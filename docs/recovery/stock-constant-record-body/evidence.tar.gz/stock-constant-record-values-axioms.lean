import FV.Backend.Proof.StockConstantRecordValues
import FV.Backend.Proof.StockAvailableValues
import FV.Backend.Proof.StockRecordIntervals
import FV.Backend.Proof.StockAliasAvailable
import FV.Backend.Proof.StockAliasTerminal
import FV.Backend.Proof.StockAliasDomain
import FV.Backend.Proof.StockSourceAliasRecords
import FV.Backend.Proof.StockSourceAliasRank
import FV.Backend.Proof.StockPayloadAliasOrigins
import FV.Backend.Proof.StockReservedTerminal
import FV.Backend.Proof.StockSourceTerminal
import FV.Backend.Proof.StockCoverageRecords
import FV.E2E.SizeIn
import FV.E2E.RelaxTotal
import FV.Link.ExeTotal
import FV.Link.Exe
import FV.E2E.LinkArm
#print axioms Backend.Stock.Proof.Coverage.statement_noOpportunity
#print axioms Backend.Stock.Proof.Coverage.branch_noOpportunity
#print axioms Backend.Stock.Proof.Coverage.emission_noOpportunity
#print axioms Backend.Stock.Proof.Coverage.statement_noOpportunity_witness
#print axioms Backend.Stock.Proof.Coverage.branch_noOpportunity_witness
#print axioms Backend.Stock.Proof.Coverage.emission_noOpportunity_witness
#print axioms Backend.Stock.Proof.Coverage.bindResults_noOpportunity
#print axioms Backend.Stock.Proof.Coverage.bindResults_noOpportunity_witness
#print axioms Backend.Stock.Proof.Coverage.retTrap_noOpportunity
#print axioms Backend.Stock.Proof.Coverage.retTrap_noOpportunity_witness
#print axioms Backend.Stock.Proof.Coverage.emission_retTrap_noOpportunity
#print axioms Backend.Stock.Proof.Coverage.emission_retTrap_noOpportunity_witness
#print axioms Backend.Stock.Proof.Coverage.scan_retTrap_noOpportunity
#print axioms Backend.Stock.Proof.Coverage.scan_retTrap_noOpportunity_witness
#print axioms Backend.Stock.Proof.Coverage.buildCtx_noOpportunity
#print axioms Backend.Stock.Proof.Coverage.buildCtx_noOpportunity_witness
#print axioms Backend.Stock.Proof.Coverage.scan_source_noOpportunity
#print axioms Backend.Stock.Proof.Coverage.scan_source_noOpportunity_witness
#print axioms Backend.Stock.Proof.Coverage.scanBlock_noOpportunity
#print axioms Backend.Stock.Proof.Coverage.scanBlock_noOpportunity_witness
#print axioms Backend.Stock.Proof.Coverage.built_scan_slots
#print axioms Backend.Stock.Proof.Coverage.built_scan_slots_witness
#print axioms Backend.Stock.Proof.Coverage.built_scanBlock_noOpportunity
#print axioms Backend.Stock.Proof.Coverage.built_scanBlock_noOpportunity_witness
#print axioms Backend.Stock.Proof.Coverage.branchArgs_noOpportunity
#print axioms Backend.Stock.Proof.Coverage.branchArgs_noOpportunity_witness
#print axioms Backend.Stock.Proof.Coverage.blockCore_noOpportunity
#print axioms Backend.Stock.Proof.Coverage.blockCore_noOpportunity_witness
#print axioms Backend.Stock.Proof.Coverage.node_noOpportunity
#print axioms Backend.Stock.Proof.Coverage.node_noOpportunity_witness
#print axioms Backend.Stock.Proof.Coverage.lower_noOpportunity
#print axioms Backend.Stock.Proof.Coverage.lower_noOpportunity_witness
#print axioms Backend.Stock.Proof.Coverage.scanBlock_records_noOpportunity
#print axioms Backend.Stock.Proof.Coverage.scanBlock_records_noOpportunity_witness
#print axioms Backend.Stock.Proof.Coverage.blockCore_records_noOpportunity
#print axioms Backend.Stock.Proof.Coverage.blockCore_records_noOpportunity_witness
#print axioms Backend.Stock.Proof.Coverage.lower_records_noOpportunity
#print axioms Backend.Stock.Proof.Coverage.lower_records_noOpportunity_witness
#print axioms Backend.Stock.Proof.Coverage.scan_noOpportunistic
#print axioms Backend.Stock.Proof.Coverage.scan_noOpportunistic_witness
#print axioms Backend.Stock.Proof.Coverage.lower_record_noOpportunistic
#print axioms Backend.Stock.Proof.Coverage.lower_record_noOpportunistic_witness
#print axioms Backend.Stock.Proof.stock_lower_undefinedSource_terminal
#print axioms Backend.Stock.Proof.stock_lower_undefinedSource_terminal_witness
#print axioms Backend.Stock.Proof.stock_lower_undefinedSource_value
#print axioms Backend.Stock.Proof.stock_lower_undefinedSource_value_witness
#print axioms Backend.Stock.Proof.allocateRequests_returnsPayloadsDisjoint
#print axioms Backend.Stock.Proof.allocateRequests_returnsPayloadsDisjoint_witness
#print axioms Backend.Stock.Proof.buildCtx_returnsPayloadsDisjoint
#print axioms Backend.Stock.Proof.buildCtx_returnsPayloadsDisjoint_witness
#print axioms Backend.Stock.Proof.stock_lower_reservedReturn_terminal
#print axioms Backend.Stock.Proof.stock_lower_reservedReturn_terminal_witness
#print axioms Backend.Stock.Proof.stock_lower_reservedReturn_resolves
#print axioms Backend.Stock.Proof.stock_lower_reservedReturn_resolves_witness
#print axioms Backend.Stock.Proof.stock_lower_reservedReturn_value
#print axioms Backend.Stock.Proof.stock_lower_reservedReturn_value_witness
#print axioms E2E.backend_correct_final_total
#print axioms E2E.backend_correct_final_total_emit_input
#print axioms E2E.backend_correct_final_total_relaxed
#print axioms E2E.LinkCheck.crate_correct_inScope_proven
#print axioms Link.compileExe_correct
#print axioms Link.compileExe_total
#print axioms Link.compileExe_spec

#print axioms Backend.Stock.Proof.stock_ctor_aliasTargetsAllowed
#print axioms Backend.Stock.Proof.stock_apply_aliasTargetsAllowed
#print axioms Backend.Stock.Proof.stock_lower_payload_aliasOrigin
#print axioms Backend.Stock.Proof.stock_lower_payload_resolves
#print axioms Backend.Stock.Proof.stock_lower_payload_terminal
#print axioms Backend.Stock.Proof.stock_lower_payload_value
#print axioms Backend.Stock.Proof.stock_ctor_aliasTargetsAllowed_witness
#print axioms Backend.Stock.Proof.stock_apply_aliasTargetsAllowed_witness
#print axioms Backend.Stock.Proof.stock_lower_payload_witness

#print axioms Backend.Stock.Proof.stock_source_provenance_rank
#print axioms Backend.Stock.Proof.stock_recorded_source_alias_provenance
#print axioms Backend.Stock.Proof.stock_recorded_source_alias_rank
#print axioms Backend.Stock.Proof.stock_recorded_source_chain_rank
#print axioms Backend.Stock.Proof.stock_recorded_source_chain_noCycle
#print axioms Backend.Stock.Proof.stock_source_provenance_rank_witness
#print axioms Backend.Stock.Proof.stock_recorded_source_chain_witness

#print axioms Backend.Stock.Proof.stock_lower_source_alias_record
#print axioms Backend.Stock.Proof.stock_lower_source_alias_emitted_record
#print axioms Backend.Stock.Proof.stock_lower_final_source_alias_recorded
#print axioms Backend.Stock.Proof.stock_lower_final_source_chain_rank
#print axioms Backend.Stock.Proof.stock_lower_final_source_chain_noCycle
#print axioms Backend.Stock.Proof.stock_lower_final_source_chain_witness

#print axioms Backend.Stock.Proof.stock_lower_alias_key_origin
#print axioms Backend.Stock.Proof.stock_lower_alias_key_origin_witness

#print axioms Backend.Stock.Proof.stock_lower_alias_wellFounded
#print axioms Backend.Stock.Proof.stock_lower_alias_terminal
#print axioms Backend.Stock.Proof.stock_lower_alias_idempotent
#print axioms Backend.Stock.Proof.stock_lower_alias_step
#print axioms Backend.Stock.Proof.stock_lower_alias_value
#print axioms Backend.Stock.Proof.stock_lower_alias_terminal_witness

#print axioms Backend.Stock.Proof.stock_lower_blockScanInitialFrontier
#print axioms Backend.Stock.Proof.stock_lower_blockScanInitialFrontier_witness
#print axioms Backend.Stock.Proof.stock_lower_source_alias_provenance
#print axioms Backend.Stock.Proof.stock_lower_source_alias_available
#print axioms Backend.Stock.Proof.stock_lower_source_path_available
#print axioms Backend.Stock.Proof.stock_lower_source_path_fresh_origin
#print axioms Backend.Stock.Proof.stock_lower_source_alias_available_witness
#print axioms Backend.Stock.Proof.stock_lower_source_path_fresh_origin_witness

#print axioms Backend.Stock.Proof.stock_lower_record_intervals
#print axioms Backend.Stock.Proof.stock_lower_record_intervals_disjoint
#print axioms Backend.Stock.Proof.stock_lower_available_alias_outside_record
#print axioms Backend.Stock.Proof.stock_lower_available_fresh_frame
#print axioms Backend.Stock.Proof.stock_lower_record_intervals_witness

#print axioms Backend.Stock.Proof.available_before_of_after_not_result

#print axioms Backend.Stock.Proof.ValuesHeld.resolvedResult_change_needed

#print axioms Backend.Stock.Proof.ValuesHeld.resolvedResult_available

#print axioms Backend.Stock.Proof.stock_iconst_available_resolved

#print axioms Backend.Stock.Proof.stock_available_values_witness

#print axioms Backend.Stock.Proof.stock_iconst_resolved

#print axioms Backend.Stock.Proof.stock_lower_record_context

#print axioms Backend.Stock.Proof.stock_lower_constant_available_values

#print axioms Backend.Stock.Proof.stock_lower_constant_available_values_witness

#print axioms Backend.Stock.Proof.stock_statement_selectedConstant_context_receipts

#print axioms Backend.Stock.Proof.stock_lower_constant_available_source
