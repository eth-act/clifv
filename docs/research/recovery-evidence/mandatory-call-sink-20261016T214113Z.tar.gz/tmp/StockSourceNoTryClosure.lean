import FV.Backend.Proof.IselScopedProjection
import FV.Backend.Proof.StockContext
namespace Backend.Stock.Proof.SourceNoTryClosureDraft
open Isle Isle.Interp Isle.Aarch64
set_option maxRecDepth 30000
set_option maxHeartbeats 8000000
attribute [local irreducible] Isle.Aarch64.program
private def part0 : List Nat := [31, 87, 90, 93, 94, 102, 118, 130, 131, 132, 140, 156, 157, 159, 160, 161, 162, 163, 164, 166, 168, 169, 170, 171, 172, 173, 174, 175, 178, 181, 182, 183, 184, 185, 187, 189, 201, 203, 208, 220, 221, 234, 235, 236, 237, 239, 242, 243]
private def part1 : List Nat := [246, 249, 250, 251, 254, 255, 256, 257, 262, 264, 278, 286, 287, 288, 294, 295, 296, 297, 298, 299, 303, 304, 305, 306, 307, 308, 309, 310, 311, 312, 316, 317, 318, 319, 320, 321, 322, 323, 324, 326, 327, 328, 331, 332, 333, 334, 335, 336]
private def part2 : List Nat := [337, 338, 344, 346, 347, 348, 349, 350, 351, 352, 355, 356, 357, 358, 359, 360, 361, 362, 363, 364, 365, 366, 367, 368, 369, 370, 371, 372, 373, 374, 375, 376, 377, 378, 379, 380, 381, 382, 383, 384, 385, 386, 387, 388, 389, 390, 391, 392]
private def part3 : List Nat := [393, 394, 395, 396, 398, 400, 401, 402, 403, 404, 405, 406, 407, 408, 409, 410, 411, 412, 413, 414, 415, 416, 417, 418, 419, 420, 421, 422, 423, 424, 425, 426, 427, 428, 429, 430, 431, 432, 433, 434, 435, 436, 437, 438, 439, 440, 441, 442]
private def part4 : List Nat := [443, 444, 445, 446, 447, 448, 449, 450, 451, 452, 453, 454, 455, 456, 457, 458, 459, 460, 461, 462, 463, 464, 465, 466, 467, 468, 469, 470, 471, 472, 473, 474, 475, 476, 477, 478, 479, 480, 481, 482, 483, 484, 485, 486, 487, 488, 489, 490]
private def part5 : List Nat := [491, 492, 493, 494, 495, 496, 497, 498, 499, 500, 501, 502, 503, 504, 505, 506, 507, 508, 509, 510, 511, 512, 513, 514, 515, 516, 517, 518, 519, 520, 521, 522, 523, 524, 525, 526, 527, 528, 529, 530, 531, 532, 533, 534, 535, 536, 537, 538]
private def part6 : List Nat := [539, 540, 541, 542, 543, 544, 545, 546, 547, 548, 549, 550, 551, 552, 553, 554, 555, 556, 557, 558, 559, 560, 561, 562, 563, 564, 565, 566, 567, 568, 569, 570, 571, 572, 573, 574, 575, 576, 577, 578, 579, 580, 581, 582, 583, 584, 585, 586]
private def part7 : List Nat := [587, 589, 590, 591, 592, 593, 594, 595, 598, 599, 600, 601, 602, 605, 606, 607, 608, 609, 610, 611, 612, 613, 614, 615, 616, 617, 618, 619, 620, 621, 622, 623, 624, 625, 626, 627, 628, 629, 630, 631, 632, 633, 634, 635, 636, 637, 638, 639]
private def part8 : List Nat := [640, 641, 642, 643, 644, 645, 646, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 659, 660, 671, 672, 673, 674, 675, 676, 677, 678, 679, 680, 681, 682, 683, 684, 686, 693, 694, 695, 696, 697, 698, 699, 700, 701, 702, 703, 704]
private def part9 : List Nat := [705, 706, 707, 708, 709, 710, 711, 712, 713, 714, 715, 716, 717, 718, 719, 720, 721, 978, 1154, 1157, 1159, 1161, 1164, 1167, 1178, 1180, 1182, 1199, 1378, 1382, 1427, 1431, 1455, 1485, 1514, 1780, 1781, 1782, 1783, 1784, 1787, 1788, 1789, 1791, 1792, 1794, 1795, 1796]
private def part10 : List Nat := [1798, 1799, 1800, 1801, 1802, 1803, 1816, 1817, 1820, 1821, 1822, 1823, 1824, 1825, 1826, 1827, 1828, 1829, 1830, 1831, 1832, 1833, 1834, 1835, 1836, 1837, 1838, 1839, 1840, 1842, 1843, 1844, 1846, 1847, 1849, 1850, 1851, 1852, 1853, 1854, 1855, 1856, 1857, 1858, 1859, 1860, 1861, 1862]
private def part11 : List Nat := [1863, 1867, 1868, 1869, 1870, 1871, 1872, 1873, 1874, 1875, 1876, 1877, 1878, 1879, 1880, 1881, 1882, 1887, 1888, 1889, 1890, 1891, 1892, 1893, 1894, 1895, 1896, 1897, 1898, 1899, 1900, 1901, 1902, 1903, 1904, 1905, 1906, 1908, 1909, 1910, 1911, 1912, 1913, 1914, 1915, 1916, 1917, 1918]
private def part12 : List Nat := [1919, 1921, 1923, 1924, 1927, 1928, 1929, 1930, 1938, 1940, 1941, 1947, 1948, 1949, 1952, 1955, 1956, 1959, 1960, 1962, 1963, 1964, 1965, 1966, 1967, 1968, 1969, 1970, 1971, 1972, 1973, 1974, 1975, 1976, 1977, 1978, 1979, 1980, 1981, 1982, 1983, 1984, 1985, 1986, 1987, 1988, 1989, 1990]
private def part13 : List Nat := [1991, 1992, 1996, 1997, 1998, 2000, 2001, 2002, 2004, 2005, 2006, 2007, 2008, 2009, 2012, 2013, 2014, 2015, 2016, 2017, 2021, 2022, 2024, 2025, 2028, 2029, 2032, 2033, 2034, 2035, 2036, 2037, 2038, 2039, 2040, 2041, 2042, 2043, 2044, 2045, 2046, 2047, 2048, 2049, 2050, 2053, 2054, 2055]
private def part14 : List Nat := [2056, 2057, 2058, 2059, 2060, 2061, 2062, 2063, 2064, 2065, 2066, 2067, 2068, 2069, 2070, 2071, 2072, 2073, 2074, 2075, 2076, 2077, 2078, 2079, 2080, 2081, 2082, 2083, 2084, 2085, 2086, 2087, 2088, 2089, 2090, 2091, 2092, 2093, 2094, 2095, 2096, 2097, 2098, 2099, 2100, 2101, 2102, 2103]
private def part15 : List Nat := [2104, 2105, 2106, 2107, 2108, 2109, 2110, 2111, 2112, 2113, 2114, 2115, 2116, 2117, 2118, 2119, 2120, 2121, 2122, 2123, 2124, 2125, 2126, 2127, 2128, 2129, 2130, 2131, 2132, 2133, 2134, 2135, 2136, 2137, 2138, 2139, 2140, 2141, 2142, 2143, 2144, 2145, 2146, 2147, 2148, 2149, 2150, 2151]
private def part16 : List Nat := [2152, 2153, 2154, 2155, 2156, 2157, 2158, 2159, 2160, 2161, 2162, 2163, 2164, 2165, 2166, 2171, 2177, 2180, 2181, 2182, 2183, 2184, 2185, 2186, 2187, 2188, 2189, 2190, 2191, 2194, 2196, 2197, 2198, 2199, 2200, 2201, 2202, 2203, 2204, 2205, 2206, 2207, 2208, 2209, 2210, 2211, 2212, 2213]
private def part17 : List Nat := [2215, 2216, 2217, 2218, 2219, 2220, 2221, 2222, 2223, 2224, 2225, 2234, 2235, 2236, 2237, 2238, 2239, 2240, 2242, 2243, 2271, 2272, 2273, 2275, 2276, 2277]
private def sourceIds : List Nat := part0 ++ part1 ++ part2 ++ part3 ++ part4 ++ part5 ++ part6 ++ part7 ++ part8 ++ part9 ++ part10 ++ part11 ++ part12 ++ part13 ++ part14 ++ part15 ++ part16 ++ part17
private def ruleCalls (r : Rule) : List Nat := r.iflets.flatMap (fun il => exprCalls il.rhs) ++ exprCalls r.rhs
private def checkTerm (id : Nat) : Bool :=
  match termOf program id with
  | .error _ => false
  | .ok term => term.id != TId.gen_try_call_rets &&
      (program.rulesOf id).all (fun r => (ruleCalls r).all (sourceIds.contains ·))
section Certificate
attribute [local semireducible] Isle.Aarch64.program
private theorem checked0 : part0.all checkTerm = true := by decide +kernel
private theorem checked1 : part1.all checkTerm = true := by decide +kernel
private theorem checked2 : part2.all checkTerm = true := by decide +kernel
private theorem checked3 : part3.all checkTerm = true := by decide +kernel
private theorem checked4 : part4.all checkTerm = true := by decide +kernel
private theorem checked5 : part5.all checkTerm = true := by decide +kernel
private theorem checked6 : part6.all checkTerm = true := by decide +kernel
private theorem checked7 : part7.all checkTerm = true := by decide +kernel
private theorem checked8 : part8.all checkTerm = true := by decide +kernel
private theorem checked9 : part9.all checkTerm = true := by decide +kernel
private theorem checked10 : part10.all checkTerm = true := by decide +kernel
private theorem checked11 : part11.all checkTerm = true := by decide +kernel
private theorem checked12 : part12.all checkTerm = true := by decide +kernel
private theorem checked13 : part13.all checkTerm = true := by decide +kernel
private theorem checked14 : part14.all checkTerm = true := by decide +kernel
private theorem checked15 : part15.all checkTerm = true := by decide +kernel
private theorem checked16 : part16.all checkTerm = true := by decide +kernel
private theorem checked17 : part17.all checkTerm = true := by decide +kernel
private theorem checked : sourceIds.all checkTerm = true := by
  simp only [sourceIds,List.all_append,checked0,checked1,checked2,checked3,checked4,checked5,checked6,checked7,checked8,checked9,checked10,checked11,checked12,checked13,checked14,checked15,checked16,checked17,Bool.and_self]
end Certificate
/-- A kernel-checked closure of the actual statement-root rules excludes the
reserved-return constructor. No accepted-program certificate is required. -/
theorem stock_source_no_try_constructor_closure :
    TId.lower ∈ sourceIds ∧ ∀ t ∈ sourceIds,∀ term,termOf program t = .ok term →
      term.id ≠ TId.gen_try_call_rets ∧
      ∀ r ∈ program.rulesOf t, RuleScoped (fun u => u ∈ sourceIds) r := by
  refine ⟨by decide,?_⟩
  intro t member term lookup
  have fact := List.all_eq_true.mp checked t member
  simp only [checkTerm,lookup,Bool.and_eq_true,bne_iff_ne] at fact
  refine ⟨fact.1,?_⟩
  intro r recorded
  have calls := List.all_eq_true.mp fact.2 r recorded
  have contains : ∀ u ∈ ruleCalls r,u ∈ sourceIds := by
    intro u inside
    have yes := List.all_eq_true.mp calls u inside
    simpa using yes
  constructor
  · intro il inside u called
    exact contains u (List.mem_append_left _ (List.mem_flatMap.mpr ⟨il,inside,called⟩))
  · intro u called
    exact contains u (List.mem_append_right _ called)
end Backend.Stock.Proof.SourceNoTryClosureDraft
