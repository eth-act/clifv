from pathlib import Path
import json,hashlib,re,datetime,tarfile,shutil
root=Path('/home/lee/clifv/.worktrees/driver-proof-resume');docs=root/'docs/research';prefix='stock-try-critical-normal'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
now=datetime.datetime.now(datetime.timezone.utc);stamp=now.strftime('%Y%m%dT%H%M%SZ')
batch=json.loads(Path('/tmp/'+prefix+'-batch.json').read_text());old=json.loads((docs/'stock-try-normal-vector-scratch.json').read_text())
log=Path('/tmp/'+prefix+'-combined-axioms.log').read_text()
sets={m.group(1):sorted(x.strip() for x in m.group(2).split(',') if x.strip()) for m in re.finditer(r"'([^']+)' depends on axioms:\s*\[([^]]*)\]",log)}
for m in re.finditer(r"'([^']+)' does not depend on any axioms",log):sets[m.group(1)]=[]
for n,a in old['normal_audit']['sets'].items():assert sorted(a)==sets[n],n
assert len(sets)==len(old['normal_audit']['sets'])+len(batch['public_roots'])+len(batch['models'])
allowed={'propext','Classical.choice','Quot.sound'}
for n in batch['public_roots']+batch['models']:assert set(sets[n])<=allowed,n
constants=[json.loads(line.split('DELIVERY_CONSTANT ',1)[1]) for line in Path('/tmp/'+prefix+'-all-constants.log').read_text().splitlines() if line.startswith('DELIVERY_CONSTANT ')]
assert constants
for n,a in constants:assert set(a)<=allowed,n
mods={}
for m in batch['modules']:
 p=Path('/tmp')/m;check=json.loads(p.with_suffix('.check.json').read_text());assert check['actual_exit']==0
 rec={}
 for key,ext in [('source','.lean'),('object','.olean'),('log','.log'),('check','.check.json')]:
  f=p.with_suffix(ext);rec[key]=str(f);rec[key+'_sha256']=sha(f)
 for k in ['source','object','log']:assert rec[k+'_sha256']==check[k+'_sha256']
 assert not re.search(r'\b(sorry|admit|axiom|trace_state|native_decide)\b',p.with_suffix('.lean').read_text()),m
 mods[m]=rec
for audit in [prefix+'-combined-axioms',prefix+'-all-constants']:
 p=Path('/tmp')/audit;check=json.loads(p.with_suffix('.check.json').read_text());assert check['actual_exit']==0
 for k,ext in [('source','.lean'),('object','.olean'),('log','.log')]:assert sha(p.with_suffix(ext))==check[k+'_sha256']
prior={}
for name in ['source-execution-x','try-source','try-context','try-rule','try-rets','try-reservation','try-outgoing','try-values','try-emitted','try-machine','try-got','try-indirect','try-rename','try-resolved','try-gap','try-got-rename','try-normal-frame','try-metadata','source-index','try-normal-vector']:
 d=json.loads((docs/f'stock-{name}-scratch.json').read_text())
 for m,rec in d['modules'].items():
  for k in ['source','object','log']:assert sha(rec[k])==rec[k+'_sha256'],(m,k)
  prior[m]=rec
freeze=json.loads(Path('/tmp/stock-coherent-build-inputs.json').read_text())
for group in ['source_sha256','validation_script_sha256']:
 for p,h in freeze[group].items():assert sha(root/p)==h,p
progress=json.loads(Path('/tmp/stock-pr246-gates-progress.json').read_text());progress.pop('completed_phases',None)
closure='StockSourceNoTryClosure' in mods
remaining=list(old['remaining_checklist']);remaining.append({'requirement':'Actual synthetic TryCall normal-column register vector and complete critical witness','state':'Kernel proved from original lowering/scope/input and actual edge tag; SAME real RHS return constructor/exact defs/base and actual synthetic edge row[0]. Complete GOT/true-indirect sources preserve unreachable predecessor, source indegree2, actual forced split and all compiler/prepare/fallback/checker/physical stages plus full source17. Static REGISTER-VECTOR only; machine live-source frame, VALUE transfer, real parameter copies and continuation remain open.'})
remaining.append({'requirement':'Source-root constructor exclusion and available-source reserved-write noninterference','state':('Kernel-checked 842-term syntactic closure excludes actual gen_try_call_rets term.id; lower root belongs to closure. Checked in bounded chunks after monolithic8GiB kill. ' if closure else 'Exploratory evaluator finds842 reachable terms and no gen_try_call_rets; not a proof. ')+'Context-erasure proof attempt fails at constructor simplification heartbeat; retained as failed experiment, excluded from proof counts/audits. Actual source-run context erasure, stronger alias provenance and machine noninterference remain OPEN.'})
counts={'modules':len(mods),'public_roots':len(batch['public_roots']),'models':len(batch['models']),'combined_roots_models':len(sets),'previous_preserved':len(old['normal_audit']['sets']),'all_new_module_constants':len(constants),'previous_modules_hashes_preserved':len(prior)}
receipt={'utc':now.isoformat(),'goal':'Original full #140 ACTIVE/INCOMPLETE; production LEGACY','scope':'Scratch-only additive Stock proofs, not coherent integration or merge-ready','delivery_target':'roughly eight substantive validated squash merges/day; prioritize coherent queue, backup and cleanup','modules':mods,'public_roots':batch['public_roots'],'models':batch['models'],'counts':counts,'normal_audit':{'path':'/tmp/'+prefix+'-combined-axioms.log','sha256':sha('/tmp/'+prefix+'-combined-axioms.log'),'sets':sets},'all_constant_audit':{'path':'/tmp/'+prefix+'-all-constants.log','sha256':sha('/tmp/'+prefix+'-all-constants.log'),'all_standard_only':True,'count':len(constants)},'previous_modules_hashes_preserved':list(prior),'canonical2246_source_and_script_freeze_preserved':True,'MCP':'Deferred until coherent integration; no new calls','active_exact_PR246_validation':progress,'remaining_checklist':remaining}
(docs/(prefix+'-scratch.json')).write_text(json.dumps(receipt,indent=2)+'\n')
text=f'''Actual synthetic TryCall normal register vectors — {now.isoformat()}

{len(mods)} scratch modules/{len(batch['public_roots'])}public roots pass actual8GiB kernel checks. The {len(sets)}-root/model cumulative audit preserves all623prior exact axiom sets. All{len(constants)}new-module constants, including private/generated helpers, use only standard axioms. All{len(prior)}prior source/object/log hashes and frozen2246canonical sources/49validation scripts remain unchanged. Previous goal turn was a verified wait of exact246gate, with live process inspected; this turn completes new critical-edge proof and full witnesses.

The actual whole-driver factory now handles normal successors represented by synthetic .edge nodes. Original lower/scope/input and actual original/source/edge tags internally construct the SAME selected branch, actual intermediate gen_try_call_rets, exact callDefs, canonical base/layout and ACTUAL critical branchArgs. Final alias resolution equals the normal .val/.ret numeric model, stored in actual returned Result.edgeArgs[edgeLabel][0]. No caller layout/state/alias/helper/outgoing certificate is added.

Complete GOT/true-indirect witnesses reuse cached full compiler/prepare/forced checkedfallback/checker/physical pipelines. The original unreachable block2 remains in the source and contributes indegree2, actually forcing the one-successor TryCall split. Original block2 is absent from output nodes and actual edge0/0/1 appears at label1. SAME helper/defs, actual normal edge row, one-element return column and full Clif.runWith returning17 are proved. These are REGISTER-VECTOR receipts, not machine VALUE/copy/continuation proofs. Near-critical and exceptional/full-return matrix still require coverage.

'''+remaining[-1]['state']+f'''

ALL original source/reserved frame, normal VALUE transfer/copies/continuation, exact shared payload endpoints/exception semantics, zero-return/sret/x8/width/handler/Try-critical matrix, uncovered families/effects/sinking/source/block/whole-driver simulation AND completeness, original-input context/visitor/static/checker/fallback/physical totality, coherent scratch integration and public/private/compiler/MCP/full/crates/runtime/encoder/BOTH E2E identity-stage parity, production compiler/checker/linker/generated consumers and fresh COMPLETE comparison remain required. Production LEGACY. Shared exceptional interfaces #232/#233 remain @kevaundray boundary.

Main0ec59a028dd3a27911cb22554b3e292b20a5c45f unchanged and threeCIchecks each246/247 PASS. Same live3247835/exclusive cache lease and deliberately held canonical1233457. Preserve old-head receipts, reconcile current main and rerun all required actual-head gates before dependent squash merges. Target8substantive validated merges/day; no merge/new worktree/MCP/heavy retry/gate restart this batch. Evidence/full remaining checklist: {prefix}-scratch.json.
'''
(docs/(prefix+'-scratch.md')).write_text(text)
plan=root/'docs/plans/test-binary-alignment-recovery.md';plan.write_text(plan.read_text()+'\n\n'+text)
files=[]
for rec in mods.values():files.extend(Path(rec[k]) for k in ['source','object','log','check'])
for name in [prefix+'-combined-axioms',prefix+'-all-constants']:
 for ext in ['.lean','.log','.olean','.check.json']:files.append(Path('/tmp')/(name+ext))
for name in ['StockSourceConstructorReach','StockSourceConstructorReachIds','StockTryContextErasure']:
 for ext in ['.lean','.log','.olean','.check.json']:
  p=Path('/tmp')/(name+ext)
  if p.exists():files.append(p)
for p in ['/tmp/'+prefix+'-batch.json','/tmp/stock-try-rule-inputs.json','/tmp/stock-try-reservation-check.py','/tmp/'+prefix+'-close.py','/tmp/'+prefix+'-make-audit.py','/tmp/stock-source-no-try-make-closure.py','/tmp/stock-source-no-try-extra-inputs.py','/tmp/'+prefix+'-status44-start.md','/tmp/stock-current-status52.json','/tmp/stock-current-status71.json','/tmp/stock-current-task140.json']:
 if Path(p).exists():files.append(Path(p))
files.extend([docs/(prefix+'-scratch.json'),docs/(prefix+'-scratch.md'),docs/'stock-delivery-main-drift.json',plan])
archive=Path('/home/lee/.clifv-recovery')/(stamp+'-try-critical-normal')/'checkpoint.tar.gz';archive.parent.mkdir(parents=True)
with tarfile.open(archive,'w:gz',compresslevel=1) as t:
 for p in files:t.add(p,arcname=str(p).lstrip('/'),recursive=False)
with tarfile.open(archive,'r:gz') as t:
 for p in files:assert t.extractfile(str(p).lstrip('/')).read()==p.read_bytes(),p
snapshot=Path('/tmp/stock-try-rule-inputs');size=sum(p.stat().st_size for p in snapshot.rglob('*') if p.is_file());shutil.rmtree(snapshot)
backup={'utc':now.isoformat(),'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(files),'all_members_byte_verified':True,'previous_remote_backup':json.loads((docs/'stock-try-normal-vector-backup.json').read_text())['remote'],'cleanup':{'duplicate_dependency_snapshot_removed':True,'bytes_reclaimed':size,'unique_sources_objects_logs_checks_audits_preserved':True,'one_shared_warm_cache_retained':True,'other_projects_touched':False,'free_bytes':shutil.disk_usage(root).free}}
(docs/(prefix+'-backup.json')).write_text(json.dumps(backup,indent=2)+'\n');Path('/tmp/'+prefix+'-archive-path').write_text(str(archive))
print(json.dumps({'counts':counts,'archive':str(archive),'cleanup':backup['cleanup'],'gate':progress},indent=2))
