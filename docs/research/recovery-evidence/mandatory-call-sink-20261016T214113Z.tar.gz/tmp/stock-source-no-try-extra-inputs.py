from pathlib import Path
import re,json,hashlib,datetime,time
root=Path('/home/lee/clifv/.worktrees/driver-proof-resume');dst=Path('/tmp/stock-try-rule-inputs');seen=set();records=json.loads(Path('/tmp/stock-try-rule-inputs.json').read_text())['modules']
def visit(m):
 if m in seen:return
 p=(Path('/tmp')/(m+'.lean')) if m.startswith('Stock') else root/(m.replace('.','/')+'.lean')
 if not p.exists():return
 seen.add(m)
 obj=p.with_suffix('.olean') if m.startswith('Stock') else root/'.lake/build/lib/lean'/(m.replace('.','/')+'.olean')
 q=dst/(m.replace('.','/')+'.olean')
 while not q.exists() and not obj.exists():
  assert 'stock-pr246-gates.py' in Path('/proc/3247835/cmdline').read_text()
  print('Waiting for current exact-PR object:',m,flush=True)
  time.sleep(5)
 data=q.read_bytes() if q.exists() else obj.read_bytes()
 q.parent.mkdir(parents=True,exist_ok=True)
 if not q.exists():q.write_bytes(data)
 records[m]={'source':str(p),'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'object':str(obj),'snapshot':str(q),'object_sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
 for line in re.findall(r'^(?:(?:public|private)\s+)?import\s+([^\n]+)',p.read_text(),re.M):
  for n in line.split():visit(n)
for m in ['FV.Backend.Proof.IselScopedProjection','FV.Backend.Proof.StockCriticalSplitWitness']:visit(m)
Path('/tmp/stock-try-rule-inputs.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'owner':'codygunton/#44','purpose':'Temporary source-specialization import objects; remove after actual check. No build IR or copied warm cache.','modules':records},indent=2)+'\n');print('snapshot modules',len(records),'bytes',sum(v['bytes'] for v in records.values()))
