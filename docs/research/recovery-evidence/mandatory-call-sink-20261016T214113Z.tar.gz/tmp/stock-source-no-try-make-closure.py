import re,json
from pathlib import Path
s=Path('/tmp/StockSourceConstructorReachIds.log').read_text();raw=re.findall(r'^"([0-9,]+)"$',s,re.M)[0];ids=[int(x) for x in raw.split(',')];assert len(ids)==842 and 300 not in ids and 686 in ids
out='''import FV.Backend.Proof.IselScopedProjection
import FV.Backend.Proof.StockContext
namespace Backend.Stock.Proof.SourceNoTryClosureDraft
open Isle Isle.Interp Isle.Aarch64
set_option maxRecDepth 30000
set_option maxHeartbeats 8000000
attribute [local irreducible] Isle.Aarch64.program
private def sourceIds : List Nat := '''+str(ids)+'''
private def ruleCalls (r : Rule) : List Nat := r.iflets.flatMap (fun il => exprCalls il.rhs) ++ exprCalls r.rhs
private def checkTerm (id : Nat) : Bool :=
  match termOf program id with
  | .error _ => false
  | .ok term => term.id != TId.gen_try_call_rets &&
      (program.rulesOf id).all (fun r => (ruleCalls r).all (sourceIds.contains ·))
section Certificate
attribute [local semireducible] Isle.Aarch64.program
private theorem checked : sourceIds.all checkTerm = true := by decide +kernel
end Certificate
/-- A kernel-checked closure of the actual statement-root rules excludes the
reserved-return constructor. No accepted-program certificate is required. -/
theorem stock_source_no_try_constructor_closure :
    TId.lower ∈ sourceIds ∧ ∀ t ∈ sourceIds,∀ term,termOf program t = .ok term →
      term.id ≠ TId.gen_try_call_rets ∧
      ∀ r ∈ program.rulesOf t, RuleScoped (fun u => u ∈ sourceIds) r := by
  refine ⟨by decide,?_⟩
  intro t member term lookup
  have fact := List.all_eq_true.mp checked t member
  simp only [checkTerm,lookup,Bool.and_eq_true,bne_iff_ne] at fact
  refine ⟨fact.1,?_⟩
  intro r recorded
  have calls := List.all_eq_true.mp fact.2 r recorded
  have contains : ∀ u ∈ ruleCalls r,u ∈ sourceIds := by
    intro u inside
    have yes := List.all_eq_true.mp calls u inside
    simpa using yes
  constructor
  · intro il inside u called
    exact contains u (List.mem_append_left _ (List.mem_flatMap.mpr ⟨il,inside,called⟩))
  · intro u called
    exact contains u (List.mem_append_right _ called)
end Backend.Stock.Proof.SourceNoTryClosureDraft
'''
Path('/tmp/StockSourceNoTryClosure.lean').write_text(out)
