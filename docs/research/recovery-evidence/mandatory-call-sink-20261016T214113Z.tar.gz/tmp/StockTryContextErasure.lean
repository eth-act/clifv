import FV.Backend.Proof.StockContext
namespace Backend.Stock.Proof.TryContextErasureDraft
open Isle Isle.Interp Isle.Aarch64
set_option maxRecDepth 20000
set_option maxHeartbeats 0
private theorem legacy_ctor (ctx : Ctx) (term : Term) (args : List V) (st : LState)
    (excluded : term.id ≠ TId.gen_try_call_rets) :
    Backend.externCtor {ctx with tryRegs := ([],[])} term args st = Backend.externCtor ctx term args st := by
  unfold Backend.externCtor
  split
  · rfl
  · split <;> first | (solve | simp_all only [TId.gen_try_call_rets]) | rfl
end Backend.Stock.Proof.TryContextErasureDraft
