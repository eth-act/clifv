import FV.Backend.Proof.IselScopedProjection
import FV.Backend.Proof.StockContext
namespace Backend.Stock.Proof.SourceConstructorReachAnalysis
open Isle Isle.Interp Isle.Aarch64
def callees (p : Program) (t : Nat) : List Nat :=
  (p.rulesOf t).flatMap fun r => (r.iflets.flatMap fun il => exprCalls il.rhs) ++ exprCalls r.rhs
def visit (p : Program) : Nat → List Nat → List Nat → List Nat × List Nat
  | 0,todo,seen => (seen,todo)
  | n+1,[],seen => (seen,[])
  | n+1,t :: todo,seen =>
    if seen.contains t then visit p n todo seen
    else visit p n (todo ++ callees p t) (t :: seen)
#eval let result := visit program 50000 [TId.lower] []
  (result.1.length,result.2.length,result.1.contains TId.gen_try_call_rets)
end Backend.Stock.Proof.SourceConstructorReachAnalysis
