Derive actual add/sub body simulation for arbitrary pure single-block bodies from original input syntax and successful Stock lowering. Earlier composition required a per-record family/result-map certificate. This packet derives original source information through the actual terminator override, singleton result arity, successful result binding and emitted/omitted family coverage, then composes the existing guarded source/machine semantics. Old variants and input conditions are retained.

Complete witnesses cover a nonempty real source/event and actual dirty-input machine execution through the new body theorem. This proves ordinary-body value simulation; whole-function entry/return composition, direct optimized-Stock checker/consumers, remaining families/effects and original #140 completeness remain active. Production class selection is unchanged.

Validation on `b382a3e5e3ad4ef1231f1ab6ba0a19d69179dd61` plus receipt-only `97d014cbb86d570e463420de89e243cd23b49381`:

- Exact hashes prove all previously verified source/audit files from merged#338 unchanged. Scheduler checks the two new modules within16GiB, then complete `lake build FV FVTest` replay passes.
- All28checked-in audit files pass;1042previous public root axiom sets retained exactly,7newpublic roots audited.
- All27newcoreownedconstants use standard axioms;2fixedwitnessconstants use only previously marked ScalarAddScanWitness native trace facts. Targeted complete builds648jobs.
- Import closure reaches no runtime consumer/executable; runtime inputs byte-identical to mergedmain, so runtime gates are outside this proof-only change.

Terminal receipt: `docs/research/stock-arithmetic-body-author-gates.json`. Full original#140 remains open.
