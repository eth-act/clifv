from pathlib import Path
import json,subprocess as sp,os,hashlib,datetime,traceback,re
view=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');root=Path('/tmp/stock-arithmetic-author-gates');root.mkdir(exist_ok=True)
head=sp.check_output(['git','rev-parse','HEAD'],cwd=view,text=True).strip();base='5f7350fa143f4a3f7f1c9fab5f5e0c679b45fb7d';logs={}
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
env=dict(os.environ,FV_MEMCAP='8G',FV_LAKE_CACHE='/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache',LEAN_NUM_THREADS='2',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2');env['PATH']='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:'+env['PATH']
def report(state,**kw):
 d=dict(state=state,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=os.getpid(),head=head,base=base,logs=logs,**kw);(root/'progress.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items() if k!='logs'}),flush=True)
def inputs():return {str(p.relative_to(view)):sha(p) for folder in ['FV','FVTest','scripts/audit'] for p in (view/folder).rglob('*.lean')}
frozen=inputs();(root/'inputs.json').write_text(json.dumps(frozen,indent=2)+'\n')
def run(name,args,scheduler=False):
 assert inputs()==frozen
 assert sp.check_output(['git','rev-parse','HEAD'],cwd=view,text=True).strip()==head
 log=root/(name+'.log');report('running',phase=name,log=str(log))
 with log.open('w') as f:r=sp.run(args if scheduler else ['scripts/memcap.sh',*args],cwd=view,env=env,stdout=f,stderr=sp.STDOUT)
 assert r.returncode==0,(name,r.returncode,str(log));assert inputs()==frozen;logs[name]={'path':str(log),'sha256':sha(log)}
try:
 previous=json.loads(Path('/tmp/stock-pure-proof-author-gates/progress.json').read_text());assert previous['state']=='per_pr_gates_passed'
 landing=json.loads(Path('/tmp/stock-pure-proof-landing/progress.json').read_text());assert landing['state']=='landed_and_integrator_notified' and landing['merge_commit']==base
 old=json.loads(Path('/tmp/stock-pure-proof-author-gates/inputs.json').read_text())['sources']
 assert all(frozen.get(p)==h for p,h in old.items()),'previously verified source changed'
 added=sorted(set(frozen)-set(old));assert added==['FV/Backend/Proof/StockArithmeticBodyRefines.lean','FV/Backend/Proof/StockArithmeticBodyWitness.lean','scripts/audit/stock-arithmetic-body.lean'],added
 modules=[p[:-5].replace('/','.') for p in added if p.startswith('FV/')]
 deps={};pat=re.compile(r'^(?:public\s+|private\s+|meta\s+)*import\s+(\S+)')
 for folder in ['FV','FVTest']:
  for p in (view/folder).rglob('*.lean'):
   deps[str(p.relative_to(view))[:-5].replace('/','.')]=set(m.group(1) for line in p.read_text().splitlines() if (m:=pat.match(line)))
 affected=set(modules)
 while True:
  more={m for m,d in deps.items() if d&affected}-affected
  if not more:break
  affected|=more
 assert affected==set(modules),affected
 manifest={'previous_exact_merged_base':base,'previous_modules_passed':2426,'all_previous_source_and_audit_hashes_unchanged':True,'new_modules':modules,'affected_modules':sorted(affected),'affected_executables':[],'runtime_input_changes':False,'reuse':'scheduler --only after exact prior source-hash/merged-tree validation; full FV/FVTest target replay follows'}
 (root/'reuse-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');only=root/'affected-modules.txt';only.write_text('\n'.join(sorted(affected))+'\n')
 run('affected-scheduler',['python3','/tmp/stock-execute-scheduler.py','--budget','16G','--max-jobs','3','--max-cap','16G','--default-cap','8G','--others-by-usage','--only',str(only),'--out',str(root/'affected-scheduler'),'FV','FVTest'],True)
 run('full-library-replay',['lake','build','FV','FVTest'])
 run('all-axiom-audits',['python3','scripts/axiom-audit.py','--log-dir',str(root/'axiom-audit')])
 run('all-new-owned',['lake','env','lean','--root=/tmp','/tmp/stock-arithmetic-body-owned.lean'])
 def axs(folder):
  result={}
  for p in Path(folder).glob('*.log'):
   flat=' '.join(p.read_text().split())
   for n,a in re.findall(r"'(.+?)' depends on axioms: \[([^\]]*)\]",flat):result[n]=sorted(x.strip() for x in a.split(',') if x.strip())
   for n in re.findall(r"'(.+?)' does not depend on any axioms",flat):result[n]=[]
  return result
 before=axs('/tmp/stock-pure-proof-author-gates/axiom-audit');after=axs(root/'axiom-audit');assert before
 missing=sorted(set(before)-set(after));changed={n:{'before':v,'after':after.get(n)} for n,v in before.items() if n in after and v!=after[n]}
 parity={'previous_roots':len(before),'current_roots':len(after),'missing':missing,'changed_sets':changed,'all_previous_axiom_sets_preserved':not missing and not changed};(root/'axiom-set-parity.json').write_text(json.dumps(parity,indent=2)+'\n');assert parity['all_previous_axiom_sets_preserved'],parity
 assert inputs()==frozen
 report('per_pr_gates_passed',reuse_manifest=manifest,axiom_parity=parity,next='Fetch current main/reconcile, receipt and author squash; continue original source/whole-function simulation/direct semantic consumers.')
except BaseException as e:report('failed',error=repr(e),traceback=traceback.format_exc());raise
