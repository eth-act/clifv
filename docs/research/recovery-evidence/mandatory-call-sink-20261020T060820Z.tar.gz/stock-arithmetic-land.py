from pathlib import Path
import subprocess as sp,json,hashlib,datetime,re
view=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');root=Path('/tmp/stock-arithmetic-landing');root.mkdir(exist_ok=True)
head='b382a3e5e3ad4ef1231f1ab6ba0a19d69179dd61';base='5f7350fa143f4a3f7f1c9fab5f5e0c679b45fb7d'
def run(*args):return sp.check_output(args,cwd=view,text=True,stderr=sp.STDOUT).strip()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
d=json.loads(Path('/tmp/stock-arithmetic-author-gates/progress.json').read_text());assert d['state']=='per_pr_gates_passed' and d['head']==head and d['base']==base
assert run('git','rev-parse','HEAD')==head
assert not run('git','diff','--name-only') and not run('git','diff','--cached','--name-only')
frozen=json.loads(Path('/tmp/stock-arithmetic-author-gates/inputs.json').read_text());current={str(p.relative_to(view)):sha(p) for folder in ['FV','FVTest','scripts/audit'] for p in (view/folder).rglob('*.lean')};assert frozen==current
for f in d['logs'].values():assert sha(f['path'])==f['sha256']
assert d['axiom_parity']['all_previous_axiom_sets_preserved']
run('git','fetch','origin','main');assert run('git','rev-parse','origin/main')==base,'main drift; reconcile first'
receipt=view/'docs/research/stock-arithmetic-body-author-gates.json';assert not receipt.exists();receipt.write_text(json.dumps(d,indent=2)+'\n')
p=view/'docs/plans/stock-driver-incremental-delivery.md';s=p.read_text();s+='\nArithmetic body author gates passed on `'+head+'`: scheduler validated the two new modules against exact unchanged source/audit hashes from the2426-module#338base, followed by the full `FV FVTest` replay, all28audit files and27core/2fixed-witness owned constants. All1042priorpublicaxiomsets retained exactly;7newpublicroots audited. No runtime/consumer input or executable changed. Receipt: [arithmetic body author gates](../research/stock-arithmetic-body-author-gates.json). Original source evaluation/entry-return composition and direct semantic consumers remain next.\n';p.write_text(s)
run('git','add','docs/research/stock-arithmetic-body-author-gates.json','docs/plans/stock-driver-incremental-delivery.md');run('git','diff','--cached','--check');run('git','commit','-m','Record exact arithmetic body author gate evidence')
final=run('git','rev-parse','HEAD');tree=run('git','rev-parse','HEAD^{tree}');run('git','push','origin','agent/stock-arithmetic-body-simulation')
body=root/'pr-body.md';body.write_text('''Derive actual add/sub body simulation for arbitrary pure single-block bodies from original input syntax and successful Stock lowering. Earlier composition required a per-record family/result-map certificate. This packet derives original source information through the actual terminator override, singleton result arity, successful result binding and emitted/omitted family coverage, then composes the existing guarded source/machine semantics. Old variants and input conditions are retained.

Complete witnesses cover a nonempty real source/event and actual dirty-input machine execution through the new body theorem. This proves ordinary-body value simulation; whole-function entry/return composition, direct optimized-Stock checker/consumers, remaining families/effects and original #140 completeness remain active. Production class selection is unchanged.

Validation on `'''+head+'''` plus receipt-only `'''+final+'''`:

- Exact hashes prove all previously verified source/audit files from merged#338 unchanged. Scheduler checks the two new modules within16GiB, then complete `lake build FV FVTest` replay passes.
- All28checked-in audit files pass;1042previous public root axiom sets retained exactly,7newpublic roots audited.
- All27newcoreownedconstants use standard axioms;2fixedwitnessconstants use only previously marked ScalarAddScanWitness native trace facts. Targeted complete builds648jobs.
- Import closure reaches no runtime consumer/executable; runtime inputs byte-identical to mergedmain, so runtime gates are outside this proof-only change.

Terminal receipt: `docs/research/stock-arithmetic-body-author-gates.json`. Full original#140 remains open.
''')
assert run('git','ls-remote','origin','refs/heads/main').split()[0]==base
out=run('gh','pr','create','--repo','eth-act/clifv','--base','main','--head','agent/stock-arithmetic-body-simulation','--title','Derive arithmetic body value simulation from original source','--body-file',str(body));urls=re.findall(r'https://github.com/eth-act/clifv/pull/\d+',out);assert len(urls)==1,out
url=urls[0];(root/'progress.json').write_text(json.dumps({'state':'merging','pr':url,'head':final})+'\n')
assert run('git','ls-remote','origin','refs/heads/main').split()[0]==base
run('gh','pr','merge',url,'--repo','eth-act/clifv','--squash','--match-head-commit',final)
pr=json.loads(run('gh','pr','view',url,'--repo','eth-act/clifv','--json','number,state,mergeCommit,url'));assert pr['state']=='MERGED'
commit=pr['mergeCommit']['oid'];(root/'progress.json').write_text(json.dumps({'state':'merged_verifying','pr':pr,'head':final})+'\n')
run('git','fetch','origin','main');assert run('git','rev-parse',commit+'^{tree}')==tree
comment=root/'integrator.md';comment.write_text('@kevaundray Author squash landed #'+str(pr['number'])+' as **'+commit+'**. Exact tree equals validated '+head+' plus receipt '+final+'. Please include the actual commit in the immediate continuous main gate.\n\nComplete derived actual arithmetic-body value simulation: source-slot provenance, singleton results/result binding, emitted/omitted family derivation and guarded machine/source composition for arbitrary pure single-block add/sub bodies, with real nonempty/dirty-input execution witnesses. Per-PR FV/FVTest passes with hash-verified reuse of unchanged#338modules, all28audits/1042exactpriorrootsets+7newroots,27standardcoreconstants/2explicitfixedwitnessconstants. No runtime/consumer input changed. This is body simulation, not another production class or full#140 completion. Next actual reference-source execution/entry-return whole-function composition and additive direct semantic checker/consumers; all original families/effects/completeness remain active.\n')
for issue in ['261','140']:run('gh','issue','comment',issue,'--repo','eth-act/clifv','--body-file',str(comment))
status=json.loads(run('gh','issue','view','44','--repo','eth-act/clifv','--json','body'))['body'];status+='\n\n'+comment.read_text()+'\nCurrent published branch agent/stock-arithmetic-body-simulation/'+final+'; stateactive. Next terminal evidence backup/cleanup, original source-step/whole-function integration. UTC '+datetime.datetime.now(datetime.timezone.utc).isoformat()+'\n';(root/'status.md').write_text(status);run('gh','issue','edit','44','--repo','eth-act/clifv','--body-file',str(root/'status.md'))
done={'state':'landed_and_integrator_notified','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pr':pr,'source':head,'receipt':final,'merge_commit':commit,'merge_tree_matches_validated_source_plus_receipt':True};(root/'progress.json').write_text(json.dumps(done,indent=2)+'\n');print(json.dumps(done))
