import FV.Backend.Proof.StockOrderGraphWitness
#print axioms Backend.Stock.Proof.stock_lower_edge_successor
#print axioms Backend.Stock.Proof.stock_lower_jump_successor
#print axioms Backend.Stock.Proof.stock_lower_jump_nonentry_successor
#print axioms Backend.Stock.Proof.stock_lower_critical_code
#print axioms Backend.Stock.Proof.OrderGraphWitness.stock_critical_order_witness
#print axioms Backend.Stock.Proof.OrderGraphWitness.stock_jump_order_witness
#print axioms Backend.Stock.Proof.OrderGraphWitness.stock_critical_code_witness
