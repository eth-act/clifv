import FV.Backend.Proof.PerEdgeRegallocSound
import FV.Backend.Proof.RegallocCSem
namespace Backend.Stock.Proof.M6StepsTest
open Backend.Proof
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private def store (w : Arm.ArmState) : Loc → CV
  | .reg r => regVal w r
  | _ => 0
private def selected (w : Arm.ArmState) : Nat :=
  if lo64 (regVal w (.x 0)) != (0#64) then 0 else 1
private theorem write_same (w : Arm.ArmState) :
    upd (store w) (.reg (.x 0)) (regVal w (.x 0)) = store w := by
  funext l
  by_cases same : l = .reg (.x 0) <;> simp [upd,same,store]
private theorem step_args {vc : VCode} {rf : RFunc} {vb : VBlock}
    (placed : vc.blocks[0]? = some vb)
    (code : vb.insts = #[.args [(.vreg 192 .int,.x 0)],.condBr 2 1 (.notZero (.vreg 192 .int) .size64)])
    (F : BitVec 64 → Prop) (ctx : FnCtx) (X : ExtSem) (w : Arm.ArmState) :
    MStep vc (csem F ctx X) ckeep rf
      (.run ⟨0,[.op 0 #[.reg (.x 0)],.op 1 #[.reg (.x 0)]],store w,w⟩)
      (.run ⟨0,[.op 1 #[.reg (.x 0)]],store w,w⟩) := by
  have run : MStep vc (csem F ctx X) ckeep rf
      (.run ⟨0,[.op 0 #[.reg (.x 0)],.op 1 #[.reg (.x 0)]],store w,w⟩)
      (.run ⟨0,[.op 1 #[.reg (.x 0)]],upd (store w) (.reg (.x 0)) (regVal w (.x 0)),w⟩) := by
    exact MStep.op placed (by rw [code]; rfl) (ops := #[⟨192,.int,.def,.late,.fixed (.x 0)⟩])
      rfl rfl (by rfl) (by simp [Operand.isDef]) (HavocOuts.refl _ _ _)
      ⟨fun _ _ => rfl,fun _ h => by cases h⟩ (by simp [Operand.isDef,Operand.isEarly,Operand.isLate,writeM]; apply MNext.next; rw [code]; decide)
  simpa only [write_same] using run
private theorem step_cond {vc : VCode} {rf : RFunc} {vb : VBlock}
    (placed : vc.blocks[0]? = some vb)
    (code : vb.insts = #[.args [(.vreg 192 .int,.x 0)],.condBr 2 1 (.notZero (.vreg 192 .int) .size64)])
    (F : BitVec 64 → Prop) (ctx : FnCtx) (X : ExtSem) (w : Arm.ArmState)
    (succ : succOf vc 0 (selected w) = some (2-selected w))
    (items : rf.blocks[2-selected w]? = some #[.op 0 #[.reg (.x 0)]]) :
    MStep vc (csem F ctx X) ckeep rf
      (.run ⟨0,[.op 1 #[.reg (.x 0)]],store w,w⟩)
      (.run ⟨2-selected w,[.op 0 #[.reg (.x 0)]],store w,w⟩) := by
  exact MStep.op placed (by rw [code]; rfl) (ops := #[⟨192,.int,.use,.early,.reg⟩]) rfl rfl
    (by rfl) (by simp [Operand.isDef]) (HavocOuts.refl _ _ _) ⟨fun _ _ => rfl,fun _ h => by cases h⟩
    (by simp [Operand.isDef,Operand.isEarly,Operand.isLate,writeM]; apply MNext.goto _ succ items; rw [code]; rfl)
private theorem step_ret {vc : VCode} {rf : RFunc} {vb : VBlock} {b key : Nat}
    (placed : vc.blocks[b]? = some vb) (code : vb.insts = #[.rets [(.vreg key .int,.x 0)]])
    (F : BitVec 64 → Prop) (ctx : FnCtx) (X : ExtSem) (w : Arm.ArmState) :
    MStep vc (csem F ctx X) ckeep rf (.run ⟨b,[.op 0 #[.reg (.x 0)]],store w,w⟩)
      (.ret [regVal w (.x 0)] (store w) w) := by
  exact MStep.op placed (by rw [code]; rfl) (ops := #[⟨key,.int,.use,.early,.fixed (.x 0)⟩]) rfl rfl
    (by rfl) (by simp [Operand.isDef]) (HavocOuts.refl _ _ _) ⟨fun _ _ => rfl,fun _ h => by cases h⟩ (by simp [Operand.isUse,Operand.isDef,Operand.isEarly,Operand.isLate,writeM,store]; apply MNext.ret; rfl)
end Backend.Stock.Proof.M6StepsTest
