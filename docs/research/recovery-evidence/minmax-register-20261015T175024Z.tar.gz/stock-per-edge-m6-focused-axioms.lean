import FV.Backend.Proof.PerEdgeRegallocSound
import FV.Backend.Proof.StockPerEdgeM6Witness
import FV.Backend.Proof.StockPerEdgeM6HaltWitness
import FV.Backend.Proof.StockPerEdgeM6DivergenceWitness
import FV.Backend.Proof.StockPerEdgeM6StuckWitness

#print axioms Backend.Proof.PerEdge.checked_of_checkAlloc
#print axioms Backend.Proof.PerEdge.Checked.at
#print axioms Backend.Proof.PerEdge.allocChecked_of_checkAlloc
#print axioms Backend.Proof.PerEdge.enter_block_at
#print axioms Backend.Proof.PerEdge.edgeEnv_lt
#print axioms Backend.Proof.PerEdge.sim_step_at
#print axioms Backend.Proof.PerEdge.sim_progress_at
#print axioms Backend.Proof.PerEdge.enter_block
#print axioms Backend.Proof.PerEdge.sim_step
#print axioms Backend.Proof.PerEdge.sim_progress
#print axioms Backend.Proof.PerEdge.checkedAt_sound
#print axioms Backend.Proof.PerEdge.checkAlloc_sound
#print axioms Backend.Proof.PerEdge.allocChecked_sound
#print axioms Backend.Proof.PerEdge.IsSimulation.star
#print axioms Backend.Proof.PerEdge.checkAlloc_ret
#print axioms Backend.Proof.PerEdge.checkAlloc_halt
#print axioms Backend.Proof.PerEdge.checkAlloc_stuck
#print axioms Backend.Proof.PerEdge.IsSimulation.next_vstep
#print axioms Backend.Proof.PerEdge.checkAlloc_diverges
#print axioms Backend.Stock.Proof.PerEdgeM6Witness.stock_per_edge_m6_return_witness
#print axioms Backend.Stock.Proof.PerEdgeM6Witness.stock_per_edge_m6_checked_witness
#print axioms Backend.Stock.Proof.PerEdgeM6HaltWitness.stock_per_edge_m6_halt_witness
#print axioms Backend.Stock.Proof.PerEdgeM6DivergenceWitness.stock_per_edge_m6_divergence_witness
#print axioms Backend.Stock.Proof.PerEdgeM6StuckWitness.stock_per_edge_m6_stuck_witness
