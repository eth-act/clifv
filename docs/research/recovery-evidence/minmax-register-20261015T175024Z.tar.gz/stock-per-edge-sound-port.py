from pathlib import Path
s=Path('FV/Backend/Proof/RegallocSound.lean').read_text()
s=s.replace('import FV.Backend.Proof.RegallocLemmas','import FV.Backend.Proof.RegallocSound\nimport FV.Backend.Proof.PerEdgeRegallocLemmas')
s=s.replace('namespace Backend.Proof\n','namespace Backend.Proof.PerEdge\n').replace('end Backend.Proof\n','end Backend.Proof.PerEdge\n')
# Reuse generic, edge-independent entry-state definitions and results.
a=s.index('/-- An entry in-state the register-level proof');b=s.index('/-- **What the downstream proofs',a);s=s[:a]+s[b:]
a=s.index('theorem entryOk_of_le');b=s.index('theorem allocChecked_of_checkAlloc',a);s=s[:a]+s[b:]
a=s.index('open Classical in');b=s.index('variable {vc : VCode}',a);s=s[:a]+s[b:]
a=s.index('def MConf.measure');b=s.index('variable (vc : VCode)',a);s=s[:a]+s[b:]
a=s.index('/-- The initial configuration of the allocated code');b=s.index('/-- **Soundness of the register-allocation checker, from verified in-states',a);s=s[:a]+s[b:]
a=s.index('/-- Exactly `n` steps.');b=s.index('theorem IsSimulation.next_vstep',a);s=s[:a]+s[b:]
# Parameterize each edge-dependent relation/contract with the actual vectors.
s=s.replace('variable {V W : Type}','variable {V W : Type}\nvariable {edges : Array (Array (Array Reg))}')
s=s.replace('def MatchRun (c : CheckCtx) (ins','def MatchRun (c : CheckCtx) (edges : Array (Array (Array Reg))) (ins').replace('def Match (c : CheckCtx) (ins','def Match (c : CheckCtx) (edges : Array (Array (Array Reg))) (ins')
s=s.replace('MatchRun c ins','MatchRun c edges ins').replace('Match c ins','Match c edges ins').replace('EdgesOk c ins','EdgesOk c edges ins')
s=s.replace('structure Checked (vc : VCode) (rf','structure Checked (vc : VCode) (edges : Array (Array (Array Reg))) (rf').replace('structure CheckedAt (vc : VCode) (rf','structure CheckedAt (vc : VCode) (edges : Array (Array (Array Reg))) (rf').replace('def AllocChecked (vc : VCode) (rf','def AllocChecked (vc : VCode) (edges : Array (Array (Array Reg))) (rf')
s=s.replace('Checked vc rf','Checked vc edges rf').replace('CheckedAt vc rf','CheckedAt vc edges rf').replace('AllocChecked vc rf','AllocChecked vc edges rf').replace('c.verifyBlock ins','c.verifyBlockAt edges ins')
s=s.replace('checkAlloc vc rf','checkAllocAt vc edges rf').replace('VStep vc sem','VStepAt vc edges sem').replace('VStep.step','VStepAt.step').replace('VNext.','VNextAt.')
s=s.replace('structure IsSimulation (R','structure IsSimulation (edges : Array (Array (Array Reg))) (R').replace('IsSimulation vc rf','IsSimulation vc rf sem keep') if False else s
# IsSimulation uses section parameters in the existing argument order; edges is explicit after vc.
s=s.replace('structure IsSimulation (R','structure IsSimulation (edges : Array (Array (Array Reg))) (R')
s=s.replace('IsSimulation vc rf sem keep','IsSimulation vc rf sem keep edges')
# edgeEnv has an index; its target lookup remains the bound justification.
s=s.replace('theorem edgeEnv_lt {b s : Nat}', 'theorem edgeEnv_lt {b s index : Nat}').replace('edgeEnv vc b s ρ','edgeEnvAt vc edges b s index ρ').replace('unfold edgeEnv at h','unfold edgeEnvAt at h').replace('| none => cases hb : vc.blocks[b]? <;> simp [hs, hb] at h','| none => simp [hs] at h')
# Preserve the source-selected successor index in the forward branch case.
s=s.replace('| goto hk1 hsucc hitems =>','| @goto j target items hk1 hsucc hitems =>')
s=s.replace('obtain ⟨e, a\'\', hedge, hins, hle⟩ := hedges _ (succOf_mem hcfg hsucc)',"obtain ⟨e, a'', hedge, hins, hle⟩ := hedges j target (succOf_index hcfg hsucc)")
# Insert a private actual-CFG indexed successor lemma before the step proofs.
a=s.index('theorem sim_step_at')
s=s[:a]+'''private theorem succOf_index {preds : Array (Array Nat)}
    (cfg : vc.cfg = .ok (c.succs,preds)) {b index target : Nat}
    (selected : succOf vc b index = some target) :
    (c.succs[b]?.getD #[])[index]? = some target := by
  simp only [succOf,cfg] at selected
  cases row : c.succs[b]? with
  | none => simp [row] at selected
  | some targets => simpa only [row,Option.bind_some,Option.getD_some] using selected

'''+s[a:]
# This is a new variant, not a change to the original module.
s=s.replace('# Soundness of the register-allocation checker (M6)','# Soundness of the per-successor register-allocation checker (M6)').replace('`VStep`','`VStepAt`').replace('`checkAlloc_sound`','`PerEdge.checkAlloc_sound`')
Path('FV/Backend/Proof/PerEdgeRegallocSound.lean').write_text(s)
