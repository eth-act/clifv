import StockTryLiveNormal
namespace Backend.Stock.Proof.TryLiveValuesDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open TryLiveNormalDraft TryResolvedRunsDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
/- The SAME actual stopped branch carries every originally held live source
value, normal returned values and returned memory/world. This transports an
ordinary simulation precondition; it is not an accepted-program condition. -/
/-- An actual stopped normal branch with normal return values and every
originally held live source value in the SAME post-call environment. -/
def ResolvedHeldNormalBranch (result : Result) (step : Step) (isem : Sem) (MR : MemRelT)
    (fr : Clif.Frame) (rho : Nat → CV) (w : Arm.ArmState) (base normal : Nat)
    (rvals : List Clif.Val) (cm' : Clif.Mem) (needed : Nat → Prop) : Prop :=
  ∃ (k : Nat) (i : MInst) (ops : Array Operand) (atCall : Nat → CV) (world : Arm.ArmState)
      (outs : List CV) (finalWorld : Arm.ArmState),
      seqRun isem (step.emitted.toList.map (·.mapRegs (resolver result))) rho w =
        some (.stop k i ops atCall world outs finalWorld (.goto normal)) ∧ MR fr.slots cm' finalWorld ∧
      (∀ (j : Nat) (v : Clif.Val),rvals[j]? = some v → VHolds v (vdefUpd ops outs atCall (keyMap result (base+j)))) ∧
      ValuesHeld needed result.ctx fr (fun key => vdefUpd ops outs atCall (keyMap result key))

theorem stock_resolved_live_normal_values_held {result : Result} {step : Step} {isem : Sem} {MR : MemRelT}
    {fr : Clif.Frame} {rho : Nat → CV} {w : Arm.ArmState} {base normal : Nat}
    {rvals : List Clif.Val} {cm' : Clif.Mem} {needed : Nat → Prop}
    (run : ResolvedLiveNormalBranch result step isem MR fr rho w base normal rvals cm' needed)
    (held : ValuesHeld needed result.ctx fr (fun key => rho (keyMap result key))) :
    ResolvedHeldNormalBranch result step isem MR fr rho w base normal rvals cm' needed := by
  obtain ⟨k,i,ops,atCall,world,outs,finalWorld,execute,related,values,frame⟩ := run
  refine ⟨k,i,ops,atCall,world,outs,finalWorld,execute,related,values,?_⟩
  intro x member v present
  obtain ⟨key,mapped,value⟩ := held x member v present
  refine ⟨key,mapped,?_⟩
  change VHolds v (vdefUpd ops outs atCall (keyMap result key))
  rw [(frame x key member mapped).2]
  exact value
end Backend.Stock.Proof.TryLiveValuesDraft
