from pathlib import Path
import json,hashlib,re,datetime,tarfile,shutil
root=Path('/home/lee/clifv/.worktrees/driver-proof-resume');docs=root/'docs/research';prefix='stock-try-live-frame'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
now=datetime.datetime.now(datetime.timezone.utc);stamp=now.strftime('%Y%m%dT%H%M%SZ')
batch=json.loads(Path('/tmp/'+prefix+'-batch.json').read_text());old=json.loads((docs/'stock-source-origin-scratch.json').read_text())
log=Path('/tmp/'+prefix+'-combined-axioms.log').read_text()
sets={m.group(1):sorted(x.strip() for x in m.group(2).split(',') if x.strip()) for m in re.finditer(r"'([^']+)' depends on axioms:\s*\[([^]]*)\]",log)}
for m in re.finditer(r"'([^']+)' does not depend on any axioms",log):sets[m.group(1)]=[]
for n,a in old['normal_audit']['sets'].items():assert sorted(a)==sets[n],n
assert len(sets)==len(old['normal_audit']['sets'])+len(batch['public_roots'])+len(batch['models'])
allowed={'propext','Classical.choice','Quot.sound'}
for n in batch['public_roots']+batch['models']:assert set(sets[n])<=allowed,n
constants=[json.loads(line.split('DELIVERY_CONSTANT ',1)[1]) for line in Path('/tmp/'+prefix+'-all-constants.log').read_text().splitlines() if line.startswith('DELIVERY_CONSTANT ')]
assert constants
for n,a in constants:assert set(a)<=allowed,n
mods={}
for m in batch['modules']:
 p=Path('/tmp')/m;check=json.loads(p.with_suffix('.check.json').read_text());assert check['actual_exit']==0
 rec={}
 for key,ext in [('source','.lean'),('object','.olean'),('log','.log'),('check','.check.json')]:
  f=p.with_suffix(ext);rec[key]=str(f);rec[key+'_sha256']=sha(f)
 for k in ['source','object','log']:assert rec[k+'_sha256']==check[k+'_sha256']
 assert not re.search(r'\b(sorry|admit|axiom|trace_state|native_decide)\b',p.with_suffix('.lean').read_text()),m
 mods[m]=rec
for audit in [prefix+'-combined-axioms',prefix+'-all-constants']:
 p=Path('/tmp')/audit;check=json.loads(p.with_suffix('.check.json').read_text());assert check['actual_exit']==0
 for k,ext in [('source','.lean'),('object','.olean'),('log','.log')]:assert sha(p.with_suffix(ext))==check[k+'_sha256']
prior={}
for name in ['source-execution-x','try-source','try-context','try-rule','try-rets','try-reservation','try-outgoing','try-values','try-emitted','try-machine','try-got','try-indirect','try-rename','try-resolved','try-gap','try-got-rename','try-normal-frame','try-metadata','source-index','try-normal-vector','try-critical-normal','source-erase','source-origin']:
 d=json.loads((docs/f'stock-{name}-scratch.json').read_text())
 for m,rec in d['modules'].items():
  for k in ['source','object','log']:assert sha(rec[k])==rec[k+'_sha256'],(m,k)
  prior[m]=rec
freeze=json.loads(Path('/tmp/stock-coherent-build-inputs.json').read_text())
for group in ['source_sha256','validation_script_sha256']:
 for p,h in freeze[group].items():assert sha(root/p)==h,p
progress=json.loads(Path('/tmp/stock-pr246-gates-progress.json').read_text());progress.pop('completed_phases',None)
remaining=list(old['remaining_checklist']);remaining.append({'requirement':'Actual normal TryCall prefix/call execution preserves live original sources with returned world/results in the SAME stop witness','state':'Kernel proved for actual final-renamed near and true-indirect branches, preserving ALL original mapped sources. Actual GOT stores/symbol load/call preserve every source available at original pre-call boundary; whole factory internally derives available-source target exclusion, no new caller alias/footprint certificate. Strong whole-source direct/indirect/GOT consumers preserve original contracts and old theorem variants. SAME stopped tuple includes actual prefix/call seqRun, returned world/MR, normal return VHolds and pre/post source register equality. Generic held-value composition supplies SAME execution/world/normal returns/post ValuesHeld. Complete near source9 with actual post held-value proof, 9argGOT16byte stores with original contracts, true-indirect nonidentity callee alias/4096 and full source17 compiler/checker/physical witnesses. Normal outgoing argument VALUE vector, real parameter copies/source continuation, exception/matrix/whole-driver/production obligations remain OPEN.'})
counts={'modules':len(mods),'public_roots':len(batch['public_roots']),'models':len(batch['models']),'combined_roots_models':len(sets),'previous_preserved':len(old['normal_audit']['sets']),'all_new_module_constants':len(constants),'previous_modules_hashes_preserved':len(prior)}
receipt={'utc':now.isoformat(),'goal':'Original full #140 ACTIVE/INCOMPLETE; production LEGACY','scope':'Scratch-only additive Stock proofs, not coherent integration or merge-ready','delivery_target':'roughly eight substantive validated squash merges/day; coherent queue priority, backup and cleanup','modules':mods,'public_roots':batch['public_roots'],'models':batch['models'],'counts':counts,'normal_audit':{'path':'/tmp/'+prefix+'-combined-axioms.log','sha256':sha('/tmp/'+prefix+'-combined-axioms.log'),'sets':sets},'all_constant_audit':{'path':'/tmp/'+prefix+'-all-constants.log','sha256':sha('/tmp/'+prefix+'-all-constants.log'),'all_standard_only':True,'count':len(constants)},'previous_modules_hashes_preserved':list(prior),'canonical2246_source_and_script_freeze_preserved':True,'MCP':'Deferred until coherent integration; no new calls','active_exact_PR246_validation':progress,'remaining_checklist':remaining}
(docs/(prefix+'-scratch.json')).write_text(json.dumps(receipt,indent=2)+'\n')
text=f'''Actual normal TryCall execution with preserved live values — {now.isoformat()}

{len(mods)}scratch modules/{len(batch['public_roots'])}public roots/{len(batch['models'])}models pass actual8GiB kernel checks. The {len(sets)}-root/model cumulative audit preserves all650prior exact axiom sets. All{len(constants)}new-module constants, including private/generated renaming/footprint/whole-source/witness helpers, use only standard axioms. All{len(prior)}prior source/object/log hashes and frozen2246canonical sources/49scripts unchanged. Previous turn PROGRESS: ordinary retained/final source alias origins, arbitrary final source chase/source-reserved separation and actual TryCall result-write frame/full witnesses,650audit/209constants,4b49d72 backup/2.8GBcleanup.

The actual raw GOT execution factory now retains available-source target exclusion for the SAME chosen source/selected branch/target, alongside target fixedness and argument exclusion. It derives all of these from original lower/scope/Dominated/input/node/block/kind/external/memory/callee/argument contracts. No caller selected-path, alias, write footprint or disjointness certificate is added. Old factory variants remain unchanged.

New exact stopped-execution model keeps the SAME final-renamed seqRun, actual stop index/instruction/operands/pre-call virtual state/world, outs/final world, normal successor and normal returned values. It additionally proves every needed original source virtual register equals its incoming value both BEFORE and AFTER the actual final call writes. A structural instruction-definition proof uses actual renamed argument stores (no defs), actual GOT symbol load (only its SAME internally derived fresh target), fixed actual reserved result definitions and universal final source/reserved separation. seqRun_stop_frame composes the entire actual prefix AND last stopped instruction. This is not a separate input replay or a second unrelated stop witness.

Actual near and true-indirect normal branches preserve ALL mapped source registers; actual GOT branches preserve every source available at the original pre-call boundary. The whole-source direct/indirect/GOT consumers construct raw receipts, final-renamed execution and live-source frame internally. Original scope/SSA/Dominated, ABI, callee, memory, world and argument contracts are retained; SSA used here is original source well-formedness, not a new accepted-program predicate. Old theorem variants/axiom sets are unchanged. Generic held-value transport carries incoming ValuesHeld into SAME post-call environment together with actual returned normal values and returned memory/world.

COMPLETE near compiler/prepare/forced fallback/checker/physical/source17 fixture now uses rho9 and a real incoming held source0→192/value9; the SAME machine execution concludes normal17 and preserved post-call source9. COMPLETE nine-argument GOT/16byte fixture exercises actual argument stores, symbol load and call with unchanged real memory/callee contracts and source17. COMPLETE true-indirect fixture retains actual nonidentity callee alias, symbol4096, held callee/argument contracts, real machine run/world/result/source frame and full source17. Existing cached compiler and physical observations reused; no cold fixture/heavy retry.

Next connect these SAME post-call source/returned values to actual mixed .val/.ret normal Result.edgeArgs VALUE vectors, then execute real parameter copies/source continuation, including actual synthetic normal edges. Existing exact REGISTER-VECTOR proofs do not substitute. Shared payload endpoints/exception machine semantics, zero-return/sret/x8/width/handler/Try-critical matrix, uncovered families/effects/sinking/source/block/whole-driver simulation AND completeness, original-input context/visitor/static/checker/fallback/physical totality, coherent integration/public/private/compiler/MCP/full/crates/runtime/encoder/BOTH E2E identity-stage parity, production compiler/checker/linker/generated consumers and fresh COMPLETE comparison remain mandatory. Production LEGACY. Shared S10/FP/Link interfaces remain @kevaundray boundary.

Same live delivery3247835/exclusive cache lease and held canonical1233457 retained; exact246gate968/1415 has an authoritative CPU-active child on StockMinMaxWideConstantDriverRuns. Main789152e unchanged. Preserve receipts, reconcile CURRENTmain and rerun actual-head affected audits and ALL full gates before dependent squash246→247. Target8substantive validated merges/day. No merge/new worktree/MCP/heavy retry/gate restart. Hashed evidence/full checklist: {prefix}-scratch.json.
'''

(docs/(prefix+'-scratch.md')).write_text(text);plan=root/'docs/plans/test-binary-alignment-recovery.md';plan.write_text(plan.read_text()+'\n\n'+text)
files=[]
for rec in mods.values():files.extend(Path(rec[k]) for k in ['source','object','log','check'])
for name in [prefix+'-combined-axioms',prefix+'-all-constants']:
 for ext in ['.lean','.log','.olean','.check.json']:files.append(Path('/tmp')/(name+ext))
for p in ['/tmp/'+prefix+'-batch.json','/tmp/stock-try-rule-inputs.json','/tmp/stock-try-reservation-check.py','/tmp/'+prefix+'-close.py','/tmp/'+prefix+'-make-audit.py','/tmp/'+prefix+'-restore.py','/tmp/'+prefix+'-status44-start.md','/tmp/'+prefix+'-status52.json','/tmp/'+prefix+'-status71.json','/tmp/'+prefix+'-task140.json','/tmp/stock-try-live-frame-issues.json']:
 if Path(p).exists():files.append(Path(p))
files.extend([docs/(prefix+'-scratch.json'),docs/(prefix+'-scratch.md'),docs/'stock-delivery-main-drift.json',plan])
archive=Path('/home/lee/.clifv-recovery')/(stamp+'-try-live-frame')/'checkpoint.tar.gz';archive.parent.mkdir(parents=True)
with tarfile.open(archive,'w:gz',compresslevel=1) as t:
 for p in files:t.add(p,arcname=str(p).lstrip('/'),recursive=False)
with tarfile.open(archive,'r:gz') as t:
 for p in files:assert t.extractfile(str(p).lstrip('/')).read()==p.read_bytes(),p
snapshot=Path('/tmp/stock-try-rule-inputs');size=sum(p.stat().st_size for p in snapshot.rglob('*') if p.is_file());shutil.rmtree(snapshot)
backup={'utc':now.isoformat(),'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(files),'all_members_byte_verified':True,'previous_remote_backup':json.loads((docs/'stock-source-origin-backup.json').read_text())['remote'],'cleanup':{'duplicate_dependency_snapshot_removed':True,'bytes_reclaimed':size,'unique_sources_objects_logs_checks_audits_preserved':True,'one_shared_warm_cache_retained':True,'other_projects_touched':False,'free_bytes':shutil.disk_usage(root).free}}
(docs/(prefix+'-backup.json')).write_text(json.dumps(backup,indent=2)+'\n');Path('/tmp/'+prefix+'-archive-path').write_text(str(archive))
print(json.dumps({'counts':counts,'archive':str(archive),'cleanup':backup['cleanup'],'gate':progress},indent=2))
