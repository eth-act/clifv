import StockTryGotLiveSourceRun
import StockTryGotResolvedRun
import StockSourceReservedDisjoint
namespace Backend.Stock.Proof.TryLiveNormalDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open TryResolvedRunsDraft TryGotResolvedRunDraft SourceReservedDisjointDraft
open TryDirectSourceRunDraft TryIndirectSourceRunDraft TryGotSourceRunDraft
open TryResultDefsFixedDraft TryRetsTotalDraft TryResultMapDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
/-- SAME actual renamed stopped execution carries returned world/results AND
all selected live source registers before and after the actual stopped call. -/
def ResolvedLiveNormalBranch (result : Result) (step : Step) (isem : Sem) (MR : MemRelT)
    (fr : Clif.Frame) (rho : Nat → CV) (w : Arm.ArmState) (base normal : Nat)
    (rvals : List Clif.Val) (cm' : Clif.Mem) (needed : Nat → Prop) : Prop :=
  ∃ (k : Nat) (i : MInst) (ops : Array Operand) (atCall : Nat → CV) (world : Arm.ArmState)
    (outs : List CV) (finalWorld : Arm.ArmState),
    seqRun isem (step.emitted.toList.map (·.mapRegs (resolver result))) rho w =
      some (.stop k i ops atCall world outs finalWorld (.goto normal)) ∧ MR fr.slots cm' finalWorld ∧
      (∀ (j : Nat) (v : Clif.Val),rvals[j]? = some v →
        VHolds v (vdefUpd ops outs atCall (keyMap result (base+j)))) ∧
      (∀ x key,needed x → result.ctx.valueReg? x = some (.vreg key .int) →
        atCall (keyMap result key) = rho (keyMap result key) ∧
        vdefUpd ops outs atCall (keyMap result key) = rho (keyMap result key))
private theorem alias_renaming (a : Array (Option Nat)) :
    VRenaming (Backend.lowerFunction.resolve a (a.size+1)) (aliasNum a) := by
  refine ⟨fun n c => resolve_vreg _ _ n c,?_⟩
  intro r hr
  cases r with
  | vreg n c => exact False.elim (hr n c rfl)
  | _ => rfl
private theorem renamed_defs (result : Result) (i : MInst) :
    vdefs (i.mapRegs (resolver result)) = (vdefs i).map (keyMap result) := by
  unfold resolver vdefs
  rw [operands_mapRegs (alias_renaming result.final.alias)]
  cases operands : i.operands with
  | error e => rfl
  | ok ops =>
    simp only [Except.map,Array.toList_map]
    rw [filter_map_rn _ Operand.isDef (fun _ => rfl)]
    simp only [List.map_map]
    rfl
private theorem lookup_of_layout {slots : Array (List Reg × List Reg)} {i base count : Nat}
    (layout : slots[i]! = (reservedReturns base count,reservedPayloads base count)) :
    slots[i]? = some (reservedReturns base count,reservedPayloads base count) := by
  cases found : slots[i]? with
  | none => simp only [getElem!_def,found] at layout; cases congrArg Prod.snd layout
  | some pair =>
    have same : pair = (reservedReturns base count,reservedPayloads base count) := by simpa only [getElem!_def,found] using layout
    rw [same]
private theorem key_reserved (base count j : Nat) (inside : j < max count 2) :
    (.vreg (resultKey base count j) .int) ∈ reservedReturns base count ++ reservedPayloads base count := by
  by_cases returned : j < count
  · apply List.mem_append_left
    exact List.mem_map.mpr ⟨j,List.mem_range.mpr returned,by simp [resultKey,returned]⟩
  · have choices : j = 0 ∨ j = 1 := by omega
    apply List.mem_append_right
    rcases choices with rfl | rfl <;> simp [resultKey,returned,reservedPayloads]
private theorem call_safe {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f) (ssa : (valueDefs f).Nodup)
    {owner base count : Nat}
    (layout : result.initial.tryRegs[owner]! = (reservedReturns base count,reservedPayloads base count))
    (dest : CallDest) (L : List (Nat × Reg)) (info : TryInfo)
    (form : (∃ name,dest = .sym name) ∨ (∃ target,dest = .reg (.vreg target .int)))
    {x key : Nat} (mapped : result.ctx.valueReg? x = some (.vreg key .int)) :
    keyMap result key ∉ vdefs ((MInst.tryCall ⟨dest,retPairs L,callDefs (resultDefs base count)⟩ info).mapRegs (resolver result)) := by
  rw [renamed_defs]
  intro member
  obtain ⟨d,defined,same⟩ := List.mem_map.mp member
  have vdefs_same (call : CallInfo) : vdefs (.tryCall call info) = vdefs (.call call) := by unfold vdefs; rw [operands_tryCall_call]
  rw [vdefs_same] at defined
  rcases form with ⟨name,rfl⟩ | ⟨target,rfl⟩
  all_goals
    first | rw [vdefs_call_sym] at defined | rw [vdefs_call_reg] at defined
    simp only [resultDefs,List.map_map,Function.comp_def,List.mem_map,List.mem_range] at defined
    obtain ⟨j,inside,rfl⟩ := defined
    have fixed := stock_lower_try_result_keys_fixed lowered layout j inside
    have apart := stock_lower_source_reserved_resolved_disjoint lowered scope ssa mapped (lookup_of_layout layout) (key_reserved base count j inside)
    exact apart (fixed.symm.trans same).symm
private theorem strengthen {result : Result} {step : Step} {isem : Sem} {MR : MemRelT}
    {fr : Clif.Frame} {rho : Nat → CV} {w : Arm.ArmState} {base normal : Nat}
    {rvals : List Clif.Val} {cm' : Clif.Mem} {needed : Nat → Prop}
    (run : ResolvedNormalBranch result step isem MR fr rho w base normal rvals cm')
    (safe : ∀ x key,needed x → result.ctx.valueReg? x = some (.vreg key .int) →
      ∀ m ∈ step.emitted.toList.map (·.mapRegs (resolver result)),keyMap result key ∉ vdefs m) :
    ResolvedLiveNormalBranch result step isem MR fr rho w base normal rvals cm' needed := by
  obtain ⟨k,i,ops,atCall,world,outs,finalWorld,execute,related,values⟩ := run
  exact ⟨k,i,ops,atCall,world,outs,finalWorld,execute,related,values,
    fun x key member mapped => seqRun_stop_frame (safe x key member mapped) execute⟩
/-- Actual near-call argument stores and final call preserve ALL original
source registers; returned world/results share the very same stopped witness. -/
theorem stock_direct_try_run_resolved_live {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f) (ssa : (valueDefs f).Nodup)
    {isem : Sem} (driver : DriverSem isem) {label bi : Nat} {b : Clif.Block} {ext : Clif.ExtFunc}
    {MR : MemRelT} {fr : Clif.Frame} {rho : Nat → CV} {w : Arm.ArmState} {rvals : List Clif.Val} {cm' : Clif.Mem}
    (raw : DirectTryRun f result label bi b ext isem MR fr (fun n => rho (keyMap result n)) w rvals cm')
    (results : rvals.length = ext.sig.returns.length) :
    ResolvedLiveNormalBranch result raw.source.branch.step isem MR fr rho w raw.base raw.info.handlers.length rvals cm' (fun _ => True) := by
  apply strengthen (stock_direct_try_run_resolved lowered driver raw results)
  intro x key needed mapped m member
  rw [raw.code,List.toList_toArray,List.map_append] at member
  rcases List.mem_append.mp member with store | call
  · obtain ⟨i,present,rfl⟩ := List.mem_map.mp store
    obtain ⟨e,_,rfl⟩ := List.mem_map.mp present
    rw [renamed_defs,vdefs_argStore]; simp
  · simp only [List.map_cons,List.map_nil,List.mem_singleton] at call
    subst m
    exact call_safe lowered scope ssa raw.layout _ _ _ (.inl ⟨ext.name,rfl⟩) mapped
/-- True-indirect stores and final call read the renamed callee before their
reserved writes; all original source registers are preserved. -/
theorem stock_indirect_try_run_resolved_live {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f) (ssa : (valueDefs f).Nodup)
    {isem : Sem} (driver : DriverSem isem) {label bi : Nat} {b : Clif.Block} {sig : Clif.Signature}
    {MR : MemRelT} {fr : Clif.Frame} {rho : Nat → CV} {w : Arm.ArmState} {rvals : List Clif.Val} {cm' : Clif.Mem}
    (raw : IndirectTryRun f result label bi b sig isem MR fr (fun n => rho (keyMap result n)) w rvals cm')
    (results : rvals.length = sig.returns.length) :
    ResolvedLiveNormalBranch result raw.source.branch.step isem MR fr rho w raw.base raw.info.handlers.length rvals cm' (fun _ => True) := by
  apply strengthen (stock_indirect_try_run_resolved lowered driver raw results)
  intro x key needed mapped m member
  rw [raw.code,List.toList_toArray,List.map_append] at member
  rcases List.mem_append.mp member with store | call
  · obtain ⟨i,present,rfl⟩ := List.mem_map.mp store
    obtain ⟨e,_,rfl⟩ := List.mem_map.mp present
    rw [renamed_defs,vdefs_argStore]; simp
  · simp only [List.map_cons,List.map_nil,List.mem_singleton] at call
    subst m
    exact call_safe lowered scope ssa raw.layout _ _ _ (.inr ⟨raw.target,rfl⟩) mapped
/-- The actual GOT load writes only its fresh symbol target. Its internally
constructed whole-source exclusion makes the SAME execution preserve all
source values available at the original pre-call boundary. -/
theorem stock_got_try_run_resolved_live {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f) (ssa : (valueDefs f).Nodup)
    {isem : Sem} (driver : DriverSem isem) {label bi : Nat} {b : Clif.Block} {ext : Clif.ExtFunc}
    {MR : MemRelT} {fr : Clif.Frame} {rho : Nat → CV} {w : Arm.ArmState} {rvals : List Clif.Val} {cm' : Clif.Mem}
    (raw : GotTryRun f result label bi b ext isem MR fr (fun n => rho (keyMap result n)) w rvals cm')
    (targetFixed : keyMap result raw.target = raw.target) (arguments : ∀ n ∈ raw.ns,keyMap result n ≠ raw.target)
    (sources : ∀ x key,x ∈ availOf f (availIn f result.ctx) bi b.body.length →
      result.ctx.valueReg? x = some (.vreg key .int) → keyMap result key ≠ raw.target)
    (results : rvals.length = ext.sig.returns.length) :
    ResolvedLiveNormalBranch result raw.source.branch.step isem MR fr rho w raw.base raw.info.handlers.length rvals cm'
      (fun x => x ∈ availOf f (availIn f result.ctx) bi b.body.length) := by
  apply strengthen (stock_got_try_run_resolved lowered driver raw targetFixed arguments results)
  intro x key needed mapped m member
  rw [raw.code,List.toList_toArray,List.map_append] at member
  rcases List.mem_append.mp member with store | tail
  · obtain ⟨i,present,rfl⟩ := List.mem_map.mp store
    obtain ⟨e,_,rfl⟩ := List.mem_map.mp present
    rw [renamed_defs,vdefs_argStore]; simp
  · simp only [List.map_cons,List.map_nil,List.mem_cons,List.not_mem_nil,or_false] at tail
    rcases tail with rfl | rfl
    · rw [renamed_defs,vdefs_got_ctl,List.map_cons,List.map_nil,List.mem_singleton,targetFixed]
      exact sources x key needed mapped
    · exact call_safe lowered scope ssa raw.layout _ _ _ (.inr ⟨raw.target,rfl⟩) mapped
end Backend.Stock.Proof.TryLiveNormalDraft
