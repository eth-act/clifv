import StockTryLiveNormal
namespace Backend.Stock.Proof.TryLiveResolvedSourceDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open TryLiveNormalDraft
open TryDirectSourceRunDraft TryIndirectSourceRunDraft TryResolvedRunsDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
/-- Whole original-source consumer constructs the real raw receipt and its
final-renamed execution internally; original inputs/contracts remain intact. -/
theorem stock_lower_direct_try_resolved_live_normal_source_run {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f) (ssa : (valueDefs f).Nodup) (input : Prg.iselInB f = true)
    {label bi : Nat} {b : Clif.Block} (node : result.order.nodes[label]? = some (.original bi))
    (block : f.blocks[bi]? = some b) {fn : Nat} {args : List Nat} {et : Clif.ExnTable}
    (kind : b.term = .tryCall fn args et) {ext : Clif.ExtFunc} (external : f.extern? fn = some ext)
    (near : ext.colocated = true)
    {Rd F : BitVec 64 → Prop} {isem : Sem} {MR : MemRelT} (driver : DriverSem isem) {sb : Nat} {syms : String → Option Nat}
    (stable : MRStable F MR) (memory : MemRefinesR Rd F sb syms isem)
    (outgoing : OutArgsOk F result.code.outgoing MR)
    {Pc : String → Clif.Signature → List Clif.Val → Clif.Mem → Prop} {env : Clif.Env} {exts : List Clif.ExtFunc}
    (calls : CallsRefineP Pc F env exts MR isem) (member : ext ∈ exts)
    {fr : Clif.Frame} {ρ : Nat → CV} {w : Arm.ArmState} {cm cm' : Clif.Mem} {vals rvals : List Clif.Val}
    (held : ValuesHeld (fun x => x ∈ args) result.ctx fr (fun key => ρ (keyMap result key))) (read : fr.getMany args = .ok vals)
    (typed : vals.map (·.ty) = Clif.AbiParam.tys ext.sig.params) (related : MR fr.slots cm w)
    {g : List Clif.Val → Clif.Mem → Clif.Outcome} (found : env.extern ext.name = some g)
    (pin : Pc ext.name ext.sig vals cm) (returned : g vals cm = .returned rvals cm')
    (results : rvals.length = ext.sig.returns.length) :
    ∃ raw : DirectTryRun f result label bi b ext isem MR fr
      (fun key => ρ (keyMap result key)) w rvals cm',
      ResolvedLiveNormalBranch result raw.source.branch.step isem MR fr ρ w raw.base raw.info.handlers.length rvals cm' (fun _ => True) := by
  obtain ⟨raw⟩ := stock_lower_direct_try_normal_source_run lowered scope input node block kind external near
    stable memory outgoing calls member held read typed related found pin returned results
  exact ⟨raw,stock_direct_try_run_resolved_live lowered scope ssa driver raw results⟩

/-- Whole original-source consumer constructs the real raw receipt and its
final-renamed execution internally; original inputs/contracts remain intact. -/
theorem stock_lower_indirect_try_resolved_live_normal_source_run {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f) (ssa : (valueDefs f).Nodup) (input : Prg.iselInB f = true)
    (abi : Backend.Proof.Spill.AbiSigsOk f)
    {label bi : Nat} {b : Clif.Block} (node : result.order.nodes[label]? = some (.original bi))
    (block : f.blocks[bi]? = some b) {callee : Nat} {args : List Nat} {et : Clif.ExnTable}
    (kind : b.term = .tryCallIndirect callee args et) {sig : Clif.Signature} {items : List (Option Nat)}
    (table : exnTableOpnd f et = .ok (sig,items))
    {isem : Sem} {MR : MemRelT} (driver : DriverSem isem)
    {Pc : String → Clif.Signature → List Clif.Val → Clif.Mem → Prop} {env : Clif.Env}
    (calls : IndCallsRefineP Pc env (indSigs f) MR isem)
    {fr : Clif.Frame} {ρ : Nat → CV} {w : Arm.ArmState} {cm cm' : Clif.Mem} {vals rvals : List Clif.Val}
    (held : ValuesHeld (fun x => x = callee ∨ x ∈ args) result.ctx fr (fun key => ρ (keyMap result key))) (read : fr.getMany args = .ok vals)
    (typed : vals.map (·.ty) = Clif.AbiParam.tys sig.params) (related : MR fr.slots cm w)
    {name : String} {address : Nat}
    (calleeValue : fr.get callee = .ok ⟨.i64,BitVec.ofNat 64 address⟩)
    (symbol : cm.symbols name = some address)
    (signature : ∀ s,env.sigOf name = some s → sig.abiMatch s = true)
    {g : List Clif.Val → Clif.Mem → Clif.Outcome} (found : env.extern name = some g)
    (pin : Pc name sig vals cm) (returned : g vals cm = .returned rvals cm')
    (results : rvals.length = sig.returns.length) :
    ∃ raw : IndirectTryRun f result label bi b sig isem MR fr
      (fun key => ρ (keyMap result key)) w rvals cm',
      ResolvedLiveNormalBranch result raw.source.branch.step isem MR fr ρ w raw.base raw.info.handlers.length rvals cm' (fun _ => True) := by
  obtain ⟨raw⟩ := stock_lower_indirect_try_normal_source_run lowered scope input abi node block kind table calls
    held read typed related calleeValue symbol signature found pin returned results
  exact ⟨raw,stock_indirect_try_run_resolved_live lowered scope ssa driver raw results⟩

end Backend.Stock.Proof.TryLiveResolvedSourceDraft
