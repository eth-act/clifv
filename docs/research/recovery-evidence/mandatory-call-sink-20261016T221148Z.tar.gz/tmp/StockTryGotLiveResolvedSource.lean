import StockTryLiveNormal
import FV.E2E.RegLevelDriverSem
namespace Backend.Stock.Proof.TryGotLiveResolvedSourceDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open TryLiveNormalDraft TryGotLiveSourceRunDraft
open TryGotSourceRunDraft TryGotSeparatedSourceRunDraft TryGotResolvedRunDraft TryResolvedRunsDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
/-- ORIGINAL whole source contracts internally construct both the raw GOT
execution and its final-renamed retained branch. All target/argument alias
separation and reserved-result fixedness are derived, without new input filters. -/
theorem stock_lower_got_try_resolved_live_normal_source_run {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f) (input : Prg.iselInB f = true)
    {label bi : Nat} {b : Clif.Block} (node : result.order.nodes[label]? = some (.original bi))
    (block : f.blocks[bi]? = some b) {fn : Nat} {args : List Nat} {et : Clif.ExnTable}
    (kind : b.term = .tryCall fn args et) {ext : Clif.ExtFunc} (external : f.extern? fn = some ext)
    (far : ext.colocated = false)
    {Rd F : BitVec 64 → Prop} {asm : FnCtx} {X : ExtSem} {MR : MemRelT} {sb : Nat} {syms : String → Option Nat}
    (stable : MRStable F MR) (memory : MemRefinesR Rd F sb syms (csem F asm X))
    (outgoing : OutArgsOk F result.code.outgoing MR)
    {env : Clif.Env} {exts : List Clif.ExtFunc}
    (calls : XCallsOk env exts MR X) (member : ext ∈ exts)
    {fr : Clif.Frame} {ρ : Nat → CV} {w : Arm.ArmState} {cm cm' : Clif.Mem} {vals rvals : List Clif.Val}
    (held : ValuesHeld (fun x => x ∈ args) result.ctx fr (fun key => ρ (keyMap result key))) (read : fr.getMany args = .ok vals)
    (typed : vals.map (·.ty) = Clif.AbiParam.tys ext.sig.params) (related : MR fr.slots cm w)
    {g : List Clif.Val → Clif.Mem → Clif.Outcome} (found : env.extern ext.name = some g)
    (returned : g vals cm = .returned rvals cm')
    (results : rvals.length = ext.sig.returns.length) :
    ∃ raw : GotTryRun f result label bi b ext (csem F asm X) MR fr (fun key => ρ (keyMap result key)) w rvals cm',
      aliasNum result.final.alias raw.target = raw.target ∧
      (∀ n ∈ raw.ns,aliasNum result.final.alias n ≠ raw.target) ∧
      (∀ x key,x ∈ availOf f (availIn f result.ctx) bi b.body.length →
        result.ctx.valueReg? x = some (.vreg key .int) → aliasNum result.final.alias key ≠ raw.target) ∧
      ResolvedLiveNormalBranch result raw.source.branch.step (csem F asm X) MR fr ρ w raw.base raw.info.handlers.length rvals cm'
        (fun x => x ∈ availOf f (availIn f result.ctx) bi b.body.length) := by
  obtain ⟨raw,targetFixed,separation,sourceGap⟩ := stock_lower_got_try_live_separated_normal_source_run
    lowered scope dominated input node block kind external far stable memory outgoing calls member
    held read typed related found returned results
  exact ⟨raw,targetFixed,separation,sourceGap,stock_got_try_run_resolved_live lowered scope dominated.ssa (driverSem_csem F asm X) raw targetFixed separation sourceGap results⟩
end Backend.Stock.Proof.TryGotLiveResolvedSourceDraft
