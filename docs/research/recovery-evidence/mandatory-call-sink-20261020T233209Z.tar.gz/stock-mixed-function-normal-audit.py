from pathlib import Path
import os,subprocess as sp,signal,json,datetime,hashlib,re
root=Path('/home/lee/clifv/.worktrees/stock-mixed-production');out=Path('/tmp/stock-mixed-function-mcp-review');sched=1763255
head=sp.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert head=='1aec0d40e68119e545dbd59c64b334e526f92799'
mods=json.loads(Path('/tmp/stock-mixed-function-mcp-modules.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();sources={m:sha(root/(m.replace('.','/')+'.lean')) for m in mods};stopped=False
try:
 assert b'stock-execute-scheduler.py' in Path(f'/proc/{sched}/cmdline').read_bytes();os.kill(sched,signal.SIGSTOP);stopped=True
 kids=Path(f'/proc/{sched}/task/{sched}/children').read_text().split();live=[k for k in kids if Path(f'/proc/{k}/stat').exists() and Path(f'/proc/{k}/stat').read_text().split()[2]!='Z'];assert len(live)<=1
 caps=[]
 for k in live:
  c=next(v.decode().split('=',1)[1] for v in Path(f'/proc/{k}/environ').read_bytes().split(b'\0') if v.startswith(b'FV_MEMCAP='));caps.append(int(c[:-1])*(1024 if c[-1]=='G' else 1))
 assert sum(caps)+4096<=16384
 env=dict(os.environ,PATH='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:'+os.environ['PATH'],FV_MEMCAP='4G',FV_LAKE_CACHE='/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache',LEAN_NUM_THREADS='1',OMP_NUM_THREADS='1',OMP_THREAD_LIMIT='1')
 log=out/'corrected-normal-audit.log'
 with log.open('w') as f:r=sp.run([str(root/'scripts/memcap.sh'),'lake','env','lean','--root='+str(out),str(out/'StockMixedFunctionReview.lean')],cwd=root,env=env,stdout=f,stderr=sp.STDOUT)
 assert r.returncode==0,('corrected normal audit failed',r.returncode,str(log))
 flat=' '.join(log.read_text().split());owned=re.search(r'MIXED_FUNCTION_CORE_STANDARD_ONLY (\d+)',flat);assert owned
 def axes(text):return {n:sorted(x.strip() for x in a.split(',') if x.strip()) for n,a in re.findall(r"'([^']+)' depends on axioms: \[([^\]]*)\]",text)}
 normal=axes(flat);raw=json.loads((out/'mcp-result.json').read_text())['structured_content'];mcp=axes(' '.join(d['message'] for d in raw['diagnostics']));assert len(normal)==14 and normal==mcp and all(set(v)<={'propext','Classical.choice','Quot.sound'} for v in normal.values())
 assert sp.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head and all(sha(root/(m.replace('.','/')+'.lean'))==h for m,h in sources.items())
 receipt={'state':'corrected_normal_owned_audit_and_public_MCP_observations_passed','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'project':str(root),'mcp_calls':1,'mcp_request_success':False,'mcp_error':'owned-audit harness counter lacked Nat annotation; all errors after public interface/axiom commands','public_roots_standard_only':14,'public_interface_applications':2,'normal_owned_constants_standard_only':int(owned[1]),'normal_owned_modules':mods,'source_sha256':sources,'axiom_sets':normal,'original_MCP_code_sha256':sha(out/'review.lean'),'corrected_normal_code_sha256':sha(out/'StockMixedFunctionReview.lean'),'raw_response_sha256':sha(out/'mcp-result.json'),'normal_log_sha256':sha(log),'cap_GiB':4,'aggregate_GiB':16,'max_build_review_jobs':2,'remaining_owned_MCP_processes':0,'MCP_full_success_claim':False}
 (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:receipt[k] for k in ['state','mcp_calls','mcp_request_success','public_roots_standard_only','normal_owned_constants_standard_only']}),flush=True)
finally:
 if stopped:os.kill(sched,signal.SIGCONT)
 print('primary scheduler resumed',flush=True)
