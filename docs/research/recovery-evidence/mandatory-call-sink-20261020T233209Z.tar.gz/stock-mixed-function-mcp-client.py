from pathlib import Path
import asyncio,json,os,re,hashlib
from mcp import ClientSession,StdioServerParameters
from mcp.client.stdio import stdio_client
root='/home/lee/clifv/.worktrees/stock-mixed-production'
out=Path('/tmp/stock-mixed-function-mcp-review');out.mkdir(exist_ok=True)
code='import FV.Backend.ABIReadFlags\nimport FV.Backend.Lowering.StockMixed\nimport FV.Backend.Lowering.StockMixedNI\nimport FV.Backend.StockMixedCheck\nimport FV.Backend.MixedNIProduction\nimport FV.Backend.Proof.StockMixedCheck\nimport FV.Backend.Proof.StockMixedBodyRefines\nimport FV.E2E.ABIReadFlags\nimport FV.E2E.StockMixedNI\nimport FV.E2E.StockMixedWorldX\nimport FV.E2E.CompiledSemantic\nimport FV.E2E.CompiledSemanticNI\nopen Lean Elab Command\nexample {f : Clif.Function} (checked : Backend.Stock.Mixed.sourceOk f = true) :\n    Backend.Stock.Mixed.Domain f := Backend.Stock.Mixed.sourceOk_sound checked\nexample {f : Clif.Function} {vc : Backend.VCode}\n    (checked : Backend.Stock.Mixed.check f vc = true) :\n    ∃ result, Backend.Stock.Mixed.Domain f ∧ Backend.Stock.lower f = .ok result ∧ result.code = vc ∧\n      result.edgeArgs.all (fun row => row.all (·.isEmpty)) = true :=\n  Backend.Stock.Mixed.check_sound checked\n#print axioms Backend.Stock.Proof.MixedBody.actual_mixed_body_refines\n#print axioms Backend.Stock.Proof.MixedBody.actual_mixed_entry_return_refines\n#print axioms Backend.Stock.Proof.MixedBody.actual_mixed_entry_return_refines_frame\n#print axioms Backend.Stock.Mixed.sourceOk_sound\n#print axioms Backend.Stock.Mixed.check_sound\n#print axioms E2E.backend_correct_world_niX_stock_mixed\n#print axioms E2E.backend_correct_worldX_stock_mixed\n#print axioms E2E.MixedFlagBoundary.refines\n#print axioms E2E.MixedFlagBoundary.driver\n#print axioms E2E.MixedFlagBoundary.memory\n#print axioms E2E.MixedFlagBoundary.machine_return\n#print axioms E2E.MixedFlagBoundary.return_transport\n#print axioms E2E.backend_correct_world_niX_semantic\n#print axioms E2E.backend_correct_worldX_semantic\nrun_cmd do\n  let env ← getEnv\n  let ownedModules := #["FV.Backend.ABIReadFlags","FV.Backend.Lowering.StockMixed","FV.Backend.Lowering.StockMixedNI","FV.Backend.StockMixedCheck","FV.Backend.MixedNIProduction","FV.Backend.Proof.StockMixedCheck","FV.Backend.Proof.StockMixedBodyRefines","FV.E2E.ABIReadFlags","FV.E2E.StockMixedNI","FV.E2E.StockMixedWorldX","FV.E2E.CompiledSemantic","FV.E2E.CompiledSemanticNI"]\n  let mut count := 0\n  for (name,_) in env.constants.toList do\n    let some i := env.getModuleIdxFor? name | continue\n    unless ownedModules.contains env.header.moduleNames[i]!.toString do continue\n    for ax in ← collectAxioms name do\n      unless #[``propext,``Classical.choice,``Quot.sound].contains ax do\n        throwError "disallowed axiom {ax} in {name}"\n    count := count+1\n  unless count > 0 do throwError "empty owned Mixed core audit"\n  logInfo m!"MIXED_FUNCTION_CORE_STANDARD_ONLY {count}"\n'
(out/'review.lean').write_text(code)
async def main():
 env=dict(os.environ,LEAN_PROJECT_PATH=root,LEAN_REPL='false',LOOGLE_LOCAL='false',LEAN_MCP_PREWARM_FILES='',LEAN_LSP_MAX_OPEN_FILES='1',LEAN_MCP_SCRATCH_SLOTS='1',LEAN_NUM_THREADS='1',OMP_NUM_THREADS='1',OMP_THREAD_LIMIT='1')
 params=StdioServerParameters(command='/home/lee/.nix-profile/bin/lean-lsp-mcp',args=['--lean-project-path',root,'--disable-tools','lean_build'],env=env,cwd=root)
 with (out/'server.stderr').open('w') as stderr:
  async with stdio_client(params,errlog=stderr) as (read,write):
   async with ClientSession(read,write,read_timeout_seconds=300) as session:
    await session.initialize()
    result=await session.call_tool('lean_run_code',{'code':code})
    raw=result.model_dump(mode='json');(out/'mcp-result.json').write_text(json.dumps(raw,indent=2)+'\n')
    assert not result.is_error,raw
    data=result.structured_content
    if not isinstance(data,dict):
     data=json.loads('\n'.join(c.text for c in result.content if c.type=='text'))
    assert data.get('success') and not data.get('timed_out'),data
    text=' '.join(str(d.get('message',d)) for d in data['diagnostics'])
    axioms={n:set(x.strip() for x in a.split(',') if x.strip()) for n,a in re.findall(r"'([^']+)' depends on axioms: \[([^\]]*)\]",text)}
    axioms.update({n:set() for n in re.findall(r"'([^']+)' does not depend on any axioms",text)})
    expected=set(['Backend.Stock.Proof.MixedBody.actual_mixed_body_refines', 'Backend.Stock.Proof.MixedBody.actual_mixed_entry_return_refines', 'Backend.Stock.Proof.MixedBody.actual_mixed_entry_return_refines_frame', 'Backend.Stock.Mixed.sourceOk_sound', 'Backend.Stock.Mixed.check_sound', 'E2E.backend_correct_world_niX_stock_mixed', 'E2E.backend_correct_worldX_stock_mixed', 'E2E.MixedFlagBoundary.refines', 'E2E.MixedFlagBoundary.driver', 'E2E.MixedFlagBoundary.memory', 'E2E.MixedFlagBoundary.machine_return', 'E2E.MixedFlagBoundary.return_transport', 'E2E.backend_correct_world_niX_semantic', 'E2E.backend_correct_worldX_semantic'])
    assert set(axioms)==expected,axioms
    assert all(v<={'propext','Classical.choice','Quot.sound'} for v in axioms.values()),axioms
    owned_match=re.search(r'MIXED_FUNCTION_CORE_STANDARD_ONLY (\d+)',text)
    assert owned_match,text
    (out/'owned-count.json').write_text(json.dumps({'count':int(owned_match[1]),'modules':['FV.Backend.ABIReadFlags', 'FV.Backend.Lowering.StockMixed', 'FV.Backend.Lowering.StockMixedNI', 'FV.Backend.StockMixedCheck', 'FV.Backend.MixedNIProduction', 'FV.Backend.Proof.StockMixedCheck', 'FV.Backend.Proof.StockMixedBodyRefines', 'FV.E2E.ABIReadFlags', 'FV.E2E.StockMixedNI', 'FV.E2E.StockMixedWorldX', 'FV.E2E.CompiledSemantic', 'FV.E2E.CompiledSemanticNI']})+'\n')
    (out/'axiom-sets.json').write_text(json.dumps({n:sorted(v) for n,v in axioms.items()},indent=2)+'\n')
 print(json.dumps({'state':'passed','project':root,'mcp_tool':'lean_run_code','calls':1,'public_roots_standard_only':14,'compatibility_applications':2,'code_sha256':hashlib.sha256(code.encode()).hexdigest(),'server_context_closed':True}),flush=True)
asyncio.run(main())
