import FV.Backend.ABIReadFlags
import FV.Backend.Lowering.StockMixed
import FV.Backend.Lowering.StockMixedNI
import FV.Backend.StockMixedCheck
import FV.Backend.MixedNIProduction
import FV.Backend.Proof.StockMixedCheck
import FV.Backend.Proof.StockMixedBodyRefines
import FV.E2E.ABIReadFlags
import FV.E2E.StockMixedNI
import FV.E2E.StockMixedWorldX
import FV.E2E.CompiledSemantic
import FV.E2E.CompiledSemanticNI
open Lean Elab Command
example {f : Clif.Function} (checked : Backend.Stock.Mixed.sourceOk f = true) :
    Backend.Stock.Mixed.Domain f := Backend.Stock.Mixed.sourceOk_sound checked
example {f : Clif.Function} {vc : Backend.VCode}
    (checked : Backend.Stock.Mixed.check f vc = true) :
    ∃ result, Backend.Stock.Mixed.Domain f ∧ Backend.Stock.lower f = .ok result ∧ result.code = vc ∧
      result.edgeArgs.all (fun row => row.all (·.isEmpty)) = true :=
  Backend.Stock.Mixed.check_sound checked
#print axioms Backend.Stock.Proof.MixedBody.actual_mixed_body_refines
#print axioms Backend.Stock.Proof.MixedBody.actual_mixed_entry_return_refines
#print axioms Backend.Stock.Proof.MixedBody.actual_mixed_entry_return_refines_frame
#print axioms Backend.Stock.Mixed.sourceOk_sound
#print axioms Backend.Stock.Mixed.check_sound
#print axioms E2E.backend_correct_world_niX_stock_mixed
#print axioms E2E.backend_correct_worldX_stock_mixed
#print axioms E2E.MixedFlagBoundary.refines
#print axioms E2E.MixedFlagBoundary.driver
#print axioms E2E.MixedFlagBoundary.memory
#print axioms E2E.MixedFlagBoundary.machine_return
#print axioms E2E.MixedFlagBoundary.return_transport
#print axioms E2E.backend_correct_world_niX_semantic
#print axioms E2E.backend_correct_worldX_semantic
run_cmd do
  let env ← getEnv
  let ownedModules := #["FV.Backend.ABIReadFlags","FV.Backend.Lowering.StockMixed","FV.Backend.Lowering.StockMixedNI","FV.Backend.StockMixedCheck","FV.Backend.MixedNIProduction","FV.Backend.Proof.StockMixedCheck","FV.Backend.Proof.StockMixedBodyRefines","FV.E2E.ABIReadFlags","FV.E2E.StockMixedNI","FV.E2E.StockMixedWorldX","FV.E2E.CompiledSemantic","FV.E2E.CompiledSemanticNI"]
  let mut count : Nat := 0
  for (name,_) in env.constants.toList do
    let some i := env.getModuleIdxFor? name | continue
    unless ownedModules.contains env.header.moduleNames[i]!.toString do continue
    for ax in ← collectAxioms name do
      unless #[``propext,``Classical.choice,``Quot.sound].contains ax do
        throwError "disallowed axiom {ax} in {name}"
    count := count+1
  unless count > 0 do throwError "empty owned Mixed core audit"
  logInfo m!"MIXED_FUNCTION_CORE_STANDARD_ONLY {count}"
