from pathlib import Path
import os,subprocess as sp,signal,json,datetime,hashlib
root=Path('/home/lee/clifv/.worktrees/stock-mixed-production');out=Path('/tmp/stock-mixed-function-mcp-review');out.mkdir(exist_ok=True);sched=1763255
head=sp.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert head=='1aec0d40e68119e545dbd59c64b334e526f92799'
assert not sp.check_output(['git','diff','--name-only'],cwd=root,text=True).strip()
assert b'stock-execute-scheduler.py' in Path(f'/proc/{sched}/cmdline').read_bytes()
mods=json.loads(Path('/tmp/stock-mixed-function-mcp-modules.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();sources={m:sha(root/(m.replace('.','/')+'.lean')) for m in mods}
stopped=False
try:
 os.kill(sched,signal.SIGSTOP);stopped=True
 kids=Path(f'/proc/{sched}/task/{sched}/children').read_text().split();live=[k for k in kids if Path(f'/proc/{k}/stat').exists() and Path(f'/proc/{k}/stat').read_text().split()[2]!='Z'];assert len(live)<=1,('existing jobs retain both slots',live)
 caps=[]
 for k in live:
  c=next(v.decode().split('=',1)[1] for v in Path(f'/proc/{k}/environ').read_bytes().split(b'\0') if v.startswith(b'FV_MEMCAP='));caps.append(int(c[:-1])*(1024 if c[-1]=='G' else 1))
 assert sum(caps)+4096<=16384,('need 4GiB review lane',caps)
 env=dict(os.environ,PATH='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:'+os.environ['PATH'],FV_MEMCAP='4G',FV_LAKE_CACHE='/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache',LEAN_NUM_THREADS='1',OMP_NUM_THREADS='1',OMP_THREAD_LIMIT='1',STOCK_MCP_REVIEW='stock-mixed-functions-20261020')
 with (out/'imports.log').open('w') as f:r=sp.run([str(root/'scripts/memcap.sh'),'lake','build','--no-build',*mods],cwd=root,env=env,stdout=f,stderr=sp.STDOUT)
 assert r.returncode==0,('current imports required',str(out/'imports.log'))
 python='/nix/store/8nf68ja9x78m7x0ni1gplic4b6w8x3bq-lean-lsp-mcp-env/bin/python3.13';assert Path(python).exists()
 with (out/'controller.log').open('w') as f:r=sp.run([str(root/'scripts/memcap.sh'),python,'/tmp/stock-mixed-function-mcp-client.py'],cwd=root,env=env,stdout=f,stderr=sp.STDOUT)
 assert r.returncode==0,('one bundled MCP review failed',r.returncode,str(out/'controller.log'))
 assert sp.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head and all(sha(root/(m.replace('.','/')+'.lean'))==h for m,h in sources.items())
 owned=json.loads((out/'owned-count.json').read_text());axioms=json.loads((out/'axiom-sets.json').read_text());assert len(axioms)==14
 receipt={'state':'passed','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'project':str(root),'mcp_calls':1,'public_roots':14,'owned_constants':owned['count'],'owned_modules':mods,'all_standard_only':True,'public_interface_applications':2,'source_sha256':sources,'code_sha256':sha(out/'review.lean'),'raw_response_sha256':sha(out/'mcp-result.json'),'logs':{p.name:sha(p) for p in out.iterdir() if p.is_file()},'cap_GiB':4,'aggregate_GiB':16,'max_build_review_jobs':2}
 (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:receipt[k] for k in ['state','mcp_calls','public_roots','owned_constants','all_standard_only']}),flush=True)
finally:
 if stopped:os.kill(sched,signal.SIGCONT)
 print('primary scheduler resumed',flush=True)
