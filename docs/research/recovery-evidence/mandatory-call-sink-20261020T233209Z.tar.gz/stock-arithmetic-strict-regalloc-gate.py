from pathlib import Path
import subprocess as sp,os,json,hashlib,datetime
root=Path('/home/lee/clifv/.worktrees/stock-driver-incremental')
source=Path('/home/lee/clifv/.worktrees/stock-mixed-production/FVTest/Backend/Lowering/StockArithmeticRuntime.lean')
out=Path('/tmp/stock-arithmetic-strict-regalloc-gate');out.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def emit(state,**kw):print(json.dumps({'state':state,**kw}),flush=True)
gate=json.loads(Path('/tmp/stock-arithmetic-current-main-author-gates/progress.json').read_text())
if gate['state']!='per_pr_gates_passed':emit('waiting_for_current_author_gates',phase=gate.get('phase'));raise SystemExit(0)
# Run only when the current author has finished and no other proof/kernel run is live.
if Path('/proc/1762992/cmdline').exists():emit('waiting_for_author_process_exit');raise SystemExit(0)
occupied=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:cmd=p.joinpath('cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')
 except (FileNotFoundError,PermissionError,ProcessLookupError):continue
 if '/bin/lean ' in cmd and any(str(tree) in cmd for tree in [root,source.parents[3]]):occupied.append(int(p.name))
if occupied:emit('waiting_for_existing_proof_kernels',pids=occupied);raise SystemExit(0)
head=sp.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert head=='213fe68bfbda3ed5d237cb7df6651f47e5a189bc'
assert gate['head']==head
frozen=json.loads(Path('/tmp/stock-arithmetic-current-main-author-gates/inputs.json').read_text())
original=root/'FVTest/Backend/Lowering/StockArithmeticRuntime.lean';assert sha(original)==frozen['sources'][str(original.relative_to(root))]
assert sha(source)=='b00043a15c8616e6b4b78bfa2d24634eeacb825bbd75d56db6aa1b1626641b1c', 'strict runtime changed; review and update expected evidence before running'
text=source.read_text();old=original.read_text()
extract=lambda x:x[x.index('private def checkConfiguration'):x.index('\ndef check : IO Unit')].split('/-- Require real accepted oracle answers')[0].rstrip()
assert extract(old)==extract(text),'original configurations/assertions changed'
assert 'private def checkedRegalloc2' in text and 'missing-binary negative control passed' in text
runtime=out/'StockArithmeticStrictRuntime.lean';runtime.write_text(text)
log=out/'runtime.log';env=dict(os.environ,PATH='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:'+os.environ['PATH'],FV_MEMCAP='8G',FV_LAKE_CACHE='/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache',LEAN_NUM_THREADS='2',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2')
with log.open('w') as f:r=sp.run([str(root/'scripts/memcap.sh'),'lake','env','lean','--run',str(runtime)],cwd=root,env=env,stdout=f,stderr=sp.STDOUT)
assert r.returncode==0,('strict_actual_primary_runtime_failed',r.returncode,str(log))
body=log.read_text();assert body.count('Stock arithmetic lean ')==6 and body.count('Stock arithmetic regalloc2 ')==6
assert 'Stock arithmetic missing-binary negative control passed' in body
assert sha(source)==sha(runtime) and sp.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head
j={'state':'strict_real_oracle_runtime_passed','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'runtime_source':str(source),'runtime_sha256':sha(runtime),'generated_runtime':str(runtime),'original_primary_runtime_sha256':sha(original),'log':str(log),'log_sha256':sha(log),'original_configuration_assertions_preserved':True,'abi_allocator_cleanup_cases':24,'real_checked_oracle_required':True,'missing_binary_negative_control':True,'remaining':'Include only this test repair in arithmetic final evidence commit and normal-build affected checked-in runtime test; production code remains frozen candidate.'}
(out/'receipt.json').write_text(json.dumps(j,indent=2)+'\n');emit(j['state'],receipt=str(out/'receipt.json'))
