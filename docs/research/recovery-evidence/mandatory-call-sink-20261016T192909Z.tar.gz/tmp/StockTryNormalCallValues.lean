import StockTryResultWrites
import FV.Backend.Proof.IselContractP
namespace Backend.Stock.Proof.TryNormalCallValuesDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open TryResultMapDraft TryResultWritesDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private theorem abi_room (sig : Clif.Signature) :
    (sigRets sig).length ≤ max sig.returns.length 2 := by
  unfold sigRets
  split
  · split
    · rename_i empty
      have zero := List.isEmpty_iff.mp empty
      simp only [zero,List.length_nil,List.length_cons,Nat.zero_add,Nat.max_eq_right (Nat.zero_le 2)]
      decide
    · exact Nat.le_max_left _ _
  · exact Nat.le_max_left _ _
/-- The ORIGINAL published callee contract realizes actual Stock TryCall normal
execution and returned memory world for its exact reserved definitions. The
explicit return count is admissible even with an implicit sret ABI return;
ordinary/direct/GOT contracts and their old variants are unchanged. -/
theorem stock_try_normal_call_values {Pc : String → Clif.Signature → List Clif.Val → Clif.Mem → Prop}
    {F : BitVec 64 → Prop} {env : Clif.Env} {exts : List Clif.ExtFunc} {MR : MemRelT} {isem : Sem}
    (calls : CallsRefineP Pc F env exts MR isem) :
    ∃ sym : String → BitVec 64,
      (∀ (rd : Reg) (name : String) (w : Arm.ArmState),∃ w',
        isem (.loadExtNameGot rd name) [] w = some ([ofX (sym name)],w',.next) ∧ SameWorldNF F w' w) ∧
      ∀ ext ∈ exts,∀ g (sl : List (Clif.SlotId × Nat)) (cm : Clif.Mem) (w : Arm.ArmState)
        (dest : CallDest) (us : List (Reg × Reg)) (info : TryInfo) (uses args : List CV)
        (vals rvals : List Clif.Val) (cm' : Clif.Mem) (base : Nat),
        env.extern ext.name = some g →
        (dest = .sym ext.name ∧ uses = args ∨
          ∃ r,dest = .reg r ∧ ext.colocated = false ∧ uses = ofX (sym ext.name) :: args) →
        ArgsAt ext.sig vals args w → MR sl cm w → Pc ext.name ext.sig vals cm →
        g vals cm = .returned rvals cm' → rvals.length = ext.sig.returns.length →
        ∃ outs w',
          isem (.tryCall ⟨dest,us,callDefs (resultDefs base ext.sig.returns.length)⟩
            {info with rets := ext.sig.returns.length}) uses w =
              some (outs,w',.goto info.handlers.length) ∧
          outs.length = max ext.sig.returns.length 2 ∧ PrefixHold rvals outs ∧ MR sl cm' w' ∧
          ∀ (ρ : Nat → CV) (j : Nat) (v : Clif.Val),rvals[j]? = some v →
            VHolds v (writeV ρ ((callDefOps (resultDefs base ext.sig.returns.length)).zip outs) (base+j)) := by
  obtain ⟨sym,load,ordinary,tried⟩ := calls
  refine ⟨sym,load,?_⟩
  intro ext member g sl cm w dest us info uses args vals rvals cm' base found target arguments memory pin returned count
  have defsCount : (callDefs (resultDefs base ext.sig.returns.length)).length = max ext.sig.returns.length 2 := by
    simp only [callDefs,resultDefs,List.length_map,List.length_range]
  obtain ⟨outs,w',run,length,held,related⟩ := tried ext member g sl cm w dest us
    (callDefs (resultDefs base ext.sig.returns.length)) {info with rets := ext.sig.returns.length}
    uses args vals rvals cm' found target (by rw [defsCount]; exact abi_room ext.sig)
    (returns_le_sigRets ext.sig) arguments memory pin returned count
  have actualLength : outs.length = max ext.sig.returns.length 2 := length.trans defsCount
  exact ⟨outs,w',run,actualLength,held,related,fun ρ j v atValue =>
    stock_try_write_normal_values base ext.sig.returns.length ρ held count actualLength atValue⟩
/-- The ORIGINAL indirect callee contract supplies normal TryCall execution,
returned world and values for the actual Stock reserved layout as well. Its
original at-most-eight argument premise is retained, with no stronger contract. -/
theorem stock_try_indirect_normal_call_values
    {Pc : String → Clif.Signature → List Clif.Val → Clif.Mem → Prop} {env : Clif.Env}
    {sigs : List Clif.Signature} {MR : MemRelT} {isem : Sem}
    (calls : IndCallsRefineP Pc env sigs MR isem) {sig : Clif.Signature} (member : sig ∈ sigs)
    {name : String} {g : List Clif.Val → Clif.Mem → Clif.Outcome} {sl : List (Clif.SlotId × Nat)}
    {cm cm' : Clif.Mem} {w : Arm.ArmState} {address : Nat} {r : Reg} {us : List (Reg × Reg)}
    (info : TryInfo) {target : CV} {args : List CV} {vals rvals : List Clif.Val} (base : Nat)
    (found : env.extern name = some g) (signature : ∀ s,env.sigOf name = some s → sig.abiMatch s = true)
    (symbol : cm.symbols name = some address) (callee : lo64 target = BitVec.ofNat 64 address)
    (count : vals.length ≤ 8) (arguments : AllHold vals args) (memory : MR sl cm w)
    (pin : Pc name sig vals cm) (returned : g vals cm = .returned rvals cm')
    (results : rvals.length = sig.returns.length) (typed : vals.map (·.ty) = Clif.AbiParam.tys sig.params) :
    ∃ outs w',isem (.tryCall ⟨.reg r,us,callDefs (resultDefs base sig.returns.length)⟩
        {info with rets := sig.returns.length}) (target :: args) w = some (outs,w',.goto info.handlers.length) ∧
      outs.length = max sig.returns.length 2 ∧ PrefixHold rvals outs ∧ MR sl cm' w' ∧
      ∀ (ρ : Nat → CV) (j : Nat) (v : Clif.Val),rvals[j]? = some v →
        VHolds v (writeV ρ ((callDefOps (resultDefs base sig.returns.length)).zip outs) (base+j)) := by
  have defsCount : (callDefs (resultDefs base sig.returns.length)).length = max sig.returns.length 2 := by
    simp only [callDefs,resultDefs,List.length_map,List.length_range]
  obtain ⟨outs,w',run,length,held,related⟩ := calls.2 sig member name g sl cm w address r us
    (callDefs (resultDefs base sig.returns.length)) {info with rets := sig.returns.length}
    target args vals rvals cm' found signature symbol callee (by rw [defsCount]; exact abi_room sig)
    (returns_le_sigRets sig) count arguments memory pin returned results typed
  have actualLength : outs.length = max sig.returns.length 2 := length.trans defsCount
  exact ⟨outs,w',run,actualLength,held,related,fun ρ j v atValue =>
    stock_try_write_normal_values base sig.returns.length ρ held results actualLength atValue⟩
end Backend.Stock.Proof.TryNormalCallValuesDraft
