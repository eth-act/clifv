import StockTryResultMap
import FV.Backend.Proof.IselCtlTry
import FV.Backend.Proof.LowerSeq
namespace Backend.Stock.Proof.TryResultWritesDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64 TryResultMapDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private theorem keys (base count : Nat) :
    (callDefOps (resultDefs base count)).map Operand.vreg =
      (List.range (max count 2)).map (resultKey base count) := by
  simp only [callDefOps,resultDefs,List.map_map,Function.comp_def]
/-- Every actual Stock TryCall definition is written once, despite the
noncontiguous virtual-register layout of overlapping return/payload registers. -/
theorem stock_try_result_defs_nodup (base count : Nat) :
    ((callDefOps (resultDefs base count)).map Operand.vreg).Nodup := by
  rw [keys]
  exact List.Pairwise.map _ (fun i j distinct same => distinct (stock_try_result_key_injective base count same)) List.nodup_range
/-- The actual indexed definition receives exactly its indexed machine output. -/
theorem stock_try_write_index (base count : Nat) (ρ : Nat → CV) {outs : List CV}
    (length : outs.length = max count 2) {j : Nat} {x : CV} (atValue : outs[j]? = some x) :
    writeV ρ ((callDefOps (resultDefs base count)).zip outs) (resultKey base count j) = x := by
  have inside : j < max count 2 := by have h := (List.getElem?_eq_some_iff.mp atValue).1; omega
  have nodup : (((callDefOps (resultDefs base count)).zip outs).map (·.1.vreg)).Nodup := by
    rw [show (fun q : Operand × CV => q.1.vreg) = Operand.vreg ∘ Prod.fst from rfl,← List.map_map,
      List.map_fst_zip (by simp [callDefOps,resultDefs,length])]
    exact stock_try_result_defs_nodup base count
  have atPair : ((callDefOps (resultDefs base count)).zip outs)[j]? =
      some (⟨resultKey base count j,.int,.def,.late,.fixed (.x j)⟩,x) := by
    rw [List.getElem?_zip_eq_some]
    simp [callDefOps,resultDefs,inside,atValue]
  exact writeV_nodup_ctl _ ρ j _ x nodup atPair
/-- Normal source results are held by the reserved return prefix after writing
actual machine outputs. No contiguous payload-layout approximation is used. -/
theorem stock_try_write_normal_values (base count : Nat) (ρ : Nat → CV)
    {values : List Clif.Val} {outs : List CV} (held : PrefixHold values outs)
    (normalCount : values.length = count) (length : outs.length = max count 2)
    {j : Nat} {v : Clif.Val} (atValue : values[j]? = some v) :
    VHolds v (writeV ρ ((callDefOps (resultDefs base count)).zip outs) (base+j)) := by
  have inside : j < count := by have h := (List.getElem?_eq_some_iff.mp atValue).1; omega
  obtain ⟨x,atOut⟩ : ∃ x,outs[j]? = some x :=
    ⟨outs[j]'(by omega),by simp⟩
  have received := stock_try_write_index base count ρ length atOut
  simp only [resultKey,inside,ite_true] at received
  rw [received]
  exact held.2 j v x atValue atOut
/-- This is the value-write ingredient for a tagged/default payload return:
physical payload j reaches the ACTUAL shared-return or separate-payload key.
It is conditional on payload values supplied by machine semantics, not a new
callee contract or a claim that exception machine execution is already proved. -/
theorem stock_try_write_payload_values (base count : Nat) (ρ : Nat → CV)
    {payloads : List Clif.Val} {outs : List CV} (held : PrefixHold payloads outs)
    (length : outs.length = max count 2) {j : Nat} {v : Clif.Val} (atValue : payloads[j]? = some v) :
    VHolds v (writeV ρ ((callDefOps (resultDefs base count)).zip outs) (resultKey base count j)) := by
  have below : j < outs.length := by have h := (List.getElem?_eq_some_iff.mp atValue).1; have bound := held.1; omega
  obtain ⟨x,atOut⟩ : ∃ x,outs[j]? = some x := ⟨outs[j]'below,by simp⟩
  rw [stock_try_write_index base count ρ length atOut]
  exact held.2 j v x atValue atOut
/-- Actual result writing preserves every virtual register outside this call's
exact definition map, with arbitrary machine output length. Source-availability
proofs must derive this disjointness when composing a whole driver simulation. -/
theorem stock_try_write_frame (base count : Nat) (ρ : Nat → CV) (outs : List CV) (d : Nat)
    (apart : ∀ j,j < max count 2 → d ≠ resultKey base count j) :
    writeV ρ ((callDefOps (resultDefs base count)).zip outs) d = ρ d := by
  apply writeV_other
  intro pair member
  have operand := (List.of_mem_zip member).1
  obtain ⟨q,present,same⟩ := List.mem_map.mp operand
  obtain ⟨j,inside,eq⟩ := List.mem_map.mp present
  rw [← same,← eq]
  exact Ne.symm (apart j (List.mem_range.mp inside))
end Backend.Stock.Proof.TryResultWritesDraft
