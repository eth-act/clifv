import StockExplicitCallSem
import StockTryNormalCallValues
namespace Backend.Stock.Proof.TryExplicitCallContractsDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64 ExplicitCallSemDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
/-- Stock's explicit regular-call result adapter preserves the ENTIRE original
pinned direct/GOT callee contract. Every old ABI-counted call remains compatible;
TryCall and symbol-load execution are definitionally unchanged. -/
theorem stock_explicit_original_calls_contract
    {Pc : String → Clif.Signature → List Clif.Val → Clif.Mem → Prop} {F : BitVec 64 → Prop}
    {env : Clif.Env} {exts : List Clif.ExtFunc} {MR : MemRelT} {isem : Sem}
    (calls : CallsRefineP Pc F env exts MR isem) :
    CallsRefineP Pc F env exts MR (explicitCallSem isem) := by
  obtain ⟨sym,load,ordinary,tried⟩ := calls
  refine ⟨sym,load,?_,tried⟩
  intro ext member g sl cm w dest us ds uses args vals rvals cm' found target defs arguments memory pin returned count
  obtain ⟨outs,w',run,length,held,related⟩ := ordinary ext member g sl cm w dest us ds uses args vals rvals cm'
    found target defs arguments memory pin returned count
  exact ⟨outs,w',stock_explicit_call_sem_compatible run length,length,held,related⟩
/-- The original indirect contract is preserved as well, with the same address,
signature, symbol-table, argument, memory and pinned-callee conditions. -/
theorem stock_explicit_original_indirect_calls_contract
    {Pc : String → Clif.Signature → List Clif.Val → Clif.Mem → Prop} {env : Clif.Env}
    {sigs : List Clif.Signature} {MR : MemRelT} {isem : Sem}
    (calls : IndCallsRefineP Pc env sigs MR isem) :
    IndCallsRefineP Pc env sigs MR (explicitCallSem isem) := by
  refine ⟨?_,calls.2⟩
  intro sig member name g sl cm w address r us ds target args vals rvals cm' found declared symbol callee defs count arguments memory pin returned length typed
  obtain ⟨outs,w',run,outCount,held,related⟩ := calls.1 sig member name g sl cm w address r us ds target args
    vals rvals cm' found declared symbol callee defs count arguments memory pin returned length typed
  exact ⟨outs,w',stock_explicit_call_sem_compatible run outCount,outCount,held,related⟩
end Backend.Stock.Proof.TryExplicitCallContractsDraft
