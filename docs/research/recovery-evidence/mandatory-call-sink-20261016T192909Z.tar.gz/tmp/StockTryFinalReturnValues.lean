import StockTryNormalCallValues
import StockTrySelectedCalls
import StockTryHelperFrames
import StockTryWholeSourceReservation
import FV.Backend.Proof.StockReservedTerminal
namespace Backend.Stock.Proof.TryFinalReturnValuesDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open TryResultMapDraft TryResultWritesDraft TryRetsTotalDraft TryWholeSourceReservationDraft
open TrySourceContextDraft TryBranchSelectionDraft TryBranchAbiDraft TrySelectedCallsDraft TryHelperFramesDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private theorem lookup_of_layout {slots : Array (List Reg × List Reg)} {i base count : Nat}
    (layout : slots[i]! = (reservedReturns base count,reservedPayloads base count)) :
    slots[i]? = some (reservedReturns base count,reservedPayloads base count) := by
  cases found : slots[i]? with
  | none => simp only [getElem!_def,found] at layout; cases congrArg Prod.snd layout
  | some pair =>
    have same : pair = (reservedReturns base count,reservedPayloads base count) := by
      simpa only [getElem!_def,found] using layout
    rw [same]
/-- Normal source results are held through the ACTUAL whole-driver final alias
map. Reserved-return terminality is derived from lowering, rather than supplied
as an alias-resolution or source-numbering certificate. -/
theorem stock_lower_try_normal_reserved_values {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) {owner base count : Nat}
    (layout : result.initial.tryRegs[owner]! = (reservedReturns base count,reservedPayloads base count))
    (ρ : Nat → CV) {values : List Clif.Val} {outs : List CV} (held : PrefixHold values outs)
    (normalCount : values.length = count) (length : outs.length = max count 2)
    {j : Nat} {v : Clif.Val} (atValue : values[j]? = some v) :
    VHolds v (writeV ρ ((callDefOps (resultDefs base count)).zip outs) (aliasNum result.final.alias (base+j))) := by
  have inside : j < count := by have h := (List.getElem?_eq_some_iff.mp atValue).1; omega
  have member : (.vreg (base+j) .int) ∈ reservedReturns base count :=
    List.mem_map.mpr ⟨j,List.mem_range.mpr inside,rfl⟩
  have terminal := (stock_lower_reservedReturn_terminal lowered (lookup_of_layout layout) member).2
  rw [terminal]
  exact stock_try_write_normal_values base count ρ held normalCount length atValue
/-- Original source/table/context/traversal facts supply the actual helper defs
and final-alias normal-result transfer for the same selected branch. No caller
reservation, count, allocation, final-alias or reachability certificate is added. -/
theorem stock_lower_original_try_result_values {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f) (input : Prg.iselInB f = true)
    {label bi : Nat} {b : Clif.Block} (node : result.order.nodes[label]? = some (.original bi))
    (block : f.blocks[bi]? = some b) {et : Clif.ExnTable} {sig : Clif.Signature} {items : List (Option Nat)}
    (kind : sourceTable b.term = some et) (table : exnTableOpnd f et = .ok (sig,items)) :
    ∃ (source : TryBranchSource f result label bi b) (_selected : TryBranchSelection source)
      (base : Nat) (value : V) (next : State),
      result.initial.tryRegs[source.ti]! = (reservedReturns base sig.returns.length,reservedPayloads base sig.returns.length) ∧
      Stock.externCtor source.ctx T.gen_try_call_rets [.op (.sig sig)] source.input = .ok (value,next) ∧
      value = .op (.callRets (callDefs (resultDefs base sig.returns.length))) ∧
      ∀ (ρ : Nat → CV) (values : List Clif.Val) (outs : List CV),PrefixHold values outs →
        values.length = sig.returns.length → outs.length = max sig.returns.length 2 →
        ∀ (j : Nat) (v : Clif.Val),values[j]? = some v →
          VHolds v (writeV ρ ((callDefOps (resultDefs base sig.returns.length)).zip outs)
            (aliasNum result.final.alias (base+j))) := by
  obtain ⟨ranges,source,selected,base,value,next,build,allocation,slots,helper,frame⟩ :=
    stock_lower_original_try_reservation lowered scope input node block kind table
  have layout : result.initial.tryRegs[source.ti]! = (reservedReturns base sig.returns.length,reservedPayloads base sig.returns.length) := by
    rw [← allocation.2]
    exact source.tryRegs.symm.trans slots
  have bound : sig.returns.length ≤ 8 := by
    obtain ⟨ps,returns,rest⟩ := TryRetsShapeDraft.stock_try_rets_exact_shape helper
    by_cases inside : sig.returns.length ≤ 8
    · exact inside
    · simp only [retRegs,if_neg inside] at returns
      cases returns
  refine ⟨source,selected,base,value,next,layout,helper,
    stock_try_reserved_result_defs helper base bound (exnTableOpnd_cc table) slots,?_⟩
  intro ρ values outs held count length j v atValue
  exact stock_lower_try_normal_reserved_values lowered layout ρ held count length atValue
private theorem actual_rets {f : Clif.Function} {result : Result} {label bi : Nat} {b : Clif.Block}
    {source : TryBranchSource f result label bi b} (selected : TryBranchSelection source)
    {et : Clif.ExnTable} {sig : Clif.Signature} {items : List (Option Nat)}
    (kind : sourceTable b.term = some et) (table : exnTableOpnd f et = .ok (sig,items)) :
    ∃ (before after : State) (value : V),
      Stock.externCtor source.ctx T.gen_try_call_rets [.op (.sig sig)] before = .ok (value,after) := by
  cases term : b.term <;> simp only [sourceTable,term] at kind
  all_goals try contradiction
  case tryCall fn args et' =>
    cases kind
    obtain ⟨sig',items',ext,decoded,external,signature,data⟩ := stock_try_source_direct_data source term
    have same := congrArg Prod.fst (Except.ok.inj (decoded.symm.trans table))
    have extSig : ext.sig = sig := signature.trans same
    cases near : ext.colocated with
    | true =>
      obtain ⟨_,_,_,_,_,_,calls⟩ := stock_selected_try_direct_rhs_calls selected term external near
      obtain ⟨info,before,after,defs,decodedInfo,helper,frame,base⟩ := stock_direct_try_helper_frames calls
      rw [extSig] at helper
      exact ⟨before,after,defs,helper⟩
    | false =>
      obtain ⟨_,_,_,_,_,_,calls⟩ := stock_selected_try_got_rhs_calls selected term external near
      obtain ⟨info,before,after,defs,decodedInfo,helper,frame,base⟩ := stock_got_try_helper_frames calls
      rw [extSig] at helper
      exact ⟨before,after,defs,helper⟩
  case tryCallIndirect callee args et' =>
    cases kind
    obtain ⟨sig',items',decoded,rule,env,matched,trace,calls⟩ := stock_selected_try_indirect_rhs_calls selected term
    have same := congrArg Prod.fst (Except.ok.inj (decoded.symm.trans table))
    obtain ⟨info,before,after,defs,decodedInfo,helper,frame,base⟩ := stock_indirect_try_helper_frames calls
    change sig' = sig at same
    rw [same] at helper
    exact ⟨before,after,defs,helper⟩
/-- Strong actual-RHS variant: the SAME real selected branch supplies the
reserved helper at its actual intermediate state after argument generation.
Its exact defs and final-alias result transfer are derived internally; the
source-input helper variant above remains available unchanged. -/
theorem stock_lower_original_try_actual_result_values {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f) (input : Prg.iselInB f = true)
    {label bi : Nat} {b : Clif.Block} (node : result.order.nodes[label]? = some (.original bi))
    (block : f.blocks[bi]? = some b) {et : Clif.ExnTable} {sig : Clif.Signature} {items : List (Option Nat)}
    (kind : sourceTable b.term = some et) (table : exnTableOpnd f et = .ok (sig,items)) :
    ∃ (source : TryBranchSource f result label bi b) (_selected : TryBranchSelection source)
      (base : Nat) (before : State) (value : V) (after : State),
      result.initial.tryRegs[source.ti]! = (reservedReturns base sig.returns.length,reservedPayloads base sig.returns.length) ∧
      Stock.externCtor source.ctx T.gen_try_call_rets [.op (.sig sig)] before = .ok (value,after) ∧
      value = .op (.callRets (callDefs (resultDefs base sig.returns.length))) ∧
      ∀ (ρ : Nat → CV) (values : List Clif.Val) (outs : List CV),PrefixHold values outs →
        values.length = sig.returns.length → outs.length = max sig.returns.length 2 →
        ∀ (j : Nat) (v : Clif.Val),values[j]? = some v →
          VHolds v (writeV ρ ((callDefOps (resultDefs base sig.returns.length)).zip outs)
            (aliasNum result.final.alias (base+j))) := by
  obtain ⟨ranges,source,selected,base,replay,replayAfter,build,allocation,slots,replayRun,frame⟩ :=
    stock_lower_original_try_reservation lowered scope input node block kind table
  obtain ⟨before,after,value,helper⟩ := actual_rets selected kind table
  have layout : result.initial.tryRegs[source.ti]! = (reservedReturns base sig.returns.length,reservedPayloads base sig.returns.length) := by
    rw [← allocation.2]
    exact source.tryRegs.symm.trans slots
  have bound : sig.returns.length ≤ 8 := by
    obtain ⟨ps,returns,rest⟩ := TryRetsShapeDraft.stock_try_rets_exact_shape helper
    by_cases inside : sig.returns.length ≤ 8
    · exact inside
    · simp only [retRegs,if_neg inside] at returns
      cases returns
  refine ⟨source,selected,base,before,value,after,layout,helper,
    stock_try_reserved_result_defs helper base bound (exnTableOpnd_cc table) slots,?_⟩
  intro ρ values outs held count length j v atValue
  exact stock_lower_try_normal_reserved_values lowered layout ρ held count length atValue
end Backend.Stock.Proof.TryFinalReturnValuesDraft
