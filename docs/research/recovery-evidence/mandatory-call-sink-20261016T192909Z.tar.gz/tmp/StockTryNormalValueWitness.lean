import StockTryExplicitCallContracts
import StockTryResultValueWitness
import FV.E2E.RegLevelDriverSem
namespace Backend.Stock.Proof.TryNormalValueWitnessDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open TryStackSourceDraft TryStackFixtureDraft TryResultMapDraft TryResultValueWitnessDraft TryNormalCallValuesDraft TryExplicitCallContractsDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
attribute [local irreducible] Stock.lower Stock.runTerm Isle.Aarch64.program
private def model : ExtSem := ⟨fun _ _ w => some ([17],w),fun _ _ => 4096,0,fun _ w => Arm.read_pstate w⟩
private def environment : Clif.Env := {
  extern := fun _ => some (fun _ cm => .returned [⟨.i64,17⟩] cm),names := ["callee"],sigOf := fun _ => some signature }
private def sourceMemory : Clif.Mem := {Clif.Mem.empty with symbols := fun n => if n = "callee" then some 4096 else none}
private def ext : Clif.ExtFunc := {name := "callee",sig := signature,colocated := false}
private def sourceValues : List Clif.Val := List.replicate 9 ⟨.i64,0⟩
private def machineArgs : List CV := List.replicate 8 0
private def uses : List (Reg × Reg) := (List.range 8).map fun j => (.x j,.vreg (192+j) .int)
private def info : TryInfo := {continuation := 1,handlers := [.tag 7 2],clobberAll := false,rets := 1}
private theorem held : PrefixHold [⟨.i64,17⟩] ([17] : List CV) := by
  refine ⟨by decide,?_⟩
  intro j v x atValue atOut
  cases j with
  | zero => cases atValue; cases atOut; rfl
  | succ j => simp at atValue
private theorem xcalls : XCallsOk environment [ext] (fun _ _ _ => True) model := by
  intro e member g sl cm w dest used args vals rvals cm' found target arguments memory returned length
  have same := List.mem_singleton.mp member
  subst e
  simp only [environment,Option.some.injEq] at found
  subst g
  cases returned
  exact ⟨[17],w,rfl,rfl,held,trivial⟩
private theorem allZero (n : Nat) :
    AllHold (List.replicate n (⟨.i64,0⟩ : Clif.Val)) (List.replicate n (0 : CV)) := by
  refine ⟨by simp,?_⟩
  intro j v x atValue atOut
  have av := (List.mem_replicate.mp (List.mem_of_getElem? atValue)).2
  have ax := (List.mem_replicate.mp (List.mem_of_getElem? atOut)).2
  subst v; subst x; rfl
private theorem argumentsAt : ArgsAt signature sourceValues machineArgs Arm.ArmState.default := by
  refine ⟨rfl,?_,?_⟩
  · change AllHold (List.replicate 8 (⟨.i64,0⟩ : Clif.Val)) (List.replicate 8 (0 : CV))
    exact allZero 8
  · intro off v member
    change (ArgLoc.stack off,v) ∈ [(.reg (.x 0),⟨.i64,0⟩),(.reg (.x 1),⟨.i64,0⟩),
      (.reg (.x 2),⟨.i64,0⟩),(.reg (.x 3),⟨.i64,0⟩),(.reg (.x 4),⟨.i64,0⟩),
      (.reg (.x 5),⟨.i64,0⟩),(.reg (.x 6),⟨.i64,0⟩),(.reg (.x 7),⟨.i64,0⟩),(.stack 0,⟨.i64,0⟩)] at member
    have only : off = 0 ∧ v = ⟨.i64,0⟩ := by simpa using member
    rcases only with ⟨rfl,rfl⟩
    rfl
/-- A COMPLETE original-condition nine-argument compiler pipeline and its real
reserved helper defs inhabit the ORIGINAL external/callee contracts, actual
csem TryCall normal execution, returned world and result-value binding.
Identification with the actual emitted instruction and source-frame transfer
remain separate obligations; no exception machine semantics is asserted. -/
theorem stock_complete_try_normal_csem_values_witness :
    ∃ (out : Output) (value : V) (next : State) (outs : List CV) (world : Arm.ArmState),
      LowerScope function ∧ Dominated function ∧ ArityOk function ∧ Stock.lower function = .ok out.result ∧
      prepareAt out.result.code out.result.edgeArgs = .ok out.prepared ∧ out.rf = spillAllocAt out.prepared.code out.prepared.edges ∧
      checkAllocAt out.prepared.code out.prepared.edges out.rf = .ok () ∧ lowerRFunc out.prepared.code out.rf = .ok out.af ∧
      Stock.externCtor (helperContext out.result) T.gen_try_call_rets [.op (.sig signature)] out.result.initial = .ok (value,next) ∧
      value = .op (.callRets (callDefs (resultDefs 201 1))) ∧
      XCallsOk environment [ext] (fun _ _ _ => True) model ∧
      CallsRefineP (fun _ _ _ _ => True) (fun _ => False) environment [ext] (fun _ _ _ => True)
        (csem (fun _ => False) ⟨0,0⟩ model) ∧
      CallsRefineP (fun _ _ _ _ => True) (fun _ => False) environment [ext] (fun _ _ _ => True)
        (ExplicitCallSemDraft.explicitCallSem (csem (fun _ => False) ⟨0,0⟩ model)) ∧
      ArgsAt signature sourceValues machineArgs Arm.ArmState.default ∧
      csem (fun _ => False) ⟨0,0⟩ model
        (.tryCall ⟨.reg (.vreg 207 .int),uses,callDefs (resultDefs 201 1)⟩ info)
        (ofX 4096 :: machineArgs) Arm.ArmState.default = some (outs,world,.goto 1) ∧
      outs.length = 2 ∧ PrefixHold [⟨.i64,17⟩] outs ∧ world = Arm.ArmState.default ∧
      (∀ ρ : Nat → CV,VHolds ⟨.i64,17⟩ (writeV ρ ((callDefOps (resultDefs 201 1)).zip outs) 201)) ∧
      Clif.runWith environment {funcs := [function]} function.name sourceValues sourceMemory 4 =
        .returned [⟨.i64,17⟩] sourceMemory := by
  obtain ⟨out,value,next,lowered,prepare,accepted,physical,slots,run,defs⟩ := stock_nine_try_result_defs_witness
  have contract : CallsRefineP (fun _ _ _ _ => True) (fun _ => False) environment [ext] (fun _ _ _ => True)
      (csem (fun _ => False) ⟨0,0⟩ model) := (callsRefine_csem xcalls).toP _
  have adapted := stock_explicit_original_calls_contract contract
  obtain ⟨sym,load,returned⟩ := stock_try_normal_call_values adapted
  have symbol : sym ext.name = 4096 := by
    obtain ⟨w,executed,preserved⟩ := load (.vreg 207 .int) ext.name Arm.ArmState.default
    have same : [ofX (sym ext.name)] = [ofX 4096] := by
      have actual := congrArg (Option.map (fun q => q.1)) executed
      simpa only [ExplicitCallSemDraft.explicitCallSem,csem,model,Option.map_some,Option.some.injEq] using actual.symm
    have valueEq := List.cons.inj same |>.1
    simpa only [lo64_ofX] using congrArg lo64 valueEq
  obtain ⟨outs,world,executed,length,relatedValues,memory,values⟩ := returned ext (by simp) _ [] Clif.Mem.empty
    Arm.ArmState.default (.reg (.vreg 207 .int)) uses info (ofX 4096 :: machineArgs) machineArgs
    sourceValues [⟨.i64,17⟩] Clif.Mem.empty 201 rfl
    (.inr ⟨.vreg 207 .int,rfl,rfl,by rw [symbol]⟩) argumentsAt trivial trivial rfl rfl
  have sameWorld : world = Arm.ArmState.default := by
    have actual := congrArg (Option.map (fun q => q.2.1)) executed
    simp [ExplicitCallSemDraft.explicitCallSem,csem,model,info,ext,signature] at actual
    obtain ⟨a,⟨_,same⟩,_⟩ := actual
    exact same.symm
  exact ⟨out,value,next,outs,world,out.scope,out.dominated,out.arity,out.lowered,out.prepare,out.fallback,
    out.accepted,out.physical,run,defs,xcalls,contract,adapted,argumentsAt,executed,length,relatedValues,sameWorld,
    (fun ρ => values ρ 0 ⟨.i64,17⟩ rfl),rfl⟩
end Backend.Stock.Proof.TryNormalValueWitnessDraft
