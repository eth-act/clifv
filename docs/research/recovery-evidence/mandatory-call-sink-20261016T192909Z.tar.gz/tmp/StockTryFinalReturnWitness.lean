import StockTryFinalReturnValues
import StockTryStackFixture
import FV.Backend.Proof.PerEdgeSpillEntryFixture
namespace Backend.Stock.Proof.TryFinalReturnWitnessDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open TryRetsTotalDraft TryResultMapDraft TryFinalReturnValuesDraft TrySourceContextDraft TryBranchSelectionDraft TryBranchAbiDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private def function (indirect : Bool) := if indirect then SpillEntryFixture.function true else TryStackSourceDraft.function
private def table (indirect : Bool) : Clif.ExnTable := if indirect then {
  sig := 0,normal := ⟨1,[.ret 0,.val 0]⟩,items := [.tag 7 ⟨2,[.exn 0,.exn 1,.val 0]⟩] } else TryStackSourceDraft.table
private structure Pipeline (f : Clif.Function) where
  result : Result
  prepared : EdgeVCode
  rf : RFunc
  af : AFunc
  lowered : Stock.lower f = .ok result
  scope : LowerScope f
  dominated : Dominated f
  arity : ArityOk f
  prepare : prepareAt result.code result.edgeArgs = .ok prepared
  fallback : rf = spillAllocAt prepared.code prepared.edges
  accepted : checkAllocAt prepared.code prepared.edges rf = .ok ()
  physical : lowerRFunc prepared.code rf = .ok af
private theorem pipeline (indirect : Bool) : Nonempty (Pipeline (function indirect)) := by
  cases indirect with
  | false =>
    obtain ⟨out⟩ := TryStackFixtureDraft.stock_nine_argument_try_fixture
    exact ⟨⟨out.result,out.prepared,out.rf,out.af,out.lowered,out.scope,out.dominated,out.arity,
      out.prepare,out.fallback,out.accepted,out.physical⟩⟩
  | true =>
    obtain ⟨out⟩ := SpillEntryFixture.try_fixture true
    exact ⟨⟨out.result,out.prepared,out.rf,out.af,out.lowered,out.scope,out.dominated,out.arity,
      out.prepare,out.fallback,out.accepted,out.physical⟩⟩
private theorem held : PrefixHold [⟨.i64,17⟩] ([17,99] : List CV) := by
  refine ⟨by decide,?_⟩
  intro j v x atValue atOut
  cases j with
  | zero => cases atValue; cases atOut; rfl
  | succ j => simp at atValue
/-- Complete original nine-argument GOT and true indirect compiler pipelines
instantiate the SAME actual source/selection/helper definition map and final
whole-driver alias transfer. No alias endpoint or allocation certificate is
supplied; the normal17 value is read through the actual final alias map. -/
theorem stock_complete_try_final_return_values_witness (indirect : Bool) :
    ∃ (out : Pipeline (function indirect))
      (source : TryBranchSource (function indirect) out.result 0 0 (function indirect).blocks[0]!)
      (_selected : TryBranchSelection source) (base : Nat) (value : V) (next : State),
      LowerScope (function indirect) ∧ Dominated (function indirect) ∧ ArityOk (function indirect) ∧
      Stock.lower (function indirect) = .ok out.result ∧ prepareAt out.result.code out.result.edgeArgs = .ok out.prepared ∧
      out.rf = spillAllocAt out.prepared.code out.prepared.edges ∧
      checkAllocAt out.prepared.code out.prepared.edges out.rf = .ok () ∧ lowerRFunc out.prepared.code out.rf = .ok out.af ∧
      out.result.initial.tryRegs[source.ti]! = (reservedReturns base 1,reservedPayloads base 1) ∧
      Stock.externCtor source.ctx T.gen_try_call_rets [.op (.sig (function indirect).sig)] source.input = .ok (value,next) ∧
      value = .op (.callRets (callDefs (resultDefs base 1))) ∧
      ∀ ρ : Nat → CV,VHolds ⟨.i64,17⟩ (writeV ρ ((callDefOps (resultDefs base 1)).zip [17,99])
        (aliasNum out.result.final.alias base)) := by
  obtain ⟨out⟩ := pipeline indirect
  have order : blockOrder (function indirect) = .ok {
    nodes := #[.original 0,.original 1,.original 2],successors := #[#[2,1],#[],#[]]} := by cases indirect <;> cbv
  have sameOrder := Except.ok.inj ((stock_lower_order out.lowered).symm.trans order)
  have node : out.result.order.nodes[0]? = some (.original 0) := by rw [sameOrder]; rfl
  have block : (function indirect).blocks[0]? = some (function indirect).blocks[0]! := by cases indirect <;> rfl
  have input : Prg.iselInB (function indirect) = true := by cases indirect <;> decide +kernel
  have kind : sourceTable (function indirect).blocks[0]!.term = some (table indirect) := by cases indirect <;> rfl
  have decoded : exnTableOpnd (function indirect) (table indirect) = .ok ((function indirect).sig,[some 7]) := by cases indirect <;> rfl
  obtain ⟨source,selected,base,value,next,layout,helper,defs,values⟩ :=
    stock_lower_original_try_result_values out.lowered out.scope input node block kind decoded
  have count : (function indirect).sig.returns.length = 1 := by cases indirect <;> rfl
  rw [count] at layout defs values
  exact ⟨out,source,selected,base,value,next,out.scope,out.dominated,out.arity,out.lowered,out.prepare,out.fallback,
    out.accepted,out.physical,layout,helper,defs,fun ρ => values ρ _ _ held rfl rfl 0 ⟨.i64,17⟩ rfl⟩
/-- Actual-RHS witness retains the source-input witness above. -/
theorem stock_complete_try_actual_final_return_values_witness (indirect : Bool) :
    ∃ (out : Pipeline (function indirect))
      (source : TryBranchSource (function indirect) out.result 0 0 (function indirect).blocks[0]!)
      (_selected : TryBranchSelection source) (base : Nat) (before : State) (value : V) (next : State),
      LowerScope (function indirect) ∧ Dominated (function indirect) ∧ ArityOk (function indirect) ∧
      Stock.lower (function indirect) = .ok out.result ∧ prepareAt out.result.code out.result.edgeArgs = .ok out.prepared ∧
      out.rf = spillAllocAt out.prepared.code out.prepared.edges ∧
      checkAllocAt out.prepared.code out.prepared.edges out.rf = .ok () ∧ lowerRFunc out.prepared.code out.rf = .ok out.af ∧
      out.result.initial.tryRegs[source.ti]! = (reservedReturns base 1,reservedPayloads base 1) ∧
      Stock.externCtor source.ctx T.gen_try_call_rets [.op (.sig (function indirect).sig)] before = .ok (value,next) ∧
      value = .op (.callRets (callDefs (resultDefs base 1))) ∧
      ∀ ρ : Nat → CV,VHolds ⟨.i64,17⟩ (writeV ρ ((callDefOps (resultDefs base 1)).zip [17,99])
        (aliasNum out.result.final.alias base)) := by
  obtain ⟨out⟩ := pipeline indirect
  have order : blockOrder (function indirect) = .ok {
    nodes := #[.original 0,.original 1,.original 2],successors := #[#[2,1],#[],#[]]} := by cases indirect <;> cbv
  have sameOrder := Except.ok.inj ((stock_lower_order out.lowered).symm.trans order)
  have node : out.result.order.nodes[0]? = some (.original 0) := by rw [sameOrder]; rfl
  have block : (function indirect).blocks[0]? = some (function indirect).blocks[0]! := by cases indirect <;> rfl
  have input : Prg.iselInB (function indirect) = true := by cases indirect <;> decide +kernel
  have kind : sourceTable (function indirect).blocks[0]!.term = some (table indirect) := by cases indirect <;> rfl
  have decoded : exnTableOpnd (function indirect) (table indirect) = .ok ((function indirect).sig,[some 7]) := by cases indirect <;> rfl
  obtain ⟨source,selected,base,before,value,next,layout,helper,defs,values⟩ :=
    stock_lower_original_try_actual_result_values out.lowered out.scope input node block kind decoded
  have count : (function indirect).sig.returns.length = 1 := by cases indirect <;> rfl
  rw [count] at layout defs values
  exact ⟨out,source,selected,base,before,value,next,out.scope,out.dominated,out.arity,out.lowered,out.prepare,out.fallback,
    out.accepted,out.physical,layout,helper,defs,fun ρ => values ρ _ _ held rfl rfl 0 ⟨.i64,17⟩ rfl⟩
end Backend.Stock.Proof.TryFinalReturnWitnessDraft
