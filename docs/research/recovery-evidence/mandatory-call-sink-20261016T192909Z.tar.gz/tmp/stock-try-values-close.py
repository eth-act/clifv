from pathlib import Path
import json,hashlib,re,datetime,tarfile,shutil
root=Path('/home/lee/clifv/.worktrees/driver-proof-resume');docs=root/'docs/research'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
now=datetime.datetime.now(datetime.timezone.utc);stamp=now.strftime('%Y%m%dT%H%M%SZ')
batch=json.loads(Path('/tmp/stock-try-values-batch.json').read_text());old=json.loads((docs/'stock-try-outgoing-scratch.json').read_text())
sets={m.group(1):sorted(x.strip() for x in m.group(2).split(',') if x.strip()) for m in re.finditer(r"'([^']+)' depends on axioms:\s*\[([^]]*)\]",Path('/tmp/stock-try-values-combined-axioms.log').read_text())}
for m in re.finditer(r"'([^']+)' does not depend on any axioms",Path('/tmp/stock-try-values-combined-axioms.log').read_text()):sets[m.group(1)]=[]
for n,a in old['normal_audit']['sets'].items():assert sorted(a)==sets[n],n
allowed={'propext','Classical.choice','Quot.sound'}
for n in batch['public_roots']+batch['models']:assert set(sets[n])<=allowed,n
constants=[json.loads(line.split('DELIVERY_CONSTANT ',1)[1]) for line in Path('/tmp/stock-try-values-all-constants.log').read_text().splitlines() if line.startswith('DELIVERY_CONSTANT ')]
assert constants
for n,a in constants:assert set(a)<=allowed,n
mods={}
for m in batch['modules']:
 p=Path('/tmp')/m;check=json.loads(p.with_suffix('.check.json').read_text());assert check['actual_exit']==0
 rec={}
 for key,ext in [('source','.lean'),('object','.olean'),('log','.log'),('check','.check.json')]:
  f=p.with_suffix(ext);rec[key]=str(f);rec[key+'_sha256']=sha(f)
 for k in ['source','object','log']:assert rec[k+'_sha256']==check[k+'_sha256']
 assert not re.search(r'\b(sorry|admit|axiom|trace_state|native_decide)\b',p.with_suffix('.lean').read_text())
 mods[m]=rec
prior={}
for name in ['source-execution-x','try-source','try-context','try-rule','try-rets','try-reservation','try-outgoing']:
 d=json.loads((docs/f'stock-{name}-scratch.json').read_text())
 for m,rec in d['modules'].items():
  for k in ['source','object','log']:assert sha(rec[k])==rec[k+'_sha256'],(m,k)
  prior[m]=rec
freeze=json.loads(Path('/tmp/stock-coherent-build-inputs.json').read_text())
for group in ['source_sha256','validation_script_sha256']:
 for p,h in freeze[group].items():assert sha(root/p)==h,p
progress=json.loads(Path('/tmp/stock-pr246-gates-progress.json').read_text());progress.pop('completed_phases',None)
remaining=old['remaining_checklist']
remaining.append({'requirement':'Actual selected helper definition maps and normal final-alias return values','state':'Proved for actual selected-RHS intermediate helper, with old source-input variant preserved; complete nine-arg GOT and true indirect witnesses. Full emitted instruction/GOT-prefix/argument-store/source-frame composition remains open.'})
remaining.append({'requirement':'Original call contracts, explicit/sret compatibility and exceptional payload machine semantics','state':'Original CallsRefineP/IndCallsRefineP consumed, explicitCallSem adapters preserved, ABI count admissibility proved. Whole sret/x8 physical/source compatibility and exceptional machine execution remain open; S10 shared interfaces claimed by Kev #232/#233.'})
receipt={'utc':now.isoformat(),'goal':'Original full #140 ACTIVE/INCOMPLETE; production LEGACY','scope':'Scratch-only additive Stock proofs, not coherent integration or merge-ready','delivery_target':'roughly eight substantive validated squash merges/day; remote backups and cleanup; drafts do not count','modules':mods,'public_roots':batch['public_roots'],'models':batch['models'],'counts':{'modules':len(mods),'public_roots':len(batch['public_roots']),'models':len(batch['models']),'combined_roots_models':len(sets),'previous_preserved':len(old['normal_audit']['sets']),'all_new_module_constants':len(constants)},'normal_audit':{'path':'/tmp/stock-try-values-combined-axioms.log','sha256':sha('/tmp/stock-try-values-combined-axioms.log'),'sets':sets},'all_constant_audit':{'path':'/tmp/stock-try-values-all-constants.log','sha256':sha('/tmp/stock-try-values-all-constants.log'),'all_standard_only':True,'count':len(constants)},'previous52_modules_hashes_preserved':list(prior),'canonical2246_source_and_script_freeze_preserved':True,'kernel_resources':'All new modules and both audits actual exit0 / object verified at8GiB through memcap; one heavy delivery worker retained','MCP':'No new calls; bundled provenance audit deferred until coherent integration','active_exact_PR246_validation':progress,'remaining_checklist':remaining}
(docs/'stock-try-values-scratch.json').write_text(json.dumps(receipt,indent=2)+'\n')
text=f'''TryCall normal result binding — {now.isoformat()}

Nine scratch modules, {len(batch['public_roots'])} public theorem roots and three models pass kernel checks at8GiB. The {len(sets)}-root/model audit preserves all479prior exact axiom sets. All {len(constants)} constants in the new modules, including private helpers, use only standard axioms. All52previous scratch source/object/log hashes and the frozen2246canonical sources plus scripts are unchanged.

The actual selected direct/GOT/indirect RHS supplies its real intermediate reserved-return helper. Exact definition maps, injectivity, normal value writes and final whole-driver return aliases derive internally. Old source-input helper variants remain. Complete nine-argument GOT and true indirect compiler/prepare/forced-checker/physical witnesses exercise the actual helper and final alias result. Original direct/indirect callee contracts and their existing explicit-call adapters are preserved and consumed; normal callee values/worlds are established. Conditional payload write facts do not establish exceptional machine execution.

Open: identity/composition with actual emitted call instructions, argument stores and GOT prefix; source frame/DFG and available-value noninterference; exact final payload endpoints; full sret/x8 compatibility; exceptional machine interfaces coordinated with @kevaundray #232/#233. Every remaining family/effect/source/block/whole-driver simulation AND completeness and production consumer cutover remains required. Production LEGACY. Both draft PRs still require exact updated-main full gates before squash. Aim roughly eight substantive validated merges/day, remote backups and cleanup.

See stock-try-values-scratch.json for hashed evidence and full remaining checklist.
'''
(docs/'stock-try-values-scratch.md').write_text(text)
plan=root/'docs/plans/test-binary-alignment-recovery.md';plan.write_text(plan.read_text()+'\n\n'+text)
files=[]
for rec in mods.values():files.extend(Path(rec[k]) for k in ['source','object','log','check'])
for name in ['stock-try-values-combined-axioms','stock-try-values-all-constants']:
 for ext in ['.lean','.log','.olean','.check.json']:files.append(Path('/tmp')/(name+ext))
files.extend(Path(p) for p in ['/tmp/stock-try-values-batch.json','/tmp/stock-try-rule-inputs.json','/tmp/stock-try-reservation-check.py','/tmp/stock-try-values-close.py','/tmp/stock-try-values-coordination.json','/tmp/stock-latest-statuses.json','/tmp/stock-current-status44.json'])
files.extend([docs/'stock-try-values-scratch.json',docs/'stock-try-values-scratch.md',docs/'stock-delivery-main-drift.json',plan])
archive=Path('/home/lee/.clifv-recovery')/(stamp+'-try-values')/'checkpoint.tar.gz';archive.parent.mkdir(parents=True)
with tarfile.open(archive,'w:gz',compresslevel=1) as t:
 for p in files:t.add(p,arcname=str(p).lstrip('/'),recursive=False)
with tarfile.open(archive,'r:gz') as t:
 for p in files:assert t.extractfile(str(p).lstrip('/')).read()==p.read_bytes(),p
snapshot=Path('/tmp/stock-try-rule-inputs');size=sum(p.stat().st_size for p in snapshot.rglob('*') if p.is_file());shutil.rmtree(snapshot)
backup={'utc':now.isoformat(),'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(files),'all_members_byte_verified':True,'previous_remote_backup':json.loads((docs/'stock-try-outgoing-backup.json').read_text())['remote'],'cleanup':{'duplicate_dependency_snapshot_removed':True,'bytes_reclaimed':size,'unique_sources_objects_logs_checks_audits_preserved':True,'one_shared_warm_cache_retained':True,'other_projects_touched':False,'free_bytes':shutil.disk_usage(root).free}}
(docs/'stock-try-values-backup.json').write_text(json.dumps(backup,indent=2)+'\n');Path('/tmp/stock-try-values-archive-path').write_text(str(archive))
print(json.dumps({'counts':receipt['counts'],'archive':str(archive),'cleanup':backup['cleanup'],'gate':progress},indent=2))
