import StockTryExplicitCallContracts
import FV.Backend.Proof.PerEdgeSpillEntryFixture
import FV.E2E.RegLevelDriverSem
namespace Backend.Stock.Proof.TryIndirectNormalValueWitnessDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open TryRetsTotalDraft TryResultMapDraft TryNormalCallValuesDraft TryExplicitCallContractsDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
attribute [local irreducible] Stock.lower Stock.runTerm Stock.externCtor
private def function := SpillEntryFixture.function true
private def signature := function.sig
private def helperCtx (result : Result) : Ctx := {result.ctx with tryRegs := result.initial.tryRegs[2]!}
private def model : ExtSem := ⟨fun _ _ w => some ([17],w),fun _ _ => 4096,0,fun _ w => Arm.read_pstate w⟩
private def environment : Clif.Env := {
  extern := fun _ => some (fun _ cm => .returned [⟨.i64,17⟩] cm),names := ["callee"],sigOf := fun _ => some signature }
private def symbols : String → Option Nat := fun n => if n = "callee" then some 4096 else none
private def memory : Clif.Mem := {Clif.Mem.empty with symbols}
private def relation : MemRelT := fun _ cm _ => cm.symbols = symbols
private def info : TryInfo := {continuation := 1,handlers := [.tag 7 2],clobberAll := false,rets := 1}
private theorem held : PrefixHold [⟨.i64,17⟩] ([17] : List CV) := by
  refine ⟨by decide,?_⟩
  intro j v x atValue atOut
  cases j with
  | zero => cases atValue; cases atOut; rfl
  | succ j => simp at atValue
private theorem xind : XCallsIndOk environment [signature] relation model := by
  intro sig member name g sl cm w u args vals rvals cm' found declared symbol count arguments related returned length typed
  have same := List.mem_singleton.mp member
  subst sig
  simp only [environment,Option.some.injEq] at found
  subst g
  cases returned
  exact ⟨[17],w,rfl,rfl,held,related⟩
private theorem lower_build {f : Clif.Function} {result : Result} (run : Stock.lower f = .ok result) :
    ∃ ranges,Stock.buildCtx f = .ok (result.ctx,ranges,result.initial) := by
  unfold Stock.lower at run
  dsimp only at run
  repeat' first
    | (solve | cases run)
    | simp only [bind,Except.bind,pure,Except.pure] at run
    | split at run
  cases run
  exact ⟨_,by assumption⟩
/-- The complete original indirect TryCall pipeline supplies its real reserved
layout and inhabits the ORIGINAL indirect contract, actual csem normal call,
returned world/result17 and a complete original-source run. Connection to its
actual emitted/final-renamed instruction remains a separate proof obligation. -/
theorem stock_complete_indirect_try_normal_csem_values_witness :
    ∃ (out : SpillEntryFixture.Output true) (value : V) (next : State) (outs : List CV) (world : Arm.ArmState),
      LowerScope function ∧ Dominated function ∧ ArityOk function ∧ Stock.lower function = .ok out.result ∧
      prepareAt out.result.code out.result.edgeArgs = .ok out.prepared ∧ out.rf = spillAllocAt out.prepared.code out.prepared.edges ∧
      checkAllocAt out.prepared.code out.prepared.edges out.rf = .ok () ∧ lowerRFunc out.prepared.code out.rf = .ok out.af ∧
      Stock.externCtor (helperCtx out.result) T.gen_try_call_rets [.op (.sig signature)] out.result.initial = .ok (value,next) ∧
      value = .op (.callRets (callDefs (resultDefs 194 1))) ∧
      XCallsIndOk environment [signature] relation model ∧
      IndCallsRefineP (fun _ _ _ _ => True) environment [signature] relation
        (csem (fun _ => False) ⟨0,0⟩ model) ∧
      IndCallsRefineP (fun _ _ _ _ => True) environment [signature] relation
        (ExplicitCallSemDraft.explicitCallSem (csem (fun _ => False) ⟨0,0⟩ model)) ∧
      csem (fun _ => False) ⟨0,0⟩ model
        (.tryCall ⟨.reg (.vreg 193 .int),[],callDefs (resultDefs 194 1)⟩ info)
        [ofX 4096] Arm.ArmState.default = some (outs,world,.goto 1) ∧
      outs.length = 2 ∧ PrefixHold [⟨.i64,17⟩] outs ∧ world = Arm.ArmState.default ∧
      (∀ ρ : Nat → CV,VHolds ⟨.i64,17⟩ (writeV ρ ((callDefOps (resultDefs 194 1)).zip outs) 194)) ∧
      Clif.runWith environment {funcs := [function]} function.name [] memory 6 = .returned [⟨.i64,17⟩] memory := by
  obtain ⟨out⟩ := SpillEntryFixture.try_fixture true
  obtain ⟨ranges,build⟩ := lower_build out.lowered
  have observed : ((Stock.buildCtx function).toOption.map (fun q => q.2.2.tryRegs[2]!)) =
      some (reservedReturns 194 1,reservedPayloads 194 1) := rfl
  change Stock.buildCtx function = .ok (out.result.ctx,ranges,out.result.initial) at build
  rw [build] at observed
  have slots : (helperCtx out.result).tryRegs = (reservedReturns 194 1,reservedPayloads 194 1) := Option.some.inj observed
  obtain ⟨value,next,helper⟩ := stock_try_rets_reserved_total (ctx := helperCtx out.result)
    (sig := signature) out.result.initial 194 (by decide +kernel) rfl slots
  have defs := stock_try_reserved_result_defs helper 194 (by decide +kernel) rfl slots
  have contract : IndCallsRefineP (fun _ _ _ _ => True) environment [signature] relation
      (csem (fun _ => False) ⟨0,0⟩ model) := (indCallsRefine_csem (syms := symbols) xind
        (by intro n b found; by_cases same : n = "callee" <;> simp [symbols,same] at found; cases found; rfl)
        (by intro sl cm w related; exact related)).toP _
  have adapted := stock_explicit_original_indirect_calls_contract contract
  have emptyHeld : AllHold ([] : List Clif.Val) ([] : List CV) := ⟨rfl,by intro j v x atValue; simp at atValue⟩
  obtain ⟨outs,world,executed,length,relatedValues,related,values⟩ := stock_try_indirect_normal_call_values adapted
    (sig := signature) (by simp) (name := "callee") (sl := []) (cm := memory) (cm' := memory)
    (w := Arm.ArmState.default) (address := 4096) (r := .vreg 193 .int) (us := []) info (target := ofX 4096)
    (args := []) (vals := []) (rvals := [⟨.i64,17⟩]) 194 rfl
    (by intro s hs; cases Option.some.inj hs; rfl) rfl rfl (by decide +kernel) emptyHeld rfl trivial rfl rfl rfl
  have sameWorld : world = Arm.ArmState.default := by
    have actual := congrArg (Option.map (fun q => q.2.1)) executed
    simp [ExplicitCallSemDraft.explicitCallSem,csem,model,info,signature,function,SpillEntryFixture.function] at actual
    obtain ⟨a,⟨_,same⟩,_⟩ := actual
    exact same.symm
  exact ⟨out,value,next,outs,world,out.scope,out.dominated,out.arity,out.lowered,out.prepare,out.fallback,
    out.accepted,out.physical,helper,defs,xind,contract,adapted,executed,length,relatedValues,sameWorld,
    (fun ρ => values ρ 0 ⟨.i64,17⟩ rfl),rfl⟩
end Backend.Stock.Proof.TryIndirectNormalValueWitnessDraft
