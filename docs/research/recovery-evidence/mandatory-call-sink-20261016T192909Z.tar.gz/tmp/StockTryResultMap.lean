import StockTryRetsTotal
namespace Backend.Stock.Proof.TryResultMapDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open TryRetsShapeDraft TryRetsTotalDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
/-- Actual definition index: return prefix, then unshared separately allocated
payloads. With one return the second payload is base+2, not base+1. -/
def resultKey (base count j : Nat) : Nat :=
  if j < count then base+j else base+count+j
def resultDefs (base count : Nat) : List (Reg × Nat) :=
  (List.range (max count 2)).map fun j => (.x j,resultKey base count j)
/-- The actual definition map has no overlapping virtual-register writes,
including the hole for the aliased payload of a one-return TryCall. -/
theorem stock_try_result_key_injective (base count : Nat) : Function.Injective (resultKey base count) := by
  intro i j same
  simp only [resultKey] at same
  split at same <;> split at same <;> omega
/-- Actual successful helper execution under its internally derived allocation
layout identifies every fixed ABI register and every output virtual register.
The proof covers all original supported zero-through-eight explicit returns. -/
theorem stock_try_reserved_result_defs {ctx : Ctx} {sig : Clif.Signature} {st next : State} {value : V}
    (run : Stock.externCtor ctx T.gen_try_call_rets [.op (.sig sig)] st = .ok (value,next))
    (base : Nat) (bound : sig.returns.length ≤ 8) (payload : payloadRegs sig.callConv = [.x 0,.x 1])
    (slots : ctx.tryRegs = (reservedReturns base sig.returns.length,reservedPayloads base sig.returns.length)) :
    value = .op (.callRets (callDefs (resultDefs base sig.returns.length))) := by
  obtain ⟨ps,returns,shape,frame⟩ := stock_try_rets_exact_shape run
  have pins : ps = (List.range sig.returns.length).map Reg.x := by
    rw [retRegs,if_pos bound] at returns
    exact (Option.some.inj returns).symm
  rw [pins,slots,payload] at shape
  have casesCount : sig.returns.length = 0 ∨ sig.returns.length = 1 ∨ sig.returns.length = 2 ∨
      sig.returns.length = 3 ∨ sig.returns.length = 4 ∨ sig.returns.length = 5 ∨
      sig.returns.length = 6 ∨ sig.returns.length = 7 ∨ sig.returns.length = 8 := by omega
  rcases casesCount with n | n | n | n | n | n | n | n | n
  all_goals
    rw [n] at shape ⊢
    simpa [resultDefs,resultKey,reservedReturns,reservedPayloads,callDefs,payloadResult,
      List.range_succ,List.idxOf?,List.findIdx?,List.findIdx?.go] using shape
end Backend.Stock.Proof.TryResultMapDraft
