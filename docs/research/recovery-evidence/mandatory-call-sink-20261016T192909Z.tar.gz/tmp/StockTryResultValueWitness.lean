import StockTryResultWrites
import StockTryStackFixture
namespace Backend.Stock.Proof.TryResultValueWitnessDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open TryStackSourceDraft TryStackFixtureDraft TryRetsTotalDraft TryResultMapDraft TryResultWritesDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
attribute [local irreducible] Stock.lower Stock.runTerm Stock.externCtor
private theorem lower_build {f : Clif.Function} {result : Result} (run : Stock.lower f = .ok result) :
    ∃ ranges,Stock.buildCtx f = .ok (result.ctx,ranges,result.initial) := by
  unfold Stock.lower at run
  dsimp only at run
  repeat' first
    | (solve | cases run)
    | simp only [bind,Except.bind,pure,Except.pure] at run
    | split at run
  cases run
  exact ⟨_,by assumption⟩
def helperContext (result : Result) : Ctx := {result.ctx with tryRegs := result.initial.tryRegs[0]!}
/-- A real complete compiler pipeline supplies the concrete slot, helper run
and exact noncontiguous definition map for later value-write witnesses. -/
theorem stock_nine_try_result_defs_witness :
    ∃ (out : Output) (value : V) (next : State),
      Stock.lower function = .ok out.result ∧ prepareAt out.result.code out.result.edgeArgs = .ok out.prepared ∧
      checkAllocAt out.prepared.code out.prepared.edges out.rf = .ok () ∧ lowerRFunc out.prepared.code out.rf = .ok out.af ∧
      (helperContext out.result).tryRegs = (reservedReturns 201 1,reservedPayloads 201 1) ∧
      Stock.externCtor (helperContext out.result) T.gen_try_call_rets [.op (.sig signature)] out.result.initial = .ok (value,next) ∧
      value = .op (.callRets (callDefs (resultDefs 201 1))) := by
  obtain ⟨out⟩ := stock_nine_argument_try_fixture
  obtain ⟨ranges,build⟩ := lower_build out.lowered
  have observed : ((Stock.buildCtx function).toOption.map (fun q => q.2.2.tryRegs[0]!)) =
      some (reservedReturns 201 1,reservedPayloads 201 1) := rfl
  rw [build] at observed
  have slots : (helperContext out.result).tryRegs = (reservedReturns 201 1,reservedPayloads 201 1) := Option.some.inj observed
  obtain ⟨value,next,run⟩ := stock_try_rets_reserved_total (ctx := helperContext out.result)
    (sig := signature) out.result.initial 201 (by decide +kernel) rfl slots
  exact ⟨out,value,next,out.lowered,out.prepare,out.accepted,out.physical,slots,run,
    stock_try_reserved_result_defs run 201 (by decide +kernel) rfl slots⟩
private theorem normalHeld : PrefixHold [⟨.i64,17⟩] ([17,99] : List CV) := by
  refine ⟨by decide,?_⟩
  intro j v x atValue atOut
  cases j with
  | zero => cases atValue; cases atOut; rfl
  | succ j => simp at atValue
private theorem payloadHeld : PrefixHold [⟨.i64,42⟩,⟨.i64,99⟩] ([42,99] : List CV) := by
  refine ⟨by decide,?_⟩
  intro j v x atValue atOut
  rcases j with _ | (_ | j)
  all_goals simp at atValue atOut
  all_goals cases atValue; cases atOut; rfl
/-- A COMPLETE original-condition nine-argument compiler pipeline exercises
normal17 and conditional payload42/99 writes through its ACTUAL helper defs.
The shared payload targets201; the separate payload targets203. Arbitrary
outside registers are framed. This is not an exception machine-call theorem. -/
theorem stock_complete_try_result_write_witness :
    ∃ (out : Output) (value : V) (next : State),
      LowerScope function ∧ Dominated function ∧ ArityOk function ∧ Stock.lower function = .ok out.result ∧
      prepareAt out.result.code out.result.edgeArgs = .ok out.prepared ∧ out.rf = spillAllocAt out.prepared.code out.prepared.edges ∧
      checkAllocAt out.prepared.code out.prepared.edges out.rf = .ok () ∧ lowerRFunc out.prepared.code out.rf = .ok out.af ∧
      Stock.externCtor (helperContext out.result) T.gen_try_call_rets [.op (.sig signature)] out.result.initial = .ok (value,next) ∧
      value = .op (.callRets (callDefs (resultDefs 201 1))) ∧
      ((callDefOps (resultDefs 201 1)).map Operand.vreg).Nodup ∧
      ∀ ρ : Nat → CV,
        VHolds ⟨.i64,17⟩ (writeV ρ ((callDefOps (resultDefs 201 1)).zip [17,99]) 201) ∧
        VHolds ⟨.i64,42⟩ (writeV ρ ((callDefOps (resultDefs 201 1)).zip [42,99]) 201) ∧
        VHolds ⟨.i64,99⟩ (writeV ρ ((callDefOps (resultDefs 201 1)).zip [42,99]) 203) ∧
        ∀ d,d ≠ 201 → d ≠ 203 → writeV ρ ((callDefOps (resultDefs 201 1)).zip [42,99]) d = ρ d := by
  obtain ⟨out,value,next,lowered,prepare,accepted,physical,slots,run,defs⟩ := stock_nine_try_result_defs_witness
  refine ⟨out,value,next,out.scope,out.dominated,out.arity,out.lowered,out.prepare,out.fallback,out.accepted,out.physical,
    run,defs,stock_try_result_defs_nodup 201 1,?_⟩
  intro ρ
  have normal := stock_try_write_normal_values 201 1 ρ normalHeld rfl rfl (j := 0) rfl
  have first := stock_try_write_payload_values 201 1 ρ payloadHeld rfl (j := 0) rfl
  have second := stock_try_write_payload_values 201 1 ρ payloadHeld rfl (j := 1) rfl
  refine ⟨normal,first,second,?_⟩
  intro d first second
  apply stock_try_write_frame
  intro j bound
  have casesIndex : j = 0 ∨ j = 1 := by omega
  rcases casesIndex with rfl | rfl
  · exact first
  · exact second
end Backend.Stock.Proof.TryResultValueWitnessDraft
