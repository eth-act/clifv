from pathlib import Path
import subprocess as sp,os,signal,time,json,datetime,hashlib
root=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');sched=1763255
out=Path('/tmp/stock-source-sink-priority');out.mkdir(exist_ok=True)
module='FV.Backend.Proof.StockSourceSinkTable'; source=root/(module.replace('.','/')+'.lean')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();head=sp.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert head=='213fe68bfbda3ed5d237cb7df6651f47e5a189bc';frozen=sha(source)
assert b'stock-execute-scheduler.py' in Path(f'/proc/{sched}/cmdline').read_bytes()
env=dict(os.environ,PATH='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:'+os.environ['PATH'],FV_MEMCAP='16G',FV_LAKE_CACHE='/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache',LEAN_NUM_THREADS='2',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2')
def report(state,**kw):
 j={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':state,'pid':os.getpid(),'head':head,'module':module,'source_sha256':frozen,'scheduler':sched,**kw};(out/'progress.json').write_text(json.dumps(j,indent=2)+'\n');print(json.dumps(j),flush=True)
stopped=False
try:
 os.kill(sched,signal.SIGSTOP);stopped=True
 report('waiting_for_existing_primary_kernels_no_interrupt')
 while True:
  assert b'stock-execute-scheduler.py' in Path(f'/proc/{sched}/cmdline').read_bytes()
  kids=Path(f'/proc/{sched}/task/{sched}/children').read_text().split()
  live=[k for k in kids if Path(f'/proc/{k}/stat').exists() and Path(f'/proc/{k}/stat').read_text().split()[2]!='Z']
  if not live:break
  time.sleep(1)
 assert sp.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head and sha(source)==frozen
 report('building_solo_16GiB')
 with (out/'build.log').open('w') as f:r=sp.run([str(root/'scripts/memcap.sh'),'lake','build',module],cwd=root,env=env,stdout=f,stderr=sp.STDOUT)
 assert r.returncode==0,('source_sink_normal_build_failed',r.returncode)
 assert sha(source)==frozen
 report('normal_build_passed',log=str(out/'build.log'),log_sha256=sha(out/'build.log'),scheduler_will_validate_current_keys=True)
finally:
 if stopped:os.kill(sched,signal.SIGCONT)
 print('primary scheduler resumed',flush=True)
