from pathlib import Path
import subprocess as sp,time,os,signal,json,datetime
sched=1763255
expected=b"stock-execute-scheduler.py"
watched={3773480,3773481}
print(json.dumps({"state":"waiting_for_exact_primary_handles","pid":os.getpid(),"watched":sorted(watched)}),flush=True)
while True:
 p=Path(f"/proc/{sched}/cmdline")
 if not p.exists() or expected not in p.read_bytes():
  print(json.dumps({"state":"primary_scheduler_terminal_revalidate_before_build"}),flush=True);raise SystemExit(0)
 kids=Path(f"/proc/{sched}/task/{sched}/children").read_text().split()
 live=[k for k in kids if Path(f"/proc/{k}/stat").exists() and Path(f"/proc/{k}/stat").read_text().split()[2]!="Z"]
 if len(live)<=1:
  os.kill(sched,signal.SIGSTOP)
  try:
   print(json.dumps({"state":"slot_observed_running_bounded_batch41","remaining_handles":live}),flush=True)
   r=sp.run(["python3","/tmp/stock-mixed-normal-modules-batch41.py"])
  finally:os.kill(sched,signal.SIGCONT)
  raise SystemExit(r.returncode)
 time.sleep(.5)
