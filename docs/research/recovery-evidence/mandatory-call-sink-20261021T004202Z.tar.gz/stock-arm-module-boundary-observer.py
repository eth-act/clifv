from pathlib import Path
import time,json,re,datetime,subprocess as sp,hashlib,os
root=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');out=Path('/tmp/stock-arm-module-boundary-observer');out.mkdir(exist_ok=True);sched=1763255;parent=1762992
print(json.dumps({'state':'observing_same_live_scheduler','pid':os.getpid(),'scheduler':sched,'held_author':parent}),flush=True)
while True:
 p=Path(f'/proc/{sched}/stat')
 if not p.exists():break
 fields=p.read_text().split()
 if fields[2]=='Z':break
 time.sleep(1)
log=Path('/tmp/stock-arithmetic-current-main-author-gates/all-modules/sched.log');text=log.read_text();ends=re.findall(r'END (\d+)/(\d+) ok, (\d+) built, wall ([\d.]+) min',text)
assert Path(f'/proc/{parent}/stat').read_text().split()[2]=='T','author hold changed; revalidate actual phase before handoff'
head=sp.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert head=='213fe68bfbda3ed5d237cb7df6651f47e5a189bc'
frozen=json.loads(Path('/tmp/stock-arithmetic-current-main-author-gates/inputs.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert all(sha(root/p)==h for p,h in frozen['sources'].items())
passed=bool(ends and ends[-1][0]==ends[-1][1]);j={'state':'old_module_epoch_passed_ready_for_verified_handoff' if passed else 'old_module_epoch_terminal_inspect_result','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'held_author':parent,'scheduler':sched,'end':ends[-1] if ends else None,'log':str(log),'log_sha256':sha(log),'all_frozen_sources_verified':len(frozen['sources']),'no_old_full_gate_pass_claim':True,'next':'Verify no active owned proof kernels, archive old epoch and stop only held obsolete author parent, preserve213 branch/cache; switch clean delivery tree to672c4dc4 and start current-Arm source-key/affected module gates with valid reusable closure. Reconcile any newer main first; do not waive current per-PR gates.'};(out/'receipt.json').write_text(json.dumps(j,indent=2)+'\n');print(json.dumps(j),flush=True)
