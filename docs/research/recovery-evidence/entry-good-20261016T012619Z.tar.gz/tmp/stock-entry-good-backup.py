from pathlib import Path
import subprocess as sp,os,datetime,json,hashlib,stat
root=Path('/home/lee/clifv/.worktrees/driver-proof-resume')
def out(*args,env=None,input=None):return sp.check_output(args,cwd=root,env=env,input=input)
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
branch='agent/stock-driver-wip-backup-'+stamp
head=out('git','rev-parse','HEAD').decode().strip()
idx=Path('/tmp/stock-backup-index-'+stamp);env=dict(os.environ,GIT_INDEX_FILE=str(idx))
original_index=out('git','diff','--cached','--binary')
paths=sorted(set(out('git','ls-files','-m','-d','-o','--exclude-standard','-z').decode().strip('\0').split('\0'))-{''})
captured={};entries=[]
for name in paths:
 p=root/name
 if not p.exists():
  entries.append('0 '+('0'*40)+'\t'+name+'\n');captured[name]=None;continue
 data=p.read_bytes();blob=out('git','hash-object','-w','--stdin',input=data).decode().strip()
 mode='100755' if p.stat().st_mode & stat.S_IXUSR else '100644'
 entries.append(mode+' '+blob+'\t'+name+'\n');captured[name]={'blob':blob,'sha256':hashlib.sha256(data).hexdigest()}
evidence=os.environ.get('STOCK_RECOVERY_EVIDENCE')
if evidence:
 p=Path(evidence);data=p.read_bytes();name='docs/research/recovery-evidence/entry-good-'+stamp+'.tar.gz'
 blob=out('git','hash-object','-w','--stdin',input=data).decode().strip()
 entries.append('100644 '+blob+'\t'+name+'\n');captured[name]={'blob':blob,'sha256':hashlib.sha256(data).hexdigest(),'archived_evidence':True}
out('git','read-tree',head,env=env)
out('git','update-index','--index-info',env=env,input=''.join(entries).encode())
tree=out('git','write-tree',env=env).decode().strip()
commit=out('git','commit-tree',tree,'-p',head,input=('Recovery snapshot '+stamp+'; preserves dirty source, documentation and verification evidence; not merge-ready.\n').encode()).decode().strip()
out('git','update-ref','refs/heads/'+branch,commit)
sp.run(['git','push','origin',branch],cwd=root,check=True)
remote=out('git','ls-remote','origin','refs/heads/'+branch).decode().split()[0];assert remote==commit
actual={}
for entry in out('git','ls-tree','-r',commit).decode().splitlines():
 meta,name=entry.split('\t',1);actual[name]=meta.split()[2]
for name,value in captured.items():
 assert actual.get(name)==(value['blob'] if value else None),name
assert out('git','rev-parse','HEAD').decode().strip()==head
assert out('git','diff','--cached','--binary')==original_index
result={'utc':stamp,'branch':branch,'commit':commit,'parent':head,'captured_dirty_paths':len(paths),'additional_evidence_paths':len(captured)-len(paths),'remote_commit_and_all_captured_blobs_verified':True,'index_and_active_head_unchanged':True,'captured':captured}
Path('/tmp/stock-backup-captured-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='captured'}))
