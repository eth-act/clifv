from pathlib import Path
import subprocess as sp, os, json, time, datetime, hashlib, traceback, re

view = Path('/home/lee/clifv/.worktrees/stock-driver-incremental')
root = Path('/tmp/stock-scalar-landing')
root.mkdir(exist_ok=True)
expected_head = 'c6f3a0805aeb67457c7942f8d56fb754567b3cd0'
expected_main = '5a143135fca1b3565085f7cf403dc475c85cfc24'
records = {}

def report(state, **kw):
    data = dict(state=state, utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                pid=os.getpid(), records=records, **kw)
    (root/'progress.json').write_text(json.dumps(data, indent=2)+'\n')
    print(json.dumps({k:v for k,v in data.items() if k != 'records'}), flush=True)

def run(*args):
    return sp.check_output(args, cwd=view, text=True, stderr=sp.STDOUT).strip()

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

try:
    report('waiting_for_exact_gates', author_pid=3977219, supplementary_pid=4174891)
    while True:
        author = json.loads(Path('/tmp/stock-scalar-author-gates/progress.json').read_text())
        extra = json.loads(Path('/tmp/stock-scalar-supplementary/progress.json').read_text())
        assert author['pid'] == 3977219 and extra['pid'] == 4174891
        assert author['state'] != 'failed', author.get('error')
        assert extra['state'] != 'failed', extra.get('error')
        if author['state'] == 'per_pr_gates_passed' and extra['state'] == 'passed':
            break
        if author['state'] != 'per_pr_gates_passed':
            assert Path('/proc/3977219').exists(), 'author missing without terminal receipt'
        if extra['state'] != 'passed':
            assert Path('/proc/4174891').exists(), 'supplementary missing without terminal receipt'
        time.sleep(2)

    report('verifying_frozen_evidence')
    assert author['head'] == expected_head
    assert run('git','rev-parse','HEAD') == expected_head
    assert not run('git','diff','--name-only') and not run('git','diff','--cached','--name-only')
    frozen = json.loads(Path('/tmp/stock-scalar-author-gates/inputs.json').read_text())
    actual = {str(p.relative_to(view)):sha(p)
              for d in ['FV','FVTest','examples/fv-demo/src','scripts/audit']
              for p in (view/d).rglob('*') if p.is_file() and p.suffix in ['.lean','.rs']}
    assert actual == frozen['sources'], 'source drift after gates'
    for item in author['logs'].values():
        assert sha(item['path']) == item['sha256'], item['path']
    parity = json.loads(Path('/tmp/stock-scalar-author-gates/identity-stage-parity.json').read_text())
    assert all(d['original'] == 1150 and d['prior_shipped'] == 1159 and
               d['all_original_and_prior_identities_and_ordered_stages_preserved'] for d in parity.values())
    owned = json.loads(Path('/tmp/stock-scalar-owned-current/state.json').read_text())
    assert owned['state'] == 'passed' and len(owned['records']) == 9
    assert all(d['rc'] == 0 for d in owned['records'])
    records['author'] = author
    records['supplementary'] = extra
    records['identity_stage_parity'] = parity
    records['owned'] = owned
    records['owned_audit_output'] = {p.name:p.read_text() for p in Path('/tmp/stock-scalar-owned-current').glob('*.log')}
    run('git','fetch','origin','main')
    assert run('git','rev-parse','origin/main') == expected_main, 'main changed: reconcile before landing'

    report('recording_terminal_receipt')
    receipt = view/'docs/research/stock-scalar-add-production-author-gates.json'
    receipt.write_text(json.dumps(dict(validated_head=expected_head, base=expected_main,
        utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), records=records,
        full_original_140_complete=False), indent=2)+'\n')
    proof = view/'docs/research/stock-scalar-add-core.json'
    data = json.loads(proof.read_text())
    data.update(state='author_gates_passed_pending_author_squash', full_author_gates_run=True,
        validated_head=expected_head, author_receipt=str(receipt.relative_to(view)),
        expanded_owned_partitions=9, settings_matched_regalloc2_passed=True,
        next='Author squash; notify integrator; continue all original #140 obligations.')
    proof.write_text(json.dumps(data,indent=2)+'\n')
    notes = view/'docs/research/stock-scalar-add-core.md'
    notes.write_text(notes.read_text()+'\nFrozen author gates and supplementary owned/native-witness and settings-matched\nregalloc2 checks passed on `'+expected_head+'`. Terminal results, exact log hashes\nand both-mode original/prior identity-stage parity are preserved in\n[the author receipt](stock-scalar-add-production-author-gates.json). The author\nsquash follows immediately after current-main reconciliation; full #140 remains open.\n')
    run('git','add',str(receipt.relative_to(view)),str(proof.relative_to(view)),str(notes.relative_to(view)))
    run('git','diff','--cached','--check')
    run('git','commit','-m','Record scalar-add production terminal author gates')
    tested_tree = run('git','rev-parse','HEAD^{tree}')
    head = run('git','rev-parse','HEAD')
    run('git','push','origin','agent/stock-scalar-production')
    records['receipt_commit'] = head
    report('published_receipt', receipt_commit=head)

    body = Path('/tmp/stock-scalar-production-pr.md').read_text()
    body = body.replace('Validation (replace with terminal frozen author receipt before publishing):','Validation on `'+expected_head+'` (receipt-only follow-up `'+head+'`):')
    body = body.replace('- Frozen current author gate: PENDING. Preserve all 1,150 original and 1,159 previously shipped identities and ordered stages in both modes. Include expanded owned scans and matched regalloc2 comparison.',
        '- Frozen author gates PASS: all FV/FVTest modules and affected tools; all checked-in axiom audits; runtime and encoder; both E2E modes with all 1,150 original and 1,159 prior shipped identities/ordered stages preserved; matched links, old/new generated proofs and real CLIs; verified default Lean-linked fv-demo and survey. Supplementary all-owned scans (nine partitions, including fixed-native witnesses and fixtures) and settings-matched regalloc2 checks PASS. Exact terminal receipts and log hashes are checked in.')
    (root/'pr-body.md').write_text(body)
    assert run('git','ls-remote','origin','refs/heads/main').split()[0] == expected_main
    url = run('gh','pr','create','--repo','eth-act/clifv','--base','main','--head',
        'agent/stock-scalar-production','--title','Enable proved scalar-add Stock production across six configurations',
        '--body-file',str(root/'pr-body.md'))
    urls = re.findall(r'https://github.com/eth-act/clifv/pull/\d+', url)
    assert len(urls) == 1, url
    url = urls[0]
    records['pr_url'] = url
    report('merging', pr=url)
    run('gh','pr','merge',url,'--repo','eth-act/clifv','--squash','--match-head-commit',head)
    pr = json.loads(run('gh','pr','view',url,'--repo','eth-act/clifv','--json','number,state,mergeCommit,url'))
    assert pr['state'] == 'MERGED', pr
    records['merged_pr'] = pr
    commit = pr['mergeCommit']['oid']
    run('git','fetch','origin','main')
    assert run('git','rev-parse',commit+'^{tree}') == tested_tree, 'merge tree differs from validated source plus receipt'
    report('merged', pr=url, merge_commit=commit)
    comment = root/'integrator-comment.md'
    comment.write_text('@kevaundray Author squash landed #'+str(pr['number'])+' as **'+commit+'**. Exact merge tree equals validated '+expected_head+' plus receipt '+head+'. Please start the immediate continuous main gate for this production activation.\n\nActual Stock scalar-add functions across all six i32/i64/default/SystemV/fast configurations now flow through compiler/checker/linker/generated-proof consumers. Complete arbitrary-pair/dirty-upper-bit executable and real-record/body witnesses; earlier D0/prologue classes and transactional legacy retry preserved. All frozen author gates and supplementary full-owned/native-witness scans and settings-matched regalloc2 checks pass; exact receipts are checked in. Both cleanup modes retain every original1,150/prior1,159 identity and ordered stages. Full original#140 remains active, including broader rule/effect/source/block/whole-driver simulation, Stock-only completeness, optimizer/unwind consumers and eventual fallback retirement.\n')
    for issue in ['261','140']:
        run('gh','issue','comment',issue,'--repo','eth-act/clifv','--body-file',str(comment))
    status = json.loads(run('gh','issue','view','44','--repo','eth-act/clifv','--json','body'))['body']
    status += '\n\n'+comment.read_text()+'\nCurrent branch agent/stock-scalar-production /'+head+' published; actual squash '+commit+'. State active. Next terminal evidence backup/resource cleanup, then broader straight-line and actual-body/full-driver proof coverage; no hold on unrelated work. UTC '+datetime.datetime.now(datetime.timezone.utc).isoformat()+'\n'
    (root/'status.md').write_text(status)
    run('gh','issue','edit','44','--repo','eth-act/clifv','--body-file',str(root/'status.md'))
    report('landed_and_integrator_notified', pr=url, merge_commit=commit,
           next='Back up terminal evidence, bounded cleanup, then continue full original #140.')
except BaseException as error:
    report('failed', error=repr(error), output=getattr(error,'output',None), traceback=traceback.format_exc())
    raise
