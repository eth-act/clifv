from pathlib import Path
import subprocess as sp,os,json,time,datetime,hashlib
view=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');root=Path('/tmp/stock-scalar-supplementary');root.mkdir(exist_ok=True)
env=dict(os.environ,FV_MEMCAP='8G',FV_LAKE_CACHE='/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',LEAN_REGALLOC=str(view/'rust/target/release/lean-regalloc'));env['PATH']='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:'+env['PATH']
records={}
def report(state,**kw):
 d={'state':state,'pid':os.getpid(),'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'records':records,**kw};(root/'progress.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items() if k!='records'}),flush=True)
report('waiting_for_exact_author_gate',author_pid=3977219)
try:
 while True:
  d=json.loads(Path('/tmp/stock-scalar-author-gates/progress.json').read_text())
  assert d['pid']==3977219,'author controller changed'
  if d['state']=='per_pr_gates_passed':break
  if d['state']=='failed':raise RuntimeError('author gate failed')
  assert Path('/proc/3977219').exists(),'author controller missing without terminal evidence'
  time.sleep(2)
 for name,args in [('all-owned-constants',['python3','/tmp/stock-scalar-owned-only.py']),('settings-matched-regalloc2',['lake','env','lean','--root=/tmp','--run','/tmp/StockScalarRegalloc2Comparison.lean'])]:
  report('running',phase=name)
  log=root/(name+'.log')
  with log.open('w') as f:r=sp.run(['scripts/memcap.sh',*args],cwd=view,env=env,stdout=f,stderr=sp.STDOUT)
  records[name]={'rc':r.returncode,'sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
  assert r.returncode==0,(name,r.returncode)
 report('passed')
except BaseException as e:report('failed',error=repr(e));raise
