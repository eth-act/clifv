from pathlib import Path
import json,hashlib,subprocess,runpy
view=Path('/home/lee/clifv/.worktrees/stock-driver-incremental')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
try:
 d=json.loads(Path('/tmp/stock-scalar-owned-reuse.json').read_text())
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=view,text=True).strip()==d['head']
 actual={str(p.relative_to(view)):sha(p) for directory in ['FV','FVTest','examples/fv-demo/src','scripts/audit'] for p in (view/directory).rglob('*') if p.is_file() and p.suffix in ['.lean','.rs']}
 assert actual==d['sources']
 assert all(sha(p)==h for p,h in d['partitions'].items())
 assert all(sha(p)==h for p,h in d['logs'].items())
 state=json.loads(Path('/tmp/stock-scalar-owned-current/state.json').read_text())
 assert state['state']=='passed' and len(state['records'])==9 and all(r['rc']==0 for r in state['records'])
 print('REUSED_EXACT_PASSED_OWNED_AUDITS: nine partitions; frozen source, head, partition code and all output hashes unchanged; 271 standard-owned and136 fixed-witness constants')
except (AssertionError,FileNotFoundError):
 runpy.run_path('/tmp/stock-scalar-owned-real.py',run_name='__main__')
