import FV.E2E.ActualBinary
import FV.Backend.Lowering.StockPrologue
import FV.Backend.Lowering.StockProduction
import FV.Backend.Proof.StockPrologueSource
import FV.Backend.Proof.StockPrologueInput
import FV.Backend.Proof.StockPrologueDomain
import FV.Backend.Proof.StockPrologueCodeCore
import FV.Backend.Proof.StockDiagnosticChecker
import FV.Backend.Proof.StockPrologueCode
import FV.Backend.Proof.StockPrologueClass
import FV.Backend.Proof.StockPrologueSelect
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let targets : Array String := #["FV.E2E.ActualBinary", "FV.Backend.Lowering.StockPrologue", "FV.Backend.Lowering.StockProduction", "FV.Backend.Proof.StockPrologueSource", "FV.Backend.Proof.StockPrologueInput", "FV.Backend.Proof.StockPrologueDomain", "FV.Backend.Proof.StockPrologueCodeCore", "FV.Backend.Proof.StockDiagnosticChecker", "FV.Backend.Proof.StockPrologueCode", "FV.Backend.Proof.StockPrologueClass", "FV.Backend.Proof.StockPrologueSelect"]
  let mut count : Nat := 0
  for (name, _) in env.constants.toList do
    let some i := env.getModuleIdxFor? name | continue
    unless targets.contains env.header.moduleNames[i]!.toString do continue
    let axioms ← collectAxioms name
    for ax in axioms do
      unless #[``propext, ``Classical.choice, ``Quot.sound].contains ax do
        throwError "disallowed axiom {ax} in {name}"
    count := count + 1
  unless count > 0 do throwError "empty consumer constant audit"
  logInfo m!"CONSUMER_CONSTANTS_STANDARD_ONLY {count}"
