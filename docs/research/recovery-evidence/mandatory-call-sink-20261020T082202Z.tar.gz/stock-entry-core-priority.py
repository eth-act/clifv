import pathlib,subprocess,os,signal,time,json,datetime
pid=1431458
assert 'stock-execute-scheduler.py' in pathlib.Path(f'/proc/{pid}/cmdline').read_bytes().decode()
children=[int(x) for x in pathlib.Path(f'/proc/{pid}/task/{pid}/children').read_text().split()]
os.kill(pid,signal.SIGSTOP)
def progress(state,**kw):
 d=dict(state=state,pid=os.getpid(),scheduler=pid,children=children,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),**kw);pathlib.Path('/tmp/stock-entry-core-priority.json').write_text(json.dumps(d,indent=2));print(json.dumps(d),flush=True)
def alive(p):
 try:return pathlib.Path(f'/proc/{p}/stat').read_text().split(') ',1)[1].split()[0]!='Z'
 except FileNotFoundError:return False
try:
 progress('waiting_for_existing_owned_jobs')
 while any(alive(p) for p in children):time.sleep(1)
 env=dict(os.environ,FV_MEMCAP='8G',FV_LAKE_CACHE='/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache',LEAN_NUM_THREADS='2',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2');env['PATH']='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:'+env['PATH']
 for target,log in [('FV.Backend.Proof.StockEntryPrelude','/tmp/stock-entry-prelude-complete-build.log'),('FV.Backend.Proof.StockArithmeticEntryRefines','/tmp/stock-arithmetic-entry-targeted-build.log'),('FV.Backend.Proof.StockArithmeticEntryWitness','/tmp/stock-arithmetic-entry-witness-build.log'),('FV.Backend.Proof.StockEntryLoadsWitness','/tmp/stock-entry-abi-stack-witness-build.log'),('FV.Backend.Proof.StockEntrySeedWitness','/tmp/stock-entry-abi-register-witness-build.log')]:
  progress('building',target=target,log=log)
  with open(log,'w') as f:r=subprocess.run(['scripts/memcap.sh','lake','build',target],env=env,stdout=f,stderr=subprocess.STDOUT)
  if r.returncode:progress('failed',target=target,exit_code=r.returncode,log=log);break
 else:progress('targeted_packet_passed')
finally:
 os.kill(pid,signal.SIGCONT)
 print('resumed existing scheduler',flush=True)
