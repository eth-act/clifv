from pathlib import Path
import subprocess as sp,json,hashlib,datetime,re
view=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');root=Path('/tmp/stock-entry-abi-landing');root.mkdir(exist_ok=True)
head='5199a6a930d840f8e7c934bd537f16b4de736df3';base='5c9917ce46c7fea62ed31515319210121ef3f0b0';branch='agent/stock-entry-abi-simulation'
def run(*args):return sp.check_output(args,cwd=view,text=True,stderr=sp.STDOUT).strip()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
gates=Path('/tmp/stock-entry-abi-author-gates');d=json.loads((gates/'progress.json').read_text())
assert d['state']=='per_pr_gates_passed' and d['head']==head and d['base']==base
assert run('git','rev-parse','HEAD')==head and not run('git','diff','--name-only') and not run('git','diff','--cached','--name-only')
frozen=json.loads((gates/'inputs.json').read_text());actual={str(p.relative_to(view)):sha(p) for folder in ['FV','FVTest','scripts/audit'] for p in (view/folder).rglob('*.lean')};assert frozen==actual
for f in d['logs'].values():assert sha(f['path'])==f['sha256']
assert d['axiom_parity']['all_previous_axiom_sets_preserved']
assert 'ENTRY_CORE_STANDARD_ONLY 150; FIXED_WITNESS_CONSTANTS 68' in (gates/'all-new-owned.log').read_text()
run('git','fetch','origin','main');assert run('git','rev-parse','origin/main')==base,'main changed: reconcile before landing'
affected=len(d['reuse_manifest']['affected_modules_to_schedule']);parity=d['axiom_parity'];jobs=re.findall(r'Build completed successfully \((\d+) jobs\)',(gates/'full-library-replay.log').read_text())[-1]
receipt=view/'docs/research/stock-entry-abi-author-gates.json';assert not receipt.exists();receipt.write_text(json.dumps(d,indent=2)+'\n')
cp=view/'docs/research/stock-entry-abi-checkpoint.json';c=json.loads(cp.read_text());c['state']='complete targeted witnesses, all-owned trust and full current author gates passed';c['author_gates_receipt']='docs/research/stock-entry-abi-author-gates.json';cp.write_text(json.dumps(c,indent=2)+'\n')
p=view/'docs/plans/stock-driver-incremental-delivery.md';p.write_text(p.read_text()+f'\nActual entry-to-return author gates passed on `{head}`: {affected} affected modules scheduled after exact source/import-closure reuse checks, complete FV/FVTest replay ({jobs} jobs), all 33 audit files, 150 standard-only core constants and 68 fixed-witness constants with no new native axioms. All {parity["previous_roots"]} prior public axiom sets are retained exactly ({parity["current_roots"]} current roots), and all 15 prior public theorem headers in changed modules are unchanged. No runtime consumer or executable is affected. [Terminal author receipt](../research/stock-entry-abi-author-gates.json). Next actual preparation/allocation and direct semantic production consumers; all original #140 obligations remain active.\n')
run('git','add','docs/research/stock-entry-abi-author-gates.json','docs/research/stock-entry-abi-checkpoint.json','docs/plans/stock-driver-incremental-delivery.md');run('git','diff','--cached','--check');run('git','commit','-m','Record Stock instruction-zero execution author gates')
final=run('git','rev-parse','HEAD');tree=run('git','rev-parse','HEAD^{tree}');run('git','push','origin',branch)
body=root/'pr-body.md';body.write_text(f'''Stock arithmetic-body simulation previously began after ABI argument materialization. Prove the actual emitted entry prelude and compose it with original source execution, body simulation and the ABI return, starting at block 0, instruction 0. Typed rows, distinct virtual destinations, omitted argument values, final aliases and segment placement follow internally from original entry and successful Stock construction. All existing public theorem variants retain their statements.

Complete witnesses cover arbitrary argument values in a real nonempty arithmetic function, an unused register parameter, and a real ninth stack-passed argument on arbitrary machine worlds. Production selection remains at the existing #336 classes; next connect the complete VCode simulation through preparation/allocation and direct semantic compiler/checker/linker/generated-proof consumers. All original #140 obligations remain active.

Validation on `{head}` plus receipt-only `{final}`:

- Strict unchanged-source/import-closure reuse and {affected} affected modules; complete FV/FVTest replay passes ({jobs} jobs). No affected executable or runtime/consumer input.
- All 33 axiom audits pass. Exact parity for all {parity['previous_roots']} prior root axiom sets ({parity['current_roots']} current roots); 15 prior public theorem headers unchanged.
- All 150 core-owned constants use standard axioms. The 68 fixed-witness constants introduce no new native axioms. All 15 new public roots and complete normal-build witnesses pass.

Receipt: `docs/research/stock-entry-abi-author-gates.json`.
''')
assert run('git','ls-remote','origin','refs/heads/main').split()[0]==base
out=run('gh','pr','create','--repo','eth-act/clifv','--base','main','--head',branch,'--title','Prove Stock arithmetic execution from ABI entry through return','--body-file',str(body));urls=re.findall(r'https://github.com/eth-act/clifv/pull/\d+',out);assert len(urls)==1,out
url=urls[0];(root/'progress.json').write_text(json.dumps({'state':'merging','pr':url,'head':final})+'\n');assert run('git','ls-remote','origin','refs/heads/main').split()[0]==base
run('gh','pr','merge',url,'--repo','eth-act/clifv','--squash','--match-head-commit',final)
pr=json.loads(run('gh','pr','view',url,'--repo','eth-act/clifv','--json','number,state,mergeCommit,url'));assert pr['state']=='MERGED';commit=pr['mergeCommit']['oid'];(root/'progress.json').write_text(json.dumps({'state':'merged_verifying','pr':pr,'head':final})+'\n')
run('git','fetch','origin','main');assert run('git','rev-parse',commit+'^{tree}')==tree
comment=root/'integrator.md';comment.write_text(f'@kevaundray Author squash landed #{pr["number"]} as **{commit}**. Exact tree equals validated {head} plus receipt {final}. Please include this actual commit in the immediate continuous main gate.\n\nComplete original-source arithmetic execution from actual Stock block0/PC0 through ABI prelude/body/return; internal typed-row/value/width/uniqueness/final-alias/placement derivation, arbitrary-value nonempty-body and real register/stack/unused-parameter witnesses. Per-PR {affected} affected modules, full FV/FVTest {jobs} jobs, all33audits, exact {parity["previous_roots"]} prior axiom sets/{parity["current_roots"]} current roots,150standardcore/68fixedwitnessconstants/no newnativeaxioms;15oldpublictheoremheaders unchanged. No runtime/consumer input changed. Next actual preparation/allocation and direct semantic compiler/checker/linker/generated-proof integration, retaining old contracts/checkAlloc universal initialization. Production classes remain #336; full original#140 active.\n')
for issue in ['261','140']:run('gh','issue','comment',issue,'--repo','eth-act/clifv','--body-file',str(comment))
status=json.loads(run('gh','issue','view','44','--repo','eth-act/clifv','--json','body'))['body'];status+='\n\n'+comment.read_text()+f'\nCurrent published branch {branch}/{final}; active. Next terminal evidence backup/cleanup, actual allocation/direct semantic production integration. UTC '+datetime.datetime.now(datetime.timezone.utc).isoformat()+'\n';(root/'status.md').write_text(status);run('gh','issue','edit','44','--repo','eth-act/clifv','--body-file',str(root/'status.md'))
done={'state':'landed_and_integrator_notified','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pr':pr,'source':head,'receipt':final,'merge_commit':commit,'merge_tree_matches_validated_source_plus_receipt':True};(root/'progress.json').write_text(json.dumps(done,indent=2)+'\n');print(json.dumps(done))
