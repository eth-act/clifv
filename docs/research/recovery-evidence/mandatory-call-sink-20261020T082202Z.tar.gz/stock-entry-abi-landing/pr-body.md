Stock arithmetic-body simulation previously began after ABI argument materialization. Prove the actual emitted entry prelude and compose it with original source execution, body simulation and the ABI return, starting at block 0, instruction 0. Typed rows, distinct virtual destinations, omitted argument values, final aliases and segment placement follow internally from original entry and successful Stock construction. All existing public theorem variants retain their statements.

Complete witnesses cover arbitrary argument values in a real nonempty arithmetic function, an unused register parameter, and a real ninth stack-passed argument on arbitrary machine worlds. Production selection remains at the existing #336 classes; next connect the complete VCode simulation through preparation/allocation and direct semantic compiler/checker/linker/generated-proof consumers. All original #140 obligations remain active.

Validation on `5199a6a930d840f8e7c934bd537f16b4de736df3` plus receipt-only `df971732ab21e0a9e5006c1a192b4e885d72ecf8`:

- Strict unchanged-source/import-closure reuse and 63 affected modules; complete FV/FVTest replay passes (2459 jobs). No affected executable or runtime/consumer input.
- All 33 axiom audits pass. Exact parity for all 1129 prior root axiom sets (1144 current roots); 15 prior public theorem headers unchanged.
- All 150 core-owned constants use standard axioms. The 68 fixed-witness constants introduce no new native axioms. All 15 new public roots and complete normal-build witnesses pass.

Receipt: `docs/research/stock-entry-abi-author-gates.json`.
