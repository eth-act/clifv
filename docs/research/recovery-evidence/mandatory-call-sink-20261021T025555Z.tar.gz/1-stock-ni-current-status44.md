# Current work: Stock driver production delivery (#140)

Updated UTC: 2026-10-21T01:27:13.993440+00:00. **Active; full original #140 remains unfinished.**

## Actual production and current candidates

Main08020ed34bea4a3656c1b080c55087da40f2ebbe ships D0 parameter-return, all-six prologue and scalar-add classes (#328–#336) with legacy fallback. General arithmetic and Mixed select/add/sub are not activated. No author PR is open yet; source/evidence is pushed independently of readiness.

**Arithmetic now validates the current Arm model**, not the obsolete source: branch `agent/stock-arithmetic-arm-model-20261021T001904Z`, commit `672c4dc4820b31c477a5e075926c72cd2b267dd8`, worktree `.worktrees/stock-driver-incremental`. Controller1235132 / scheduler1235140, phase all-modules; live evidence `/tmp/stock-arithmetic-arm-model-author-gates/progress.json`. All current FV/FVTest module keys are checked, with matching Lake artifacts restored; all22 named and dynamic activation gates remain required. No source or original gate requirement was weakened.

The old213 epoch is retired. Its last already-running AddSubShiftEdgeWitness finished exit0 uninterrupted;1258 completed log records, that last result and all2655 frozen source hashes are preserved. The old full module batch was intentionally not finished after main invalidated its model. Only idle/stopped metadata1762992/1763255/2890710/2912219 was retired. Successful outputs remain source-keyed; no incomplete old-epoch pass or unchecked reuse claim. Receipt `/tmp/stock-arm-drained-handoff/receipt.json`.

**Mixed now uses the same current Arm model**, branch `agent/stock-mixed-arm-model-20261021T003711Z`, commit `bbcdf080a43d340087692da65828c8a36762f795` in existing `.worktrees/stock-mixed-production`. All30 changed code blobs equal saved source. Its old-model source/evidence is preserved/pushed as11a57ca637d2cb87ed85764c6e2e88feccf90a84 on agent/stock-mixed-production-current-main. Current-model normal/integration gates remain pending; arithmetic lands first.

The old-model port now has366 distinct normal module successes, including complete Mixed/function/compiler-choice/fallback witnesses, linked fixture and both runtime modules. This continuation completed80 normal builds (one necessary changed-runtime rebuild) and both exact checked-in runtime grids:48 positive cases+2 missing-binary negative controls. All24 fresh Mixed objects/tables/original CLIF inputs equal the prior624-call native execution grid; not624 new executions. Normal per-module/whole-file evidence replaces the earlier scratch-import qualification, but is **not a current-Arm activation pass**. See docs/research/stock-mixed-normal-runtimes-strict.json and stock-mixed-current-main-normal-build.json.

Added checked-in scripts/check-stock-mixed-integration.py for the12 actual linked roots/33-function slices, current/retained CLI proofs, verified linker and generated axiom audit. Syntax/help and ordering on18 existing emitted files checked; actual full current-model execution, final bundled MCP/owned/public/previous-axiom parity, corpus/encoding, both original/prior identity-stage reports, actual default CLIs, all generated proofs and verified fv-demo/survey remain mandatory.

## Next and coordination

Observe the same live1235132/1235140 handles; never restart proofs on observation timeout. Finish current-model arithmetic gates and terminal source+receipt review; author a substantive non-draft PR and squash promptly after per-PR gates, verify exact squash tree and notify#261/#140. Then reconcile Mixed onto actual squash main and finish its full gates/activation; next tentatively logical95d72, then all remaining original families/effects, omitted/sunk memory/trap/call/CFG, source/block/whole-driver simulation, Stock-only completeness, optimizer/unwind and compiler/checker/linker/generated-proof consumers. Next is not a reservation. Preserve original inputs, all old theorem variants, exact required axiom sets and accepted identities/ordered stages.

Read contributor statuses#52/#71 and relevant#140 claims; stale statuses uncertain. [Specific shared Arm/TPIDR/MInst/Cov boundary request to @kevaundray](https://github.com/eth-act/clifv/issues/140#issuecomment-6304759270) remains unanswered at last read. No TLS/overflow/FP expansion claimed by our integer class. Current main CI39519636227 caches reused in the existing store:380 unique output records across two imports, stage5 alone317 records/639 referenced files,257 new keys. Both dict-facet and string-ltar schemas verified; original metadata-validator failure retained. Cache reuse is not a gate pass; downloads/staging removed.

## Ownership, preservation and bounded resources

All5 worktrees still have necessary purposes; no new tree/physical cache:

- `/home/lee/clifv`: user's dirty primary, preserve.
- `.worktrees/driver-proof-resume`: original1874 saved dirty paths at01081291e566bc4eb80419a526c5725406ed62b7; shared artifact store and Rust target. Never overwrite/stash.
- `.worktrees/stock-lowering`: saved dirty source, preserve.
- `.worktrees/stock-driver-incremental`: active current-Arm arithmetic gates.
- `.worktrees/stock-mixed-production`: current-Arm Mixed source and normal import view, hardlinks to the shared store.

Aggregate16GiB, max2 actual compiler jobs, OMP threads2, no actual proof wall timeout/pattern kill. One physical shared cache; cache-only I/O reserves1GiB within budget.768GiB free.12 completed helpers and duplicate native exports removed only after byte verification against remotely backed archive. Keep terminal logs/receipts; clean unneeded trees/caches when their work ends.

Full saved-source recovery commits (all1874 dirty paths, remote commit/blobs verified, canonical HEAD/index unchanged):

- 0b76d25d796550be1cfa6e720b353c265f6a227a, agent/stock-driver-wip-backup-20261021T011134Z: normal80-build evidence, exact runtime logs and exports, cache317 verification, previous long#44 body. Archive /tmp/stock-normal-complete-recovery/evidence.tar.gz.
- 400debde42252efe4e402e1bb4ef4c1f1b114a96, agent/stock-driver-wip-backup-20261021T011946Z: drained old epoch, final kernel exit0 and new verified handoff/controller/readiness logic. Archive /tmp/stock-arm-drained-handoff/completed-old-source-epoch.tar.gz.

Source candidates and evidence commits are separately pushed. Current recovery index `/tmp/stock-current-resume.json` contains live handles and full remaining obligations, with obsolete live assumptions removed. Prior full index retained in the remote archives. Execution plan: docs/plans/stock-driver-incremental-delivery.md on the current Mixed branch.


Current cache compatibility investigation 2026-10-21T01:58:20.931628+00:00: current-model scheduler3859380 remains live; no proof restart. Three more08020 CI shards imported,643 records/1265 referenced artifacts verified,399 new keys.52 record JSON changes are proven packed-to-unpacked transitions;47 retain the same ltar,5 have byte-identical olean/ilean/C after unpack. Sources and outputs of IselCmpEmit match main but local input key differs from exported keys. Checking the exact CI-pinned official Lean4.34.1 release in owned /home/lee/.local/share/clifv-test-tools/lean-4.34.1-linux (expected<5GiB;767GiB free), using the existing idle Mixed view for a cache-only probe. This is toolchain compatibility investigation, not another worktree/build cache; no running proof/toolchain will be changed before evidence supports it. Preserve user-installed .elan toolchain; remove temporary archive/toolchain if unnecessary. Budget cache/tool IO1GiB within16GiB, max2 actual compilers unchanged.


### Current verified cache alignment 2026-10-21T02:39:19.688269+00:00
Active arithmetic remains672c4dc4, current08020 model: controller1235132 / scheduler1235140, all-modules phase. Old3859194/3859380 metadata is retired after both kernels completed exit0;421 prior successful current-model module log records and all1874 saved dirty paths are verified remotely in70be76da74642a8f274644dc3c0b5efbeef7a00f. Exact same source/compiler/axiom/gate requirements. Root cause: RegallocLemmas exact input key7f930049350db887 retained a different serialized local proof output; default unstage and saved-trace precedence shadowed CI. Preserved the old artifact/trace; normal Lake API now selects CI1b128b2edf21984c. Downstream IselCmpEmit now restores without compilation at CI key1b659459a23ebf18. All current keys rechecked; no proof interrupted, manual input-key rebinding or gate waiver.

Three more CI shards imported:643 verified records/1265 referenced artifacts,399 new keys,779 unique current-main keys overall.52 old JSON digest changes were proven packed-to-unpacked conversions (47 same ltar,5 byte-identical olean/ilean/C). The official pinned-toolchain check produced the same six library fingerprints, version and cache keys; no compiler swap needed. Temporary official tree/archive removed. Current Mixed branch pushedbbcdf080 with cache alignment evidence/plan; original class source unchanged and current-model gates still pending. One physical cache/five necessary trees,16GiB/max2 compilers. Full140 active; no activation merged.


Current recovery 2026-10-21T02:41:43.093072+00:00: cache-alignment completion, saved-trace-precedence fix, resumed1235132/1235140 controls and all1874 saved dirty paths are remotely verified in d15e909a8f2bf4b6ab35c6c8525dd4692105b816 (agent/stock-driver-wip-backup-20261021T023956Z). Five completed helper scripts removed after byte verification against remote-backed archives; duplicate official toolchain/archive removed. Current-model gate has242 latest successful module records, no latest nonzero, same live handles. Source672 and all landing gates unchanged. Full140 remains active; no activation merge claimed.

Current verified wait 2026-10-21T02:42:48.639080+00:00: controller1235132 and scheduler1235140 confirmed live; active compiler jobs continue under16GiB/max2. Do not restart for observation timeouts. The source/gates remain fixed672/current08020; no full-goal or activation completion claim. Next: inspect actual results, finish remaining class gates and author substantive squash PR, then Mixed/all original140 obligations.


Current verification 2026-10-21T02:55:35.580514+00:00: same1235132/1235140 gate live, source672/current08020 unchanged. IselCtlTry completed successfully725s; TermFactsBase/Rules also pass. Current actual job IselTermFactsCall before16GiB soloStockNoOpportunityTable; cache-only probe confirms that table is out of date, historical13.5GiB peak fits planned16GiB. No actual kernel restarted/interrupted and no smaller-memory retry. Two more08020 CI shards imported through existing cache:553 verified output records/1332 artifact references,159 new keys,938 unique current-CI keys overall. Both original maps retained; preferred RegallocLemmas1b remains unchanged. No source/compiler/theorem/axiom/gate changes; no activation claim. Next: finish same handles/full remaining activation gates, substantive arithmetic PR and author squash, then Mixed and full original140.
