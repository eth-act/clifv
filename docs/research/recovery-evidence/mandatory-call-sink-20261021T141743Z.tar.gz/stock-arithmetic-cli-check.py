from pathlib import Path
import subprocess as sp,os,json,hashlib
view=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');root=Path('/tmp/stock-arithmetic-cli-check');root.mkdir(exist_ok=True);records={}
env=dict(os.environ,FV_MEMCAP='8G',FV_LAKE_CACHE='/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2');env['PATH']='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:'+env['PATH']
def run(name,args):
 log=root/(name+'.log');(root/'state.json').write_text(json.dumps({'state':'running','phase':name,'pid':os.getpid()}))
 with log.open('w') as f:r=sp.run(['scripts/memcap.sh','lake','env',*args],cwd=view,env=env,stdout=f,stderr=sp.STDOUT)
 records[name]={'rc':r.returncode,'sha256':hashlib.sha256(log.read_bytes()).hexdigest()};assert r.returncode==0,(name,r.returncode,str(log));assert 'Error: index out of bounds' not in log.read_text(),(name,'native initialization panic');return log
try:
 lp=sp.check_output(['scripts/memcap.sh','lake','env','printenv','LEAN_PATH'],cwd=view,env=env,text=True).strip()
 for mode,flags in [('Plain',['--no-dead-cleanup']),('Cleanup',[])]:
  bundle=Path('/tmp/stock-arithmetic-linked-proper')/('StockArithmetic2'+mode+'FallbackGlobal-bundle')
  retained=Path('/tmp/stock-arithmetic-linked-proper')/('StockArithmetic2Retained'+mode+'FallbackGlobal-bundle')
  proof=root/'Crates'/('ArithmeticRetainedCLI'+mode+'.lean');proof.parent.mkdir(exist_ok=True)
  run('retained-link-check-'+mode,[str(view/'.lake/build/bin/link-check'),str(retained),'--lean',str(proof),'--module','ArithmeticRetainedCLI'+mode,*flags])
  if mode == 'Plain':
   assert 'lowerWithFallbacks [' in proof.read_text(), 'retained consumer route was not exercised'
  env['LEAN_PATH']=str(root)+':'+lp
  run('retained-proof-'+mode,['lean','--root='+str(root),'-o',str(proof.with_suffix('.olean')),str(proof)])
  env.pop('LEAN_PATH',None)
  log=run('lean-link-'+mode,[str(view/'.lake/build/bin/lean-link'),str(bundle),'--verified',*flags])
  assert 'written by Link.SemanticCompilerWith.compile' in log.read_text()
  assert 'attempt_correct_source_peak' in log.read_text()
  proof=root/'Crates'/('ArithmeticCLI'+mode+'.lean');proof.parent.mkdir(exist_ok=True)
  run('link-check-'+mode,[str(view/'.lake/build/bin/link-check'),str(bundle),'--lean',str(proof),'--module','ArithmeticCLI'+mode,*flags])
  env['LEAN_PATH']=str(root)+':'+lp
  run('proof-'+mode,['lean','--root='+str(root),'-o',str(proof.with_suffix('.olean')),str(proof)])
  env.pop('LEAN_PATH',None)
 (root/'state.json').write_text(json.dumps({'state':'passed','records':records},indent=2))
except BaseException as e:
 (root/'state.json').write_text(json.dumps({'state':'failed','error':repr(e),'records':records},indent=2));raise
