from pathlib import Path
import json,hashlib,re,datetime,tarfile,shutil
root=Path('/home/lee/clifv/.worktrees/driver-proof-resume');docs=root/'docs/research'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
now=datetime.datetime.now(datetime.timezone.utc);stamp=now.strftime('%Y%m%dT%H%M%SZ')
batch=json.loads(Path('/tmp/stock-try-got-rename-batch.json').read_text());old=json.loads((docs/'stock-try-gap-scratch.json').read_text())
log=Path('/tmp/stock-try-got-rename-combined-axioms.log').read_text()
sets={m.group(1):sorted(x.strip() for x in m.group(2).split(',') if x.strip()) for m in re.finditer(r"'([^']+)' depends on axioms:\s*\[([^]]*)\]",log)}
for m in re.finditer(r"'([^']+)' does not depend on any axioms",log):sets[m.group(1)]=[]
for n,a in old['normal_audit']['sets'].items():assert sorted(a)==sets[n],n
assert len(sets)==len(old['normal_audit']['sets'])+len(batch['public_roots'])+len(batch['models'])
allowed={'propext','Classical.choice','Quot.sound'}
for n in batch['public_roots']+batch['models']:assert set(sets[n])<=allowed,n
constants=[json.loads(line.split('DELIVERY_CONSTANT ',1)[1]) for line in Path('/tmp/stock-try-got-rename-all-constants.log').read_text().splitlines() if line.startswith('DELIVERY_CONSTANT ')]
assert constants
for n,a in constants:assert set(a)<=allowed,n
mods={}
for m in batch['modules']:
 p=Path('/tmp')/m;check=json.loads(p.with_suffix('.check.json').read_text());assert check['actual_exit']==0
 rec={}
 for key,ext in [('source','.lean'),('object','.olean'),('log','.log'),('check','.check.json')]:
  f=p.with_suffix(ext);rec[key]=str(f);rec[key+'_sha256']=sha(f)
 for k in ['source','object','log']:assert rec[k+'_sha256']==check[k+'_sha256']
 assert not re.search(r'\b(sorry|admit|axiom|trace_state|native_decide)\b',p.with_suffix('.lean').read_text()),m
 mods[m]=rec
for audit in ['stock-try-got-rename-combined-axioms','stock-try-got-rename-all-constants']:
 p=Path('/tmp')/audit;check=json.loads(p.with_suffix('.check.json').read_text());assert check['actual_exit']==0
 for k,ext in [('source','.lean'),('object','.olean'),('log','.log')]:assert sha(p.with_suffix(ext))==check[k+'_sha256']
prior={}
for name in ['source-execution-x','try-source','try-context','try-rule','try-rets','try-reservation','try-outgoing','try-values','try-emitted','try-machine','try-got','try-indirect','try-rename','try-resolved','try-gap']:
 d=json.loads((docs/f'stock-{name}-scratch.json').read_text())
 for m,rec in d['modules'].items():
  for k in ['source','object','log']:assert sha(rec[k])==rec[k+'_sha256'],(m,k)
  prior[m]=rec
freeze=json.loads(Path('/tmp/stock-coherent-build-inputs.json').read_text())
for group in ['source_sha256','validation_script_sha256']:
 for p,h in freeze[group].items():assert sha(root/p)==h,p
progress=json.loads(Path('/tmp/stock-pr246-gates-progress.json').read_text());progress.pop('completed_phases',None)
remaining=old['remaining_checklist']
remaining.append({'requirement':'Actual final-renamed GOT TryCall retained branch and normal source returned values/world','state':'Proved under original scope/Dominated/input/source/semantic contracts, with fresh symbol target/source alias separation and reserved result fixedness derived internally. Prefix stores+load agreement composed with partial-agreement stopped call, permitting legitimate aliases to reserved result registers. Complete original nine-arg/16-byte compiler/prepare/forced checked fallback/checker/physical/source17 witness passes. All direct/GOT/true-indirect normal retained branches now final-renamed locally; available source-frame/noninterference and normal edge/block/whole simulation/completeness still open.'})
counts={'modules':len(mods),'public_roots':len(batch['public_roots']),'models':len(batch['models']),'combined_roots_models':len(sets),'previous_preserved':len(old['normal_audit']['sets']),'all_new_module_constants':len(constants),'previous_modules_hashes_preserved':len(prior)}
receipt={'utc':now.isoformat(),'goal':'Original full #140 ACTIVE/INCOMPLETE; production LEGACY','scope':'Scratch-only additive Stock proofs, not coherent integration or merge-ready','delivery_target':'roughly eight substantive validated squash merges/day; prioritize landing coherent backlog, remote backups and cleanup; drafts do not count','modules':mods,'public_roots':batch['public_roots'],'models':batch['models'],'counts':counts,'normal_audit':{'path':'/tmp/stock-try-got-rename-combined-axioms.log','sha256':sha('/tmp/stock-try-got-rename-combined-axioms.log'),'sets':sets},'all_constant_audit':{'path':'/tmp/stock-try-got-rename-all-constants.log','sha256':sha('/tmp/stock-try-got-rename-all-constants.log'),'all_standard_only':True,'count':len(constants)},'previous_modules_hashes_preserved':list(prior),'canonical2246_source_and_script_freeze_preserved':True,'kernel_resources':'All new modules and both audits actual exit0/object verified at8GiB through memcap; one heavy delivery worker retained','MCP':'No new calls; bundled audit deferred until coherent integration','active_exact_PR246_validation':progress,'remaining_checklist':remaining}
(docs/'stock-try-got-rename-scratch.json').write_text(json.dumps(receipt,indent=2)+'\n')
text=f'''Final-renamed GOT TryCall normal execution — {now.isoformat()}

Five scratch modules/six public roots pass actual8GiB kernel checks. The {len(sets)}-root/model audit preserves all571prior exact axiom sets. All {len(constants)} constants of the new modules, including private prefix splitting/alias/fixed-call/fixture helpers, use only standard axioms. All{len(prior)}previous scratch source/object/log hashes and frozen2246canonical sources plus49validation scripts remain unchanged. Previous goal turn PROGRESS: actual whole branch/record/source gap, GOT exact target+1 allocation/final terminal/source alias exclusion, complete three-form and nine-argGOT witnesses,571audit/418constants, verified bf8dcc7 remote backup and2.8GBcleanup.

Partial-agreement stopped-instruction renaming reads operands under the incoming prefix write-set agreement, then enlarges the output fixed set internally. Newly written reserved call result registers need not be disjoint from final source argument aliases: their reads precede writes. The actual prefix and final stopped call compose to exact renamed stopped execution and pointwise value-update agreement at every fixed result key. Existing full-agreement/no-def prefix variants remain unchanged.

The whole original-source GOT factory constructs the SAME raw branch execution together with internally derived target terminal and actual argument final-alias separation. The actual stack stores have no defs; the real GOT load defines exactly the fresh target, and its actual uses are empty. All store and final-call argument uses derive from actual mapped arguments; the target use is in the prefix write set. Original whole-driver reserved-result fixedness discharges every final call def. Renaming thus executes the actual stores, fresh symbol load and stopped TryCall through the returned world and EVERY normal source result's actual final key. Whole original source/scope/Dominated/input and unchanged csem/memory/external/outgoing contracts construct both raw and final-renamed executions internally, without new accepted-use/layout/allocation/alias certificates. The original callee model/DriverSem is used directly.

Complete nine-argument GOT with16byte outgoing area inhabits original LowerScope/Dominated/Arity, cached lower/prepareAt/forced checkedfallback/checker/physical, unchanged memory/external contracts, actual final-renamed retained branch/world/results and actual Clif source run returning17. Earlier raw GOT and final direct/true-indirect variants/witnesses remain unchanged. All THREE near/GOT/true-indirect normal retained branches now have local final-renamed execution/value/world proofs and full pipeline witnesses. This is not block/whole-driver simulation or completeness.

Next: derive available original-source frame/reserved-write noninterference and normal edge copies/source continuation from actual whole lowering, then compose block/whole simulation AND completeness. Exact shared payload alias endpoints/exception machine execution, full zero-return/sret/x8/width/handler matrix and every remaining original family/effect/sinking obligation remain. Original-input context/visitor/static/checker/fallback/physical totality, coherent scratch integration/MCP/public/private/compiler audits, full/crates/runtime/encoder/BOTH E2E identity-stage parity, actual production compiler/checker/linker/generated consumers and FRESH COMPLETE comparison remain mandatory. Full#140 ACTIVE/INCOMPLETE, production LEGACY. S10 shared exceptional interfaces stay with @kevaundray #232/#233.

Delivery246/247 remain drafts; exact-PR worker3247835 live under same exclusive shared warm-cache lease, canonical1233457 deliberately held. Preserve old-head receipts; reconcile current main and rerun required actual-head gates before dependent squash merges. Target roughly8substantive validated merges/day, prioritize landing coherent backlog, semantic grouping and remote backups. No merge/new worktree/new MCP/heavy retry/gate restart this batch.

Hashed evidence/full remaining checklist: stock-try-got-rename-scratch.json.
'''
(docs/'stock-try-got-rename-scratch.md').write_text(text)
plan=root/'docs/plans/test-binary-alignment-recovery.md';plan.write_text(plan.read_text()+'\n\n'+text)
files=[]
for rec in mods.values():files.extend(Path(rec[k]) for k in ['source','object','log','check'])
for name in ['stock-try-got-rename-combined-axioms','stock-try-got-rename-all-constants']:
 for ext in ['.lean','.log','.olean','.check.json']:files.append(Path('/tmp')/(name+ext))
files.extend(Path(p) for p in ['/tmp/stock-try-got-rename-batch.json','/tmp/stock-try-rule-inputs.json','/tmp/stock-try-reservation-check.py','/tmp/stock-try-got-rename-close.py','/tmp/stock-try-got-rename-make-audit.py','/tmp/make-stock-got-resolved.py','/tmp/stock-try-got-rename-status44.json','/tmp/stock-try-got-rename-status52.json','/tmp/stock-try-got-rename-status71.json','/tmp/stock-try-got-rename-task140.json'])
files.extend([docs/'stock-try-got-rename-scratch.json',docs/'stock-try-got-rename-scratch.md',docs/'stock-delivery-main-drift.json',plan])
archive=Path('/home/lee/.clifv-recovery')/(stamp+'-try-got-rename')/'checkpoint.tar.gz';archive.parent.mkdir(parents=True)
with tarfile.open(archive,'w:gz',compresslevel=1) as t:
 for p in files:t.add(p,arcname=str(p).lstrip('/'),recursive=False)
with tarfile.open(archive,'r:gz') as t:
 for p in files:assert t.extractfile(str(p).lstrip('/')).read()==p.read_bytes(),p
snapshot=Path('/tmp/stock-try-rule-inputs');size=sum(p.stat().st_size for p in snapshot.rglob('*') if p.is_file());shutil.rmtree(snapshot)
backup={'utc':now.isoformat(),'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(files),'all_members_byte_verified':True,'previous_remote_backup':json.loads((docs/'stock-try-gap-backup.json').read_text())['remote'],'cleanup':{'duplicate_dependency_snapshot_removed':True,'bytes_reclaimed':size,'unique_sources_objects_logs_checks_audits_preserved':True,'one_shared_warm_cache_retained':True,'other_projects_touched':False,'free_bytes':shutil.disk_usage(root).free}}
(docs/'stock-try-got-rename-backup.json').write_text(json.dumps(backup,indent=2)+'\n');Path('/tmp/stock-try-got-rename-archive-path').write_text(str(archive))
print(json.dumps({'counts':counts,'archive':str(archive),'cleanup':backup['cleanup'],'gate':progress},indent=2))
