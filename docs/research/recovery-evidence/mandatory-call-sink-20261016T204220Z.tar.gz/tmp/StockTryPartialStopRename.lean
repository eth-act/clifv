import StockTryStopRename
namespace Backend.Stock.Proof.TryPartialStopRenameDraft
open Backend.Proof Backend.Proof.Driver
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private theorem split_last_stop {V W : Type} {sem : ISem V W} {pre : List MInst} {i : MInst}
    {rho : Nat → V} {w : W} {ops : Array Operand} {atCall : Nat → V} {world : W}
    {outs : List V} {finalWorld : W} {ctl : Ctl}
    (run : seqRun sem (pre ++ [i]) rho w = some (.stop pre.length i ops atCall world outs finalWorld ctl)) :
    seqRun sem pre rho w = some (.fall atCall world) ∧
    seqRun sem [i] atCall world = some (.stop 0 i ops atCall world outs finalWorld ctl) := by
  induction pre generalizing rho w with
  | nil =>
    rcases seqRun_cons_stop run with first | ⟨k,op,output,world',impossible,rest⟩
    · obtain ⟨_,_,_,sameRho,sameWorld,rest⟩ := first
      subst atCall
      subst world
      exact ⟨rfl,run⟩
    · simp only [List.length_nil] at impossible
      omega
  | cons m pre ih =>
    rcases seqRun_cons_stop run with first | ⟨k,op,output,world',index,operands,execute,length,rest⟩
    · have zero := first.1
      simp only [List.length_cons] at zero
      omega
    · have same : k = pre.length := by simp only [List.length_cons] at index; omega
      subst k
      obtain ⟨prefixRun,single⟩ := ih rest
      refine ⟨?_,single⟩
      simp only [seqRun,operands,execute,length,ite_true,prefixRun,Option.map_some,SeqEnd.succ]
/-- A final stopped call uses only the incoming prefix agreement. Its fixed
writes may extend the prefix write set, with no exclusion of aliases to those
new result registers. All fixed output keys retain pointwise agreement. -/
theorem stock_single_stop_partial_rename {V W : Type} {sem : ISem V W} {g : Reg → Reg} {gn : Nat → Nat}
    (ren : VRenaming g gn) (semantic : ∀ i,sem (i.mapRegs g) = sem i)
    {D : Nat → Prop} (fixedD : ∀ d,D d → gn d = d)
    {i : MInst} (uses : ∀ u ∈ vuseNums i,D u ∨ ¬ D (gn u)) (fixed : ∀ d ∈ vdefs i,gn d = d)
    {raw rho : Nat → V} (agree : Agree gn D raw rho)
    {w finalWorld : W} {ops : Array Operand} {outs : List V} {ctl : Ctl}
    (run : seqRun sem [i] raw w = some (.stop 0 i ops raw w outs finalWorld ctl)) :
    seqRun sem [i.mapRegs g] rho w = some (.stop 0 (i.mapRegs g) (ops.map (rnOp gn)) rho w outs finalWorld ctl) ∧
      ∀ n,gn n = n → vdefUpd ops outs raw n = vdefUpd (ops.map (rnOp gn)) outs rho n := by
  rcases seqRun_cons_stop run with first | ⟨k,op,output,world',impossible,rest⟩
  · obtain ⟨_,_,operands,_,_,execute,length,control⟩ := first
    have operandUses : ∀ o ∈ ops.toList,o.isUse = true → D o.vreg ∨ ¬ D (gn o.vreg) := by
      intro o member used
      apply uses o.vreg
      simp only [vuseNums,operands]
      exact List.mem_map.mpr ⟨o,List.mem_filter.mpr ⟨member,used⟩,rfl⟩
    have renamedUses := vuses_rename agree operandUses
    have fixedAgree : ∀ n,gn n = n → raw n = rho (gn n) := by
      intro n same
      by_cases inside : D n
      · exact agree n (.inl inside)
      · exact agree n (.inr (by rw [same]; exact inside))
    have enlargedAgree : Agree gn (fun n => D n ∨ gn n = n) raw rho := by
      intro n guard
      rcases guard with (inside | same) | outside
      · exact agree n (.inl inside)
      · exact fixedAgree n same
      · exact agree n (.inr (fun member => outside (.inl member)))
    have defs : ∀ o ∈ ops.toList,o.isDef = true → o.vreg ∈ vdefs i := by
      intro o member defined
      simp only [vdefs,operands]
      exact List.mem_map.mpr ⟨o,List.mem_filter.mpr ⟨member,defined⟩,rfl⟩
    have post := vdefUpd_rename (outs := outs) (D := fun n => D n ∨ gn n = n)
      (fun d member => member.elim (fixedD d) id) enlargedAgree
      (fun o member defined => Or.inr (fixed o.vreg (defs o member defined)))
    refine ⟨?_,?_⟩
    · simp only [seqRun,operands_mapRegs ren,operands,Except.map,semantic,renamedUses,execute,
        defs_length_rn,length,ite_true]
    · intro n unchanged
      have decision : (D n ∨ gn n = n) ∨ ¬ (D (gn n) ∨ gn (gn n) = gn n) := .inl (.inr unchanged)
      simpa only [unchanged] using post n decision
  · omega
/-- Compose an actual prefix allocation set with the final stopped call.
Only uses BEFORE writes must avoid the prefix's renamed definition image;
new call result definitions need merely be fixed by the final resolver. -/
theorem stock_fixed_prefix_stop_rename {V W : Type} {sem : ISem V W} {g : Reg → Reg} {gn : Nat → Nat}
    (ren : VRenaming g gn) (semantic : ∀ i,sem (i.mapRegs g) = sem i)
    {D : Nat → Prop} (fixedD : ∀ d,D d → gn d = d)
    {pre : List MInst} (defs : ∀ m ∈ pre,∀ d ∈ vdefs m,D d)
    (uses : ∀ m ∈ pre,∀ u ∈ vuseNums m,D u ∨ ¬ D (gn u))
    {i : MInst} (lastUses : ∀ u ∈ vuseNums i,D u ∨ ¬ D (gn u))
    (fixed : ∀ d ∈ vdefs i,gn d = d) {rho : Nat → V} {w : W}
    {ops : Array Operand} {atCall : Nat → V} {world : W} {outs : List V} {finalWorld : W} {ctl : Ctl}
    (run : seqRun sem (pre ++ [i]) (fun n => rho (gn n)) w =
      some (.stop pre.length i ops atCall world outs finalWorld ctl)) :
    ∃ next,seqRun sem ((pre ++ [i]).map (·.mapRegs g)) rho w =
      some (.stop pre.length (i.mapRegs g) (ops.map (rnOp gn)) next world outs finalWorld ctl) ∧
      ∀ n,gn n = n → vdefUpd ops outs atCall n = vdefUpd (ops.map (rnOp gn)) outs next n := by
  obtain ⟨prefixRun,single⟩ := split_last_stop run
  obtain ⟨next,renamed,agree⟩ := (seqRun_rename ren semantic fixedD defs uses (by intro n _; rfl)).1 prefixRun
  obtain ⟨last,post⟩ := stock_single_stop_partial_rename ren semantic fixedD lastUses fixed agree single
  refine ⟨next,?_,post⟩
  have combined := seqRun_append_fall_stop sem renamed last
  simpa only [List.map_append,List.map_cons,List.map_nil,List.length_map,Nat.zero_add] using combined
end Backend.Stock.Proof.TryPartialStopRenameDraft
