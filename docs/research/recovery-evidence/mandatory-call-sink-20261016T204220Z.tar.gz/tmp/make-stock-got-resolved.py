from pathlib import Path
old=Path('/tmp/StockTryResolvedRuns.lean').read_text()
a=old.index('private theorem alias_ren');b=old.index('private theorem last_index',a);alias=old[a:b]
a=old.index('private theorem fixed_call');b=old.index('/-- Final-renamed direct',a);fixed=old[a:b]
a=old.index('theorem stock_indirect_try_run_resolved');b=old.index('\nend Backend.Stock.Proof',a);s=old[a:b]
s=s.replace('stock_indirect_try_run_resolved','stock_got_try_run_resolved').replace('{sig : Clif.Signature}','{ext : Clif.ExtFunc}').replace('IndirectTryRun f result label bi b sig','GotTryRun f result label bi b ext').replace('sig.returns.length','ext.sig.returns.length')
s=s.replace('(results : rvals.length = ext.sig.returns.length)', '''(targetFixed : keyMap result raw.target = raw.target)
    (separation : ∀ n ∈ raw.ns,keyMap result n ≠ raw.target)
    (results : rvals.length = ext.sig.returns.length)''')
a=s.index('  have apart :');b=s.index('  have fixed :=',a)
s=s[:a]+'''  let pre := ((stackEnts ((raw.locs.zip raw.ns).zip raw.bytes)).map argStore) ++
    [MInst.loadExtNameGot (.vreg raw.target .int) ext.name]
  have arranged : seqRun isem (pre ++ [MInst.tryCall
      ⟨.reg (.vreg raw.target .int),retPairs (regPairsOf ((raw.locs.zip raw.ns).zip raw.bytes)),
        callDefs (resultDefs raw.base ext.sig.returns.length)⟩ {raw.info with rets := ext.sig.returns.length}])
      (fun n => rho (keyMap result n)) w = some (.stop pre.length
        (.tryCall ⟨.reg (.vreg raw.target .int),retPairs (regPairsOf ((raw.locs.zip raw.ns).zip raw.bytes)),
          callDefs (resultDefs raw.base ext.sig.returns.length)⟩ {raw.info with rets := ext.sig.returns.length})
        (tgtOp raw.target :: (retOps (regPairsOf ((raw.locs.zip raw.ns).zip raw.bytes)) ++
          callDefOps (resultDefs raw.base ext.sig.returns.length))).toArray
        (upd (fun n => rho (keyMap result n)) raw.target (ofX raw.symbol)) raw.atCall raw.outs raw.finalWorld
        (.goto raw.info.handlers.length)) := by
    simpa only [pre,List.append_assoc,List.cons_append,List.nil_append,List.length_append,List.length_singleton] using execute
  have fixedTarget : ∀ d,d = raw.target → keyMap result d = d := by intro d same; subst d; exact targetFixed
  have defs : ∀ m ∈ pre,∀ d ∈ vdefs m,d = raw.target := by
    intro m member d defined
    rcases List.mem_append.mp member with store | load
    · obtain ⟨e,_,rfl⟩ := List.mem_map.mp store
      rw [vdefs_argStore] at defined
      cases defined
    · have same := List.mem_singleton.mp load
      subst m
      simpa only [vdefs_got_ctl,List.mem_singleton] using defined
  have uses : ∀ m ∈ pre,∀ u ∈ vuseNums m,u = raw.target ∨ keyMap result u ≠ raw.target := by
    intro m member u used
    rcases List.mem_append.mp member with store | load
    · obtain ⟨e,present,rfl⟩ := List.mem_map.mp store
      rw [vuseNums_argStore,List.mem_singleton] at used
      subst u
      exact .inr (separation _ (map_zip_args (mem_args_of_stackEnts present)))
    · have same := List.mem_singleton.mp load
      subst m
      simp only [vuseNums_got_ctl,List.not_mem_nil] at used
  have lastUses : ∀ u ∈ vuseNums (MInst.tryCall
      ⟨.reg (.vreg raw.target .int),retPairs (regPairsOf ((raw.locs.zip raw.ns).zip raw.bytes)),
        callDefs (resultDefs raw.base ext.sig.returns.length)⟩ {raw.info with rets := ext.sig.returns.length}),
      u = raw.target ∨ keyMap result u ≠ raw.target := by
    intro u used
    rw [vuseNums_tryCall,vuseNums_call_reg] at used
    rcases List.mem_cons.mp used with same | argument
    · exact .inl same
    · exact .inr (separation _ (map_zip_args (mem_args_of_regPairs argument)))
''' +s[b:]
s=s.replace('stock_no_def_prefix_stop_rename (alias_ren result)\n    (driver.rename _ _ (alias_ren result)) noDefs fixed execute', 'stock_fixed_prefix_stop_rename (alias_ren result)\n    (driver.rename _ _ (alias_ren result)) fixedTarget defs uses lastUses fixed arranged')
s=s.replace('⟨((stackEnts ((raw.locs.zip raw.ns).zip raw.bytes)).map argStore).length,','⟨pre.length,')
s=s.replace('    exact renamed','    simpa only [pre,List.append_assoc,List.cons_append,List.nil_append] using renamed')
Path('/tmp/StockTryGotResolvedRun.lean').write_text('''import StockTryPartialStopRename
import StockTryResolvedRuns
import StockTryGotSeparatedSourceRun
namespace Backend.Stock.Proof.TryGotResolvedRunDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open TryPartialStopRenameDraft TryResultDefsFixedDraft TryRetsTotalDraft TryResultMapDraft
open TryGotSourceRunDraft TryResolvedRunsDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
'''+alias+fixed+'''/-- Exact final-renamed GOT branch execution. The stores and symbol load use
only the fresh target write set; the final call adds actual fixed reserved
outputs after reading arguments. Whole-source consumers derive separation. -/
'''+s+'\nend Backend.Stock.Proof.TryGotResolvedRunDraft\n')
