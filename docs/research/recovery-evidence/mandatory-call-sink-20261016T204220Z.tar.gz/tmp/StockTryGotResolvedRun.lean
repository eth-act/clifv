import StockTryPartialStopRename
import StockTryResolvedRuns
import StockTryGotSeparatedSourceRun
namespace Backend.Stock.Proof.TryGotResolvedRunDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open TryPartialStopRenameDraft TryResultDefsFixedDraft TryRetsTotalDraft TryResultMapDraft
open TryGotSourceRunDraft TryResolvedRunsDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private theorem alias_ren (result : Result) : VRenaming (resolver result) (keyMap result) := by
  refine ⟨fun n c => resolve_vreg _ _ n c,?_⟩
  intro r notVirtual
  cases r with
  | vreg n c => exact False.elim (notVirtual n c rfl)
  | _ => rfl
private theorem fixed_call {f : Clif.Function} {result : Result} (lowered : Stock.lower f = .ok result)
    {owner base count : Nat}
    (layout : result.initial.tryRegs[owner]! = (reservedReturns base count,reservedPayloads base count))
    (dest : CallDest) (L : List (Nat × Reg)) (info : TryInfo)
    (form : (∃ name,dest = .sym name) ∨ (∃ target,dest = .reg (.vreg target .int))) :
    ∀ d ∈ vdefs (.tryCall ⟨dest,retPairs L,callDefs (resultDefs base count)⟩ info),keyMap result d = d := by
  intro d defined
  have same (call : CallInfo) : vdefs (.tryCall call info) = vdefs (.call call) := by
    unfold vdefs
    rw [operands_tryCall_call]
  rw [same] at defined
  rcases form with ⟨name,rfl⟩ | ⟨target,rfl⟩
  · rw [vdefs_call_sym] at defined
    simp only [resultDefs,List.map_map,Function.comp_def,List.mem_map,List.mem_range] at defined
    obtain ⟨j,inside,rfl⟩ := defined
    exact stock_lower_try_result_keys_fixed lowered layout j inside
  · rw [vdefs_call_reg] at defined
    simp only [resultDefs,List.map_map,Function.comp_def,List.mem_map,List.mem_range] at defined
    obtain ⟨j,inside,rfl⟩ := defined
    exact stock_lower_try_result_keys_fixed lowered layout j inside
/-- Exact final-renamed GOT branch execution. The stores and symbol load use
only the fresh target write set; the final call adds actual fixed reserved
outputs after reading arguments. Whole-source consumers derive separation. -/
theorem stock_got_try_run_resolved {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) {isem : Sem} (driver : DriverSem isem)
    {label bi : Nat} {b : Clif.Block} {ext : Clif.ExtFunc} {MR : MemRelT} {fr : Clif.Frame}
    {rho : Nat → CV} {w : Arm.ArmState} {rvals : List Clif.Val} {cm' : Clif.Mem}
    (raw : GotTryRun f result label bi b ext isem MR fr (fun n => rho (keyMap result n)) w rvals cm')
    (targetFixed : keyMap result raw.target = raw.target)
    (separation : ∀ n ∈ raw.ns,keyMap result n ≠ raw.target)
    (results : rvals.length = ext.sig.returns.length) :
    ResolvedNormalBranch result raw.source.branch.step isem MR fr rho w raw.base raw.info.handlers.length rvals cm' := by
  have execute := raw.run
  rw [raw.code,List.toList_toArray] at execute
  let pre := ((stackEnts ((raw.locs.zip raw.ns).zip raw.bytes)).map argStore) ++
    [MInst.loadExtNameGot (.vreg raw.target .int) ext.name]
  have arranged : seqRun isem (pre ++ [MInst.tryCall
      ⟨.reg (.vreg raw.target .int),retPairs (regPairsOf ((raw.locs.zip raw.ns).zip raw.bytes)),
        callDefs (resultDefs raw.base ext.sig.returns.length)⟩ {raw.info with rets := ext.sig.returns.length}])
      (fun n => rho (keyMap result n)) w = some (.stop pre.length
        (.tryCall ⟨.reg (.vreg raw.target .int),retPairs (regPairsOf ((raw.locs.zip raw.ns).zip raw.bytes)),
          callDefs (resultDefs raw.base ext.sig.returns.length)⟩ {raw.info with rets := ext.sig.returns.length})
        (tgtOp raw.target :: (retOps (regPairsOf ((raw.locs.zip raw.ns).zip raw.bytes)) ++
          callDefOps (resultDefs raw.base ext.sig.returns.length))).toArray
        (upd (fun n => rho (keyMap result n)) raw.target (ofX raw.symbol)) raw.atCall raw.outs raw.finalWorld
        (.goto raw.info.handlers.length)) := by
    simpa only [pre,List.append_assoc,List.cons_append,List.nil_append,List.length_append,List.length_singleton] using execute
  have fixedTarget : ∀ d,d = raw.target → keyMap result d = d := by intro d same; subst d; exact targetFixed
  have defs : ∀ m ∈ pre,∀ d ∈ vdefs m,d = raw.target := by
    intro m member d defined
    rcases List.mem_append.mp member with store | load
    · obtain ⟨e,_,rfl⟩ := List.mem_map.mp store
      rw [vdefs_argStore] at defined
      cases defined
    · have same := List.mem_singleton.mp load
      subst m
      simpa only [vdefs_got_ctl,List.mem_singleton] using defined
  have uses : ∀ m ∈ pre,∀ u ∈ vuseNums m,u = raw.target ∨ keyMap result u ≠ raw.target := by
    intro m member u used
    rcases List.mem_append.mp member with store | load
    · obtain ⟨e,present,rfl⟩ := List.mem_map.mp store
      rw [vuseNums_argStore,List.mem_singleton] at used
      subst u
      exact .inr (separation _ (map_zip_args (mem_args_of_stackEnts present)))
    · have same := List.mem_singleton.mp load
      subst m
      simp only [vuseNums_got_ctl,List.not_mem_nil] at used
  have lastUses : ∀ u ∈ vuseNums (MInst.tryCall
      ⟨.reg (.vreg raw.target .int),retPairs (regPairsOf ((raw.locs.zip raw.ns).zip raw.bytes)),
        callDefs (resultDefs raw.base ext.sig.returns.length)⟩ {raw.info with rets := ext.sig.returns.length}),
      u = raw.target ∨ keyMap result u ≠ raw.target := by
    intro u used
    rw [vuseNums_tryCall,vuseNums_call_reg] at used
    rcases List.mem_cons.mp used with same | argument
    · exact .inl same
    · exact .inr (separation _ (map_zip_args (mem_args_of_regPairs argument)))
  have fixed := fixed_call lowered raw.layout (.reg (.vreg raw.target .int)) (regPairsOf ((raw.locs.zip raw.ns).zip raw.bytes))
    {raw.info with rets := ext.sig.returns.length} (.inr ⟨raw.target,rfl⟩)
  obtain ⟨next,renamed,post⟩ := stock_fixed_prefix_stop_rename (alias_ren result)
    (driver.rename _ _ (alias_ren result)) fixedTarget defs uses lastUses fixed arranged
  refine ⟨pre.length,
    (MInst.tryCall ⟨.reg (.vreg raw.target .int),retPairs (regPairsOf ((raw.locs.zip raw.ns).zip raw.bytes)),callDefs (resultDefs raw.base ext.sig.returns.length)⟩ {raw.info with rets := ext.sig.returns.length}).mapRegs (resolver result),
    ((tgtOp raw.target :: (retOps (regPairsOf ((raw.locs.zip raw.ns).zip raw.bytes)) ++ callDefOps (resultDefs raw.base ext.sig.returns.length))).toArray.map (rnOp (keyMap result))),next,raw.atCall,raw.outs,raw.finalWorld,?_,raw.returnedWorld,?_⟩
  · rw [raw.code,List.toList_toArray]
    simpa only [pre,List.append_assoc,List.cons_append,List.nil_append] using renamed
  · intro j v atValue
    have inside : j < ext.sig.returns.length := by have bound := (List.getElem?_eq_some_iff.mp atValue).1; omega
    have fixedKey : keyMap result (raw.base+j) = raw.base+j := by
      have atKey := stock_lower_try_result_keys_fixed lowered raw.layout j (Nat.lt_of_lt_of_le inside (Nat.le_max_left _ _))
      simpa only [keyMap,resultKey,if_pos inside] using atKey
    have value := raw.normalValues j v atValue
    dsimp only [keyMap] at fixedKey value ⊢
    rw [fixedKey] at value ⊢
    have sameUpdate := post _ fixedKey
    dsimp only [keyMap] at sameUpdate
    rw [← sameUpdate]
    exact value
end Backend.Stock.Proof.TryGotResolvedRunDraft
