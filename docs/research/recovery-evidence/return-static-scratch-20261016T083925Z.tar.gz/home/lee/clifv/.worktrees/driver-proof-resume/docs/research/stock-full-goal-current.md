# #140 completion evidence and remaining obligations

Use this checklist with every obligation and gate in
[the recovery plan](../plans/test-binary-alignment-recovery.md). The goal is
active and incomplete. Production still uses the legacy driver.

| Requirement | Current evidence | Work still required |
| --- | --- | --- |
| Original inputs, old theorem variants and axiom sets | Frozen source manifest and previous audited checkpoints; the three placement roots retain their exact old sets | Current consolidated audit, fresh upstream reconciliation and final cutover parity audit; derive internal producer conditions instead of adding source filters |
| Every accepted rule family and effect | Saved selected-rule/source-transfer proofs, including guarded scalar cases | Complete uncovered families, memory/world effects, calls, traps, sinking and TryCall continuation under original conditions |
| Register agreement, fresh writes and final aliases | Saved actual result binding, alias origins, guarded value/frame and available-source transfer proofs | Whole-driver growth/alias classes and full returned/prepared ClassesOkM/ClassesOk/all indexed-vector classes now compile in scratch; integrate/audit them, then prove universal value agreement, fresh-write noninterference and every source/world semantic case |
| Source, DFG, world, block and whole-driver simulation | Existing source-definedness/guarded relations and partial body composition | Full composition for every accepted source case and whole-driver simulation/completeness; preserve original theorem interfaces |
| CFG and preparation | Existing actual indexed CFG/arity/origin, no-additional-split and shared-target proofs/witnesses | Full returned/prepared class interfaces and executable parameter/edge-vector class transport now compile in scratch; integrate/audit them and complete branch decisions, controlABI/visitor success, indexed CFG/copy readiness and dataflow |
| Emitted instruction forms and local spill requirements | Canonical actual source-body coverage/final segments; twenty-two compiled standard-only scratch roots cover scans, return/trap emission, branches, block cores, actual entry assembly, returned whole code and prepared code | Integrate scratch proofs after frozen validation, run MCP/full audits; validate integrated universal whole-code/prepared coverage and derive control ABI/operand validity |
| Allocation/checker completeness | Existing symbolic dense-home/copy/edge execution and complete selected fallback witnesses | Derive original-input must-availability/EntryAvailAt, arbitrary block/edge verification, actual checker fixpoint/fallback acceptance/completeness, allocation and physical readiness |
| Production integration | Current compiler/checker/linker/generated-proof paths remain legacy | Switch all actual consumers to the verified Stock driver while preserving accepted identities, successful stages, old variants and required axioms; coordinate shared interfaces with kevaundray |
| Complete non-vacuity witnesses | Complete source/raw/checked/physical witnesses include real nine-parameter stack entry, direct/indirect forced-critical TryCall with retained unreachable predecessor and one-register executable vector, plus earlier return/comparing-branch/helper/reservation cases | General whole-driver/production ABI witnesses and every remaining new public-root premise; preserve actual stage and consumer links |
| Public-root/kernel/transitive axiom audit | Canonical targeted normal/MCP receipts; ninety-seven scratch roots normal-standard-only, prior ninety-one sets unchanged | Frozen 1,992-root audit/all 1,969 prior and seven compiler sets; then integrated 2,089-root audit and one bundled ninety-seven-root MCP; final production audit |
| Full build, crates, runtime, encoder and both E2E modes | Last fully validated checkpoint is prepared-shared; current complete gates queued behind live serialized rebuild | Verify actual current receipts and full identity/stage parity; rerun after integration and at production cutover |
| Fresh complete stock comparison and #179 baseline | Historical comparison and unchanged 420 comparison-source hashes | Fresh complete comparison at production cutover, inspect every identity/stage and rejection class, retain at least #179 and all original accepted-input guarantees |

The canonical frozen batch is recorded in
[stock-body-form-checkpoint.json](stock-body-form-checkpoint.json). Its source
freeze remains active until the deferred watcher is terminal. Check the exact
live processes and receipts before editing sources or interpreting old logs.

The twelve scratch modules and complete same-run entry/stack witness are recorded in
[stock-whole-forms-scratch.json](stock-whole-forms-scratch.json). They have not been
integrated or MCP-checked. Actual whole-traversal assembly and preparation form
transport compile in scratch; source value semantics and universal checker
acceptance remain open. All twenty-two roots are outside the queued 1,992-root audit.

Whole-driver class growth, initial/final source and reservation classes, and a
complete source/raw/checked/physical witness are recorded in
[stock-class-growth-scratch.json](stock-class-growth-scratch.json). The combined
sixteen-module/thirty-seven-root scratch integration supersedes earlier counts.
Instruction operand classes and source register values remain unproved globally.

Actual helper/class-model/source-statement/branch/return contracts and complete
pipeline witnesses are recorded in
[stock-operand-class-scratch.json](stock-operand-class-scratch.json). This
supersedes earlier integration counts: twenty-one modules/forty-seven roots.
Ordered result binding and final-alias/global instruction-class composition
remain open; production still uses the legacy driver.

Ordered binding, conditional alias/resolver class transport and complete body-scan
class composition are recorded in
[stock-binding-class-scratch.json](stock-binding-class-scratch.json). Combined
integration now covers twenty-five modules/fifty-eight roots. Whole-driver alias
invariant derivation and global returned/prepared instruction-class composition
remain open; no new source certificate or runtime filter was added.

Actual helper/interpreter/named-root alias classes, initialization, complete scans
and a real original-condition try-call/raw/checked/physical witness are recorded in
[stock-helper-alias-scratch.json](stock-helper-alias-scratch.json). Combined
integration now covers thirty-four modules/seventy-five roots. The try witness
contains a normal continuation and no exception handlers; whole-driver alias
composition and universal exception/source/world simulation remain open.
Reconcile newer main218–227/f29d0c0 before production integration.

Latest cumulative checkpoint: [stock-driver-alias-scratch.json](stock-driver-alias-scratch.json),36modules/78roots. Universal whole-driver alias-class derivation under original LowerScope now compiles, with complete real try/direct+indirect critical-edge stage witnesses. Global instruction classes, original value semantics, full simulation/completeness and production cutover remain open. These counts supersede all earlier integration proposals.

Current cumulative checkpoint: [stock-core-class-scratch.json](stock-core-class-scratch.json),39modules/81roots. Actual branch and built original-core instruction classes now compile, with a complete original-condition comparing-branch pipeline witness and real ordinary classed outputs. Internal prefix invariants still require whole-traversal composition; entry/global returned/prepared instruction classes, full value simulation/completeness and production cutover remain mandatory. Counts supersede earlier integration proposals.

Latest cumulative checkpoint: [stock-whole-instruction-class-scratch.json](stock-whole-instruction-class-scratch.json),44modules/86roots. Universal returned/prepared instruction operand classes under ORIGINAL LowerScope and complete nine-parameter/real stack-load/direct+indirect critical-try pipeline witnesses compile. Full ClassesOk/block-parameter/branch/edge-register classes and control ABI/visitor success remain open, as do all original value semantics, simulation/completeness and production obligations. These integration counts supersede earlier proposals.

Latest cumulative checkpoint: [stock-whole-classes-scratch.json](stock-whole-classes-scratch.json),48modules/91roots. Actual whole Stock and indexed preparation supply BOTH full ClassesOkM/ClassesOk interfaces, virtual integer block/branch registers and all indexed outgoing vector classes internally under ORIGINAL LowerScope. Complete real entry/critical-try witnesses include actual one-register vectors. Universal control ABI/visitor success/SpillInstOk, availability/checker/fallback/totality and all original value simulation/completeness/production obligations remain mandatory. Counts supersede every prior integration proposal.

Latest cumulative checkpoint: [stock-return-static-scratch.json](stock-return-static-scratch.json),53modules/97roots. Actual ordinary/x8 return constructor, source-terminal records, final aliases and positioned returned code have derived SpillInstOk, with complete ordinary/struct-return raw/globalcheckedfallback/physical pipelines. Remaining control static/visitor, availability/completeness, every original value simulation/completeness and production obligation remain mandatory. Peer#52 now ACTIVE; own#44 records specific ABI/TryCall/production boundary/coordination before overlapping interface edits. Counts supersede all earlier integration proposals.
