import StockCallSinkCheckedTable
import StockCallSinkRootPart0
import StockCallSinkRootPart1
import StockCallSinkRootPart2
import StockCallSinkRootPart3
import StockCallSinkRootPart4
import StockCallSinkRootPart5
import StockCallSinkRootPart6
import StockCallSinkRootPart7
namespace Backend.Stock.Proof.CallSinkDraft
open Backend.Proof Backend.Proof.Cov Isle Isle.Interp Isle.Aarch64
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
attribute [local irreducible] Isle.Aarch64.program
private theorem eight_cases (n : Nat) (bound : n < 8) :
    n = 0 ∨ n = 1 ∨ n = 2 ∨ n = 3 ∨ n = 4 ∨ n = 5 ∨ n = 6 ∨ n = 7 := by omega
/-- All original roots except the two explicitly handled extension-load rules
check under the same source-input descriptions and original root exclusions. -/
theorem stock_callSink_roots_checked :
    (program.rulesOf TId.lower).all (fun r =>
      !closureRootIds.contains r.id || r.id == 815 || r.id == 824 ||
        aRule program callSinkTab aext sourceSinkActor callSinkPre callSinkOracle [.xv .inst] AW.top r) = true ∧
    (program.rulesOf TId.lower).all (fun r => !(r.id == 964 || r.id == 1037) ||
      aRule program callSinkTab aext sourceSinkActor callSinkPre callSinkOracle [.c0] AW.top r) = true ∧
    (program.rulesOf TId.lower_branch).all
      (aRule program callSinkTab aext sourceSinkActor callSinkPre callSinkOracle [.c0,.c0] AW.top) = true := by
  refine ⟨?_,by decide +kernel,by decide +kernel⟩
  apply List.all_eq_true.mpr
  intro r member
  change callSinkRootOk r = true
  have bound : r.id % 8 < 8 := Nat.mod_lt _ (by decide)
  have cases : r.id % 8 = 0 ∨ r.id % 8 = 1 ∨ r.id % 8 = 2 ∨ r.id % 8 = 3 ∨
      r.id % 8 = 4 ∨ r.id % 8 = 5 ∨ r.id % 8 = 6 ∨ r.id % 8 = 7 := eight_cases _ bound
  rcases cases with h | h | h | h | h | h | h | h
  · simpa only [h,beq_self_eq_true,ite_true] using List.all_eq_true.mp call_roots_0_checked r member
  · simpa only [h,beq_self_eq_true,ite_true] using List.all_eq_true.mp call_roots_1_checked r member
  · simpa only [h,beq_self_eq_true,ite_true] using List.all_eq_true.mp call_roots_2_checked r member
  · simpa only [h,beq_self_eq_true,ite_true] using List.all_eq_true.mp call_roots_3_checked r member
  · simpa only [h,beq_self_eq_true,ite_true] using List.all_eq_true.mp call_roots_4_checked r member
  · simpa only [h,beq_self_eq_true,ite_true] using List.all_eq_true.mp call_roots_5_checked r member
  · simpa only [h,beq_self_eq_true,ite_true] using List.all_eq_true.mp call_roots_6_checked r member
  · simpa only [h,beq_self_eq_true,ite_true] using List.all_eq_true.mp call_roots_7_checked r member

end Backend.Stock.Proof.CallSinkDraft
