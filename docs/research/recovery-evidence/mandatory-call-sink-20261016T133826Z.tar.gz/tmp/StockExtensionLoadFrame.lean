import StockExtensionLoadSource
import StockExtensionTailTable
import FV.Backend.Proof.IselCovDriver
import FV.Backend.Proof.IselCmpBase
namespace Backend.Stock.Proof.ExtensionLoadFrameDraft
open Backend.Proof Backend.Proof.Cov Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open ExtensionLoadSourceDraft ExtensionTailDraft PureSinkDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
attribute [local irreducible] Isle.Aarch64.program
private theorem rhs_parts {ctx : Ctx} {cfg : Config} {n : Nat}
    {before after : State} {tr trace : Array RuleId} {env : Isle.Interp.Env V}
    {body : Expr} {value : V}
    (run : (evalExpr program (Stock.sem ctx) cfg (n+5)
      (.let 25 [(6,13,.term 13 236 [.var 18 5])] body) env).run (before,tr) =
        .ok (some value,after,trace)) :
    ∃ unit sunk sinkTrace,
      (evalExpr program (Stock.sem ctx) cfg (n+3) (.term 13 236 [.var 18 5]) env).run (before,tr) =
        .ok (some unit,sunk,sinkTrace) ∧
      (evalExpr program (Stock.sem ctx) cfg (n+4) body (env.set! 6 (some unit))).run (sunk,sinkTrace) =
        .ok (some value,after,trace) := by
  rw [evalExpr.eq_6,evalBinds.eq_3] at run
  simp only [isel_monad] at run
  cases hs : (evalExpr program (Stock.sem ctx) cfg (n+3) (.term 13 236 [.var 18 5]) env).run (before,tr) with
  | error e => rw [hs] at run; cases run
  | ok q =>
    obtain ⟨out,sunk,sinkTrace⟩ := q
    cases out with
    | none => rw [hs] at run; simp only [isel_monad] at run; cases run
    | some unit =>
      rw [hs] at run
      simp only [isel_monad] at run
      split at run
      · simp only [evalBinds.eq_2,isel_monad] at run
        exact ⟨unit,sunk,sinkTrace,rfl,run⟩
      · simp only [isel_monad] at run; cases run
/-- Full execution of either extension-load RHS changes the sunk table only
at the ordinary-load producer derived from its actual source match. -/
theorem stock_extension_load_full_sink_frame {f : Clif.Function} {ctx : Ctx}
    (mapped : MappedCtxInv f ctx) (clean : Clean (sourceIdentityCtx ctx))
    {cfg : Config} (overlap : cfg.checkOverlap = false) {root m n : Nat}
    {rootInfo : IInfo} {inst : Clif.Inst}
    (rootSlot : ctx.insts[root]? = some rootInfo) (rootClif : rootInfo.clif = some inst)
    {before matched after : State} {tr matchTrace trace : Array RuleId}
    {bound : Isle.Interp.Env V} {out : V} (signed : Bool)
    (matchRun : (matchRule program (Stock.sem ctx) cfg (m+5)
      (if signed then rule_lower_1359 else rule_lower_1300) [.inst root]).run (before,tr) =
      .ok (some bound,matched,matchTrace))
    (rhsRun : (evalExpr program (Stock.sem ctx) cfg (n+5)
      (if signed then rule_lower_1359 else rule_lower_1300).rhs bound).run (matched,matchTrace) =
      .ok (some out,after,trace)) :
    ∃ i info fields,ctx.insts[i]? = some info ∧
      (Backend.sem ctx).unData 152 info.data = some (16,fields) ∧
      after.sunk = before.sunk.set! i true := by
  obtain ⟨i,info,fields,unit,sunk,sinkTrace,slot,format,sinkRun,update⟩ :=
    stock_extension_load_sink_source signed matchRun rhsRun
  have shape : (if signed then rule_lower_1359 else rule_lower_1300).rhs =
      .let 25 [(6,13,.term 13 236 [.var 18 5])] (tailBody signed) := by
    cases signed <;> rfl
  have bodyRun := rhsRun
  rw [shape] at bodyRun
  obtain ⟨unit',sunk',sinkTrace',sinkRun',tailRun⟩ := rhs_parts bodyRun
  have same := Except.ok.inj (sinkRun.symm.trans sinkRun')
  have sunkSame : sunk.sunk = sunk'.sunk := congrArg (fun q => q.2.1.sunk) same
  have analyzed := stock_extension_tail_environments_checked signed
  cases hc : aRuleEnvs program sourceSinkTab aext sourceSinkActor sourceSinkPre aOracle
      [.xv .inst] (if signed then rule_lower_1359 else rule_lower_1300) with
  | none => simp only [hc] at analyzed; cases analyzed
  | some envs =>
    have accepted : envs.all (fun env =>
        (aExpr program tailTab actor purePre aOracle (tailBody signed) (env.set 6 AW.top)).isSome) = true := by
      simpa only [hc] using analyzed
    let hole := max ctx.insts.size before.sunk.size
    have empty : ctx.insts[hole]!.clif = none := by
      rw [getElem!_def,Array.getElem?_eq_none (Nat.le_max_left _ _)]; rfl
    have unused : before.sunk[hole]! = false := by
      rw [getElem!_def,Array.getElem?_eq_none (Nat.le_max_right _ _)]; rfl
    let md := Coverage.sourceSinkModel mapped clean hole empty
    have held := holds_inst mapped.identityView rootSlot rootClif
    have matchedAnalysis := (Coverage.Invariant.soundAt mapped md cfg sourceSinkTab overlap
      stock_sourceSink_table_checked (m+5)).mrule _ _ _ _ _ _ _ _ _ hc held unused matchRun
    obtain ⟨aenv,member,envHeld⟩ := matchedAnalysis.2
    obtain ⟨a,checked⟩ := Option.isSome_iff_exists.mp (List.all_eq_true.mp accepted aenv member)
    let tailModel := pureModel mapped clean sunk'.sunk
    have result := (Coverage.Invariant.soundAt mapped tailModel cfg tailTab overlap
      stock_extension_tail_table_checked (n+4)).expr (tailBody signed) (aenv.set 6 AW.top) a
        (bound.set! 6 (some unit')) sunk' sinkTrace' (some out) after trace checked
          (envOK_set envHeld (γ_top unit') 6) rfl tailRun
    exact ⟨i,info,fields,slot,format,result.1.trans (sunkSame.symm.trans update)⟩
/-- Full execution of either extension-load RHS changes the sunk table only
at the ordinary-load producer derived from its actual source match. -/
theorem stock_extension_load_full_sink_frame_any_fuel {f : Clif.Function} {ctx : Ctx}
    (mapped : MappedCtxInv f ctx) (clean : Clean (sourceIdentityCtx ctx))
    {cfg : Config} (overlap : cfg.checkOverlap = false) {root m n : Nat}
    {rootInfo : IInfo} {inst : Clif.Inst}
    (rootSlot : ctx.insts[root]? = some rootInfo) (rootClif : rootInfo.clif = some inst)
    {before matched after : State} {tr matchTrace trace : Array RuleId}
    {bound : Isle.Interp.Env V} {out : V} (signed : Bool)
    (matchRun : (matchRule program (Stock.sem ctx) cfg m
      (if signed then rule_lower_1359 else rule_lower_1300) [.inst root]).run (before,tr) =
      .ok (some bound,matched,matchTrace))
    (rhsRun : (evalExpr program (Stock.sem ctx) cfg n
      (if signed then rule_lower_1359 else rule_lower_1300).rhs bound).run (matched,matchTrace) =
      .ok (some out,after,trace)) :
    ∃ i info fields,ctx.insts[i]? = some info ∧
      (Backend.sem ctx).unData 152 info.data = some (16,fields) ∧
      after.sunk = before.sunk.set! i true := by
  have matchBound : 5 ≤ m := by
    cases m with
    | zero => rw [matchRule.eq_1] at matchRun; cases matchRun
    | succ k =>
      obtain ⟨env,patterns,iflets⟩ := matchRule_some_inv matchRun
      cases signed <;> simp only [Bool.false_eq_true,↓reduceIte,rule_lower_1300,rule_lower_1359] at iflets
      all_goals
        rcases k with _ | (_ | (_ | (_ | k)))
        all_goals try omega
        all_goals isel_inv [matchIfLets.eq_1,evalExpr.eq_1,evalArgs.eq_1,evalBinds.eq_1,applyTerm.eq_1] at iflets
  have rhsBound : 5 ≤ n := by
    cases signed <;> simp only [Bool.false_eq_true,↓reduceIte,rule_lower_1300,rule_lower_1359] at rhsRun
    all_goals
      rcases n with _ | (_ | (_ | (_ | (_ | n))))
      all_goals try omega
      all_goals isel_inv [evalExpr.eq_1,evalArgs.eq_1,evalBinds.eq_1,applyTerm.eq_1] at rhsRun
  have matchEq : m = (m-5)+5 := by omega
  have rhsEq : n = (n-5)+5 := by omega
  rw [matchEq] at matchRun
  rw [rhsEq] at rhsRun
  exact stock_extension_load_full_sink_frame mapped clean overlap rootSlot rootClif signed matchRun rhsRun
end Backend.Stock.Proof.ExtensionLoadFrameDraft
