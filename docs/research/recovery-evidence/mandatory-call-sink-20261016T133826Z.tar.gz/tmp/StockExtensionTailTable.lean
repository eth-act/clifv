import StockPureSinkModel
namespace Backend.Stock.Proof.ExtensionTailDraft
open Backend.Proof Backend.Proof.Cov Isle Isle.Interp Isle.Aarch64 PureSinkDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
attribute [local irreducible] Isle.Aarch64.program
/-- Closed helper summaries for the actual tail after load sinking. -/
def tailTerms : List Nat := [1, 2, 93, 111, 113, 120, 144, 157, 164, 170, 172, 175, 182, 201, 209, 219, 235, 287, 305, 318, 319, 320, 321, 325, 339, 352, 358, 359, 360, 362, 376, 432, 433, 498, 529, 530, 531, 532, 533, 534, 553, 554, 574, 575, 576, 577, 580, 581, 582, 699, 700, 702, 978, 1157, 1182, 1378, 1431, 1455, 1508, 1514, 1614, 1820, 1822, 1823, 1828, 1829, 1830, 1831, 1832, 1833, 1844, 1962, 1964, 1989, 1990, 1998, 2002, 2012, 2013, 2014, 2015, 2016, 2017, 2024, 2028, 2029, 2235, 2331, 2341, 2357, 2387, 2425, 2426, 2449, 2468, 2476, 2482]
def tailTab : Tab := (covTab.filter (fun e => tailTerms.contains e.1)) ++ [(584,[.reg 1,.c0],.reg 1)]
theorem stock_extension_tail_table_checked :
    chkTab program tailTab aext actor purePre aOracle = true := by
  decide +kernel
/-- Exact original extension-load body after the leading sink binding. -/
def tailBody (signed : Bool) : Expr :=
  .term 25 172 [.term 27 (if signed then 700 else 699)
    [.var 14 0,.term 89 574 [.var 14 0,.var 15 1,.term 9 156 [.var 138 3]],.var 142 2]]
/-- Every actual matched abstract environment admits the entire RHS tail;
this is a fixed analysis result, with no added accepted-input condition. -/
theorem stock_extension_tail_environments_checked (signed : Bool) :
    (match aRuleEnvs program sourceSinkTab aext sourceSinkActor sourceSinkPre aOracle
      [.xv .inst] (if signed then rule_lower_1359 else rule_lower_1300) with
    | none => false
    | some envs => envs.all (fun env =>
      (aExpr program tailTab actor purePre aOracle (tailBody signed) (env.set 6 AW.top)).isSome)) = true := by
  cases signed <;> decide +kernel
end Backend.Stock.Proof.ExtensionTailDraft

