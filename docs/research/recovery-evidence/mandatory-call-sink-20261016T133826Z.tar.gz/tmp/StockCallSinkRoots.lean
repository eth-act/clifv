import StockCallSinkModel
import StockExtensionLoadFrame
import FV.Backend.Proof.StockSelectionReceipts
import FV.Backend.Proof.IselCovDriver
namespace Backend.Stock.Proof.CallSinkRootsDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Cov Isle Isle.Interp Isle.Aarch64
open CallSinkDraft Coverage.OracleInvariant ExtensionLoadFrameDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
attribute [local irreducible] Isle.Aarch64.program
private theorem call_data {f : Clif.Function} {ctx : Ctx} (mapped : MappedCtxInv f ctx)
    {ti fn : Nat} {info : IInfo} {args : List Nat}
    (slot : ctx.insts[ti]? = some info) (clif : info.clif = some (.call fn args)) :
    info.data = .data 152 6 [.data 151 8 [],.values args,.op (.funcRef fn)] := by
  have data := mapped.data ti info _ slot clif
  simp only [instData] at data
  cases external : f.extern? fn with
  | none => simp only [external] at data; cases data
  | some ext =>
    simp only [external] at data
    split at data
    · unfold instDataV opcodeV mkVariant variantIdx variantNames Isle.Aarch64.program at data
      change Except.ok (V.data 152 6 [.data 151 8 [],.values args,.op (.funcRef fn)]) = .ok info.data at data
      exact (Except.ok.inj data).symm
    · cases data

private theorem indirect_data {f : Clif.Function} {ctx : Ctx} (mapped : MappedCtxInv f ctx)
    {ti ref callee : Nat} {info : IInfo} {args : List Nat}
    (slot : ctx.insts[ti]? = some info) (clif : info.clif = some (.callIndirect ref callee args)) :
    ∃ sig,f.sigDecls.lookup ref = some sig ∧
      info.data = .data 152 7 [.data 151 9 [],.values (callee :: args),.op (.sig sig)] := by
  have data := mapped.data ti info _ slot clif
  simp only [instData] at data
  cases declared : f.sigDecls.lookup ref with
  | none => simp only [declared] at data; cases data
  | some sig =>
    simp only [declared] at data
    unfold instDataV opcodeV mkVariant variantIdx variantNames Isle.Aarch64.program at data
    change Except.ok (V.data 152 7 [.data 151 9 [],.values (callee :: args),.op (.sig sig)]) = .ok info.data at data
    exact ⟨sig,rfl,(Except.ok.inj data).symm⟩

private theorem stock_lower_nonroot_nomatch {f : Clif.Function} {ctx original : Ctx}
    (view : DFGViewEq ctx original) (hctx : CtxInv f original) {ii : Nat}
    {info : IInfo} {inst : Clif.Inst} (hi : original.insts[ii]? = some info)
    (hc : info.clif = some inst) {r : Rule} (hr : r ∈ program.rulesOf TId.lower)
    (hroot : closureRootIds.contains r.id = false) :
    ∀ m s0 env s1, (matchRule program (Stock.sem ctx) {} m r [.inst ii]).run s0 ≠
      .ok (some env, s1) := by
  intro m s0 env' s1 hmatch
  have hok := List.all_eq_true.mp exclOk_program r hr
  simp only [exclOk, hroot, Bool.false_or] at hok
  cases m with
  | zero => rw [matchRule.eq_1] at hmatch; cases hmatch
  | succ m =>
    obtain ⟨env0, ha, -⟩ := matchRule_some_inv hmatch
    rw [stock_matchArgs_source view] at ha
    split at hok
    · rename_i q hargs
      rw [hargs] at ha
      obtain ⟨e1, h1, -⟩ := matchArgs_cons_inv ha
      exact fails_sound hctx q .inst _ _ _ _ hok
        ⟨ii, info, inst, rfl, hi, hc, hctx.data ii info inst hi hc⟩ h1
    · cases hok


private theorem only_uext : (program.rulesOf TId.lower).filter (fun r => r.id == 815) = [rule_lower_1300] := by
  decide +kernel
private theorem only_sext : (program.rulesOf TId.lower).filter (fun r => r.id == 824) = [rule_lower_1359] := by
  decide +kernel
private theorem protected_statement {f : Clif.Function} {ctx : Ctx}
    (mapped : MappedCtxInv f ctx) (clean : Clean (sourceIdentityCtx ctx))
    {guardedIndex : Nat}
    (notAtomic : ∀ info fields,ctx.insts[guardedIndex]? = some info →
      (Backend.sem ctx).unData 152 info.data ≠ some (17,fields))
    (notLoad : ∀ info fields,ctx.insts[guardedIndex]? = some info →
      (Backend.sem ctx).unData 152 info.data ≠ some (16,fields))
    {ii : Nat} {info : IInfo} {inst : Clif.Inst}
    (slot : ctx.insts[ii]? = some info) (clif : info.clif = some inst)
    {before after : State} {out : V} {trace : List RuleId}
    (run : Stock.runTerm ctx "lower" [.inst ii] before = .ok (some out,after,trace)) :
    after.sunk[guardedIndex]! = before.sunk[guardedIndex]! := by
  obtain ⟨selected⟩ := stock_named_lower_selection run
  have checked := List.all_eq_true.mp stock_callSink_roots_checked.1 selected.rule selected.rule_mem
  simp only [Bool.or_eq_true,Bool.not_eq_true',beq_iff_eq] at checked
  rcases checked with ((excluded | uext) | sext) | checked
  · have view : DFGViewEq ctx (sourceIdentityCtx ctx) := ⟨rfl,rfl,rfl,rfl,rfl⟩
    exact False.elim (stock_lower_nonroot_nomatch view mapped.identityView slot clif selected.rule_mem excluded
      _ _ _ _ selected.matchedRun)
  · have member : selected.rule ∈ (program.rulesOf TId.lower).filter (fun r => r.id == 815) :=
      List.mem_filter.mpr ⟨selected.rule_mem,by simpa only [beq_iff_eq] using uext⟩
    rw [only_uext] at member
    have same := List.mem_singleton.mp member
    have hm := selected.matchedRun
    have hr := selected.rhsRun
    rw [same] at hm hr
    obtain ⟨i,actual,fields,found,format,frame⟩ :=
      stock_extension_load_full_sink_frame_any_fuel mapped clean rfl slot clif false hm hr
    have ne : guardedIndex ≠ i := by
      intro eq; subst i; exact notLoad actual fields found format
    rw [frame]
    simp [getElem!_def,Array.getElem?_setIfInBounds,ne,Ne.symm ne]
  · have member : selected.rule ∈ (program.rulesOf TId.lower).filter (fun r => r.id == 824) :=
      List.mem_filter.mpr ⟨selected.rule_mem,by simpa only [beq_iff_eq] using sext⟩
    rw [only_sext] at member
    have same := List.mem_singleton.mp member
    have hm := selected.matchedRun
    have hr := selected.rhsRun
    rw [same] at hm hr
    obtain ⟨i,actual,fields,found,format,frame⟩ :=
      stock_extension_load_full_sink_frame_any_fuel mapped clean rfl slot clif true hm hr
    have ne : guardedIndex ≠ i := by
      intro eq; subst i; exact notLoad actual fields found format
    rw [frame]
    simp [getElem!_def,Array.getElem?_setIfInBounds,ne,Ne.symm ne]
  · let md := callSinkModel mapped clean guardedIndex notAtomic before.sunk[guardedIndex]!
    have held := holds_inst mapped.identityView slot clif
    exact (selected_rule_sound mapped md {} callSinkTab rfl stock_callSink_table_checked checked held rfl
      selected.matchedRun selected.rhsRun).1
/-- Every successful actual source-statement root preserves the sunk bit of
EVERY original direct call in its mapped context, for any call result count.
All load distinctions and selected-rule cases are derived internally. -/
theorem stock_statement_preserves_direct_source_call {f : Clif.Function} {ctx : Ctx}
    (mapped : MappedCtxInv f ctx) (clean : Clean (sourceIdentityCtx ctx))
    {guardedIndex fn : Nat} {callInfo : IInfo} {args : List Nat}
    (callSlot : ctx.insts[guardedIndex]? = some callInfo) (callClif : callInfo.clif = some (.call fn args))
    {ii : Nat} {info : IInfo} {inst : Clif.Inst}
    (slot : ctx.insts[ii]? = some info) (clif : info.clif = some inst)
    {before after : State} {out : V} {trace : List RuleId}
    (run : Stock.runTerm ctx "lower" [.inst ii] before = .ok (some out,after,trace)) :
    after.sunk[guardedIndex]! = before.sunk[guardedIndex]! := by
  have data := call_data mapped callSlot callClif
  apply protected_statement mapped clean ?_ ?_ slot clif run
  all_goals
    intro actual fields found format
    have same := Option.some.inj (callSlot.symm.trans found)
    subst actual
    rw [data] at format
    simp [Backend.sem] at format
/-- The same actual all-statement protection holds for original indirect calls;
source metadata supplies the signature and non-load format internally. -/
theorem stock_statement_preserves_indirect_source_call {f : Clif.Function} {ctx : Ctx}
    (mapped : MappedCtxInv f ctx) (clean : Clean (sourceIdentityCtx ctx))
    {guardedIndex ref callee : Nat} {callInfo : IInfo} {args : List Nat}
    (callSlot : ctx.insts[guardedIndex]? = some callInfo) (callClif : callInfo.clif = some (.callIndirect ref callee args))
    {ii : Nat} {info : IInfo} {inst : Clif.Inst}
    (slot : ctx.insts[ii]? = some info) (clif : info.clif = some inst)
    {before after : State} {out : V} {trace : List RuleId}
    (run : Stock.runTerm ctx "lower" [.inst ii] before = .ok (some out,after,trace)) :
    after.sunk[guardedIndex]! = before.sunk[guardedIndex]! := by
  obtain ⟨sig,declared,data⟩ := indirect_data mapped callSlot callClif
  apply protected_statement mapped clean ?_ ?_ slot clif run
  all_goals
    intro actual fields found format
    have same := Option.some.inj (callSlot.symm.trans found)
    subst actual
    rw [data] at format
    simp [Backend.sem] at format
end Backend.Stock.Proof.CallSinkRootsDraft
