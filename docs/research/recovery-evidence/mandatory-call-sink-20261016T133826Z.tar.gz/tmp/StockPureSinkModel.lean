import StockPureSinkTable
import FV.Backend.Proof.StockCoverageInvariant
import FV.Backend.Proof.StockSourceSinkModel
namespace Backend.Stock.Proof.PureSinkDraft
open Backend.Proof Backend.Proof.Cov Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
attribute [local irreducible] Isle.Aarch64.program
/-- The real source semantics instantiate the closed no-sink helper analysis. -/
def pureModel {f : Clif.Function} {ctx : Ctx} (mapped : MappedCtxInv f ctx)
    (clean : Clean (sourceIdentityCtx ctx)) (sunk : Array Bool) :
    Coverage.Invariant.Model actor purePre program f ctx where
  Is := fun st => st.sunk = sunk
  source := covModel logicImmComplete mapped.identityView clean sinkState.base
  ctor := by
    intro t term lookup as vs value st next held invariant pre run
    have parts : noOpportunityPre term.id as = true ∧ (term.id != TId.sink_inst) = true := by
      simpa only [purePre, Bool.and_eq_true] using pre
    have ordinary := parts.1
    simp only [noOpportunityPre, Bool.and_eq_true] at ordinary
    refine ⟨Coverage.ctor_value_sound mapped logicImmComplete held ordinary.2 run,?_⟩
    exact (stock_ctor_noSink (bne_iff_ne.mp parts.2) run).trans invariant
  oracle := Coverage.oracle_sound _
/-- Actual successful evaluation admitted by the closed helper summaries
preserves every sunk bit. The caller's original source context is unchanged. -/
theorem stock_pure_apply_noSink {f : Clif.Function} {ctx : Ctx}
    (mapped : MappedCtxInv f ctx) (clean : Clean (sourceIdentityCtx ctx))
    {cfg : Config} (overlap : cfg.checkOverlap = false)
    {fuel ty term : Nat} {as : List AW} {a : AW} {vs : List V}
    {before after : State} {trace finalTrace : Array RuleId} {out : Option V}
    (checked : aApply program pureTab actor purePre aOracle ty term as = some a)
    (held : Holds2 f (sourceIdentityCtx ctx) as vs)
    (run : (applyTerm program (Stock.sem ctx) cfg fuel ty term vs).run (before,trace) =
      .ok (out,after,finalTrace)) :
    after.sunk = before.sunk ∧ ∀ value,out = some value → γ f (sourceIdentityCtx ctx) a value := by
  let md := pureModel mapped clean before.sunk
  exact (Coverage.Invariant.soundAt mapped md cfg pureTab overlap stock_pure_noSink_table_checked fuel).apply
    ty term as a vs before trace out after finalTrace checked held rfl run
end Backend.Stock.Proof.PureSinkDraft
