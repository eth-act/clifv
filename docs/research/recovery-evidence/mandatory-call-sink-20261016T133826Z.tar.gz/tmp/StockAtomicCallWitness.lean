import StockAtomicCallProtected
import FV.Backend.Proof.LowerDecide
import FV.Backend.Proof.SpillCtlPipe
import FV.Backend.Proof.SpillArity
namespace Backend.Stock.Proof.AtomicCallWitnessDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64 AtomicCallProtectedDraft AtomicProtectedDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm
private def callee : Clif.Signature := {callConv := some .systemV}
private def function : Clif.Function := {
  name := "stock_atomic_call_protection"
  sig := {params := [⟨.i64,.none,.normal⟩,⟨.i64,.none,.normal⟩],callConv := some .systemV}
  blocks := [{id := 0,params := [(1,.i64),(3,.i64)],body := [
    ⟨[2],.atomicLoad .i8 {} 1⟩,⟨[],.call 0 []⟩,⟨[],.callIndirect 0 3 []⟩],term := .ret []}]
  externs := [(0,{name := "atomic_call_target",sig := callee,colocated := true})]
  sigDecls := [(0,callee)] }
private def built : Ctx × Array (Nat × Nat) × State :=
  (Stock.buildCtx function).toOption.getD (sinkCtx,#[],sinkState)
private theorem build : Stock.buildCtx function = .ok built := rfl
private theorem scope : LowerScope function := by apply lowerScope_of; decide +kernel
private theorem dominated : Dominated function := by
  constructor
  · decide +kernel
  · intro ctx ranges st build bi b found
    cases bi with
    | zero =>
      simp only [function,List.getElem?_cons_zero,Option.some.injEq] at found
      subst b
      constructor
      · intro j stm statement x member
        rcases j with _ | (_ | (_ | j))
        all_goals simp [function] at statement
        all_goals subst stm
        all_goals simp [Driver.instArgs] at member
        all_goals subst x
        all_goals simp [availOf,function,defsBefore,defsFrom]
      · intro x member
        simp [abiTerm,Driver.termArgs,function,callee,sretRet,sigRets] at member
    | succ bi => simp [function] at found
  · intro ctx ranges st build tl x incoming notLocal y member
    have bound := (inFix_fixOk (f := function) (ctx := ctx) (gn := id)).cand tl x incoming
    have length : function.blocks.length = 1 := rfl
    omega
private theorem arity : ArityOk function := by apply arityOk_of; decide +kernel
private theorem abi : AbiSigsOk function := by
  constructor
  · constructor
    · decide +kernel
    · intro e member
      simp only [function,List.mem_singleton] at member
      subst e
      decide +kernel
  · intro sig member
    simp [indSigs,function,callee] at member
    subst sig
    constructor <;> decide +kernel
private def input : State := {built.2.2 with color := some (built.2.2.entryColor[0]!+1)}
private def observed : Prop :=
  ((applyTerm program (Stock.sem built.1) {} 13 27 564 [.inst 0]).run (input,#[])).toOption.map
    (fun q => q.1.isSome && q.2.1.sunk[0]! && !q.2.1.sunk[1]! && !q.2.1.sunk[2]!) = some true
private theorem actual : observed := by unfold observed; decide +kernel
/-- A real original-condition source contains an atomic load and both direct
and indirect calls. The full atomic helper sinks its load while preserving BOTH
actual call bits in the same real built context; no protected-slot certificate. -/
theorem stock_atomic_load_both_source_calls_witness :
    ∃ (f : Clif.Function) (ctx : Ctx) (ranges : Array (Nat × Nat)) (initial before after : State)
      (direct indirect : IInfo) (value : V) (trace : Array RuleId),
      LowerScope f ∧ Dominated f ∧ ArityOk f ∧ AbiSigsOk f ∧
      Stock.buildCtx f = .ok (ctx,ranges,initial) ∧ MappedCtxInv f ctx ∧
      ctx.insts[1]? = some direct ∧ direct.clif = some (.call 0 []) ∧
      ctx.insts[2]? = some indirect ∧ indirect.clif = some (.callIndirect 0 3 []) ∧
      ApplyInternal program (Stock.sem ctx) {} 12 27 564 [.inst 0] (before,#[]) value (after,trace) ∧
      after.sunk[0]! = true ∧ before.sunk[1]! = false ∧ before.sunk[2]! = false ∧
      after.sunk[1]! = before.sunk[1]! ∧ after.sunk[2]! = before.sunk[2]! := by
  have observation := actual
  unfold observed at observation
  cases run : (applyTerm program (Stock.sem built.1) {} 13 27 564 [.inst 0]).run (input,#[]) with
  | error e => simp only [run,Except.toOption,Option.map_none] at observation; cases observation
  | ok q =>
    obtain ⟨out,after,trace⟩ := q
    cases out with
    | none => simp [run,Except.toOption] at observation
    | some value =>
      simp only [run,Except.toOption,Option.map_some,Option.some.injEq,Bool.and_eq_true,
        Bool.not_eq_true',Option.isSome_some,Bool.true_and] at observation
      have mapped := buildCtx_mappedInv scope build
      have direct : built.1.insts[1]? = some built.1.insts[1]! := rfl
      have indirect : built.1.insts[2]? = some built.1.insts[2]! := rfl
      have directClif : built.1.insts[1]!.clif = some (.call 0 []) := by decide +kernel
      have indirectClif : built.1.insts[2]!.clif = some (.callIndirect 0 3 []) := by decide +kernel
      have directFrame := stock_atomic_load_preserves_direct_source_call mapped rfl direct directClif run
      have indirectFrame := stock_atomic_load_preserves_indirect_source_call mapped rfl indirect indirectClif run
      exact ⟨function,built.1,built.2.1,built.2.2,input,after,_,_,value,trace,scope,dominated,arity,abi,build,mapped,
        direct,directClif,indirect,indirectClif,run,observation.1.1,by decide +kernel,by decide +kernel,directFrame,indirectFrame⟩
end Backend.Stock.Proof.AtomicCallWitnessDraft
