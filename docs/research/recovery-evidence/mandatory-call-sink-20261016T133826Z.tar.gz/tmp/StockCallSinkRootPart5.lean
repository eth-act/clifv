import StockCallSinkRootDefs
namespace Backend.Stock.Proof.CallSinkDraft
open Backend.Proof Backend.Proof.Cov Isle Isle.Interp Isle.Aarch64
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
attribute [local irreducible] Isle.Aarch64.program
/-- Kernel checked root partition; existing exclusions and both explicit load
exceptions are identical across every partition. -/
theorem call_roots_5_checked : (program.rulesOf TId.lower).all
    (fun r => if r.id % 8 == 5 then callSinkRootOk r else true) = true := by
  decide +kernel
end Backend.Stock.Proof.CallSinkDraft
