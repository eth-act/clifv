import StockExtensionLoadFrame
import StockCallSinkRoots
import FV.Backend.Proof.LowerDecide
import FV.Backend.Proof.SpillCtlPipe
import FV.Backend.Proof.SpillArity
namespace Backend.Stock.Proof.AtomicExtensionWitnessDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Cov Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open ExtensionLoadFrameDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm
private def callee : Clif.Signature := {callConv := some .systemV}
private def function (signed : Bool) : Clif.Function := {
  name := "stock_atomic_extension_call_protection"
  sig := {params := [⟨.i64,.none,.normal⟩,⟨.i64,.none,.normal⟩],callConv := some .systemV}
  blocks := [{id := 0,params := [(1,.i64),(3,.i64)],body := [
    ⟨[2],.atomicLoad .i8 {} 1⟩,⟨[4],.extend (if signed then .sextend else .uextend) .i64 2⟩,⟨[],.call 0 []⟩,⟨[],.callIndirect 0 3 []⟩],term := .ret []}]
  externs := [(0,{name := "atomic_call_target",sig := callee,colocated := true})]
  sigDecls := [(0,callee)] }
private def built (signed : Bool) : Ctx × Array (Nat × Nat) × State :=
  (Stock.buildCtx (function signed)).toOption.getD (sinkCtx,#[],sinkState)
private theorem build (signed : Bool) : Stock.buildCtx (function signed) = .ok (built signed) := by cases signed <;> rfl
private theorem scope (signed : Bool) : LowerScope (function signed) := by cases signed <;> apply lowerScope_of <;> decide +kernel

private theorem dominated (signed : Bool) : Dominated (function signed) := by
  constructor
  · cases signed <;> decide +kernel
  · intro ctx ranges st build bi b found
    cases bi with
    | zero =>
      simp only [function,List.getElem?_cons_zero,Option.some.injEq] at found
      subst b
      constructor
      · intro j stm statement x member
        rcases j with _ | (_ | (_ | (_ | j)))
        all_goals simp [function] at statement
        all_goals subst stm
        all_goals simp [Driver.instArgs] at member
        all_goals subst x
        all_goals simp [availOf,function,defsBefore,defsFrom]
      · intro x member
        simp [abiTerm,Driver.termArgs,function,callee,sretRet,sigRets] at member
    | succ bi => simp [function] at found
  · intro ctx ranges st build tl x incoming notLocal y member
    have bound := (inFix_fixOk (f := function signed) (ctx := ctx) (gn := id)).cand tl x incoming
    have length : (function signed).blocks.length = 1 := rfl
    omega
private theorem arity (signed : Bool) : ArityOk (function signed) := by cases signed <;> apply arityOk_of <;> decide +kernel
private theorem abi (signed : Bool) : AbiSigsOk (function signed) := by
  constructor
  · constructor
    · cases signed <;> decide +kernel
    · intro e member
      simp only [function,List.mem_singleton] at member
      subst e
      decide +kernel
  · intro sig member
    simp [indSigs,function,callee] at member
    subst sig
    constructor <;> decide +kernel
private def input (signed : Bool) : State :=
  {(built signed).2.2 with color := some ((built signed).2.2.entryColor[0]!+1)}
private theorem clean_built {f : Clif.Function} {ctx : Ctx}
    {ranges : Array (Nat × Nat)} {initial : State}
    (build : Stock.buildCtx f = .ok (ctx,ranges,initial)) : Clean (sourceIdentityCtx ctx) := by
  obtain ⟨original,before,legacy,spec,view⟩ := buildCtx_source build
  have h := Cov.clean_of_build legacy
  intro i info lookup
  change ctx.insts[i]? = some info at lookup
  rw [view.insts] at lookup
  exact h i info lookup
private theorem clean (signed : Bool) : Clean (sourceIdentityCtx (built signed).1) :=
  clean_built (build signed)
private def namedObserved (signed : Bool) : Bool :=
  match Stock.runTerm (built signed).1 "lower" [.inst 1] (input signed) with
  | .error _ => false
  | .ok (out,after,trace) => out.isSome && after.sunk[0]! && !after.sunk[2]! && !after.sunk[3]! && decide (trace.getLast? = some 810)
private theorem named_actual : namedObserved false = true := by decide +kernel
/-- The original atomic-load/extension source selects the actual atomic fusion
root810 and its isolated helper while both real source calls remain unsunk. -/
theorem stock_atomic_extension_both_source_calls_witness  :
    ∃ (f : Clif.Function) (ctx : Ctx) (ranges : Array (Nat × Nat))
      (initial before after : State) (rootInfo direct indirect : IInfo)
      (value : V) (trace : List RuleId),
      LowerScope f ∧ Dominated f ∧ ArityOk f ∧ AbiSigsOk f ∧
      Stock.buildCtx f = .ok (ctx,ranges,initial) ∧ MappedCtxInv f ctx ∧ Clean (sourceIdentityCtx ctx) ∧
      ctx.insts[1]? = some rootInfo ∧
      rootInfo.clif = some (.extend (if false then .sextend else .uextend) .i64 2) ∧
      ctx.insts[2]? = some direct ∧ direct.clif = some (.call 0 []) ∧
      ctx.insts[3]? = some indirect ∧ indirect.clif = some (.callIndirect 0 3 []) ∧
      Stock.runTerm ctx "lower" [.inst 1] before = .ok (some value,after,trace) ∧
      after.sunk[0]! = true ∧ before.sunk[2]! = false ∧ before.sunk[3]! = false ∧
      after.sunk[2]! = before.sunk[2]! ∧ after.sunk[3]! = before.sunk[3]! ∧ trace.getLast? = some 810 := by
  have observation := named_actual
  unfold namedObserved at observation
  cases run : Stock.runTerm (built false).1 "lower" [.inst 1] (input false) with
  | error e => simp only [run] at observation; cases observation
  | ok q =>
    obtain ⟨out,after,trace⟩ := q
    cases out with
    | none => simp only [run,Option.isSome_none,Bool.false_and] at observation; cases observation
    | some value =>
      simp only [run,Option.isSome_some,Bool.true_and,Bool.and_eq_true,Bool.not_eq_true',decide_eq_true_eq] at observation
      have mapped := buildCtx_mappedInv (scope false) (build false)
      have root : (built false).1.insts[1]? = some (built false).1.insts[1]! := by cases false <;> rfl
      have rootClif : (built false).1.insts[1]!.clif =
          some (.extend (if false then .sextend else .uextend) .i64 2) := by cases false <;> rfl
      have direct : (built false).1.insts[2]? = some (built false).1.insts[2]! := by cases false <;> rfl
      have directClif : (built false).1.insts[2]!.clif = some (.call 0 []) := by cases false <;> rfl
      have indirect : (built false).1.insts[3]? = some (built false).1.insts[3]! := by cases false <;> rfl
      have indirectClif : (built false).1.insts[3]!.clif = some (.callIndirect 0 3 []) := by cases false <;> rfl
      have directFrame := CallSinkRootsDraft.stock_statement_preserves_direct_source_call
        mapped (clean false) direct directClif root rootClif run
      have indirectFrame := CallSinkRootsDraft.stock_statement_preserves_indirect_source_call
        mapped (clean false) indirect indirectClif root rootClif run
      refine ⟨function false,(built false).1,(built false).2.1,(built false).2.2,input false,
        after,_,_,_,value,trace,scope false,dominated false,arity false,abi false,build false,
        mapped,clean false,root,rootClif,direct,directClif,indirect,indirectClif,run,
        observation.1.1.1,?_,?_,directFrame,indirectFrame,observation.2⟩
      all_goals decide +kernel
end Backend.Stock.Proof.AtomicExtensionWitnessDraft
