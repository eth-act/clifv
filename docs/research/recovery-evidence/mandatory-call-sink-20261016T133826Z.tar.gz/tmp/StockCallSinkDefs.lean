import FV.Backend.Proof.StockSourceSinkTable
namespace Backend.Stock.Proof.CallSinkDraft
open Backend.Proof Backend.Proof.Cov Isle Isle.Interp Isle.Aarch64
/-- Semantic oracle for the actual atomic-load helper only. -/
def callSinkOracle (t : TermId) (as : List AW) : Option AW :=
  if t == 564 then (match as with | [.xv .inst] => some (.reg 1) | _ => none) else aOracle t as
def callSinkTab : Tab := sourceSinkTab.filter (fun e => e.1 != 564)
def callSinkPre (t : TermId) (as : List AW) : Bool := sourceSinkPre t as && t != TId.sink_inst
def callSinkEntryOk (e : TermId × List AW × AW) : Bool :=
  let e := sourceSinkEntry e
  !(e.1 != 564) || (program.rulesOf e.1).all
    (aRule program callSinkTab aext sourceSinkActor callSinkPre callSinkOracle e.2.1 e.2.2)
end Backend.Stock.Proof.CallSinkDraft
