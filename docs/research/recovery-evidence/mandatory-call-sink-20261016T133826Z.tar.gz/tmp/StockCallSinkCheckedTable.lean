import StockCallSinkPart0
import StockCallSinkPart1
import StockCallSinkPart2
import StockCallSinkPart3
import StockCallSinkPart4
import StockCallSinkPart5
import StockCallSinkPart6
import StockCallSinkPart7
namespace Backend.Stock.Proof.CallSinkDraft
open Backend.Proof Backend.Proof.Cov Isle Isle.Interp Isle.Aarch64
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
attribute [local irreducible] Isle.Aarch64.program
/-- All retained summaries check with raw sinking forbidden. The kernel
checks the original table partitions separately to bound peak memory. -/
theorem stock_callSink_table_checked :
    chkTab program callSinkTab aext sourceSinkActor callSinkPre callSinkOracle = true := by
  unfold chkTab callSinkTab sourceSinkTab
  simp only [List.all_filter,List.all_map]
  change covTab.all callSinkEntryOk = true
  simp only [covTab,List.all_append,call_table_0_checked,call_table_1_checked,call_table_2_checked,call_table_3_checked,call_table_4_checked,call_table_5_checked,call_table_6_checked,call_table_7_checked,Bool.and_self]
end Backend.Stock.Proof.CallSinkDraft
