import StockCallSinkDefs
namespace Backend.Stock.Proof.CallSinkDraft
open Backend.Proof Backend.Proof.Cov Isle Isle.Interp Isle.Aarch64
def callSinkRootOk (r : Rule) : Bool :=
  !closureRootIds.contains r.id || r.id == 815 || r.id == 824 ||
    aRule program callSinkTab aext sourceSinkActor callSinkPre callSinkOracle [.xv .inst] AW.top r
end Backend.Stock.Proof.CallSinkDraft
