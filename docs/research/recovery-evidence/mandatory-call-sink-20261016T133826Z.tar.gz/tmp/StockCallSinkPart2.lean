import StockCallSinkDefs
namespace Backend.Stock.Proof.CallSinkDraft
open Backend.Proof Backend.Proof.Cov Isle Isle.Interp Isle.Aarch64
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
attribute [local irreducible] Isle.Aarch64.program
/-- Fixed table partition checked in its own bounded kernel invocation. -/
theorem call_table_2_checked : covTab2.all callSinkEntryOk = true := by
  decide +kernel
end Backend.Stock.Proof.CallSinkDraft
