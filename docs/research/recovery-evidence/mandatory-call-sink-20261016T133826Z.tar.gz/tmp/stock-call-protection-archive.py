from pathlib import Path
import os,json,datetime,hashlib,tarfile,io
os.nice(10)
root=Path('/home/lee/clifv/.worktrees/driver-proof-resume');stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');dest=Path('/home/lee/.clifv-recovery')/(stamp+'-call-protection');dest.mkdir()
r=json.loads((root/'docs/research/stock-call-protection-scratch.json').read_text());previous=json.loads((root/'docs/research/stock-mandatory-call-sink-backup.json').read_text())
files=[Path(p) for k in ['new_scratch_sources','new_compiled_modules','new_compiled_logs'] for p in r[k]]
files += [root/p for p in ['AGENTS.md','docs/plans/test-binary-alignment-recovery.md','docs/research/stock-full-goal-current.md','docs/research/stock-call-protection-scratch.json','docs/research/stock-call-protection-scratch.md','docs/research/cleanup-discipline-current.json','docs/research/cleanup-comparison-results-current.json','docs/research/stock-outgoing-audit-review.json','docs/research/stock-coherent-integration.json','docs/research/stock-mandatory-call-sink-backup.json']]
files += [Path('/tmp',p) for p in ['stock-call-protection-batch.json','stock-call-protection-axioms.lean','stock-call-protection-axioms.log','stock-call-protection-evidence.py','stock-call-protection-archive.py','stock-call-protection-resource-journal.log','stock-coherent-build-inputs.json','stock-coherent-serial-progress.json','stock-coherent-serial-build.py','stock-outgoing-all-axioms.lean','stock-outgoing-all-axioms.log','stock-outgoing-new-roots.json','stock-outgoing-audit-differences.json','stock-outgoing-validation-progress.json','stock-mandatory-candidate-progress.json','stock-mandatory-candidate-build.py','stock-mandatory-candidate-resume.py','stock-mandatory-candidate-resume2.py','stock-mandatory-candidate-resume3.py','stock-mandatory-candidate-resume4.py','stock-mandatory-candidate-resume5.py','stock-mandatory-candidate-resume6.py','StockPureSinkModel-before-bool-fix.txt','StockCallSinkModel-before-bool-fix.txt','StockCallSinkTable-before-partitions.txt','StockCallSinkTable-before-root-split.txt']]
review=json.loads((root/'docs/research/stock-outgoing-audit-review.json').read_text())
for m in review['modules']:
 files +=[Path('/tmp',m+'.lean'),Path('/tmp',m+'.olean')]
files+=[Path('/tmp/stock-call-outgoing-witness.log')]
# Keep the preceding complete source/kernel/gate recovery chain recoverable.
a=json.loads((root/'docs/research/stock-mandatory-call-sink-backup.json').read_text())
def paths_with_archives(o):
 if isinstance(o,dict):
  for k,v in o.items():
   if isinstance(v,str) and v.startswith('/home/lee/.clifv-recovery/') and v.endswith(('.tar.gz','.tar.zst')):yield Path(v)
   elif isinstance(v,(dict,list)):yield from paths_with_archives(v)
 elif isinstance(o,list):
  for v in o:yield from paths_with_archives(v)
files+=list(paths_with_archives(a));assert list(paths_with_archives(a)),'previous archive path missing'
files=sorted(set(files));captured=[]
archive=dest/'checkpoint.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=1) as t:
 for p in files:
  data=p.read_bytes();name=str(p).lstrip('/');meta=tarfile.TarInfo(name);meta.size=len(data);meta.mtime=int(p.stat().st_mtime);meta.mode=0o644;t.addfile(meta,io.BytesIO(data));captured.append({'path':str(p),'member':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with tarfile.open(archive,'r:gz') as t:
 for row in captured:
  f=t.extractfile(row['member']);h=hashlib.sha256();size=0
  for data in iter(lambda:f.read(1048576),b''):h.update(data);size+=len(data)
  assert h.hexdigest()==row['sha256'] and size==row['bytes'],row['path']
r={'utc':stamp,'archive':str(archive),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'members':len(captured),'every_member_verified':True,'captured':captured}
(dest/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');Path('/tmp/stock-call-protection-archive-result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='captured'}))
