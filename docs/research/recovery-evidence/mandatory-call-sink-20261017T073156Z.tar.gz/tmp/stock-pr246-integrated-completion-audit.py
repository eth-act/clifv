from pathlib import Path
import json,subprocess as sp,hashlib,re,os,datetime
canon=Path('/home/lee/clifv/.worktrees/driver-proof-resume');view=Path('/home/lee/clifv/.worktrees/stock-delivery-gates');expected='088111278aecc094fc87937525b79cba2e88b8b3';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();now=datetime.datetime.now(datetime.timezone.utc).isoformat()
r=json.loads(Path('/tmp/stock-pr246-gates-receipt.json').read_text());lease=json.loads(Path('/tmp/stock-delivery-cache-lease.json').read_text());assert lease['state']=='held_for_review' and lease['pr']==246
assert sp.check_output(['git','rev-parse','HEAD'],cwd=view,text=True).strip()==expected and r['commit']==expected
assert not sp.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=view,text=True).strip()
manifest=json.loads(Path('/tmp/stock-pr246-gates-inputs.json').read_text());assert {str(p.relative_to(view)):sha(p) for d in ['FV','FVTest'] for p in (view/d).rglob('*.lean')}==manifest['sources']
for p,h in manifest['scripts'].items():assert sha(view/p)==h,p
for kind in ['full','crates','axioms','runtime','encoder','e2e','legacy-e2e']:
 log=r['logs'][kind];assert sha(log['path'])==log['sha256'],kind
 if kind in ['full','crates']:assert 'Build completed successfully' in Path(log['path']).read_text()
counts={}
for label in ['e2e','legacy-e2e']:
 text=Path(r['logs'][label]['path']).read_text();rejected=[int(n) for n in re.findall(r'\b(\d+) rejected\b',text)];rejects=[int(n) for n in re.findall(r'\brejects (\d+)\b',text)];fails=[int(n) for n in re.findall(r'\b(\d+) fail\b',text)];assert len(rejected)>=3 and len(rejects)>=3 and len(fails)>=5
 assert all(n==0 for n in rejected+rejects+fails),(label,rejected,rejects,fails)
 assert re.search(r'lowerCheck: 1[1-9]\d\d accepted, 0 rejected',text)
 info=r['identities'][label];assert sha(info['path'])==info['sha256'];base=json.loads(Path(info['baseline']).read_text());new=json.loads(Path(info['path']).read_text());key=lambda d:(d['file'],d['index'],d['function']);oldmap={key(d):d['stages'] for d in base['functions']};newmap={key(d):d['stages'] for d in new['functions']};assert len(oldmap)==1150
 assert all(newmap.get(k)==v for k,v in oldmap.items());counts[label]={'all_rejection_and_failure_summaries_zero':True,'original_identity_stage_lists_preserved':1150,'current_identities':len(newmap),'byte_identical':info['byte_identical']}
core=json.loads(Path('/tmp/stock-delivery-core-paths.json').read_text());selected=[p for p in core['paths'] if p.endswith('.lean')]
for p in selected:
 text=(view/p).read_text();assert not re.search(r'\b(sorry|admit|trace_state)\b',text),p
 assert not re.search(r'^\s*(?:private\s+)?axiom\s+',text,re.M),p
# Audit ALL declared constants, including private helpers and proof-valued data,
# rather than only theorem declarations, in each changed Lean module.
mods=[p[:-5].replace('/','.') for p in selected];smoke=Path('/tmp/stock-delivery-audit-smoke.lean').read_text();body=smoke[smoke.index('open Lean'):].replace('#["FV.Clif.Syntax"]','#[ '+','.join(json.dumps(m) for m in mods)+' ]').replace('if !info.isTheorem || name.toString.startsWith "_private." || name.isInternal then continue','if false then continue').replace('logInfo m!"DELIVERY_AXIOMS {name} {Json.compress (toJson (axioms.map Name.toString))}"','logInfo m!"DELIVERY_CONSTANT {Json.compress (toJson (name.toString, axioms.map Name.toString))}"')
audit=Path('/tmp/stock-pr246-all-constants-axioms.lean');audit.write_text('import Lean\n'+'\n'.join('import '+m for m in mods)+'\n'+body);log=Path('/tmp/stock-pr246-all-constants-axioms.log');env=dict(os.environ,OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',FV_MEMCAP='22G')
with log.open('w') as out:sp.run([str(canon/'scripts/memcap.sh'),'/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin/lake','env','lean','--root=/tmp',str(audit)],cwd=view,env=env,stdout=out,stderr=sp.STDOUT,check=True)
text=log.read_text();assert not re.search(r'error[:(]',text);actual={n:sorted(v) for n,v in (json.loads(row) for row in re.findall(r'DELIVERY_CONSTANT (\[[^\n]*\])',text))};assert len(actual)==int(re.search(r'DELIVERY_AXIOM_COUNT (\d+)',text)[1]);std={'propext','Classical.choice','Quot.sound'};native={n:a for n,a in actual.items() if set(a)-std};assert not any('sorryAx' in a for a in actual.values())
priorText=Path('/tmp/stock-body-form-axioms.log').read_text();prior={m.group(1):sorted(x.strip() for x in m.group(2).split(',') if x.strip()) for m in re.finditer(r"'([^']+)' depends on axioms:\s*\[([^]]*)\]",priorText)};prior.update({n:[] for n in re.findall(r"'([^']+)' does not depend on any axioms",priorText)})
changed={n:{'before':a,'after':actual[n]} for n,a in prior.items() if n in actual and actual[n]!=a}
pr=json.loads(sp.check_output(['gh','pr','view','246','--json','headRefOid,baseRefOid,state,isDraft,statusCheckRollup'],cwd=view,text=True));assert pr['headRefOid']==expected and pr['baseRefOid']=='789152e24d12c8ff17c5caededd016800e781c31';assert pr['state']=='OPEN'
assert len(pr['statusCheckRollup'])==3 and all(c['conclusion']=='SUCCESS' for c in pr['statusCheckRollup'])
result={'utc':now,'pr':246,'commit':expected,'all_required_local_gate_logs_verified':True,'all_E2E_rejection_fail_summaries_zero_and_identity_stage_parity':counts,'all_changed_Lean_source_scans_pass':True,'all_constant_count':len(actual),'all_constant_audit':{'path':str(log),'sha256':sha(log),'roots':actual},'nonstandard_sets_requiring_explicit_review':native,'earlier_exact_set_changes_requiring_explicit_review':changed,'current_main_base_and_all3CIchecks_verified':True,'success_pending_MCP_provenance_review':not native and not changed,'MCP':'Review historical source-matching receipts separately; no fresh MCP is claimed here','production':'legacy; full#140 not complete'}
Path('/tmp/stock-pr246-completion-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='all_constant_audit'}))
