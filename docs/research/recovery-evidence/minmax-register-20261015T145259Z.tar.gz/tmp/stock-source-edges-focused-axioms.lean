import FV.Backend.Proof.StockSourceEdgesWitness
#print axioms Backend.Stock.Proof.source_defined_enterBlock
#print axioms Backend.Stock.Proof.source_defined_branch_step
#print axioms Backend.Stock.Proof.SourceEdgesWitness.stock_source_edge_defined_witness
