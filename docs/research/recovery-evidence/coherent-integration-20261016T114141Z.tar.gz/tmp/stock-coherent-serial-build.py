from pathlib import Path
import subprocess as sp,os,json,datetime,hashlib,re,traceback
root=Path('/home/lee/clifv/.worktrees/driver-proof-resume');os.chdir(root);data=json.loads(Path('/tmp/stock-coherent-build-inputs.json').read_text());affected=set(data['affected']);done=set();order=[]
def visit(m):
 if m in done:return
 done.add(m)
 for d in data['imports'][m]:
  if d in affected:visit(d)
 order.append(m)
for m in sorted(affected):visit(m)
progress=Path('/tmp/stock-coherent-serial-progress.json');logs={};now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
env=dict(os.environ,OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',FV_MEMCAP='22G');lake='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin/lake';assert sp.check_output(['nproc'],env=env,text=True).strip()=='2'
def report(state,**kw):
 d={'state':state,'pid':os.getpid(),'utc':now(),'total':len(order),'completed_modules':len(logs),**kw};progress.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)
def frozen():
 current={str(p):sha(p) for t in ['FV','FVTest'] for p in Path(t).rglob('*.lean')};assert current==data['source_sha256'],'canonical source freeze changed'
 for p,h in data['validation_script_sha256'].items():assert sha(p)==h,p
try:
 frozen()
 for i,m in enumerate(order):
  cap='32G' if m=='FV.Backend.Proof.StockCmpWithFlags' else '22G';env['FV_MEMCAP']=cap
  log=Path('/tmp/stock-coherent-build-'+m+'.log');report('running',index=i+1,current=m,log=str(log),memcap=cap)
  with log.open('w') as out:result=sp.run(['scripts/memcap.sh',lake,'build',m],env=env,stdout=out,stderr=sp.STDOUT)
  assert result.returncode==0 and 'Build completed successfully' in log.read_text(),f'{m} rc={result.returncode} log={log}'
  logs[m]={'path':str(log),'sha256':sha(log)}
 frozen();report('normal_audit',current='2182public roots plus4legacy bases')
 env['FV_MEMCAP']='22G';log=Path('/tmp/stock-coherent-all-axioms.log')
 with log.open('w') as out:sp.run(['scripts/memcap.sh',lake,'env','lean','--root=/tmp','/tmp/stock-coherent-all-axioms.lean'],env=env,stdout=out,stderr=sp.STDOUT,check=True)
 text=log.read_text();assert not re.search(r'error[:(]',text)
 actual={m.group(1):sorted(x.strip() for x in m.group(2).split(',') if x.strip()) for m in re.finditer(r"'([^']+)' depends on axioms:\s*\[([^]]*)\]",text)};actual.update({n:[] for n in re.findall(r"'([^']+)' does not depend on any axioms",text)})
 expected=json.loads(Path('/tmp/stock-coherent-expected-axioms.json').read_text());changed={n:{'before':a,'after':actual.get(n)} for n,a in expected.items() if actual.get(n)!=a};assert set(expected)<=set(actual)
 frozen();receipt={'utc':now(),'success':not changed,'serial_targets':order,'logs':logs,'normal_audit':{'path':str(log),'sha256':sha(log),'roots':{n:actual[n] for n in expected},'changed_exact_sets':changed},'source_manifest':'/tmp/stock-coherent-build-inputs.json','source_freeze_verified':True,'heavy_kernels_concurrent':1,'effective_nproc':2,'upstream':data['upstream'],'MCP':'pending ONE bundled190root call','full_gates':'pending','full_goal':'active/incomplete; production legacy'};Path('/tmp/stock-coherent-build-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');report('audit_review' if changed else 'complete',changed_exact_sets=len(changed),receipt='/tmp/stock-coherent-build-receipt.json')
except BaseException as e:
 report('failed',error=repr(e),logs=logs,traceback=traceback.format_exc());raise
