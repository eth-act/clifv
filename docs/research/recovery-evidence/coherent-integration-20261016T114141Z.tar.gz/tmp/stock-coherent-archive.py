from pathlib import Path
import os,datetime,json,hashlib,tarfile,io,shutil
os.nice(10);root=Path('/home/lee/clifv/.worktrees/driver-proof-resume');stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');dest=Path('/home/lee/.clifv-recovery')/(stamp+'-coherent-integration');dest.mkdir()
q=json.loads((root/'docs/research/stock-coherent-integration.json').read_text());up=json.loads((root/'docs/research/stock-upstream-reconciliation.json').read_text());got=json.loads((root/'docs/research/stock-got-source-scratch-backup.json').read_text())
files=[root/p for p in q['sources']]+[root/p for p in ['AGENTS.md','scripts/agent-worktree.sh','docs/research/stock-coherent-integration.json','docs/research/stock-coherent-integration.md','docs/research/stock-upstream-reconciliation.json','docs/research/stock-got-source-scratch-backup.json','docs/research/stock-got-source-scratch.json','docs/research/stock-got-source-scratch.md','docs/research/stock-body-form-checkpoint.json','docs/research/stock-full-goal-current.md','docs/plans/test-binary-alignment-recovery.md','docs/research/cleanup-discipline-current.json']]
files += [Path('/tmp')/p for p in ['stock-coherent-serial-build.py','stock-coherent-build-inputs.json','stock-coherent-serial-progress.json','stock-coherent-all-axioms.lean','stock-coherent-expected-axioms.json','stock-upstream-reconcile.py','stock-upstream-reconciliation-paths.json','stock-body-form-terminal-verified.json','stock-coherent-archive.py']]
files += [Path(up['archive']),Path(got['archive']['path'])]
snap={str(p).lstrip('/'):p.read_bytes() for p in files};manifest={'utc':stamp,'files':{p:hashlib.sha256(b).hexdigest() for p,b in snap.items()},'goal':'#140 active/incomplete; production legacy','state':'110modules190roots canonical, upstream032d5764 reconciled;1930-target bounded serial rebuild running;2182-root audit/ONE190MCP/full gates pending','all_prior_scratch_and_terminal_baseline_evidence':'nested byteverified archive included'};snap['archive-manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
archive=dest/'checkpoint.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=1) as t:
 for n,b in snap.items():
  info=tarfile.TarInfo(n);info.size=len(b);t.addfile(info,io.BytesIO(b))
with tarfile.open(archive,'r:gz') as t:assert {m.name:t.extractfile(m).read() for m in t.getmembers()}==snap
r={'utc':stamp,'path':str(archive),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'members':len(snap),'every_member_byte_verified':True};(dest/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');Path('/tmp/stock-coherent-archive-receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
# A rejected pre-mutation reconciliation created an empty directory; remove only that empty task directory.
removed=[]
for p in Path('/home/lee/.clifv-recovery').glob('20261016T1139*-upstream-reconciliation'):
 if p.is_dir() and not any(p.iterdir()):p.rmdir();removed.append(str(p))
print('Empty task directories removed',removed,'free GiB',round(shutil.disk_usage(root).free/2**30,1))
