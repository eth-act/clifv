from pathlib import Path
import subprocess as sp,json,hashlib,datetime,tarfile,io,stat
root=Path('/home/lee/clifv/.worktrees/driver-proof-resume');q=json.loads(Path('/tmp/stock-upstream-reconciliation-paths.json').read_text());up=q['upstream'];base=q['base'];sha=lambda b:hashlib.sha256(b).hexdigest()
def blob(ref,n):
 p=sp.run(['git','show',ref+':'+n],cwd=root,capture_output=True);return p.stdout if p.returncode==0 else None
now=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');dest=Path('/home/lee/.clifv-recovery')/(now+'-upstream-reconciliation');dest.mkdir()
changes={};snap={}
for n in q['safe_upstream_updates']:
 p=root/n;old=p.read_bytes() if p.is_file() else None;assert old==blob(base,n),n
 new=blob(up,n)
 changes[n]={'before':sha(old) if old is not None else None,'upstream':sha(new) if new is not None else None}
 if old is not None:snap['before/'+n]=old
 if new is not None:snap['upstream/'+n]=new
for n in q['both_differ']:
 snap['local-preserved/'+n]=(root/n).read_bytes();snap['upstream-variant/'+n]=blob(up,n)
n='FV/Backend/Proof/StockReturnSourceWitness.lean';old=blob(up,n).decode();ours=(root/n).read_text();body=old[old.index('namespace '):old.rindex('end Backend.Stock.Proof.ReturnSourceWitness')];assert body in ours,'upstream witness body changed'
with tarfile.open(dest/'checkpoint.tar.gz','w:gz',compresslevel=1) as t:
 for n,b in snap.items():
  info=tarfile.TarInfo(n);info.size=len(b);t.addfile(info,io.BytesIO(b))
with tarfile.open(dest/'checkpoint.tar.gz','r:gz') as t:assert {m.name:t.extractfile(m).read() for m in t.getmembers()}==snap
for n in q['safe_upstream_updates']:
 p=root/n
 if changes[n]['upstream'] is None:
  p.unlink();continue
 p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(snap['upstream/'+n])
 mode=sp.check_output(['git','ls-tree',up,'--',n],cwd=root).decode().split()[0];p.chmod(0o755 if mode=='100755' else 0o644)
for n in q['safe_upstream_updates']:
 assert (sha((root/n).read_bytes()) if (root/n).exists() else None)==changes[n]['upstream']
for n in q['both_differ']:assert (root/n).read_bytes()==snap['local-preserved/'+n]
r={'utc':now,'upstream':up,'merge_base':base,'safe_published_updates':changes,'both_differ_local_preserved':q['both_differ'],'source_overlap_upstream_body_preserved_with_local_additions':True,'archive':str(dest/'checkpoint.tar.gz'),'archive_sha256':sha((dest/'checkpoint.tar.gz').read_bytes()),'every_member_byte_verified':True,'unique_stock_sources_and_old_variants':'preserved','head_index':'unchanged','validation':'pending rebuild/audit/full gates under reconciled upstream'}
(root/'docs/research/stock-upstream-reconciliation.json').write_text(json.dumps(r,indent=2)+'\n');print('Reconciled',len(changes),'published upstream paths;11local variants preserved;archive',dest)
