# Current work: Stock production delivery (#140)

Updated UTC: 2026-10-21T07:25:27.471291+00:00. **Active. Full original #140 is unfinished.** Owner: @codygunton and this agent.

## Actual shipped state and first landing

Main `08020ed34bea4a3656c1b080c55087da40f2ebbe` ships D0 parameter-return, six prologue configurations and scalar-add (#328–#336), with legacy fallback. General arithmetic, Mixed and the next logical class are not activated. No new author PR is open yet.

First landing: `agent/stock-arithmetic-arm-model-20261021T001904Z`, frozen and remote-verified `672c4dc4820b31c477a5e075926c72cd2b267dd8`, in `.worktrees/stock-driver-incremental`. Current-Arm author controller `1235132` and scheduler `1235140` are live; phase `all-modules`. Evidence: `/tmp/stock-arithmetic-arm-model-author-gates/progress.json`; terminal readiness checker `/tmp/stock-arithmetic-arm-model-ready-to-land.py`. All current FV/FVTest keys, affected tools, all named/dynamic activation gates, runtime/encoding, both identity/stage reports, owned/public/previous axiom sets, generated/link proofs and verified fv-demo/survey remain required. Partial module records are not a full gate pass. No restart for observation expiry.

Retained-theorem source preflight: all34 old theorem headers in the five modified existing Lean files are unchanged; no existing FV/FVTest Lean file is deleted. Receipt `/tmp/stock-arithmetic-arm-model-author-gates/retained-theorem-source-preflight.json`. This literal source comparison does not replace normal elaboration or AX parity.

Recent normal successes: wide min/max driver207s; wide constant driver833s/9.3GiB; RegallocCover133s; scalar-select driver412s/8.7GiB; KillTab604s; try-call shape583s; total shape277s/7.6GiB; call shape166s. No current module failure recorded. Source-routing preflight confirms the actual compiler/checker/linker/generated consumers use paired NI validation; the retained non-NI variant is not the default route.

After terminal gates: fetch/reconcile main, write exact source/validation receipt, open a substantive non-draft implementation PR, author squash promptly under the adopted per-PR policy (no CI wait), verify squash tree, notify #261/#140. Then Mixed, then logical and remaining classes. Next is tentative, not a reservation.

## Next-class source: precise validation boundary

`.worktrees/stock-mixed-production` currently checks out **logical**, not Mixed: `agent/stock-logical-current-model`, remote-verified `f3a5527c6a420c7ee74d9a6ff97d14e6a92b2724`.

Verified EXTR packet at1827ff05: nine current-model semantic modules normal-pass; six general roots exactly Std3. Actual checked-in RootWitness normal-passes its440-module closure, all24 real pipeline configurations and arbitrary-word first-match/retained-record/original-source witnesses. One transitive MCP source-witness check passes without warnings; fixed witnesses add only declared native checks. Atomic6GiB attempt hit its cap; same scheduler's12GiB retry passed1145s/9.6GiB. All old theorem variants retained. This is not logical function activation or a full obsolete777-node pass.

**Pending normal validation:** complete eleven-root logical source dispatch, scan/body/source-execution composition; actual ABI entry/return proof and arbitrary-word OR witness(e6f366dd); all-fuel nontrapping outcome/witness(fbe184ef); executable ordinary i32/i64 select/add/sub/AND/OR/XOR source/provenance checker, soundness and nonempty whole-driver witness(f3a5527c). No default route changed. Normal targets: `StockLogicalSourceWitness`, `StockLogicalReturnWitness`, `StockLogicalNotrapWitness`, `StockLogicalCheckWitness`; audit `scripts/audit/stock-logical-complete-values.lean`. Do not delay the arithmetic landing for this next packet.

Mixed source is preserved remotely on `agent/stock-mixed-arm-model-20261021T003711Z` at `bbcdf080a43d340087692da65828c8a36762f795`, no separate checkout. Prior old-model branch `agent/stock-mixed-production-current-main` at11a57ca6 preserves366 distinct normal module passes, exact48positive+2negative runtime cases and fresh24-object/input parity with the prior624-call native grid(not624 new executions). Current-model Mixed normal/integration/consumer/AX/identity/example gates remain pending; reconcile onto actual arithmetic squash first. Existing `scripts/check-stock-mixed-integration.py` covers linked33-function/sliced/current/retained/generated consumers.

## Coordination and complete remaining scope

#140 remains our claimed task. Contributor statuses#52/#71 read; stale is uncertain, not a reservation. Shared Arm/TPIDR/MInst/Cov boundary request to @kevaundray remains at [#140 coordination comment](https://github.com/eth-act/clifv/issues/140#issuecomment-6304759270). No shared model/runtime edit or TLS/overflow/FP expansion is claimed by this integer packet. Pause only concrete conflicting work.

Keep original input conditions, theorem variants, required axiom sets(≥1181 prior roots), accepted identities(original1150/prior1159) and successful ordered stages. Continue through uncovered families/effects, omitted/sunk instructions, memory/traps/calls/CFG, original-source/block/whole-driver simulation, Stock-only completeness, optimizer/unwind and actual compiler/checker/linker/generated-proof production integration. Neither a proof fragment nor the first class completes the goal. Follow `docs/plans/stock-driver-incremental-delivery.md` and preserved recovery plan.

Current-main full-gate39519636227 is terminal red from shard6 `leantar` assertion/exit101, not a Lean theorem diagnostic. Reused938 verified current-CI output keys in the existing store; no compiler swap. RegallocLemmas exact key7f930049350db887 now prefers current-CI1b128...; only the inactive logical view's old saved trace was archived/quarantined. Normal current-key materialization succeeded; aligned logical replay/new packet validation remains pending. Do not reopen retired old-model/prealignment controllers or claim their unfinished full epochs passed.

## Worktree/cache ownership and preservation

All five views owned by @codygunton for these purposes; no new tree/cache:

- `/home/lee/clifv`: user's dirty primary; preserve.
- `.worktrees/driver-proof-resume`: canonical1874 dirty saved paths at01081291; shared artifact store/Rust target; never overwrite/stash.
- `.worktrees/stock-lowering`: dirty saved source; preserve.
- `.worktrees/stock-driver-incremental`: frozen arithmetic author gates.
- `.worktrees/stock-mixed-production`: logical next-class source/import view; Mixed branch preserved remotely.

One physical artifact cache at `.worktrees/driver-proof-resume/.lake/artifact-cache`; other build views use hardlinks. Aggregate16GiB/max2 actual compiler jobs, OMP threads2, all Lake/cargo through memcap; no proof wall timeout/pattern kill. Last free space763GiB. Remove unneeded clean worktrees/obsolete artifacts at batch completion after archiving unique evidence; preserve dirty/unpublished source and recovery backups. Completed helper scripts and temporary duplicate toolchain/download staging have been removed.

Latest recovery branch head: **9927222da5b15737d1d9f8dfebda70c2aa15d9c5** on `agent/stock-driver-wip-backup-20261021T061345Z`, remote commit/blob verified. Contains core44cf348e, exact original inputs43ec2f64, pending extra runtime source6f11d760 and readiness guard9927222d. All active worktree HEADs/indexes unchanged; supplemental runtime remains unexecuted.

Core remote recovery snapshot: `agent/stock-driver-wip-backup-20261021T061345Z` at `44cf348e773856a7534df9fc58fd38e317752edc`, remote commit/all blobs verified. Preserves1874 dirty paths plus784 completed current module records, controls, source hashes and the **entire prior37KB status history before this consolidation**, including old handoffs/evidence references. Archive `/tmp/stock-status-consolidation-recovery-20261021T061345Z/evidence.tar.gz`, SHA256 `e81fabb5e87a98a273059ee2536a03b6beb63cfe4415302f0ef1f7c81623e1bd`,1580 paths/4,971,134bytes. Canonical HEAD/index unchanged. Earlier complete EXTR/handoff backupef7bc0bc and partial current backupcfd0e447 remain remote. This backup is not merge-ready validation.

Recovery index: `/tmp/stock-current-resume.json`.




Gate-input repair 2026-10-21T06:26:03.573840+00:00: static preflight found both original `/tmp/legacy-dead-cleanup-final*-identities.json` paths missing. Restored byte-exact from retained reports using preserved receipt hashes8cdc10dc.../c6073d7d...; no current-run regeneration/filtering/baseline change. All8 helpers target arithmetic view,8 static inputs exist, original1150/prior1159 reports and1181 prior AX roots are present. Receipts: `original-identity-baseline-restoration.json`, `external-gate-input-preflight.json`, `gate-input-restoration-backup.json` under current gate root. Exact inputs/raw prior AX logs/helper sources/preflights remotely backed up as **43ec2f64613dbb787740287bbb722f054fb0a3eb**, fast-forward child of44cf348e on the same recovery branch; archive /tmp/stock-arithmetic-gate-input-recovery-20261021T062524Z/evidence.tar.gz SHA256 f306b689e200530341799305f7cb78e96c9e0d91bc70b1fcc4a6ebcd1d64c9b7 (55paths/90,744bytes). Canonical/frozen HEADs and real indexes unchanged; live author1235132/scheduler1235140 and kernel4160724 preserved(10m18s observed). No gate pass or merge claimed.





Supplemental validation prepared 2026-10-21T06:41:27.282570+00:00: `/tmp/StockArithmeticCommittedRoute.lean` (SHA256c370fc8cafbe994d6af73a1c4d367b484e6d4d38ac7c0ece33c04fd637665a32) checks actual raw Stock at allocation, exactly one positive allocation attempt, and all emitted artifacts/stages for6configurations×2cleanup×2allocators. Run normally after current strict real-oracle runtime gate/full author gates, before landing; expected24 pass lines. This prevents a silent complete-attempt fallback from masquerading as a positive compiler activation. Existing linked fixtures already assert nonlegacy raw code and ELF code-table agreement; CLI checks require successful Stock attempt. Extra harness is **prepared, not executed/passed**; frozen672c4dc4 source/controller unchanged. Receipt `committed-route-extra-gate.json` under gate root.

















Latest live arithmetic observation: 2026-10-21T07:25:27.471291+00:00: DefGenTab1262703 passed841s/3.5GiB; original author1235132/scheduler1235140 continue actual StockCastWitness under13GiB cap after cached RuleExtends2. 866 completed current records, 0 nonzero. Frozen672c4dc4 unchanged; extra committed-route check prepared/not run, logicalf3a5527c normal validation pending. No restart/source change/merge.
