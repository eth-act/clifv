from pathlib import Path
s=Path('FV/Backend/Proof/StockAllocationFlow.lean').read_text();s=s[:s.index('private def outputSig')]
s=s.replace('namespace Backend.Stock.Proof','namespace Backend.Stock.Proof.OutgoingDraft').replace('AllocationLe','OutgoingLe').replace('allocationLe','outgoingLe')
a=s.index('def OutgoingLe');b=s.index('private theorem marks_fields',a)
s=s[:a]+'''def OutgoingLe (st next : State) : Prop := st.base.outgoing ≤ next.base.outgoing
private theorem allocation_refl (st : State) : OutgoingLe st st := Nat.le_refl _
private theorem allocation_trans {a b c : State} (ab : OutgoingLe a b) (bc : OutgoingLe b c) :
    OutgoingLe a c := Nat.le_trans ab bc
private def fields (st : State) := st.base.outgoing
private theorem fields_rel {st next : State} (h : fields next = fields st) :
    OutgoingLe st next := Nat.le_of_eq h.symm
''' +s[b:]
s=s.replace('exact ⟨(externCtor_ok ctx t args st.base _ _ call).vreg, rfl⟩','exact (externCtor_ok ctx t args st.base _ _ call).out')
s=s.replace('base.nextVreg ≤ (returns.foldl','base.outgoing ≤ (returns.foldl').replace('(regs, base)).2.nextVreg','(regs, base)).2.outgoing')
s=s.replace('⟨Nat.le_refl _, rfl⟩','Nat.le_refl _').replace('exact ⟨output_frontier _ [] st.base, rfl⟩','exact output_frontier _ [] st.base')
s=s.replace('/-! Actual stock evaluation preserves preallocated exception reservations and\nnever moves the fresh-register frontier backwards. -/','/-! Actual Stock evaluation never decreases its outgoing argument area. -/').replace('/-- The allocation frontier grows, while reserved exception registers stay fixed. -/','/-- The actual outgoing area grows monotonically. -/').replace('/-- All successful actual constructors preserve reservations and increase the\nfresh frontier, including try-call alias installation and explicit call outputs. -/','/-- Actual constructors never decrease the outgoing area. -/').replace('/-- Full actual term evaluation preserves reservations and a monotone frontier. -/','/-- Full actual term evaluation preserves a monotone outgoing area. -/').replace('/-- Actual scans preserve reservations and a monotone allocation frontier. -/','/-- Actual scans preserve a monotone outgoing area. -/').replace('/-- Complete tail-recursive scans preserve the allocation invariants. -/','/-- Complete tail-recursive scans preserve a monotone outgoing area. -/')
s+='end Backend.Stock.Proof.OutgoingDraft\n';Path('/tmp/StockOutgoingFlow.lean').write_text(s)
