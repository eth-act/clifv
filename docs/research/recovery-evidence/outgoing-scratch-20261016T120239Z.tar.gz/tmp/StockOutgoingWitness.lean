import StockOutgoingFlow
import FV.Backend.Proof.StockAllocationFlow
namespace Backend.Stock.Proof.OutgoingWitnessDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64 OutgoingDraft
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm
private def signature : Clif.Signature := {
  params := List.replicate 9 ⟨.i64,.none,.normal⟩
  callConv := some .systemV }
private def input : State := { sinkState with base.outgoing := 0 }
private def output : State := { input with base.outgoing := 16 }
private def args : List V := [.op (.sig signature),.op (.extName "outgoing_witness"),
  .op (.callArgs []),.op (.callRets []),.op .tryCallNone,.bool false]
private def value : V := .op (.callInfo ⟨.sym "outgoing_witness",[],[]⟩)
private def program : Program := { (default : Program) with terms := #[T.gen_call_info] }
private theorem actual : Stock.externCtor sinkCtx T.gen_call_info args input = .ok (value,output) := rfl

/-- The real call-info constructor raises the outgoing area for nine parameters. -/
theorem stock_ctor_outgoing_witness :
    ∃ (ctx : Ctx) (t : Term) (args : List V) (st next : State) (value : V),
      Stock.externCtor ctx t args st = .ok (value,next) ∧ OutgoingLe st next ∧
      st.base.outgoing = 0 ∧ next.base.outgoing = 16 :=
  ⟨sinkCtx,T.gen_call_info,args,input,output,value,actual,stock_ctor_outgoingLe actual,rfl,rfl⟩

/-- Actual external-term interpretation raises the same area at its real state. -/
theorem stock_apply_outgoing_witness :
    ∃ (p : Program) (ctx : Ctx) (st next : State) (args : List V) (value : V),
      (applyTerm p (Stock.sem ctx) {} 1 T.gen_call_info.ret 0 args).run (st,#[]) =
        .ok (some value,next,#[]) ∧ OutgoingLe st next ∧
      st.base.outgoing = 0 ∧ next.base.outgoing = 16 := by
  have run : (applyTerm program (Stock.sem sinkCtx) {} 1 T.gen_call_info.ret 0 args).run (input,#[]) =
      .ok (some value,output,#[]) := rfl
  exact ⟨program,sinkCtx,input,output,args,value,run,stock_apply_outgoingLe run,rfl,rfl⟩

/-- An actual opportunistic scan retains the area while installing a real alias. -/
theorem stock_scan_outgoing_witness :
    ∃ ctx st output,scanInstruction ctx 0 0 1 false st = .ok output ∧
      OutgoingLe st output.state ∧ output.state.alias[192]? = some (some 197) := by
  obtain ⟨ctx,st,output,run,allocation,alias,fresh⟩ := stock_scan_allocationLe_witness
  exact ⟨ctx,st,output,run,stock_scan_outgoingLe run,alias⟩

/-- A real nonempty backward block scan also inhabits outgoing monotonicity. -/
theorem stock_scanBlock_outgoing_witness :
    ∃ ctx st output,scanBlock ctx 0 1 false [0] st = .ok output ∧
      OutgoingLe st output.state ∧ output.state.alias[192]? = some (some 197) ∧ output.records ≠ [] ∧
      (∀ record ∈ output.records,record.output.state.base.outgoing ≤ output.state.base.outgoing) := by
  obtain ⟨ctx,st,output,run,allocation,alias,fresh⟩ := stock_scanBlock_allocationLe_witness
  have nonempty : output.records ≠ [] := by
    have order := (runScans_spec run).order
    intro empty
    rw [empty] at order
    cases order
  exact ⟨ctx,st,output,run,stock_scanBlock_outgoingLe run,alias,nonempty,(stock_scanBlock_record_outgoing run).2⟩
end Backend.Stock.Proof.OutgoingWitnessDraft
