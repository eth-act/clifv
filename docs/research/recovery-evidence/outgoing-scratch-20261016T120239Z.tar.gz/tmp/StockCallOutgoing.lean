import StockOutgoingWhole
import StockCallRecordFootprint
namespace Backend.Stock.Proof.CallOutgoingDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Backend.Proof.Cov Isle Isle.Interp Isle.Aarch64
open OutgoingDraft CallRhsCallsDraft CallRecordCallsDraft CallAbiStaticDraft CallResultBindingDraft TupleBindingDraft TupleRecordBindingDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm
private theorem numbers : ∀ rs : List Reg,(∀ r ∈ rs,∃ n,r = .vreg n .int) →
    ∃ ns : List Nat,rs = ns.map (fun n => Reg.vreg n .int)
  | [],_ => ⟨[],rfl⟩
  | r :: rs,virtual => by
    obtain ⟨n,rfl⟩ := virtual r (List.mem_cons_self ..)
    obtain ⟨ns,rfl⟩ := numbers rs (fun r member => virtual r (List.mem_cons_of_mem _ member))
    exact ⟨n :: ns,rfl⟩
private theorem marked_base (xs : List Nat) (st : State) : (xs.foldl State.mark st).base = st.base := by
  induction xs generalizing st with
  | nil => rfl
  | cons x xs ih => exact ih (st.mark x)
theorem stock_lower_direct_call_record_outgoing {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (ssa : (valueDefs f).Nodup) (abi : AbiSigsOk f)
    {event : BlockScanEvent} (events : event ∈ result.blockScans.toList)
    {record : ScanRecord} (records : record ∈ event.output.records)
    {info : IInfo} {fn : Nat} {args : List Nat} {ext : Clif.ExtFunc}
    (slot : event.ctx.insts[record.inst]? = some info) (clif : info.clif = some (.call fn args))
    (external : f.extern? fn = some ext) (colocated : ext.colocated = true)
    {step : Step} (recorded : record.output.step = some step) (emitted : step.decision = .emitted) :
    SigStackOk ext.sig record.output.state.base.outgoing := by
  obtain ⟨receipt,chosen,last,environment,state,trace,calls⟩ := stock_lower_direct_call_record_calls
    run scope events records slot clif external colocated recorded emitted
  have mapped := (stock_lower_record_context run scope events).1
  have vectors := (stock_lower_call_result_binding run scope ssa abi events records slot clif external recorded emitted).2.1
  have binding := receipt.binding
  have bang : event.ctx.insts[record.inst]! = info := by simp only [getElem!_def,slot]
  rw [bang,receipt.resultRegs.symm.trans vectors] at binding
  have installed := stock_bindResults_fresh_tuple mapped (stock_lower_record_results_nodup run scope ssa events slot clif) binding
  obtain ⟨outs,afterOut,abiValue,afterAbi,requested,afterRequest,uses,afterArgs,defs,afterDefs,noTry,afterNone,
    callInfo,afterInfo,machine,afterMachine,machineTrace,unit,afterEmit,emitTrace,callFuel,emitFuel,
    output,abiRun,request,arguments,returns,noneRun,formed,callBound,emitBound,machineCall,emission,outputRun,traceEq⟩ := calls
  have a6 := stock_apply_outgoingLe machineCall
  have a7 := stock_apply_outgoingLe emission
  have a8 := stock_ctor_outgoingLe outputRun
  have abiShape : abiValue = .op (.sig ext.sig) := by
    rw [stock_ctor_baseOnly _ _ _ _ (by decide)] at abiRun
    change ExtResult.ok (.op (.sig ext.sig),afterOut) = .ok (abiValue,afterAbi) at abiRun
    cases abiRun
    rfl
  rw [abiShape] at arguments returns formed
  obtain ⟨safe,rs,mapping,requestedEq,requestState⟩ := (stock_put_in_regs_vec_iff _ _ _ _ _).mp request
  have virtual : ∀ r ∈ rs,∃ n,r = .vreg n .int := by
    intro r member
    obtain ⟨x,present,lookup⟩ := Backend.Proof.Flow.mapM_mem mapping r member
    exact mapped.valueReg x r lookup
  obtain ⟨ns,rfl⟩ := numbers rs virtual
  rw [requestedEq] at arguments
  have noneShape : noTry = .op .tryCallNone := by
    rw [stock_ctor_baseOnly _ _ _ _ (by decide)] at noneRun
    change ExtResult.ok (.op .tryCallNone,afterDefs) = .ok (noTry,afterNone) at noneRun
    cases noneRun
    rfl
  rw [noneShape] at formed
  obtain ⟨locs,bytes,stack,call,byteRun,locations,useValue,defValue,infoValue,shape,valid,static,stores,pins,outgoing⟩ :=
    stock_call_helpers_static (extern_sigAbiOk abi external) false ext.name 0 output arguments returns formed
  have raised : stack ≤ afterInfo.base.outgoing := by rw [outgoing]; exact Nat.le_max_right _ _
  have upper : stack ≤ record.output.state.base.outgoing := by
    rw [receipt.state,installed.2.1]
    exact Nat.le_trans raised (Nat.le_trans a6 (Nat.le_trans a7 a8))
  obtain ⟨b,j,stm,block,statement,current,inst⟩ := SourceRecordStatementDraft.stock_lower_source_record_statement
    run scope events records slot clif
  exact ⟨by simpa [stackBytes,locations] using upper,
    scope.stackLayout.1 b (List.mem_of_getElem? block) stm (List.mem_of_getElem? statement) fn args ext inst external⟩
theorem stock_lower_direct_call_code_outgoing {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (ssa : (valueDefs f).Nodup) (abi : AbiSigsOk f)
    {event : BlockScanEvent} (events : event ∈ result.blockScans.toList)
    {record : ScanRecord} (records : record ∈ event.output.records)
    {info : IInfo} {fn : Nat} {args : List Nat} {ext : Clif.ExtFunc}
    (slot : event.ctx.insts[record.inst]? = some info) (clif : info.clif = some (.call fn args))
    (external : f.extern? fn = some ext) (colocated : ext.colocated = true)
    {step : Step} (recorded : record.output.step = some step) (emitted : step.decision = .emitted) :
    SigStackOk ext.sig result.code.outgoing := by
  have localBound := stock_lower_direct_call_record_outgoing run scope ssa abi events records slot clif external colocated recorded emitted
  exact ⟨Nat.le_trans localBound.1 (OutgoingWholeDraft.stock_lower_record_code_outgoing run events records),localBound.2⟩
end Backend.Stock.Proof.CallOutgoingDraft
