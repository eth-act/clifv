import StockOutgoingDriver
namespace Backend.Stock.Proof.OutgoingWholeDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64 OutgoingDraft OutgoingDriverDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm
/-- The actual reverse node fold never decreases the outgoing call area. -/
theorem stock_lowerNodes_outgoing {ctx : Ctx} {ranges : Array (Nat × Nat)} {order : Order}
    {f : Clif.Function} {params labels : List Nat} {input output : DriverState}
    (run : labels.foldlM (fun d label => lowerNode ctx ranges order f params label d) input = .ok output) :
    OutgoingLe input.state output.state := by
  induction labels generalizing input with
  | nil => cases run; exact Nat.le_refl _
  | cons label labels ih =>
    rw [List.foldlM_cons] at run
    cases node : lowerNode ctx ranges order f params label input with
    | error e => simp only [node,bind,Except.bind] at run; cases run
    | ok next =>
      simp only [node,bind,Except.bind] at run
      exact Nat.le_trans (stock_lowerNode_outgoing node) (ih run)

/-- Every actual retained record fits the final area of the whole Stock run,
including records from earlier nodes of the real reverse traversal. -/
theorem stock_lower_record_outgoing {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) {event : BlockScanEvent}
    (events : event ∈ result.blockScans.toList) {record : ScanRecord}
    (records : record ∈ event.output.records) :
    record.output.state.base.outgoing ≤ result.final.base.outgoing := by
  obtain ⟨ranges,params,earlier,suffix,starting,finishing,before,after,label,bi,data,core,
    build,ordered,initial,empty,parts,folded,final,prefixRun,nodeRun,suffixRun,node,coreRun,eventEq,stateEq⟩ :=
    stock_lower_blockScanOrigin run events
  have present : record ∈ core.scan.output.records := by rw [← eventEq]; exact records
  have localBound := (stock_lowerBlockCore_outgoing coreRun).2 record present
  have finalBound := stock_lowerNodes_outgoing suffixRun
  rw [stateEq,final] at finalBound
  exact Nat.le_trans localBound finalBound

/-- Whole-driver assembly copies that final area to the returned VCode. -/
theorem stock_lower_code_outgoing {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) : result.code.outgoing = result.final.base.outgoing := by
  unfold Stock.lower at run
  dsimp only at run
  repeat' first
    | (solve | cases run)
    | (solve | cases run; rfl)
    | simp only [bind,Except.bind,pure,Except.pure] at run
    | split at run

/-- The same actual record area is bounded by the actual returned VCode area. -/
theorem stock_lower_record_code_outgoing {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) {event : BlockScanEvent}
    (events : event ∈ result.blockScans.toList) {record : ScanRecord}
    (records : record ∈ event.output.records) :
    record.output.state.base.outgoing ≤ result.code.outgoing := by
  rw [stock_lower_code_outgoing run]
  exact stock_lower_record_outgoing run events records
end Backend.Stock.Proof.OutgoingWholeDraft
