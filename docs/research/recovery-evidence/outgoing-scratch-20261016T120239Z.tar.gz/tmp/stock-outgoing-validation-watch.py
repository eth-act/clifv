from pathlib import Path
import os,json,re,time,subprocess as sp,hashlib,datetime,traceback
root=Path('/home/lee/clifv/.worktrees/driver-proof-resume');os.chdir(root);now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();progress=Path('/tmp/stock-outgoing-validation-progress.json')
mods=['StockOutgoingFlow','StockOutgoingWitness','StockOutgoingDriver','StockOutgoingWhole','StockOutgoingDriverWitness','StockCallOutgoing','StockGotOutgoing','StockCallOutgoingWitness']
old=json.loads(Path('docs/research/stock-got-source-scratch.json').read_text());allmods=sorted({Path(p).stem for p in old['scratch_sources']}|set(mods));roots=[]
for m in mods:
 text=Path('/tmp',m+'.lean').read_text();ns=re.search(r'^namespace (\S+)',text,re.M).group(1);roots += [ns+'.'+n for n in re.findall(r'^theorem (\w+)',text,re.M)]
assert len(roots)==26
Path('/tmp/stock-outgoing-new-roots.json').write_text(json.dumps(roots,indent=2)+'\n')
Path('/tmp/stock-outgoing-all-axioms.lean').write_text('\n'.join('import '+m for m in allmods)+'\n'+'\n'.join('#print axioms '+n for n in list(old['normal_axiom_audit']['roots'])+roots+list(old['normal_axiom_audit']['legacy_dependency_exact_sets']))+'\n')
seen=set();deps=set()
def visit(p):
 if str(p) in seen:return
 seen.add(str(p))
 for line in re.findall(r'^import\s+([^\n]+)',p.read_text(),re.M):
  for m in line.split():
   if m.startswith('FV.'):deps.add(m);src=Path(m.replace('.','/')+'.lean')
   elif m.startswith('Stock'):src=Path('/tmp',m+'.lean')
   else:continue
   if src.exists():visit(src)
for m in allmods:visit(Path('/tmp',m+'.lean'))
def report(state,**kw):
 q={'state':state,'watcher_pid':os.getpid(),'utc':now(),**kw};progress.write_text(json.dumps(q,indent=2)+'\n');print(json.dumps(q),flush=True)
env=dict(os.environ,OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',LEAN_PATH='/tmp',FV_MEMCAP='8G');lake='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin/lake'
try:
 last=None
 while True:
  p=json.loads(Path('/tmp/stock-coherent-serial-progress.json').read_text());assert p['state'] not in ['failed','audit_review'],p
  if p['state']!='complete':
   cmd=Path('/proc',str(p['pid']),'cmdline').read_bytes();assert cmd.startswith(b'python3\0/tmp/stock-coherent-serial-build.py'),cmd
  missing=sorted(m for m in deps if not Path('.lake/build/lib/lean',m.replace('.','/')+'.olean').exists())
  ready=not missing and p.get('current') not in deps
  current=(p['state'],p.get('index'),tuple(missing))
  if current!=last:report('waiting_dependencies',serial={k:v for k,v in p.items() if k in ['state','pid','index','current','total']},missing=missing,current_in_required_dependencies=p.get('current') in deps);last=current
  if ready:break
  time.sleep(5)
 report('compiling_complete_witness',memcap='8G',no_new_kernel_observation=True)
 with Path('/tmp/stock-call-outgoing-witness.log').open('w') as out:sp.run(['scripts/memcap.sh',lake,'env','lean','--root=/tmp','-o','/tmp/StockCallOutgoingWitness.olean','/tmp/StockCallOutgoingWitness.lean'],env=env,stdout=out,stderr=sp.STDOUT,check=True)
 report('cumulative_normal_audit',public_roots=216)
 with Path('/tmp/stock-outgoing-all-axioms.log').open('w') as out:sp.run(['scripts/memcap.sh',lake,'env','lean','--root=/tmp','/tmp/stock-outgoing-all-axioms.lean'],env=env,stdout=out,stderr=sp.STDOUT,check=True)
 text=Path('/tmp/stock-outgoing-all-axioms.log').read_text();assert not re.search(r'error[:(]',text);actual={m.group(1):sorted(x.strip() for x in m.group(2).split(',') if x.strip()) for m in re.finditer(r"'([^']+)' depends on axioms:\s*\[([^]]*)\]",text)};actual.update({n:[] for n in re.findall(r"'([^']+)' does not depend on any axioms",text)})
 for n,a in old['normal_axiom_audit']['roots'].items():assert actual[n]==a,n
 for n,a in old['normal_axiom_audit']['legacy_dependency_exact_sets'].items():assert actual[n]==a,n
 std={'propext','Classical.choice','Quot.sound'}
 for n in roots:assert set(actual[n])<=std,(n,actual[n])
 for k in ['scratch_sources','scratch_compiled_modules','compiled_logs']:
  for p,h in old[k].items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
 report('complete',modules=8,new_roots=26,all26_standard_only=True,all190_previous_exact_sets_and_hashes_preserved=True,cumulative_scratch_roots=216,canonical_integration_MCP_fullgates='pending after current frozen coherent build')
except BaseException as e:report('failed',error=repr(e),traceback=traceback.format_exc());raise
