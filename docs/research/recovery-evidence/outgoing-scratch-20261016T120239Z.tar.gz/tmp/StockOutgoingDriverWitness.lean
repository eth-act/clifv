import StockOutgoingWhole
namespace Backend.Stock.Proof.OutgoingDriverWitnessDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64 OutgoingDraft OutgoingDriverDraft OutgoingWholeDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm
private theorem branch_of_core {ctx : Ctx} {order : Order} {f : Clif.Function} {b : Clif.Block}
    {bi start stop : Nat} {data : V} {targets : Array Nat} {input : State} {core : LoweredBlockCore}
    (run : lowerBlockCore ctx order f b bi start stop data targets input = .ok core)
    (branch : (match b.term with | .ret .. | .trap .. | .returnCall .. => false | _ => true : Bool) = true) :
    ∃ out,emitBranch { ctx with
      insts := ctx.insts.set! (stop-1) ⟨data,[],[],none⟩
      tryRegs := input.tryRegs[stop-1]! } f b.term bi (stop-1) targets input = .ok out := by
  unfold lowerBlockCore at run
  dsimp only at run
  cases actual : emitBranch { ctx with
      insts := ctx.insts.set! (stop-1) ⟨data,[],[],none⟩
      tryRegs := input.tryRegs[stop-1]! } f b.term bi (stop-1) targets input with
  | error e =>
    cases termEq : b.term <;> simp_all [termEq,Functor.map,Except.map,bind,Except.bind]
  | ok out => exact ⟨out,rfl⟩
/-- The cached successful jump core includes a real separately emitted branch. -/
theorem stock_emitBranch_outgoing_witness :
    ∃ ctx f term bi ti targets input output,
      emitBranch ctx f term bi ti targets input = .ok output ∧ OutgoingLe input output.state := by
  obtain ⟨core,build,aliases,fresh,reserved,run,rest⟩ := stock_lowerBlockCore_scanAllocationBounds_witness
  change lowerBlockCore _ _ _ _ _ _ _ _ _ _ = .ok core at run
  obtain ⟨out,emitted⟩ := branch_of_core run rfl
  have bound := stock_emitBranch_outgoing emitted
  exact ⟨_,_,_,_,_,_,_,out,emitted,bound⟩

/-- A real original-node execution retains a nonempty alias and its area bound. -/
theorem stock_lowerNode_outgoing_witness :
    ∃ ctx ranges order f params label input output,
      lowerNode ctx ranges order f params label input = .ok output ∧
      OutgoingLe input.state output.state ∧ (output.state.alias[192]?).join = some 193 := by
  obtain ⟨output,run,code,scans,alias,rest⟩ := stock_lowerNode_allocationBounds_witness
  change lowerNode _ _ _ _ _ _ _ = .ok output at run
  have bound := stock_lowerNode_outgoing run
  exact ⟨_,_,_,_,_,_,_,output,run,bound,alias⟩

/-- The actual one-node fold inhabits the traversal bound without an empty fold. -/
theorem stock_lowerNodes_outgoing_witness :
    ∃ ctx ranges order f params label input output,
      ([label] : List Nat).foldlM (fun d label => lowerNode ctx ranges order f params label d) input = .ok output ∧
      OutgoingLe input.state output.state ∧ (output.state.alias[192]?).join = some 193 := by
  obtain ⟨output,run,code,alias,rest⟩ := stock_lowerNodes_allocationBounds_witness
  have bound := stock_lowerNodes_outgoing run
  exact ⟨_,_,_,_,_,_,_,output,run,bound,alias⟩

/-- A real block core with nonempty incoming aliases supplies the actual scan. -/
theorem stock_lowerBlockCore_outgoing_witness :
    ∃ ctx order f b bi start stop data targets input core,
      lowerBlockCore ctx order f b bi start stop data targets input = .ok core ∧
      OutgoingLe input core.state ∧
      (∀ record ∈ core.scan.output.records,record.output.state.base.outgoing ≤ core.state.base.outgoing) := by
  obtain ⟨core,build,aliases,fresh,reserved,run,rest⟩ := stock_lowerBlockCore_scanAllocationBounds_witness
  change lowerBlockCore _ _ _ _ _ _ _ _ _ _ = .ok core at run
  have bound := stock_lowerBlockCore_outgoing run
  exact ⟨_,_,_,_,_,_,_,_,_,_,core,run,bound⟩
end Backend.Stock.Proof.OutgoingDriverWitnessDraft
