import StockOutgoingFlow
import FV.Backend.Proof.StockTraversalRecordOrigin
namespace Backend.Stock.Proof.OutgoingDriverDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64 OutgoingDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm
private def frame (st : State) := st.base.outgoing

private theorem forIn_frame {α β γ : Type} (field : α → γ)
    (step : β → α → Except String (ForInStep α))
    (keeps : ∀ x a b, step x a = .ok (.yield b) → field b = field a)
    (no_break : ∀ x a b, step x a ≠ .ok (.done b))
    (xs : List β) {a next : α} (h : forIn xs a step = .ok next) :
    field next = field a := by
  induction xs generalizing a with
  | nil => simp only [List.forIn_nil, pure, Except.pure] at h; cases h; rfl
  | cons x xs ih =>
    rw [List.forIn_cons] at h
    cases call : step x a with
    | error e => simp only [call, bind, Except.bind] at h; cases h
    | ok result =>
      cases result with
      | done b => exact False.elim (no_break x a b call)
      | yield b =>
        simp only [call, bind, Except.bind] at h
        exact (ih h).trans (keeps x a b call)

private def argStep (ctx : Ctx) (rets pays : List Reg) (index nh : Nat)
    (arg : Clif.TryArg) (acc : State × Array Reg) :
    Except String (ForInStep (State × Array Reg)) := do
  match arg with
  | .val v =>
    let some r := ctx.valueReg? v | throw s!"unknown value v{v}"
    pure (.yield (acc.1.mark v, acc.2.push r))
  | .ret i =>
    if index < nh then throw "try_call return on exception edge"
    let some r := rets[i]? | throw "try_call return index"
    pure (.yield (acc.1, acc.2.push r))
  | .exn i =>
    if index == nh then throw "try_call payload on normal edge"
    let some r := pays[i]? | throw "try_call payload index"
    pure (.yield (acc.1, acc.2.push r))

private theorem arg_frame (ctx : Ctx) (rets pays : List Reg) (index nh : Nat)
    (arg : Clif.TryArg) (a b : State × Array Reg)
    (h : argStep ctx rets pays index nh arg a = .ok (.yield b)) :
    frame b.1 = frame a.1 := by
  cases arg <;> unfold argStep at h
  all_goals repeat' first | (solve | cases h <;> rfl) | split at h

private theorem arg_no_break (ctx : Ctx) (rets pays : List Reg) (index nh : Nat)
    (arg : Clif.TryArg) (a b : State × Array Reg) :
    argStep ctx rets pays index nh arg a ≠ .ok (.done b) := by
  intro h
  cases arg <;> unfold argStep at h
  all_goals repeat' first | (solve | cases h) | split at h

private theorem branch_frame {ctx : Ctx} {st next : State} {block index : Nat}
    {args : Array Reg} (h : branchArgs ctx st block index = .ok (args, next)) :
    frame next = frame st := by
  unfold branchArgs at h
  dsimp only at h
  split at h
  · rename_i id values lookup
    split at h
    · rename_i target found
      split at h
      · cases h
      · let ti := (st.instBlock.findIdx? (· == block)).getD 0 + ctx.func.blocks[block]!.body.length
        let reservations := st.tryRegs[ti]!
        let nh := match ctx.func.blocks[block]!.term with
          | .tryCall _ _ et | .tryCallIndirect _ _ et => et.handlers.length
          | _ => 0
        change (do
          let result ← forIn values (st, #[]) (argStep ctx reservations.1 reservations.2 index nh)
          pure (result.2, result.1)) = .ok (args, next) at h
        cases loop : forIn values (st, #[]) (argStep ctx reservations.1 reservations.2 index nh) with
        | error e => simp only [loop, bind, Except.bind] at h; cases h
        | ok result =>
          simp only [loop, bind, Except.bind, pure, Except.pure] at h
          cases h
          exact forIn_frame (fun a : State × Array Reg => frame a.1) _
            (arg_frame ctx reservations.1 reservations.2 index nh)
            (arg_no_break ctx reservations.1 reservations.2 index nh) values loop
    · cases h
  · cases h

private theorem fold_fields_eq {α β γ : Type} (field : α → γ)
    (step : α → β → Except String α)
    (hs : ∀ a b next, step a b = .ok next → field next = field a)
    (xs : List β) {a next : α} (h : xs.foldlM step a = .ok next) :
    field next = field a := by
  induction xs generalizing a with
  | nil => cases h; rfl
  | cons x xs ih =>
    rw [List.foldlM_cons] at h
    cases he : step a x with
    | error e => simp only [he, bind, Except.bind] at h; cases h
    | ok middle =>
      simp only [he, bind, Except.bind] at h
      exact (ih h).trans (hs a x middle he)


private theorem outgoing_frame {ctx : Ctx} {order : Order} {bi : Nat} {targets : Array Nat}
    {st next : State} {outgoing : Array (Array Reg)}
    (h : collectOutgoing ctx order bi targets st = .ok (next, outgoing)) :
    frame next = frame st := by
  unfold collectOutgoing at h
  apply fold_fields_eq (fun a : State × Array (Array Reg) => frame a.1) _ ?_ _ h
  intro acc target result step
  unfold outgoingStep at step
  split at step
  · cases step; rfl
  · cases call : branchArgs ctx acc.1 bi target.2 with
    | error e => simp only [call, bind, Except.bind] at step; cases step
    | ok pair =>
      rcases pair with ⟨regs, state⟩
      simp only [call, bind, Except.bind, pure, Except.pure] at step
      cases step
      exact branch_frame call

private theorem named_outgoing {ctx : Ctx} {term : String} {args : List V}
    {st next : State} {out : Option V} {trace : List RuleId}
    (h : Stock.runTerm ctx term args st = .ok (out, next, trace)) :
    OutgoingLe st next := by
  unfold Stock.runTerm at h
  cases hr : Isle.Interp.run program (Stock.sem ctx) {} term args st with
  | error e => rw [hr] at h; cases h
  | ok result =>
    rw [hr] at h
    cases h
    unfold Isle.Interp.run at hr
    cases ht : program.termByName? term with
    | none => simp only [ht] at hr; cases hr
    | some t =>
      simp only [ht] at hr
      cases ha : (applyTerm program (Stock.sem ctx) {} (Config.fuel ({} : Config))
          t.ret t.id args).run (st, #[]) with
      | error e => simp only [ha, bind, Except.bind] at hr; cases hr
      | ok result =>
        rcases result with ⟨out, next, trace⟩
        simp only [ha, bind, Except.bind, pure, Except.pure] at hr
        cases hr
        exact stock_apply_outgoingLe ha

theorem stock_emitBranch_outgoing {ctx : Ctx} {f : Clif.Function} {t : Clif.Terminator}
    {bi ti : Nat} {targets : Array Nat} {st : State} {output : BranchEmission}
    (h : emitBranch ctx f t bi ti targets st = .ok output) :
    OutgoingLe st output.state := by
  unfold emitBranch at h
  dsimp only at h
  let before := { st with current := some ti, color := none, base.emitted := #[] }
  change ((do
    let (out, next, fired) ← Stock.runTerm ctx "lower_branch" [.inst ti, .labels targets.toList] before
    if out.isNone then throw s!"no lowering rule for terminator {repr t}"
    let code ← branchCode f t targets next.base.emitted
    pure ⟨next, code, ⟨bi, ti, .emitted, before, next, [], fired, code⟩, fired⟩) : Except String BranchEmission) = .ok output at h
  cases root : Stock.runTerm ctx "lower_branch" [.inst ti, .labels targets.toList] before with
  | error e => simp only [root, bind, Except.bind] at h; cases h
  | ok result =>
    rcases result with ⟨out, next, fired⟩
    simp only [root, bind, Except.bind] at h
    split at h
    · cases h
    · cases code : branchCode f t targets next.base.emitted with
      | error e => simp only [code] at h; cases h
      | ok instructions =>
        simp only [code, pure, Except.pure] at h
        cases h
        have grown := named_outgoing root
        exact grown

theorem stock_lowerBlockCore_outgoing {ctx : Ctx} {order : Order} {f : Clif.Function} {b : Clif.Block}
    {bi start stop : Nat} {data : V} {targets : Array Nat} {st : State}
    {output : LoweredBlockCore}
    (h : lowerBlockCore ctx order f b bi start stop data targets st = .ok output) :
    OutgoingLe st output.state ∧
      ∀ r ∈ output.scan.output.records,r.output.state.base.outgoing ≤ output.state.base.outgoing := by
  let ti := stop - 1
  let termCtx := { ctx with
    insts := ctx.insts.set! ti ⟨data, [], [], none⟩
    tryRegs := st.tryRegs[ti]! }
  let branch : Bool := match b.term with | .ret .. | .trap .. | .returnCall .. => false | _ => true
  let branchCall : Except String (Option BranchEmission) :=
    if branch then some <$> emitBranch termCtx f b.term bi ti targets st else pure none
  have branch_keeps {result : Option BranchEmission} (call : branchCall = .ok result) :
      OutgoingLe st (result.map (·.state) |>.getD st) := by
    unfold branchCall at call
    split at call
    · cases emitted : emitBranch termCtx f b.term bi ti targets st with
      | error e => simp only [emitted, Functor.map, Except.map] at call; cases call
      | ok e =>
        simp only [emitted, Functor.map, Except.map] at call
        cases call
        exact stock_emitBranch_outgoing emitted
    · cases call; exact Nat.le_refl _
  have normal : lowerBlockCore ctx order f b bi start stop data targets st = ((do
    let br ← branchCall
    let edge ← collectOutgoing ctx order bi targets (br.map (·.state) |>.getD st)
    let next := edge.1
    let outgoing := edge.2
    let beforeScan := { next with color := some next.endColor[bi]! }
    let indices := ((Array.range (stop - start)).map (start + ·)).reverse.toList
    let bodyScan ← scanBlock termCtx bi ti branch indices beforeScan
    pure ⟨bodyScan.state, bodyScan.code ++ (br.map (·.code) |>.getD #[]), outgoing,
      br, ⟨termCtx, bi, ti, branch, indices, beforeScan, bodyScan⟩⟩) : Except String LoweredBlockCore) := by
    unfold lowerBlockCore
    dsimp only [branchCall, branch, termCtx, ti]
    split <;> simp_all only [branch, termCtx, ti] <;> rfl
  rw [normal] at h
  cases call : branchCall with
  | error e => simp only [call, bind, Except.bind] at h; cases h
  | ok br =>
    simp only [call, bind, Except.bind] at h
    cases edges : collectOutgoing ctx order bi targets (br.map (·.state) |>.getD st) with
    | error e => simp only [edges] at h; cases h
    | ok result =>
      rcases result with ⟨next, outgoing⟩
      simp only [edges] at h
      have edgeBound : st.base.outgoing ≤ next.base.outgoing := by
        rw [show next.base.outgoing = (br.map (·.state) |>.getD st).base.outgoing from outgoing_frame edges]
        exact branch_keeps call
      let before := { next with color := some next.endColor[bi]! }
      let indices := ((Array.range (stop - start)).map (start + ·)).reverse.toList
      have beforeBound : st.base.outgoing ≤ before.base.outgoing := edgeBound
      change (scanBlock termCtx bi ti branch indices before >>= fun bodyScan =>
        pure (⟨bodyScan.state, bodyScan.code ++ (br.map (·.code) |>.getD #[]), outgoing,
          br, ⟨termCtx, bi, ti, branch, indices, before, bodyScan⟩⟩ : LoweredBlockCore)) = .ok output at h
      cases scan : scanBlock termCtx bi ti branch indices before with
      | error e => simp only [scan, bind, Except.bind] at h; cases h
      | ok body =>
        simp only [scan, bind, Except.bind, pure, Except.pure] at h
        cases h
        have bounds := stock_scanBlock_record_outgoing scan
        exact ⟨Nat.le_trans beforeBound bounds.1,bounds.2⟩

theorem stock_lowerNode_outgoing {ctx : Ctx} {ranges : Array (Nat × Nat)} {order : Order}
    {f : Clif.Function} {paramBytes : List Nat} {label : Nat} {input output : DriverState}
    (h : lowerNode ctx ranges order f paramBytes label input = .ok output) :
    OutgoingLe input.state output.state := by
  unfold lowerNode at h
  dsimp only at h
  repeat' first
    | (solve | cases h)
    | (solve | cases h; exact Nat.le_of_eq (branch_frame (by assumption)).symm)
    | (solve | cases h; exact (stock_lowerBlockCore_outgoing (by assumption)).1)
    | simp only [bind, Except.bind, pure, Except.pure] at h
    | split at h
end Backend.Stock.Proof.OutgoingDriverDraft
