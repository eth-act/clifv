from pathlib import Path
base=Path('/tmp/StockCallRecordFootprint.lean').read_text()
start=base.index('  obtain ⟨receipt,chosen');end=base.index('  have outputShape := output')
body=base[start:end]
a=body.index('  have a0 :=');body=body[:a]+'''  have a6 := stock_apply_outgoingLe machineCall
  have a7 := stock_apply_outgoingLe emission
  have a8 := stock_ctor_outgoingLe outputRun
  have abiShape : abiValue = .op (.sig ext.sig) := by
    rw [stock_ctor_baseOnly _ _ _ _ (by decide)] at abiRun
    change ExtResult.ok (.op (.sig ext.sig),afterOut) = .ok (abiValue,afterAbi) at abiRun
    cases abiRun
    rfl
  rw [abiShape] at arguments returns formed
  obtain ⟨safe,rs,mapping,requestedEq,requestState⟩ := (stock_put_in_regs_vec_iff _ _ _ _ _).mp request
  have virtual : ∀ r ∈ rs,∃ n,r = .vreg n .int := by
    intro r member
    obtain ⟨x,present,lookup⟩ := Backend.Proof.Flow.mapM_mem mapping r member
    exact mapped.valueReg x r lookup
  obtain ⟨ns,rfl⟩ := numbers rs virtual
  rw [requestedEq] at arguments
  have noneShape : noTry = .op .tryCallNone := by
    rw [stock_ctor_baseOnly _ _ _ _ (by decide)] at noneRun
    change ExtResult.ok (.op .tryCallNone,afterDefs) = .ok (noTry,afterNone) at noneRun
    cases noneRun
    rfl
  rw [noneShape] at formed
  obtain ⟨locs,bytes,stack,call,byteRun,locations,useValue,defValue,infoValue,shape,valid,static,stores,pins,outgoing⟩ :=
    stock_call_helpers_static (extern_sigAbiOk abi external) false ext.name 0 output arguments returns formed
  have raised : stack ≤ afterInfo.base.outgoing := by rw [outgoing]; exact Nat.le_max_right _ _
  have upper : stack ≤ record.output.state.base.outgoing := by
    rw [receipt.state,installed.2.1]
    exact Nat.le_trans raised (Nat.le_trans a6 (Nat.le_trans a7 a8))
  obtain ⟨b,j,stm,block,statement,current,inst⟩ := SourceRecordStatementDraft.stock_lower_source_record_statement
    run scope events records slot clif
  exact ⟨by simpa [stackBytes,locations] using upper,
    scope.stackLayout.1 b (List.mem_of_getElem? block) stm (List.mem_of_getElem? statement) fn args ext inst external⟩
'''
header=base[base.index('theorem stock_lower_direct_call_record_footprint'):start]; header=header.replace('stock_lower_direct_call_record_footprint','stock_lower_direct_call_record_outgoing')
a=header.index('    record.input.base.nextVreg +');header=header[:a]+'''    SigStackOk ext.sig record.output.state.base.outgoing := by
'''
# Keep a direct proof of tuple decomposition to avoid depending on private helpers.
numbers=Path('/tmp/StockCallEmission.lean').read_text();a=numbers.index('private theorem numbers');b=numbers.index('\n\n',a); numbers=numbers[a:b]+'\n'
s='''import StockOutgoingFlow
import StockCallRecordFootprint
namespace Backend.Stock.Proof.CallOutgoingDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Backend.Proof.Cov Isle Isle.Interp Isle.Aarch64
open OutgoingDraft CallRhsCallsDraft CallRecordCallsDraft CallAbiStaticDraft CallResultBindingDraft TupleBindingDraft TupleRecordBindingDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm
'''+numbers+header+body+'end Backend.Stock.Proof.CallOutgoingDraft\n'
Path('/tmp/StockCallOutgoing.lean').write_text(s)
