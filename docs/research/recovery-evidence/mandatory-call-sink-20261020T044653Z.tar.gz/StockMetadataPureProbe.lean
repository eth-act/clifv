import FV.Backend.Lowering.Stock
open Backend Backend.Stock
set_option maxRecDepth 4096
private abbrev ColorState := Array Nat × Array Nat × Array (List Nat) × Nat
private def bodyStep (start bi : Nat) (x : Clif.Stmt × Nat) (s : ColorState) : Id (ForInStep ColorState) :=
  if colored x.1.inst then
    pure (.yield (s.1.set! (start+x.2) bi,s.2.1.set! (start+x.2) s.2.2.2,
      s.2.2.1.set! (start+x.2) (instArgs x.1.inst),s.2.2.2+1))
  else pure (.yield (s.1.set! (start+x.2) bi,s.2.1,
    s.2.2.1.set! (start+x.2) (instArgs x.1.inst),s.2.2.2))
private theorem body_colors (start bi : Nat) (xs : List (Clif.Stmt × Nat))
    (quiet : ∀ x ∈ xs, colored x.1.inst = false) (s : ColorState) :
    ((forIn xs s (bodyStep start bi)).run).2.1 = s.2.1 := by
  induction xs generalizing s with
  | nil => rfl
  | cons x xs ih =>
    have hx := quiet x (by simp)
    have tail : ∀ y ∈ xs, colored y.1.inst = false := fun y hy => quiet y (by simp [hy])
    rw [List.forIn_cons]
    simp only [bodyStep,hx,Bool.false_eq_true,ite_false]
    change ((forIn xs (s.1.set! (start+x.2) bi,s.2.1,
      s.2.2.1.set! (start+x.2) (instArgs x.1.inst),s.2.2.2) (bodyStep start bi)).run).2.1 = s.2.1
    exact ih tail _
example (ctx : Ctx) (ranges : Array (Nat × Nat)) (b : Clif.Block)
    (blocks : ctx.func.blocks = [b]) (range : ranges[0]! = (0,b.body.length+1))
    (pureBody : ∀ s ∈ b.body, colored s.inst = false) (q : Nat) (inside : q < b.body.length)
    (bound : q < ctx.insts.size) : (sourceMetadata ctx ranges).entryColor[q]! = 0 := by
  have quiet : ∀ x ∈ b.body.zipIdx, colored x.1.inst = false :=
    fun x hx => pureBody x.1 (List.fst_mem_of_mem_zipIdx hx)
  have inner := body_colors ranges[0]!.1 0 b.body.zipIdx quiet
    (Array.replicate ctx.insts.size 0,Array.replicate ctx.insts.size 0,
      Array.replicate ctx.insts.size [],0+1)
  simp only [sourceMetadata,blocks,List.zipIdx_cons,List.zipIdx_nil,
    List.forIn_cons,List.forIn_nil,Id.run_bind,Id.run_pure]
  change (((forIn b.body.zipIdx _ (bodyStep ranges[0]!.1 0)).run).2.1.set!
    (ranges[0]!.2-1) _)[q]! = 0
  rw [inner]
  have different : q ≠ ranges[0]!.2-1 := by rw [range]; simp only; omega
  rw [Array.getElem!_set!_ne _ _ _ _ (Ne.symm different)]
  simp [getElem!_def,Array.getElem?_replicate,bound]
