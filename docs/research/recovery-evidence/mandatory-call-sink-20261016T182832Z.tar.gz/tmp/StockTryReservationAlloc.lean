import FV.Backend.Proof.StockContext
namespace Backend.Stock.Proof.TryReservationAllocDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
/-- Exact disjoint return/payload layout at an actual allocator instruction. -/
def SlotLayout (a : Allocation) (i n p : Nat) : Prop :=
  ∃ base,a.tryRegs[i]? = some ((List.range n).map (fun j => Reg.vreg (base+j) .int),
    (List.range p).map (fun j => Reg.vreg (base+n+j) .int))
private theorem step_size (a : Allocation) (q : AllocationRequest) :
    (a.step q).tryRegs.size = a.tryRegs.size := by cases q <;> simp [Allocation.step]
private theorem fold_size (qs : List AllocationRequest) (a : Allocation) :
    (qs.foldl Allocation.step a).tryRegs.size = a.tryRegs.size := by
  induction qs generalizing a with
  | nil => rfl
  | cons q qs ih => exact (ih (a.step q)).trans (step_size a q)
private theorem install (a : Allocation) (i n p : Nat) (bound : i < a.tryRegs.size) :
    SlotLayout (a.step (.exception i n p)) i n p := by
  refine ⟨a.base.nextVreg,?_⟩
  simp only [Allocation.step,Array.set!_eq_setIfInBounds,Array.getElem?_setIfInBounds_self_of_lt bound]
private theorem step_keeps (a : Allocation) (q : AllocationRequest) {i n p : Nat}
    (same : ∀ nr np,q = .exception i nr np → nr = n ∧ np = p)
    (old : SlotLayout a i n p) : SlotLayout (a.step q) i n p := by
  cases q with
  | value x => exact old
  | exception j nr np =>
    by_cases hit : j = i
    · subst j
      obtain ⟨rfl,rfl⟩ := same nr np rfl
      obtain ⟨base,atSlot⟩ := old
      exact install a i _ _ (Array.getElem?_eq_some_iff.mp atSlot).1
    · obtain ⟨base,atSlot⟩ := old
      refine ⟨base,?_⟩
      simp only [Allocation.step,Array.set!_eq_setIfInBounds,Array.getElem?_setIfInBounds]
      simpa only [hit,ite_false] using atSlot
private theorem fold_keeps (qs : List AllocationRequest) (a : Allocation) {i n p : Nat}
    (same : ∀ q ∈ qs,∀ nr np,q = .exception i nr np → nr = n ∧ np = p)
    (old : SlotLayout a i n p) : SlotLayout (qs.foldl Allocation.step a) i n p := by
  induction qs generalizing a with
  | nil => exact old
  | cons q qs ih =>
    exact ih (a.step q) (fun r hr => same r (List.mem_cons_of_mem q hr))
      (step_keeps a q (same q (by simp)) old)
/-- A real request installs the exact disjoint layout and later requests
preserve its counts. No caller reservation vector or fresh-base value is used. -/
theorem stock_allocate_requested_try_layout (values instructions : Nat) (requests : List AllocationRequest)
    {i n p : Nat} (bound : i < instructions) (requested : AllocationRequest.exception i n p ∈ requests)
    (same : ∀ nr np,AllocationRequest.exception i nr np ∈ requests → nr = n ∧ np = p) :
    SlotLayout (allocateRequests values instructions requests) i n p := by
  obtain ⟨before,after,split,_⟩ := List.eq_append_cons_of_mem requested
  unfold allocateRequests
  rw [split,List.foldl_append,List.foldl_cons]
  apply fold_keeps
  · intro q member nr np equal
    subst q
    apply same nr np
    rw [split]
    exact List.mem_append_right _ (List.mem_cons_of_mem _ member)
  · apply install
    rw [fold_size]
    simpa only [Allocation.initial,Array.size_replicate] using bound
end Backend.Stock.Proof.TryReservationAllocDraft
