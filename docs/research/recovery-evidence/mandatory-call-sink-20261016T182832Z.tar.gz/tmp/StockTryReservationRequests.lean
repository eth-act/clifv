import FV.Backend.Proof.StockContext
import FV.Backend.Proof.LowerLemmas
namespace Backend.Stock.Proof.TryReservationRequestsDraft
open Backend.Proof Backend.Proof.Driver
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private theorem mapM_flatten {α β : Type} {fn : α → Except String (List β)} {xs : List α}
    {chunks : List (List β)} (run : xs.mapM fn = .ok chunks) (q : β) :
    q ∈ chunks.flatten ↔ ∃ x ∈ xs,∃ ys,fn x = .ok ys ∧ q ∈ ys := by
  induction xs generalizing chunks with
  | nil => simp only [List.mapM_nil] at run; cases run; simp
  | cons x xs ih =>
    simp only [List.mapM_cons] at run
    cases first : fn x with
    | error e => simp only [first,bind,Except.bind] at run; cases run
    | ok ys =>
      cases rest : xs.mapM fn with
      | error e => simp only [first,rest,bind,Except.bind] at run; cases run
      | ok zs =>
        simp only [first,rest,bind,Except.bind,pure,Except.pure] at run
        cases run
        rw [List.flatten_cons,List.mem_append,ih rest]
        simp only [List.mem_cons,exists_eq_or_imp,first,Except.ok.injEq,exists_eq_left']
/-- A block contributes exactly its original exception reservation, as a
consequence of successful real block request generation. -/
theorem stock_block_try_request_iff {f : Clif.Function} {ranges : Array (Nat × Nat)}
    {b : Clif.Block} {bi : Nat} {requests : List AllocationRequest}
    (run : blockAllocationRequests f ranges b bi = .ok requests) (i n p : Nat) :
    AllocationRequest.exception i n p ∈ requests ↔
      exceptionReservation f ranges bi b.term = .ok (some (i,n,p)) := by
  unfold blockAllocationRequests at run
  obtain ⟨extra,selected,rest⟩ := Except.bind_ok run
  cases rest
  cases extra with
  | none =>
    simp [selected,List.mem_map,List.mem_flatMap]
  | some r =>
    rcases r with ⟨ri,rn,rp⟩
    simp only [selected,Except.ok.injEq,Option.some.injEq]
    simp [List.mem_map,List.mem_flatMap,eq_comm]
/-- Every actual function allocation request comes from a real indexed source
block; conversely every real block reservation occurs in that same request list.
No reachability filter or caller-supplied reservation certificate is introduced. -/
theorem stock_allocation_try_request_iff {f : Clif.Function} {ranges : Array (Nat × Nat)}
    {requests : List AllocationRequest} (run : allocationRequests f ranges = .ok requests) (i n p : Nat) :
    AllocationRequest.exception i n p ∈ requests ↔
      ∃ bi b,f.blocks[bi]? = some b ∧ exceptionReservation f ranges bi b.term = .ok (some (i,n,p)) := by
  unfold allocationRequests at run
  obtain ⟨chunks,mapped,rest⟩ := Except.bind_ok run
  cases rest
  rw [mapM_flatten mapped]
  constructor
  · rintro ⟨⟨b,bi⟩,member,ys,generated,inside⟩
    exact ⟨bi,b,List.mem_zipIdx_iff_getElem?.mp member,(stock_block_try_request_iff generated i n p).mp inside⟩
  · rintro ⟨bi,b,block,reserved⟩
    have member : (b,bi) ∈ f.blocks.zipIdx := List.mem_zipIdx_iff_getElem?.mpr block
    obtain ⟨j,atBlock⟩ := List.mem_iff_getElem?.mp member
    obtain ⟨ys,generated,_⟩ := (list_mapM_ok mapped).2 j (b,bi) atBlock
    exact ⟨(b,bi),member,ys,generated,(stock_block_try_request_iff generated i n p).mpr reserved⟩
end Backend.Stock.Proof.TryReservationRequestsDraft
