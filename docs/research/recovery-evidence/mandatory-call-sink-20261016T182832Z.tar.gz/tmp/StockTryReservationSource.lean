import StockTryReservationAlloc
import StockTryReservationRequests
import StockTryBranchAbi
import FV.Backend.Proof.StockBlockRanges
namespace Backend.Stock.Proof.TryReservationSourceDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open TryReservationAllocDraft TryReservationRequestsDraft TryBranchAbiDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private theorem block_generated {f : Clif.Function} {ranges : Array (Nat × Nat)}
    {requests : List AllocationRequest} (run : allocationRequests f ranges = .ok requests)
    {bi : Nat} {b : Clif.Block} (block : f.blocks[bi]? = some b) :
    ∃ qs,blockAllocationRequests f ranges b bi = .ok qs := by
  unfold allocationRequests at run
  obtain ⟨chunks,mapped,_⟩ := Except.bind_ok run
  have member : (b,bi) ∈ f.blocks.zipIdx := List.mem_zipIdx_iff_getElem?.mpr block
  obtain ⟨j,atBlock⟩ := List.mem_iff_getElem?.mp member
  obtain ⟨qs,generated,_⟩ := (list_mapM_ok mapped).2 j (b,bi) atBlock
  exact ⟨qs,generated⟩
private theorem reservation_origin {f : Clif.Function} {ranges : Array (Nat × Nat)}
    {bi i n p : Nat} {term : Clif.Terminator}
    (run : exceptionReservation f ranges bi term = .ok (some (i,n,p))) :
    ∃ et sig items,sourceTable term = some et ∧ exnTableOpnd f et = .ok (sig,items) ∧
      i = ranges[bi]!.2-1 ∧ n = sig.returns.length ∧ p = (payloadRegs sig.callConv).length := by
  cases term <;> unfold exceptionReservation at run
  all_goals try contradiction
  all_goals
    dsimp only at run
    repeat' first
      | (solve | cases run)
      | simp only [bind,Except.bind,pure,Except.pure] at run
      | split at run
    all_goals
      cases run
      exact ⟨_,_,_,rfl,by assumption,rfl,rfl,rfl⟩
private theorem reservation_for {f : Clif.Function} {ranges : Array (Nat × Nat)} {bi : Nat}
    {b : Clif.Block} {qs : List AllocationRequest}
    (generated : blockAllocationRequests f ranges b bi = .ok qs)
    {et : Clif.ExnTable} {sig : Clif.Signature} {items : List (Option Nat)}
    (kind : sourceTable b.term = some et) (table : exnTableOpnd f et = .ok (sig,items)) :
    exceptionReservation f ranges bi b.term =
      .ok (some (ranges[bi]!.2-1,sig.returns.length,(payloadRegs sig.callConv).length)) := by
  unfold blockAllocationRequests at generated
  obtain ⟨extra,reserved,_⟩ := Except.bind_ok generated
  cases term : b.term <;> simp only [sourceTable,term] at kind
  all_goals try contradiction
  all_goals
    cases kind
    simp only [term,exceptionReservation,table,bind,Except.bind] at reserved ⊢
    split at reserved
    · cases reserved
    · simp_all only [Bool.false_eq_true,ite_false,pure,Except.pure]
/-- Successful real Stock context construction and the original source table
internally determine the exact reservation counts AND disjoint allocated layout.
No new scope, numbering, reachability or reservation certificate is assumed. -/
theorem stock_build_try_source_layout {f : Clif.Function} {ctx : Ctx}
    {ranges : Array (Nat × Nat)} {initial : State}
    (build : Stock.buildCtx f = .ok (ctx,ranges,initial))
    {bi : Nat} {b : Clif.Block} (block : f.blocks[bi]? = some b)
    {et : Clif.ExnTable} {sig : Clif.Signature} {items : List (Option Nat)}
    (kind : sourceTable b.term = some et) (table : exnTableOpnd f et = .ok (sig,items)) :
    ∃ base,initial.tryRegs[blockStart f bi+b.body.length]? = some
      ((List.range sig.returns.length).map (fun j => Reg.vreg (base+j) .int),
       (List.range (payloadRegs sig.callConv).length).map (fun j => Reg.vreg (base+sig.returns.length+j) .int)) := by
  obtain ⟨original,st0,requests,oldBuild,requested,finished⟩ := buildCtx_allocation build
  have spec := ctxSpec_of oldBuild
  have atRange := spec.ranges bi b block
  have range : ranges[bi]! = (blockStart f bi,blockStart f bi+b.body.length+1) := by
    simp only [getElem!_def,atRange]
  obtain ⟨qs,generated⟩ := block_generated requested block
  have reservation := reservation_for generated kind table
  rw [range] at reservation
  simp only [Nat.add_sub_cancel] at reservation
  have member : AllocationRequest.exception (blockStart f bi+b.body.length)
      sig.returns.length (payloadRegs sig.callConv).length ∈ requests :=
    (stock_allocation_try_request_iff requested _ _ _).mpr ⟨bi,b,block,reservation⟩
  have same : ∀ nr np,AllocationRequest.exception (blockStart f bi+b.body.length) nr np ∈ requests →
      nr = sig.returns.length ∧ np = (payloadRegs sig.callConv).length := by
    intro nr np present
    obtain ⟨bj,other,found,run⟩ := (stock_allocation_try_request_iff requested _ _ _).mp present
    obtain ⟨et',sig',items',kind',table',owner,ncount,pcount⟩ := reservation_origin run
    by_cases equal : bj = bi
    · subst bj
      cases Option.some.inj (block.symm.trans found)
      cases Option.some.inj (kind.symm.trans kind')
      cases Except.ok.inj (table.symm.trans table')
      exact ⟨ncount,pcount⟩
    · have otherAt := spec.ranges bj other found
      have otherRange : ranges[bj]! = (blockStart f bj,blockStart f bj+other.body.length+1) := by
        simp only [getElem!_def,otherAt]
      have apart := stock_buildCtx_block_ranges_disjoint build block found (Ne.symm equal) atRange otherAt
      rw [otherRange] at owner
      rcases apart with before | after <;> omega
  have bound := (Array.getElem?_eq_some_iff.mp (spec.facts.term bi b block)).1
  obtain ⟨base,layout⟩ := stock_allocate_requested_try_layout original.valTy.size original.insts.size
    requests bound member same
  have slots := congrArg (fun q : Ctx × Array (Nat × Nat) × State => q.2.2.tryRegs) finished
  change initial.tryRegs = (allocateRequests original.valTy.size original.insts.size requests).tryRegs at slots
  exact ⟨base,by rw [slots]; exact layout⟩
end Backend.Stock.Proof.TryReservationSourceDraft
