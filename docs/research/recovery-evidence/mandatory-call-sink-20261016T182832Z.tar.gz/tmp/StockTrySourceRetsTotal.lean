import StockTryReservationSource
import StockTryRetsTotal
import FV.Backend.Proof.StockAllocationFlow
import FV.Backend.Proof.IselPrgCtx
namespace Backend.Stock.Proof.TrySourceRetsTotalDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open TryReservationSourceDraft TryRetsTotalDraft TryBranchAbiDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private theorem original_returns_bound {f : Clif.Function} (input : Prg.iselInB f = true)
    {bi : Nat} {b : Clif.Block} (block : f.blocks[bi]? = some b)
    {et : Clif.ExnTable} {sig : Clif.Signature} {items : List (Option Nat)}
    (kind : sourceTable b.term = some et) (table : exnTableOpnd f et = .ok (sig,items)) :
    sig.returns.length ≤ 8 := by
  have progress := Prg.termIsel_of input (List.mem_of_getElem? block)
  have declared := exnTableOpnd_sig table
  have abi : Prg.sigOkB sig = true := by
    cases term : b.term <;> simp only [sourceTable,term] at kind
    all_goals try contradiction
    all_goals
      cases kind
      simp only [Prg.termIselB,term,declared,Bool.and_eq_true] at progress
      exact progress.2
  exact Nat.le_trans (returns_le_sigRets sig) (Prg.sigOk_of abi).2
/-- At every real source TryCall, existing original iselInB supplies the ABI
bound and successful context construction supplies the actual reservation.
Their layout/count facts are derived internally, not new accepted conditions.
AllocationLe is the existing internal state-preservation invariant. -/
theorem stock_original_source_try_rets_total {f : Clif.Function} {ctx : Ctx}
    {ranges : Array (Nat × Nat)} {initial st : State}
    (build : Stock.buildCtx f = .ok (ctx,ranges,initial)) (input : Prg.iselInB f = true)
    (allocation : AllocationLe initial st) {bi : Nat} {b : Clif.Block}
    (block : f.blocks[bi]? = some b) {et : Clif.ExnTable} {sig : Clif.Signature} {items : List (Option Nat)}
    (kind : sourceTable b.term = some et) (table : exnTableOpnd f et = .ok (sig,items)) :
    ∃ (base : Nat) (value : V) (next : State),
      st.tryRegs[blockStart f bi+b.body.length]! =
        (reservedReturns base sig.returns.length,reservedPayloads base sig.returns.length) ∧
      Stock.externCtor {ctx with tryRegs := st.tryRegs[blockStart f bi+b.body.length]!}
        T.gen_try_call_rets [.op (.sig sig)] st = .ok (value,next) := by
  obtain ⟨base,layout⟩ := stock_build_try_source_layout build block kind table
  have payload := exnTableOpnd_cc table
  have slots : st.tryRegs[blockStart f bi+b.body.length]! =
      (reservedReturns base sig.returns.length,reservedPayloads base sig.returns.length) := by
    rw [allocation.2]
    simp only [getElem!_def,layout]
    rw [payload]
    rfl
  obtain ⟨value,next,run⟩ := stock_try_rets_reserved_total
    (ctx := {ctx with tryRegs := st.tryRegs[blockStart f bi+b.body.length]!}) (sig := sig) st base
    (original_returns_bound input block kind table) payload slots
  exact ⟨base,value,next,slots,run⟩
end Backend.Stock.Proof.TrySourceRetsTotalDraft
