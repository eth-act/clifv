import StockTrySourceAllocation
import StockTrySourceRetsTotal
import StockTryBranchSelection
namespace Backend.Stock.Proof.TryWholeSourceReservationDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open TrySourceContextDraft TrySourceAllocationDraft TrySourceRetsTotalDraft TryRetsTotalDraft TryBranchSelectionDraft TryBranchAbiDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
/-- Actual whole-driver traversal supplies the source branch, selected rule,
allocation invariant and reserved helper totality. All layout/count facts come
from the original source and build; none are caller acceptance certificates. -/
theorem stock_lower_original_try_reservation {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (input : Prg.iselInB f = true)
    {label bi : Nat} {b : Clif.Block} (node : result.order.nodes[label]? = some (.original bi))
    (block : f.blocks[bi]? = some b) {et : Clif.ExnTable} {sig : Clif.Signature} {items : List (Option Nat)}
    (kind : sourceTable b.term = some et) (table : exnTableOpnd f et = .ok (sig,items)) :
    ∃ (ranges : Array (Nat × Nat)) (source : TryBranchSource f result label bi b)
      (_selected : TryBranchSelection source) (base : Nat) (value : V) (next : State),
      Stock.buildCtx f = .ok (result.ctx,ranges,result.initial) ∧ AllocationLe result.initial source.input ∧
      source.ctx.tryRegs = (reservedReturns base sig.returns.length,reservedPayloads base sig.returns.length) ∧
      Stock.externCtor source.ctx T.gen_try_call_rets [.op (.sig sig)] source.input = .ok (value,next) ∧
      {next with alias := #[]} = {source.input with alias := #[]} := by
  have isTry : b.term.isTry = true := by
    cases term : b.term <;> simp only [sourceTable,term] at kind
    all_goals first | contradiction | rfl
  obtain ⟨ranges,source,build,allocation⟩ := stock_lower_try_source_allocation run scope node block isTry
  obtain ⟨selected⟩ := stock_try_branch_selection source
  obtain ⟨base,value,next,layout,helper⟩ := stock_original_source_try_rets_total build input allocation block kind table
  have slots : source.ctx.tryRegs = (reservedReturns base sig.returns.length,reservedPayloads base sig.returns.length) := by
    rw [source.tryRegs,source.index]
    exact layout
  have actual : Stock.externCtor source.ctx T.gen_try_call_rets [.op (.sig sig)] source.input = .ok (value,next) := by
    calc Stock.externCtor source.ctx T.gen_try_call_rets [.op (.sig sig)] source.input =
        Stock.externCtor {result.ctx with tryRegs := source.ctx.tryRegs} T.gen_try_call_rets [.op (.sig sig)] source.input := rfl
      _ = .ok (value,next) := by rw [source.tryRegs,source.index]; exact helper
  exact ⟨ranges,source,selected,base,value,next,build,allocation,slots,actual,
    TryRetsFrameDraft.stock_try_rets_alias_only actual⟩
end Backend.Stock.Proof.TryWholeSourceReservationDraft
