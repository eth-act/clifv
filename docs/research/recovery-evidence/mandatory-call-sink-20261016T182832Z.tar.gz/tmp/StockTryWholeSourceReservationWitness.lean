import StockTryWholeSourceReservation
import StockTryBranchAbiWitness
namespace Backend.Stock.Proof.TryWholeSourceReservationWitnessDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open TryProtocolWitnessDraft TryBranchAbiDraft TrySourceContextDraft TryBranchSelectionDraft TryWholeSourceReservationDraft TryRetsTotalDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private def function : Kind → Clif.Function
  | .near => TryNearFixtureDraft.function false
  | .got => SpillEntryFixture.function false
  | .indirect => SpillEntryFixture.function true
/-- COMPLETE near/GOT/indirect original-condition pipelines instantiate the
whole-driver source/selection/reservation result, including the internally
derived allocation invariant at the actual branch input and retained step. -/
theorem stock_complete_whole_source_try_reservation_witness (k : Kind) :
    ∃ (result : Result) (prepared : EdgeVCode) (rf : RFunc) (af : AFunc)
      (ranges : Array (Nat × Nat))
      (source : TryBranchSource (function k) result 0 0 (function k).blocks[0]!)
      (_selected : TryBranchSelection source) (sig : Clif.Signature) (base : Nat) (value : V) (next : State),
      LowerScope (function k) ∧ Dominated (function k) ∧ ArityOk (function k) ∧
      Prg.iselInB (function k) = true ∧ Stock.lower (function k) = .ok result ∧
      prepareAt result.code result.edgeArgs = .ok prepared ∧ rf = spillAllocAt prepared.code prepared.edges ∧
      checkAllocAt prepared.code prepared.edges rf = .ok () ∧ lowerRFunc prepared.code rf = .ok af ∧
      Stock.buildCtx (function k) = .ok (result.ctx,ranges,result.initial) ∧
      AllocationLe result.initial source.input ∧ source.branch.step ∈ result.schedule.toList ∧
      source.ctx.tryRegs = (reservedReturns base sig.returns.length,reservedPayloads base sig.returns.length) ∧
      Stock.externCtor source.ctx T.gen_try_call_rets [.op (.sig sig)] source.input = .ok (value,next) ∧
      {next with alias := #[]} = {source.input with alias := #[]} := by
  obtain ⟨result,prepared,rf,af,oldSource,oldSelected,et,sig,items,info,call,scope,dominated,arity,
    lowered,prepare,fallback,accepted,physical,scheduled,kind,table,metadata,count,raw,last⟩ :=
    TryBranchAbiWitnessDraft.stock_complete_try_branch_explicit_abi_witness k
  have originalInput : Prg.iselInB (function k) = true := by cases k <;> decide +kernel
  have block : (function k).blocks[0]? = some (function k).blocks[0]! := by cases k <;> rfl
  have order : blockOrder (function k) = .ok {
    nodes := #[.original 0,.original 1,.original 2],successors := #[#[2,1],#[],#[]]} := by cases k <;> cbv
  have sameOrder := Except.ok.inj ((stock_lower_order lowered).symm.trans order)
  have node : result.order.nodes[0]? = some (.original 0) := by rw [sameOrder]; rfl
  obtain ⟨ranges,source,selected,base,value,next,build,allocation,slots,run,frame⟩ :=
    stock_lower_original_try_reservation lowered scope originalInput node block kind table
  exact ⟨result,prepared,rf,af,ranges,source,selected,sig,base,value,next,scope,dominated,arity,originalInput,
    lowered,prepare,fallback,accepted,physical,build,allocation,source.scheduled,slots,run,frame⟩
end Backend.Stock.Proof.TryWholeSourceReservationWitnessDraft
