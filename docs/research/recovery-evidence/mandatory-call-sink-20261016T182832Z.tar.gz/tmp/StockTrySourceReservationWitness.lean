import StockTrySourceRetsTotal
import StockTryBranchAbiWitness
import StockTryRetsShape
namespace Backend.Stock.Proof.TrySourceReservationWitnessDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open TryProtocolWitnessDraft TryBranchAbiDraft TryReservationSourceDraft TrySourceRetsTotalDraft TryRetsTotalDraft TryRetsShapeDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
attribute [local irreducible] Stock.lower Stock.runTerm Stock.externCtor
private def function : Kind → Clif.Function
  | .near => TryNearFixtureDraft.function false
  | .got => SpillEntryFixture.function false
  | .indirect => SpillEntryFixture.function true
private theorem lower_build {f : Clif.Function} {result : Result} (run : Stock.lower f = .ok result) :
    ∃ ranges,Stock.buildCtx f = .ok (result.ctx,ranges,result.initial) := by
  unfold Stock.lower at run
  dsimp only at run
  repeat' first
    | (solve | cases run)
    | simp only [bind,Except.bind,pure,Except.pure] at run
    | split at run
  cases run
  exact ⟨_,by assumption⟩
/-- All three COMPLETE original-condition TryCall pipelines instantiate the
new original-source reservation/count and helper-totality roots. Existing
iselInB is inhabited; no reservation-layout/ABI-count input certificate is added. -/
theorem stock_complete_original_source_try_reservation_witness (k : Kind) :
    ∃ (result : Result) (prepared : EdgeVCode) (rf : RFunc) (af : AFunc)
      (ranges : Array (Nat × Nat)) (et : Clif.ExnTable) (sig : Clif.Signature)
      (items : List (Option Nat)) (base : Nat) (value : V) (next : State),
      LowerScope (function k) ∧ Dominated (function k) ∧ ArityOk (function k) ∧
      Prg.iselInB (function k) = true ∧ Stock.lower (function k) = .ok result ∧
      prepareAt result.code result.edgeArgs = .ok prepared ∧ rf = spillAllocAt prepared.code prepared.edges ∧
      checkAllocAt prepared.code prepared.edges rf = .ok () ∧ lowerRFunc prepared.code rf = .ok af ∧
      Stock.buildCtx (function k) = .ok (result.ctx,ranges,result.initial) ∧
      sourceTable (function k).blocks[0]!.term = some et ∧ exnTableOpnd (function k) et = .ok (sig,items) ∧
      result.initial.tryRegs[blockStart (function k) 0+(function k).blocks[0]!.body.length]! =
        (reservedReturns base sig.returns.length,reservedPayloads base sig.returns.length) ∧
      Stock.externCtor {result.ctx with tryRegs := result.initial.tryRegs[blockStart (function k) 0+(function k).blocks[0]!.body.length]!}
        T.gen_try_call_rets [.op (.sig sig)] result.initial = .ok (value,next) ∧
      {next with alias := #[]} = {result.initial with alias := #[]} := by
  obtain ⟨result,prepared,rf,af,source,selected,et,sig,items,info,call,scope,dominated,arity,
    lowered,prepare,fallback,accepted,physical,scheduled,kind,table,metadata,count,raw,last⟩ :=
    TryBranchAbiWitnessDraft.stock_complete_try_branch_explicit_abi_witness k
  have originalInput : Prg.iselInB (function k) = true := by cases k <;> decide +kernel
  have block : (function k).blocks[0]? = some (function k).blocks[0]! := by cases k <;> rfl
  obtain ⟨ranges,build⟩ := lower_build lowered
  obtain ⟨base,value,next,layout,run⟩ := stock_original_source_try_rets_total build originalInput
    (show AllocationLe result.initial result.initial from ⟨Nat.le_refl _,rfl⟩) block kind table
  exact ⟨result,prepared,rf,af,ranges,et,sig,items,base,value,next,scope,dominated,arity,originalInput,
    lowered,prepare,fallback,accepted,physical,build,kind,table,layout,run,
    TryRetsFrameDraft.stock_try_rets_alias_only run⟩
end Backend.Stock.Proof.TrySourceReservationWitnessDraft
