from pathlib import Path
import os,sys,time,json,hashlib,datetime,subprocess,traceback
root=Path('/home/lee/clifv/.worktrees/driver-proof-resume');os.chdir(root)
progress=Path('/tmp/stock-body-form-validation-progress.json');serial=Path('/tmp/stock-static-serial-progress.json');controller=json.loads(serial.read_text())['pid'];phase='waiting_serial'
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
manifest=json.loads(Path('/tmp/stock-body-form-validation-inputs.json').read_text())
def verify_sources():
 current={str(p):sha(p) for top in ['FV','FVTest'] for p in Path(top).rglob('*.lean')}
 assert current==manifest['all_Lean_sources'],'Lean source set/bytes changed during frozen validation'
 p=json.loads(Path('docs/research/stock-body-form-checkpoint.json').read_text())
 assert p['sources']==manifest['recorded_sources'],'recorded source manifest changed'
 assert all(sha(f)==h for f,h in p['sources'].items()),'recorded source bytes changed'
 assert all(sha(f)==h for f,h in manifest['validation_scripts'].items()),'validation scripts changed'
def report(state,**fields):
 d={'state':state,'phase':phase,'watcher_pid':os.getpid(),'serial_controller_pid':controller,'utc':now(),'frozen_source_manifest':'/tmp/stock-body-form-validation-inputs.json',**fields}
 progress.write_text(json.dumps(d,indent=2)+'\n');print(now(),state,phase,fields,flush=True)
try:
 report('running')
 previous=None
 while True:
  p=json.loads(serial.read_text())
  if p['state']=='complete':
   receipt=json.loads(Path('/tmp/stock-static-serial-rebuild-receipt.json').read_text());assert receipt['success'] and len(receipt['sequential_modules'])==1011;break
  assert p['state']=='running',p
  assert p['pid']==controller,p
  cmd=Path(f'/proc/{controller}/cmdline').read_bytes();assert cmd.startswith(b'python3\0/tmp/stock-static-serial-rebuild.py'),cmd
  if p.get('index')!=previous:
   previous=p.get('index');report('running',serial_index=previous,serial_current=p.get('current'))
  time.sleep(5)
 verify_sources();phase='full_normal_axiom_audit';report('running')
 env=dict(os.environ,OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',FV_MEMCAP='22G');env['PATH']='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:/home/lee/.cargo/bin:'+env['PATH'];assert subprocess.check_output(['nproc'],env=env,text=True).strip()=='2'
 with Path('/tmp/stock-body-form-axioms.log').open('w') as out:
  subprocess.run(['scripts/memcap.sh','lake','env','lean','docs/research/stock-body-form-all-axioms.lean'],env=env,stdout=out,stderr=subprocess.STDOUT,check=True)
 with Path('/tmp/stock-body-form-audit-check.log').open('w') as out:
  subprocess.run([sys.executable,'/tmp/stock-body-form-audit-check.py'],stdout=out,stderr=subprocess.STDOUT,check=True)
 verify_sources();phase='full_gates';report('running')
 with Path('/tmp/stock-body-form-full-controller.log').open('w') as out:
  subprocess.run([sys.executable,'/tmp/stock-body-form-full-gates.py'],stdout=out,stderr=subprocess.STDOUT,check=True)
 verify_sources();phase='complete'
 path=Path('docs/research/stock-body-form-checkpoint.json');p=json.loads(path.read_text());p['normal_full_audit']=json.loads(Path('/tmp/stock-body-form-audit-receipt.json').read_text());p['validation_state']['full_validation']='PASS current frozen proof batch:1992 normal roots/all1969 old/seven compiler sets preserved;23 new standard-only match four existing MCP receipts; all full FV/FVTest/tools/crates/runtime/encoder/bothE2E exact identity-stage/420comparison-source gates pass. Production remains legacy; full-goal proofs/integration/final fresh complete comparison remain mandatory.';p['updated_utc']=now();path.write_text(json.dumps(p,indent=2)+'\n');report('complete',goal='active/incomplete; production legacy',full_gates=p['full_gates'])
except BaseException as e:
 report('failed',error=repr(e),traceback=traceback.format_exc());raise
