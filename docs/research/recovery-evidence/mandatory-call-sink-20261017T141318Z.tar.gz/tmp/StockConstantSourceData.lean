import FV.Backend.Proof.StockConstantRecordValues
namespace Backend.Stock.Proof.ConstantSourceDataDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
/-- Original context scope, data and typing supply all scalar constant selector
facts, including signed Imm64 representation. No additional source filter. -/
theorem stock_constant_source_data {f : Clif.Function} {ctx : Ctx} (inv : MappedCtxInv f ctx)
    {ii : Nat} {info : IInfo} {ty : Clif.Ty} {imm : BitVec ty.width}
    (source : ctx.insts[ii]? = some info) (clif : info.clif = some (.iconst ty imm)) :
    (ty.width = 8 ∨ ty.width = 16 ∨ ty.width = 32 ∨ ty.width = 64) ∧ info.data = .data 152 35 [.data 151 57 [],.int (imm64OfIconst ty imm)] ∧
      info.resTys.head? = some (.int ty.width) := by
  have accepted := inv.instE ii info _ source clif
  have supported : eTy ty = true := by simpa [Compile.instE,Compile.tyE,eTy] using accepted
  have raw := inv.data ii info _ source clif
  obtain ⟨types,result,typed,_⟩ := inv.resTys ii info _ source clif
  simp only [Clif.Inst.resultTypes] at result
  cases result
  refine ⟨?_,?_,by rw [typed]; simp [ofClif_int_width]⟩
  · cases ty <;> simp [eTy,Clif.Ty.width] at supported ⊢
  · have expected : instData f (.iconst ty imm) =
        .ok (.data 152 35 [.data 151 57 [],.int (imm64OfIconst ty imm)]) := by
      simp [instData,supported]; rfl
    exact Except.ok.inj (raw.symm.trans expected)


end Backend.Stock.Proof.ConstantSourceDataDraft
