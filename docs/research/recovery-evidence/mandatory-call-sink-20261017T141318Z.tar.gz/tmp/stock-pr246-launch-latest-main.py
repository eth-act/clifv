from pathlib import Path
import json,time,subprocess as sp,datetime
state=Path('/tmp/stock-pr246-latest-main-launch-state.json')
def report(status,**kw):state.write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':status,**kw},indent=2)+'\n')
report('waiting_old_base_runtime_preflight')
while True:
 p=json.loads(Path('/tmp/stock-pr246-runtime-preflight-state.json').read_text())
 if p['status']=='failed':report('needs_preflight_triage',preflight=p);raise SystemExit(1)
 if p['status']=='old_base_preflight_passed_pending_latest_main_gates':break
 time.sleep(5)
# Optional warm-cache coordination does not become an indefinite dependency.
# Existing per-PR gates run locally unless a compatible cache is supplied.
Path('/tmp/stock-pr246-integrated-completion-audit.py').write_bytes(Path('/tmp/stock-pr246-latest-main-completion-audit.py').read_bytes())
with Path('/tmp/stock-pr246-review-preparation-latest-controller.log').open('w') as helperlog:
 helper=sp.Popen(['python3','/tmp/stock-drafts-prepare-review.py','246'],stdout=helperlog,stderr=sp.STDOUT,start_new_session=True)
report('running_latest_main_gates',head='a071e715d1feea0266c86c3b46d5cb96db885c91',review_helper_pid=helper.pid,cache_handoff='requested, optional; do not waive per-PR gates')
with Path('/tmp/stock-pr246-latest-main-gates-controller.log').open('w') as log:p=sp.run(['python3','/tmp/stock-pr246-latest-main-gates.py'],stdout=log,stderr=sp.STDOUT)
report('latest_main_gates_terminal',returncode=p.returncode)
raise SystemExit(p.returncode)
