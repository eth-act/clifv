import StockConstantSourceSelection
import FV.Backend.Proof.StockSelectScanRefines
namespace Backend.Stock.Proof.ConstantScanDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open ConstantSourceSelectionDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
attribute [local irreducible] Stock.runTerm scanBlock emitBranch
private theorem scans_execute {exec : Nat → State → Except String Scan}
    {indices : List Nat} {input : State} {output : BlockScan}
    (cert : ScansSpec exec indices input output) :
    ∀ record ∈ output.records, exec record.inst record.input = .ok record.output := by
  induction cert with
  | nil input => simp
  | cons head rest ih =>
    intro record member
    rcases List.mem_cons.mp member with rfl | member
    · exact head
    · exact ih record member

private theorem record_execute {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) {event : BlockScanEvent}
    (events : event ∈ result.blockScans.toList) {record : ScanRecord}
    (records : record ∈ event.output.records) :
    scanInstruction event.ctx event.block record.inst event.termInst event.isBranch record.input =
      .ok record.output := by
  obtain ⟨ranges, params, earlier, suffix, starting, finishing, before, after,
    label, bi, data, core, build, ordered, initial, empty, parts, folded,
    final, prefixRun, nodeRun, suffixRun, node, coreRun, eventEq, stateEq⟩ :=
    stock_lower_blockScanOrigin run events
  rw [eventEq] at records ⊢
  have actual := (stock_lowerBlockCore_scanOrigin coreRun).2.2.2.2.2
  unfold scanBlock at actual
  exact scans_execute (runScans_spec actual) record records


private theorem emission_root {ctx : Ctx} {ii : Nat} {before : State} {emission : Emission}
    (run : emitInstruction ctx ii before = .ok emission) :
    ∃ rss next trace,Stock.runTerm ctx "lower" [.inst ii] before = .ok (some (.regsVec rss),next,trace) := by
  unfold emitInstruction at run
  cases root : Stock.runTerm ctx "lower" [.inst ii] before with
  | error err => simp only [root,bind,Except.bind] at run; cases run
  | ok value =>
    obtain ⟨out,next,trace⟩ := value
    cases out with
    | none => simp only [root,bind,Except.bind] at run; cases run
    | some value =>
      cases value <;> simp only [root,bind,Except.bind] at run
      all_goals first | (solve | cases run) | exact ⟨_,next,trace,rfl⟩

/-- An actual emitted scalar constant discharges its guarded source scan
obligation. Actual emitter/root success and original context derive every
matcher/RHS receipt internally; no caller selector certificate is added. -/
theorem stock_lower_constant_scan_fall_refines {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    {event : BlockScanEvent} {record : ScanRecord}
    (events : event ∈ result.blockScans.toList) (records : record ∈ event.output.records)
    {bi j : Nat} {b : Clif.Block} {stm : Clif.Stmt}
    (block : f.blocks[bi]? = some b) (statement : b.body[j]? = some stm)
    (current : record.inst = blockStart f bi + j)
    {info : IInfo} {ty : Clif.Ty} {imm : BitVec ty.width} {x a : Nat}
    (source : event.ctx.insts[record.inst]? = some info) (clif : info.clif = some (.iconst ty imm))
    (results : info.results = [x]) (statementResults : stm.results = [x])
    (mapped : event.ctx.valueReg? x = some (.vreg a .int))
    {step : Step} (recorded : record.output.step = some step) (emitted : step.decision = .emitted)
    {F : BitVec 64 → Prop} {isem : Sem} (refines : Refines F isem)
    (renameLaw : ∀ aliases i,isem (i.mapRegs
      (Backend.lowerFunction.resolve aliases (aliases.size+1))) = isem i)
    {MR : MemRelT} (stable : MRStable F MR) {env : Clif.Env} {cp : Clif.Program} :
    ScanFallRefines (IndexedSourceInst env cp f event.ctx bi) isem result.final.alias
      (GuardedScanRel f result event.ctx bi MR) record := by
  have context := (stock_lower_record_context lowered scope events).1
  obtain ⟨emission,emissionRun,_⟩ := stock_emitted_scan (record_execute lowered events records) recorded emitted
  obtain ⟨rss,next,trace,root⟩ := emission_root emissionRun
  obtain ⟨evalTrace,matched,evaluated⟩ := stock_constant_original_selected_rhs context source clif root
  obtain ⟨_,_,_,transfer⟩ := stock_lower_constant_available_source lowered scope dominated events records
    block statement current source clif statementResults results mapped recorded emitted refines renameLaw
    (by decide : 2 ≤ 999825) (by decide : 50 ≤ 999999) matched evaluated root
  intro s s' indexed rho w related
  obtain ⟨index,advance,sourceStep⟩ := indexed
  have position : s.1 = j := Nat.add_left_cancel (index.symm.trans current)
  obtain ⟨func,dfg,memory,values⟩ := related
  rw [position] at dfg values
  have postDFG := stock_lower_source_step_dfg lowered scope dominated events block statement current func dfg sourceStep
  have preserve : ∀ cm w w',SameWorld F w' w → MR s.2.1.slots cm w → MR s.2.1.slots cm w' := by
    intro cm w w' same memory
    exact stable _ _ _ _ ⟨fun field unmasked _ => same.1 field unmasked,same.2.1,same.2.2⟩ memory
  obtain ⟨final,w',run,postMemory,postValues⟩ := transfer env cp (fun cm w => MR s.2.1.slots cm w)
    preserve s.2.1 s'.2.1 s.2.2 s'.2.2 rho w sourceStep memory values
  obtain ⟨info',inst,vals,regs,rest,found,original,body,evaluated,written,updated⟩ := sourceStep
  have func' : s'.2.1.func = f := by rw [updated]; exact func
  have slots : s'.2.1.slots = s.2.1.slots := by rw [updated]
  refine ⟨final,w',run,func',?_,?_,?_⟩
  · simpa only [advance,position] using postDFG
  · rw [slots]; exact postMemory
  · simpa only [advance,position] using postValues
end Backend.Stock.Proof.ConstantScanDraft
