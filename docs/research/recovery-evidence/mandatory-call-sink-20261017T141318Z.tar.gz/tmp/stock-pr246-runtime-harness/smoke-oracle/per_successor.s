  .globl per_successor
  .type per_successor, %function
  .p2align 2
per_successor:
.L0_b0:
  stp x29, x30, [sp, #-16]!
  mov x29, sp
  cbnz x0, .L0_b2
.L0_b1:
  mov x0, x2
  ldp x29, x30, [sp], #16
  ret
.L0_b2:
  mov x0, x1
  ldp x29, x30, [sp], #16
  ret
  .ifne . - per_successor - 36
  .error "function size mismatch"
  .endif
  .size per_successor, . - per_successor
