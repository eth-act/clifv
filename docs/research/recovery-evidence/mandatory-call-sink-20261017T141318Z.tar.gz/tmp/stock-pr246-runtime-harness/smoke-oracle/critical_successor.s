  .globl critical_successor
  .type critical_successor, %function
  .p2align 2
critical_successor:
.L1_b0:
  stp x29, x30, [sp, #-16]!
  mov x29, sp
  cbnz x0, .L1_b2
.L1_b1:
  mov x0, x2
  b .L1_b3
.L1_b2:
  mov x0, x1
.L1_b3:
  ldp x29, x30, [sp], #16
  ret
  .ifne . - critical_successor - 32
  .error "function size mismatch"
  .endif
  .size critical_successor, . - critical_successor
