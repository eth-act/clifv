  .globl fuzzgen_2
  .type fuzzgen_2, %function
  .p2align 2
fuzzgen_2:
.L0_b0:
  stp x29, x30, [sp, #-16]!
  mov x29, sp
  ubfm w7, w0, #0, #15
  cbnz w7, .L0_b2
.L0_b1:
  mov x1, x0
  b .L0_b5
.L0_b2:
  mov x1, x0
  ubfm w9, w0, #0, #15
  cbnz w9, .L0_b3
.L0_b4:
  mov x0, x1
  b .L0_b5
.L0_b3:
  mov x0, x1
.L0_b5:
  ldp x29, x30, [sp], #16
  ret
  .ifne . - fuzzgen_2 - 56
  .error "function size mismatch"
  .endif
  .size fuzzgen_2, . - fuzzgen_2
