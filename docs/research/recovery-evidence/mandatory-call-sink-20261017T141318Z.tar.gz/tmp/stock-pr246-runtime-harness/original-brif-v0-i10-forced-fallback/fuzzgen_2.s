  .globl fuzzgen_2
  .type fuzzgen_2, %function
  .p2align 2
fuzzgen_2:
.L0_b0:
  stp x29, x30, [sp, #-16]!
  mov x29, sp
  sub sp, sp, #288
  stur x19, [sp, #208]
  stur x20, [sp, #216]
  stur x21, [sp, #224]
  stur x22, [sp, #232]
  stur x23, [sp, #240]
  stur x24, [sp, #248]
  str x25, [sp, #256]
  str x26, [sp, #264]
  str x27, [sp, #272]
  str x28, [sp, #280]
  stur q8, [sp, #80]
  stur q9, [sp, #96]
  stur q10, [sp, #112]
  stur q11, [sp, #128]
  stur q12, [sp, #144]
  stur q13, [sp, #160]
  stur q14, [sp, #176]
  stur q15, [sp, #192]
  stur x0, [sp, #0]
  ldur x1, [sp, #0]
  ubfm w0, w1, #0, #15
  stur x0, [sp, #8]
  ldur x0, [sp, #8]
  cbnz w0, .L0_b2
.L0_b1:
  ldur x9, [sp, #0]
  stur x9, [sp, #56]
  ldur x9, [sp, #0]
  stur x9, [sp, #64]
  ldur x9, [sp, #56]
  stur x9, [sp, #40]
  ldur x9, [sp, #64]
  stur x9, [sp, #48]
  b .L0_b5
.L0_b2:
  ldur x9, [sp, #0]
  stur x9, [sp, #56]
  ldur x9, [sp, #0]
  stur x9, [sp, #64]
  ldur x9, [sp, #56]
  stur x9, [sp, #16]
  ldur x9, [sp, #64]
  stur x9, [sp, #24]
  ldur x1, [sp, #16]
  ubfm w0, w1, #0, #15
  stur x0, [sp, #32]
  ldur x0, [sp, #32]
  cbnz w0, .L0_b3
.L0_b4:
  ldur x9, [sp, #24]
  stur x9, [sp, #56]
  ldur x9, [sp, #24]
  stur x9, [sp, #64]
  ldur x9, [sp, #56]
  stur x9, [sp, #40]
  ldur x9, [sp, #64]
  stur x9, [sp, #48]
  b .L0_b5
.L0_b3:
  ldur x9, [sp, #24]
  stur x9, [sp, #56]
  ldur x9, [sp, #24]
  stur x9, [sp, #64]
  ldur x9, [sp, #56]
  stur x9, [sp, #40]
  ldur x9, [sp, #64]
  stur x9, [sp, #48]
.L0_b5:
  ldur x19, [sp, #208]
  ldur x20, [sp, #216]
  ldur x21, [sp, #224]
  ldur x22, [sp, #232]
  ldur x23, [sp, #240]
  ldur x24, [sp, #248]
  ldr x25, [sp, #256]
  ldr x26, [sp, #264]
  ldr x27, [sp, #272]
  ldr x28, [sp, #280]
  ldur q8, [sp, #80]
  ldur q9, [sp, #96]
  ldur q10, [sp, #112]
  ldur q11, [sp, #128]
  ldur q12, [sp, #144]
  ldur q13, [sp, #160]
  ldur q14, [sp, #176]
  ldur q15, [sp, #192]
  ldur x0, [sp, #40]
  ldur x1, [sp, #48]
  add sp, sp, #288
  ldp x29, x30, [sp], #16
  ret
  .ifne . - fuzzgen_2 - 356
  .error "function size mismatch"
  .endif
  .size fuzzgen_2, . - fuzzgen_2
