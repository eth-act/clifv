  .globl fibonacci_recursive
  .type fibonacci_recursive, %function
  .p2align 2
fibonacci_recursive:
.L0_b0:
  stp x29, x30, [sp, #-16]!
  mov x29, sp
  sub sp, sp, #304
  stur x19, [sp, #224]
  stur x20, [sp, #232]
  stur x21, [sp, #240]
  stur x22, [sp, #248]
  str x23, [sp, #256]
  str x24, [sp, #264]
  str x25, [sp, #272]
  str x26, [sp, #280]
  str x27, [sp, #288]
  str x28, [sp, #296]
  stur q8, [sp, #96]
  stur q9, [sp, #112]
  stur q10, [sp, #128]
  stur q11, [sp, #144]
  stur q12, [sp, #160]
  stur q13, [sp, #176]
  stur q14, [sp, #192]
  stur q15, [sp, #208]
  stur x0, [sp, #0]
  ldur x0, [sp, #0]
  subs wzr, w0, #2
  b.ls .L0_b2
.L0_b1:
  ldur x9, [sp, #0]
  stur x9, [sp, #80]
  ldur x9, [sp, #80]
  stur x9, [sp, #8]
  ldur x1, [sp, #8]
  sub w0, w1, #1
  stur x0, [sp, #16]
  adrp x0, :got:fibonacci_recursive
  ldr x0, [x0, :got_lo12:fibonacci_recursive]
  stur x0, [sp, #24]
  ldur x19, [sp, #24]
  ldur x0, [sp, #16]
  blr x19
  stur x0, [sp, #32]
  ldur x1, [sp, #8]
  sub w0, w1, #2
  stur x0, [sp, #40]
  adrp x0, :got:fibonacci_recursive
  ldr x0, [x0, :got_lo12:fibonacci_recursive]
  stur x0, [sp, #48]
  ldur x19, [sp, #48]
  ldur x0, [sp, #40]
  blr x19
  stur x0, [sp, #56]
  ldur x1, [sp, #32]
  ldur x2, [sp, #56]
  add w0, w1, w2
  stur x0, [sp, #64]
  ldur x19, [sp, #224]
  ldur x20, [sp, #232]
  ldur x21, [sp, #240]
  ldur x22, [sp, #248]
  ldr x23, [sp, #256]
  ldr x24, [sp, #264]
  ldr x25, [sp, #272]
  ldr x26, [sp, #280]
  ldr x27, [sp, #288]
  ldr x28, [sp, #296]
  ldur q8, [sp, #96]
  ldur q9, [sp, #112]
  ldur q10, [sp, #128]
  ldur q11, [sp, #144]
  ldur q12, [sp, #160]
  ldur q13, [sp, #176]
  ldur q14, [sp, #192]
  ldur q15, [sp, #208]
  ldur x0, [sp, #64]
  add sp, sp, #304
  ldp x29, x30, [sp], #16
  ret
.L0_b2:
  movz w0, #0x1, lsl #0
  stur x0, [sp, #72]
  ldur x19, [sp, #224]
  ldur x20, [sp, #232]
  ldur x21, [sp, #240]
  ldur x22, [sp, #248]
  ldr x23, [sp, #256]
  ldr x24, [sp, #264]
  ldr x25, [sp, #272]
  ldr x26, [sp, #280]
  ldr x27, [sp, #288]
  ldr x28, [sp, #296]
  ldur q8, [sp, #96]
  ldur q9, [sp, #112]
  ldur q10, [sp, #128]
  ldur q11, [sp, #144]
  ldur q12, [sp, #160]
  ldur q13, [sp, #176]
  ldur q14, [sp, #192]
  ldur q15, [sp, #208]
  ldur x0, [sp, #72]
  add sp, sp, #304
  ldp x29, x30, [sp], #16
  ret
  .ifne . - fibonacci_recursive - 396
  .error "function size mismatch"
  .endif
  .size fibonacci_recursive, . - fibonacci_recursive
