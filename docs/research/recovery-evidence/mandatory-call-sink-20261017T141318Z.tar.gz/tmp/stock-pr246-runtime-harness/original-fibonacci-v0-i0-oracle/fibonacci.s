  .globl fibonacci
  .type fibonacci, %function
  .p2align 2
fibonacci:
.L0_b0:
  stp x29, x30, [sp, #-16]!
  mov x29, sp
  movz w5, #0x1, lsl #0
  subs wzr, w0, #2
  b.ls .L0_b1
.L0_b2:
  movz w9, #0x1, lsl #0
  sub w8, w0, #2
.L0_b3:
  add w0, w5, w9
  sub w8, w8, #1
  cbz w8, .L0_b4
.L0_b5:
  mov x9, x5
  mov x5, x0
  b .L0_b3
.L0_b4:
  b .L0_b6
.L0_b1:
  mov x0, x5
.L0_b6:
  ldp x29, x30, [sp], #16
  ret
  .ifne . - fibonacci - 68
  .error "function size mismatch"
  .endif
  .size fibonacci, . - fibonacci
