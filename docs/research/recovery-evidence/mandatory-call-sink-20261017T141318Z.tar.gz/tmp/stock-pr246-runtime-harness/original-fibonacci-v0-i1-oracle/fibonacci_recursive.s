  .globl fibonacci_recursive
  .type fibonacci_recursive, %function
  .p2align 2
fibonacci_recursive:
.L0_b0:
  stp x29, x30, [sp, #-16]!
  mov x29, sp
  sub sp, sp, #16
  stur x19, [sp, #0]
  subs wzr, w0, #2
  mov x19, x0
  b.ls .L0_b2
.L0_b1:
  mov x1, x19
  sub w0, w1, #1
  adrp x12, :got:fibonacci_recursive
  ldr x12, [x12, :got_lo12:fibonacci_recursive]
  blr x12
  mov x1, x0
  mov x0, x19
  mov x19, x1
  sub w0, w0, #2
  adrp x12, :got:fibonacci_recursive
  ldr x12, [x12, :got_lo12:fibonacci_recursive]
  blr x12
  mov x1, x19
  add w0, w1, w0
  ldur x19, [sp, #0]
  add sp, sp, #16
  ldp x29, x30, [sp], #16
  ret
.L0_b2:
  movz w0, #0x1, lsl #0
  ldur x19, [sp, #0]
  add sp, sp, #16
  ldp x29, x30, [sp], #16
  ret
  .ifne . - fibonacci_recursive - 120
  .error "function size mismatch"
  .endif
  .size fibonacci_recursive, . - fibonacci_recursive
