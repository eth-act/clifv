  .globl fibonacci
  .type fibonacci, %function
  .p2align 2
fibonacci:
.L0_b0:
  stp x29, x30, [sp, #-16]!
  mov x29, sp
  sub sp, sp, #336
  str x19, [sp, #256]
  str x20, [sp, #264]
  str x21, [sp, #272]
  str x22, [sp, #280]
  str x23, [sp, #288]
  str x24, [sp, #296]
  str x25, [sp, #304]
  str x26, [sp, #312]
  str x27, [sp, #320]
  str x28, [sp, #328]
  stur q8, [sp, #128]
  stur q9, [sp, #144]
  stur q10, [sp, #160]
  stur q11, [sp, #176]
  stur q12, [sp, #192]
  stur q13, [sp, #208]
  stur q14, [sp, #224]
  stur q15, [sp, #240]
  stur x0, [sp, #0]
  movz w0, #0x1, lsl #0
  stur x0, [sp, #8]
  ldur x0, [sp, #0]
  subs wzr, w0, #2
  b.ls .L0_b1
.L0_b2:
  ldur x9, [sp, #0]
  stur x9, [sp, #96]
  ldur x9, [sp, #8]
  stur x9, [sp, #104]
  ldur x9, [sp, #96]
  stur x9, [sp, #16]
  ldur x9, [sp, #104]
  stur x9, [sp, #24]
  movz w0, #0x1, lsl #0
  stur x0, [sp, #40]
  ldur x1, [sp, #16]
  sub w0, w1, #2
  stur x0, [sp, #32]
  ldur x9, [sp, #32]
  stur x9, [sp, #96]
  ldur x9, [sp, #24]
  stur x9, [sp, #104]
  ldur x9, [sp, #40]
  stur x9, [sp, #112]
  ldur x9, [sp, #96]
  stur x9, [sp, #48]
  ldur x9, [sp, #104]
  stur x9, [sp, #56]
  ldur x9, [sp, #112]
  stur x9, [sp, #64]
.L0_b3:
  ldur x1, [sp, #56]
  ldur x2, [sp, #64]
  add w0, w1, w2
  stur x0, [sp, #72]
  ldur x1, [sp, #48]
  sub w0, w1, #1
  stur x0, [sp, #80]
  ldur x0, [sp, #80]
  cbz w0, .L0_b4
.L0_b5:
  ldur x9, [sp, #80]
  stur x9, [sp, #96]
  ldur x9, [sp, #72]
  stur x9, [sp, #104]
  ldur x9, [sp, #56]
  stur x9, [sp, #112]
  ldur x9, [sp, #96]
  stur x9, [sp, #48]
  ldur x9, [sp, #104]
  stur x9, [sp, #56]
  ldur x9, [sp, #112]
  stur x9, [sp, #64]
  b .L0_b3
.L0_b4:
  ldur x9, [sp, #72]
  stur x9, [sp, #96]
  ldur x9, [sp, #96]
  stur x9, [sp, #88]
  b .L0_b6
.L0_b1:
  ldur x9, [sp, #8]
  stur x9, [sp, #96]
  ldur x9, [sp, #96]
  stur x9, [sp, #88]
.L0_b6:
  ldr x19, [sp, #256]
  ldr x20, [sp, #264]
  ldr x21, [sp, #272]
  ldr x22, [sp, #280]
  ldr x23, [sp, #288]
  ldr x24, [sp, #296]
  ldr x25, [sp, #304]
  ldr x26, [sp, #312]
  ldr x27, [sp, #320]
  ldr x28, [sp, #328]
  ldur q8, [sp, #128]
  ldur q9, [sp, #144]
  ldur q10, [sp, #160]
  ldur q11, [sp, #176]
  ldur q12, [sp, #192]
  ldur q13, [sp, #208]
  ldur q14, [sp, #224]
  ldur q15, [sp, #240]
  ldur x0, [sp, #88]
  add sp, sp, #336
  ldp x29, x30, [sp], #16
  ret
  .ifne . - fibonacci - 420
  .error "function size mismatch"
  .endif
  .size fibonacci, . - fibonacci
