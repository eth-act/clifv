  .globl brif_different_args
  .type brif_different_args, %function
  .p2align 2
brif_different_args:
.L0_b0:
  stp x29, x30, [sp, #-16]!
  mov x29, sp
  ands wzr, w0, #0xff
  b.ne .L0_b2
.L0_b1:
  ldp x29, x30, [sp], #16
  ret
.L0_b2:
  mov x6, x0
  add w0, w0, w6
  ldp x29, x30, [sp], #16
  ret
  .ifne . - brif_different_args - 40
  .error "function size mismatch"
  .endif
  .size brif_different_args, . - brif_different_args
