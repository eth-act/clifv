  .globl critical_successor
  .type critical_successor, %function
  .p2align 2
critical_successor:
.L1_b0:
  stp x29, x30, [sp, #-16]!
  mov x29, sp
  sub sp, sp, #256
  stur x19, [sp, #176]
  stur x20, [sp, #184]
  stur x21, [sp, #192]
  stur x22, [sp, #200]
  stur x23, [sp, #208]
  stur x24, [sp, #216]
  stur x25, [sp, #224]
  stur x26, [sp, #232]
  stur x27, [sp, #240]
  stur x28, [sp, #248]
  stur q8, [sp, #48]
  stur q9, [sp, #64]
  stur q10, [sp, #80]
  stur q11, [sp, #96]
  stur q12, [sp, #112]
  stur q13, [sp, #128]
  stur q14, [sp, #144]
  stur q15, [sp, #160]
  stur x0, [sp, #0]
  stur x1, [sp, #8]
  stur x2, [sp, #16]
  ldur x0, [sp, #0]
  cbnz x0, .L1_b2
.L1_b1:
  ldur x9, [sp, #16]
  stur x9, [sp, #40]
  ldur x9, [sp, #40]
  stur x9, [sp, #32]
  b .L1_b3
.L1_b2:
  ldur x9, [sp, #8]
  stur x9, [sp, #40]
  ldur x9, [sp, #40]
  stur x9, [sp, #24]
  ldur x9, [sp, #24]
  stur x9, [sp, #40]
  ldur x9, [sp, #40]
  stur x9, [sp, #32]
.L1_b3:
  ldur x19, [sp, #176]
  ldur x20, [sp, #184]
  ldur x21, [sp, #192]
  ldur x22, [sp, #200]
  ldur x23, [sp, #208]
  ldur x24, [sp, #216]
  ldur x25, [sp, #224]
  ldur x26, [sp, #232]
  ldur x27, [sp, #240]
  ldur x28, [sp, #248]
  ldur q8, [sp, #48]
  ldur q9, [sp, #64]
  ldur q10, [sp, #80]
  ldur q11, [sp, #96]
  ldur q12, [sp, #112]
  ldur q13, [sp, #128]
  ldur q14, [sp, #144]
  ldur q15, [sp, #160]
  ldur x0, [sp, #32]
  add sp, sp, #256
  ldp x29, x30, [sp], #16
  ret
  .ifne . - critical_successor - 244
  .error "function size mismatch"
  .endif
  .size critical_successor, . - critical_successor
