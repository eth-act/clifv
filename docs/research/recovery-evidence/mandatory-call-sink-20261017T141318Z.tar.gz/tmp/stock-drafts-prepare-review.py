from pathlib import Path
import subprocess as sp,json,os,time,sys,datetime,hashlib
pr=int(sys.argv[1]);view=Path('/home/lee/clifv/.worktrees/stock-delivery-gates');canon=Path('/home/lee/clifv/.worktrees/driver-proof-resume');state=Path(f'/tmp/stock-pr{pr}-review-preparation.json');now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
config=Path(f'/tmp/stock-pr{pr}-'+('main-integration' if pr==246 else 'after-squash')+'.json');expected=json.loads(config.read_text())['head']
def report(status,**kw):
 state.write_text(json.dumps({'utc':now(),'pr':pr,'commit':expected,'status':status,'pid':os.getpid(),**kw},indent=2)+'\n')
report('waiting_required_gates')
try:
 while True:
  progress=json.loads(Path(f'/tmp/stock-pr{pr}-gates-progress.json').read_text())
  if progress['commit']==expected:
   assert progress['state']!='failed',progress
   if progress['state'] in ['review_ready','trust_review']:
    receipt=json.loads(Path(f'/tmp/stock-pr{pr}-gates-receipt.json').read_text());assert receipt['commit']==expected and receipt['success'] and not receipt['trust_review_required'];break
  time.sleep(5)
 report('completion_audit')
 env=dict(os.environ,PATH='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:/home/lee/.cargo/bin:'+os.environ['PATH'],OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',FV_MEMCAP='22G')
 log=Path(f'/tmp/stock-pr{pr}-review-preparation.log')
 with log.open('w') as out:
  sp.run(['python3',f'/tmp/stock-pr{pr}-integrated-completion-audit.py'],env=env,stdout=out,stderr=sp.STDOUT,check=True)
  sp.run(['python3',f'/tmp/stock-pr{pr}-mcp-bundle.py'],env=env,stdout=out,stderr=sp.STDOUT,check=True)
  cfg=json.loads(Path(f'/tmp/stock-pr{pr}-mcp-bundle.json').read_text());p=Path(cfg['file_path']);source=p.read_text();source+='\n#print axioms '+cfg['theorem_name']+'\n';p.write_text(source)
  cfg['source_sha256']=hashlib.sha256(source.encode()).hexdigest();Path(f'/tmp/stock-pr{pr}-mcp-bundle.json').write_text(json.dumps(cfg,indent=2)+'\n')
  report('normal_bundle_compile',log=str(log),config=f'/tmp/stock-pr{pr}-mcp-bundle.json')
  sp.run([str(view/'scripts/memcap.sh'),'/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin/lake','env','lean','DeliveryAudit.lean'],cwd=view,env=env,stdout=out,stderr=sp.STDOUT,check=True)
 report('mcp_ready',log=str(log),config=f'/tmp/stock-pr{pr}-mcp-bundle.json',normal_compile_rc=0)
except BaseException as error:
 report('failed',error=repr(error));raise
