import StockScalarBodyRefines
import StockBodySteps
import FV.Backend.Proof.RefinesCSem
namespace Backend.Stock.Proof.ScalarBodyStepsDraft
open Backend.Proof Backend.Proof.Driver ScalarBodyRefinesDraft BodyStepsDraft FallStepsDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
theorem stock_lower_actual_scalar_body_steps {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    {event : BlockScanEvent} (events : event ∈ result.blockScans.toList)
    {F : BitVec 64 → Prop} {isem : Sem} (refines : Refines F isem)
    (renameLaw : ∀ aliases i,isem (i.mapRegs
      (Backend.lowerFunction.resolve aliases (aliases.size+1))) = isem i)
    (terminalSem : ∀ i,i.isTerminator = true → ∀ uses outs w w',isem i uses w ≠ some (outs,w',.next))
    {MR : MemRelT} (stable : MRStable F MR) {env : Clif.Env} {cp : Clif.Program} :
    ∃ (b : Clif.Block) (term : ScanRecord) (body : BlockScan) (label : Nat) (vb : VBlock) (prelude : Array MInst),
      SourceBodySplit f event b term body ∧ result.code.blocks[label]? = some vb ∧
      ((∀ r ∈ body.records,ScalarBodyRecord f event.ctx event.block r) →
        ∀ s s',SourceSteps (IndexedSourceInst env cp f event.ctx event.block)
          ((List.range b.body.length).map (blockStart f event.block + ·)) s s' →
        ∀ rho w,GuardedScanRel f result event.ctx event.block MR event.output.state s rho w →
          ∃ final w',seqRun isem (body.code.toList.map (·.mapRegs
            (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1)))) rho w = some (.fall final w') ∧
            Star (VStepAt result.code result.edgeArgs isem) (.run ⟨label,prelude.size,rho,w⟩)
              (.run ⟨label,prelude.size+body.code.size,final,w'⟩) ∧
            GuardedScanRel f result event.ctx event.block MR term.output.state s' final w') := by
  obtain ⟨b,term,body,split,semantic⟩ := stock_lower_actual_scalar_body_refines lowered scope dominated events refines renameLaw stable
    (env := env) (cp := cp)
  obtain ⟨label,vb,prelude,afterCode,placed,code,execution⟩ := stock_lower_body_fall_steps lowered scope events split
  refine ⟨b,term,body,label,vb,prelude,split,placed,?_⟩
  intro families s s' source rho w related
  obtain ⟨final,w',run,post⟩ := semantic families s s' source rho w related
  exact ⟨final,w',run,execution _ _ isem terminalSem _ _ _ _ run,post⟩

end Backend.Stock.Proof.ScalarBodyStepsDraft
