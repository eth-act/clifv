from pathlib import Path
import json,subprocess as sp,time,os,datetime,hashlib
root=Path('/home/lee/clifv/.worktrees/stock-delivery-gates');record=json.loads(Path('/tmp/stock-pr246-upstream-handoff.json').read_text());state=Path('/tmp/stock-pr246-runtime-preflight-state.json');now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def report(status,**kw):state.write_text(json.dumps({'utc':now(),'status':status,'pid':os.getpid(),**kw},indent=2)+'\n')
def proc(pid):
 try:
  fields=Path('/proc',str(pid),'stat').read_text().split(') ',1)[1].split();return {'state':fields[0],'exit_code':int(fields[49])}
 except FileNotFoundError:return None
report('waiting_current_kernels')
try:
 assert proc(record['old_worker'])['state'] in ['T','t'] and proc(record['old_scheduler'])['state'] in ['T','t']
 while True:
  statuses={c:proc(c) for c in record['children']}
  if all(p is None or p['state']=='Z' for p in statuses.values()):break
  time.sleep(5)
 for child,p in statuses.items():
  if p:assert p['exit_code']==0,(child,p)
 manifest=json.loads(Path('/tmp/stock-pr246-gates-inputs.json').read_text());old=json.loads(Path('/tmp/stock-pr246-main-integration-before-9a3e5f8c.json').read_text());assert manifest['commit']==old['head']
 for d in ['sources','scripts']:
  for p,h in manifest[d].items():assert hashlib.sha256((root/p).read_bytes()).hexdigest()==h,p
 leasepath=Path('/tmp/stock-delivery-cache-lease.json');lease=json.loads(leasepath.read_text());assert lease['commit']==old['head'] and lease['state']=='running_exact_PR_gates'
 lease.update(state='held_for_runtime_preflight',preflight_pid=os.getpid(),new_module_launches_held=True,old_running_kernels_completed_rc0=True,latest_main='9a3e5f8c0f8de56c07705f84c670b86de387bc2c');leasepath.write_text(json.dumps(lease,indent=2)+'\n')
 source=Path('/tmp/stock-pr246-harness-check.py').read_text().replace("lease['state']=='held_for_review'", "lease['state']=='held_for_runtime_preflight'").replace("Path('/tmp/stock-pr246-main-integration.json')", "Path('/tmp/stock-pr246-main-integration-before-9a3e5f8c.json')")
 source=source.replace("assert json.loads(Path('/tmp/stock-pr246-review-preparation.json').read_text())['status']=='mcp_ready'", "assert lease['old_running_kernels_completed_rc0'] and lease['new_module_launches_held']")
 source=source.replace('/tmp/stock-pr246-runtime-harness','/tmp/stock-pr246-runtime-preflight').replace("'success':True}","'success':True,'gate_status':'OLD_BASE_BEHAVIOR_PREFLIGHT_ONLY; NOT_LATEST_MAIN_MERGE_CERTIFICATE'}")
 script=Path('/tmp/stock-pr246-old-base-runtime-preflight.py');script.write_text(source);report('running_old_base_runtime_preflight',commit=old['head'],latest_published_head='a071e715d1feea0266c86c3b46d5cb96db885c91')
 with Path('/tmp/stock-pr246-old-base-runtime-preflight.log').open('w') as log:p=sp.run(['python3',str(script)],stdout=log,stderr=sp.STDOUT)
 assert p.returncode==0,p.returncode
 lease.update(state='held_for_latest_main_reconciliation',old_base_runtime_preflight_rc=0);leasepath.write_text(json.dumps(lease,indent=2)+'\n');report('old_base_preflight_passed_pending_latest_main_gates',receipt='/tmp/stock-pr246-runtime-preflight.json')
except BaseException as e:report('failed',error=repr(e));raise
