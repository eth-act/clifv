from pathlib import Path
import os,sys,json,datetime,hashlib,re,subprocess as sp,time,signal,traceback
canon=Path('/home/lee/clifv/.worktrees/driver-proof-resume');view=Path('/home/lee/clifv/.worktrees/stock-delivery-gates');expected='088111278aecc094fc87937525b79cba2e88b8b3';pr=246
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');prefix=Path('/tmp/stock-pr246-integrated-gates-'+stamp);progress=Path('/tmp/stock-pr246-gates-progress.json');leasePath=Path('/tmp/stock-delivery-cache-lease.json');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();controller=1233457
logs={};lease={};held=False;finished=False

def proc(pid):
 try:
  fields=Path('/proc',str(pid),'stat').read_text().split(') ',1)[1].split()
  return {'state':fields[0],'exit_code':int(fields[49]),'cmdline':Path('/proc',str(pid),'cmdline').read_bytes().replace(b'\0',b' ').decode()}
 except FileNotFoundError:return None

def frozen():
 f=json.loads(Path('/tmp/stock-coherent-build-inputs.json').read_text())
 assert {str(p.relative_to(canon)):sha(p) for d in ['FV','FVTest'] for p in (canon/d).rglob('*.lean')}==f['source_sha256']
 for p,h in f['validation_script_sha256'].items():assert sha(canon/p)==h,p

def report(state,**kw):
 d={'utc':now(),'state':state,'pid':os.getpid(),'pr':pr,'view':str(view),'commit':expected,'canonical_controller':controller,'cache_lease':str(leasePath),'completed_phases':logs,**kw};progress.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items() if k!='completed_phases'}),flush=True)

def release(reason):
 global held
 if held:
  frozen();p=proc(controller)
  if p:
   assert 'python3 /tmp/stock-coherent-serial-build.py' in p['cmdline'],p
   os.kill(controller,signal.SIGCONT)
  lease.update(state='released',released_utc=now(),reason=reason,canonical_handle_present=bool(p));leasePath.write_text(json.dumps(lease,indent=2)+'\n');held=False

if '--release' in sys.argv:
 lease=json.loads(leasePath.read_text());assert lease['pr']==pr and lease['state'] in ['waiting_current_kernel','running_exact_PR_gates','held_for_review'];held=True;release('Explicit release after review/gate scheduling');print('Same canonical controller resumed');sys.exit(0)

env=dict(os.environ,PATH='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:/home/lee/.cargo/bin:'+os.environ['PATH'],OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',FV_MEMCAP='22G',CLIF_NATIVE_QEMU='/home/lee/.local/share/clifv-test-tools/usr/bin/qemu-aarch64-static',LLVM_MC='/home/lee/.local/share/clifv-test-tools/usr/bin/llvm-mc')
lake='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin/lake';cap=str(view/'scripts/memcap.sh')

def clean_view():
 assert sp.check_output(['git','rev-parse','HEAD'],cwd=view,text=True).strip()==expected
 assert not sp.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=view,text=True).strip()
 if 'manifest' in globals():
  assert {str(p.relative_to(view)):sha(p) for d in ['FV','FVTest'] for p in (view/d).rglob('*.lean')}==manifest['sources']
  for p,h in manifest['scripts'].items():assert sha(view/p)==h,p

def check(kind,command,cwd=view,capSize='22G'):
 clean_view();frozen();log=Path(str(prefix)+'-'+kind+'.log');report('running',phase=kind,log=str(log),memory_cap=capSize)
 stageEnv=dict(env,FV_MEMCAP=capSize)
 with log.open('w') as out:p=sp.run([cap,*command],cwd=cwd,env=stageEnv,stdout=out,stderr=sp.STDOUT)
 assert p.returncode==0,f'{kind} rc={p.returncode} log={log}'
 logs[kind]={'path':str(log),'sha256':sha(log)};clean_view();return log

try:
 frozen()
 assert sp.check_output(['nproc'],env=env,text=True).strip()=='2'
 prior=json.loads(leasePath.read_text());assert prior['state']=='released' and prior['commit']==expected
 assert proc(controller)['state'] in ['T','t']
 children=[int(x) for x in Path('/proc',str(controller),'task',str(controller),'children').read_text().split()]
 for child in children:
  status=proc(child);assert status is None or (status['state']=='Z' and status['exit_code']==0),status
 assert 'Build completed successfully' in Path(json.loads(Path('/tmp/stock-coherent-serial-progress.json').read_text())['log']).read_text()
 clean_view();frozen()
 held=True
 lease={'utc':now(),'state':'running_exact_PR_gates','owner':'codygunton / #44 / root','worker_pid':os.getpid(),'pr':pr,'view':str(view),'commit':expected,'canonical_controller':controller,'canonical_previous_progress':prior['canonical_previous_progress'],'previous_exclusive_lease':prior,'old_head_handoff':'/tmp/stock-pr246-old-head-handoff.json','policy':'Current old-head kernel finished successfully; all evidence preserved. Exact integrated current-main validation; no new worktree/cache; one exclusive writer.','release_command':'python3 /tmp/stock-pr246-integrated-gates.py --release'}
 leasePath.write_text(json.dumps(lease,indent=2)+'\n')
 for relative in ['.lake/build','crate-proofs/.lake/build','rust/target']:
  p=view/relative;assert p.is_symlink() and p.resolve()==(canon/relative).resolve()
 manifest={'utc':now(),'pr':pr,'commit':expected,'tree':sp.check_output(['git','rev-parse','HEAD^{tree}'],cwd=view,text=True).strip(),'sources':{str(p.relative_to(view)):sha(p) for d in ['FV','FVTest'] for p in (view/d).rglob('*.lean')},'scripts':{str(p.relative_to(view)):sha(p) for p in (view/'scripts').rglob('*') if p.is_file()},'cache':'one physical canonical cache, continuously exclusive lease; no copy','lake_source_hashing':'actual source/import hash checking with final full --rehash build','reconciled_main':'789152e24d12c8ff17c5caededd016800e781c31'}
 Path('/tmp/stock-pr246-gates-inputs.json').write_text(json.dumps(manifest,indent=2)+'\n')
 schedulerLog=Path(str(prefix)+'-scheduler.log');schedulerDir=Path(str(prefix)+'-modules')
 report('integrated_module_build',log=str(schedulerLog),scheduler_output=str(schedulerDir),budget='24G',max_jobs=2)
 schedulerCommand=['python3','/tmp/stock-delivery-lake-scheduler.py','--root',str(view),'--out',str(schedulerDir),'--budget','24G','--max-jobs','2','--max-cap','32G','--default-cap','22G','--profile','/tmp/stock-delivery-module-peaks.tsv','--record','/tmp/stock-pr246-integrated-module-peaks.tsv','--others-by-usage','FV','FVTest']
 with schedulerLog.open('w') as out:p=sp.run(schedulerCommand,cwd=view,env=env,stdout=out,stderr=sp.STDOUT)
 assert p.returncode==0,f'integrated module scheduler rc={p.returncode} log={schedulerLog}'
 logs['integrated-module-build']={'path':str(schedulerLog),'sha256':sha(schedulerLog),'module_logs':str(schedulerDir)}
 clean_view();frozen()
 full=check('full',[lake,'--rehash','build','FV','FVTest','lean-backend','lean-e2e-check','link-check','lean-link','clif-decode'])
 assert 'Build completed successfully' in full.read_text()
 crates=check('crates',[lake,'build'],view/'crate-proofs');assert 'Build completed successfully' in crates.read_text()
 core=json.loads(Path('/tmp/stock-delivery-core-paths.json').read_text());targetmods=[p[:-5].replace('/','.') for p in core['paths'] if p.endswith('.lean')]
 compiler=[]
 for n,m in re.findall(r'^\| `([^`]+)` \| `(FV\.[^`]+)` \| standard \|', (view/'docs/research/axiom-audit.md').read_text(),re.M):compiler.append((n,m))
 assert len(compiler)>=100,len(compiler)
 audit=Path(str(prefix)+'-axioms.lean');smoke=Path('/tmp/stock-delivery-audit-smoke.lean').read_text();body=smoke[smoke.index('open Lean'):].replace('#["FV.Clif.Syntax"]','#[ '+','.join(json.dumps(m) for m in targetmods)+' ]')
 audit.write_text('import Lean\n'+'\n'.join('import '+m for m in sorted(set(targetmods+[m for n,m in compiler])))+'\n'+body+'\n'+'\n'.join('#print axioms '+n for n,m in compiler)+'\n')
 auditlog=check('axioms',[lake,'env','lean','--root=/tmp',str(audit)])
 txt=auditlog.read_text();assert not re.search(r'error[:(]',txt);roots={n:sorted(json.loads(v)) for n,v in re.findall(r'DELIVERY_AXIOMS (\S+) (\[[^\n]*\])',txt)};std={'propext','Classical.choice','Quot.sound'}
 compiled={m.group(1):sorted(x.strip() for x in m.group(2).split(',') if x.strip()) for m in re.finditer(r"'([^']+)' depends on axioms:\s*\[([^]]*)\]",txt)};compiled.update({n:[] for n in re.findall(r"'([^']+)' does not depend on any axioms",txt)})
 assert set(n for n,m in compiler)<=set(compiled);assert all(set(compiled[n])<=std for n,m in compiler)
 assert roots;unknown_native={n:a for n,a in roots.items() if set(a)-std};assert not any('sorryAx' in a for a in roots.values())
 runtime=check('runtime',['bash','scripts/lean-backend-filetests.sh']);rt=runtime.read_text();match=re.search(r'runs: lean pass (\d+) fail (\d+) error (\d+).*not-runnable (\d+) file-error (\d+)',rt);assert match,rt[-1000:];counts=[int(x) for x in match.groups()];assert counts[0]>=4672 and counts[1:]==[0,0,7,0],counts
 encoder=check('encoder',['bash','scripts/lean-backend-encode-check.sh']);enc=re.search(r'functions (\d+): identical (\d+), differ (\d+)',encoder.read_text());assert enc and int(enc[1])>=1292 and enc[1]==enc[2] and enc[3]=='0'
 identities={}
 for label,flags,baseline in [('e2e',[],'/tmp/stock-body-form-full-identities.json'),('legacy-e2e',['--no-dead-cleanup'],'/tmp/stock-body-form-full-legacy-identities.json')]:
  reportPath=Path(str(prefix)+'-'+label+'-identities.json');log=check(label,[lake,'exe','lean-e2e-check',*flags,'--identity-report',str(reportPath)])
  old=json.loads(Path(baseline).read_text());new=json.loads(reportPath.read_text());key=lambda r:(r['file'],r['index'],r['function']);oldmap={key(r):r['stages'] for r in old['functions']};newmap={key(r):r['stages'] for r in new['functions']};assert len(oldmap)==1150
  losses={str(k):{'before':v,'after':newmap.get(k)} for k,v in oldmap.items() if newmap.get(k)!=v};assert not losses,losses
  assert new['dead_cleanup']==old['dead_cleanup'] and new['schema']==old['schema'];assert 'rejected 0' in log.read_text() or re.search(r'0 rejected',log.read_text()),log.read_text()[-1200:]
  identities[label]={'path':str(reportPath),'sha256':sha(reportPath),'baseline':baseline,'baseline_sha256':sha(baseline),'all1150_original_identity_stage_lists_preserved':True,'current_accepted_identities':len(newmap),'byte_identical':reportPath.read_bytes()==Path(baseline).read_bytes()}
 clean_view();frozen();result={'utc':now(),'pr':pr,'commit':expected,'success':not unknown_native,'trust_review_required':unknown_native,'source_manifest':'/tmp/stock-pr246-gates-inputs.json','serial_plan':'/tmp/stock-pr246-gates-build-plan.json','normal_audit':{'public_root_count':len(roots),'public_roots':roots,'compiler_roots':compiled,'documented_standard_compiler_roots':len(compiler),'log':str(auditlog)},'full_build':str(full),'crates':str(crates),'runtime_counts':counts,'encoder_counts':[int(enc[1]),int(enc[2]),int(enc[3])],'identities':identities,'logs':logs,'canonical_source_script_freeze_preserved':True,'new_warm_cache':False,'view_tracked_clean':True,'MCP':'Historical unchanged-source receipts need review; no new MCP invoked by worker','full_goal':'ORIGINAL#140 active/incomplete; production legacy'}
 receipt=Path('/tmp/stock-pr246-gates-receipt.json');receipt.write_text(json.dumps(result,indent=2)+'\n');lease.update(state='held_for_review',gates_terminal_utc=now(),receipt=str(receipt),worker_finished=True);leasePath.write_text(json.dumps(lease,indent=2)+'\n');finished=True;report('trust_review' if unknown_native else 'review_ready',receipt=str(receipt),canonical_queue_state='held for exact-PR review; release command in lease')
except BaseException as e:
 report('failed',error=repr(e),traceback=traceback.format_exc());raise
finally:
 if held and not finished:
  lease.update(state='held_after_failure',worker_finished=True,failure_utc=now());leasePath.write_text(json.dumps(lease,indent=2)+'\n')
