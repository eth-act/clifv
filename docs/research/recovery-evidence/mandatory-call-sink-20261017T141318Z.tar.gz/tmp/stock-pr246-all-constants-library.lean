import Lean
import FV.Backend.Proof.PerEdgeAllocDriverSound
import FV.Backend.Proof.PerEdgePrepareComplete
import FV.Backend.Proof.PerEdgePrepareFacts
import FV.Backend.Proof.PerEdgePrepareFilterFacts
import FV.Backend.Proof.PerEdgePrepareInputTotal
import FV.Backend.Proof.PerEdgePrepareLoopFacts
import FV.Backend.Proof.PerEdgePrepareLoopWitness
import FV.Backend.Proof.PerEdgePrepareOrderFacts
import FV.Backend.Proof.PerEdgePrepareOuterFacts
import FV.Backend.Proof.PerEdgePrepareOuterWitness
import FV.Backend.Proof.PerEdgePrepareSound
import FV.Backend.Proof.PerEdgePrepareTotal
import FV.Backend.Proof.PerEdgePrepareTotalWitness
import FV.Backend.Proof.PerEdgePrepareWitness
import FV.Backend.Proof.PerEdgePreparedDriverSound
import FV.Backend.Proof.PerEdgeRegallocFwd
import FV.Backend.Proof.PerEdgeRegallocLemmas
import FV.Backend.Proof.PerEdgeRegallocSound
import FV.Backend.Proof.PerEdgeVCodeSem
import FV.Backend.Proof.StockBlockCode
import FV.Backend.Proof.StockBranchArgumentCode
import FV.Backend.Proof.StockCriticalCode
import FV.Backend.Proof.StockCriticalValues
import FV.Backend.Proof.StockCriticalValuesWitness
import FV.Backend.Proof.StockEdgeCode
import FV.Backend.Proof.StockEdgeValues
import FV.Backend.Proof.StockEntryAliases
import FV.Backend.Proof.StockOrderGraph
import FV.Backend.Proof.StockOutgoingOrigin
import FV.Backend.Proof.StockOutgoingVectors
import FV.Backend.Proof.StockPerEdgeAllocatorWitness
import FV.Backend.Proof.StockPerEdgeCheckerWitness
import FV.Backend.Proof.StockPerEdgeCriticalAllocatorWitness
import FV.Backend.Proof.StockPerEdgeM6HaltWitness
import FV.Backend.Proof.StockPerEdgeM6Witness
import FV.Backend.Proof.StockPerEdgeValues
import FV.Backend.Proof.StockPerSuccessorWitness
import FV.Backend.Proof.StockPrepareComplete
import FV.Backend.Proof.StockPrepareCompleteWitness
import FV.Backend.Proof.StockPrepareInputs
import FV.Backend.Proof.StockPreparedForwardWitness
import FV.Backend.Proof.StockSelectedArguments
import FV.Backend.Proof.StockSelectedGraph
import FV.Backend.Proof.StockSelectedRoutes
import FV.Backend.Proof.StockSourceEdges
import FV.Backend.Proof.StockTermContract
import FV.Backend.Proof.StockTermContractWitness
import FV.Backend.RegallocPerEdge
import FV.Backend.RegallocPerEdgeDriver
import FV.Backend.RegallocPerEdgePrepare
import FV.Backend.RegallocPerEdgePrepareCheck
import FV.Backend.RegallocPerEdgeSpill
import FVTest.Backend.StockConfig
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let targets : Array String := #[ "FV.Backend.Proof.PerEdgeAllocDriverSound","FV.Backend.Proof.PerEdgePrepareComplete","FV.Backend.Proof.PerEdgePrepareFacts","FV.Backend.Proof.PerEdgePrepareFilterFacts","FV.Backend.Proof.PerEdgePrepareInputTotal","FV.Backend.Proof.PerEdgePrepareLoopFacts","FV.Backend.Proof.PerEdgePrepareLoopWitness","FV.Backend.Proof.PerEdgePrepareOrderFacts","FV.Backend.Proof.PerEdgePrepareOuterFacts","FV.Backend.Proof.PerEdgePrepareOuterWitness","FV.Backend.Proof.PerEdgePrepareSound","FV.Backend.Proof.PerEdgePrepareTotal","FV.Backend.Proof.PerEdgePrepareTotalWitness","FV.Backend.Proof.PerEdgePrepareWitness","FV.Backend.Proof.PerEdgePreparedDriverSound","FV.Backend.Proof.PerEdgeRegallocFwd","FV.Backend.Proof.PerEdgeRegallocLemmas","FV.Backend.Proof.PerEdgeRegallocSound","FV.Backend.Proof.PerEdgeVCodeSem","FV.Backend.Proof.StockBlockCode","FV.Backend.Proof.StockBranchArgumentCode","FV.Backend.Proof.StockCriticalCode","FV.Backend.Proof.StockCriticalValues","FV.Backend.Proof.StockCriticalValuesWitness","FV.Backend.Proof.StockEdgeCode","FV.Backend.Proof.StockEdgeValues","FV.Backend.Proof.StockEntryAliases","FV.Backend.Proof.StockOrderGraph","FV.Backend.Proof.StockOutgoingOrigin","FV.Backend.Proof.StockOutgoingVectors","FV.Backend.Proof.StockPerEdgeAllocatorWitness","FV.Backend.Proof.StockPerEdgeCheckerWitness","FV.Backend.Proof.StockPerEdgeCriticalAllocatorWitness","FV.Backend.Proof.StockPerEdgeM6HaltWitness","FV.Backend.Proof.StockPerEdgeM6Witness","FV.Backend.Proof.StockPerEdgeValues","FV.Backend.Proof.StockPerSuccessorWitness","FV.Backend.Proof.StockPrepareComplete","FV.Backend.Proof.StockPrepareCompleteWitness","FV.Backend.Proof.StockPrepareInputs","FV.Backend.Proof.StockPreparedForwardWitness","FV.Backend.Proof.StockSelectedArguments","FV.Backend.Proof.StockSelectedGraph","FV.Backend.Proof.StockSelectedRoutes","FV.Backend.Proof.StockSourceEdges","FV.Backend.Proof.StockTermContract","FV.Backend.Proof.StockTermContractWitness","FV.Backend.RegallocPerEdge","FV.Backend.RegallocPerEdgeDriver","FV.Backend.RegallocPerEdgePrepare","FV.Backend.RegallocPerEdgePrepareCheck","FV.Backend.RegallocPerEdgeSpill","FVTest.Backend.StockConfig" ]
  let mut count : Nat := 0
  for (name, info) in env.constants.toList do
    if false then continue
    let some index := env.getModuleIdxFor? name | continue
    let mod := env.header.moduleNames[index]!
    if !targets.contains mod.toString then continue
    let axioms ← collectAxioms name
    logInfo m!"DELIVERY_CONSTANT {Json.compress (toJson (name.toString, axioms.map Name.toString))}"
    count := count + 1
  logInfo m!"DELIVERY_AXIOM_COUNT {count}"
