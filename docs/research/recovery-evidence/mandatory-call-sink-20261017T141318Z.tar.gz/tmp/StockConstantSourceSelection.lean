import StockConstantRootSelection
import StockConstantSourceData
import FV.Backend.Proof.StockConstantRecordValues
namespace Backend.Stock.Proof.ConstantSourceSelectionDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open ConstantRootSelectionDraft ConstantSourceDataDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
/-- Actual successful constant-root execution recovers its selected matcher/RHS
receipts under original mapped context, for all four original scalar widths. -/
theorem stock_constant_original_selected_rhs {f : Clif.Function} {ctx : Ctx} (inv : MappedCtxInv f ctx)
    {ii : Nat} {info : IInfo} {ty : Clif.Ty} {imm : BitVec ty.width}
    (source : ctx.insts[ii]? = some info) (clif : info.clif = some (.iconst ty imm))
    {input next : State} {out : V} {trace : List RuleId}
    (root : Stock.runTerm ctx "lower" [.inst ii] input = .ok (some out,next,trace)) :
    ∃ evalTrace,
      (matchRule program (Stock.sem ctx) {} 999825 rule_lower_53 [.inst ii]).run (input,#[]) =
        .ok (some (env2 (.ty (.int ty.width)) (.int (u64 (imm64OfIconst ty imm)))),input,#[]) ∧
      (evalExpr program (Stock.sem ctx) {} 999999 rule_lower_53.rhs
        (env2 (.ty (.int ty.width)) (.int (u64 (imm64OfIconst ty imm))))).run (input,#[]) = .ok (some out,next,evalTrace) := by
  obtain ⟨fit,data,typed⟩ := stock_constant_source_data inv source clif
  have extracted : ∀ st : LState,Backend.externExtract ctx T.inst_data_value (.inst ii) st =
      .ok [.ty (.int ty.width),.data 152 35 [.data 151 57 [],.int (imm64OfIconst ty imm)]] := by
    intro st
    simp only [Backend.externExtract,show T.inst_data_value.id = 209 from rfl,Backend.tyPred,
      source,typed,Option.getD_some,data]
  exact stock_constant_selected_rhs ctx fit extracted root
end Backend.Stock.Proof.ConstantSourceSelectionDraft
