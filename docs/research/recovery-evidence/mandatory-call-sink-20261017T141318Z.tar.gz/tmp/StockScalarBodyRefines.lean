import StockConstantScan
import StockBodySteps
import FV.Backend.Proof.RefinesCSem
namespace Backend.Stock.Proof.ScalarBodyRefinesDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open ConstantScanDraft BodyStepsDraft FallStepsDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
/-- An explicit unfinished source-family partition, extended with actual
emitted constants. This describes internal records, not accepted source input. -/
def ScalarBodyRecord (f : Clif.Function) (ctx : Ctx) (bi : Nat) (r : ScanRecord) : Prop :=
  SelectOrOmittedRecord f ctx bi r ∨
    ∃ (j : Nat) (b : Clif.Block) (stm : Clif.Stmt) (info : IInfo) (ty : Clif.Ty)
      (imm : BitVec ty.width) (x a : Nat) (step : Step),
      f.blocks[bi]? = some b ∧ b.body[j]? = some stm ∧ r.inst = blockStart f bi+j ∧
      ctx.insts[r.inst]? = some info ∧ info.clif = some (.iconst ty imm) ∧
      info.results = [x] ∧ stm.results = [x] ∧ ctx.valueReg? x = some (.vreg a .int) ∧
      r.output.step = some step ∧ step.decision = .emitted

/-- Compose constants, selects and omissions in actual forward body-code order;
all constant root/RHS certificates are derived internally from real emission. -/
theorem stock_lower_scalar_body_fall_refines {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    {event : BlockScanEvent} (events : event ∈ result.blockScans.toList)
    {bi : Nat} {indices : List Nat} {input : State} {body : BlockScan}
    (scanned : ScansSpec (fun i => scanInstruction event.ctx event.block i event.termInst event.isBranch)
      indices input body)
    (retained : ∀ r ∈ body.records,r ∈ event.output.records)
    (families : ∀ r ∈ body.records,ScalarBodyRecord f event.ctx bi r)
    {F : BitVec 64 → Prop} {isem : Sem} (refines : Refines F isem)
    (renameLaw : ∀ aliases i,isem (i.mapRegs
      (Backend.lowerFunction.resolve aliases (aliases.size+1))) = isem i)
    {MR : MemRelT} (stable : MRStable F MR) {env : Clif.Env} {cp : Clif.Program} :
    ∀ s s',SourceSteps (IndexedSourceInst env cp f event.ctx bi) indices.reverse s s' →
      ∀ rho w,GuardedScanRel f result event.ctx bi MR body.state s rho w → ∃ final w',
        seqRun isem (body.code.toList.map (·.mapRegs
          (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1)))) rho w = some (.fall final w') ∧
        GuardedScanRel f result event.ctx bi MR input s' final w' := by
  apply scanned.fall_refines
  intro r member
  rcases families r member with old | constant
  · obtain ⟨j,b,stm,block,statement,current,step,recorded,kind⟩ := old
    rcases kind with omitted | ⟨emitted,info,ty,c,x,y,z,a,source,clif,results,statementResults,mapped⟩
    · exact stock_lower_omitted_scan_fall_refines lowered scope dominated events (retained r member)
        block statement current recorded omitted
    · exact stock_lower_select_scan_fall_refines lowered scope dominated events (retained r member)
        block statement current source clif results statementResults mapped recorded emitted refines stable
  · obtain ⟨j,b,stm,info,ty,imm,x,a,step,block,statement,current,source,clif,results,statementResults,mapped,recorded,emitted⟩ := constant
    exact stock_lower_constant_scan_fall_refines lowered scope dominated events (retained r member)
      block statement current source clif results statementResults mapped recorded emitted refines renameLaw stable

/-- Recover actual ordinary-body scans from the compiler and compose the
expanded internal scalar family partition under original source conditions. -/
theorem stock_lower_actual_scalar_body_refines {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    {event : BlockScanEvent} (events : event ∈ result.blockScans.toList)
    {F : BitVec 64 → Prop} {isem : Sem} (refines : Refines F isem)
    (renameLaw : ∀ aliases i,isem (i.mapRegs
      (Backend.lowerFunction.resolve aliases (aliases.size+1))) = isem i)
    {MR : MemRelT} (stable : MRStable F MR) {env : Clif.Env} {cp : Clif.Program} :
    ∃ b term body,SourceBodySplit f event b term body ∧
      ((∀ r ∈ body.records,ScalarBodyRecord f event.ctx event.block r) →
        ∀ s s',SourceSteps (IndexedSourceInst env cp f event.ctx event.block)
          ((List.range b.body.length).map (blockStart f event.block + ·)) s s' →
        ∀ rho w,GuardedScanRel f result event.ctx event.block MR event.output.state s rho w → ∃ final w',
          seqRun isem (body.code.toList.map (·.mapRegs
            (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1)))) rho w = some (.fall final w') ∧
          GuardedScanRel f result event.ctx event.block MR term.output.state s' final w') := by
  obtain ⟨b,term,body,split⟩ := stock_lower_body_scan_split lowered scope events
  refine ⟨b,term,body,split,?_⟩
  intro families s s' source rho w related
  apply stock_lower_scalar_body_fall_refines lowered scope dominated events split.scanned split.retained
    families refines renameLaw stable s s'
  · simpa only [sourceBodyIndices,List.reverse_reverse] using source
  · simpa only [split.state] using related
end Backend.Stock.Proof.ScalarBodyRefinesDraft
