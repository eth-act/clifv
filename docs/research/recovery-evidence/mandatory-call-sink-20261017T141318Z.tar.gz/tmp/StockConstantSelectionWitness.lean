import StockConstantSourceSelection
import FV.Backend.Proof.StockConstantRoot
namespace Backend.Stock.Proof.ConstantSelectionWitnessDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open ConstantSourceDataDraft ConstantSourceSelectionDraft ConstantSelectionDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
/-- The original built mapped-context constant fixture inhabits the new
producer inversion for every initial state; selected RHS and state are SAME. -/
theorem stock_constant_selected_rhs_complete_witness :
    ∃ (f : Clif.Function) (ctx : Ctx) (info : IInfo),
      MappedCtxInv f ctx ∧ ctx.insts[0]? = some info ∧ info.clif = some (.iconst .i8 9) ∧
      info.results = [2] ∧ ctx.valueReg? 2 = some (.vreg 193 .int) ∧
      ∀ input : State,∃ next trace evalTrace,
        Stock.runTerm ctx "lower" [.inst 0] input =
          .ok (some (.regsVec [[(input.base.fresh .int).1]]),next,trace) ∧
        (∀ r ∈ (program.rulesOf 686).take 172,matchArgs program (Stock.sem ctx) input r.args [.inst 0]
          (Array.replicate r.vars.length none) = .ok none) ∧
        (matchRule program (Stock.sem ctx) {} 999825 rule_lower_53 [.inst 0]).run (input,#[]) =
          .ok (some (env2 (.ty (.int 8)) (.int 9)),input,#[]) ∧
        (evalExpr program (Stock.sem ctx) {} 999999 rule_lower_53.rhs
          (env2 (.ty (.int 8)) (.int 9))).run (input,#[]) =
          .ok (some (.regsVec [[(input.base.fresh .int).1]]),next,evalTrace) := by
  obtain ⟨f,ctx,info,inv,source,clif,results,mapped,runs⟩ := stock_statement_selectedConstant
  obtain ⟨fit,data,type⟩ := stock_constant_source_data inv source clif
  have extracted : ∀ st : LState,Backend.externExtract ctx T.inst_data_value (.inst 0) st =
      .ok [.ty (.int 8),.data 152 35 [.data 151 57 [],.int 9]] := by
    intro st
    rw [ext_inst_data_value ctx st source,data,type]
    rfl
  refine ⟨f,ctx,info,inv,source,clif,results,mapped,?_⟩
  intro input
  obtain ⟨next,trace,root,_,_⟩ := runs input
  obtain ⟨evalTrace,matched,evaluated⟩ := stock_constant_original_selected_rhs inv source clif root
  exact ⟨next,_,evalTrace,root,stock_constant_prefix_nomatch ctx (Or.inl rfl) extracted input,matched,evaluated⟩
end Backend.Stock.Proof.ConstantSelectionWitnessDraft
