from pathlib import Path
import json,re,os
p=json.loads(Path('/tmp/stock-pr246-gates-progress.json').read_text());review=json.loads(Path('/tmp/stock-pr246-review-preparation.json').read_text());out={'phase':p['state'],'review':review['status']}
if p['state']=='integrated_module_build':
 s=(Path(p['scheduler_output'])/'sched.log').read_text();active=set();passed=set();nonzero=[]
 for line in s.splitlines():
  a=re.search(r' start (\S+) ',line);b=re.search(r' done (\S+) rc=(\S+)',line)
  if a:active.add(a[1])
  if b:
   active.discard(b[1])
   if b[2]=='0':passed.add(b[1])
   else:nonzero.append((b[1],b[2]))
  probe=re.search(r' done (\S+) up-to-date \(probe\)',line)
  if probe:passed.add(probe[1])
 seed=re.search(r'reuse (\d+) ',s);total=re.search(r'want (\d+) modules',s);out.update(completed=len(passed)+(int(seed[1]) if seed else 0),total=int(total[1]) if total else 2017,running=sorted(active),nonzero=nonzero)
else:out.update({k:p[k] for k in ['phase','error','log'] if k in p})
leaves=[]
for d in Path('/proc').iterdir():
 if not d.name.isdigit():continue
 try:
  if (d/'comm').read_text().strip()!='lean':continue
  cmd=(d/'cmdline').read_bytes().split(b'\0');args=[x.decode() for x in cmd if x]
  if len(args)<2 or not args[1].startswith('/home/lee/clifv/.worktrees/stock-delivery-gates/'):continue
  stat=(d/'stat').read_text().split(') ',1)[1].split();name=Path(args[1]).name;leaves.append({'pid':int(d.name),'source':name,'cpu_seconds':round((int(stat[11])+int(stat[12]))/os.sysconf('SC_CLK_TCK')),'rss_MiB':round(int(stat[21])*os.sysconf('SC_PAGE_SIZE')/2**20)})
 except (OSError,ValueError,IndexError):continue
out['kernels']=leaves
out['validated_commit']=p['commit']
for key,name in [('preflight','/tmp/stock-pr246-runtime-preflight-state.json'),('latest_main_launch','/tmp/stock-pr246-latest-main-launch-state.json')]:
 q=Path(name)
 if q.exists():out[key]=json.loads(q.read_text())['status']
print(json.dumps(out))
