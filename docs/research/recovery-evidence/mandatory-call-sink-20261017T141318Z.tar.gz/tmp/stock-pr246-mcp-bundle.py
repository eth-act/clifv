from pathlib import Path
import json,hashlib,subprocess,re
view=Path('/home/lee/clifv/.worktrees/stock-delivery-gates');lease=json.loads(Path('/tmp/stock-delivery-cache-lease.json').read_text());assert lease['state']=='held_for_review'
r=json.loads(Path('/tmp/stock-pr246-gates-receipt.json').read_text());c=json.loads(Path('/tmp/stock-pr246-completion-audit.json').read_text());assert c['success_pending_MCP_provenance_review'];assert not r['trust_review_required']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=view,text=True).strip()==r['commit']
roots=sorted(set(r['normal_audit']['public_roots'])|set(r['normal_audit']['compiler_roots']));assert roots
expected=sorted({a for d in [r['normal_audit']['public_roots'],r['normal_audit']['compiler_roots']] for values in d.values() for a in values});assert set(expected)<={'propext','Classical.choice','Quot.sound'}
text=Path(r['logs']['axioms']['path']).read_text();imports=re.findall(r'^import (\S+)',Path(str(Path(r['logs']['axioms']['path']).with_suffix('.lean'))).read_text(),re.M)
# Each conjunction component is the COMPLETE theorem proposition inferred from
# its explicitly referenced proof, so every root remains in both the type and value.
propositions=['Root _ (@'+n+')' for n in roots];value='(@'+roots[-1]+')'
for n in reversed(roots[:-1]):value='And.intro (@'+n+') ('+value+')'
s='\n'.join('import '+m for m in imports)+'\nset_option maxRecDepth 20000\nset_option maxHeartbeats 8000000\nnamespace StockDeliveryAudit\ndef Root (P : Prop) (_proof : P) : Prop := P\ntheorem pr246_bundle :\n  '+' ∧\n  '.join(propositions)+' :=\n  '+value+'\nend StockDeliveryAudit\n'
p=view/'DeliveryAudit.lean';assert not p.exists();p.write_text(s)
receipt={'file_path':str(p),'theorem_name':'StockDeliveryAudit.pr246_bundle','scan_source':True,'public_and_compiler_root_count':len(roots),'roots':roots,'expected_union_axioms':expected,'source_sha256':hashlib.sha256(s.encode()).hexdigest(),'scope':'Single conjunction of every exact-PR public theorem plus every documented compiler theorem; full statements retained. Source outside FV/FVTest globs; no PR or frozen canonical source changed.','MCP':'PENDING; run ONE lean_verify with file_path/theorem_name above after normal compile of bundle'}
Path('/tmp/stock-pr246-mcp-bundle.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items() if k!='roots'}))
