import subprocess,sys,resource,time,pathlib
output=sys.argv[1];start=time.monotonic()
p=subprocess.run(sys.argv[2:])
rss=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss
pathlib.Path(output).write_text("Maximum resident set size (kbytes): "+str(rss)+"\nElapsed seconds: "+str(time.monotonic()-start)+"\nExit status: "+str(p.returncode)+"\n")
sys.exit(p.returncode if p.returncode>=0 else 128-p.returncode)
