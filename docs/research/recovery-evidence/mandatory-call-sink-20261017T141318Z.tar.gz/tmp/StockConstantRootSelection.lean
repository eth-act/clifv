import StockConstantSelection
namespace Backend.Stock.Proof.ConstantRootSelectionDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64 ConstantSelectionDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private theorem selectRule_skipArgs {p : Program} {sem : Isle.Sem V State}
    {cfg : Config} {term : Term} {vs : List V} {s : State × Array RuleId}
    {pre : List Rule} (hn : ∀ r ∈ pre,
      matchArgs p sem s.1 r.args vs (Array.replicate r.vars.length none) = .ok none)
    (fuel : Nat) (post : List Rule) :
    (selectRule p sem cfg (fuel + pre.length + 2) term (pre ++ post) vs).run s =
      (selectRule p sem cfg (fuel + 2) term post vs).run s := by
  induction pre with
  | nil => rfl
  | cons r rs ih =>
    have hr := hn r (List.mem_cons_self ..)
    have htail := ih (fun r hr => hn r (List.mem_cons_of_mem _ hr))
    simp only [List.length_cons, List.cons_append]
    rw [show fuel + (rs.length + 1) + 2 = (fuel + rs.length) + 3 by omega]
    rw [selectRule.eq_3, tryRule.eq_2, matchRule.eq_2]
    simp only [isel_monad, hr]
    exact htail

/-- A successful actual named constant root selects the original constant rule.
The real RHS receipt is recovered from that success, for arbitrary supported
widths/immediates/source slots; callers supply no matcher/RHS certificate. -/
theorem stock_constant_selected_rhs (ctx : Ctx) {ii width : Nat} {imm : Int}
    (fit : width = 8 ∨ width = 16 ∨ width = 32 ∨ width = 64)
    (data : ∀ st : LState,Backend.externExtract ctx T.inst_data_value (.inst ii) st =
      .ok [.ty (.int width),.data 152 35 [.data 151 57 [],.int imm]])
    {input next : State} {out : V} {trace : List RuleId}
    (root : Stock.runTerm ctx "lower" [.inst ii] input = .ok (some out,next,trace)) :
    ∃ evalTrace,
      (matchRule program (Stock.sem ctx) {} 999825 rule_lower_53 [.inst ii]).run (input,#[]) =
        .ok (some (env2 (.ty (.int width)) (.int (u64 imm))),input,#[]) ∧
      (evalExpr program (Stock.sem ctx) {} 999999 rule_lower_53.rhs
        (env2 (.ty (.int width)) (.int (u64 imm)))).run (input,#[]) = .ok (some out,next,evalTrace) := by
  have hp := data_program
  have matched := stock_constant_match ctx fit data input
  have lowerCall : ∃ fired,(applyTerm program (Stock.sem ctx) {} 1000000 T.lower.ret T.lower.id [.inst ii]).run
      (input,#[]) = .ok (some out,next,fired) := by
    unfold Stock.runTerm Interp.run at root
    rw [program_termByName_lower] at root
    dsimp only at root
    cases call : (applyTerm program (Stock.sem ctx) {} 1000000 T.lower.ret T.lower.id [.inst ii]).run (input,#[]) with
    | error e => rw [call] at root; cases root
    | ok q =>
      obtain ⟨v,after,fired⟩ := q
      rw [call] at root
      simp only [bind,Except.bind,pure,Except.pure,Except.ok.injEq,Prod.mk.injEq] at root
      obtain ⟨rfl,rfl,rfl⟩ := root
      exact ⟨fired,rfl⟩
  obtain ⟨fired,root⟩ := lowerCall
  change (applyTerm program (Stock.sem ctx) {} 1000000 25 686 [.inst ii]).run (input,#[]) = _ at root
  rw [applyTerm_internal_run hp.t686 term_686_kind rfl] at root
  have rules : program.rulesOf 686 = (program.rulesOf 686).take 172 ++ rule_lower_53 :: (program.rulesOf 686).drop 173 := by
    rw [hp.r686]; rfl
  rw [rules] at root
  have skipped := selectRule_skipArgs (stock_constant_prefix_nomatch ctx fit data input)
    (cfg := {}) (term := T.lower) (s := (input,#[])) 999825 (rule_lower_53 :: (program.rulesOf 686).drop 173)
  simp only [show ((program.rulesOf 686).take 172).length = 172 from by rw [data_program.r686]; rfl] at skipped
  change (selectRule program (Stock.sem ctx) {} 999999 T.lower
    ((program.rulesOf 686).take 172 ++ rule_lower_53 :: (program.rulesOf 686).drop 173) [.inst ii]).run (input,#[]) = _ at skipped
  rw [skipped] at root
  have selected : (selectRule program (Stock.sem ctx) {} 999827 T.lower
      (rule_lower_53 :: (program.rulesOf 686).drop 173) [.inst ii]).run (input,#[]) =
      .ok (some (rule_lower_53,env2 (.ty (.int width)) (.int (u64 imm))),input,#[]) := by
    rw [selectRule.eq_3,tryRule.eq_2]
    simp only [M.run_bind,M.run_get,M.except_ok_bind,matched,isel_monad]
  rw [selected] at root
  simp only [M.except_ok_bind,M.run_bind] at root
  cases evaluated : (evalExpr program (Stock.sem ctx) {} 999999 rule_lower_53.rhs
      (env2 (.ty (.int width)) (.int (u64 imm)))).run (input,#[]) with
  | error err => rw [evaluated] at root; cases root
  | ok value =>
    obtain ⟨value,state,tr⟩ := value
    cases value with
    | none => rw [evaluated] at root; simp only [isel_monad,rule_lower_53] at root; cases root
    | some value =>
      rw [evaluated] at root
      simp only [isel_monad,rule_lower_53,Except.ok.injEq,Prod.mk.injEq,Option.some.injEq] at root
      obtain ⟨rfl,rfl,_⟩ := root
      exact ⟨tr,matched,rfl⟩

end Backend.Stock.Proof.ConstantRootSelectionDraft
