import StockScalarBodySteps
import StockBodySplitUnique
import FV.Backend.Proof.StockSourceDefined
import StockTryNearFixture
import StockConstantBodyObservation
namespace Backend.Stock.Proof.ConstantBodyFixtureDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open TryNearFixtureDraft ConstantScanDraft ScalarBodyRefinesDraft ScalarBodyStepsDraft BodyStepsDraft FallStepsDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 16000000
private def f := function false
private def before : Clif.Frame := {func := f,regs := Clif.Regs.empty,slots := [],body := f.blocks[0]!.body,term := f.blocks[0]!.term}
private def after : Clif.Frame := {before with regs := Clif.Regs.empty.set 0 ⟨.i64,9⟩,body := []}
private theorem available_none (ctx : Ctx) (x : Nat) : x ∉ availOf f (availIn f ctx) 0 0 := by
  intro available
  obtain ⟨present,_⟩ := (mem_av (show f.blocks[0]? = some f.blocks[0]! from rfl)).mp available
  rcases present with param | incoming | ⟨j,stm,earlier,statement,member⟩
  · change x ∈ ([] : List Nat) at param; cases param
  · have impossible := (inFix_fixOk (f := f) (ctx := ctx) (gn := id)).cand 0 x incoming; omega
  · omega
private theorem initialDFG (result : Result) (ctx : Ctx) :
    DFGCons ctx (restrict before (availOf f (availIn f result.ctx) 0 0)) := by
  have empty : (restrict before (availOf f (availIn f result.ctx) 0 0)).regs = Clif.Regs.empty := by
    funext x
    simp [restrict,available_none,before,Clif.Regs.empty]
  constructor
  · intro x j info inst v defined found original pure value
    rw [empty] at value; cases value
  · intro x ty v type value
    rw [empty] at value; cases value
private theorem initialHeld (result : Result) (ctx : Ctx) (st : State) (rho : Nat → CV) :
    ValuesHeld (fun x => Demanded st x ∧ x ∈ availOf f (availIn f result.ctx) 0 0)
      ctx before (fun key => rho (aliasNum result.final.alias key)) := by
  intro x required
  exact False.elim (available_none _ x required.2)
private structure Inputs where
  out : Output
  event : BlockScanEvent
  record : ScanRecord
  step : Step
  info : IInfo
  events : event ∈ out.result.blockScans.toList
  records : record ∈ event.output.records
  entry : event.block = 0
  current : record.inst = 0
  needed : record.input.demand[0]! ≠ 0
  recorded : record.output.step = some step
  emitted : step.decision = .emitted
  source : event.ctx.insts[0]? = some info
  clif : info.clif = some (.iconst .i64 9)
  results : info.results = [0]
  mapped : event.ctx.valueReg? 0 = some (.vreg 192 .int)
private theorem inputs : Nonempty Inputs := by
  obtain ⟨out⟩ := stock_near_try_fixture
  have actual := ConstantBodyObservationDraft.stock_constant_body_observation
  rw [out.lowered] at actual
  simp only [Except.toOption,Option.map_some,Option.some.injEq,List.any_eq_true,Bool.and_eq_true,
    beq_iff_eq,bne_iff_ne,decide_eq_true_eq,and_assoc] at actual
  obtain ⟨event,events,entry,record,records,current,needed,stepData,sourceData,mapped⟩ := actual
  obtain ⟨step,recorded,emitted⟩ := (by simpa only [Option.any_eq_true,beq_iff_eq] using stepData :
    ∃ step,record.output.step = some step ∧ step.decision = .emitted)
  obtain ⟨info,source,clif,results⟩ := (by simpa only [Option.map_eq_some_iff,Prod.mk.injEq] using sourceData :
    ∃ info,event.ctx.insts[0]? = some info ∧ info.clif = some (.iconst .i64 9) ∧ info.results = [0])
  exact ⟨⟨out,event,record,step,info,events,records,entry,current,needed,recorded,emitted,source,clif,results,mapped⟩⟩
private theorem aliasesRenaming (aliases : Array (Option Nat)) :
    VRenaming (Backend.lowerFunction.resolve aliases (aliases.size+1)) (aliasNum aliases) := by
  refine ⟨fun n c => resolve_vreg aliases _ n c,?_⟩
  intro r notVirtual
  cases r with
  | vreg n c => exact False.elim (notVirtual n c rfl)
  | _ => simp [Backend.lowerFunction.resolve]

private def sourceEnvironment : Clif.Env := {
  extern := fun _ => some (fun _ cm => .returned [⟨.i64,17⟩] cm),names := ["callee"],sigOf := fun _ => some f.sig }

/-- A COMPLETE original compiler/preparation/forced-fallback/checker/physical
pipeline really executes its scalar-constant body from an empty source register
file and ANY machine register file, establishing source9 and guarded agreement.
The actual original source program still returns17. -/
theorem stock_constant_actual_body_complete_witness :
    ∃ (out : Output) (event : BlockScanEvent) (b : Clif.Block) (term : ScanRecord) (body : BlockScan),
      Stock.lower f = .ok out.result ∧ LowerScope f ∧ Dominated f ∧ ArityOk f ∧
      prepareAt out.result.code out.result.edgeArgs = .ok out.prepared ∧
      out.rf = spillAllocAt out.prepared.code out.prepared.edges ∧
      checkAllocAt out.prepared.code out.prepared.edges out.rf = .ok () ∧
      lowerRFunc out.prepared.code out.rf = .ok out.af ∧
      event ∈ out.result.blockScans.toList ∧ SourceBodySplit f event b term body ∧
      (∀ r ∈ body.records,ScalarBodyRecord f event.ctx event.block r) ∧
      Clif.enterFunc f [] Clif.Mem.empty = .ok (before,Clif.Mem.empty) ∧
      SourceDefinedAt f out.result.ctx 0 0 before ∧ SourceDefinedAt f out.result.ctx 0 1 after ∧
      before.regs 0 = none ∧ after.regs 0 = some ⟨.i64,9⟩ ∧
      SourceSteps (IndexedSourceInst Clif.Env.empty {funcs := []} f event.ctx event.block)
        ((List.range b.body.length).map (blockStart f event.block + ·))
        (0,before,Clif.Mem.empty) (1,after,Clif.Mem.empty) ∧
      Clif.runWith sourceEnvironment {funcs := [f]} f.name [] Clif.Mem.empty 6 =
        .returned [⟨.i64,17⟩] Clif.Mem.empty ∧
      ∀ (F : BitVec 64 → Prop) (ctx : FnCtx) (X : ExtSem) (rho : Nat → CV) (w : Arm.ArmState),
        GuardedScanRel f out.result event.ctx event.block (fun _ cm _ => cm = Clif.Mem.empty)
          event.output.state (0,before,Clif.Mem.empty) rho w ∧
        ∃ (label : Nat) (vb : VBlock) (prelude : Array MInst) (final : Nat → CV) (w' : Arm.ArmState),
          out.result.code.blocks[label]? = some vb ∧
          seqRun (csem F ctx X) (body.code.toList.map (·.mapRegs
            (Backend.lowerFunction.resolve out.result.final.alias (out.result.final.alias.size+1)))) rho w =
            some (.fall final w') ∧
          Star (VStepAt out.result.code out.result.edgeArgs (csem F ctx X))
            (.run ⟨label,prelude.size,rho,w⟩) (.run ⟨label,prelude.size+body.code.size,final,w'⟩) ∧
          GuardedScanRel f out.result event.ctx event.block (fun _ cm _ => cm = Clif.Mem.empty)
            term.output.state (1,after,Clif.Mem.empty) final w' ∧
          VHolds ⟨.i64,9⟩ (final (aliasNum out.result.final.alias 192)) := by
  obtain ⟨input⟩ := inputs
  obtain ⟨b,term,body,split⟩ := stock_lower_body_scan_split input.out.lowered input.out.scope input.events
  have block : b = f.blocks[0]! := by
    have found := split.block
    rw [input.entry] at found
    exact Option.some.inj (found.symm.trans (show f.blocks[0]? = some f.blocks[0]! from rfl))
  have termIndex : term.inst = 1 := by rw [split.termInst,split.termIndex,input.entry,block]; rfl
  have member : input.record ∈ body.records := by
    have saved := input.records
    rw [split.records] at saved
    rcases List.mem_cons.mp saved with same | inside
    · have bad := congrArg ScanRecord.inst same
      rw [input.current,termIndex] at bad
      cases bad
    · exact inside
  have indices : body.records.map (·.inst) = [0] := by
    rw [split.scanned.order,sourceBodyIndices,input.entry,block]
    rfl
  have length : body.records.length = 1 := by
    have same := congrArg List.length indices
    simpa only [List.length_map,List.length_cons,List.length_nil] using same
  obtain ⟨only,pair⟩ := List.length_eq_one_iff.mp length
  have unique : input.record = only := by simpa only [pair,List.mem_singleton] using member
  have singleton : body.records = [input.record] := by rw [pair,←unique]
  have current : input.record.inst = blockStart f 0+0 := by change input.record.inst = 0; exact input.current
  have source : input.event.ctx.insts[input.record.inst]? = some input.info := by rw [input.current]; exact input.source
  have families : ∀ r ∈ body.records,ScalarBodyRecord f input.event.ctx input.event.block r := by
    intro r inside
    have same : r = input.record := by simpa only [singleton,List.mem_singleton] using inside
    subst r
    rw [input.entry]
    exact .inr ⟨0,f.blocks[0]!,⟨[0],.iconst .i64 9⟩,input.info,.i64,9,0,192,input.step,
      rfl,rfl,current,source,input.clif,input.results,rfl,input.mapped,input.recorded,input.emitted⟩
  have step : SourceInstResult Clif.Env.empty {funcs := []} input.event.ctx input.record.inst
      (before,Clif.Mem.empty) (after,Clif.Mem.empty) := by
    refine ⟨input.info,.iconst .i64 9,[⟨.i64,9⟩],Clif.Regs.empty.set 0 ⟨.i64,9⟩,[],source,input.clif,?_,rfl,?_,rfl⟩
    · rw [input.results]; rfl
    · rw [input.results]; rfl
  have sourceSteps : SourceSteps (IndexedSourceInst Clif.Env.empty {funcs := []} f input.event.ctx input.event.block)
      ((List.range b.body.length).map (blockStart f input.event.block + ·))
      (0,before,Clif.Mem.empty) (1,after,Clif.Mem.empty) := by
    rw [input.entry,block]
    have first := step
    rw [input.current] at first
    exact .cons (s1 := (1,after,Clif.Mem.empty)) ⟨rfl,rfl,first⟩ (.nil _)
  have entered : Clif.enterFunc f [] Clif.Mem.empty = .ok (before,Clif.Mem.empty) := rfl
  have defined := source_defined_enterFunc input.out.dominated input.out.result.ctx entered
  have postDefined := stock_lower_source_defined_step input.out.lowered input.out.scope input.out.dominated input.events
    (bi := 0) (j := 0) (i := input.record.inst) (b := f.blocks[0]!) rfl rfl current defined step
  refine ⟨input.out,input.event,b,term,body,input.out.lowered,input.out.scope,input.out.dominated,input.out.arity,
    input.out.prepare,input.out.fallback,input.out.accepted,input.out.physical,input.events,split,families,entered,
    defined,postDefined,rfl,rfl,sourceSteps,rfl,?_⟩
  intro F ctx X rho w
  have stable : MRStable F (fun _ cm _ => cm = Clif.Mem.empty) := by intro _ _ _ _ _ same; exact same
  have renameLaw : ∀ aliases i,csem F ctx X (i.mapRegs
      (Backend.lowerFunction.resolve aliases (aliases.size+1))) = csem F ctx X i := by
    intro aliases i
    exact (driverSem_csem F ctx X).rename _ _ (aliasesRenaming aliases) i
  have related : GuardedScanRel f input.out.result input.event.ctx input.event.block
      (fun _ cm _ => cm = Clif.Mem.empty) input.event.output.state (0,before,Clif.Mem.empty) rho w := by
    rw [input.entry]
    exact ⟨rfl,initialDFG _ _,rfl,initialHeld _ _ _ _⟩
  obtain ⟨b2,term2,body2,label,vb,prelude,split2,placed,semantic⟩ := stock_lower_actual_scalar_body_steps
    input.out.lowered input.out.scope input.out.dominated input.events (refines_csem F ctx X) renameLaw
    (fun _ ends _ _ _ _ => csem_terminal_no_next ends) stable (env := Clif.Env.empty) (cp := {funcs := []})
  obtain ⟨rfl,rfl,rfl⟩ := BodySplitUniqueDraft.sourceBodySplit_unique split split2
  obtain ⟨final,w',run,steps,post⟩ := semantic families _ _ sourceSteps rho w related
  have chain : input.record.input = term.output.state := by
    have actual := split.scanned.chain
    rw [singleton] at actual
    exact actual.1
  have demanded : Demanded term.output.state 0 := by
    change term.output.state.demand[0]! ≠ 0
    rw [←chain]
    exact input.needed
  have available : 0 ∈ availOf f (availIn f input.out.result.ctx) input.event.block 1 := by
    rw [input.entry]
    simp [availOf,f,TryNearFixtureDraft.function,defsBefore,defsFrom]
  obtain ⟨key,keyMap,value⟩ := post.2.2.2 0 ⟨demanded,available⟩ ⟨.i64,9⟩ (show after.regs 0 = some ⟨.i64,9⟩ from rfl)
  rw [input.mapped] at keyMap
  cases keyMap
  exact ⟨related,label,vb,prelude,final,w',placed,run,steps,post,value⟩

end Backend.Stock.Proof.ConstantBodyFixtureDraft
