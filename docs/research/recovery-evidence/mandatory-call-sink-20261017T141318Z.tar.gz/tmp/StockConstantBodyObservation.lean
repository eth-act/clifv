import StockTryNearFixture
namespace Backend.Stock.Proof.ConstantBodyObservationDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option maxRecDepth 20000
set_option maxHeartbeats 16000000
theorem stock_constant_body_observation : (Stock.lower (TryNearFixtureDraft.function false)).toOption.map (fun result => result.blockScans.toList.any (fun event =>
  event.block == 0 && event.output.records.any (fun record => record.inst == 0 && record.input.demand[0]! != 0 &&
    record.output.step.any (fun step => step.decision == .emitted) &&
    decide ((event.ctx.insts[0]?).map (fun info => (info.clif,info.results)) = some (some (.iconst .i64 9),[0])) &&
    decide (event.ctx.valueReg? 0 = some (.vreg 192 .int))))) = some true :=
  by decide +kernel

end Backend.Stock.Proof.ConstantBodyObservationDraft
