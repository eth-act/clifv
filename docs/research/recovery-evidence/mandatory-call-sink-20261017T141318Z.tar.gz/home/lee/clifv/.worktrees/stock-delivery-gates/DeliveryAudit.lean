import Lean
import FV.Backend.Proof.Encode
import FV.Backend.Proof.FormsCoverComplete
import FV.Backend.Proof.LowerComplete
import FV.Backend.Proof.LowerLoop
import FV.Backend.Proof.PerEdgeAllocDriverSound
import FV.Backend.Proof.PerEdgePrepareComplete
import FV.Backend.Proof.PerEdgePrepareFacts
import FV.Backend.Proof.PerEdgePrepareFilterFacts
import FV.Backend.Proof.PerEdgePrepareInputTotal
import FV.Backend.Proof.PerEdgePrepareLoopFacts
import FV.Backend.Proof.PerEdgePrepareLoopWitness
import FV.Backend.Proof.PerEdgePrepareOrderFacts
import FV.Backend.Proof.PerEdgePrepareOuterFacts
import FV.Backend.Proof.PerEdgePrepareOuterWitness
import FV.Backend.Proof.PerEdgePrepareSound
import FV.Backend.Proof.PerEdgePrepareTotal
import FV.Backend.Proof.PerEdgePrepareTotalWitness
import FV.Backend.Proof.PerEdgePrepareWitness
import FV.Backend.Proof.PerEdgePreparedDriverSound
import FV.Backend.Proof.PerEdgeRegallocFwd
import FV.Backend.Proof.PerEdgeRegallocLemmas
import FV.Backend.Proof.PerEdgeRegallocSound
import FV.Backend.Proof.PerEdgeVCodeSem
import FV.Backend.Proof.PrepareComplete
import FV.Backend.Proof.PrepareDirect
import FV.Backend.Proof.StockBlockCode
import FV.Backend.Proof.StockBranchArgumentCode
import FV.Backend.Proof.StockCriticalCode
import FV.Backend.Proof.StockCriticalValues
import FV.Backend.Proof.StockCriticalValuesWitness
import FV.Backend.Proof.StockEdgeCode
import FV.Backend.Proof.StockEdgeValues
import FV.Backend.Proof.StockEntryAliases
import FV.Backend.Proof.StockOrderGraph
import FV.Backend.Proof.StockOutgoingOrigin
import FV.Backend.Proof.StockOutgoingVectors
import FV.Backend.Proof.StockPerEdgeAllocatorWitness
import FV.Backend.Proof.StockPerEdgeCheckerWitness
import FV.Backend.Proof.StockPerEdgeCriticalAllocatorWitness
import FV.Backend.Proof.StockPerEdgeM6HaltWitness
import FV.Backend.Proof.StockPerEdgeM6Witness
import FV.Backend.Proof.StockPerEdgeValues
import FV.Backend.Proof.StockPerSuccessorWitness
import FV.Backend.Proof.StockPrepareComplete
import FV.Backend.Proof.StockPrepareCompleteWitness
import FV.Backend.Proof.StockPrepareInputs
import FV.Backend.Proof.StockPreparedForwardWitness
import FV.Backend.Proof.StockSelectedArguments
import FV.Backend.Proof.StockSelectedGraph
import FV.Backend.Proof.StockSelectedRoutes
import FV.Backend.Proof.StockSourceEdges
import FV.Backend.Proof.StockTermContract
import FV.Backend.Proof.StockTermContractWitness
import FV.Backend.RegallocPerEdge
import FV.Backend.RegallocPerEdgeDriver
import FV.Backend.RegallocPerEdgePrepare
import FV.Backend.RegallocPerEdgePrepareCheck
import FV.Backend.RegallocPerEdgeSpill
import FV.E2E.AllocDirect
import FV.E2E.AllocTotal
import FV.E2E.BinaryGood
import FV.E2E.DeadCleanupExecBytes
import FV.E2E.DeadCleanupExecGoodReads
import FV.E2E.DeadCleanupExecGoodRun
import FV.E2E.DeadCleanupExecGot
import FV.E2E.DeadCleanupExecPeak
import FV.E2E.DeadCleanupExecProven
import FV.E2E.DeadCleanupExecRunN
import FV.E2E.DeadCleanupExecStatic
import FV.E2E.DeadCleanupFinal
import FV.E2E.DeadCleanupLegal
import FV.E2E.DeadCleanupLegalDirect
import FV.E2E.DeadCleanupOptProven
import FV.E2E.DeadCleanupSize
import FV.E2E.DeadCleanupStackBound
import FV.E2E.DeadCleanupTotal
import FV.E2E.EmitTotal
import FV.E2E.EmitTotalIn
import FV.E2E.ExecBytes
import FV.E2E.ExecGoodReads
import FV.E2E.ExecGoodRun
import FV.E2E.ExecGot
import FV.E2E.ExecProven
import FV.E2E.ExecRunN
import FV.E2E.ExecStatic
import FV.E2E.Final
import FV.E2E.FinalDirect
import FV.E2E.Legal
import FV.E2E.LegalDepth
import FV.E2E.LegalDirect
import FV.E2E.LegalProgram
import FV.E2E.LinkArm
import FV.E2E.LinkGood
import FV.E2E.NonVacuity
import FV.E2E.OptProven
import FV.E2E.RelaxTotal
import FV.E2E.SizeIn
import FV.E2E.SpillDefined
import FV.E2E.SpillKillFree
import FV.E2E.StackBound
import FV.Front.BundleProof
import FV.Front.Exe
import FV.Front.Raw
import FV.Front.RawExe
import FV.Front.RawProof
import FV.Front.RenameRun
import FV.Link.Correct
import FV.Link.DeadCleanupCorrect
import FV.Link.DeadCleanupExe
import FV.Link.DeadCleanupExePeak
import FV.Link.DeadCleanupExeSource
import FV.Link.DeadCleanupExeTotal
import FV.Link.DeadCleanupLayoutProof
import FV.Link.Exe
import FV.Link.ExeInput
import FV.Link.ExeInputCleanup
import FV.Link.ExeInputReach
import FV.Link.ExeInputReachCleanup
import FV.Link.ExeSource
import FV.Link.ExeTotal
import FV.Link.LayoutProof
import FV.Link.NonVacuityDeadCleanupExeSource
import FV.Link.NonVacuityExeSource
import FV.Opt.Proof.LegalPre
import FV.Opt.Proof.RuleAll
import FV.Opt.Proof.SimpPass
import FVTest.Backend.StockConfig
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
namespace StockDeliveryAudit
def Root (P : Prop) (_proof : P) : Prop := P
theorem pr246_bundle :
  Root _ (@Backend.CheckCtx.edgeAt.eq_1) ∧
  Root _ (@Backend.CheckCtx.edgeForget.eq_1) ∧
  Root _ (@Backend.EdgeVCode.mk.inj) ∧
  Root _ (@Backend.EdgeVCode.mk.injEq) ∧
  Root _ (@Backend.EdgeVCode.mk.sizeOf_spec) ∧
  Root _ (@Backend.Insn.decode_encode) ∧
  Root _ (@Backend.MInst.setTargets.eq_1) ∧
  Root _ (@Backend.MInst.setTargets.eq_2) ∧
  Root _ (@Backend.MInst.setTargets.eq_3) ∧
  Root _ (@Backend.MInst.setTargets.eq_4) ∧
  Root _ (@Backend.MInst.setTargets.eq_5) ∧
  Root _ (@Backend.MInst.setTargets.eq_6) ∧
  Root _ (@Backend.Proof.Driver.formsCovered_complete) ∧
  Root _ (@Backend.Proof.Driver.lowerCheck_complete) ∧
  Root _ (@Backend.Proof.Driver.prepDomain_of_lower) ∧
  Root _ (@Backend.Proof.PerEdge.Checked.at) ∧
  Root _ (@Backend.Proof.PerEdge.Checked.blocks) ∧
  Root _ (@Backend.Proof.PerEdge.Checked.cfg) ∧
  Root _ (@Backend.Proof.PerEdge.Checked.entry) ∧
  Root _ (@Backend.Proof.PerEdge.Checked.nonempty) ∧
  Root _ (@Backend.Proof.PerEdge.Checked.rf_eq) ∧
  Root _ (@Backend.Proof.PerEdge.Checked.size) ∧
  Root _ (@Backend.Proof.PerEdge.Checked.vc_eq) ∧
  Root _ (@Backend.Proof.PerEdge.CheckedAt.blocks) ∧
  Root _ (@Backend.Proof.PerEdge.CheckedAt.cfg) ∧
  Root _ (@Backend.Proof.PerEdge.CheckedAt.entry) ∧
  Root _ (@Backend.Proof.PerEdge.CheckedAt.nonempty) ∧
  Root _ (@Backend.Proof.PerEdge.CheckedAt.rf_eq) ∧
  Root _ (@Backend.Proof.PerEdge.CheckedAt.size) ∧
  Root _ (@Backend.Proof.PerEdge.CheckedAt.vc_eq) ∧
  Root _ (@Backend.Proof.PerEdge.IsSimulation.at_op) ∧
  Root _ (@Backend.Proof.PerEdge.IsSimulation.halt) ∧
  Root _ (@Backend.Proof.PerEdge.IsSimulation.move) ∧
  Root _ (@Backend.Proof.PerEdge.IsSimulation.next_vstep) ∧
  Root _ (@Backend.Proof.PerEdge.IsSimulation.progress) ∧
  Root _ (@Backend.Proof.PerEdge.IsSimulation.ret) ∧
  Root _ (@Backend.Proof.PerEdge.IsSimulation.run) ∧
  Root _ (@Backend.Proof.PerEdge.IsSimulation.star) ∧
  Root _ (@Backend.Proof.PerEdge.IsSimulation.step) ∧
  Root _ (@Backend.Proof.PerEdge.VNextAt_det) ∧
  Root _ (@Backend.Proof.PerEdge.VStepAt_det) ∧
  Root _ (@Backend.Proof.PerEdge.allocChecked_of_checkAlloc) ∧
  Root _ (@Backend.Proof.PerEdge.allocChecked_sound) ∧
  Root _ (@Backend.Proof.PerEdge.allocResultAt_checked) ∧
  Root _ (@Backend.Proof.PerEdge.checkAlloc_diverges) ∧
  Root _ (@Backend.Proof.PerEdge.checkAlloc_halt) ∧
  Root _ (@Backend.Proof.PerEdge.checkAlloc_ok) ∧
  Root _ (@Backend.Proof.PerEdge.checkAlloc_ret) ∧
  Root _ (@Backend.Proof.PerEdge.checkAlloc_sound) ∧
  Root _ (@Backend.Proof.PerEdge.checkAlloc_stuck) ∧
  Root _ (@Backend.Proof.PerEdge.checkedAt_sound) ∧
  Root _ (@Backend.Proof.PerEdge.checked_of_checkAlloc) ∧
  Root _ (@Backend.Proof.PerEdge.edgeCopy_ok) ∧
  Root _ (@Backend.Proof.PerEdge.edgeEnv_lt) ∧
  Root _ (@Backend.Proof.PerEdge.edge_ok) ∧
  Root _ (@Backend.Proof.PerEdge.enter_block) ∧
  Root _ (@Backend.Proof.PerEdge.enter_block_at) ∧
  Root _ (@Backend.Proof.PerEdge.forward) ∧
  Root _ (@Backend.Proof.PerEdge.forward_aux) ∧
  Root _ (@Backend.Proof.PerEdge.forward_op) ∧
  Root _ (@Backend.Proof.PerEdge.lowerAllocAt_ok) ∧
  Root _ (@Backend.Proof.PerEdge.lowerAllocAt_sound) ∧
  Root _ (@Backend.Proof.PerEdge.prepareCheckedAt_ok) ∧
  Root _ (@Backend.Proof.PerEdge.prepared_halt_forward) ∧
  Root _ (@Backend.Proof.PerEdge.prepared_return_forward) ∧
  Root _ (@Backend.Proof.PerEdge.sim_progress) ∧
  Root _ (@Backend.Proof.PerEdge.sim_progress_at) ∧
  Root _ (@Backend.Proof.PerEdge.sim_step) ∧
  Root _ (@Backend.Proof.PerEdge.sim_step_at) ∧
  Root _ (@Backend.Proof.PerEdge.verifyBlock_ok) ∧
  Root _ (@Backend.Proof.PerEdge.verify_ok) ∧
  Root _ (@Backend.Proof.PerEdgePrep.KeptAt.blocks) ∧
  Root _ (@Backend.Proof.PerEdgePrep.OuterInv.copies) ∧
  Root _ (@Backend.Proof.PerEdgePrep.OuterInv.graph) ∧
  Root _ (@Backend.Proof.PerEdgePrep.OuterInv.paired) ∧
  Root _ (@Backend.Proof.PerEdgePrep.OuterInv.rowCount) ∧
  Root _ (@Backend.Proof.PerEdgePrep.edgeBlockOkAt_sound) ∧
  Root _ (@Backend.Proof.PerEdgePrep.graphBlock.eq_1) ∧
  Root _ (@Backend.Proof.PerEdgePrep.graphState.eq_1) ∧
  Root _ (@Backend.Proof.PerEdgePrep.innerFoldAt_copies) ∧
  Root _ (@Backend.Proof.PerEdgePrep.innerFoldAt_facts) ∧
  Root _ (@Backend.Proof.PerEdgePrep.innerFoldAt_graph) ∧
  Root _ (@Backend.Proof.PerEdgePrep.innerFoldAt_rows) ∧
  Root _ (@Backend.Proof.PerEdgePrep.innerForInAt_eq) ∧
  Root _ (@Backend.Proof.PerEdgePrep.innerStepAt.eq_1) ∧
  Root _ (@Backend.Proof.PerEdgePrep.innerStepAt_graph) ∧
  Root _ (@Backend.Proof.PerEdgePrep.innerStepAt_rows) ∧
  Root _ (@Backend.Proof.PerEdgePrep.keptAt.eq_1) ∧
  Root _ (@Backend.Proof.PerEdgePrep.keptAt_blocks) ∧
  Root _ (@Backend.Proof.PerEdgePrep.keptAt_source) ∧
  Root _ (@Backend.Proof.PerEdgePrep.keptOkAt_sound) ∧
  Root _ (@Backend.Proof.PerEdgePrep.kept_cfg) ∧
  Root _ (@Backend.Proof.PerEdgePrep.kept_entry) ∧
  Root _ (@Backend.Proof.PerEdgePrep.live_okAt) ∧
  Root _ (@Backend.Proof.PerEdgePrep.ordered_cfg) ∧
  Root _ (@Backend.Proof.PerEdgePrep.outerLoopAt_inv) ∧
  Root _ (@Backend.Proof.PerEdgePrep.outerLoopAt_total) ∧
  Root _ (@Backend.Proof.PerEdgePrep.outerLoopAt_total_targets) ∧
  Root _ (@Backend.Proof.PerEdgePrep.outerStepAt.eq_1) ∧
  Root _ (@Backend.Proof.PerEdgePrep.outerStepAt_inv) ∧
  Root _ (@Backend.Proof.PerEdgePrep.outerStepAt_total) ∧
  Root _ (@Backend.Proof.PerEdgePrep.outer_order_facts) ∧
  Root _ (@Backend.Proof.PerEdgePrep.prepCheckAt_complete) ∧
  Root _ (@Backend.Proof.PerEdgePrep.prep_entry_step) ∧
  Root _ (@Backend.Proof.PerEdgePrep.prep_halt) ∧
  Root _ (@Backend.Proof.PerEdgePrep.prep_ret) ∧
  Root _ (@Backend.Proof.PerEdgePrep.prep_sound) ∧
  Root _ (@Backend.Proof.PerEdgePrep.prep_star) ∧
  Root _ (@Backend.Proof.PerEdgePrep.prep_step) ∧
  Root _ (@Backend.Proof.PerEdgePrep.prepareAt_cfg) ∧
  Root _ (@Backend.Proof.PerEdgePrep.prepareAt_entry) ∧
  Root _ (@Backend.Proof.PerEdgePrep.prepareAt_fields) ∧
  Root _ (@Backend.Proof.PerEdgePrep.prepareAt_input_facts) ∧
  Root _ (@Backend.Proof.PerEdgePrep.prepareAt_kept_facts) ∧
  Root _ (@Backend.Proof.PerEdgePrep.prepareAt_no_new_effects) ∧
  Root _ (@Backend.Proof.PerEdgePrep.prepareAt_outer_facts) ∧
  Root _ (@Backend.Proof.PerEdgePrep.prepareAt_stages) ∧
  Root _ (@Backend.Proof.PerEdgePrep.prepareAt_total) ∧
  Root _ (@Backend.Proof.PerEdgePrep.prepareCheckedAt_complete) ∧
  Root _ (@Backend.Proof.PerEdgePrep.prepareCheckedAt_total) ∧
  Root _ (@Backend.Proof.PerEdgePrep.setTargets_total) ∧
  Root _ (@Backend.Proof.PerEdgePrep.split_cfg) ∧
  Root _ (@Backend.Proof.PerEdgePrepLoopWitness.indexed_inner_loop_witness) ∧
  Root _ (@Backend.Proof.PerEdgePrepLoopWitness.indexed_prepare_stages_witness) ∧
  Root _ (@Backend.Proof.PerEdgePrepOuterWitness.indexed_outer_loop_witness) ∧
  Root _ (@Backend.Proof.PerEdgePrepOuterWitness.indexed_prepare_filter_facts_witness) ∧
  Root _ (@Backend.Proof.PerEdgePrepOuterWitness.indexed_prepare_outer_facts_witness) ∧
  Root _ (@Backend.Proof.PerEdgePrepOuterWitness.indexed_prepared_entry_cfg_witness) ∧
  Root _ (@Backend.Proof.PerEdgePrepOuterWitness.indexed_rpo_witness) ∧
  Root _ (@Backend.Proof.PerEdgePrepTotalWitness.raw_prepare_total_witness) ∧
  Root _ (@Backend.Proof.PerEdgePrepTotalWitness.retarget_total_witness) ∧
  Root _ (@Backend.Proof.PerEdgePrepTotalWitness.splitting_total_witness) ∧
  Root _ (@Backend.Proof.PerEdgePrepTotalWitness.stock_dimensions_witness) ∧
  Root _ (@Backend.Proof.PerEdgePrepareWitness.per_edge_prepare_split_copy_witness) ∧
  Root _ (@Backend.Proof.Prep.prepCheck_complete) ∧
  Root _ (@Backend.Proof.Prep.prepare_correct) ∧
  Root _ (@Backend.Proof.edgeEnvAt.eq_1) ∧
  Root _ (@Backend.Proof.edgeEnvAt_eq) ∧
  Root _ (@Backend.SpillHomesAt.mk.inj) ∧
  Root _ (@Backend.SpillHomesAt.mk.injEq) ∧
  Root _ (@Backend.SpillHomesAt.mk.sizeOf_spec) ∧
  Root _ (@Backend.Stock.Proof.CriticalValuesWitness.stock_critical_edge_env_witness) ∧
  Root _ (@Backend.Stock.Proof.CriticalValuesWitness.stock_critical_per_edge_step_witness) ∧
  Root _ (@Backend.Stock.Proof.CriticalValuesWitness.stock_critical_selected_route_witness) ∧
  Root _ (@Backend.Stock.Proof.LowerTermOkABI.defs) ∧
  Root _ (@Backend.Stock.Proof.LowerTermOkABI.legacy) ∧
  Root _ (@Backend.Stock.Proof.LowerTermOkABI.mono) ∧
  Root _ (@Backend.Stock.Proof.LowerTermOkABI.run) ∧
  Root _ (@Backend.Stock.Proof.PerEdgeAllocatorWitness.stock_per_edge_allocator_fallback_witness) ∧
  Root _ (@Backend.Stock.Proof.PerEdgeCheckerWitness.stock_per_edge_checker_value_witness) ∧
  Root _ (@Backend.Stock.Proof.PerEdgeCheckerWitness.stock_per_edge_checker_witness) ∧
  Root _ (@Backend.Stock.Proof.PerEdgeCriticalAllocatorWitness.stock_per_edge_critical_allocator_fallback_witness) ∧
  Root _ (@Backend.Stock.Proof.PerEdgeM6HaltWitness.stock_per_edge_m6_halt_witness) ∧
  Root _ (@Backend.Stock.Proof.PerEdgeM6Witness.stock_per_edge_m6_checked_witness) ∧
  Root _ (@Backend.Stock.Proof.PerEdgeM6Witness.stock_per_edge_m6_return_witness) ∧
  Root _ (@Backend.Stock.Proof.PerSuccessorWitness.stock_per_successor_migration_witness) ∧
  Root _ (@Backend.Stock.Proof.PrepareCompleteWitness.generic_prepare_complete_witness) ∧
  Root _ (@Backend.Stock.Proof.PrepareCompleteWitness.stock_prepare_complete_critical_witness) ∧
  Root _ (@Backend.Stock.Proof.PrepareCompleteWitness.stock_prepare_complete_halt_witness) ∧
  Root _ (@Backend.Stock.Proof.PrepareCompleteWitness.stock_prepare_complete_return_witness) ∧
  Root _ (@Backend.Stock.Proof.PreparedForwardWitness.stock_prepared_halt_forward_witness) ∧
  Root _ (@Backend.Stock.Proof.PreparedForwardWitness.stock_prepared_return_forward_witness) ∧
  Root _ (@Backend.Stock.Proof.ReturnABI.ordinary) ∧
  Root _ (@Backend.Stock.Proof.RunOkABI.legacy) ∧
  Root _ (@Backend.Stock.Proof.RunOkABI.prefix) ∧
  Root _ (@Backend.Stock.Proof.TermContractWitness.stock_trap_term_contract_witness) ∧
  Root _ (@Backend.Stock.Proof.aliasNum.eq_1) ∧
  Root _ (@Backend.Stock.Proof.edgeArgumentNumbers.eq_1) ∧
  Root _ (@Backend.Stock.Proof.edgeParamNumbers.eq_1) ∧
  Root _ (@Backend.Stock.Proof.edgeValueNum.eq_1) ∧
  Root _ (@Backend.Stock.Proof.outgoingAt.eq_1) ∧
  Root _ (@Backend.Stock.Proof.sourceTargetIndex.eq_1) ∧
  Root _ (@Backend.Stock.Proof.sourceTargetParams.eq_1) ∧
  Root _ (@Backend.Stock.Proof.source_defined_branch_step) ∧
  Root _ (@Backend.Stock.Proof.source_defined_enterBlock) ∧
  Root _ (@Backend.Stock.Proof.stock_branchArgs_jump_numbers) ∧
  Root _ (@Backend.Stock.Proof.stock_branchArgs_selected_numbers) ∧
  Root _ (@Backend.Stock.Proof.stock_lower_block_scan_code) ∧
  Root _ (@Backend.Stock.Proof.stock_lower_critical_argument_vector) ∧
  Root _ (@Backend.Stock.Proof.stock_lower_critical_code) ∧
  Root _ (@Backend.Stock.Proof.stock_lower_critical_edge_values) ∧
  Root _ (@Backend.Stock.Proof.stock_lower_critical_outgoing) ∧
  Root _ (@Backend.Stock.Proof.stock_lower_critical_per_edge_values) ∧
  Root _ (@Backend.Stock.Proof.stock_lower_deferred_outgoing) ∧
  Root _ (@Backend.Stock.Proof.stock_lower_direct_per_edge_values) ∧
  Root _ (@Backend.Stock.Proof.stock_lower_edge_successor) ∧
  Root _ (@Backend.Stock.Proof.stock_lower_edge_values) ∧
  Root _ (@Backend.Stock.Proof.stock_lower_entry_alias_apart) ∧
  Root _ (@Backend.Stock.Proof.stock_lower_jump_nonentry_successor) ∧
  Root _ (@Backend.Stock.Proof.stock_lower_jump_successor) ∧
  Root _ (@Backend.Stock.Proof.stock_lower_order) ∧
  Root _ (@Backend.Stock.Proof.stock_lower_original_block_params) ∧
  Root _ (@Backend.Stock.Proof.stock_lower_original_jump_args) ∧
  Root _ (@Backend.Stock.Proof.stock_lower_original_outgoing) ∧
  Root _ (@Backend.Stock.Proof.stock_lower_parameter_resolves) ∧
  Root _ (@Backend.Stock.Proof.stock_lower_record_code) ∧
  Root _ (@Backend.Stock.Proof.stock_lower_record_segment) ∧
  Root _ (@Backend.Stock.Proof.stock_lower_selected_outgoing) ∧
  Root _ (@Backend.Stock.Proof.stock_lower_selected_route_values) ∧
  Root _ (@Backend.Stock.Proof.stock_lower_selected_successor) ∧
  Root _ (@Backend.Stock.Proof.stock_prepCheckAt_complete) ∧
  Root _ (@Backend.Stock.Proof.stock_prepareCheckedAt_complete) ∧
  Root _ (@Backend.Stock.Proof.stock_prepare_dimensions) ∧
  Root _ (@Backend.Stock.Proof.stock_prepare_domain) ∧
  Root _ (@Backend.Stock.Proof.stock_prepare_halt) ∧
  Root _ (@Backend.Stock.Proof.stock_prepare_return) ∧
  Root _ (@Backend.Stock.Proof.stock_prepare_sound) ∧
  Root _ (@Backend.ensure.eq_1) ∧
  Root _ (@Backend.lowerAllocAt.eq_1) ∧
  Root _ (@Backend.prepareCheckedAt.eq_1) ∧
  Root _ (@Clif.Function.block?.eq_1) ∧
  Root _ (@Clif.Regs.empty.eq_1) ∧
  Root _ (@Clif.runLoop_ren) ∧
  Root _ (@E2E.DeadCleanupExecBytes.binary_correct_exec) ∧
  Root _ (@E2E.DeadCleanupExecBytes.binary_correct_exec_of_good) ∧
  Root _ (@E2E.DeadCleanupExecBytes.binary_correct_exec_of_got) ∧
  Root _ (@E2E.DeadCleanupExecBytes.binary_correct_exec_of_insn) ∧
  Root _ (@E2E.DeadCleanupExecBytes.binary_correct_exec_of_reads) ∧
  Root _ (@E2E.DeadCleanupExecBytes.binary_correct_exec_peak_proven) ∧
  Root _ (@E2E.DeadCleanupExecBytes.binary_correct_exec_proven) ∧
  Root _ (@E2E.DeadCleanupExecBytes.binary_correct_exec_static) ∧
  Root _ (@E2E.DeadCleanupExecBytes.binary_correct_exec_staticN) ∧
  Root _ (@E2E.DeadCleanupStackBound.goodN_iff) ∧
  Root _ (@E2E.DeadCleanupStackBound.stackB_isSome_iff) ∧
  Root _ (@E2E.ExecBytes.binary_correct_exec) ∧
  Root _ (@E2E.ExecBytes.binary_correct_exec_depth_proven) ∧
  Root _ (@E2E.ExecBytes.binary_correct_exec_of_good) ∧
  Root _ (@E2E.ExecBytes.binary_correct_exec_of_got) ∧
  Root _ (@E2E.ExecBytes.binary_correct_exec_of_insn) ∧
  Root _ (@E2E.ExecBytes.binary_correct_exec_of_reads) ∧
  Root _ (@E2E.ExecBytes.binary_correct_exec_peak_proven) ∧
  Root _ (@E2E.ExecBytes.binary_correct_exec_proven) ∧
  Root _ (@E2E.ExecBytes.binary_correct_exec_static) ∧
  Root _ (@E2E.ExecBytes.binary_correct_exec_staticN) ∧
  Root _ (@E2E.LegalProgram.legalProg_refines) ∧
  Root _ (@E2E.LegalProgram.legalProg_refines_depth) ∧
  Root _ (@E2E.LinkCheck.crate_correct_inScope_proven) ∧
  Root _ (@E2E.StackBound.budOkW_budMap) ∧
  Root _ (@E2E.StackBound.goodN_iff) ∧
  Root _ (@E2E.StackBound.stackB_isSome_iff) ∧
  Root _ (@E2E.backend_correct_final) ∧
  Root _ (@E2E.backend_correct_final_alloc) ∧
  Root _ (@E2E.backend_correct_final_alloc_proven) ∧
  Root _ (@E2E.backend_correct_final_cleanup) ∧
  Root _ (@E2E.backend_correct_final_cleanup_ex) ∧
  Root _ (@E2E.backend_correct_final_cleanup_total) ∧
  Root _ (@E2E.backend_correct_final_cleanup_total_emit) ∧
  Root _ (@E2E.backend_correct_final_cleanup_total_emit_in) ∧
  Root _ (@E2E.backend_correct_final_cleanup_total_emit_input) ∧
  Root _ (@E2E.backend_correct_final_cleanup_total_ready) ∧
  Root _ (@E2E.backend_correct_final_ex) ∧
  Root _ (@E2E.backend_correct_final_id) ∧
  Root _ (@E2E.backend_correct_final_indirectFree) ∧
  Root _ (@E2E.backend_correct_final_of_lower) ∧
  Root _ (@E2E.backend_correct_final_of_lower_ex) ∧
  Root _ (@E2E.backend_correct_final_total) ∧
  Root _ (@E2E.backend_correct_final_total_emit) ∧
  Root _ (@E2E.backend_correct_final_total_emit_in) ∧
  Root _ (@E2E.backend_correct_final_total_emit_input) ∧
  Root _ (@E2E.backend_correct_final_total_ready) ∧
  Root _ (@E2E.backend_correct_final_total_relaxed) ∧
  Root _ (@E2E.backend_correct_final_try_witness) ∧
  Root _ (@E2E.backend_correct_final_witness) ∧
  Root _ (@E2E.backend_correct_legal) ∧
  Root _ (@E2E.backend_correct_legal_callFree) ∧
  Root _ (@E2E.backend_correct_legal_callFree_cleanup) ∧
  Root _ (@E2E.backend_correct_legal_cleanup) ∧
  Root _ (@E2E.backend_correct_legal_direct) ∧
  Root _ (@E2E.backend_correct_legal_direct_cleanup) ∧
  Root _ (@E2E.backend_correct_legal_env) ∧
  Root _ (@E2E.backend_correct_legal_env_cleanup) ∧
  Root _ (@E2E.backend_correct_opt_proven) ∧
  Root _ (@E2E.backend_correct_opt_proven_cleanup) ∧
  Root _ (@E2E.backend_correct_program) ∧
  Root _ (@E2E.backend_correct_program_budget) ∧
  Root _ (@E2E.backend_correct_program_budgetX) ∧
  Root _ (@E2E.backend_correct_program_core) ∧
  Root _ (@E2E.backend_correct_program_coreX) ∧
  Root _ (@E2E.backend_correct_program_peak) ∧
  Root _ (@E2E.backend_correct_program_peakX) ∧
  Root _ (@E2E.backend_correct_program_returned) ∧
  Root _ (@E2E.backend_correct_program_returned_budget) ∧
  Root _ (@E2E.backend_correct_program_stack) ∧
  Root _ (@E2E.backend_correct_program_stackX) ∧
  Root _ (@E2E.emitReady_spill) ∧
  Root _ (@E2E.lowerRFunc_spillAlloc) ∧
  Root _ (@E2E.spillAccepted) ∧
  Root _ (@Except.toBool.eq_1) ∧
  Root _ (@Except.toBool.eq_2) ∧
  Root _ (@Front.buildSpec_spec) ∧
  Root _ (@Front.buildSpec_srcProg) ∧
  Root _ (@Front.bundle_correct_raw) ∧
  Root _ (@Front.bundle_correct_raw_baseline) ∧
  Root _ (@Front.bundle_correct_raw_peak) ∧
  Root _ (@Front.bundle_correct_raw_peak_baseline) ∧
  Root _ (@Front.bundle_correct_source) ∧
  Root _ (@Front.bundle_correct_source_baseline) ∧
  Root _ (@Front.bundle_correct_source_peak) ∧
  Root _ (@Front.bundle_correct_source_peak_baseline) ∧
  Root _ (@Front.data_complete) ∧
  Root _ (@Front.decodeFn_spec) ∧
  Root _ (@Front.link_alpha) ∧
  Root _ (@Front.parseUnit_raw) ∧
  Root _ (@Front.rawLink_eq_link) ∧
  Root _ (@Link.DeadCleanup.SourceWitness.compileExe_correct_source_helper) ∧
  Root _ (@Link.DeadCleanup.SourceWitness.compileExe_correct_source_peak_helper) ∧
  Root _ (@Link.DeadCleanup.binOk_leanLink) ∧
  Root _ (@Link.DeadCleanup.compileExe_correct) ∧
  Root _ (@Link.DeadCleanup.compileExe_correct_peak) ∧
  Root _ (@Link.DeadCleanup.compileExe_correct_source) ∧
  Root _ (@Link.DeadCleanup.compileExe_correct_source_peak) ∧
  Root _ (@Link.DeadCleanup.compileExe_total) ∧
  Root _ (@Link.DeadCleanup.compileExe_total_input) ∧
  Root _ (@Link.DeadCleanup.compileExe_total_reach) ∧
  Root _ (@Link.DeadCleanup.leanLink_linkerOk) ∧
  Root _ (@Link.DeadCleanup.relocOk_tab) ∧
  Root _ (@Link.SourceWitness.compileExe_correct_source_helper) ∧
  Root _ (@Link.SourceWitness.compileExe_correct_source_peak_helper) ∧
  Root _ (@Link.binOk_leanLink) ∧
  Root _ (@Link.compileExe_correct) ∧
  Root _ (@Link.compileExe_correct_depth) ∧
  Root _ (@Link.compileExe_correct_peak) ∧
  Root _ (@Link.compileExe_correct_source) ∧
  Root _ (@Link.compileExe_correct_source_peak) ∧
  Root _ (@Link.compileExe_total) ∧
  Root _ (@Link.compileExe_total_input) ∧
  Root _ (@Link.compileExe_total_reach) ∧
  Root _ (@Link.leanLink_linkerOk) ∧
  Root _ (@Link.relocOk_tab) ∧
  Root _ (@Opt.Legal.Complete.check_complete_of_preB) ∧
  Root _ (@Opt.Legal.Complete.preB_iff) ∧
  Root _ (@Opt.Proof.simplifyRulesCorrect_proven) ∧
  Root _ (@Opt.optimize_sim_proven) ∧
  Root _ (@StockConfig.Config.mk.inj) ∧
  Root _ (@StockConfig.Config.mk.injEq) ∧
  Root _ (@StockConfig.Config.mk.sizeOf_spec) :=
  And.intro (@Backend.CheckCtx.edgeAt.eq_1) (And.intro (@Backend.CheckCtx.edgeForget.eq_1) (And.intro (@Backend.EdgeVCode.mk.inj) (And.intro (@Backend.EdgeVCode.mk.injEq) (And.intro (@Backend.EdgeVCode.mk.sizeOf_spec) (And.intro (@Backend.Insn.decode_encode) (And.intro (@Backend.MInst.setTargets.eq_1) (And.intro (@Backend.MInst.setTargets.eq_2) (And.intro (@Backend.MInst.setTargets.eq_3) (And.intro (@Backend.MInst.setTargets.eq_4) (And.intro (@Backend.MInst.setTargets.eq_5) (And.intro (@Backend.MInst.setTargets.eq_6) (And.intro (@Backend.Proof.Driver.formsCovered_complete) (And.intro (@Backend.Proof.Driver.lowerCheck_complete) (And.intro (@Backend.Proof.Driver.prepDomain_of_lower) (And.intro (@Backend.Proof.PerEdge.Checked.at) (And.intro (@Backend.Proof.PerEdge.Checked.blocks) (And.intro (@Backend.Proof.PerEdge.Checked.cfg) (And.intro (@Backend.Proof.PerEdge.Checked.entry) (And.intro (@Backend.Proof.PerEdge.Checked.nonempty) (And.intro (@Backend.Proof.PerEdge.Checked.rf_eq) (And.intro (@Backend.Proof.PerEdge.Checked.size) (And.intro (@Backend.Proof.PerEdge.Checked.vc_eq) (And.intro (@Backend.Proof.PerEdge.CheckedAt.blocks) (And.intro (@Backend.Proof.PerEdge.CheckedAt.cfg) (And.intro (@Backend.Proof.PerEdge.CheckedAt.entry) (And.intro (@Backend.Proof.PerEdge.CheckedAt.nonempty) (And.intro (@Backend.Proof.PerEdge.CheckedAt.rf_eq) (And.intro (@Backend.Proof.PerEdge.CheckedAt.size) (And.intro (@Backend.Proof.PerEdge.CheckedAt.vc_eq) (And.intro (@Backend.Proof.PerEdge.IsSimulation.at_op) (And.intro (@Backend.Proof.PerEdge.IsSimulation.halt) (And.intro (@Backend.Proof.PerEdge.IsSimulation.move) (And.intro (@Backend.Proof.PerEdge.IsSimulation.next_vstep) (And.intro (@Backend.Proof.PerEdge.IsSimulation.progress) (And.intro (@Backend.Proof.PerEdge.IsSimulation.ret) (And.intro (@Backend.Proof.PerEdge.IsSimulation.run) (And.intro (@Backend.Proof.PerEdge.IsSimulation.star) (And.intro (@Backend.Proof.PerEdge.IsSimulation.step) (And.intro (@Backend.Proof.PerEdge.VNextAt_det) (And.intro (@Backend.Proof.PerEdge.VStepAt_det) (And.intro (@Backend.Proof.PerEdge.allocChecked_of_checkAlloc) (And.intro (@Backend.Proof.PerEdge.allocChecked_sound) (And.intro (@Backend.Proof.PerEdge.allocResultAt_checked) (And.intro (@Backend.Proof.PerEdge.checkAlloc_diverges) (And.intro (@Backend.Proof.PerEdge.checkAlloc_halt) (And.intro (@Backend.Proof.PerEdge.checkAlloc_ok) (And.intro (@Backend.Proof.PerEdge.checkAlloc_ret) (And.intro (@Backend.Proof.PerEdge.checkAlloc_sound) (And.intro (@Backend.Proof.PerEdge.checkAlloc_stuck) (And.intro (@Backend.Proof.PerEdge.checkedAt_sound) (And.intro (@Backend.Proof.PerEdge.checked_of_checkAlloc) (And.intro (@Backend.Proof.PerEdge.edgeCopy_ok) (And.intro (@Backend.Proof.PerEdge.edgeEnv_lt) (And.intro (@Backend.Proof.PerEdge.edge_ok) (And.intro (@Backend.Proof.PerEdge.enter_block) (And.intro (@Backend.Proof.PerEdge.enter_block_at) (And.intro (@Backend.Proof.PerEdge.forward) (And.intro (@Backend.Proof.PerEdge.forward_aux) (And.intro (@Backend.Proof.PerEdge.forward_op) (And.intro (@Backend.Proof.PerEdge.lowerAllocAt_ok) (And.intro (@Backend.Proof.PerEdge.lowerAllocAt_sound) (And.intro (@Backend.Proof.PerEdge.prepareCheckedAt_ok) (And.intro (@Backend.Proof.PerEdge.prepared_halt_forward) (And.intro (@Backend.Proof.PerEdge.prepared_return_forward) (And.intro (@Backend.Proof.PerEdge.sim_progress) (And.intro (@Backend.Proof.PerEdge.sim_progress_at) (And.intro (@Backend.Proof.PerEdge.sim_step) (And.intro (@Backend.Proof.PerEdge.sim_step_at) (And.intro (@Backend.Proof.PerEdge.verifyBlock_ok) (And.intro (@Backend.Proof.PerEdge.verify_ok) (And.intro (@Backend.Proof.PerEdgePrep.KeptAt.blocks) (And.intro (@Backend.Proof.PerEdgePrep.OuterInv.copies) (And.intro (@Backend.Proof.PerEdgePrep.OuterInv.graph) (And.intro (@Backend.Proof.PerEdgePrep.OuterInv.paired) (And.intro (@Backend.Proof.PerEdgePrep.OuterInv.rowCount) (And.intro (@Backend.Proof.PerEdgePrep.edgeBlockOkAt_sound) (And.intro (@Backend.Proof.PerEdgePrep.graphBlock.eq_1) (And.intro (@Backend.Proof.PerEdgePrep.graphState.eq_1) (And.intro (@Backend.Proof.PerEdgePrep.innerFoldAt_copies) (And.intro (@Backend.Proof.PerEdgePrep.innerFoldAt_facts) (And.intro (@Backend.Proof.PerEdgePrep.innerFoldAt_graph) (And.intro (@Backend.Proof.PerEdgePrep.innerFoldAt_rows) (And.intro (@Backend.Proof.PerEdgePrep.innerForInAt_eq) (And.intro (@Backend.Proof.PerEdgePrep.innerStepAt.eq_1) (And.intro (@Backend.Proof.PerEdgePrep.innerStepAt_graph) (And.intro (@Backend.Proof.PerEdgePrep.innerStepAt_rows) (And.intro (@Backend.Proof.PerEdgePrep.keptAt.eq_1) (And.intro (@Backend.Proof.PerEdgePrep.keptAt_blocks) (And.intro (@Backend.Proof.PerEdgePrep.keptAt_source) (And.intro (@Backend.Proof.PerEdgePrep.keptOkAt_sound) (And.intro (@Backend.Proof.PerEdgePrep.kept_cfg) (And.intro (@Backend.Proof.PerEdgePrep.kept_entry) (And.intro (@Backend.Proof.PerEdgePrep.live_okAt) (And.intro (@Backend.Proof.PerEdgePrep.ordered_cfg) (And.intro (@Backend.Proof.PerEdgePrep.outerLoopAt_inv) (And.intro (@Backend.Proof.PerEdgePrep.outerLoopAt_total) (And.intro (@Backend.Proof.PerEdgePrep.outerLoopAt_total_targets) (And.intro (@Backend.Proof.PerEdgePrep.outerStepAt.eq_1) (And.intro (@Backend.Proof.PerEdgePrep.outerStepAt_inv) (And.intro (@Backend.Proof.PerEdgePrep.outerStepAt_total) (And.intro (@Backend.Proof.PerEdgePrep.outer_order_facts) (And.intro (@Backend.Proof.PerEdgePrep.prepCheckAt_complete) (And.intro (@Backend.Proof.PerEdgePrep.prep_entry_step) (And.intro (@Backend.Proof.PerEdgePrep.prep_halt) (And.intro (@Backend.Proof.PerEdgePrep.prep_ret) (And.intro (@Backend.Proof.PerEdgePrep.prep_sound) (And.intro (@Backend.Proof.PerEdgePrep.prep_star) (And.intro (@Backend.Proof.PerEdgePrep.prep_step) (And.intro (@Backend.Proof.PerEdgePrep.prepareAt_cfg) (And.intro (@Backend.Proof.PerEdgePrep.prepareAt_entry) (And.intro (@Backend.Proof.PerEdgePrep.prepareAt_fields) (And.intro (@Backend.Proof.PerEdgePrep.prepareAt_input_facts) (And.intro (@Backend.Proof.PerEdgePrep.prepareAt_kept_facts) (And.intro (@Backend.Proof.PerEdgePrep.prepareAt_no_new_effects) (And.intro (@Backend.Proof.PerEdgePrep.prepareAt_outer_facts) (And.intro (@Backend.Proof.PerEdgePrep.prepareAt_stages) (And.intro (@Backend.Proof.PerEdgePrep.prepareAt_total) (And.intro (@Backend.Proof.PerEdgePrep.prepareCheckedAt_complete) (And.intro (@Backend.Proof.PerEdgePrep.prepareCheckedAt_total) (And.intro (@Backend.Proof.PerEdgePrep.setTargets_total) (And.intro (@Backend.Proof.PerEdgePrep.split_cfg) (And.intro (@Backend.Proof.PerEdgePrepLoopWitness.indexed_inner_loop_witness) (And.intro (@Backend.Proof.PerEdgePrepLoopWitness.indexed_prepare_stages_witness) (And.intro (@Backend.Proof.PerEdgePrepOuterWitness.indexed_outer_loop_witness) (And.intro (@Backend.Proof.PerEdgePrepOuterWitness.indexed_prepare_filter_facts_witness) (And.intro (@Backend.Proof.PerEdgePrepOuterWitness.indexed_prepare_outer_facts_witness) (And.intro (@Backend.Proof.PerEdgePrepOuterWitness.indexed_prepared_entry_cfg_witness) (And.intro (@Backend.Proof.PerEdgePrepOuterWitness.indexed_rpo_witness) (And.intro (@Backend.Proof.PerEdgePrepTotalWitness.raw_prepare_total_witness) (And.intro (@Backend.Proof.PerEdgePrepTotalWitness.retarget_total_witness) (And.intro (@Backend.Proof.PerEdgePrepTotalWitness.splitting_total_witness) (And.intro (@Backend.Proof.PerEdgePrepTotalWitness.stock_dimensions_witness) (And.intro (@Backend.Proof.PerEdgePrepareWitness.per_edge_prepare_split_copy_witness) (And.intro (@Backend.Proof.Prep.prepCheck_complete) (And.intro (@Backend.Proof.Prep.prepare_correct) (And.intro (@Backend.Proof.edgeEnvAt.eq_1) (And.intro (@Backend.Proof.edgeEnvAt_eq) (And.intro (@Backend.SpillHomesAt.mk.inj) (And.intro (@Backend.SpillHomesAt.mk.injEq) (And.intro (@Backend.SpillHomesAt.mk.sizeOf_spec) (And.intro (@Backend.Stock.Proof.CriticalValuesWitness.stock_critical_edge_env_witness) (And.intro (@Backend.Stock.Proof.CriticalValuesWitness.stock_critical_per_edge_step_witness) (And.intro (@Backend.Stock.Proof.CriticalValuesWitness.stock_critical_selected_route_witness) (And.intro (@Backend.Stock.Proof.LowerTermOkABI.defs) (And.intro (@Backend.Stock.Proof.LowerTermOkABI.legacy) (And.intro (@Backend.Stock.Proof.LowerTermOkABI.mono) (And.intro (@Backend.Stock.Proof.LowerTermOkABI.run) (And.intro (@Backend.Stock.Proof.PerEdgeAllocatorWitness.stock_per_edge_allocator_fallback_witness) (And.intro (@Backend.Stock.Proof.PerEdgeCheckerWitness.stock_per_edge_checker_value_witness) (And.intro (@Backend.Stock.Proof.PerEdgeCheckerWitness.stock_per_edge_checker_witness) (And.intro (@Backend.Stock.Proof.PerEdgeCriticalAllocatorWitness.stock_per_edge_critical_allocator_fallback_witness) (And.intro (@Backend.Stock.Proof.PerEdgeM6HaltWitness.stock_per_edge_m6_halt_witness) (And.intro (@Backend.Stock.Proof.PerEdgeM6Witness.stock_per_edge_m6_checked_witness) (And.intro (@Backend.Stock.Proof.PerEdgeM6Witness.stock_per_edge_m6_return_witness) (And.intro (@Backend.Stock.Proof.PerSuccessorWitness.stock_per_successor_migration_witness) (And.intro (@Backend.Stock.Proof.PrepareCompleteWitness.generic_prepare_complete_witness) (And.intro (@Backend.Stock.Proof.PrepareCompleteWitness.stock_prepare_complete_critical_witness) (And.intro (@Backend.Stock.Proof.PrepareCompleteWitness.stock_prepare_complete_halt_witness) (And.intro (@Backend.Stock.Proof.PrepareCompleteWitness.stock_prepare_complete_return_witness) (And.intro (@Backend.Stock.Proof.PreparedForwardWitness.stock_prepared_halt_forward_witness) (And.intro (@Backend.Stock.Proof.PreparedForwardWitness.stock_prepared_return_forward_witness) (And.intro (@Backend.Stock.Proof.ReturnABI.ordinary) (And.intro (@Backend.Stock.Proof.RunOkABI.legacy) (And.intro (@Backend.Stock.Proof.RunOkABI.prefix) (And.intro (@Backend.Stock.Proof.TermContractWitness.stock_trap_term_contract_witness) (And.intro (@Backend.Stock.Proof.aliasNum.eq_1) (And.intro (@Backend.Stock.Proof.edgeArgumentNumbers.eq_1) (And.intro (@Backend.Stock.Proof.edgeParamNumbers.eq_1) (And.intro (@Backend.Stock.Proof.edgeValueNum.eq_1) (And.intro (@Backend.Stock.Proof.outgoingAt.eq_1) (And.intro (@Backend.Stock.Proof.sourceTargetIndex.eq_1) (And.intro (@Backend.Stock.Proof.sourceTargetParams.eq_1) (And.intro (@Backend.Stock.Proof.source_defined_branch_step) (And.intro (@Backend.Stock.Proof.source_defined_enterBlock) (And.intro (@Backend.Stock.Proof.stock_branchArgs_jump_numbers) (And.intro (@Backend.Stock.Proof.stock_branchArgs_selected_numbers) (And.intro (@Backend.Stock.Proof.stock_lower_block_scan_code) (And.intro (@Backend.Stock.Proof.stock_lower_critical_argument_vector) (And.intro (@Backend.Stock.Proof.stock_lower_critical_code) (And.intro (@Backend.Stock.Proof.stock_lower_critical_edge_values) (And.intro (@Backend.Stock.Proof.stock_lower_critical_outgoing) (And.intro (@Backend.Stock.Proof.stock_lower_critical_per_edge_values) (And.intro (@Backend.Stock.Proof.stock_lower_deferred_outgoing) (And.intro (@Backend.Stock.Proof.stock_lower_direct_per_edge_values) (And.intro (@Backend.Stock.Proof.stock_lower_edge_successor) (And.intro (@Backend.Stock.Proof.stock_lower_edge_values) (And.intro (@Backend.Stock.Proof.stock_lower_entry_alias_apart) (And.intro (@Backend.Stock.Proof.stock_lower_jump_nonentry_successor) (And.intro (@Backend.Stock.Proof.stock_lower_jump_successor) (And.intro (@Backend.Stock.Proof.stock_lower_order) (And.intro (@Backend.Stock.Proof.stock_lower_original_block_params) (And.intro (@Backend.Stock.Proof.stock_lower_original_jump_args) (And.intro (@Backend.Stock.Proof.stock_lower_original_outgoing) (And.intro (@Backend.Stock.Proof.stock_lower_parameter_resolves) (And.intro (@Backend.Stock.Proof.stock_lower_record_code) (And.intro (@Backend.Stock.Proof.stock_lower_record_segment) (And.intro (@Backend.Stock.Proof.stock_lower_selected_outgoing) (And.intro (@Backend.Stock.Proof.stock_lower_selected_route_values) (And.intro (@Backend.Stock.Proof.stock_lower_selected_successor) (And.intro (@Backend.Stock.Proof.stock_prepCheckAt_complete) (And.intro (@Backend.Stock.Proof.stock_prepareCheckedAt_complete) (And.intro (@Backend.Stock.Proof.stock_prepare_dimensions) (And.intro (@Backend.Stock.Proof.stock_prepare_domain) (And.intro (@Backend.Stock.Proof.stock_prepare_halt) (And.intro (@Backend.Stock.Proof.stock_prepare_return) (And.intro (@Backend.Stock.Proof.stock_prepare_sound) (And.intro (@Backend.ensure.eq_1) (And.intro (@Backend.lowerAllocAt.eq_1) (And.intro (@Backend.prepareCheckedAt.eq_1) (And.intro (@Clif.Function.block?.eq_1) (And.intro (@Clif.Regs.empty.eq_1) (And.intro (@Clif.runLoop_ren) (And.intro (@E2E.DeadCleanupExecBytes.binary_correct_exec) (And.intro (@E2E.DeadCleanupExecBytes.binary_correct_exec_of_good) (And.intro (@E2E.DeadCleanupExecBytes.binary_correct_exec_of_got) (And.intro (@E2E.DeadCleanupExecBytes.binary_correct_exec_of_insn) (And.intro (@E2E.DeadCleanupExecBytes.binary_correct_exec_of_reads) (And.intro (@E2E.DeadCleanupExecBytes.binary_correct_exec_peak_proven) (And.intro (@E2E.DeadCleanupExecBytes.binary_correct_exec_proven) (And.intro (@E2E.DeadCleanupExecBytes.binary_correct_exec_static) (And.intro (@E2E.DeadCleanupExecBytes.binary_correct_exec_staticN) (And.intro (@E2E.DeadCleanupStackBound.goodN_iff) (And.intro (@E2E.DeadCleanupStackBound.stackB_isSome_iff) (And.intro (@E2E.ExecBytes.binary_correct_exec) (And.intro (@E2E.ExecBytes.binary_correct_exec_depth_proven) (And.intro (@E2E.ExecBytes.binary_correct_exec_of_good) (And.intro (@E2E.ExecBytes.binary_correct_exec_of_got) (And.intro (@E2E.ExecBytes.binary_correct_exec_of_insn) (And.intro (@E2E.ExecBytes.binary_correct_exec_of_reads) (And.intro (@E2E.ExecBytes.binary_correct_exec_peak_proven) (And.intro (@E2E.ExecBytes.binary_correct_exec_proven) (And.intro (@E2E.ExecBytes.binary_correct_exec_static) (And.intro (@E2E.ExecBytes.binary_correct_exec_staticN) (And.intro (@E2E.LegalProgram.legalProg_refines) (And.intro (@E2E.LegalProgram.legalProg_refines_depth) (And.intro (@E2E.LinkCheck.crate_correct_inScope_proven) (And.intro (@E2E.StackBound.budOkW_budMap) (And.intro (@E2E.StackBound.goodN_iff) (And.intro (@E2E.StackBound.stackB_isSome_iff) (And.intro (@E2E.backend_correct_final) (And.intro (@E2E.backend_correct_final_alloc) (And.intro (@E2E.backend_correct_final_alloc_proven) (And.intro (@E2E.backend_correct_final_cleanup) (And.intro (@E2E.backend_correct_final_cleanup_ex) (And.intro (@E2E.backend_correct_final_cleanup_total) (And.intro (@E2E.backend_correct_final_cleanup_total_emit) (And.intro (@E2E.backend_correct_final_cleanup_total_emit_in) (And.intro (@E2E.backend_correct_final_cleanup_total_emit_input) (And.intro (@E2E.backend_correct_final_cleanup_total_ready) (And.intro (@E2E.backend_correct_final_ex) (And.intro (@E2E.backend_correct_final_id) (And.intro (@E2E.backend_correct_final_indirectFree) (And.intro (@E2E.backend_correct_final_of_lower) (And.intro (@E2E.backend_correct_final_of_lower_ex) (And.intro (@E2E.backend_correct_final_total) (And.intro (@E2E.backend_correct_final_total_emit) (And.intro (@E2E.backend_correct_final_total_emit_in) (And.intro (@E2E.backend_correct_final_total_emit_input) (And.intro (@E2E.backend_correct_final_total_ready) (And.intro (@E2E.backend_correct_final_total_relaxed) (And.intro (@E2E.backend_correct_final_try_witness) (And.intro (@E2E.backend_correct_final_witness) (And.intro (@E2E.backend_correct_legal) (And.intro (@E2E.backend_correct_legal_callFree) (And.intro (@E2E.backend_correct_legal_callFree_cleanup) (And.intro (@E2E.backend_correct_legal_cleanup) (And.intro (@E2E.backend_correct_legal_direct) (And.intro (@E2E.backend_correct_legal_direct_cleanup) (And.intro (@E2E.backend_correct_legal_env) (And.intro (@E2E.backend_correct_legal_env_cleanup) (And.intro (@E2E.backend_correct_opt_proven) (And.intro (@E2E.backend_correct_opt_proven_cleanup) (And.intro (@E2E.backend_correct_program) (And.intro (@E2E.backend_correct_program_budget) (And.intro (@E2E.backend_correct_program_budgetX) (And.intro (@E2E.backend_correct_program_core) (And.intro (@E2E.backend_correct_program_coreX) (And.intro (@E2E.backend_correct_program_peak) (And.intro (@E2E.backend_correct_program_peakX) (And.intro (@E2E.backend_correct_program_returned) (And.intro (@E2E.backend_correct_program_returned_budget) (And.intro (@E2E.backend_correct_program_stack) (And.intro (@E2E.backend_correct_program_stackX) (And.intro (@E2E.emitReady_spill) (And.intro (@E2E.lowerRFunc_spillAlloc) (And.intro (@E2E.spillAccepted) (And.intro (@Except.toBool.eq_1) (And.intro (@Except.toBool.eq_2) (And.intro (@Front.buildSpec_spec) (And.intro (@Front.buildSpec_srcProg) (And.intro (@Front.bundle_correct_raw) (And.intro (@Front.bundle_correct_raw_baseline) (And.intro (@Front.bundle_correct_raw_peak) (And.intro (@Front.bundle_correct_raw_peak_baseline) (And.intro (@Front.bundle_correct_source) (And.intro (@Front.bundle_correct_source_baseline) (And.intro (@Front.bundle_correct_source_peak) (And.intro (@Front.bundle_correct_source_peak_baseline) (And.intro (@Front.data_complete) (And.intro (@Front.decodeFn_spec) (And.intro (@Front.link_alpha) (And.intro (@Front.parseUnit_raw) (And.intro (@Front.rawLink_eq_link) (And.intro (@Link.DeadCleanup.SourceWitness.compileExe_correct_source_helper) (And.intro (@Link.DeadCleanup.SourceWitness.compileExe_correct_source_peak_helper) (And.intro (@Link.DeadCleanup.binOk_leanLink) (And.intro (@Link.DeadCleanup.compileExe_correct) (And.intro (@Link.DeadCleanup.compileExe_correct_peak) (And.intro (@Link.DeadCleanup.compileExe_correct_source) (And.intro (@Link.DeadCleanup.compileExe_correct_source_peak) (And.intro (@Link.DeadCleanup.compileExe_total) (And.intro (@Link.DeadCleanup.compileExe_total_input) (And.intro (@Link.DeadCleanup.compileExe_total_reach) (And.intro (@Link.DeadCleanup.leanLink_linkerOk) (And.intro (@Link.DeadCleanup.relocOk_tab) (And.intro (@Link.SourceWitness.compileExe_correct_source_helper) (And.intro (@Link.SourceWitness.compileExe_correct_source_peak_helper) (And.intro (@Link.binOk_leanLink) (And.intro (@Link.compileExe_correct) (And.intro (@Link.compileExe_correct_depth) (And.intro (@Link.compileExe_correct_peak) (And.intro (@Link.compileExe_correct_source) (And.intro (@Link.compileExe_correct_source_peak) (And.intro (@Link.compileExe_total) (And.intro (@Link.compileExe_total_input) (And.intro (@Link.compileExe_total_reach) (And.intro (@Link.leanLink_linkerOk) (And.intro (@Link.relocOk_tab) (And.intro (@Opt.Legal.Complete.check_complete_of_preB) (And.intro (@Opt.Legal.Complete.preB_iff) (And.intro (@Opt.Proof.simplifyRulesCorrect_proven) (And.intro (@Opt.optimize_sim_proven) (And.intro (@StockConfig.Config.mk.inj) (And.intro (@StockConfig.Config.mk.injEq) ((@StockConfig.Config.mk.sizeOf_spec))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
end StockDeliveryAudit

#print axioms StockDeliveryAudit.pr246_bundle
