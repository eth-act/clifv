import StockTryRootMatch
namespace Backend.Stock.Proof.TryRhsCallsDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64 TryRootMatchDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm
private theorem sem_ctor (ctx : Ctx) (t : Term) (vs : List V) (st : State) :
    (Stock.sem ctx).ctor t vs st = Stock.externCtor ctx t vs st := rfl
private theorem sem_zero (ctx : Ctx) : (Stock.sem ctx).int 10 0 = .int 0 := by
  unfold Stock.sem Backend.sem normInt Isle.Aarch64.program
  rfl

def DirectTryCalls (p : Program) (ctx : Ctx) (args : List Nat) (sig : Clif.Signature)
    (name : String) (items : List (Option Nat)) (labels : List Label)
    (before next : State) (tr trace : Array RuleId) (out : V) : Prop :=
  ∃ abi afterAbi tryInfo afterTry requested afterRequest uses afterArgs defs afterDefs info afterInfo
      machine afterMachine machineTrace callFuel emitFuel,
    Stock.externCtor ctx T.abi_sig [.op (.sig sig)] before = .ok (abi,afterAbi) ∧
    Stock.externCtor ctx T.try_call_info [.op (.exnTable sig items),.labels labels] afterAbi = .ok (tryInfo,afterTry) ∧
    Stock.externCtor ctx T.put_in_regs_vec [.values args] afterTry = .ok (requested,afterRequest) ∧
    Stock.externCtor ctx T.gen_call_args [abi,requested] afterRequest = .ok (uses,afterArgs) ∧
    Stock.externCtor ctx T.gen_try_call_rets [abi] afterArgs = .ok (defs,afterDefs) ∧
    Stock.externCtor ctx T.gen_call_info [abi,.op (.extName name),uses,defs,tryInfo,.bool false] afterDefs = .ok (info,afterInfo) ∧
    30 ≤ callFuel ∧ 30 ≤ emitFuel ∧
    ApplyInternal p (Stock.sem ctx) {} callFuel 46 638 [info] (afterInfo,tr) machine (afterMachine,machineTrace) ∧
    ApplyInternal p (Stock.sem ctx) {} emitFuel 13 242 [machine] (afterMachine,machineTrace) out (next,trace)
/-- All real direct TryCall RHS helper calls at their actual intermediate
Stock states, including exception-info and reserved return/payload generation. -/
theorem stock_try_direct_rhs_calls {p : Program} (hp : Data p) (hpT : TryData p) (ctx : Ctx)
    (args : List Nat) (sig : Clif.Signature) (name : String) (items : List (Option Nat)) (labels : List Label)
    {before next : State} {tr trace : Array RuleId} {out : V}
    (run : (evalExpr p (Stock.sem ctx) {} 999999 rule_lower_2542.rhs (directEnv args sig name items labels)).run
      (before,tr) = .ok (some out,next,trace)) : DirectTryCalls p ctx args sig name items labels before next tr trace out := by
  have hc : ({} : Config).checkOverlap = false := rfl
  obtain ⟨t300,t302,t2297,t2474⟩ := hpT
  cases hp
  isel_inv [*,rule_lower_2542,directEnv,sem_ctor] at run
  isel_destruct
  simp [Array.getElem?_setIfInBounds,Array.size_setIfInBounds] at *
  isel_destruct
  subst_vars
  unfold DirectTryCalls
  refine ⟨_,_,_,_,_,_,_,_,_,_,_,_,_,_,_,_,_,
    (by assumption),(by assumption),(by assumption),(by assumption),(by assumption),(by assumption),
    ?_,?_,(by assumption),(by assumption)⟩
  all_goals omega

def GotTryCalls (p : Program) (ctx : Ctx) (args : List Nat) (sig : Clif.Signature)
    (name : String) (distance : V) (items : List (Option Nat)) (labels : List Label)
    (before next : State) (tr trace : Array RuleId) (out : V) : Prop :=
  ∃ abi afterAbi tryInfo afterTry requested afterRequest uses afterArgs defs afterDefs boxed afterBox
      target afterTarget targetTrace info afterInfo machine afterMachine machineTrace loadFuel callFuel emitFuel,
    Stock.externCtor ctx T.abi_sig [.op (.sig sig)] before = .ok (abi,afterAbi) ∧
    Stock.externCtor ctx T.try_call_info [.op (.exnTable sig items),.labels labels] afterAbi = .ok (tryInfo,afterTry) ∧
    Stock.externCtor ctx T.put_in_regs_vec [.values args] afterTry = .ok (requested,afterRequest) ∧
    Stock.externCtor ctx T.gen_call_args [abi,requested] afterRequest = .ok (uses,afterArgs) ∧
    Stock.externCtor ctx T.gen_try_call_rets [abi] afterArgs = .ok (defs,afterDefs) ∧
    Stock.externCtor ctx T.box_external_name [.op (.extName name)] afterDefs = .ok (boxed,afterBox) ∧
    40 ≤ loadFuel ∧
    ApplyInternal p (Stock.sem ctx) {} loadFuel 27 570 [boxed,.int 0,distance]
      (afterBox,tr) target (afterTarget,targetTrace) ∧
    Stock.externCtor ctx T.gen_call_ind_info [abi,target,uses,defs,tryInfo] afterTarget = .ok (info,afterInfo) ∧
    30 ≤ callFuel ∧ 30 ≤ emitFuel ∧
    ApplyInternal p (Stock.sem ctx) {} callFuel 46 639 [info] (afterInfo,targetTrace) machine (afterMachine,machineTrace) ∧
    ApplyInternal p (Stock.sem ctx) {} emitFuel 13 242 [machine] (afterMachine,machineTrace) out (next,trace)
/-- All real GOT TryCall RHS helpers, including the actual GOT target load,
reserved exception definitions and final call/emitter executions. -/
theorem stock_try_got_rhs_calls {p : Program} (hp : Data p) (hpT : TryData p) (ctx : Ctx)
    (args : List Nat) (sig : Clif.Signature) (name : String) (distance : V)
    (items : List (Option Nat)) (labels : List Label)
    {before next : State} {tr trace : Array RuleId} {out : V}
    (run : (evalExpr p (Stock.sem ctx) {} 999999 rule_lower_2551.rhs (gotEnv args sig name distance items labels)).run
      (before,tr) = .ok (some out,next,trace)) : GotTryCalls p ctx args sig name distance items labels before next tr trace out := by
  have hc : ({} : Config).checkOverlap = false := rfl
  obtain ⟨t300,t302,t2297,t2474⟩ := hpT
  cases hp
  isel_inv [*,rule_lower_2551,gotEnv,sem_ctor] at run
  isel_destruct
  simp [Array.getElem?_setIfInBounds,Array.size_setIfInBounds] at *
  isel_destruct
  subst_vars
  simp only [sem_zero] at *
  unfold GotTryCalls
  refine ⟨_,_,_,_,_,_,_,_,_,_,_,_,_,_,_,_,_,_,_,_,_,_,_,
    (by assumption),(by assumption),(by assumption),(by assumption),(by assumption),(by assumption),
    ?_,(by assumption),(by assumption),?_,?_,(by assumption),(by assumption)⟩
  all_goals omega

def IndirectTryCalls (p : Program) (ctx : Ctx) (callee : Nat) (args : List Nat) (sig : Clif.Signature)
    (items : List (Option Nat)) (labels : List Label) (before next : State) (tr trace : Array RuleId) (out : V) : Prop :=
  ∃ abi afterAbi tryInfo afterTry target afterTarget requested afterRequest uses afterArgs defs afterDefs
      info afterInfo machine afterMachine machineTrace callFuel emitFuel,
    Stock.externCtor ctx T.abi_sig [.op (.sig sig)] before = .ok (abi,afterAbi) ∧
    Stock.externCtor ctx T.try_call_info [.op (.exnTable sig items),.labels labels] afterAbi = .ok (tryInfo,afterTry) ∧
    Stock.externCtor ctx T.put_in_reg [.value callee] afterTry = .ok (target,afterTarget) ∧
    Stock.externCtor ctx T.put_in_regs_vec [.values args] afterTarget = .ok (requested,afterRequest) ∧
    Stock.externCtor ctx T.gen_call_args [abi,requested] afterRequest = .ok (uses,afterArgs) ∧
    Stock.externCtor ctx T.gen_try_call_rets [abi] afterArgs = .ok (defs,afterDefs) ∧
    Stock.externCtor ctx T.gen_call_ind_info [abi,target,uses,defs,tryInfo] afterDefs = .ok (info,afterInfo) ∧
    30 ≤ callFuel ∧ 30 ≤ emitFuel ∧
    ApplyInternal p (Stock.sem ctx) {} callFuel 46 639 [info] (afterInfo,tr) machine (afterMachine,machineTrace) ∧
    ApplyInternal p (Stock.sem ctx) {} emitFuel 13 242 [machine] (afterMachine,machineTrace) out (next,trace)
/-- All real indirect TryCall RHS helper calls, including the actual target
request and reserved exception definitions at their same Stock states. -/
theorem stock_try_indirect_rhs_calls {p : Program} (hp : Data p) (hpT : TryData p) (ctx : Ctx)
    (callee : Nat) (args : List Nat) (sig : Clif.Signature) (items : List (Option Nat)) (labels : List Label)
    {before next : State} {tr trace : Array RuleId} {out : V}
    (run : (evalExpr p (Stock.sem ctx) {} 999999 rule_lower_2561.rhs (indirectEnv callee args sig items labels)).run
      (before,tr) = .ok (some out,next,trace)) : IndirectTryCalls p ctx callee args sig items labels before next tr trace out := by
  have hc : ({} : Config).checkOverlap = false := rfl
  obtain ⟨t300,t302,t2297,t2474⟩ := hpT
  cases hp
  isel_inv [*,rule_lower_2561,indirectEnv,sem_ctor] at run
  isel_destruct
  simp [Array.getElem?_setIfInBounds,Array.size_setIfInBounds] at *
  isel_destruct
  subst_vars
  unfold IndirectTryCalls
  refine ⟨_,_,_,_,_,_,_,_,_,_,_,_,_,_,_,_,_,_,_,
    (by assumption),(by assumption),(by assumption),(by assumption),(by assumption),(by assumption),(by assumption),
    ?_,?_,(by assumption),(by assumption)⟩
  all_goals omega
end Backend.Stock.Proof.TryRhsCallsDraft
