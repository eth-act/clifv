import StockTryBranchSelection
import FV.Backend.Proof.IselCtl
import FV.Backend.Proof.IselCtlTryInd
namespace Backend.Stock.Proof.TryRuleSelectionDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open TrySourceContextDraft TryBranchSelectionDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm
private theorem matched_format {ctx : Ctx} {r : Rule} {fT : Nat}
    (format : ruleFmt r = some fT) (lo : 2447 ≤ fT) (hi : fT < 2447+36)
    {fuel ti : Nat} {labels : List Label} {st next : State × Array RuleId} {env : Isle.Interp.Env V}
    (matched : (matchRule program (Stock.sem ctx) {} fuel r [.inst ti,.labels labels]).run st = .ok (some env,next)) :
    ∃ info fs,ctx.insts[ti]? = some info ∧ info.data = .data 152 (fT-2447) fs := by
  have bound : fT-2447 < 36 := by omega
  obtain ⟨term,lookup,kind⟩ := fmtKinds_program (fT-2447) bound
  rw [show 2447+(fT-2447)=fT by omega] at lookup
  cases fuel with
  | zero => rw [matchRule.eq_1] at matched; cases matched
  | succ fuel =>
    obtain ⟨env0,args,_⟩ := matchRule_some_inv matched
    rw [stock_matchArgs] at args
    unfold ruleFmt at format
    split at format
    · rename_i q qs shape
      rw [shape] at args
      obtain ⟨env1,head,_⟩ := matchArgs_cons_inv args
      exact rootFmt_match_k data_program format lookup kind head
    · cases format
private theorem rule_member {f : Clif.Function} {result : Result} {label bi : Nat} {b : Clif.Block}
    {source : TryBranchSource f result label bi b} (selected : TryBranchSelection source) :
    selected.selected.rule ∈ program.rulesOf TId.lower_branch := by
  change selected.selected.rule ∈ program.rulesOf T.lower_branch.id
  rw [selected.selected.candidates]
  exact List.mem_append_right _ List.mem_cons_self
/-- An actual selected direct TryCall rule is exactly the real direct or GOT
rule. Original source data and the actual match exclude every other branch
family; identity-based CtxInv is not assumed for Stock's mapped context. -/
theorem stock_selected_try_direct_rule {f : Clif.Function} {result : Result} {label bi : Nat} {b : Clif.Block}
    {source : TryBranchSource f result label bi b} (selected : TryBranchSelection source)
    {fn : Nat} {args : List Nat} {et : Clif.ExnTable} (kind : b.term = .tryCall fn args et) :
    selected.selected.rule = rule_lower_2542 ∨ selected.selected.rule = rule_lower_2551 := by
  have member := rule_member selected
  have checked := List.all_eq_true.mp lower_branch_try_fmts selected.selected.rule member
  simp only [tryFmtOk,Bool.or_eq_true] at checked
  rcases checked with root | other
  · simp only [tryRootRule,Bool.or_eq_true,beq_iff_eq] at root
    rcases root with direct | got
    · exact .inl (eq_of_mem_of_id lower_branch_ids_nodup member mem_lower_branch_2542 direct)
    · exact .inr (eq_of_mem_of_id lower_branch_ids_nodup member mem_lower_branch_2551 got)
  · cases format : ruleFmt selected.selected.rule with
    | none => simp only [format] at other; cases other
    | some fT =>
      simp only [format,Bool.and_eq_true,decide_eq_true_eq,bne_iff_ne,ne_eq] at other
      obtain ⟨⟨lo,hi⟩,different⟩ := other
      obtain ⟨info,fs,lookup,shape⟩ := matched_format format lo hi selected.selected.matchedRun
      rw [source.slot] at lookup
      cases lookup
      obtain ⟨sig,items,ext,table,external,signature,data⟩ := stock_try_source_direct_data source kind
      rw [data] at shape
      simp only [V.data.injEq] at shape
      omega
/-- An actual selected indirect TryCall is exactly rule1036. The real source
layout and actual match rule out every other branch family internally. -/
theorem stock_selected_try_indirect_rule {f : Clif.Function} {result : Result} {label bi : Nat} {b : Clif.Block}
    {source : TryBranchSource f result label bi b} (selected : TryBranchSelection source)
    {callee : Nat} {args : List Nat} {et : Clif.ExnTable} (kind : b.term = .tryCallIndirect callee args et) :
    selected.selected.rule = rule_lower_2561 := by
  have member := rule_member selected
  have checked := List.all_eq_true.mp lower_branch_tryInd_fmts selected.selected.rule member
  simp only [tryIndFmtOk,Bool.or_eq_true] at checked
  rcases checked with root | other
  · simp only [tryIndRootRule,beq_iff_eq] at root
    exact eq_of_mem_of_id lower_branch_ids_nodup member mem_lower_branch_2561 root
  · cases format : ruleFmt selected.selected.rule with
    | none => simp only [format] at other; cases other
    | some fT =>
      simp only [format,Bool.and_eq_true,decide_eq_true_eq,bne_iff_ne,ne_eq] at other
      obtain ⟨⟨lo,hi⟩,different⟩ := other
      obtain ⟨info,fs,lookup,shape⟩ := matched_format format lo hi selected.selected.matchedRun
      rw [source.slot] at lookup
      cases lookup
      obtain ⟨sig,items,table,data⟩ := stock_try_source_indirect_data source kind
      rw [data] at shape
      simp only [V.data.injEq] at shape
      omega
end Backend.Stock.Proof.TryRuleSelectionDraft
