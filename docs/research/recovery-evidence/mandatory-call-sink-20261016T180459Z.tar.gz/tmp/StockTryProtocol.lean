import StockTrySelectedCalls
namespace Backend.Stock.Proof.TryProtocolDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open TrySourceContextDraft TryBranchSelectionDraft TryRhsCallsDraft TrySelectedCallsDraft
/-- Exhaustive direct/GOT source cases with their internally derived actual
rule/helper protocols. Colocation is a conclusion about the existing input;
this predicate adds no accepted-program condition. -/
def ActualDirectTryProtocol {f : Clif.Function} {result : Result} {label bi : Nat} {b : Clif.Block}
    (source : TryBranchSource f result label bi b) (selected : TryBranchSelection source)
    (fn : Nat) (args : List Nat) (et : Clif.ExnTable) : Prop :=
  let start := {source.input with current := some source.ti,color := none,base.emitted := #[]}
  ∃ ext,f.extern? fn = some ext ∧
    ((ext.colocated = true ∧ ∃ items,exnTableOpnd f et = .ok (ext.sig,items) ∧
      selected.selected.rule = rule_lower_2542 ∧
      DirectTryCalls program source.ctx args ext.sig ext.name items result.order.successors[label]!.toList
        start selected.next #[] selected.selected.rhsTrace selected.out) ∨
     (ext.colocated = false ∧ ∃ items,exnTableOpnd f et = .ok (ext.sig,items) ∧
      selected.selected.rule = rule_lower_2551 ∧
      GotTryCalls program source.ctx args ext.sig ext.name (.data 38 1 []) items result.order.successors[label]!.toList
        start selected.next #[] selected.selected.rhsTrace selected.out))
/-- Original source data and actual first-match selection derive the complete
direct/GOT split and every real helper call, without a colocation certificate. -/
theorem stock_selected_direct_try_protocol {f : Clif.Function} {result : Result} {label bi : Nat} {b : Clif.Block}
    {source : TryBranchSource f result label bi b} (selected : TryBranchSelection source)
    {fn : Nat} {args : List Nat} {et : Clif.ExnTable} (kind : b.term = .tryCall fn args et) :
    ActualDirectTryProtocol source selected fn args et := by
  obtain ⟨sig,items,ext,table,external,signature,data⟩ := stock_try_source_direct_data source kind
  refine ⟨ext,external,?_⟩
  cases co : ext.colocated with
  | false =>
    obtain ⟨items,table,chosen,env,matched,trace,calls⟩ := stock_selected_try_got_rhs_calls selected kind external co
    exact .inr ⟨rfl,items,table,chosen,calls⟩
  | true =>
    obtain ⟨items,table,chosen,env,matched,trace,calls⟩ := stock_selected_try_direct_rhs_calls selected kind external co
    exact .inl ⟨rfl,items,table,chosen,calls⟩
/-- A successful actual whole Stock driver yields its exact original-source
branch, first-match selection and complete direct/GOT helper protocol internally. -/
theorem stock_lower_direct_try_protocol {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f) {label bi : Nat} {b : Clif.Block}
    (node : result.order.nodes[label]? = some (.original bi)) (block : f.blocks[bi]? = some b)
    {fn : Nat} {args : List Nat} {et : Clif.ExnTable} (kind : b.term = .tryCall fn args et) :
    ∃ (source : TryBranchSource f result label bi b) (selected : TryBranchSelection source),
      ActualDirectTryProtocol source selected fn args et := by
  have isTry : b.term.isTry = true := by rw [kind]; rfl
  obtain ⟨source,⟨selected⟩⟩ := stock_lower_try_source_selection lowered scope node block isTry
  exact ⟨source,selected,stock_selected_direct_try_protocol selected kind⟩
end Backend.Stock.Proof.TryProtocolDraft
