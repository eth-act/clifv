import StockTryNearObservation
import FV.Backend.Proof.PerEdgeSpillEntry
import FV.Backend.Proof.SpillCtlForms
import FV.Backend.Proof.SpillArity
import FV.Backend.Proof.StockCfgTotalWitness
import FV.Backend.Proof.PerEdgeAllocDriverSound

namespace Backend.Stock.Proof.TryNearFixtureDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.PerEdgeSpill Backend.Proof.Spill
set_option maxRecDepth 20000
set_option maxHeartbeats 16000000
private def signature : Clif.Signature := {returns := [⟨.i64,.none,.normal⟩],callConv := some .systemV}
private def table : Clif.ExnTable := {
  sig := 0,normal := ⟨1,[.ret 0,.val 0]⟩,items := [.tag 7 ⟨2,[.exn 0,.exn 1,.val 0]⟩] }
private def term (indirect : Bool) : Clif.Terminator :=
  if indirect then .tryCallIndirect 1 [] table else .tryCall 0 [] table
def function (indirect : Bool) : Clif.Function := {
  name := "stock_spill_try_entry",sig := signature,sigDecls := [(0,signature)],externs := [(0,{name := "callee",sig := signature,colocated := true})]
  blocks := [{id := 0,body := [⟨[0],.iconst .i64 9⟩] ++
      (if indirect then [⟨[1],.iconst .i64 4096⟩] else []),term := term indirect},
    {id := 1,params := [(2,.i64),(3,.i64)],term := .ret [2]},
    {id := 2,params := [(4,.i64),(5,.i64),(6,.i64)],term := .ret [4]}] }
private def pipeline (indirect : Bool) : Except String (Result × EdgeVCode × RFunc × AFunc) := do
  let result ← Stock.lower (function indirect)
  let prepared ← prepareAt result.code result.edgeArgs
  let rf ← allocResultAt prepared.code prepared.edges (.error "force indexed try fallback")
  let af ← lowerRFunc prepared.code rf
  pure (result,prepared,rf,af)

private def original (indirect : Bool) : Ctx × Array (Nat × Nat) × LState :=
  (Backend.buildCtx (function indirect)).toOption.getD (sinkCtx,#[],default)
private theorem original_build (indirect : Bool) : Backend.buildCtx (function indirect) = .ok (original indirect) := by
  cases indirect <;> rfl
private theorem scope (indirect : Bool) : LowerScope (function indirect) := by
  cases indirect <;> apply lowerScope_of <;> decide +kernel
private theorem arity (indirect : Bool) : ArityOk (function indirect) := by
  cases indirect <;> apply arityOk_of <;> decide +kernel
private theorem dominated (indirect : Bool) : Dominated (function indirect) := by
  cases indirect with
  | false =>
    constructor
    · change ([0,2,3,4,5,6] : List Nat).Nodup; decide +kernel
    · intro ctx ranges st build bi b found
      have bound : bi < 3 := by have h := lt_of_getElem? found; simpa [function] using h
      have choices : bi = 0 ∨ bi = 1 ∨ bi = 2 := by omega
      rcases choices with rfl | rfl | rfl
      all_goals
        simp [function] at found
        subst b
        constructor
        · intro j stm present y member
          cases j <;> simp at present <;> subst stm <;> cases member
        · intro y member
          simp [abiTerm,Driver.termArgs,sretRet,sigRets,function,term,table,signature,
            Clif.ExnTable.vals,Clif.TryDest.vals] at member
          simp_all [availOf,function,defsBefore,defsFrom] <;>
            (rcases member with h | h <;> simp_all [availOf,function,defsBefore,defsFrom])
    · intro ctx ranges st build tl x available notLocal y member
      have fixed := (inFix_fixOk (f := function false) (ctx := ctx) (gn := id)).cand tl x available
      have values : x = 0 ∨ x = 2 ∨ x = 3 ∨ x = 4 ∨ x = 5 ∨ x = 6 := by
        simpa [valueDefs,function] using fixed.2.2.2.1
      have context : ctx = (original false).1 := congrArg Prod.fst (Except.ok.inj (build.symm.trans (original_build false)))
      rw [context] at member
      rcases values with rfl | rfl | rfl | rfl | rfl | rfl
      all_goals change y ∈ ([] : List Nat) at member; cases member
  | true =>
    constructor
    · change ([0,1,2,3,4,5,6] : List Nat).Nodup; decide +kernel
    · intro ctx ranges st build bi b found
      have bound : bi < 3 := by have h := lt_of_getElem? found; simpa [function] using h
      have choices : bi = 0 ∨ bi = 1 ∨ bi = 2 := by omega
      rcases choices with rfl | rfl | rfl
      all_goals
        simp [function] at found
        subst b
        constructor
        · intro j stm present y member
          cases j with
          | zero => simp at present <;> subst stm <;> cases member
          | succ j => cases j <;> simp at present <;> subst stm <;> cases member
        · intro y member
          simp [abiTerm,Driver.termArgs,sretRet,sigRets,function,term,table,signature,
            Clif.ExnTable.vals,Clif.TryDest.vals] at member
          simp_all [availOf,function,defsBefore,defsFrom] <;>
            (rcases member with h | h <;> simp_all [availOf,function,defsBefore,defsFrom])
    · intro ctx ranges st build tl x available notLocal y member
      have fixed := (inFix_fixOk (f := function true) (ctx := ctx) (gn := id)).cand tl x available
      have values : x = 0 ∨ x = 1 ∨ x = 2 ∨ x = 3 ∨ x = 4 ∨ x = 5 ∨ x = 6 := by
        simpa [valueDefs,function] using fixed.2.2.2.1
      have context : ctx = (original true).1 := congrArg Prod.fst (Except.ok.inj (build.symm.trans (original_build true)))
      rw [context] at member
      rcases values with rfl | rfl | rfl | rfl | rfl | rfl | rfl
      all_goals change y ∈ ([] : List Nat) at member; cases member

private def Observed : Prop := (pipeline false).isOk = true
private theorem observed : Observed := TryNearObservationDraft.observed
structure Output where
  result : Result
  prepared : EdgeVCode
  rf : RFunc
  af : AFunc
  lowered : Stock.lower (function false) = .ok result
  scope : LowerScope (function false)
  dominated : Dominated (function false)
  arity : ArityOk (function false)
  prepare : prepareAt result.code result.edgeArgs = .ok prepared
  fallback : rf = spillAllocAt prepared.code prepared.edges
  accepted : checkAllocAt prepared.code prepared.edges rf = .ok ()
  physical : lowerRFunc prepared.code rf = .ok af
/-- Complete original-condition colocated TryCall pipeline, including checked
forced spill fallback and physical lowering, for the direct BL root witnesses. -/
theorem stock_near_try_fixture : Nonempty Output := by
  have actual := observed
  unfold Observed at actual
  cases run : pipeline false with
  | error err => rw [run] at actual; cases actual
  | ok q =>
    unfold pipeline at run
    obtain ⟨result,lowered,h⟩ := Except.bind_ok run
    obtain ⟨prepared,prepare,h⟩ := Except.bind_ok h
    obtain ⟨rf,selected,h⟩ := Except.bind_ok h
    obtain ⟨af,physical,h⟩ := Except.bind_ok h
    cases h
    have accepted := PerEdge.allocResultAt_checked selected
    have fallback : rf = spillAllocAt prepared.code prepared.edges := by
      unfold allocResultAt checkedSpillAt at selected
      simp only [bind,Except.bind] at selected
      split at selected <;> cases selected
      rfl
    exact ⟨⟨result,prepared,rf,af,lowered,scope false,dominated false,arity false,
      prepare,fallback,accepted,physical⟩⟩
end Backend.Stock.Proof.TryNearFixtureDraft
