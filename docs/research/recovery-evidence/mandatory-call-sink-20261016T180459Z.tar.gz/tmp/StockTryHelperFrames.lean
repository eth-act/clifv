import StockTryRetsFrame
namespace Backend.Stock.Proof.TryHelperFramesDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64 TryRhsCallsDraft TryRetsFrameDraft
/-- The actual Stock ABI-signature helper is the identity at its real state. -/
theorem stock_try_abi_identity {ctx : Ctx} {value abi : V} {st next : State}
    (run : Stock.externCtor ctx T.abi_sig [value] st = .ok (abi,next)) : abi = value ∧ next = st := by
  change ExtResult.ok (value,st) = .ok (abi,next) at run
  cases run
  exact ⟨rfl,rfl⟩
/-- The actual exception-info helper decodes the real signature/items/labels
and preserves every Stock state field. -/
theorem stock_try_info_frame {ctx : Ctx} {sig : Clif.Signature} {items : List (Option Nat)}
    {labels : List Label} {value : V} {st next : State}
    (run : Stock.externCtor ctx T.try_call_info [.op (.exnTable sig items),.labels labels] st = .ok (value,next)) :
    ∃ info,tryInfoOf sig items labels = some info ∧ value = .op (.tryCallInfo info) ∧ next = st := by
  change (match Backend.externCtor ctx T.try_call_info [.op (.exnTable sig items),.labels labels] st.base with
    | .ok (v,base) => ExtResult.ok (v,{st with base})
    | .fail => .fail
    | .unmodeled err => .unmodeled err) = .ok (value,next) at run
  cases call : Backend.externCtor ctx T.try_call_info [.op (.exnTable sig items),.labels labels] st.base with
  | fail => rw [call] at run; cases run
  | unmodeled err => rw [call] at run; cases run
  | ok pair =>
    obtain ⟨v,base⟩ := pair
    obtain ⟨info,selected,equal,unchanged⟩ := (ctor_try_call_info_iff st.base sig items labels v base).mp call
    subst v
    subst base
    rw [call] at run
    cases run
    exact ⟨info,selected,rfl,rfl⟩
/-- The SAME actual direct RHS produces its exception info and reserved defs,
with the actual ABI identity and alias-only state effect discharged internally. -/
theorem stock_direct_try_helper_frames {p : Program} {ctx : Ctx} {args : List Nat} {sig : Clif.Signature}
    {name : String} {items : List (Option Nat)} {labels : List Label} {st next : State}
    {tr trace : Array RuleId} {out : V} (calls : DirectTryCalls p ctx args sig name items labels st next tr trace out) :
    ∃ (info : TryInfo) (before after : State) (defs : V),tryInfoOf sig items labels = some info ∧
      Stock.externCtor ctx T.gen_try_call_rets [.op (.sig sig)] before = .ok (defs,after) ∧
      {after with alias := #[]} = {before with alias := #[]} ∧ after.base = before.base := by
  obtain ⟨abi,afterAbi,tryValue,afterTry,requested,afterRequest,uses,afterArgs,defs,afterDefs,
    callInfo,afterInfo,machine,afterMachine,machineTrace,callFuel,emitFuel,
    abiCall,tryCall,requestCall,argsCall,retsCall,infoCall,callBound,emitBound,callRun,emitRun⟩ := calls
  obtain ⟨same,frame⟩ := stock_try_abi_identity abiCall
  subst abi
  obtain ⟨info,selected,value,unchanged⟩ := stock_try_info_frame tryCall
  exact ⟨info,afterArgs,afterDefs,defs,selected,retsCall,stock_try_rets_alias_only retsCall,
    (stock_try_rets_state_frame retsCall).1⟩
/-- The SAME actual GOT RHS retains those helper/state facts across its real
symbol load and call construction, rather than using a separately replayed run. -/
theorem stock_got_try_helper_frames {p : Program} {ctx : Ctx} {args : List Nat} {sig : Clif.Signature}
    {name : String} {distance : V} {items : List (Option Nat)} {labels : List Label} {st next : State}
    {tr trace : Array RuleId} {out : V} (calls : GotTryCalls p ctx args sig name distance items labels st next tr trace out) :
    ∃ (info : TryInfo) (before after : State) (defs : V),tryInfoOf sig items labels = some info ∧
      Stock.externCtor ctx T.gen_try_call_rets [.op (.sig sig)] before = .ok (defs,after) ∧
      {after with alias := #[]} = {before with alias := #[]} ∧ after.base = before.base := by
  obtain ⟨abi,afterAbi,tryValue,afterTry,requested,afterRequest,uses,afterArgs,defs,afterDefs,
    boxed,afterBox,target,afterTarget,targetTrace,callInfo,afterInfo,machine,afterMachine,machineTrace,
    loadFuel,callFuel,emitFuel,abiCall,tryCall,requestCall,argsCall,retsCall,boxCall,loadBound,loadRun,
    infoCall,callBound,emitBound,callRun,emitRun⟩ := calls
  obtain ⟨same,frame⟩ := stock_try_abi_identity abiCall
  subst abi
  obtain ⟨info,selected,value,unchanged⟩ := stock_try_info_frame tryCall
  exact ⟨info,afterArgs,afterDefs,defs,selected,retsCall,stock_try_rets_alias_only retsCall,
    (stock_try_rets_state_frame retsCall).1⟩
/-- The SAME actual indirect RHS retains those helper/state facts across the
real callee request, call arguments and reserved return/payload definitions. -/
theorem stock_indirect_try_helper_frames {p : Program} {ctx : Ctx} {callee : Nat} {args : List Nat} {sig : Clif.Signature}
    {items : List (Option Nat)} {labels : List Label} {st next : State}
    {tr trace : Array RuleId} {out : V} (calls : IndirectTryCalls p ctx callee args sig items labels st next tr trace out) :
    ∃ (info : TryInfo) (before after : State) (defs : V),tryInfoOf sig items labels = some info ∧
      Stock.externCtor ctx T.gen_try_call_rets [.op (.sig sig)] before = .ok (defs,after) ∧
      {after with alias := #[]} = {before with alias := #[]} ∧ after.base = before.base := by
  obtain ⟨abi,afterAbi,tryValue,afterTry,target,afterTarget,requested,afterRequest,uses,afterArgs,defs,afterDefs,
    callInfo,afterInfo,machine,afterMachine,machineTrace,callFuel,emitFuel,
    abiCall,tryCall,targetCall,requestCall,argsCall,retsCall,infoCall,callBound,emitBound,callRun,emitRun⟩ := calls
  obtain ⟨same,frame⟩ := stock_try_abi_identity abiCall
  subst abi
  obtain ⟨info,selected,value,unchanged⟩ := stock_try_info_frame tryCall
  exact ⟨info,afterArgs,afterDefs,defs,selected,retsCall,stock_try_rets_alias_only retsCall,
    (stock_try_rets_state_frame retsCall).1⟩
end Backend.Stock.Proof.TryHelperFramesDraft
