import StockTryRuleSelection
namespace Backend.Stock.Proof.TryRootMatchDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm
private theorem sem_extract (ctx : Ctx) (t : Term) (v : V) (st : State) :
    (Stock.sem ctx).extract t v st = Backend.externExtract ctx t v st.base := rfl
private theorem sem_unData (ctx : Ctx) (ty : Nat) (v : V) :
    (Stock.sem ctx).unData ty v = (Backend.sem ctx).unData ty v := rfl
private theorem sem_eq (ctx : Ctx) (a b : V) : (Stock.sem ctx).eq a b = (a == b) := rfl
private theorem sem_bool (ctx : Ctx) (b : Bool) : (Stock.sem ctx).bool b = .bool b := rfl

def directEnv (args : List Nat) (sig : Clif.Signature) (name : String)
    (items : List (Option Nat)) (labels : List Label) : Isle.Interp.Env V :=
  #[some (.values args),some (.op (.sig sig)),some (.op (.extName name)),some (.bool false),
    some (.op (.exnTable sig items)),some (.labels labels),none,none,none,none,none]
def gotEnv (args : List Nat) (sig : Clif.Signature) (name : String)
    (distance : V) (items : List (Option Nat)) (labels : List Label) : Isle.Interp.Env V :=
  #[some (.values args),some (.op (.sig sig)),some (.op (.extName name)),some distance,
    some (.op (.exnTable sig items)),some (.labels labels),none,none,none,none,none,none]
def indirectEnv (callee : Nat) (args : List Nat) (sig : Clif.Signature)
    (items : List (Option Nat)) (labels : List Label) : Isle.Interp.Env V :=
  #[some (.value callee),some (.values args),some (.op (.exnTable sig items)),some (.labels labels),
    some (.op (.sig sig)),none,none,none,none,none,none]

/-- Actual colocated TryCall matching returns its canonical environment and
preserves the complete Stock state and match trace. -/
theorem stock_try_direct_root_match {p : Program} (hp : Data p) (hpT : TryData p) (ctx : Ctx)
    {ti fn : Nat} {info : IInfo} {args : List Nat} {sig : Clif.Signature} {items : List (Option Nat)}
    {ext : Clif.ExtFunc} (slot : ctx.insts[ti]? = some info)
    (data : info.data = .data 152 27 [.data 151 13 [],.values args,.op (.funcRef fn),.op (.exnTable sig items)])
    (external : ctx.func.extern? fn = some ext) (signature : ext.sig = sig) (colocated : ext.colocated = true)
    (labels : List Label) (st : State) (tr : Array RuleId) (n : Nat) :
    (matchRule p (Stock.sem ctx) {} (n+1000) rule_lower_2542 [.inst ti,.labels labels]).run (st,tr) =
      .ok (some (directEnv args sig ext.name items labels),st,tr) := by
  have source := ext_inst_data_value ctx st.base slot
  rw [data] at source
  have extracted : Backend.externExtract ctx T.func_ref_data (.op (.funcRef fn)) st.base =
      .ok [.op (.sig sig),.op (.extName ext.name),.data 38 0 [],.bool false] := by
    apply (ext_func_ref_data_iff st.base fn _).mpr
    exact ⟨ext,external,by rw [signature,colocated]; rfl⟩
  have sliced : Backend.externExtract ctx T.value_list_slice (.values args) st.base = .ok [.values args] := rfl
  obtain ⟨t300,t302,t2297,t2474⟩ := hpT
  cases hp
  isel_eval [*,rule_lower_2542,directEnv,sem_extract,sem_unData,sem_eq,sem_bool]
  isel_eval [*,rule_lower_2542,directEnv,sem_extract,sem_unData,sem_eq,sem_bool]
  rfl
/-- Actual GOT TryCall matching retains the real relocation distance and
frames the entire Stock state and match trace. -/
theorem stock_try_got_root_match {p : Program} (hp : Data p) (hpT : TryData p) (ctx : Ctx)
    {ti fn : Nat} {info : IInfo} {args : List Nat} {sig : Clif.Signature} {items : List (Option Nat)}
    {ext : Clif.ExtFunc} (slot : ctx.insts[ti]? = some info)
    (data : info.data = .data 152 27 [.data 151 13 [],.values args,.op (.funcRef fn),.op (.exnTable sig items)])
    (external : ctx.func.extern? fn = some ext) (signature : ext.sig = sig)
    (labels : List Label) (st : State) (tr : Array RuleId) (n : Nat) :
    (matchRule p (Stock.sem ctx) {} (n+1000) rule_lower_2551 [.inst ti,.labels labels]).run (st,tr) =
      .ok (some (gotEnv args sig ext.name (.data 38 (if ext.colocated then 0 else 1) []) items labels),st,tr) := by
  have source := ext_inst_data_value ctx st.base slot
  rw [data] at source
  have extracted : Backend.externExtract ctx T.func_ref_data (.op (.funcRef fn)) st.base =
      .ok [.op (.sig sig),.op (.extName ext.name),.data 38 (if ext.colocated then 0 else 1) [],.bool false] := by
    apply (ext_func_ref_data_iff st.base fn _).mpr
    exact ⟨ext,external,by rw [signature]⟩
  have sliced : Backend.externExtract ctx T.value_list_slice (.values args) st.base = .ok [.values args] := rfl
  obtain ⟨t300,t302,t2297,t2474⟩ := hpT
  cases hp
  isel_eval [*,rule_lower_2551,gotEnv,sem_extract,sem_unData,sem_eq,sem_bool]
  isel_eval [*,rule_lower_2551,gotEnv,sem_extract,sem_unData,sem_eq,sem_bool]
  rfl
/-- Actual indirect TryCall matching derives target, arguments, exception
signature and labels while preserving the entire Stock state and trace. -/
theorem stock_try_indirect_root_match {p : Program} (hp : Data p) (hpT : TryData p)
    (hpI : IndData p) (hpJ : TryIndData p) (ctx : Ctx)
    {ti callee : Nat} {info : IInfo} {args : List Nat} {sig : Clif.Signature} {items : List (Option Nat)}
    (slot : ctx.insts[ti]? = some info)
    (data : info.data = .data 152 28 [.data 151 14 [],.values (callee::args),.op (.exnTable sig items)])
    (labels : List Label) (st : State) (tr : Array RuleId) (n : Nat) :
    (matchRule p (Stock.sem ctx) {} (n+1000) rule_lower_2561 [.inst ti,.labels labels]).run (st,tr) =
      .ok (some (indirectEnv callee args sig items labels),st,tr) := by
  have source := ext_inst_data_value ctx st.base slot
  rw [data] at source
  have sliced : Backend.externExtract ctx T.value_list_slice (.values (callee::args)) st.base = .ok [.values (callee::args)] := rfl
  have unwrapped : Backend.externExtract ctx T.value_slice_unwrap (.values (callee::args)) st.base = .ok [.value callee,.values args] := rfl
  have signature : Backend.externExtract ctx T.exception_sig (.op (.exnTable sig items)) st.base = .ok [.op (.sig sig)] := rfl
  obtain ⟨t300,t302,t2297,t2474⟩ := hpT
  obtain ⟨t196,t2293,t2454⟩ := hpI
  obtain ⟨t266,t2298,t2475⟩ := hpJ
  cases hp
  isel_eval [*,rule_lower_2561,indirectEnv,sem_extract,sem_unData,sem_eq,sem_bool]
  isel_eval [*,rule_lower_2561,indirectEnv,sem_extract,sem_unData,sem_eq,sem_bool]
  rfl
end Backend.Stock.Proof.TryRootMatchDraft
