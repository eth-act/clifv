import StockTryRhsCalls
namespace Backend.Stock.Proof.TryRetsFrameDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private def fields (st : State) : State := {st with alias := #[]}
private theorem setAlias_fields {st next : State} {dst src : Reg}
    (h : st.setAlias dst src = .ok next) : fields next = fields st := by
  cases dst <;> cases src <;>
    simp only [State.setAlias, bind, Except.bind, pure, Except.pure,
      throw, throwThe, MonadExceptOf.throw] at h
  all_goals repeat' first | (solve | cases h) | (solve | cases h; rfl) | split at h

private def tryAliasStep (ps rets : List Reg) (acc : Except String (State × List Reg))
    (pair : Reg × Reg) : Except String (State × List Reg) := do
  let (s, regs) ← acc
  let (p, r) := pair
  if let some i := ps.idxOf? p then
    let some ret := rets[i]? | throw "try_call return register"
    pure (← s.setAlias r ret, regs ++ [ret])
  else pure (s, regs ++ [r])

private theorem try_fold_error (ps rets : List Reg) (pairs : List (Reg × Reg)) (e : String) :
    pairs.foldl (tryAliasStep ps rets) (.error e) = .error e := by
  induction pairs with
  | nil => rfl
  | cons pair pairs ih => exact ih

private theorem try_fold_fields (ps rets : List Reg) (pairs : List (Reg × Reg))
    (st : State) (regs : List Reg) {next : State} {out : List Reg}
    (h : pairs.foldl (tryAliasStep ps rets) (.ok (st, regs)) = .ok (next, out)) :
    fields next = fields st := by
  induction pairs generalizing st regs with
  | nil => cases h; rfl
  | cons pair pairs ih =>
    rw [List.foldl_cons] at h
    cases hs : tryAliasStep ps rets (.ok (st, regs)) pair with
    | error e => rw [hs, try_fold_error] at h; cases h
    | ok result =>
      rcases result with ⟨middle, rs⟩
      rw [hs] at h
      have hm : fields middle = fields st := by
        unfold tryAliasStep at hs
        simp only [bind, Except.bind] at hs
        cases hi : ps.idxOf? pair.1 with
        | none => simp only [hi, pure, Except.pure] at hs; cases hs; rfl
        | some i =>
          simp only [hi] at hs
          cases hr : rets[i]? with
          | none => simp only [hr] at hs; cases hs
          | some r =>
            simp only [hr] at hs
            cases ha : st.setAlias pair.2 r with
            | error e => rw [ha] at hs; cases hs
            | ok q =>
              rw [ha] at hs
              simp only [pure, Except.pure] at hs
              cases hs
              exact setAlias_fields ha
      exact (ih middle rs h).trans hm

/-- Stock's actual reserved return/payload helper changes aliases only. Every
base-machine, demand, sunk, reservation, scheduling and opportunistic field is
preserved; no identity numbering or reserved-vector certificate is assumed. -/
theorem stock_try_rets_alias_only {ctx : Ctx} {sig : Clif.Signature} {st next : State} {value : V}
    (run : Stock.externCtor ctx T.gen_try_call_rets [.op (.sig sig)] st = .ok (value,next)) :
    {next with alias := #[]} = {st with alias := #[]} := by
  change (match retRegs sig.returns.length with
    | none => ExtResult.unmodeled "try_call return count"
    | some ps =>
      match ((payloadRegs sig.callConv).zip ctx.tryRegs.2).foldl (tryAliasStep ps ctx.tryRegs.1) (Except.ok (st,([] : List Reg))) with
      | .error e => ExtResult.unmodeled e
      | .ok (s,regs) => ExtResult.ok (V.op (.callRets (ps.zip ctx.tryRegs.1 ++
          (((payloadRegs sig.callConv).zip regs).filter fun (q : Reg × Reg) => !ps.contains q.1))),s)) = .ok (value,next) at run
  cases returns : retRegs sig.returns.length with
  | none => simp only [returns] at run; cases run
  | some ps =>
    simp only [returns] at run
    cases folded : ((payloadRegs sig.callConv).zip ctx.tryRegs.2).foldl (tryAliasStep ps ctx.tryRegs.1) (Except.ok (st,([] : List Reg))) with
    | error err => rw [folded] at run; cases run
    | ok pair =>
      obtain ⟨after,regs⟩ := pair
      rw [folded] at run
      cases run
      exact try_fold_fields ps ctx.tryRegs.1 _ st [] folded
/-- The real helper retains the entire base state, including emitted code,
fresh frontier and outgoing area, as well as source demand and sinking state. -/
theorem stock_try_rets_state_frame {ctx : Ctx} {sig : Clif.Signature} {st next : State} {value : V}
    (run : Stock.externCtor ctx T.gen_try_call_rets [.op (.sig sig)] st = .ok (value,next)) :
    next.base = st.base ∧ next.demand = st.demand ∧ next.sunk = st.sunk ∧
      next.tryRegs = st.tryRegs ∧ next.current = st.current ∧ next.color = st.color := by
  have unchanged := stock_try_rets_alias_only run
  have base := congrArg State.base unchanged
  have demand := congrArg State.demand unchanged
  have sunk := congrArg State.sunk unchanged
  have regs := congrArg State.tryRegs unchanged
  have current := congrArg State.current unchanged
  have color := congrArg State.color unchanged
  exact ⟨base,demand,sunk,regs,current,color⟩
end Backend.Stock.Proof.TryRetsFrameDraft
