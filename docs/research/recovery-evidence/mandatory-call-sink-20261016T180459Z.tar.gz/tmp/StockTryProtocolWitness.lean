import FV.Clif.Unwind
import StockTryHelperFrames
import StockTrySelectedCalls
import StockTryProtocol
import StockTryNearFixture
import FV.Backend.Proof.PerEdgeSpillEntryFixture
namespace Backend.Stock.Proof.TryProtocolWitnessDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open TryHelperFramesDraft TryProtocolDraft TrySourceContextDraft TryBranchSelectionDraft TryRuleSelectionDraft TryRhsCallsDraft TrySelectedCallsDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
attribute [local irreducible] Stock.lower Stock.runTerm Isle.Aarch64.program
inductive Kind where | near | got | indirect
  deriving DecidableEq,Repr
private def function : Kind → Clif.Function
  | .near => TryNearFixtureDraft.function false
  | .got => SpillEntryFixture.function false
  | .indirect => SpillEntryFixture.function true
private def entry (k : Kind) := (function k).blocks[0]!
private def table : Clif.ExnTable := {
  sig := 0,normal := ⟨1,[.ret 0,.val 0]⟩,items := [.tag 7 ⟨2,[.exn 0,.exn 1,.val 0]⟩] }
private structure Fixture (k : Kind) where
  result : Result
  prepared : EdgeVCode
  rf : RFunc
  af : AFunc
  lowered : Stock.lower (function k) = .ok result
  scope : LowerScope (function k)
  dominated : Dominated (function k)
  arity : ArityOk (function k)
  prepare : prepareAt result.code result.edgeArgs = .ok prepared
  fallback : rf = spillAllocAt prepared.code prepared.edges
  accepted : checkAllocAt prepared.code prepared.edges rf = .ok ()
  physical : lowerRFunc prepared.code rf = .ok af
private theorem fixture (k : Kind) : Nonempty (Fixture k) := by
  cases k with
  | near =>
    obtain ⟨out⟩ := TryNearFixtureDraft.stock_near_try_fixture
    exact ⟨⟨out.result,out.prepared,out.rf,out.af,out.lowered,out.scope,out.dominated,out.arity,
      out.prepare,out.fallback,out.accepted,out.physical⟩⟩
  | got =>
    obtain ⟨out⟩ := SpillEntryFixture.try_fixture false
    exact ⟨⟨out.result,out.prepared,out.rf,out.af,out.lowered,out.scope,out.dominated,out.arity,
      out.prepare,out.fallback,out.accepted,out.physical⟩⟩
  | indirect =>
    obtain ⟨out⟩ := SpillEntryFixture.try_fixture true
    exact ⟨⟨out.result,out.prepared,out.rf,out.af,out.lowered,out.scope,out.dominated,out.arity,
      out.prepare,out.fallback,out.accepted,out.physical⟩⟩
private theorem order (k : Kind) : blockOrder (function k) = .ok {
    nodes := #[.original 0,.original 1,.original 2],successors := #[#[2,1],#[],#[]]} := by cases k <;> cbv
private def protocol (k : Kind) (out : Fixture k)
    (source : TryBranchSource (function k) out.result 0 0 (entry k)) (selected : TryBranchSelection source) : Prop :=
  let before := {source.input with current := some source.ti,color := none,base.emitted := #[]}
  match k with
  | .near => ∃ items,selected.selected.rule = rule_lower_2542 ∧
      DirectTryCalls program source.ctx [] (function k).sig "callee" items out.result.order.successors[0]!.toList
        before selected.next #[] selected.selected.rhsTrace selected.out
  | .got => ∃ items,selected.selected.rule = rule_lower_2551 ∧
      GotTryCalls program source.ctx [] (function k).sig "callee" (.data 38 1 []) items out.result.order.successors[0]!.toList
        before selected.next #[] selected.selected.rhsTrace selected.out
  | .indirect => ∃ sig items,selected.selected.rule = rule_lower_2561 ∧
      IndirectTryCalls program source.ctx 1 [] sig items out.result.order.successors[0]!.toList
        before selected.next #[] selected.selected.rhsTrace selected.out
/-- Three COMPLETE original-condition compiler pipelines inhabit direct BL,
GOT/BLR and indirect TryCall selection and the same actual RHS helper protocols.
The selected branches carry the real prepared handler/normal/payload vectors. -/
theorem stock_complete_selected_try_protocol_witness (k : Kind) :
    ∃ (out : Fixture k) (source : TryBranchSource (function k) out.result 0 0 (entry k))
      (selected : TryBranchSelection source),
      LowerScope (function k) ∧ Dominated (function k) ∧ ArityOk (function k) ∧
      Stock.lower (function k) = .ok out.result ∧
      prepareAt out.result.code out.result.edgeArgs = .ok out.prepared ∧
      out.rf = spillAllocAt out.prepared.code out.prepared.edges ∧
      checkAllocAt out.prepared.code out.prepared.edges out.rf = .ok () ∧
      lowerRFunc out.prepared.code out.rf = .ok out.af ∧
      source.branch.step ∈ out.result.schedule.toList ∧ protocol k out source selected := by
  obtain ⟨out⟩ := fixture k
  have sameOrder := Except.ok.inj ((stock_lower_order out.lowered).symm.trans (order k))
  have node : out.result.order.nodes[0]? = some (.original 0) := by rw [sameOrder]; rfl
  have block : (function k).blocks[0]? = some (entry k) := by cases k <;> rfl
  have kind : (entry k).term.isTry = true := by cases k <;> rfl
  obtain ⟨source,⟨selected⟩⟩ := stock_lower_try_source_selection out.lowered out.scope node block kind
  refine ⟨out,source,selected,out.scope,out.dominated,out.arity,out.lowered,out.prepare,out.fallback,
    out.accepted,out.physical,source.scheduled,?_⟩
  cases k with
  | near =>
    let ext : Clif.ExtFunc := {name := "callee",sig := (function .near).sig,colocated := true}
    have external : (function .near).extern? 0 = some ext := rfl
    obtain ⟨items,_,chosen,env,matched,trace,calls⟩ := stock_selected_try_direct_rhs_calls selected
      (show (entry .near).term = .tryCall 0 [] table from rfl) external rfl
    exact ⟨items,chosen,calls⟩
  | got =>
    let ext : Clif.ExtFunc := {name := "callee",sig := (function .got).sig,colocated := false}
    have external : (function .got).extern? 0 = some ext := rfl
    obtain ⟨items,_,chosen,env,matched,trace,calls⟩ := stock_selected_try_got_rhs_calls selected
      (show (entry .got).term = .tryCall 0 [] table from rfl) external rfl
    exact ⟨items,chosen,calls⟩
  | indirect =>
    obtain ⟨sig,items,_,chosen,env,matched,trace,calls⟩ := stock_selected_try_indirect_rhs_calls selected
      (show (entry .indirect).term = .tryCallIndirect 1 [] table from rfl)
    exact ⟨sig,items,chosen,calls⟩
/-- The whole-driver variant derives the direct/GOT split internally for both
complete source cases, without a caller colocation or selected-rule certificate. -/
theorem stock_complete_direct_try_dispatch_witness (near : Bool) :
    ∃ (out : Fixture (if near then .near else .got))
      (source : TryBranchSource (function (if near then .near else .got)) out.result 0 0 (entry (if near then .near else .got)))
      (selected : TryBranchSelection source),
      Stock.lower (function (if near then .near else .got)) = .ok out.result ∧
      prepareAt out.result.code out.result.edgeArgs = .ok out.prepared ∧
      checkAllocAt out.prepared.code out.prepared.edges out.rf = .ok () ∧
      lowerRFunc out.prepared.code out.rf = .ok out.af ∧
      ActualDirectTryProtocol source selected 0 [] table := by
  let k : Kind := if near then .near else .got
  obtain ⟨out⟩ := fixture k
  have sameOrder := Except.ok.inj ((stock_lower_order out.lowered).symm.trans (order k))
  have node : out.result.order.nodes[0]? = some (.original 0) := by rw [sameOrder]; rfl
  have block : (function k).blocks[0]? = some (entry k) := by cases near <;> rfl
  have kind : (entry k).term = .tryCall 0 [] table := by cases near <;> rfl
  obtain ⟨source,selected,protocol⟩ := stock_lower_direct_try_protocol out.lowered out.scope node block kind
  exact ⟨out,source,selected,out.lowered,out.prepare,out.accepted,out.physical,protocol⟩
private def sourceMemory : Clif.Mem := {Clif.Mem.empty with symbols := fun n => if n = "callee" then some 4096 else none}
private def sourceException : Clif.Exn := {catches := fun n => n == 7,payload := [⟨.i64,42⟩,⟨.i64,99⟩]}
private def sourceEnvironment (k : Kind) (handler : Bool) : Clif.XEnv := {
  extern := fun n => if n = "callee" then some (fun _ mem =>
    if handler then .unwound sourceException mem else .returned [⟨.i64,17⟩] mem) else none
  names := ["callee"]
  sigOf := fun n => if n = "callee" then some (function k).sig else none }
private theorem completed (k : Kind) (handler : Bool) :
    Clif.runWithX (sourceEnvironment k handler) {funcs := [function k]} (function k).name [] sourceMemory 6 =
      .returned [⟨.i64,if handler then 42 else 17⟩] sourceMemory := by cases k <;> cases handler <;> rfl
/-- Every direct/GOT/indirect protocol witness also executes a complete real
normal OR exceptional source run, including payload/ordinary argument binding
and actual handler entry, alongside its full compiler/checked physical pipeline. -/
theorem stock_complete_try_protocol_source_run_witness (k : Kind) (handler : Bool) :
    ∃ (out : Fixture k) (source : TryBranchSource (function k) out.result 0 0 (entry k))
      (selected : TryBranchSelection source),
      LowerScope (function k) ∧ Dominated (function k) ∧ ArityOk (function k) ∧
      Stock.lower (function k) = .ok out.result ∧
      prepareAt out.result.code out.result.edgeArgs = .ok out.prepared ∧
      out.rf = spillAllocAt out.prepared.code out.prepared.edges ∧
      checkAllocAt out.prepared.code out.prepared.edges out.rf = .ok () ∧
      lowerRFunc out.prepared.code out.rf = .ok out.af ∧ protocol k out source selected ∧
      Clif.runWithX (sourceEnvironment k handler) {funcs := [function k]} (function k).name [] sourceMemory 6 =
        .returned [⟨.i64,if handler then 42 else 17⟩] sourceMemory := by
  obtain ⟨out,source,selected,scope,dominated,arity,lowered,prepare,fallback,checked,physical,scheduled,calls⟩ :=
    stock_complete_selected_try_protocol_witness k
  exact ⟨out,source,selected,scope,dominated,arity,lowered,prepare,fallback,checked,physical,calls,completed k handler⟩
/-- Real complete pipelines exercise the ABI/info/reserved-def frame theorems
on the SAME direct/GOT/indirect helper executions derived from actual selection. -/
theorem stock_complete_try_helper_frame_witness (k : Kind) :
    ∃ (out : Fixture k) (source : TryBranchSource (function k) out.result 0 0 (entry k))
      (selected : TryBranchSelection source) (sig : Clif.Signature) (items : List (Option Nat))
      (info : TryInfo) (before after : State) (defs : V),
      Stock.lower (function k) = .ok out.result ∧
      prepareAt out.result.code out.result.edgeArgs = .ok out.prepared ∧
      checkAllocAt out.prepared.code out.prepared.edges out.rf = .ok () ∧
      lowerRFunc out.prepared.code out.rf = .ok out.af ∧
      tryInfoOf sig items out.result.order.successors[0]!.toList = some info ∧
      Stock.externCtor source.ctx T.gen_try_call_rets [.op (.sig sig)] before = .ok (defs,after) ∧
      {after with alias := #[]} = {before with alias := #[]} ∧ after.base = before.base := by
  obtain ⟨out,source,selected,scope,dominated,arity,lowered,prepare,fallback,checked,physical,scheduled,calls⟩ :=
    stock_complete_selected_try_protocol_witness k
  cases k with
  | near =>
    obtain ⟨items,chosen,run⟩ := calls
    obtain ⟨info,before,after,defs,valid,generated,frame,base⟩ := stock_direct_try_helper_frames run
    exact ⟨out,source,selected,_,items,info,before,after,defs,lowered,prepare,checked,physical,valid,generated,frame,base⟩
  | got =>
    obtain ⟨items,chosen,run⟩ := calls
    obtain ⟨info,before,after,defs,valid,generated,frame,base⟩ := stock_got_try_helper_frames run
    exact ⟨out,source,selected,_,items,info,before,after,defs,lowered,prepare,checked,physical,valid,generated,frame,base⟩
  | indirect =>
    obtain ⟨sig,items,chosen,run⟩ := calls
    obtain ⟨info,before,after,defs,valid,generated,frame,base⟩ := stock_indirect_try_helper_frames run
    exact ⟨out,source,selected,sig,items,info,before,after,defs,lowered,prepare,checked,physical,valid,generated,frame,base⟩
end Backend.Stock.Proof.TryProtocolWitnessDraft
