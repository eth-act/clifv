import FV.Backend.Proof.PerEdgeSpillEntry
import FV.Backend.Proof.SpillCtlForms
import FV.Backend.Proof.SpillArity
import FV.Backend.Proof.StockCfgTotalWitness
import FV.Backend.Proof.PerEdgeAllocDriverSound

namespace Backend.Stock.Proof.TryNearObservationDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.PerEdgeSpill Backend.Proof.Spill
set_option maxRecDepth 20000
set_option maxHeartbeats 16000000
private def signature : Clif.Signature := {returns := [⟨.i64,.none,.normal⟩],callConv := some .systemV}
private def table : Clif.ExnTable := {
  sig := 0,normal := ⟨1,[.ret 0,.val 0]⟩,items := [.tag 7 ⟨2,[.exn 0,.exn 1,.val 0]⟩] }
private def term (indirect : Bool) : Clif.Terminator :=
  if indirect then .tryCallIndirect 1 [] table else .tryCall 0 [] table
def function (indirect : Bool) : Clif.Function := {
  name := "stock_spill_try_entry",sig := signature,sigDecls := [(0,signature)],externs := [(0,{name := "callee",sig := signature,colocated := true})]
  blocks := [{id := 0,body := [⟨[0],.iconst .i64 9⟩] ++
      (if indirect then [⟨[1],.iconst .i64 4096⟩] else []),term := term indirect},
    {id := 1,params := [(2,.i64),(3,.i64)],term := .ret [2]},
    {id := 2,params := [(4,.i64),(5,.i64),(6,.i64)],term := .ret [4]}] }
private def pipeline (indirect : Bool) : Except String (Result × EdgeVCode × RFunc × AFunc) := do
  let result ← Stock.lower (function indirect)
  let prepared ← prepareAt result.code result.edgeArgs
  let rf ← allocResultAt prepared.code prepared.edges (.error "force indexed try fallback")
  let af ← lowerRFunc prepared.code rf
  pure (result,prepared,rf,af)

set_option maxRecDepth 20000
set_option maxHeartbeats 16000000
def Observed : Prop := (pipeline false).isOk = true
theorem observed : Observed := by
  unfold Observed pipeline
  decide +kernel

end Backend.Stock.Proof.TryNearObservationDraft
