import StockTryRhsCalls
namespace Backend.Stock.Proof.TrySelectedCallsDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open TrySourceContextDraft TryBranchSelectionDraft TryRuleSelectionDraft TryRootMatchDraft TryRhsCallsDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm
private def before {f : Clif.Function} {result : Result} {label bi : Nat} {b : Clif.Block}
    (source : TryBranchSource f result label bi b) :=
  {source.input with current := some source.ti,color := none,base.emitted := #[]}
private theorem count : (program.rulesOf T.lower_branch.id).length = 8 := by
  rw [show T.lower_branch.id = 687 from rfl,data_program.r687]
  rfl
private theorem direct_before_got :
    (program.rulesOf T.lower_branch.id).idxOf rule_lower_2542 <
      (program.rulesOf T.lower_branch.id).idxOf rule_lower_2551 := by
  rw [show T.lower_branch.id = 687 from rfl,data_program.r687]
  decide +kernel
private theorem direct_no_match {p : Program} (hp : Data p) (hpT : TryData p) (ctx : Ctx)
    {ti fn : Nat} {info : IInfo} {args : List Nat} {sig : Clif.Signature} {items : List (Option Nat)}
    {ext : Clif.ExtFunc} (slot : ctx.insts[ti]? = some info)
    (data : info.data = .data 152 27 [.data 151 13 [],.values args,.op (.funcRef fn),.op (.exnTable sig items)])
    (external : ctx.func.extern? fn = some ext) (signature : ext.sig = sig) (far : ext.colocated = false)
    (labels : List Label) (st : State) (tr : Array RuleId) (n : Nat) :
    (matchRule p (Stock.sem ctx) {} (n+1000) rule_lower_2542 [.inst ti,.labels labels]).run (st,tr) = .ok (none,st,tr) := by
  have source := ext_inst_data_value ctx st.base slot
  rw [data] at source
  have extracted : Backend.externExtract ctx T.func_ref_data (.op (.funcRef fn)) st.base =
      .ok [.op (.sig sig),.op (.extName ext.name),.data 38 1 [],.bool false] := by
    apply (ext_func_ref_data_iff st.base fn _).mpr
    exact ⟨ext,external,by rw [signature,far]; rfl⟩
  have sliced : Backend.externExtract ctx T.value_list_slice (.values args) st.base = .ok [.values args] := rfl
  have sem_extract (t : Term) (v : V) (s : State) :
      (Stock.sem ctx).extract t v s = Backend.externExtract ctx t v s.base := rfl
  have sem_unData (ty : Nat) (v : V) : (Stock.sem ctx).unData ty v = (Backend.sem ctx).unData ty v := rfl
  have sem_eq (a b : V) : (Stock.sem ctx).eq a b = (a == b) := rfl
  obtain ⟨t300,t302,t2297,t2474⟩ := hpT
  cases hp
  isel_eval [*,rule_lower_2542,sem_extract,sem_unData,sem_eq]
  isel_eval [*,rule_lower_2542,sem_extract,sem_unData,sem_eq]
  all_goals rfl
/-- First-match priority derives the direct TryCall rule and all real helper
calls for a colocated source extern. This is a family case, not an input filter. -/
theorem stock_selected_try_direct_rhs_calls {f : Clif.Function} {result : Result} {label bi : Nat} {b : Clif.Block}
    {source : TryBranchSource f result label bi b} (selected : TryBranchSelection source)
    {fn : Nat} {args : List Nat} {et : Clif.ExnTable} (kind : b.term = .tryCall fn args et)
    {ext : Clif.ExtFunc} (external : f.extern? fn = some ext) (near : ext.colocated = true) :
    ∃ items,exnTableOpnd f et = .ok (ext.sig,items) ∧
      selected.selected.rule = rule_lower_2542 ∧
      selected.selected.env = directEnv args ext.sig ext.name items result.order.successors[label]!.toList ∧
      selected.selected.matched = before source ∧ selected.selected.matchTrace = #[] ∧
      DirectTryCalls program source.ctx args ext.sig ext.name items result.order.successors[label]!.toList
        (before source) selected.next #[] selected.selected.rhsTrace selected.out := by
  obtain ⟨sig,items,found,table,decl,signature,data⟩ := stock_try_source_direct_data source kind
  rw [external] at decl
  cases decl
  subst sig
  have ctxExt : source.ctx.func.extern? fn = some ext := by rw [source.mapped.func]; exact external
  have chosen : selected.selected.rule = rule_lower_2542 := by
    rcases stock_selected_try_direct_rule selected kind with direct | got
    · exact direct
    · have priority := direct_before_got
      rw [← got] at priority
      have earlier : rule_lower_2542 ∈ selected.selected.pre := by
        by_cases present : rule_lower_2542 ∈ selected.selected.pre
        · exact present
        · have unique := lower_branch_ids_nodup
          change (List.map Rule.id (program.rulesOf T.lower_branch.id)).Nodup at unique
          have order := congrArg (List.map Rule.id) selected.selected.candidates
          simp only [List.map_append,List.map_cons] at order
          rw [order] at unique
          have absent : selected.selected.rule ∉ selected.selected.pre := by
            intro contained
            have disjoint := (List.nodup_append.mp unique).2.2
            exact (disjoint selected.selected.rule.id (List.mem_map.mpr ⟨_,contained,rfl⟩)
              selected.selected.rule.id (List.mem_cons_self ..)) rfl
          rw [selected.selected.candidates,List.idxOf_append,ite_eq_right present,List.idxOf_append,
            ite_eq_right absent,List.idxOf_cons_self] at priority
          omega
      obtain ⟨fuel,bound,after,failed⟩ := selected.selected.rejected _ earlier
      change (matchRule program (Stock.sem source.ctx) {} fuel rule_lower_2542
        [.inst source.ti,.labels result.order.successors[label]!.toList]).run (before source,#[]) = .ok (none,after) at failed
      obtain ⟨n,equal⟩ : ∃ n,fuel=n+1000 := ⟨fuel-1000,by have h := count; omega⟩
      rw [equal,stock_try_direct_root_match data_program tryData_program source.ctx source.slot data ctxExt rfl near
        result.order.successors[label]!.toList (before source) #[] n] at failed
      cases failed
  have enough := selected.selected.fuelBound
  obtain ⟨n,equal⟩ : ∃ n,selected.selected.matchFuel=n+1000 :=
    ⟨selected.selected.matchFuel-1000,by have h := count; omega⟩
  have matched := selected.selected.matchedRun
  change (matchRule program (Stock.sem source.ctx) {} selected.selected.matchFuel selected.selected.rule
    [.inst source.ti,.labels result.order.successors[label]!.toList]).run (before source,#[]) =
      .ok (some selected.selected.env,selected.selected.matched,selected.selected.matchTrace) at matched
  rw [chosen,equal,stock_try_direct_root_match data_program tryData_program source.ctx source.slot data ctxExt rfl near
    result.order.successors[label]!.toList (before source) #[] n] at matched
  simp only [Except.ok.injEq,Prod.mk.injEq,Option.some.injEq] at matched
  obtain ⟨environment,state,trace⟩ := matched
  refine ⟨items,table,chosen,environment.symm,state.symm,trace.symm,?_⟩
  have rhs := selected.selected.rhsRun
  rw [chosen,← environment,← state,← trace] at rhs
  exact stock_try_direct_rhs_calls data_program tryData_program source.ctx args ext.sig ext.name items _ rhs

/-- Non-colocated actual source calls derive the GOT rule and its real target
load, call and exception helper protocol without a caller rule certificate. -/
theorem stock_selected_try_got_rhs_calls {f : Clif.Function} {result : Result} {label bi : Nat} {b : Clif.Block}
    {source : TryBranchSource f result label bi b} (selected : TryBranchSelection source)
    {fn : Nat} {args : List Nat} {et : Clif.ExnTable} (kind : b.term = .tryCall fn args et)
    {ext : Clif.ExtFunc} (external : f.extern? fn = some ext) (far : ext.colocated = false) :
    ∃ items,exnTableOpnd f et = .ok (ext.sig,items) ∧
      selected.selected.rule = rule_lower_2551 ∧
      selected.selected.env = gotEnv args ext.sig ext.name (.data 38 1 []) items result.order.successors[label]!.toList ∧
      selected.selected.matched = before source ∧ selected.selected.matchTrace = #[] ∧
      GotTryCalls program source.ctx args ext.sig ext.name (.data 38 1 []) items result.order.successors[label]!.toList
        (before source) selected.next #[] selected.selected.rhsTrace selected.out := by
  obtain ⟨sig,items,found,table,decl,signature,data⟩ := stock_try_source_direct_data source kind
  rw [external] at decl
  cases decl
  subst sig
  have ctxExt : source.ctx.func.extern? fn = some ext := by rw [source.mapped.func]; exact external
  have enough := selected.selected.fuelBound
  obtain ⟨n,equal⟩ : ∃ n,selected.selected.matchFuel=n+1000 :=
    ⟨selected.selected.matchFuel-1000,by have h := count; omega⟩
  have chosen : selected.selected.rule = rule_lower_2551 := by
    rcases stock_selected_try_direct_rule selected kind with direct | got
    · have matched := selected.selected.matchedRun
      change (matchRule program (Stock.sem source.ctx) {} selected.selected.matchFuel selected.selected.rule
        [.inst source.ti,.labels result.order.successors[label]!.toList]).run (before source,#[]) =
          .ok (some selected.selected.env,selected.selected.matched,selected.selected.matchTrace) at matched
      rw [direct,equal,direct_no_match data_program tryData_program source.ctx source.slot data ctxExt rfl far
        result.order.successors[label]!.toList (before source) #[] n] at matched
      cases matched
    · exact got
  have matched := selected.selected.matchedRun
  change (matchRule program (Stock.sem source.ctx) {} selected.selected.matchFuel selected.selected.rule
    [.inst source.ti,.labels result.order.successors[label]!.toList]).run (before source,#[]) =
      .ok (some selected.selected.env,selected.selected.matched,selected.selected.matchTrace) at matched
  rw [chosen,equal,stock_try_got_root_match data_program tryData_program source.ctx source.slot data ctxExt rfl
    result.order.successors[label]!.toList (before source) #[] n,far] at matched
  simp only [Bool.false_eq_true,ite_false,Except.ok.injEq,Prod.mk.injEq,Option.some.injEq] at matched
  obtain ⟨environment,state,trace⟩ := matched
  refine ⟨items,table,chosen,environment.symm,state.symm,trace.symm,?_⟩
  have rhs := selected.selected.rhsRun
  rw [chosen,← environment,← state,← trace] at rhs
  exact stock_try_got_rhs_calls data_program tryData_program source.ctx args ext.sig ext.name _ items _ rhs

/-- Actual indirect TryCall selection derives rule1036, its exact environment
and every real target/argument/exception/call helper at the same Stock states. -/
theorem stock_selected_try_indirect_rhs_calls {f : Clif.Function} {result : Result} {label bi : Nat} {b : Clif.Block}
    {source : TryBranchSource f result label bi b} (selected : TryBranchSelection source)
    {callee : Nat} {args : List Nat} {et : Clif.ExnTable} (kind : b.term = .tryCallIndirect callee args et) :
    ∃ sig items,exnTableOpnd f et = .ok (sig,items) ∧ selected.selected.rule = rule_lower_2561 ∧
      selected.selected.env = indirectEnv callee args sig items result.order.successors[label]!.toList ∧
      selected.selected.matched = before source ∧ selected.selected.matchTrace = #[] ∧
      IndirectTryCalls program source.ctx callee args sig items result.order.successors[label]!.toList
        (before source) selected.next #[] selected.selected.rhsTrace selected.out := by
  obtain ⟨sig,items,table,data⟩ := stock_try_source_indirect_data source kind
  have chosen := stock_selected_try_indirect_rule selected kind
  have enough := selected.selected.fuelBound
  obtain ⟨n,equal⟩ : ∃ n,selected.selected.matchFuel=n+1000 :=
    ⟨selected.selected.matchFuel-1000,by have h := count; omega⟩
  have matched := selected.selected.matchedRun
  change (matchRule program (Stock.sem source.ctx) {} selected.selected.matchFuel selected.selected.rule
    [.inst source.ti,.labels result.order.successors[label]!.toList]).run (before source,#[]) =
      .ok (some selected.selected.env,selected.selected.matched,selected.selected.matchTrace) at matched
  rw [chosen,equal,stock_try_indirect_root_match data_program tryData_program indData_program tryIndData_program
    source.ctx source.slot data result.order.successors[label]!.toList (before source) #[] n] at matched
  simp only [Except.ok.injEq,Prod.mk.injEq,Option.some.injEq] at matched
  obtain ⟨environment,state,trace⟩ := matched
  refine ⟨sig,items,table,chosen,environment.symm,state.symm,trace.symm,?_⟩
  have rhs := selected.selected.rhsRun
  rw [chosen,← environment,← state,← trace] at rhs
  exact stock_try_indirect_rhs_calls data_program tryData_program source.ctx callee args sig items _ rhs
end Backend.Stock.Proof.TrySelectedCallsDraft
