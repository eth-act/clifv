import FV.Backend.Proof.StockMinMaxNarrowSourceReads
import FV.Backend.Proof.StockMinMaxWideSourceReads
namespace Backend.Stock.Proof.ScalarSelect
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open MinMaxRegisterFixture Backend.Stock.Proof.ScalarCmp
/-- Actual retained min/max register-case execution transfers the original guarded source
relation to the real original source-step frame, not merely a constructed result
frame. Original restricted DFG and demanded/available guards are retained. -/
theorem stock_lower_minmax_actual_source_values {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    {event : BlockScanEvent} {record : ScanRecord}
    (events : event ∈ result.blockScans.toList) (records : record ∈ event.output.records)
    {bi j : Nat} {block : Clif.Block} {stmt : Clif.Stmt}
    (foundBlock : f.blocks[bi]? = some block) (foundStmt : block.body[j]? = some stmt)
    (current : record.inst = blockStart f bi + j)
    {info : IInfo} (unsigned maximum : Bool) {ty : Clif.Ty} {x y z a : Nat}
    (source : event.ctx.insts[record.inst]? = some info) (clif : info.clif = some (.binary (minmaxOperation unsigned maximum) ty x y))
    (typeX : event.ctx.valueType? x = some (.int ty.width))
    (typeY : event.ctx.valueType? y = some (.int ty.width))
    (results : info.results = [z]) (statementResults : stmt.results = [z])
    (mapped : event.ctx.valueReg? z = some (.vreg a .int))
    {step : Step} (recorded : record.output.step = some step) (emitted : step.decision = .emitted)
    {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem} (refines : Refines F isem)
    {fr : Clif.Frame} {ρ : Nat → CV} {u v : BitVec ty.width}
    (dfg : DFGCons event.ctx (restrict fr (availOf f (availIn f result.ctx) bi j)))
    (getX : (restrict fr (availOf f (availIn f result.ctx) bi j)).getAs x ty = .ok u)
    (getY : (restrict fr (availOf f (availIn f result.ctx) bi j)).getAs y ty = .ok v)
    (held : ValuesHeld (fun value => Demanded record.output.state value ∧ value ∈ availOf f (availIn f result.ctx) bi j)
      event.ctx fr (fun key => ρ (aliasNum result.final.alias key)))
    {env : Clif.Env} {cp : Clif.Program} {fr' : Clif.Frame} {cm cm' : Clif.Mem}
    (sourceStep : SourceInstResult env cp event.ctx record.inst (fr,cm) (fr',cm')) :
    ∃ d,step.results = [[.vreg d .int]] ∧ record.input.base.nextVreg ≤ d ∧ d < record.output.state.base.nextVreg ∧
      cm' = cm ∧
      ∀ world,Runs F isem (record.output.emitted.toList.map
        (·.mapRegs (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1)))) ρ world (fun ρ' _ =>
          VHolds ⟨ty,Clif.Sem.binary (minmaxOperation unsigned maximum) u v⟩ (ρ' d) ∧ (∀ k,k < record.input.base.nextVreg ∨ record.output.state.base.nextVreg ≤ k → ρ' k = ρ k) ∧
          ValuesHeld (fun value => Demanded record.input value ∧ value ∈ availOf f (availIn f result.ctx) bi (j+1))
            event.ctx fr' (fun key => ρ' (aliasNum result.final.alias key))) := by
  have inv := (stock_lower_record_context run scope events).1
  have widths := (stock_minmax_source_data inv unsigned maximum source clif).1
  cases ty with
  | i8 =>
    exact stock_lower_minmax_narrow_source_values run scope dominated events records
      foundBlock foundStmt current unsigned maximum source clif false rfl typeX typeY results statementResults mapped
      recorded emitted refines dfg getX getY held sourceStep
  | i16 =>
    exact stock_lower_minmax_narrow_source_values run scope dominated events records
      foundBlock foundStmt current unsigned maximum source clif true rfl typeX typeY results statementResults mapped
      recorded emitted refines dfg getX getY held sourceStep
  | i32 =>
    exact stock_lower_minmax_wide_source_values run scope dominated events records
      foundBlock foundStmt current unsigned maximum source clif false rfl typeX typeY results statementResults mapped
      recorded emitted refines dfg getX getY held sourceStep
  | i64 =>
    exact stock_lower_minmax_wide_source_values run scope dominated events records
      foundBlock foundStmt current unsigned maximum source clif true rfl typeX typeY results statementResults mapped
      recorded emitted refines dfg getX getY held sourceStep
  | i128 => simp [Clif.Ty.width] at widths

/-- Original source execution supplies both getters internally; the original
reads are returned explicitly while both earlier source-transfer variants remain unchanged. -/
theorem stock_lower_minmax_actual_source_with_reads {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    {event : BlockScanEvent} {record : ScanRecord}
    (events : event ∈ result.blockScans.toList) (records : record ∈ event.output.records)
    {bi j : Nat} {block : Clif.Block} {stmt : Clif.Stmt}
    (foundBlock : f.blocks[bi]? = some block) (foundStmt : block.body[j]? = some stmt)
    (current : record.inst = blockStart f bi + j)
    {info : IInfo} (unsigned maximum : Bool) {ty : Clif.Ty} {x y z a : Nat}
    (source : event.ctx.insts[record.inst]? = some info) (clif : info.clif = some (.binary (minmaxOperation unsigned maximum) ty x y))
    (typeX : event.ctx.valueType? x = some (.int ty.width))
    (typeY : event.ctx.valueType? y = some (.int ty.width))
    (results : info.results = [z]) (statementResults : stmt.results = [z])
    (mapped : event.ctx.valueReg? z = some (.vreg a .int))
    {step : Step} (recorded : record.output.step = some step) (emitted : step.decision = .emitted)
    {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem} (refines : Refines F isem)
    {fr : Clif.Frame} {ρ : Nat → CV}
    (dfg : DFGCons event.ctx (restrict fr (availOf f (availIn f result.ctx) bi j)))
    (held : ValuesHeld (fun value => Demanded record.output.state value ∧ value ∈ availOf f (availIn f result.ctx) bi j)
      event.ctx fr (fun key => ρ (aliasNum result.final.alias key)))
    {env : Clif.Env} {cp : Clif.Program} {fr' : Clif.Frame} {cm cm' : Clif.Mem}
    (sourceStep : SourceInstResult env cp event.ctx record.inst (fr,cm) (fr',cm')) :
    ∃ u : BitVec ty.width,∃ v : BitVec ty.width,
      (restrict fr (availOf f (availIn f result.ctx) bi j)).getAs x ty = .ok u ∧
      (restrict fr (availOf f (availIn f result.ctx) bi j)).getAs y ty = .ok v ∧ ∃ d,step.results = [[.vreg d .int]] ∧ record.input.base.nextVreg ≤ d ∧ d < record.output.state.base.nextVreg ∧
      cm' = cm ∧
      ∀ world,Runs F isem (record.output.emitted.toList.map
        (·.mapRegs (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1)))) ρ world (fun ρ' _ =>
          VHolds ⟨ty,Clif.Sem.binary (minmaxOperation unsigned maximum) u v⟩ (ρ' d) ∧ (∀ k,k < record.input.base.nextVreg ∨ record.output.state.base.nextVreg ≤ k → ρ' k = ρ k) ∧
          ValuesHeld (fun value => Demanded record.input value ∧ value ∈ availOf f (availIn f result.ctx) bi (j+1))
            event.ctx fr' (fun key => ρ' (aliasNum result.final.alias key))) := by
  obtain ⟨u,v,getX,getY⟩ := stock_lower_minmax_source_operands run scope dominated events
    foundBlock foundStmt current unsigned maximum source clif sourceStep
  obtain ⟨d,output,lower,upper,memory,execution⟩ := stock_lower_minmax_actual_source_values run scope dominated events records
    foundBlock foundStmt current unsigned maximum source clif typeX typeY results statementResults mapped
    recorded emitted refines dfg getX getY held sourceStep
  exact ⟨u,v,getX,getY,d,output,lower,upper,memory,execution⟩
end Backend.Stock.Proof.ScalarSelect
