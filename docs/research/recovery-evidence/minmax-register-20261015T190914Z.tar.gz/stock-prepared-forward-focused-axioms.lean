import FV.Backend.RegallocPerEdgePrepareCheck
import FV.Backend.Proof.PerEdgePrepareSound
import FV.Backend.Proof.PerEdgeRegallocFwd
import FV.Backend.Proof.PerEdgePreparedDriverSound
import FV.Backend.Proof.PerEdgePrepareFacts
import FV.Backend.Proof.StockPreparedForwardWitness
import FV.Backend.Proof.PerEdgePrepSplitWitness

#print axioms Backend.Proof.PerEdgePrep.edgeBlockOkAt_sound
#print axioms Backend.Proof.PerEdgePrep.keptOkAt_sound
#print axioms Backend.Proof.PerEdgePrep.prep_step
#print axioms Backend.Proof.PerEdgePrep.prep_star
#print axioms Backend.Proof.PerEdgePrep.prep_entry_step
#print axioms Backend.Proof.PerEdgePrep.prep_ret
#print axioms Backend.Proof.PerEdgePrep.prep_halt
#print axioms Backend.Proof.PerEdgePrep.prep_sound
#print axioms Backend.Proof.PerEdge.VNextAt_det
#print axioms Backend.Proof.PerEdge.VStepAt_det
#print axioms Backend.Proof.PerEdge.forward_aux
#print axioms Backend.Proof.PerEdge.forward
#print axioms Backend.Proof.PerEdge.forward_op
#print axioms Backend.Proof.PerEdge.prepareCheckedAt_ok
#print axioms Backend.Proof.PerEdge.prepared_return_forward
#print axioms Backend.Proof.PerEdge.prepared_halt_forward
#print axioms Backend.Proof.PerEdgePrep.prepareAt_fields
#print axioms Backend.Stock.Proof.PreparedForwardWitness.stock_prepared_return_forward_witness
#print axioms Backend.Stock.Proof.PreparedForwardWitness.stock_prepared_halt_forward_witness
#print axioms Backend.Proof.PerEdgePrepSplitWitness.per_edge_prepare_actual_split_step_witness
