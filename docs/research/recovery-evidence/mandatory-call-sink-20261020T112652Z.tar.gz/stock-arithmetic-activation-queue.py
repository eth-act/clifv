from pathlib import Path
import os,json,time,datetime,subprocess as sp
root=Path('/tmp/stock-arithmetic-activation-queue');root.mkdir(exist_ok=True)
controller=2876591;gatefile=Path('/tmp/stock-arithmetic-activation-author-gates/progress.json')
def report(state,**kw):
 d=dict(state=state,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=os.getpid(),waiting_for_controller_pid=controller,**kw);(root/'progress.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)
report('waiting_for_existing_frozen_author_controller')
while Path('/proc/'+str(controller)).exists():
 try:
  cmd=Path('/proc/'+str(controller)+'/cmdline').read_bytes()
 except FileNotFoundError:break
 if cmd and b'stock-arithmetic-activation-author-gates.py' not in cmd:
  report('stopped_pid_identity_changed');raise SystemExit(1)
 time.sleep(5)
d=json.loads(gatefile.read_text())
if d['state']!='per_pr_gates_passed':
 report('stopped_author_gates_not_passed',gate_state=d.get('state'),gate_error=d.get('error'));raise SystemExit(1)
report('running_guarded_post_gate_reconciliation')
log=root/'reconcile.log'
with log.open('w') as f:r=sp.run(['python3','/tmp/stock-arithmetic-activation-reconcile.py'],cwd='/home/lee/clifv/.worktrees/stock-driver-incremental',stdout=f,stderr=sp.STDOUT)
report('reconciliation_passed' if r.returncode==0 else 'stopped_reconciliation_failed',rc=r.returncode,log=str(log),next='Inspect exact terminal receipts, open substantive PR and author squash after all gates; no user approval required. Continue all original #140 obligations.')
raise SystemExit(r.returncode)
