from pathlib import Path
import subprocess as sp, os, json, hashlib, datetime, traceback
view=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');gates=Path('/tmp/stock-arithmetic-activation-author-gates');root=Path('/tmp/stock-arithmetic-activation-reconciliation');root.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(*a):return sp.check_output(['git',*a],cwd=view,text=True).strip()
def inputs():return {str(p.relative_to(view)):sha(p) for d in ['FV','FVTest','examples/fv-demo/src','scripts/audit'] for p in (view/d).rglob('*') if p.is_file() and p.suffix in ['.lean','.rs']}
d=json.loads((gates/'progress.json').read_text());assert d['state']=='per_pr_gates_passed', 'existing author gates must finish successfully first'
frozen=json.loads((gates/'inputs.json').read_text());old=frozen['head'];assert git('rev-parse','HEAD')==old
assert inputs()==frozen['sources'];assert not git('diff','--name-only') and not git('diff','--cached','--name-only')
for item in d['logs'].values():assert sha(item['path'])==item['sha256']
assert json.loads((gates/'axiom-set-parity.json').read_text())['all_previous_axiom_sets_preserved']
assert all(p['all_original_and_prior_identities_and_ordered_stages_preserved'] for p in json.loads((gates/'identity-stage-parity.json').read_text()).values())
git('fetch','origin','main');base=git('rev-parse','origin/main')
assert git('diff','--name-only','9f76d9f6',base).splitlines()==['rust/crates/cargo-fv/src/pipeline.rs'], 'new upstream scope requires review'
assert not Path('/proc/2876591').exists(), 'do not mutate a still-live frozen author controller'
branch='agent/stock-arithmetic-production-landing'
assert not sp.run(['git','show-ref','--verify','--quiet','refs/heads/'+branch],cwd=view).returncode==0,'landing branch already exists; resume it instead'
git('switch','-c',branch);git('rebase',base);head=git('rev-parse','HEAD')
assert git('diff','--name-only',old,head).splitlines()==['rust/crates/cargo-fv/src/pipeline.rs'];assert inputs()==frozen['sources']
git('push','-u','origin','HEAD')
status_path=root/'status44.md'
status_path.write_text(sp.check_output(['gh','issue','view','44','--json','body','--jq','.body'],cwd=view,text=True)+'\n\nReconciliation '+datetime.datetime.now(datetime.timezone.utc).isoformat()+': complete frozen activation gates passed on '+old+'. Published rebased '+branch+'/'+head+' on current main '+base+'. All Lean/test/source inputs and prior gate output hashes match exactly. Rebuilding atomic-write cargo tools and rerunning verified default fv-demo/survey before author squash. Full #140 stays active; no new activation merged yet.\n')
sp.run(['gh','issue','edit','44','--body-file',str(status_path)],cwd=view,check=True)
resume_path=Path('/tmp/stock-current-resume.json')
resume=json.loads(resume_path.read_text());resume.update(head=head,branch=branch,base_main=base,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),gate_phase='post-gate-reconciliation',evidence=str(root/'progress.json'));resume_path.write_text(json.dumps(resume,indent=2)+'\n')
env=dict(os.environ);env.update(PATH='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:/home/lee/.cargo/bin:/home/lee/.local/share/clifv-test-tools/usr/bin:/home/lee/.rustup/toolchains/nightly-2026-09-26-x86_64-unknown-linux-gnu/lib/rustlib/x86_64-unknown-linux-gnu/bin:'+str(view/'rust/target/release')+':'+env['PATH'],FV_ROOT=str(view),FV_AR='/home/lee/.local/share/clifv-test-tools/usr/bin/llvm-ar',FV_OBJCOPY='/home/lee/.local/share/clifv-test-tools/usr/bin/llvm-objcopy',FV_LAKE_CACHE='/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache',FV_MEMCAP='8G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',CARGO_BUILD_JOBS='2',CLIF_NATIVE_QEMU='/home/lee/.local/share/clifv-test-tools/usr/bin/qemu-aarch64-static')
logs={}
def report(state,**kw):
 result=dict(state=state,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=os.getpid(),head=head,previous_validated_head=old,base=base,branch=branch,logs=logs,**kw);(root/'progress.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='logs'}),flush=True)
def run(name,args):
 assert git('rev-parse','HEAD')==head and inputs()==frozen['sources'];p=root/(name+'.log');report('running',phase=name)
 with p.open('w') as f:r=sp.run([str(view/'scripts/memcap.sh'),*args],cwd=view,env=env,stdout=f,stderr=sp.STDOUT)
 assert r.returncode==0,(name,r.returncode,str(p));logs[name]={'path':str(p),'sha256':sha(p)}
try:
 run('atomic-write-cargo-tools',['rustup','run','nightly-2026-09-26','cargo','build','--locked','--release','--manifest-path','rust/Cargo.toml','-p','cargo-fv'])
 for example in ['fv-demo','survey']:run('verified-'+example,['bash','examples/compare.sh','examples/'+example,'--lean-link','--verified','--keep-temps'])
 assert git('rev-parse','HEAD')==head and inputs()==frozen['sources']
 report('reconciled_per_pr_gates_passed',reuse='All prior validated Lean/test/source inputs and gate output hashes preserved exactly; only upstream atomic metadata write changed. Cargo tools rebuilt and both default verified examples rerun.',next='Write terminal receipt and final current feature documentation; open substantive non-draft PR and author squash promptly, verify exact merge tree, notify integrator, archive terminal evidence and continue all original #140 obligations.')
except BaseException as e:report('failed',error=repr(e),traceback=traceback.format_exc());raise
