from pathlib import Path
import subprocess as sp,os,json,hashlib,datetime
view=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');root=Path('/tmp/stock-production-linked-proper-check');root.mkdir(exist_ok=True)
env=dict(os.environ,FV_MEMCAP='8G',FV_LAKE_CACHE='/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2');env['PATH']='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:'+env['PATH']
lp=sp.check_output([str(view/'scripts/memcap.sh'),'lake','env','printenv','LEAN_PATH'],cwd=view,env=env,text=True).strip();env['LEAN_PATH']=lp
records={}
def report(state,**kw):
 d={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':state,'pid':os.getpid(),'head':sp.check_output(['git','rev-parse','HEAD'],cwd=view,text=True).strip(),'records':records,**kw};(root/'progress.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items() if k!='records'}),flush=True)
def run(name,args):
 log=root/(name+'.log');report('running',phase=name,log=str(log))
 with log.open('w') as f:r=sp.run([str(view/'scripts/memcap.sh'),*args],cwd=view,env=env,stdout=f,stderr=sp.STDOUT)
 records[name]={'rc':r.returncode,'log':str(log),'sha256':hashlib.sha256(log.read_bytes()).hexdigest()};assert r.returncode==0,(name,r.returncode,str(log))
try:
 run('current-module-keys',['lake','build','--no-build','FVTest.Backend.Lowering.StockProductionLinked'])
 run('actual-linked-fixture',['lake','env','lean','--run','FVTest/Backend/Lowering/StockProductionLinked.lean','/tmp/stock-production-linked-proper'])
 generated=Path('/tmp/stock-production-linked-proper');env['LEAN_PATH']=str(generated)+':'+env['LEAN_PATH']
 for p in sorted((generated/'Crates').rglob('*.lean'),key=lambda p: (len(p.parts),0 if p.name=='Input.lean' else 1,str(p))):
  if p.parent==generated/'Crates':continue
  run('generated-'+p.relative_to(generated).as_posix().replace('/','-'),['lean','--root='+str(generated),'-o',str(p.with_suffix('.olean')),str(p)])
 for p in sorted((generated/'Crates').glob('*.lean')):
  run('generated-'+p.stem,['lean','--root='+str(generated),'-o',str(p.with_suffix('.olean')),str(p)])
 report('actual_linked_fixture_and_generated_proofs_passed',remaining='This is an integration witness. Universal prologue/default activation and all original#140 obligations remain.')
except BaseException as e:report('failed',error=repr(e));raise
