import StockD0ProofDraft

namespace Backend.Stock.IncrementalD0Draft
set_option maxRecDepth 100000
set_option maxHeartbeats 8000000
set_option Elab.async false

private theorem legacy_succeeds (name : String) (c : Configuration) (runs : List Clif.RunCommand) :
    (lowerFunction (source name c runs)).isOk = true := by
  cases c <;> d0_open_kernel_decide

/-- The selected class is inhabited for arbitrary names and run metadata. -/
theorem source_eligible (name : String) (c : Configuration) (runs : List Clif.RunCommand) :
    eligible (source name c runs) = true := by
  have member : c ∈ configurations := by cases c <;> simp [configurations]
  apply List.any_eq_true.mpr
  refine ⟨c, member, ?_⟩
  exact decide_eq_true rfl

/-- The Stock branch actually succeeds; equality cannot be vacuously explained by
both drivers rejecting the class. -/
theorem stock_succeeds (name : String) (c : Configuration) (runs : List Clif.RunCommand) :
    ∃ r, Stock.lower (source name c runs) = .ok r ∧
      lower (source name c runs) = .ok (compact name r) := by
  have hn := normalized_eq_legacy name c runs
  cases hs : Stock.lower (source name c runs) with
  | error e =>
    have hi := legacy_succeeds name c runs
    rw [← hn, hs] at hi
    cases hi
  | ok r =>
    refine ⟨r, hs, ?_⟩
    simp only [lower, source_eligible, ↓reduceIte, hs]

#print axioms source_eligible
#print axioms stock_succeeds
end Backend.Stock.IncrementalD0Draft
