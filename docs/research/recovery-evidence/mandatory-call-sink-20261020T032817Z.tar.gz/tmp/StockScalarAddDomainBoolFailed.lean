import FV.Backend.Lowering.StockScalarAdd
import FV.Backend.Proof.LowerDecide
set_option autoImplicit false
namespace Backend.Stock.ScalarAdd
open D0 Backend.Proof.Driver
set_option maxRecDepth 100000
set_option maxHeartbeats 8000000
set_option Elab.async false

theorem input_defaultI32 (name : String) (runs : List Clif.RunCommand) :
    dominatedB (source name .defaultI32 runs) = true ∧ lowerScopeB (source name .defaultI32 runs) = true := by
  change dominatedB (source "" .defaultI32 []) = true ∧ lowerScopeB (source "" .defaultI32 []) = true
  decide +kernel

theorem input_systemVI32 (name : String) (runs : List Clif.RunCommand) :
    dominatedB (source name .systemVI32 runs) = true ∧ lowerScopeB (source name .systemVI32 runs) = true := by
  change dominatedB (source "" .systemVI32 []) = true ∧ lowerScopeB (source "" .systemVI32 []) = true
  decide +kernel

theorem input_fastI32 (name : String) (runs : List Clif.RunCommand) :
    dominatedB (source name .fastI32 runs) = true ∧ lowerScopeB (source name .fastI32 runs) = true := by
  change dominatedB (source "" .fastI32 []) = true ∧ lowerScopeB (source "" .fastI32 []) = true
  decide +kernel

theorem input_defaultI64 (name : String) (runs : List Clif.RunCommand) :
    dominatedB (source name .defaultI64 runs) = true ∧ lowerScopeB (source name .defaultI64 runs) = true := by
  change dominatedB (source "" .defaultI64 []) = true ∧ lowerScopeB (source "" .defaultI64 []) = true
  decide +kernel

theorem input_systemVI64 (name : String) (runs : List Clif.RunCommand) :
    dominatedB (source name .systemVI64 runs) = true ∧ lowerScopeB (source name .systemVI64 runs) = true := by
  change dominatedB (source "" .systemVI64 []) = true ∧ lowerScopeB (source "" .systemVI64 []) = true
  decide +kernel

theorem input_fastI64 (name : String) (runs : List Clif.RunCommand) :
    dominatedB (source name .fastI64 runs) = true ∧ lowerScopeB (source name .fastI64 runs) = true := by
  change dominatedB (source "" .fastI64 []) = true ∧ lowerScopeB (source "" .fastI64 []) = true
  decide +kernel

theorem lowering_domain (name : String) (runs : List Clif.RunCommand) (c : Configuration) :
    Dominated (source name c runs) ∧ LowerScope (source name c runs) := by
  have input : dominatedB (source name c runs) = true ∧ lowerScopeB (source name c runs) = true := by
    cases c with
    | defaultI32 => exact input_defaultI32 name runs
    | systemVI32 => exact input_systemVI32 name runs
    | fastI32 => exact input_fastI32 name runs
    | defaultI64 => exact input_defaultI64 name runs
    | systemVI64 => exact input_systemVI64 name runs
    | fastI64 => exact input_fastI64 name runs
  exact ⟨dominated_of input.1, lowerScope_of input.2⟩

end Backend.Stock.ScalarAdd
