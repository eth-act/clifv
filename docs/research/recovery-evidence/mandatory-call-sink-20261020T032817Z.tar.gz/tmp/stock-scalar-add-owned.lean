import FV.Backend.Lowering.StockScalarAdd
import FV.Backend.Lowering.StockScalarProduction
import FV.Backend.Proof.StockAddSubScanRefines
import FV.Backend.Proof.StockScalarAddChecked
import FV.Backend.Proof.StockScalarAddClass
import FV.Backend.Proof.StockScalarAddCode
import FV.Backend.Proof.StockScalarAddDomain
import FV.Backend.Proof.StockScalarAddSource
import FV.Backend.Proof.StockScalarAddWitness
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let targets : Array String := #["FV.Backend.Lowering.StockScalarAdd", "FV.Backend.Lowering.StockScalarProduction", "FV.Backend.Proof.StockAddSubScanRefines", "FV.Backend.Proof.StockScalarAddChecked", "FV.Backend.Proof.StockScalarAddClass", "FV.Backend.Proof.StockScalarAddCode", "FV.Backend.Proof.StockScalarAddDomain", "FV.Backend.Proof.StockScalarAddSource", "FV.Backend.Proof.StockScalarAddWitness"]
  let mut count : Nat := 0
  for (name, _) in env.constants.toList do
    let some i := env.getModuleIdxFor? name | continue
    unless targets.contains env.header.moduleNames[i]!.toString do continue
    let axioms ← collectAxioms name
    for ax in axioms do
      unless #[``propext, ``Classical.choice, ``Quot.sound].contains ax do
        throwError "disallowed axiom {ax} in {name}"
    count := count + 1
  unless count > 0 do throwError "empty consumer constant audit"
  logInfo m!"CONSUMER_CONSTANTS_STANDARD_ONLY {count}"
