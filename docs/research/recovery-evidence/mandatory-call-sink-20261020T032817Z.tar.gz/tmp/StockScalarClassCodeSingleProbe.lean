import FV.Backend.Proof.StockPrologueAllCode
import FV.Backend.Proof.DriverCheck

namespace Backend.Stock.ScalarClassCodeSingleProbe
open D0
inductive Form where
  | add | sub | mul | andBits | orBits | xorBits | notBits | neg | swap | reverse | leading | trailing | count
  deriving Repr, Inhabited

def forms : List Form := [.add,.sub,.mul,.andBits,.orBits,.xorBits,.notBits,.neg,.swap,.reverse,.leading,.trailing,.count]
def binary : Form → Bool
  | .add | .sub | .mul | .andBits | .orBits | .xorBits => true
  | _ => false

def instruction (op : Form) (ty : Clif.Ty) : Clif.Inst := match op with
  | .add => .binary .iadd ty 0 1
  | .sub => .binary .isub ty 0 1
  | .mul => .binary .imul ty 0 1
  | .andBits => .binary .band ty 0 1
  | .orBits => .binary .bor ty 0 1
  | .xorBits => .binary .bxor ty 0 1
  | .notBits => .unary .bnot ty 0
  | .neg => .unary .ineg ty 0
  | .swap => .unary .bswap ty 0
  | .reverse => .unary .bitrev ty 0
  | .leading => .unary .clz ty 0
  | .trailing => .unary .ctz ty 0
  | .count => .unary .popcnt ty 0

def source (name : String) (c : Configuration) (op : Form) (runs : List Clif.RunCommand := []) : Clif.Function :=
  let ty := valueType c
  let parameters := if binary op then [(0,ty),(1,ty)] else [(0,ty)]
  let result := if binary op then 2 else 1
  let signature : Clif.Signature := {
    params := parameters.map (fun p => ⟨p.2,.none,.normal⟩)
    returns := [⟨ty,.none,.normal⟩]
    callConv := convention c }
  let block : Clif.Block := {
    id := 0
    params := parameters
    body := [⟨[result],instruction op ty⟩]
    term := .ret [result] }
  { D0.source name c runs with sig := signature, blocks := [block] }

deriving instance DecidableEq for VBlock
deriving instance DecidableEq for VCode

set_option maxRecDepth 100000
set_option maxHeartbeats 50000000
set_option Elab.async false

macro "scalar_class_kernel_decide" : tactic => `(tactic|
  run_tac do
    let goal ← Lean.Elab.Tactic.getMainGoal
    let proof ← Lean.Meta.mkDecideProof (← goal.getType)
    goal.assign proof)

/-- Whole actual Stock code for arbitrary names and metadata, across all
thirteen scalar forms and six ABI/type configurations. Argument values remain
unrestricted: they are runtime parameters, absent from this code-shape proof. -/
theorem code_and_success (name : String) (runs : List Clif.RunCommand) :
    (Stock.lower (source name .systemVI64 .add runs)).isOk = true ∧
    (Stock.lower (source name .systemVI64 .add runs)).map
      (fun r => Prologue.AllConfigurations.eraseDiagnostics (compact name r)) =
      (lowerFunction (source name .systemVI64 .add runs)).map Prologue.AllConfigurations.eraseDiagnostics ∧
    ((Stock.lower (source name .systemVI64 .add runs)).toOption.map
      (fun r => r.edgeArgs.all (fun row => row.all (·.isEmpty)))).getD false = true := by
  scalar_class_kernel_decide

#print axioms code_and_success
end Backend.Stock.ScalarClassCodeSingleProbe
