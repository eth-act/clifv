from pathlib import Path
import os,subprocess as sp,json,datetime,hashlib,re,traceback
view=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');root=Path('/tmp/stock-all-reconcile-gates');root.mkdir(exist_ok=True);records={}
head=sp.check_output(['git','rev-parse','HEAD'],cwd=view,text=True).strip();old=json.loads(Path('/tmp/stock-production-all-author-gates/inputs.json').read_text())
def inputs():return {str(p.relative_to(view)):hashlib.sha256(p.read_bytes()).hexdigest() for d in ['FV','FVTest','examples/fv-demo/src','scripts/audit'] for p in (view/d).rglob('*') if p.is_file() and p.suffix in ['.lean','.rs']}
assert inputs()==old['sources'],'Lean/Rust/audit source differs from validated packet'
env=dict(os.environ);env.update(PATH='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:/home/lee/.cargo/bin:/home/lee/.local/share/clifv-test-tools/usr/bin:/home/lee/.rustup/toolchains/nightly-2026-09-26-x86_64-unknown-linux-gnu/lib/rustlib/x86_64-unknown-linux-gnu/bin:'+str(view/'rust/target/release')+':'+env['PATH'],FV_ROOT=str(view),FV_AR='/home/lee/.local/share/clifv-test-tools/usr/bin/llvm-ar',FV_OBJCOPY='/home/lee/.local/share/clifv-test-tools/usr/bin/llvm-objcopy',FV_LAKE_CACHE='/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache',FV_MEMCAP='8G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',CARGO_BUILD_JOBS='2',CLIF_NATIVE_QEMU='/home/lee/.local/share/clifv-test-tools/usr/bin/qemu-aarch64-static',LLVM_MC='/home/lee/.local/share/clifv-test-tools/usr/bin/llvm-mc',PYTHONPATH=str(view/'scripts'))
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:8])
def report(state,**kw):
 d={'state':state,'pid':os.getpid(),'head':head,'validated_code_head':old['head'],'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'records':records,**kw};(root/'progress.json').write_text(json.dumps(d,indent=2));print(json.dumps({k:v for k,v in d.items() if k!='records'}),flush=True)
def frozen():assert inputs()==old['sources'] and sp.check_output(['git','rev-parse','HEAD'],cwd=view,text=True).strip()==head

def run(n,args,allow=(0,)):
 frozen();report('running',phase=n);p=root/(n+'.log')
 with p.open('w') as f:r=sp.run([str(view/'scripts/memcap.sh'),*args],cwd=view,env=env,stdout=f,stderr=sp.STDOUT)
 records[n]={'rc':r.returncode,'log':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()};assert r.returncode in allow,(n,r.returncode,str(p));frozen();return p

def ids(p):
 fs=json.loads(p.read_text())['functions'];d={(f['file'],f['index'],f['function']):tuple(f['stages']) for f in fs};assert len(d)==len(fs);return d
try:
 run('source-matching-build',['lake','build','FV','FVTest','lean-backend','lean-e2e-check','link-check','lean-link','clif-filetest'])
 run('encoder',['bash','scripts/lean-backend-encode-check.sh'])
 run('moved-fixture-backend-runtime',['bash','scripts/lean-backend-filetests.sh','corpus/clif-regress/i128-call-indirect.clif'])
 parity={}
 for label,flags,previous in [('e2e',[],'legacy-dead-cleanup-final-e2e-identities.json'),('legacy-e2e',['--no-dead-cleanup'],'legacy-dead-cleanup-final-legacy-e2e-identities.json')]:
  actual=root/(label+'-identities.json');run(label,['lake','exe','lean-e2e-check',*flags,'--identity-report',str(actual)])
  a=ids(Path('/tmp')/previous);b=ids(actual);assert len(a)==1150 and a.keys()<=b.keys();assert all(a[k]==b[k] for k in a)
  parity[label]={'original':len(a),'current':len(b),'all_original_identities_and_ordered_stages_preserved':True}
 p=run('clif-filetests-baseline',['bash','scripts/clif-filetests.sh'],allow=(0,1));s=p.read_text();lines=[l for l in s.splitlines() if l.startswith('TOTAL files')];assert lines, str(p)
 m=re.search(r'pass (\d+) fail (\d+).*? disagree (\d+)',lines[-1]);assert m,lines[-1];actual=tuple(map(int,m.groups()));baseline=(11714,8,13);assert actual[0]>=baseline[0] and actual[1]<=baseline[1] and actual[2]<=baseline[2],actual
 report('reconciled_author_gates_passed',identity_stage_parity=parity,clif_baseline={'pass_fail_disagree':actual,'required':baseline,'raw_script_rc':records['clif-filetests-baseline']['rc']},source_hashes_equal_to_full_validated_head=True)
except BaseException as e:report('failed',error=repr(e),traceback=traceback.format_exc());raise
