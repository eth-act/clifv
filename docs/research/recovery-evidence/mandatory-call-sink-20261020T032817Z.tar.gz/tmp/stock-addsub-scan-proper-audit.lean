import Lean
import FV.Backend.Proof.StockAddSubScanRefines
#print axioms Backend.Stock.Proof.stock_lower_addsub_scan_fall_refines
#print axioms Backend.Stock.Proof.stock_lower_select_addsub_omitted_body_fall_refines
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let targets : Array String := #["FV.Backend.Proof.StockAddSubScanRefines"]
  let mut count : Nat := 0
  for (name, _) in env.constants.toList do
    let some i := env.getModuleIdxFor? name | continue
    unless targets.contains env.header.moduleNames[i]!.toString do continue
    let axioms ← collectAxioms name
    for ax in axioms do
      unless #[``propext, ``Classical.choice, ``Quot.sound].contains ax do
        throwError "disallowed axiom {ax} in {name}"
    count := count + 1
  unless count > 0 do throwError "empty consumer constant audit"
  logInfo m!"CONSUMER_CONSTANTS_STANDARD_ONLY {count}"
