import FV.Backend.Proof.StockPrologueAllCode
import FV.Backend.Proof.DriverCheck

namespace Backend.Stock.ScalarClassProbe
open D0
inductive Form where
  | add | sub | mul | andBits | orBits | xorBits | notBits | neg | swap | reverse | leading | trailing | count
  deriving Repr, Inhabited

def forms : List Form := [.add,.sub,.mul,.andBits,.orBits,.xorBits,.notBits,.neg,.swap,.reverse,.leading,.trailing,.count]
def binary : Form → Bool
  | .add | .sub | .mul | .andBits | .orBits | .xorBits => true
  | _ => false

def instruction (op : Form) (ty : Clif.Ty) : Clif.Inst := match op with
  | .add => .binary .iadd ty 0 1
  | .sub => .binary .isub ty 0 1
  | .mul => .binary .imul ty 0 1
  | .andBits => .binary .band ty 0 1
  | .orBits => .binary .bor ty 0 1
  | .xorBits => .binary .bxor ty 0 1
  | .notBits => .unary .bnot ty 0
  | .neg => .unary .ineg ty 0
  | .swap => .unary .bswap ty 0
  | .reverse => .unary .bitrev ty 0
  | .leading => .unary .clz ty 0
  | .trailing => .unary .ctz ty 0
  | .count => .unary .popcnt ty 0

def source (name : String) (c : Configuration) (op : Form) (runs : List Clif.RunCommand := []) : Clif.Function :=
  let ty := valueType c
  let parameters := if binary op then [(0,ty),(1,ty)] else [(0,ty)]
  let result := if binary op then 2 else 1
  let signature : Clif.Signature := {
    params := parameters.map (fun p => ⟨p.2,.none,.normal⟩)
    returns := [⟨ty,.none,.normal⟩]
    callConv := convention c }
  let block : Clif.Block := {
    id := 0
    params := parameters
    body := [⟨[result],instruction op ty⟩]
    term := .ret [result] }
  { D0.source name c runs with sig := signature, blocks := [block] }

deriving instance DecidableEq for VBlock
deriving instance DecidableEq for VCode

def compactUsed (name : String) (vc : VCode) : VCode :=
  let ids := ((vc.blocks.toList.flatMap fun b =>
    b.params.toList ++ b.branchArgs.toList ++ b.insts.toList.flatMap (fun i => i.uses ++ i.defs)).filterMap
      (fun r => match r with | .vreg n _ => some n | _ => none)).eraseDups.mergeSort (fun a b => decide (a ≤ b))
  let rename := fun r => match r with
    | .vreg n cls => Reg.vreg (ids.idxOf n) cls
    | r => r
  let block := fun (b : VBlock) => { b with
    params := b.params.map rename
    branchArgs := b.branchArgs.map rename
    insts := b.insts.map (·.mapRegs rename) }
  { vc with
    name := name
    classes := (ids.map (fun i => vc.classes[i]!)).toArray
    blocks := vc.blocks.map block }

-- Native observations only. A true observation is not a universal proof.
#eval do
  for c in configurations do
    for op in forms do
      let f := source "scalar_candidate" c op
      let observed : Except String (Bool × Bool × Bool × Bool × Bool) := do
        let actual ← Stock.lower f
        let old ← lowerFunction f
        let vc := compact f.name actual
        let ranked := compactUsed f.name actual.code
        pure (decide (Prologue.AllConfigurations.eraseDiagnostics vc =
          Prologue.AllConfigurations.eraseDiagnostics old),
          decide (Prologue.AllConfigurations.eraseDiagnostics ranked =
            Prologue.AllConfigurations.eraseDiagnostics old),
          Backend.Proof.Driver.lowerCheck f vc,
          Backend.Proof.Driver.lowerCheck f ranked,
          actual.edgeArgs.all (fun row => row.all (·.isEmpty)))
      IO.println s!"{repr c} {repr op}: {repr observed}"
end Backend.Stock.ScalarClassProbe
