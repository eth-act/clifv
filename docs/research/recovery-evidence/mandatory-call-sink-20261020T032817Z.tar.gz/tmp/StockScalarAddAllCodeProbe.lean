import StockScalarClassCodeSingleProbe
namespace Backend.Stock.ScalarAddAllCodeProbe
set_option maxRecDepth 100000
set_option maxHeartbeats 50000000
set_option Elab.async false

abbrev CheckedCode (name : String) (runs : List Clif.RunCommand) (c : D0.Configuration) : Prop :=
    (Stock.lower (ScalarClassCodeSingleProbe.source name c .add runs)).isOk = true ∧
    (Stock.lower (ScalarClassCodeSingleProbe.source name c .add runs)).map
      (fun r => Prologue.AllConfigurations.eraseDiagnostics (D0.compact name r)) =
      (lowerFunction (ScalarClassCodeSingleProbe.source name c .add runs)).map Prologue.AllConfigurations.eraseDiagnostics ∧
    ((Stock.lower (ScalarClassCodeSingleProbe.source name c .add runs)).toOption.map
      (fun r => r.edgeArgs.all (fun row => row.all (·.isEmpty)))).getD false = true

theorem code_defaultI32 (name : String) (runs : List Clif.RunCommand) :
    CheckedCode name runs .defaultI32 := by
  unfold CheckedCode
  scalar_class_kernel_decide
#print axioms code_defaultI32

theorem code_systemVI32 (name : String) (runs : List Clif.RunCommand) :
    CheckedCode name runs .systemVI32 := by
  unfold CheckedCode
  scalar_class_kernel_decide
#print axioms code_systemVI32

theorem code_fastI32 (name : String) (runs : List Clif.RunCommand) :
    CheckedCode name runs .fastI32 := by
  unfold CheckedCode
  scalar_class_kernel_decide
#print axioms code_fastI32

theorem code_defaultI64 (name : String) (runs : List Clif.RunCommand) :
    CheckedCode name runs .defaultI64 := by
  unfold CheckedCode
  scalar_class_kernel_decide
#print axioms code_defaultI64

theorem code_systemVI64 (name : String) (runs : List Clif.RunCommand) :
    CheckedCode name runs .systemVI64 := by
  exact ScalarClassCodeSingleProbe.code_and_success name runs
#print axioms code_systemVI64

theorem code_fastI64 (name : String) (runs : List Clif.RunCommand) :
    CheckedCode name runs .fastI64 := by
  unfold CheckedCode
  scalar_class_kernel_decide
#print axioms code_fastI64

theorem all_configurations (name : String) (runs : List Clif.RunCommand) (c : D0.Configuration) :
    CheckedCode name runs c := by
  cases c with
  | defaultI32 => exact code_defaultI32 name runs
  | systemVI32 => exact code_systemVI32 name runs
  | fastI32 => exact code_fastI32 name runs
  | defaultI64 => exact code_defaultI64 name runs
  | systemVI64 => exact code_systemVI64 name runs
  | fastI64 => exact code_fastI64 name runs

#print axioms all_configurations
end Backend.Stock.ScalarAddAllCodeProbe
