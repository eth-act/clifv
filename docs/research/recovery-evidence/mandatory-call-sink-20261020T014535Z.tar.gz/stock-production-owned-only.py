from pathlib import Path
import subprocess as sp,os,json
view=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');root=Path('/tmp/stock-production-owned-current');root.mkdir(exist_ok=True)
env=dict(os.environ,FV_MEMCAP='8G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2');env['PATH']='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:'+env['PATH']
commands=[['lake','env','lean','--root=/tmp',p] for p in json.load(open('/tmp/stock-production-owned-partitions.json'))]
records=[]
for i,cmd in enumerate(commands):
 (root/'state.json').write_text(json.dumps({'state':'running','phase':i,'pid':os.getpid()}))
 with (root/(str(i)+'.log')).open('w') as f:r=sp.run(['scripts/memcap.sh',*cmd],cwd=view,env=env,stdout=f,stderr=sp.STDOUT)
 records.append({'phase':i,'rc':r.returncode})
 if r.returncode:(root/'state.json').write_text(json.dumps({'state':'failed','records':records}));raise SystemExit(r.returncode)
(root/'state.json').write_text(json.dumps({'state':'passed','records':records}))
