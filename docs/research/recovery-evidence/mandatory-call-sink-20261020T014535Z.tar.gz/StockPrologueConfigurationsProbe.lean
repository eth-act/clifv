import FV.Backend.Proof.StockPrologueInput

namespace Backend.Stock.Prologue.NextConfigurations
open D0

deriving instance DecidableEq for VBlock
deriving instance DecidableEq for VCode
deriving instance DecidableEq for Except

def eraseDiagnostics (v : VCode) : VCode := {v with name := "",rulesFired := #[]}
def observe (c : Configuration) : Except String (Bool × Bool) := do
  let f := Prologue.source "next_configuration_probe" c []
  let actual ← Stock.lower f
  let old ← lowerFunction f
  pure (decide (eraseDiagnostics (compact f.name actual) = eraseDiagnostics old),
    actual.edgeArgs.all fun row => row.all (·.isEmpty))

#eval configurations.map fun c => (reprStr c,observe c)
end Backend.Stock.Prologue.NextConfigurations
