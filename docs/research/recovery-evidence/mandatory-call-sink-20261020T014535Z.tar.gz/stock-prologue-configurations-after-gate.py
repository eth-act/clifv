from pathlib import Path
import os,time,json,subprocess as sp
root=Path('/tmp/stock-production-activation-gates');out=Path('/tmp/stock-prologue-configurations-probe');out.mkdir(exist_ok=True)
while True:
 d=json.loads((root/'progress.json').read_text())
 try:os.kill(d['pid'],0)
 except ProcessLookupError:
  if d['state']!='per_pr_gates_passed':raise RuntimeError('gate controller stopped before validated module phase')
 if 'all-modules' in d.get('logs',{}):break
 if d['state']=='failed':raise RuntimeError(d.get('error'))
 time.sleep(5)
env=dict(os.environ,FV_MEMCAP='8G',FV_LAKE_CACHE='/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2');env['PATH']='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:'+env['PATH']
view=Path('/home/lee/clifv/.worktrees/stock-driver-incremental')
(out/'state.json').write_text(json.dumps({'state':'running','pid':os.getpid()}))
with (out/'kernel.log').open('w') as f:r=sp.run(['scripts/memcap.sh','lake','env','lean','--root=/tmp','/tmp/StockPrologueConfigurationsProbe.lean'],cwd=view,env=env,stdout=f,stderr=sp.STDOUT)
(out/'state.json').write_text(json.dumps({'state':'passed' if r.returncode==0 else 'failed','rc':r.returncode,'pid':os.getpid()}))
