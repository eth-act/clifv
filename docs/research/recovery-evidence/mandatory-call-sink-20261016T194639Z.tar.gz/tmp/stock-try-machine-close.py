from pathlib import Path
import json,hashlib,re,datetime,tarfile,shutil
root=Path('/home/lee/clifv/.worktrees/driver-proof-resume');docs=root/'docs/research'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
now=datetime.datetime.now(datetime.timezone.utc);stamp=now.strftime('%Y%m%dT%H%M%SZ')
batch=json.loads(Path('/tmp/stock-try-machine-batch.json').read_text());old=json.loads((docs/'stock-try-emitted-scratch.json').read_text())
sets={m.group(1):sorted(x.strip() for x in m.group(2).split(',') if x.strip()) for m in re.finditer(r"'([^']+)' depends on axioms:\s*\[([^]]*)\]",Path('/tmp/stock-try-machine-combined-axioms.log').read_text())}
for m in re.finditer(r"'([^']+)' does not depend on any axioms",Path('/tmp/stock-try-machine-combined-axioms.log').read_text()):sets[m.group(1)]=[]
for n,a in old['normal_audit']['sets'].items():assert sorted(a)==sets[n],n
allowed={'propext','Classical.choice','Quot.sound'}
for n in batch['public_roots']+batch['models']:assert set(sets[n])<=allowed,n
constants=[json.loads(line.split('DELIVERY_CONSTANT ',1)[1]) for line in Path('/tmp/stock-try-machine-all-constants.log').read_text().splitlines() if line.startswith('DELIVERY_CONSTANT ')]
assert constants
for n,a in constants:assert set(a)<=allowed,n
mods={}
for m in batch['modules']:
 p=Path('/tmp')/m;check=json.loads(p.with_suffix('.check.json').read_text());assert check['actual_exit']==0
 rec={}
 for key,ext in [('source','.lean'),('object','.olean'),('log','.log'),('check','.check.json')]:
  f=p.with_suffix(ext);rec[key]=str(f);rec[key+'_sha256']=sha(f)
 for k in ['source','object','log']:assert rec[k+'_sha256']==check[k+'_sha256']
 assert not re.search(r'\b(sorry|admit|axiom|trace_state|native_decide)\b',p.with_suffix('.lean').read_text())
 mods[m]=rec
prior={}
for name in ['source-execution-x','try-source','try-context','try-rule','try-rets','try-reservation','try-outgoing','try-values','try-emitted']:
 d=json.loads((docs/f'stock-{name}-scratch.json').read_text())
 for m,rec in d['modules'].items():
  for k in ['source','object','log']:assert sha(rec[k])==rec[k+'_sha256'],(m,k)
  prior[m]=rec
freeze=json.loads(Path('/tmp/stock-coherent-build-inputs.json').read_text())
for group in ['source_sha256','validation_script_sha256']:
 for p,h in freeze[group].items():assert sha(root/p)==h,p
progress=json.loads(Path('/tmp/stock-pr246-gates-progress.json').read_text());progress.pop('completed_phases',None)
remaining=old['remaining_checklist']
for item in remaining:
 if 'Actual emitted direct/GOT/indirect TryCall outgoing' in item['requirement']:
  item['state']='Original outgoing bounds/SigStackOk derived. Direct colocated retained branch now has exact argument-store+reserved-call code and actual seqRun normal returned world/operand results through final aliases under original memory/callee contracts. GOT/indirect machine composition, exception payload machine execution and final-renamed/source-frame/block composition remain open.'
remaining.append({'requirement':'Actual direct retained branch machine execution from original source/build and memory/callee contracts','state':'Proved with complete original-condition compiler/prepare/checked-fallback/physical witness and real Clif.runWith normal17 source execution. Full final-renamed branch/source-frame continuation is still open; this is not whole-driver simulation or completeness.'})
receipt={'utc':now.isoformat(),'goal':'Original full #140 ACTIVE/INCOMPLETE; production LEGACY','scope':'Scratch-only additive Stock proofs, not coherent integration or merge-ready','delivery_target':'roughly eight substantive validated squash merges/day; remote backups and cleanup; drafts do not count','modules':mods,'public_roots':batch['public_roots'],'models':batch['models'],'counts':{'modules':len(mods),'public_roots':len(batch['public_roots']),'models':len(batch['models']),'combined_roots_models':len(sets),'previous_preserved':len(old['normal_audit']['sets']),'all_new_module_constants':len(constants)},'normal_audit':{'path':'/tmp/stock-try-machine-combined-axioms.log','sha256':sha('/tmp/stock-try-machine-combined-axioms.log'),'sets':sets},'all_constant_audit':{'path':'/tmp/stock-try-machine-all-constants.log','sha256':sha('/tmp/stock-try-machine-all-constants.log'),'all_standard_only':True,'count':len(constants)},'previous68_modules_hashes_preserved':list(prior),'canonical2246_source_and_script_freeze_preserved':True,'kernel_resources':'All new modules and both audits actual exit0 / object verified at8GiB through memcap; one heavy delivery worker retained','MCP':'No new calls; bundled provenance audit deferred until coherent integration','active_exact_PR246_validation':progress,'remaining_checklist':remaining}
(docs/'stock-try-machine-scratch.json').write_text(json.dumps(receipt,indent=2)+'\n')
text=f'''Actual direct TryCall normal machine execution — {now.isoformat()}

Five scratch modules, {len(batch['public_roots'])} public theorem roots and one public execution model pass kernel checks at8GiB. The {len(sets)}-root/model audit preserves all516prior exact axiom sets. All {len(constants)} constants in new modules, including private operational helpers, use only standard axioms. All68previous scratch source/object/log hashes and the frozen2246canonical sources plus scripts are unchanged. Previous goal turn classified PROGRESS: checked emitted-call/argument-store proofs and complete witnesses, audits, archive and verified remote backup.

The SAME actual direct RHS now emits exactly its original mapped-source ABI argument stores followed by its reserved-definition call. Actual whole lowering derives the retained branch code, original source/selection/layout, valid per-site stack bound and final return alias endpoints internally. Under the ORIGINAL memory/outgoing/callee contracts and held source arguments, its real seqRun executes stores then TryCall, takes normal control and returns the related memory world. Values are read through the actual vdefUpd operand update and whole-driver final aliases. No eight-argument limit is added; old theorem variants and input conditions are unchanged.

The complete colocated compiler/prepare/forced checked fallback/checker/physical witness inhabits original memory/callee/outgoing contracts, runs the retained machine branch and actually runs the source program to17. A cached projection-only outgoing observation passes at8GiB; no heavy retry, cap raise or restarted delivery kernel. This witness has zero call arguments; earlier complete9argumentGOT16byte store/code witnesses remain, but a complete nonempty-stack machine execution witness is still required for the broader ABI matrix.

Open: GOT/indirect full machine composition, actual final-renamed instruction and source-frame/DFG/available-value noninterference/normal edge parameter continuation; explicit/sret/x8 compatibility; payload endpoints and exception machine semantics (S10 owner @kevaundray #232/#233). Every remaining family/effect/source/block/whole-driver simulation AND completeness, coherent integration and production compiler/checker/linker/generated consumer cutover remains required. Production LEGACY. Both draft PRs require exact updated-main full gates before squash. Same live delivery supervisor3247835 retained, canonical1233457 intentionally held. Aim roughly eight substantive validated squash merges/day with backup/cleanup. No new MCP calls; expanded bundled provenance check remains after coherent integration.

See stock-try-machine-scratch.json for hashed evidence and the full remaining checklist.
'''
(docs/'stock-try-machine-scratch.md').write_text(text)
plan=root/'docs/plans/test-binary-alignment-recovery.md';plan.write_text(plan.read_text()+'\n\n'+text)
files=[]
for rec in mods.values():files.extend(Path(rec[k]) for k in ['source','object','log','check'])
for name in ['stock-try-machine-combined-axioms','stock-try-machine-all-constants']:
 for ext in ['.lean','.log','.olean','.check.json']:files.append(Path('/tmp')/(name+ext))
files.extend(Path(p) for p in ['/tmp/stock-try-machine-batch.json','/tmp/stock-try-rule-inputs.json','/tmp/stock-try-reservation-check.py','/tmp/stock-try-machine-close.py','/tmp/stock-try-machine-status44.json','/tmp/stock-try-machine-status52.json','/tmp/stock-try-machine-status71.json','/tmp/stock-try-machine-task140.json'])
files.extend([docs/'stock-try-machine-scratch.json',docs/'stock-try-machine-scratch.md',docs/'stock-delivery-main-drift.json',plan])
archive=Path('/home/lee/.clifv-recovery')/(stamp+'-try-machine')/'checkpoint.tar.gz';archive.parent.mkdir(parents=True)
with tarfile.open(archive,'w:gz',compresslevel=1) as t:
 for p in files:t.add(p,arcname=str(p).lstrip('/'),recursive=False)
with tarfile.open(archive,'r:gz') as t:
 for p in files:assert t.extractfile(str(p).lstrip('/')).read()==p.read_bytes(),p
snapshot=Path('/tmp/stock-try-rule-inputs');size=sum(p.stat().st_size for p in snapshot.rglob('*') if p.is_file());shutil.rmtree(snapshot)
backup={'utc':now.isoformat(),'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(files),'all_members_byte_verified':True,'previous_remote_backup':json.loads((docs/'stock-try-emitted-backup.json').read_text())['remote'],'cleanup':{'duplicate_dependency_snapshot_removed':True,'bytes_reclaimed':size,'unique_sources_objects_logs_checks_audits_preserved':True,'one_shared_warm_cache_retained':True,'other_projects_touched':False,'free_bytes':shutil.disk_usage(root).free}}
(docs/'stock-try-machine-backup.json').write_text(json.dumps(backup,indent=2)+'\n');Path('/tmp/stock-try-machine-archive-path').write_text(str(archive))
print(json.dumps({'counts':receipt['counts'],'archive':str(archive),'cleanup':backup['cleanup'],'gate':progress},indent=2))
