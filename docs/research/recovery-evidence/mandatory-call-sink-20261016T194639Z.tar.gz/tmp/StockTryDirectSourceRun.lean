import StockTryDirectSem
import StockTryWholeOutgoing
import StockTryFinalReturnValues
namespace Backend.Stock.Proof.TryDirectSourceRunDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open TrySourceContextDraft TryBranchSelectionDraft TryBranchAbiDraft TrySelectedCallsDraft
open TryWholeSourceReservationDraft TryRetsTotalDraft TryDirectCodeDraft TryDirectSemDraft TryWholeOutgoingDraft
open TryResultMapDraft TryFinalReturnValuesDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
/-- A conclusion about the actual retained source branch and its normal machine
execution. It is constructed internally, never an accepted-program premise. -/
structure DirectTryRun (f : Clif.Function) (result : Result) (label bi : Nat) (b : Clif.Block)
    (ext : Clif.ExtFunc) (isem : Sem) (MR : MemRelT) (fr : Clif.Frame)
    (ρ : Nat → CV) (w : Arm.ArmState) (rvals : List Clif.Val) (cm' : Clif.Mem) where
  source : TryBranchSource f result label bi b
  selected : TryBranchSelection source
  base : Nat
  ns : List Nat
  bytes : List Nat
  locs : List ArgLoc
  stack : Nat
  info : TryInfo
  outs : List CV
  atCall : Arm.ArmState
  finalWorld : Arm.ArmState
  layout : result.initial.tryRegs[source.ti]! = (reservedReturns base ext.sig.returns.length,reservedPayloads base ext.sig.returns.length)
  code : source.branch.step.emitted = (((stackEnts ((locs.zip ns).zip bytes)).map argStore) ++
    [MInst.tryCall ⟨.sym ext.name,retPairs (regPairsOf ((locs.zip ns).zip bytes)),callDefs (resultDefs base ext.sig.returns.length)⟩
      {info with rets := ext.sig.returns.length}]).toArray
  run : seqRun isem source.branch.step.emitted.toList ρ w =
    some (.stop ((stackEnts ((locs.zip ns).zip bytes)).map argStore).length
      (.tryCall ⟨.sym ext.name,retPairs (regPairsOf ((locs.zip ns).zip bytes)),callDefs (resultDefs base ext.sig.returns.length)⟩
        {info with rets := ext.sig.returns.length})
      (retOps (regPairsOf ((locs.zip ns).zip bytes)) ++ callDefOps (resultDefs base ext.sig.returns.length)).toArray
      ρ atCall outs finalWorld (.goto info.handlers.length))
  returnedWorld : MR fr.slots cm' finalWorld
  normalValues : ∀ (j : Nat) (v : Clif.Val),rvals[j]? = some v →
    VHolds v (vdefUpd (retOps (regPairsOf ((locs.zip ns).zip bytes)) ++ callDefOps (resultDefs base ext.sig.returns.length)).toArray
      outs ρ (aliasNum result.final.alias (base+j)))
/-- Actual whole Stock lowering derives the direct TryCall's exact branch code
and final reserved aliases, executes its real ABI stores and call, and transfers
normal returned values/world. All source/static/layout premises are derived
from the original build/scope/input; memory and callee contracts are unchanged. -/
theorem stock_lower_direct_try_normal_source_run {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f) (input : Prg.iselInB f = true)
    {label bi : Nat} {b : Clif.Block} (node : result.order.nodes[label]? = some (.original bi))
    (block : f.blocks[bi]? = some b) {fn : Nat} {args : List Nat} {et : Clif.ExnTable}
    (kind : b.term = .tryCall fn args et) {ext : Clif.ExtFunc} (external : f.extern? fn = some ext)
    (near : ext.colocated = true)
    {Rd F : BitVec 64 → Prop} {isem : Sem} {MR : MemRelT} {sb : Nat} {syms : String → Option Nat}
    (stable : MRStable F MR) (memory : MemRefinesR Rd F sb syms isem)
    (outgoing : OutArgsOk F result.code.outgoing MR)
    {Pc : String → Clif.Signature → List Clif.Val → Clif.Mem → Prop} {env : Clif.Env} {exts : List Clif.ExtFunc}
    (calls : CallsRefineP Pc F env exts MR isem) (member : ext ∈ exts)
    {fr : Clif.Frame} {ρ : Nat → CV} {w : Arm.ArmState} {cm cm' : Clif.Mem} {vals rvals : List Clif.Val}
    (held : ValuesHeld (fun x => x ∈ args) result.ctx fr ρ) (read : fr.getMany args = .ok vals)
    (typed : vals.map (·.ty) = Clif.AbiParam.tys ext.sig.params) (related : MR fr.slots cm w)
    {g : List Clif.Val → Clif.Mem → Clif.Outcome} (found : env.extern ext.name = some g)
    (pin : Pc ext.name ext.sig vals cm) (returned : g vals cm = .returned rvals cm')
    (results : rvals.length = ext.sig.returns.length) :
    Nonempty (DirectTryRun f result label bi b ext isem MR fr ρ w rvals cm') := by
  have isTry : b.term.isTry = true := by rw [kind]; rfl
  obtain ⟨original,⟨originalSelected⟩⟩ := stock_lower_try_source_selection lowered scope node block isTry
  obtain ⟨items,table,_,_,_,_,_⟩ := stock_selected_try_direct_rhs_calls originalSelected kind external near
  have sourceTableEq : sourceTable b.term = some et := by rw [kind]; rfl
  obtain ⟨ranges,source,selected,base,replay,replayAfter,build,allocation,slots,replayRun,frame⟩ :=
    stock_lower_original_try_reservation lowered scope input node block sourceTableEq table
  obtain ⟨actualItems,actualTable,_,_,_,_,protocol⟩ := stock_selected_try_direct_rhs_calls selected kind external near
  obtain ⟨ns,bytes,locs,stack,mapping,byteRun,locations,raw⟩ := stock_direct_try_actual_code data_program
    source.mapped protocol base (exnTableOpnd_cc table) slots
  change selected.next.base.emitted = (#[] ++ _).push _ at raw
  simp only [Array.empty_append] at raw
  obtain ⟨et',sig',items',info,call,tableKind,decoded,metadata,abiCount,last,code,finalLast⟩ :=
    stock_try_branch_explicit_abi isTry selected.code
  have sameTable : et' = et := Option.some.inj (tableKind.symm.trans sourceTableEq)
  subst et'
  have sameSig := Except.ok.inj (decoded.symm.trans table)
  cases sameSig
  rw [raw,Array.back?_push] at last
  have sameCall := Option.some.inj last
  cases sameCall
  have exactCode : source.branch.step.emitted = (((stackEnts ((locs.zip ns).zip bytes)).map argStore) ++
    [MInst.tryCall ⟨.sym ext.name,retPairs (regPairsOf ((locs.zip ns).zip bytes)),callDefs (resultDefs base ext.sig.returns.length)⟩
      {info with rets := ext.sig.returns.length}]).toArray := by
    rw [selected.stepCode,code,raw,Array.pop_push]
    apply Array.toList_inj.mp
    simp only [Array.toList_push,List.toList_toArray]
  have heldSource : ValuesHeld (fun x => x ∈ args) source.ctx fr ρ := by
    intro x member v lookup
    obtain ⟨n,mapped,value⟩ := held x member v lookup
    exact ⟨n,by rw [source.valueMap]; exact mapped,value⟩
  have allValues := requested_values_hold heldSource read mapping
  simp only [List.map_map,Function.comp_def,registerView] at allValues
  have counts : ns.length = vals.length := by simpa using allValues.1.symm
  have values : ∀ (j : Nat) (v : Clif.Val) (n : Nat),vals[j]? = some v → ns[j]? = some n → VHolds v (ρ n) := by
    intro j v n atValue atReg
    apply allValues.2 j v (ρ n) atValue
    simp only [List.getElem?_map,atReg,Option.map_some]
  have stackOk := stock_lower_direct_try_stack lowered scope node block kind external
  obtain ⟨outs,atCall,w',run,length,heldResults,world,normal⟩ := stock_try_direct_stores_normal_execution
    stable memory outgoing calls member stackOk byteRun locations typed counts values related found pin returned results base info
  have layout : result.initial.tryRegs[source.ti]! = (reservedReturns base ext.sig.returns.length,reservedPayloads base ext.sig.returns.length) := by
    rw [← allocation.2]
    exact source.tryRegs.symm.trans slots
  refine ⟨{
    source := source
    selected := selected
    base := base
    ns := ns
    bytes := bytes
    locs := locs
    stack := stack
    info := info
    outs := outs
    atCall := atCall
    finalWorld := w'
    layout := layout
    code := exactCode
    run := ?_
    returnedWorld := world
    normalValues := ?_ }⟩
  · rw [exactCode,List.toList_toArray]
    exact run
  · intro j v atValue
    rw [vdefUpd_call]
    exact stock_lower_try_normal_reserved_values lowered layout ρ heldResults results length atValue
end Backend.Stock.Proof.TryDirectSourceRunDraft
