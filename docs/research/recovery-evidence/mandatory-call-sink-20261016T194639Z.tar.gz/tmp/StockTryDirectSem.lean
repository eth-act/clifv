import StockTryDirectCode
import StockTryNormalCallValues
import FV.Backend.Proof.IselContractP
namespace Backend.Stock.Proof.TryDirectSemDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open TryResultMapDraft TryResultWritesDraft TryNormalCallValuesDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
/-- The actual fixed-call operand update has the reserved normal value result;
this uses the real operands, including arbitrary preceding ABI argument uses. -/
theorem stock_try_direct_operand_values (base count : Nat) (L : List (Nat × Reg)) (ρ : Nat → CV)
    {values : List Clif.Val} {outs : List CV} (held : PrefixHold values outs)
    (normalCount : values.length = count) (length : outs.length = max count 2)
    {j : Nat} {v : Clif.Val} (atValue : values[j]? = some v) :
    VHolds v (vdefUpd (retOps L ++ callDefOps (resultDefs base count)).toArray outs ρ (base+j)) := by
  rw [vdefUpd_call]
  exact stock_try_write_normal_values base count ρ held normalCount length atValue
/-- Exact ABI argument stores execute before the actual reserved-definition
TryCall, under ORIGINAL memory/outgoing/callee contracts and held source values.
Normal branch control, returned world and actual operand result writes follow;
no at-most-eight source-argument condition is introduced. -/
theorem stock_try_direct_stores_normal_execution
    {Rd F : BitVec 64 → Prop} {isem : Sem} {MR : MemRelT} {sb : Nat} {syms : String → Option Nat}
    (stable : MRStable F MR) (memory : MemRefinesR Rd F sb syms isem)
    {outB : Nat} (outgoing : OutArgsOk F outB MR)
    {Pc : String → Clif.Signature → List Clif.Val → Clif.Mem → Prop}
    {env : Clif.Env} {exts : List Clif.ExtFunc} (calls : CallsRefineP Pc F env exts MR isem)
    {ext : Clif.ExtFunc} (member : ext ∈ exts) (stackOk : SigStackOk ext.sig outB)
    {bytes : List Nat} {locs : List ArgLoc} {stack : Nat}
    (byteRun : sigParamBytes ext.sig = .ok bytes) (locations : sigArgLocs ext.sig = .ok (locs,stack))
    {ns : List Nat} {vals rvals : List Clif.Val} {ρ : Nat → CV}
    (typed : vals.map (·.ty) = Clif.AbiParam.tys ext.sig.params) (count : ns.length = vals.length)
    (held : ∀ (j : Nat) (v : Clif.Val) (n : Nat),vals[j]? = some v → ns[j]? = some n → VHolds v (ρ n))
    {sl : List (Clif.SlotId × Nat)} {cm cm' : Clif.Mem} {w : Arm.ArmState} (related : MR sl cm w)
    {g : List Clif.Val → Clif.Mem → Clif.Outcome} (found : env.extern ext.name = some g)
    (pin : Pc ext.name ext.sig vals cm) (returned : g vals cm = .returned rvals cm')
    (results : rvals.length = ext.sig.returns.length) (base : Nat) (info : TryInfo) :
    ∃ (outs : List CV) (atCall w' : Arm.ArmState),
      let L := regPairsOf ((locs.zip ns).zip bytes)
      let D := resultDefs base ext.sig.returns.length
      let call := MInst.tryCall ⟨.sym ext.name,retPairs L,callDefs D⟩ {info with rets := ext.sig.returns.length}
      seqRun isem (((stackEnts ((locs.zip ns).zip bytes)).map argStore) ++ [call]) ρ w =
        some (.stop ((stackEnts ((locs.zip ns).zip bytes)).map argStore).length call
          (retOps L ++ callDefOps D).toArray ρ atCall outs w' (.goto info.handlers.length)) ∧
      outs.length = max ext.sig.returns.length 2 ∧ PrefixHold rvals outs ∧ MR sl cm' w' ∧
      ∀ (j : Nat) (v : Clif.Val),rvals[j]? = some v →
        VHolds v (vdefUpd (retOps L ++ callDefOps D).toArray outs ρ (base+j)) := by
  obtain ⟨atCall,stores,relatedCall,arguments⟩ := argsAt_after_stores stable memory outgoing stackOk byteRun locations typed count held related
  obtain ⟨sym,load,tried⟩ := stock_try_normal_call_values calls
  obtain ⟨outs,w',run,length,values,world,normal⟩ := tried ext member g sl cm atCall (.sym ext.name)
    (retPairs (regPairsOf ((locs.zip ns).zip bytes))) info _ _ vals rvals cm' base found (.inl ⟨rfl,rfl⟩)
    (arguments atCall (SameWorldNF.refl F atCall)) relatedCall pin returned results
  have defsLength : outs.length = (resultDefs base ext.sig.returns.length).length := by
    simpa only [resultDefs,List.length_map,List.length_range] using length
  refine ⟨outs,atCall,w',?_,length,values,world,?_⟩
  · simpa only [Nat.zero_add] using seqRun_append_fall_stop isem stores (seqRun_tryCall_sym run defsLength)
  · intro j v atValue
    rw [vdefUpd_call]
    exact normal ρ j v atValue
end Backend.Stock.Proof.TryDirectSemDraft
