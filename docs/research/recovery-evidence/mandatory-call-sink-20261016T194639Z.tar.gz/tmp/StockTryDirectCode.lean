import StockTryArgumentEmission
namespace Backend.Stock.Proof.TryDirectCodeDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open TryRhsCallsDraft TryHelperFramesDraft TryInfoAreaDraft TryResultMapDraft TryArgumentEmissionDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm
private theorem sem_ctor (ctx : Ctx) (t : Term) (vs : List V) (st : State) :
    (Stock.sem ctx).ctor t vs st = Stock.externCtor ctx t vs st := rfl
private theorem sem_mkData (ctx : Ctx) (ty k : Nat) (vs : List V) :
    (Stock.sem ctx).mkData ty k vs = .data ty k vs := rfl

private theorem sem_unData (ctx : Ctx) (ty : Nat) (v : V) :
    (Stock.sem ctx).unData ty v = (Backend.sem ctx).unData ty v := rfl

private theorem stock_internal_split_first {p : Program} {cfg : Config} {σ : Type} {sem : Isle.Sem V σ}
    (hc : cfg.checkOverlap = false) {ty : TypeId} {t : TermId} {vs : List V} {term : Term}
    {flags : TermFlags} {ex : Option Extractor} (ht : termOf p t = .ok term)
    (hk : term.kind = .decl flags (some .internal) ex) (hm : flags.isMulti = false)
    {n : Nat} (hn : 22 + (p.rulesOf t).length ≤ n) {s s' : σ × Array RuleId} {v : V}
    (h : ApplyInternal p sem cfg n ty t vs s v s') :
    ∃ pre r post, p.rulesOf t = pre ++ r :: post ∧
      (∀ r' ∈ pre, ∃ m' s1, (matchRule p sem cfg (m' + 20) r' vs).run s = .ok (none, s1)) ∧
      ∃ m' n' env s1 st tr,
      (matchRule p sem cfg (m' + 20) r vs).run s = .ok (some env, s1) ∧
      (evalExpr p sem cfg (n' + 20) r.rhs env).run s1 = .ok (some v, (st, tr)) ∧
      s' = (st, tr.push r.id) ∧ n = n' + 20 := by
  obtain ⟨r, pre, post, hL, hpre, m, env, s1, st, tr, hmn, hmt, he, rfl⟩ :=
    applyTerm_internal_some_first hc ht hk hm h
  obtain ⟨m', rfl⟩ : ∃ m', m = m' + 20 := ⟨m - 20, by omega⟩
  obtain ⟨n', rfl⟩ : ∃ n', n = n' + 20 := ⟨n - 20, by omega⟩
  refine ⟨pre, r, post, hL, fun r' hr' => ?_, m', n', env, s1, st, tr, hmt, he, rfl, rfl⟩
  obtain ⟨k, hk, s2, h2⟩ := hpre r' hr'
  obtain ⟨k', rfl⟩ : ∃ k', k = k' + 20 := ⟨k - 20, by omega⟩
  exact ⟨k', s2, h2⟩

private theorem stock_try_direct_machine {p : Program} (hp : Data p) {ctx : Ctx} {n : Nat}
    (enough : 30 ≤ n) {info : V} {before after : State × Array RuleId} {machine : V}
    (run : ApplyInternal p (Stock.sem ctx) {} n 46 638 [info] before machine after) :
    after.1 = before.1 ∧ machine = .data 46 0 [.data 58 109 [info]] := by
  have hc : ({} : Config).checkOverlap = false := rfl
  rcases before with ⟨st,tr⟩
  rcases after with ⟨next,trace⟩
  obtain ⟨_,_,_,hL,hpre,_,_,_,_,_,_,hm,he,stateEq,fuelEq⟩ :=
    stock_internal_split_first hc hp.t638 term_638_kind rfl (by rw [hp.r638]; simp; omega) run
  rcases Prod.mk.inj stateEq with ⟨rfl,rfl⟩
  cases fuelEq
  rw [hp.r638] at hL
  isel_rule_cases hL
  cases hp
  isel_inv [*,rule_inst_4780,sem_mkData,sem_unData] at hm he

private theorem stock_try_direct_emit {p : Program} (hp : Data p) {ctx : Ctx} {n : Nat}
    (enough : 30 ≤ n) {call : CallInfo} {before after : State × Array RuleId} {unit : V}
    (run : ApplyInternal p (Stock.sem ctx) {} n 13 242
      [.data 46 0 [.data 58 109 [.op (.callInfo call)]]] before unit after) :
    after.1 = {before.1 with base := before.1.base.emit (.call call)} ∧ unit = .op .unit := by
  have hc : ({} : Config).checkOverlap = false := rfl
  have emitted (st : State) : Stock.externCtor ctx T.emit [.data 58 109 [.op (.callInfo call)]] st =
      .ok (.op .unit,{st with base := st.base.emit (.call call)}) := by
    rw [stock_ctor_baseOnly _ _ _ _ (by decide),ctor_emit _ _ (ofV_call call)]
  rcases before with ⟨st,tr⟩
  rcases after with ⟨next,trace⟩
  obtain ⟨_,_,_,hL,hpre,_,_,_,_,_,_,hm,he,stateEq,fuelEq⟩ :=
    stock_internal_split_first hc hp.t242 term_242_kind rfl (by rw [hp.r242]; simp; omega) run
  rcases Prod.mk.inj stateEq with ⟨rfl,rfl⟩
  cases fuelEq
  rw [hp.r242] at hL
  isel_rule_cases hL
  all_goals cases hp
  · isel_inv [*,rule_prelude_lower_522,sem_ctor,sem_mkData,sem_unData,emitted] at hm he
    isel_destruct
    rename_i actual
    rw [emitted] at actual
    cases actual
    exact ⟨rfl,rfl⟩
  · isel_inv [*,rule_prelude_lower_524,sem_mkData,sem_unData] at hm
  · isel_inv [*,rule_prelude_lower_527,sem_mkData,sem_unData] at hm


private theorem marked_base (xs : List Nat) (st : State) : (xs.foldl State.mark st).base = st.base := by
  induction xs generalizing st with
  | nil => rfl
  | cons x xs ih => exact ih (st.mark x)
/-- The SAME actual direct RHS emits exactly its original source argument
stores and actual reserved-definition call, with the source register map and
ABI uses derived internally. The local layout premise is supplied from original
whole-driver construction by the consumer, not an accepted-input restriction. -/
theorem stock_direct_try_actual_code {p : Program} (hp : Data p)
    {f : Clif.Function} {ctx : Ctx} (mapped : MappedCtxInv f ctx)
    {args : List Nat} {sig : Clif.Signature} {name : String} {items : List (Option Nat)}
    {labels : List Label} {st next : State} {tr trace : Array RuleId} {out : V}
    (calls : DirectTryCalls p ctx args sig name items labels st next tr trace out)
    (base : Nat) (payload : payloadRegs sig.callConv = [.x 0,.x 1])
    (slots : ctx.tryRegs = (TryRetsTotalDraft.reservedReturns base sig.returns.length,
      TryRetsTotalDraft.reservedPayloads base sig.returns.length)) :
    ∃ (ns bytes : List Nat) (locs : List ArgLoc) (stack : Nat),
      args.mapM ctx.valueReg? = some (ns.map fun n => Reg.vreg n .int) ∧
      sigParamBytes sig = .ok bytes ∧ sigArgLocs sig = .ok (locs,stack) ∧
      next.base.emitted = (st.base.emitted ++ ((stackEnts ((locs.zip ns).zip bytes)).map argStore).toArray).push
        (.call ⟨.sym name,retPairs (regPairsOf ((locs.zip ns).zip bytes)),callDefs (resultDefs base sig.returns.length)⟩) := by
  obtain ⟨abi,afterAbi,tryValue,afterTry,requested,afterRequest,uses,afterArgs,defs,afterDefs,
    callInfo,afterInfo,machine,afterMachine,machineTrace,callFuel,emitFuel,
    abiCall,tryCall,requestCall,argsCall,retsCall,infoCall,callBound,emitBound,callRun,emitRun⟩ := calls
  obtain ⟨rfl,abiFrame⟩ := stock_try_abi_identity abiCall
  subst afterAbi
  obtain ⟨info,metadata,tryEq,tryFrame⟩ := stock_try_info_frame tryCall
  obtain ⟨ns,bytes,locs,stack,mapping,byteRun,locations,usesValue,argsFrame⟩ :=
    stock_try_actual_argument_stores mapped requestCall argsCall
  have requestFrame := ((stock_put_in_regs_vec_iff _ _ _ _ _).mp requestCall).2
  obtain ⟨rs,_,_,requestFrame⟩ := requestFrame
  have requestBase : afterRequest.base = st.base := by rw [requestFrame,marked_base,tryFrame]
  have bound : sig.returns.length ≤ 8 := by
    obtain ⟨ps,returns,rest⟩ := TryRetsShapeDraft.stock_try_rets_exact_shape retsCall
    by_cases h : sig.returns.length ≤ 8
    · exact h
    · simp only [retRegs,if_neg h] at returns
      cases returns
  have defsValue := stock_try_reserved_result_defs retsCall base bound payload slots
  have retsFrame := (TryRetsFrameDraft.stock_try_rets_state_frame retsCall).1
  obtain ⟨locs',area,us,ds,locations',usesEq,defsEq,infoEq,infoFrame⟩ := stock_try_direct_info_area infoCall
  have sameUses : us = retPairs (regPairsOf ((locs.zip ns).zip bytes)) := by
    simpa only [V.op.injEq,Opnd.callArgs.injEq] using usesEq.symm.trans usesValue
  have sameDefs : ds = callDefs (resultDefs base sig.returns.length) := by
    simpa only [V.op.injEq,Opnd.callRets.injEq] using defsEq.symm.trans defsValue
  subst us
  subst ds
  rw [infoEq] at callRun
  obtain ⟨machineFrame,machineValue⟩ := stock_try_direct_machine hp callBound callRun
  rw [machineValue] at emitRun
  obtain ⟨emitted,_⟩ := stock_try_direct_emit hp emitBound emitRun
  dsimp only at emitted machineFrame
  refine ⟨ns,bytes,locs,stack,mapping,byteRun,locations,?_⟩
  rw [emitted,machineFrame,infoFrame]
  change afterDefs.base.emitted.push _ = _
  rw [retsFrame,argsFrame]
  change (afterRequest.base.emitted ++ _).push _ = _
  rw [requestBase]
end Backend.Stock.Proof.TryDirectCodeDraft
