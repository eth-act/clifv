import StockTryNearFixture
namespace Backend.Stock.Proof.TryNearOutgoingObservationDraft
open Backend.Proof Backend.Proof.Driver
set_option maxRecDepth 20000
set_option maxHeartbeats 16000000
/-- Projection-only kernel observation for the already witnessed complete
colocated pipeline, to inhabit its original outgoing memory contract. -/
theorem observed : ((Stock.lower (TryNearFixtureDraft.function false)).map (fun r => r.code.outgoing)).toOption = some 0 := by
  decide +kernel
end Backend.Stock.Proof.TryNearOutgoingObservationDraft
