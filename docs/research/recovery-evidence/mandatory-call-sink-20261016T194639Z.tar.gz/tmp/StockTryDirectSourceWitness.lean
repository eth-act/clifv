import StockTryDirectSourceRun
import StockTryNearOutgoingObservation
import FV.Backend.Proof.MemRefines
import FV.E2E.RegLevelDriverSem
namespace Backend.Stock.Proof.TryDirectSourceWitnessDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open TryDirectSourceRunDraft TryNearFixtureDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private def f := function false
private def ext : Clif.ExtFunc := {name := "callee",sig := f.sig,colocated := true}
private def table : Clif.ExnTable := {
  sig := 0,normal := ⟨1,[.ret 0,.val 0]⟩,items := [.tag 7 ⟨2,[.exn 0,.exn 1,.val 0]⟩] }
private def fr : Clif.Frame := {func := f,regs := Clif.Regs.empty.set 0 ⟨.i64,9⟩,slots := [],body := [],term := f.blocks[0]!.term}
private def model : ExtSem := ⟨fun _ _ w => some ([17],w),fun _ _ => 4096,0,fun _ w => Arm.read_pstate w⟩
private def environment : Clif.Env := {
  extern := fun _ => some (fun _ cm => .returned [⟨.i64,17⟩] cm),names := ["callee"],sigOf := fun _ => some f.sig }
private theorem held : PrefixHold [⟨.i64,17⟩] ([17] : List CV) := by
  refine ⟨by decide,?_⟩
  intro j v x atValue atOut
  cases j with
  | zero => cases atValue; cases atOut; rfl
  | succ j => simp at atValue
private theorem xcalls : XCallsOk environment [ext] (fun _ _ _ => True) model := by
  intro e member g sl cm w dest used args vals rvals cm' found target arguments memory returned length
  have same := List.mem_singleton.mp member
  subst e
  simp only [environment,Option.some.injEq] at found
  subst g
  cases returned
  exact ⟨[17],w,rfl,rfl,held,trivial⟩
/-- A COMPLETE original-condition compiler/prepare/checked-fallback/physical
pipeline inhabits the original memory/callee contracts and the new whole-source
actual branch execution. The actual normal operand update returns17 through
final aliases; the source program also really runs to17. -/
theorem stock_complete_direct_try_normal_source_run_witness :
    ∃ out : Output,
      LowerScope f ∧ Dominated f ∧ ArityOk f ∧ Stock.lower f = .ok out.result ∧
      prepareAt out.result.code out.result.edgeArgs = .ok out.prepared ∧
      out.rf = spillAllocAt out.prepared.code out.prepared.edges ∧
      checkAllocAt out.prepared.code out.prepared.edges out.rf = .ok () ∧ lowerRFunc out.prepared.code out.rf = .ok out.af ∧
      XCallsOk environment [ext] (fun _ _ _ => True) model ∧
      CallsRefineP (fun _ _ _ _ => True) (fun _ => False) environment [ext] (fun _ _ _ => True) (csem (fun _ => False) ⟨0,0⟩ model) ∧
      MRStable (fun _ => False) (fun _ _ _ => True) ∧
      MemRefinesR (fun _ => True) (fun _ => False) 0 (fun _ => none) (csem (fun _ => False) ⟨0,0⟩ model) ∧
      OutArgsOk (fun _ => False) out.result.code.outgoing (fun _ _ _ => True) ∧
      Nonempty (DirectTryRun f out.result 0 0 f.blocks[0]! ext (csem (fun _ => False) ⟨0,0⟩ model)
        (fun _ _ _ => True) fr (fun _ => 0) Arm.ArmState.default [⟨.i64,17⟩] Clif.Mem.empty) ∧
      Clif.runWith environment {funcs := [f]} f.name [] Clif.Mem.empty 6 = .returned [⟨.i64,17⟩] Clif.Mem.empty := by
  obtain ⟨out⟩ := stock_near_try_fixture
  have order : blockOrder f = .ok {nodes := #[.original 0,.original 1,.original 2],successors := #[#[2,1],#[],#[]]} := by cbv
  have sameOrder := Except.ok.inj ((stock_lower_order out.lowered).symm.trans order)
  have node : out.result.order.nodes[0]? = some (.original 0) := by rw [sameOrder]; rfl
  have block : f.blocks[0]? = some f.blocks[0]! := rfl
  have kind : f.blocks[0]!.term = .tryCall 0 [] table := rfl
  have external : f.extern? 0 = some ext := rfl
  have area : out.result.code.outgoing = 0 := by
    have observed := TryNearOutgoingObservationDraft.observed
    rw [out.lowered] at observed
    exact Option.some.inj observed
  have stable : MRStable (fun _ => False) (fun _ _ _ => True) := by intro _ _ _ _ _ _; trivial
  have memory : MemRefinesR (fun _ => True) (fun _ => False) 0 (fun _ => none) (csem (fun _ => False) ⟨0,0⟩ model) :=
    memRefinesR_of (memRefines_csem _ _ _ rfl (by intro n b found; cases found))
  have outgoing : OutArgsOk (fun _ => False) out.result.code.outgoing (fun _ _ _ => True) := by
    rw [area]
    intro sl cm w related
    exact ⟨by decide,by intro k bound bad; exact bad,by intro k n y inside; trivial⟩
  have contract : CallsRefineP (fun _ _ _ _ => True) (fun _ => False) environment [ext] (fun _ _ _ => True)
      (csem (fun _ => False) ⟨0,0⟩ model) := (callsRefine_csem xcalls).toP _
  have heldArgs : ValuesHeld (fun x => x ∈ ([] : List Nat)) out.result.ctx fr (fun _ => 0) := by
    intro x member; cases member
  have run := stock_lower_direct_try_normal_source_run (w := Arm.ArmState.default) (cm := Clif.Mem.empty) (cm' := Clif.Mem.empty) out.lowered out.scope
    (show Prg.iselInB f = true from by decide +kernel) node block kind external rfl stable memory outgoing
    contract (show ext ∈ [ext] from by simp) heldArgs (show fr.getMany [] = .ok [] from rfl)
    (show ([] : List Clif.Val).map (·.ty) = Clif.AbiParam.tys ext.sig.params from rfl)
    (show (fun _ _ _ => True) fr.slots Clif.Mem.empty Arm.ArmState.default from trivial)
    (show environment.extern ext.name = some (fun _ cm => .returned [⟨.i64,17⟩] cm) from rfl)
    trivial rfl rfl
  exact ⟨out,out.scope,out.dominated,out.arity,out.lowered,out.prepare,out.fallback,out.accepted,out.physical,
    xcalls,contract,stable,memory,outgoing,run,rfl⟩
end Backend.Stock.Proof.TryDirectSourceWitnessDraft
