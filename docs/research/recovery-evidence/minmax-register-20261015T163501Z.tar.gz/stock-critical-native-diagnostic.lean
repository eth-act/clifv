import FV.Backend.Proof.StockCriticalValues
open Backend Backend.Stock
private def f : Clif.Function := {
  name := "stock_critical_values_alias"
  sig := {params := [⟨.i64,.none,.normal⟩],returns := [⟨.i8,.none,.normal⟩],callConv := some .systemV}
  blocks := [{id := 0,params := [(7,.i64)],body := [⟨[17],.ireduce .i8 7⟩],term := .brif 7 ⟨1,[17]⟩ ⟨1,[17]⟩},
    {id := 1,params := [(31,.i8)],term := .ret [31]}] }
#eval (Stock.lower f).map fun r => (r.order,r.ctx.valueReg? 7,r.ctx.valueReg? 17,r.ctx.valueReg? 31,r.final.alias[193]?,r.final.demand,r.code.blocks)
