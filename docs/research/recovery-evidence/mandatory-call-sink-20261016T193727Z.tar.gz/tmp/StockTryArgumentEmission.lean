import StockTryCallMachine
namespace Backend.Stock.Proof.TryArgumentEmissionDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open TryRhsCallsDraft TryHelperFramesDraft TryInfoAreaDraft TryRetsFrameDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private theorem delegated {ctx : Ctx} {t : Term} {args : List V} {st next : State} {out : V}
    (ordinary : t.id ∉ revisedCtors) (run : Stock.externCtor ctx t args st = .ok (out,next)) :
    ∃ base,Backend.externCtor ctx t args st.base = .ok (out,base) ∧ next = {st with base} := by
  rw [stock_ctor_baseOnly _ _ _ _ ordinary] at run
  cases call : Backend.externCtor ctx t args st.base with
  | fail => rw [call] at run; cases run
  | unmodeled err => rw [call] at run; cases run
  | ok pair =>
    obtain ⟨value,base⟩ := pair
    rw [call] at run
    cases run
    exact ⟨base,rfl,rfl⟩
private theorem numbers : ∀ rs : List Reg,(∀ r ∈ rs,∃ n,r = .vreg n .int) →
    ∃ ns : List Nat,rs = ns.map (fun n => Reg.vreg n .int)
  | [],_ => ⟨[],rfl⟩
  | r :: rs,virtual => by
    obtain ⟨n,rfl⟩ := virtual r (List.mem_cons_self ..)
    obtain ⟨ns,rfl⟩ := numbers rs (fun r member => virtual r (List.mem_cons_of_mem _ member))
    exact ⟨n :: ns,rfl⟩
/-- The actual request and argument helper derive the original source register
map, exact ABI register uses and exact stack stores at the SAME intermediate
states. This covers arbitrary stack arguments; it adds no count/layout input
condition or replayed helper certificate. -/
theorem stock_try_actual_argument_stores {f : Clif.Function} {ctx : Ctx} (mapped : MappedCtxInv f ctx)
    {args : List Nat} {sig : Clif.Signature} {requested uses : V} {before afterRequest afterArgs : State}
    (request : Stock.externCtor ctx T.put_in_regs_vec [.values args] before = .ok (requested,afterRequest))
    (arguments : Stock.externCtor ctx T.gen_call_args [.op (.sig sig),requested] afterRequest = .ok (uses,afterArgs)) :
    ∃ (ns : List Nat) (bytes : List Nat) (locs : List ArgLoc) (stack : Nat),
      args.mapM ctx.valueReg? = some (ns.map fun n => Reg.vreg n .int) ∧
      sigParamBytes sig = .ok bytes ∧ sigArgLocs sig = .ok (locs,stack) ∧
      uses = .op (.callArgs (retPairs (regPairsOf ((locs.zip ns).zip bytes)))) ∧
      afterArgs = {afterRequest with base.emitted := afterRequest.base.emitted ++
        ((stackEnts ((locs.zip ns).zip bytes)).map argStore).toArray} := by
  obtain ⟨safe,rs,mapping,rfl,requestState⟩ := (stock_put_in_regs_vec_iff _ _ _ _ _).mp request
  have virtual : ∀ r ∈ rs,∃ n,r = .vreg n .int := by
    intro r member
    obtain ⟨x,present,lookup⟩ := Backend.Proof.Flow.mapM_mem mapping r member
    exact mapped.valueReg x r lookup
  obtain ⟨ns,rfl⟩ := numbers rs virtual
  obtain ⟨base,legacy,state⟩ := delegated (by decide) arguments
  obtain ⟨bytes,byteRun⟩ := ctor_gen_call_args_bytes legacy
  obtain ⟨locs,stack,locRun⟩ := ctor_gen_call_args_locs legacy
  obtain ⟨value,stores⟩ := (ctor_gen_call_args_gen _ _ ns byteRun locRun _ _).mp legacy
  exact ⟨ns,bytes,locs,stack,mapping,byteRun,locRun,value,by rw [state,stores]⟩
end Backend.Stock.Proof.TryArgumentEmissionDraft
