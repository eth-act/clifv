import StockTrySelectedEmission
import StockTryArgumentEmission
namespace Backend.Stock.Proof.TrySelectedArgumentsDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open TrySourceContextDraft TryBranchSelectionDraft TrySelectedCallsDraft TryBranchAbiDraft TryArgumentEmissionDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
/-- Explicit source callee arguments, excluding the indirect target. -/
def argumentsOf : Clif.Terminator → List Clif.ValueId
  | .tryCall _ args _ | .tryCallIndirect _ args _ => args
  | _ => []
private theorem actual_arguments {f : Clif.Function} {result : Result} {label bi : Nat} {b : Clif.Block}
    {source : TryBranchSource f result label bi b} (selected : TryBranchSelection source)
    {et : Clif.ExnTable} {sig : Clif.Signature} {items : List (Option Nat)}
    (kind : sourceTable b.term = some et) (table : exnTableOpnd f et = .ok (sig,items)) :
    ∃ (before afterRequest afterArgs : State) (requested uses : V),
      Stock.externCtor source.ctx T.put_in_regs_vec [.values (argumentsOf b.term)] before = .ok (requested,afterRequest) ∧
      Stock.externCtor source.ctx T.gen_call_args [.op (.sig sig),requested] afterRequest = .ok (uses,afterArgs) := by
  cases term : b.term <;> simp only [sourceTable,term] at kind
  all_goals try contradiction
  case tryCall fn args et' =>
    cases kind
    obtain ⟨sig',items',ext,decoded,external,signature,data⟩ := stock_try_source_direct_data source term
    have same := congrArg Prod.fst (Except.ok.inj (decoded.symm.trans table))
    have extSig : ext.sig = sig := signature.trans same
    cases near : ext.colocated with
    | true =>
      obtain ⟨_,_,_,_,_,_,calls⟩ := stock_selected_try_direct_rhs_calls selected term external near
      obtain ⟨abi,afterAbi,tryValue,afterTry,requested,afterRequest,uses,afterArgs,defs,afterDefs,callInfo,afterInfo,machine,afterMachine,machineTrace,callFuel,emitFuel,abiCall,tryCall,requestCall,argsCall,rest⟩ := calls
      obtain ⟨abiEq,_⟩ := TryHelperFramesDraft.stock_try_abi_identity abiCall
      subst abi
      rw [extSig] at argsCall
      exact ⟨afterTry,afterRequest,afterArgs,requested,uses,by simpa only [argumentsOf,term] using requestCall,argsCall⟩
    | false =>
      obtain ⟨_,_,_,_,_,_,calls⟩ := stock_selected_try_got_rhs_calls selected term external near
      obtain ⟨abi,afterAbi,tryValue,afterTry,requested,afterRequest,uses,afterArgs,defs,afterDefs,boxed,afterBox,target,afterTarget,targetTrace,callInfo,afterInfo,machine,afterMachine,machineTrace,loadFuel,callFuel,emitFuel,abiCall,tryCall,requestCall,argsCall,rest⟩ := calls
      obtain ⟨abiEq,_⟩ := TryHelperFramesDraft.stock_try_abi_identity abiCall
      subst abi
      rw [extSig] at argsCall
      exact ⟨afterTry,afterRequest,afterArgs,requested,uses,by simpa only [argumentsOf,term] using requestCall,argsCall⟩
  case tryCallIndirect callee args et' =>
    cases kind
    obtain ⟨sig',items',decoded,rule,env,matched,trace,calls⟩ := stock_selected_try_indirect_rhs_calls selected term
    have same := congrArg Prod.fst (Except.ok.inj (decoded.symm.trans table))
    obtain ⟨abi,afterAbi,tryValue,afterTry,target,afterTarget,requested,afterRequest,uses,afterArgs,defs,afterDefs,callInfo,afterInfo,machine,afterMachine,machineTrace,callFuel,emitFuel,abiCall,tryCall,targetCall,requestCall,argsCall,rest⟩ := calls
    obtain ⟨abiEq,_⟩ := TryHelperFramesDraft.stock_try_abi_identity abiCall
    subst abi
    change sig' = sig at same
    rw [same] at argsCall
    exact ⟨afterTarget,afterRequest,afterArgs,requested,uses,by simpa only [argumentsOf,term] using requestCall,argsCall⟩


/-- Original source and actual first-match RHS internally supply the SAME real
request/argument states and their exact register ABI uses and stack stores. -/
theorem stock_selected_try_actual_argument_stores {f : Clif.Function} {result : Result} {label bi : Nat} {b : Clif.Block}
    {source : TryBranchSource f result label bi b} (selected : TryBranchSelection source)
    {et : Clif.ExnTable} {sig : Clif.Signature} {items : List (Option Nat)}
    (kind : sourceTable b.term = some et) (table : exnTableOpnd f et = .ok (sig,items)) :
    ∃ (before afterRequest afterArgs : State) (requested uses : V)
      (ns bytes : List Nat) (locs : List ArgLoc) (stack : Nat),
      Stock.externCtor source.ctx T.put_in_regs_vec [.values (argumentsOf b.term)] before = .ok (requested,afterRequest) ∧
      Stock.externCtor source.ctx T.gen_call_args [.op (.sig sig),requested] afterRequest = .ok (uses,afterArgs) ∧
      (argumentsOf b.term).mapM source.ctx.valueReg? = some (ns.map fun n => Reg.vreg n .int) ∧
      sigParamBytes sig = .ok bytes ∧ sigArgLocs sig = .ok (locs,stack) ∧
      uses = .op (.callArgs (retPairs (regPairsOf ((locs.zip ns).zip bytes)))) ∧
      afterArgs = {afterRequest with base.emitted := afterRequest.base.emitted ++
        ((stackEnts ((locs.zip ns).zip bytes)).map argStore).toArray} := by
  obtain ⟨before,afterRequest,afterArgs,requested,uses,request,args⟩ := actual_arguments selected kind table
  obtain ⟨ns,bytes,locs,stack,mapping,byteRun,locations,value,stores⟩ :=
    stock_try_actual_argument_stores source.mapped request args
  exact ⟨before,afterRequest,afterArgs,requested,uses,ns,bytes,locs,stack,request,args,mapping,byteRun,locations,value,stores⟩
end Backend.Stock.Proof.TrySelectedArgumentsDraft
