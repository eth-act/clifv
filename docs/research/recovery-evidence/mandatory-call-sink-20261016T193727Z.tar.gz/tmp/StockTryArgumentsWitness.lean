import StockTrySelectedArguments
import StockTryStackFixture
import FV.Backend.Proof.PerEdgeSpillEntryFixture
namespace Backend.Stock.Proof.TryArgumentsWitnessDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open TrySourceContextDraft TryBranchSelectionDraft TryBranchAbiDraft TrySelectedArgumentsDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private def function (indirect : Bool) := if indirect then SpillEntryFixture.function true else TryStackSourceDraft.function
private def table (indirect : Bool) : Clif.ExnTable := if indirect then {
  sig := 0,normal := ⟨1,[.ret 0,.val 0]⟩,items := [.tag 7 ⟨2,[.exn 0,.exn 1,.val 0]⟩] } else TryStackSourceDraft.table
private structure Pipeline (f : Clif.Function) where
  result : Result
  prepared : EdgeVCode
  rf : RFunc
  af : AFunc
  lowered : Stock.lower f = .ok result
  scope : LowerScope f
  dominated : Dominated f
  arity : ArityOk f
  prepare : prepareAt result.code result.edgeArgs = .ok prepared
  fallback : rf = spillAllocAt prepared.code prepared.edges
  accepted : checkAllocAt prepared.code prepared.edges rf = .ok ()
  physical : lowerRFunc prepared.code rf = .ok af
private theorem pipeline (indirect : Bool) : Nonempty (Pipeline (function indirect)) := by
  cases indirect with
  | false =>
    obtain ⟨out⟩ := TryStackFixtureDraft.stock_nine_argument_try_fixture
    exact ⟨⟨out.result,out.prepared,out.rf,out.af,out.lowered,out.scope,out.dominated,out.arity,
      out.prepare,out.fallback,out.accepted,out.physical⟩⟩
  | true =>
    obtain ⟨out⟩ := SpillEntryFixture.try_fixture true
    exact ⟨⟨out.result,out.prepared,out.rf,out.af,out.lowered,out.scope,out.dominated,out.arity,
      out.prepare,out.fallback,out.accepted,out.physical⟩⟩

/-- Complete nine-argument GOT and true indirect original-condition pipelines
instantiate the actual RHS argument request and exact stores/register ABI uses.
The GOT case has real16byte stack arguments; no original8argument direct-call
restriction is introduced. -/
theorem stock_complete_try_actual_argument_stores_witness (indirect : Bool) :
    ∃ (out : Pipeline (function indirect))
      (source : TryBranchSource (function indirect) out.result 0 0 (function indirect).blocks[0]!)
      (_selected : TryBranchSelection source)
      (before afterRequest afterArgs : State) (requested uses : V)
      (ns bytes : List Nat) (locs : List ArgLoc) (stack : Nat),
      LowerScope (function indirect) ∧ Dominated (function indirect) ∧ ArityOk (function indirect) ∧
      Stock.lower (function indirect) = .ok out.result ∧ prepareAt out.result.code out.result.edgeArgs = .ok out.prepared ∧
      out.rf = spillAllocAt out.prepared.code out.prepared.edges ∧
      checkAllocAt out.prepared.code out.prepared.edges out.rf = .ok () ∧ lowerRFunc out.prepared.code out.rf = .ok out.af ∧
      Stock.externCtor source.ctx T.put_in_regs_vec [.values (argumentsOf (function indirect).blocks[0]!.term)] before = .ok (requested,afterRequest) ∧
      Stock.externCtor source.ctx T.gen_call_args [.op (.sig (function indirect).sig),requested] afterRequest = .ok (uses,afterArgs) ∧
      (argumentsOf (function indirect).blocks[0]!.term).mapM source.ctx.valueReg? = some (ns.map fun n => Reg.vreg n .int) ∧
      sigParamBytes (function indirect).sig = .ok bytes ∧ sigArgLocs (function indirect).sig = .ok (locs,stack) ∧
      stack = (if indirect then 0 else 16) ∧
      uses = .op (.callArgs (retPairs (regPairsOf ((locs.zip ns).zip bytes)))) ∧
      afterArgs = {afterRequest with base.emitted := afterRequest.base.emitted ++
        ((stackEnts ((locs.zip ns).zip bytes)).map argStore).toArray} := by
  obtain ⟨out⟩ := pipeline indirect
  have order : blockOrder (function indirect) = .ok {
    nodes := #[.original 0,.original 1,.original 2],successors := #[#[2,1],#[],#[]]} := by cases indirect <;> cbv
  have sameOrder := Except.ok.inj ((stock_lower_order out.lowered).symm.trans order)
  have node : out.result.order.nodes[0]? = some (.original 0) := by rw [sameOrder]; rfl
  have block : (function indirect).blocks[0]? = some (function indirect).blocks[0]! := by cases indirect <;> rfl
  have isTry : (function indirect).blocks[0]!.term.isTry = true := by cases indirect <;> rfl
  have kind : sourceTable (function indirect).blocks[0]!.term = some (table indirect) := by cases indirect <;> rfl
  have decoded : exnTableOpnd (function indirect) (table indirect) = .ok ((function indirect).sig,[some 7]) := by cases indirect <;> rfl
  obtain ⟨source,⟨selected⟩⟩ := stock_lower_try_source_selection out.lowered out.scope node block isTry
  obtain ⟨before,afterRequest,afterArgs,requested,uses,ns,bytes,locs,stack,request,args,mapping,byteRun,locations,value,stores⟩ :=
    stock_selected_try_actual_argument_stores selected kind decoded
  have area : (sigArgLocs (function indirect).sig).map Prod.snd = .ok (if indirect then 0 else 16) := by
    cases indirect <;> rfl
  rw [locations] at area
  have exactArea : stack = (if indirect then 0 else 16) := Except.ok.inj area
  exact ⟨out,source,selected,before,afterRequest,afterArgs,requested,uses,ns,bytes,locs,stack,
    out.scope,out.dominated,out.arity,out.lowered,out.prepare,out.fallback,out.accepted,out.physical,
    request,args,mapping,byteRun,locations,exactArea,value,stores⟩
end Backend.Stock.Proof.TryArgumentsWitnessDraft
