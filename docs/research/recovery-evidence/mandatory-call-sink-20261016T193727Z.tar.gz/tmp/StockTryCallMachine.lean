import StockTryInfoArea
import StockTryResultMap
namespace Backend.Stock.Proof.TryCallMachineDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm
private theorem sem_ctor (ctx : Ctx) (t : Term) (vs : List V) (st : State) :
    (Stock.sem ctx).ctor t vs st = Stock.externCtor ctx t vs st := rfl
private theorem sem_mkData (ctx : Ctx) (ty k : Nat) (vs : List V) :
    (Stock.sem ctx).mkData ty k vs = .data ty k vs := rfl

private theorem sem_unData (ctx : Ctx) (ty : Nat) (v : V) :
    (Stock.sem ctx).unData ty v = (Backend.sem ctx).unData ty v := rfl

private theorem stock_internal_split_first {p : Program} {cfg : Config} {σ : Type} {sem : Isle.Sem V σ}
    (hc : cfg.checkOverlap = false) {ty : TypeId} {t : TermId} {vs : List V} {term : Term}
    {flags : TermFlags} {ex : Option Extractor} (ht : termOf p t = .ok term)
    (hk : term.kind = .decl flags (some .internal) ex) (hm : flags.isMulti = false)
    {n : Nat} (hn : 22 + (p.rulesOf t).length ≤ n) {s s' : σ × Array RuleId} {v : V}
    (h : ApplyInternal p sem cfg n ty t vs s v s') :
    ∃ pre r post, p.rulesOf t = pre ++ r :: post ∧
      (∀ r' ∈ pre, ∃ m' s1, (matchRule p sem cfg (m' + 20) r' vs).run s = .ok (none, s1)) ∧
      ∃ m' n' env s1 st tr,
      (matchRule p sem cfg (m' + 20) r vs).run s = .ok (some env, s1) ∧
      (evalExpr p sem cfg (n' + 20) r.rhs env).run s1 = .ok (some v, (st, tr)) ∧
      s' = (st, tr.push r.id) ∧ n = n' + 20 := by
  obtain ⟨r, pre, post, hL, hpre, m, env, s1, st, tr, hmn, hmt, he, rfl⟩ :=
    applyTerm_internal_some_first hc ht hk hm h
  obtain ⟨m', rfl⟩ : ∃ m', m = m' + 20 := ⟨m - 20, by omega⟩
  obtain ⟨n', rfl⟩ : ∃ n', n = n' + 20 := ⟨n - 20, by omega⟩
  refine ⟨pre, r, post, hL, fun r' hr' => ?_, m', n', env, s1, st, tr, hmt, he, rfl, rfl⟩
  obtain ⟨k, hk, s2, h2⟩ := hpre r' hr'
  obtain ⟨k', rfl⟩ : ∃ k', k = k' + 20 := ⟨k - 20, by omega⟩
  exact ⟨k', s2, h2⟩

private theorem stock_try_direct_machine {p : Program} (hp : Data p) {ctx : Ctx} {n : Nat}
    (enough : 30 ≤ n) {info : V} {before after : State × Array RuleId} {machine : V}
    (run : ApplyInternal p (Stock.sem ctx) {} n 46 638 [info] before machine after) :
    after.1 = before.1 ∧ machine = .data 46 0 [.data 58 109 [info]] := by
  have hc : ({} : Config).checkOverlap = false := rfl
  rcases before with ⟨st,tr⟩
  rcases after with ⟨next,trace⟩
  obtain ⟨_,_,_,hL,hpre,_,_,_,_,_,_,hm,he,stateEq,fuelEq⟩ :=
    stock_internal_split_first hc hp.t638 term_638_kind rfl (by rw [hp.r638]; simp; omega) run
  rcases Prod.mk.inj stateEq with ⟨rfl,rfl⟩
  cases fuelEq
  rw [hp.r638] at hL
  isel_rule_cases hL
  cases hp
  isel_inv [*,rule_inst_4780,sem_mkData,sem_unData] at hm he

private theorem stock_try_direct_emit {p : Program} (hp : Data p) {ctx : Ctx} {n : Nat}
    (enough : 30 ≤ n) {call : CallInfo} {before after : State × Array RuleId} {unit : V}
    (run : ApplyInternal p (Stock.sem ctx) {} n 13 242
      [.data 46 0 [.data 58 109 [.op (.callInfo call)]]] before unit after) :
    after.1 = {before.1 with base := before.1.base.emit (.call call)} ∧ unit = .op .unit := by
  have hc : ({} : Config).checkOverlap = false := rfl
  have emitted (st : State) : Stock.externCtor ctx T.emit [.data 58 109 [.op (.callInfo call)]] st =
      .ok (.op .unit,{st with base := st.base.emit (.call call)}) := by
    rw [stock_ctor_baseOnly _ _ _ _ (by decide),ctor_emit _ _ (ofV_call call)]
  rcases before with ⟨st,tr⟩
  rcases after with ⟨next,trace⟩
  obtain ⟨_,_,_,hL,hpre,_,_,_,_,_,_,hm,he,stateEq,fuelEq⟩ :=
    stock_internal_split_first hc hp.t242 term_242_kind rfl (by rw [hp.r242]; simp; omega) run
  rcases Prod.mk.inj stateEq with ⟨rfl,rfl⟩
  cases fuelEq
  rw [hp.r242] at hL
  isel_rule_cases hL
  all_goals cases hp
  · isel_inv [*,rule_prelude_lower_522,sem_ctor,sem_mkData,sem_unData,emitted] at hm he
    isel_destruct
    rename_i actual
    rw [emitted] at actual
    cases actual
    exact ⟨rfl,rfl⟩
  · isel_inv [*,rule_prelude_lower_524,sem_mkData,sem_unData] at hm
  · isel_inv [*,rule_prelude_lower_527,sem_mkData,sem_unData] at hm

private theorem stock_try_indirect_machine {p : Program} (hp : Data p) {ctx : Ctx} {n : Nat}
    (enough : 30 ≤ n) {info : V} {before after : State × Array RuleId} {machine : V}
    (run : ApplyInternal p (Stock.sem ctx) {} n 46 639 [info] before machine after) :
    after.1 = before.1 ∧ machine = .data 46 0 [.data 58 110 [info]] := by
  have hc : ({} : Config).checkOverlap = false := rfl
  rcases before with ⟨st,tr⟩
  rcases after with ⟨next,trace⟩
  obtain ⟨_,_,_,hL,hpre,_,_,_,_,_,_,hm,he,stateEq,fuelEq⟩ :=
    stock_internal_split_first hc hp.t639 term_639_kind rfl (by rw [hp.r639]; simp; omega) run
  rcases Prod.mk.inj stateEq with ⟨rfl,rfl⟩
  cases fuelEq
  rw [hp.r639] at hL
  isel_rule_cases hL
  cases hp
  isel_inv [*,rule_inst_4786,sem_mkData,sem_unData] at hm he

private theorem stock_try_indirect_emit {p : Program} (hp : Data p) {ctx : Ctx} {n : Nat}
    (enough : 30 ≤ n) {call : CallInfo} {before after : State × Array RuleId} {unit : V}
    (run : ApplyInternal p (Stock.sem ctx) {} n 13 242
      [.data 46 0 [.data 58 110 [.op (.callInfo call)]]] before unit after) :
    after.1 = {before.1 with base := before.1.base.emit (.call call)} ∧ unit = .op .unit := by
  have hc : ({} : Config).checkOverlap = false := rfl
  have emitted (st : State) : Stock.externCtor ctx T.emit [.data 58 110 [.op (.callInfo call)]] st =
      .ok (.op .unit,{st with base := st.base.emit (.call call)}) := by
    rw [stock_ctor_baseOnly _ _ _ _ (by decide),ctor_emit _ _ (ofV_callInd call)]
  rcases before with ⟨st,tr⟩
  rcases after with ⟨next,trace⟩
  obtain ⟨_,_,_,hL,hpre,_,_,_,_,_,_,hm,he,stateEq,fuelEq⟩ :=
    stock_internal_split_first hc hp.t242 term_242_kind rfl (by rw [hp.r242]; simp; omega) run
  rcases Prod.mk.inj stateEq with ⟨rfl,rfl⟩
  cases fuelEq
  rw [hp.r242] at hL
  isel_rule_cases hL
  all_goals cases hp
  · isel_inv [*,rule_prelude_lower_522,sem_ctor,sem_mkData,sem_unData,emitted] at hm he
    isel_destruct
    rename_i actual
    rw [emitted] at actual
    cases actual
    exact ⟨rfl,rfl⟩
  · isel_inv [*,rule_prelude_lower_524,sem_mkData,sem_unData] at hm
  · isel_inv [*,rule_prelude_lower_527,sem_mkData,sem_unData] at hm


open TryRhsCallsDraft TryHelperFramesDraft TryInfoAreaDraft TryResultMapDraft
/-- The actual direct RHS emits the call carrying the SAME helper's reserved
return/payload definitions, rather than a separately replayed helper. -/
theorem stock_direct_try_actual_emitted_defs {p : Program} (hp : Data p) {ctx : Ctx}
    {args : List Nat} {sig : Clif.Signature} {name : String} {items : List (Option Nat)}
    {labels : List Label} {st next : State} {tr trace : Array RuleId} {out : V}
    (calls : DirectTryCalls p ctx args sig name items labels st next tr trace out) :
    ∃ (call : CallInfo) (before after : State),
      Stock.externCtor ctx T.gen_try_call_rets [.op (.sig sig)] before =
        .ok (.op (.callRets call.defs),after) ∧
      call.dest = .sym name ∧ next.base.emitted.back? = some (.call call) := by
  obtain ⟨abi,afterAbi,tryValue,afterTry,requested,afterRequest,uses,afterArgs,defs,afterDefs,
    callInfo,afterInfo,machine,afterMachine,machineTrace,callFuel,emitFuel,
    abiCall,tryCall,requestCall,argsCall,retsCall,infoCall,callBound,emitBound,callRun,emitRun⟩ := calls
  obtain ⟨same,_⟩ := stock_try_abi_identity abiCall
  subst abi
  obtain ⟨locs,area,us,ds,locations,usesEq,defsEq,infoEq,frame⟩ := stock_try_direct_info_area infoCall
  rw [infoEq] at callRun
  obtain ⟨machineState,machineValue⟩ := stock_try_direct_machine hp callBound callRun
  rw [machineValue] at emitRun
  obtain ⟨emitted,_⟩ := stock_try_direct_emit hp emitBound emitRun
  rw [defsEq] at retsCall
  refine ⟨⟨.sym name,us,ds⟩,afterArgs,afterDefs,retsCall,rfl,?_⟩
  dsimp only at emitted
  rw [emitted]
  simp only [LState.emit,Array.back?_push]
/-- Actual indirect RHS likewise binds the SAME reserved helper output to the
last emitted call's definitions and its actual requested target register. -/
theorem stock_indirect_try_actual_emitted_defs {p : Program} (hp : Data p) {ctx : Ctx}
    {callee : Nat} {args : List Nat} {sig : Clif.Signature} {items : List (Option Nat)}
    {labels : List Label} {st next : State} {tr trace : Array RuleId} {out : V}
    (calls : IndirectTryCalls p ctx callee args sig items labels st next tr trace out) :
    ∃ (call : CallInfo) (before after : State) (r : Reg),
      Stock.externCtor ctx T.gen_try_call_rets [.op (.sig sig)] before =
        .ok (.op (.callRets call.defs),after) ∧
      call.dest = .reg r ∧ next.base.emitted.back? = some (.call call) := by
  obtain ⟨abi,afterAbi,tryValue,afterTry,target,afterTarget,requested,afterRequest,uses,afterArgs,defs,afterDefs,
    callInfo,afterInfo,machine,afterMachine,machineTrace,callFuel,emitFuel,
    abiCall,tryCall,targetCall,requestCall,argsCall,retsCall,infoCall,callBound,emitBound,callRun,emitRun⟩ := calls
  obtain ⟨same,_⟩ := stock_try_abi_identity abiCall
  subst abi
  obtain ⟨locs,area,r,us,ds,locations,targetEq,usesEq,defsEq,infoEq,frame⟩ := stock_try_indirect_info_area infoCall
  rw [infoEq] at callRun
  obtain ⟨machineState,machineValue⟩ := stock_try_indirect_machine hp callBound callRun
  rw [machineValue] at emitRun
  obtain ⟨emitted,_⟩ := stock_try_indirect_emit hp emitBound emitRun
  rw [defsEq] at retsCall
  refine ⟨⟨.reg r,us,ds⟩,afterArgs,afterDefs,r,retsCall,rfl,?_⟩
  dsimp only at emitted
  rw [emitted]
  simp only [LState.emit,Array.back?_push]
/-- Actual GOT RHS preserves its reserved helper definition vector through the
symbol load and indirect call construction, into the call actually emitted. -/
theorem stock_got_try_actual_emitted_defs {p : Program} (hp : Data p) {ctx : Ctx}
    {args : List Nat} {sig : Clif.Signature} {name : String} {distance : V} {items : List (Option Nat)}
    {labels : List Label} {st next : State} {tr trace : Array RuleId} {out : V}
    (calls : GotTryCalls p ctx args sig name distance items labels st next tr trace out) :
    ∃ (call : CallInfo) (before after : State) (r : Reg),
      Stock.externCtor ctx T.gen_try_call_rets [.op (.sig sig)] before =
        .ok (.op (.callRets call.defs),after) ∧
      call.dest = .reg r ∧ next.base.emitted.back? = some (.call call) := by
  obtain ⟨abi,afterAbi,tryValue,afterTry,requested,afterRequest,uses,afterArgs,defs,afterDefs,
    boxed,afterBox,target,afterTarget,targetTrace,callInfo,afterInfo,machine,afterMachine,machineTrace,
    loadFuel,callFuel,emitFuel,abiCall,tryCall,requestCall,argsCall,retsCall,boxCall,loadBound,loadRun,
    infoCall,callBound,emitBound,callRun,emitRun⟩ := calls
  obtain ⟨same,_⟩ := stock_try_abi_identity abiCall
  subst abi
  obtain ⟨locs,area,r,us,ds,locations,targetEq,usesEq,defsEq,infoEq,frame⟩ := stock_try_indirect_info_area infoCall
  rw [infoEq] at callRun
  obtain ⟨machineState,machineValue⟩ := stock_try_indirect_machine hp callBound callRun
  rw [machineValue] at emitRun
  obtain ⟨emitted,_⟩ := stock_try_indirect_emit hp emitBound emitRun
  rw [defsEq] at retsCall
  refine ⟨⟨.reg r,us,ds⟩,afterArgs,afterDefs,r,retsCall,rfl,?_⟩
  dsimp only at emitted
  rw [emitted]
  simp only [LState.emit,Array.back?_push]
end Backend.Stock.Proof.TryCallMachineDraft
