import StockTryCallMachine
import StockTryFinalReturnValues
namespace Backend.Stock.Proof.TrySelectedEmissionDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open TrySourceContextDraft TryBranchSelectionDraft TrySelectedCallsDraft TryBranchAbiDraft TryCallMachineDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private theorem actual_call {f : Clif.Function} {result : Result} {label bi : Nat} {b : Clif.Block}
    {source : TryBranchSource f result label bi b} (selected : TryBranchSelection source)
    {et : Clif.ExnTable} {sig : Clif.Signature} {items : List (Option Nat)}
    (kind : sourceTable b.term = some et) (table : exnTableOpnd f et = .ok (sig,items)) :
    ∃ (call : CallInfo) (before after : State),
      Stock.externCtor source.ctx T.gen_try_call_rets [.op (.sig sig)] before = .ok (.op (.callRets call.defs),after) ∧
      selected.next.base.emitted.back? = some (.call call) := by
  cases term : b.term <;> simp only [sourceTable,term] at kind
  all_goals try contradiction
  case tryCall fn args et' =>
    cases kind
    obtain ⟨sig',items',ext,decoded,external,signature,data⟩ := stock_try_source_direct_data source term
    have same := congrArg Prod.fst (Except.ok.inj (decoded.symm.trans table))
    have extSig : ext.sig = sig := signature.trans same
    cases near : ext.colocated with
    | true =>
      obtain ⟨_,_,_,_,_,_,calls⟩ := stock_selected_try_direct_rhs_calls selected term external near
      obtain ⟨call,before,after,helper,target,raw⟩ := stock_direct_try_actual_emitted_defs data_program calls
      rw [extSig] at helper
      exact ⟨call,before,after,helper,raw⟩
    | false =>
      obtain ⟨_,_,_,_,_,_,calls⟩ := stock_selected_try_got_rhs_calls selected term external near
      obtain ⟨call,before,after,r,helper,target,raw⟩ := stock_got_try_actual_emitted_defs data_program calls
      rw [extSig] at helper
      exact ⟨call,before,after,helper,raw⟩
  case tryCallIndirect callee args et' =>
    cases kind
    obtain ⟨sig',items',decoded,rule,env,matched,trace,calls⟩ := stock_selected_try_indirect_rhs_calls selected term
    have same := congrArg Prod.fst (Except.ok.inj (decoded.symm.trans table))
    obtain ⟨call,before,after,r,helper,target,raw⟩ := stock_indirect_try_actual_emitted_defs data_program calls
    change sig' = sig at same
    rw [same] at helper
    exact ⟨call,before,after,helper,raw⟩

/-- The real selected RHS and actual branch replacement share one call and its
SAME reserved helper definitions. Original source/table facts select all forms
internally, with no caller call-emission or definition certificate. -/
theorem stock_selected_try_actual_emission {f : Clif.Function} {result : Result} {label bi : Nat} {b : Clif.Block}
    {source : TryBranchSource f result label bi b} (selected : TryBranchSelection source)
    {et : Clif.ExnTable} {sig : Clif.Signature} {items : List (Option Nat)}
    (kind : sourceTable b.term = some et) (table : exnTableOpnd f et = .ok (sig,items)) :
    ∃ (call : CallInfo) (before after : State) (info : TryInfo),
      Stock.externCtor source.ctx T.gen_try_call_rets [.op (.sig sig)] before = .ok (.op (.callRets call.defs),after) ∧
      tryInfoOf sig items result.order.successors[label]!.toList = some info ∧
      info.rets = (sigRets sig).length ∧
      selected.next.base.emitted.back? = some (.call call) ∧
      source.branch.step.emitted.back? = some (.tryCall call {info with rets := sig.returns.length}) := by
  obtain ⟨call,before,after,helper,raw⟩ := actual_call selected kind table
  have isTry : b.term.isTry = true := by
    cases term : b.term <;> simp only [sourceTable,term] at kind
    all_goals first | contradiction | rfl
  obtain ⟨et',sig',items',info,actual,sourceTableEq,decoded,metadata,count,last,branch⟩ :=
    stock_selected_try_explicit_abi selected isTry
  have equalTable : et' = et := Option.some.inj (sourceTableEq.symm.trans kind)
  subst et'
  have same := Except.ok.inj (decoded.symm.trans table)
  cases same
  have equalCall : actual = call := by
    have same := Option.some.inj (last.symm.trans raw)
    cases same
    rfl
  subst actual
  exact ⟨call,before,after,info,helper,metadata,count,raw,branch⟩
end Backend.Stock.Proof.TrySelectedEmissionDraft
