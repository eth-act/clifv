import StockTryWholeEmission
import StockTryNearFixture
import FV.Backend.Proof.PerEdgeSpillEntryFixture
namespace Backend.Stock.Proof.TryEmittedWitnessDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open TryWholeEmissionDraft TrySourceContextDraft TryBranchSelectionDraft TryBranchAbiDraft
open TryResultMapDraft TryRetsTotalDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
inductive Kind where | near | got | indirect
  deriving DecidableEq,Repr
private def function : Kind → Clif.Function
  | .near => TryNearFixtureDraft.function false
  | .got => SpillEntryFixture.function false
  | .indirect => SpillEntryFixture.function true
private def entry (k : Kind) := (function k).blocks[0]!
private def table : Clif.ExnTable := {
  sig := 0,normal := ⟨1,[.ret 0,.val 0]⟩,items := [.tag 7 ⟨2,[.exn 0,.exn 1,.val 0]⟩] }
private structure Fixture (k : Kind) where
  result : Result
  prepared : EdgeVCode
  rf : RFunc
  af : AFunc
  lowered : Stock.lower (function k) = .ok result
  scope : LowerScope (function k)
  dominated : Dominated (function k)
  arity : ArityOk (function k)
  prepare : prepareAt result.code result.edgeArgs = .ok prepared
  fallback : rf = spillAllocAt prepared.code prepared.edges
  accepted : checkAllocAt prepared.code prepared.edges rf = .ok ()
  physical : lowerRFunc prepared.code rf = .ok af
private theorem fixture (k : Kind) : Nonempty (Fixture k) := by
  cases k with
  | near =>
    obtain ⟨out⟩ := TryNearFixtureDraft.stock_near_try_fixture
    exact ⟨⟨out.result,out.prepared,out.rf,out.af,out.lowered,out.scope,out.dominated,out.arity,
      out.prepare,out.fallback,out.accepted,out.physical⟩⟩
  | got =>
    obtain ⟨out⟩ := SpillEntryFixture.try_fixture false
    exact ⟨⟨out.result,out.prepared,out.rf,out.af,out.lowered,out.scope,out.dominated,out.arity,
      out.prepare,out.fallback,out.accepted,out.physical⟩⟩
  | indirect =>
    obtain ⟨out⟩ := SpillEntryFixture.try_fixture true
    exact ⟨⟨out.result,out.prepared,out.rf,out.af,out.lowered,out.scope,out.dominated,out.arity,
      out.prepare,out.fallback,out.accepted,out.physical⟩⟩
private theorem order (k : Kind) : blockOrder (function k) = .ok {
    nodes := #[.original 0,.original 1,.original 2],successors := #[#[2,1],#[],#[]]} := by cases k <;> cbv
private theorem held : PrefixHold [⟨.i64,17⟩] ([17,99] : List CV) := by
  refine ⟨by decide,?_⟩
  intro j v x atValue atOut
  cases j with
  | zero => cases atValue; cases atOut; rfl
  | succ j => simp at atValue
/-- Complete original-condition colocated, GOT and true indirect compiler,
prepare, forced checked fallback and physical pipelines exercise actual emitted
TryCall/helper definition identity and normal values through final aliases. -/
theorem stock_complete_try_emitted_result_values_witness (k : Kind) :
    ∃ (out : Fixture k) (source : TryBranchSource (function k) out.result 0 0 (entry k))
      (_selected : TryBranchSelection source) (base : Nat) (call : CallInfo) (info : TryInfo)
      (before after : State),
      LowerScope (function k) ∧ Dominated (function k) ∧ ArityOk (function k) ∧
      Stock.lower (function k) = .ok out.result ∧ prepareAt out.result.code out.result.edgeArgs = .ok out.prepared ∧
      out.rf = spillAllocAt out.prepared.code out.prepared.edges ∧
      checkAllocAt out.prepared.code out.prepared.edges out.rf = .ok () ∧ lowerRFunc out.prepared.code out.rf = .ok out.af ∧
      Stock.externCtor source.ctx T.gen_try_call_rets [.op (.sig (function k).sig)] before =
        .ok (.op (.callRets call.defs),after) ∧
      call.defs = callDefs (resultDefs base 1) ∧
      source.branch.step ∈ out.result.schedule.toList ∧
      source.branch.step.emitted.back? = some (.tryCall call {info with rets := 1}) ∧
      ∀ ρ : Nat → CV,VHolds ⟨.i64,17⟩ (writeV ρ ((callDefOps (resultDefs base 1)).zip [17,99])
        (aliasNum out.result.final.alias base)) := by
  obtain ⟨out⟩ := fixture k
  have sameOrder := Except.ok.inj ((stock_lower_order out.lowered).symm.trans (order k))
  have node : out.result.order.nodes[0]? = some (.original 0) := by rw [sameOrder]; rfl
  have block : (function k).blocks[0]? = some (entry k) := by cases k <;> rfl
  have input : Prg.iselInB (function k) = true := by cases k <;> decide +kernel
  have kind : sourceTable (entry k).term = some table := by cases k <;> rfl
  have decoded : exnTableOpnd (function k) table = .ok ((function k).sig,[some 7]) := by cases k <;> rfl
  obtain ⟨source,selected,base,call,info,before,after,layout,helper,defs,metadata,abiCount,scheduled,emitted,values⟩ :=
    stock_lower_original_try_emitted_result_values out.lowered out.scope input node block kind decoded
  have count : (function k).sig.returns.length = 1 := by cases k <;> rfl
  rw [count] at defs emitted values
  exact ⟨out,source,selected,base,call,info,before,after,out.scope,out.dominated,out.arity,out.lowered,
    out.prepare,out.fallback,out.accepted,out.physical,helper,defs,scheduled,emitted,
    fun ρ => values ρ _ _ held rfl rfl 0 ⟨.i64,17⟩ rfl⟩
end Backend.Stock.Proof.TryEmittedWitnessDraft
