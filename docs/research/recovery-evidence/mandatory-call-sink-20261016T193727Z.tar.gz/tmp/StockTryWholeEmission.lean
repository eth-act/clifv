import StockTrySelectedEmission
namespace Backend.Stock.Proof.TryWholeEmissionDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open TrySourceContextDraft TryBranchSelectionDraft TrySelectedEmissionDraft TryBranchAbiDraft
open TryWholeSourceReservationDraft TryRetsTotalDraft TryResultMapDraft TryFinalReturnValuesDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
/-- Actual whole lowering derives the original branch, SAME helper/call defs,
real retained TryCall and normal return values through final aliases internally.
No caller-selected result map, emitted instruction, allocation invariant or
alias endpoint is added to the original accepted-input conditions. -/
theorem stock_lower_original_try_emitted_result_values {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f) (input : Prg.iselInB f = true)
    {label bi : Nat} {b : Clif.Block} (node : result.order.nodes[label]? = some (.original bi))
    (block : f.blocks[bi]? = some b) {et : Clif.ExnTable} {sig : Clif.Signature} {items : List (Option Nat)}
    (kind : sourceTable b.term = some et) (table : exnTableOpnd f et = .ok (sig,items)) :
    ∃ (source : TryBranchSource f result label bi b) (_selected : TryBranchSelection source)
      (base : Nat) (call : CallInfo) (info : TryInfo) (before after : State),
      result.initial.tryRegs[source.ti]! = (reservedReturns base sig.returns.length,reservedPayloads base sig.returns.length) ∧
      Stock.externCtor source.ctx T.gen_try_call_rets [.op (.sig sig)] before = .ok (.op (.callRets call.defs),after) ∧
      call.defs = callDefs (resultDefs base sig.returns.length) ∧
      tryInfoOf sig items result.order.successors[label]!.toList = some info ∧ info.rets = (sigRets sig).length ∧
      source.branch.step ∈ result.schedule.toList ∧
      source.branch.step.emitted.back? = some (.tryCall call {info with rets := sig.returns.length}) ∧
      ∀ (ρ : Nat → CV) (values : List Clif.Val) (outs : List CV),PrefixHold values outs →
        values.length = sig.returns.length → outs.length = max sig.returns.length 2 →
        ∀ (j : Nat) (v : Clif.Val),values[j]? = some v →
          VHolds v (writeV ρ ((callDefOps (resultDefs base sig.returns.length)).zip outs)
            (aliasNum result.final.alias (base+j))) := by
  obtain ⟨ranges,source,selected,base,replay,replayAfter,build,allocation,slots,replayRun,frame⟩ :=
    stock_lower_original_try_reservation lowered scope input node block kind table
  obtain ⟨call,before,after,info,helper,metadata,count,raw,emitted⟩ :=
    stock_selected_try_actual_emission selected kind table
  have layout : result.initial.tryRegs[source.ti]! = (reservedReturns base sig.returns.length,reservedPayloads base sig.returns.length) := by
    rw [← allocation.2]
    exact source.tryRegs.symm.trans slots
  have bound : sig.returns.length ≤ 8 := by
    obtain ⟨ps,returns,rest⟩ := TryRetsShapeDraft.stock_try_rets_exact_shape helper
    by_cases inside : sig.returns.length ≤ 8
    · exact inside
    · simp only [retRegs,if_neg inside] at returns
      cases returns
  have exactDefs := stock_try_reserved_result_defs helper base bound (exnTableOpnd_cc table) slots
  have defs : call.defs = callDefs (resultDefs base sig.returns.length) := by
    simpa only [V.op.injEq,Opnd.callRets.injEq] using exactDefs
  refine ⟨source,selected,base,call,info,before,after,layout,helper,defs,metadata,count,source.scheduled,emitted,?_⟩
  intro ρ values outs held results length j v atValue
  exact stock_lower_try_normal_reserved_values lowered layout ρ held results length atValue
end Backend.Stock.Proof.TryWholeEmissionDraft
