import FV.Backend.Proof.StockLogicalNotRecordWitness
import FV.Backend.Proof.StockLogicalSourceWitness
open Lean Elab Command
run_cmd do
  let env ← getEnv
  for (name,_) in env.constants.toList do
    let s := name.toString
    if !s.startsWith "_private." then continue
    if (s.splitOn "StockLogicalNotRecordWitness").length > 1 &&
        #[".inputs", ".dominated", ".function", ".frame", ".frame_available", ".regs", ".scope"].any (fun (suffix : String) => s.endsWith suffix) then
      logInfo m!"WITNESS_NAME {s}"
    if (s.splitOn "StockLogicalSourceWitness").length > 1 &&
        #[".rrDominated", ".rrFrame", ".rrRestricted"].any (fun (suffix : String) => s.endsWith suffix) then
      logInfo m!"WITNESS_NAME {s}"
