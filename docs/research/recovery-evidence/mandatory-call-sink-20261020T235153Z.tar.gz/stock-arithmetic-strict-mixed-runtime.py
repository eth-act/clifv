from pathlib import Path
import os,signal,subprocess as sp,json,hashlib,datetime
root=Path('/home/lee/clifv/.worktrees/stock-mixed-production');out=Path('/tmp/stock-arithmetic-strict-mixed-runtime');out.mkdir(exist_ok=True);port=1946126;sched=1763255
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();source=root/'FVTest/Backend/Lowering/StockArithmeticRuntime.lean';assert sha(source)=='b00043a15c8616e6b4b78bfa2d24634eeacb825bbd75d56db6aa1b1626641b1c'
head=sp.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert head=='1aec0d40e68119e545dbd59c64b334e526f92799'
old=source.read_text();needle='import FV.E2E.StockArithmeticNIWitness\n';assert old.count(needle)==1;code=old.replace(needle,'import FV.E2E.StockProductionFixtures\n');runtime=out/'StockArithmeticStrictMixedRuntime.lean';runtime.write_text(code)
assert Path(f'/proc/{port}/cmdline').read_bytes().split(b'\0')[1]==b'/tmp/stock-mixed-normal-modules-batch52.py'
stopped=False
try:
 os.kill(port,signal.SIGSTOP);stopped=True
 assert Path(f'/proc/{sched}/stat').read_text().split()[2]=='T'
 kids=Path(f'/proc/{sched}/task/{sched}/children').read_text().split();live=[k for k in kids if Path(f'/proc/{k}/stat').exists() and Path(f'/proc/{k}/stat').read_text().split()[2]!='Z'];assert not live
 env=dict(os.environ,PATH='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:'+os.environ['PATH'],FV_MEMCAP='4G',FV_LAKE_CACHE='/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache',LEAN_NUM_THREADS='2',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2')
 imports=[l.split()[1] for l in code.splitlines() if l.startswith('import ')]
 with (out/'imports.log').open('w') as f:r=sp.run([str(root/'scripts/memcap.sh'),'lake','build','--no-build',*imports],cwd=root,env=env,stdout=f,stderr=sp.STDOUT)
 assert r.returncode==0,('strict runtime imports not current',str(out/'imports.log'))
 with (out/'runtime.log').open('w') as f:r=sp.run([str(root/'scripts/memcap.sh'),'lake','env','lean','--root='+str(out),'--run',str(runtime)],cwd=root,env=env,stdout=f,stderr=sp.STDOUT)
 assert r.returncode==0,('strict runtime failed',r.returncode,str(out/'runtime.log'))
 text=(out/'runtime.log').read_text();assert text.count('Stock arithmetic lean ')==6 and text.count('Stock arithmetic regalloc2 ')==6 and 'Stock arithmetic missing-binary negative control passed' in text
 assert sha(source)=='b00043a15c8616e6b4b78bfa2d24634eeacb825bbd75d56db6aa1b1626641b1c' and sp.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head
 j={'state':'strict_arithmetic_runtime_passed_in_mixed_view','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'source_sha256':sha(source),'generated_runtime_sha256':sha(runtime),'only_source_change':'proof-witness import replaced by existing fixture data module; exact same public function constant and runtime assertions','case_grid':24,'positive_real_oracle_required':True,'missing_binary_negative_control_passed':True,'regalloc_binary_sha256':sha(root/'rust/target/release/lean-regalloc'),'log':str(out/'runtime.log'),'log_sha256':sha(out/'runtime.log'),'primary_activation_gate_pass_claim':False,'normal_checked_in_module_pass_claim':False,'remaining':'Normal-build checked-in runtime/witness module; exact primary213 strict run and all per-PR gates before arithmetic landing','cap_GiB':4,'aggregate_cap_GiB':8,'max_compiler_jobs':2}
 (out/'receipt.json').write_text(json.dumps(j,indent=2)+'\n');print(json.dumps(j),flush=True)
finally:
 if stopped:os.kill(port,signal.SIGCONT)
 print('port launcher resumed; it owns author scheduler resume after its proof completes',flush=True)
