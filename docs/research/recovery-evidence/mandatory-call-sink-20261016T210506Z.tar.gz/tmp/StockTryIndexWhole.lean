import StockTryIndexControl
import FV.Backend.Proof.StockOutgoingOrigin
namespace Backend.Stock.Proof.TryIndexWholeDraft
open Backend.Proof Backend.Proof.Driver TryIndexFrameDraft TryIndexControlDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
attribute [local irreducible] Stock.runTerm lowerBlockCore branchArgs emitBranch collectOutgoing scanBlock
private theorem node_install {ctx : Ctx} {ranges : Array (Nat × Nat)} {order : Order}
    {f : Clif.Function} {params : List Nat} {label : Nat} {input output : DriverState}
    (run : lowerNode ctx ranges order f params label input = .ok output) :
    ∃ block, output.edgeArgs = input.edgeArgs.set! label block := by
  unfold lowerNode at run
  dsimp only at run
  repeat' first
    | (solve | cases run)
    | simp only [bind, Except.bind, pure, Except.pure] at run
    | split at run
  all_goals
    cases run
    exact ⟨_,rfl⟩

private theorem node_size {ctx : Ctx} {ranges : Array (Nat × Nat)} {order : Order}
    {f : Clif.Function} {params : List Nat} {label : Nat} {input output : DriverState}
    (run : lowerNode ctx ranges order f params label input = .ok output) :
    output.edgeArgs.size = input.edgeArgs.size := by
  obtain ⟨block,installed⟩ := node_install run
  rw [installed]
  simp

private theorem node_frame {ctx : Ctx} {ranges : Array (Nat × Nat)} {order : Order}
    {f : Clif.Function} {params : List Nat} {label other : Nat} {input output : DriverState}
    (run : lowerNode ctx ranges order f params label input = .ok output) (different : other ≠ label) :
    output.edgeArgs[other]? = input.edgeArgs[other]? := by
  obtain ⟨block,installed⟩ := node_install run
  rw [installed]
  simp [Array.getElem?_setIfInBounds,Ne.symm different]

private theorem nodes_size {ctx : Ctx} {ranges : Array (Nat × Nat)} {order : Order}
    {f : Clif.Function} {params labels : List Nat} {input output : DriverState}
    (run : labels.foldlM (fun d k => lowerNode ctx ranges order f params k d) input = .ok output) :
    output.edgeArgs.size = input.edgeArgs.size := by
  induction labels generalizing input with
  | nil => cases run; rfl
  | cons label rest ih =>
    rw [List.foldlM_cons] at run
    cases call : lowerNode ctx ranges order f params label input with
    | error e => simp only [call,bind,Except.bind] at run; cases run
    | ok middle =>
      simp only [call,bind,Except.bind] at run
      exact (ih run).trans (node_size call)

private theorem nodes_frame {ctx : Ctx} {ranges : Array (Nat × Nat)} {order : Order}
    {f : Clif.Function} {params labels : List Nat} {other : Nat} {input output : DriverState}
    (run : labels.foldlM (fun d k => lowerNode ctx ranges order f params k d) input = .ok output)
    (different : ∀ k ∈ labels,other ≠ k) : output.edgeArgs[other]? = input.edgeArgs[other]? := by
  induction labels generalizing input with
  | nil => cases run; rfl
  | cons label rest ih =>
    rw [List.foldlM_cons] at run
    cases call : lowerNode ctx ranges order f params label input with
    | error e => simp only [call,bind,Except.bind] at run; cases run
    | ok middle =>
      simp only [call,bind,Except.bind] at run
      exact (ih run (fun k member => different k (List.mem_cons_of_mem _ member))).trans
        (node_frame call (different label (by simp)))

private def startDriver (initial : State) (n : Nat) : DriverState := {
  state := initial,blocks := Array.replicate n default,edgeArgs := Array.replicate n #[],
  schedule := #[],scans := #[],blockScans := #[],rules := #[] }

private theorem lower_code_origin {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) :
    ∃ (ranges : Array (Nat × Nat)) (params : List Nat) (driver : DriverState),
      Stock.buildCtx f = .ok (result.ctx,ranges,result.initial) ∧
      blockOrder f = .ok result.order ∧
      (Array.range result.order.nodes.size).reverse.toList.foldlM
        (fun d k => lowerNode result.ctx ranges result.order f params k d)
        (startDriver result.initial result.order.nodes.size) = .ok driver ∧
      result.blockScans = driver.blockScans ∧ result.final = driver.state ∧
      result.edgeArgs = driver.edgeArgs.map (fun args => args.map (fun rs =>
        rs.map (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1)))) := by
  unfold Stock.lower at run
  dsimp only at run
  repeat' first
    | (solve | cases run)
    | simp only [bind,Except.bind,pure,Except.pure] at run
    | split at run
  cases run
  exact ⟨_,_,_,by assumption,by assumption,by assumption,rfl,rfl,rfl⟩


private theorem node_origin {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) {label : Nat} (bound : label < result.order.nodes.size) :
    ∃ (ranges : Array (Nat × Nat)) (params : List Nat) (input output : DriverState),
      Stock.buildCtx f = .ok (result.ctx,ranges,result.initial) ∧
      input.state.instBlock = result.initial.instBlock ∧ input.state.tryRegs = result.initial.tryRegs ∧
      label < input.edgeArgs.size ∧
      lowerNode result.ctx ranges result.order f params label input = .ok output ∧
      result.edgeArgs[label]? = (output.edgeArgs[label]?).map (fun args => args.map (fun rs =>
        rs.map (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1)))) := by
  obtain ⟨ranges,params,driver,build,ordered,folded,events,final,vectors⟩ := lower_code_origin run
  have member : label ∈ (Array.range result.order.nodes.size).reverse.toList := by simpa using bound
  obtain ⟨earlier,suffix,parts,noEarlier⟩ := List.eq_append_cons_of_mem member
  rw [parts,List.foldlM_append] at folded
  cases first : earlier.foldlM (fun d k => lowerNode result.ctx ranges result.order f params k d)
      (startDriver result.initial result.order.nodes.size) with
  | error e => simp only [first,bind,Except.bind] at folded; cases folded
  | ok before =>
    simp only [first,bind,Except.bind] at folded
    rw [List.foldlM_cons] at folded
    cases step : lowerNode result.ctx ranges result.order f params label before with
    | error e => simp only [step,bind,Except.bind] at folded; cases folded
    | ok after =>
      simp only [step,bind,Except.bind] at folded
      have beforeBound : label < before.edgeArgs.size := by
        rw [nodes_size first]
        simpa only [startDriver,Array.size_replicate] using bound
      have finalVector : driver.edgeArgs[label]? = after.edgeArgs[label]? := by
        rw [nodes_frame folded]
        intro k member
        rw [(stock_backward_suffix_split parts).2] at member
        have small : k < label := by simpa using member
        omega
      have metadata : before.state.instBlock = result.initial.instBlock := stock_nodes_instBlock first
      have empty : result.initial.alias = #[] := by
        obtain ⟨original,st0,requests,oldBuild,requestRun,same⟩ := buildCtx_allocation build
        exact congrArg (fun q : Ctx × Array (Nat × Nat) × State => q.2.2.alias) same
      have allocation := stock_lowerNodes_allocationBounds build
        (input := startDriver result.initial result.order.nodes.size)
        ⟨by change result.initial.alias.size ≤ result.initial.base.nextVreg; rw [empty]; exact Nat.zero_le _,Nat.le_refl _,rfl⟩ first
      exact ⟨ranges,params,before,after,build,metadata,allocation.2.2,beforeBound,step,
        by simp only [vectors,Array.getElem?_map,finalVector]⟩


/-- The full actual driver retains its original instruction-to-block table. -/
theorem stock_lower_instBlock {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) : result.final.instBlock = result.initial.instBlock := by
  obtain ⟨ranges,params,driver,build,ordered,folded,events,final,vectors⟩ := lower_code_origin run
  rw [final]
  exact stock_nodes_instBlock folded
/-- At an actual original node, both source metadata and reservation tables
still equal their actual initial build values. The node run is retained for
subsequent branch/outgoing composition, without a caller state certificate. -/
theorem stock_lower_original_node_metadata {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) {label bi : Nat}
    (tag : result.order.nodes[label]? = some (.original bi)) :
    ∃ (ranges : Array (Nat × Nat)) (params : List Nat) (input output : DriverState),
      Stock.buildCtx f = .ok (result.ctx,ranges,result.initial) ∧
      input.state.instBlock = result.initial.instBlock ∧ input.state.tryRegs = result.initial.tryRegs ∧
      lowerNode result.ctx ranges result.order f params label input = .ok output := by
  obtain ⟨ranges,params,input,output,build,metadata,reservations,bound,node,stored⟩ :=
    node_origin run (Array.getElem?_eq_some_iff.mp tag).1
  exact ⟨ranges,params,input,output,build,metadata,reservations,node⟩
/-- Actual critical-edge argument collection reads the original source metadata
and reserved table, even after all preceding real block/scan transitions. The
returned resolved vector is the one installed by this SAME collection. -/
theorem stock_lower_critical_argument_metadata {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) {label pred index target : Nat}
    (tag : result.order.nodes[label]? = some (.edge pred index target)) :
    ∃ (ranges : Array (Nat × Nat)) (input next : State) (args : Array Reg),
      Stock.buildCtx f = .ok (result.ctx,ranges,result.initial) ∧
      branchArgs result.ctx input pred index = .ok (args,next) ∧
      input.instBlock = result.initial.instBlock ∧ input.tryRegs = result.initial.tryRegs ∧
      next.instBlock = result.initial.instBlock ∧
      input.tryRegs[(input.instBlock.findIdx? (· == pred)).getD 0 + result.ctx.func.blocks[pred]!.body.length]! =
        result.initial.tryRegs[(result.initial.instBlock.findIdx? (· == pred)).getD 0 + result.ctx.func.blocks[pred]!.body.length]! ∧
      result.edgeArgs[label]? = some #[args.map
        (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1))] := by
  obtain ⟨ranges,params,input,output,build,metadata,reservations,bound,nodeRun,stored⟩ :=
    node_origin run (Array.getElem?_eq_some_iff.mp tag).1
  have node : result.order.nodes[label]! = .edge pred index target := by simp [getElem!_def,tag]
  unfold lowerNode at nodeRun
  simp only [node] at nodeRun
  cases call : branchArgs result.ctx input.state pred index with
  | error e => simp only [call,bind,Except.bind] at nodeRun; cases nodeRun
  | ok pair =>
    obtain ⟨args,next⟩ := pair
    simp only [call,bind,Except.bind] at nodeRun
    cases nodeRun
    dsimp only at stored
    rw [Array.set!_eq_setIfInBounds,Array.getElem?_setIfInBounds_self_of_lt bound] at stored
    refine ⟨ranges,input.state,next,args,build,call,metadata,reservations,
      (stock_branchArgs_instBlock call).trans metadata,?_,?_⟩
    · rw [metadata,reservations]
    · simpa only [Option.map_some,Array.map_singleton] using stored
end Backend.Stock.Proof.TryIndexWholeDraft
