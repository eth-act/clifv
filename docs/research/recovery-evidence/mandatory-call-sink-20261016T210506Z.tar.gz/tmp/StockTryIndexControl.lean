import StockTryIndexFrame
namespace Backend.Stock.Proof.TryIndexControlDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64 TryIndexFrameDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
attribute [local irreducible] Stock.runTerm
private def frame (st : State) := st.instBlock

private theorem forIn_frame {α β γ : Type} (field : α → γ)
    (step : β → α → Except String (ForInStep α))
    (keeps : ∀ x a b, step x a = .ok (.yield b) → field b = field a)
    (no_break : ∀ x a b, step x a ≠ .ok (.done b))
    (xs : List β) {a next : α} (h : forIn xs a step = .ok next) :
    field next = field a := by
  induction xs generalizing a with
  | nil => simp only [List.forIn_nil, pure, Except.pure] at h; cases h; rfl
  | cons x xs ih =>
    rw [List.forIn_cons] at h
    cases call : step x a with
    | error e => simp only [call, bind, Except.bind] at h; cases h
    | ok result =>
      cases result with
      | done b => exact False.elim (no_break x a b call)
      | yield b =>
        simp only [call, bind, Except.bind] at h
        exact (ih h).trans (keeps x a b call)

private def argStep (ctx : Ctx) (rets pays : List Reg) (index nh : Nat)
    (arg : Clif.TryArg) (acc : State × Array Reg) :
    Except String (ForInStep (State × Array Reg)) := do
  match arg with
  | .val v =>
    let some r := ctx.valueReg? v | throw s!"unknown value v{v}"
    pure (.yield (acc.1.mark v, acc.2.push r))
  | .ret i =>
    if index < nh then throw "try_call return on exception edge"
    let some r := rets[i]? | throw "try_call return index"
    pure (.yield (acc.1, acc.2.push r))
  | .exn i =>
    if index == nh then throw "try_call payload on normal edge"
    let some r := pays[i]? | throw "try_call payload index"
    pure (.yield (acc.1, acc.2.push r))

private theorem arg_frame (ctx : Ctx) (rets pays : List Reg) (index nh : Nat)
    (arg : Clif.TryArg) (a b : State × Array Reg)
    (h : argStep ctx rets pays index nh arg a = .ok (.yield b)) :
    frame b.1 = frame a.1 := by
  cases arg <;> unfold argStep at h
  all_goals repeat' first | (solve | cases h <;> rfl) | split at h

private theorem arg_no_break (ctx : Ctx) (rets pays : List Reg) (index nh : Nat)
    (arg : Clif.TryArg) (a b : State × Array Reg) :
    argStep ctx rets pays index nh arg a ≠ .ok (.done b) := by
  intro h
  cases arg <;> unfold argStep at h
  all_goals repeat' first | (solve | cases h) | split at h

theorem stock_branchArgs_instBlock {ctx : Ctx} {st next : State} {block index : Nat}
    {args : Array Reg} (h : branchArgs ctx st block index = .ok (args, next)) :
    frame next = frame st := by
  unfold branchArgs at h
  dsimp only at h
  split at h
  · rename_i id values lookup
    split at h
    · rename_i target found
      split at h
      · cases h
      · let ti := (st.instBlock.findIdx? (· == block)).getD 0 + ctx.func.blocks[block]!.body.length
        let reservations := st.tryRegs[ti]!
        let nh := match ctx.func.blocks[block]!.term with
          | .tryCall _ _ et | .tryCallIndirect _ _ et => et.handlers.length
          | _ => 0
        change (do
          let result ← forIn values (st, #[]) (argStep ctx reservations.1 reservations.2 index nh)
          pure (result.2, result.1)) = .ok (args, next) at h
        cases loop : forIn values (st, #[]) (argStep ctx reservations.1 reservations.2 index nh) with
        | error e => simp only [loop, bind, Except.bind] at h; cases h
        | ok result =>
          simp only [loop, bind, Except.bind, pure, Except.pure] at h
          cases h
          exact forIn_frame (fun a : State × Array Reg => frame a.1) _
            (arg_frame ctx reservations.1 reservations.2 index nh)
            (arg_no_break ctx reservations.1 reservations.2 index nh) values loop
    · cases h
  · cases h

private theorem fold_fields_eq {α β γ : Type} (field : α → γ)
    (step : α → β → Except String α)
    (hs : ∀ a b next, step a b = .ok next → field next = field a)
    (xs : List β) {a next : α} (h : xs.foldlM step a = .ok next) :
    field next = field a := by
  induction xs generalizing a with
  | nil => cases h; rfl
  | cons x xs ih =>
    rw [List.foldlM_cons] at h
    cases he : step a x with
    | error e => simp only [he, bind, Except.bind] at h; cases h
    | ok middle =>
      simp only [he, bind, Except.bind] at h
      exact (ih h).trans (hs a x middle he)


theorem stock_collectOutgoing_instBlock {ctx : Ctx} {order : Order} {bi : Nat} {targets : Array Nat}
    {st next : State} {outgoing : Array (Array Reg)}
    (h : collectOutgoing ctx order bi targets st = .ok (next, outgoing)) :
    frame next = frame st := by
  unfold collectOutgoing at h
  apply fold_fields_eq (fun a : State × Array (Array Reg) => frame a.1) _ ?_ _ h
  intro acc target result step
  unfold outgoingStep at step
  split at step
  · cases step; rfl
  · cases call : branchArgs ctx acc.1 bi target.2 with
    | error e => simp only [call, bind, Except.bind] at step; cases step
    | ok pair =>
      rcases pair with ⟨regs, state⟩
      simp only [call, bind, Except.bind, pure, Except.pure] at step
      cases step
      exact stock_branchArgs_instBlock call

theorem stock_emitBranch_instBlock {ctx : Ctx} {f : Clif.Function} {term : Clif.Terminator}
    {bi ti : Nat} {targets : Array Nat} {input : State} {out : BranchEmission}
    (run : emitBranch ctx f term bi ti targets input = .ok out) : out.state.instBlock = input.instBlock := by
  unfold emitBranch at run
  dsimp only at run
  let before := {input with current := some ti,color := none,base.emitted := #[]}
  change ((do
    let (value,next,trace) ← Stock.runTerm ctx "lower_branch" [.inst ti,.labels targets.toList] before
    if value.isNone then throw s!"no lowering rule for terminator {repr term}"
    let code ← branchCode f term targets next.base.emitted
    pure ⟨next,code,⟨bi,ti,.emitted,before,next,[],trace,code⟩,trace⟩) : Except String BranchEmission) = .ok out at run
  cases root : Stock.runTerm ctx "lower_branch" [.inst ti,.labels targets.toList] before with
  | error err => simp only [root,bind,Except.bind] at run; cases run
  | ok result =>
    rcases result with ⟨value,next,trace⟩
    simp only [root,bind,Except.bind] at run
    split at run
    · cases run
    · cases code : branchCode f term targets next.base.emitted with
      | error err => simp only [code,bind,Except.bind] at run; cases run
      | ok instructions =>
        simp only [code,pure,Except.pure] at run
        cases run
        exact stock_named_instBlock (st := before) root


private def finishCore (ctx localCtx : Ctx) (order : Order) (bi ti start stop : Nat)
    (isBranch : Bool) (targets : Array Nat) (input : State) (branch : Option BranchEmission) :
    Except String LoweredBlockCore := do
  let beforeEdges := branch.map (·.state) |>.getD input
  let (next,outgoing) ← collectOutgoing ctx order bi targets beforeEdges
  let beforeScan := {next with color := some next.endColor[bi]!}
  let indices := ((Array.range (stop-start)).map (start+·)).reverse.toList
  let bodyScan ← scanBlock localCtx bi ti isBranch indices beforeScan
  pure ⟨bodyScan.state,bodyScan.code ++ (branch.map (·.code) |>.getD #[]),outgoing,branch,
    ⟨localCtx,bi,ti,isBranch,indices,beforeScan,bodyScan⟩⟩
/-- Actual complete original block lowering retains the exact source metadata. -/
theorem stock_core_instBlock {ctx : Ctx} {order : Order} {f : Clif.Function} {b : Clif.Block}
    {bi start stop : Nat} {data : V} {targets : Array Nat} {input : State} {output : LoweredBlockCore}
    (run : lowerBlockCore ctx order f b bi start stop data targets input = .ok output) :
    output.state.instBlock = input.instBlock := by
  let ti := stop-1
  let localCtx := {ctx with insts := ctx.insts.set! ti ⟨data,[],[],none⟩,tryRegs := input.tryRegs[ti]!}
  let flag : Bool := match b.term with | .ret .. | .trap .. | .returnCall .. => false | _ => true
  change (do
    let branch ← if flag then some <$> emitBranch localCtx f b.term bi ti targets input else pure none
    finishCore ctx localCtx order bi ti start stop flag targets input branch) = .ok output at run
  have finish (branch : Option BranchEmission)
      (branchFrame : ((branch.map (·.state)).getD input).instBlock = input.instBlock)
      (rest : finishCore ctx localCtx order bi ti start stop flag targets input branch = .ok output) :
      output.state.instBlock = input.instBlock := by
    unfold finishCore at rest
    obtain ⟨⟨next,outgoing⟩,collected,rest⟩ := Except.bind_ok rest
    obtain ⟨scan,scanned,rest⟩ := Except.bind_ok rest
    cases rest
    exact (stock_scanBlock_instBlock scanned).trans ((stock_collectOutgoing_instBlock collected).trans branchFrame)
  cases hflag : flag with
  | false =>
    simp only [hflag,Bool.false_eq_true,ite_false,pure,Except.pure,bind,Except.bind] at run
    exact finish none rfl (by simpa only [hflag] using run)
  | true =>
    simp only [hflag,ite_true] at run
    cases call : emitBranch localCtx f b.term bi ti targets input with
    | error e => simp only [call,Except.map,bind,Except.bind] at run; cases run
    | ok emitted =>
      have mapped : some <$> (Except.ok emitted : Except String BranchEmission) = .ok (some emitted) := rfl
      rw [call,mapped] at run
      simp only [bind,Except.bind] at run
      exact finish (some emitted) (stock_emitBranch_instBlock call) (by simpa only [hflag] using run)
/-- Actual original and synthetic nodes retain source metadata. -/
theorem stock_node_instBlock {ctx : Ctx} {ranges : Array (Nat × Nat)} {order : Order}
    {f : Clif.Function} {params : List Nat} {label : Nat} {input output : DriverState}
    (run : lowerNode ctx ranges order f params label input = .ok output) :
    output.state.instBlock = input.state.instBlock := by
  unfold lowerNode at run
  dsimp only at run
  repeat' first
    | (solve | cases run)
    | simp only [bind,Except.bind,pure,Except.pure] at run
    | split at run
  all_goals cases run
  all_goals first
    | exact stock_core_instBlock (by assumption)
    | exact stock_branchArgs_instBlock (by assumption)
/-- The full actual reverse traversal retains source metadata. -/
theorem stock_nodes_instBlock {ctx : Ctx} {ranges : Array (Nat × Nat)} {order : Order}
    {f : Clif.Function} {params labels : List Nat} {input output : DriverState}
    (run : labels.foldlM (fun d k => lowerNode ctx ranges order f params k d) input = .ok output) :
    output.state.instBlock = input.state.instBlock := by
  induction labels generalizing input with
  | nil => cases run; rfl
  | cons label labels ih =>
    rw [List.foldlM_cons] at run
    obtain ⟨middle,step,rest⟩ := Except.bind_ok run
    exact (ih rest).trans (stock_node_instBlock step)
end Backend.Stock.Proof.TryIndexControlDraft
