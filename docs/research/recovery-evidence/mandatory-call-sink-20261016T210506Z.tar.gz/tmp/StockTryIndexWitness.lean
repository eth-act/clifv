import StockTryIndexWhole
import StockTryEmittedWitness
namespace Backend.Stock.Proof.TryIndexWitnessDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open TryEmittedWitnessDraft (Kind)
open TryIndexFrameDraft TryIndexControlDraft TryIndexWholeDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private def function : Kind → Clif.Function
  | .near => TryNearFixtureDraft.function false
  | .got => SpillEntryFixture.function false
  | .indirect => SpillEntryFixture.function true
private def entry (k : Kind) := (function k).blocks[0]!
private def table : Clif.ExnTable := {
  sig := 0,normal := ⟨1,[.ret 0,.val 0]⟩,items := [.tag 7 ⟨2,[.exn 0,.exn 1,.val 0]⟩] }
private structure Fixture (k : Kind) where
  result : Result
  prepared : EdgeVCode
  rf : RFunc
  af : AFunc
  lowered : Stock.lower (function k) = .ok result
  scope : LowerScope (function k)
  dominated : Dominated (function k)
  arity : ArityOk (function k)
  prepare : prepareAt result.code result.edgeArgs = .ok prepared
  fallback : rf = spillAllocAt prepared.code prepared.edges
  accepted : checkAllocAt prepared.code prepared.edges rf = .ok ()
  physical : lowerRFunc prepared.code rf = .ok af
private theorem fixture (k : Kind) : Nonempty (Fixture k) := by
  cases k with
  | near =>
    obtain ⟨out⟩ := TryNearFixtureDraft.stock_near_try_fixture
    exact ⟨⟨out.result,out.prepared,out.rf,out.af,out.lowered,out.scope,out.dominated,out.arity,
      out.prepare,out.fallback,out.accepted,out.physical⟩⟩
  | got =>
    obtain ⟨out⟩ := SpillEntryFixture.try_fixture false
    exact ⟨⟨out.result,out.prepared,out.rf,out.af,out.lowered,out.scope,out.dominated,out.arity,
      out.prepare,out.fallback,out.accepted,out.physical⟩⟩
  | indirect =>
    obtain ⟨out⟩ := SpillEntryFixture.try_fixture true
    exact ⟨⟨out.result,out.prepared,out.rf,out.af,out.lowered,out.scope,out.dominated,out.arity,
      out.prepare,out.fallback,out.accepted,out.physical⟩⟩
private theorem order (k : Kind) : blockOrder (function k) = .ok {
    nodes := #[.original 0,.original 1,.original 2],successors := #[#[2,1],#[],#[]]} := by cases k <;> cbv


private def built (k : Kind) : Ctx × Array (Nat × Nat) × State :=
  (Stock.buildCtx (function k)).toOption.getD (sinkCtx,#[],default)
private theorem built_ok (k : Kind) : Stock.buildCtx (function k) = .ok (built k) := by cases k <;> rfl
/-- All three COMPLETE TryCall pipelines retain their nonempty source metadata,
including each actual original node's pre-state and reservation table. The
entry block's actual query selects its SAME canonical terminator index. -/
theorem stock_complete_try_source_metadata_witness (k : Kind) :
    ∃ (out : Fixture k) (ranges : Array (Nat × Nat)) (params : List Nat) (input output : DriverState),
      LowerScope (function k) ∧ Dominated (function k) ∧ ArityOk (function k) ∧
      Stock.lower (function k) = .ok out.result ∧ prepareAt out.result.code out.result.edgeArgs = .ok out.prepared ∧
      out.rf = spillAllocAt out.prepared.code out.prepared.edges ∧
      checkAllocAt out.prepared.code out.prepared.edges out.rf = .ok () ∧ lowerRFunc out.prepared.code out.rf = .ok out.af ∧
      Stock.buildCtx (function k) = .ok (out.result.ctx,ranges,out.result.initial) ∧
      lowerNode out.result.ctx ranges out.result.order (function k) params 0 input = .ok output ∧
      input.state.instBlock = out.result.initial.instBlock ∧ input.state.tryRegs = out.result.initial.tryRegs ∧
      out.result.final.instBlock = out.result.initial.instBlock ∧
      input.state.instBlock.findIdx? (· == 0) = some 0 ∧
      (input.state.instBlock.findIdx? (· == 0)).getD 0 + (entry k).body.length =
        blockStart (function k) 0 + (entry k).body.length := by
  obtain ⟨out⟩ := fixture k
  have sameOrder := Except.ok.inj ((stock_lower_order out.lowered).symm.trans (order k))
  have node : out.result.order.nodes[0]? = some (.original 0) := by rw [sameOrder]; rfl
  obtain ⟨ranges,params,input,output,build,metadata,reservations,call⟩ := stock_lower_original_node_metadata out.lowered node
  have stateEq : out.result.initial = (built k).2.2 :=
    congrArg (fun q : Ctx × Array (Nat × Nat) × State => q.2.2) (Except.ok.inj (build.symm.trans (built_ok k)))
  have query : input.state.instBlock.findIdx? (· == 0) = some 0 := by
    rw [metadata,stateEq]
    cases k <;> decide +kernel
  exact ⟨out,ranges,params,input,output,out.scope,out.dominated,out.arity,out.lowered,out.prepare,out.fallback,
    out.accepted,out.physical,build,call,metadata,reservations,stock_lower_instBlock out.lowered,query,
    by simp only [query,Option.getD_some,blockStart,List.take_zero,List.foldl_nil]; rfl⟩
end Backend.Stock.Proof.TryIndexWitnessDraft
