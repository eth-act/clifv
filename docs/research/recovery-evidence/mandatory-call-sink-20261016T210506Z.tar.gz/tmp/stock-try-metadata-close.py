from pathlib import Path
import json,hashlib,re,datetime,tarfile,shutil
root=Path('/home/lee/clifv/.worktrees/driver-proof-resume');docs=root/'docs/research'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
now=datetime.datetime.now(datetime.timezone.utc);stamp=now.strftime('%Y%m%dT%H%M%SZ')
batch=json.loads(Path('/tmp/stock-try-metadata-batch.json').read_text());old=json.loads((docs/'stock-try-normal-frame-scratch.json').read_text())
log=Path('/tmp/stock-try-metadata-combined-axioms.log').read_text()
sets={m.group(1):sorted(x.strip() for x in m.group(2).split(',') if x.strip()) for m in re.finditer(r"'([^']+)' depends on axioms:\s*\[([^]]*)\]",log)}
for m in re.finditer(r"'([^']+)' does not depend on any axioms",log):sets[m.group(1)]=[]
for n,a in old['normal_audit']['sets'].items():assert sorted(a)==sets[n],n
assert len(sets)==len(old['normal_audit']['sets'])+len(batch['public_roots'])+len(batch['models'])
allowed={'propext','Classical.choice','Quot.sound'}
for n in batch['public_roots']+batch['models']:assert set(sets[n])<=allowed,n
constants=[json.loads(line.split('DELIVERY_CONSTANT ',1)[1]) for line in Path('/tmp/stock-try-metadata-all-constants.log').read_text().splitlines() if line.startswith('DELIVERY_CONSTANT ')]
assert constants
for n,a in constants:assert set(a)<=allowed,n
mods={}
for m in batch['modules']:
 p=Path('/tmp')/m;check=json.loads(p.with_suffix('.check.json').read_text());assert check['actual_exit']==0
 rec={}
 for key,ext in [('source','.lean'),('object','.olean'),('log','.log'),('check','.check.json')]:
  f=p.with_suffix(ext);rec[key]=str(f);rec[key+'_sha256']=sha(f)
 for k in ['source','object','log']:assert rec[k+'_sha256']==check[k+'_sha256']
 assert not re.search(r'\b(sorry|admit|axiom|trace_state|native_decide)\b',p.with_suffix('.lean').read_text()),m
 mods[m]=rec
for audit in ['stock-try-metadata-combined-axioms','stock-try-metadata-all-constants']:
 p=Path('/tmp')/audit;check=json.loads(p.with_suffix('.check.json').read_text());assert check['actual_exit']==0
 for k,ext in [('source','.lean'),('object','.olean'),('log','.log')]:assert sha(p.with_suffix(ext))==check[k+'_sha256']
prior={}
for name in ['source-execution-x','try-source','try-context','try-rule','try-rets','try-reservation','try-outgoing','try-values','try-emitted','try-machine','try-got','try-indirect','try-rename','try-resolved','try-gap','try-got-rename','try-normal-frame']:
 d=json.loads((docs/f'stock-{name}-scratch.json').read_text())
 for m,rec in d['modules'].items():
  for k in ['source','object','log']:assert sha(rec[k])==rec[k+'_sha256'],(m,k)
  prior[m]=rec
freeze=json.loads(Path('/tmp/stock-coherent-build-inputs.json').read_text())
for group in ['source_sha256','validation_script_sha256']:
 for p,h in freeze[group].items():assert sha(root/p)==h,p
progress=json.loads(Path('/tmp/stock-pr246-gates-progress.json').read_text());progress.pop('completed_phases',None)
remaining=old['remaining_checklist']
remaining.append({'requirement':'Actual instruction-to-block metadata framing at helpers/scans/blocks/nodes/traversal and outgoing collection','state':'Proved through all successful actual constructors/ISLE/named runs/binding/opportunistic scans/body scans/branch/outgoing/core/original and synthetic nodes/full reverse traversal/whole lower. Actual original node pre-state metadata and reservations equal initial tables; actual critical collection derives unchanged original tables, same reservation query and returned resolved vector internally. Complete near/GOT/indirect and positive one-arg/nonidentity193→192 critical compiler/fallback/physical witnesses pass. General initial sourceMetadata first-index correctness, matching every normal outgoing .ret reservation with actual call helper, machine source/reserved-write noninterference and normal parameter-copy/source continuation remain open.'})
counts={'modules':len(mods),'public_roots':len(batch['public_roots']),'models':len(batch['models']),'combined_roots_models':len(sets),'previous_preserved':len(old['normal_audit']['sets']),'all_new_module_constants':len(constants),'previous_modules_hashes_preserved':len(prior)}
receipt={'utc':now.isoformat(),'goal':'Original full #140 ACTIVE/INCOMPLETE; production LEGACY','scope':'Scratch-only additive Stock proofs, not coherent integration or merge-ready','delivery_target':'roughly eight substantive validated squash merges/day; prioritize landing coherent backlog, remote backups and cleanup; drafts do not count','modules':mods,'public_roots':batch['public_roots'],'models':batch['models'],'counts':counts,'normal_audit':{'path':'/tmp/stock-try-metadata-combined-axioms.log','sha256':sha('/tmp/stock-try-metadata-combined-axioms.log'),'sets':sets},'all_constant_audit':{'path':'/tmp/stock-try-metadata-all-constants.log','sha256':sha('/tmp/stock-try-metadata-all-constants.log'),'all_standard_only':True,'count':len(constants)},'previous_modules_hashes_preserved':list(prior),'canonical2246_source_and_script_freeze_preserved':True,'kernel_resources':'All new modules and both audits actual exit0/object verified at8GiB through memcap; one heavy delivery worker retained','MCP':'No new calls; bundled audit deferred until coherent integration','active_exact_PR246_validation':progress,'remaining_checklist':remaining}
(docs/'stock-try-metadata-scratch.json').write_text(json.dumps(receipt,indent=2)+'\n')
text=f'''Actual Stock instruction-to-block metadata framing — {now.isoformat()}

Five scratch modules/16public roots/one definitional frame model pass actual8GiB kernel checks. The {len(sets)}-root/model audit preserves all583prior exact axiom sets. All{len(constants)}new-module constants including private alias/loop/control/prefix/fixture helpers use only standard axioms. All{len(prior)}previous scratch source/object/log hashes and frozen2246canonical sources plus49validation scripts remain unchanged. Prior turn PROGRESS: source synthetic-result preservation/normal source entry and actual two-step direct/indirect consumers, complete near/GOT/indirect source17/live9 witnesses,583audit/123constants, verified6ab902a backup and2.8GBcleanup.

All successful actual Stock constructors preserve instBlock, including real gen_try_call_rets alias installation and gen_call_output. Full fuel-generic ISLE evaluation, named roots, result binding, opportunistic commit, actual instruction/body scans, argument collection, outgoing collection, branch emission, complete original block cores, original and synthetic nodes, and complete actual reverse traversal retain this SAME table. Proof composition uses actual runs and no new accepted-program metadata premise. The frame model is a definitional equality.

Whole successful lowering returns final.instBlock=initial.instBlock. Every actual original node pre-state also has initial metadata and reservation tables. For every actual synthetic edge, the SAME branchArgs call reads those original tables; the dynamic findIdx/body-length reservation query equals the original-table query, and the actual returned edgeArgs field contains that SAME collection after real final alias resolution. No caller state/layout/reservation/alias certificate is added.

Complete near/GOT/true-indirect compiler→prepareAt→forced checkedfallback→checker→physical witnesses inhabit original scope/Dominated/Arity and actual original-node runs, nonempty metadata, initial/final/pre-state equality and actual entry-block query selecting its canonical terminator index. A complete real synthetic critical-edge pipeline reuses cached compiler/fallback/physical kernels, passes an actual one-register outgoing vector, retains original tables and final resolved vector, and has an actual NONIDENTITY193→192 source alias. No cold heavy compiler witness build/new cache is introduced.

This closes mutation framing, not the general sourceMetadata constructor correctness or machine value frame. Next: prove original sourceMetadata/ranges gives findIdx block=blockStart for EVERY actual source block (the entry query is witnessed only), identify each normal .ret reservation with the SAME actual call helper, derive actual resolved .val/.ret outgoing vectors and real parameter copies/normal continuation, and prove available-source/reserved-write machine noninterference. Existing ordinary edge vectors cover only .val, so they cannot replace the TryCall proof. Existing local final-renamed direct/GOT/indirect normal execution and source definedness remain preserved.

ALL original shared payload endpoint/exception machine semantics, full zero-return/sret/x8/width/handler matrix, uncovered family/effect/sinking/source/block/whole-driver simulation AND completeness, original-input context/visitor/static/checker/fallback/physical totality, coherent scratch integration/MCP/public/private/compiler audits, full/crates/runtime/encoder/BOTH E2E identity-stage parity, actual production compiler/checker/linker/generated consumers and FRESH COMPLETE comparison remain mandatory. Full#140 ACTIVE/INCOMPLETE, production LEGACY. S10 shared exceptional interfaces remain @kevaundray #232/#233.

Delivery246/247 remain drafts; same live3247835/exclusive shared warm-cache lease, canonical1233457 deliberately held. Preserve old-head receipts, reconcile current main and rerun required actual-head gates before dependent squash merges. Target roughly8substantive validated merges/day, meaningful semantic grouping and remote backups. Initial proof-script failures corrected from actual diagnostics (obsolete case already solved, control monad normalization, missing explicit witness imports); no new native assumptions/heavy retry/delivery restart/new worktree/new MCP/merge this batch.

Hashed evidence/full remaining checklist: stock-try-metadata-scratch.json.
'''
(docs/'stock-try-metadata-scratch.md').write_text(text)
plan=root/'docs/plans/test-binary-alignment-recovery.md';plan.write_text(plan.read_text()+'\n\n'+text)
files=[]
for rec in mods.values():files.extend(Path(rec[k]) for k in ['source','object','log','check'])
for name in ['stock-try-metadata-combined-axioms','stock-try-metadata-all-constants']:
 for ext in ['.lean','.log','.olean','.check.json']:files.append(Path('/tmp')/(name+ext))
files.extend(Path(p) for p in ['/tmp/stock-try-metadata-batch.json','/tmp/stock-try-rule-inputs.json','/tmp/stock-try-reservation-check.py','/tmp/stock-try-metadata-close.py','/tmp/stock-try-metadata-make-audit.py','/tmp/stock-try-metadata-extra-inputs.py','/tmp/stock-try-metadata-status44.json','/tmp/stock-try-metadata-status52.json','/tmp/stock-try-metadata-status71.json','/tmp/stock-try-metadata-task140.json'])
files.extend([docs/'stock-try-metadata-scratch.json',docs/'stock-try-metadata-scratch.md',docs/'stock-delivery-main-drift.json',plan])
archive=Path('/home/lee/.clifv-recovery')/(stamp+'-try-metadata')/'checkpoint.tar.gz';archive.parent.mkdir(parents=True)
with tarfile.open(archive,'w:gz',compresslevel=1) as t:
 for p in files:t.add(p,arcname=str(p).lstrip('/'),recursive=False)
with tarfile.open(archive,'r:gz') as t:
 for p in files:assert t.extractfile(str(p).lstrip('/')).read()==p.read_bytes(),p
snapshot=Path('/tmp/stock-try-rule-inputs');size=sum(p.stat().st_size for p in snapshot.rglob('*') if p.is_file());shutil.rmtree(snapshot)
backup={'utc':now.isoformat(),'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(files),'all_members_byte_verified':True,'previous_remote_backup':json.loads((docs/'stock-try-normal-frame-backup.json').read_text())['remote'],'cleanup':{'duplicate_dependency_snapshot_removed':True,'bytes_reclaimed':size,'unique_sources_objects_logs_checks_audits_preserved':True,'one_shared_warm_cache_retained':True,'other_projects_touched':False,'free_bytes':shutil.disk_usage(root).free}}
(docs/'stock-try-metadata-backup.json').write_text(json.dumps(backup,indent=2)+'\n');Path('/tmp/stock-try-metadata-archive-path').write_text(str(archive))
print(json.dumps({'counts':counts,'archive':str(archive),'cleanup':backup['cleanup'],'gate':progress},indent=2))
