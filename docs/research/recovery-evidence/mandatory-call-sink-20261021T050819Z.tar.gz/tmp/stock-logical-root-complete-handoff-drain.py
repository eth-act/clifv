from pathlib import Path
import os,signal,time,json,datetime
root=Path('/tmp/stock-logical-root-complete-handoff');root.mkdir(exist_ok=True);sched=2201390
assert json.loads(Path('/tmp/stock-logical-compact-witness-attempt3/progress.json').read_text())['state']=='normal_build_passed'
assert '/tmp/stock-execute-scheduler.py' in Path(f'/proc/{sched}/cmdline').read_bytes().decode().replace('\0',' ')
def report(state,**fields):
 d={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':os.getpid(),'state':state,'held_scheduler':sched,**fields};(root/'progress.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)
os.kill(sched,signal.SIGSTOP)
report('draining_obsolete_import_graph_jobs',reason='Actual checked-in RootWitness normal440-module import closure passed; pre-refactor777-node launch graph is obsolete. Preserve running kernels and all successful outputs, review current packet, then resume first arithmetic landing.')
while True:
 ids=Path(f'/proc/{sched}/task/{sched}/children').read_text().split()
 live=[int(p) for p in ids if Path('/proc/'+p+'/stat').exists() and Path('/proc/'+p+'/stat').read_text().split()[2]!='Z']
 if not live:break
 time.sleep(3)
report('kernels_drained_ready_for_trust_review',actual_live_kernel_jobs=0,old_full777_pass_claim=False,current_checked_in_440_target_pass=True)
