import StockSourceExecutionXStack
import StockSourceExecutionStackShape
namespace Backend.Stock.Proof.SourceExecutionXLiftDraft
open SourceExecutionXStackDraft SourceExecutionStackShapeDraft
/-- Real normal steps and Clif.liftStep preserve saved-table alignment. The
source-specific caller proves location through its normal-step invariant and
derives the newly saved table from the original TryCall terminator. -/
theorem stock_source_liftStep_located
    {located : Clif.Frame → Prop} {pending : Clif.Frame → Clif.ExnTable → Prop}
    {env : Clif.Env} {p : Clif.Program} {xs next : Clif.XState} {s : Clif.State}
    (aligned : CallerTables located pending xs.s.callers xs.tries)
    (normal : located s.frame ∧ ∀ c ∈ s.callers, located c.1)
    (table : ∀ fr et, fr.func = xs.s.frame.func →
      Clif.pendingOf xs.s = some et → pending fr et)
    (step : Clif.step env p xs.s = .next s)
    (run : Clif.liftStep xs (.next s) = .next next) : XLocated located pending next := by
  have delta := stock_source_step_stack_delta step
  simp only [Clif.liftStep,Clif.XStepResult.next.injEq] at run
  cases run
  change located s.frame ∧ CallerTables located pending s.callers
    (if s.callers.length = xs.s.callers.length + 1 then Clif.pendingOf xs.s :: xs.tries
     else if s.callers.length + 1 = xs.s.callers.length then xs.tries.tail else xs.tries)
  rcases delta with same | ⟨c,push,func⟩ | ⟨c,pop⟩
  · have lengths := congrArg List.length same
    have no_push : ¬ s.callers.length = xs.s.callers.length + 1 := by omega
    have no_pop : ¬ s.callers.length + 1 = xs.s.callers.length := by omega
    simp only [ite_eq_right no_push,ite_eq_right no_pop]
    rw [same]
    exact ⟨normal.1,aligned⟩
  · have lengths := congrArg List.length push
    simp only [List.length_cons] at lengths
    have is_push : s.callers.length = xs.s.callers.length + 1 := by omega
    simp only [ite_eq_left is_push]
    rw [push]
    refine ⟨normal.1,normal.2 c (by rw [push]; exact List.mem_cons_self),?_,aligned⟩
    intro et actual
    exact table c.1 et func actual
  · have lengths := congrArg List.length pop
    simp only [List.length_cons] at lengths
    have no_push : ¬ s.callers.length = xs.s.callers.length + 1 := by omega
    have is_pop : s.callers.length + 1 = xs.s.callers.length := by omega
    simp only [ite_eq_right no_push,ite_eq_left is_pop]
    rw [pop] at aligned
    cases tries : xs.tries with
    | nil => rw [tries] at aligned; cases aligned
    | cons t ts =>
      rw [tries] at aligned
      exact ⟨normal.1,aligned.2.2⟩
end Backend.Stock.Proof.SourceExecutionXLiftDraft
