import StockSourceExecutionFixture
import StockSourceExecutingXCalls
namespace Backend.Stock.Proof.SourceExecutingXCallsWitnessDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open SourceExecutionGraphDraft SourceExecutionCallsDraft SourceExecutionCoreDraft SourceExecutingCallsDraft
open SourceExecutionFixtureDraft SourceExecutingXCallsDraft SourceExecutionXCoreDraft
open ExplicitCallWitnessDraft (sourceArgs values)
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
attribute [local irreducible] Stock.lower Stock.runTerm Isle.Aarch64.program

private theorem xexecution (k : Kind) (implicit : Bool) :
    XRunPrefix (environment k implicit).toX (program k implicit)
      (initial k implicit).toX (current k implicit).toX := by
  cases k with
  | direct => exact .refl _
  | got => exact .refl _
  | indirect =>
    apply XRunPrefix.next (s' := (current .indirect implicit).toX)
    · cases implicit <;> rfl
    · exact .refl _
private theorem completedX (k : Kind) (implicit : Bool) :
    Clif.runWithX (environment k implicit).toX (program k implicit) (function k implicit).name
      (sourceArgs (indirect k) implicit) memory (if indirect k then 4 else 3) =
      .returned (values implicit) memory := by cases k <;> cases implicit <;> rfl

/-- Complete original direct ordinary/sret compiler pipelines and real source
runs inhabit the new executing-call coverage bridge. The actual reached source
call derives its Stock record and emission evidence through the new roots. -/
theorem stock_complete_direct_xexecuting_call_witness (implicit : Bool) :
    ∃ (out : CallStaticFixture.Output) (bi j : Nat) (b : Clif.Block) (event : BlockScanEvent)
      (record : ScanRecord) (info : IInfo) (step : Step),
      LowerScope (CallStaticFixture.function false implicit) ∧ Dominated (CallStaticFixture.function false implicit) ∧ ArityOk (CallStaticFixture.function false implicit) ∧ AbiSigsOk (CallStaticFixture.function false implicit) ∧
      Stock.lower (CallStaticFixture.function false implicit) = .ok out.result ∧
      prepareAt out.result.code out.result.edgeArgs = .ok out.prepared ∧
      out.rf = spillAllocAt out.prepared.code out.prepared.edges ∧
      checkAllocAt out.prepared.code out.prepared.edges out.rf = .ok () ∧
      lowerRFunc out.prepared.code out.rf = .ok out.af ∧
      Clif.initState (program .direct implicit) (function .direct implicit).name (sourceArgs false implicit) memory =
        .ok (initial .direct implicit) ∧
      XRunPrefix (environment .direct implicit).toX (program .direct implicit) (initial .direct implicit).toX (current .direct implicit).toX ∧
      Clif.step (environment .direct implicit) (program .direct implicit) (current .direct implicit) = .next (afterCall .direct implicit) ∧
      StateLocated (CallStaticFixture.function false implicit) #[#[]] (afterCall .direct implicit) ∧
      SigStackOk (CallStaticFixture.signature false implicit) out.result.code.outgoing ∧
      (CallStaticFixture.function false implicit).blocks[bi]? = some b ∧ b.body[j]? = some (CallStaticFixture.callStatement false implicit) ∧
      event ∈ out.result.blockScans.toList ∧ event.block = bi ∧ record ∈ event.output.records ∧
      record.inst = blockStart (CallStaticFixture.function false implicit) bi + j ∧ event.ctx.insts[record.inst]? = some info ∧
      info.clif = some (.call 0 (CallStaticFixture.arguments false implicit)) ∧ record.output.step = some step ∧ step.decision = .emitted ∧
      Clif.runWithX (environment .direct implicit).toX (program .direct implicit) (function .direct implicit).name
        (sourceArgs (indirect .direct) implicit) memory (if indirect .direct then 4 else 3) =
        .returned (values implicit) memory := by
  obtain ⟨out,oldEvent,oldRecord,oldInfo,oldStep,scope,dom,arity,abi,run,prepared,fallback,checked,physical,
    facts,oldEvents,oldRecords,oldSlot,oldClif,oldRecorded,oldEmitted,rest⟩ := CallEmissionWitnessDraft.stock_complete_direct_call_emission_witness implicit
  have computed : stockSourceTable (function .direct implicit) = .ok #[#[]] := by cases implicit <;> cbv
  have same : (current .direct implicit).frame.func = (CallStaticFixture.function false implicit) := by cases implicit <;> rfl
  have kind : (CallStaticFixture.callStatement false implicit).inst = (.call 0 (CallStaticFixture.arguments false implicit)) := rfl
  have call : (∃ fn xs,(CallStaticFixture.callStatement false implicit).inst = .call fn xs) ∨
      (∃ sig callee xs,(CallStaticFixture.callStatement false implicit).inst = .callIndirect sig callee xs) :=
    .inl ⟨0,_,kind⟩
  obtain ⟨bi,b,j,event,record,info,step,block,statement,events,eventBlock,records,index,slot,clif,recorded,emitted⟩ :=
    stock_lower_xexecuting_source_call_emitted run scope (entered .direct implicit) (xexecution .direct implicit) same
      (head .direct implicit) call
  have located := stock_source_runPrefix_located computed (stock_source_initState_located (entered .direct implicit))
    (execution .direct implicit)
  have after := stock_source_step_located computed located (called .direct implicit)
  let ext : Clif.ExtFunc := {name := CallStaticFixture.calleeName,sig := CallStaticFixture.signature false implicit,colocated := true}
  have external : (CallStaticFixture.function false implicit).extern? 0 = some ext := rfl
  have stack := stock_lower_xexecuting_direct_call_stack run scope dom.1 abi (entered .direct implicit)
    (xexecution .direct implicit) same (head .direct implicit) kind external
  exact ⟨out,bi,j,b,event,record,info,step,scope,dom,arity,abi,run,prepared,fallback,checked,physical,
    entered .direct implicit,xexecution .direct implicit,called .direct implicit,after,stack,
    block,statement,events,eventBlock,records,index,slot,clif,recorded,emitted,completedX .direct implicit⟩

/-- Complete original indirect ordinary/sret compiler pipelines and real source
runs inhabit the new executing-call coverage bridge. The actual reached source
call derives its Stock record and emission evidence through the new roots. -/
theorem stock_complete_indirect_xexecuting_call_witness (implicit : Bool) :
    ∃ (out : CallStaticFixture.Output) (bi j : Nat) (b : Clif.Block) (event : BlockScanEvent)
      (record : ScanRecord) (info : IInfo) (step : Step),
      LowerScope (CallStaticFixture.function true implicit) ∧ Dominated (CallStaticFixture.function true implicit) ∧ ArityOk (CallStaticFixture.function true implicit) ∧ AbiSigsOk (CallStaticFixture.function true implicit) ∧
      Stock.lower (CallStaticFixture.function true implicit) = .ok out.result ∧
      prepareAt out.result.code out.result.edgeArgs = .ok out.prepared ∧
      out.rf = spillAllocAt out.prepared.code out.prepared.edges ∧
      checkAllocAt out.prepared.code out.prepared.edges out.rf = .ok () ∧
      lowerRFunc out.prepared.code out.rf = .ok out.af ∧
      Clif.initState (program .indirect implicit) (function .indirect implicit).name (sourceArgs true implicit) memory =
        .ok (initial .indirect implicit) ∧
      XRunPrefix (environment .indirect implicit).toX (program .indirect implicit) (initial .indirect implicit).toX (current .indirect implicit).toX ∧
      Clif.step (environment .indirect implicit) (program .indirect implicit) (current .indirect implicit) = .next (afterCall .indirect implicit) ∧
      StateLocated (CallStaticFixture.function true implicit) #[#[]] (afterCall .indirect implicit) ∧
      (CallStaticFixture.function true implicit).blocks[bi]? = some b ∧ b.body[j]? = some (CallStaticFixture.callStatement true implicit) ∧
      event ∈ out.result.blockScans.toList ∧ event.block = bi ∧ record ∈ event.output.records ∧
      record.inst = blockStart (CallStaticFixture.function true implicit) bi + j ∧ event.ctx.insts[record.inst]? = some info ∧
      info.clif = some (.callIndirect 0 80 (CallStaticFixture.arguments true implicit)) ∧ record.output.step = some step ∧ step.decision = .emitted ∧
      Clif.runWithX (environment .indirect implicit).toX (program .indirect implicit) (function .indirect implicit).name
        (sourceArgs (indirect .indirect) implicit) memory (if indirect .indirect then 4 else 3) =
        .returned (values implicit) memory := by
  obtain ⟨out,oldEvent,oldRecord,oldInfo,oldStep,scope,dom,arity,abi,run,prepared,fallback,checked,physical,
    facts,oldEvents,oldRecords,oldSlot,oldClif,oldRecorded,oldEmitted,rest⟩ := IndirectCallEmissionWitnessDraft.stock_complete_indirect_call_emission_witness implicit
  have computed : stockSourceTable (function .indirect implicit) = .ok #[#[]] := by cases implicit <;> cbv
  have same : (current .indirect implicit).frame.func = (CallStaticFixture.function true implicit) := by cases implicit <;> rfl
  have kind : (CallStaticFixture.callStatement true implicit).inst = (.callIndirect 0 80 (CallStaticFixture.arguments true implicit)) := rfl
  have call : (∃ fn xs,(CallStaticFixture.callStatement true implicit).inst = .call fn xs) ∨
      (∃ sig callee xs,(CallStaticFixture.callStatement true implicit).inst = .callIndirect sig callee xs) :=
    .inr ⟨0,80,_,kind⟩
  obtain ⟨bi,b,j,event,record,info,step,block,statement,events,eventBlock,records,index,slot,clif,recorded,emitted⟩ :=
    stock_lower_xexecuting_source_call_emitted run scope (entered .indirect implicit) (xexecution .indirect implicit) same
      (head .indirect implicit) call
  have located := stock_source_runPrefix_located computed (stock_source_initState_located (entered .indirect implicit))
    (execution .indirect implicit)
  have after := stock_source_step_located computed located (called .indirect implicit)
  exact ⟨out,bi,j,b,event,record,info,step,scope,dom,arity,abi,run,prepared,fallback,checked,physical,
    entered .indirect implicit,xexecution .indirect implicit,called .indirect implicit,after,
    block,statement,events,eventBlock,records,index,slot,clif,recorded,emitted,completedX .indirect implicit⟩

/-- Complete original got ordinary/sret compiler pipelines and real source
runs inhabit the new executing-call coverage bridge. The actual reached source
call derives its Stock record and emission evidence through the new roots. -/
theorem stock_complete_got_xexecuting_call_witness (implicit : Bool) :
    ∃ (out : GotCallFixture.Output) (bi j : Nat) (b : Clif.Block) (event : BlockScanEvent)
      (record : ScanRecord) (info : IInfo) (step : Step),
      LowerScope (GotCallFixture.function implicit) ∧ Dominated (GotCallFixture.function implicit) ∧ ArityOk (GotCallFixture.function implicit) ∧ AbiSigsOk (GotCallFixture.function implicit) ∧
      Stock.lower (GotCallFixture.function implicit) = .ok out.result ∧
      prepareAt out.result.code out.result.edgeArgs = .ok out.prepared ∧
      out.rf = spillAllocAt out.prepared.code out.prepared.edges ∧
      checkAllocAt out.prepared.code out.prepared.edges out.rf = .ok () ∧
      lowerRFunc out.prepared.code out.rf = .ok out.af ∧
      Clif.initState (program .got implicit) (function .got implicit).name (sourceArgs false implicit) memory =
        .ok (initial .got implicit) ∧
      XRunPrefix (environment .got implicit).toX (program .got implicit) (initial .got implicit).toX (current .got implicit).toX ∧
      Clif.step (environment .got implicit) (program .got implicit) (current .got implicit) = .next (afterCall .got implicit) ∧
      StateLocated (GotCallFixture.function implicit) #[#[]] (afterCall .got implicit) ∧
      SigStackOk (CallStaticFixture.signature false implicit) out.result.code.outgoing ∧
      (GotCallFixture.function implicit).blocks[bi]? = some b ∧ b.body[j]? = some (CallStaticFixture.callStatement false implicit) ∧
      event ∈ out.result.blockScans.toList ∧ event.block = bi ∧ record ∈ event.output.records ∧
      record.inst = blockStart (GotCallFixture.function implicit) bi + j ∧ event.ctx.insts[record.inst]? = some info ∧
      info.clif = some (.call 0 (CallStaticFixture.arguments false implicit)) ∧ record.output.step = some step ∧ step.decision = .emitted ∧
      Clif.runWithX (environment .got implicit).toX (program .got implicit) (function .got implicit).name
        (sourceArgs (indirect .got) implicit) memory (if indirect .got then 4 else 3) =
        .returned (values implicit) memory := by
  obtain ⟨out,oldEvent,oldRecord,oldInfo,oldStep,scope,dom,arity,abi,run,prepared,fallback,checked,physical,
    facts,oldEvents,oldRecords,oldSlot,oldClif,oldRecorded,oldEmitted,rest⟩ := GotCallWitnessDraft.stock_complete_got_call_emission_witness implicit
  have computed : stockSourceTable (function .got implicit) = .ok #[#[]] := by cases implicit <;> cbv
  have same : (current .got implicit).frame.func = (GotCallFixture.function implicit) := by cases implicit <;> rfl
  have kind : (CallStaticFixture.callStatement false implicit).inst = (.call 0 (CallStaticFixture.arguments false implicit)) := rfl
  have call : (∃ fn xs,(CallStaticFixture.callStatement false implicit).inst = .call fn xs) ∨
      (∃ sig callee xs,(CallStaticFixture.callStatement false implicit).inst = .callIndirect sig callee xs) :=
    .inl ⟨0,_,kind⟩
  obtain ⟨bi,b,j,event,record,info,step,block,statement,events,eventBlock,records,index,slot,clif,recorded,emitted⟩ :=
    stock_lower_xexecuting_source_call_emitted run scope (entered .got implicit) (xexecution .got implicit) same
      (head .got implicit) call
  have located := stock_source_runPrefix_located computed (stock_source_initState_located (entered .got implicit))
    (execution .got implicit)
  have after := stock_source_step_located computed located (called .got implicit)
  let ext : Clif.ExtFunc := {name := CallStaticFixture.calleeName,sig := CallStaticFixture.signature false implicit,colocated := false}
  have external : (GotCallFixture.function implicit).extern? 0 = some ext := rfl
  have stack := stock_lower_xexecuting_direct_call_stack run scope dom.1 abi (entered .got implicit)
    (xexecution .got implicit) same (head .got implicit) kind external
  exact ⟨out,bi,j,b,event,record,info,step,scope,dom,arity,abi,run,prepared,fallback,checked,physical,
    entered .got implicit,xexecution .got implicit,called .got implicit,after,stack,
    block,statement,events,eventBlock,records,index,slot,clif,recorded,emitted,completedX .got implicit⟩
end Backend.Stock.Proof.SourceExecutingXCallsWitnessDraft
