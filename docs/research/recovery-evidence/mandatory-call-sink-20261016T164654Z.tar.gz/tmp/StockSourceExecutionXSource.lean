import StockSourceExecutionUnwind
import StockSourceExecutionCore
import StockSourceExecutionXCore
namespace Backend.Stock.Proof.SourceExecutionXSourceDraft
open Backend.Proof Backend.Proof.Driver
open SourceExecutionGraphDraft SourceExecutionCallsDraft SourceExecutionUnwindDraft SourceExecutionCoreDraft
open SourceExecutionXStackDraft SourceExecutionXCoreDraft

/-- Actual saved-table location invariant for the original Stock source CFG. -/
def SourceXLocated (f : Clif.Function) (source : Array (Array Nat)) (xs : Clif.XState) : Prop :=
  XLocated (FrameLocated f source) (PendingTableLocated f source) xs

private theorem pending_actual {f : Clif.Function} {source : Array (Array Nat)}
    {s : Clif.State} (located : FrameLocated f source s.frame)
    (fr : Clif.Frame) (et : Clif.ExnTable) (same : fr.func = s.frame.func)
    (actual : Clif.pendingOf s = some et) : PendingTableLocated f source fr et := by
  have pending : PendingTableLocated f source s.frame et := by
    cases body : s.frame.body with
    | cons stm rest => simp only [Clif.pendingOf,body] at actual; cases actual
    | nil =>
      cases term : s.frame.term with
      | tryCall fn args original =>
        simp only [Clif.pendingOf,body,term,Option.some.injEq] at actual
        subst et
        exact stock_source_try_table_located located (.inl ⟨fn,args,term⟩)
      | tryCallIndirect callee args original =>
        simp only [Clif.pendingOf,body,term,Option.some.injEq] at actual
        subst et
        exact stock_source_try_table_located located (.inr ⟨callee,args,term⟩)
      | _ => simp only [Clif.pendingOf,body,term] at actual; cases actual
  intro original
  exact pending (same ▸ original)

/-- Every actual stepX derives original source locations and aligned suspended
TryCall tables, including calls, returns, tail calls and multi-frame unwinding.
The source-specific normal/catch/pending obligations are discharged internally. -/
theorem stock_source_stepX_original_located {f : Clif.Function} {source : Array (Array Nat)}
    (computed : stockSourceTable f = .ok source) {env : Clif.XEnv} {p : Clif.Program}
    {xs next : Clif.XState} (before : SourceXLocated f source xs)
    (run : Clif.stepX env p xs = .next next) : SourceXLocated f source next := by
  exact stock_source_stepX_located stock_source_catchIn_located before
    (fun s stepping => stock_source_step_located computed
      ⟨before.1,stock_source_caller_tables_frames before.2⟩ stepping)
    (pending_actual before.1) run

/-- Real source entry derives the exceptional-interpreter invariant without a
caller-provided table, reachability, emission or interpreter-success certificate. -/
theorem stock_source_initStateX_original_located {f : Clif.Function} {source : Array (Array Nat)}
    {p : Clif.Program} {name : String} {args : List Clif.Val} {mem : Clif.Mem} {s : Clif.State}
    (entered : Clif.initState p name args mem = .ok s) : SourceXLocated f source s.toX := by
  have normal : StateLocated f source s := stock_source_initState_located entered
  exact stock_source_toX_located normal.1 normal.2

/-- Original source reachability and exact saved-table correspondence hold at
every actual normal OR exceptional prefix starting at the real source entry. -/
theorem stock_source_xrunPrefix_original_located {f : Clif.Function} {source : Array (Array Nat)}
    (computed : stockSourceTable f = .ok source) {env : Clif.XEnv} {p : Clif.Program}
    {name : String} {args : List Clif.Val} {mem : Clif.Mem} {s : Clif.State} {next : Clif.XState}
    (entered : Clif.initState p name args mem = .ok s)
    (execution : XRunPrefix env p s.toX next) : SourceXLocated f source next := by
  exact stock_source_xrunPrefix_located stock_source_catchIn_located
    (fun s s' located stepping => stock_source_step_located computed located stepping)
    (fun s located => pending_actual located)
    (stock_source_initStateX_original_located entered) execution
end Backend.Stock.Proof.SourceExecutionXSourceDraft
