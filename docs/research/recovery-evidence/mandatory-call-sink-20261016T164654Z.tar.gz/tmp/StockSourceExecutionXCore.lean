import StockSourceExecutionXLift
namespace Backend.Stock.Proof.SourceExecutionXCoreDraft
open SourceExecutionXStackDraft SourceExecutionXLiftDraft
/-- Every stored caller is located; table alignment carries this alongside
its pending-table fact, so unwinding cannot invent a caller location. -/
theorem stock_source_caller_tables_frames
    {located : Clif.Frame → Prop} {pending : Clif.Frame → Clif.ExnTable → Prop}
    {cs : List (Clif.Frame × List Clif.ValueId)} {ts : List (Option Clif.ExnTable)}
    (aligned : CallerTables located pending cs ts) : ∀ c ∈ cs, located c.1 := by
  induction cs generalizing ts with
  | nil => intro c member; cases member
  | cons c cs ih =>
    cases ts with
    | nil => cases aligned
    | cons t ts =>
      intro caller member
      rcases List.mem_cons.mp member with rfl | tail
      · exact aligned.1
      · exact ih aligned.2.2 caller tail

/-- Every actual exceptional-interpreter next step preserves aligned source
locations when the original-source normal-step and pending-table facts hold.
The actual raiseAt? branch is inspected internally. -/
theorem stock_source_stepX_located
    {located : Clif.Frame → Prop} {pending : Clif.Frame → Clif.ExnTable → Prop}
    (caught : ∀ {fr et e next}, pending fr et →
      Clif.catchIn fr et e = some (.ok next) → located next)
    {env : Clif.XEnv} {p : Clif.Program} {xs next : Clif.XState}
    (before : XLocated located pending xs)
    (normal : ∀ s, Clif.step env.toEnv p xs.s = .next s →
      located s.frame ∧ ∀ c ∈ s.callers,located c.1)
    (table : ∀ fr et, fr.func = xs.s.frame.func →
      Clif.pendingOf xs.s = some et → pending fr et)
    (run : Clif.stepX env p xs = .next next) : XLocated located pending next := by
  cases raised : Clif.raiseAt? env p xs.s with
  | some pair =>
    obtain ⟨e,mem⟩ := pair
    simp only [Clif.stepX,raised] at run
    exact stock_source_raiseIn_located caught before.2
      (fun et actual => table xs.s.frame et rfl actual) run
  | none =>
    simp only [Clif.stepX,raised] at run
    cases stepped : Clif.step env.toEnv p xs.s with
    | next s =>
      rw [stepped] at run
      exact stock_source_liftStep_located before.2 (normal s stepped) table stepped run
    | done vals mem => simp only [stepped,Clif.liftStep] at run; cases run
    | trapped code => simp only [stepped,Clif.liftStep] at run; cases run
    | stuck msg => simp only [stepped,Clif.liftStep] at run; cases run

/-- Finite prefixes of the unchanged actual exception-aware step relation. -/
inductive XRunPrefix (env : Clif.XEnv) (p : Clif.Program) : Clif.XState → Clif.XState → Prop
  | refl (s : Clif.XState) : XRunPrefix env p s s
  | next {s s' s'' : Clif.XState} : Clif.stepX env p s = .next s' →
      XRunPrefix env p s' s'' → XRunPrefix env p s s''

/-- Derive locations for every actual exceptional prefix. Its source-specific
caller discharges normal stepping, pending tables and catchIn once; no per-run
reachability or emission certificate is part of compiler acceptance. -/
theorem stock_source_xrunPrefix_located
    {located : Clif.Frame → Prop} {pending : Clif.Frame → Clif.ExnTable → Prop}
    (caught : ∀ {fr et e next}, pending fr et →
      Clif.catchIn fr et e = some (.ok next) → located next)
    {env : Clif.XEnv} {p : Clif.Program}
    (normal : ∀ s s', (located s.frame ∧ ∀ c ∈ s.callers,located c.1) →
      Clif.step env.toEnv p s = .next s' → located s'.frame ∧ ∀ c ∈ s'.callers,located c.1)
    (table : ∀ s,located s.frame → ∀ fr et, fr.func = s.frame.func →
      Clif.pendingOf s = some et → pending fr et)
    {xs next : Clif.XState} (before : XLocated located pending xs)
    (execution : XRunPrefix env p xs next) : XLocated located pending next := by
  induction execution with
  | refl => exact before
  | @next s s' s'' step rest ih =>
    have after := stock_source_stepX_located caught before
      (fun next stepping => normal s.s next ⟨before.1,stock_source_caller_tables_frames before.2⟩ stepping)
      (table s.s before.1) step
    exact ih after
end Backend.Stock.Proof.SourceExecutionXCoreDraft
