import FV.Clif.Run
namespace Backend.Stock.Proof.SourceExecutionStackShapeDraft
/-- The actual source interpreter changes its caller stack by at most one
frame. A pushed caller keeps the current source function. -/
def StackDelta (s next : Clif.State) : Prop :=
  next.callers = s.callers ∨
  (∃ c, next.callers = c :: s.callers ∧ c.1.func = s.frame.func) ∨
  (∃ c, s.callers = c :: next.callers)
private theorem ofRes_next {α : Type} {r : Clif.Res α} {k : α → Clif.StepResult} {next : Clif.State}
    (run : Clif.StepResult.ofRes r k = .next next) : ∃ a,r = .ok a ∧ k a = .next next := by
  cases r with
  | ok a => exact ⟨a,rfl,run⟩
  | trap c => cases run
  | stuck msg => cases run
private theorem continued {s next : Clif.State} {rest : List Clif.Stmt} {results : List Nat}
    {vals : List Clif.Val} {mem : Clif.Mem}
    (run : Clif.continueWith s rest results vals mem = .next next) : StackDelta s next := by
  unfold Clif.continueWith at run
  cases found : s.frame.regs.setMany results vals with
  | none => simp only [found] at run; cases run
  | some regs => simp only [found,Clif.StepResult.next.injEq] at run; cases run; exact .inl rfl
private theorem returned {s next : Clif.State} {vals : List Clif.Val} {mem : Clif.Mem}
    (run : Clif.returnValues s vals mem = .next next) : StackDelta s next := by
  unfold Clif.returnValues at run
  obtain ⟨u,types,run⟩ := ofRes_next run
  cases stored : s.callers with
  | nil => simp only [stored] at run; cases run
  | cons caller tail =>
    obtain ⟨fr,results⟩ := caller
    simp only [stored] at run
    cases bound : fr.regs.setMany results vals with
    | none => simp only [bound] at run; cases run
    | some regs =>
      simp only [bound,Clif.StepResult.next.injEq] at run
      cases run
      exact .inr (.inr ⟨(fr,results),stored⟩)
private theorem called {env : Clif.Env} {p : Clif.Program} {s next : Clif.State}
    {rest : List Clif.Stmt} {results : List Nat} {fn : Nat} {args : List Nat}
    (run : Clif.stepCall env p s rest results fn args = .next next) : StackDelta s next := by
  unfold Clif.stepCall at run
  obtain ⟨⟨ext,vals⟩,request,run⟩ := ofRes_next run
  cases target : p.func? ext.name with
  | some callee =>
    simp only [target] at run
    split at run
    · obtain ⟨⟨fr,mem⟩,entered,run⟩ := ofRes_next run
      cases run
      exact .inr (.inl ⟨_,rfl,rfl⟩)
    · cases run
  | none =>
    simp only [target] at run
    cases found : env.extern ext.name with
    | none => simp only [found] at run; cases run
    | some g =>
      simp only [found] at run
      cases outcome : g vals s.mem with
      | trapped c => simp only [outcome] at run; cases run
      | stuck msg => simp only [outcome] at run; cases run
      | outOfFuel => simp only [outcome] at run; cases run
      | returned rvals mem =>
        simp only [outcome] at run
        split at run
        · exact continued run
        · cases run
private theorem indirect {env : Clif.Env} {p : Clif.Program} {s next : Clif.State}
    {rest : List Clif.Stmt} {results : List Nat} {sig callee : Nat} {args : List Nat}
    (run : Clif.stepCallIndirect env p s rest results sig callee args = .next next) : StackDelta s next := by
  unfold Clif.stepCallIndirect at run
  obtain ⟨⟨declared,addr,vals⟩,request,run⟩ := ofRes_next run
  cases target : p.funcs.find? (fun g => s.mem.symbols g.name == some addr) with
  | some g =>
    simp only [target] at run
    split at run
    · obtain ⟨⟨fr,mem⟩,entered,run⟩ := ofRes_next run
      cases run
      exact .inr (.inl ⟨_,rfl,rfl⟩)
    · cases run
  | none =>
    simp only [target] at run
    obtain ⟨⟨vals,mem⟩,returned,run⟩ := ofRes_next run
    exact continued run
private theorem tailcall {env : Clif.Env} {p : Clif.Program} {s next : Clif.State}
    {fn : Nat} {args : List Nat}
    (run : Clif.stepReturnCall env p s fn args = .next next) : StackDelta s next := by
  unfold Clif.stepReturnCall at run
  obtain ⟨⟨ext,vals⟩,request,run⟩ := ofRes_next run
  cases target : p.func? ext.name with
  | some callee =>
    simp only [target] at run
    split at run
    · obtain ⟨⟨fr,mem⟩,entered,run⟩ := ofRes_next run
      cases run
      exact .inl rfl
    · cases run
  | none =>
    simp only [target] at run
    cases found : env.extern ext.name with
    | none => simp only [found] at run; cases run
    | some g =>
      simp only [found] at run
      cases outcome : g vals s.mem with
      | trapped c => simp only [outcome] at run; cases run
      | stuck msg => simp only [outcome] at run; cases run
      | outOfFuel => simp only [outcome] at run; cases run
      | returned rvals mem => simp only [outcome] at run; exact returned run
private theorem tried {env : Clif.Env} {p : Clif.Program} {s next : Clif.State}
    {fn : Nat} {args : List Nat} {et : Clif.ExnTable}
    (run : Clif.stepTryCall env p s fn args et = .next next) : StackDelta s next := by
  unfold Clif.stepTryCall at run
  obtain ⟨⟨n,base,bc⟩,request,run⟩ := ofRes_next run
  have delta := called run
  exact delta
private theorem triedIndirect {env : Clif.Env} {p : Clif.Program} {s next : Clif.State}
    {callee : Nat} {args : List Nat} {et : Clif.ExnTable}
    (run : Clif.stepTryCallIndirect env p s callee args et = .next next) : StackDelta s next := by
  unfold Clif.stepTryCallIndirect at run
  obtain ⟨⟨n,base,bc⟩,request,run⟩ := ofRes_next run
  have delta := indirect run
  exact delta
private theorem term {env : Clif.Env} {p : Clif.Program} {s next : Clif.State}
    {t : Clif.Terminator} (run : Clif.stepTerm env p s t = .next next) : StackDelta s next := by
  cases t with
  | jump bc =>
    obtain ⟨fr,entered,run⟩ := ofRes_next run
    cases run
    exact .inl rfl
  | brif c t e =>
    obtain ⟨value,read,run⟩ := ofRes_next run
    obtain ⟨fr,entered,run⟩ := ofRes_next run
    cases run
    exact .inl rfl
  | brTable x d table =>
    obtain ⟨value,read,run⟩ := ofRes_next run
    obtain ⟨fr,entered,run⟩ := ofRes_next run
    cases run
    exact .inl rfl
  | ret xs => obtain ⟨vals,values,run⟩ := ofRes_next run; exact returned run
  | returnCall fn args => exact tailcall run
  | trap code => cases run
  | tryCall fn args et => exact tried run
  | tryCallIndirect callee args et => exact triedIndirect run
/-- Every successful actual normal source step has the caller-stack shape
used by Clif.liftStep. No instruction, callee or source-scope restriction. -/
theorem stock_source_step_stack_delta {env : Clif.Env} {p : Clif.Program} {s next : Clif.State}
    (run : Clif.step env p s = .next next) : StackDelta s next := by
  classical
  cases body : s.frame.body with
  | nil => rw [Clif.step_term env p s body] at run; exact term run
  | cons stm rest =>
    by_cases direct : ∃ fn args,stm.inst = .call fn args
    · obtain ⟨fn,args,kind⟩ := direct
      unfold Clif.step at run
      simp only [body,kind] at run
      exact called run
    · by_cases ind : ∃ sig callee args,stm.inst = .callIndirect sig callee args
      · obtain ⟨sig,callee,args,kind⟩ := ind
        unfold Clif.step at run
        simp only [body,kind] at run
        exact indirect run
      · rw [Clif.step_inst env p s stm rest body (fun fn args h => direct ⟨fn,args,h⟩)
          (fun sig callee args h => ind ⟨sig,callee,args,h⟩)] at run
        obtain ⟨⟨vals,mem⟩,evaluated,run⟩ := ofRes_next run
        exact continued run
end Backend.Stock.Proof.SourceExecutionStackShapeDraft
