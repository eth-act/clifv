from pathlib import Path
s=Path('/tmp/StockSourceExecutingCallsWitness.lean').read_text().replace('import StockSourceExecutionFixture','import StockSourceExecutionFixture\nimport StockSourceExecutingXCalls').replace('namespace Backend.Stock.Proof.SourceExecutingCallsWitnessDraft','namespace Backend.Stock.Proof.SourceExecutingXCallsWitnessDraft').replace('end Backend.Stock.Proof.SourceExecutingCallsWitnessDraft','end Backend.Stock.Proof.SourceExecutingXCallsWitnessDraft')
s=s.replace('open SourceExecutionFixtureDraft','open SourceExecutionFixtureDraft SourceExecutingXCallsDraft SourceExecutionXCoreDraft')
marker='/-- Complete original direct ordinary/sret'
i=s.index(marker)
s=s[:i]+'''private theorem xexecution (k : Kind) (implicit : Bool) :
    XRunPrefix (environment k implicit).toX (program k implicit)
      (initial k implicit).toX (current k implicit).toX := by
  cases k with
  | direct => exact .refl _
  | got => exact .refl _
  | indirect =>
    apply XRunPrefix.next (s' := (current .indirect implicit).toX)
    · cases implicit <;> rfl
    · exact .refl _
private theorem completedX (k : Kind) (implicit : Bool) :
    Clif.runWithX (environment k implicit).toX (program k implicit) (function k implicit).name
      (sourceArgs (indirect k) implicit) memory (if indirect k then 4 else 3) =
      .returned (values implicit) memory := by cases k <;> cases implicit <;> rfl

'''+s[i:]
s=s.replace('stock_complete_direct_executing_call_witness','stock_complete_direct_xexecuting_call_witness').replace('stock_complete_indirect_executing_call_witness','stock_complete_indirect_xexecuting_call_witness').replace('stock_complete_got_executing_call_witness','stock_complete_got_xexecuting_call_witness')
s=s.replace('stock_lower_executing_source_call_emitted','stock_lower_xexecuting_source_call_emitted').replace('stock_lower_executing_direct_call_stack','stock_lower_xexecuting_direct_call_stack')
for k in ['direct','indirect','got']:
 old=f'RunPrefix (environment .{k} implicit) (program .{k} implicit) (initial .{k} implicit) (current .{k} implicit)'
 new=f'XRunPrefix (environment .{k} implicit).toX (program .{k} implicit) (initial .{k} implicit).toX (current .{k} implicit).toX'
 s=s.replace(old,new)
 s=s.replace(f'(execution .{k} implicit) same',f'(xexecution .{k} implicit) same')
 s=s.replace(f'entered .{k} implicit,execution .{k} implicit,called',f'entered .{k} implicit,xexecution .{k} implicit,called')
 # Add complete actual exception-interpreter execution to every new witness.
 sig='      info.clif = some '
 name='theorem stock_complete_'+k+'_xexecuting_call_witness'
 start=s.index(name);end=s.index(' := by',start)
 header=s[start:end]
 oldend='step.decision = .emitted'
 newend=f'''step.decision = .emitted ∧
      Clif.runWithX (environment .{k} implicit).toX (program .{k} implicit) (function .{k} implicit).name
        (sourceArgs (indirect .{k}) implicit) memory (if indirect .{k} then 4 else 3) =
        .returned (values implicit) memory'''
 assert oldend in header;header=header.replace(oldend,newend);s=s[:start]+header+s[end:]
 # Final tuple has this unique suffix in this theorem.
 nextstart=s.find('\n/--',start+len(header));nextstart=len(s) if nextstart<0 else nextstart
 part=s[start:nextstart];assert 'recorded,emitted⟩' in part;part=part.replace('recorded,emitted⟩',f'recorded,emitted,completedX .{k} implicit⟩');s=s[:start]+part+s[nextstart:]
Path('/tmp/StockSourceExecutingXCallsWitness.lean').write_text(s)
