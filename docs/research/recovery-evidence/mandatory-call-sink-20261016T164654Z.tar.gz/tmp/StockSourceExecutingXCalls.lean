import StockSourceExecutingCalls
import StockSourceExecutionXSource
namespace Backend.Stock.Proof.SourceExecutingXCallsDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open SourceExecutionGraphDraft SourceExecutionCallsDraft SourceExecutingCallsDraft CallSourceCoverageDraft
open SourceExecutionXCoreDraft SourceExecutionXSourceDraft
/-- A source call reached by actual exception-aware execution is a real
emitted Stock record. Original-source position and emission are derived even
after handlers or unwinding, without a caller-supplied reachability certificate. -/
theorem stock_lower_xexecuting_source_call_emitted {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f)
    {env : Clif.XEnv} {p : Clif.Program} {name : String} {args : List Clif.Val} {mem : Clif.Mem}
    {initial : Clif.State} {current : Clif.XState} (entry : Clif.initState p name args mem = .ok initial)
    (execution : XRunPrefix env p initial.toX current) (function : current.s.frame.func = f)
    {stm : Clif.Stmt} {rest : List Clif.Stmt} (body : current.s.frame.body = stm :: rest)
    (call : (∃ fn xs,stm.inst = .call fn xs) ∨ (∃ sig callee xs,stm.inst = .callIndirect sig callee xs)) :
    ∃ (bi : Nat) (b : Clif.Block) (j : Nat) (event : BlockScanEvent) (record : ScanRecord) (info : IInfo) (step : Step),
      f.blocks[bi]? = some b ∧ b.body[j]? = some stm ∧
      event ∈ result.blockScans.toList ∧ event.block = bi ∧ record ∈ event.output.records ∧
      record.inst = blockStart f bi + j ∧ event.ctx.insts[record.inst]? = some info ∧
      info.clif = some stm.inst ∧ record.output.step = some step ∧ step.decision = .emitted := by
  obtain ⟨source,computed,size,bounds⟩ := stock_blockOrder_sourceTable (stock_lower_order lowered)
  have located := stock_source_xrunPrefix_original_located computed entry execution
  obtain ⟨bi,b,j,block,reached,statement⟩ := stock_source_executing_statement located.1 function body
  obtain ⟨event,record,info,step,events,current,records,index,slot,clif,recorded,emitted⟩ :=
    stock_lower_reachable_source_call_emitted lowered scope computed reached block statement call
  exact ⟨bi,b,j,event,record,info,step,block,statement,events,current,records,index,slot,clif,recorded,emitted⟩
/-- Exception-aware execution derives the actual direct/GOT call's outgoing
bound from its emitted record. No all-block CallsStack assumption is added. -/
theorem stock_lower_xexecuting_direct_call_stack {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f) (ssa : (valueDefs f).Nodup) (abi : AbiSigsOk f)
    {env : Clif.XEnv} {p : Clif.Program} {name : String} {args : List Clif.Val} {mem : Clif.Mem}
    {initial : Clif.State} {current : Clif.XState} (entry : Clif.initState p name args mem = .ok initial)
    (execution : XRunPrefix env p initial.toX current) (function : current.s.frame.func = f)
    {stm : Clif.Stmt} {rest : List Clif.Stmt} (body : current.s.frame.body = stm :: rest)
    {fn : Nat} {xs : List Nat} (kind : stm.inst = .call fn xs)
    {ext : Clif.ExtFunc} (external : f.extern? fn = some ext) : SigStackOk ext.sig result.code.outgoing := by
  obtain ⟨bi,b,j,event,record,info,step,block,statement,events,current,records,index,slot,clif,recorded,emitted⟩ :=
    stock_lower_xexecuting_source_call_emitted lowered scope entry execution function body (.inl ⟨fn,xs,kind⟩)
  exact CallOriginalOutgoingDraft.stock_lower_original_call_code_stack lowered scope ssa abi events records slot
    (by rw [clif,kind]) external
end Backend.Stock.Proof.SourceExecutingXCallsDraft
