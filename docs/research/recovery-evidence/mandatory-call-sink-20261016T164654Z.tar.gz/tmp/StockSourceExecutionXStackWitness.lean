import StockSourceExecutionXSource
import FV.Backend.Proof.LowerDecide

namespace Backend.Stock.Proof.SourceExecutionXStackWitnessDraft
open SourceExecutionXStackDraft SourceExecutionStackShapeDraft SourceExecutionXLiftDraft
open SourceExecutionXCoreDraft SourceExecutionXSourceDraft SourceExecutionGraphDraft
open Backend.Proof Backend.Proof.Driver
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private def sig : Clif.Signature := {}
private def table : Clif.ExnTable := {
  sig := 0
  normal := ⟨1,[]⟩
  items := [.context 7,.tag 7 ⟨2,[.exn 0]⟩,.default ⟨2,[.exn 0]⟩] }
private def root : Clif.Function := {
  name := "source_xstack_root"
  sig := {params := [⟨.i64,.none,.normal⟩],returns := [⟨.i64,.none,.normal⟩]}
  externs := [(0,{name := "source_xstack_middle",sig})]
  sigDecls := [(0,sig)]
  blocks := [{id := 0,params := [(7,.i64)],term := .tryCall 0 [] table},
    {id := 1,term := .ret [7]}, {id := 2,params := [(9,.i64)],term := .ret [9]}] }
private def middle : Clif.Function := {
  name := "source_xstack_middle",sig
  externs := [(0,{name := "source_xstack_leaf",sig})]
  blocks := [{id := 0,body := [{inst := .call 0 []}],term := .ret []}] }
private def leaf : Clif.Function := {
  name := "source_xstack_leaf",sig
  externs := [(0,{name := "source_xstack_throw",sig})]
  blocks := [{id := 0,body := [{inst := .call 0 []}],term := .ret []}] }
private def program : Clif.Program := {funcs := [root,middle,leaf]}
private def exception (tagged : Bool) : Clif.Exn := {
  catches := fun n => tagged && n == 7
  payload := [⟨.i64,42⟩] }
private def environment (tagged : Bool) : Clif.XEnv := {
  extern := fun n => if n = "source_xstack_throw" then
    some (fun _ mem => .unwound (exception tagged) mem) else none }
private def fallback : Clif.XState := {
  s := {
    frame := {func := root,regs := Clif.Regs.empty,slots := [],body := [],term := .ret []}
    callers := []
    mem := Clif.Mem.empty }
  tries := [] }
private def initial : Clif.XState :=
  match Clif.initState program root.name [⟨.i64,42⟩] Clif.Mem.empty with
  | .ok s => s.toX
  | _ => fallback
private def nextOf : Clif.XStepResult → Clif.XState
  | .next xs => xs
  | _ => fallback
private def one (tagged : Bool) := nextOf (Clif.stepX (environment tagged) program initial)
private def two (tagged : Bool) := nextOf (Clif.stepX (environment tagged) program (one tagged))
private def three (tagged : Bool) := nextOf (Clif.stepX (environment tagged) program (two tagged))
private def located (fr : Clif.Frame) : Prop := fr.func ∈ program.funcs
private def pending (fr : Clif.Frame) (et : Clif.ExnTable) : Prop :=
  fr.func = root ∧ et = table

private theorem catch_func {fr next : Clif.Frame} {et : Clif.ExnTable} {e : Clif.Exn}
    (run : Clif.catchIn fr et e = some (.ok next)) : next.func = fr.func := by
  unfold Clif.catchIn at run
  cases found : et.catch? e with
  | none => simp only [found,Option.map_none] at run; cases run
  | some d =>
    simp only [found,Option.map_some,Option.some.injEq] at run
    cases handler : Clif.tryHandler d fr.func.freshValue with
    | trap code => simp only [handler] at run; cases run
    | stuck msg => simp only [handler] at run; cases run
    | ok bc =>
      simp only [handler] at run
      cases bound : fr.regs.setMany ((List.range e.payload.length).map (fr.func.freshValue + ·)) e.payload with
      | none => simp only [bound] at run; cases run
      | some regs => simp only [bound] at run; cases run; rfl

private theorem catches {fr next : Clif.Frame} {et : Clif.ExnTable} {e : Clif.Exn}
    (table : pending fr et) (run : Clif.catchIn fr et e = some (.ok next)) : located next := by
  change next.func ∈ [root,middle,leaf]
  rw [catch_func run,table.1]
  exact List.mem_cons_self

private theorem aligned (tagged : Bool) :
    CallerTables located pending (two tagged).s.callers (two tagged).tries := by
  cases tagged <;> change located _ ∧ (∀ et, none = some et → pending _ et) ∧
    located _ ∧ (∀ et, some table = some et → pending _ et) ∧ True
  all_goals refine ⟨?_,?_,?_,?_,True.intro⟩
  all_goals solve
    | (change middle ∈ [root,middle,leaf]; simp)
    | (change root ∈ [root,middle,leaf]; simp)
    | (intro et impossible; cases impossible)
    | (intro et same; cases same; exact ⟨rfl,rfl⟩)

/-- Two real program calls save a plain caller above a TryCall caller. Raising
at the leaf skips the plain caller and resumes the lower caller with its table.
Both first-tag and default selection bind the real exception payload. -/
theorem stock_source_nested_unwind_witness (tagged : Bool) :
    Clif.initState program root.name [⟨.i64,42⟩] Clif.Mem.empty = .ok initial.s ∧
    XLocated located pending initial ∧
    Clif.stepX (environment tagged) program initial = .next (one tagged) ∧
    Clif.stepX (environment tagged) program (one tagged) = .next (two tagged) ∧
    CallerTables located pending (two tagged).s.callers (two tagged).tries ∧
    (two tagged).s.callers.length = (two tagged).tries.length ∧
    (two tagged).s.callers.length = 2 ∧
    Clif.raiseIn (two tagged) (exception tagged) (two tagged).s.mem = .next (three tagged) ∧
    XLocated located pending (three tagged) ∧
    (three tagged).s.frame.func = root ∧
    (three tagged).s.frame.term = .jump ⟨2,[10]⟩ ∧
    (three tagged).s.frame.regs 10 = some ⟨.i64,42⟩ ∧
    (three tagged).s.callers = [] ∧ (three tagged).tries = [] := by
  have entered : XLocated located pending initial :=
    stock_source_toX_located (s := initial.s) (pending := pending)
      (by change root ∈ [root,middle,leaf]; simp)
      (by intro c member; cases member)
  have raising : Clif.raiseIn (two tagged) (exception tagged) (two tagged).s.mem = .next (three tagged) := by
    cases tagged <;> rfl
  have resumed := stock_source_raiseIn_located catches (aligned tagged)
    (by intro et same; cases tagged <;> cases same) raising
  refine ⟨rfl,entered,?_,?_,aligned tagged,stock_source_caller_tables_length (aligned tagged),?_,raising,resumed,?_,?_,?_,?_,?_⟩
  all_goals cases tagged <;> rfl

/-- The very same nested exception executions complete through handler entry,
payload assignment and return, rather than merely constructing an intermediate state. -/
theorem stock_source_nested_unwind_complete_witness (tagged : Bool) :
    Clif.runWithX (environment tagged) program root.name [⟨.i64,42⟩] Clif.Mem.empty 6 =
      .returned [⟨.i64,42⟩] Clif.Mem.empty := by
  cases tagged <;> rfl

/-- Actual TryCall caller push exercises the general normal-step stack-shape
and lifted saved-table invariant, with the table derived at the real source head. -/
theorem stock_source_actual_lift_witness (tagged : Bool) :
    Clif.step (environment tagged).toEnv program initial.s = .next (one tagged).s ∧
    StackDelta initial.s (one tagged).s ∧ XLocated located pending (one tagged) := by
  have stepping : Clif.step (environment tagged).toEnv program initial.s = .next (one tagged).s := by
    cases tagged <;> rfl
  have normal : located (one tagged).s.frame ∧ ∀ c ∈ (one tagged).s.callers,located c.1 := by
    cases tagged <;> constructor
    all_goals first
      | (solve | change middle ∈ [root,middle,leaf]; simp)
      | (intro c member
         change c ∈ [_] at member
         simp only [List.mem_singleton] at member
         subst c
         change root ∈ [root,middle,leaf]
         simp)
  have lifted : Clif.liftStep initial (.next (one tagged).s) = .next (one tagged) := by
    cases tagged <;> rfl
  refine ⟨stepping,stock_source_step_stack_delta stepping,?_⟩
  exact stock_source_liftStep_located (by trivial) normal
    (by intro fr et same actual; cases actual; exact ⟨same,rfl⟩) stepping lifted

private def rootSource : Array (Array Nat) := #[#[2,2,1],#[],#[]]
private theorem rootComputed : stockSourceTable root = .ok rootSource := by cbv
private theorem originalScope : LowerScope root := by apply lowerScope_of; decide +kernel
private theorem middleScope : LowerScope middle := by apply lowerScope_of; decide +kernel
private theorem leafScope : LowerScope leaf := by apply lowerScope_of; decide +kernel

/-- The nested real exception execution inhabits the ORIGINAL-source stepX
and prefix theorems. Every participating function satisfies original LowerScope;
actual entry, reachable source table and original saved TryCall table are used.
There is no caller-provided reachability, source-position or emission premise. -/
theorem stock_source_original_nested_prefix_witness (tagged : Bool) :
    LowerScope root ∧ LowerScope middle ∧ LowerScope leaf ∧
    stockSourceTable root = .ok rootSource ∧
    Clif.initState program root.name [⟨.i64,42⟩] Clif.Mem.empty = .ok initial.s ∧
    SourceXLocated root rootSource initial ∧
    XRunPrefix (environment tagged) program initial (two tagged) ∧
    SourceXLocated root rootSource (two tagged) ∧
    Clif.stepX (environment tagged) program (two tagged) = .next (three tagged) ∧
    SourceXLocated root rootSource (three tagged) ∧
    XRunPrefix (environment tagged) program initial (three tagged) ∧
    (three tagged).s.frame.func = root ∧
    (three tagged).s.frame.regs 10 = some ⟨.i64,42⟩ ∧
    Clif.runWithX (environment tagged) program root.name [⟨.i64,42⟩] Clif.Mem.empty 6 =
      .returned [⟨.i64,42⟩] Clif.Mem.empty := by
  have entered : Clif.initState program root.name [⟨.i64,42⟩] Clif.Mem.empty = .ok initial.s := rfl
  have first : Clif.stepX (environment tagged) program initial = .next (one tagged) := by cases tagged <;> rfl
  have second : Clif.stepX (environment tagged) program (one tagged) = .next (two tagged) := by cases tagged <;> rfl
  have third : Clif.stepX (environment tagged) program (two tagged) = .next (three tagged) := by cases tagged <;> rfl
  have execution : XRunPrefix (environment tagged) program initial (two tagged) := .next first (.next second (.refl _))
  have whole : XRunPrefix (environment tagged) program initial (three tagged) := .next first (.next second (.next third (.refl _)))
  have start : SourceXLocated root rootSource initial := stock_source_initStateX_original_located entered
  have during : SourceXLocated root rootSource (two tagged) := stock_source_xrunPrefix_original_located rootComputed entered execution
  have caught := stock_source_stepX_original_located rootComputed during third
  have final : SourceXLocated root rootSource (three tagged) := stock_source_xrunPrefix_original_located rootComputed entered whole
  refine ⟨originalScope,middleScope,leafScope,rootComputed,entered,start,execution,during,third,caught,whole,?_,?_,stock_source_nested_unwind_complete_witness tagged⟩
  all_goals cases tagged <;> rfl

private def returningEnv : Clif.XEnv := {
  extern := fun n => if n = "source_xstack_throw" then some (fun _ mem => .returned [] mem) else none }
private def leafDone := nextOf (Clif.stepX returningEnv program (two false))
private def middleResumed := nextOf (Clif.stepX returningEnv program leafDone)
private def rootResumed := nextOf (Clif.stepX returningEnv program middleResumed)

/-- Actual ordinary returns pop the plain caller table and then the saved
TryCall table, retaining the source location of the pending normal jump. -/
theorem stock_source_original_normal_pop_witness :
    Clif.stepX returningEnv program leafDone = .next middleResumed ∧
    leafDone.s.callers.length = 2 ∧ leafDone.tries.length = 2 ∧
    middleResumed.s.callers.length = 1 ∧ middleResumed.tries = [some table] ∧
    SourceXLocated root rootSource middleResumed ∧
    Clif.stepX returningEnv program middleResumed = .next rootResumed ∧
    rootResumed.s.frame.func = root ∧ rootResumed.s.callers = [] ∧ rootResumed.tries = [] ∧
    SourceXLocated root rootSource rootResumed ∧
    Clif.runWithX returningEnv program root.name [⟨.i64,42⟩] Clif.Mem.empty 8 =
      .returned [⟨.i64,42⟩] Clif.Mem.empty := by
  have first : Clif.stepX returningEnv program initial = .next (one false) := rfl
  have second : Clif.stepX returningEnv program (one false) = .next (two false) := rfl
  have third : Clif.stepX returningEnv program (two false) = .next leafDone := rfl
  have fourth : Clif.stepX returningEnv program leafDone = .next middleResumed := rfl
  have fifth : Clif.stepX returningEnv program middleResumed = .next rootResumed := rfl
  have execution : XRunPrefix returningEnv program initial middleResumed :=
    .next first (.next second (.next third (.next fourth (.refl _))))
  have entered : Clif.initState program root.name [⟨.i64,42⟩] Clif.Mem.empty = .ok initial.s := rfl
  have during : SourceXLocated root rootSource middleResumed :=
    stock_source_xrunPrefix_original_located rootComputed entered execution
  have after := stock_source_stepX_original_located rootComputed during fifth
  exact ⟨fourth,rfl,rfl,rfl,rfl,during,fifth,rfl,rfl,rfl,after,rfl⟩

private def missTable : Clif.ExnTable := {table with items := [.context 7,.tag 7 ⟨2,[.exn 0]⟩]}
private def missRoot : Clif.Function := {root with blocks := [
  {id := 0,params := [(7,.i64)],term := .tryCall 0 [] missTable},
  {id := 1,term := .ret [7]},{id := 2,params := [(9,.i64)],term := .ret [9]}]}
private def missProgram : Clif.Program := {funcs := [missRoot,middle,leaf]}
/-- When no saved handler matches, real unwinding leaves all three activations
and reports the exception. No return or caught-next state is manufactured. -/
theorem stock_source_uncaught_nested_witness :
    LowerScope missRoot ∧
    Clif.runWithX (environment false) missProgram missRoot.name [⟨.i64,42⟩] Clif.Mem.empty 6 =
      .unwound (exception false) Clif.Mem.empty := by
  constructor
  · apply lowerScope_of
    decide +kernel
  · rfl

end Backend.Stock.Proof.SourceExecutionXStackWitnessDraft
