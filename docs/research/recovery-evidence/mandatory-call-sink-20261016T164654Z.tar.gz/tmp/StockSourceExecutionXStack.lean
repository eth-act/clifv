import FV.Clif.Unwind

namespace Backend.Stock.Proof.SourceExecutionXStackDraft

/-- Saved callers and their real pending exception tables, in the same order.
This is internal proof state, never an accepted-program condition. -/
def CallerTables (located : Clif.Frame → Prop)
    (pending : Clif.Frame → Clif.ExnTable → Prop) :
    List (Clif.Frame × List Clif.ValueId) → List (Option Clif.ExnTable) → Prop
  | [], [] => True
  | (fr, _) :: cs, t :: ts =>
      located fr ∧ (∀ et, t = some et → pending fr et) ∧ CallerTables located pending cs ts
  | _, _ => False

/-- The active frame and every saved caller retain their original-source location. -/
def XLocated (located : Clif.Frame → Prop)
    (pending : Clif.Frame → Clif.ExnTable → Prop) (xs : Clif.XState) : Prop :=
  located xs.s.frame ∧ CallerTables located pending xs.s.callers xs.tries

/-- Actual unwinding may discard any number of frames. If it resumes a caught
caller, that caller has its own saved table, and the remaining stack stays aligned. -/
theorem stock_source_unwindFrom_located
    {located : Clif.Frame → Prop} {pending : Clif.Frame → Clif.ExnTable → Prop}
    (caught : ∀ {fr et e next}, pending fr et →
      Clif.catchIn fr et e = some (.ok next) → located next)
    {e : Clif.Exn} {fr : Clif.Frame} {cs : List (Clif.Frame × List Clif.ValueId)}
    {ts : List (Option Clif.ExnTable)} {mem : Clif.Mem} {next : Clif.XState}
    (aligned : CallerTables located pending cs ts)
    (run : Clif.unwindFrom e fr cs ts mem = .next next) : XLocated located pending next := by
  induction cs generalizing fr ts mem with
  | nil => simp only [Clif.unwindFrom] at run; cases run
  | cons c cs ih =>
    obtain ⟨caller,results⟩ := c
    cases ts with
    | nil => cases aligned
    | cons t ts =>
      obtain ⟨head,table,tail⟩ := aligned
      cases t with
      | none =>
        simp only [Clif.unwindFrom,Option.bind_none] at run
        exact ih tail run
      | some et =>
        cases found : Clif.catchIn caller et e with
        | none =>
          simp only [Clif.unwindFrom,Option.bind_some,found] at run
          exact ih tail run
        | some result =>
          cases result with
          | trap code => simp only [Clif.unwindFrom,Option.bind_some,found,Clif.XStepResult.ofRes] at run; cases run
          | stuck msg => simp only [Clif.unwindFrom,Option.bind_some,found,Clif.XStepResult.ofRes] at run; cases run
          | ok resumed =>
            simp only [Clif.unwindFrom,Option.bind_some,found,Clif.XStepResult.ofRes,Clif.XStepResult.next.injEq] at run
            cases run
            exact ⟨caught (table et rfl) found,tail⟩

/-- Raising at an actual source call either catches in the active frame or
uses actual saved-caller unwinding. The caller table invariant is retained. -/
theorem stock_source_raiseIn_located
    {located : Clif.Frame → Prop} {pending : Clif.Frame → Clif.ExnTable → Prop}
    (caught : ∀ {fr et e next}, pending fr et →
      Clif.catchIn fr et e = some (.ok next) → located next)
    {xs next : Clif.XState} {e : Clif.Exn} {mem : Clif.Mem}
    (aligned : CallerTables located pending xs.s.callers xs.tries)
    (current : ∀ et, Clif.pendingOf xs.s = some et → pending xs.s.frame et)
    (run : Clif.raiseIn xs e mem = .next next) : XLocated located pending next := by
  cases table : Clif.pendingOf xs.s with
  | none =>
    simp only [Clif.raiseIn,table,Option.bind_none] at run
    exact stock_source_unwindFrom_located caught aligned run
  | some et =>
    cases found : Clif.catchIn xs.s.frame et e with
    | none =>
      simp only [Clif.raiseIn,table,Option.bind_some,found] at run
      exact stock_source_unwindFrom_located caught aligned run
    | some result =>
      cases result with
      | trap code => simp only [Clif.raiseIn,table,Option.bind_some,found,Clif.XStepResult.ofRes] at run; cases run
      | stuck msg => simp only [Clif.raiseIn,table,Option.bind_some,found,Clif.XStepResult.ofRes] at run; cases run
      | ok resumed =>
        simp only [Clif.raiseIn,table,Option.bind_some,found,Clif.XStepResult.ofRes,Clif.XStepResult.next.injEq] at run
        cases run
        exact ⟨caught (current et table) found,aligned⟩

/-- Stack/table alignment rules out missing or excess saved tables. -/
theorem stock_source_caller_tables_length
    {located : Clif.Frame → Prop} {pending : Clif.Frame → Clif.ExnTable → Prop}
    {cs : List (Clif.Frame × List Clif.ValueId)} {ts : List (Option Clif.ExnTable)}
    (aligned : CallerTables located pending cs ts) : cs.length = ts.length := by
  induction cs generalizing ts with
  | nil => cases ts <;> simp_all [CallerTables]
  | cons c cs ih =>
    cases ts with
    | nil => cases aligned
    | cons t ts => exact congrArg Nat.succ (ih aligned.2.2)

/-- Ordinary entry creates aligned empty pending tables internally. -/
theorem stock_source_toX_located
    {located : Clif.Frame → Prop} {pending : Clif.Frame → Clif.ExnTable → Prop}
    {s : Clif.State} (active : located s.frame)
    (callers : ∀ c ∈ s.callers, located c.1) : XLocated located pending s.toX := by
  refine ⟨active,?_⟩
  change CallerTables located pending s.callers (s.callers.map fun _ => none)
  have all_none : ∀ cs : List (Clif.Frame × List Clif.ValueId),
      (∀ c ∈ cs, located c.1) → CallerTables located pending cs (cs.map fun _ => none) := by
    intro cs good
    induction cs with
    | nil => trivial
    | cons c cs ih =>
      refine ⟨good c (by simp),?_,?_⟩
      · intro et impossible
        cases impossible
      · exact ih (fun c member => good c (List.mem_cons_of_mem _ member))
  exact all_none s.callers callers

end Backend.Stock.Proof.SourceExecutionXStackDraft
