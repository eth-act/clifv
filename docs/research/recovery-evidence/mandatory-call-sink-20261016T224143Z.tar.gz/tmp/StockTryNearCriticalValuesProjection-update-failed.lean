import FV.Backend.Proof.StockCriticalSplitFixture
import FV.Backend.Proof.PerEdgeSpillEntryFixture

namespace Backend.Stock.Proof.TryNearCriticalValuesProjectionDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Backend.Proof.PerEdgeSpill
set_option maxRecDepth 20000
set_option maxHeartbeats 16000000
def function : Clif.Function := {CriticalSplitFixture.function false with externs :=
  [(0,{name := "callee",sig := (CriticalSplitFixture.function false).sig,colocated := true})] }

/-- Concrete projected output, computed only as a candidate and checked below. -/
def codeArgs : VCode × Array (Array (Array Reg)) :=
  ({ name := "stock_forced_single_try_split",
     blocks := #[{ label := 0,
                   insts := #[Backend.MInst.tryCall
                                { dest := Backend.CallDest.sym "callee",
                                  uses := [],
                                  defs := [(Backend.Reg.x 0, Backend.Reg.vreg 192 (Backend.RegClass.int)),
                                           (Backend.Reg.x 1, Backend.Reg.vreg 194 (Backend.RegClass.int))] }
                                { continuation := 1, handlers := [], clobberAll := false, rets := 1 }],
                   params := #[],
                   branchArgs := #[] },
                 { label := 1,
                   insts := #[Backend.MInst.jump 2],
                   params := #[],
                   branchArgs := #[Backend.Reg.vreg 192 (Backend.RegClass.int)] },
                 { label := 2,
                   insts := #[Backend.MInst.rets [(Backend.Reg.vreg 195 (Backend.RegClass.int), Backend.Reg.x 0)]],
                   params := #[Backend.Reg.vreg 195 (Backend.RegClass.int)],
                   branchArgs := #[] }],
     classes := #[Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int,
                  Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int,
                  Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int,
                  Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int,
                  Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int,
                  Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int,
                  Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int,
                  Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int,
                  Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int,
                  Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int,
                  Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int,
                  Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int,
                  Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int,
                  Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int,
                  Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int,
                  Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int,
                  Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int,
                  Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int,
                  Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int,
                  Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int,
                  Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int,
                  Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int,
                  Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int,
                  Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int,
                  Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int,
                  Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int,
                  Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int,
                  Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int,
                  Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int,
                  Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int,
                  Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int,
                  Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int,
                  Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int,
                  Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int,
                  Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int,
                  Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int,
                  Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int,
                  Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int,
                  Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int,
                  Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int,
                  Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int,
                  Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int,
                  Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int,
                  Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int,
                  Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int,
                  Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int,
                  Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int,
                  Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int,
                  Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int, Backend.RegClass.int,
                  Backend.RegClass.int],
     slotBytes := 0,
     outgoing := 0,
     rulesFired := #[77, 1037, 458, 6, 1034] },
   #[#[#[]], #[#[Backend.Reg.vreg 192 (Backend.RegClass.int)]], #[]])

/-- Kernel equality ties the fixed concrete code/edge data to actual Stock lowering. -/
theorem observed_projection : (Stock.lower function).toOption.map (fun r => (r.code,r.edgeArgs)) = some codeArgs := by
  with_unfolding_all rfl
end Backend.Stock.Proof.TryNearCriticalValuesProjectionDraft
