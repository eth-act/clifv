from pathlib import Path
import json,hashlib,re,datetime,tarfile,shutil
root=Path('/home/lee/clifv/.worktrees/driver-proof-resume');docs=root/'docs/research';prefix='stock-try-normal-values'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
now=datetime.datetime.now(datetime.timezone.utc);stamp=now.strftime('%Y%m%dT%H%M%SZ')
batch=json.loads(Path('/tmp/'+prefix+'-batch.json').read_text());old=json.loads((docs/'stock-try-live-frame-scratch.json').read_text())
log=Path('/tmp/'+prefix+'-combined-axioms.log').read_text()
sets={m.group(1):sorted(x.strip() for x in m.group(2).split(',') if x.strip()) for m in re.finditer(r"'([^']+)' depends on axioms:\s*\[([^]]*)\]",log)}
for m in re.finditer(r"'([^']+)' does not depend on any axioms",log):sets[m.group(1)]=[]
for n,a in old['normal_audit']['sets'].items():assert sorted(a)==sets[n],n
assert len(sets)==len(old['normal_audit']['sets'])+len(batch['public_roots'])+len(batch['models'])
allowed={'propext','Classical.choice','Quot.sound'}
for n in batch['public_roots']+batch['models']:assert set(sets[n])<=allowed,n
constants=[json.loads(line.split('DELIVERY_CONSTANT ',1)[1]) for line in Path('/tmp/'+prefix+'-all-constants.log').read_text().splitlines() if line.startswith('DELIVERY_CONSTANT ')]
assert constants
for n,a in constants:assert set(a)<=allowed,n
mods={}
for m in batch['modules']:
 p=Path('/tmp')/m;check=json.loads(p.with_suffix('.check.json').read_text());assert check['actual_exit']==0
 rec={}
 for key,ext in [('source','.lean'),('object','.olean'),('log','.log'),('check','.check.json')]:
  f=p.with_suffix(ext);rec[key]=str(f);rec[key+'_sha256']=sha(f)
 for k in ['source','object','log']:assert rec[k+'_sha256']==check[k+'_sha256']
 assert not re.search(r'\b(sorry|admit|axiom|trace_state|native_decide)\b',p.with_suffix('.lean').read_text()),m
 mods[m]=rec
for audit in [prefix+'-combined-axioms',prefix+'-all-constants']:
 p=Path('/tmp')/audit;check=json.loads(p.with_suffix('.check.json').read_text());assert check['actual_exit']==0
 for k,ext in [('source','.lean'),('object','.olean'),('log','.log')]:assert sha(p.with_suffix(ext))==check[k+'_sha256']
prior={}
for name in ['source-execution-x','try-source','try-context','try-rule','try-rets','try-reservation','try-outgoing','try-values','try-emitted','try-machine','try-got','try-indirect','try-rename','try-resolved','try-gap','try-got-rename','try-normal-frame','try-metadata','source-index','try-normal-vector','try-critical-normal','source-erase','source-origin','try-live-frame']:
 d=json.loads((docs/f'stock-{name}-scratch.json').read_text())
 for m,rec in d['modules'].items():
  for k in ['source','object','log']:assert sha(rec[k])==rec[k+'_sha256'],(m,k)
  prior[m]=rec
freeze=json.loads(Path('/tmp/stock-coherent-build-inputs.json').read_text())
for group in ['source_sha256','validation_script_sha256']:
 for p,h in freeze[group].items():assert sha(root/p)==h,p
progress=json.loads(Path('/tmp/stock-pr246-gates-progress.json').read_text());progress.pop('completed_phases',None)
remaining=list(old['remaining_checklist']);remaining.append({'requirement':'Normal outgoing argument VALUES tied to successful source return binding and jump read','state':'Kernel proved actual source fresh setMany/tryNormal/getMany values agree with exact final-resolved .val/.ret numbers. Original dominance internally establishes normal .val availability and prevents fresh-ID overwrite. Both original and synthetic compiler factories expose actual normal mapping, excluding .exn/missing returns; canonical layout internally identifies machine and collected bases. NormalColumnValues describes exact stored Result.edgeArgs registers, length and VHolds. Whole near/GOT/indirect consumers construct SAME actual renamed stopped run/world/normal returns/post source agreement and actual column values; original-successor full non-vacuity witnesses pass for near/indirect [17,9] and actual 9argGOT16byte [17]. All original source/runtime/memory/callee conditions preserved. Critical whole-source variants kernel pass, but full critical machine/value non-vacuity remains PENDING; new near-critical observation repeatedly exceeds ordinary8GiB cap, including staged lower-only projection. Failed sources/checks and untrusted VM literal candidates saved; queue one larger-kernel check only after active heavy delivery gate releases lane. These critical variants and this scratch batch are NOT merge-ready. Parameter copies/source continuation and all remaining full-goal gates/production obligations remain OPEN.'})
counts={'modules':len(mods),'public_roots':len(batch['public_roots']),'models':len(batch['models']),'combined_roots_models':len(sets),'previous_preserved':len(old['normal_audit']['sets']),'all_new_module_constants':len(constants),'previous_modules_hashes_preserved':len(prior)}
receipt={'utc':now.isoformat(),'goal':'Original full #140 ACTIVE/INCOMPLETE; production LEGACY','scope':'Scratch-only additive Stock proofs, not coherent integration or merge-ready','delivery_target':'roughly eight substantive validated squash merges/day; coherent queue priority, backup and cleanup','modules':mods,'public_roots':batch['public_roots'],'models':batch['models'],'counts':counts,'normal_audit':{'path':'/tmp/'+prefix+'-combined-axioms.log','sha256':sha('/tmp/'+prefix+'-combined-axioms.log'),'sets':sets},'all_constant_audit':{'path':'/tmp/'+prefix+'-all-constants.log','sha256':sha('/tmp/'+prefix+'-all-constants.log'),'all_standard_only':True,'count':len(constants)},'previous_modules_hashes_preserved':list(prior),'canonical2246_source_and_script_freeze_preserved':True,'nonvacuity':{'original_near_GOT_indirect':'COMPLETE compiler/checker/physical/source and actual normal column values','critical_whole_source_variants':'PENDING complete machine/value witnesses; ordinary8GiB resource failures preserved; no merge readiness'},'MCP':'Deferred until coherent integration; no new calls','active_exact_PR246_validation':progress,'remaining_checklist':remaining}
(docs/(prefix+'-scratch.json')).write_text(json.dumps(receipt,indent=2)+'\n')
text=f'''Actual normal outgoing argument values — {now.isoformat()}

{len(mods)} scratch modules, {len(batch['public_roots'])} public roots and {len(batch['models'])} model pass actual kernel checks at 8 GiB. The cumulative audit covers {len(sets)} roots/models and preserves all 663 prior exact axiom sets. All {len(constants)} new-module constants, including private helpers, use only standard axioms. All {len(prior)} prior source/object/log hashes and frozen 2246 canonical sources plus 49 scripts are unchanged. Previous turn made progress: actual renamed near/GOT/indirect call-prefix and final-call live frames, complete same-state normal17/live9 witness, 663 audits/234 constants, verified dfda33a remote backup and 2.8 GB cleanup.

The executable source binding to fresh result IDs, successful tryNormal, and actual getMany now identify the values held by the compiler's exact final-resolved normal argument numbers. Original must-availability places every inherited .val below the fresh source IDs, so actual result binding cannot replace it. Actual compiler normal mapping supplies .ret bounds and excludes .exn/missing returns. The proof uses successful source binding/read and ordinary register agreement, rather than inventing a source value vector or adding an accepted-program condition.

Both original-successor and synthetic normal-edge factories now retain their actual mapM normal mapping as well as the exact Result.edgeArgs column. A new value relation records the actual stored register array, equal source-read length, virtual-register shape and VHolds for each argument. Internally derived source-slot indices and reservation layout prove that the collector base is the SAME base as the actual machine call, even though the helper factories obtain their source receipts separately. No caller register-map or base-identification certificate is required.

Whole near/GOT/true-indirect consumers preserve original lowering/scope/SSA/Dominated/input/ABI/memory/callee/argument contracts and the ordinary incoming live-source simulation agreement. They construct the SAME actual renamed stopped run, returned world, normal returned values and post-call source agreement; that post-call environment holds the exact stored outgoing column's actual source-read values. Successful source result binding, tryNormal and getMany are runtime observations, not compiler input filters. All older theorem variants remain unchanged.

COMPLETE original-successor witnesses pass: near and true-indirect actual columns hold [17,9], while the existing nine-argument GOT/16byte fixture's ACTUAL one-element normal column holds [17]. The indirect fixture retains its nonidentity callee alias and source callee4096; a kernel-only fixed-example observation proves simultaneous source9/callee4096 aliases distinct, solely for non-vacuity, not as a new input requirement. All compiler/prepare/forced checkedfallback/checker/physical stages, original conditions, original memory/callee contracts and full source runs returning17 are retained.

Critical whole-source consumers also compile, and the conditional value-column proof covers actual synthetic row0. Their COMPLETE critical machine/value non-vacuity gate is still PENDING. The new near-critical full observation, split observation, and staged exact code projection exceed the ordinary 8 GiB cap. Replacing the record update by a definitionally equal literal input did not resolve that resource limit. All failed checks, staged source and VM-produced candidate code are archived; the VM candidate is NOT a proof and its projection equality is NOT verified. Queue the larger kernel check only after the currently active delivery heavy lane is free. Do not call these critical variants or this batch merge-ready. Existing cached GOT/indirect critical compiler/physical fixtures remain preserved, but do not substitute for the new full value-execution witness.

Next prove parameter-copy agreement and source continuation using these actual normal values, then finish the critical witness gate when the heavy lane is free. Normal control-index/CFG composition and original/synthetic edge execution still need their whole-driver connection. Shared payload endpoints/exception machine semantics, full zero-return/sret/x8/width/handler/Try-critical matrix, uncovered families/effects/sinking/source/block/whole-driver simulation AND completeness, original-input context/visitor/static/checker/fallback/physical totality, coherent integration/public/private/compiler/MCP/full/crates/runtime/encoder/BOTH E2E identity-stage parity, production compiler/checker/linker/generated consumers and a fresh COMPLETE comparison remain mandatory. Production remains LEGACY. Preserve Kev's shared S10/FP/Link interfaces.

The same live delivery supervisor 3247835 and held canonical controller1233457 retain completed work and the exclusive shared-cache lease. PR246 progressed from968 to995/1415 during this turn, with actual process inspected live. Main789152e is unchanged. Preserve old-head receipts, reconcile CURRENT main and rerun actual-head affected audits and ALL full gates before dependent squash246→247. Target roughly8 substantive validated merges/day. No merge, new worktree, MCP call, concurrent heavy check, gate restart or other-project cleanup. Evidence and full remaining checklist: {prefix}-scratch.json.
'''

(docs/(prefix+'-scratch.md')).write_text(text);plan=root/'docs/plans/test-binary-alignment-recovery.md';plan.write_text(plan.read_text()+'\n\n'+text)
files=[]
for rec in mods.values():files.extend(Path(rec[k]) for k in ['source','object','log','check'])
for name in [prefix+'-combined-axioms',prefix+'-all-constants']:
 for ext in ['.lean','.log','.olean','.check.json']:files.append(Path('/tmp')/(name+ext))
for p in ['/tmp/'+prefix+'-batch.json','/tmp/stock-try-rule-inputs.json','/tmp/stock-try-reservation-check.py','/tmp/'+prefix+'-close.py','/tmp/'+prefix+'-make-audit.py','/tmp/'+prefix+'-restore.py','/tmp/'+prefix+'-status44-start.md','/tmp/'+prefix+'-status52.json','/tmp/'+prefix+'-status71.json','/tmp/'+prefix+'-task140.json','/tmp/stock-try-normal-values-issues.json']:
 if Path(p).exists():files.append(Path(p))
for name in ['StockTryNearCriticalValuesFixture','StockTryNearCriticalValuesFixture-combined-failed','StockTryNearCriticalValuesData','StockTryNearCriticalValuesProjection','StockTryNearCriticalValuesProjection-update-failed']:
 for ext in ['.lean','.olean','.log','.check.json']:
  p=Path('/tmp')/(name+ext)
  if p.exists():files.append(p)
for name in ['StockTryNearCriticalValuesFixture.staged.lean','stock-try-normal-value-columns-tail.lean']:
 p=Path('/tmp')/name
 if p.exists():files.append(p)
files.extend([docs/(prefix+'-scratch.json'),docs/(prefix+'-scratch.md'),docs/'stock-delivery-main-drift.json',plan])
archive=Path('/home/lee/.clifv-recovery')/(stamp+'-try-normal-values')/'checkpoint.tar.gz';archive.parent.mkdir(parents=True)
with tarfile.open(archive,'w:gz',compresslevel=1) as t:
 for p in files:t.add(p,arcname=str(p).lstrip('/'),recursive=False)
with tarfile.open(archive,'r:gz') as t:
 for p in files:assert t.extractfile(str(p).lstrip('/')).read()==p.read_bytes(),p
snapshot=Path('/tmp/stock-try-rule-inputs');size=sum(p.stat().st_size for p in snapshot.rglob('*') if p.is_file());shutil.rmtree(snapshot)
backup={'utc':now.isoformat(),'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(files),'all_members_byte_verified':True,'previous_remote_backup':json.loads((docs/'stock-try-live-frame-backup.json').read_text())['remote'],'cleanup':{'duplicate_dependency_snapshot_removed':True,'bytes_reclaimed':size,'unique_sources_objects_logs_checks_audits_preserved':True,'one_shared_warm_cache_retained':True,'other_projects_touched':False,'free_bytes':shutil.disk_usage(root).free}}
(docs/(prefix+'-backup.json')).write_text(json.dumps(backup,indent=2)+'\n');Path('/tmp/'+prefix+'-archive-path').write_text(str(archive))
print(json.dumps({'counts':counts,'archive':str(archive),'cleanup':backup['cleanup'],'gate':progress},indent=2))
