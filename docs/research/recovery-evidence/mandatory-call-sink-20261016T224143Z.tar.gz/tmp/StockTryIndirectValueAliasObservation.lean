import StockTryResolvedRuns
import FV.Backend.Proof.PerEdgeSpillEntryFixture
namespace Backend.Stock.Proof.TryIndirectValueAliasObservationDraft
open Backend.Proof Backend.Proof.Driver TryResolvedRunsDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 16000000
/-- The real fixed witness keeps its simultaneously live source9 and callee4096
in distinct final-resolved registers; this is test evidence, not an input filter. -/
theorem observed : (Stock.lower (SpillEntryFixture.function true)).toOption.any
    (fun r => keyMap r 192 != keyMap r 193) = true := by decide +kernel
end Backend.Stock.Proof.TryIndirectValueAliasObservationDraft
