import StockTryNormalNumbers
import StockTryNormalDefined
import StockTryLiveValues
import FV.Backend.Proof.LowerSim
namespace Backend.Stock.Proof.TryNormalArgumentValuesDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open TryNormalNumbersDraft TryNormalVectorDraft TryRetsTotalDraft TryNormalDefinedDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private theorem mapM_defined {α β : Type} (g : α → Option β) {xs : List α} {ys : List β}
    (run : xs.mapM g = some ys) {x : α} (member : x ∈ xs) : ∃ y,g x = some y := by
  induction xs generalizing ys with
  | nil => cases member
  | cons a xs ih =>
    simp only [List.mapM_cons,Option.bind_eq_bind,Option.bind_eq_some_iff,Option.pure_def,Option.some.injEq] at run
    obtain ⟨y,head,tail,rest,rfl⟩ := run
    rcases List.mem_cons.mp member with rfl | member
    · exact ⟨y,head⟩
    · exact ih rest member
/-- Executable source fresh-result binding, tryNormal and actual getMany
identify VALUES held by the exact final-resolved .val/.ret argument numbers.
The compiler mapping excludes missing returns/.exn; source availability prevents
fresh result binding from replacing any inherited .val. -/
theorem stock_try_normal_argument_values {f : Clif.Function} {result : Result} {bi : Nat} {b : Clif.Block}
    (block : f.blocks[bi]? = some b) {fr : Clif.Frame} {rvals values : List Clif.Val} {regs : Clif.Regs}
    (bound : fr.regs.setMany ((List.range rvals.length).map (f.freshValue + ·)) rvals = some regs)
    {et : Clif.ExnTable} {bc : Clif.BlockCall}
    (normal : Clif.tryNormal et f.freshValue = .ok bc)
    (read : ({fr with regs} : Clif.Frame).getMany bc.args = .ok values)
    (available : ∀ x,Clif.TryArg.val x ∈ et.normal.args → x ∈ availOf f (availIn f result.ctx) bi b.body.length)
    {base : Nat} {argRegs : List Reg}
    (mapping : et.normal.args.mapM (normalReg? result.ctx (reservedReturns base rvals.length)) = some argRegs)
    {rho : Nat → CV}
    (held : ValuesHeld (fun x => x ∈ availOf f (availIn f result.ctx) bi b.body.length) result.ctx fr
      (fun key => rho (aliasNum result.final.alias key)))
    (returned : ∀ j v,rvals[j]? = some v → VHolds v (rho (aliasNum result.final.alias (base+j)))) :
    (normalArgumentNumbers result base et).length = values.length ∧
      ∀ (i : Nat) (v : Clif.Val) (n : Nat),values[i]? = some v → (normalArgumentNumbers result base et)[i]? = some n → VHolds v (rho n) := by
  have sourceArgs := tryNormal_ok normal
  have lengths := (getMany_spec read).1
  rw [sourceArgs] at lengths
  refine ⟨by simpa only [normalArgumentNumbers,List.length_map] using lengths,?_⟩
  intro i v n atValue atNumber
  simp only [normalArgumentNumbers,List.getElem?_map] at atNumber
  cases atArg : et.normal.args[i]? with
  | none => rw [atArg] at atNumber; cases atNumber
  | some arg =>
    rw [atArg] at atNumber
    simp only [Option.map_some,Option.some.injEq] at atNumber
    subst n
    have member := List.mem_of_getElem? atArg
    have sourceAt : bc.args[i]? = some (tryArgVal f.freshValue arg) := by rw [sourceArgs]; simp only [List.getElem?_map,atArg,Option.map_some]
    obtain ⟨value,atReg,atRead⟩ := (getMany_spec read).2 i _ sourceAt
    have sameValue : value = v := Option.some.inj (atRead.symm.trans atValue)
    subst v
    have current : regs (tryArgVal f.freshValue arg) = some value := atReg
    obtain ⟨r,reg⟩ := mapM_defined _ mapping member
    cases arg with
    | val x =>
      have live := available x member
      have preserved : regs x = fr.regs x := by
        apply setMany_other bound
        intro written
        obtain ⟨j,inside,same⟩ := List.mem_map.mp written
        have below := source_available_below_try_fresh block live
        have lower : f.freshValue ≤ x := by rw [← same]; exact Nat.le_add_right _ _
        exact (Nat.not_le_of_gt below) lower
      change regs x = some value at current
      rw [preserved] at current
      obtain ⟨key,mapped,valueHeld⟩ := held x live value current
      simpa only [normalArgNum,edgeValueNum,mapped] using valueHeld
    | ret j =>
      have inside : j < rvals.length := by
        have bound := (List.getElem?_eq_some_iff.mp reg).1
        simpa only [normalReg?,reservedReturns,List.length_map,List.length_range] using bound
      have resultsNodup : ((List.range rvals.length).map (f.freshValue + ·)).Nodup :=
        List.Pairwise.map _ (fun a b different same => different (Nat.add_left_cancel same)) List.nodup_range
      have actual : regs (f.freshValue+j) = some rvals[j] :=
        setMany_nodup bound resultsNodup j _ _ (by simp [inside]) (List.getElem?_eq_getElem inside)
      change regs (f.freshValue+j) = some value at current
      cases Option.some.inj (actual.symm.trans current)
      exact returned j _ (List.getElem?_eq_getElem inside)
    | exn j => cases reg
end Backend.Stock.Proof.TryNormalArgumentValuesDraft
