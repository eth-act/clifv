import StockTryNormalSourceValues
import StockTryGotLiveResolvedSource
namespace Backend.Stock.Proof.TryNormalIndirectSourceValuesDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open TryLiveResolvedSourceDraft TryGotLiveResolvedSourceDraft TryLiveNormalDraft TryResolvedRunsDraft
open TryDirectSourceRunDraft TryGotSourceRunDraft TryIndirectSourceRunDraft
open TryNormalValueColumnsDraft TrySelectedCallsDraft TryBranchAbiDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
theorem stock_lower_indirect_try_normal_column_source_values {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f) (input : Prg.iselInB f = true)
    (abi : Backend.Proof.Spill.AbiSigsOk f)
    {label bi : Nat} {b : Clif.Block} (node : result.order.nodes[label]? = some (.original bi))
    (block : f.blocks[bi]? = some b) {callee : Nat} {args : List Nat} {et : Clif.ExnTable}
    (kind : b.term = .tryCallIndirect callee args et) {sig : Clif.Signature} {items : List (Option Nat)}
    (table : exnTableOpnd f et = .ok (sig,items))
    {targetLabel targetBi : Nat}
    (successor : result.order.successors[label]![et.handlers.length]? = some targetLabel)
    (target : result.order.nodes[targetLabel]? = some (.original targetBi))
    {isem : Sem} {MR : MemRelT} (driver : DriverSem isem)
    {Pc : String → Clif.Signature → List Clif.Val → Clif.Mem → Prop} {env : Clif.Env}
    (calls : IndCallsRefineP Pc env (indSigs f) MR isem)
    {fr : Clif.Frame} {ρ : Nat → CV} {w : Arm.ArmState} {cm cm' : Clif.Mem} {vals rvals : List Clif.Val}
    (held : ValuesHeld (fun x => x = callee ∨ x ∈ args) result.ctx fr (fun key => ρ (keyMap result key))) (read : fr.getMany args = .ok vals)
    (typed : vals.map (·.ty) = Clif.AbiParam.tys sig.params) (related : MR fr.slots cm w)
    {name : String} {address : Nat}
    (calleeValue : fr.get callee = .ok ⟨.i64,BitVec.ofNat 64 address⟩)
    (symbol : cm.symbols name = some address)
    (signature : ∀ s,env.sigOf name = some s → sig.abiMatch s = true)
    {g : List Clif.Val → Clif.Mem → Clif.Outcome} (found : env.extern name = some g)
    (pin : Pc name sig vals cm) (returned : g vals cm = .returned rvals cm')
    (results : rvals.length = sig.returns.length)    (liveHeld : ValuesHeld (fun x => x ∈ availOf f (availIn f result.ctx) bi b.body.length) result.ctx fr
      (fun key => ρ (keyMap result key)))
    {regs : Clif.Regs} {bc : Clif.BlockCall} {normalValues : List Clif.Val}
    (bound : fr.regs.setMany ((List.range rvals.length).map (f.freshValue + ·)) rvals = some regs)
    (normal : Clif.tryNormal et f.freshValue = .ok bc)
    (normalRead : ({fr with regs} : Clif.Frame).getMany bc.args = .ok normalValues) :
    ∃ (raw : IndirectTryRun f result label bi b sig isem MR fr (fun key => ρ (keyMap result key)) w rvals cm')
      (k : Nat) (i : MInst) (ops : Array Operand) (atCall : Nat → CV) (world : Arm.ArmState)
      (outs : List CV) (finalWorld : Arm.ArmState),
      seqRun isem (raw.source.branch.step.emitted.toList.map (·.mapRegs (resolver result))) ρ w =
        some (.stop k i ops atCall world outs finalWorld (.goto raw.info.handlers.length)) ∧
      MR fr.slots cm' finalWorld ∧
      (∀ (j : Nat) (v : Clif.Val),rvals[j]? = some v → VHolds v (vdefUpd ops outs atCall (keyMap result (raw.base+j)))) ∧
      ValuesHeld (fun x => x ∈ availOf f (availIn f result.ctx) bi b.body.length) result.ctx fr
        (fun key => vdefUpd ops outs atCall (keyMap result key)) ∧
      NormalColumnValues result label et.handlers.length normalValues (vdefUpd ops outs atCall) := by
  obtain ⟨raw,run⟩ := stock_lower_indirect_try_resolved_live_normal_source_run lowered scope dominated.ssa input abi
    node block kind table driver calls held read typed related calleeValue symbol signature found pin returned results
  obtain ⟨k,i,ops,atCall,world,outs,finalWorld,execute,returnedWorld,returns,frame⟩ := run
  have postHeld : ValuesHeld (fun x => x ∈ availOf f (availIn f result.ctx) bi b.body.length) result.ctx fr
      (fun key => vdefUpd ops outs atCall (keyMap result key)) := by
    intro x available v present
    obtain ⟨key,mapped,value⟩ := liveHeld x available v present
    refine ⟨key,mapped,?_⟩
    change VHolds v (vdefUpd ops outs atCall (keyMap result key))
    rw [(frame x key trivial mapped).2]
    exact value
  have sourceTableEq : sourceTable b.term = some et := by rw [kind]; rfl
  have column := stock_lower_original_normal_column_values lowered scope dominated input node block sourceTableEq table
    successor target raw.source raw.base raw.layout results bound normal normalRead postHeld returns
  exact ⟨raw,k,i,ops,atCall,world,outs,finalWorld,execute,returnedWorld,returns,postHeld,column⟩

/-- Critical normal-edge version; the actual source predecessor is preserved. -/
theorem stock_lower_indirect_try_critical_normal_column_source_values {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f) (input : Prg.iselInB f = true)
    (abi : Backend.Proof.Spill.AbiSigsOk f)
    {label bi : Nat} {b : Clif.Block} (node : result.order.nodes[label]? = some (.original bi))
    (block : f.blocks[bi]? = some b) {callee : Nat} {args : List Nat} {et : Clif.ExnTable}
    (kind : b.term = .tryCallIndirect callee args et) {sig : Clif.Signature} {items : List (Option Nat)}
    (table : exnTableOpnd f et = .ok (sig,items))
    {edgeLabel targetBi : Nat}
    (edge : result.order.nodes[edgeLabel]? = some (.edge bi et.handlers.length targetBi))
    {isem : Sem} {MR : MemRelT} (driver : DriverSem isem)
    {Pc : String → Clif.Signature → List Clif.Val → Clif.Mem → Prop} {env : Clif.Env}
    (calls : IndCallsRefineP Pc env (indSigs f) MR isem)
    {fr : Clif.Frame} {ρ : Nat → CV} {w : Arm.ArmState} {cm cm' : Clif.Mem} {vals rvals : List Clif.Val}
    (held : ValuesHeld (fun x => x = callee ∨ x ∈ args) result.ctx fr (fun key => ρ (keyMap result key))) (read : fr.getMany args = .ok vals)
    (typed : vals.map (·.ty) = Clif.AbiParam.tys sig.params) (related : MR fr.slots cm w)
    {name : String} {address : Nat}
    (calleeValue : fr.get callee = .ok ⟨.i64,BitVec.ofNat 64 address⟩)
    (symbol : cm.symbols name = some address)
    (signature : ∀ s,env.sigOf name = some s → sig.abiMatch s = true)
    {g : List Clif.Val → Clif.Mem → Clif.Outcome} (found : env.extern name = some g)
    (pin : Pc name sig vals cm) (returned : g vals cm = .returned rvals cm')
    (results : rvals.length = sig.returns.length)    (liveHeld : ValuesHeld (fun x => x ∈ availOf f (availIn f result.ctx) bi b.body.length) result.ctx fr
      (fun key => ρ (keyMap result key)))
    {regs : Clif.Regs} {bc : Clif.BlockCall} {normalValues : List Clif.Val}
    (bound : fr.regs.setMany ((List.range rvals.length).map (f.freshValue + ·)) rvals = some regs)
    (normal : Clif.tryNormal et f.freshValue = .ok bc)
    (normalRead : ({fr with regs} : Clif.Frame).getMany bc.args = .ok normalValues) :
    ∃ (raw : IndirectTryRun f result label bi b sig isem MR fr (fun key => ρ (keyMap result key)) w rvals cm')
      (k : Nat) (i : MInst) (ops : Array Operand) (atCall : Nat → CV) (world : Arm.ArmState)
      (outs : List CV) (finalWorld : Arm.ArmState),
      seqRun isem (raw.source.branch.step.emitted.toList.map (·.mapRegs (resolver result))) ρ w =
        some (.stop k i ops atCall world outs finalWorld (.goto raw.info.handlers.length)) ∧
      MR fr.slots cm' finalWorld ∧
      (∀ (j : Nat) (v : Clif.Val),rvals[j]? = some v → VHolds v (vdefUpd ops outs atCall (keyMap result (raw.base+j)))) ∧
      ValuesHeld (fun x => x ∈ availOf f (availIn f result.ctx) bi b.body.length) result.ctx fr
        (fun key => vdefUpd ops outs atCall (keyMap result key)) ∧
      NormalColumnValues result edgeLabel 0 normalValues (vdefUpd ops outs atCall) := by
  obtain ⟨raw,run⟩ := stock_lower_indirect_try_resolved_live_normal_source_run lowered scope dominated.ssa input abi
    node block kind table driver calls held read typed related calleeValue symbol signature found pin returned results
  obtain ⟨k,i,ops,atCall,world,outs,finalWorld,execute,returnedWorld,returns,frame⟩ := run
  have postHeld : ValuesHeld (fun x => x ∈ availOf f (availIn f result.ctx) bi b.body.length) result.ctx fr
      (fun key => vdefUpd ops outs atCall (keyMap result key)) := by
    intro x available v present
    obtain ⟨key,mapped,value⟩ := liveHeld x available v present
    refine ⟨key,mapped,?_⟩
    change VHolds v (vdefUpd ops outs atCall (keyMap result key))
    rw [(frame x key trivial mapped).2]
    exact value
  have sourceTableEq : sourceTable b.term = some et := by rw [kind]; rfl
  have column := stock_lower_critical_normal_column_values lowered scope dominated input node block sourceTableEq table
    edge raw.source raw.base raw.layout results bound normal normalRead postHeld returns
  exact ⟨raw,k,i,ops,atCall,world,outs,finalWorld,execute,returnedWorld,returns,postHeld,column⟩

end Backend.Stock.Proof.TryNormalIndirectSourceValuesDraft
