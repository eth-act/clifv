import StockTryNormalMappedColumns
import StockTryNormalArgumentValues
namespace Backend.Stock.Proof.TryNormalValueColumnsDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Driver.Fix Isle Isle.Interp Isle.Aarch64
open TryNormalMappedColumnsDraft TryNormalArgumentValuesDraft TryNormalNumbersDraft TryNormalVectorDraft
open TryRetsTotalDraft TrySourceContextDraft TryBranchSelectionDraft TryBranchAbiDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private theorem view_avail {ctx original : Ctx}
    (view : DFGViewEq ctx original) (f : Clif.Function) :
    availIn f ctx = availIn f original := by
  have args : defArgs ctx = defArgs original := by
    funext x
    simp only [defArgs, Ctx.defInst?, view.valDef, view.insts]
  have users : fUsers ctx = fUsers original := by
    simp only [fUsers, usersN, args, view.valDef]
  have bytes : fInB0 f ctx id = fInB0 f original id := by
    unfold fInB0
    rw [view.valDef]
  have work : fWork0 f ctx id = fWork0 f original id := by
    simp only [fWork0, view.valDef, bytes, args]
  simp only [availIn, inFix_eq, users, bytes, work, view.valDef]

private theorem built_context {f : Clif.Function} {result : Result} (run : Stock.lower f = .ok result) :
    ∃ ranges,Stock.buildCtx f = .ok (result.ctx,ranges,result.initial) := by
  unfold Stock.lower at run
  dsimp only at run
  repeat' first
    | (solve | cases run)
    | simp only [bind,Except.bind,pure,Except.pure] at run
    | split at run
  cases run
  rename_i _ built hbuild _ order horder _ driver hdriver
  exact ⟨_,hbuild⟩
/-- Every inherited normal-table value is available at the original source
pre-call boundary, derived from the original dominance/context construction. -/
theorem stock_lower_try_normal_values_available {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (dominated : Dominated f)
    {bi : Nat} {b : Clif.Block} (block : f.blocks[bi]? = some b)
    {et : Clif.ExnTable} (kind : IsTryWith b.term et) :
    ∀ x,Clif.TryArg.val x ∈ et.normal.args → x ∈ availOf f (availIn f result.ctx) bi b.body.length := by
  obtain ⟨ranges,build⟩ := built_context lowered
  obtain ⟨old,st,oldBuild,spec,view⟩ := buildCtx_source build
  intro x member
  have etMember : x ∈ et.vals := by
    simp only [Clif.ExnTable.vals,Clif.TryDest.vals,List.mem_append,List.mem_filterMap]
    exact .inl ⟨.val x,member,rfl⟩
  have use := etVals_termArgs kind x etMember
  have available := (dominated.uses old ranges st oldBuild bi b block).2 x (by
    rcases kind with ⟨fn,args,term⟩ | ⟨callee,args,term⟩ <;> rw [term] at use ⊢ <;> simpa only [abiTerm] using use)
  rw [view_avail view f]
  exact available

/-- Actual returned edge-column registers, with the complete successful source
normal argument read and pointwise held values, not merely register numbers. -/
def NormalColumnValues (result : Result) (label column : Nat) (values : List Clif.Val) (rho : Nat → CV) : Prop :=
  ∃ regs : Array Reg,(result.edgeArgs[label]?.bind fun row => row[column]?) = some regs ∧
    regs.size = values.length ∧ ∀ (i : Nat) (v : Clif.Val) (r : Reg),values[i]? = some v → regs[i]? = some r →
      ∃ n,r = .vreg n .int ∧ VHolds v (rho n)
private theorem value_column {result : Result} {label column base : Nat} {et : Clif.ExnTable}
    {values : List Clif.Val} {rho : Nat → CV}
    (stored : (result.edgeArgs[label]?.bind fun row => row[column]?) =
      some ((normalArgumentNumbers result base et).map (fun n => Reg.vreg n .int)).toArray)
    (valuesHeld : (normalArgumentNumbers result base et).length = values.length ∧
      ∀ (i : Nat) (v : Clif.Val) (n : Nat),values[i]? = some v → (normalArgumentNumbers result base et)[i]? = some n → VHolds v (rho n)) :
    NormalColumnValues result label column values rho := by
  refine ⟨_,stored,by simpa only [List.size_toArray,List.length_map] using valuesHeld.1,?_⟩
  intro i v r atValue atReg
  simp only [List.getElem?_toArray,List.getElem?_map] at atReg
  cases atNumber : (normalArgumentNumbers result base et)[i]? with
  | none => rw [atNumber] at atReg; cases atReg
  | some n =>
    rw [atNumber] at atReg
    have same : Reg.vreg n .int = r := Option.some.inj atReg
    exact ⟨n,same.symm,valuesHeld.2 i v n atValue atNumber⟩
private theorem layout_base_unique {slots : Array (List Reg × List Reg)} {i a b count : Nat}
    (first : slots[i]! = (reservedReturns a count,reservedPayloads a count))
    (second : slots[i]! = (reservedReturns b count,reservedPayloads b count)) : a = b := by
  have eq := congrArg Prod.snd (first.symm.trans second)
  have heads := congrArg List.head? eq
  simp only [reservedPayloads,List.head?_cons,Option.some.injEq] at heads
  have numbers := (Reg.vreg.inj heads).1
  omega
private theorem isTryOfTable {term : Clif.Terminator} {et : Clif.ExnTable}
    (kind : sourceTable term = some et) : IsTryWith term et := by
  cases shape : term <;> simp only [sourceTable,shape] at kind
  all_goals try contradiction
  case tryCall fn args table => cases kind; exact .inl ⟨fn,args,rfl⟩
  case tryCallIndirect callee args table => cases kind; exact .inr ⟨callee,args,rfl⟩
/-- The actual original-node normal column carries actual source jump VALUES.
The canonical result base is matched to the machine source internally; actual
compiler mapping excludes invalid return indices and normal payload operands. -/
theorem stock_lower_original_normal_column_values {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f) (input : Prg.iselInB f = true)
    {label bi : Nat} {b : Clif.Block} (node : result.order.nodes[label]? = some (.original bi)) (block : f.blocks[bi]? = some b)
    {et : Clif.ExnTable} {sig : Clif.Signature} {items : List (Option Nat)}
    (kind : sourceTable b.term = some et) (table : exnTableOpnd f et = .ok (sig,items))
    {targetLabel targetBi : Nat} (successor : result.order.successors[label]![et.handlers.length]? = some targetLabel)
    (target : result.order.nodes[targetLabel]? = some (.original targetBi))
    (owner : TryBranchSource f result label bi b) (base : Nat)
    (layout : result.initial.tryRegs[owner.ti]! = (reservedReturns base sig.returns.length,reservedPayloads base sig.returns.length))
    {fr : Clif.Frame} {rvals values : List Clif.Val} {regs : Clif.Regs}
    (results : rvals.length = sig.returns.length)
    (bound : fr.regs.setMany ((List.range rvals.length).map (f.freshValue + ·)) rvals = some regs)
    {bc : Clif.BlockCall} (normal : Clif.tryNormal et f.freshValue = .ok bc)
    (read : ({fr with regs} : Clif.Frame).getMany bc.args = .ok values) {rho : Nat → CV}
    (held : ValuesHeld (fun x => x ∈ availOf f (availIn f result.ctx) bi b.body.length) result.ctx fr
      (fun key => rho (aliasNum result.final.alias key)))
    (returned : ∀ j v,rvals[j]? = some v → VHolds v (rho (aliasNum result.final.alias (base+j)))) :
    NormalColumnValues result label et.handlers.length values rho := by
  obtain ⟨source,selected,colbase,before,value,after,edgeInput,edgeNext,args,slots,helper,defs,call,mapping,numbers,stored⟩ :=
    stock_lower_try_normal_mapped_column lowered scope input node block kind table successor target
  have first : result.initial.tryRegs[blockStart f bi+b.body.length]! =
      (reservedReturns colbase sig.returns.length,reservedPayloads colbase sig.returns.length) := by simpa only [source.index] using slots
  have second : result.initial.tryRegs[blockStart f bi+b.body.length]! =
      (reservedReturns base sig.returns.length,reservedPayloads base sig.returns.length) := by simpa only [owner.index] using layout
  have equal := layout_base_unique first second
  subst colbase
  have mapping' : et.normal.args.mapM (normalReg? result.ctx (reservedReturns base rvals.length)) = some args.toList := by
    simpa only [results] using mapping
  exact value_column stored (stock_try_normal_argument_values block bound normal read
    (stock_lower_try_normal_values_available lowered dominated block (isTryOfTable kind)) mapping' held returned)
/-- Actual synthetic normal-edge row0 carries the SAME original source jump
values; unreachable predecessors and critical insertion are left intact. -/
theorem stock_lower_critical_normal_column_values {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f) (input : Prg.iselInB f = true)
    {label bi : Nat} {b : Clif.Block} (node : result.order.nodes[label]? = some (.original bi)) (block : f.blocks[bi]? = some b)
    {et : Clif.ExnTable} {sig : Clif.Signature} {items : List (Option Nat)}
    (kind : sourceTable b.term = some et) (table : exnTableOpnd f et = .ok (sig,items))
    {edgeLabel targetBi : Nat} (edge : result.order.nodes[edgeLabel]? = some (.edge bi et.handlers.length targetBi))
    (owner : TryBranchSource f result label bi b) (base : Nat)
    (layout : result.initial.tryRegs[owner.ti]! = (reservedReturns base sig.returns.length,reservedPayloads base sig.returns.length))
    {fr : Clif.Frame} {rvals values : List Clif.Val} {regs : Clif.Regs}
    (results : rvals.length = sig.returns.length)
    (bound : fr.regs.setMany ((List.range rvals.length).map (f.freshValue + ·)) rvals = some regs)
    {bc : Clif.BlockCall} (normal : Clif.tryNormal et f.freshValue = .ok bc)
    (read : ({fr with regs} : Clif.Frame).getMany bc.args = .ok values) {rho : Nat → CV}
    (held : ValuesHeld (fun x => x ∈ availOf f (availIn f result.ctx) bi b.body.length) result.ctx fr
      (fun key => rho (aliasNum result.final.alias key)))
    (returned : ∀ j v,rvals[j]? = some v → VHolds v (rho (aliasNum result.final.alias (base+j)))) :
    NormalColumnValues result edgeLabel 0 values rho := by
  obtain ⟨source,selected,colbase,before,value,after,edgeInput,edgeNext,args,slots,helper,defs,call,mapping,numbers,stored⟩ :=
    stock_lower_try_critical_normal_mapped_column lowered scope input node block kind table edge
  have first : result.initial.tryRegs[blockStart f bi+b.body.length]! =
      (reservedReturns colbase sig.returns.length,reservedPayloads colbase sig.returns.length) := by simpa only [source.index] using slots
  have second : result.initial.tryRegs[blockStart f bi+b.body.length]! =
      (reservedReturns base sig.returns.length,reservedPayloads base sig.returns.length) := by simpa only [owner.index] using layout
  have equal := layout_base_unique first second
  subst colbase
  have mapping' : et.normal.args.mapM (normalReg? result.ctx (reservedReturns base rvals.length)) = some args.toList := by simpa only [results] using mapping
  exact value_column stored (stock_try_normal_argument_values block bound normal read
    (stock_lower_try_normal_values_available lowered dominated block (isTryOfTable kind)) mapping' held returned)

end Backend.Stock.Proof.TryNormalValueColumnsDraft
