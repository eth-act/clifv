import StockTryNearCriticalValuesProjection
namespace Backend.Stock.Proof.TryNearCriticalValuesFixtureDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Backend.Proof.PerEdgeSpill
set_option maxRecDepth 20000
set_option maxHeartbeats 16000000
abbrev function := TryNearCriticalValuesProjectionDraft.function
private def original  : Ctx × Array (Nat × Nat) × LState :=
  (Backend.buildCtx function).toOption.getD (sinkCtx,#[],default)
private theorem original_build  : Backend.buildCtx function = .ok (original indirect) := by
  rfl
private theorem dominated  : Dominated function := by
  cases indirect
  all_goals
    constructor
    · simp only [valueDefs,function,CriticalSplitFixture.function]; decide +kernel
    · intro ctx ranges st build bi b found
      have bound : bi < 3 := by have h := lt_of_getElem? found; simpa [function,CriticalSplitFixture.function] using h
      have choices : bi = 0 ∨ bi = 1 ∨ bi = 2 := by omega
      rcases choices with rfl | rfl | rfl
      all_goals
        simp [function,CriticalSplitFixture.function] at found
        subst b
        constructor
        · intro j stm present y member
          cases j <;> simp at present <;> subst stm <;> cases member
        · intro y member
          first
          | (change y ∈ ([] : List Nat) at member; cases member)
          | (change y ∈ [0] at member; simp only [List.mem_singleton] at member; subst y; simp [availOf,function,defsBefore,defsFrom])
          | (change y ∈ [2] at member; simp only [List.mem_singleton] at member; subst y; simp [availOf,function,defsBefore,defsFrom])
          | (change y ∈ [7] at member; simp only [List.mem_singleton] at member; subst y; simp [availOf,function,defsBefore,defsFrom])
    · intro ctx ranges st build tl x available notLocal y member
      have fixed := (inFix_fixOk (ctx := ctx) (gn := id)).cand tl x available
      have context := congrArg Prod.fst (Except.ok.inj (build.symm.trans (original_build _)))
      change ctx = _ at context
      rw [context] at member
      have values := fixed.2.2.2.1
      simp [valueDefs,function,CriticalSplitFixture.function] at values
      first | (rcases values with rfl | rfl | rfl) | (rcases values with rfl | rfl)
      all_goals change y ∈ ([] : List Nat) at member; cases member

private def physicalPipeline : Except String (EdgeVCode × RFunc × AFunc) := do
  let p ← prepareAt TryNearCriticalValuesProjectionDraft.codeArgs.1 TryNearCriticalValuesProjectionDraft.codeArgs.2
  let rf ← allocResultAt p.code p.edges (.error "force critical normal value witness")
  let af ← lowerRFunc p.code rf
  pure (p,rf,af)
private theorem observed_physical : physicalPipeline.isOk = true := by decide +kernel
private theorem scope : LowerScope function := by apply lowerScope_of; decide +kernel
private theorem arity : ArityOk function := by apply arityOk_of; decide +kernel
structure Output where
  result : Result
  prepared : EdgeVCode
  rf : RFunc
  af : AFunc
  lowered : Stock.lower function = .ok result
  scope : LowerScope function
  dominated : Dominated function
  arity : ArityOk function
  prepare : prepareAt result.code result.edgeArgs = .ok prepared
  fallback : rf = spillAllocAt prepared.code prepared.edges
  accepted : checkAllocAt prepared.code prepared.edges rf = .ok ()
  physical : lowerRFunc prepared.code rf = .ok af
  outgoing : result.code.outgoing = 0
/-- Full near-call critical-edge pipeline. Kernel-checked code projection and
concrete physical checks are separate bounded proof stages, with no extra input. -/
theorem stock_near_critical_values_fixture : Nonempty Output := by
  have projected := TryNearCriticalValuesProjectionDraft.observed_projection
  cases lowered : Stock.lower function with
  | error err => rw [lowered] at projected; cases projected
  | ok result =>
    rw [lowered] at projected
    have dataEq : (result.code,result.edgeArgs) = TryNearCriticalValuesProjectionDraft.codeArgs := Option.some.inj projected
    have codeEq := congrArg Prod.fst dataEq
    have edgesEq := congrArg Prod.snd dataEq
    have checked := observed_physical
    cases run : physicalPipeline with
    | error err => rw [run] at checked; cases checked
    | ok q =>
      unfold physicalPipeline at run
      obtain ⟨p,prepare,h⟩ := Except.bind_ok run
      obtain ⟨rf,selected,h⟩ := Except.bind_ok h
      obtain ⟨af,physical,h⟩ := Except.bind_ok h
      cases h
      have accepted := PerEdge.allocResultAt_checked selected
      have fallback : rf = spillAllocAt p.code p.edges := by
        unfold allocResultAt checkedSpillAt at selected
        simp only [bind,Except.bind] at selected
        split at selected <;> cases selected
        rfl
      have prepared : prepareAt result.code result.edgeArgs = .ok p := by rw [codeEq,edgesEq]; exact prepare
      have area : result.code.outgoing = 0 := by rw [codeEq]; rfl
      exact ⟨⟨result,p,rf,af,lowered,scope,dominated,arity,prepared,fallback,accepted,physical,area⟩⟩
end Backend.Stock.Proof.TryNearCriticalValuesFixtureDraft
