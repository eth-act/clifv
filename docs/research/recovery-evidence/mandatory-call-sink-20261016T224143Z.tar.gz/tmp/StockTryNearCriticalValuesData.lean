import FV.Backend.Proof.StockCriticalSplitFixture
import FV.Backend.Proof.PerEdgeSpillEntryFixture

namespace Backend.Stock.Proof.TryNearCriticalValuesDataDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Backend.Proof.PerEdgeSpill
set_option maxRecDepth 20000
set_option maxHeartbeats 16000000
def function : Clif.Function := {CriticalSplitFixture.function false with externs :=
  [(0,{name := "callee",sig := (CriticalSplitFixture.function false).sig,colocated := true})] }

deriving instance Repr for VCode
#eval reprStr ((Stock.lower function).toOption.map (fun r => (r.code,r.edgeArgs)))
end Backend.Stock.Proof.TryNearCriticalValuesDataDraft
