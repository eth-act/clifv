import FV.Backend.Proof.StockCriticalSplitFixture
import FV.Backend.Proof.PerEdgeSpillEntryFixture

namespace Backend.Stock.Proof.TryNearCriticalValuesFixtureDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Backend.Proof.PerEdgeSpill
set_option maxRecDepth 20000
set_option maxHeartbeats 16000000
def function : Clif.Function := {CriticalSplitFixture.function false with externs :=
  [(0,{name := "callee",sig := (CriticalSplitFixture.function false).sig,colocated := true})] }
private def pipeline  : Except String (Result × EdgeVCode × RFunc × AFunc) := do
  let result ← Stock.lower function
  let p ← prepareAt result.code result.edgeArgs
  let rf ← allocResultAt p.code p.edges (.error "force indexed split witness")
  let af ← lowerRFunc p.code rf
  pure (result,p,rf,af)
private theorem observed : pipeline.toOption.map (fun q => q.1.code.outgoing) = some 0 := by decide +kernel
private theorem scope  : LowerScope function := by
  apply lowerScope_of <;> decide +kernel
private theorem arity  : ArityOk function := by
  apply arityOk_of <;> decide +kernel

structure Output  where
  result : Result
  prepared : EdgeVCode
  rf : RFunc
  af : AFunc
  lowered : Stock.lower function = .ok result
  scope : LowerScope function
  arity : ArityOk function
  prepare : prepareAt result.code result.edgeArgs = .ok prepared
  fallback : rf = spillAllocAt prepared.code prepared.edges
  accepted : checkAllocAt prepared.code prepared.edges rf = .ok ()
  physical : lowerRFunc prepared.code rf = .ok af
  outgoing : result.code.outgoing = 0

/-- Complete source-constant compiler, preparation, checked fallback and physical pipeline. -/
theorem stock_near_critical_values_fixture  : Nonempty (Output) := by
  have actual := observed
  cases run : pipeline with
  | error err => simp only [run,Except.toOption] at actual; cases actual
  | ok q =>
    have area : q.1.code.outgoing = 0 := Option.some.inj (by simpa only [run,Except.toOption,Option.map_some] using actual)
    unfold pipeline at run
    obtain ⟨result,lowered,h⟩ := Except.bind_ok run
    obtain ⟨p,prepare,h⟩ := Except.bind_ok h
    obtain ⟨rf,selected,h⟩ := Except.bind_ok h
    obtain ⟨af,physical,h⟩ := Except.bind_ok h
    cases h
    have accepted := PerEdge.allocResultAt_checked selected
    have fallback : rf = spillAllocAt p.code p.edges := by
      unfold allocResultAt checkedSpillAt at selected
      simp only [bind,Except.bind] at selected
      split at selected <;> cases selected
      rfl
    exact ⟨⟨result,p,rf,af,lowered,scope,arity,prepare,fallback,accepted,physical,area⟩⟩

end Backend.Stock.Proof.TryNearCriticalValuesFixtureDraft
