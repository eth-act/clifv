import StockTrySelectiveScan
import StockTryPayloadUnique
namespace Backend.Stock.Proof.TryInactivePayloadDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open TrySelectivePayloadDraft TryPayloadUniqueDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
/-- No reservation may alias this payload by sharing an existing return index. -/
def InactivePayload (initial : State) (key : Nat) : Prop :=
  ∀ (slot : Nat) (rs : List Reg × List Reg),initial.tryRegs[slot]? = some rs →
    ∀ j,j < rs.1.length → ∀ c,rs.2[j]? ≠ some (.vreg key c)
/-- Exact allocator ownership derives inactivity for a payload beyond its OWN
return prefix; no predicate about other slots is supplied by the caller. -/
theorem stock_build_unshared_payload_inactive {f : Clif.Function} {ctx : Ctx} {ranges : Array (Nat × Nat)} {initial : State}
    (build : Stock.buildCtx f = .ok (ctx,ranges,initial)) {owner j key : Nat} {rs : List Reg × List Reg}
    (lookup : initial.tryRegs[owner]? = some rs) (payload : rs.2[j]? = some (.vreg key .int))
    (unshared : rs.1.length ≤ j) : InactivePayload initial key := by
  intro slot qs other k below c same
  obtain ⟨n,reg,range⟩ := buildCtx_reservedBelow build slot qs other (.vreg key c)
    (List.mem_append_right _ (List.mem_of_getElem? same))
  have classes : c = .int := (Reg.vreg.inj reg).2
  subst c
  obtain ⟨sameSlot,sameIndex⟩ := stock_build_payload_index_unique build owner rs lookup slot qs other j k (.vreg key .int) payload same
  subst slot
  cases Option.some.inj (lookup.symm.trans other)
  omega
/-- The actual physical payload convention and retRegs index establish the
selective constructor guard from globally derived inactive payload ownership. -/
theorem stock_inactive_payload_write_apart {initial : State} {ctx : Ctx} {slot key : Nat}
    (inactive : InactivePayload initial key) (reserved : ctx.tryRegs = initial.tryRegs[slot]!) : PayloadWriteApart ctx key := by
  intro sig ps returns pair member i index below c same
  have supported : payloadRegs sig.callConv = [] ∨ payloadRegs sig.callConv = [.x 0,.x 1] := by
    cases sig.callConv with
    | none => exact .inr rfl
    | some cc => cases cc <;> first | exact .inl rfl | exact .inr rfl
  rcases supported with empty | payloads
  · rw [empty] at member
    cases member
  · obtain ⟨j,atPair⟩ := List.mem_iff_getElem?.mp member
    rw [List.getElem?_zip_eq_some] at atPair
    have physical : pair.1 = .x j := by
      rw [payloads] at atPair
      rcases atPair with ⟨atPhysical,_⟩
      cases j with
      | zero => simpa using atPhysical.symm
      | succ j => cases j with
        | zero => simpa using atPhysical.symm
        | succ j => simp at atPhysical
    obtain ⟨bound,pins⟩ := retRegs_eq returns
    have atRet := (List.idxOf?_eq_some_iff.mp index)
    have physicalRet : Reg.x i = pair.1 := by
      have got := atRet.2.1
      simpa only [pins,List.getElem_map,List.getElem_range] using got
    have sameIndex : i = j := Reg.x.inj (physicalRet.trans physical)
    subst i
    rw [reserved] at atPair below
    cases found : initial.tryRegs[slot]? with
    | none => simp only [getElem!_def,found] at atPair; cases atPair.2
    | some rs =>
      have atPayload : rs.2[j]? = some pair.2 := by simpa only [getElem!_def,found] using atPair.2
      have inside : j < rs.1.length := by simpa only [getElem!_def,found] using below
      exact inactive slot rs found j inside c (by rw [← same]; exact atPayload)
end Backend.Stock.Proof.TryInactivePayloadDraft
