import StockTrySelectivePayload
import FV.Backend.Proof.StockAliasScanEntries
import FV.Backend.Proof.StockNodeAliasConnection
namespace Backend.Stock.Proof.TrySelectiveScanDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64 TrySelectivePayloadDraft
attribute [local irreducible] Isle.Aarch64.program
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private theorem setAlias_entry {st next : State} {dst src : Reg} {key : Nat}
    (apart : ∀ c, dst ≠ .vreg key c)
    (run : st.setAlias dst src = .ok next) :
    (next.alias[key]?).join = (st.alias[key]?).join := by
  cases dst <;> cases src <;> simp only [State.setAlias, bind, Except.bind,
    pure, Except.pure, throw, throwThe, MonadExceptOf.throw] at run
  all_goals try solve | cases run
  rename_i n c m d
  split at run
  · cases run
  · cases run
    change ((aliasStep st.alias (n, m))[key]?).join = (st.alias[key]?).join
    rw [aliasStep_get]
    have different : key ≠ n := by
      intro same
      subst n
      exact apart c rfl
    simp only [different, ite_false]


private theorem fold_entry {α β γ : Type} (field : α → γ)
    (step : α → β → Except String α) (xs : List β) {a next : α}
    (keeps : ∀ b ∈ xs, ∀ input output, step input b = .ok output →
      field output = field input)
    (run : xs.foldlM step a = .ok next) : field next = field a := by
  induction xs generalizing a with
  | nil => cases run; rfl
  | cons b bs ih =>
    rw [List.foldlM_cons] at run
    cases call : step a b with
    | error e => simp only [call, bind, Except.bind] at run; cases run
    | ok middle =>
      simp only [call, bind, Except.bind] at run
      exact (ih (fun b mem => keeps b (List.mem_cons_of_mem _ mem)) run).trans
        (keeps b (by simp) a middle call)


private theorem named_entry {ctx : Ctx} {term : String} {args : List V}
    {st next : State} {out : Option V} {trace : List RuleId} {key : Nat}
    (payloads : PayloadWriteApart ctx key)
    (h : Stock.runTerm ctx term args st = .ok (out, next, trace)) :
    (next.alias[key]?).join = (st.alias[key]?).join := by
  unfold Stock.runTerm at h
  cases hr : Isle.Interp.run program (Stock.sem ctx) {} term args st with
  | error e => rw [hr] at h; cases h
  | ok result =>
    rw [hr] at h
    cases h
    unfold Isle.Interp.run at hr
    cases ht : program.termByName? term with
    | none => simp only [ht] at hr; cases hr
    | some t =>
      simp only [ht] at hr
      cases ha : (applyTerm program (Stock.sem ctx) {} (Config.fuel ({} : Config))
          t.ret t.id args).run (st, #[]) with
      | error e => simp only [ha, bind, Except.bind] at hr; cases hr
      | ok result =>
        rcases result with ⟨out, next, trace⟩
        simp only [ha, bind, Except.bind, pure, Except.pure] at hr
        cases hr
        exact stock_apply_selective_payload_entry payloads ha


private theorem emitted_entry {ctx : Ctx} {i : Nat} {st : State}
    {emission : Emission} {key : Nat}
    (payloads : PayloadWriteApart ctx key)
    (mapped : ∀ x ∈ ctx.insts[i]!.results, ∀ r,
      ctx.valueReg? x = some r → ∀ c, r ≠ .vreg key c)
    (h : emitInstruction ctx i st = .ok emission) :
    (emission.state.alias[key]?).join = (st.alias[key]?).join := by
  unfold emitInstruction at h
  cases hr : Stock.runTerm ctx "lower" [.inst i] st with
  | error e => simp only [hr, bind, Except.bind] at h; cases h
  | ok root =>
    rcases root with ⟨out, next, trace⟩
    simp only [hr, bind, Except.bind] at h
    cases out with
    | none => cases h
    | some out =>
      cases out <;> try (cases h)
      rename_i rss
      dsimp only at h
      split at h
      · cases h
      · cases hb : bindResults ctx (ctx.insts[i]!.results.zip rss) next with
        | error e => simp only [hb] at h; cases h
        | ok result =>
          rcases result with ⟨final, copies⟩
          simp only [hb, pure, Except.pure] at h
          cases h
          exact (stock_bindResults_aliasEntry
            (fun pair member r hr c => mapped pair.1 (List.of_mem_zip member).1 r hr c)
            hb).trans (named_entry payloads hr)

private theorem opportunity_values_entry {ctx : Ctx} {values : List Nat}
    {st next : State} {key : Nat}
    (mapped : ∀ x ∈ values, ∀ r, ctx.valueReg? x = some r → ∀ c, r ≠ .vreg key c)
    (h : commitOpportunisticValues ctx values st = .ok next) :
    (next.alias[key]?).join = (st.alias[key]?).join := by
  unfold commitOpportunisticValues at h
  apply fold_entry (fun s : State => (s.alias[key]?).join) _ values ?_ h
  intro v member a b step
  split at step
  · split at step
    · rename_i dst hdst
      split at step
      · rename_i src _
        cases hs : a.setAlias dst src with
        | error e => simp only [hs, bind, Except.bind] at step; cases step
        | ok q =>
          simp only [hs, bind, Except.bind, pure, Except.pure] at step
          cases step
          exact setAlias_entry (next := q) (mapped v member dst hdst) hs
      · cases step
    · cases step
  · cases step; rfl

private theorem opportunity_entry {ctx : Ctx} {block i : Nat}
    {st next : State} {key : Nat}
    (mapped : ∀ x ∈ ctx.insts[i]!.results, ∀ r,
      ctx.valueReg? x = some r → ∀ c, r ≠ .vreg key c)
    (h : commitOpportunistic ctx block i st = .ok (some next)) :
    (next.alias[key]?).join = (st.alias[key]?).join := by
  unfold commitOpportunistic at h
  dsimp only at h
  split at h
  · cases h
  · cases hv : commitOpportunisticValues ctx (ctx.insts[i]!.results) st with
    | error e => simp only [hv, bind, Except.bind] at h; cases h
    | ok q =>
      simp only [hv, bind, Except.bind, pure, Except.pure] at h
      cases h
      exact opportunity_values_entry mapped hv

private theorem scan_state_entry (st : State) (i key : Nat) :
    ((scanState st i).alias[key]?).join = (st.alias[key]?).join := by
  unfold scanState
  dsimp only
  split <;> rfl

/-- Every actual scan decision preserves an alias whose key is absent from the
current source-result destinations and reserved exception payload destinations. -/
theorem stock_scan_selective_payload_entry {ctx : Ctx} {block i ti : Nat} {branch : Bool}
    {st : State} {output : Scan} {key : Nat}
    (payloads : PayloadWriteApart ctx key)
    (mapped : ∀ x ∈ ctx.insts[i]!.results, ∀ r,
      ctx.valueReg? x = some r → ∀ c, r ≠ .vreg key c)
    (h : scanInstruction ctx block i ti branch st = .ok output) :
    (output.state.alias[key]?).join = (st.alias[key]?).join := by
  have before := scan_state_entry st i key
  have emit (h : (emitInstruction ctx i (scanState st i) >>= fun e =>
      pure (e.scan block i (scanState st i))) = .ok output) :
      (output.state.alias[key]?).join = (st.alias[key]?).join := by
    cases he : emitInstruction ctx i (scanState st i) with
    | error e => simp only [he, bind, Except.bind] at h; cases h
    | ok e =>
      simp only [he, bind, Except.bind, pure, Except.pure] at h
      cases h
      exact (emitted_entry payloads mapped he).trans before
  unfold scanInstruction at h
  dsimp only at h
  generalize hm : (if i == ti then true else ctx.insts[i]!.clif.any mustLower) = mandatory at h
  split at h
  · cases h; rfl
  · split at h
    · cases h; exact before
    · split at h
      · cases h; exact before
      · split at h
        · cases hc : commitOpportunistic ctx block i (scanState st i) with
          | error e => simp only [hc, bind, Except.bind] at h; cases h
          | ok result =>
            simp only [hc, bind, Except.bind] at h
            cases result with
            | none => exact emit h
            | some q => cases h; exact (opportunity_entry mapped hc).trans before
        · exact emit h

/-- The actual complete block scan composes that preservation through any
number of omitted, sunk, opportunistic or emitted instructions. -/
theorem stock_scanBlock_selective_payload_entry {ctx : Ctx} {block ti : Nat} {branch : Bool}
    {indices : List Nat} {st : State} {output : BlockScan} {key : Nat}
    (payloads : PayloadWriteApart ctx key)
    (mapped : ∀ i ∈ indices, ∀ x ∈ ctx.insts[i]!.results, ∀ r,
      ctx.valueReg? x = some r → ∀ c, r ≠ .vreg key c)
    (h : scanBlock ctx block ti branch indices st = .ok output) :
    (output.state.alias[key]?).join = (st.alias[key]?).join := by
  have cert := runScans_spec h
  clear h
  induction cert with
  | nil st => rfl
  | cons head rest ih =>
    exact (ih (fun i mem => mapped i (List.mem_cons_of_mem _ mem))).trans
      (stock_scan_selective_payload_entry payloads (mapped _ (List.mem_cons_self ..)) head)

theorem stock_emitBranch_selective_payload_entry {ctx : Ctx} {f : Clif.Function} {t : Clif.Terminator}
    {bi ti : Nat} {targets : Array Nat} {input : State} {output : BranchEmission} {key : Nat}
    (payloads : PayloadWriteApart ctx key)
    (run : emitBranch ctx f t bi ti targets input = .ok output) :
    (output.state.alias[key]?).join = (input.alias[key]?).join := by
  unfold emitBranch at run
  dsimp only at run
  let before := { input with current := some ti, color := none, base.emitted := #[] }
  change ((do
    let (out, next, fired) ← Stock.runTerm ctx "lower_branch" [.inst ti, .labels targets.toList] before
    if out.isNone then throw s!"no lowering rule for terminator {repr t}"
    let code ← branchCode f t targets next.base.emitted
    pure ⟨next, code, ⟨bi, ti, .emitted, before, next, [], fired, code⟩, fired⟩) : Except String BranchEmission) = .ok output at run
  cases root : Stock.runTerm ctx "lower_branch" [.inst ti, .labels targets.toList] before with
  | error e => simp only [root, bind, Except.bind] at run; cases run
  | ok result =>
    rcases result with ⟨out, next, fired⟩
    simp only [root, bind, Except.bind] at run
    split at run
    · cases run
    · cases code : branchCode f t targets next.base.emitted with
      | error e => simp only [code] at run; cases run
      | ok instructions =>
        simp only [code, pure, Except.pure] at run
        cases run
        have same := named_entry (st := before) payloads root
        exact same


end Backend.Stock.Proof.TrySelectiveScanDraft
