import StockTryUnsharedTerminal
import StockTryFinalReturnValues
namespace Backend.Stock.Proof.TryResultDefsFixedDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open TryResultMapDraft TryRetsTotalDraft TryUnsharedTerminalDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private theorem lookup_of_layout {slots : Array (List Reg × List Reg)} {i base count : Nat}
    (layout : slots[i]! = (reservedReturns base count,reservedPayloads base count)) :
    slots[i]? = some (reservedReturns base count,reservedPayloads base count) := by
  cases found : slots[i]? with
  | none => simp only [getElem!_def,found] at layout; cases congrArg Prod.snd layout
  | some pair =>
    have same : pair = (reservedReturns base count,reservedPayloads base count) := by
      simpa only [getElem!_def,found] using layout
    rw [same]

/-- Every actual reserved call definition is fixed by the ACTUAL final alias
map: return prefix and all unshared payload outputs, including counts0and1.
This discharges the reserved-def part of stopped-run renaming internally. -/
theorem stock_lower_try_result_keys_fixed {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) {owner base count : Nat}
    (layout : result.initial.tryRegs[owner]! = (reservedReturns base count,reservedPayloads base count)) :
    ∀ j,j < max count 2 → aliasNum result.final.alias (resultKey base count j) = resultKey base count j := by
  intro j inside
  have slot := lookup_of_layout layout
  by_cases isReturn : j < count
  · have member : Reg.vreg (base+j) .int ∈ reservedReturns base count := by
      exact List.mem_map.mpr ⟨j,List.mem_range.mpr isReturn,rfl⟩
    simpa only [resultKey,if_pos isReturn] using (stock_lower_reservedReturn_terminal lowered slot member).2
  · have payloadIndex : j < 2 := by omega
    have atPayload : (reservedPayloads base count)[j]? = some (.vreg (base+count+j) .int) := by
      have choices : j = 0 ∨ j = 1 := by omega
      rcases choices with rfl | rfl <;> rfl
    have unshared : (reservedReturns base count).length ≤ j := by
      simp only [reservedReturns,List.length_map,List.length_range]
      omega
    simpa only [resultKey,if_neg isReturn] using
      (stock_lower_unshared_payload_terminal lowered slot atPayload unshared).2
end Backend.Stock.Proof.TryResultDefsFixedDraft
