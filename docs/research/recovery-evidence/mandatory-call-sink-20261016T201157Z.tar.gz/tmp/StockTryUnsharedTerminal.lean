import StockTryInactivePayload
namespace Backend.Stock.Proof.TryUnsharedTerminalDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open TrySelectivePayloadDraft TrySelectiveScanDraft TryInactivePayloadDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm emitBranch scanBlock
private theorem return_source_apart {f : Clif.Function} {source ctx : Ctx}
    {ranges : Array (Nat × Nat)} {initial : State} {owner key : Nat} {rs : List Reg × List Reg}
    (build : Stock.buildCtx f = .ok (source, ranges, initial))
    (lookup : initial.tryRegs[owner]? = some rs) (member : (.vreg key .int) ∈ rs.2)
    (values : ∀ x, ctx.valueReg? x = source.valueReg? x) :
    ∀ x r, ctx.valueReg? x = some r → ∀ c, r ≠ .vreg key c := by
  intro x r mapped c equal
  rw [values] at mapped
  obtain ⟨n, reg, _⟩ := (buildCtx_allocated build).2.2.1 x r mapped
  have classes : (.int : RegClass) = c := (Reg.vreg.inj (reg.symm.trans equal)).2
  subst c
  exact buildCtx_valueReservedDisjoint build x r mapped owner rs lookup
    (.vreg key .int) (List.mem_append_right _ member) equal

private theorem core_entry {f : Clif.Function} {ctx : Ctx}
    {ranges : Array (Nat × Nat)} {initial : State}
    (build : Stock.buildCtx f = .ok (ctx, ranges, initial))
     {owner key bi : Nat} {rs : List Reg × List Reg}
    (lookup : initial.tryRegs[owner]? = some rs) (member : (.vreg key .int) ∈ rs.2) (inactive : InactivePayload initial key)
    {second : Clif.Block} {start stop : Nat}
    {order : Order} {data : V} {targets : Array Nat} {input : State} {output : LoweredBlockCore}
    (reservations : input.tryRegs = initial.tryRegs)
    (run : lowerBlockCore ctx order f second bi start stop data targets input = .ok output) :
    (output.state.alias[key]?).join = (input.alias[key]?).join := by
  let ti := stop - 1
  let selected := { Driver.termCtx ctx ti data with tryRegs := input.tryRegs[ti]! }
  let branch : Bool := match second.term with | .ret .. | .trap .. | .returnCall .. => false | _ => true
  let branchCall : Except String (Option BranchEmission) :=
    if branch then some <$> emitBranch selected f second.term bi ti targets input else pure none
  have payloads : PayloadWriteApart selected key :=
    stock_inactive_payload_write_apart (slot := ti) inactive (by simp only [selected,reservations])
  have branchKeeps {br : Option BranchEmission} (call : branchCall = .ok br) :
      (((br.map (·.state)).getD input).alias[key]?).join = (input.alias[key]?).join := by
    unfold branchCall at call
    split at call
    · cases emitted : emitBranch selected f second.term bi ti targets input with
      | error e => simp only [emitted, Functor.map, Except.map] at call; cases call
      | ok e =>
        simp only [emitted, Functor.map, Except.map] at call
        cases call
        exact stock_emitBranch_selective_payload_entry payloads emitted
    · cases call; rfl
  have normal : lowerBlockCore ctx order f second bi start stop data targets input = (do
      let br ← branchCall
      let (next, outgoing) ← collectOutgoing ctx order bi targets (br.map (·.state) |>.getD input)
      let before := { next with color := some next.endColor[bi]! }
      let indices := ((Array.range (stop - start)).map (start + ·)).reverse.toList
      let body ← scanBlock selected bi ti branch indices before
      pure ⟨body.state, body.code ++ (br.map (·.code) |>.getD #[]), outgoing,
        br, ⟨selected, bi, ti, branch, indices, before, body⟩⟩) := by
    unfold lowerBlockCore
    dsimp only [branchCall, branch, selected, ti, Driver.termCtx]
    split <;> simp_all only [branch, selected, ti] <;> rfl
  rw [normal] at run
  cases call : branchCall with
  | error e => simp only [call, bind, Except.bind] at run; cases run
  | ok br =>
    simp only [call, bind, Except.bind] at run
    cases edges : collectOutgoing ctx order bi targets (br.map (·.state) |>.getD input) with
    | error e => simp only [edges] at run; cases run
    | ok pair =>
      rcases pair with ⟨next, outgoing⟩
      simp only [edges] at run
      let before := { next with color := some next.endColor[bi]! }
      let indices := ((Array.range (stop - start)).map (start + ·)).reverse.toList
      have keeps : (next.alias[key]?).join = (input.alias[key]?).join := by
        rw [stock_collectOutgoing_alias edges]
        exact branchKeeps call
      change (scanBlock selected bi ti branch indices before >>= fun body =>
        pure (⟨body.state, body.code ++ (br.map (·.code) |>.getD #[]), outgoing,
          br, ⟨selected, bi, ti, branch, indices, before, body⟩⟩ : LoweredBlockCore)) = .ok output at run
      cases scan : scanBlock selected bi ti branch indices before with
      | error e => simp only [scan, bind, Except.bind] at run; cases run
      | ok body =>
        simp only [scan, bind, Except.bind, pure, Except.pure] at run
        cases run
        have scanned := stock_scanBlock_selective_payload_entry payloads
          (fun i _ x _ r mapping c => return_source_apart (ctx := selected) build lookup member
            (fun _ => rfl) x r mapping c) scan
        exact scanned.trans keeps

private theorem node_entry {f : Clif.Function} {ctx : Ctx}
    {ranges : Array (Nat × Nat)} {initial : State}
    (build : Stock.buildCtx f = .ok (ctx, ranges, initial)) 
    {owner key : Nat} {rs : List Reg × List Reg}
    (lookup : initial.tryRegs[owner]? = some rs) (member : (.vreg key .int) ∈ rs.2) (inactive : InactivePayload initial key)
    {order : Order} {params : List Nat} {label : Nat} {input output : DriverState}
    (reservations : input.state.tryRegs = initial.tryRegs)
    (run : lowerNode ctx ranges order f params label input = .ok output) :
    (output.state.alias[key]?).join = (input.state.alias[key]?).join := by
  cases node : order.nodes[label]! with
  | edge pred k target =>
    unfold lowerNode at run
    simp only [node] at run
    cases args : branchArgs ctx input.state pred k with
    | error e => simp only [args, bind, Except.bind] at run; cases run
    | ok pair =>
      rcases pair with ⟨args, next⟩
      simp only [args, bind, Except.bind, pure, Except.pure] at run
      cases run
      rw [stock_branchArgs_alias args]
  | original bi =>
    let b := f.blocks[bi]!
    let start := ranges[bi]!.1
    let stop := ranges[bi]!.2
    let fetchData : Except String V := match b.term with
      | .tryCall .. | .tryCallIndirect .. => tryCallData f b.term
      | _ => termData (abiTerm f b.term)
    let reject : Bool := (match b.term with | .ret .. => true | _ => false) &&
      (sretRet f).isEmpty && (sigRets f.sig != f.sig.returns)
    have normal : lowerNode ctx ranges order f params label input = (do
        let data ← fetchData
        if reject then throw "sret parameter is not an entry-block parameter"
        let lowered ← lowerBlockCore ctx order f b bi start stop data order.successors[label]! input.state
        let assembled ← assembleOriginalBlock ctx f b bi label order.successors[label]!
          lowered.outgoing params lowered.state.uses lowered.code
        pure { recordCore input lowered bi stop with
          blocks := input.blocks.set! label assembled,
          edgeArgs := input.edgeArgs.set! label lowered.outgoing }) := by
      unfold lowerNode
      simp only [node]
      dsimp only [fetchData, reject, b, start, stop]
      split <;> simp_all only [reject] <;> rfl
    rw [normal] at run
    cases dataRun : fetchData with
    | error e => simp only [dataRun, bind, Except.bind] at run; cases run
    | ok data =>
      simp only [dataRun, bind, Except.bind] at run
      split at run
      · cases run
      · cases core : lowerBlockCore ctx order f b bi start stop data order.successors[label]! input.state with
        | error e => simp only [core] at run; cases run
        | ok lowered =>
          simp only [core] at run
          cases assembled : assembleOriginalBlock ctx f b bi label order.successors[label]!
              lowered.outgoing params lowered.state.uses lowered.code with
          | error e => simp only [assembled] at run; cases run
          | ok block =>
            simp only [assembled, pure, Except.pure] at run
            cases run
            exact core_entry build lookup member inactive reservations core

private theorem traversal_entry {f : Clif.Function} {ctx : Ctx}
    {ranges : Array (Nat × Nat)} {initial : State}
    (build : Stock.buildCtx f = .ok (ctx, ranges, initial)) 
    {owner key : Nat} {rs : List Reg × List Reg}
    (lookup : initial.tryRegs[owner]? = some rs) (member : (.vreg key .int) ∈ rs.2) (inactive : InactivePayload initial key)
    {order : Order} {params labels : List Nat} {input output : DriverState}
    (bound : input.state.alias.size ≤ initial.base.nextVreg ∧
      initial.base.nextVreg ≤ input.state.base.nextVreg ∧ input.state.tryRegs = initial.tryRegs)
    (run : labels.foldlM (fun d label => lowerNode ctx ranges order f params label d) input = .ok output) :
    (output.state.alias[key]?).join = (input.state.alias[key]?).join := by
  induction labels generalizing input with
  | nil => cases run; rfl
  | cons label labels ih =>
    rw [List.foldlM_cons] at run
    cases call : lowerNode ctx ranges order f params label input with
    | error e => simp only [call, bind, Except.bind] at run; cases run
    | ok next =>
      simp only [call, bind, Except.bind] at run
      exact (ih (stock_lowerNode_allocationBounds build bound call) run).trans
        (node_entry build lookup member inactive bound.2.2 call)


/-- Every unshared initial payload stays unaliased and is an ACTUAL final
resolver endpoint across successful whole lowering. Inactivity and cross-slot
ownership are derived internally from construction, not accepted-input checks. -/
theorem stock_lower_unshared_payload_terminal {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) {owner key j : Nat} {rs : List Reg × List Reg}
    (lookup : result.initial.tryRegs[owner]? = some rs) (payload : rs.2[j]? = some (.vreg key .int))
    (unshared : rs.1.length ≤ j) :
    (result.final.alias[key]?).join = none ∧ aliasNum result.final.alias key = key := by
  unfold Stock.lower at run
  dsimp only at run
  repeat' first
    | (solve | cases run)
    | simp only [bind, Except.bind, pure, Except.pure] at run
    | split at run
  cases run
  rename_i _ built hbuild _ order horder _ driver hdriver
  change built.2.2.tryRegs[owner]? = some rs at lookup
  have inactive := stock_build_unshared_payload_inactive hbuild lookup payload unshared
  have member : (.vreg key .int) ∈ rs.2 := List.mem_of_getElem? payload
  have initial : built.2.2.alias = #[] := by
    obtain ⟨original, before, requests, _, _, same⟩ := buildCtx_allocation hbuild
    exact congrArg (fun p : Ctx × Array (Nat × Nat) × State => p.2.2.alias) same
  have bound : built.2.2.alias.size ≤ built.2.2.base.nextVreg ∧
      built.2.2.base.nextVreg ≤ built.2.2.base.nextVreg ∧ built.2.2.tryRegs = built.2.2.tryRegs :=
    ⟨by rw [initial]; exact Nat.zero_le _, Nat.le_refl _, rfl⟩
  have kept := traversal_entry hbuild lookup member inactive bound hdriver
  change (driver.state.alias[key]?).join = (built.2.2.alias[key]?).join at kept
  have absent : (driver.state.alias[key]?).join = none := by rw [kept, initial]; rfl
  exact ⟨absent,chaseF_none absent _⟩

end Backend.Stock.Proof.TryUnsharedTerminalDraft
