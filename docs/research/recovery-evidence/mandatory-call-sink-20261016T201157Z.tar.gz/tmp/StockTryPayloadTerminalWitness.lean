import StockTryResultDefsFixed
import StockTryEmittedWitness
import StockTryStackFixture
namespace Backend.Stock.Proof.TryPayloadTerminalWitnessDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open TryEmittedWitnessDraft (Kind)
open TrySourceContextDraft TryBranchSelectionDraft TryWholeSourceReservationDraft TryBranchAbiDraft
open TryRetsTotalDraft TryResultMapDraft TryUnsharedTerminalDraft TryResultDefsFixedDraft TryPayloadUniqueDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private def function : Kind → Clif.Function
  | .near => TryNearFixtureDraft.function false
  | .got => SpillEntryFixture.function false
  | .indirect => SpillEntryFixture.function true
private def entry (k : Kind) := (function k).blocks[0]!
private def table : Clif.ExnTable := {
  sig := 0,normal := ⟨1,[.ret 0,.val 0]⟩,items := [.tag 7 ⟨2,[.exn 0,.exn 1,.val 0]⟩] }
private structure Fixture (k : Kind) where
  result : Result
  prepared : EdgeVCode
  rf : RFunc
  af : AFunc
  lowered : Stock.lower (function k) = .ok result
  scope : LowerScope (function k)
  dominated : Dominated (function k)
  arity : ArityOk (function k)
  prepare : prepareAt result.code result.edgeArgs = .ok prepared
  fallback : rf = spillAllocAt prepared.code prepared.edges
  accepted : checkAllocAt prepared.code prepared.edges rf = .ok ()
  physical : lowerRFunc prepared.code rf = .ok af
private theorem fixture (k : Kind) : Nonempty (Fixture k) := by
  cases k with
  | near =>
    obtain ⟨out⟩ := TryNearFixtureDraft.stock_near_try_fixture
    exact ⟨⟨out.result,out.prepared,out.rf,out.af,out.lowered,out.scope,out.dominated,out.arity,
      out.prepare,out.fallback,out.accepted,out.physical⟩⟩
  | got =>
    obtain ⟨out⟩ := SpillEntryFixture.try_fixture false
    exact ⟨⟨out.result,out.prepared,out.rf,out.af,out.lowered,out.scope,out.dominated,out.arity,
      out.prepare,out.fallback,out.accepted,out.physical⟩⟩
  | indirect =>
    obtain ⟨out⟩ := SpillEntryFixture.try_fixture true
    exact ⟨⟨out.result,out.prepared,out.rf,out.af,out.lowered,out.scope,out.dominated,out.arity,
      out.prepare,out.fallback,out.accepted,out.physical⟩⟩
private theorem order (k : Kind) : blockOrder (function k) = .ok {
    nodes := #[.original 0,.original 1,.original 2],successors := #[#[2,1],#[],#[]]} := by cases k <;> cbv

/-- Complete near/GOT/indirect pipelines exercise the real unshared second
payload and every actual result definition's final resolver endpoint. -/
theorem stock_complete_try_payload_terminals_witness (k : Kind) :
    ∃ (out : Fixture k) (source : TryBranchSource (function k) out.result 0 0 (entry k))
      (_selected : TryBranchSelection source) (base : Nat),
      LowerScope (function k) ∧ Dominated (function k) ∧ ArityOk (function k) ∧
      Stock.lower (function k) = .ok out.result ∧ prepareAt out.result.code out.result.edgeArgs = .ok out.prepared ∧
      out.rf = spillAllocAt out.prepared.code out.prepared.edges ∧
      checkAllocAt out.prepared.code out.prepared.edges out.rf = .ok () ∧ lowerRFunc out.prepared.code out.rf = .ok out.af ∧
      out.result.initial.tryRegs[source.ti]! = (reservedReturns base 1,reservedPayloads base 1) ∧
      (out.result.final.alias[base+2]?).join = none ∧ aliasNum out.result.final.alias (base+2) = base+2 ∧
      ∀ j,j < max 1 2 → aliasNum out.result.final.alias (resultKey base 1 j) = resultKey base 1 j := by
  obtain ⟨out⟩ := fixture k
  have sameOrder := Except.ok.inj ((stock_lower_order out.lowered).symm.trans (order k))
  have node : out.result.order.nodes[0]? = some (.original 0) := by rw [sameOrder]; rfl
  have block : (function k).blocks[0]? = some (entry k) := by cases k <;> rfl
  have input : Prg.iselInB (function k) = true := by cases k <;> decide +kernel
  have kind : sourceTable (entry k).term = some table := by cases k <;> rfl
  have decoded : exnTableOpnd (function k) table = .ok ((function k).sig,[some 7]) := by cases k <;> rfl
  obtain ⟨ranges,source,selected,base,value,next,build,allocation,slots,helper,frame⟩ :=
    stock_lower_original_try_reservation out.lowered out.scope input node block kind decoded
  have count : (function k).sig.returns.length = 1 := by cases k <;> rfl
  rw [count] at slots
  have layout : out.result.initial.tryRegs[source.ti]! = (reservedReturns base 1,reservedPayloads base 1) := by
    rw [← allocation.2]
    exact source.tryRegs.symm.trans slots
  have slot : out.result.initial.tryRegs[source.ti]? = some (reservedReturns base 1,reservedPayloads base 1) := by
    cases found : out.result.initial.tryRegs[source.ti]? with
    | none => simp only [getElem!_def,found] at layout; cases congrArg Prod.snd layout
    | some pair => have equal : pair = (reservedReturns base 1,reservedPayloads base 1) := by simpa only [getElem!_def,found] using layout
                   rw [equal]
  have terminal := stock_lower_unshared_payload_terminal out.lowered slot
    (show (reservedPayloads base 1)[1]? = some (.vreg (base+2) .int) from rfl) (by simp [reservedReturns])
  exact ⟨out,source,selected,base,out.scope,out.dominated,out.arity,out.lowered,out.prepare,out.fallback,
    out.accepted,out.physical,layout,terminal.1,terminal.2,stock_lower_try_result_keys_fixed out.lowered layout⟩
/-- Overwritten and cross-slot payload requests have exact, nonempty indexed
ownership. The last slot0 request replaces its older reservation. -/
theorem stock_payload_index_unique_overwrite_witness :
    let a := allocateRequests 1 2 [.value 0,.exception 0 1 2,.exception 1 2 1,.exception 0 1 2]
    a.tryRegs[0]? = some ([.vreg 199 .int],[.vreg 200 .int,.vreg 201 .int]) ∧
    a.tryRegs[1]? = some ([.vreg 196 .int,.vreg 197 .int],[.vreg 198 .int]) ∧ PayloadIndexUnique a := by
  exact ⟨rfl,rfl,stock_allocate_payload_index_unique _ _ _⟩
end Backend.Stock.Proof.TryPayloadTerminalWitnessDraft
