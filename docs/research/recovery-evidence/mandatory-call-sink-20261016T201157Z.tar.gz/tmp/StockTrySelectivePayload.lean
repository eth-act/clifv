import FV.Backend.Proof.StockAliasWrites
namespace Backend.Stock.Proof.TrySelectivePayloadDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
attribute [local irreducible] Isle.Aarch64.program
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
/-- Only a payload sharing an existing return index can be an alias destination.
This internal guard excludes those actual writes, not all payload registers. -/
def PayloadWriteApart (ctx : Ctx) (key : Nat) : Prop :=
  ∀ (sig : Clif.Signature) (ps : List Reg),retRegs sig.returns.length = some ps →
    ∀ pair ∈ (payloadRegs sig.callConv).zip ctx.tryRegs.2,∀ i,
      ps.idxOf? pair.1 = some i → i < ctx.tryRegs.1.length → ∀ c,pair.2 ≠ .vreg key c
private theorem setAlias_entry {st next : State} {dst src : Reg} {key : Nat}
    (apart : ∀ c, dst ≠ .vreg key c)
    (run : st.setAlias dst src = .ok next) :
    (next.alias[key]?).join = (st.alias[key]?).join := by
  cases dst <;> cases src <;> simp only [State.setAlias, bind, Except.bind,
    pure, Except.pure, throw, throwThe, MonadExceptOf.throw] at run
  all_goals try solve | cases run
  rename_i n c m d
  split at run
  · cases run
  · cases run
    change ((aliasStep st.alias (n, m))[key]?).join = (st.alias[key]?).join
    rw [aliasStep_get]
    have different : key ≠ n := by
      intro same
      subst n
      exact apart c rfl
    simp only [different, ite_false]

private def tryAliasStep (ps rets : List Reg) (acc : Except String (State × List Reg))
    (pair : Reg × Reg) : Except String (State × List Reg) := do
  let (s, regs) ← acc
  let (p, r) := pair
  if let some i := ps.idxOf? p then
    let some ret := rets[i]? | throw "try_call return register"
    pure (← s.setAlias r ret, regs ++ [ret])
  else pure (s, regs ++ [r])

private theorem try_fold_error (ps rets : List Reg) (pairs : List (Reg × Reg)) (e : String) :
    pairs.foldl (tryAliasStep ps rets) (.error e) = .error e := by
  induction pairs with
  | nil => rfl
  | cons pair pairs ih => exact ih

private theorem try_fold_entry (ps rets : List Reg) (pairs : List (Reg × Reg))
    (st : State) (regs : List Reg) {next : State} {out : List Reg} {key : Nat}
    (destinations : ∀ pair ∈ pairs, ∀ i,ps.idxOf? pair.1 = some i → i < rets.length → ∀ c,pair.2 ≠ .vreg key c)
    (run : pairs.foldl (tryAliasStep ps rets) (.ok (st, regs)) = .ok (next, out)) :
    (next.alias[key]?).join = (st.alias[key]?).join := by
  induction pairs generalizing st regs with
  | nil => cases run; rfl
  | cons pair pairs ih =>
    rw [List.foldl_cons] at run
    cases step : tryAliasStep ps rets (.ok (st, regs)) pair with
    | error e => rw [step, try_fold_error] at run; cases run
    | ok result =>
      rcases result with ⟨middle, rs⟩
      rw [step] at run
      have mb : (middle.alias[key]?).join = (st.alias[key]?).join := by
        unfold tryAliasStep at step
        simp only [bind, Except.bind] at step
        cases idx : ps.idxOf? pair.1 with
        | none => simp only [idx, pure, Except.pure] at step; cases step; rfl
        | some i =>
          simp only [idx] at step
          cases ret : rets[i]? with
          | none => simp only [ret] at step; cases step
          | some r =>
            simp only [ret] at step
            cases alias : st.setAlias pair.2 r with
            | error e => rw [alias] at step; cases step
            | ok q =>
              rw [alias] at step
              simp only [pure, Except.pure] at step
              cases step
              exact setAlias_entry (destinations pair (by simp) i idx (List.getElem?_eq_some_iff.mp ret).1) alias
      exact (ih middle rs (fun pair mem => destinations pair (by simp [mem])) run).trans mb

private theorem delegate_entry {ctx : Ctx} {t : Term} {args : List V}
    {st next : State} {v : V} {key : Nat}
    (run : (match Backend.externCtor ctx t args st.base with
      | .ok (v, base) => ExtResult.ok (v, { st with base })
      | .fail => ExtResult.fail
      | .unmodeled e => ExtResult.unmodeled e) = ExtResult.ok (v, next)) :
    (next.alias[key]?).join = (st.alias[key]?).join := by
  cases call : Backend.externCtor ctx t args st.base with
  | fail => rw [call] at run; cases run
  | unmodeled e => rw [call] at run; cases run
  | ok pair => rw [call] at run; cases run; rfl

private theorem marks_alias (st : State) (vs : List Nat) :
    (vs.foldl State.mark st).alias = st.alias := by
  induction vs generalizing st with
  | nil => rfl
  | cons x xs ih => exact ih (st.mark x)

/-- Actual constructors preserve every alias entry outside the exception
payload destinations, regardless of selected rule, incoming aliases or fuel. -/
theorem stock_ctor_selective_payload_entry {ctx : Ctx} {t : Term} {args : List V}
    {st next : State} {v : V} {key : Nat}
    (payloads : PayloadWriteApart ctx key)
    (run : Stock.externCtor ctx t args st = .ok (v, next)) :
    (next.alias[key]?).join = (st.alias[key]?).join := by
  unfold Stock.externCtor at run
  split at run
  all_goals dsimp only at run
  all_goals try solve | exact delegate_entry run
  all_goals
    repeat' first
    | (solve | cases run <;> rfl)
    | (solve | have h := delegate_entry (key := key) run; simpa only [State.mark, marks_alias] using h)
    | split at run
  rename_i _ _ sig _ _ ps _ _ s regs step
  cases run
  exact try_fold_entry ps ctx.tryRegs.1 ((payloadRegs sig.callConv).zip ctx.tryRegs.2) st []
    (fun pair mem i atIndex below => payloads sig ps (by assumption) pair mem i atIndex below) step

/-- Nested term evaluation, matching failures and rollback preserve the same
entry. This uses the actual interpreter rather than a selected-path receipt. -/
theorem stock_apply_selective_payload_entry {p : Program} {ctx : Ctx} {cfg : Config}
    {n ty t : Nat} {args : List V} {st next : State} {tr tr' : Array RuleId}
    {out : Option V} {key : Nat}
    (payloads : PayloadWriteApart ctx key)
    (run : (applyTerm p (Stock.sem ctx) cfg n ty t args).run (st, tr) =
      .ok (out, next, tr')) :
    (next.alias[key]?).join = (st.alias[key]?).join := by
  exact (presAt (R := fun a b : State => (b.alias[key]?).join = (a.alias[key]?).join)
    (fun _ => rfl) (fun _ _ _ ab bc => bc.trans ab)
    (fun _ _ _ _ _ ctor => stock_ctor_selective_payload_entry payloads ctor) n).apply
      ty t args st tr out next tr' run


end Backend.Stock.Proof.TrySelectivePayloadDraft
