import FV.Backend.Proof.StockReservedTerminal
namespace Backend.Stock.Proof.TryPayloadUniqueDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
/-- A payload virtual register identifies both its reservation slot and index,
even when exception requests overwrite earlier reservations. -/
def PayloadIndexUnique (a : Allocation) : Prop :=
  ∀ (i : Nat) (rs : List Reg × List Reg),a.tryRegs[i]? = some rs →
    ∀ (j : Nat) (qs : List Reg × List Reg),a.tryRegs[j]? = some qs →
      ∀ (u v : Nat) (r : Reg),rs.2[u]? = some r → qs.2[v]? = some r → i = j ∧ u = v
private theorem fresh_at (base rets pays u : Nat) {r : Reg}
    (atReg : ((List.range pays).map (fun j => Reg.vreg (base+rets+j) .int))[u]? = some r) :
    u < pays ∧ r = .vreg (base+rets+u) .int := by
  have below : u < pays := by
    have h := (List.getElem?_eq_some_iff.mp atReg).1
    simpa only [List.length_map,List.length_range] using h
  have index : ((List.range pays).map (fun j => Reg.vreg (base+rets+j) .int))[u]? = some (.vreg (base+rets+u) .int) := by simp [below]
  exact ⟨below,Option.some.inj (atReg.symm.trans index)⟩

private theorem initial_unique (values instructions : Nat) : PayloadIndexUnique (Allocation.initial values instructions) := by
  intro i rs lookup j qs other u v r left right
  by_cases inside : i < instructions <;> simp [Allocation.initial,inside] at lookup
  subst rs
  cases left
private theorem step_unique {a : Allocation} (old : PayloadIndexUnique a) (reserved : ReservedRegsBelow a)
    (request : AllocationRequest) : PayloadIndexUnique (a.step request) := by
  intro i rs lookup j qs other u v r left right
  cases request with
  | value x => exact old i rs lookup j qs other u v r left right
  | exception slot rets pays =>
    simp only [Allocation.step,Array.set!_eq_setIfInBounds,Array.getElem?_setIfInBounds] at lookup other
    by_cases hit : i = slot
    · subst i
      by_cases inside : slot < a.tryRegs.size
      · simp only [inside,ite_true,Option.some.injEq] at lookup
        subst rs
        obtain ⟨ub,reg⟩ := fresh_at a.base.nextVreg rets pays u left
        by_cases same : j = slot
        · subst j
          simp only [inside,ite_true,Option.some.injEq] at other
          subst qs
          obtain ⟨vb,otherReg⟩ := fresh_at a.base.nextVreg rets pays v right
          have indices := Reg.vreg.inj (reg.symm.trans otherReg)
          exact ⟨rfl,by omega⟩
        · simp only [Ne.symm same,ite_false] at other
          obtain ⟨n,value,below⟩ := reserved j qs other r (List.mem_append_right _ (List.mem_of_getElem? right))
          have index := Reg.vreg.inj (value.symm.trans reg)
          omega
      · simp only [inside,ite_false] at lookup
        cases lookup
    · simp only [Ne.symm hit,ite_false] at lookup
      by_cases same : j = slot
      · subst j
        by_cases inside : slot < a.tryRegs.size
        · simp only [inside,ite_true,Option.some.injEq] at other
          subst qs
          obtain ⟨vb,reg⟩ := fresh_at a.base.nextVreg rets pays v right
          obtain ⟨n,value,below⟩ := reserved i rs lookup r (List.mem_append_right _ (List.mem_of_getElem? left))
          have index := Reg.vreg.inj (value.symm.trans reg)
          omega
        · simp only [inside,ite_false] at other
          cases other
      · simp only [Ne.symm same,ite_false] at other
        exact old i rs lookup j qs other u v r left right
/-- Actual allocation folds derive payload slot/index uniqueness internally. -/
theorem stock_allocate_payload_index_unique (values instructions : Nat) (requests : List AllocationRequest) :
    PayloadIndexUnique (allocateRequests values instructions requests) := by
  have reversed (qs : List AllocationRequest) : PayloadIndexUnique (allocateRequests values instructions qs.reverse) := by
    induction qs with
    | nil => exact initial_unique values instructions
    | cons request qs ih =>
      rw [List.reverse_cons]
      have step := step_unique ih (allocateRequests_reservedBelow values instructions qs.reverse) request
      simpa only [allocateRequests,List.foldl_append,List.foldl_cons,List.foldl_nil] using step
  simpa only [List.reverse_reverse] using reversed requests.reverse
/-- Successful original Stock construction gives exact slot/index ownership. -/
theorem stock_build_payload_index_unique {f : Clif.Function} {ctx : Ctx} {ranges : Array (Nat × Nat)} {initial : State}
    (build : Stock.buildCtx f = .ok (ctx,ranges,initial)) :
    ∀ (i : Nat) (rs : List Reg × List Reg),initial.tryRegs[i]? = some rs →
      ∀ (j : Nat) (qs : List Reg × List Reg),initial.tryRegs[j]? = some qs →
        ∀ (u v : Nat) (r : Reg),rs.2[u]? = some r → qs.2[v]? = some r → i = j ∧ u = v := by
  obtain ⟨original,before,requests,_,_,same⟩ := buildCtx_allocation build
  have state := congrArg (fun q : Ctx × Array (Nat × Nat) × State => q.2.2.tryRegs) same
  rw [state]
  exact stock_allocate_payload_index_unique original.valTy.size original.insts.size requests
end Backend.Stock.Proof.TryPayloadUniqueDraft
