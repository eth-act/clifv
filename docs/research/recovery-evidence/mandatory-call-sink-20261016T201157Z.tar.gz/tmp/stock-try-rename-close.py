from pathlib import Path
import json,hashlib,re,datetime,tarfile,shutil
root=Path('/home/lee/clifv/.worktrees/driver-proof-resume');docs=root/'docs/research'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
now=datetime.datetime.now(datetime.timezone.utc);stamp=now.strftime('%Y%m%dT%H%M%SZ')
batch=json.loads(Path('/tmp/stock-try-rename-batch.json').read_text());old=json.loads((docs/'stock-try-indirect-scratch.json').read_text())
sets={m.group(1):sorted(x.strip() for x in m.group(2).split(',') if x.strip()) for m in re.finditer(r"'([^']+)' depends on axioms:\s*\[([^]]*)\]",Path('/tmp/stock-try-rename-combined-axioms.log').read_text())}
for m in re.finditer(r"'([^']+)' does not depend on any axioms",Path('/tmp/stock-try-rename-combined-axioms.log').read_text()):sets[m.group(1)]=[]
for n,a in old['normal_audit']['sets'].items():assert sorted(a)==sets[n],n
allowed={'propext','Classical.choice','Quot.sound'}
for n in batch['public_roots']+batch['models']:assert set(sets[n])<=allowed,n
constants=[json.loads(line.split('DELIVERY_CONSTANT ',1)[1]) for line in Path('/tmp/stock-try-rename-all-constants.log').read_text().splitlines() if line.startswith('DELIVERY_CONSTANT ')]
assert constants
for n,a in constants:assert set(a)<=allowed,n
mods={}
for m in batch['modules']:
 p=Path('/tmp')/m;check=json.loads(p.with_suffix('.check.json').read_text());assert check['actual_exit']==0
 rec={}
 for key,ext in [('source','.lean'),('object','.olean'),('log','.log'),('check','.check.json')]:
  f=p.with_suffix(ext);rec[key]=str(f);rec[key+'_sha256']=sha(f)
 for k in ['source','object','log']:assert rec[k+'_sha256']==check[k+'_sha256']
 assert not re.search(r'\b(sorry|admit|axiom|trace_state|native_decide)\b',p.with_suffix('.lean').read_text())
 mods[m]=rec
prior={}
for name in ['source-execution-x','try-source','try-context','try-rule','try-rets','try-reservation','try-outgoing','try-values','try-emitted','try-machine','try-got','try-indirect']:
 d=json.loads((docs/f'stock-{name}-scratch.json').read_text())
 for m,rec in d['modules'].items():
  for k in ['source','object','log']:assert sha(rec[k])==rec[k+'_sha256'],(m,k)
  prior[m]=rec
freeze=json.loads(Path('/tmp/stock-coherent-build-inputs.json').read_text())
for group in ['source_sha256','validation_script_sha256']:
 for p,h in freeze[group].items():assert sha(root/p)==h,p
progress=json.loads(Path('/tmp/stock-pr246-gates-progress.json').read_text());progress.pop('completed_phases',None)
remaining=old['remaining_checklist']
for item in remaining:
 if 'Mapped/final-alias source frame' in item['requirement']:
  item['state']='Whole-driver unshared payload terminality now proved from internally derived allocator index ownership/selective constructor frames. ALL actual TryCall result keys (normal prefix and separate payload outputs, including0/1 returns) are fixed by actual final aliases. Source availability/write noninterference and final-renamed branch execution/edge continuation remain open.'
remaining.append({'requirement':'Whole-driver unshared payload endpoints and fixed actual TryCall result definitions','state':'Proved under successful actual lowering with slot ownership derived internally, complete near/GOT/indirect compiler-to-physical witnesses and overwritten cross-slot allocation witness. Shared payload exact return endpoints, final-renamed branch/source-frame composition and complete zero-return/sret matrix remain open.'})
receipt={'utc':now.isoformat(),'goal':'Original full #140 ACTIVE/INCOMPLETE; production LEGACY','scope':'Scratch-only additive Stock proofs, not coherent integration or merge-ready','delivery_target':'roughly eight substantive validated squash merges/day; remote backups and cleanup; drafts do not count','modules':mods,'public_roots':batch['public_roots'],'models':batch['models'],'counts':{'modules':len(mods),'public_roots':len(batch['public_roots']),'models':len(batch['models']),'combined_roots_models':len(sets),'previous_preserved':len(old['normal_audit']['sets']),'all_new_module_constants':len(constants)},'normal_audit':{'path':'/tmp/stock-try-rename-combined-axioms.log','sha256':sha('/tmp/stock-try-rename-combined-axioms.log'),'sets':sets},'all_constant_audit':{'path':'/tmp/stock-try-rename-all-constants.log','sha256':sha('/tmp/stock-try-rename-all-constants.log'),'all_standard_only':True,'count':len(constants)},'previous81_modules_hashes_preserved':list(prior),'canonical2246_source_and_script_freeze_preserved':True,'kernel_resources':'All new modules and both audits actual exit0 / object verified at8GiB through memcap; one heavy delivery worker retained','MCP':'No new calls; bundled provenance audit deferred until coherent integration','active_exact_PR246_validation':progress,'remaining_checklist':remaining}
(docs/'stock-try-rename-scratch.json').write_text(json.dumps(receipt,indent=2)+'\n')
text=f'''Whole-driver unshared payload endpoints — {now.isoformat()}

Seven scratch modules, {len(batch['public_roots'])} public theorem roots and {len(batch['models'])} public models pass actual8GiB kernel checks. The {len(sets)}-root/model audit preserves all534prior exact axiom sets. All {len(constants)} constants in new modules, including private operational/traversal helpers, use only standard axioms. All81previous scratch source/object/log hashes and frozen2246canonical sources plus scripts are unchanged. Prior goal turn PROGRESS: actual indirect branch normal execution/witness/audits/archive/verified backup.

Existing seqRun_rename already handles stopped runs. Its missing definition premise required exact unshared payload endpoints. Actual allocator folds now derive unique payload slot AND index ownership, including overwritten/cross-slot requests. A selective constructor guard excludes only payloads sharing existing return indices, rather than all payload reservations. Actual constructors/nested interpreter/branches/complete scans preserve inactive alias entries; original construction derives inactivity for a payload beyond its OWN return prefix. These compose through real cores/nodes/reverse traversal to prove unshared payloads remain unaliased and actual final resolver endpoints.

Combining with existing reserved-return terminality proves ALL actual resultKey definitions fixed by actual final alias maps, including zero/one explicit return layouts. No accepted-input condition, caller alias/path/cross-slot certificate or signature filter is introduced. Existing broader-exclusion/return terminal variants remain unchanged. Complete near/GOT/true-indirect compiler/prepare/forced checkedfallback/checker/physical witnesses exercise the real unshared second payload and every call result key. A nonempty overwritten/cross-slot allocator witness proves exact ownership. Complete zero-return/sret/x8/width/handler matrix remains open.

Next: compose actual final-renamed stopped runs and available source frame. Existing seqRun_rename stop arm is usable; its all-instruction use-image predicate is stronger than necessary for last-call writes. For direct/indirect branches, prefix argument stores have no register defs, so rename the prefix with D=False, then rename the final stopped call from full register agreement and use these fixed result keys for its update. This avoids adding source-availability certificates for values read before the final write. GOT additionally writes a fresh target before the call; derive its source-use alias separation internally. Shared payload exact alias-to-own-return endpoints also remain open for exception continuation.

ALL original family/effect/sinking/source/block/whole-driver simulation AND completeness, input context/visitor/static/checker/fallback/physical totality, coherent scratch integration/public/private/compiler/MCP/full/crates/runtime/encoder/BOTH E2E identity-stage gates, production compiler/checker/linker/generated consumers and fresh COMPLETE comparison remain required. Production LEGACY. S10 shared exceptional interfaces stay with @kevaundray #232/#233. Same live delivery3247835/held canonical1233457 retained; eight substantive validated squash merges/day target. No merge/new worktree/MCP/heavy retry/restarted validation this batch.

See stock-try-rename-scratch.json for hashes and full remaining checklist.
'''
(docs/'stock-try-rename-scratch.md').write_text(text)
plan=root/'docs/plans/test-binary-alignment-recovery.md';plan.write_text(plan.read_text()+'\n\n'+text)
files=[]
for rec in mods.values():files.extend(Path(rec[k]) for k in ['source','object','log','check'])
for name in ['stock-try-rename-combined-axioms','stock-try-rename-all-constants']:
 for ext in ['.lean','.log','.olean','.check.json']:files.append(Path('/tmp')/(name+ext))
files.extend(Path(p) for p in ['/tmp/stock-try-rename-batch.json','/tmp/stock-try-rule-inputs.json','/tmp/stock-try-reservation-check.py','/tmp/stock-try-rename-close.py','/tmp/stock-try-rename-status44.json','/tmp/stock-try-rename-status52.json','/tmp/stock-try-rename-status71.json','/tmp/stock-try-rename-task140.json'])
files.extend([docs/'stock-try-rename-scratch.json',docs/'stock-try-rename-scratch.md',docs/'stock-delivery-main-drift.json',plan])
archive=Path('/home/lee/.clifv-recovery')/(stamp+'-try-rename')/'checkpoint.tar.gz';archive.parent.mkdir(parents=True)
with tarfile.open(archive,'w:gz',compresslevel=1) as t:
 for p in files:t.add(p,arcname=str(p).lstrip('/'),recursive=False)
with tarfile.open(archive,'r:gz') as t:
 for p in files:assert t.extractfile(str(p).lstrip('/')).read()==p.read_bytes(),p
snapshot=Path('/tmp/stock-try-rule-inputs');size=sum(p.stat().st_size for p in snapshot.rglob('*') if p.is_file());shutil.rmtree(snapshot)
backup={'utc':now.isoformat(),'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(files),'all_members_byte_verified':True,'previous_remote_backup':json.loads((docs/'stock-try-indirect-backup.json').read_text())['remote'],'cleanup':{'duplicate_dependency_snapshot_removed':True,'bytes_reclaimed':size,'unique_sources_objects_logs_checks_audits_preserved':True,'one_shared_warm_cache_retained':True,'other_projects_touched':False,'free_bytes':shutil.disk_usage(root).free}}
(docs/'stock-try-rename-backup.json').write_text(json.dumps(backup,indent=2)+'\n');Path('/tmp/stock-try-rename-archive-path').write_text(str(archive))
print(json.dumps({'counts':receipt['counts'],'archive':str(archive),'cleanup':backup['cleanup'],'gate':progress},indent=2))
