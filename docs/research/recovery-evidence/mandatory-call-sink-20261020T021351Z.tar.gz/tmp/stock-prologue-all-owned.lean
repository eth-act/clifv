import FV.E2E.ProductionPipelineWith
import FV.Backend.Proof.StockPrologueAllChecker
import FV.Backend.Proof.StockPrologueAllClass
import FV.Backend.Proof.StockPrologueAllCode
import FV.Backend.Proof.StockPrologueAllDomain
import FV.Backend.Proof.StockPrologueAllSource
import FV.Backend.Proof.StockPrologueAllWitness
import FV.Backend.Lowering.StockPrologueAll
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let targets : Array String := #["FV.Backend.Proof.StockPrologueAllChecker", "FV.Backend.Proof.StockPrologueAllClass", "FV.Backend.Proof.StockPrologueAllCode", "FV.Backend.Proof.StockPrologueAllDomain", "FV.Backend.Proof.StockPrologueAllSource", "FV.Backend.Proof.StockPrologueAllWitness", "FV.Backend.Lowering.StockPrologueAll", "FV.E2E.ProductionPipelineWith"]
  let mut count : Nat := 0
  for (name, _) in env.constants.toList do
    let some i := env.getModuleIdxFor? name | continue
    unless targets.contains env.header.moduleNames[i]!.toString do continue
    let axioms ← collectAxioms name
    for ax in axioms do
      unless #[``propext, ``Classical.choice, ``Quot.sound].contains ax do
        throwError "disallowed axiom {ax} in {name}"
    count := count + 1
  unless count > 0 do throwError "empty consumer constant audit"
  logInfo m!"CONSUMER_CONSTANTS_STANDARD_ONLY {count}"
