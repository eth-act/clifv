from pathlib import Path
import os,signal,subprocess as sp,json,hashlib,datetime,re,time
primary=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');out=Path('/tmp/stock-author-parallel-bswap-leaf');out.mkdir(exist_ok=True)
sched=1763255;port=1946126;kernel=1946830;module='FV.Backend.Proof.StockBswapWitness'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();source=primary/(module.replace('.','/')+'.lean');source_hash=sha(source);head=sp.check_output(['git','rev-parse','HEAD'],cwd=primary,text=True).strip();assert head=='213fe68bfbda3ed5d237cb7df6651f47e5a189bc'
frozen=json.loads(Path('/tmp/stock-arithmetic-current-main-author-gates/inputs.json').read_text());assert frozen['sources'][str(source.relative_to(primary))]==source_hash
assert Path(f'/proc/{port}/cmdline').read_bytes().split(b'\0')[1]==b'/tmp/stock-mixed-normal-modules-batch52.py'
assert Path(f'/proc/{kernel}/cmdline').exists()
stopped=False
try:
 os.kill(port,signal.SIGSTOP);stopped=True
 assert Path(f'/proc/{sched}/stat').read_text().split()[2]=='T'
 children=Path(f'/proc/{sched}/task/{sched}/children').read_text().split();live=[k for k in children if Path(f'/proc/{k}/stat').exists() and Path(f'/proc/{k}/stat').read_text().split()[2]!='Z'];assert not live,('existing author kernel retained; no new job',live)
 env=dict(os.environ,PATH='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:'+os.environ['PATH'],FV_MEMCAP='12G',FV_LAKE_CACHE='/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache',LEAN_NUM_THREADS='2',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2')
 deps=[m[1] for l in source.read_text().splitlines() if (m:=re.match(r'^(?:public\s+|private\s+|meta\s+)*import\s+(\S+)',l))]
 with (out/'imports.log').open('w') as f:r=sp.run([str(primary/'scripts/memcap.sh'),'lake','build','--no-build',*deps],cwd=primary,env=env,stdout=f,stderr=sp.STDOUT)
 assert r.returncode==0,('candidate imports not current',str(out/'imports.log'))
 progress={'state':'normal_primary_leaf_started','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':os.getpid(),'primary_head':head,'module':module,'source_sha256':source_hash,'port_launcher_paused':port,'existing_port_kernel_uninterrupted':kernel,'author_scheduler_paused':sched,'new_job_cap_GiB':12,'existing_job_cap_GiB':4,'aggregate_cap_GiB':16,'max_compiler_jobs':2};(out/'progress.json').write_text(json.dumps(progress,indent=2)+'\n');print(json.dumps(progress),flush=True)
 start=time.monotonic()
 with (out/'build.log').open('w') as f:r=sp.run(['python3','/tmp/stock-delivery-time.py',str(out/'build.time'),str(primary/'scripts/memcap.sh'),'lake','build',module],cwd=primary,env=env,stdout=f,stderr=sp.STDOUT)
 assert sha(source)==source_hash and sp.check_output(['git','rev-parse','HEAD'],cwd=primary,text=True).strip()==head
 result={**progress,'state':'normal_primary_leaf_passed' if r.returncode==0 else 'normal_primary_leaf_failed','returncode':r.returncode,'elapsed_seconds':round(time.monotonic()-start,1),'log_sha256':sha(out/'build.log'),'scheduler_will_validate_current_keys':True};(out/'receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
 assert r.returncode==0,('parallel author leaf failed',r.returncode)
finally:
 if stopped:os.kill(port,signal.SIGCONT)
 print('port launcher resumed; its existing finally block owns author scheduler resume',flush=True)
