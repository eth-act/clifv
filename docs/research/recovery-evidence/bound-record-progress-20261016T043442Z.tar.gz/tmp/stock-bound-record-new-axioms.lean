import FV.Backend.Proof.StockResultRegisterTable
import FV.Backend.Proof.StockResultRegisterCoverage
import FV.Backend.Proof.StockBindingCoverage
import FV.Backend.Proof.StockRecordFormCoverage
import FV.Backend.Proof.StockScanContextCoverage
import FV.Backend.Proof.StockBindingCoverageKernel
import FV.Backend.Proof.StockBindingCoverageWitness
#print axioms Backend.Stock.Proof.Coverage.Result.stock_statement_result_table_checked
#print axioms Backend.Stock.Proof.Coverage.Result.stock_statement_result_registers
#print axioms Backend.Stock.Proof.Coverage.Result.stock_bindResults_virtual_only
#print axioms Backend.Stock.Proof.Coverage.Result.stock_emitInstruction_form_coverage
#print axioms Backend.Stock.Proof.Coverage.Result.stock_scanInstruction_form_coverage
#print axioms Backend.Stock.Proof.Coverage.Result.stock_lower_source_record_form_coverage
#print axioms Backend.Stock.Proof.Coverage.Result.stock_lower_scan_context_clean
#print axioms Backend.Stock.Proof.Coverage.Result.stock_lower_source_record_form_coverage_original
#print axioms Backend.Stock.Proof.BindingCoverageWitness.stock_binding_observed
#print axioms Backend.Stock.Proof.BindingCoverageWitness.stock_bound_record_form_witness
