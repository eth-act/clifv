import StockCallAbiStatic
import FV.Backend.Proof.StockReturnRootCalls
namespace Backend.Stock.Proof.CallRootSelectionDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option maxRecDepth 100000
set_option maxHeartbeats 6000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm

private def checkedFormat (r : Rule) : Bool :=
  match ruleFmt r with
  | none => false
  | some f => decide (2447 ≤ f ∧ f < 2447+36) &&
      (if f == 2453 then callRootRule r else if f == 2454 then indRootRule r else true)

#eval ((program.rulesOf TId.lower).filter (fun r => !checkedFormat r)).map (fun r => (r.name,ruleFmt r))
end Backend.Stock.Proof.CallRootSelectionDraft
