from pathlib import Path
import datetime, hashlib, json, re, shutil

root = Path('/home/lee/clifv/.worktrees/driver-proof-resume')
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p): return json.loads(Path(p).read_text())
prior = read(root/'docs/research/stock-return-static-scratch.json')
mods = ['StockCallOutputStatic','StockCallAbiStatic','StockCallStaticSource','StockCallStaticObservation','StockCallStaticWitness','StockCallOutputValues','StockCallOutputValuesWitness']
logs = ['/tmp/'+s+'-build.log' for s in ['stock-call-output-static','stock-call-abi-static','stock-call-static-source','stock-call-static-observation','stock-call-static-witness','stock-call-output-values','stock-call-output-values-witness']]
files = ['/tmp/'+s+'.lean' for s in mods]
compiled = ['/tmp/'+s+'.olean' for s in mods]
for key in ['scratch_sources','scratch_compiled_modules','compiled_logs']:
    for p,h in prior[key].items(): assert sha(p)==h,p
for p in logs: assert not re.search(r'error[:(]',Path(p).read_text()),p
scans = {p:[(i,l) for i,l in enumerate(Path(p).read_text().splitlines(),1) if re.search(r'\b(sorry|admit|axiom|trace_state)\b',l)] for p in files}
assert not any(scans.values())
audit = '/tmp/stock-call-static-all-axioms.log'
s = Path(audit).read_text()
normal = {m.group(1):sorted(x.strip() for x in m.group(2).split(',') if x.strip()) for m in re.finditer(r"'([^']+)' depends on axioms:\s*\[([^]]*)\]",s)}
normal.update({n:[] for n in re.findall(r"'([^']+)' does not depend on any axioms",s)})
old = prior['normal_axiom_audit']['roots']; new=read('/tmp/stock-call-static-new-roots.json')
assert len(normal)==105 and len(new)==8 and set(normal)-set(old)==set(new)
assert all(normal[n]==a for n,a in old.items())
assert all(set(a)<={'propext','Classical.choice','Quot.sound'} for a in normal.values())
assert 'error:' not in s
frozen=read('/tmp/stock-body-form-validation-inputs.json')
assert {str(p.relative_to(root)):sha(p) for t in ['FV','FVTest'] for p in (root/t).rglob('*.lean')}==frozen['all_Lean_sources']
for k in ['recorded_sources','validation_scripts']:
    for p,h in frozen[k].items(): assert sha(root/p if not Path(p).is_absolute() else p)==h,p
serial=read('/tmp/stock-static-serial-progress.json');watch=read('/tmp/stock-body-form-validation-progress.json')
for pid,script in [(serial['pid'],'/tmp/stock-static-serial-rebuild.py'),(watch['watcher_pid'],'/tmp/stock-body-form-validation-watch.py')]:
    assert Path(f'/proc/{pid}/cmdline').read_bytes().startswith(('python3\0'+script).encode())
window=read('/tmp/stock-call-static-window.json');assert window['returncode']==0 and window['controller_resumed_utc']
scope='Actual revised Stock explicit call-output allocation and successful return pins derive fresh/distinct ABI defs and state/emission framing. Actual direct/indirect argument, pin and info helpers derive CallOk/SpillInstOk with arbitrary stack arguments under original sigAbiOk. Writing actual fresh result defs frames every earlier vreg and transports callee AllHold/length to ResultsHeld. Complete four direct/indirect x ordinary/implicit-sret source pipelines preserve original LowerScope/Dominated/ArityOk/ABI and actual Stock/raw/global checked fallback/physical success, actual returned/prepared call instructions, ordinary nonempty outputs, empty explicit sret outputs, and real direct nine-argument stack stores. Auxiliary helper protocol uses the SAME actual built context and initial state. Separate concrete 7/9 result-value witnesses exercise local transport.'
limits='Selected-RHS/retained-record binding of the auxiliary helper protocol and whole-call/source/world semantic composition remain OPEN. Local result transport assumes callee AllHold and explicit result length; these must be derived from source call semantics, not added as accepted input conditions. TryCall reserved definition uniqueness/final alias transport, remaining control OpsOk/SpillInstOk/visitor success, availability/checker/fallback completeness and Stock totality remain open. ALL original rule/effect/call/trap/sinking/Try continuations, register/value/source/DFG/world/block/whole-driver simulation/completeness, compiler/checker/linker/generated-proof production integration, final complete witnesses/audits/full gates/both E2E identity-stage parity/fresh complete stock comparison and original input/theorem/axiom/#179 parity remain mandatory.'
next_steps=['Maintain canonical freeze until exact watcher terminal; inspect actual 1992-root audit and every full gate receipt.','Reconcile upstream f29d0c0 and newer peer variants before integration. Integrate all 60 scratch modules/105 roots as one coherent batch; preserve cached observations; exactly one bundled 105-root MCP, then 2097 normal roots preserving all 1992 prior exact sets and every full gate.','Bind actual call helpers to selected RHS/retained records and source semantics; derive TryCall reserved uniqueness/final alias transport and whole control visitor/static validity.','Finish original input availability/checker/fallback completeness/Stock totality and ALL original whole-driver simulation/completeness and production consumers; final complete witnesses/audits/full gates/both E2E parity/fresh comparison.']
r=dict(prior)
r.update(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),previous_goal_turn_classification='maintenance progress: resource inventory/cleanup evidence and discipline update; original proof goal remained active',scope=scope,limits=limits,scratch_sources=prior['scratch_sources']|{p:sha(p) for p in files},scratch_compiled_modules=prior['scratch_compiled_modules']|{p:sha(p) for p in compiled},compiled_logs=prior['compiled_logs']|{p:sha(p) for p in logs},source_scans=prior['source_scans']|scans,normal_axiom_audit=dict(path=audit,sha256=sha(audit),roots=normal,all105_standard_only=True,all97_prior_exact_sets_preserved=True),new_public_roots=new,resource_windows={'/tmp/stock-call-static-window.json':window},proof_development='Seven modules compiled. One isolated20GiB four-case pipeline kernel after existing owned child finished; exact same controller finally resumed08:58:29Z. All other compiles8GiB, no repeated pipeline kernel, new tree or scratch MCP. Finite source argument lists retain all original conditions; local proof inference/record-layout errors corrected before successful compile.',serial={k:serial.get(k) for k in ['state','pid','index','total','current']},watcher={k:watch.get(k) for k in ['state','phase','watcher_pid','serial_controller_pid']},integration_counts=dict(modules=60,new_roots=105,canonical_roots_after_integration=2097,bundled_MCP_roots=105),next_steps=next_steps)
r['resources']=dict(prior['resources']);r['resources'].update(free_GiB=round(shutil.disk_usage(root).free/2**30,1),new_scratch_compiled_bytes=sum(Path(p).stat().st_size for p in compiled))
(root/'docs/research/stock-call-static-scratch.json').write_text(json.dumps(r,indent=2)+'\n')
md='# Actual call ABI and fresh result-value contracts\n\nFull original #140 remains active/incomplete; production remains legacy.\n\n'+scope+'\n\n'+limits+'\n\nAll 60 scratch modules compile; 105 normal public roots use only standard axioms and all 97 prior exact sets are unchanged. Prior scratch hashes and frozen canonical bytes/scripts are unchanged. No scratch MCP yet. [Hashed receipt](stock-call-static-scratch.json).\n\nIntegration counts supersede earlier proposals: 60 modules/105 roots, one bundled 105-root MCP after integration, then 2097 normal roots preserving all 1992 prior sets and every full gate. Integration waits for the existing frozen watcher to finish and its receipts to be verified, then upstream/peer reconciliation.\n\n'+ '\n'.join(str(i+1)+'. '+x for i,x in enumerate(next_steps))+'\n'
(root/'docs/research/stock-call-static-scratch.md').write_text(md)
p=root/'docs/plans/test-binary-alignment-recovery.md';text=p.read_text();first,rest=text.split('\n',1)
p.write_text(first+'\n\n## Actual call ABI and fresh result-value contracts — '+r['utc']+'\n\n'+md.split('\n\n',2)[2]+'\n'+rest)
p=root/'docs/research/stock-full-goal-current.md';text=p.read_text();text+='\nLatest cumulative checkpoint: [stock-call-static-scratch.json](stock-call-static-scratch.json),60 modules/105 roots; target2097 normal roots and ONE bundled105-root MCP after freeze and peer reconciliation. '+scope+'\n\n'+limits+'\n';p.write_text(text)
print('PASS60modules/105Stdroots; all97 prior sets and all frozen bytes unchanged; serial',serial['index'])
