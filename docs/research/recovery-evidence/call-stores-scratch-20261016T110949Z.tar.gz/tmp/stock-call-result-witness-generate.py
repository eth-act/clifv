from pathlib import Path
head='''import StockCallResultValues
import StockCallEmissionWitness
import StockIndirectCallEmissionWitness
import StockGotCallWitness
namespace Backend.Stock.Proof.CallResultBindingWitnessDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Backend.Proof.PerEdgePrep Isle Isle.Interp Isle.Aarch64
open TupleBindingDraft CallResultBindingDraft CallResultValuesDraft CallStaticFixture
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm Stock.lower
private def values (implicit : Bool) : List Clif.Val := if implicit then [] else [⟨.i64,7⟩,⟨.i64,9⟩]
private def outputs (implicit : Bool) : List CV := if implicit then [123] else [7,9]
private theorem prefix_held (implicit : Bool) : PrefixHold (values implicit) (outputs implicit) := by
  cases implicit with
  | false =>
    constructor
    · decide
    · intro j v x atValue atResult
      rcases j with _ | (_ | j)
      all_goals simp [values,outputs] at atValue atResult
      all_goals cases atValue; cases atResult; rfl
  | true => exact ⟨by decide,by intro j v x atValue; simp [values] at atValue⟩
private theorem set_exists (xs : List Nat) (vs : List Clif.Val) (length : xs.length = vs.length)
    (regs : Clif.Regs) : ∃ next,regs.setMany xs vs = some next := by
  induction xs generalizing vs regs with
  | nil => cases vs <;> simp_all [Clif.Regs.setMany]
  | cons x xs ih =>
    cases vs with
    | nil => simp at length
    | cons v vs => exact ih vs (by simpa using length) (regs.set x v)

def ResultBindingFacts (implicit : Bool) (result : Result) (event : BlockScanEvent)
    (record : ScanRecord) (info : IInfo) (step : Step) : Prop :=
  info.results.length = (if implicit then 0 else 2) ∧
  step.results = freshVectors record.input.base.nextVreg info.results.length ∧
  (∀ j x,info.results[j]? = some x → ∃ key,event.ctx.valueReg? x = some (.vreg key .int) ∧
    (result.final.alias[key]?).join = some (record.input.base.nextVreg+j) ∧
    aliasNum result.final.alias key = record.input.base.nextVreg+j) ∧
  ∃ (fr fr' : Clif.Frame) (regs : Clif.Regs),
    fr.regs.setMany info.results (values implicit) = some regs ∧ fr'.regs = regs ∧
    PrefixHold (values implicit) (outputs implicit) ∧
    ValuesHeld (fun x => x ∈ info.results) result.ctx fr'
      (fun key => writeV (fun _ => 0)
        ((callDefOps (outDefs record.input.base.nextVreg info.results.length)).zip (outputs implicit))
          (aliasNum result.final.alias key))

private theorem make_facts (implicit : Bool) (f : Clif.Function) (result : Result) (event : BlockScanEvent)
    (record : ScanRecord) (info : IInfo) (step : Step)
    (length : info.results.length = (if implicit then 0 else 2))
    (output : step.results = freshVectors record.input.base.nextVreg info.results.length)
    (bindings : ∀ j x,info.results[j]? = some x → ∃ key,event.ctx.valueReg? x = some (.vreg key .int) ∧
      (result.final.alias[key]?).join = some (record.input.base.nextVreg+j) ∧
      aliasNum result.final.alias key = record.input.base.nextVreg+j)
    (transfer : ∀ (fr fr' : Clif.Frame) (regs : Clif.Regs),
      fr.regs.setMany info.results (values implicit) = some regs → fr'.regs = regs →
      ValuesHeld (fun x => x ∈ info.results) result.ctx fr'
        (fun key => writeV (fun _ => 0)
          ((callDefOps (outDefs record.input.base.nextVreg info.results.length)).zip (outputs implicit))
            (aliasNum result.final.alias key))) : ResultBindingFacts implicit result event record info step := by
  let fr : Clif.Frame := ⟨f,fun _ => none,[],[],.ret []⟩
  have count : info.results.length = (values implicit).length := by rw [length]; cases implicit <;> rfl
  obtain ⟨regs,set⟩ := set_exists info.results (values implicit) count fr.regs
  exact ⟨length,output,bindings,fr,{fr with regs},regs,set,rfl,prefix_held implicit,transfer fr {fr with regs} regs set rfl⟩
'''
text=head
for kind in ['direct','indirect','got']:
 ind='true' if kind=='indirect' else 'false'
 func=f'(function {ind} implicit)' if kind!='got' else '(GotCallFixture.function implicit)'
 typ='Output' if kind!='got' else 'GotCallFixture.Output'
 facts=f'Facts {ind} implicit out' if kind!='got' else 'GotCallFixture.Facts implicit out'
 clif=f'(.callIndirect 0 80 (arguments true implicit))' if kind=='indirect' else '(.call 0 (arguments false implicit))'
 oldns={'direct':'CallEmissionWitnessDraft','indirect':'IndirectCallEmissionWitnessDraft','got':'GotCallWitnessDraft'}[kind]
 tail={'direct':'actual,placed','indirect':'origin,actual,placed','got':'protocol,actual,placed'}[kind]
 text+=f'''
/-- Complete original-condition {kind} ordinary/two-result and sret/zero-result
pipelines inhabit actual tuple aliases and successful source value binding.
The sret case also exercises an extra unused ABI value; cached pipelines are reused. -/
theorem stock_complete_{kind}_call_result_binding_witness (implicit : Bool) :
    ∃ (out : {typ}) (event : BlockScanEvent) (record : ScanRecord) (info : IInfo) (step : Step),
      LowerScope {func} ∧ Dominated {func} ∧ ArityOk {func} ∧ AbiSigsOk {func} ∧
      Stock.lower {func} = .ok out.result ∧
      prepareAt out.result.code out.result.edgeArgs = .ok out.prepared ∧
      out.rf = spillAllocAt out.prepared.code out.prepared.edges ∧
      checkAllocAt out.prepared.code out.prepared.edges out.rf = .ok () ∧
      lowerRFunc out.prepared.code out.rf = .ok out.af ∧ {facts} ∧
      event ∈ out.result.blockScans.toList ∧ record ∈ event.output.records ∧
      event.ctx.insts[record.inst]? = some info ∧ info.clif = some {clif} ∧
      record.output.step = some step ∧ step.decision = .emitted ∧
      ResultBindingFacts implicit out.result event record info step := by
  obtain ⟨out,event,record,info,step,scope,dominated,arity,abi,lowered,prepared,fallback,checked,physical,
    facts,events,records,slot,clif,recorded,emitted,{tail}⟩ :=
    {oldns}.stock_complete_{kind}_call_emission_witness implicit
'''
 if kind=='indirect':
  text+='''  obtain ⟨sig,declared,length,output,bindings⟩ := stock_lower_indirect_call_result_binding lowered scope dominated.ssa abi events records slot clif recorded emitted
  have expected : (function true implicit).sigDecls.lookup 0 = some (signature true implicit) := rfl
  have same := Option.some.inj (declared.symm.trans expected)
  subst sig
'''
 else:
  text+=f'''  let ext : Clif.ExtFunc := {{name := calleeName,sig := signature false implicit,colocated := {'false' if kind=='got' else 'true'}}}
  have external : {func}.extern? 0 = some ext := rfl
  obtain ⟨length,output,bindings⟩ := stock_lower_call_result_binding lowered scope dominated.ssa abi events records slot clif external recorded emitted
'''
 text+=f'''  have count : info.results.length = (if implicit then 0 else 2) := by
    rw [length]
    cases implicit <;> rfl
  have bound := make_facts implicit {func} out.result event record info step count output bindings (by
    intro fr fr' regs set updated
    exact {'stock_lower_indirect_call_result_values' if kind=='indirect' else 'stock_lower_call_result_values'} lowered scope dominated.ssa abi events records slot clif {'external ' if kind!='indirect' else ''}recorded emitted set updated (prefix_held implicit))
  exact ⟨out,event,record,info,step,scope,dominated,arity,abi,lowered,prepared,fallback,checked,physical,
    facts,events,records,slot,clif,recorded,emitted,bound⟩
'''
text+='end Backend.Stock.Proof.CallResultBindingWitnessDraft\n'
Path('/tmp/StockCallResultBindingWitness.lean').write_text(text)
