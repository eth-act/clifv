from pathlib import Path
import os,signal,subprocess,time,json,datetime
pid=json.loads(Path('/tmp/stock-static-serial-progress.json').read_text())['pid'];assert Path(f'/proc/{pid}/cmdline').read_bytes().startswith(b'python3\0/tmp/stock-static-serial-rebuild.py');os.kill(pid,signal.SIGSTOP)
r={'controller_pid':pid,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reason':'Isolate two complete new noncolocated/GOT ordinary+sret source pipelines and retained records at20GiB; preserve frozen sources and resume same exact controller'}
try:
 children=Path(f'/proc/{pid}/task/{pid}/children').read_text().split();r['existing_children']=children
 def live(p):
  try:return Path(f'/proc/{p}/stat').read_text().split(') ',1)[1][0]!='Z'
  except FileNotFoundError:return False
 while any(live(c) for c in children):time.sleep(1)
 print('Previous owned build finished; compiling one scratch observation kernel',flush=True)
 env=dict(os.environ,OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',LEAN_PATH='/tmp',FV_MEMCAP='20G')
 with Path('/tmp/stock-got-call-observation-build.log').open('w') as log:
  q=subprocess.run(['scripts/memcap.sh','/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin/lake','env','lean','--root=/tmp','-o','/tmp/StockGotCallObservation.olean','/tmp/StockGotCallObservation.lean'],cwd='/home/lee/clifv/.worktrees/driver-proof-resume',env=env,stdout=log,stderr=subprocess.STDOUT)
 r['returncode']=q.returncode
finally:
 os.kill(pid,signal.SIGCONT);r['controller_resumed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();Path('/tmp/stock-got-call-window.json').write_text(json.dumps(r,indent=2)+'\n');print('Same controller resumed',r,flush=True)

raise SystemExit(r.get("returncode",1))
