from pathlib import Path
import os,json,re,time,subprocess as sp,traceback
prefix=Path('/tmp/stock-d0-affected-gates.py').read_text().split('\ntry:\n')[0].replace("Path('/tmp/stock-d0-affected-gates')","Path('/tmp/stock-d0-post-narrow-gates')")
exec(compile(prefix,'/tmp/stock-d0-affected-gates.py','exec'),globals())
oldpid=4094834
assert '/tmp/stock-execute-scheduler.py' in Path(f'/proc/{oldpid}/cmdline').read_text()
def controller(name,path):
 frozen();p=root/(name+'.log');report('running',phase=name,log=str(p))
 with p.open('w') as log:r=sp.run(['python3',path],cwd=view,env=env,stdout=log,stderr=sp.STDOUT)
 assert r.returncode==0,(name,r.returncode,str(p));frozen();logs[name]={'path':str(p),'sha256':sha(p)}
try:
 report('waiting_on_confirmed_live_narrow_scheduler',scheduler_pid=oldpid,log='/tmp/stock-d0-complete-witness-controller.log')
 while Path(f'/proc/{oldpid}/cmdline').exists():
  if '/tmp/stock-execute-scheduler.py' not in Path(f'/proc/{oldpid}/cmdline').read_text():break
  time.sleep(10)
 text=Path('/tmp/stock-d0-complete-witness-controller.log').read_text();end=re.findall(r'END (\d+)/(\d+) ok',text)
 assert end and end[-1][0]==end[-1][1], 'Narrow proof gate did not pass; inspect exact module errors and preserve passed caches'
 old=json.loads(Path('/tmp/stock-d0-independent-gates/inputs.json').read_text());assert old['head']==head and old['sources']==frozen_sources
 passed=json.loads(Path('/tmp/stock-d0-independent-gates/progress.json').read_text());assert passed['state']=='independent_runtime_encoder_e2e_passed'
 for name,receipt in passed['logs'].items():assert sha(Path(receipt['path']))==receipt['sha256'];logs['reused-'+name]=receipt
 report('current_runtime_encoder_e2e_gates_reused_by_exact_source_and_log_hash',identity_stage_parity=passed['identity_stage_parity'])
 run('lean-link-modules',['python3','/tmp/stock-execute-scheduler.py','--budget','16G','--max-jobs','3','--max-cap','16G','--default-cap','8G','--others-by-usage','--out',str(root/'lean-link-modules'),'FVTest.Link.LeanLinkMain'])
 run('lean-link-tool',['lake','build','lean-link'])
 run('d0-roots-audit',['python3','scripts/axiom-audit.py','scripts/audit/stock-d0.lean','--log-dir',str(root/'d0-roots-audit')])
 run('all-changed-constants',['lake','env','lean','--root=/tmp','/tmp/stock-d0-all-constants.lean'])
 run('stock-development-artifacts',['python3','-m','unittest','-v','test_stock_compiler_compare.StockDevelopmentIntegrationTests'])
 meta=json.loads(Path('/tmp/stock-cgclif-source.json').read_text());assert sha(Path(meta['output']))==meta['output_sha256'];assert sha(view/'scripts/patches/cg-clif-extnames.patch')==meta['patch_sha256']
 run('rust-tools',['cargo','build','--release','--locked','-p','cargo-fv','-p','clif-data-export','-p','lean-regalloc'],cwd=view/'rust')
 for example in ['fv-demo','survey']:run('verified-'+example,['bash','examples/compare.sh','examples/'+example,'--lean-link','--verified','--keep-temps'])
 units=view/'examples/fv-demo/target/fv/plain-leanlink-verified-leanld/units';found={}
 for unit in units.glob('*.json'):
  data=json.loads(unit.read_text())
  for fn in data.get('functions',[]):
   for name in ['stock_entry_return::identity32','stock_entry_return::identity64']:
    if name in fn.get('instance',''):found.setdefault(name,[]).append({'unit':str(unit),'symbol':fn['symbol'],'status':fn['status']})
 assert len(found)==2,found
 assert all(row['status']=='verified' for rows in found.values() for row in rows),found
 (root/'mixed-program-verified-functions.json').write_text(json.dumps(found,indent=2)+'\n')
 symbols={row['symbol'] for rows in found.values() for row in rows};dumps=[]
 for link in (units.parent/'tmp').glob('*/fv-link.json'):
  for fn in json.loads(link.read_text()).get('functions',[]):
   if fn['symbol'] in symbols:
    assert fn['verified'];dump=link.parent/'split'/Path(fn['dump']).name;assert dump.is_file(),dump;dumps.append(str(dump))
 assert len(dumps)>=2,dumps
 (root/'mixed-program-stock-dumps.json').write_text(json.dumps(sorted(set(dumps)),indent=2)+'\n')
 run('mixed-program-stock-routes',['lake','env','lean','--run','/tmp/stock-d0-production-routes.lean',*sorted(set(dumps))])
 controller('generated-proof-consumers','/tmp/stock-d0-generated-proof-gate.py')
 report('d0_current_affected_gates_and_generated_consumers_passed_full_module_gate_pending')
 controller('full-module-and-trust-gate','/tmp/stock-d0-full-module-gate.py')
 module_state=json.loads(Path('/tmp/stock-d0-full-module-gate/progress.json').read_text())
 report('implementation_gates_finished_or_waiting_on_heavy_handoff',full_module_state=module_state['state'],remaining='Inspect all actual gate outcomes and current main before author squash; no merge is automated by this controller. Original #140 remains after D0.')
except BaseException as e:report('failed',error=repr(e),traceback=traceback.format_exc());raise
