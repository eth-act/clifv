from pathlib import Path
import importlib.util,json,subprocess as sp,os,datetime,traceback
prefix=Path('/tmp/stock-d0-affected-gates.py').read_text().split('\ntry:\n')[0].replace("Path('/tmp/stock-d0-affected-gates')","Path('/tmp/stock-d0-full-module-gate')")
exec(compile(prefix,'/tmp/stock-d0-affected-gates.py','exec'),globals())
spec=importlib.util.spec_from_file_location('s','/tmp/stock-execute-scheduler.py');sched=importlib.util.module_from_spec(spec);spec.loader.exec_module(sched)
_,mods,imports=sched.load_modules(view);wanted={n for n in mods if n=='FV' or n.startswith('FV.') or n=='FVTest' or n.startswith('FVTest.')}
heavy='FV.Backend.Proof.StockCmpWithFlags';excluded={heavy};q=[heavy];rdeps={n:[] for n in mods}
for n,deps in imports.items():
 for d in deps:rdeps[d].append(n)
while q:
 for n in rdeps[q.pop()]:
  if n not in excluded:excluded.add(n);q.append(n)
(root/'non-heavy-modules.txt').write_text('\n'.join(sorted(wanted-excluded))+'\n');(root/'pending-heavy-descendants.txt').write_text('\n'.join(sorted(wanted&excluded))+'\n')
command=['python3','/tmp/stock-execute-scheduler.py','--budget','16G','--max-jobs','3','--max-cap','16G','--default-cap','8G','--others-by-usage']
try:
 report('building_non_heavy_subset_not_a_full_gate',total_modules=len(wanted),selected=len(wanted-excluded),pending_heavy_closure=len(wanted&excluded))
 run('non-heavy-modules',[*command,'--out',str(root/'non-heavy-modules'),'--only',str(root/'non-heavy-modules.txt'),'FV','FVTest'])
 report('non_heavy_subset_passed_not_a_full_gate',pending_heavy_closure=len(wanted&excluded))
 ci=json.loads(sp.check_output(['gh','run','view','39242870268','--json','status,conclusion'],cwd=view,text=True))
 if ci['status']!='completed':
  report('waiting_for_verified_live_heavy_ci',run=39242870268,ci=ci,remaining='Poll same CI handle; restore exact-source outputs through official Lake keys and run full FV/FVTest gate and E2E audit.');raise SystemExit(0)
 assert ci['conclusion']=='success',ci
 run('download-heavy-cache',['gh','run','download','39242870268','--name','stock-cmp-heavy-cache','--dir',str(root/'heavy-stage')])
 manifests=list((root/'heavy-stage').rglob('outputs.jsonl'));assert len(manifests)==1,manifests
 run('restore-heavy-cache',['lake','cache','unstage',str(manifests[0].parent)])
 run('validate-current-heavy-input-key',['lake','build','--no-build',heavy])
 run('all-modules',[*command,'--out',str(root/'all-modules'),'FV','FVTest'])
 run('library-replay',['lake','build','FV','FVTest'])
 run('e2e-axiom-audit',['python3','scripts/axiom-audit.py','--log-dir',str(root/'axiom-audit')])
 run('all-changed-constants',['lake','env','lean','--root=/tmp','/tmp/stock-d0-all-constants.lean'])
 report('full_current_module_and_trust_gates_passed',remaining='Require current runtime/encoder/E2E, verified crates and generated-proof gates; reconcile main and squash substantive production PR. Full original #140 remains after D0.')
except SystemExit:raise
except BaseException as e:report('failed',error=repr(e),traceback=traceback.format_exc());raise
