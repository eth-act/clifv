from pathlib import Path
import os,signal,subprocess as sp,json,hashlib,datetime,re,time
root=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');out=Path('/tmp/stock-author-spare-slot-batch');out.mkdir(exist_ok=True);port=1946126;kernel=1946830;sched=1763255
mods=['FV.Backend.Proof.StockAddSubNegativeWitness','FV.Backend.Proof.StockAddSubImmediateWitness','FV.Backend.Proof.StockMinMaxNarrowBothConstantDriverRuns','FV.Backend.Proof.StockMinMaxWideBothConstantDriverRuns']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();head=sp.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert head=='213fe68bfbda3ed5d237cb7df6651f47e5a189bc';frozen=json.loads(Path('/tmp/stock-arithmetic-current-main-author-gates/inputs.json').read_text());records=[];stopped=False
assert Path(f'/proc/{port}/cmdline').read_bytes().split(b'\0')[1]==b'/tmp/stock-mixed-normal-modules-batch52.py'
def kernel_live():
 p=Path(f'/proc/{kernel}')
 try:return p.joinpath('stat').read_text().split()[2]!='Z' and b'IselPrgTab.lean' in p.joinpath('cmdline').read_bytes()
 except FileNotFoundError:return False
def report(state,**kw):
 j={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':os.getpid(),'state':state,'primary_head':head,'port_launcher_paused':port,'existing_port_kernel':kernel,'author_scheduler_held':sched,'max_compiler_jobs':2,'aggregate_cap_GiB':16,'records':records,**kw};(out/'progress.json').write_text(json.dumps(j,indent=2)+'\n');print(json.dumps({k:v for k,v in j.items() if k!='records'}),flush=True)
try:
 os.kill(port,signal.SIGSTOP);stopped=True
 assert Path(f'/proc/{sched}/stat').read_text().split()[2]=='T'
 kids=Path(f'/proc/{sched}/task/{sched}/children').read_text().split();assert not [k for k in kids if Path(f'/proc/{k}/stat').exists() and Path(f'/proc/{k}/stat').read_text().split()[2]!='Z']
 env=dict(os.environ,PATH='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:'+os.environ['PATH'],FV_MEMCAP='12G',FV_LAKE_CACHE='/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache',LEAN_NUM_THREADS='2',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2')
 for m in mods:
  if not kernel_live():break
  source=root/(m.replace('.','/')+'.lean');h=sha(source);assert frozen['sources'][str(source.relative_to(root))]==h
  deps=[x[1] for l in source.read_text().splitlines() if (x:=re.match(r'^(?:public\s+|private\s+|meta\s+)*import\s+(\S+)',l))]
  with (out/(m+'.imports.log')).open('w') as f:r=sp.run([str(root/'scripts/memcap.sh'),'lake','build','--no-build',*deps],cwd=root,env=env,stdout=f,stderr=sp.STDOUT)
  if r.returncode:records.append({'module':m,'state':'waiting_for_current_imports'});continue
  report('building_one_ready_author_leaf',module=m,cap_GiB=12)
  log=out/(m+'.build.log');start=time.monotonic()
  with log.open('w') as f:r=sp.run(['python3','/tmp/stock-delivery-time.py',str(out/(m+'.time')),str(root/'scripts/memcap.sh'),'lake','build',m],cwd=root,env=env,stdout=f,stderr=sp.STDOUT)
  assert sha(source)==h and sp.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head
  records.append({'module':m,'state':'passed' if r.returncode==0 else 'failed','returncode':r.returncode,'source_sha256':h,'log':str(log),'log_sha256':sha(log),'elapsed_seconds':round(time.monotonic()-start,1)})
  assert r.returncode==0,('author ready leaf failed',m,r.returncode)
 report('ready_author_batch_terminal',existing_port_kernel_live=kernel_live())
finally:
 if stopped:os.kill(port,signal.SIGCONT)
 print('port launcher resumed; its finally owns author scheduler resume',flush=True)
