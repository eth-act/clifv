from pathlib import Path
import subprocess as sp,os,json,hashlib
view=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');root=Path('/tmp/stock-production-cli-original-bundles-check');root.mkdir(exist_ok=True);records={}
env=dict(os.environ,FV_MEMCAP='8G',FV_LAKE_CACHE='/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2');env['PATH']='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:'+env['PATH']
def run(name,args):
 log=root/(name+'.log');(root/'state.json').write_text(json.dumps({'state':'running','phase':name,'pid':os.getpid()}))
 with log.open('w') as f:r=sp.run(['scripts/memcap.sh','lake','env',*args],cwd=view,env=env,stdout=f,stderr=sp.STDOUT)
 records[name]={'rc':r.returncode,'sha256':hashlib.sha256(log.read_bytes()).hexdigest()};assert r.returncode==0,(name,r.returncode,str(log));return log
try:
 lp=sp.check_output(['scripts/memcap.sh','lake','env','printenv','LEAN_PATH'],cwd=view,env=env,text=True).strip()
 for mode,flags in [('Plain',['--no-dead-cleanup']),('Cleanup',[])]:
  bundle=Path('/tmp/stock-production-linked-proper')/('StockProduction2'+mode+'FallbackGlobal-bundle')
  log=run('lean-link-'+mode,['lean','--run','FVTest/Link/LeanLinkMain.lean',str(bundle),'--verified',*flags])
  assert 'written by Link.ProductionCompilerWith.compile' in log.read_text()
  assert 'attempt_correct_source_peak' in log.read_text()
  proof=root/'Crates'/('ProductionCLI'+mode+'.lean');proof.parent.mkdir(exist_ok=True)
  run('link-check-'+mode,['lean','--run','FVTest/E2E/LinkCheckMain.lean',str(bundle),'--lean',str(proof),'--module','ProductionCLI'+mode,*flags])
  env['LEAN_PATH']=str(root)+':'+lp
  run('proof-'+mode,['lean','--root='+str(root),'-o',str(proof.with_suffix('.olean')),str(proof)])
  env.pop('LEAN_PATH',None)
 (root/'state.json').write_text(json.dumps({'state':'passed','records':records},indent=2))
except BaseException as e:
 (root/'state.json').write_text(json.dumps({'state':'failed','error':repr(e),'records':records},indent=2));raise
