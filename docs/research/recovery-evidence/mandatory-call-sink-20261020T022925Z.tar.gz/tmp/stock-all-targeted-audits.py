from pathlib import Path
import os,subprocess as sp,json,datetime,hashlib,traceback
view=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');root=Path('/tmp/stock-all-targeted-audits');root.mkdir(exist_ok=True);records={}
env=dict(os.environ,FV_MEMCAP='8G',LEAN_NUM_THREADS='2',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',FV_LAKE_CACHE='/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache');env['PATH']='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:'+env['PATH']
def report(state,**kw):
 d={'state':state,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':os.getpid(),'records':records,**kw};(root/'state.json').write_text(json.dumps(d,indent=2));print(json.dumps({k:v for k,v in d.items() if k!='records'}),flush=True)
def run(n,args):
 report('running',phase=n);p=root/(n+'.log')
 with p.open('w') as f:r=sp.run([str(view/'scripts/memcap.sh'),*args],cwd=view,env=env,stdout=f,stderr=sp.STDOUT)
 records[n]={'rc':r.returncode,'log':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()};assert r.returncode==0,(n,r.returncode,str(p))
try:
 run('public-audits',['python3','scripts/axiom-audit.py','--log-dir',str(root/'public'),'scripts/audit/stock-production-parametric.lean','scripts/audit/stock-production-all-boundary.lean','scripts/audit/stock-prologue-all-configurations.lean'])
 counts=[]
 for i,p in enumerate(json.loads(Path('/tmp/stock-all-owned-partitions.json').read_text())):
  run('owned-'+str(i),['lake','env','lean','--root=/tmp',p]);t=Path(records['owned-'+str(i)]['log']).read_text();counts.append(int(t.split('CONSUMER_CONSTANTS_STANDARD_ONLY ')[1].split()[0]))
 report('passed',owned_counts=counts,total_owned=sum(counts))
except BaseException as e:report('failed',error=repr(e),traceback=traceback.format_exc());raise
