import FV.Link.ProductionCompatibility
import FV.Backend.Lowering.StockPrologueAll
import FV.Backend.ProductionWith
import FV.Backend.Proof.StockPrologueAllChecker
import FV.Backend.Proof.StockPrologueAllClass
import FV.Backend.Proof.StockPrologueAllCode
import FV.Backend.Proof.StockPrologueAllDomain
import FV.Backend.Proof.StockPrologueAllSource
import FV.Backend.Proof.StockPrologueAllWitness
import FV.E2E.ProductionBinary
import FV.E2E.ProductionChecksWith
import FV.E2E.ProductionExecGot
import FV.E2E.ProductionPipelineWith
import FV.E2E.ProductionStackBound
import FV.Link.ProductionCompileWith
import FV.Link.ProductionExeSource
import FV.Link.ProductionExeSourceWith
import FV.Link.ProductionExeWith
import FV.Link.ProductionImageWith
import FV.Link.ProductionImageWithProof
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let targets : Array String := #["FV.Link.ProductionCompatibility", "FV.Backend.Lowering.StockPrologueAll", "FV.Backend.ProductionWith", "FV.Backend.Proof.StockPrologueAllChecker", "FV.Backend.Proof.StockPrologueAllClass", "FV.Backend.Proof.StockPrologueAllCode", "FV.Backend.Proof.StockPrologueAllDomain", "FV.Backend.Proof.StockPrologueAllSource", "FV.Backend.Proof.StockPrologueAllWitness", "FV.E2E.ProductionBinary", "FV.E2E.ProductionChecksWith", "FV.E2E.ProductionExecGot", "FV.E2E.ProductionPipelineWith", "FV.E2E.ProductionStackBound", "FV.Link.ProductionCompileWith", "FV.Link.ProductionExeSource", "FV.Link.ProductionExeSourceWith", "FV.Link.ProductionExeWith", "FV.Link.ProductionImageWith", "FV.Link.ProductionImageWithProof"]
  let mut count : Nat := 0
  for (name, _) in env.constants.toList do
    let some i := env.getModuleIdxFor? name | continue
    unless targets.contains env.header.moduleNames[i]!.toString do continue
    let axioms ← collectAxioms name
    for ax in axioms do
      unless #[``propext, ``Classical.choice, ``Quot.sound].contains ax do
        throwError "disallowed axiom {ax} in {name}"
    count := count + 1
  unless count > 0 do throwError "empty consumer constant audit"
  logInfo m!"CONSUMER_CONSTANTS_STANDARD_ONLY {count}"
