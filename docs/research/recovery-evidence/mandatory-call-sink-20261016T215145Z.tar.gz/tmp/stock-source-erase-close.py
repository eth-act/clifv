from pathlib import Path
import json,hashlib,re,datetime,tarfile,shutil
root=Path('/home/lee/clifv/.worktrees/driver-proof-resume');docs=root/'docs/research';prefix='stock-source-erase'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
now=datetime.datetime.now(datetime.timezone.utc);stamp=now.strftime('%Y%m%dT%H%M%SZ')
batch=json.loads(Path('/tmp/'+prefix+'-batch.json').read_text());old=json.loads((docs/'stock-try-critical-normal-scratch.json').read_text())
log=Path('/tmp/'+prefix+'-combined-axioms.log').read_text()
sets={m.group(1):sorted(x.strip() for x in m.group(2).split(',') if x.strip()) for m in re.finditer(r"'([^']+)' depends on axioms:\s*\[([^]]*)\]",log)}
for m in re.finditer(r"'([^']+)' does not depend on any axioms",log):sets[m.group(1)]=[]
for n,a in old['normal_audit']['sets'].items():assert sorted(a)==sets[n],n
assert len(sets)==len(old['normal_audit']['sets'])+len(batch['public_roots'])+len(batch['models'])
allowed={'propext','Classical.choice','Quot.sound'}
for n in batch['public_roots']+batch['models']:assert set(sets[n])<=allowed,n
constants=[json.loads(line.split('DELIVERY_CONSTANT ',1)[1]) for line in Path('/tmp/'+prefix+'-all-constants.log').read_text().splitlines() if line.startswith('DELIVERY_CONSTANT ')]
assert constants
for n,a in constants:assert set(a)<=allowed,n
mods={}
for m in batch['modules']:
 p=Path('/tmp')/m;check=json.loads(p.with_suffix('.check.json').read_text());assert check['actual_exit']==0
 rec={}
 for key,ext in [('source','.lean'),('object','.olean'),('log','.log'),('check','.check.json')]:
  f=p.with_suffix(ext);rec[key]=str(f);rec[key+'_sha256']=sha(f)
 for k in ['source','object','log']:assert rec[k+'_sha256']==check[k+'_sha256']
 assert not re.search(r'\b(sorry|admit|axiom|trace_state|native_decide)\b',p.with_suffix('.lean').read_text()),m
 mods[m]=rec
for audit in [prefix+'-combined-axioms',prefix+'-all-constants']:
 p=Path('/tmp')/audit;check=json.loads(p.with_suffix('.check.json').read_text());assert check['actual_exit']==0
 for k,ext in [('source','.lean'),('object','.olean'),('log','.log')]:assert sha(p.with_suffix(ext))==check[k+'_sha256']
prior={}
for name in ['source-execution-x','try-source','try-context','try-rule','try-rets','try-reservation','try-outgoing','try-values','try-emitted','try-machine','try-got','try-indirect','try-rename','try-resolved','try-gap','try-got-rename','try-normal-frame','try-metadata','source-index','try-normal-vector','try-critical-normal']:
 d=json.loads((docs/f'stock-{name}-scratch.json').read_text())
 for m,rec in d['modules'].items():
  for k in ['source','object','log']:assert sha(rec[k])==rec[k+'_sha256'],(m,k)
  prior[m]=rec
freeze=json.loads(Path('/tmp/stock-coherent-build-inputs.json').read_text())
for group in ['source_sha256','validation_script_sha256']:
 for p,h in freeze[group].items():assert sha(root/p)==h,p
progress=json.loads(Path('/tmp/stock-pr246-gates-progress.json').read_text());progress.pop('completed_phases',None)
remaining=list(old['remaining_checklist']);remaining.append({'requirement':'Actual source-root reservation context erasure and stronger ordinary provenance','state':'Kernel proved actual arbitrary-fuel root equality, including exact values/state/trace/errors, under original overlap=false. The842-term checked closure supplies constructor exclusion internally. Actual selected root and availability classifications now have only fresh/source alternatives even with arbitrary nonempty reservations. Old variants preserved. Complete same-source LowerScope/Dominated/Arity/compiler/prepare/forced checkedfallback/checker/physical and source9 witness, changed terminator, nonempty reserves and actual source run/erased run inhabit all new roots. General constructor/extractor irrelevance helpers audited, equivalent local constructor case decomposition checked definitionally against actual compiler; compiler code unchanged. Whole retained-record/alias-chain source origins, available source vs reserved terminal/write separation, actual machine value/copy/continuation simulation remain OPEN.'})
counts={'modules':len(mods),'public_roots':len(batch['public_roots']),'models':len(batch['models']),'combined_roots_models':len(sets),'previous_preserved':len(old['normal_audit']['sets']),'all_new_module_constants':len(constants),'previous_modules_hashes_preserved':len(prior)}
receipt={'utc':now.isoformat(),'goal':'Original full #140 ACTIVE/INCOMPLETE; production LEGACY','scope':'Scratch-only additive Stock proofs, not coherent integration or merge-ready','delivery_target':'roughly eight substantive validated squash merges/day; coherent queue priority, backup and cleanup','modules':mods,'public_roots':batch['public_roots'],'models':batch['models'],'counts':counts,'normal_audit':{'path':'/tmp/'+prefix+'-combined-axioms.log','sha256':sha('/tmp/'+prefix+'-combined-axioms.log'),'sets':sets},'all_constant_audit':{'path':'/tmp/'+prefix+'-all-constants.log','sha256':sha('/tmp/'+prefix+'-all-constants.log'),'all_standard_only':True,'count':len(constants)},'previous_modules_hashes_preserved':list(prior),'canonical2246_source_and_script_freeze_preserved':True,'MCP':'Deferred until coherent integration; no new calls','active_exact_PR246_validation':progress,'remaining_checklist':remaining}
(docs/(prefix+'-scratch.json')).write_text(json.dumps(receipt,indent=2)+'\n')
text=f'''Actual source-root reservation erasure and ordinary provenance — {now.isoformat()}

{len(mods)}scratch modules/{len(batch['public_roots'])}public roots/{len(batch['models'])}model pass actual8GiB kernel checks. The {len(sets)}-root/model cumulative audit preserves all626prior exact axiom sets. All{len(constants)}new-module constants including private/generated constructor decomposition helpers use only standard axioms. All{len(prior)}prior source/object/log hashes and frozen2246canonical sources/49scripts unchanged. Previous turn PROGRESS: actual Try-critical normal vector/full witnesses,842-term no-reserved-constructor closure,626audit/115constants, verifieddf187ec6 remote backup/2.8GBcleanup.

Actual arbitrary-fuel statement-root interpretation is exactly unchanged after clearing ctx.tryRegs: values, complete Stock.State, traces, failure/errors all agree. The real842-term constructor/rule closure supplies no-gen_try_call_rets internally. Generic source/selected consumers add no caller reachability, reservation/disjointness, selected helper or alias certificate. Original overlap=false is the existing configuration. Backend constructor equality is proved via a local case decomposition definitionally equal to the actual compiler; this avoids generating the original large imported match splitter under its smaller saved heartbeat options. The actual compiler sources remain unchanged. Constructor helper nonempty output witness passes.

Successful ordinary source outputs in arbitrary-reservation contexts now classify ONLY as freshly allocated registers or mapped source provenance. The actual selected terminator-overridden context transports that ordinary provenance back to the original source. Original Dominated/available-source facts then establish ordinary source availability with no reserved-output alternative. Old theorem variants remain unchanged. This closes the conservative branch at source roots; whole record/alias-chain propagation and reserved-write machine framing are still required.

A COMPLETE same-source compiler/prepare/forced checkedfallback/checker/physical pipeline and original LowerScope/Dominated/Arity witness passes. Actual source constant9 lowering at changed terminator/nonempty194/195/196reservations yields fresh197; the SAME actual run, state and trace survive erasure. All generic/selected/source-availability roots are instantiated, and full original Clif.runWith with argument7 returns i8 value9. This witness is source-side; it does not claim machine clobber/copy/continuation simulation.

Next propagate stronger source origins through retained bindings, whole source-alias records and final resolver paths; combine original availability/dominance and actual reserved terminal/definition facts to prove universal live-source/write separation. Then compose actual final-renamed call return values with inherited .val values through real outgoing arguments, normal parameter copies and source continuation. ALL shared payload endpoints/exception machine semantics, zero-return/sret/x8/width/handler/Try-critical matrix, uncovered families/effects/sinking/source/block/whole-driver simulation AND completeness, original-input context/visitor/static/checker/fallback/physical totality, coherent integration and public/private/compiler/MCP/full/crates/runtime/encoder/BOTH E2E identity-stage parity, production compiler/checker/linker/generated consumers and fresh COMPLETE comparison remain mandatory. Production LEGACY. Shared exceptional interfaces232/233 remain @kevaundray boundary.

Same live delivery3247835/exclusive shared-cache lease and held canonical1233457. Preserve completed validation, reconcile CURRENTmain and rerun required actual-head gates before dependent squash246→247. Target8substantive validated merges/day; no new worktree/MCP/heavy retry/gate restart/merge. Hashed full evidence/checklist: {prefix}-scratch.json.
'''
(docs/(prefix+'-scratch.md')).write_text(text);plan=root/'docs/plans/test-binary-alignment-recovery.md';plan.write_text(plan.read_text()+'\n\n'+text)
files=[]
for rec in mods.values():files.extend(Path(rec[k]) for k in ['source','object','log','check'])
for name in [prefix+'-combined-axioms',prefix+'-all-constants']:
 for ext in ['.lean','.log','.olean','.check.json']:files.append(Path('/tmp')/(name+ext))
for p in ['/tmp/'+prefix+'-batch.json','/tmp/stock-try-rule-inputs.json','/tmp/stock-try-reservation-check.py','/tmp/'+prefix+'-close.py','/tmp/'+prefix+'-make-audit.py','/tmp/'+prefix+'-restore.py','/tmp/'+prefix+'-status44-start.md','/tmp/'+prefix+'-status52.json','/tmp/'+prefix+'-status71.json','/tmp/'+prefix+'-task140.json','/tmp/StockTryContextErasure-failed-20261016T2142.lean','/tmp/stock-source-erase-main-diff.json']:
 if Path(p).exists():files.append(Path(p))
files.extend([docs/(prefix+'-scratch.json'),docs/(prefix+'-scratch.md'),docs/'stock-delivery-main-drift.json',plan])
archive=Path('/home/lee/.clifv-recovery')/(stamp+'-source-erase')/'checkpoint.tar.gz';archive.parent.mkdir(parents=True)
with tarfile.open(archive,'w:gz',compresslevel=1) as t:
 for p in files:t.add(p,arcname=str(p).lstrip('/'),recursive=False)
with tarfile.open(archive,'r:gz') as t:
 for p in files:assert t.extractfile(str(p).lstrip('/')).read()==p.read_bytes(),p
snapshot=Path('/tmp/stock-try-rule-inputs');size=sum(p.stat().st_size for p in snapshot.rglob('*') if p.is_file());shutil.rmtree(snapshot)
backup={'utc':now.isoformat(),'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(files),'all_members_byte_verified':True,'previous_remote_backup':json.loads((docs/'stock-try-critical-normal-backup.json').read_text())['remote'],'cleanup':{'duplicate_dependency_snapshot_removed':True,'bytes_reclaimed':size,'unique_sources_objects_logs_checks_audits_preserved':True,'one_shared_warm_cache_retained':True,'other_projects_touched':False,'free_bytes':shutil.disk_usage(root).free}}
(docs/(prefix+'-backup.json')).write_text(json.dumps(backup,indent=2)+'\n');Path('/tmp/'+prefix+'-archive-path').write_text(str(archive))
print(json.dumps({'counts':counts,'archive':str(archive),'cleanup':backup['cleanup'],'gate':progress},indent=2))
