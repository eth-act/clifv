import StockSourceErasure
import FV.Backend.Proof.StockSelectedFlow
namespace Backend.Stock.Proof.SourceUnreservedFlowDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open SourceErasureDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private theorem provenance (ctx : Ctx) (ii x : Nat)
    (h : Prov {ctx with tryRegs := ([],[])} ii x) : Prov ctx ii x := by
  induction h with
  | arg lookup clif member => exact .arg lookup clif member
  | dep h defined lookup clif member ih => exact .dep ih defined lookup clif member
/-- Arbitrary actual exception reservations do not introduce a reserved-output
alternative for successful statement roots. Outputs are fresh or source operands. -/
theorem stock_root_source_context_flow {f : Clif.Function} {ctx : Ctx}
    (mapped : MappedCtxInv f ctx) {ii : Nat} {info : IInfo} {inst : Clif.Inst}
    (hi : ctx.insts[ii]? = some info) (hc : info.clif = some inst)
    {fuel : Nat} {before after : State} {out : V} {trace finalTrace : Array RuleId}
    (run : (applyTerm program (Stock.sem ctx) {} fuel T.lower.ret T.lower.id [.inst ii]).run
      (before,trace) = .ok (some out,after,finalTrace)) :
    ∀ rss,out = .regsVec rss → info.results ≠ [] → ∀ rs ∈ rss,∀ o cls,rs = [.vreg o cls] →
      (before.base.nextVreg ≤ o ∧ o < after.base.nextVreg) ∨
      ∃ x,Prov ctx ii x ∧ ctx.valueReg? x = some (.vreg o cls) := by
  have same := stock_source_root_reservations_irrelevant ctx {} rfl fuel [.inst ii] before trace
  have erasedRun := same.symm.trans run
  intro rss output results rs member o cls singleton
  rcases MappedFlow.stock_root_mapped_context_flow (mapped.withTryRegs ([],[])) rfl hi hc erasedRun
    rss output results rs member o cls singleton with fresh | ⟨x,reached,register⟩
  · exact .inl fresh
  · exact .inr ⟨x,provenance ctx ii x reached,register⟩
/-- The actual selected terminator/reservation context reaches only ordinary
source operands or freshly allocated registers at a source statement root. -/
theorem stock_selected_root_source_flow {f : Clif.Function} {ctx : Ctx}
    (mapped : MappedCtxInv f ctx) {ti ii : Nat}
    (placeholder : ctx.insts[ti]? = some ⟨.op .unit,[],[],none⟩)
    (distinct : ii ≠ ti) (data : V) (reserved : List Reg × List Reg)
    {info : IInfo} {inst : Clif.Inst} (source : ctx.insts[ii]? = some info)
    (original : info.clif = some inst)
    {fuel : Nat} {before after : State} {out : V} {trace finalTrace : Array RuleId}
    (run : (applyTerm program (Stock.sem {Driver.termCtx ctx ti data with tryRegs := reserved})
      {} fuel T.lower.ret T.lower.id [.inst ii]).run (before,trace) = .ok (some out,after,finalTrace)) :
    ∀ rss,out = .regsVec rss → info.results ≠ [] → ∀ rs ∈ rss,∀ o cls,rs = [.vreg o cls] →
      (before.base.nextVreg ≤ o ∧ o < after.base.nextVreg) ∨
      ∃ x,Prov ctx ii x ∧ ctx.valueReg? x = some (.vreg o cls) := by
  have selected := (mapped.termCtx placeholder data).withTryRegs reserved
  have infoSelected : ({Driver.termCtx ctx ti data with tryRegs := reserved} : Ctx).insts[ii]? = some info := by
    change (Driver.termCtx ctx ti data).insts[ii]? = some info
    rw [termCtx_insts_ne distinct]
    exact source
  intro rss output results rs member o cls singleton
  rcases stock_root_source_context_flow selected infoSelected original run rss output results rs member o cls singleton with
    fresh | ⟨x,reached,register⟩
  · exact .inl fresh
  · exact .inr ⟨x,stock_selected_provenance_source mapped placeholder distinct data reserved reached,register⟩
theorem stock_selected_root_source_available {f : Clif.Function} {ctx : Ctx}
    {ranges : Array (Nat × Nat)} {initial : State}
    (build : Stock.buildCtx f = .ok (ctx, ranges, initial)) (scope : LowerScope f)
    (dominated : Dominated f) {ti ii bi j n : Nat}
    (placeholder : ctx.insts[ti]? = some ⟨.op .unit, [], [], none⟩)
    (distinct : ii ≠ ti) (data : V) (reserved : List Reg × List Reg)
    (available : n ∈ availOf f (availIn f ctx) bi j) (definition : ctx.defInst? n = some ii)
    {info : IInfo} {inst : Clif.Inst}
    (source : ctx.insts[ii]? = some info) (original : info.clif = some inst)
    {fuel : Nat} {before after : State} {out : V} {trace finalTrace : Array RuleId}
    (run : (applyTerm program (Stock.sem { Driver.termCtx ctx ti data with tryRegs := reserved })
      {} fuel T.lower.ret T.lower.id [.inst ii]).run (before, trace) =
        .ok (some out, (after, finalTrace))) :
    ∀ rss, out = .regsVec rss → info.results ≠ [] → ∀ rs ∈ rss, ∀ o cls,
      rs = [.vreg o cls] →
      (before.base.nextVreg ≤ o ∧ o < after.base.nextVreg) ∨
        (∃ x, x ∈ availOf f (availIn f ctx) bi j ∧ ctx.valueReg? x = some (.vreg o cls)) := by
  intro rss output results rs member o cls singleton
  rcases stock_selected_root_source_flow (buildCtx_mappedInv scope build) placeholder distinct data reserved
      source original run rss output results rs member o cls singleton with
      fresh | ⟨x, reached, register⟩
  · exact .inl fresh
  · exact .inr ⟨x, stock_available_provenance build dominated available definition reached, register⟩

end Backend.Stock.Proof.SourceUnreservedFlowDraft
