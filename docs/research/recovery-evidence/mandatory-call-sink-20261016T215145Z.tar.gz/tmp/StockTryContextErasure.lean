import FV.Backend.Proof.StockContext
namespace Backend.Stock.Proof.TryContextErasureDraft
open Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option maxRecDepth 20000
set_option maxHeartbeats 0
private def legacyCtorView (ctx : Ctx) (t : Term) (args : List V) (st : LState) : ExtResult (V × LState) :=
  let ok (v : V) : ExtResult (V × LState) := .ok (v, st)
  let optOk (o : Option V) : ExtResult (V × LState) := match o with
    | some v => .ok (v, st)
    | none => .fail
  match tyPred t.id, args with
  | some p, [.ty ty] => if p ty then ok (.ty ty) else .fail
  | _, _ =>
  match t.id, args with
  -- prelude.isle / isle_prelude.rs
  | TId.i64_sextend_imm64, [.ty ty, .int x] => ok (.int (sextFrom ty.bits x))
  | TId.ty_bits, [.ty ty] => ok (.int ty.bits)
  | TId.ty_bytes, [.ty ty] => ok (.int ty.bytes)
  -- `ty_mask` (isle_prelude.rs:366): `2^bits - 1`
  | TId.ty_mask, [.ty ty] => ok (.int (2 ^ ty.bits - 1))
  | TId.offset32_to_i32, [.int i] => ok (.int i)
  | TId.i32_to_offset32, [.int i] => ok (.int i)
  | TId.signed_cond_code, [cc] => match cc.intcc? with
    | some n => if [VIdx.IntCC.SignedGreaterThanOrEqual, VIdx.IntCC.SignedGreaterThan,
        VIdx.IntCC.SignedLessThanOrEqual, VIdx.IntCC.SignedLessThan].contains n then ok cc else .fail
    | none => .unmodeled "signed_cond_code"
  | TId.unsigned_cond_code, [cc] => match cc.intcc? with
    | some n => if [VIdx.IntCC.Equal, VIdx.IntCC.UnsignedGreaterThanOrEqual,
        VIdx.IntCC.UnsignedGreaterThan, VIdx.IntCC.UnsignedLessThanOrEqual,
        VIdx.IntCC.UnsignedLessThan, VIdx.IntCC.NotEqual].contains n then ok cc else .fail
    | none => .unmodeled "unsigned_cond_code"
  | TId.trap_code_division_by_zero, [] => ok (.op (.trapCode .intDivz))
  | TId.trap_code_integer_overflow, [] => ok (.op (.trapCode .intOvf))
  | TId.safe_divisor_from_imm64, [.ty ty, .int v] =>
    let minusOne : Nat := 2 ^ (ty.bytes * 8) - 1
    let bits := u64 v % 2 ^ (ty.bytes * 8)
    if bits == 0 || bits == minusOne then .fail else ok (.int bits)
  -- prelude_lower.isle / machinst/isle.rs
  | TId.value_reg, [.reg r] => ok (.regs [r])
  | TId.value_regs, [.reg a, .reg b] => ok (.regs [a, b])
  | TId.output_none, [] => ok (.regsVec [])
  | TId.output, [.regs rs] => ok (.regsVec [rs])
  | TId.output_vec, [.regsVec rss] => ok (.regsVec rss)
  | TId.temp_writable_reg, [.ty ty] => match ty.regClass? with
    | some cls => let (r, st) := st.fresh cls; .ok (.reg r, st)
    | none => .unmodeled s!"temp_writable_reg of {repr ty}"
  | TId.opportunistic_def, [_, _] => ok (.op .unit)
  | TId.put_in_reg, [.value n] => match ctx.valueReg? n with
    | some r => ok (.reg r)
    | none => .unmodeled s!"put_in_reg v{n}"
  | TId.put_in_regs, [.value n] => match ctx.valueReg? n with
    | some r => ok (.regs [r])
    | none => .unmodeled s!"put_in_regs v{n}"
  | TId.put_in_regs_vec, [.values vs] => match vs.mapM ctx.valueReg? with
    | some rs => ok (.regsVec (rs.map fun r => [r]))
    | none => .unmodeled "put_in_regs_vec"
  | TId.value_regs_get, [.regs rs, .int i] => match rs[i.toNat]? with
    | some r => ok (.reg r)
    | none => .unmodeled "value_regs_get index"
  | TId.jump_table_size, [.labels ls] => ok (.int ls.length)
  | TId.writable_reg_to_reg, [r] => ok r
  -- `invalid_reg` (machinst/isle.rs:107): `Reg::invalid_sentinel()`
  | TId.invalid_reg, [] => ok (.reg Reg.invalid)
  | TId.is_sinkable_inst, [_] => .fail
  | TId.emit, [i] => match MInst.ofV i with
    | some m => .ok (.op .unit, st.emit m)
    | none => .unmodeled s!"emit of {((i.variant?).map (·.2.1)).getD "?"}"
  | TId.box_external_name, [n] => ok n
  | TId.abi_sig, [s] => ok s
  | TId.abi_stackslot_addr, [rd, .op (.stackSlot s), .int off] =>
    match ctx.slotOff.lookup s with
    | some base =>
      ok (.data tyMInst VIdx.MInst.LoadAddr [rd, .data tyAMode VIdx.AMode.SlotOffset [.int (base + off)]])
    | none => .unmodeled s!"stack slot ss{s}"
  | TId.abi_stackslot_offset_into_slot_region, [.op (.stackSlot s), .int a, .int b] =>
    match ctx.slotOff.lookup s with
    | some base => ok (.int (base + a + b))
    | none => .unmodeled s!"stack slot ss{s}"
  | TId.gen_return, [.regsVec rss] =>
    match retRegs rss.length, rss.mapM (fun | [r] => some r | _ => none) with
    | some ps, some rs => .ok (.op .unit, st.emit (.rets (rs.zip ps)))
    | _, _ => .unmodeled "gen_return: more than 8 return values or multi-register values"
  | TId.gen_call_output, [.op (.sig s)] =>
    let (rs, st) := (sigRets s).foldl (init := (#[], st)) fun (acc, st) _ =>
      let (r, st) := st.fresh .int
      (acc.push [r], st)
    .ok (.regsVec rs.toList, st)
  | TId.gen_call_args, [.op (.sig s), .regsVec rss] =>
    match sigArgLocs s, rss.mapM (fun | [r] => some r | _ => none) with
    | .ok (locs, _), some rs =>
      let bytes := match sigArgs s with | .ok b => b | _ => []
      let (uses, st) := ((locs.zip rs).zip bytes).foldl (init := (#[], st))
        fun (acc, st) ((loc, r), b) => match loc with
          | .reg p => (acc.push (r, p), st)
          | .stack off => (acc, st.emit (.store (storeOpOfBytes b) r (.spOffset off) trustedFlags))
      .ok (.op (.callArgs uses.toList), st)
    | .error e, _ => .unmodeled s!"gen_call_args: {e}"
    | _, none => .unmodeled "gen_call_args: multi-register value"
  | TId.gen_call_rets, [.op (.sig _), .regsVec rss] =>
    match retRegs rss.length, rss.mapM (fun | [r] => some r | _ => none) with
    | some ps, some rs => ok (.op (.callRets (ps.zip rs)))
    | _, _ => .unmodeled "gen_call_rets: more than 8 return values"
  | TId.try_call_none, [] => ok (.op .tryCallNone)
  | TId.try_call_info, [.op (.exnTable s items), .labels ls] =>
    match tryInfoOf s items ls with
    | some ti => ok (.op (.tryCallInfo ti))
    | none => .unmodeled "try_call_info: label count"
  -- `gen_try_call_rets` (`Lower::gen_try_call_rets` → `gen_call_rets` with payloads): the
  -- return vregs in the return registers, then each payload register that is not also a
  -- return register (a payload in a return register shares the return's vreg, as
  -- `set_vreg_alias` makes it there)
  | TId.gen_try_call_rets, [.op (.sig s)] =>
    let (rets, pays) := ctx.tryRegs
    match retRegs (sigRets s).length with
    | some ps =>
      if ps.length != rets.length then .unmodeled "gen_try_call_rets: return count"
      else
        let extra := ((payloadRegs s.callConv).zip pays).filter fun (p, _) => !ps.contains p
        ok (.op (.callRets (ps.zip rets ++ extra)))
    | none => .unmodeled "gen_try_call_rets: more than 8 return values"
  | TId.gen_call_info, [.op (.sig s), .op (.extName n), .op (.callArgs us), .op (.callRets ds), _, _] =>
    match sigArgLocs s with
    | .ok (_, stack) =>
      .ok (.op (.callInfo ⟨.sym n, us, ds⟩), { st with outgoing := max st.outgoing stack })
    | .error e => .unmodeled s!"gen_call_info: {e}"
  | TId.gen_call_ind_info, [.op (.sig s), .reg r, .op (.callArgs us), .op (.callRets ds), _] =>
    match sigArgLocs s with
    | .ok (_, stack) =>
      .ok (.op (.callInfo ⟨.reg r, us, ds⟩), { st with outgoing := max st.outgoing stack })
    | .error e => .unmodeled s!"gen_call_ind_info: {e}"
  -- aarch64 inst.isle / lower.isle helpers (aarch64/lower/isle.rs)
  | TId.use_fp16, [] => ok (.bool false)
  | TId.is_pic, [] => ok (.bool true)
  | TId.move_wide_const_from_u64, [.ty ty, .int n] =>
    let n := if ty.bits < 64 then u64 n % 2 ^ ty.bits else u64 n
    optOk ((MoveWideConst.ofNat? n).map (.op ∘ .moveWideConst))
  | TId.move_wide_const_from_inverted_u64, [.ty ty, .int n] =>
    let n := 2 ^ 64 - 1 - u64 n
    let n := if ty.bits < 64 then n % 2 ^ ty.bits else n
    optOk ((MoveWideConst.ofNat? n).map (.op ∘ .moveWideConst))
  | TId.imm_logic_from_u64, [.ty ty, .int n] =>
    if ty == .int 32 || ty == .int 64 then
      optOk ((ImmLogic.ofNat? (u64 n) (.ofBits ty.bits)).map (.op ∘ .immLogic))
    else .fail
  | TId.imm_size_from_type, [.ty ty] =>
    if ty == .int 32 then ok (.int 32) else if ty == .int 64 then ok (.int 64) else .fail
  | TId.imm_logic_from_imm64, [.ty ty, .int n] =>
    let ty := if ty.bits < 32 then CTy.int 32 else ty
    if ty == .int 32 || ty == .int 64 then
      optOk ((ImmLogic.ofNat? (u64 n) (.ofBits ty.bits)).map (.op ∘ .immLogic))
    else .fail
  | TId.imm_shift_from_imm64, [.ty ty, .int n] =>
    let v := Nat.land (u64 n) (ty.bits - 1)
    if v < 64 then ok (.op (.immShift v)) else .fail
  | TId.imm_shift_from_u8, [.int n] => if n < 64 then ok (.op (.immShift n.toNat)) else .fail
  | TId.u8_into_uimm5, [.int n] => if n < 32 then ok (.op (.uimm5 n.toNat)) else .fail
  | TId.u8_into_imm12, [.int n] => optOk ((Imm12.ofNat? n.toNat).map (.op ∘ .imm12))
  | TId.u64_into_imm_logic, [.ty ty, .int n] =>
    if ty == .int 32 || ty == .int 64 then
      optOk ((ImmLogic.ofNat? (u64 n) (.ofBits ty.bits)).map (.op ∘ .immLogic))
    else .fail
  | TId.branch_target, [.label l] => ok (.label l)
  | TId.targets_jt_space, [.labels ls] => ok (.int (4 * (8 + ls.length)))
  | TId.lshl_from_imm64, [.ty ty, .int n] =>
    match shiftImm? (u64 n) with
    | some s => if ty.bits ≤ 255 then ok (.op (.shiftOpAndAmt ⟨.lsl, Nat.land s (ty.bits - 1)⟩))
      else .fail
    | none => .fail
  | TId.ashr_from_u64, [.ty ty, .int n] =>
    match shiftImm? n.toNat with
    | some s => if ty.bits ≤ 255 then ok (.op (.shiftOpAndAmt ⟨.asr, Nat.land s (ty.bits - 1)⟩))
      else .fail
    | none => .fail
  | TId.put_extended_in_reg, [.op (.extended x _)] => match ctx.valueReg? x with
    | some r => ok (.reg r)
    | none => .unmodeled "put_extended_in_reg"
  | TId.get_extended_op, [.op (.extended _ e)] => ok (.data tyExtendOp e.idx [])
  | TId.nzcv, [.bool n, .bool z, .bool c, .bool v] => ok (.op (.nzcv ⟨n, z, c, v⟩))
  | TId.cond_br_zero, [r, s] => ok (.data tyCondBrKind VIdx.CondBrKind.Zero [r, s])
  | TId.cond_br_not_zero, [r, s] => ok (.data tyCondBrKind VIdx.CondBrKind.NotZero [r, s])
  | TId.cond_br_cond, [c] => ok (.data tyCondBrKind VIdx.CondBrKind.Cond [c])
  | TId.zero_reg, [] => ok (.reg .xzr)
  | TId.writable_zero_reg, [] => ok (.reg .xzr)
  | TId.a64_extr_imm, [.ty ty, .op (.immShift s)] =>
    if ty == .int 32 then ok (.op (.shiftOpAndAmt ⟨.lsl, s⟩))
    else if ty == .int 64 then ok (.op (.shiftOpAndAmt ⟨.lsr, s⟩))
    else .fail
  | TId.load_constant_full, [.ty ty, ext, sz, .int v] =>
    match ext.enumOf? tyImmExtend, sz.size? with
    | some (e, _), some size =>
      let (r, st) := loadConstantFull ty.bits (e == VIdx.ImmExtend.Sign) size (u64 v) st
      .ok (.reg r, st)
    | _, _ => .unmodeled "load_constant_full"
  | TId.uimm12_scaled_from_i64, [.int v, .ty ty] =>
    optOk ((uimm12Scaled? v ty.bytes).map (.op ∘ .uimm12Scaled))
  | TId.uimm12_scaled_nonzero_from_i64, [.int v, .ty ty] =>
    if v == 0 then .fail else optOk ((uimm12Scaled? v ty.bytes).map (.op ∘ .uimm12Scaled))
  | TId.simm9_from_i64, [.int v] => optOk ((simm9? v).map (.op ∘ .simm9))
  | TId.cond_code, [cc] => match cc.intcc? >>= condOfIntCC with
    | some c => ok (.data tyCond c.idx [])
    | none => .unmodeled "cond_code"
  | TId.invert_cond, [c] => match c.cond? with
    | some c => ok (.data tyCond c.invert.idx [])
    | none => .unmodeled "invert_cond"
  | TId.shift_masked_imm, [.ty ty, .int n] => ok (.int (Nat.land (u64 n % 256) (ty.laneBits - 1)))
  | TId.shift_mask, [.ty ty] => optOk ((ImmLogic.ofNat? (ty.laneBits - 1) .size32).map (.op ∘ .immLogic))
  | TId.bfm_immr, [.ty ty, .int a, .int b] =>
    let w := ty.laneBits
    let a := Nat.land (u64 a % 256) (w - 1)
    let b := Nat.land (u64 b % 256) (w - 1)
    ok (.op (.uimm6 (if a ≤ b then b - a else w - (a - b))))
  | TId.bfm_imms, [.ty ty, .int a, .int _] =>
    let w := ty.laneBits
    let a := Nat.land (u64 a % 256) (w - 1)
    ok (.op (.uimm6 (w - 1 - a)))
  | TId.negate_imm_shift, [.ty ty, .op (.immShift s)] =>
    let size := ty.bits
    ok (.op (.immShift (Nat.land ((size + 256 - s) % 256) (size - 1))))
  | TId.rotr_mask, [.ty ty] => optOk ((ImmLogic.ofNat? (ty.bits - 1) .size32).map (.op ∘ .immLogic))
  | TId.rotr_opposite_amount, [.ty ty, .op (.immShift s)] =>
    let amount := Nat.land s (ty.bits - 1)
    let r := ty.bits - amount
    if r < 64 then ok (.op (.immShift r)) else .fail
  | TId.test_and_compare_bit_const, [.ty ty, .int n] =>
    let n := u64 n
    let ones := (List.range 64).filter (n.testBit ·)
    match ones with
    | [bit] => if bit < ty.bits then ok (.int bit) else .fail
    | _ => .fail
  -- numerics.isle (generated `isle_numerics.rs`)
  | TId.i32_checked_add, [.int a, .int b] =>
    let s := a + b
    if -(2 ^ 31 : Int) ≤ s ∧ s < 2 ^ 31 then ok (.int s) else .fail
  | TId.i64_checked_neg, [.int a] => if a == -(2 ^ 63 : Int) then .fail else ok (.int (-a))
  | TId.u64_eq, [.int a, .int b] => ok (.bool (a == b))
  | TId.u64_gt, [.int a, .int b] => ok (.bool (a > b))
  | TId.u64_wrapping_add, [.int a, .int b] => ok (.int (u64 (a + b)))
  | TId.u64_wrapping_sub, [.int a, .int b] => ok (.int (u64 (a - b)))
  | TId.u64_wrapping_shl, [.int a, .int b] => ok (.int (u64 (a * 2 ^ (b.toNat % 64))))
  | TId.u64_is_odd, [.int a] => ok (.bool (a % 2 == 1))
  | TId.u8_into_u32, [.int a] | TId.u8_into_u64, [.int a] | TId.u16_into_u64, [.int a]
  | TId.i32_into_i64, [.int a] | TId.u32_into_u64, [.int a] => ok (.int a)
  | TId.i64_cast_unsigned, [.int a] => ok (.int (u64 a))
  -- clif_lower.isle
  | TId.value_array_2, [.value a, .value b] => ok (.values [a, b])
  -- `pack_value_array_3` (isle_prelude.rs:948)
  | TId.value_array_3, [.value a, .value b, .value c] => ok (.values [a, b, c])
  | TId.block_array_2, [.blockCalls a, .blockCalls b] => ok (.blockCalls (a ++ b))
  | _, args => .unmodeled s!"constructor {t.name} ({args.length} args)"


theorem stock_legacy_ctor_reservations_irrelevant (ctx : Ctx) (term : Term) (args : List V) (st : LState)
    (excluded : term.id ≠ TId.gen_try_call_rets) :
    Backend.externCtor {ctx with tryRegs := ([],[])} term args st = Backend.externCtor ctx term args st := by
  change legacyCtorView _ _ _ _ = legacyCtorView _ _ _ _
  unfold legacyCtorView
  split
  · rfl
  · split <;> first | (exact False.elim (excluded (by assumption))) | rfl
/-- Nonempty reservation lists coexist with an actual ordinary output constructor. -/
theorem stock_legacy_ctor_erasure_witness :
    ∃ ctx : Ctx,ctx.tryRegs ≠ ([],[]) ∧ T.output.id ≠ TId.gen_try_call_rets ∧
      Backend.externCtor ctx T.output [.regs [.vreg 193 .int]] sinkState.base =
        .ok (.regsVec [[.vreg 193 .int]],sinkState.base) ∧
      Backend.externCtor {ctx with tryRegs := ([],[])} T.output [.regs [.vreg 193 .int]] sinkState.base =
        .ok (.regsVec [[.vreg 193 .int]],sinkState.base) := by
  refine ⟨{sinkCtx with tryRegs := ([.vreg 194 .int],[.vreg 195 .int])},by decide,by decide,rfl,rfl⟩
end Backend.Stock.Proof.TryContextErasureDraft
