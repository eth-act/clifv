import StockTryContextErasure
import StockSourceNoTryClosure
namespace Backend.Stock.Proof.SourceErasureDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open TryContextErasureDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private theorem extract (ctx : Ctx) (term : Term) (v : V) (st : LState) :
    Backend.externExtract {ctx with tryRegs := ([],[])} term v st = Backend.externExtract ctx term v st := by
  unfold Backend.externExtract
  rfl
private theorem stock_ctor (ctx : Ctx) (term : Term) (args : List V) (st : State)
    (excluded : term.id ≠ TId.gen_try_call_rets) :
    Stock.externCtor {ctx with tryRegs := ([],[])} term args st = Stock.externCtor ctx term args st := by
  have delegate (s : LState) := stock_legacy_ctor_reservations_irrelevant ctx term args s excluded
  simp only [Stock.externCtor,Stock.source,delegate]
  split <;> first | (exact False.elim (excluded (by assumption))) | rfl
private theorem project_ctor_id (r : ExtResult (V × State)) : projectCtor id r = r := by
  cases r with
  | ok pair => cases pair; rfl
  | fail => rfl
  | unmodeled err => rfl
private theorem project_result_id {α : Type} (r : Except Err (α × State × Array RuleId)) :
    projectResult id r = r := by
  cases r with
  | error err => rfl
  | ok pair => cases pair with | mk a pair => cases pair; rfl
/-- The actual statement-root interpreter retains exactly its values, state,
trace and errors after erasing exception reservations. The closed actual rule
scope is derived internally; no caller constructor/alias/run certificate. -/
theorem stock_source_root_reservations_irrelevant (ctx : Ctx) (cfg : Config)
    (overlap : cfg.checkOverlap = false) (fuel : Nat) (args : List V)
    (st : State) (trace : Array RuleId) :
    (applyTerm program (Stock.sem ctx) cfg fuel T.lower.ret T.lower.id args).run (st,trace) =
      (applyTerm program (Stock.sem {ctx with tryRegs := ([],[])}) cfg fuel T.lower.ret T.lower.id args).run (st,trace) := by
  obtain ⟨allowed,root,closed⟩ : ∃ allowed : TermId → Prop,allowed TId.lower ∧
      ∀ t,allowed t → ∀ term,termOf program t = .ok term → term.id ≠ TId.gen_try_call_rets ∧
      ∀ r ∈ program.rulesOf t, RuleScoped allowed r :=
    ⟨_,SourceNoTryClosureDraft.stock_source_no_try_constructor_closure⟩
  have scope : ProjectionScope program (Stock.sem {ctx with tryRegs := ([],[])}) id (Stock.externCtor ctx) allowed := by
    constructor
    · intro t term member lookup vs state
      rw [project_ctor_id]
      exact (stock_ctor ctx term vs state (closed t member term lookup).1).symm
    · intro t term member lookup flags ex kind r recorded
      exact (closed t member term lookup).2 r recorded
  have same := (evaluation_scoped_restate program (Stock.sem {ctx with tryRegs := ([],[])}) cfg overlap id
    (Stock.externCtor ctx) (fun t v s => Backend.externExtract ctx t v s.base) allowed scope
    (fun t v s => (extract ctx t v s.base).symm) fuel).term T.lower.ret T.lower.id args root st trace
  rw [project_result_id] at same
  exact same

end Backend.Stock.Proof.SourceErasureDraft
