import StockSourceUnreservedFlow
import StockSourceErasureFixture
namespace Backend.Stock.Proof.SourceErasureWitnessDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open SourceUnreservedFlowDraft SourceErasureDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private def selectedFunction : Clif.Function := {
  name := "mapped_dfg"
  sig := { params := [⟨.i64, .none, .normal⟩], returns := [⟨.i8, .none, .normal⟩] }
  blocks := [{ id := 5, params := [(7, .i64)], body := [⟨[2], .iconst .i8 9⟩], term := .ret [2] }] }
private def selectedBuilt : Ctx × Array (Nat × Nat) × State :=
  (Stock.buildCtx selectedFunction).toOption.getD (sinkCtx, #[], sinkState)
private def selectedReserved : List Reg × List Reg :=
  ([.vreg 194 .int], [.vreg 195 .int, .vreg 196 .int])
private def selectedData : V := (Backend.termData (.ret [2])).toOption.getD (.op .unit)
private def selectedCtx : Ctx :=
  { Driver.termCtx selectedBuilt.1 1 selectedData with tryRegs := selectedReserved }
private def selectedInput : State :=
  { sinkState with base := { sinkState.base with nextVreg := 197 } }
private theorem selected_build : Stock.buildCtx selectedFunction = .ok selectedBuilt := rfl
private theorem selected_scope : LowerScope selectedFunction := buildCtx_mappedInv_witness.1
private theorem selected_info : selectedBuilt.1.insts[0]? = some selectedBuilt.1.insts[0]! := rfl
private theorem selected_original : selectedBuilt.1.insts[0]!.clif = some (.iconst .i8 9) := rfl
private theorem selected_placeholder : selectedBuilt.1.insts[1]? = some ⟨.op .unit, [], [], none⟩ := rfl

private def selectedOriginalBuilt : Ctx × Array (Nat × Nat) × LState :=
  (Backend.buildCtx selectedFunction).toOption.getD (sinkCtx, #[], sinkState.base)
private theorem selected_original_build : Backend.buildCtx selectedFunction = .ok selectedOriginalBuilt := rfl
private theorem selected_original_defs :
    selectedOriginalBuilt.1.valDef = #[none, none, some 0, none, none, none, none, none] := rfl
private theorem selected_original_args (x : Nat) : defArgs selectedOriginalBuilt.1 x = [] := by
  rcases x with _ | (_ | (_ | (_ | (_ | (_ | (_ | (_ | x))))))) <;>
    simp [defArgs, Ctx.defInst?, selected_original_defs]
  rfl

private theorem selected_dominated : Dominated selectedFunction := by
  constructor
  · decide +kernel
  · intro ctx ranges st build bi B block
    cases bi with
    | zero =>
      simp [selectedFunction] at block
      subst B
      constructor
      · intro j stmt lookup y member
        cases j with
        | zero => simp at lookup; subst stmt; simp [Backend.Proof.Driver.instArgs] at member
        | succ j => simp at lookup
      · intro y member
        change y ∈ [2] at member
        simp only [List.mem_singleton] at member
        subst y
        change 2 ∈ ([7] ++ (availIn selectedFunction ctx).getD 0 [] ++ [2]).filter
          (fun x => decide (x ∉ ([] : List Nat)))
        simp
    | succ bi => simp [selectedFunction] at block
  · intro ctx ranges st build tl x available notLocal y member
    rw [selected_original_build] at build
    cases build
    change y ∈ defArgs selectedOriginalBuilt.1 x at member
    rw [selected_original_args] at member
    cases member

private theorem selected_available :
    (2 : Nat) ∈ availOf selectedFunction (availIn selectedFunction selectedBuilt.1) 0 1 := by
  change 2 ∈ ([7] ++ (availIn selectedFunction selectedBuilt.1).getD 0 [] ++ [2]).filter
    (fun x => decide (x ∉ ([] : List Nat)))
  simp


/-- Complete compiler/prepare/checked fallback/physical source9 pipeline,
with actual changed-terminator source-root execution and nonempty reservations.
The SAME run survives erasure and has only fresh/source-available provenance. -/
theorem stock_complete_source_erasure_flow_witness :
    ∃ (out : SourceErasureFixtureDraft.Output) (next : State) (trace : Array RuleId),
      Stock.lower selectedFunction = .ok out.result ∧ LowerScope selectedFunction ∧ Dominated selectedFunction ∧ ArityOk selectedFunction ∧
      prepareAt out.result.code out.result.edgeArgs = .ok out.prepared ∧
      out.rf = spillAllocAt out.prepared.code out.prepared.edges ∧
      checkAllocAt out.prepared.code out.prepared.edges out.rf = .ok () ∧
      lowerRFunc out.prepared.code out.rf = .ok out.af ∧
      Stock.buildCtx selectedFunction = .ok selectedBuilt ∧ selectedCtx.tryRegs.2 ≠ [] ∧
      selectedCtx.insts[1]? ≠ selectedBuilt.1.insts[1]? ∧
      (applyTerm program (Stock.sem selectedCtx) {} 1000000 T.lower.ret T.lower.id [.inst 0]).run
        (selectedInput,#[]) = .ok (some (.regsVec [[.vreg 197 .int]]),next,trace.push 582) ∧
      (applyTerm program (Stock.sem {selectedCtx with tryRegs := ([],[])}) {} 1000000 T.lower.ret T.lower.id [.inst 0]).run
        (selectedInput,#[]) = .ok (some (.regsVec [[.vreg 197 .int]]),next,trace.push 582) ∧
      ((selectedInput.base.nextVreg ≤ 197 ∧ 197 < next.base.nextVreg) ∨
        ∃ x,Prov selectedCtx 0 x ∧ selectedCtx.valueReg? x = some (.vreg 197 .int)) ∧
      ((selectedInput.base.nextVreg ≤ 197 ∧ 197 < next.base.nextVreg) ∨
        ∃ x,Prov selectedBuilt.1 0 x ∧ selectedBuilt.1.valueReg? x = some (.vreg 197 .int)) ∧
      ((selectedInput.base.nextVreg ≤ 197 ∧ 197 < next.base.nextVreg) ∨
        ∃ x,x ∈ availOf selectedFunction (availIn selectedFunction selectedBuilt.1) 0 1 ∧
          selectedBuilt.1.valueReg? x = some (.vreg 197 .int)) ∧
      Clif.runWith {} {funcs := [selectedFunction]} selectedFunction.name [⟨.i64,7⟩] Clif.Mem.empty 3 =
        .returned [⟨.i8,9⟩] Clif.Mem.empty := by
  obtain ⟨out⟩ := SourceErasureFixtureDraft.stock_source_erasure_fixture
  obtain ⟨next,trace,mapping,changed,nonempty,run⟩ := stock_statement_selectedConstant_context_witness
  have erased := (stock_source_root_reservations_irrelevant selectedCtx {} rfl 1000000 [.inst 0] selectedInput #[]).symm.trans run
  have mapped := buildCtx_mappedInv selected_scope selected_build
  have selected := (mapped.termCtx selected_placeholder selectedData).withTryRegs selectedReserved
  have actual : selectedCtx.insts[0]? = some selectedBuilt.1.insts[0]! := rfl
  have root := stock_root_source_context_flow selected actual selected_original run _ rfl (by decide) _ (List.mem_singleton_self _) _ _ rfl
  have source := stock_selected_root_source_flow mapped selected_placeholder (by decide) selectedData selectedReserved
    selected_info selected_original run _ rfl (by decide) _ (List.mem_singleton_self _) _ _ rfl
  have available := stock_selected_root_source_available selected_build selected_scope selected_dominated selected_placeholder (by decide)
    selectedData selectedReserved selected_available rfl selected_info selected_original run _ rfl (by decide) _ (List.mem_singleton_self _) _ _ rfl
  exact ⟨out,next,trace,out.lowered,out.scope,selected_dominated,out.arity,out.prepare,out.fallback,out.accepted,out.physical,
    selected_build,nonempty,changed,run,erased,root,source,available,rfl⟩
end Backend.Stock.Proof.SourceErasureWitnessDraft
