import StockTryNormalDefined
namespace Backend.Stock.Proof.TryNormalSourceEntryDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Driver.Fix TryNormalDefinedDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
/-- The original successful TryCall result binding followed by its actual
normal successor entry preserves source definedness at the destination.
The normal edge is derived from executable tryNormal, not caller edge metadata. -/
theorem source_defined_try_normal_entry {f : Clif.Function} (ssa : (valueDefs f).Nodup) (ctx : Ctx)
    {bi : Nat} {b : Clif.Block} (block : f.blocks[bi]? = some b)
    {fr fr' : Clif.Frame} (func : fr.func = f) {et : Clif.ExnTable} (kind : IsTryWith b.term et)
    (defined : SourceDefinedAt f ctx bi b.body.length fr) {count : Nat} {values : List Clif.Val} {regs : Clif.Regs}
    (bound : fr.regs.setMany ((List.range count).map (f.freshValue + ·)) values = some regs)
    {bc : Clif.BlockCall} (normal : Clif.tryNormal et f.freshValue = .ok bc)
    {tl : Nat} (index : blockIdx? f bc.block = some tl)
    (entered : Clif.enterBlock {fr with regs,body := [],term := .jump bc} bc = .ok fr') :
    SourceDefinedAt f ctx tl 0 fr' := by
  have preserved := (source_defined_try_result_bind block defined bound).1
  have pending : SourceDefinedAt f ctx bi b.body.length {fr with regs,body := [],term := .jump bc} := preserved
  have edge : bc.block ∈ succIds b.term := by
    have blockEq : bc.block = et.normal.block := by rw [tryNormal_ok normal]
    rw [blockEq]
    rcases kind with ⟨fn,args,term⟩ | ⟨callee,args,term⟩ <;> rw [term] <;> simp [succIds,Clif.ExnTable.dests]
  exact source_defined_enterBlock (fr := {fr with regs,body := [],term := .jump bc}) ssa ctx block func edge index pending entered
end Backend.Stock.Proof.TryNormalSourceEntryDraft
