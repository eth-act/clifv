from pathlib import Path
import json,hashlib,re,datetime,tarfile,shutil
root=Path('/home/lee/clifv/.worktrees/driver-proof-resume');docs=root/'docs/research'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
now=datetime.datetime.now(datetime.timezone.utc);stamp=now.strftime('%Y%m%dT%H%M%SZ')
batch=json.loads(Path('/tmp/stock-try-normal-frame-batch.json').read_text());old=json.loads((docs/'stock-try-got-rename-scratch.json').read_text())
log=Path('/tmp/stock-try-normal-frame-combined-axioms.log').read_text()
sets={m.group(1):sorted(x.strip() for x in m.group(2).split(',') if x.strip()) for m in re.finditer(r"'([^']+)' depends on axioms:\s*\[([^]]*)\]",log)}
for m in re.finditer(r"'([^']+)' does not depend on any axioms",log):sets[m.group(1)]=[]
for n,a in old['normal_audit']['sets'].items():assert sorted(a)==sets[n],n
assert len(sets)==len(old['normal_audit']['sets'])+len(batch['public_roots'])+len(batch['models'])
allowed={'propext','Classical.choice','Quot.sound'}
for n in batch['public_roots']+batch['models']:assert set(sets[n])<=allowed,n
constants=[json.loads(line.split('DELIVERY_CONSTANT ',1)[1]) for line in Path('/tmp/stock-try-normal-frame-all-constants.log').read_text().splitlines() if line.startswith('DELIVERY_CONSTANT ')]
assert constants
for n,a in constants:assert set(a)<=allowed,n
mods={}
for m in batch['modules']:
 p=Path('/tmp')/m;check=json.loads(p.with_suffix('.check.json').read_text());assert check['actual_exit']==0
 rec={}
 for key,ext in [('source','.lean'),('object','.olean'),('log','.log'),('check','.check.json')]:
  f=p.with_suffix(ext);rec[key]=str(f);rec[key+'_sha256']=sha(f)
 for k in ['source','object','log']:assert rec[k+'_sha256']==check[k+'_sha256']
 assert not re.search(r'\b(sorry|admit|axiom|trace_state|native_decide)\b',p.with_suffix('.lean').read_text()),m
 mods[m]=rec
for audit in ['stock-try-normal-frame-combined-axioms','stock-try-normal-frame-all-constants']:
 p=Path('/tmp')/audit;check=json.loads(p.with_suffix('.check.json').read_text());assert check['actual_exit']==0
 for k,ext in [('source','.lean'),('object','.olean'),('log','.log')]:assert sha(p.with_suffix(ext))==check[k+'_sha256']
prior={}
for name in ['source-execution-x','try-source','try-context','try-rule','try-rets','try-reservation','try-outgoing','try-values','try-emitted','try-machine','try-got','try-indirect','try-rename','try-resolved','try-gap','try-got-rename']:
 d=json.loads((docs/f'stock-{name}-scratch.json').read_text())
 for m,rec in d['modules'].items():
  for k in ['source','object','log']:assert sha(rec[k])==rec[k+'_sha256'],(m,k)
  prior[m]=rec
freeze=json.loads(Path('/tmp/stock-coherent-build-inputs.json').read_text())
for group in ['source_sha256','validation_script_sha256']:
 for p,h in freeze[group].items():assert sha(root/p)==h,p
progress=json.loads(Path('/tmp/stock-pr246-gates-progress.json').read_text());progress.pop('completed_phases',None)
remaining=old['remaining_checklist']
remaining.append({'requirement':'Actual source definedness through TryCall synthetic result binding and normal successor entry','state':'Proved: every originally available source ID is below original Function.freshValue; actual setMany preserves every such source slot and definedness for arbitrary successful counts, including zero. Successful executable tryNormal and actual enterBlock yield definedness at actual successor. Direct and true-indirect actual two-step call/jump consumers use original external-program guards; complete near/GOT/indirect compiler/prepare/forced fallback/checker/physical witnesses carry live9 and returned17, with full original source run17. Machine available-value/reserved-write frame and actual TryArg.ret outgoing vectors/parameter copies remain open.'})
counts={'modules':len(mods),'public_roots':len(batch['public_roots']),'models':len(batch['models']),'combined_roots_models':len(sets),'previous_preserved':len(old['normal_audit']['sets']),'all_new_module_constants':len(constants),'previous_modules_hashes_preserved':len(prior)}
receipt={'utc':now.isoformat(),'goal':'Original full #140 ACTIVE/INCOMPLETE; production LEGACY','scope':'Scratch-only additive Stock proofs, not coherent integration or merge-ready','delivery_target':'roughly eight substantive validated squash merges/day; prioritize landing coherent backlog, remote backups and cleanup; drafts do not count','modules':mods,'public_roots':batch['public_roots'],'models':batch['models'],'counts':counts,'normal_audit':{'path':'/tmp/stock-try-normal-frame-combined-axioms.log','sha256':sha('/tmp/stock-try-normal-frame-combined-axioms.log'),'sets':sets},'all_constant_audit':{'path':'/tmp/stock-try-normal-frame-all-constants.log','sha256':sha('/tmp/stock-try-normal-frame-all-constants.log'),'all_standard_only':True,'count':len(constants)},'previous_modules_hashes_preserved':list(prior),'canonical2246_source_and_script_freeze_preserved':True,'kernel_resources':'All new modules and both audits actual exit0/object verified at8GiB through memcap; one heavy delivery worker retained','MCP':'No new calls; bundled audit deferred until coherent integration','active_exact_PR246_validation':progress,'remaining_checklist':remaining}
(docs/'stock-try-normal-frame-scratch.json').write_text(json.dumps(receipt,indent=2)+'\n')
text=f'''Source TryCall normal result binding and successor definedness — {now.isoformat()}

Four scratch modules/six public roots pass actual8GiB kernel checks. The {len(sets)}-root/model audit preserves all577prior exact axiom sets. All{len(constants)}new-module constants, including private fresh-bound/pending-jump/fixture helpers, use only standard axioms. All{len(prior)}previous scratch source/object/log hashes and frozen2246canonical sources plus49validation scripts remain unchanged. Prior turn PROGRESS: actual final-renamed GOT normal execution/world/results plus complete9arg16byte witness,577audit/93constants, verified be50eb7 remote backup and2.8GBcleanup.

Original must-availability places every source ID below Function.freshValue, independently of Stock register numbering. Actual executable TryCall setMany writes synthetic source result IDs at freshValue+i, so EVERY originally available source register remains exactly unchanged and source definedness is retained, for arbitrary successful counts (including zero). Actual successful tryNormal determines the real source normal destination; successful pending jump/enterBlock then derives definedness at that original successor. Direct and true-indirect consumers invert the SAME actual executable call and next jump under existing original external-program guards; no result-binding, availability, source-ID bound, chosen successor or accepted-program certificate is added.

Complete near/GOT/true-indirect compiler→prepareAt→forced checkedfallback→checker→physical fixtures inhabit original LowerScope/Dominated/Arity, actual source call/jump, destination availability/definedness, live source value9 and returned17 bound into actual destination parameters, plus full original Clif.runWith returning17. The original source frames include only actual pre-call source registers (callee4096 only for true-indirect). These are source-side proofs; they DO NOT establish machine clobber freedom. Existing actual final-renamed machine branch proofs for all three forms remain unchanged.

The ordinary branch vector/edge-value theorem only covers plain .val arguments. TryCall normal outgoing vectors also carry .ret arguments through actual preallocated reservations. Remaining connection must derive the actual branchArgs slot (instBlock.findIdx plus body length) from original context/traversal metadata, identify those reservations with the SAME actual call helper, prove the actual final-resolved outgoing .val/.ret vector, then compose real parameter copies. Do not substitute an ordinary branch theorem or introduce caller layout/slot/alias certificates. Available source machine-frame/reserved-write noninterference remains OPEN; source setMany preservation above is separate.

The existing Opt.SimWin source has the fresh-value bounds, but its compiled import is absent under the active delivery freeze. The small pure structural bound proof is temporarily reused locally as private helpers (standard-only), with no cold heavy dependency build; replace with the published reusable import at coherent integration once available. Only the temporary missing-object wait was stopped; delivery/gate controllers were not restarted. No FV/FVTest/validation source changed.

ALL original reserved machine frames/normal edge continuation/block/whole-driver simulation AND completeness, shared payload endpoints/exception machine execution, full zero-return/sret/x8/width/handler witness matrix, uncovered families/effects/sinking, original-input context/visitor/static/checker/fallback/physical totality, coherent scratch integration/MCP/public/private/compiler audits, full/crates/runtime/encoder/BOTH E2E identity-stage parity, actual production compiler/checker/linker/generated consumers and FRESH COMPLETE comparison remain mandatory. Full#140 ACTIVE/INCOMPLETE; production LEGACY. S10 shared exceptional interfaces stay with @kevaundray #232/#233.

Delivery246/247 remain drafts; same exclusive cache worker3247835 live, canonical1233457 deliberately held. Preserve old-head receipts, reconcile current main and rerun affected kernel/trust and all full gates on updated actual heads before dependent squash merges. Target roughly8substantive validated merges/day, semantic grouping, remote backups and cleanup. No merge/new worktree/new MCP/new heavy retry/gate restart this batch.

Hashed evidence/full remaining checklist: stock-try-normal-frame-scratch.json.
'''
(docs/'stock-try-normal-frame-scratch.md').write_text(text)
plan=root/'docs/plans/test-binary-alignment-recovery.md';plan.write_text(plan.read_text()+'\n\n'+text)
files=[]
for rec in mods.values():files.extend(Path(rec[k]) for k in ['source','object','log','check'])
for name in ['stock-try-normal-frame-combined-axioms','stock-try-normal-frame-all-constants']:
 for ext in ['.lean','.log','.olean','.check.json']:files.append(Path('/tmp')/(name+ext))
files.extend(Path(p) for p in ['/tmp/stock-try-normal-frame-batch.json','/tmp/stock-try-rule-inputs.json','/tmp/stock-try-reservation-check.py','/tmp/stock-try-normal-frame-close.py','/tmp/stock-try-normal-frame-make-audit.py','/tmp/stock-try-normal-frame-extra-inputs.py','/tmp/stock-try-normal-frame-status44.json','/tmp/stock-try-normal-frame-status52.json','/tmp/stock-try-normal-frame-status71.json','/tmp/stock-try-normal-frame-task140.json'])
files.extend([docs/'stock-try-normal-frame-scratch.json',docs/'stock-try-normal-frame-scratch.md',docs/'stock-delivery-main-drift.json',plan])
archive=Path('/home/lee/.clifv-recovery')/(stamp+'-try-normal-frame')/'checkpoint.tar.gz';archive.parent.mkdir(parents=True)
with tarfile.open(archive,'w:gz',compresslevel=1) as t:
 for p in files:t.add(p,arcname=str(p).lstrip('/'),recursive=False)
with tarfile.open(archive,'r:gz') as t:
 for p in files:assert t.extractfile(str(p).lstrip('/')).read()==p.read_bytes(),p
snapshot=Path('/tmp/stock-try-rule-inputs');size=sum(p.stat().st_size for p in snapshot.rglob('*') if p.is_file());shutil.rmtree(snapshot)
backup={'utc':now.isoformat(),'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(files),'all_members_byte_verified':True,'previous_remote_backup':json.loads((docs/'stock-try-got-rename-backup.json').read_text())['remote'],'cleanup':{'duplicate_dependency_snapshot_removed':True,'bytes_reclaimed':size,'unique_sources_objects_logs_checks_audits_preserved':True,'one_shared_warm_cache_retained':True,'other_projects_touched':False,'free_bytes':shutil.disk_usage(root).free}}
(docs/'stock-try-normal-frame-backup.json').write_text(json.dumps(backup,indent=2)+'\n');Path('/tmp/stock-try-normal-frame-archive-path').write_text(str(archive))
print(json.dumps({'counts':counts,'archive':str(archive),'cleanup':backup['cleanup'],'gate':progress},indent=2))
