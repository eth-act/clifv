import StockTryNormalSourceSteps
import StockTryEmittedWitness
namespace Backend.Stock.Proof.TryNormalSourceWitnessDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Backend.Proof.Driver.Fix Isle Isle.Interp Isle.Aarch64
open TryEmittedWitnessDraft (Kind)
open TryNormalDefinedDraft TryNormalSourceEntryDraft TryNormalSourceStepsDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private def function : Kind → Clif.Function
  | .near => TryNearFixtureDraft.function false
  | .got => SpillEntryFixture.function false
  | .indirect => SpillEntryFixture.function true
private def entry (k : Kind) := (function k).blocks[0]!
private def table : Clif.ExnTable := {
  sig := 0,normal := ⟨1,[.ret 0,.val 0]⟩,items := [.tag 7 ⟨2,[.exn 0,.exn 1,.val 0]⟩] }
private structure Fixture (k : Kind) where
  result : Result
  prepared : EdgeVCode
  rf : RFunc
  af : AFunc
  lowered : Stock.lower (function k) = .ok result
  scope : LowerScope (function k)
  dominated : Dominated (function k)
  arity : ArityOk (function k)
  prepare : prepareAt result.code result.edgeArgs = .ok prepared
  fallback : rf = spillAllocAt prepared.code prepared.edges
  accepted : checkAllocAt prepared.code prepared.edges rf = .ok ()
  physical : lowerRFunc prepared.code rf = .ok af
private theorem fixture (k : Kind) : Nonempty (Fixture k) := by
  cases k with
  | near =>
    obtain ⟨out⟩ := TryNearFixtureDraft.stock_near_try_fixture
    exact ⟨⟨out.result,out.prepared,out.rf,out.af,out.lowered,out.scope,out.dominated,out.arity,
      out.prepare,out.fallback,out.accepted,out.physical⟩⟩
  | got =>
    obtain ⟨out⟩ := SpillEntryFixture.try_fixture false
    exact ⟨⟨out.result,out.prepared,out.rf,out.af,out.lowered,out.scope,out.dominated,out.arity,
      out.prepare,out.fallback,out.accepted,out.physical⟩⟩
  | indirect =>
    obtain ⟨out⟩ := SpillEntryFixture.try_fixture true
    exact ⟨⟨out.result,out.prepared,out.rf,out.af,out.lowered,out.scope,out.dominated,out.arity,
      out.prepare,out.fallback,out.accepted,out.physical⟩⟩
private theorem order (k : Kind) : blockOrder (function k) = .ok {
    nodes := #[.original 0,.original 1,.original 2],successors := #[#[2,1],#[],#[]]} := by cases k <;> cbv


private def environment (k : Kind) : Clif.Env := {
  extern := fun _ => some (fun _ cm => .returned [⟨.i64,17⟩] cm),names := ["callee"],sigOf := fun _ => some (function k).sig }
private def memory : Clif.Mem := {Clif.Mem.empty with symbols := fun name => if name = "callee" then some 4096 else none}
private def initial (k : Kind) : Clif.State := {
  frame := {
    func := function k
    regs := fun x => if x = 0 then some ⟨.i64,9⟩ else if k = .indirect ∧ x = 1 then some ⟨.i64,4096⟩ else none
    slots := []
    body := []
    term := (entry k).term }
  mem := memory
  callers := [] }
private def pending (k : Kind) : Clif.State := tryNext (initial k)
  (fun x => if x = (function k).freshValue then some ⟨.i64,17⟩ else (initial k).frame.regs x)
  ⟨1,[(function k).freshValue,0]⟩ memory
private def finalState (k : Kind) : Clif.State :=
  match Clif.step (environment k) {funcs := []} (pending k) with
  | .next s => s
  | _ => initial k
private theorem call (k : Kind) :
    Clif.stepTerm (environment k) {funcs := []} (initial k) (entry k).term = .next (pending k) := by
  cases k <;> rfl
private theorem jump (k : Kind) :
    Clif.step (environment k) {funcs := []} (pending k) = .next (finalState k) := by
  cases k <;> rfl
private theorem defined (k : Kind) (ctx : Ctx) : SourceDefinedAt (function k) ctx 0 (entry k).body.length (initial k).frame := by
  have block : (function k).blocks[0]? = some (entry k) := by cases k <;> rfl
  have bodyChoices : ∀ stm ∈ (entry k).body,∀ x ∈ stm.results,x = 0 ∨ (k = .indirect ∧ x = 1) := by
    cases k <;> simp [entry,function,TryNearFixtureDraft.function,SpillEntryFixture.function]
  intro x available
  obtain ⟨present,_⟩ := (mem_av block).mp available
  rcases present with parameter | incoming | ⟨j,stm,earlier,statement,member⟩
  · have absent : (entry k).params = [] := by cases k <;> rfl
    simp only [absent,List.map_nil,List.not_mem_nil] at parameter
  · have impossible := (inFix_fixOk (f := function k) (ctx := ctx) (gn := id)).cand 0 x incoming
    omega
  · rcases bodyChoices stm (List.mem_of_getElem? statement) x member with rfl | ⟨rfl,rfl⟩
    · exact ⟨⟨.i64,9⟩,rfl⟩
    · exact ⟨⟨.i64,4096⟩,rfl⟩
/-- Complete near/GOT/true-indirect compiler/prepare/checked fallback/physical
pipelines inhabit actual executable normal calls and successor jumps with live
source value9 and returned17, preserving destination source definedness. -/
theorem stock_complete_try_normal_source_entry_witness (k : Kind) :
    ∃ (out : Fixture k) (tl : Nat) (target : Clif.Block),
      LowerScope (function k) ∧ Dominated (function k) ∧ ArityOk (function k) ∧
      Stock.lower (function k) = .ok out.result ∧ prepareAt out.result.code out.result.edgeArgs = .ok out.prepared ∧
      out.rf = spillAllocAt out.prepared.code out.prepared.edges ∧
      checkAllocAt out.prepared.code out.prepared.edges out.rf = .ok () ∧ lowerRFunc out.prepared.code out.rf = .ok out.af ∧
      SourceDefinedAt (function k) out.result.ctx 0 (entry k).body.length (initial k).frame ∧
      Clif.stepTerm (environment k) {funcs := []} (initial k) (entry k).term = .next (pending k) ∧
      Clif.step (environment k) {funcs := []} (pending k) = .next (finalState k) ∧
      (function k).blocks[tl]? = some target ∧ (finalState k).frame.func = function k ∧
      (finalState k).frame.body = target.body ∧ (finalState k).frame.term = target.term ∧
      SourceDefinedAt (function k) out.result.ctx tl 0 (finalState k).frame ∧
      (finalState k).frame.get 2 = .ok ⟨.i64,17⟩ ∧ (finalState k).frame.get 3 = .ok ⟨.i64,9⟩ ∧
      Clif.runWith (environment k) {funcs := [function k]} (function k).name [] memory 6 = .returned [⟨.i64,17⟩] memory := by
  obtain ⟨out⟩ := fixture k
  have block : (function k).blocks[0]? = some (entry k) := by cases k <;> rfl
  have before := defined k out.result.ctx
  have holds : ∃ tl target,(function k).blocks[tl]? = some target ∧ (finalState k).frame.func = function k ∧
      (finalState k).frame.body = target.body ∧ (finalState k).frame.term = target.term ∧
      SourceDefinedAt (function k) out.result.ctx tl 0 (finalState k).frame ∧
      (finalState k).callers = (initial k).callers := by
    cases k with
    | near =>
      exact source_defined_direct_try_normal_steps out.dominated.ssa out.result.ctx block rfl rfl before
        (by intro ext found; rfl) (call .near) (jump .near)
    | got =>
      exact source_defined_direct_try_normal_steps out.dominated.ssa out.result.ctx block rfl rfl before
        (by intro ext found; rfl) (call .got) (jump .got)
    | indirect =>
      exact source_defined_indirect_try_normal_steps out.dominated.ssa out.result.ctx block rfl rfl before
        (by intro cv lookup g member; cases member) (call .indirect) (jump .indirect)
  obtain ⟨tl,target,atBlock,func,body,term,after,callers⟩ := holds
  refine ⟨out,tl,target,out.scope,out.dominated,out.arity,out.lowered,out.prepare,out.fallback,out.accepted,
    out.physical,before,call k,jump k,atBlock,func,body,term,after,?_,?_,?_⟩
  · cases k <;> rfl
  · cases k <;> rfl
  · cases k <;> rfl
end Backend.Stock.Proof.TryNormalSourceWitnessDraft
