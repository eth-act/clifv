import StockTryNormalSourceEntry
namespace Backend.Stock.Proof.TryNormalSourceStepsDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Driver.Fix TryNormalDefinedDraft TryNormalSourceEntryDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private theorem index_found {f : Clif.Function} {id : Clif.BlockId} {b : Clif.Block}
    (found : f.block? id = some b) : ∃ tl,blockIdx? f id = some tl := by
  cases index : blockIdx? f id with
  | some tl => exact ⟨tl,rfl⟩
  | none =>
    have absent : f.block? id = none := by
      simp only [Clif.Function.block?,List.find?_eq_none,Bool.not_eq_true]
      exact List.findIdx?_eq_none_iff.mp index
    rw [absent] at found
    cases found
private theorem normal_enter {f : Clif.Function} (ssa : (valueDefs f).Nodup) (ctx : Ctx)
    {bi : Nat} {b : Clif.Block} (block : f.blocks[bi]? = some b)
    {env : Clif.Env} {p : Clif.Program} {s next : Clif.State} (func : s.frame.func = f)
    {et : Clif.ExnTable} (kind : IsTryWith b.term et)
    (defined : SourceDefinedAt f ctx bi b.body.length s.frame)
    {count : Nat} {values : List Clif.Val} {regs : Clif.Regs} {cm : Clif.Mem} {bc : Clif.BlockCall}
    (bound : s.frame.regs.setMany ((List.range count).map (f.freshValue + ·)) values = some regs)
    (normal : Clif.tryNormal et f.freshValue = .ok bc)
    (jump : Clif.step env p (tryNext s regs bc cm) = .next next) :
    ∃ tl target,f.blocks[tl]? = some target ∧ next.frame.func = f ∧ next.frame.body = target.body ∧
      next.frame.term = target.term ∧ SourceDefinedAt f ctx tl 0 next.frame ∧ next.mem = cm ∧ next.callers = s.callers := by
  have jumpTerm : Clif.step env p (tryNext s regs bc cm) = Clif.stepTerm env p (tryNext s regs bc cm) (.jump bc) :=
    Clif.step_term env p _ rfl
  rw [jumpTerm] at jump
  obtain ⟨j,actual,fr,selected,destination,entered,nextEq⟩ := stepTerm_branch (by simp [dests]) jump
  have same : bc = actual := by
    cases j with
    | zero => simpa only [dests,List.getElem?_cons_zero,Option.some.injEq] using destination
    | succ j => simp [dests] at destination
  subst actual
  obtain ⟨target,vals,registers,found,read,types,set,frameEq⟩ := enterBlock_spec entered
  rw [show (tryNext s regs bc cm).frame.func = f from func] at found
  obtain ⟨tl,index⟩ := index_found found
  have holds := source_defined_try_normal_entry ssa ctx block func kind defined bound normal index entered
  refine ⟨tl,target,blockIdx_block index found,?_,?_,?_,?_,?_,?_⟩
  · rw [nextEq,frameEq]; exact func
  · rw [nextEq,frameEq]
  · rw [nextEq,frameEq]
  · simpa only [nextEq] using holds
  · rw [nextEq]; rfl
  · rw [nextEq]; rfl
/-- The SAME successful executable direct TryCall and pending normal jump
establish source definedness at its real successor, including source slots
preserved across the synthetic result binding. External-program guards are the
original direct-call semantic boundary. -/
theorem source_defined_direct_try_normal_steps {f : Clif.Function} (ssa : (valueDefs f).Nodup) (ctx : Ctx)
    {bi : Nat} {b : Clif.Block} (block : f.blocks[bi]? = some b)
    {env : Clif.Env} {p : Clif.Program} {s pending next : Clif.State} (func : s.frame.func = f)
    {fn : Nat} {args : List Nat} {et : Clif.ExnTable} (kind : b.term = .tryCall fn args et)
    (defined : SourceDefinedAt f ctx bi b.body.length s.frame)
    (external : ∀ ext,s.frame.func.extern? fn = some ext → p.func? ext.name = none)
    (call : Clif.stepTerm env p s (.tryCall fn args et) = .next pending)
    (jump : Clif.step env p pending = .next next) :
    ∃ tl target,f.blocks[tl]? = some target ∧ next.frame.func = f ∧ next.frame.body = target.body ∧
      next.frame.term = target.term ∧ SourceDefinedAt f ctx tl 0 next.frame ∧ next.callers = s.callers := by
  obtain ⟨ext,bc,values,cm,regs,found,normal,outcome,bound,pendingEq⟩ := (stepTry_spec external).2 pending call
  rw [func] at normal bound
  rw [pendingEq] at jump
  obtain ⟨tl,target,block',func',body',term',defined',mem',callers⟩ :=
    normal_enter ssa ctx block func (.inl ⟨fn,args,kind⟩) defined bound normal jump
  exact ⟨tl,target,block',func',body',term',defined',callers⟩
/-- The corresponding true-indirect normal return and jump preserve source
availability/definedness under the unchanged original indirect semantic guard. -/
theorem source_defined_indirect_try_normal_steps {f : Clif.Function} (ssa : (valueDefs f).Nodup) (ctx : Ctx)
    {bi : Nat} {b : Clif.Block} (block : f.blocks[bi]? = some b)
    {env : Clif.Env} {p : Clif.Program} {s pending next : Clif.State} (func : s.frame.func = f)
    {callee : Nat} {args : List Nat} {et : Clif.ExnTable} (kind : b.term = .tryCallIndirect callee args et)
    (defined : SourceDefinedAt f ctx bi b.body.length s.frame)
    (external : ∀ cv,s.frame.get callee = .ok cv → ∀ g ∈ p.funcs,s.mem.symbols g.name ≠ some cv.toNat)
    (call : Clif.stepTerm env p s (.tryCallIndirect callee args et) = .next pending)
    (jump : Clif.step env p pending = .next next) :
    ∃ tl target,f.blocks[tl]? = some target ∧ next.frame.func = f ∧ next.frame.body = target.body ∧
      next.frame.term = target.term ∧ SourceDefinedAt f ctx tl 0 next.frame ∧ next.callers = s.callers := by
  obtain ⟨sig,bc,values,cm,regs,found,normal,outcome,bound,pendingEq⟩ := (stepTryInd_spec external).2 pending call
  rw [func] at normal bound
  rw [pendingEq] at jump
  obtain ⟨tl,target,block',func',body',term',defined',mem',callers⟩ :=
    normal_enter ssa ctx block func (.inr ⟨callee,args,kind⟩) defined bound normal jump
  exact ⟨tl,target,block',func',body',term',defined',callers⟩
end Backend.Stock.Proof.TryNormalSourceStepsDraft
