import FV.Backend.Proof.StockSourceEdges
import FV.Backend.Proof.LowerSim
namespace Backend.Stock.Proof.TryNormalDefinedDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Driver.Fix
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
open Clif
private theorem lt_foldl_of_mem {α : Type} (g : Nat → α → Nat) (hg : ∀ m a, m ≤ g m a) {x : Nat} {a : α}
    (hx : ∀ m, x < g m a) : ∀ (l : List α), a ∈ l → ∀ m, x < l.foldl g m
  | [], h, _ => by cases h
  | b :: l, h, m => by
    simp only [List.foldl_cons]
    rcases List.mem_cons.1 h with rfl | h
    · exact Nat.lt_of_lt_of_le (hx m) (le_foldl g hg l _)
    · exact lt_foldl_of_mem g hg hx l h _
where
  le_foldl (g : Nat → α → Nat) (hg : ∀ m a, m ≤ g m a) : ∀ (l : List α) m, m ≤ l.foldl g m
    | [], _ => Nat.le_refl _
    | b :: l, m => Nat.le_trans (hg m b) (le_foldl g hg l _)

private theorem le_foldl' {α : Type} (g : Nat → α → Nat) (hg : ∀ m a, m ≤ g m a) :
    ∀ (l : List α) m, m ≤ l.foldl g m :=
  lt_foldl_of_mem.le_foldl g hg

/-- Block parameters and statement results are below the fresh value. -/
private theorem lt_freshValue {f : Function} {b : Block} (hb : b ∈ f.blocks) :
    (∀ p ∈ b.params, p.1 < f.freshValue) ∧ ∀ st ∈ b.body, ∀ r ∈ st.results, r < f.freshValue := by
  have hres : ∀ (st : Stmt) m, m ≤ st.results.foldl (fun m r => max m (r + 1)) m :=
    fun st => le_foldl' _ (fun m r => Nat.le_max_left _ _) _
  have hbody : ∀ m, m ≤ b.body.foldl (fun m st => st.results.foldl (fun m r => max m (r + 1)) m) m :=
    le_foldl' _ (fun m st => hres st m) _
  have hgb : ∀ m (b : Block), m ≤ (fun m (b : Block) =>
      let m := b.params.foldl (fun m p => max m (p.1 + 1)) m
      b.body.foldl (fun m st => st.results.foldl (fun m r => max m (r + 1)) m) m) m b := by
    intro m b
    exact Nat.le_trans (le_foldl' _ (fun m p => Nat.le_max_left _ _) _ _)
      (le_foldl' _ (fun m st => hres st m) _ _)
  refine ⟨fun p hp => ?_, fun st hst r hr => ?_⟩
  · refine lt_foldl_of_mem _ hgb (fun m => ?_) f.blocks hb 0
    refine Nat.lt_of_lt_of_le ?_ (le_foldl' _ (fun m st => hres st m) _ _)
    exact lt_foldl_of_mem (fun m (p : ValueId × Ty) => max m (p.1 + 1))
      (fun m p => Nat.le_max_left _ _)
      (fun m => Nat.lt_of_lt_of_le (Nat.lt_succ_self _) (Nat.le_max_right _ _)) _ hp m
  · refine lt_foldl_of_mem _ hgb (fun m => ?_) f.blocks hb 0
    refine lt_foldl_of_mem _ (fun m st => hres st m) (fun m => ?_) _ hst _
    exact lt_foldl_of_mem (fun m (r : ValueId) => max m (r + 1)) (fun m r => Nat.le_max_left _ _)
      (fun m => Nat.lt_of_lt_of_le (Nat.lt_succ_self _) (Nat.le_max_right _ _)) _ hr m


private theorem available_source {f : Clif.Function} {ctx : Ctx} {bi j x : Nat} {b : Clif.Block}
    (block : f.blocks[bi]? = some b) (available : x ∈ availOf f (availIn f ctx) bi j) : x ∈ valueDefs f := by
  obtain ⟨present,_⟩ := (mem_av block).mp available
  rcases present with parameter | incoming | ⟨k,stm,earlier,statement,member⟩
  · exact mem_valueDefs_par block parameter
  · exact (inFix_fixOk (f := f) (ctx := ctx) (gn := id)).cand bi x incoming |>.2.2.2.1
  · exact mem_valueDefs_res block statement member
/-- Original must-availability excludes the synthetic result IDs used by the
executable TryCall semantics. No new numerical input bound is needed. -/
theorem source_available_below_try_fresh {f : Clif.Function} {ctx : Ctx} {bi j x : Nat} {b : Clif.Block}
    (block : f.blocks[bi]? = some b) (available : x ∈ availOf f (availIn f ctx) bi j) : x < f.freshValue := by
  have member := available_source block available
  simp only [valueDefs,List.mem_flatMap,List.mem_append,List.mem_map] at member
  obtain ⟨B,inBlocks,parameter | ⟨stm,inBody,inResults⟩⟩ := member
  · obtain ⟨p,inParams,rfl⟩ := parameter
    exact (lt_freshValue inBlocks).1 p inParams
  · exact (lt_freshValue inBlocks).2 stm inBody x inResults
/-- The actual source result binding preserves EVERY original available
source register and source definedness. This is separate from machine clobber
freedom and works for arbitrary successful result counts, including zero. -/
theorem source_defined_try_result_bind {f : Clif.Function} {ctx : Ctx} {bi j : Nat} {b : Clif.Block}
    (block : f.blocks[bi]? = some b) {fr : Clif.Frame}
    (defined : SourceDefinedAt f ctx bi j fr) {count : Nat} {values : List Clif.Val} {regs : Clif.Regs}
    (bound : fr.regs.setMany ((List.range count).map (f.freshValue + ·)) values = some regs) :
    SourceDefinedAt f ctx bi j {fr with regs} ∧
      ∀ x,x ∈ availOf f (availIn f ctx) bi j → regs x = fr.regs x := by
  have preserved : ∀ x,x ∈ availOf f (availIn f ctx) bi j → regs x = fr.regs x := by
    intro x available
    apply setMany_other bound
    intro member
    obtain ⟨i,inside,same⟩ := List.mem_map.mp member
    have small := source_available_below_try_fresh block available
    have lower : f.freshValue ≤ x := by rw [← same]; exact Nat.le_add_right _ _
    exact (Nat.not_le_of_gt small) lower
  refine ⟨?_,preserved⟩
  intro x available
  obtain ⟨v,lookup⟩ := defined x available
  exact ⟨v,by change regs x = some v; rw [preserved x available]; exact lookup⟩
end Backend.Stock.Proof.TryNormalDefinedDraft
