from pathlib import Path
import json,time,subprocess as sp,os
view=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');state=Path('/tmp/stock-arithmetic-prototype-state.json')
def report(s,**kw):state.write_text(json.dumps(dict(state=s,pid=os.getpid(),**kw),indent=2)+'\n')
report('waiting_for_scheduler_budget',author_pid=3086906)
while True:
 d=json.loads(Path('/tmp/stock-pure-proof-author-gates/progress.json').read_text());assert d['pid']==3086906
 assert d['state']!='failed',d.get('error')
 if d.get('phase')!='all-modules':break
 assert Path('/proc/3086906').exists(),'author missing without terminal result'
 time.sleep(2)
report('checking_next_arithmetic_helpers')
env=dict(os.environ,FV_MEMCAP='8G',FV_LAKE_CACHE='/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache',LEAN_NUM_THREADS='2',OMP_NUM_THREADS='2');env['PATH']='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:'+env['PATH']
with open('/tmp/stock-arithmetic-prototype.log','w') as f:r=sp.run(['scripts/memcap.sh','lake','env','lean','--root=/tmp','/tmp/StockArithmeticBodyPrototype.lean'],cwd=view,env=env,stdout=f,stderr=sp.STDOUT)
report('kernel_check_passed' if r.returncode==0 else 'failed',rc=r.returncode)
raise SystemExit(r.returncode)
