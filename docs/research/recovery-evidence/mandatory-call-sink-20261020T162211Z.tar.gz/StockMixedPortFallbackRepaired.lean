import FV.Backend.Lowering.StockArithmetic
import FV.Backend.StockArithmeticCheck
import FV.Backend.Proof.StockArithmeticBodyRefines
import FV.Backend.Proof.StockArithmeticEntryRefines
import FV.E2E.LinkWorld
import FV.E2E.StockArithmeticStage
import FV.E2E.DeadCleanupRegLevelX
import FV.E2E.DeadCleanupGot
import FV.E2E.CompiledProduction
import FV.E2E.StockArithmeticWorldX
import FV.Backend.ABIReadOnly
import FV.E2E.ABIReadOnlyMachine
import FV.Backend.Proof.IselCmpRun
import FV.E2E.StockArithmeticNI
import FV.Backend.Proof.SpillCtlPipe
import FV.E2E.LinkArm
import FV.E2E.PreparedPipeline
import FV.E2E.ProductionStackBound
import FV.Link.ProductionImageWith
import FV.Link.Placed
import FV.E2E.LinkGood
import FV.E2E.ProductionCheck
import FV.E2E.ProductionChecksWith
import FV.E2E.ExecWords
import FV.E2E.CodeMap
import FV.E2E.ExecFrame
import FV.E2E.PairLines
import FV.Link.Exe
import FV.Link.ProductionImageWithProof
import FV.Link.ExeSource
import FV.Backend.LinearScan
import FV.Backend.Lowering.StockD0
import FV.Link.Ld.Spec
import FV.Clif.Print

namespace Backend.Stock.Mixed
set_option autoImplicit false

abbrev abiEligible := Arithmetic.abiEligible

def bodyEligible (stm : Clif.Stmt) : Bool :=
  match stm.inst with
  | .binary op ty _ _ => (op == .iadd || op == .isub) && (ty == .i32 || ty == .i64)
  | .select ty _ _ _ => ty == .i32 || ty == .i64
  | _ => false

def eligible (f : Clif.Function) : Bool :=
  match f.blocks with
  | [b] => b.body.all bodyEligible &&
      (match b.term with | .ret _ => true | _ => false) &&
      f.sig.params.all abiEligible && f.sig.returns.all abiEligible
  | _ => false

/-- Previously shipped arithmetic classes retain their exact selector. -/
def activationEligible (f : Clif.Function) : Bool :=
  eligible f && !Arithmetic.eligible f

def lowerCandidate (f : Clif.Function) : Except String VCode :=
  if !activationEligible f then Arithmetic.lowerCandidate f
  else do
    let result ← Stock.lower f
    if result.edgeArgs.all (fun row => row.all (·.isEmpty)) then pure result.code
    else throw "Stock mixed candidate has nonempty edge arguments"


end Backend.Stock.Mixed

namespace Backend.Stock.Mixed
open Backend.Proof.Driver
set_option autoImplicit false

def sourceOk (f : Clif.Function) : Bool :=
  eligible f && lowerScopeB f && dominatedB f && sigAbiOk f.sig

/-- Only the new actual-Stock branch; the production union retains its previous
legacy/arithmetic alternatives and transactional fallbacks. -/
def check (f : Clif.Function) (vc : VCode) : Bool :=
  sourceOk f && match Stock.lower f with
  | .error _ => false
  | .ok result => decide (result.code = vc) && result.edgeArgs.all (fun row => row.all (·.isEmpty))


end Backend.Stock.Mixed

/-! Original-source simulation for complete straight-line select/add/sub bodies. -/
namespace Backend.Stock.Proof.MixedBody
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 8192
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm

/-- A syntactic family, with no execution or register-map certificate. -/
def Family (inst : Clif.Inst) : Prop :=
  (∃ subtract : Bool, ∃ ty x y,
    inst = .binary (if subtract then .isub else .iadd) ty x y) ∨
  (∃ ty c x y, inst = .select ty c x y)

private theorem select_result {f : Clif.Function} {ctx : Ctx} (inv : MappedCtxInv f ctx)
    {i : Nat} {info : IInfo} {ty : Clif.Ty} {c x y : Nat}
    (source : ctx.insts[i]? = some info)
    (clif : info.clif = some (.select ty c x y)) :
    ∃ z, info.results = [z] := by
  obtain ⟨tys,result,typed,arity⟩ := inv.resTys i info _ source clif
  have result' : tys = [ty] := by
    simpa [Clif.Inst.resultTypes] using result.symm
  rw [result'] at arity
  cases values : info.results with
  | nil => simp [values] at arity
  | cons z rest =>
    cases rest with
    | nil => exact ⟨z,rfl⟩
    | cons a tail => simp [values] at arity

private theorem scans_execute {exec : Nat → State → Except String Scan}
    {indices : List Nat} {input : State} {output : BlockScan}
    (cert : ScansSpec exec indices input output) :
    ∀ record ∈ output.records, exec record.inst record.input = .ok record.output := by
  induction cert with
  | nil input => simp
  | cons head rest ih =>
    intro record member
    rcases List.mem_cons.mp member with rfl | member
    · exact head
    · exact ih record member

/-- Derive actual emitted/omitted select and arithmetic record coverage from
original source syntax and successful lowering, retaining unused/dead operations. -/
theorem actual_mixed_families {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f)
    {b : Clif.Block} (blocks : f.blocks = [b])
    (family : ∀ stm ∈ b.body, Family stm.inst)
    {event : BlockScanEvent} (events : event ∈ result.blockScans.toList) :
    ∃ term body, SourceBodySplit f event b term body ∧
      ∀ record ∈ body.records, SelectAddSubOrOmittedRecord f event.ctx event.block record := by
  have quiet : ∀ stm ∈ b.body, colored stm.inst = false := by
    intro stm member
    rcases family stm member with ⟨subtract,ty,x,y,shape⟩ | ⟨ty,c,x,y,shape⟩
    · rw [shape]; cases subtract <;> rfl
    · rw [shape]; rfl
  obtain ⟨term,body,split,decisions⟩ := stock_lower_pure_body_decisions run scope blocks quiet events
  refine ⟨term,body,split,?_⟩
  intro record member
  obtain ⟨j,stm,statement,current⟩ := split.positions record member
  obtain ⟨step,recorded,decision⟩ := decisions record member
  rcases decision with omitted | emitted
  · exact Or.inl ⟨j,b,stm,split.block,statement,current,step,recorded,Or.inl omitted⟩
  · obtain ⟨info,source,clif,results⟩ :=
      ArithmeticBody.body_source_info run events split statement current
    have inv := (stock_lower_record_context run scope events).1
    obtain ⟨emission,emissionRun,scan⟩ := stock_emitted_scan
      (scans_execute split.scanned record member) recorded emitted
    have atInst : event.ctx.insts[record.inst]! = info := by
      simp only [Array.getElem!_eq_getD,Array.getD_eq_getD_getElem?,source,Option.getD_some]
    rcases family stm (List.mem_of_getElem? statement) with
      ⟨subtract,ty,x,y,shape⟩ | ⟨ty,c,x,y,shape⟩
    · have clif' : info.clif = some (.binary (if subtract then .isub else .iadd) ty x y) := by
        rw [clif,shape]
      obtain ⟨z,one⟩ := ArithmeticBody.arithmetic_result inv subtract source clif'
      obtain ⟨r,mapped⟩ := ArithmeticBody.emission_result_mapped emissionRun
        (by rw [atInst]; exact one)
      obtain ⟨a,rfl⟩ := inv.valueReg z r mapped
      exact Or.inr ⟨j,b,stm,split.block,statement,current,step,recorded,emitted,
        subtract,info,ty,x,y,z,a,source,clif',one,results.symm.trans one,mapped⟩
    · have clif' : info.clif = some (.select ty c x y) := by rw [clif,shape]
      obtain ⟨z,one⟩ := select_result inv source clif'
      obtain ⟨r,mapped⟩ := ArithmeticBody.emission_result_mapped emissionRun
        (by rw [atInst]; exact one)
      obtain ⟨a,rfl⟩ := inv.valueReg z r mapped
      exact Or.inl ⟨j,b,stm,split.block,statement,current,step,recorded,Or.inr
        ⟨emitted,info,ty,c,x,y,z,a,source,clif',one,results.symm.trans one,mapped⟩⟩

/-- Complete mixed ordinary-body simulation with record-family and map facts
derived internally, preserving the original source and related-world boundary. -/
theorem actual_mixed_body_refines {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    {b : Clif.Block} (blocks : f.blocks = [b])
    (family : ∀ stm ∈ b.body, Family stm.inst)
    {event : BlockScanEvent} (events : event ∈ result.blockScans.toList)
    {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem} (refines : Refines F isem)
    {MR : MemRelT} (stable : MRStable F MR) {env : Clif.Env} {cp : Clif.Program} :
    ∃ term body, SourceBodySplit f event b term body ∧
      ∀ s s', SourceSteps (IndexedSourceInst env cp f event.ctx event.block)
        ((List.range b.body.length).map (blockStart f event.block + ·)) s s' →
        ∀ ρ w, GuardedScanRel f result event.ctx event.block MR event.output.state s ρ w → ∃ ρ' w',
          seqRun isem (body.code.toList.map (·.mapRegs
            (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size + 1)))) ρ w =
            some (.fall ρ' w') ∧
          GuardedScanRel f result event.ctx event.block MR term.output.state s' ρ' w' := by
  obtain ⟨term,body,split,families⟩ := actual_mixed_families run scope blocks family events
  refine ⟨term,body,split,?_⟩
  intro s s' source ρ w held
  apply stock_lower_select_addsub_omitted_body_fall_refines run scope dominated events
    split.scanned split.retained families refines stable s s'
  · simpa only [sourceBodyIndices,List.reverse_reverse] using source
  · simpa only [split.state] using held


private theorem step_of_family {env : Clif.Env} {cp : Clif.Program}
    {s : Clif.State} {stm : Clif.Stmt} {rest : List Clif.Stmt}
    (remaining : s.frame.body = stm :: rest) (family : Family stm.inst) :
    Clif.step env cp s = Clif.StepResult.ofRes (Clif.evalInst s.frame s.mem stm.inst)
      (fun (vs,cm) => Clif.continueWith s rest stm.results vs cm) := by
  rcases family with ⟨subtract,ty,x,y,shape⟩ | ⟨ty,c,x,y,shape⟩
  all_goals unfold Clif.step; simp only [remaining,shape]

private theorem outcome_of_family {env : Clif.Env} {cp : Clif.Program}
    {fr : Clif.Frame} {cm : Clif.Mem} {inst : Clif.Inst} (family : Family inst) :
    instOutcome env cp fr cm inst = Clif.evalInst fr cm inst := by
  rcases family with ⟨subtract,ty,x,y,shape⟩ | ⟨ty,c,x,y,shape⟩
  all_goals rw [shape]; rfl

/-- The original executable source step supplies the mixed-family indexed step. -/
theorem actual_mixed_source_step {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) {event : BlockScanEvent}
    (events : event ∈ result.blockScans.toList) {b : Clif.Block} {term : ScanRecord} {body : BlockScan}
    (split : SourceBodySplit f event b term body) {record : ScanRecord} {j : Nat} {stm : Clif.Stmt}
    (statement : b.body[j]? = some stm) (current : record.inst = blockStart f event.block + j)
    (family : Family stm.inst)
    {env : Clif.Env} {cp : Clif.Program} {s t : Clif.State} {rest : List Clif.Stmt}
    (remaining : s.frame.body = stm :: rest) (next : Clif.step env cp s = .next t) :
    IndexedSourceInst env cp f event.ctx event.block record.inst
      (j,s.frame,s.mem) (j+1,t.frame,t.mem) := by
  obtain ⟨info,source,clif,results⟩ := ArithmeticBody.body_source_info run events split statement current
  have remaining' : s.frame.body = ⟨info.results,stm.inst⟩ :: rest := by
    rw [remaining,results]
  rw [step_of_family remaining family] at next
  cases evaluated : Clif.evalInst s.frame s.mem stm.inst with
  | trap code => simp only [evaluated,Clif.StepResult.ofRes] at next; cases next
  | stuck message => simp only [evaluated,Clif.StepResult.ofRes] at next; cases next
  | ok value =>
    obtain ⟨vals,mem⟩ := value
    simp only [evaluated,Clif.StepResult.ofRes] at next
    unfold Clif.continueWith at next
    cases written : s.frame.regs.setMany stm.results vals with
    | none => simp only [written] at next; cases next
    | some regs =>
      simp only [written] at next
      cases next
      refine ⟨current,rfl,info,stm.inst,vals,regs,rest,source,clif,remaining',?_,?_,rfl⟩
      · rw [outcome_of_family family]; exact evaluated
      · rw [results]; exact written

/-- Frame components untouched by the arithmetic source body. -/
def SourceFrameEq (s t : Clif.State) : Prop :=
  t.callers = s.callers ∧ t.frame.func = s.frame.func ∧
    t.frame.slots = s.frame.slots ∧ t.frame.term = s.frame.term

private theorem SourceFrameEq.trans {s t u : Clif.State}
    (first : SourceFrameEq s t) (second : SourceFrameEq t u) : SourceFrameEq s u :=
  ⟨second.1.trans first.1,second.2.1.trans first.2.1,
    second.2.2.1.trans first.2.2.1,second.2.2.2.trans first.2.2.2⟩

private theorem mixed_next_of_returned_frame {env : Clif.Env} {cp : Clif.Program}
    {fuel : Nat} {s : Clif.State} {stm : Clif.Stmt} {rest : List Clif.Stmt}
    (remaining : s.frame.body = stm :: rest) (family : Family stm.inst)
    {vals : List Clif.Val} {mem : Clif.Mem}
    (returned : Clif.runLoop env cp (fuel+1) s = .returned vals mem) :
    ∃ t, Clif.step env cp s = .next t ∧ t.frame.body = rest ∧
      Clif.runLoop env cp fuel t = .returned vals mem ∧ SourceFrameEq s t := by
  have step : Clif.step env cp s =
      Clif.StepResult.ofRes (Clif.evalInst s.frame s.mem stm.inst)
        (fun (vs,cm) => Clif.continueWith s rest stm.results vs cm) := by
    exact step_of_family remaining family
  rw [Clif.runLoop_succ,step] at returned
  cases evaluated : Clif.evalInst s.frame s.mem stm.inst with
  | trap code => simp only [evaluated,Clif.StepResult.ofRes] at returned; cases returned
  | stuck message => simp only [evaluated,Clif.StepResult.ofRes] at returned; cases returned
  | ok value =>
    obtain ⟨vs,cm⟩ := value
    simp only [evaluated,Clif.StepResult.ofRes] at returned
    unfold Clif.continueWith at returned
    cases written : s.frame.regs.setMany stm.results vs with
    | none => simp only [written] at returned; cases returned
    | some regs =>
      simp only [written] at returned
      refine ⟨{s with frame := {s.frame with regs,body := rest},mem := cm},?_,rfl,returned,rfl,rfl,rfl,rfl⟩
      rw [step,evaluated]
      simp only [Clif.StepResult.ofRes,Clif.continueWith,written]

/-- The actual reference run supplies every ordinary arithmetic source step,
including the residual fuel and the exact state at the terminator. -/
theorem actual_mixed_source_execution_frame {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) {event : BlockScanEvent}
    (events : event ∈ result.blockScans.toList) {b : Clif.Block} {term : ScanRecord} {body : BlockScan}
    (split : SourceBodySplit f event b term body)
    (family : ∀ stm ∈ b.body, Family stm.inst)
    {env : Clif.Env} {cp : Clif.Program} {fuel j : Nat} {s : Clif.State}
    (bound : j ≤ b.body.length) (remaining : s.frame.body = b.body.drop j)
    {vals : List Clif.Val} {mem : Clif.Mem}
    (returned : Clif.runLoop env cp fuel s = .returned vals mem) :
    ∃ t left, left + (b.body.length-j) = fuel ∧
      Clif.runLoop env cp left t = .returned vals mem ∧ t.frame.body = [] ∧
      SourceSteps (IndexedSourceInst env cp f event.ctx event.block)
        (List.range' (blockStart f event.block+j) (b.body.length-j))
        (j,s.frame,s.mem) (b.body.length,t.frame,t.mem) ∧ SourceFrameEq s t := by
  induction fuel generalizing j s with
  | zero => cases returned
  | succ fuel ih =>
    by_cases done : j = b.body.length
    · subst j
      refine ⟨s,fuel+1,by omega,returned,?_,?_,rfl,rfl,rfl,rfl⟩
      · simpa using remaining
      · simp only [Nat.sub_self,List.range'_zero]
        exact .nil _
    · have inside : j < b.body.length := by omega
      let stm := b.body[j]
      have statement : b.body[j]? = some stm := List.getElem?_eq_getElem inside
      have head : s.frame.body = stm :: b.body.drop (j+1) := by
        rw [remaining,List.drop_eq_getElem_cons inside]
      have instFamily := family stm (List.mem_of_getElem? statement)
      obtain ⟨next,stepped,rest,returned',frame⟩ := mixed_next_of_returned_frame head instFamily returned
      obtain ⟨t,left,total,ends,empty,tail,tailFrame⟩ := ih (by omega) rest returned'
      have current := actual_mixed_source_step run events split
        (record := ⟨blockStart f event.block+j,default,default⟩) statement rfl instFamily head stepped
      refine ⟨t,left,by omega,ends,empty,?_,SourceFrameEq.trans frame tailFrame⟩
      have length : b.body.length-j = (b.body.length-(j+1))+1 := by omega
      rw [length,List.range'_succ]
      simpa only [Nat.add_assoc,Nat.add_comm 1 j] using SourceSteps.cons current tail

private theorem return_done_of_runLoop {env : Clif.Env} {cp : Clif.Program}
    {s : Clif.State} {xs : List Nat} {fuel : Nat} {vals : List Clif.Val} {mem : Clif.Mem}
    (empty : s.frame.body = []) (callers : s.callers = []) (term : s.frame.term = .ret xs)
    (returned : Clif.runLoop env cp fuel s = .returned vals mem) :
    Clif.stepTerm env cp s (.ret xs) = .done vals mem := by
  cases fuel with
  | zero => cases returned
  | succ fuel =>
    rw [Clif.runLoop_succ,Clif.step_term env cp s empty,term] at returned
    cases step : Clif.stepTerm env cp s (.ret xs) with
    | next t => exact False.elim ((stepTerm_ret callers).1 t step)
    | done vs cm =>
      simp only [step,Clif.Outcome.returned.injEq] at returned
      obtain ⟨rfl,rfl⟩ := returned
      rfl
    | trapped c => simp only [step] at returned; cases returned
    | stuck message => simp only [step] at returned; cases returned

private theorem factor_seg {vb : VBlock} {pre code post : Array MInst}
    (parts : vb.insts = pre ++ code ++ post) : SegAt vb pre.size code.toList := by
  intro k hk
  have bound : k < code.size := by simpa using hk
  rw [parts,Array.append_assoc,Array.getElem?_append_right (by omega)]
  simp only [Nat.add_sub_cancel_left]
  rw [Array.getElem?_append_left bound]
  simp [bound]

/-- Actual source execution and the actual emitted arithmetic body/return reach
an ABI-correct return in Stock's returned VCode. Source steps, terminal definedness,
caller/frame transport and segment placement are all derived internally. -/
theorem actual_mixed_return_refines_at {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    (abi : sigAbiOk f.sig = true) {b : Clif.Block} (blocks : f.blocks = [b])
    (family : ∀ stm ∈ b.body, Family stm.inst)
    {xs : List Nat} (ret : b.term = .ret xs)
    {event : BlockScanEvent} (events : event ∈ result.blockScans.toList)
    {env : Clif.Env} {cp : Clif.Program} {fuel : Nat} {s : Clif.State}
    (func : s.frame.func = f) (callers : s.callers = [])
    (remaining : s.frame.body = b.body) (terminal : s.frame.term = b.term)
    (defined : SourceDefinedAt f result.ctx event.block 0 s.frame)
    {vals : List Clif.Val} {mem : Clif.Mem}
    (returned : Clif.runLoop env cp fuel s = .returned vals mem)
    {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem} (refines : Refines F isem)
    {MR : MemRelT} (stable : MRStable F MR)
    {label : Nat} {vb : VBlock} {pre post : Array MInst}
    (placed : result.code.blocks[label]? = some vb)
    (code : vb.insts = pre ++ event.output.code.map (·.mapRegs
      (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1))) ++ post) :
    ∀ ρ w, GuardedScanRel f result event.ctx event.block MR event.output.state
      (0,s.frame,s.mem) ρ w →
      RunOkABI f result.code isem MR s.frame.slots ⟨label,pre.size,ρ,w⟩ (.returned vals mem) := by
  obtain ⟨term,body,split,families⟩ := actual_mixed_families run scope blocks family events
  have start : s.frame.body = b.body.drop 0 := by simpa using remaining
  obtain ⟨t,left,total,ends,empty,steps,frame⟩ := actual_mixed_source_execution_frame
    run events split family (j := 0) (by omega) start returned
  have tDefined : SourceDefinedAt f result.ctx event.block b.body.length t.frame := by
    apply ArithmeticBody.arithmetic_steps_defined run scope dominated events split.block
      (env := env) (cp := cp) (s := (0,s.frame,s.mem)) (t := (b.body.length,t.frame,t.mem))
      (j := 0) (n := b.body.length) (by omega) rfl ?_ defined
    simpa only [Nat.add_zero,Nat.sub_zero] using steps
  have tFunc : t.frame.func = f := frame.2.1.trans func
  have tCallers : t.callers = [] := frame.1.trans callers
  have tTerm : t.frame.term = .ret xs := frame.2.2.2.trans (terminal.trans ret)
  have done := return_done_of_runLoop empty tCallers tTerm ends
  let resolve := Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1)
  have pieces : vb.insts = pre ++ body.code.map (·.mapRegs resolve) ++
      (term.output.emitted.map (·.mapRegs resolve) ++ post) := by
    simp only [code,split.code,Array.map_append,Array.append_assoc,resolve]
  have bodySeg : SegAt vb pre.size (body.code.toList.map (·.mapRegs resolve)) := by
    simpa only [Array.toList_map] using factor_seg pieces
  have termPieces : vb.insts = (pre ++ body.code.map (·.mapRegs resolve)) ++
      term.output.emitted.map (·.mapRegs resolve) ++ post := by
    simpa only [Array.append_assoc] using pieces
  have termSeg : SegAt vb (pre.size+body.code.size)
      (term.output.emitted.toList.map (·.mapRegs resolve)) := by
    simpa only [Array.size_append,Array.size_map,Array.toList_map] using factor_seg termPieces
  have termMember : term ∈ event.output.records := by rw [split.records]; exact List.mem_cons_self
  intro ρ w held
  obtain ⟨ρ',w',executed,postHeld⟩ := stock_lower_select_addsub_omitted_body_fall_refines
    run scope dominated events split.scanned split.retained families refines stable
    (0,s.frame,s.mem) (b.body.length,t.frame,t.mem)
    (by simpa only [sourceBodyIndices,List.reverse_reverse,Nat.add_zero,Nat.sub_zero,List.range'_eq_map_range] using steps)
    ρ w (by simpa only [split.state] using held)
  obtain ⟨heldFunc,dfg,memory,values⟩ := postHeld
  obtain ⟨step,rs,ps,extra,recorded,emitted,termCode,rest⟩ :=
    stock_lower_return_record_source_run_auto run scope dominated abi events split.block ret
      termMember split.termInst tFunc tCallers done tDefined values refines stable
  have nonempty : 0 < term.output.emitted.size := by rw [termCode]; exact Nat.zero_lt_succ 0
  have room : pre.size + (body.code.toList.map (·.mapRegs resolve)).length < vb.insts.size := by
    have sizes := congrArg Array.size pieces
    simp only [Array.size_append,Array.size_map] at sizes
    simp only [List.length_map,Array.length_toList]
    omega
  have path := seqRun_fall_star (vc := result.code) (sem := isem) placed bodySeg room executed
  have finished := stock_lower_return_record_runOk run scope dominated abi events split.block ret
    termMember split.termInst tFunc tCallers done tDefined values refines stable placed termSeg w' memory
  have combined := RunOkABI.prefix path (by simpa only [List.length_map,Array.length_toList] using finished)
  simpa only [frame.2.2.1] using combined

/-- Compatibility variant retaining existential body placement. -/
theorem actual_mixed_return_refines {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    (abi : sigAbiOk f.sig = true) {b : Clif.Block} (blocks : f.blocks = [b])
    (family : ∀ stm ∈ b.body, Family stm.inst)
    {xs : List Nat} (ret : b.term = .ret xs)
    {event : BlockScanEvent} (events : event ∈ result.blockScans.toList)
    {env : Clif.Env} {cp : Clif.Program} {fuel : Nat} {s : Clif.State}
    (func : s.frame.func = f) (callers : s.callers = [])
    (remaining : s.frame.body = b.body) (terminal : s.frame.term = b.term)
    (defined : SourceDefinedAt f result.ctx event.block 0 s.frame)
    {vals : List Clif.Val} {mem : Clif.Mem}
    (returned : Clif.runLoop env cp fuel s = .returned vals mem)
    {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem} (refines : Refines F isem)
    {MR : MemRelT} (stable : MRStable F MR) :
    ∃ label k, ∀ ρ w, GuardedScanRel f result event.ctx event.block MR event.output.state
      (0,s.frame,s.mem) ρ w →
      RunOkABI f result.code isem MR s.frame.slots ⟨label,k,ρ,w⟩ (.returned vals mem) := by
  obtain ⟨label,vb,pre,post,placed,code⟩ := stock_lower_block_scan_code run events
  exact ⟨label,pre.size,actual_mixed_return_refines_at run scope dominated abi blocks family ret
    events func callers remaining terminal defined returned refines stable placed code⟩

/-- Original function entry derives the frame, caller and source-definedness
premises of the actual arithmetic return simulation. -/
theorem actual_mixed_entered_return_refines {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    (abi : sigAbiOk f.sig = true) {b : Clif.Block} (blocks : f.blocks = [b])
    (family : ∀ stm ∈ b.body, Family stm.inst)
    {xs : List Nat} (ret : b.term = .ret xs)
    {event : BlockScanEvent} (events : event ∈ result.blockScans.toList)
    {args : List Clif.Val} {cm0 cm : Clif.Mem} {fr : Clif.Frame}
    (entered : Clif.enterFunc f args cm0 = .ok (fr,cm))
    {env : Clif.Env} {cp : Clif.Program} {fuel : Nat} {vals : List Clif.Val} {mem : Clif.Mem}
    (returned : Clif.runLoop env cp fuel ⟨fr,[],cm⟩ = .returned vals mem)
    {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem} (refines : Refines F isem)
    {MR : MemRelT} (stable : MRStable F MR) :
    ∃ label k, ∀ ρ w, GuardedScanRel f result event.ctx event.block MR event.output.state
      (0,fr,cm) ρ w →
      RunOkABI f result.code isem MR fr.slots ⟨label,k,ρ,w⟩ (.returned vals mem) := by
  obtain ⟨b',regs,entry,types,paramTypes,set,slots,frame⟩ := Opt.enterFunc_ok entered
  have same : b' = b := by
    have found : some b = some b' := by simpa only [Clif.Function.entry?,blocks,List.head?_cons] using entry
    exact Option.some.inj found.symm
  subst b'
  obtain ⟨term,body,split,families⟩ := actual_mixed_families run scope blocks family events
  have bound := (List.getElem?_eq_some_iff.mp split.block).1
  rw [blocks] at bound
  have zero : event.block = 0 := by simpa using bound
  have defined : SourceDefinedAt f result.ctx event.block 0 fr := by
    rw [zero]
    exact source_defined_enterFunc dominated result.ctx entered
  apply actual_mixed_return_refines run scope dominated abi blocks family ret events
    (s := ⟨fr,[],cm⟩) (by rw [frame]) rfl
    (by rw [frame]) (by rw [frame]) defined returned refines stable

private theorem return_inbounds {vc : VCode} {isem : Backend.Proof.Sem}
    {vs : VState CV Arm.ArmState} {us : List (Reg × Reg)} {vals : List CV} {w : Arm.ArmState}
    (ret : VRetFrom vc isem vs us vals w) {block : VBlock}
    (placed : vc.blocks[vs.b]? = some block) : vs.k < block.insts.size := by
  obtain ⟨b,k,ρ,w₁,vb,ops,outs,path,atBlock,instruction,_⟩ := ret
  cases path with
  | refl =>
    have same : block = vb := Option.some.inj (placed.symm.trans atBlock)
    subst vb
    exact (Array.getElem?_eq_some_iff.mp instruction).1
  | step first rest =>
    cases first with
    | step found instruction operands semantics length next =>
      have same : block = _ := Option.some.inj (placed.symm.trans found)
      subst same
      exact (Array.getElem?_eq_some_iff.mp instruction).1

/-- Complete original-entry-to-return simulation of arbitrary single-block
add/sub bodies in the actual Stock VCode. ABI materialization, omitted parameter
values, final aliases, source execution and machine PC placement are derived
internally. The allocation checker may choose the proof-selected initial file. -/
theorem actual_mixed_entry_return_refines_frame {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    (abi : sigAbiOk f.sig = true) {b : Clif.Block} (blocks : f.blocks = [b])
    (family : ∀ stm ∈ b.body, Family stm.inst)
    {xs : List Nat} (ret : b.term = .ret xs)
    {args : List Clif.Val} {cm : Clif.Mem} {fr : Clif.Frame}
    (entered : SourceEntry f args fr)
    {env : Clif.Env} {cp : Clif.Program} {fuel : Nat} {vals : List Clif.Val} {mem : Clif.Mem}
    (returned : Clif.runLoop env cp fuel ⟨fr,[],cm⟩ = .returned vals mem)
    {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem} (refines : Refines F isem)
    (driver : DriverSem isem) {sb : Nat} {syms : String → Option Nat}
    (memorySem : MemRefines F sb syms isem) {MR : MemRelT} (stable : MRStable F MR)
    {w : Arm.ArmState} (memory : MR fr.slots cm w)
    (arguments : ArgsAtEntry F f.sig args w) :
    ∃ ρ, RunOkABI f result.code isem MR fr.slots ⟨0,0,ρ,w⟩ (.returned vals mem) := by
  obtain ⟨event,vb,pre,body,ρ',w',events,zero,placed,pieces,execution,mem',values,same,
    after,bodyCode⟩ := stock_lower_entry_prelude_refines_frame run scope dominated entered driver
      memorySem stable memory arguments
  have code : vb.insts = pre ++ event.output.code.map (·.mapRegs
      (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1))) ++ after := by
    rw [pieces,bodyCode,Array.append_assoc]
  have entryFacts := entered
  obtain ⟨b',regs,entry,argTypes,paramTypes,set,frame⟩ := entryFacts
  have sameBlock : b' = b := by
    have found : some b = some b' := by
      simpa only [Clif.Function.entry?,blocks,List.head?_cons] using entry
    exact Option.some.inj found.symm
  subst b'
  have defined : SourceDefinedAt f result.ctx event.block 0 fr := by
    rw [zero]
    exact source_defined_entry_frame dominated result.ctx entered
  have held := stock_lower_entered_values_guarded_frame run scope dominated events entered values
    event.output.state w' mem'
  have finished := actual_mixed_return_refines_at run scope dominated abi blocks family ret events
    (s := ⟨fr,[],cm⟩) (by rw [frame]) rfl (by rw [frame]) (by rw [frame])
    defined returned refines stable placed code ρ' w' held
  have room : pre.size < vb.insts.size := by
    obtain ⟨us,outs,world,cm',reached,_⟩ := finished
    exact return_inbounds reached placed
  have segment : SegAt vb 0 pre.toList := by
    intro k bound
    have inside : k < pre.size := by simpa only [Array.length_toList] using bound
    rw [Nat.zero_add,pieces,Array.getElem?_append_left inside]
    simp [inside]
  have path := seqRun_fall_star (vc := result.code) (sem := isem) placed segment
    (by simpa only [Nat.zero_add,Array.length_toList] using room) execution
  refine ⟨entrySeed event.ctx fr,RunOkABI.prefix path ?_⟩
  simpa only [Nat.zero_add,Array.length_toList] using finished

/-- Executable-entry compatibility variant; retains the original statement. -/
theorem actual_mixed_entry_return_refines {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    (abi : sigAbiOk f.sig = true) {b : Clif.Block} (blocks : f.blocks = [b])
    (family : ∀ stm ∈ b.body, Family stm.inst)
    {xs : List Nat} (ret : b.term = .ret xs)
    {args : List Clif.Val} {cm0 cm : Clif.Mem} {fr : Clif.Frame}
    (entered : Clif.enterFunc f args cm0 = .ok (fr,cm))
    {env : Clif.Env} {cp : Clif.Program} {fuel : Nat} {vals : List Clif.Val} {mem : Clif.Mem}
    (returned : Clif.runLoop env cp fuel ⟨fr,[],cm⟩ = .returned vals mem)
    {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem} (refines : Refines F isem)
    (driver : DriverSem isem) {sb : Nat} {syms : String → Option Nat}
    (memorySem : MemRefines F sb syms isem) {MR : MemRelT} (stable : MRStable F MR)
    {w : Arm.ArmState} (memory : MR fr.slots cm w)
    (arguments : ArgsAtEntry F f.sig args w) :
    ∃ ρ, RunOkABI f result.code isem MR fr.slots ⟨0,0,ρ,w⟩ (.returned vals mem) := by
  exact actual_mixed_entry_return_refines_frame run scope dominated abi blocks family ret (SourceEntry.of_enterFunc entered) returned refines driver memorySem stable memory arguments


private theorem get_notrap (fr : Clif.Frame) (x : Nat) (c : Clif.TrapCode) :
    fr.get x ≠ .trap c := by
  cases found : fr.regs x <;> simp [Clif.Frame.get,Clif.Res.ofOption,found]

private theorem getAs_notrap (fr : Clif.Frame) (x : Nat) (ty : Clif.Ty) (c : Clif.TrapCode) :
    fr.getAs x ty ≠ .trap c := by
  cases found : fr.get x with
  | trap code => exact False.elim (get_notrap fr x code found)
  | stuck message => simp [Clif.Frame.getAs,found]
  | ok value => cases cast : value.as? ty <;> simp [Clif.Frame.getAs,found,Clif.Res.ofOption,cast]

private theorem getMany_notrap (fr : Clif.Frame) (xs : List Nat) (c : Clif.TrapCode) :
    fr.getMany xs ≠ .trap c := by
  induction xs generalizing c with
  | nil => simp [Clif.Frame.getMany]
  | cons x xs ih =>
    cases found : fr.get x with
    | trap code => exact False.elim (get_notrap fr x code found)
    | stuck message => simp [Clif.Frame.getMany,found]
    | ok value =>
      cases rest : fr.getMany xs with
      | trap code => exact False.elim ((ih code) rest)
      | stuck message => simp [Clif.Frame.getMany,found,rest]
      | ok values => simp [Clif.Frame.getMany,found,rest]

private theorem arithmetic_notrap (fr : Clif.Frame) (cm : Clif.Mem)
    (subtract : Bool) (ty : Clif.Ty) (x y : Nat) (c : Clif.TrapCode) :
    Clif.evalInst fr cm (.binary (if subtract then .isub else .iadd) ty x y) ≠ .trap c := by
  cases subtract <;>
    simp only [Bool.false_eq_true,ite_false,ite_true,Clif.evalInst,Clif.BinaryOp.isShift]
  all_goals
    cases left : fr.getAs x ty with
    | trap code => exact False.elim (getAs_notrap fr x ty code left)
    | stuck message => simp
    | ok a =>
      cases right : fr.getAs y ty with
      | trap code => exact False.elim (getAs_notrap fr y ty code right)
      | stuck message => simp
      | ok b => simp

private theorem family_notrap (fr : Clif.Frame) (cm : Clif.Mem)
    {inst : Clif.Inst} (family : Family inst) (c : Clif.TrapCode) :
    Clif.evalInst fr cm inst ≠ .trap c := by
  rcases family with ⟨subtract,ty,x,y,rfl⟩ | ⟨ty,condition,x,y,rfl⟩
  · exact arithmetic_notrap fr cm subtract ty x y c
  · simp only [Clif.evalInst]
    cases cond : fr.get condition with
    | trap code => exact False.elim (get_notrap fr condition code cond)
    | stuck message => simp
    | ok cv =>
      cases left : fr.getAs x ty with
      | trap code => exact False.elim (getAs_notrap fr x ty code left)
      | stuck message => simp
      | ok a =>
        cases right : fr.getAs y ty with
        | trap code => exact False.elim (getAs_notrap fr y ty code right)
        | stuck message => simp
        | ok b => simp

/-- Pure add/sub source bodies ending in return cannot produce a trap, even
when malformed operands instead make the executable semantics stuck. -/
theorem mixed_source_notrap {env : Clif.Env} {cp : Clif.Program} (fuel : Nat)
    (s : Clif.State) (callers : s.callers = [])
    (family : ∀ stm ∈ s.frame.body, Family stm.inst)
    {xs : List Nat} (ret : s.frame.term = .ret xs) (code : Clif.TrapCode) :
    Clif.runLoop env cp fuel s ≠ .trapped code := by
  induction fuel generalizing s with
  | zero => simp
  | succ fuel ih =>
    rw [Clif.runLoop_succ]
    cases remaining : s.frame.body with
    | nil =>
      rw [Clif.step_term env cp s remaining,ret,Clif.stepTerm]
      cases values : s.frame.getMany xs with
      | trap c => exact False.elim (getMany_notrap s.frame xs c values)
      | stuck message => simp
      | ok vals =>
        simp only [Clif.StepResult.ofRes]
        by_cases typed : vals.map (·.ty) = Clif.AbiParam.tys s.frame.func.sig.returns <;>
          simp [Clif.returnValues,Clif.checkTys,Clif.Res.check,callers,Clif.StepResult.ofRes,typed]
    | cons stm rest =>
      have instFamily := family stm (by simp [remaining])
      rw [Clif.step_inst env cp s stm rest remaining
        (by
          intro fn args h
          rcases instFamily with ⟨subtract,ty,x,y,shape⟩ | ⟨ty,c,x,y,shape⟩
          all_goals rw [shape] at h; cases h)
        (by
          intro sig callee args h
          rcases instFamily with ⟨subtract,ty,x,y,shape⟩ | ⟨ty,c,x,y,shape⟩
          all_goals rw [shape] at h; cases h)]
      cases evaluated : Clif.evalInst s.frame s.mem stm.inst with
      | trap c => exact False.elim (family_notrap s.frame s.mem instFamily c evaluated)
      | stuck message => simp
      | ok pair =>
        rcases pair with ⟨values,cm⟩
        simp only [Clif.StepResult.ofRes,Clif.continueWith]
        cases written : s.frame.regs.setMany stm.results values with
        | none => simp
        | some regs =>
          simp only
          apply ih {s with frame := {s.frame with regs,body := rest},mem := cm} callers ?_ ret
          intro other member
          apply family other
          rw [remaining]
          exact List.mem_cons_of_mem _ member


end Backend.Stock.Proof.MixedBody

namespace Backend.Stock.Mixed
open Backend.Proof Backend.Proof.Driver
structure Domain (f : Clif.Function) : Prop where
  scope : LowerScope f
  dominated : Dominated f
  abi : sigAbiOk f.sig = true
  shape : ∃ b xs, f.blocks = [b] ∧ b.term = .ret xs ∧
    ∀ stm ∈ b.body, Backend.Stock.Proof.MixedBody.Family stm.inst
  ordinary : (sigRets f.sig).any (·.purpose == .sret) = false
end Backend.Stock.Mixed

namespace Backend.Stock.Mixed
open Backend.Proof Backend.Proof.Driver
set_option autoImplicit false
set_option Elab.async false

private theorem normal_abi {params : List Clif.AbiParam} (all : params.all abiEligible = true) :
    ∀ p ∈ params, p.purpose = .normal := by
  intro p member
  have good := List.all_eq_true.mp all p member
  simp only [abiEligible,Arithmetic.abiEligible, Bool.and_eq_true] at good
  have purpose : (p.purpose == .normal) = true := good.1
  exact beq_iff_eq.mp purpose

/-- The runtime source classifier derives all semantic premises internally. -/
theorem sourceOk_sound {f : Clif.Function} (checked : sourceOk f = true) : Domain f := by
  simp only [sourceOk,Bool.and_eq_true] at checked
  obtain ⟨⟨⟨eligible,scope⟩,dominated⟩,abi⟩ := checked
  unfold Mixed.eligible at eligible
  split at eligible
  next b blocks =>
    simp only [Bool.and_eq_true] at eligible
    obtain ⟨⟨⟨body,terminal⟩,params⟩,returns⟩ := eligible
    have sourceShape : ∃ xs, b.term = .ret xs := by
      cases term : b.term <;> simp_all
    obtain ⟨xs,ret⟩ := sourceShape
    have families : ∀ stm ∈ b.body, Stock.Proof.MixedBody.Family stm.inst := by
      intro stm member
      have supported := List.all_eq_true.mp body stm member
      cases inst : stm.inst <;> simp only [bodyEligible,inst] at supported
      all_goals try contradiction
      next op ty x y =>
        simp only [Bool.and_eq_true] at supported
        have ops := supported.1
        simp only [Bool.or_eq_true,beq_iff_eq] at ops
        rcases ops with rfl | rfl
        · exact .inl ⟨false,ty,x,y,rfl⟩
        · exact .inl ⟨true,ty,x,y,rfl⟩
      next ty c x y => exact .inr ⟨ty,c,x,y,rfl⟩
    have noSret : f.sig.params.find? (·.purpose == .sret) = none := by
      apply List.find?_eq_none.mpr
      intro p member
      simp [(normal_abi params) p member]
    have ordinary : (sigRets f.sig).any (·.purpose == .sret) = false := by
      rw [sigRets,noSret]
      apply Bool.eq_false_iff.mpr
      intro any
      obtain ⟨p,member,sret⟩ := List.any_eq_true.mp any
      simpa [(normal_abi returns) p member] using sret
    exact ⟨lowerScope_of scope,dominated_of dominated,abi,⟨b,xs,blocks,ret,families⟩,ordinary⟩
  next => cases eligible


theorem check_sound {f : Clif.Function} {vc : VCode} (checked : check f vc = true) :
    ∃ result, Domain f ∧ Stock.lower f = .ok result ∧ result.code = vc ∧
      result.edgeArgs.all (fun row => row.all (·.isEmpty)) = true := by
  simp only [check,Bool.and_eq_true] at checked
  obtain ⟨source,lowered⟩ := checked
  cases run : Stock.lower f with
  | error message => simp [run] at lowered
  | ok result =>
    simp only [run,Bool.and_eq_true,decide_eq_true_eq] at lowered
    exact ⟨result,sourceOk_sound source,rfl,lowered.1,lowered.2⟩
end Backend.Stock.Mixed

namespace E2E
open Backend Backend.Proof Backend.Proof.Driver Backend.Stock.Proof Backend.DeadCleanup
set_option autoImplicit false
set_option Elab.async false

/-- Actual Stock arithmetic with both production cleanup settings, original
source entry, linked ABI returns, post-call trace and per-state guarantees. -/
theorem backend_correct_worldX_stock_mixed {p : Clif.Program} {f : Clif.Function} {k : Nat} {result : Stock.Result} {vcp : VCode}
    {rf : RFunc} {af : AFunc} {fa : FnAsm} {fb : FnBin}
    (domain : Stock.Mixed.Domain f) {cleanup : Bool}
    (hc : CompiledStockArithmeticStage f cleanup k result vcp rf af fa fb)
    {X : ExtSem} {syms : String → Option Nat} {slotOff : Nat} {env : Clif.Env} {K : Nat}
    {F : BitVec 64 → Prop} {c : BitVec 64}
    (hcov : FormsCovered ⟨fa.k, af.slotBase⟩ vcp)
    (hsym : ∀ n b, syms n = some b → X.sym n 0 = BitVec.ofNat 64 b)
    (hslot : af.slotBase = slotOff)
    {w₀ : Arm.ArmState} {args : List Clif.Val} {cs : Clif.State}
    (hcs : ClifEntry f args cs)
    (hrel : RelW ⟨F, syms, slotOff, (RAFrame.compute vcp rf).intBase⟩ f c cs.frame.slots cs.mem w₀)
    (hargs : ArgsAtEntry F f.sig args w₀)
    (fuel : Nat) :
    (∀ vals cm, Clif.runLoop env p fuel cs = .returned vals cm →
      ∃ (us : List (Reg × Reg)) (outs : List CV) (w : Arm.ArmState),
        us.map (·.2) = (List.range us.length).map Reg.x ∧ us.length = outs.length ∧
        PrefixHold vals outs ∧ MemRel F syms cm w ∧ result.code.RetsSite us ∧
        ∀ (H : ArmHooks) (G : BitVec 64 → Prop) (base ra : BitVec 64) (s : Arm.ArmState),
          ActEntry vcp rf af fa fb K F G X H base ra s w₀ →
          ∃ n, ActRet ra F G us outs w s (runX (ArmStepX X H fa) n s) ∧
            PostTrace fa af base (ArmStepX X H fa) s n ∧
            ∀ i < n, actGoodX vcp rf af fa fb base s X H K G (GotV vcp)
              (runX (ArmStepX X H fa) i s)) ∧
    (∀ c', Clif.runLoop env p fuel cs = .trapped c' →
      ∀ (H : ArmHooks) (G : BitVec 64 → Prop) (base ra : BitVec 64) (s : Arm.ArmState),
        ActEntry vcp rf af fa fb K F G X H base ra s w₀ →
        ∃ n, TrapAt fb base c' (runX (ArmStepX X H fa) n s) ∧
          (∀ i < n, actGoodX vcp rf af fa fb base s X H K G (GotV vcp)
            (runX (ArmStepX X H fa) i s)) ∧
          ∀ m, Arm.r .ERR (runX (ArmStepX X H fa) (n + m + 1) s) ≠ .None) := by
  obtain ⟨b,xs,blocks,ret,family⟩ := domain.shape
  have state : (⟨cs.frame,[],cs.mem⟩ : Clif.State) = cs := by
    have callers := hcs.callers
    cases cs
    cases callers
    rfl
  refine ⟨fun vals cm returned => ?_, fun code trapped H G base ra s he => ?_⟩
  · obtain ⟨ρ,source⟩ := MixedBody.actual_mixed_entry_return_refines_frame
      hc.lower domain.scope domain.dominated domain.abi blocks family ret hcs.stockSourceEntry
      (by rwa [state]) (refines_valueSem F ⟨fa.k,af.slotBase⟩ X)
      (driverSem_valueSem F ⟨fa.k,af.slotBase⟩ X)
      (memRefines_valueSem F ⟨fa.k,af.slotBase⟩ X hslot hsym)
      (mrStable_relW ⟨F,syms,slotOff,(RAFrame.compute vcp rf).intBase⟩ f c) hrel hargs
    obtain ⟨us,outs,w,cm0,reached,pins,arity,values,memory,freed⟩ := source
    have reached' := StockArithmeticStage_returns hc.prepOk reached
    have site : result.code.RetsSite us := by
      obtain ⟨b,k,ρ,w₁,vb,ops,outs',_,hvb,hk,_⟩ := reached
      exact ⟨b,vb,k,hvb,hk⟩
    have mem : MemRel F syms cm w := by
      rw [freed]
      exact memRel_leave (memRel_free memory.1.1 _)
    refine ⟨us,outs,w,pins.ordinary domain.ordinary,arity,values,mem,site,?_⟩
    intro H G base ra s he
    have machine := regLevelCorrect_worldX_value hc.check hc.alloc hc.emit hc.layout
      (X := X) (H := H) (K := K) (G := G) (gv := GotV vcp)
      hcov he.abi he.stack he.gfree (by rw [he.hF]; exact he.calls)
      (by rw [he.hF]; exact he.tries) (by rw [he.hF]; exact he.tls)
      (by rw [he.hF]; exact he.body) ρ
    rw [he.hF] at machine
    obtain ⟨n,⟨h1,h2,h3,h4,h5,h6,h7⟩,h8⟩ :=
      machine.1 us outs w (vReturns_gotV_value reached')
    exact ⟨n,⟨h1,h2,h3,h4,h5,h6⟩,h7,h8⟩
  · obtain ⟨b',found,body,terminal,_,_⟩ := hcs.entry
    have same : b' = b := by
      have equal : some b = some b' := by
        simpa only [Clif.Function.entry?,blocks,List.head?_cons] using found
      exact Option.some.inj equal.symm
    subst b'
    exact False.elim (MixedBody.mixed_source_notrap fuel cs hcs.callers
      (fun stm member => family stm (by rwa [body] at member)) (terminal.trans ret) code trapped)

end E2E

namespace E2E
open Backend Backend.Proof Backend.Proof.Driver
set_option autoImplicit false
set_option Elab.async false

/-- Additive artifact contract for actual Stock semantics. Legacy production
contracts and their lowerCheck consequences retain their original meaning. -/
inductive CompiledSemantic (f : Clif.Function) (k : Nat) (vc vcp : VCode)
    (rf : RFunc) (af : AFunc) (fa : FnAsm) (fb : FnBin) : Prop where
  | compatible : CompiledProduction f k vc vcp rf af fa fb →
      CompiledSemantic f k vc vcp rf af fa fb
  | arithmetic {cleanup : Bool} {result : Stock.Result} :
      Stock.Arithmetic.Domain f → result.code = vc →
      CompiledStockArithmeticStage f cleanup k result vcp rf af fa fb →
      CompiledSemantic f k vc vcp rf af fa fb
  | mixed {cleanup : Bool} {result : Stock.Result} :
      Stock.Mixed.Domain f → result.code = vc →
      CompiledStockArithmeticStage f cleanup k result vcp rf af fa fb →
      CompiledSemantic f k vc vcp rf af fa fb

namespace CompiledSemantic
variable {f : Clif.Function} {k : Nat} {vc vcp : VCode} {rf : RFunc}
  {af : AFunc} {fa : FnAsm} {fb : FnBin}

/-- Executable checker facts construct the semantic artifact. This does not
assert the old lowerCheck verdict for a raw Stock artifact. -/
theorem of_checks {cleanup : Bool} (lower : Stock.Arithmetic.check f vc = true)
    (prepared : Backend.prepare (Stock.Arithmetic.stage cleanup vc) = .ok vcp)
    (prepOk : prepCheck (Stock.Arithmetic.stage cleanup vc) vcp = true)
    (check : Backend.checkAlloc vcp rf = .ok ()) (alloc : lowerRFunc vcp rf = .ok af)
    (emit : emitFunc k af = .ok fa) (layout : fa.layout = .ok fb) :
    CompiledSemantic f k vc vcp rf af fa fb := by
  rcases Stock.Arithmetic.check_sound lower with legacy | ⟨result,domain,run,equal,_⟩
  · apply CompiledSemantic.compatible
    cases cleanup with
    | false =>
      exact .stock ⟨⟨legacy,prepared,prepOk,allocChecked_of_checkAlloc check,alloc,emit,layout⟩,check⟩
    | true =>
      exact .stockCleanup ⟨⟨legacy,prepared,prepOk,allocChecked_of_checkAlloc check,alloc,emit,layout⟩,check⟩
  · exact .arithmetic domain equal ⟨run,by rwa [equal],by rwa [equal],check,alloc,emit,layout⟩

theorem check (hc : CompiledSemantic f k vc vcp rf af fa fb) : Backend.checkAlloc vcp rf = .ok () := by
  cases hc with
  | compatible h => exact h.check
  | arithmetic _ _ h => exact h.check
  | mixed _ _ h => exact h.check

theorem alloc (hc : CompiledSemantic f k vc vcp rf af fa fb) : lowerRFunc vcp rf = .ok af := by
  cases hc with
  | compatible h => exact h.alloc
  | arithmetic _ _ h => exact h.alloc
  | mixed _ _ h => exact h.alloc

theorem emit (hc : CompiledSemantic f k vc vcp rf af fa fb) : emitFunc k af = .ok fa := by
  cases hc with
  | compatible h => exact h.emit
  | arithmetic _ _ h => exact h.emit
  | mixed _ _ h => exact h.emit

theorem layout (hc : CompiledSemantic f k vc vcp rf af fa fb) : fa.layout = .ok fb := by
  cases hc with
  | compatible h => exact h.layout
  | arithmetic _ _ h => exact h.layout
  | mixed _ _ h => exact h.layout

end CompiledSemantic

/-- Dispatch the linked per-state consumer using the checked artifact's actual
semantic provenance. All original activation and source conditions are kept. -/
theorem backend_correct_worldX_semantic {p : Clif.Program} {f : Clif.Function} {k : Nat} {vc vcp : VCode}
    {rf : RFunc} {af : AFunc} {fa : FnAsm} {fb : FnBin}
    (hsub : InSubset p f) (hc : CompiledSemantic f k vc vcp rf af fa fb)
    {X : ExtSem} {syms : String → Option Nat} {slotOff : Nat} {env : Clif.Env} {K : Nat}
    {F : BitVec 64 → Prop} {c : BitVec 64}
    (hcov : FormsCovered ⟨fa.k, af.slotBase⟩ vcp)
    (hX : XCallsOk env (f.externs.map (·.2))
      (RelW ⟨F, syms, slotOff, (RAFrame.compute vcp rf).intBase⟩ f c) X)
    (hXI : XCallsIndOk env (indSigs f)
      (RelW ⟨F, syms, slotOff, (RAFrame.compute vcp rf).intBase⟩ f c) X)
    (hsym : ∀ n b, syms n = some b → X.sym n 0 = BitVec.ofNat 64 b)
    (hslot : af.slotBase = slotOff)
    {w₀ : Arm.ArmState} {args : List Clif.Val} {cs : Clif.State}
    (hcs : ClifEntry f args cs)
    (hrel : RelW ⟨F, syms, slotOff, (RAFrame.compute vcp rf).intBase⟩ f c cs.frame.slots cs.mem w₀)
    (hargs : ArgsAtEntry F f.sig args w₀)
    (htr : TrapsExplicit env p cs) (fuel : Nat) :
    (∀ vals cm, Clif.runLoop env p fuel cs = .returned vals cm →
      ∃ (us : List (Reg × Reg)) (outs : List CV) (w : Arm.ArmState),
        us.map (·.2) = (List.range us.length).map Reg.x ∧ us.length = outs.length ∧
        PrefixHold vals outs ∧ MemRel F syms cm w ∧ vc.RetsSite us ∧
        ∀ (H : ArmHooks) (G : BitVec 64 → Prop) (base ra : BitVec 64) (s : Arm.ArmState),
          ActEntry vcp rf af fa fb K F G X H base ra s w₀ →
          ∃ n, ActRet ra F G us outs w s (runX (ArmStepX X H fa) n s) ∧
            PostTrace fa af base (ArmStepX X H fa) s n ∧
            ∀ i < n, actGoodX vcp rf af fa fb base s X H K G (GotV vcp)
              (runX (ArmStepX X H fa) i s)) ∧
    (∀ c', Clif.runLoop env p fuel cs = .trapped c' →
      ∀ (H : ArmHooks) (G : BitVec 64 → Prop) (base ra : BitVec 64) (s : Arm.ArmState),
        ActEntry vcp rf af fa fb K F G X H base ra s w₀ →
        ∃ n, TrapAt fb base c' (runX (ArmStepX X H fa) n s) ∧
          (∀ i < n, actGoodX vcp rf af fa fb base s X H K G (GotV vcp)
            (runX (ArmStepX X H fa) i s)) ∧
          ∀ m, Arm.r .ERR (runX (ArmStepX X H fa) (n + m + 1) s) ≠ .None) := by
  cases hc with
  | compatible h =>
    exact backend_correct_worldX_production hsub h hcov hX hXI hsym hslot hcs hrel hargs htr fuel
  | arithmetic domain equal h =>
    subst vc
    exact backend_correct_worldX_stock_arithmetic domain h hcov hsym hslot hcs hrel hargs fuel
  | mixed domain equal h =>
    subst vc
    exact backend_correct_worldX_stock_mixed domain h hcov hsym hslot hcs hrel hargs fuel

end E2E

namespace Backend.ABIReadFlags
set_option autoImplicit false

def extra : MInst → Bool
  | .aluRRR .subS _ .xzr (.vreg _ .int) .xzr => true
  | .csel (.vreg _ .int) (.vreg _ .int) (.vreg _ .int) _ => true
  | _ => false

def instruction (sig : Clif.Signature) (b k : Nat) (i : MInst) : Bool :=
  Backend.ABIReadOnly.instruction sig b k i || extra i

def check (sig : Clif.Signature) (vc : VCode) : Bool :=
  vc.blocks.toList.zipIdx.all fun (block,b) =>
    block.insts.toList.zipIdx.all fun (i,k) => instruction sig b k i


end Backend.ABIReadFlags

namespace E2E.MixedFlagBoundary
open Backend Backend.Proof Backend.Proof.Driver Backend.DeadCleanup
set_option autoImplicit false
set_option Elab.async false

/-- Additional forms actually used by parameter-conditioned scalar select.
This classifier does not change the dead-code-removal whitelist. -/
abbrev extra := Backend.ABIReadFlags.extra

/-- Executable facts expose only concrete instruction shapes. -/
theorem extra_cases {i : MInst} (checked : extra i = true) :
    (∃ sz n, i = .aluRRR .subS sz .xzr (.vreg n .int) .xzr) ∨
    (∃ d n m c, i = .csel (.vreg d .int) (.vreg n .int) (.vreg m .int) c) := by
  cases i with
  | aluRRR op sz rd rn rm =>
    cases op <;> try cases checked
    cases rd <;> try cases checked
    cases rn <;> try cases checked
    case vreg n cls =>
      cases cls <;> try cases checked
      cases rm <;> try cases checked
      exact .inl ⟨sz,n,rfl⟩
  | csel rd rn rm c =>
    cases rd <;> try cases checked
    case vreg d cls =>
      cases cls <;> try cases checked
      cases rn <;> try cases checked
      case vreg n cls =>
        cases cls <;> try cases checked
        cases rm <;> try cases checked
        case vreg m cls =>
          cases cls <;> try cases checked
          exact .inr ⟨d,n,m,c,rfl⟩
  | _ => cases checked

private theorem no_mem {i : MInst} (checked : extra i = true) : i.isMemAcc = false := by
  rcases extra_cases checked with ⟨sz,n,rfl⟩ | ⟨d,n,m,c,rfl⟩ <;> rfl

private theorem spec_eq {i : MInst} (checked : extra i = true) (sb : Nat)
    (us : List CV) (w : Arm.ArmState) : mspec sb i us w = ispec i us w := by
  rcases extra_cases checked with ⟨sz,n,rfl⟩ | ⟨d,n,m,c,rfl⟩ <;> rfl

/-- Extra select forms may change NZCV, while preserving the full memory and
all non-flag world fields required by the source memory relation. -/
theorem step_frame {i : MInst} (checked : extra i = true) {sb : Nat}
    {us outs : List CV} {w t : Arm.ArmState} {ctl : Ctl}
    (run : mspec sb i us w = some (outs,t,ctl)) :
    SameWorldNF (fun _ => False) t w ∧ ctl = .next := by
  rw [spec_eq checked] at run
  rcases extra_cases checked with ⟨sz,n,rfl⟩ | ⟨d,n,m,c,rfl⟩
  · cases us with
    | nil => cases run
    | cons a rest =>
      cases rest with
      | cons b tail =>
        cases tail with
        | cons c rest => simp [ispec] at run
        | nil =>
          simp only [ispec,Option.some.injEq,Prod.mk.injEq] at run
          obtain ⟨rfl,rfl,rfl⟩ := run
          exact ⟨SameWorldNF.write_pstate _ _ _,rfl⟩
      | nil =>
        simp only [ispec,Option.some.injEq,Prod.mk.injEq] at run
        obtain ⟨rfl,rfl,rfl⟩ := run
        exact ⟨SameWorldNF.write_pstate _ _ _,rfl⟩
  · cases us with
    | nil => cases run
    | cons a rest =>
      cases rest with
      | nil => cases run
      | cons b tail =>
        cases tail with
        | cons c rest => cases run
        | nil =>
          simp only [ispec,Option.some.injEq,Prod.mk.injEq] at run
          obtain ⟨rfl,rfl,rfl⟩ := run
          exact ⟨SameWorld.nf (SameWorld.refl _ _),rfl⟩

/-- Equal virtual operands on related worlds produce equal values/control and
related successor worlds, including the newly computed flags. -/
theorem step_transport {i : MInst} (checked : extra i = true) {sb : Nat}
    {Z : BitVec 64 → Prop} {w w' : Arm.ArmState} (worlds : SameWorld Z w w')
    {us outs : List CV} {t : Arm.ArmState} {ctl : Ctl}
    (run : mspec sb i us w = some (outs,t,ctl)) :
    ∃ t', mspec sb i us w' = some (outs,t',ctl) ∧ SameWorld Z t t' :=
  mspec_lockstep (no_mem checked) worlds run

/-- Realize the flag-threaded specification through the existing shipped
value semantics, retaining identical outputs and flags on related worlds. -/
theorem step_realize {i : MInst} (checked : extra i = true)
    {F : BitVec 64 → Prop} {ctx : FnCtx} {X : ExtSem}
    {us outs : List CV} {w w' t : Arm.ArmState} {ctl : Ctl}
    (worlds : SameWorld F w' w)
    (run : mspec ctx.slotBase i us w = some (outs,t,ctl)) :
    ∃ t', valueSem F ctx X i us w' = some (outs,t',ctl) ∧ SameWorld F t' t := by
  obtain ⟨spec,executed,related⟩ := step_transport checked worlds.symm run
  rw [spec_eq checked] at executed
  obtain ⟨actual,realized,related'⟩ := refines_valueSem F ctx X i us w' outs spec executed
  exact ⟨actual,realized,related'.trans related.symm⟩

/-- A real compare step and dependent conditional select preserve the flag
thread; both outcomes are covered for arbitrary words and caller state. -/
theorem compare_select_witness (sz : OperandSize) (a x y : CV) (w : Arm.ArmState) :
    ∃ t,
      mspec 0 (.aluRRR .subS sz .xzr (.vreg 0 .int) .xzr) [a] w = some ([],t,.next) ∧
      mspec 0 (.csel (.vreg 3 .int) (.vreg 1 .int) (.vreg 2 .int) .ne) [x,y] t =
        some ([ofX (if Arm.ConditionHolds Cond.ne.bits t then lo64 x else lo64 y)],t,.next) := by
  exact ⟨_,rfl,rfl⟩


/-- Proof semantics classify the operation independently of register names;
the executable boundary above restricts actual accepted shapes. -/
def special : MInst → Bool
  | .aluRRR .subS .. | .csel .. => true
  | _ => false

noncomputable def sem (F : BitVec 64 → Prop) (ctx : FnCtx) (X : ExtSem) : Sem :=
  fun i us w => if special i then mspec ctx.slotBase i us w else ABIReadOnly.sem F ctx X i us w

/-- The original source specification is preserved, including flag updates. -/
theorem refines (F : BitVec 64 → Prop) (ctx : FnCtx) (X : ExtSem) :
    Refines F (sem F ctx X) := by
  intro i us w outs w' ctl executed
  by_cases hs : special i = true
  · exact ⟨w',by simp only [sem,hs,↓reduceIte]; exact mspec_of_ispec executed,SameWorld.refl F w'⟩
  · simpa only [sem,show special i = false from Bool.eq_false_iff.mpr hs,Bool.false_eq_true,↓reduceIte] using
      ABIReadOnly.refines F ctx X i us w outs w' executed

/-- Memory and symbol contracts retain the existing implementation. -/
theorem memory (F : BitVec 64 → Prop) (ctx : FnCtx) (X : ExtSem)
    {sb : Nat} {syms : String → Option Nat} (base : ctx.slotBase = sb)
    (symbols : ∀ n b, syms n = some b → X.sym n 0 = BitVec.ofNat 64 b) :
    MemRefines F sb syms (sem F ctx X) := by
  simpa only [MemRefines,sem,special,Bool.false_eq_true,↓reduceIte] using ABIReadOnly.memory F ctx X base symbols

/-- Alias resolution, retargeting and actual ABI argument reads retain their
original driver contracts. No chosen virtual file is added to source inputs. -/
theorem driver (F : BitVec 64 → Prop) (ctx : FnCtx) (X : ExtSem) :
    DriverSem (sem F ctx X) := by
  have hd := ABIReadOnly.driver F ctx X
  refine ⟨⟨?_,?_,?_⟩,?_⟩
  · intro l w; exact hd.jump l w
  · intro g gn hg i
    funext us w
    have old := congrFun (congrFun (hd.rename g gn hg i) us) w
    have spec := mspec_mapRegs hg ctx.slotBase i us w
    cases i with
    | aluRRR op sz rd rn rm =>
      cases op
      all_goals first
        | simpa only [sem,special,MInst.mapRegs,Bool.false_eq_true,↓reduceIte] using spec
        | simpa only [sem,special,MInst.mapRegs,Bool.false_eq_true,↓reduceIte] using old
    | csel rd rn rm c => simpa only [sem,special,MInst.mapRegs,Bool.false_eq_true,↓reduceIte] using spec
    | _ => simpa only [sem,special,MInst.mapRegs,Bool.false_eq_true,↓reduceIte] using old
  · intro i ls i' targets
    have old := hd.retarget i ls i' targets
    unfold MInst.setTargets at targets
    split at targets
    all_goals repeat' first | cases targets | split at targets
    all_goals
      funext us w
      simpa only [sem,special,Bool.false_eq_true,↓reduceIte] using congrFun (congrFun old us) w
  · intro ds w; exact hd.args ds w


/-- Specification worlds differ only in flags; even masked physical registers
are retained, so original ABI reads remain available while flags are threaded. -/
def FlagFrame (w t : Arm.ArmState) : Prop :=
  (∀ f, (∀ fl, f ≠ .FLAG fl) → Arm.r f t = Arm.r f w) ∧
  t.mem = w.mem ∧ t.program = w.program

private theorem FlagFrame.refl (w : Arm.ArmState) : FlagFrame w w :=
  ⟨fun _ _ => rfl,rfl,rfl⟩

private theorem FlagFrame.write_pstate (ps : Arm.PState) (w : Arm.ArmState) :
    FlagFrame w (Arm.write_pstate ps w) := by
  refine ⟨fun f nonflag => ?_,?_,?_⟩
  · simp only [Arm.write_pstate]
    rw [Arm.r_of_w_different (nonflag _),Arm.r_of_w_different (nonflag _),
      Arm.r_of_w_different (nonflag _),Arm.r_of_w_different (nonflag _)]
  · simp only [Arm.write_pstate,Arm.ArmState.mem_w_eq_mem]
  · simp only [Arm.write_pstate,Arm.w_program]

private theorem old_not_special {sig : Clif.Signature} {b k : Nat} {i : MInst}
    (checked : Backend.ABIReadOnly.instruction sig b k i = true) : special i = false := by
  cases i with
  | aluRRR op sz rd rn rm =>
    cases op <;> simp_all [special,Backend.ABIReadOnly.instruction,pureForm,pureAlu]
  | csel rd rn rm c => cases checked
  | _ => rfl

private theorem extra_special {i : MInst} (checked : extra i = true) : special i = true := by
  rcases extra_cases checked with ⟨sz,n,rfl⟩ | ⟨d,n,m,c,rfl⟩ <;> rfl

/-- Extra select forms may change NZCV, while preserving the full memory and
all non-flag world fields required by the source memory relation. -/
theorem step_flag_frame {i : MInst} (checked : extra i = true) {sb : Nat}
    {us outs : List CV} {w t : Arm.ArmState} {ctl : Ctl}
    (run : mspec sb i us w = some (outs,t,ctl)) :
    FlagFrame w t ∧ ctl = .next := by
  rw [spec_eq checked] at run
  rcases extra_cases checked with ⟨sz,n,rfl⟩ | ⟨d,n,m,c,rfl⟩
  · cases us with
    | nil => cases run
    | cons a rest =>
      cases rest with
      | cons b tail =>
        cases tail with
        | cons c rest => simp [ispec] at run
        | nil =>
          simp only [ispec,Option.some.injEq,Prod.mk.injEq] at run
          obtain ⟨rfl,rfl,rfl⟩ := run
          exact ⟨FlagFrame.write_pstate _ _,rfl⟩
      | nil =>
        simp only [ispec,Option.some.injEq,Prod.mk.injEq] at run
        obtain ⟨rfl,rfl,rfl⟩ := run
        exact ⟨FlagFrame.write_pstate _ _,rfl⟩
  · cases us with
    | nil => cases run
    | cons a rest =>
      cases rest with
      | nil => cases run
      | cons b tail =>
        cases tail with
        | cons c rest => cases run
        | nil =>
          simp only [ispec,Option.some.injEq,Prod.mk.injEq] at run
          obtain ⟨rfl,rfl,rfl⟩ := run
          exact ⟨FlagFrame.refl _,rfl⟩


/-- The executable combined boundary preserves every ABI register/memory byte,
threading the actual flag changes rather than assuming an unchanged world. -/
theorem checked_step_frame {sig : Clif.Signature} {b k : Nat} {i : MInst}
    (checked : (Backend.ABIReadOnly.instruction sig b k i || extra i) = true)
    {F : BitVec 64 → Prop} {ctx : FnCtx} {X : ExtSem}
    {us outs : List CV} {w t : Arm.ArmState} {ctl : Ctl}
    (run : sem F ctx X i us w = some (outs,t,ctl)) :
    FlagFrame w t ∧ (ctl = .next ∨ ctl = .ret) := by
  simp only [Bool.or_eq_true] at checked
  rcases checked with old | added
  · have ordinary := old_not_special old
    simp only [sem,ordinary,Bool.false_eq_true,↓reduceIte] at run
    have unchanged := ABIReadOnly.step_world old run
    subst t
    exact ⟨FlagFrame.refl _,ABIReadOnly.step_control old run⟩
  · simp only [sem,extra_special added,↓reduceIte] at run
    obtain ⟨frame,control⟩ := step_flag_frame added run
    exact ⟨frame,.inl control⟩


private theorem FlagFrame.trans {w t u : Arm.ArmState}
    (first : FlagFrame w t) (second : FlagFrame t u) : FlagFrame w u :=
  ⟨fun f h => (second.1 f h).trans (first.1 f h),
    second.2.1.trans first.2.1,second.2.2.trans first.2.2⟩

private theorem FlagFrame.regVal {w t : Arm.ArmState} (frame : FlagFrame w t) (r : Reg) :
    regVal t r = regVal w r := by
  cases r with
  | x n => exact congrArg (fun bits : BitVec 64 => bits.setWidth 128) (frame.1 (.GPR (rnum n)) (by intro fl eq; cases eq))
  | v n => exact frame.1 (.SFP (rnum n)) (by intro fl eq; cases eq)
  | _ => rfl

/-- Transfer checked flag-threaded steps with the same virtual operands,
using only the original ABI agreement and internally preserved physical reads. -/
theorem checked_step_transport {sig : Clif.Signature} {args : List Clif.Val}
    (types : args.map (·.ty) = sig.params.map (·.ty))
    {b k : Nat} {i : MInst}
    (checked : (Backend.ABIReadOnly.instruction sig b k i || extra i) = true)
    {F Z : BitVec 64 → Prop} {ctx : FnCtx} {X : ExtSem}
    {initial initial' w w' : Arm.ArmState}
    (current : FlagFrame initial w) (other : FlagFrame initial' w')
    (worlds : SameWorld Z w w')
    (registers : ∀ r v, (.reg r,v) ∈ (locsOf sig).zip args →
      regVal initial' r = regVal initial r)
    (stack : ∀ (off : Nat) (v : Clif.Val), (.stack off,v) ∈ (locsOf sig).zip args →
      ∀ j < v.ty.bytes,
      initial'.mem (Arm.r (.GPR 29#5) initial + BitVec.ofInt 64 (16+(off : Int)) + BitVec.ofNat 64 j) =
      initial.mem (Arm.r (.GPR 29#5) initial + BitVec.ofInt 64 (16+(off : Int)) + BitVec.ofNat 64 j))
    {us outs : List CV} {t : Arm.ArmState} {ctl : Ctl}
    (run : sem F ctx X i us w = some (outs,t,ctl)) :
    ∃ t', sem F ctx X i us w' = some (outs,t',ctl) ∧ SameWorld Z t t' := by
  simp only [Bool.or_eq_true] at checked
  rcases checked with old | added
  · have hs := old_not_special old
    simp only [sem,hs,Bool.false_eq_true,↓reduceIte] at run ⊢
    have fixed := ABIReadOnly.step_world old run
    subst t
    have regs : ∀ r v, (.reg r,v) ∈ (locsOf sig).zip args → regVal w' r = regVal w r := by
      intro r v member
      rw [other.regVal r,current.regVal r]
      exact registers r v member
    have bytes : ∀ (off : Nat) (v : Clif.Val), (.stack off,v) ∈ (locsOf sig).zip args →
        ∀ j < v.ty.bytes,
        w'.mem (Arm.r (.GPR 29#5) w + BitVec.ofInt 64 (16+(off : Int)) + BitVec.ofNat 64 j) =
        w.mem (Arm.r (.GPR 29#5) w + BitVec.ofInt 64 (16+(off : Int)) + BitVec.ofNat 64 j) := by
      intro off v member j bound
      rw [other.2.1,current.2.1,current.1 (.GPR 29#5) (by intro fl eq; cases eq)]
      exact stack off v member j bound
    exact ⟨w',ABIReadOnly.step_transport types old worlds regs bytes run,worlds⟩
  · have hs := extra_special added
    simp only [sem,hs,↓reduceIte] at run ⊢
    exact step_transport added worlds run

abbrev instruction := Backend.ABIReadFlags.instruction
abbrev check := Backend.ABIReadFlags.check

theorem checked_instruction {sig : Clif.Signature} {vc : VCode}
    (checked : check sig vc = true) {b k : Nat} {vb : VBlock} {i : MInst}
    (block : vc.blocks[b]? = some vb) (inst : vb.insts[k]? = some i) :
    (Backend.ABIReadOnly.instruction sig b k i || extra i) = true := by
  have bm : (vb,b) ∈ vc.blocks.toList.zipIdx :=
    List.mk_mem_zipIdx_iff_getElem?.mpr (by simpa using block)
  have im : (i,k) ∈ vb.insts.toList.zipIdx :=
    List.mk_mem_zipIdx_iff_getElem?.mpr (by simpa using inst)
  exact List.all_eq_true.mp (List.all_eq_true.mp checked (vb,b) bm) (i,k) im

/-- Both runs retain the same PC and complete virtual register file, with
related flags and original ABI reads framed throughout. -/
def Related (Z : BitVec 64 → Prop) (initial initial' : Arm.ArmState)
    (c d : VConf CV Arm.ArmState) : Prop :=
  ∃ w w', c.mapW (fun _ => w) = c ∧ d = c.mapW (fun _ => w') ∧
    FlagFrame initial w ∧ FlagFrame initial' w' ∧ SameWorld Z w w'

/-- Whole checked executions transfer one proof-internal virtual file; no
second file, final flags or execution callback is assumed. -/
theorem star_transport {sig : Clif.Signature} {args : List Clif.Val}
    (types : args.map (·.ty) = sig.params.map (·.ty))
    {vc : VCode} (checked : check sig vc = true)
    {F Z : BitVec 64 → Prop} {ctx : FnCtx} {X : ExtSem}
    {initial initial' : Arm.ArmState}
    (registers : ∀ r v, (.reg r,v) ∈ (locsOf sig).zip args →
      regVal initial' r = regVal initial r)
    (stack : ∀ (off : Nat) (v : Clif.Val), (.stack off,v) ∈ (locsOf sig).zip args →
      ∀ j < v.ty.bytes,
      initial'.mem (Arm.r (.GPR 29#5) initial + BitVec.ofInt 64 (16+(off : Int)) + BitVec.ofNat 64 j) =
      initial.mem (Arm.r (.GPR 29#5) initial + BitVec.ofInt 64 (16+(off : Int)) + BitVec.ofNat 64 j))
    {c c' d : VConf CV Arm.ArmState} (related : Related Z initial initial' c d)
    (path : Star (VStep vc (sem F ctx X)) c c') :
    ∃ d', Star (VStep vc (sem F ctx X)) d d' ∧ Related Z initial initial' c' d' := by
  induction path generalizing d with
  | refl => exact ⟨d,.refl _,related⟩
  | @step c next final first rest ih =>
    obtain ⟨w,w',fixed,rfl,current,other,worlds⟩ := related
    cases first with
    | @step b k ρ w0 vb i ops outs t ctl target hb hi hops run arity successor =>
      have eq : w0 = w := by
        have state := VConf.run.inj fixed
        exact (congrArg VState.w state).symm
      subst w0
      have supported := checked_instruction checked hb hi
      obtain ⟨t',executed,postWorlds⟩ := checked_step_transport types supported
        current other worlds registers stack run
      have post := (checked_step_frame supported run).1
      have post' := (checked_step_frame supported executed).1
      have mapped := VStep.step hb hi hops executed arity
        (vnext_map vc (fun _ => t') successor)
      have relation : Related Z initial initial' next (next.mapW (fun _ => t')) := by
        refine ⟨t,t',?_,rfl,current.trans post,other.trans post',postWorlds⟩
        cases successor <;> rfl
      obtain ⟨d',tail,final⟩ := ih relation
      exact ⟨d',.step mapped tail,final⟩


/-- Transfer the complete returned ABI values with one initial virtual file.
Final flags are related outputs, never a caller-provided or unchanged-world premise. -/
theorem return_transport {sig : Clif.Signature} {args : List Clif.Val}
    (types : args.map (·.ty) = sig.params.map (·.ty))
    {vc : VCode} (checked : check sig vc = true)
    {F Z : BitVec 64 → Prop} {ctx : FnCtx} {X : ExtSem}
    {initial initial' : Arm.ArmState} (worlds : SameWorld Z initial initial')
    (registers : ∀ r v, (.reg r,v) ∈ (locsOf sig).zip args →
      regVal initial' r = regVal initial r)
    (stack : ∀ (off : Nat) (v : Clif.Val), (.stack off,v) ∈ (locsOf sig).zip args →
      ∀ j < v.ty.bytes,
      initial'.mem (Arm.r (.GPR 29#5) initial + BitVec.ofInt 64 (16+(off : Int)) + BitVec.ofNat 64 j) =
      initial.mem (Arm.r (.GPR 29#5) initial + BitVec.ofInt 64 (16+(off : Int)) + BitVec.ofNat 64 j))
    {ρ : Nat → CV} {us : List (Reg × Reg)} {outs : List CV} {world : Arm.ArmState}
    (returned : VReturns vc (sem F ctx X) ρ initial us outs world) :
    ∃ world', VReturns vc (sem F ctx X) ρ initial' us outs world' ∧ SameWorld Z world world' := by
  obtain ⟨b,k,ρ1,w1,vb,ops,results,path,hb,hi,hops,values,run⟩ := returned
  have initialRelation : Related Z initial initial'
      (.run ⟨0,0,ρ,initial⟩) (.run ⟨0,0,ρ,initial'⟩) :=
    ⟨initial,initial',rfl,rfl,FlagFrame.refl _,FlagFrame.refl _,worlds⟩
  obtain ⟨d,path',w,w',fixed,equal,current,other,related⟩ :=
    star_transport types checked registers stack initialRelation path
  have same : w1 = w := by
    have state := VConf.run.inj fixed
    exact (congrArg VState.w state).symm
  subst w1
  obtain ⟨world',executed,finalWorlds⟩ := checked_step_transport types
    (checked_instruction checked hb hi) current other related registers stack run
  exact ⟨world',⟨b,k,ρ1,w',vb,ops,results,
    by simpa only [equal,VConf.mapW] using path',hb,hi,hops,values,executed⟩,finalWorlds⟩


private theorem FlagFrame.arguments {F : BitVec 64 → Prop} {sig : Clif.Signature}
    {args : List Clif.Val} {w t : Arm.ArmState} (frame : FlagFrame w t)
    (arguments : ArgsAtEntry F sig args w) : ArgsAtEntry F sig args t := by
  intro loc value member
  have given := arguments loc value member
  cases loc with
  | reg r =>
    change VHolds value (Backend.Proof.regVal t r)
    rw [frame.regVal r]
    exact given
  | stack off =>
    have fp := frame.1 (.GPR 29#5) (by intro fl eq; cases eq)
    change Avoids F value.ty.bytes _ ∧ _
    rw [fp]
    refine ⟨given.1,?_⟩
    have bytes := read_mem_bytes_congr (s := t) (t := w) value.ty.bytes
      (Arm.r (.GPR 29#5) w + BitVec.ofInt 64 (16+(off : Int)))
      (fun j hj => congrFun frame.2.1 _)
    rw [bytes]
    exact given.2

namespace Realize
/-- Realize each checked flag-threaded step at the existing machine boundary. -/
theorem step_realize {sig : Clif.Signature} {args : List Clif.Val}
    (types : args.map (·.ty) = sig.params.map (·.ty))
    {b k : Nat} {i : MInst}
    (checked : (Backend.ABIReadOnly.instruction sig b k i || extra i) = true)
    {F : BitVec 64 → Prop} {ctx : FnCtx} {X : ExtSem}
    {initial w t final : Arm.ArmState} (frame : FlagFrame initial w)
    (arguments : ArgsAtEntry F sig args initial) (worlds : SameWorld F t w)
    (entry : k = 0 → t = w) {us outs : List CV} {ctl : Ctl}
    (executed : sem F ctx X i us w = some (outs,final,ctl)) :
    ∃ actual, valueSem F ctx X i us t = some (outs,actual,ctl) ∧ SameWorld F actual final := by
  simp only [Bool.or_eq_true] at checked
  rcases checked with old | added
  · simp only [sem,old_not_special old,Bool.false_eq_true,↓reduceIte] at executed
    have unchanged := ABIReadOnly.step_world old executed
    subst final
    exact ABIReadOnly.step_realize types old (frame.arguments arguments) worlds entry executed
  · simp only [sem,extra_special added,↓reduceIte] at executed
    exact E2E.MixedFlagBoundary.step_realize added worlds executed

def Related (F : BitVec 64 → Prop) (initial : Arm.ArmState)
    (c d : VConf CV Arm.ArmState) : Prop :=
  ∃ w t, c.mapW (fun _ => w) = c ∧ d = c.mapW (fun _ => t) ∧
    FlagFrame initial w ∧ SameWorld F t w ∧
    ∀ vs, c = .run vs → vs.k = 0 → t = w

private theorem realize_step {sig : Clif.Signature} {args : List Clif.Val}
    (types : args.map (·.ty) = sig.params.map (·.ty))
    {vc : VCode} (checked : check sig vc = true)
    {F : BitVec 64 → Prop} {ctx : FnCtx} {X : ExtSem} {initial : Arm.ArmState}
    (arguments : ArgsAtEntry F sig args initial)
    {c c' d : VConf CV Arm.ArmState} (related : Related F initial c d)
    (step : VStep vc (sem F ctx X) c c') :
    ∃ d', VStep vc (valueSem F ctx X) d d' ∧ Related F initial c' d' := by
  obtain ⟨w,t,fixed,rfl,frame,worlds,entry⟩ := related
  cases step with
  | @step b k ρ w0 vb i ops outs w1 ctl target hb hi hops run arity successor =>
    have eq : w0 = w := by
      have state := VConf.run.inj fixed
      exact (congrArg VState.w state).symm
    subst w0
    have supported := checked_instruction checked hb hi
    obtain ⟨t',realized,related'⟩ := step_realize types supported frame arguments worlds (entry _ rfl) run
    have preserved := (checked_step_frame supported run).1
    refine ⟨c'.mapW (fun _ => t'),
      VStep.step hb hi hops realized arity (vnext_map vc (fun _ => t') successor),?_⟩
    have control := (checked_step_frame supported run).2
    cases successor with
    | next hk =>
      refine ⟨w1,t',rfl,rfl,frame.trans preserved,related',?_⟩
      intro vs eq zero
      cases eq
      change k+1=0 at zero
      omega
    | goto => rcases control with control | control <;> cases control
    | ret => exact ⟨w1,t',rfl,rfl,frame.trans preserved,related',fun vs eq => by cases eq⟩
    | halt => rcases control with control | control <;> cases control

theorem star_realize {sig : Clif.Signature} {args : List Clif.Val}
    (types : args.map (·.ty) = sig.params.map (·.ty))
    {vc : VCode} (checked : check sig vc = true)
    {F : BitVec 64 → Prop} {ctx : FnCtx} {X : ExtSem} {initial : Arm.ArmState}
    (arguments : ArgsAtEntry F sig args initial)
    {c c' d : VConf CV Arm.ArmState} (related : Related F initial c d)
    (path : Star (VStep vc (sem F ctx X)) c c') :
    ∃ d', Star (VStep vc (valueSem F ctx X)) d d' ∧ Related F initial c' d' := by
  induction path generalizing d with
  | refl => exact ⟨d,.refl _,related⟩
  | step first rest ih =>
    obtain ⟨d1,first',related'⟩ := realize_step types checked arguments related first
    obtain ⟨d',tail,final⟩ := ih related'
    exact ⟨d',.step first' tail,final⟩

/-- Complete realization preserves exact virtual definitions/ABI pins and the
actual final flags, without requiring the final source world to equal entry. -/
theorem return_realize {sig : Clif.Signature} {args : List Clif.Val}
    (types : args.map (·.ty) = sig.params.map (·.ty))
    {vc : VCode} (checked : check sig vc = true)
    {F : BitVec 64 → Prop} {ctx : FnCtx} {X : ExtSem} {initial : Arm.ArmState}
    (arguments : ArgsAtEntry F sig args initial)
    {ρ : Nat → CV} {us : List (Reg × Reg)} {outs : List CV} {world : Arm.ArmState}
    (returned : VReturns vc (sem F ctx X) ρ initial us outs world) :
    ∃ t, VReturns vc (valueSem F ctx X) ρ initial us outs t ∧ SameWorld F t world := by
  obtain ⟨b,k,ρ1,w1,vb,ops,results,path,hb,hi,hops,values,run⟩ := returned
  have start : Related F initial (.run ⟨0,0,ρ,initial⟩) (.run ⟨0,0,ρ,initial⟩) :=
    ⟨initial,initial,rfl,rfl,FlagFrame.refl _,SameWorld.refl _ _,fun _ _ _ => rfl⟩
  obtain ⟨d,path',w,t,fixed,equal,frame,worlds,entry⟩ := star_realize types checked arguments start path
  have same : w1 = w := by
    have state := VConf.run.inj fixed
    exact (congrArg VState.w state).symm
  subst w1
  obtain ⟨t',realized,related⟩ := step_realize types (checked_instruction checked hb hi)
    frame arguments worlds (entry _ rfl) run
  exact ⟨t',⟨b,k,ρ1,t,vb,ops,results,
    by simpa only [equal,VConf.mapW] using path',hb,hi,hops,values,realized⟩,related⟩
end Realize
/-- The existing checked preparation/allocation machine consumer realizes the
read-only run in either cleanup mode, including a wider non-interference world.
Initial virtual values stay proof-internal in the complete source consumer. -/
theorem machine_return {f : Clif.Function} {args : List Clif.Val}
    (types : args.map (·.ty) = f.sig.params.map (·.ty))
    {vc vcp : VCode} {rf : RFunc} {af : AFunc} {fa : FnAsm} {fb : FnBin} {k : Nat}
    {cleanup : Bool} (readOnly : check f.sig vc = true)
    (prep : prepCheck (Stock.Arithmetic.stage cleanup vc) vcp = true)
    (check : checkAlloc vcp rf = .ok ()) (alloc : lowerRFunc vcp rf = .ok af)
    (emit : emitFunc k af = .ok fa) (layout : fa.layout = .ok fb)
    {X : ExtSem} {K : Nat} {F Z : BitVec 64 → Prop}
    (frame : ∀ a, F a → Z a) (covered : FormsCovered ⟨fa.k,af.slotBase⟩ vcp)
    {w final reference : Arm.ArmState} (arguments : ArgsAtEntry F f.sig args w)
    (worlds : SameWorld Z final reference)
    {ρ : Nat → CV} {us : List (Reg × Reg)} {outs : List CV}
    (returned : VReturns vc (sem F ⟨fa.k,af.slotBase⟩ X) ρ w us outs final)
    (H : ArmHooks) (G : BitVec 64 → Prop) (base ra : BitVec 64) (s : Arm.ArmState)
    (entry : ActEntry vcp rf af fa fb K F G X H base ra s w) :
    ∃ n, ActRet ra Z G us outs reference s (runX (ArmStepX X H fa) n s) ∧
      PostTrace fa af base (ArmStepX X H fa) s n ∧
      ∀ i < n, actGoodX vcp rf af fa fb base s X H K G (GotV vcp)
        (runX (ArmStepX X H fa) i s) := by
  obtain ⟨t,valueRun,related⟩ := Realize.return_realize types readOnly arguments returned
  have finalWorld := (SameWorld.mono frame related).trans worlds
  have prepared := StockArithmeticStage_returns prep valueRun
  have machine := regLevelCorrect_worldX_value check alloc emit layout
    (X := X) (H := H) (K := K) (G := G) (gv := GotV vcp)
    covered entry.abi entry.stack entry.gfree (by rw [entry.hF]; exact entry.calls)
    (by rw [entry.hF]; exact entry.tries) (by rw [entry.hF]; exact entry.tls)
    (by rw [entry.hF]; exact entry.body) ρ
  rw [entry.hF] at machine
  obtain ⟨n,⟨h1,h2,h3,h4,h5,h6,h7⟩,h8⟩ :=
    machine.1 us outs t (vReturns_gotV_value prepared)
  refine ⟨n,⟨h1,h2,?_,?_,h5,h6⟩,h7,h8⟩
  · intro a outside
    rw [h3 a (fun hf => outside (frame a hf))]
    exact finalWorld.2.1 a outside
  · intro field unmasked fp sp
    rw [h4 field unmasked fp sp]
    exact finalWorld.1 field unmasked


end E2E.MixedFlagBoundary

namespace E2E
open Backend Backend.Proof Backend.Proof.Driver Backend.Stock.Proof Backend.DeadCleanup
set_option autoImplicit false
set_option Elab.async false

/-- Complete source-to-machine non-interference for actual Stock arithmetic.
The runtime ABI-read check derives the read boundary; no legacy lowering verdict,
second chosen virtual file or extra source-value assumption is needed. -/
theorem backend_correct_world_niX_stock_mixed {p : Clif.Program} {f : Clif.Function} {k : Nat} {result : Stock.Result} {vcp : VCode}
    {rf : RFunc} {af : AFunc} {fa : FnAsm} {fb : FnBin}
    (domain : Stock.Mixed.Domain f) {cleanup : Bool}
    (readOnly : E2E.MixedFlagBoundary.check f.sig result.code = true)
    (hc : CompiledStockArithmeticStage f cleanup k result vcp rf af fa fb)
    {X : ExtSem} {syms : String → Option Nat} {slotOff : Nat} {env : Clif.Env} {K : Nat}
    {F : BitVec 64 → Prop} {c : BitVec 64}
    (hcov : FormsCovered ⟨fa.k, af.slotBase⟩ vcp)
    (hsym : ∀ n b, syms n = some b → X.sym n 0 = BitVec.ofNat 64 b)
    (hslot : af.slotBase = slotOff)
    {w₀ : Arm.ArmState} {args : List Clif.Val} {cs : Clif.State}
    (hcs : ClifEntry f args cs)
    (hrel : RelW ⟨F, syms, slotOff, (RAFrame.compute vcp rf).intBase⟩ f c cs.frame.slots cs.mem w₀)
    (hargs : ArgsAtEntry F f.sig args w₀)
    (fuel : Nat) :
    ∀ vals cm, Clif.runLoop env p fuel cs = .returned vals cm →
      ∃ (us : List (Reg × Reg)) (outs : List CV) (w : Arm.ArmState),
        us.map (·.2) = (List.range us.length).map Reg.x ∧ us.length = outs.length ∧
        PrefixHold vals outs ∧ MemRel F syms cm w ∧ result.code.RetsSite us ∧
        (∀ (H : ArmHooks) (G : BitVec 64 → Prop) (base ra : BitVec 64) (s : Arm.ArmState),
          ActEntry vcp rf af fa fb K F G X H base ra s w₀ →
          ∃ n, ActRet ra F G us outs w s (runX (ArmStepX X H fa) n s) ∧
            PostTrace fa af base (ArmStepX X H fa) s n ∧
            ∀ i < n, actGoodX vcp rf af fa fb base s X H K G (GotV vcp)
              (runX (ArmStepX X H fa) i s)) ∧
        (∀ (D : BitVec 64 → Prop) (w₀' : Arm.ArmState),
          RelW ⟨F, syms, slotOff, (RAFrame.compute vcp rf).intBase⟩ f c cs.frame.slots cs.mem w₀' →
          SameWorld (fun b => F b ∨ D b) w₀ w₀' →
          (∀ r v, (ArgLoc.reg r, v) ∈ (locsOf f.sig).zip args → regVal w₀' r = regVal w₀ r) →
          (∀ off v, (ArgLoc.stack off, v) ∈ (locsOf f.sig).zip args → ∀ k < v.ty.bytes,
            w₀'.mem (Arm.r (.GPR 29#5) w₀ + BitVec.ofInt 64 (16 + (off : Int)) + BitVec.ofNat 64 k) =
              w₀.mem (Arm.r (.GPR 29#5) w₀ + BitVec.ofInt 64 (16 + (off : Int)) + BitVec.ofNat 64 k)) →
          ∀ (H : ArmHooks) (G : BitVec 64 → Prop) (base ra : BitVec 64) (s : Arm.ArmState),
            ActEntry vcp rf af fa fb K F G X H base ra s w₀' →
            ∃ n, ActRet ra (fun a => F a ∨ D a) G us outs w s (runX (ArmStepX X H fa) n s) ∧
              PostTrace fa af base (ArmStepX X H fa) s n ∧
              ∀ i < n, actGoodX vcp rf af fa fb base s X H K G (GotV vcp)
                (runX (ArmStepX X H fa) i s)) := by
  intro vals cm returned
  obtain ⟨b,xs,blocks,ret,family⟩ := domain.shape
  have state : (⟨cs.frame,[],cs.mem⟩ : Clif.State) = cs := by
    have callers := hcs.callers
    cases cs
    cases callers
    rfl
  obtain ⟨ρ,source⟩ := MixedBody.actual_mixed_entry_return_refines_frame
    hc.lower domain.scope domain.dominated domain.abi blocks family ret hcs.stockSourceEntry
    (by rwa [state]) (MixedFlagBoundary.refines F ⟨fa.k,af.slotBase⟩ X)
    (MixedFlagBoundary.driver F ⟨fa.k,af.slotBase⟩ X)
    (MixedFlagBoundary.memory F ⟨fa.k,af.slotBase⟩ X hslot hsym)
    (mrStable_relW ⟨F,syms,slotOff,(RAFrame.compute vcp rf).intBase⟩ f c) hrel hargs
  obtain ⟨us,outs,w,cm0,reached,pins,arity,values,memory,freed⟩ := source
  have site : result.code.RetsSite us := by
    obtain ⟨b,k,ρ,w₁,vb,ops,outs',_,hvb,hk,_⟩ := reached
    exact ⟨b,vb,k,hvb,hk⟩
  have mem : MemRel F syms cm w := by
    rw [freed]
    exact memRel_leave (memRel_free memory.1.1 _)
  refine ⟨us,outs,w,pins.ordinary domain.ordinary,arity,values,mem,site,?_,?_⟩
  · intro H G base ra s he
    exact MixedFlagBoundary.machine_return (f := f) hcs.sig readOnly hc.prepOk hc.check hc.alloc hc.emit hc.layout
      (fun _ h => h) hcov hargs (SameWorld.refl F w) reached H G base ra s he
  · intro D w₀' hrel' hsw hreg hstk H G base ra s he
    have arguments := ABIReadOnly.arguments_transport hargs hsw hreg hstk
    obtain ⟨otherWorld,other,relatedWorlds⟩ :=
      MixedFlagBoundary.return_transport hcs.sig readOnly hsw hreg hstk reached
    exact MixedFlagBoundary.machine_return (f := f) hcs.sig readOnly hc.prepOk hc.check hc.alloc hc.emit hc.layout
      (fun _ h => Or.inl h) hcov arguments relatedWorlds.symm other H G base ra s he

end E2E

namespace Backend.SemanticNI
set_option autoImplicit false

/-- Keep the legacy lowering verdict, or validate actual Stock provenance and
its finite ABI read boundary. No proof object is supplied by the input. -/
def check (f : Clif.Function) (vc : VCode) : Bool :=
  Proof.Driver.lowerCheck f vc ||
    ((Stock.Arithmetic.check f vc && ABIReadOnly.check f.sig vc) ||
      (Stock.Mixed.check f vc && ABIReadFlags.check f.sig vc))

end Backend.SemanticNI

namespace E2E
open Backend Backend.Proof Backend.Proof.Driver
set_option autoImplicit false
set_option Elab.async false

/-- Fully paired semantic artifact. The executable checker derives the raw
Stock read boundary while all old production artifacts retain their contracts. -/
inductive CompiledSemanticNI (f : Clif.Function) (k : Nat) (vc vcp : VCode)
    (rf : RFunc) (af : AFunc) (fa : FnAsm) (fb : FnBin) : Prop where
  | compatible : CompiledProduction f k vc vcp rf af fa fb →
      CompiledSemanticNI f k vc vcp rf af fa fb
  | arithmetic {cleanup : Bool} {result : Stock.Result} :
      Stock.Arithmetic.Domain f → result.code = vc → ABIReadOnly.check f.sig vc = true →
      CompiledStockArithmeticStage f cleanup k result vcp rf af fa fb →
      CompiledSemanticNI f k vc vcp rf af fa fb
  | mixed {cleanup : Bool} {result : Stock.Result} :
      Stock.Mixed.Domain f → result.code = vc → ABIReadFlags.check f.sig vc = true →
      CompiledStockArithmeticStage f cleanup k result vcp rf af fa fb →
      CompiledSemanticNI f k vc vcp rf af fa fb

namespace CompiledSemanticNI
variable {f : Clif.Function} {k : Nat} {vc vcp : VCode} {rf : RFunc}
  {af : AFunc} {fa : FnAsm} {fb : FnBin}

/-- Forgetting paired execution retains the published semantic contract. -/
theorem toSemantic (hc : CompiledSemanticNI f k vc vcp rf af fa fb) :
    CompiledSemantic f k vc vcp rf af fa fb := by
  cases hc with
  | compatible h => exact .compatible h
  | arithmetic domain equal _ h => exact .arithmetic domain equal h
  | mixed domain equal _ h => exact .mixed domain equal h

/-- All new semantic and paired premises come from executable checks and actual
pipeline observations, rather than new accepted-source assumptions. -/
theorem of_checks {cleanup : Bool} (lower : SemanticNI.check f vc = true)
    (prepared : Backend.prepare (Stock.Arithmetic.stage cleanup vc) = .ok vcp)
    (prepOk : prepCheck (Stock.Arithmetic.stage cleanup vc) vcp = true)
    (check : Backend.checkAlloc vcp rf = .ok ()) (alloc : lowerRFunc vcp rf = .ok af)
    (emit : emitFunc k af = .ok fa) (layout : fa.layout = .ok fb) :
    CompiledSemanticNI f k vc vcp rf af fa fb := by
  have retained (legacy : lowerCheck f vc = true) : CompiledProduction f k vc vcp rf af fa fb := by
    cases cleanup with
    | false =>
      exact .stock ⟨⟨legacy,prepared,prepOk,allocChecked_of_checkAlloc check,alloc,emit,layout⟩,check⟩
    | true =>
      exact .stockCleanup ⟨⟨legacy,prepared,prepOk,allocChecked_of_checkAlloc check,alloc,emit,layout⟩,check⟩
  simp only [SemanticNI.check,Bool.or_eq_true,Bool.and_eq_true] at lower
  rcases lower with legacy | ⟨semantic,reads⟩ | ⟨semantic,reads⟩
  · exact .compatible (retained legacy)
  · rcases Stock.Arithmetic.check_sound semantic with legacy | ⟨result,domain,run,equal,_⟩
    · exact .compatible (retained legacy)
    · exact .arithmetic domain equal reads
        ⟨run,by rwa [equal],by rwa [equal],check,alloc,emit,layout⟩
  · obtain ⟨result,domain,run,equal,_⟩ := Stock.Mixed.check_sound semantic
    exact .mixed domain equal reads
      ⟨run,by rwa [equal],by rwa [equal],check,alloc,emit,layout⟩

end CompiledSemanticNI

/-- The complete paired linker consumer follows the actual checked artifact,
retaining the old external, source, ABI and activation interfaces. -/
theorem backend_correct_world_niX_semantic {p : Clif.Program} {f : Clif.Function} {k : Nat} {vc vcp : VCode}
    {rf : RFunc} {af : AFunc} {fa : FnAsm} {fb : FnBin}
    (hsub : InSubset p f) (hc : CompiledSemanticNI f k vc vcp rf af fa fb)
    {X : ExtSem} {syms : String → Option Nat} {slotOff : Nat} {env : Clif.Env} {K : Nat}
    {F : BitVec 64 → Prop} {c : BitVec 64}
    (hcov : FormsCovered ⟨fa.k, af.slotBase⟩ vcp)
    (hX : XCallsOk env (f.externs.map (·.2))
      (RelW ⟨F, syms, slotOff, (RAFrame.compute vcp rf).intBase⟩ f c) X)
    (hXI : XCallsIndOk env (indSigs f)
      (RelW ⟨F, syms, slotOff, (RAFrame.compute vcp rf).intBase⟩ f c) X)
    (hsym : ∀ n b, syms n = some b → X.sym n 0 = BitVec.ofNat 64 b)
    (hslot : af.slotBase = slotOff)
    {w₀ : Arm.ArmState} {args : List Clif.Val} {cs : Clif.State}
    (hcs : ClifEntry f args cs)
    (hrel : RelW ⟨F, syms, slotOff, (RAFrame.compute vcp rf).intBase⟩ f c cs.frame.slots cs.mem w₀)
    (hargs : ArgsAtEntry F f.sig args w₀)
    (htr : TrapsExplicit env p cs) (fuel : Nat) :
    ∀ vals cm, Clif.runLoop env p fuel cs = .returned vals cm →
      ∃ (us : List (Reg × Reg)) (outs : List CV) (w : Arm.ArmState),
        us.map (·.2) = (List.range us.length).map Reg.x ∧ us.length = outs.length ∧
        PrefixHold vals outs ∧ MemRel F syms cm w ∧ vc.RetsSite us ∧
        (∀ (H : ArmHooks) (G : BitVec 64 → Prop) (base ra : BitVec 64) (s : Arm.ArmState),
          ActEntry vcp rf af fa fb K F G X H base ra s w₀ →
          ∃ n, ActRet ra F G us outs w s (runX (ArmStepX X H fa) n s) ∧
            PostTrace fa af base (ArmStepX X H fa) s n ∧
            ∀ i < n, actGoodX vcp rf af fa fb base s X H K G (GotV vcp)
              (runX (ArmStepX X H fa) i s)) ∧
        (XNI F syms (f.externs.map (·.2)) (indSigs f) c
          (CallLg env (f.externs.map (·.2)) (indSigs f)) X → XTls F X →
        ∀ (D : BitVec 64 → Prop) (w₀' : Arm.ArmState),
          RelW ⟨F, syms, slotOff, (RAFrame.compute vcp rf).intBase⟩ f c cs.frame.slots cs.mem w₀' →
          SameWorld (fun b => F b ∨ D b) w₀ w₀' →
          (∀ r v, (ArgLoc.reg r, v) ∈ (locsOf f.sig).zip args → regVal w₀' r = regVal w₀ r) →
          (∀ off v, (ArgLoc.stack off, v) ∈ (locsOf f.sig).zip args → ∀ k < v.ty.bytes,
            w₀'.mem (Arm.r (.GPR 29#5) w₀ + BitVec.ofInt 64 (16 + (off : Int)) + BitVec.ofNat 64 k) =
              w₀.mem (Arm.r (.GPR 29#5) w₀ + BitVec.ofInt 64 (16 + (off : Int)) + BitVec.ofNat 64 k)) →
          ∀ (H : ArmHooks) (G : BitVec 64 → Prop) (base ra : BitVec 64) (s : Arm.ArmState),
            ActEntry vcp rf af fa fb K F G X H base ra s w₀' →
            ∃ n, ActRet ra (fun a => F a ∨ D a) G us outs w s (runX (ArmStepX X H fa) n s) ∧
              PostTrace fa af base (ArmStepX X H fa) s n ∧
              ∀ i < n, actGoodX vcp rf af fa fb base s X H K G (GotV vcp)
                (runX (ArmStepX X H fa) i s)) := by
  cases hc with
  | compatible h =>
    exact backend_correct_world_niX_production hsub h hcov hX hXI hsym hslot hcs hrel hargs htr fuel
  | arithmetic domain equal reads h =>
    subst vc
    intro vals cm returned
    obtain ⟨us,outs,w,pins,arity,values,memory,site,base,paired⟩ :=
      backend_correct_world_niX_stock_arithmetic domain reads h hcov hsym hslot hcs hrel hargs
        fuel vals cm returned
    exact ⟨us,outs,w,pins,arity,values,memory,site,base,fun _ _ => paired⟩
  | mixed domain equal reads h =>
    subst vc
    intro vals cm returned
    obtain ⟨us,outs,w,pins,arity,values,memory,site,base,paired⟩ :=
      backend_correct_world_niX_stock_mixed domain reads h hcov hsym hslot hcs hrel hargs
        fuel vals cm returned
    exact ⟨us,outs,w,pins,arity,values,memory,site,base,fun _ _ => paired⟩

end E2E

namespace E2E
open Backend Backend.Proof Backend.Proof.Driver
set_option autoImplicit false
set_option Elab.async false

namespace CompiledSemanticNI
variable {f : Clif.Function} {k : Nat} {vc vcp : VCode} {rf : RFunc}
  {af : AFunc} {fa : FnAsm} {fb : FnBin}

theorem check (hc : CompiledSemanticNI f k vc vcp rf af fa fb) : Backend.checkAlloc vcp rf = .ok () :=
  hc.toSemantic.check

theorem alloc (hc : CompiledSemanticNI f k vc vcp rf af fa fb) : lowerRFunc vcp rf = .ok af :=
  hc.toSemantic.alloc

theorem emit (hc : CompiledSemanticNI f k vc vcp rf af fa fb) : emitFunc k af = .ok fa :=
  hc.toSemantic.emit

theorem layout (hc : CompiledSemanticNI f k vc vcp rf af fa fb) : fa.layout = .ok fb :=
  hc.toSemantic.layout

/-- Integer source scope and ABI correctness give the entry locations needed
by whole-program linking; a raw Stock artifact needs no legacy lowerCheck. -/
theorem entryRegs (hc : CompiledSemanticNI f k vc vcp rf af fa fb) :
    ∀ l ∈ locsOf f.sig, ∀ r, l = .reg r → ∃ n, r = .x n ∧ n ≤ 8 := by
  cases hc with
  | compatible h => exact entryRegs_of_check h.lowerOk
  | arithmetic domain equal reads h =>
    intro loc member r located
    have regs := (Spill.locsOf_regs (functionE_sig_int domain.scope.subsetE).1
      (Spill.sret_le_of_sigAbiOk domain.abi)).2
    have found : r ∈ Spill.locRegs (locsOf f.sig) :=
      List.mem_filterMap.mpr ⟨loc,member,by rw [located]⟩
    obtain ⟨n,bound,pin⟩ := regs r found
    exact ⟨n,pin,bound⟩

  | mixed domain equal reads h =>
    intro loc member r located
    have regs := (Spill.locsOf_regs (functionE_sig_int domain.scope.subsetE).1
      (Spill.sret_le_of_sigAbiOk domain.abi)).2
    have found : r ∈ Spill.locRegs (locsOf f.sig) :=
      List.mem_filterMap.mpr ⟨loc,member,by rw [located]⟩
    obtain ⟨n,bound,pin⟩ := regs r found
    exact ⟨n,pin,bound⟩

/-- An ABI-read-only artifact contains no TLS helper; cleanup and checked
preparation preserve that exclusion. -/
theorem noTls {sig : Clif.Signature} {code : VCode}
    (checked : Backend.ABIReadOnly.check sig code = true) : code.hasTls = false := by
  rw [VCode.hasTls,Array.any_eq_false']
  intro vb member
  apply Bool.eq_false_iff.mp
  apply Array.any_eq_false'.mpr
  intro i member'
  obtain ⟨b,hb⟩ := List.mem_iff_getElem?.mp (Array.mem_toList_iff.mpr member)
  obtain ⟨k,hi⟩ := List.mem_iff_getElem?.mp (Array.mem_toList_iff.mpr member')
  have supported := ABIReadOnly.checked_instruction checked (by simpa using hb) (by simpa using hi)
  cases i <;> simp_all [Backend.ABIReadOnly.instruction,Backend.DeadCleanup.pureForm]

theorem noTlsFlags {sig : Clif.Signature} {code : VCode}
    (checked : Backend.ABIReadFlags.check sig code = true) : code.hasTls = false := by
  rw [VCode.hasTls,Array.any_eq_false']
  intro vb member
  apply Bool.eq_false_iff.mp
  apply Array.any_eq_false'.mpr
  intro i member'
  obtain ⟨b,hb⟩ := List.mem_iff_getElem?.mp (Array.mem_toList_iff.mpr member)
  obtain ⟨k,hi⟩ := List.mem_iff_getElem?.mp (Array.mem_toList_iff.mpr member')
  have supported := MixedFlagBoundary.checked_instruction checked (by simpa using hb) (by simpa using hi)
  cases i <;> simp_all [Backend.ABIReadOnly.instruction,Backend.DeadCleanup.pureForm,Backend.ABIReadFlags.extra]

end CompiledSemanticNI

/-- The existing whole-program TLS contract also applies to paired semantic
artifacts; the new pure arithmetic route has no TLS instructions. -/
theorem hasTls_of_vcode_semantic {f : Clif.Function} {k : Nat} {vc vcp : VCode}
    {rf : RFunc} {af : AFunc} {fa : FnAsm} {fb : FnBin}
    (hc : CompiledSemanticNI f k vc vcp rf af fa fb) (ht : vcp.hasTls = true) : hasTls f = true := by
  cases hc with
  | compatible h => exact hasTls_of_vcode_production h ht
  | @arithmetic cleanup result domain equal reads h =>
    have raw := CompiledSemanticNI.noTls reads
    have staged : (Stock.Arithmetic.stage cleanup result.code).hasTls = false := by
      rw [equal]
      cases cleanup with
      | false => exact raw
      | true => exact Backend.DeadCleanup.prune_noTls raw
    have prepared := noTls_of_prepCheck h.prepOk staged
    rw [prepared] at ht
    cases ht

  | @mixed cleanup result domain equal reads h =>
    have raw := CompiledSemanticNI.noTlsFlags reads
    have staged : (Stock.Arithmetic.stage cleanup result.code).hasTls = false := by
      rw [equal]
      cases cleanup with
      | false => exact raw
      | true => exact Backend.DeadCleanup.prune_noTls raw
    have prepared := noTls_of_prepCheck h.prepOk staged
    rw [prepared] at ht
    cases ht

/-- Stack-argument avoidance follows from actual physical allocation and the
original hardware ABI entry; lowering provenance is irrelevant to the bound. -/
theorem stackArgsAvoid_frameW_semantic {f : Clif.Function} {k : Nat} {vc vcp : VCode} {rf : RFunc}
    {af : AFunc} {fa : FnAsm} {fb : FnBin} (hc : CompiledSemanticNI f k vc vcp rf af fa fb) {K : Nat}
    {s : Arm.ArmState} {base ra : BitVec 64} {args : List Clif.Val} (hres : StackAvail K af s)
    (_hent : AbiEntry fb base ra s) (hargs : ArgsIn f.sig args s) :
    StackArgsAvoid (frameW K (RAFrame.compute vcp rf).intBase (RAFrame.compute vcp rf).size af s)
      f.sig args s := by
  intro off v hm j hj hF
  have h := hargs _ _ hm
  simp only at h
  have hframe := lowerRFunc_frame hc.alloc
  have hfs := (lowerRFunc_ok hc.alloc).1.1
  have hD : frameDrop af = af.frameSize + 16 := by simp [frameDrop, hframe]
  have hsz : (RAFrame.compute vcp rf).size ≤ af.frameSize := by
    rw [hfs]; simp only [RAFrame.compute]
    exact Nat.le_trans (Nat.le_add_right _ _) (le_alignTo _ 16 (by decide))
  have hsp := hres.1
  have hfit := h.fits
  have hx : (spv s + BitVec.ofNat 64 off + BitVec.ofNat 64 j -
      (spv s - BitVec.ofNat 64 (frameDrop af))).toNat = off + j + frameDrop af := by
    rw [hD]
    bv_omega
  rcases hF with (⟨-, h2⟩ | ⟨-, h2⟩ | hcode) | ⟨hlt, -⟩
  · rw [hx] at h2; omega
  · rw [hx] at h2; omega
  · have e : spv s + BitVec.ofNat 64 off + BitVec.ofNat 64 j = spv s + BitVec.ofNat 64 (off + j) := by
      rw [BitVec.add_assoc]; congr 1
      apply BitVec.eq_of_toNat_eq; simp [BitVec.toNat_add]
    rw [e] at hcode
    exact h.noCode j hj hcode
  · rw [(spBody_toNat hres).1] at hlt
    have : (spv s + BitVec.ofNat 64 off + BitVec.ofNat 64 j).toNat = (spv s).toNat + off + j := by
      bv_omega
    omega


theorem backend_correct_world_semantic {p : Clif.Program} {f : Clif.Function} {k : Nat} {vc vcp : VCode}
    {rf : RFunc} {af : AFunc} {fa : FnAsm} {fb : FnBin}
    (hsub : InSubset p f) (hc : CompiledSemanticNI f k vc vcp rf af fa fb)
    {X : ExtSem} {syms : String → Option Nat} {slotOff : Nat} {env : Clif.Env} {K : Nat}
    {F : BitVec 64 → Prop} {c : BitVec 64}
    (hcov : FormsCovered ⟨fa.k, af.slotBase⟩ vcp)
    (hX : XCallsOk env (f.externs.map (·.2))
      (RelW ⟨F, syms, slotOff, (RAFrame.compute vcp rf).intBase⟩ f c) X)
    (hXI : XCallsIndOk env (indSigs f)
      (RelW ⟨F, syms, slotOff, (RAFrame.compute vcp rf).intBase⟩ f c) X)
    (hsym : ∀ n b, syms n = some b → X.sym n 0 = BitVec.ofNat 64 b)
    (hslot : af.slotBase = slotOff)
    {w₀ : Arm.ArmState} {args : List Clif.Val} {cs : Clif.State}
    (hcs : ClifEntry f args cs)
    (hrel : RelW ⟨F, syms, slotOff, (RAFrame.compute vcp rf).intBase⟩ f c cs.frame.slots cs.mem w₀)
    (hargs : ArgsAtEntry F f.sig args w₀)
    (htr : TrapsExplicit env p cs) (fuel : Nat) :
    (∀ vals cm, Clif.runLoop env p fuel cs = .returned vals cm →
      ∃ (us : List (Reg × Reg)) (outs : List CV) (w : Arm.ArmState),
        us.map (·.2) = (List.range us.length).map Reg.x ∧ us.length = outs.length ∧
        PrefixHold vals outs ∧ MemRel F syms cm w ∧ vc.RetsSite us ∧
        ∀ (H : ArmHooks) (G : BitVec 64 → Prop) (base ra : BitVec 64) (s : Arm.ArmState),
          ActEntry vcp rf af fa fb K F G X H base ra s w₀ →
          ∃ n, ActRet ra F G us outs w s (runX (ArmStepX X H fa) n s) ∧
            PostTrace fa af base (ArmStepX X H fa) s n) ∧
    (∀ c', Clif.runLoop env p fuel cs = .trapped c' →
      ∀ (H : ArmHooks) (G : BitVec 64 → Prop) (base ra : BitVec 64) (s : Arm.ArmState),
        ActEntry vcp rf af fa fb K F G X H base ra s w₀ →
        ∃ n, TrapAt fb base c' (runX (ArmStepX X H fa) n s)) := by
  have both := backend_correct_worldX_semantic (K := K) hsub hc.toSemantic hcov hX hXI hsym hslot hcs hrel hargs htr fuel
  refine ⟨fun vals cm returned => ?_,fun code trapped H G base ra s entry => ?_⟩
  · obtain ⟨us,outs,w,pins,arity,values,memory,site,run⟩ := both.1 vals cm returned
    refine ⟨us,outs,w,pins,arity,values,memory,site,?_⟩
    intro H G base ra s entry
    obtain ⟨n,ret,trace,_⟩ := run H G base ra s entry
    exact ⟨n,ret,trace⟩
  · obtain ⟨n,trap,_⟩ := both.2 code trapped H G base ra s entry
    exact ⟨n,trap⟩

theorem backend_correct_world_ni_semantic {p : Clif.Program} {f : Clif.Function} {k : Nat} {vc vcp : VCode}
    {rf : RFunc} {af : AFunc} {fa : FnAsm} {fb : FnBin}
    (hsub : InSubset p f) (hc : CompiledSemanticNI f k vc vcp rf af fa fb)
    {X : ExtSem} {syms : String → Option Nat} {slotOff : Nat} {env : Clif.Env} {K : Nat}
    {F : BitVec 64 → Prop} {c : BitVec 64}
    (hcov : FormsCovered ⟨fa.k, af.slotBase⟩ vcp)
    (hX : XCallsOk env (f.externs.map (·.2))
      (RelW ⟨F, syms, slotOff, (RAFrame.compute vcp rf).intBase⟩ f c) X)
    (hXI : XCallsIndOk env (indSigs f)
      (RelW ⟨F, syms, slotOff, (RAFrame.compute vcp rf).intBase⟩ f c) X)
    (hsym : ∀ n b, syms n = some b → X.sym n 0 = BitVec.ofNat 64 b)
    (hslot : af.slotBase = slotOff)
    {w₀ : Arm.ArmState} {args : List Clif.Val} {cs : Clif.State}
    (hcs : ClifEntry f args cs)
    (hrel : RelW ⟨F, syms, slotOff, (RAFrame.compute vcp rf).intBase⟩ f c cs.frame.slots cs.mem w₀)
    (hargs : ArgsAtEntry F f.sig args w₀)
    (htr : TrapsExplicit env p cs) (fuel : Nat) :
    ∀ vals cm, Clif.runLoop env p fuel cs = .returned vals cm →
      ∃ (us : List (Reg × Reg)) (outs : List CV) (w : Arm.ArmState),
        us.map (·.2) = (List.range us.length).map Reg.x ∧ us.length = outs.length ∧
        PrefixHold vals outs ∧ MemRel F syms cm w ∧ vc.RetsSite us ∧
        (∀ (H : ArmHooks) (G : BitVec 64 → Prop) (base ra : BitVec 64) (s : Arm.ArmState),
          ActEntry vcp rf af fa fb K F G X H base ra s w₀ →
          ∃ n, ActRet ra F G us outs w s (runX (ArmStepX X H fa) n s) ∧
            PostTrace fa af base (ArmStepX X H fa) s n) ∧
        (XNI F syms (f.externs.map (·.2)) (indSigs f) c
          (CallLg env (f.externs.map (·.2)) (indSigs f)) X → XTls F X →
        ∀ (D : BitVec 64 → Prop) (w₀' : Arm.ArmState),
          RelW ⟨F, syms, slotOff, (RAFrame.compute vcp rf).intBase⟩ f c cs.frame.slots cs.mem w₀' →
          SameWorld (fun b => F b ∨ D b) w₀ w₀' →
          (∀ r v, (ArgLoc.reg r, v) ∈ (locsOf f.sig).zip args → regVal w₀' r = regVal w₀ r) →
          (∀ off v, (ArgLoc.stack off, v) ∈ (locsOf f.sig).zip args → ∀ k < v.ty.bytes,
            w₀'.mem (Arm.r (.GPR 29#5) w₀ + BitVec.ofInt 64 (16 + (off : Int)) + BitVec.ofNat 64 k) =
              w₀.mem (Arm.r (.GPR 29#5) w₀ + BitVec.ofInt 64 (16 + (off : Int)) + BitVec.ofNat 64 k)) →
          ∀ (H : ArmHooks) (G : BitVec 64 → Prop) (base ra : BitVec 64) (s : Arm.ArmState),
            ActEntry vcp rf af fa fb K F G X H base ra s w₀' →
            ∃ n, ActRet ra (fun a => F a ∨ D a) G us outs w s (runX (ArmStepX X H fa) n s) ∧
              PostTrace fa af base (ArmStepX X H fa) s n) := by
  intro vals cm returned
  obtain ⟨us,outs,w,pins,arity,values,memory,site,run,paired⟩ :=
    backend_correct_world_niX_semantic (K := K) hsub hc hcov hX hXI hsym hslot hcs hrel hargs htr fuel vals cm returned
  refine ⟨us,outs,w,pins,arity,values,memory,site,?_,?_⟩
  · intro H G base ra s entry
    obtain ⟨n,ret,trace,_⟩ := run H G base ra s entry
    exact ⟨n,ret,trace⟩
  · intro hNI hTls D w' rel worlds regs stack H G base ra s entry
    obtain ⟨n,ret,trace,_⟩ := paired hNI hTls D w' rel worlds regs stack H G base ra s entry
    exact ⟨n,ret,trace⟩

end E2E

/-! Additive whole-program proofs for actual validated output.
Uses the existing LinkSys, hooks, CLIF runs, machine, depth/peak budgets and
binary artifacts. Only the proof contract's compilation field is generalized;
all38 non-compilation input/layout/environment conditions and old theorem variants are
preserved. Actual raw Stock artifacts use the paired semantic interface. Existing production theorem variants remain available. -/
set_option autoImplicit false

namespace E2E
open Backend Backend.Proof Backend.Proof.Driver
open Clif Opt

namespace LinkSys
variable (L : LinkSys)

structure OkSemanticNI : Prop where
  /-- distinct names, no `return_call` -/
  names : (L.P.funcs.map (·.name)).Nodup
  free : ∀ g ∈ L.P.funcs, Clif.LinkFree g
  subset : ∀ g ∈ L.P.funcs, InSubset L.P.bare g
  compiled : ∀ g ∈ L.P.funcs, CompiledSemanticNI g (L.A g).k (L.A g).vc (L.A g).vcp (L.A g).rf
    (L.A g).af (L.A g).fa (L.A g).fb
  covered : ∀ g ∈ L.P.funcs, FormsCovered ⟨(L.A g).fa.k, (L.A g).af.slotBase⟩ (L.A g).vcp
  /-- scope: the outgoing-argument area of a function holds the stack-passed arguments of the
  functions of `P` it declares (checked per declaration; vacuous for register-only signatures) -/
  outFits : ∀ g ∈ L.P.funcs, ∀ e ∈ g.externs.map (·.2), (L.P.func? e.name).isSome →
    ∀ (i off : Nat) (p : Clif.AbiParam), (locsOf e.sig)[i]? = some (ArgLoc.stack off) →
      e.sig.params[i]? = some p →
      off + p.ty.bytes ≤ (RAFrame.compute (L.A g).vcp (L.A g).rf).intBase
  /-- the base externs create no allocation (needed only when a function of `P` has an
  outgoing-argument area: the callees' runs keep it free of live CLIF bytes) -/
  baseNoAlloc : (∃ g ∈ L.P.funcs, (RAFrame.compute (L.A g).vcp (L.A g).rf).intBase ≠ 0) →
    NoAllocEnv L.base
  argRegs : ∀ g ∈ L.P.funcs, (regLocs g.sig).Nodup ∧ (∀ r ∈ regLocs g.sig, r.isArgReg = true) ∧
    ∀ p ∈ g.sig.params, p.ty.width ≤ 64
  /-- an `sret` function's returns carry its ABI results (the struct pointer: `lowerFunction`
  appends it to every `return`), checked on the compiled code -/
  sretRets : ∀ g ∈ L.P.funcs, g.sig.params.any (·.purpose == .sret) = true → ∀ us,
    (L.A g).vc.RetsSite us → (sigRets g.sig).length ≤ us.length
  /-- layout: a function called from `P` without stack slots has no slot region, and the slots
  of one with stack slots fit in its slot region (checked per function; the slot layout of
  `lowerFunction`) -/
  calleeFrame : ∀ g ∈ L.P.funcs, ∀ h, L.Callee g h → h.slots = [] →
    (RAFrame.compute (L.A h).vcp (L.A h).rf).size = (L.A h).af.frameSize
  slotFits : ∀ g ∈ L.P.funcs, ∀ h, L.Callee g h → ∀ p ∈ h.slots, ∃ off,
    (slotLayout h.slots).1.lookup p.1 = some off ∧
      (L.A h).af.slotBase + off + p.2.size ≤ (L.A h).af.frameSize
  /-- scope: a call of a function `h` of `P` passes integer arguments in `h`'s parameter
  registers and takes its results from x0.. (those of its defs that are results: the defs past
  them are a `try_call`'s exception payload registers; checked per call site) -/
  callRegs : ∀ g ∈ L.P.funcs, ∀ info h, L.ProgSite g info h →
    ∃ n Lu Ld, info = ⟨.sym n, retPairs Lu, callDefs Ld⟩ ∧ Lu.map (·.2) = regLocs h.sig ∧
      (Ld.map (·.1)).take (sigRets h.sig).length =
        (List.range (min (sigRets h.sig).length Ld.length)).map Reg.x
  /-- scope: a `blr` call site (an indirect call, or a call through the GOT) passes integer
  arguments in the parameter registers of every function of `P` it may enter (`BlrTo`: one its
  function may reach, `MayCall`; at a call through the GOT only the GOT symbol's function, none
  for a base extern) that has as many register parameters, and takes the results its defs hold
  from x0.. (a site with fewer defs than that function's results constrains nothing more; checked
  per site; vacuous without `blr` sites) -/
  blrRegs : ∀ g ∈ L.P.funcs, ∀ info, (L.A g).vcp.CallSite info → (∀ n, info.dest ≠ .sym n) →
    ∃ t Lu Ld, info = ⟨.reg (.vreg t .int), retPairs Lu, callDefs Ld⟩ ∧
      ∀ h ∈ L.P.funcs, L.BlrTo g t h → (regLocs h.sig).length = Lu.length →
        Lu.map (·.2) = regLocs h.sig ∧
        (Ld.map (·.1)).take (sigRets h.sig).length =
          (List.range (min (sigRets h.sig).length Ld.length)).map Reg.x
  /-- layout: the return address of a `blr` is not in the code of a function of `P` it may call
  (`MayCall`), or is after a call instruction of that function's code, not at its entry
  (`RaOk`: functions sharing one copy of code) -/
  raBlr : ∀ g ∈ L.P.funcs, ∀ info, (L.A g).vcp.CallSite info → (∀ n, info.dest ≠ .sym n) →
    ∀ h ∈ L.P.funcs, L.MayCall g h.name → ∀ pc, CallPc (L.A g).fa (L.A g).base pc →
      RaOk (L.A h) pc
  /-- scope of the indirect calls (`call_indirect`, `try_call_indirect`; vacuous without them):
  the base externs keep the symbols and distinct names of `P` and of the base environment have
  distinct addresses (`Clif.IndScope`) -/
  indScope : ∀ g ∈ L.P.funcs, ¬ Clif.IndFree g → Clif.IndScope L.P L.base L.syms
  /-- the functions `g` may reach whose signature one of its indirect calls matches
  (`IndSigMatch`: parameter types and purposes, return types; the whole-program run enters no
  other, `Clif.stepCallIndirect`), or, for a function `g` declares (which the per-function run
  may enter through any pointer to it), whose parameter types one of them has (`IndTyMatch`),
  take their arguments in registers (an `sret` pointer in x8), and an indirect call of `g` with
  their parameter types and as many declared returns has as many ABI returns (`sigRets`: both
  or neither pass an `sret` pointer) -/
  indSig : ∀ g ∈ L.P.funcs, ¬ Clif.IndFree g →
    ∀ h ∈ L.P.funcs, L.MayCall g h.name → ((∃ sig ∈ indSigs g, IndSigMatch sig h) ∨
      (DeclN g h.name ∧ ∃ sig ∈ indSigs g, IndTyMatch sig h)) →
      (∃ bytes, sigParamBytes h.sig = .ok bytes ∧ bytes.length ≤ 8) ∧
      ∀ sig ∈ indSigs g, IndTyMatch sig h → h.sig.returns.length = sig.returns.length →
        (sigRets h.sig).length = (sigRets sig).length
  /-- when no program callee has stack slots (`NeedSlots` fails: the slot-placement oracle is
  not in play), a function of `P` has an outgoing-argument area and one has indirect calls, the
  functions with an address have no stack slots (an indirect call enters no slotted function);
  with `NeedSlots` the runs' allocations are the base's to keep (`baseKeepsAllocs`) -/
  addrSlots : ¬ L.NeedSlots → (∃ g ∈ L.P.funcs, (RAFrame.compute (L.A g).vcp (L.A g).rf).intBase ≠ 0) →
    (∃ g ∈ L.P.funcs, ¬ Clif.IndFree g) → ∀ h ∈ L.P.funcs, L.syms h.name ≠ none → h.slots = []
  /-- the link-time address of a function of `P` is no other symbol's -/
  symInj : ∀ h ∈ L.P.funcs, ∀ n, L.Xb.sym h.name 0 = L.Xb.sym n 0 → n = h.name
  /-- the declarations of the program's functions are their definitions' signatures -/
  declSig : ∀ g ∈ L.P.funcs, ∀ e ∈ g.externs.map (·.2), ∀ h, L.P.func? e.name = some h → e.sig = h.sig
  /-- the entry `Args` reads parameter registers -/
  entryRegs : ∀ g ∈ L.P.funcs, ∀ r, (L.A g).vcp.EntryArg r → r ∈ regLocs g.sig
  /-- layout: every function's words fit at its base -/
  fits : ∀ g ∈ L.P.funcs, (L.A g).base.toNat + 4 * (L.A g).fb.words.size ≤ 2 ^ 64
  /-- layout: the code image (`Img`, holding `imgMem`) contains every function's words -/
  imgAddr : ∀ g ∈ L.P.funcs, ∀ a, CodeAddr (Arm.set_program Arm.ArmState.default
    ((L.A g).fb.program (L.A g).base)) a → L.Img a
  imgCode : ∀ g ∈ L.P.funcs, ∀ t : Arm.ArmState, (∀ a, L.Img a → t.mem a = L.imgMem a) →
    ∀ k w, (L.A g).fb.words[k]? = some w →
      Arm.read_mem_bytes 4 ((L.A g).base + BitVec.ofNat 64 (4 * k)) t = w
  /-- the code is outside every activation's world -/
  imgF : ∀ a, L.Img a → L.F a
  /-- layout: the return address of a call is not in the code of a function of `P` that `g`
  calls, or is after a call instruction of that function's code, not at its entry (`RaOk`;
  stated for the callees of `g`'s call sites, not for every function of `P`: the return address
  is in `g`'s own code, so a native recursive callee or a callee sharing `g`'s code
  takes the second case) -/
  raCall : ∀ g ∈ L.P.funcs, ∀ info h, L.ProgSite g info h → ∀ pc, CallPc (L.A g).fa (L.A g).base pc →
    RaOk (L.A h) pc
  raStar : ∀ h ∈ L.P.funcs, ∀ k < (L.A h).fb.words.size,
    L.raStar ≠ (L.A h).base + BitVec.ofNat 64 (4 * k)
  /-- the stack of one call level -/
  depth : ∀ g ∈ L.P.funcs, frameDrop (L.A g).af ≤ L.D
  /-- the base environment: symbols, the contracts of the calls outside `P` (at the program's
  call sites), the CLIF contract of the base externs, TLS -/
  symOk : ∀ n b, L.syms n = some b → L.Xb.sym n 0 = BitVec.ofNat 64 b
  baseOs : ∀ g ∈ L.P.funcs, ∀ info, (L.A g).vcp.CallSite info → L.BaseDest (destOf info) →
    ∀ F K G s0 Pc ctx, CallSoundCtlG F K G s0 Pc (callExec L.Hb) (csem F ctx L.Xb) (.call info) .next
  basePc : ∀ d s, L.BaseDest d → Arm.r .ERR s = .None → Arm.CheckSPAlignment s →
    Arm.r .PC (L.Hb.call d s) = Arm.r .PC s + 4
  baseExt : ∀ d uses w outs w', L.BaseDest d → L.Xb.call d uses w = some (outs, w') →
    Arm.r .ERR w = .None → Arm.r .ERR w' = .None ∧ w'.program = w.program
  baseX : ∀ g ∈ L.P.funcs, ∀ F slotOff out c, XCallsOk L.base
    ((g.externs.map (·.2)).filter fun e => (L.P.func? e.name).isNone)
    (RelW ⟨F, L.syms, slotOff, out⟩ g c) L.Xb
  /-- the indirect calls of `g` that reach an extern outside `P`, whatever the call-site
  signature (`sigOf` erased: the linked environment knows only the signatures of `P`'s
  functions, `Clif.linkEnvN`; vacuous without indirect calls) -/
  baseXI : ∀ g ∈ L.P.funcs, ∀ F slotOff out c, XCallsIndOk { L.base with sigOf := fun _ => none }
    (indSigs g) (RelW ⟨F, L.syms, slotOff, out⟩ g c) L.Xb
  baseTls : ∀ g ∈ L.P.funcs, hasTls g = true → ∀ F K, TlsOk F K L.Xb L.Hb
  /-- the results of a `try_call` of an extern outside `P` (normal return; vacuous without such
  `try_call`s) -/
  baseTry : ∀ g ∈ L.P.funcs, ∀ F, CalleeTryOk F L.Xb L.Hb
    fun info ti => (L.A g).vcp.TrySite info ti ∧ L.BaseDest (destOf info)
  /-- **non-interference of the base externs** (needed only when a program callee has an
  outgoing-argument area or a slot region): a returning call of an extern outside `P`, pinned to
  its CLIF call, from two worlds that agree outside `Z ⊇ F`, related to the same CLIF memory, with
  the same stack pointer and the same argument bytes, gives the same results and worlds that agree
  outside `Z` -/
  baseNI : L.NeedNI → ∀ g ∈ L.P.funcs, ∀ F c, XNI F L.syms (g.externs.map (·.2)) (indSigs g) c
    (fun n sig vals cm => L.P.func? n = none ∧
      CallLg L.base (g.externs.map (·.2)) (indSigs g) n sig vals cm) L.Xb
  /-- the TLSDESC flags do not depend on the world outside `F` (needed only when a program
  callee has an outgoing-argument area) -/
  baseTlsNI : L.NeedNI → ∀ F, XTls F L.Xb
  /-- the base externs keep the slot-placement oracle and create no allocation (needed only when
  a program callee has stack slots) -/
  baseKeepsPlace : L.NeedSlots → Clif.EnvKeepsPlace L.base
  baseKeepsAllocs : L.NeedSlots → Clif.EnvKeepsAllocs L.base


/-- Every retained legacy system is an instance with the same actual artifacts. -/
theorem Ok.toSemanticNI {L : LinkSys} (h : L.Ok) : L.OkSemanticNI where
  names := h.names
  free := h.free
  subset := h.subset
  compiled := fun g hg => .compatible (.legacy (h.compiled g hg))
  covered := h.covered
  outFits := h.outFits
  baseNoAlloc := h.baseNoAlloc
  argRegs := h.argRegs
  sretRets := h.sretRets
  calleeFrame := h.calleeFrame
  slotFits := h.slotFits
  callRegs := h.callRegs
  blrRegs := h.blrRegs
  raBlr := h.raBlr
  indScope := h.indScope
  indSig := h.indSig
  addrSlots := h.addrSlots
  symInj := h.symInj
  declSig := h.declSig
  entryRegs := h.entryRegs
  fits := h.fits
  imgAddr := h.imgAddr
  imgCode := h.imgCode
  imgF := h.imgF
  raCall := h.raCall
  raStar := h.raStar
  depth := h.depth
  symOk := h.symOk
  baseOs := h.baseOs
  basePc := h.basePc
  baseExt := h.baseExt
  baseX := h.baseX
  baseXI := h.baseXI
  baseTls := h.baseTls
  baseTry := h.baseTry
  baseNI := h.baseNI
  baseTlsNI := h.baseTlsNI
  baseKeepsPlace := h.baseKeepsPlace
  baseKeepsAllocs := h.baseKeepsAllocs

end LinkSys

namespace LinkSys
variable (L : LinkSys)
variable {κ : Nat → Clif.Function → Nat}

theorem callerOk_canon_semantic (hL : L.OkSemanticNI) {g : Clif.Function} (hg : g ∈ L.P.funcs) {F : BitVec 64 → Prop}
    (himgF : ∀ a, L.Img a → F a) (uses : List CV)
    (w : Arm.ArmState) : L.CallerOk F g uses w (L.canon g uses w) := by
  have harg := (hL.argRegs g hg).2.1
  refine ⟨⟨fun f hf => L.r_canon harg uses w hf, fun a ha => ?_, L.program_canon g uses w⟩,
    fun a ha => ?_, fun _ _ => rfl, .inl fun k hk => ?_⟩
  · rw [L.mem_canon, mem_withImg, if_neg (fun hi => ha (himgF a hi))]
  · rw [L.mem_canon, mem_withImg, if_pos ha]
  · simp only [canon, Arm.r_of_w_same, BitVec.sub_add_cancel]
    exact hL.raStar g hg k hk
end LinkSys

namespace LinkSys
variable (L : LinkSys)
variable {κ : Nat → Clif.Function → Nat}

theorem bodyEntryW_compat_semantic (hL : L.OkSemanticNI) {h : Clif.Function} (hh : h ∈ L.P.funcs) {F : BitVec 64 → Prop}
    (himgF : ∀ a, L.Img a → F a) {uses : List CV}
    {w t : Arm.ArmState} (ht : L.CallerOk F h uses w t) :
    BodyEntryW F (L.A h).vcp.EntryArg (L.A h).af (enterAt (L.A h) t)
      (bodyOf (L.A h).af (enterAt (L.A h) (L.canon h uses w))) := by
  have harg := (hL.argRegs h hh).2.1
  have hc := L.callerOk_canon_semantic hL hh himgF uses w
  have hsp : spv (enterAt (L.A h) (L.canon h uses w)) = spv (enterAt (L.A h) t) := by
    rw [spv_enterAt, spv_enterAt]; simp only [spv]
    rw [hc.world.1 _ (by simp [Masked]), ht.world.1 _ (by simp [Masked])]
  have h29 : xreg 29 (enterAt (L.A h) (L.canon h uses w)) = xreg 29 (enterAt (L.A h) t) := by
    simp only [xreg]
    rw [r_enterAt _ _ (by simp) (by simp), r_enterAt _ _ (by simp) (by simp),
      hc.world.1 _ (by simp [Masked]), ht.world.1 _ (by simp [Masked])]
  refine ⟨by rw [spv_bodyOf, hsp], by rw [x29_bodyOf, hsp, h29], fun r hr => ?_, fun f hf h29' h31 => ?_,
    fun a ha => ?_, by simp⟩
  · have hra := harg r (hL.entryRegs h hh r hr)
    rw [regVal_bodyOf _ _ hra, regVal_enterAt _ _ hra, regVal_enterAt _ _ hra,
      ht.regs r (hL.entryRegs h hh r hr)]
  · have hpc : f ≠ .PC := by rintro rfl; exact hf trivial
    have h30 : f ≠ .GPR 30#5 := by rintro rfl; exact hf (by simp [Masked])
    rw [r_bodyOf _ _ h29' h31, r_enterAt _ _ hpc h30, r_enterAt _ _ hpc h30,
      hc.world.1 f hf, ht.world.1 f hf]
  · rw [mem_bodyOf, mem_enterAt, mem_enterAt, hc.world.2.1 a ha, ht.world.2.1 a ha]
end LinkSys

namespace LinkSys
variable (L : LinkSys)
variable {κ : Nat → Clif.Function → Nat}

theorem frameSize_mod_semantic (hL : L.OkSemanticNI) {h : Clif.Function} (hh : h ∈ L.P.funcs) :
    (L.A h).af.frameSize % 16 = 0 := by
  rw [(lowerRFunc_ok (hL.compiled h hh).alloc).1.1]
  exact alignTo16_mod _
end LinkSys

namespace LinkSys
variable (L : LinkSys)
variable {κ : Nat → Clif.Function → Nat}

theorem frameDrop_eq_semantic (hL : L.OkSemanticNI) {h : Clif.Function} (hh : h ∈ L.P.funcs) :
    frameDrop (L.A h).af = (L.A h).af.frameSize + 16 := by
  simp [frameDrop, lowerRFunc_frame (hL.compiled h hh).alloc]
end LinkSys

namespace LinkSys
variable (L : LinkSys)
variable {κ : Nat → Clif.Function → Nat}

theorem progCall_semantic (hL : L.OkSemanticNI) [hR : L.CrunOk] {M : Nat} (hM : 0 < M) (ih : L.Thm κ (M - 1)) {n : String}
    {h : Clif.Function} (hpf : L.P.func? n = some h) (hcal : ∃ g ∈ L.P.funcs, L.Callee g h)
    (hib : ((RAFrame.compute (L.A h).vcp (L.A h).rf).intBase = 0 ∧
      (RAFrame.compute (L.A h).vcp (L.A h).rf).size = (L.A h).af.frameSize) ∨ L.NeedNI)
    {F : BitVec 64 → Prop} (himgF : ∀ a, L.Img a → F a)
    {uses : List CV} {w : Arm.ArmState} (herr : Arm.r .ERR w = .None)
    (hal : (spv w).toNat % 16 = 0)
    (hroom : frameDrop (L.A h).af + κ (M - 1) h ≤ (spv w).toNat)
    (hdead : ∀ a, StackBelow (frameDrop (L.A h).af + κ (M - 1) h) (spv w) a → F a ∧ ¬ L.Img a)
    {vals : List Clif.Val} {cm : Clif.Mem} {cs : Clif.State} {rvals : List Clif.Val}
    {cm' : Clif.Mem} (hmr : MemRel F L.syms cm w) (hargs : ArgsAt h.sig vals uses w)
    (hsav : StackArgsAvoid F h.sig vals w) (hpl : L.NeedSlots → L.PlaceAt cm (spv w))
    (hinit : Clif.initState L.P n vals cm = .ok cs)
    (hrun : L.crun M cs = .returned rvals cm') :
    ∃ (us : List (Reg × Reg)) (outs : List CV) (wf : Arm.ArmState),
      us.map (·.2) = (List.range us.length).map Reg.x ∧ us.length = outs.length ∧
      PrefixHold rvals outs ∧ MemRel F L.syms cm' wf ∧ (L.A h).vc.RetsSite us ∧
      (∀ t, L.CallerOk F h uses w t → ∃ k,
        L.pcall M h t =
          Arm.set_program (runX (L.mach (M - 1) h) k (enterAt (L.A h) t)) t.program ∧
        ActRet (Arm.r .PC t + 4) F
          (fun a => F a ∧ ¬ StackBelow (frameDrop (L.A h).af + κ (M - 1) h) (spv w) a)
          us outs wf (enterAt (L.A h) t) (runX (L.mach (M - 1) h) k (enterAt (L.A h) t))) ∧
      (L.NeedNI → ∀ (Z : BitVec 64 → Prop) (t : Arm.ArmState), (∀ a, F a → Z a) →
        SameWorld Z t w → (∀ a, L.Img a → t.mem a = L.imgMem a) →
        (∀ r ∈ regLocs h.sig, regVal t r = regVal (L.canon h uses w) r) →
        RaOk (L.A h) (Arm.r .PC t) →
        MemRel F L.syms cm t →
        (∀ off v, (ArgLoc.stack off, v) ∈ (locsOf h.sig).zip vals → ∀ k < v.ty.bytes,
          t.mem (spv w + BitVec.ofNat 64 off + BitVec.ofNat 64 k) =
            w.mem (spv w + BitVec.ofNat 64 off + BitVec.ofNat 64 k)) → ∃ k,
        L.pcall M h t =
          Arm.set_program (runX (L.mach (M - 1) h) k (enterAt (L.A h) t)) t.program ∧
        ActRet (Arm.r .PC t + 4) Z
          (fun a => F a ∧ ¬ StackBelow (frameDrop (L.A h).af + κ (M - 1) h) (spv w) a)
          us outs wf (enterAt (L.A h) t) (runX (L.mach (M - 1) h) k (enterAt (L.A h) t))) := by
  obtain ⟨hh, hname⟩ := Clif.Program.func?_some hpf
  subst hname
  have hc := hL.compiled h hh
  have hfr := lowerRFunc_frame hc.alloc
  have hdrop := L.frameDrop_eq_semantic hL hh
  have hfs := L.frameSize_mod_semantic hL hh
  obtain ⟨hnd, harg, hwid⟩ := hL.argRegs h hh
  have hsl0 : ¬ L.NeedSlots → h.slots = [] := fun hn => Classical.byContradiction fun hne => by
    obtain ⟨g, hg, hcg⟩ := hcal
    exact hn ⟨g, hg, h, hcg, hne⟩
  have hcase : h.slots = [] ∨ L.PlaceAt cm (spv w) := by
    by_cases hN : L.NeedSlots
    · exact .inr (hpl hN)
    · exact .inl (hsl0 hN)
  obtain ⟨hsl', hsym', hal', hby', hpl'⟩ := L.initState_mem hpf hinit hcase
  have hslotB : (L.A h).af.slotBase = (RAFrame.compute (L.A h).vcp (L.A h).rf).size :=
    (lowerRFunc_ok hc.alloc).1.2.1
  have hsz_le := size_le_frameSize hc.alloc
  have hfits : ∀ p ∈ h.slots, ∃ off, (slotLayout h.slots).1.lookup p.1 = some off ∧
      (L.A h).af.slotBase + off + p.2.size ≤ (L.A h).af.frameSize := by
    obtain ⟨g, hg, hcg⟩ := hcal
    exact hL.slotFits g hg h hcg
  have hce : ClifEntry h vals cs := clifEntry_initState hpf hinit
  -- the run of the program without functions (program callees: the callee runs one level down)
  obtain ⟨m, hm⟩ := hR.link M hM h hh cs (runInv_entry hh hce)
    (runInv_entry (by simp [Clif.Program.only]) hce) (fun _ => hsym'.trans hmr.symbols)
    (L.envR (M - 1) h) rfl rfl (fun _ hn => L.envR_of (.inl hn)) (L.envR_link hL.names)
    (by rw [hrun]; intro _ e; cases e) (by rw [hrun]; intro e; cases e)
  rw [hrun] at hm
  obtain ⟨Nr, hrunN⟩ := hR.runs M cs _ hrun (.inl ⟨_, _, rfl⟩)
  -- the canonical state and the shared body-entry world
  let cn := L.canon h uses w
  let w₀ := bodyOf (L.A h).af (enterAt (L.A h) cn)
  have hcOk := L.callerOk_canon_semantic hL hh himgF uses w
  have hsp0 : spv cn = spv w := hcOk.world.1 _ (by simp [Masked])
  have hspw₀ : spv w₀ = spv w - BitVec.ofNat 64 (frameDrop (L.A h).af) := by
    rw [spv_bodyOf, spv_enterAt, hsp0]
  obtain ⟨-, -, hB⟩ := off_toNat 0 (spv w) (frameDrop (L.A h).af) (by omega)
  -- the callee's outgoing area (in the caller's dead stack) is outside the callee's `F`
  let ib := (RAFrame.compute (L.A h).vcp (L.A h).rf).intBase
  let spb := spv w - BitVec.ofNat 64 (frameDrop (L.A h).af)
  let sz := (RAFrame.compute (L.A h).vcp (L.A h).rf).size
  let Fh : BitVec 64 → Prop := fun a =>
    F a ∧ ¬ OutAt ib spb a ∧ ¬ SlotAt sz (L.A h).af.frameSize spb a
  have hib_le : ib ≤ sz := intBase_le_size _ _
  have hspb : spb.toNat = (spv w).toNat - frameDrop (L.A h).af := hB
  have hlt := (spv w).isLt
  have hout_reg : ∀ a, OutAt ib spb a →
      StackBelow (frameDrop (L.A h).af + κ (M - 1) h) (spv w) a := by
    intro a ⟨h1, h2⟩
    rw [hspb] at h1 h2
    exact ⟨by omega, by omega⟩
  have hout_F : ∀ a, OutAt ib spb a → F a ∧ ¬ L.Img a := fun a ha => hdead a (hout_reg a ha)
  -- the callee's slot region (in the caller's dead stack) is outside the callee's `F`
  have hslot_reg : ∀ a, SlotAt sz (L.A h).af.frameSize spb a →
      StackBelow (frameDrop (L.A h).af + κ (M - 1) h) (spv w) a := by
    intro a ⟨h1, h2⟩
    rw [hspb] at h1 h2
    exact ⟨by omega, by omega⟩
  have hslot_F : ∀ a, SlotAt sz (L.A h).af.frameSize spb a → F a ∧ ¬ L.Img a :=
    fun a ha => hdead a (hslot_reg a ha)
  have hspb_add : ∀ j < ib, OutAt ib spb (spb + BitVec.ofNat 64 j) := by
    intro j hj
    have e : (spb + BitVec.ofNat 64 j).toNat = spb.toNat + j := by
      rw [BitVec.toNat_add, BitVec.toNat_ofNat, Nat.mod_eq_of_lt (by omega : j < 2 ^ 64), hspb]
      exact Nat.mod_eq_of_lt (by omega)
    exact ⟨by omega, by omega⟩
  have hOut : ∀ (u : Arm.ArmState), spv u = spb →
      (∀ a n, cs.mem.valid a n = true → ∀ k < n, ¬ OutAt ib spb (BitVec.ofNat 64 (a + k))) →
      OutRel Fh ib cs.mem u := by
    intro u hu hv
    refine ⟨by omega, fun j hj hfh => hfh.2.1 (hu ▸ hspb_add j hj), fun a n hva k hk j hj e => ?_⟩
    rw [hu] at e
    exact hv a n hva k hk (e ▸ hspb_add j hj)
  -- the live allocations of the callee's entry: the caller's, and its slots in its slot region
  have hcsv : ∀ a n, cs.mem.valid a n = true → a + n ≤ 2 ^ 64 ∧ ∀ k < n,
      ¬ Fh (BitVec.ofNat 64 (a + k)) ∧ ¬ OutAt ib spb (BitVec.ofNat 64 (a + k)) := by
    intro a n hv
    simp only [Clif.Mem.valid, List.any_eq_true] at hv
    obtain ⟨x, hx, hcx⟩ := hv
    rcases hal' x hx with hx' | ⟨p, hp, rfl⟩
    · have hv' : cm.valid a n = true := List.any_eq_true.mpr ⟨x, hx', hcx⟩
      obtain ⟨h1, h2⟩ := hmr.valid a n hv'
      exact ⟨h1, fun k hk => ⟨fun hf => h2 k hk hf.1, fun ho => h2 k hk (hout_F _ ho).1⟩⟩
    · obtain ⟨off, hoff, hle⟩ := hfits p hp
      simp only [Clif.Alloc.contains, Bool.and_eq_true, decide_eq_true_eq, hoff,
        Option.getD_some] at hcx
      refine ⟨by omega, fun k hk => ?_⟩
      have e : (BitVec.ofNat 64 (a + k)).toNat = a + k := by
        rw [BitVec.toNat_ofNat]; exact Nat.mod_eq_of_lt (by omega)
      refine ⟨fun hf => hf.2.2 ⟨by rw [e]; omega, by rw [e]; omega⟩,
        fun ⟨o1, o2⟩ => by rw [e] at o1 o2; omega⟩
  -- the callee's entry memory is related to a body-entry world agreeing with the caller's
  have hRel : ∀ u, spv u = spb → Arm.r .ERR u = .None →
      (∀ a b, cm.valid a 1 = true → cm.bytes a = some b → Arm.read_mem (BitVec.ofNat 64 a) u = b) →
      RelW ⟨Fh, L.syms, (L.A h).af.slotBase, ib⟩ h (spv w₀) cs.frame.slots cs.mem u := by
    intro u hu herru hbu
    refine ⟨⟨⟨fun a b hv hb => ?_, fun a n hv => ⟨(hcsv a n hv).1,
      fun k hk => ((hcsv a n hv).2 k hk).1⟩, hsym'.trans hmr.symbols⟩, fun id b hl => ?_,
      hOut u hu (fun a n hv k hk => ((hcsv a n hv).2 k hk).2)⟩, by rw [hu, hspw₀], herru⟩
    · obtain ⟨hb', hnot⟩ := hby' a b hb
      refine hbu a b ?_ hb'
      simp only [Clif.Mem.valid, List.any_eq_true] at hv ⊢
      obtain ⟨x, hx, hcx⟩ := hv
      rcases hal' x hx with hx' | ⟨p, hp, rfl⟩
      · exact ⟨x, hx', hcx⟩
      · simp only [Clif.Alloc.contains, Bool.and_eq_true, decide_eq_true_eq] at hcx
        exact absurd ⟨hcx.1, by omega⟩ (hnot p hp)
    · rw [hsl'] at hl
      obtain ⟨p, hp, rfl, rfl⟩ := lookup_map_some hl
      obtain ⟨off, hoff, -⟩ := hfits p hp
      refine ⟨off, hoff, ?_⟩
      simp only [Rel.slotReg, hoff, Option.getD_some, hu]
      omega
  have hWE : L.WorldEntry κ (M - 1) h Fh vals cs w₀ := by
    refine ⟨hce, ?_, ?_, ?_, ?_, ?_, fun a ha => ⟨himgF a ha, fun ho => (hout_F a ho).2 ha,
      fun hs => (hslot_F a hs).2 ha⟩, fun hN => by rw [hspw₀]; exact hpl' (hpl hN)⟩
    · refine hRel w₀ hspw₀ ?_ fun a b hv hb => ?_
      · simp only [w₀]
        rw [r_bodyOf _ _ (by simp) (by simp), r_enterAt _ _ (by simp) (by simp),
          hcOk.world.1 _ (by simp [Masked])]
        exact herr
      · rw [← hmr.bytes a b hv hb]
        simp only [Arm.read_mem, Arm.read_store, w₀, mem_bodyOf, mem_enterAt]
        rw [L.mem_canon, mem_withImg, if_neg]
        intro hi
        exact (hmr.valid a 1 hv).2 0 (by omega) (by simpa using himgF _ hi)
    · intro loc v hmem
      obtain ⟨i, hi⟩ := List.mem_iff_getElem?.mp hmem
      cases loc with
      | stack off =>
        simp only
        have hx29 : Arm.r (.GPR 29#5) w₀ = spv w - 16#64 := by
          have := x29_bodyOf (L.A h).af (enterAt (L.A h) cn)
          rw [if_pos hfr, spv_enterAt, hsp0] at this
          exact this
        rw [hx29, fp_off_eq]
        refine ⟨fun k hk hf => hsav off v hmem k hk hf.1, ?_⟩
        rw [show Arm.read_mem_bytes v.ty.bytes (spv w + BitVec.ofNat 64 off) w₀ =
            Arm.read_mem_bytes v.ty.bytes (spv w + BitVec.ofNat 64 off) w from
          read_mem_bytes_congr _ _ (fun k hk => by
            simp only [w₀, mem_bodyOf, mem_enterAt]
            rw [L.mem_canon, mem_withImg, if_neg (fun hi => hsav off v hmem k hk (himgF _ hi))])]
        exact hargs.2.2 off v hmem
      | reg r =>
        obtain ⟨i, hr, hv⟩ := reg_zip _ _ hi
        have hlen := hargs.2.1.1
        obtain ⟨u, hu⟩ : ∃ u, uses[i]? = some u := by
          have hi' : i < uses.length := by
            rw [← hlen]; exact (List.getElem?_eq_some_iff.mp hv).1
          exact ⟨uses[i]'hi', List.getElem?_eq_getElem _⟩
        have hvh := hargs.2.1.2 i v u hv hu
        have hrA : r.isArgReg = true := harg r (List.mem_of_getElem? hr)
        simp only
        rw [show regVal w₀ r = regVal (placeArgs (regLocs h.sig) uses (L.withImg w)) r by
          simp only [w₀]; rw [regVal_bodyOf _ _ hrA, regVal_enterAt _ _ hrA, L.regVal_canon _ _ _ hrA],
          placeArgs_regVal _ _ _ hnd harg hr hu]
        refine vHolds_setVal ?_ hvh
        have hty := hce.sig
        have hvmem : v ∈ vals := List.of_mem_zip hmem |>.2
        obtain ⟨j, hj⟩ := List.mem_iff_getElem?.mp hvmem
        have e := congrArg (·[j]?) hty
        simp only [List.getElem?_map, hj, Option.map_some] at e
        cases hp : h.sig.params[j]? with
        | none => rw [hp] at e; cases e
        | some p =>
          rw [hp] at e
          simp only [Option.map_some, Option.some.injEq] at e
          rw [e]; exact hwid p (List.mem_of_getElem? hp)
    · rw [hspw₀, hB]; omega
    · intro a ha
      rw [hspw₀] at ha
      obtain ⟨h1, h2⟩ := ha
      rw [hB] at h1 h2
      have hd := hdead a ⟨by omega, by omega⟩
      exact ⟨⟨hd.1, fun ⟨o1, o2⟩ => by rw [hspb] at o1; omega,
        fun ⟨o1, o2⟩ => by rw [hspb] at o1; omega⟩, hd.2⟩
    · rw [hspw₀, hB, hdrop]; omega
  obtain ⟨us, outs, wf, hus, hlen, hhold, hmemR, hrs, hall, hni⟩ :=
    ih h hh Fh vals cs w₀ m rvals cm' hWE hm
  -- the callee's live allocations after the call are outside the caller's `F`
  have hmemF : MemRel F L.syms cm' wf := by
    refine ⟨hmemR.bytes, fun a n hv => ?_, hmemR.symbols⟩
    by_cases hN : L.NeedSlots
    · exact hmr.valid a n (Clif.runLoop_allocs hL.free (hL.baseKeepsAllocs hN) Nr cs rvals cm'
        (runInv_entry hh hce) (Clif.initState_allocInv hinit) hrunN a n hv)
    have hsl1 := hsl0 hN
    have hsz1 : sz = (L.A h).af.frameSize := by
      obtain ⟨g, hg, hcg⟩ := hcal
      exact hL.calleeFrame g hg h hcg hsl1
    by_cases hib0 : ib = 0
    · obtain ⟨h1, h2⟩ := hmemR.valid a n hv
      exact ⟨h1, fun k hk hf => h2 k hk ⟨hf, fun ⟨o1, o2⟩ => by omega,
        fun ⟨o1, o2⟩ => by omega⟩⟩
    · obtain ⟨-, pl, hcm⟩ := initState_noSlots hpf hsl1 hinit
      have hv0 := runLoop_valid hL.free (hL.baseNoAlloc ⟨h, hh, hib0⟩) (L.slotFree hN) Nr
        cs rvals cm' (runInv_entry hh hce)
        (fun hkk => by
          have ⟨k0, hk0, hnk⟩ := hkk
          refine ⟨(hL.indScope k0 hk0 hnk).keep, fun h' hh' hs' =>
            hL.addrSlots hN ⟨h, hh, hib0⟩ hkk h' hh' ?_⟩
          rw [hcm] at hs'; rwa [← hmr.symbols]) hrunN a n hv
      rw [hcm] at hv0
      exact hmr.valid a n hv0
  -- the callee's activation from a caller state `t`
  let G : BitVec 64 → Prop :=
    fun a => F a ∧ ¬ StackBelow (frameDrop (L.A h).af + κ (M - 1) h) (spv w) a
  have hcode : ∀ t, ∀ a, CodeAddr (enterAt (L.A h) t) a → L.Img a := fun t a ha =>
    hL.imgAddr h hh a (by simpa [CodeAddr] using ha)
  have hME : ∀ t w₀', spv t = spv w → Arm.r .ERR t = .None →
      (∀ a, L.Img a → t.mem a = L.imgMem a) →
      BodyEntryW Fh (L.A h).vcp.EntryArg (L.A h).af (enterAt (L.A h) t) w₀' →
      L.MachEntry κ (M - 1) h Fh G (Arm.r .PC t + 4) (enterAt (L.A h) t) w₀' := by
    intro t w₀' hst herrt himgt hbw
    have hspt : spv (enterAt (L.A h) t) = spv w := by rw [spv_enterAt]; exact hst
    have hFrame : frameWG (κ (M - 1) h) ib (RAFrame.compute (L.A h).vcp (L.A h).rf).size
        (L.A h).af G (enterAt (L.A h) t) = Fh := by
      funext a
      apply propext
      rw [frameWG_out hfr (by rw [hspt, ← hdrop]; exact hroom) hib_le hsz_le, ← hdrop, hspt]
      constructor
      · rintro (⟨hb, hno, hns⟩ | hc | hg)
        · exact ⟨(hdead a hb).1, hno, hns⟩
        · exact ⟨himgF a (hcode t a hc), fun ho => (hout_F a ho).2 (hcode t a hc),
            fun hs => (hslot_F a hs).2 (hcode t a hc)⟩
        · exact ⟨hg.1, fun ho => hg.2 (hout_reg a ho), fun hs => hg.2 (hslot_reg a hs)⟩
      · intro ⟨hF, hno, hns⟩
        by_cases hb : StackBelow (frameDrop (L.A h).af + κ (M - 1) h) (spv w) a
        · exact .inl ⟨hb, hno, hns⟩
        · exact .inr (.inr ⟨hF, hb⟩)
    refine ⟨⟨by simp, fun k wd hk => hL.imgCode h hh _ (fun a ha => by
        rw [mem_enterAt]; exact himgt a ha) k wd hk, by simp, ?_, x30_enterAt _ _, ?_,
        hL.fits h hh⟩, ?_, fun a ha => ?_, hFrame,
      fun a ha => ⟨himgF a ha, fun hb => (hdead a hb).2 ha⟩,
      fun a ha => by rw [mem_enterAt]; exact himgt a ha, hbw⟩
    · rw [r_enterAt _ _ (by simp) (by simp)]; exact herrt
    · rw [hspt]; exact hal
    · refine stackRoom_of (by rw [hspt, ← hdrop]; exact hroom) fun a ha hb => ?_
      rw [hspt, ← hdrop] at hb
      exact (hdead a hb).2 (hcode t a ha)
    · rw [hspt]; exact ha.2
  have hpcall : ∀ t k, RaOk (L.A h) (Arm.r .PC t) →
      PostTrace (L.A h).fa (L.A h).af (L.A h).base (L.mach (M - 1) h) (enterAt (L.A h) t) k →
      ArmRet (Arm.r .PC t + 4) (enterAt (L.A h) t)
        (runX (L.mach (M - 1) h) k (enterAt (L.A h) t)) →
      (runX (L.mach (M - 1) h) k (enterAt (L.A h) t)).program = (enterAt (L.A h) t).program →
      L.pcall M h t =
        Arm.set_program (runX (L.mach (M - 1) h) k (enterAt (L.A h) t)) t.program := by
    intro t k hra htrk hret hprog
    obtain ⟨M', rfl⟩ : ∃ M', M = M' + 1 := ⟨M - 1, by omega⟩
    obtain ⟨lm, hlm⟩ := FnAsm.layout_labelOffsets hc.layout
    show linkedCall _ _ _ = _
    exact linkedCall_eq hc.layout hlm hra (by rw [hdrop]; omega) (by omega) htrk
      ⟨hret.pc, hret.err, hprog.trans (program_enterAt _ _), hret.sp.trans (spv_enterAt _ _)⟩
  have hx29 : Arm.r (.GPR 29#5) w₀ = spv w - 16#64 := by
    have := x29_bodyOf (L.A h).af (enterAt (L.A h) cn)
    rw [if_pos hfr, spv_enterAt, hsp0] at this
    exact this
  -- non-interference: a caller state `t` agreeing with `w` outside `Z ⊇ F`, entered with its
  -- own body-entry world
  have key2 : L.NeedNI → ∀ (Z : BitVec 64 → Prop) (t : Arm.ArmState), (∀ a, F a → Z a) →
      SameWorld Z t w → (∀ a, L.Img a → t.mem a = L.imgMem a) →
      (∀ r ∈ regLocs h.sig, regVal t r = regVal (L.canon h uses w) r) →
      RaOk (L.A h) (Arm.r .PC t) →
      MemRel F L.syms cm t →
      (∀ off v, (ArgLoc.stack off, v) ∈ (locsOf h.sig).zip vals → ∀ k < v.ty.bytes,
        t.mem (spv w + BitVec.ofNat 64 off + BitVec.ofNat 64 k) =
          w.mem (spv w + BitVec.ofNat 64 off + BitVec.ofNat 64 k)) → ∃ k,
      L.pcall M h t =
        Arm.set_program (runX (L.mach (M - 1) h) k (enterAt (L.A h) t)) t.program ∧
      ActRet (Arm.r .PC t + 4) Z G us outs wf (enterAt (L.A h) t)
        (runX (L.mach (M - 1) h) k (enterAt (L.A h) t)) := by
    intro hN Z t hFZ hZ himgt hregt hrat hmt hstkt
    have hst : spv t = spv w := hZ.1 _ (by simp [Masked])
    have herrt : Arm.r .ERR t = .None := by rw [hZ.1 _ (by simp [Masked])]; exact herr
    let w₀' := bodyOf (L.A h).af (enterAt (L.A h) t)
    let D : BitVec 64 → Prop := fun a => Z a ∧ ¬ Fh a
    have hspw₀' : spv w₀' = spb := by
      simp only [w₀']; rw [spv_bodyOf, spv_enterAt, hst]
    have hbw : BodyEntryW Fh (L.A h).vcp.EntryArg (L.A h).af (enterAt (L.A h) t) w₀' :=
      ⟨spv_bodyOf _ _, x29_bodyOf _ _, fun r hr => regVal_bodyOf _ _
        (harg r (hL.entryRegs h hh r hr)), fun f hf h29 h31 => r_bodyOf _ _ h29 h31,
        fun a _ => by simp [w₀'], by simp [w₀']⟩
    have hrel' : RelW ⟨Fh, L.syms, (L.A h).af.slotBase, ib⟩ h (spv w₀) cs.frame.slots cs.mem w₀' := by
      refine hRel w₀' hspw₀' ?_ fun a b hv hb => ?_
      · simp only [w₀']
        rw [r_bodyOf _ _ (by simp) (by simp), r_enterAt _ _ (by simp) (by simp)]
        exact herrt
      · have := hmt.bytes a b hv hb
        simp only [Arm.read_mem, Arm.read_store, w₀', mem_bodyOf, mem_enterAt] at this ⊢
        exact this
    have hsw : SameWorld (fun a => Fh a ∨ D a) w₀ w₀' := by
      refine ⟨fun f hf => ?_, fun a ha => ?_, by simp [w₀, w₀']⟩
      · by_cases h29 : f = .GPR 29#5
        · subst h29
          have e1 := x29_bodyOf (L.A h).af (enterAt (L.A h) cn)
          have e2 := x29_bodyOf (L.A h).af (enterAt (L.A h) t)
          simp only [xreg] at e1 e2
          rw [e1, e2, spv_enterAt, spv_enterAt, hsp0, hst, if_pos hfr, if_pos hfr]
        by_cases h31 : f = .GPR 31#5
        · subst h31
          show spv w₀ = spv w₀'
          rw [hspw₀, hspw₀']
        have hpc : f ≠ .PC := by rintro rfl; exact hf trivial
        have h30 : f ≠ .GPR 30#5 := by rintro rfl; exact hf (by simp [Masked])
        rw [r_bodyOf _ _ h29 h31, r_bodyOf _ _ h29 h31, r_enterAt _ _ hpc h30, r_enterAt _ _ hpc h30,
          hcOk.world.1 f hf, hZ.1 f hf]
      · have hnZ : ¬ Z a := fun hz => by
          by_cases hf : Fh a
          · exact ha (.inl hf)
          · exact ha (.inr ⟨hz, hf⟩)
        simp only [w₀, w₀', mem_bodyOf, mem_enterAt]
        rw [hcOk.world.2.1 a (fun hf => hnZ (hFZ a hf)), hZ.2.1 a hnZ]
    have hreg : ∀ r v, (ArgLoc.reg r, v) ∈ (locsOf h.sig).zip vals →
        regVal w₀' r = regVal w₀ r := by
      intro r v hm
      have hrl : r ∈ regLocs h.sig :=
        List.mem_filterMap.mpr ⟨.reg r, (List.of_mem_zip hm).1, rfl⟩
      have hrA := harg r hrl
      simp only [w₀, w₀']
      rw [regVal_bodyOf _ _ hrA, regVal_bodyOf _ _ hrA, regVal_enterAt _ _ hrA,
        regVal_enterAt _ _ hrA, hregt r hrl]
    have hstk : ∀ off v, (ArgLoc.stack off, v) ∈ (locsOf h.sig).zip vals → ∀ k < v.ty.bytes,
        w₀'.mem (Arm.r (.GPR 29#5) w₀ + BitVec.ofInt 64 (16 + (off : Int)) + BitVec.ofNat 64 k) =
          w₀.mem (Arm.r (.GPR 29#5) w₀ + BitVec.ofInt 64 (16 + (off : Int)) + BitVec.ofNat 64 k) := by
      intro off v hm k hk
      rw [hx29, fp_off_eq]
      have hnF := hsav off v hm k hk
      simp only [w₀, w₀', mem_bodyOf, mem_enterAt]
      rw [hstkt off v hm k hk, hcOk.world.2.1 _ hnF]
    obtain ⟨k, hret, htrk⟩ := hni hN D w₀' hrel' hsw hreg hstk G (Arm.r .PC t + 4)
      (enterAt (L.A h) t) (hME t w₀' hst herrt himgt hbw)
    refine ⟨k, hpcall t k hrat htrk hret.ret hret.prog, ⟨hret.ret, hret.regs, fun a ha => hret.mem a
      (fun h' => ha (h'.elim (fun h1 => hFZ a h1.1) (fun h2 => h2.1))), hret.fields, hret.gkeep,
      hret.prog⟩⟩
  refine ⟨us, outs, wf, hus, hlen, hhold, hmemF, hrs, fun t ht => ?_, key2⟩
  by_cases hN : L.NeedNI
  · refine key2 hN F t (fun _ h => h) ht.world ht.img ht.regs ht.ra ⟨fun a b hv hb => ?_,
      hmr.valid, hmr.symbols⟩ fun off v hm k hk => ht.world.2.1 _ (hsav off v hm k hk)
    rw [← hmr.bytes a b hv hb]
    simp only [Arm.read_mem, Arm.read_store]
    exact ht.world.2.1 _ (by simpa using (hmr.valid a 1 hv).2 0 (by omega))
  · -- no outgoing area: the canonical body-entry world is the actual activation's
    obtain ⟨hib0, hsz0⟩ := hib.resolve_right hN
    have hFh : Fh = F := funext fun a => propext ⟨fun h => h.1, fun h => ⟨h, fun ⟨o1, o2⟩ => by
      omega, fun ⟨o1, o2⟩ => by omega⟩⟩
    have hbw : BodyEntryW Fh (L.A h).vcp.EntryArg (L.A h).af (enterAt (L.A h) t) w₀ := by
      rw [hFh]; exact L.bodyEntryW_compat_semantic hL hh himgF ht
    have hst : spv t = spv w := ht.world.1 _ (by simp [Masked])
    have herrt : Arm.r .ERR t = .None := by rw [ht.world.1 _ (by simp [Masked])]; exact herr
    obtain ⟨k, hret, htrk⟩ := hall G (Arm.r .PC t + 4) (enterAt (L.A h) t)
      (hME t w₀ hst herrt ht.img hbw)
    exact ⟨k, hpcall t k ht.ra htrk hret.ret hret.prog, ⟨hret.ret, hret.regs, fun a ha => hret.mem a
      (fun h' => ha h'.1), hret.fields, hret.gkeep, hret.prog⟩⟩
end LinkSys

namespace LinkSys
variable (L : LinkSys)
variable {κ : Nat → Clif.Function → Nat}

theorem X_ext_semantic (hL : L.OkSemanticNI) {M : Nat} {g : Clif.Function} {F : BitVec 64 → Prop} {d : Option String}
    {uses : List CV} {w : Arm.ArmState} {outs : List CV} {w' : Arm.ArmState}
    (hx : (L.X κ M g F).call d uses w = some (outs, w'))
    (herr : Arm.r .ERR w = .None) : Arm.r .ERR w' = .None ∧ w'.program = w.program := by
  cases d with
  | some n =>
    cases hpf : L.P.func? n with
    | none =>
      rw [L.X_base hpf _ _ F] at hx
      exact hL.baseExt _ _ _ _ _ (.inr ⟨n, rfl, hpf⟩) hx herr
    | some h =>
      rw [L.X_prog hpf _ _ F] at hx
      exact L.progX_ext hx
  | none =>
    cases uses with
    | nil => exact hL.baseExt _ _ _ _ _ (.inl rfl) hx herr
    | cons u args =>
      cases hs : symCallee L.Xb L.P (lo64 u) with
      | none =>
        rw [L.X_none hs] at hx
        exact hL.baseExt _ _ _ _ _ (.inl rfl) hx herr
      | some h =>
        rw [L.X_ind hs] at hx
        split at hx
        · exact L.progX_ext hx
        · cases hx
end LinkSys

namespace LinkSys
variable (L : LinkSys)
variable {κ : Nat → Clif.Function → Nat}

theorem budget_K_semantic (hL : L.OkSemanticNI) : L.Budget fun M _ => L.K M := by
  intro M g _ h hc
  have := hL.depth h (L.callee_mem hc)
  simp only [K, Nat.mul_succ]
  omega
end LinkSys

namespace LinkSys
variable (L : LinkSys)
variable {κ : Nat → Clif.Function → Nat}

theorem progOsCore_semantic (hL : L.OkSemanticNI) [hR : L.CrunOk] (hκ : L.Budget κ) {M : Nat} (ih : 0 < M → L.Thm κ (M - 1)) {g h : Clif.Function}
    (hg : g ∈ L.P.funcs) (hh : h ∈ L.P.funcs)
    (hcallee : L.Callee g h)
    {F G : BitVec 64 → Prop} {s0 : Arm.ArmState} (himgF : ∀ a, L.Img a → F a)
    (himgG : ∀ a, L.Img a → G a) (himgS : ∀ a, L.Img a → s0.mem a = L.imgMem a)
    {Lu : List (Nat × Reg)} {Ld : List (Reg × Nat)} (hLu : Lu.map (·.2) = regLocs h.sig)
    (hLd : (Ld.map (·.1)).take (sigRets h.sig).length =
      (List.range (min (sigRets h.sig).length Ld.length)).map Reg.x)
    {info : CallInfo} (hdefs0 : info.defs = callDefs Ld)
    {ops : Array Operand} {regs : Array Reg}
    (hdefs : ((ops.zip regs).toList.filter (·.1.isDef)) = (callDefOps Ld).zip (Ld.map (·.1)))
    {t w w' : Arm.ArmState} {outs : List CV}
    (hK : κ M g ≤ (spOf t).toNat) (hG : ∀ a, G a → t.mem a = s0.mem a)
    (hra : RaOk (L.A h) (Arm.r .PC t))
    (hsw : SameWorld F t w)
    (hx : L.progX κ M F h (Lu.map (fun q => regVal t q.2)) w = some (outs, w')) :
    SameWorld F (L.pcall M h t) w' ∧
      FrameKeep (fun a => F a ∧ ¬ StackBelow (κ M g) (spOf t) a) t (L.pcall M h t) ∧
      (∀ p ∈ defRegs ops regs outs, regVal (L.pcall M h t) p.1.2 = p.2) ∧
      (∀ r, r.allocatable = true → (∀ p ∈ (ops.zip regs).toList, p.1.isDef = true → p.2 ≠ r) →
        r ∉ (MInst.call info).clobbers → regVal (L.pcall M h t) r = regVal t r) ∧
      (∀ r ∈ (MInst.call info).clobbers, r ∈ calleeSaved →
        ckeep r (regVal (L.pcall M h t) r) = ckeep r (regVal t r)) := by
  have hpf := func?_of_mem hL.names hh
  have hib : ((RAFrame.compute (L.A h).vcp (L.A h).rf).intBase = 0 ∧
      (RAFrame.compute (L.A h).vcp (L.A h).rf).size = (L.A h).af.frameSize) ∨ L.NeedNI := by
    by_cases h0 : (RAFrame.compute (L.A h).vcp (L.A h).rf).intBase = 0
    · by_cases h1 : (RAFrame.compute (L.A h).vcp (L.A h).rf).size = (L.A h).af.frameSize
      · exact .inl ⟨h0, h1⟩
      · exact .inr ⟨g, hg, h, hcallee, .inr h1⟩
    · exact .inr ⟨g, hg, h, hcallee, .inl h0⟩
  obtain ⟨hnd, harg, -⟩ := hL.argRegs h hh
  generalize huses : Lu.map (fun q => regVal t q.2) = uses at hx
  unfold progX at hx
  have hcond : L.Cond κ M F h uses w ∧
      Arm.r .ERR (L.pcall M h (L.canon h uses w)) = .None :=
    Classical.byContradiction fun hc => by rw [if_neg hc] at hx; cases hx
  rw [if_pos hcond] at hx
  obtain ⟨⟨hM, herrw, halw, hroom, hdead, vals, cm, cs, rvals, cm', hmr, hargs, hsav, hpl, hinit,
    hrun⟩,
    -⟩ := hcond
  simp only [Option.some.injEq, Prod.mk.injEq] at hx
  obtain ⟨rfl, rfl⟩ := hx
  obtain ⟨us, outsV, wf, hus, hlen, hhold, hmemR, hrs, hcall, -⟩ :=
    L.progCall_semantic hL hM (ih hM) hpf ⟨g, hg, hcallee⟩ hib himgF herrw halw hroom hdead hmr hargs hsav hpl
      hinit hrun
  -- the caller state is compatible with the canonical one
  have hcOk : L.CallerOk F h uses w t := by
    refine ⟨hsw, fun a ha => (hG a (himgG a ha)).trans (himgS a ha), fun r hr => ?_,
      hra⟩
    rw [← hLu] at hr
    obtain ⟨j, hj⟩ := List.mem_iff_getElem?.mp hr
    have hrA : r.isArgReg = true := harg r (by rw [← hLu]; exact List.mem_of_getElem? hj)
    have hu : uses[j]? = some (regVal t r) := by
      simp only [List.getElem?_map, Option.map_eq_some_iff] at hj
      obtain ⟨q, hq, rfl⟩ := hj
      simp [← huses, hq]
    rw [L.regVal_canon _ _ _ hrA, placeArgs_regVal _ _ _ hnd harg (by rw [← hLu]; exact hj) hu,
      setVal_regVal]
  obtain ⟨ks, hs_eq, hs_ret⟩ := hcall t hcOk
  obtain ⟨kc, hc_eq, hc_ret⟩ := hcall _ (L.callerOk_canon_semantic hL hh himgF uses w)
  -- the allocated call
  refine ⟨?_, ?_, ?_, ?_, ?_⟩
  · -- the world
    rw [hs_eq, hc_eq]
    refine ⟨fun f hf => ?_, fun a ha => ?_, ?_⟩
    · rw [r_set_program, r_set_program]
      by_cases h29 : f = .GPR 29#5
      · subst h29
        have e1 := hs_ret.ret.savedX 29 (by decide)
        have e2 := hc_ret.ret.savedX 29 (by decide)
        simp only [xreg] at e1 e2
        rw [show (BitVec.ofNat 5 29) = 29#5 from rfl] at e1 e2
        rw [e1, e2, r_enterAt _ _ (by simp) (by simp), r_enterAt _ _ (by simp) (by simp),
          (L.callerOk_canon_semantic hL hh himgF uses w).world.1 _ hf, hsw.1 _ hf]
      by_cases h31 : f = .GPR 31#5
      · subst h31
        have e1 := hs_ret.ret.sp
        have e2 := hc_ret.ret.sp
        simp only [spv] at e1 e2
        rw [e1, e2, r_enterAt _ _ (by simp) (by simp), r_enterAt _ _ (by simp) (by simp),
          (L.callerOk_canon_semantic hL hh himgF uses w).world.1 _ hf, hsw.1 _ hf]
      · rw [hs_ret.fields f hf h29 h31, hc_ret.fields f hf h29 h31]
    · simp only [mem_set_program]
      rw [hs_ret.mem a ha, hc_ret.mem a ha]
    · simp only [program_set_program]
      rw [hsw.2.2, L.program_canon]
  · -- the frame outside the dead stack
    rw [hs_eq]
    refine ⟨?_, fun a ⟨ha, hb⟩ => ?_⟩
    · show spv (Arm.set_program _ _) = spv t
      simp only [spv]; rw [r_set_program]
      have := hs_ret.ret.sp
      simp only [spv] at this
      rw [this, r_enterAt _ _ (by simp) (by simp)]
    · rw [mem_set_program, hs_ret.gkeep a ⟨ha, fun hb' => hb ?_⟩, mem_enterAt]
      have hsp : spv w = spOf t := (hsw.1 (.GPR 31#5) (by simp [Masked])).symm
      rw [hsp] at hb'
      exact stackBelow_mono hb' (L.budget_step hκ hM hg hcallee)
  · -- the results
    intro p hp
    obtain ⟨⟨op, r⟩, x⟩ := p
    rw [defRegs, hdefs] at hp
    obtain ⟨j, hj⟩ := List.mem_iff_getElem?.mp hp
    simp only [List.getElem?_zip_eq_some] at hj
    obtain ⟨⟨-, hr⟩, hx⟩ := hj
    simp only [List.getElem?_map, Option.map_eq_some_iff] at hx
    obtain ⟨j2, hj2, rfl⟩ := hx
    have hjr : j < (sigRets h.sig).length := by
      have := (List.getElem?_eq_some_iff.mp hj2).1; simpa using this
    have hjL : j < Ld.length := by
      have := (List.getElem?_eq_some_iff.mp hr).1; simpa using this
    have e : ((Ld.map (·.1)).take (sigRets h.sig).length)[j]? = (Ld.map (·.1))[j]? := by
      rw [List.getElem?_take]; simp [hjr]
    rw [← e, hLd] at hr
    simp only [List.getElem?_map, Option.map_eq_some_iff] at hr
    obtain ⟨j1, hj1, rfl⟩ := hr
    rw [List.getElem?_range (by omega : j < min (sigRets h.sig).length Ld.length),
      Option.some.injEq] at hj1
    rw [List.getElem?_range hjr, Option.some.injEq] at hj2
    subst hj1 hj2
    show regVal _ (Reg.x j) = regVal _ (Reg.x j)
    rw [hs_eq, regVal_set_program, hc_eq, regVal_set_program]
    -- the `j`-th result register is a return register of the callee
    obtain ⟨Nr, hrunN⟩ := hR.runs M cs _ hrun (.inl ⟨_, _, rfl⟩)
    have hrt := Clif.runLoop_returned_tys hL.free Nr cs rvals cm'
      (runInv_entry hh (clifEntry_initState hpf hinit)) hrunN
    have hbot : cs.bottom = h := by
      have hce := clifEntry_initState (f := h) hpf hinit
      simp [Clif.State.bottom, hce.callers, hce.func]
    rw [hbot] at hrt
    have hlr : (sigRets h.sig).length ≤ us.length := by
      cases hsr : h.sig.params.any (·.purpose == .sret) with
      | true => exact hL.sretRets h hh hsr us hrs
      | false =>
        rw [sigRets_of_noSret hsr, hlen]
        have := congrArg List.length hrt
        simp only [List.length_map, Clif.AbiParam.tys] at this
        rw [← this]; exact hhold.1
    have hju : j < us.length := by omega
    have hus_j : us[j]? = some ((us[j]'hju).1, Reg.x j) := by
      have := congrArg (·[j]?) hus
      simp only [List.getElem?_map, List.getElem?_range hju, List.getElem?_eq_getElem hju,
        Option.map_some, Option.some.injEq] at this
      rw [List.getElem?_eq_getElem hju, ← this]
    have hoj : outsV[j]? = some (outsV[j]'(by omega)) := List.getElem?_eq_getElem _
    rw [hs_ret.regs j _ _ _ hus_j hoj, hc_ret.regs j _ _ _ hus_j hoj]
  · -- the registers the callee preserves
    intro r hr hnd' hnc
    rw [hs_eq, regVal_set_program]
    have hnotd : r ∉ Ld.map (·.1) := by
      intro hm
      obtain ⟨q, hq, rfl⟩ := List.mem_map.mp hm
      have hmem : (⟨⟨q.2, .int, .def, .late, .fixed q.1⟩, q.1⟩ : Operand × Reg) ∈
          (ops.zip regs).toList := by
        have h1 : (⟨⟨q.2, .int, .def, .late, .fixed q.1⟩, q.1⟩ : Operand × Reg) ∈
            (callDefOps Ld).zip (Ld.map (·.1)) := List.mem_iff_getElem?.mpr (by
          obtain ⟨i, hi⟩ := List.mem_iff_getElem?.mp hq
          exact ⟨i, by simp [callDefOps, List.getElem?_zip_eq_some, hi]⟩)
        rw [← hdefs] at h1
        exact (List.mem_filter.mp h1).1
      exact hnd' _ hmem rfl rfl
    have hnD : r ∉ defaultAapcsClobbers := by
      intro hm
      apply hnc
      simp only [MInst.clobbers, List.mem_filter, hm, true_and, hdefs0, callDefs]
      simp only [List.any_map, Bool.not_eq_true', List.any_eq_false, beq_iff_eq]
      exact fun q hq e => hnotd (List.mem_map.mpr ⟨q, hq, by simpa using e⟩)
    rcases allocatable_cases hr with ⟨m, rfl, hm, h16, h17, h18⟩ | ⟨m, rfl, hm⟩
    · have h19 : 19 ≤ m :=
        Classical.byContradiction fun hc => hnD (by simp [defaultAapcsClobbers]; omega)
      have e := hs_ret.ret.savedX m (by simp [calleeSavedX]; exact ⟨m - 19, by omega, by omega⟩)
      simp only [xreg] at e
      simp only [regVal]
      rw [show rnum m = BitVec.ofNat 5 m from rfl, e, r_enterAt _ _ (by simp) (fun e' => by
        have := congrArg (fun f => match f with | Arm.StateField.GPR i => i.toNat | _ => 0) e'
        simp [rnum_toNat (show m < 32 by omega)] at this; omega)]
    · exact absurd (by simp [defaultAapcsClobbers]; omega) hnD
  · -- the callee-saved registers the call clobbers: the low halves of v8–v15
    intro r hr hcs
    rw [hs_eq, regVal_set_program]
    have hrD : r ∈ defaultAapcsClobbers := (List.mem_filter.mp hr).1
    simp only [calleeSaved, List.mem_append, List.mem_map, List.mem_range] at hcs
    rcases hcs with ⟨i, hi, rfl⟩ | ⟨i, hi, rfl⟩
    · exact absurd hrD (by simp [defaultAapcsClobbers]; omega)
    · have e := hs_ret.ret.savedV (8 + i) (by omega) (by omega)
      simp only [ckeep, regVal]
      rw [show rnum (8 + i) = BitVec.ofNat 5 (8 + i) from rfl, e,
        r_enterAt _ _ (by simp) (by simp)]
end LinkSys

namespace LinkSys
variable (L : LinkSys)
variable {κ : Nat → Clif.Function → Nat}

theorem got_target_semantic (hL : L.OkSemanticNI) {a : BitVec 64} {h : Clif.Function} {n : String}
    (hs : symCallee L.Xb L.P a = some h) (e : a = L.Xb.sym n 0) : n = h.name := by
  have hh : h ∈ L.P.funcs := List.mem_of_find?_eq_some hs
  have := List.find?_some hs
  simp only [beq_iff_eq] at this
  exact hL.symInj h hh n (this.trans e)
end LinkSys

namespace LinkSys
variable (L : LinkSys)
variable {κ : Nat → Clif.Function → Nat}

theorem progOs_semantic (hL : L.OkSemanticNI) [L.CrunOk] (hκ : L.Budget κ) {M : Nat} (ih : 0 < M → L.Thm κ (M - 1)) {g : Clif.Function}
    (hg : g ∈ L.P.funcs) {F G : BitVec 64 → Prop} {s0 : Arm.ArmState} (himgF : ∀ a, L.Img a → F a)
    (himgG : ∀ a, L.Img a → G a) (himgS : ∀ a, L.Img a → s0.mem a = L.imgMem a)
    {info : CallInfo} {h : Clif.Function} (hsite : L.ProgSite g info h) (ctx : FnCtx) :
    CallSoundCtlG F (κ M g) G s0 (CallAt (L.A g).fa (L.A g).base) (callExec (L.hooks M))
      (csemV (GotV (L.A g).vcp) F ctx (L.X κ M g F)) (.call info) .next := by
  have ⟨_, n, hdest, hpf⟩ := hsite
  obtain ⟨hh, hname⟩ := Clif.Program.func?_some hpf
  subst hname
  obtain ⟨n', Lu, Ld, hinfo, hLu, hLd⟩ := hL.callRegs g hg info h hsite
  subst hinfo
  cases hdest
  intro t hK hD hG c wh ops regs i' w outs w' hops hst hasg hP hsw hal herr hsem
  replace hsem := csemV_sub hsem
  rw [operands_call_sym] at hops
  cases hops
  obtain ⟨hsz', hloc, -, -⟩ := checkStatic_facts hst
  have hregs := callRegs_eq (regs := regs) (by simpa using hsz')
    (fun p hp r hr => (hloc p hp).2 r hr)
  rw [call_useVals hregs] at hsem
  have hx : L.progX κ M F h (Lu.map (fun q => regVal t q.2)) w = some (outs, w') := by
    simp only [csem, Option.map_eq_some_iff, Prod.mk.injEq] at hsem
    obtain ⟨⟨o, w2⟩, hx, rfl, rfl, -⟩ := hsem
    rw [L.X_prog hpf] at hx
    exact hx
  obtain ⟨us', ds', rfl⟩ := assign_call_sym hasg
  exact ⟨L.pcall M h t, by simp only [callExec, hal, ↓reduceIte, L.hooks_some hpf],
    L.progOsCore_semantic hL hκ ih hg hh (.inl ⟨_, hsite⟩) himgF himgG himgS hLu hLd rfl (call_defs hregs) hK hG
      (hL.raCall g hg _ h hsite _ hP.callPc) hsw hx⟩
end LinkSys

namespace LinkSys
variable (L : LinkSys)
variable {κ : Nat → Clif.Function → Nat}

theorem progOsReg_semantic (hL : L.OkSemanticNI) [L.CrunOk] (hκ : L.Budget κ) {M : Nat} (ih : 0 < M → L.Thm κ (M - 1)) {g : Clif.Function}
    (hg : g ∈ L.P.funcs) {F G : BitVec 64 → Prop} {s0 : Arm.ArmState} (himgF : ∀ a, L.Img a → F a)
    (himgG : ∀ a, L.Img a → G a) (himgS : ∀ a, L.Img a → s0.mem a = L.imgMem a)
    {info : CallInfo} (hsite : (L.A g).vcp.CallSite info) (hreg : ∀ n, info.dest ≠ .sym n)
    (ctx : FnCtx) :
    CallSoundCtlG F (κ M g) G s0 (CallAt (L.A g).fa (L.A g).base) (callExec (L.hooks M))
      (csemV (GotV (L.A g).vcp) F ctx (L.X κ M g F)) (.call info) .next := by
  obtain ⟨tv, Lu, Ld, rfl, hregs⟩ := hL.blrRegs g hg info hsite hreg
  intro t hK hD hG c wh ops regs i' w outs w' hops hst hasg hP hsw hal herr hsem
  have hguard := csemV_guard hsem
  replace hsem := csemV_sub hsem
  have hops0 := hops
  rw [operands_call_reg] at hops
  cases hops
  obtain ⟨hsz', hloc, -, -⟩ := checkStatic_facts hst
  obtain ⟨r0, hregs0⟩ := callRegs_eq_reg (regs := regs) (by simpa using hsz')
    (fun p hp r hr => (hloc p hp).2 r hr)
  -- the target register: an allocatable X register
  obtain ⟨n0, rfl, hn0, -⟩ : ∃ n, r0 = .x n ∧ n < 29 ∧ n ≠ 16 := by
    have hmem : (tgtOp tv, Loc.reg r0) ∈
        (((tgtOp tv :: (retOps Lu ++ callDefOps Ld)).toArray).zip (regs.map Loc.reg)).toList := by
      simp [Array.toList_zip, Array.toList_map, hregs0]
    obtain ⟨n, hn, h29, h16, -⟩ := locOk_int (hloc _ hmem).1
    exact ⟨n, hn, h29, h16⟩
  have hsem0 := hsem
  rw [call_useVals_reg hregs0] at hsem
  -- the allocated call: `blr x n0`
  obtain ⟨r1, us', ds', hr1, rfl⟩ := assign_call_reg hasg
  have h0 : regs[0]? = some (.x n0) := by
    rw [← Array.getElem?_toList, hregs0]; rfl
  rw [h0] at hr1
  cases hr1
  -- the target the machine reads
  have hc := hL.compiled g hg
  obtain ⟨lm, hlm⟩ := FnAsm.layout_labelOffsets hc.layout
  have htgt : blrTarget t = some (lo64 (regVal t (.x n0))) := by
    obtain ⟨j, x, tt, hj, hx, hpc⟩ := hP
    simp only [MInst.callInsn?, Option.some.injEq] at hx
    subst hx
    rw [lo64_regVal_x]
    exact blrTarget_of hc.layout hlm hj hn0 hpc
      (fun k wd hk => hL.imgCode g hg t (fun a ha => (hG a (himgG a ha)).trans (himgS a ha)) k wd hk)
  -- the external semantics' call
  have hx : (L.X κ M g F).call none (regVal t (.x n0) :: Lu.map (fun q => regVal t q.2)) w =
      some (outs, w') := by
    simp only [csem, Option.map_eq_some_iff, Prod.mk.injEq] at hsem
    obtain ⟨⟨o, w2⟩, hx, rfl, rfl, -⟩ := hsem
    exact hx
  cases hs : symCallee L.Xb L.P (lo64 (regVal t (.x n0))) with
  | none =>
    -- no function of `P` at the target: the base's contract
    have hb : (blrTarget t).bind (symCallee L.Xb L.P) = none := by rw [htgt]; exact hs
    rw [L.X_none hs] at hx
    have hsem' : csem F ctx L.Xb (.call ⟨.reg (.vreg tv .int), retPairs Lu, callDefs Ld⟩)
        (useVals (tgtOp tv :: (retOps Lu ++ callDefOps Ld)).toArray regs t) w =
        some (outs, w', .next) := by
      rw [call_useVals_reg hregs0]; simp [csem, hx]
    obtain ⟨s', hex, rest⟩ := hL.baseOs g hg _ hsite (.inl rfl) F (κ M g) G s0
      (CallAt (L.A g).fa (L.A g).base) ctx t hK hD hG c wh _ regs _ w outs w' hops0 hst hasg hP hsw
      hal herr hsem'
    refine ⟨s', ?_, rest⟩
    simp only [callExec] at hex ⊢
    rw [L.hooks_base (.inl rfl) t (fun _ => hb)]
    exact hex
  | some h =>
    rw [L.X_ind hs] at hx
    split at hx
    · rename_i hdecl
      have hh : h ∈ L.P.funcs := List.mem_of_find?_eq_some hs
      have hgot : ∀ n, GotV (L.A g).vcp tv n → n = h.name := by
        intro n hn
        have e := hguard tv n _ rfl hn (operands_call_reg tv Lu Ld) (by simp [tgtOp, Operand.isUse])
        rw [call_useVals_reg hregs0] at e
        simp only [List.head?_cons, Option.map_some, Option.some.injEq] at e
        exact L.got_target_semantic hL hs e
      obtain ⟨hLu, hLd⟩ := hregs h hh ⟨hdecl.1, hgot⟩ (by rw [← hdecl.2, List.length_map])
      have hb : (blrTarget t).bind (symCallee L.Xb L.P) = some h := by rw [htgt]; exact hs
      exact ⟨L.pcall M h t, by simp only [callExec, hal, ↓reduceIte, L.hooks_none hb],
        L.progOsCore_semantic hL hκ ih hg hh (.inr (.inr ⟨hh, hdecl.1.1⟩)) himgF himgG himgS hLu hLd rfl
          (call_defs_reg hregs0) hK hG
          (hL.raBlr g hg _ hsite hreg h hh hdecl.1.1 _ hP.callPc) hsw hx⟩
    · cases hx
end LinkSys

namespace LinkSys
variable (L : LinkSys)
variable {κ : Nat → Clif.Function → Nat}

theorem calleeOk_semantic (hL : L.OkSemanticNI) [L.CrunOk] (hκ : L.Budget κ) {M : Nat} (ih : 0 < M → L.Thm κ (M - 1)) {g : Clif.Function}
    (hg : g ∈ L.P.funcs) {F G : BitVec 64 → Prop} {ra : BitVec 64} {s w₀ : Arm.ArmState}
    (he : L.MachEntry κ M g F G ra s w₀) :
    CalleeOkG F (κ M g) G s (CallAt (L.A g).fa (L.A g).base) (L.X κ M g F) (L.hooks M)
      (L.A g).vcp.CallSite (GotV (L.A g).vcp) where
  os ctx info hsite := by
    cases hd : info.dest with
    | reg r =>
      exact L.progOsReg_semantic hL hκ ih hg he.imgF he.imgG he.imgS hsite (fun n => by rw [hd]; simp) ctx
    | sym n =>
    have hdest := hd
    cases hpf : L.P.func? n with
    | some h => exact L.progOs_semantic hL hκ ih hg he.imgF he.imgG he.imgS ⟨hsite, n, hdest, hpf⟩ ctx
    | none =>
      have hb : L.BaseDest (destOf info) := .inr ⟨n, by simp [destOf, hdest], hpf⟩
      have h0 := hL.baseOs g hg info hsite hb F (κ M g) G s (CallAt (L.A g).fa (L.A g).base) ctx
      intro t h1 h2 h3 c wh ops regs i' w outs w' hops hst hasg h4 hsw hal herr hsem
      obtain ⟨d, us, ds⟩ := info
      simp only at hdest
      subst hdest
      have hsem' : csem F ctx L.Xb (.call ⟨.sym n, us, ds⟩) (useVals ops regs t) w =
          some (outs, w', .next) := by
        rw [← csemV_sub hsem]; simp [csem, L.X_base hpf _ _ F]
      obtain ⟨s', hex, rest⟩ :=
        h0 t h1 h2 h3 c wh ops regs i' w outs w' hops hst hasg h4 hsw hal herr hsem'
      refine ⟨s', ?_, rest⟩
      obtain ⟨us', ds', rfl⟩ := assign_call_sym hasg
      simp only [callExec] at hex ⊢
      rw [L.hooks_base (.inr ⟨n, rfl, hpf⟩) t (fun h => by cases h)]
      exact hex
  pc d u herr hal := by
    cases d with
    | none =>
      cases hb : (blrTarget u).bind (symCallee L.Xb L.P) with
      | none =>
        rw [L.hooks_base (.inl rfl) u (fun _ => hb)]; exact hL.basePc _ _ (.inl rfl) herr hal
      | some h => rw [L.hooks_none hb]; exact (L.pcall_pc M h u).2
    | some n =>
      cases hpf : L.P.func? n with
      | none =>
        rw [L.hooks_base (.inr ⟨n, rfl, hpf⟩) u (fun h => by cases h)]
        exact hL.basePc _ _ (.inr ⟨n, rfl, hpf⟩) herr hal
      | some h => rw [L.hooks_some hpf]; exact (L.pcall_pc M h u).2
  ext _ _ _ _ _ hx herr := L.X_ext_semantic hL hx herr
end LinkSys

namespace LinkSys
variable (L : LinkSys)
variable {κ : Nat → Clif.Function → Nat}

theorem calleeTryOk_semantic (hL : L.OkSemanticNI) [L.CrunOk] (hκ : L.Budget κ) {M : Nat} (ih : 0 < M → L.Thm κ (M - 1)) {g : Clif.Function}
    (hg : g ∈ L.P.funcs) {F G : BitVec 64 → Prop} {ra : BitVec 64} {s w₀ : Arm.ArmState}
    (he : L.MachEntry κ M g F G ra s w₀) :
    CalleeTryOkG F (κ M g) G s (CallAt (L.A g).fa (L.A g).base) (L.X κ M g F) (L.hooks M)
      (L.A g).vcp.TrySite (GotV (L.A g).vcp) := by
  intro ctx info ti hsite
  cases hd : info.dest with
  | sym n =>
    have hdest := hd
    cases hpf : L.P.func? n with
    | some h =>
      exact calleeTryOkG_of_call (S := fun i t => i = info ∧ t = ti)
        (fun ctx' i t ⟨e1, _⟩ => e1 ▸ (L.calleeOk_semantic hL hκ ih hg he).os ctx' info hsite.callSite)
        (fun _ _ _ h => callAt_tryCall_call h)
        (fun i t ⟨_, e2⟩ => e2 ▸ trySite_clobberAll (hL.compiled g hg).alloc hsite)
        ctx info ti ⟨rfl, rfl⟩
    | none =>
      have hb : L.BaseDest (destOf info) := .inr ⟨n, by simp [destOf, hdest], hpf⟩
      intro c wh ops regs i' t w outs w' s' _ _ _ hops hst hasg _ hsw hal herr hsem hex
      obtain ⟨d, us, ds⟩ := info
      simp only at hdest
      subst hdest
      have hsem' : csem F ctx L.Xb (.tryCall ⟨.sym n, us, ds⟩ ti) (useVals ops regs t) w =
          some (outs, w', .goto ti.handlers.length) := by
        rw [← csemV_sub hsem]; simp [csem, L.X_base hpf _ _ F]
      obtain ⟨ic, rfl, hasg'⟩ := (assign_call_tryCall _ regs).2 ti i' hasg
      obtain ⟨us', ds', hic⟩ := assign_call_sym hasg'
      cases hic
      have hex' : callExec L.Hb (.tryCall ⟨.sym n, us', ds'⟩ ti) t = some s' := by
        simp only [callExec] at hex ⊢
        rw [← L.hooks_base (M := M) (.inr ⟨n, rfl, hpf⟩) t (fun h => by cases h)]
        exact hex
      exact hL.baseTry g hg F ctx _ ti ⟨hsite, hb⟩ c wh ops regs _ t w outs w' s' hops hst hasg
        hsw hal herr hsem' hex'
  | reg r =>
    obtain ⟨tv, Lu, Ld, hinfo, -⟩ :=
      hL.blrRegs g hg info hsite.callSite (fun n => by rw [hd]; simp)
    subst hinfo
    intro c wh ops regs i' t w outs w' s' hK hD hG hops hst hasg hP hsw hal herr hsem hex
    have hcl := trySite_clobberAll (hL.compiled g hg).alloc hsite
    have hopsC : (MInst.call ⟨.reg (.vreg tv .int), retPairs Lu, callDefs Ld⟩).operands = .ok ops := by
      rw [← operands_tryCall_call _ ti]; exact hops
    have hops1 := hopsC
    rw [operands_call_reg] at hops1
    cases hops1
    obtain ⟨hsz', hloc, -, -⟩ := checkStatic_facts hst
    obtain ⟨r0, hregs0⟩ := callRegs_eq_reg (regs := regs)
      (by have := hsz'; simp only [Array.size_map] at this ⊢; simpa using this)
      (fun p hp r hr => (hloc p hp).2 r hr)
    obtain ⟨n0, rfl, hn0, -⟩ : ∃ n, r0 = .x n ∧ n < 29 ∧ n ≠ 16 := by
      have hmem : (tgtOp tv, Loc.reg r0) ∈
          (((tgtOp tv :: (retOps Lu ++ callDefOps Ld)).toArray).zip (regs.map Loc.reg)).toList := by
        simp [Array.toList_zip, Array.toList_map, hregs0]
      obtain ⟨n, hn, h29, h16, -⟩ := locOk_int (hloc _ hmem).1
      exact ⟨n, hn, h29, h16⟩
    obtain ⟨ic, rfl, hasg'⟩ := (assign_call_tryCall _ regs).2 ti i' hasg
    obtain ⟨r1, us', ds', hr1, hic⟩ := assign_call_reg hasg'
    cases hic
    have h0 : regs[0]? = some (.x n0) := by
      rw [← Array.getElem?_toList, hregs0]; rfl
    rw [h0] at hr1
    cases hr1
    have hc := hL.compiled g hg
    obtain ⟨lm, hlm⟩ := FnAsm.layout_labelOffsets hc.layout
    have htgt : blrTarget t = some (lo64 (regVal t (.x n0))) := by
      obtain ⟨j, x, tt, hj, hx, hpc⟩ := hP
      simp only [MInst.callInsn?, Option.some.injEq] at hx
      subst hx
      rw [lo64_regVal_x]
      exact blrTarget_of hc.layout hlm hj hn0 hpc
        (fun k wd hk => hL.imgCode g hg t (fun a ha => (hG a (he.imgG a ha)).trans (he.imgS a ha)) k wd hk)
    have huv := call_useVals_reg (tv := tv) (s := t) hregs0
    cases hs : symCallee L.Xb L.P (lo64 (regVal t (.x n0))) with
    | none =>
      have hb : (blrTarget t).bind (symCallee L.Xb L.P) = none := by rw [htgt]; exact hs
      have hsem' : csem F ctx L.Xb (.tryCall ⟨.reg (.vreg tv .int), retPairs Lu, callDefs Ld⟩ ti)
          (useVals (tgtOp tv :: (retOps Lu ++ callDefOps Ld)).toArray regs t) w =
          some (outs, w', .goto ti.handlers.length) := by
        rw [← csemV_sub hsem, huv]; simp [csem, L.X_none hs]
      have hex' : callExec L.Hb (.tryCall ⟨.reg (.x n0), us', ds'⟩ ti) t = some s' := by
        simp only [callExec] at hex ⊢
        rw [← L.hooks_base (M := M) (.inl rfl) t (fun _ => hb)]
        exact hex
      exact hL.baseTry g hg F ctx _ ti ⟨hsite, .inl rfl⟩ c wh _ regs _ t w outs w' s' hops hst
        hasg hsw hal herr hsem' hex'
    | some h =>
      exact calleeTry_at ((L.calleeOk_semantic hL hκ ih hg he).os ctx _ hsite.callSite)
        (fun _ _ h => callAt_tryCall_call h) hcl hK hD hG hops hst hasg hP hsw hal herr hsem hex
end LinkSys

namespace LinkSys
variable (L : LinkSys)
variable {κ : Nat → Clif.Function → Nat}

theorem find_sym_semantic (hL : L.OkSemanticNI) (n : String) :
    (∀ h, L.P.func? n = some h → L.P.funcs.find? (fun h' => L.Xb.sym h'.name 0 == L.Xb.sym n 0) = some h) ∧
    (L.P.func? n = none → L.P.funcs.find? (fun h' => L.Xb.sym h'.name 0 == L.Xb.sym n 0) = none) := by
  constructor
  · intro h hpf
    cases hf : L.P.funcs.find? (fun h' => L.Xb.sym h'.name 0 == L.Xb.sym n 0) with
    | none =>
      obtain ⟨hh, rfl⟩ := Clif.Program.func?_some hpf
      have := List.find?_eq_none.mp hf h hh
      simp at this
    | some h' =>
      have hh' := List.mem_of_find?_eq_some hf
      have he := List.find?_some hf
      simp only [beq_iff_eq] at he
      have := hL.symInj h' hh' n he
      subst this
      rw [func?_of_mem hL.names hh'] at hpf
      cases hpf; rfl
  · intro hn
    cases hf : L.P.funcs.find? (fun h' => L.Xb.sym h'.name 0 == L.Xb.sym n 0) with
    | none => rfl
    | some h' =>
      have hh' := List.mem_of_find?_eq_some hf
      have he := List.find?_some hf
      simp only [beq_iff_eq] at he
      have := hL.symInj h' hh' n he
      subst this
      rw [func?_of_mem hL.names hh'] at hn
      cases hn
end LinkSys

namespace LinkSys
variable (L : LinkSys)
variable {κ : Nat → Clif.Function → Nat}

theorem progResult_semantic (hL : L.OkSemanticNI) [hR : L.CrunOk] (hκ : L.Budget κ) {M : Nat} (ih : 0 < M → L.Thm κ (M - 1)) {g h : Clif.Function}
    (hg : g ∈ L.P.funcs) (hh : h ∈ L.P.funcs)
    (hcallee : L.Callee g h) {F : BitVec 64 → Prop}
    (himgF : ∀ a, L.Img a → F a) {c : BitVec 64}
    (hroom : κ M g ≤ c.toNat) (hdead : ∀ a, StackBelow (κ M g) c a → F a ∧ ¬ L.Img a)
    (halign : c.toNat % 16 = 0)
    {sl : List (Clif.SlotId × Nat)} {cm : Clif.Mem} {w : Arm.ArmState} {args : List CV}
    {vals rvals : List Clif.Val} {cm' : Clif.Mem} {cs : Clif.State}
    (hargs : ArgsAt h.sig vals args w) (hsav : StackArgsAvoid F h.sig vals w)
    (hmr : RelW ⟨F, L.syms, (L.A g).af.slotBase, (RAFrame.compute (L.A g).vcp (L.A g).rf).intBase⟩
      g c sl cm w)
    (hpl : L.NeedSlots → L.PlaceAt cm c) (hinit : Clif.initState L.P h.name vals cm = .ok cs)
    (hret : L.crun M cs = .returned rvals cm') :
    ∃ outs w', L.progX κ M F h args w = some (outs, w') ∧ outs.length = (sigRets h.sig).length ∧
      PrefixHold rvals outs ∧
      RelW ⟨F, L.syms, (L.A g).af.slotBase, (RAFrame.compute (L.A g).vcp (L.A g).rf).intBase⟩
        g c sl cm' w' := by
  have hpf := func?_of_mem hL.names hh
  have hM : 0 < M := by
    cases M with
    | zero => exact absurd hret (hR.zero cs rvals cm')
    | succ M => omega
  obtain ⟨Nr, hretN⟩ := hR.runs M cs _ hret (.inl ⟨_, _, rfl⟩)
  obtain ⟨⟨hmemR0, hslot, hout⟩, hsp, herrw⟩ := hmr
  have hroom' : frameDrop (L.A h).af + κ (M - 1) h ≤ (spv w).toNat := by
    rw [hsp]; have := L.budget_step hκ hM hg hcallee; omega
  have hdead' : ∀ a, StackBelow (frameDrop (L.A h).af + κ (M - 1) h) (spv w) a →
      F a ∧ ¬ L.Img a := fun a ha =>
    hdead a (by rw [← hsp]; exact stackBelow_mono ha (L.budget_step hκ hM hg hcallee))
  have hib : ((RAFrame.compute (L.A h).vcp (L.A h).rf).intBase = 0 ∧
      (RAFrame.compute (L.A h).vcp (L.A h).rf).size = (L.A h).af.frameSize) ∨ L.NeedNI := by
    by_cases h0 : (RAFrame.compute (L.A h).vcp (L.A h).rf).intBase = 0
    · by_cases h1 : (RAFrame.compute (L.A h).vcp (L.A h).rf).size = (L.A h).af.frameSize
      · exact .inl ⟨h0, h1⟩
      · exact .inr ⟨g, hg, h, hcallee, .inr h1⟩
    · exact .inr ⟨g, hg, h, hcallee, .inl h0⟩
  have hplw : L.NeedSlots → L.PlaceAt cm (spv w) := fun hN => by rw [hsp]; exact hpl hN
  obtain ⟨us, outsV, wf, hus, hlen, hhold, hmemR, -, hcall, -⟩ :=
    L.progCall_semantic hL hM (ih hM) hpf ⟨g, hg, hcallee⟩ hib himgF herrw (by rw [hsp]; exact halign)
      hroom' hdead' hmemR0 hargs hsav hplw hinit hret
  obtain ⟨kc, hc_eq, hc_ret⟩ := hcall _ (L.callerOk_canon_semantic hL hh himgF args w)
  have hcond : L.Cond κ M F h args w ∧ Arm.r .ERR (L.pcall M h (L.canon h args w)) = .None := by
    refine ⟨⟨hM, herrw, by rw [hsp]; exact halign, hroom', hdead', vals, cm, cs, rvals, cm',
      hmemR0, hargs, hsav, hplw, hinit, hret⟩, ?_⟩
    rw [hc_eq, r_set_program]; exact hc_ret.ret.err
  have hspT : spv (L.pcall M h (L.canon h args w)) = spv w := by
    rw [hc_eq]
    simp only [spv]
    rw [r_set_program]
    have := hc_ret.ret.sp
    simp only [spv] at this
    rw [this, r_enterAt _ _ (by simp) (by simp)]
    exact (L.callerOk_canon_semantic hL hh himgF args w).world.1 _ (by simp [Masked])
  have hce := clifEntry_initState (f := h) hpf hinit
  have hlr : rvals.length ≤ (sigRets h.sig).length := by
    have hrt := Clif.runLoop_returned_tys hL.free Nr cs rvals cm' (runInv_entry hh hce) hretN
    have hbot : cs.bottom = h := by simp [Clif.State.bottom, hce.callers, hce.func]
    rw [hbot] at hrt
    have := congrArg List.length hrt
    simp only [List.length_map, Clif.AbiParam.tys] at this
    rw [this]; exact returns_le_sigRets _
  refine ⟨_, _, by rw [progX, if_pos hcond], ?_, ⟨by simpa using hlr, fun j v x hv hx => ?_⟩,
    ⟨⟨⟨fun a b hv hb => ?_, hmemR.valid, hmemR.symbols⟩, ?_, ?_⟩, ?_, hcond.2⟩⟩
  · rw [List.length_map, List.length_range]
  · -- the results
    have hjr : j < rvals.length := (List.getElem?_eq_some_iff.mp hv).1
    have hju : j < us.length := by have := hhold.1; omega
    simp only [List.getElem?_map, List.getElem?_range (by omega : j < (sigRets h.sig).length),
      Option.map_some, Option.some.injEq] at hx
    subst hx
    have hus_j : us[j]? = some ((us[j]'hju).1, Reg.x j) := by
      have := congrArg (·[j]?) hus
      simp only [List.getElem?_map, List.getElem?_range hju, List.getElem?_eq_getElem hju,
        Option.map_some, Option.some.injEq] at this
      rw [List.getElem?_eq_getElem hju, ← this]
    have hoj : outsV[j]? = some (outsV[j]'(by omega)) := List.getElem?_eq_getElem _
    rw [hc_eq, regVal_set_program, hc_ret.regs j _ _ _ hus_j hoj]
    exact hhold.2 j v _ hv hoj
  · -- the bytes of the live allocations
    rw [← hmemR.bytes a b hv hb]
    simp only [Arm.read_mem, Arm.read_store]
    rw [hc_eq, mem_set_program, hc_ret.mem _ (by simpa using (hmemR.valid a 1 hv).2 0 (by omega))]
  · simpa [Rel.slotReg, hspT] using hslot
  · -- the caller's outgoing area: the callee's run creates no allocation there
    by_cases hib0 : (RAFrame.compute (L.A g).vcp (L.A g).rf).intBase = 0
    · rw [hib0]; exact outRel_zero _ _ _
    · refine ⟨hout.1, by rw [hspT]; exact hout.2.1, fun a n hv k hk j hj => ?_⟩
      rw [hspT]
      by_cases hN : L.NeedSlots
      · exact hout.2.2 a n (Clif.runLoop_allocs hL.free (hL.baseKeepsAllocs hN) Nr cs rvals cm'
          (runInv_entry hh hce) (Clif.initState_allocInv hinit) hretN a n hv) k hk j hj
      have hsl : h.slots = [] := Classical.byContradiction fun hne =>
        hN ⟨g, hg, h, hcallee, hne⟩
      obtain ⟨-, pl, hcs⟩ := initState_noSlots hpf hsl hinit
      have hv0 := runLoop_valid hL.free (hL.baseNoAlloc ⟨g, hg, hib0⟩) (L.slotFree hN) Nr
        cs rvals cm' (runInv_entry hh hce)
        (fun hkk => by
          have ⟨k0, hk0, hnk⟩ := hkk
          refine ⟨(hL.indScope k0 hk0 hnk).keep, fun h' hh' hs' => hL.addrSlots hN ⟨g, hg, hib0⟩ hkk h' hh' ?_⟩
          rw [hcs] at hs'; simpa [hmemR0.symbols] using hs') hretN a n hv
      rw [hcs] at hv0
      exact hout.2.2 a n hv0 k hk j hj
  · rw [hspT, hsp]
end LinkSys

namespace LinkSys
variable (L : LinkSys)
variable {κ : Nat → Clif.Function → Nat}

theorem envOf_keeps_semantic (hL : L.OkSemanticNI) [hR : L.CrunOk] {M : Nat} {g : Clif.Function} {c : BitVec 64}
    (hk : Opt.EnvKeepsSymbols L.base) : Opt.EnvKeepsSymbols (L.envOf M g c) := by
  intro n G hG vals m rvals m' hr
  rcases L.envOf_some hG with ⟨hpf, hb⟩ | ⟨_, _, _, G0, h, hG0⟩
  · have hl : (Clif.linkEnvR L.P L.base (L.crun M)).extern n = some G := by
      rw [Clif.linkEnvR_none hpf]; exact hb
    exact Clif.linkEnvR_keeps (hR.runs M) hL.free hk n G hl vals m rvals m' hr
  · exact Clif.linkEnvR_keeps (hR.runs M) hL.free hk n G0 h vals m rvals m'
      (hG0 vals m rvals m' hr).2
end LinkSys

namespace LinkSys
variable (L : LinkSys)
variable {κ : Nat → Clif.Function → Nat}

theorem xCallsOk_semantic (hL : L.OkSemanticNI) [L.CrunOk] (hκ : L.Budget κ) {M : Nat} (ih : 0 < M → L.Thm κ (M - 1)) {g : Clif.Function}
    (hg : g ∈ L.P.funcs) {F : BitVec 64 → Prop} (himgF : ∀ a, L.Img a → F a) {c : BitVec 64}
    (hroom : κ M g ≤ c.toNat)
    (hdead : ∀ a, StackBelow (κ M g) c a → F a ∧ ¬ L.Img a) (halign : c.toNat % 16 = 0) :
    XCallsOk (L.envOf M g c) (g.externs.map (·.2))
      (RelW ⟨F, L.syms, (L.A g).af.slotBase, (RAFrame.compute (L.A g).vcp (L.A g).rf).intBase⟩
        g c) (L.X κ M g F) := by
  intro ext hin gsem sl cm w d uses args vals rvals cm' hgs hd hargs hmr hret hrl
  rcases L.envOf_some hgs with ⟨hpf, hgs⟩ | ⟨h, hpf, hdecl, G0, hgs, hG0⟩
  · obtain ⟨outs, w', hx, h1, h2, h3⟩ := hL.baseX g hg F (L.A g).af.slotBase
      (RAFrame.compute (L.A g).vcp (L.A g).rf).intBase c ext
      (List.mem_filter.mpr ⟨hin, by simp [hpf]⟩) gsem sl cm w d uses args vals rvals cm' hgs hd
      hargs hmr hret hrl
    refine ⟨outs, w', ?_, h1, h2, h3⟩
    rcases hd with ⟨rfl, rfl⟩ | ⟨rfl, -, rfl⟩
    · rw [L.X_base hpf _ _ F]; exact hx
    · rw [L.X_none (by
        show L.P.funcs.find? (fun h' => L.Xb.sym h'.name 0 == lo64 (ofX (L.Xb.sym ext.name 0))) = none
        rw [lo64_ofX]; exact (L.find_sym_semantic hL ext.name).2 hpf)]
      exact hx
  · obtain ⟨hh, hname⟩ := Clif.Program.func?_some hpf
    have hsig := hL.declSig g hg ext hin h hpf
    obtain ⟨hpl, hret⟩ := hG0 _ _ _ _ hret
    rw [Clif.linkEnvR_some hpf] at hgs
    cases hgs
    -- the callee's whole-program run
    simp only at hret
    cases hinit : Clif.initState L.P ext.name vals cm with
    | trap c' => rw [hinit] at hret; cases hret
    | stuck m' => rw [hinit] at hret; cases hret
    | ok cs =>
    rw [hinit] at hret
    simp only at hret
    rw [hsig] at hargs
    have hout := hmr.1.2.2
    have hsp := hmr.2.1
    -- the stack-passed arguments are in the caller's outgoing area, outside `F`
    have hsav : StackArgsAvoid F h.sig vals w := by
      intro off v hm k hk
      obtain ⟨i, hi⟩ := List.mem_iff_getElem?.mp hm
      rw [List.getElem?_zip_eq_some] at hi
      obtain ⟨hli, hvi⟩ := hi
      have hty := (clifEntry_initState (f := h) (by rw [hname]; exact hpf)
        (by rw [hname]; exact hinit)).sig
      obtain ⟨p, hp⟩ : ∃ p, h.sig.params[i]? = some p := by
        have := congrArg (·[i]?) hty
        simp only [List.getElem?_map, hvi, Option.map_some] at this
        cases hp : h.sig.params[i]? with
        | none => rw [hp] at this; cases this
        | some p => exact ⟨p, rfl⟩
      have hvp : v.ty = p.ty := by
        have := congrArg (·[i]?) hty
        simp only [List.getElem?_map, hvi, hp, Option.map_some, Option.some.injEq] at this
        exact this
      have hfit := hL.outFits g hg ext hin (by simp [hpf]) i off p (by rw [hsig]; exact hli)
        (by rw [hsig]; exact hp)
      rw [hvp] at hk
      rw [add_ofNat_add]
      have hav : Avoids F (RAFrame.compute (L.A g).vcp (L.A g).rf).intBase (spv w) := hout.2.1
      exact hav (off + k) (by omega)
    rw [← hname] at hinit
    obtain ⟨outs, w', hx, hol, hho, hmr'⟩ :=
      L.progResult_semantic hL hκ ih hg hh (.inr (.inl ⟨ext, hin, hpf⟩)) himgF hroom hdead halign hargs hsav
        hmr hpl hinit hret
    refine ⟨outs, w', ?_, by rw [hol, hsig], hho, hmr'⟩
    rcases hd with ⟨rfl, rfl⟩ | ⟨rfl, hcol, rfl⟩
    · rw [L.X_prog hpf]; exact hx
    · have hs : symCallee L.Xb L.P (lo64 (ofX ((L.X κ M g F).sym ext.name 0))) = some h := by
        show L.P.funcs.find? (fun h' => L.Xb.sym h'.name 0 == lo64 (ofX (L.Xb.sym ext.name 0))) = some h
        rw [lo64_ofX]; exact (L.find_sym_semantic hL ext.name).1 h hpf
      have hto : L.IndTo g h := by
        refine ⟨by rw [hname]; exact hdecl, ?_⟩
        rcases hdecl with hdn | ⟨-, -, hall⟩
        · exact .inl ⟨by rw [hname]; exact hdn, ext, hin, hname.symm, hcol⟩
        · obtain ⟨sig, hs, hm⟩ := hall h hpf
          exact .inr ⟨sig, hs, hm, hm.returns_length⟩
      rw [L.X_ind hs, if_pos ⟨hto, argsAt_regLocs hargs⟩]
      exact hx
end LinkSys

namespace LinkSys
variable (L : LinkSys)
variable {κ : Nat → Clif.Function → Nat}

theorem xCallsIndOk_semantic (hL : L.OkSemanticNI) [L.CrunOk] (hκ : L.Budget κ) {M : Nat} (ih : 0 < M → L.Thm κ (M - 1)) {g : Clif.Function}
    (hg : g ∈ L.P.funcs) {F : BitVec 64 → Prop} (himgF : ∀ a, L.Img a → F a) {c : BitVec 64}
    (hroom : κ M g ≤ c.toNat)
    (hdead : ∀ a, StackBelow (κ M g) c a → F a ∧ ¬ L.Img a) (halign : c.toNat % 16 = 0) :
    XCallsIndOk (L.envOf M g c) (indSigs g)
      (RelW ⟨F, L.syms, (L.A g).af.slotBase, (RAFrame.compute (L.A g).vcp (L.A g).rf).intBase⟩
        g c) (L.X κ M g F) := by
  intro sig hsig n gsem sl cm w u args vals rvals cm' hgs hsg hu hl8 hall hmr hret hrl hty
  rcases L.envOf_some hgs with ⟨hpf, hgs⟩ | ⟨h, hpf, hdecl, G0, hgs, hG0⟩
  · have hs : symCallee L.Xb L.P (lo64 u) = none := by
      show L.P.funcs.find? (fun h' => L.Xb.sym h'.name 0 == lo64 u) = none
      rw [hu]; exact (L.find_sym_semantic hL n).2 hpf
    obtain ⟨outs, w', hx, h1, h2, h3⟩ := hL.baseXI g hg F (L.A g).af.slotBase
      (RAFrame.compute (L.A g).vcp (L.A g).rf).intBase c sig hsig n gsem sl cm w u args vals rvals
      cm' hgs (fun _ h => nomatch h) hu hl8 hall hmr hret hrl hty
    exact ⟨outs, w', by rw [L.X_none hs]; exact hx, h1, h2, h3⟩
  · obtain ⟨hh, hname⟩ := Clif.Program.func?_some hpf
    subst hname
    have hnf : ¬ Clif.IndFree g := fun hif => by
      rw [indSigs_nil_of_indFree hif] at hsig; cases hsig
    have hdeclS := hL.indSig g hg hnf
    have hs : symCallee L.Xb L.P (lo64 u) = some h := by
      show L.P.funcs.find? (fun h' => L.Xb.sym h'.name 0 == lo64 u) = some h
      rw [hu]; exact (L.find_sym_semantic hL h.name).1 h hpf
    obtain ⟨hpl, hret⟩ := hG0 _ _ _ _ hret
    rw [Clif.linkEnvR_some hpf] at hgs
    cases hgs
    simp only at hret
    cases hinit : Clif.initState L.P h.name vals cm with
    | trap c' => rw [hinit] at hret; cases hret
    | stuck m' => rw [hinit] at hret; cases hret
    | ok cs =>
    rw [hinit] at hret
    simp only at hret
    have hce := clifEntry_initState (f := h) hpf hinit
    have hvl : vals.length = h.sig.params.length := by
      have := congrArg List.length hce.sig
      simpa using this
    -- the call site's signature matches `h`'s (`Clif.callExternAt` checks it against `sigOf`)
    have hm : IndSigMatch sig h :=
      hsg h.sig (by simp only [envOf, Clif.linkEnvR_sigOf, hpf, Option.map_some])
    obtain ⟨⟨bytes, hb, hb8⟩, hsr⟩ := hdeclS h hh hdecl (.inl ⟨sig, hsig, hm⟩)
    have hargs : ArgsAt h.sig vals args w := (argsAt_iff_of_regs hb hb8 hvl).mpr hall
    have hsav : StackArgsAvoid F h.sig vals w := by
      intro off v hm
      obtain ⟨r, hr⟩ := (locsOf_small hb hb8).2 _ (List.of_mem_zip hm).1
      cases hr
    obtain ⟨outs, w', hx, hol, hho, hmr'⟩ :=
      L.progResult_semantic hL hκ ih hg hh (.inr (.inr ⟨hh, hdecl⟩)) himgF hroom hdead halign hargs hsav
        hmr hpl hinit hret
    refine ⟨outs, w', ?_, ?_, hho, hmr'⟩
    · rw [L.X_ind hs, if_pos ⟨⟨hdecl, .inr ⟨sig, hsig, hm, hm.returns_length⟩⟩,
        argsAt_regLocs hargs⟩]
      exact hx
    · rw [hol]
      exact hsr sig hsig hm.ty hm.returns_length
end LinkSys

namespace LinkSys
variable (L : LinkSys)
variable {κ : Nat → Clif.Function → Nat}

theorem regVal_canon_eq_semantic (hL : L.OkSemanticNI) {h : Clif.Function} (hh : h ∈ L.P.funcs) {args : List CV}
    (hlen : args.length = (regLocs h.sig).length) (w w' : Arm.ArmState) :
    ∀ r ∈ regLocs h.sig, regVal (L.canon h args w') r = regVal (L.canon h args w) r := by
  intro r hr
  obtain ⟨hnd, harg, -⟩ := hL.argRegs h hh
  obtain ⟨j, hj⟩ := List.mem_iff_getElem?.mp hr
  have hjl : j < args.length := by have := (List.getElem?_eq_some_iff.mp hj).1; omega
  rw [L.regVal_canon _ _ _ (harg r hr), L.regVal_canon _ _ _ (harg r hr),
    placeArgs_regVal _ _ _ hnd harg hj (List.getElem?_eq_getElem hjl),
    placeArgs_regVal _ _ _ hnd harg hj (List.getElem?_eq_getElem hjl)]
end LinkSys

namespace LinkSys
variable (L : LinkSys)
variable {κ : Nat → Clif.Function → Nat}

theorem progX_ni_semantic (hL : L.OkSemanticNI) [hR : L.CrunOk] (hN : L.NeedNI) {M : Nat} (ih : 0 < M → L.Thm κ (M - 1))
    {g h : Clif.Function} (hg : g ∈ L.P.funcs) (hh : h ∈ L.P.funcs)
    (hcallee : L.Callee g h) {F Z : BitVec 64 → Prop}
    (himgF : ∀ a, L.Img a → F a) (hFZ : ∀ a, F a → Z a) {w w' : Arm.ArmState}
    (hsw : SameWorld Z w w') {cm : Clif.Mem} {vals : List Clif.Val} {args : List CV}
    (hm : MemRel F L.syms cm w) (hm' : MemRel F L.syms cm w') (ha : ArgsAt h.sig vals args w)
    (ha' : ArgsAt h.sig vals args w') {cs : Clif.State} {rvals : List Clif.Val} {cm' : Clif.Mem}
    (hpl : L.NeedSlots → L.PlaceAt cm (spv w)) (hinit : Clif.initState L.P h.name vals cm = .ok cs)
    (hrun : L.crun M cs = .returned rvals cm') {o o' : List CV}
    {x x' : Arm.ArmState} (hx : L.progX κ M F h args w = some (o, x))
    (hx' : L.progX κ M F h args w' = some (o', x')) : o = o' ∧ SameWorld Z x x' := by
  have hpf := func?_of_mem hL.names hh
  unfold progX at hx hx'
  split at hx
  case isFalse => cases hx
  rename_i hc
  split at hx'
  case isFalse => cases hx'
  simp only [Option.some.injEq, Prod.mk.injEq] at hx hx'
  obtain ⟨rfl, rfl⟩ := hx
  obtain ⟨rfl, rfl⟩ := hx'
  obtain ⟨⟨hM, herr, hal, hroom, hdead, vals1, cm1, cs1, rvals1, cm1', -, -, hsav1, -, hinit1, -⟩,
    -⟩ :=
    hc
  have hty : vals.map (·.ty) = vals1.map (·.ty) := by
    rw [(clifEntry_initState hpf hinit).sig, (clifEntry_initState hpf hinit1).sig]
  have hsav := stackArgsAvoid_tys hsav1 hty
  obtain ⟨us, outs, wf, hus, hlen, hhold, -, hrs, hall, hni⟩ :=
    L.progCall_semantic hL hM (ih hM) hpf ⟨g, hg, hcallee⟩ (.inr hN) himgF herr hal hroom hdead hm ha
      hsav hpl hinit hrun
  have hc0 := L.callerOk_canon_semantic hL hh himgF args w
  have hc1 := L.callerOk_canon_semantic hL hh himgF args w'
  have hsp' : spv w' = spv w := (hsw.1 _ (by simp [Masked])).symm
  obtain ⟨k, heq, hret⟩ := hall _ hc0
  obtain ⟨k', heq', hret'⟩ := hni hN Z (L.canon h args w') hFZ
    ((SameWorld.mono hFZ hc1.world).trans hsw.symm) hc1.img
    (L.regVal_canon_eq_semantic hL hh (argsAt_regLocs ha) w w') hc1.ra (L.memRel_canon himgF hm' h args)
    (fun off v hmz j hj => by
      rw [L.mem_canon, mem_withImg, if_neg (fun hi => hsav off v hmz j hj (himgF _ hi))]
      exact stackArgs_bytes ha.2.2 ha'.2.2 hsp' off v hmz j hj)
  -- the callee's ABI results are among the defs of its return site
  have hsr : (sigRets h.sig).length ≤ us.length := by
    cases hs : h.sig.params.any (·.purpose == .sret)
    · have hce := clifEntry_initState hpf hinit
      obtain ⟨Nr, hrunN⟩ := hR.runs M cs _ hrun (.inl ⟨_, _, rfl⟩)
      have hrt := Clif.runLoop_returned_tys hL.free Nr cs rvals cm' (runInv_entry hh hce) hrunN
      have hbot : cs.bottom = h := by simp [Clif.State.bottom, hce.callers, hce.func]
      rw [hbot] at hrt
      have e := congrArg List.length hrt
      simp only [List.length_map, Clif.AbiParam.tys] at e
      rw [sigRets_of_noSret hs, ← e]
      have := hhold.1
      omega
    · exact hL.sretRets h hh hs us hrs
  have hres : ∀ (u : Arm.ArmState) (kk : Nat) (Y : BitVec 64 → Prop) (G : BitVec 64 → Prop),
      ActRet (Arm.r .PC u + 4) Y G us outs wf (enterAt (L.A h) u)
        (runX (L.mach (M - 1) h) kk (enterAt (L.A h) u)) →
      ∀ j (hj : j < (sigRets h.sig).length),
        regVal (Arm.set_program (runX (L.mach (M - 1) h) kk (enterAt (L.A h) u)) u.program)
          (.x j) = outs[j]'(by omega) := by
    intro u kk Y G hr j hj
    have hju : j < us.length := by omega
    have hus_j : us[j]? = some ((us[j]'hju).1, Reg.x j) := by
      have := congrArg (·[j]?) hus
      simp only [List.getElem?_map, List.getElem?_range hju, List.getElem?_eq_getElem hju,
        Option.map_some, Option.some.injEq] at this
      rw [List.getElem?_eq_getElem hju, ← this]
    rw [regVal_set_program, hr.regs j _ _ _ hus_j (List.getElem?_eq_getElem _)]
  refine ⟨?_, ?_⟩
  · apply List.ext_getElem (by simp)
    intro j h1 h2
    simp only [List.getElem_map, List.getElem_range]
    simp only [List.length_map, List.length_range] at h1
    rw [heq, heq', hres _ k _ _ hret j h1, hres _ k' _ _ hret' j h1]
  · rw [heq, heq']
    refine ⟨fun f hf => ?_, fun a ha => ?_, ?_⟩
    · rw [r_set_program, r_set_program]
      by_cases h29 : f = .GPR 29#5
      · subst h29
        have e1 := hret.ret.savedX 29 (by unfold calleeSavedX; decide)
        have e2 := hret'.ret.savedX 29 (by unfold calleeSavedX; decide)
        simp only [xreg] at e1 e2
        rw [show (BitVec.ofNat 5 29) = 29#5 from rfl] at e1 e2
        rw [e1, e2, r_enterAt _ _ (by simp) (by simp), r_enterAt _ _ (by simp) (by simp),
          hc0.world.1 _ hf, hc1.world.1 _ hf, hsw.1 _ hf]
      by_cases h31 : f = .GPR 31#5
      · subst h31
        have e1 := hret.ret.sp
        have e2 := hret'.ret.sp
        simp only [spv] at e1 e2
        rw [e1, e2, r_enterAt _ _ (by simp) (by simp), r_enterAt _ _ (by simp) (by simp),
          hc0.world.1 _ hf, hc1.world.1 _ hf, hsw.1 _ hf]
      rw [hret.fields f hf h29 h31, hret'.fields f hf h29 h31]
    · rw [mem_set_program, mem_set_program, hret.mem a (fun hf => ha (hFZ a hf)), hret'.mem a ha]
    · rw [program_set_program, program_set_program, L.program_canon, L.program_canon]
      exact hsw.2.2
end LinkSys

namespace LinkSys
variable (L : LinkSys)
variable {κ : Nat → Clif.Function → Nat}

theorem xni_semantic (hL : L.OkSemanticNI) [L.CrunOk] (hN : L.NeedNI) {M : Nat} (ih : 0 < M → L.Thm κ (M - 1))
    {g : Clif.Function} (hg : g ∈ L.P.funcs) {F : BitVec 64 → Prop}
    (himgF : ∀ a, L.Img a → F a) (c : BitVec 64) :
    XNI F L.syms (g.externs.map (·.2)) (indSigs g) c
      (CallLg (L.envOf M g c) (g.externs.map (·.2)) (indSigs g)) (L.X κ M g F) := by
  intro n sig vals cm args d uses Z w w' o x o' x' hlg hd hFZ hsw hm hm' hc1 hc2 hA hx hx'
  obtain ⟨hkind, G, rv, cm'', hG, hGo⟩ := hlg
  rcases L.envOf_some hG with ⟨hpf, hb⟩ | ⟨h, hpf, hdecl, G0, hGl, hG0⟩
  · have hbase := hL.baseNI hN g hg F c n sig vals cm args d uses Z w w' o x o' x'
      ⟨hpf, hkind, G, rv, cm'', hb, hGo⟩ hd hFZ hsw hm hm' hc1 hc2 hA
    rcases hd with ⟨rfl, rfl⟩ | ⟨rfl, u, rfl, hu⟩
    · rw [L.X_base hpf] at hx hx'
      exact hbase hx hx'
    · have hs : symCallee L.Xb L.P (lo64 u) = none := by
        show L.P.funcs.find? (fun h' => L.Xb.sym h'.name 0 == lo64 u) = none
        rw [hu]; exact (L.find_sym_semantic hL n).2 hpf
      rw [L.X_none hs] at hx hx'
      exact hbase hx hx'
  · obtain ⟨hh, hname⟩ := Clif.Program.func?_some hpf
    subst hname
    obtain ⟨hpl, hGo⟩ := hG0 _ _ _ _ hGo
    have hplw : L.NeedSlots → L.PlaceAt cm (spv w) := fun hS => hc1 ▸ hpl hS
    rw [Clif.linkEnvR_some hpf] at hGl
    cases hGl
    simp only at hGo
    cases hinit : Clif.initState L.P h.name vals cm with
    | trap c' => rw [hinit] at hGo; cases hGo
    | stuck m' => rw [hinit] at hGo; cases hGo
    | ok cs =>
    rw [hinit] at hGo
    simp only at hGo
    have hce := clifEntry_initState (f := h) hpf hinit
    have hvl : vals.length = h.sig.params.length := by
      have := congrArg List.length hce.sig
      simpa using this
    have hcallee : L.Callee g h := .inr (.inr ⟨hh, hdecl⟩)
    have hAA : ArgsAt h.sig vals args w ∧ ArgsAt h.sig vals args w' := by
      rcases hA with ⟨⟨e', he', hen', hes⟩, h1, h2⟩ | ⟨hsig, h8, hall⟩
      · have := hL.declSig g hg e' he' h (by rw [hen']; exact hpf)
        rw [← hes, this] at h1 h2
        exact ⟨h1, h2⟩
      · have hnf : ¬ Clif.IndFree g := fun hif => by
          rw [indSigs_nil_of_indFree hif] at hsig; cases hsig
        have hdeclS := hL.indSig g hg hnf
        -- the call entered `h`: its parameter types are the call's signature's
        have hmatch : IndTyMatch sig h := by
          rcases hkind with ⟨e', he', hen', hes⟩ | ⟨-, hty⟩
          · have := hL.declSig g hg e' he' h (by rw [hen']; exact hpf)
            rw [← hes, this]
            rfl
          · exact hce.sig.symm.trans hty
        obtain ⟨⟨bytes, hb, hb8⟩, -⟩ := hdeclS h hh hdecl (L.indReach hpf hdecl hsig hmatch)
        exact ⟨(argsAt_iff_of_regs hb hb8 hvl).mpr hall, (argsAt_iff_of_regs hb hb8 hvl).mpr hall⟩
    rcases hd with ⟨rfl, rfl⟩ | ⟨rfl, u, rfl, hu⟩
    · rw [L.X_prog hpf] at hx hx'
      exact L.progX_ni_semantic hL hN ih hg hh hcallee himgF hFZ hsw hm hm' hAA.1 hAA.2 hplw hinit hGo hx hx'
    · have hs : symCallee L.Xb L.P (lo64 u) = some h := by
        show L.P.funcs.find? (fun h' => L.Xb.sym h'.name 0 == lo64 u) = some h
        rw [hu]; exact (L.find_sym_semantic hL h.name).1 h hpf
      rw [L.X_ind hs] at hx hx'
      split at hx
      · rename_i hif
        rw [if_pos hif] at hx'
        exact L.progX_ni_semantic hL hN ih hg hh hcallee himgF hFZ hsw hm hm' hAA.1 hAA.2 hplw hinit hGo hx
          hx'
      · cases hx
end LinkSys

namespace LinkSys
variable (L : LinkSys)
variable {κ : Nat → Clif.Function → Nat}

theorem xTls_semantic (hL : L.OkSemanticNI) (hN : L.NeedNI) {M : Nat} {g : Clif.Function} {F : BitVec 64 → Prop} :
    XTls F (L.X κ M g F) :=
  fun Z n w w' hFZ hsw => hL.baseTlsNI hN F Z n w w' hFZ hsw
end LinkSys

namespace LinkSys
variable (L : LinkSys)
variable {κ : Nat → Clif.Function → Nat}

theorem actInv_step_semantic (hL : L.OkSemanticNI) [hR : L.CrunOk] {M : Nat} {g : Clif.Function} (hg : g ∈ L.P.funcs) {c : BitVec 64}
    {s s1 : Clif.State} (hJ : L.ActInv g c s)
    (hs : Clif.step (Clif.linkEnvR L.P L.base (L.crun M)) L.P.bare s = .next s1) :
    L.ActInv g c s1 := by
  obtain ⟨hI, hc, hpl⟩ := hJ
  have hPf : ∀ f ∈ (L.P.only g).funcs, Clif.LinkFree f := fun f hf => by
    simp only [Clif.Program.only, List.mem_cons, List.not_mem_nil, or_false] at hf
    subst hf; exact hL.free f hg
  have hc1 := Clif.step_bare_callers hPf hI.1 hc hs
  refine ⟨(Clif.step_next_linv hPf hI hs (fun _ h => by simp at h)).1, hc1, fun hN => ?_⟩
  obtain ⟨sps, hp⟩ := hpl hN
  refine ⟨sps, ?_⟩
  rcases Clif.step_next_cases hPf hI hs with ⟨-, -, ⟨hpl', -⟩ | ⟨n, G, vals, rv, hG, hr⟩⟩ |
    ⟨cc, hcc, -⟩ | ⟨cc, hcc, -⟩
  · rw [hpl', hp]
  · rw [Clif.linkEnvR_keepsPlace (hR.runs M) hL.free (hL.baseKeepsPlace hN) n G hG vals s.mem rv
      s1.mem hr, hp]
  · rw [hc1] at hcc; cases hcc
  · rw [hc] at hcc; cases hcc
end LinkSys

namespace LinkSys
variable (L : LinkSys)
variable {κ : Nat → Clif.Function → Nat}

theorem step_envOf_link_semantic (hL : L.OkSemanticNI) {M : Nat} {g : Clif.Function} (hg : g ∈ L.P.funcs)
    {c : BitVec 64} {s : Clif.State} (hJ : L.ActInv g c s) {r : Clif.StepResult}
    (hs : Clif.step (L.envOf M g c) L.P.bare s = r) (hr : ∀ m, r ≠ .stuck m) :
    Clif.step (Clif.linkEnvR L.P L.base (L.crun M)) L.P.bare s = r := by
  have hPf : ∀ f ∈ (L.P.only g).funcs, Clif.LinkFree f := fun f hf => by
    simp only [Clif.Program.only, List.mem_cons, List.not_mem_nil, or_false] at hf
    subst hf; exact hL.free f hg
  rw [L.step_envOf (hL.free g hg) hJ.1.1 hJ.2.2] at hs
  exact step_of_restrict L.envR_restricts hPf hJ.1.1 hs hr
end LinkSys

namespace LinkSys
variable (L : LinkSys)
variable {κ : Nat → Clif.Function → Nat}

theorem runLoop_envOf_semantic (hL : L.OkSemanticNI) [L.CrunOk] {M : Nat} {g : Clif.Function} (hg : g ∈ L.P.funcs)
    {c : BitVec 64} :
    ∀ (n : Nat) (s : Clif.State), L.ActInv g c s →
      Clif.runLoop (L.envOf M g c) L.P.bare n s = Clif.runLoop (L.envR M g) L.P.bare n s
  | 0, _, _ => rfl
  | n + 1, s, hJ => by
    rw [Clif.runLoop_succ', Clif.runLoop_succ', L.step_envOf (hL.free g hg) hJ.1.1 hJ.2.2]
    cases hs : Clif.step (L.envR M g) L.P.bare s with
    | next s1 =>
      have hs' := L.step_envOf_link_semantic hL hg hJ
        ((L.step_envOf (hL.free g hg) hJ.1.1 hJ.2.2).trans hs) (fun _ h => nomatch h)
      exact runLoop_envOf_semantic hL hg n s1 (L.actInv_step_semantic hL hg hJ hs')
    | _ => rfl
end LinkSys

namespace LinkSys
variable (L : LinkSys)
variable {κ : Nat → Clif.Function → Nat}

theorem reach_envOf_semantic (hL : L.OkSemanticNI) [L.CrunOk] {M : Nat} {g : Clif.Function} (hg : g ∈ L.P.funcs)
    {c : BitVec 64} {cs s : Clif.State} (hr : Reach (L.envOf M g c) L.P.bare cs s)
    (hJ : L.ActInv g c cs) :
    Reach (Clif.linkEnvR L.P L.base (L.crun M)) L.P.bare cs s ∧ L.ActInv g c s := by
  induction hr with
  | refl => exact ⟨.refl _, hJ⟩
  | step hs _ ih =>
    have hs' := L.step_envOf_link_semantic hL hg hJ hs (fun _ h => nomatch h)
    obtain ⟨h1, h2⟩ := ih (L.actInv_step_semantic hL hg hJ hs')
    exact ⟨.step hs' h1, h2⟩
end LinkSys

namespace LinkSys
variable (L : LinkSys)
variable {κ : Nat → Clif.Function → Nat}

theorem trapsExplicit_envOf_semantic (hL : L.OkSemanticNI) [L.CrunOk] {M : Nat} {g : Clif.Function} (hg : g ∈ L.P.funcs)
    {c : BitVec 64} {cs : Clif.State} (hJ : L.ActInv g c cs)
    (h : TrapsExplicit (Clif.linkEnvR L.P L.base (L.crun M)) L.P.bare cs) :
    TrapsExplicit (L.envOf M g c) L.P.bare cs where
  stmt := fun s c st rest hr hs hb => by
    obtain ⟨hr', hJs⟩ := L.reach_envOf_semantic hL hg hr hJ
    exact h.stmt s c st rest hr' (L.step_envOf_link_semantic hL hg hJs hs (fun _ h => nomatch h)) hb
  tryCall := fun s c fn args et hr hs hb ht => by
    obtain ⟨hr', hJs⟩ := L.reach_envOf_semantic hL hg hr hJ
    exact h.tryCall s c fn args et hr' (L.step_envOf_link_semantic hL hg hJs hs (fun _ h => nomatch h)) hb ht
  tryCallInd := fun s c callee args et hr hs hb ht => by
    obtain ⟨hr', hJs⟩ := L.reach_envOf_semantic hL hg hr hJ
    exact h.tryCallInd s c callee args et hr'
      (L.step_envOf_link_semantic hL hg hJs hs (fun _ h => nomatch h)) hb ht
  indirect := fun s st rest sig callee args hr hb hi hst =>
    h.indirect s st rest sig callee args (L.reach_envOf_semantic hL hg hr hJ).1 hb hi hst
  tryIndirect := fun s callee args et hr hb ht hB =>
    h.tryIndirect s callee args et (L.reach_envOf_semantic hL hg hr hJ).1 hb ht hB
end LinkSys

namespace LinkSys
variable (L : LinkSys)
variable {κ : Nat → Clif.Function → Nat}

theorem thm_of_semantic (hL : L.OkSemanticNI) [L.CrunOk] (hκ : L.Budget κ) {M : Nat} (ih : 0 < M → L.Thm κ (M - 1)) : L.Thm κ M := by
  intro g hg F vals cs w₀ fuel rvals cm' hWE hrun
  have hc := hL.compiled g hg
  have hI : Clif.LInv (L.P.only g) cs := runInv_entry (by simp [Clif.Program.only]) hWE.clif
  have hJ : L.ActInv g (spv w₀) cs := ⟨hI, hWE.clif.callers, hWE.place⟩
  have hrun' : Clif.runLoop (L.envOf M g (spv w₀)) L.P.bare fuel cs = .returned rvals cm' := by
    rw [L.runLoop_envOf_semantic hL hg fuel cs hJ]; exact hrun
  have h := backend_correct_world_ni_semantic (hL.subset g hg) hc
    (X := L.X κ M g F) (syms := L.syms)
    (env := L.envOf M g (spv w₀)) (K := κ M g) (F := F) (c := spv w₀) (hL.covered g hg)
    (L.xCallsOk_semantic hL hκ ih hg hWE.img hWE.room hWE.dead hWE.align)
    (L.xCallsIndOk_semantic hL hκ ih hg hWE.img hWE.room hWE.dead hWE.align)
    (fun n b hn => hL.symOk n b hn) rfl hWE.clif hWE.rel hWE.args
    (trapsExplicit_of_returned hrun') fuel
  obtain ⟨us, outs, wf, hus, hlen, hhold, hmem, hrs, hall, hni⟩ := h rvals cm' hrun'
  have hAE : ∀ G ra s w₀', L.MachEntry κ M g F G ra s w₀' →
      ActEntry (L.A g).vcp (L.A g).rf (L.A g).af (L.A g).fa (L.A g).fb (κ M g) F G (L.X κ M g F)
        (L.hooks M) (L.A g).base ra s w₀' := fun G ra s w₀' hME =>
    ⟨hME.abi, hME.stack, hME.gfree, hME.hF, L.calleeOk_semantic hL hκ ih hg hME,
      fun _ => L.calleeTryOk_semantic hL hκ ih hg hME,
      fun ht => L.tlsOk_hooks (hL.baseTls g hg (hasTls_of_vcode_semantic hc ht) F (κ M g)), hME.body⟩
  refine ⟨us, outs, wf, hus, hlen, hhold, hmem, hrs, fun G ra s hME => hall (L.hooks M) G
    (L.A g).base ra s (hAE G ra s w₀ hME), fun hN D w₀' hrel' hsw hreg hstk G ra s hME => ?_⟩
  exact hni (L.xni_semantic hL hN ih hg hWE.img (spv w₀)) (L.xTls_semantic hL hN) D w₀' hrel' hsw hreg hstk
    (L.hooks M) G
    (L.A g).base ra s (hAE G ra s w₀' hME)
end LinkSys

namespace LinkSys
variable (L : LinkSys)
variable {κ : Nat → Clif.Function → Nat}

theorem thm_semantic (hL : L.OkSemanticNI) [L.CrunOk] (hκ : L.Budget κ) : ∀ M, L.Thm κ M
  | 0 => L.thm_of_semantic hL hκ fun h => absurd h (Nat.lt_irrefl 0)
  | M + 1 => L.thm_of_semantic hL hκ fun _ => thm_semantic hL hκ M
end LinkSys

namespace LinkSys
variable (L : LinkSys)
variable {κ : Nat → Clif.Function → Nat}

theorem OkSemanticNI.withCrun {L : LinkSys} (hL : L.OkSemanticNI) (c : Nat → Clif.State → Clif.Outcome) :
    (L.withCrun c).OkSemanticNI := by
  cases hL; constructor <;> assumption
end LinkSys

namespace LinkSys
variable (L : LinkSys)
variable {κ : Nat → Clif.Function → Nat}

theorem crunOk_std_semantic (hL : L.OkSemanticNI) : L.std.CrunOk where
  runs M := Clif.runsOf_runLoop L.base L.P M
  zero _ _ _ h := by simp [std, withCrun] at h
  link M hM _ hf s hI hIf hsy _ hEn hEs hEb hEp hst hof :=
    Clif.runLoop_linkN (base := L.base) (syms := L.syms) (M - 1) hL.names hf hL.free
      (hL.indScope _ hf) hEn hEs hEb hEp M s (by omega) hI hIf hsy hst hof
end LinkSys

namespace LinkSys
variable (L : LinkSys)
variable {κ : Nat → Clif.Function → Nat}

theorem crunOk_peak_semantic (hL : L.OkSemanticNI) (F : Nat) : (L.peak F).CrunOk where
  runs M := Clif.runsOf_runD L.base L.P F M
  zero _ _ _ h := by simp [peak, withCrun, Clif.runD] at h
  link M _ _ hf s hI hIf hsy _ hEn hEs hEb hEp hst hof := by
    have hd : 0 < M ∧ Clif.DepthLe L.base L.P (M - 1) s := by
      refine Classical.byContradiction fun hc => hof ?_
      show Clif.runD L.base L.P F M s = _
      simp only [Clif.runD, hc, ↓reduceIte]
    have he : Clif.runD L.base L.P F M s = Clif.runLoop L.base L.P F s := by
      simp only [Clif.runD, hd, and_self, ↓reduceIte]
    obtain ⟨m, hm⟩ := Clif.runLoop_linkD (base := L.base) (syms := L.syms) F (M - 1) hL.names hf
      hL.free (hL.indScope _ hf) hEn hEs hEb hEp F s (by omega) hd.2 hI hIf hsy
      (by rw [← he]; exact hst) (by rw [← he]; exact hof)
    exact ⟨m, hm.trans he.symm⟩
end LinkSys

theorem backend_correct_program_core_semantic (L : LinkSys) (hL : L.OkSemanticNI) [L.CrunOk]
    {κ : Nat → Clif.Function → Nat} (hκ : L.Budget κ) {f : Clif.Function}
    (hf : f ∈ L.P.funcs) (M : Nat) {ra : BitVec 64} {s w₀ : Arm.ArmState} {args : List Clif.Val}
    {cs : Clif.State}
    (hent : AbiEntry (L.A f).fb (L.A f).base ra s) (hres : StackAvail (κ M f) (L.A f).af s)
    (hF : L.F = frameWG (κ M f) (RAFrame.compute (L.A f).vcp (L.A f).rf).intBase
      (RAFrame.compute (L.A f).vcp (L.A f).rf).size (L.A f).af L.Img s)
    (hgfree : ∀ a, L.Img a → ¬ StackBelow (frameDrop (L.A f).af + κ M f) (spv s) a)
    (himg : ∀ a, L.Img a → s.mem a = L.imgMem a)
    (hbe : BodyEntry (L.A f).af s w₀) (hargs : ArgsIn f.sig args s) (hcs : ClifEntry f args cs)
    (hsav : StackArgsAvoid L.Img f.sig args s)
    (hrel : Rel.holds ⟨L.F, L.syms, (L.A f).af.slotBase,
      (RAFrame.compute (L.A f).vcp (L.A f).rf).intBase⟩ f cs.frame.slots cs.mem w₀)
    (hpl : L.NeedSlots → L.PlaceAt cs.mem (spv w₀))
    (htr : TrapsExplicit (Clif.linkEnvR L.P L.base (L.crun M)) L.P.bare cs) {o : Clif.Outcome}
    (hlink : ((∃ vals cm, o = .returned vals cm) ∨ ∃ c, o = .trapped c) →
      ∃ m, Clif.runLoop (L.envR M f) L.P.bare m cs = o) :
    ArmRefines (L.A f).fb (L.A f).base ra (L.mach M f) s o := by
  have hc := hL.compiled f hf
  have hfr := lowerRFunc_frame hc.alloc
  have hst := hres
  obtain ⟨hB, hK⟩ := spBody_toNat hres
  have hd : frameDrop (L.A f).af = (L.A f).af.frameSize + 16 := by simp [frameDrop, hfr]
  -- the world side
  have hWE : L.WorldEntry κ M f L.F args cs w₀ := by
    refine ⟨hcs, ⟨hrel, rfl, ?_⟩, ?_, ?_, ?_, ?_, hL.imgF, hpl⟩
    · rw [hbe.other .ERR (by simp [Masked]) (by simp) (by simp)]; exact hent.err
    · refine argsAtEntry_body hfr hc.entryRegs hbe hargs fun off v hm k hk hk' => ?_
      rw [hF] at hk'
      rcases hk' with hw | hi
      · exact stackArgsAvoid_frameW_semantic hc hres hent hargs off v hm k hk hw
      · exact hsav off v hm k hk hi
    · rw [hbe.sp, hB]; omega
    · intro a ha
      rw [hbe.sp] at ha
      refine ⟨by rw [hF]; exact .inl (.inr ha), fun hi => hgfree a hi ?_⟩
      obtain ⟨h1, h2⟩ := ha
      rw [hB] at h1 h2
      exact ⟨by omega, by omega⟩
    · rw [hbe.sp, hB, hd]
      have := hent.spAligned
      have := L.frameSize_mod_semantic hL hf
      omega
  -- the machine side
  have hME : L.MachEntry κ M f L.F L.Img ra s w₀ :=
    ⟨hent.toCall, hres, hgfree, hF.symm, fun _ h => h, himg,
      hbe.w L.F fun r ⟨_, _, hvb, hi, _, hv⟩ =>
        ((ctlCheck_args (lowerRFunc_ok hc.alloc).2.2 hvb hi).2.2 _ hv).2⟩
  -- the whole-program run is a run of the program without functions
  have hIf : Clif.LInv (L.P.only f) cs := runInv_entry (by simp [Clif.Program.only]) hcs
  cases o with
  | stuck m => trivial
  | outOfFuel => trivial
  | returned vals cm =>
    obtain ⟨m, hm⟩ := hlink (.inl ⟨_, _, rfl⟩)
    obtain ⟨us, outs, wf, hus, hlen, hhold, hmemR, -, hall, -⟩ :=
      L.thm_semantic hL hκ M f hf L.F args cs w₀ m vals cm hWE hm
    obtain ⟨n, hret, -⟩ := hall L.Img ra s hME
    exact armRefines_of_actRet hus hlen hhold hmemR hret
  | trapped c =>
    obtain ⟨m, hm⟩ := hlink (.inr ⟨_, rfl⟩)
    have ih : 0 < M → L.Thm κ (M - 1) := fun _ => L.thm_semantic hL hκ (M - 1)
    have hJ : L.ActInv f (spv w₀) cs := ⟨hIf, hcs.callers, hpl⟩
    have hm' : Clif.runLoop (L.envOf M f (spv w₀)) L.P.bare m cs = .trapped c := by
      rw [L.runLoop_envOf_semantic hL hf m cs hJ]; exact hm
    have h := backend_correct_world_semantic (hL.subset f hf) hc
      (X := L.X κ M f L.F) (syms := L.syms)
      (env := L.envOf M f (spv w₀)) (K := κ M f) (F := L.F) (c := spv w₀) (hL.covered f hf)
      (L.xCallsOk_semantic hL hκ ih hf hL.imgF hWE.room hWE.dead hWE.align)
      (L.xCallsIndOk_semantic hL hκ ih hf hL.imgF hWE.room hWE.dead hWE.align)
      (fun n b hn => hL.symOk n b hn) rfl hWE.clif hWE.rel hWE.args
      (L.trapsExplicit_envOf_semantic hL hf hJ htr) m
    exact h.2 c hm' (L.hooks M) L.Img (L.A f).base ra s ⟨hME.abi, hME.stack, hME.gfree, hME.hF,
      L.calleeOk_semantic hL hκ ih hf hME,
      fun _ => L.calleeTryOk_semantic hL hκ ih hf hME,
      fun ht => L.tlsOk_hooks (hL.baseTls f hf (hasTls_of_vcode_semantic hc ht) L.F (κ M f)), hME.body⟩

theorem backend_correct_program_budget_semantic (L : LinkSys) (hL : L.OkSemanticNI)
    {κ : Nat → Clif.Function → Nat} (hκ : L.Budget κ) {f : Clif.Function}
    (hf : f ∈ L.P.funcs) (M : Nat) {ra : BitVec 64} {s w₀ : Arm.ArmState} {args : List Clif.Val}
    {cs : Clif.State}
    (hent : AbiEntry (L.A f).fb (L.A f).base ra s) (hres : StackAvail (κ M f) (L.A f).af s)
    (hF : L.F = frameWG (κ M f) (RAFrame.compute (L.A f).vcp (L.A f).rf).intBase
      (RAFrame.compute (L.A f).vcp (L.A f).rf).size (L.A f).af L.Img s)
    (hgfree : ∀ a, L.Img a → ¬ StackBelow (frameDrop (L.A f).af + κ M f) (spv s) a)
    (himg : ∀ a, L.Img a → s.mem a = L.imgMem a)
    (hbe : BodyEntry (L.A f).af s w₀) (hargs : ArgsIn f.sig args s) (hcs : ClifEntry f args cs)
    (hsav : StackArgsAvoid L.Img f.sig args s)
    (hrel : Rel.holds ⟨L.F, L.syms, (L.A f).af.slotBase,
      (RAFrame.compute (L.A f).vcp (L.A f).rf).intBase⟩ f cs.frame.slots cs.mem w₀)
    (hpl : L.NeedSlots → L.PlaceAt cs.mem (spv w₀))
    (htr : TrapsExplicit (Clif.linkEnvN L.P L.base M) L.P.bare cs) :
    ArmRefines (L.A f).fb (L.A f).base ra (L.mach M f) s (Clif.runLoop L.base L.P (M + 1) cs) := by
  haveI := L.crunOk_std_semantic hL
  rw [← L.mach_std]
  have hIf : Clif.LInv (L.P.only f) cs := runInv_entry (by simp [Clif.Program.only]) hcs
  refine backend_correct_program_core_semantic L.std (hL.withCrun _) hκ hf M hent hres hF hgfree himg hbe
    hargs hcs hsav hrel hpl htr fun ho => ?_
  exact Clif.runLoop_linkN (base := L.base) (syms := L.syms) M hL.names hf hL.free
    (hL.indScope f hf) (E := L.std.envR M f)
    rfl rfl (fun _ hn => L.std.envR_of (.inl hn))
    (L.std.envR_link hL.names) (M + 1) cs (Nat.le_refl _) (runInv_entry hf hcs) hIf
    (fun _ => hrel.1.symbols)
    (by rcases ho with ⟨_, _, ho⟩ | ⟨_, ho⟩ <;> rw [ho] <;> exact fun _ h => nomatch h)
    (by rcases ho with ⟨_, _, ho⟩ | ⟨_, ho⟩ <;> rw [ho] <;> exact fun h => nomatch h)

theorem backend_correct_program_peak_semantic (L : LinkSys) (hL : L.OkSemanticNI)
    {κ : Nat → Clif.Function → Nat} (hκ : L.Budget κ) {f : Clif.Function}
    (hf : f ∈ L.P.funcs) (F d : Nat) {ra : BitVec 64} {s w₀ : Arm.ArmState}
    {args : List Clif.Val} {cs : Clif.State}
    (hent : AbiEntry (L.A f).fb (L.A f).base ra s) (hres : StackAvail (κ d f) (L.A f).af s)
    (hF : L.F = frameWG (κ d f) (RAFrame.compute (L.A f).vcp (L.A f).rf).intBase
      (RAFrame.compute (L.A f).vcp (L.A f).rf).size (L.A f).af L.Img s)
    (hgfree : ∀ a, L.Img a → ¬ StackBelow (frameDrop (L.A f).af + κ d f) (spv s) a)
    (himg : ∀ a, L.Img a → s.mem a = L.imgMem a)
    (hbe : BodyEntry (L.A f).af s w₀) (hargs : ArgsIn f.sig args s) (hcs : ClifEntry f args cs)
    (hsav : StackArgsAvoid L.Img f.sig args s)
    (hrel : Rel.holds ⟨L.F, L.syms, (L.A f).af.slotBase,
      (RAFrame.compute (L.A f).vcp (L.A f).rf).intBase⟩ f cs.frame.slots cs.mem w₀)
    (hpl : L.NeedSlots → L.PlaceAt cs.mem (spv w₀))
    (hd : Clif.DepthLe L.base L.P d cs)
    (htr : TrapsExplicit (Clif.linkEnvD L.P L.base F d) L.P.bare cs) :
    ArmRefines (L.A f).fb (L.A f).base ra (L.mach d f) s (Clif.runLoop L.base L.P (F + 1) cs) := by
  haveI := L.crunOk_peak_semantic hL F
  rw [← L.mach_peak F]
  have hIf : Clif.LInv (L.P.only f) cs := runInv_entry (by simp [Clif.Program.only]) hcs
  refine backend_correct_program_core_semantic (L.peak F) (hL.withCrun _) hκ hf d hent hres hF hgfree himg
    hbe hargs hcs hsav hrel hpl htr fun ho => ?_
  exact Clif.runLoop_linkD (base := L.base) (syms := L.syms) F d hL.names hf hL.free
    (hL.indScope f hf) (E := (L.peak F).envR d f)
    rfl rfl (fun _ hn => (L.peak F).envR_of (.inl hn))
    ((L.peak F).envR_link hL.names) (F + 1) cs (Nat.le_refl _) hd (runInv_entry hf hcs) hIf
    (fun _ => hrel.1.symbols)
    (by rcases ho with ⟨_, _, ho⟩ | ⟨_, ho⟩ <;> rw [ho] <;> exact fun _ h => nomatch h)
    (by rcases ho with ⟨_, _, ho⟩ | ⟨_, ho⟩ <;> rw [ho] <;> exact fun h => nomatch h)

theorem backend_correct_program_semantic (L : LinkSys) (hL : L.OkSemanticNI) {f : Clif.Function}
    (hf : f ∈ L.P.funcs) (M : Nat) {ra : BitVec 64} {s w₀ : Arm.ArmState} {args : List Clif.Val}
    {cs : Clif.State}
    (hent : AbiEntry (L.A f).fb (L.A f).base ra s) (hres : StackAvail (L.K M) (L.A f).af s)
    (hF : L.F = frameWG (L.K M) (RAFrame.compute (L.A f).vcp (L.A f).rf).intBase
      (RAFrame.compute (L.A f).vcp (L.A f).rf).size (L.A f).af L.Img s)
    (hgfree : ∀ a, L.Img a → ¬ StackBelow (frameDrop (L.A f).af + L.K M) (spv s) a)
    (himg : ∀ a, L.Img a → s.mem a = L.imgMem a)
    (hbe : BodyEntry (L.A f).af s w₀) (hargs : ArgsIn f.sig args s) (hcs : ClifEntry f args cs)
    (hsav : StackArgsAvoid L.Img f.sig args s)
    (hrel : Rel.holds ⟨L.F, L.syms, (L.A f).af.slotBase,
      (RAFrame.compute (L.A f).vcp (L.A f).rf).intBase⟩ f cs.frame.slots cs.mem w₀)
    (hpl : L.NeedSlots → L.PlaceAt cs.mem (spv w₀))
    (htr : TrapsExplicit (Clif.linkEnvN L.P L.base M) L.P.bare cs) :
    ArmRefines (L.A f).fb (L.A f).base ra (L.mach M f) s (Clif.runLoop L.base L.P (M + 1) cs) :=
  backend_correct_program_budget_semantic L hL (κ := fun M _ => L.K M) (L.budget_K_semantic hL) hf M hent hres hF
    hgfree himg hbe hargs hcs hsav hrel hpl htr

theorem backend_correct_program_returned_budget_semantic (L : LinkSys) (hL : L.OkSemanticNI)
    {κ : Nat → Clif.Function → Nat} (hκ : L.Budget κ) {f : Clif.Function}
    (hf : f ∈ L.P.funcs) (M : Nat) {ra : BitVec 64} {s w₀ : Arm.ArmState} {args : List Clif.Val}
    {cs : Clif.State}
    (hent : AbiEntry (L.A f).fb (L.A f).base ra s) (hres : StackAvail (κ M f) (L.A f).af s)
    (hF : L.F = frameWG (κ M f) (RAFrame.compute (L.A f).vcp (L.A f).rf).intBase
      (RAFrame.compute (L.A f).vcp (L.A f).rf).size (L.A f).af L.Img s)
    (hgfree : ∀ a, L.Img a → ¬ StackBelow (frameDrop (L.A f).af + κ M f) (spv s) a)
    (himg : ∀ a, L.Img a → s.mem a = L.imgMem a)
    (hbe : BodyEntry (L.A f).af s w₀) (hargs : ArgsIn f.sig args s) (hcs : ClifEntry f args cs)
    (hsav : StackArgsAvoid L.Img f.sig args s)
    (hrel : Rel.holds ⟨L.F, L.syms, (L.A f).af.slotBase,
      (RAFrame.compute (L.A f).vcp (L.A f).rf).intBase⟩ f cs.frame.slots cs.mem w₀)
    (hpl : L.NeedSlots → L.PlaceAt cs.mem (spv w₀))
    {vals : List Clif.Val} {cm : Clif.Mem}
    (hrun : Clif.runLoop L.base L.P (M + 1) cs = .returned vals cm) :
    ArmRefines (L.A f).fb (L.A f).base ra (L.mach M f) s (.returned vals cm) := by
  have hIf : Clif.LInv (L.P.only f) cs := runInv_entry (by simp [Clif.Program.only]) hcs
  obtain ⟨m, hm⟩ := Clif.runLoop_linkN (base := L.base) (syms := L.syms) M hL.names hf hL.free
    (hL.indScope f hf)
    (E := Clif.linkEnvN L.P L.base M) rfl rfl (fun _ _ => rfl) (fun _ _ _ => rfl)
    (M + 1) cs (Nat.le_refl _) (runInv_entry hf hcs) hIf
    (fun _ => hrel.1.symbols) (by rw [hrun]; exact fun _ h => nomatch h)
    (by rw [hrun]; exact fun h => nomatch h)
  rw [hrun] at hm
  rw [← hrun]
  exact backend_correct_program_budget_semantic L hL hκ hf M hent hres hF hgfree himg hbe hargs hcs hsav hrel hpl
    (trapsExplicit_of_returned hm)

theorem backend_correct_program_returned_semantic (L : LinkSys) (hL : L.OkSemanticNI) {f : Clif.Function}
    (hf : f ∈ L.P.funcs) (M : Nat) {ra : BitVec 64} {s w₀ : Arm.ArmState} {args : List Clif.Val}
    {cs : Clif.State}
    (hent : AbiEntry (L.A f).fb (L.A f).base ra s) (hres : StackAvail (L.K M) (L.A f).af s)
    (hF : L.F = frameWG (L.K M) (RAFrame.compute (L.A f).vcp (L.A f).rf).intBase
      (RAFrame.compute (L.A f).vcp (L.A f).rf).size (L.A f).af L.Img s)
    (hgfree : ∀ a, L.Img a → ¬ StackBelow (frameDrop (L.A f).af + L.K M) (spv s) a)
    (himg : ∀ a, L.Img a → s.mem a = L.imgMem a)
    (hbe : BodyEntry (L.A f).af s w₀) (hargs : ArgsIn f.sig args s) (hcs : ClifEntry f args cs)
    (hsav : StackArgsAvoid L.Img f.sig args s)
    (hrel : Rel.holds ⟨L.F, L.syms, (L.A f).af.slotBase,
      (RAFrame.compute (L.A f).vcp (L.A f).rf).intBase⟩ f cs.frame.slots cs.mem w₀)
    (hpl : L.NeedSlots → L.PlaceAt cs.mem (spv w₀))
    {vals : List Clif.Val} {cm : Clif.Mem}
    (hrun : Clif.runLoop L.base L.P (M + 1) cs = .returned vals cm) :
    ArmRefines (L.A f).fb (L.A f).base ra (L.mach M f) s (.returned vals cm) :=
  backend_correct_program_returned_budget_semantic L hL (κ := fun M _ => L.K M) (L.budget_K_semantic hL) hf M hent
    hres hF hgfree himg hbe hargs hcs hsav hrel hpl hrun

end E2E

namespace E2E.LinkCheck
open Backend Backend.Proof Backend.Proof.Driver
set_option autoImplicit false
set_option Elab.async false

def staticChksSemanticNI (stage : VCode → VCode) (I : LinkInput) (g : Clif.Function) (r : Except String Art) : List (String × Bool) :=
  let a := getOk r
  [("compiled: pipeline", r.toBool),
   ("compiled: lowerCheck", SemanticNI.check g a.vc),
   ("compiled: prepCheck", prepCheck (stage a.vc) a.vcp),
   ("compiled: checkAlloc", (checkAlloc a.vcp a.rf).toBool),
   ("covered", formsCoveredB ⟨a.fa.k, a.af.slotBase⟩ a.vcp),
   ("sretRets", allInsts a.vc (retsB g)),
   ("argRegs: distinct", decide (regLocs g.sig).Nodup),
   ("argRegs: argument registers", (regLocs g.sig).all (·.isArgReg)),
   ("argRegs: width ≤ 64", g.sig.params.all (fun p => decide (p.ty.width ≤ 64))),
   ("entryRegs", entryB g a.vcp),
   ("fits", decide (a.base.toNat + 4 * a.fb.words.size ≤ 2 ^ 64)),
   ("depth", decide (frameDrop a.af ≤ I.D)),
   ("free (no return_call)", linkFreeB g),
   ("subset: clif-subset-v2 E", Compile.functionE g),
   ("subset: ABI signatures", sigAbiOk g.sig && g.externs.all (fun e => sigAbiOk e.2.sig)),
   ("subset: indirect-call signatures", indSigsOk g)]

def chksSemanticNI (stage : VCode → VCode) (I : LinkInput) (P : Clif.Program)
    (T : List (Clif.Function × Art)) (g : Clif.Function) (r : Except String Art) :
    List (String × Bool) := staticChksSemanticNI stage I g r ++ linkChks I P T g r

def okRSemanticNI (stage : VCode → VCode) (I : LinkInput) (R : Res) : Bool :=
  (globalChks I (progOf R) (tabOf R)).all (·.2) &&
    R.all fun e => (chksSemanticNI stage I (progOf R) (tabOf R) e.1 e.2).all (·.2)

theorem okRSemanticNI_global (stage : VCode → VCode) {I : LinkInput} {R : Res} (h : okRSemanticNI stage I R = true) :
    ∀ c ∈ globalChks I (progOf R) (tabOf R), c.2 = true := by
  simp only [okRSemanticNI, chksSemanticNI, Bool.and_eq_true, List.all_eq_true] at h
  exact h.1

theorem okRSemanticNI_names (stage : VCode → VCode) {I : LinkInput} {R : Res} (h : okRSemanticNI stage I R = true) :
    ((progOf R).funcs.map (·.name)).Nodup := by
  have := okRSemanticNI_global stage h _ (by simp [globalChks]; exact Or.inl rfl)
  simpa using this

/-- The image check is unchanged by semantic lowering validation. -/
theorem okRSemanticNI_img (stage : VCode → VCode) {I : LinkInput} {R : Res}
    (checked : okRSemanticNI stage I R = true) : imgB (tabOf R) = true :=
  okRSemanticNI_global stage checked ("imgCode: the image reads back",imgB (tabOf R))
    (by simp [globalChks])

end E2E.LinkCheck

/-! Pipeline provenance for transactional production attempts. Every successful
artifact retains the original preparation, allocation, emission and layout facts;
the existing source/SSA checks supply source correctness for either attempt. -/
set_option autoImplicit false

namespace E2E.LinkCheck
open Backend Backend.Proof Backend.Proof.Driver

structure SemanticPreparedFacts (stage : VCode → VCode) (I : LinkInput) (R : Res) (g : Clif.Function) (a : Art) : Prop where
  pipe : prepare (stage a.vc) = .ok a.vcp ∧ lowerRFunc a.vcp a.rf = .ok a.af ∧
    emitFunc a.k a.af = .ok a.fa ∧ a.fa.layout = .ok a.fb ∧
    a.base = BitVec.ofNat 64 (I.baseOf g.name)
  lowerOk : SemanticNI.check g a.vc = true
  prepOk : prepCheck (stage a.vc) a.vcp = true
  check : checkAlloc a.vcp a.rf = .ok ()
  covered : FormsCovered ⟨a.fa.k, a.af.slotBase⟩
    a.vcp
  rets : allInsts a.vc (retsB g) = true
  outFits : ∀ e ∈ g.externs, ((progOf R).func? e.2.name).isSome = true →
    outFitsB e.2.sig (RAFrame.compute a.vcp a.rf).intBase = true
  nodup : (regLocs g.sig).Nodup
  argReg : ∀ r ∈ regLocs g.sig, r.isArgReg = true
  width : ∀ p ∈ g.sig.params, p.ty.width ≤ 64
  callee : calleeB (progOf R) (fun n => I.syms.lookup n) g = true → (g.slots = [] →
    (RAFrame.compute a.vcp a.rf).size =
      a.af.frameSize) ∧ slotFitsB g a = true
  sites : allInsts a.vcp (siteB (siteOk (progOf R) g
    (indToB (fun n => I.syms.lookup n) g) a.vcp)) = true
  declSig : ∀ e ∈ g.externs.map (·.2), ∀ h, (progOf R).func? e.name = some h → e.sig = h.sig
  entry : entryB g a.vcp = true
  fits : a.base.toNat + 4 * a.fb.words.size ≤ 2 ^ 64
  ra : raCallB (tabOf R) g a = true
  depth : frameDrop a.af ≤ I.D
  free : Clif.LinkFree g
  subsetE : Compile.functionE g = true
  abi : sigAbiOk g.sig = true ∧ ∀ e ∈ g.externs, sigAbiOk e.2.sig = true
  indOk : indSigsOk g = true
  ind : indB (progOf R) (fun n => I.syms.lookup n) g = true

theorem semanticPreparedFacts (stage : VCode → VCode) {I : LinkInput} {R : Res} (hR : PreparedResults stage I R) (h : okRSemanticNI stage I R = true) {g : Clif.Function}
    (hg : g ∈ (progOf R).funcs) : SemanticPreparedFacts stage I R g (artOf R g) := by
  have hn := okRSemanticNI_names stage h
  obtain ⟨e, he, rfl, hart⟩ := artOf_spec hn hg
  have hall : ∀ c ∈ chksSemanticNI stage I (progOf R) (tabOf R) e.1 e.2, c.2 = true := by
    simp only [okRSemanticNI, chksSemanticNI, Bool.and_eq_true, List.all_eq_true] at h
    exact h.2 e he
  rw [hart]
  simp only [chksSemanticNI, staticChksSemanticNI, linkChks, List.cons_append, List.nil_append, List.mem_cons,
    List.not_mem_nil, or_false, forall_eq_or_imp, forall_eq] at hall
  obtain ⟨h1, h2, h3, h4, h5, h7, h9, h10, h11, h15, h16, h18, h19, h20, h22, h23, h8,
    h12, h13, h14, h17, h24⟩ := hall
  simp only [List.all_eq_true, decide_eq_true_eq, Bool.or_eq_true, Bool.not_eq_true',
    Bool.and_eq_true, beq_iff_eq, bne_iff_ne, ne_eq] at h8 h9 h10 h11 h12 h14 h16 h18 h22
  refine ⟨hR e he _ (getOk_eq h1), h2, h3, toBool_unit h4,
    (formsCoveredB_iff _ _).1 h5, h7, fun x hx hs => ?_, h9, h10, h11, fun hc => ?_, h13,
    fun x hx h' hf => ?_, h15, h16, h17, h18, linkFreeB_sound h19, h20,
    ⟨h22.1, h22.2⟩, h23, h24⟩
  · rcases h8 x hx with h | h
    · simp [hs] at h
    · exact h
  · rcases h12 with h | ⟨h', hfit⟩
    · simp [hc] at h
    · refine ⟨fun hs => ?_, hfit⟩
      rcases h' with h | h
      · simp [hs] at h
      · exact h
  · obtain ⟨⟨fn, e'⟩, hm, rfl⟩ := List.mem_map.1 hx
    have := h14 _ hm
    simp only [hf, decide_eq_true_eq] at this
    exact this

theorem semanticPreparedIndFacts (stage : VCode → VCode) {I : LinkInput} {R : Res} (hR : PreparedResults stage I R) (h : okRSemanticNI stage I R = true) {g : Clif.Function}
    (hg : g ∈ (progOf R).funcs) (hnf : ¬ Clif.IndFree g) :
    ∀ h ∈ (progOf R).funcs, mayB (fun n => I.syms.lookup n) g h.name = true →
      ((∃ sig ∈ indSigs g, LinkSys.IndSigMatch sig h) ∨
        (DeclN g h.name ∧ ∃ sig ∈ indSigs g, LinkSys.IndTyMatch sig h)) →
      (∃ bytes, sigParamBytes h.sig = .ok bytes ∧ bytes.length ≤ 8) ∧
      ∀ sig ∈ indSigs g, LinkSys.IndTyMatch sig h → h.sig.returns.length = sig.returns.length →
        (sigRets h.sig).length = (sigRets sig).length := by
  have h := (semanticPreparedFacts stage hR h hg).ind
  simp only [indB, Bool.or_eq_true, List.all_eq_true] at h
  rcases h with h | h2
  · exact absurd (indFreeB_sound h) hnf
  intro h' hh hd hm
  have hany : indSigB g h' = true := by
    simp only [indSigB, Bool.or_eq_true, Bool.and_eq_true, List.any_eq_true, decide_eq_true_eq]
    rcases hm with ⟨sig, hs, hm⟩ | ⟨hdn, sig, hs, hm⟩
    · exact .inl ⟨sig, hs, hm⟩
    · exact .inr ⟨declB_of hdn, sig, hs, hm⟩
  have h2' := h2 h' hh
  simp only [Bool.and_eq_true] at h2'
  rw [hd, hany] at h2'
  rcases h2' with (e | e) | ⟨hb8, hr⟩
  · cases e
  · cases e
  refine ⟨?_, indRetsB_sound hr⟩
  revert hb8
  cases hb : sigParamBytes h'.sig <;> simp

theorem semanticPreparedResults_sound (stage : VCode → VCode) {I : LinkInput} {R : Res} (hstage : stage = id ∨ stage = DeadCleanup.prune) (hR : PreparedResults stage I R) (hI : okRSemanticNI stage I R = true) {B : BaseEnv}
    {F : BitVec 64 → Prop} (hB : BaseOk (ofRes I R B F)) (hF : ∀ a, (ofRes I R B F).Img a → F a) :
    (ofRes I R B F).OkSemanticNI := by
  have hn := okRSemanticNI_names stage hI
  have hgl := okRSemanticNI_global stage hI
  simp only [globalChks, List.mem_cons, List.not_mem_nil, or_false, forall_eq_or_imp,
    forall_eq] at hgl
  obtain ⟨-, himg, hstar, hinj, hsymok, haddr⟩ := hgl
  have fa := fun {g} (hg : g ∈ (progOf R).funcs) => semanticPreparedFacts stage hR hI hg
  have site : ∀ g ∈ (progOf R).funcs, ∀ info h,
      (ofRes I R B F).ProgSite g info h →
      h ∈ (progOf R).funcs ∧
        calleeB (progOf R) (fun n => I.syms.lookup n) h = true ∧
        ∃ n Lu Ld, info = ⟨.sym n, retPairs Lu, callDefs Ld⟩ ∧
        Lu.map (·.2) = regLocs h.sig ∧
        (Ld.map (·.1)).take (sigRets h.sig).length =
          (List.range (min (sigRets h.sig).length Ld.length)).map Reg.x := by
    intro g hg info h ⟨hs, n, hd, hf⟩
    have hf' : (progOf R).func? n = some h := hf
    obtain ⟨⟨e, he, hen⟩, Lu, Ld, heq, h1, h2⟩ :=
      siteOk_sound (site_sound (fa hg).sites hs) hd hf'
    obtain ⟨hh, hname⟩ := Clif.Program.func?_some hf'
    refine ⟨hh, ?_, n, Lu, Ld, heq, h1, h2⟩
    simp only [calleeB, Bool.or_eq_true, List.any_eq_true, beq_iff_eq]
    exact .inl ⟨g, hg, e, he, by rw [hen, hname]⟩
  have hcal : ∀ g ∈ (progOf R).funcs, ∀ h, (ofRes I R B F).Callee g h →
      (h.slots = [] → (RAFrame.compute (artOf R h).vcp (artOf R h).rf).size =
        (artOf R h).af.frameSize) ∧ slotFitsB h (artOf R h) = true := by
    intro g hg h hh
    have hc : calleeB (progOf R) (fun n => I.syms.lookup n) h = true ∧
        h ∈ (progOf R).funcs := by
      rcases hh with ⟨info, hs⟩ | ⟨e, he, hf⟩ | ⟨hh', hmay⟩
      · obtain ⟨hh', hc, -⟩ := site g hg info h hs
        exact ⟨hc, hh'⟩
      · obtain ⟨hh', hname⟩ := Clif.Program.func?_some (p := progOf R) hf
        refine ⟨?_, hh'⟩
        obtain ⟨⟨fn, e'⟩, hm, rfl⟩ := List.mem_map.1 he
        simp only [calleeB, Bool.or_eq_true, List.any_eq_true, beq_iff_eq]
        exact .inl ⟨g, hg, (fn, e'), hm, hname.symm⟩
      · refine ⟨?_, hh'⟩
        simp only [calleeB, Bool.or_eq_true, List.any_eq_true, beq_iff_eq, Bool.and_eq_true,
          Bool.not_eq_true']
        rcases hmay with hm | ⟨hnf, hs, -⟩
        · obtain ⟨⟨fn, e'⟩, he, hen⟩ := List.mem_map.1 hm
          exact .inl ⟨g, hg, (fn, e'), he, hen⟩
        · refine .inr ⟨?_, g, hg, indFreeB_false hnf⟩
          show (I.syms.lookup h.name).isSome = true
          cases h' : I.syms.lookup h.name
          · exact absurd h' hs
          · rfl
    exact (fa hc.2).callee hc.1
  have hpipe : ∀ g ∈ (progOf R).funcs,
      CompiledSemanticNI g (artOf R g).k (artOf R g).vc (artOf R g).vcp
        (artOf R g).rf (artOf R g).af (artOf R g).fa
        (artOf R g).fb ∧ (artOf R g).base = BitVec.ofNat 64 (I.baseOf g.name) := by
    intro g hg
    obtain ⟨hpr, ha, he, hla, hb⟩ := (fa hg).pipe
    rcases hstage with rfl | rfl
    · exact ⟨CompiledSemanticNI.of_checks (cleanup := false) (fa hg).lowerOk hpr
        (fa hg).prepOk (fa hg).check ha he hla,hb⟩
    · exact ⟨CompiledSemanticNI.of_checks (cleanup := true) (fa hg).lowerOk hpr
        (fa hg).prepOk (fa hg).check ha he hla,hb⟩
  refine
    { names := hn
      free := fun g hg => (fa hg).free
      subset := fun g hg => ⟨(fa hg).subsetE, ?_, ?_, (fa hg).abi, ?_⟩
      compiled := fun g hg => (hpipe g hg).1
      covered := fun g hg => (fa hg).covered
      outFits := fun g hg e he hs i off p hl hp => ?_
      baseNoAlloc := hB.baseNoAlloc
      argRegs := fun g hg => ⟨(fa hg).nodup, (fa hg).argReg, (fa hg).width⟩
      sretRets := fun g hg hs us hr => retsB_sound (fa hg).rets hs hr
      calleeFrame := fun g hg h hh hs => (hcal g hg h hh).1 hs
      slotFits := fun g hg h hh => slotFitsB_sound (hcal g hg h hh).2
      callRegs := fun g hg info h hs => (site g hg info h hs).2.2
      blrRegs := fun g hg info hs hreg => by
        obtain ⟨t, Lu, Ld, heq, hall⟩ := blrOk_sound (siteOk_reg (site_sound (fa hg).sites hs) hreg)
        exact ⟨t, Lu, Ld, heq, fun h hh hb hl =>
          hall h hh (indToB_of hb.1) (fun n hn => (hb.2 n (gotOf_sound hn)).symm) hl⟩
      raBlr := fun g hg info hs hreg h hh hmay pc hpc => by
        by_cases hhg : h.name = g.name
        · rw [Clif.name_inj hn hh hg hhg]
          exact raOk_self (hpipe g hg).1.layout (List.all_eq_true.1 hstar _ (tab_mem hn hg)) hpc
        · exact raCallB_sound (fa hg).ra hpc _ (tab_mem hn hh) hhg
      indScope := fun g hg hnf => ⟨hB.keepSyms ⟨g, hg, hnf⟩, ?_, hB.aliasSyms ⟨g, hg, hnf⟩⟩
      indSig := fun g hg hnf h hh hmay hm => semanticPreparedIndFacts stage hR hI hg hnf h hh (mayB_of hmay) hm
      addrSlots := fun hN ⟨g, hg, hout⟩ ⟨g', hg', hind⟩ h hh hs => ?_
      symInj := fun h hh n hn => ?_
      declSig := fun g hg e he h hf => (fa hg).declSig e he h hf
      entryRegs := fun g hg r hr => entryB_sound (fa hg).entry hr
      fits := fun g hg => (fa hg).fits
      imgAddr := fun g hg a ha => ⟨_, tab_mem hn hg, ha⟩
      imgCode := fun g hg t ht k w hw => imgCode_of himg (tab_mem hn hg) t ht k w hw
      imgF := hF
      raCall := fun g hg info h hs pc hpc => ?_
      raStar := fun h hh k hk => ?_
      depth := fun g hg => (fa hg).depth
      symOk := fun n b hn' => ?_
      baseOs := hB.baseOs
      basePc := hB.basePc
      baseExt := hB.baseExt
      baseX := hB.baseX
      baseXI := hB.baseXI
      baseTls := hB.baseTls
      baseTry := hB.baseTry
      baseNI := hB.baseNI
      baseTlsNI := hB.baseTlsNI
      baseKeepsPlace := hB.baseKeepsPlace
      baseKeepsAllocs := hB.baseKeepsAllocs }
  · intro b _ st _ fn args _ e he
    exact Clif.Program.bare_func? _ _
  · intro b _ fn args et _ e he
    exact Clif.Program.bare_func? _ _
  · intro sig hs
    have := List.all_eq_true.mp (fa hg).indOk sig hs
    simpa [Bool.and_eq_true, decide_eq_true_eq] using this
  · obtain ⟨⟨fn, e'⟩, hm, rfl⟩ := List.mem_map.1 he
    exact outFitsB_sound ((fa hg).outFits _ hm hs) hl hp
  · -- the functions of `P` have distinct addresses: their link-map addresses (`symOk`), which
    -- no other link-map entry has (`symInj`)
    intro a ha b hb x hxa hxb
    obtain ⟨g', -, rfl⟩ := List.mem_map.1 ha
    obtain ⟨h', hh', rfl⟩ := List.mem_map.1 hb
    simp only [symOkB, List.all_eq_true, beq_iff_eq] at hsymok
    have ea : I.addrOf g'.name = x := hsymok _ (lookup_pair hxa)
    have eb : I.addrOf h'.name = x := hsymok _ (lookup_pair hxb)
    simp only [symInjB, List.all_eq_true, Bool.and_eq_true, decide_eq_true_eq, bne_iff_ne,
      ne_eq, Bool.or_eq_true, beq_iff_eq] at hinj
    obtain ⟨⟨hlt, h0⟩, hall⟩ := hinj h' hh'
    rcases addrOf_cases I g'.name with hz | hm
    · exact absurd (eb.trans (ea.symm.trans hz)) h0
    · rcases hall _ hm with e | e
      · exact e
      · exact absurd (by rw [ea, ← eb, Nat.mod_eq_of_lt hlt]) e
  · simp only [addrSlotsB, Bool.or_eq_true, Bool.not_eq_true', Bool.and_eq_false_iff,
      List.any_eq_false, List.all_eq_true, Bool.not_eq_true, bne_iff_ne, ne_eq,
      Decidable.not_not, Bool.or_eq_true, Option.isNone_iff_eq_none, List.isEmpty_iff] at haddr
    rcases haddr with ((h1 | h1) | h1) | h1
    · exact absurd (h1 _ (tab_mem hn hg)) hout
    · exact absurd (indFreeB_sound (by simpa using h1 g' hg')) hind
    · exact (h1 h hh).resolve_left hs
    · obtain ⟨g0, hg0, e, he, h0, hf, hs0⟩ := declSlotsB_sound h1
      exact absurd ⟨g0, hg0, h0, .inr (.inl ⟨e, he, hf⟩), hs0⟩ hN
  · simp only [symInjB, List.all_eq_true, Bool.and_eq_true, decide_eq_true_eq, bne_iff_ne,
      ne_eq, Bool.or_eq_true, beq_iff_eq] at hinj
    obtain ⟨⟨hlt, h0⟩, hall⟩ := hinj h hh
    have hn' : I.symAddr h.name 0 = I.symAddr n 0 := hn
    rw [symAddr_zero, symAddr_zero] at hn'
    have e1 : (I.addrOf h.name) = (I.addrOf n) % 2 ^ 64 := by
      have := congrArg BitVec.toNat hn'
      simpa [Nat.mod_eq_of_lt hlt] using this
    by_cases hne : n = h.name
    · exact hne
    exfalso
    rcases addrOf_cases I n with hz | hm
    · rw [hz] at e1; exact h0 (by simpa using e1)
    · rcases hall _ hm with h' | h'
      · exact hne h'
      · exact h' e1.symm
  · obtain ⟨hh, -⟩ := site g hg info h hs
    by_cases hhg : h.name = g.name
    · rw [Clif.name_inj hn hh hg hhg]
      exact raOk_self (hpipe g hg).1.layout (List.all_eq_true.1 hstar _ (tab_mem hn hg)) hpc
    · exact raCallB_sound (fa hg).ra hpc _ (tab_mem hn hh) hhg
  · simp only [raStarB, List.all_eq_true] at hstar
    exact outside_sound (hstar _ (tab_mem hn hh)) k hk
  · simp only [symOkB, List.all_eq_true, beq_iff_eq] at hsymok
    have := hsymok _ (lookup_pair hn')
    show I.symAddr n 0 = _
    rw [symAddr_zero, this]

end E2E.LinkCheck

/-! Actual-output stack-bound adapters. Reuses the original graph,
budget algorithm, machine semantics and successful generated-proof stages. -/
set_option autoImplicit false
namespace E2E.SemanticStackBound
open Backend Backend.Proof Backend.Proof.Driver E2E.LinkCheck E2E.StackBound

abbrev CompilerInput := E2E.ProductionStackBound.CompilerInput

def okB (I : CompilerInput) : Bool := okRSemanticNI I.stage I.toLinkInput I.results

theorem stage_cases (I : CompilerInput) : I.stage = id ∨ I.stage = DeadCleanup.prune := by
  cases hc : I.cleanup with
  | false => exact .inl (by simp [ProductionStackBound.CompilerInput.stage, hc])
  | true => exact .inr (by simp [ProductionStackBound.CompilerInput.stage, hc])

def ofInput (I : CompilerInput) (B : BaseEnv) (F : BitVec 64 → Prop) : LinkSys :=
  ofRes I.toLinkInput I.results B F

theorem okB_names {I : CompilerInput} (hI : okB I = true) :
    ((progOf I.results).funcs.map (·.name)).Nodup := okRSemanticNI_names I.stage hI

theorem facts {I : CompilerInput} (hI : okB I = true) {g : Clif.Function}
    (hg : g ∈ (progOf I.results).funcs) :
    SemanticPreparedFacts I.stage I.toLinkInput I.results g (artOf I.results g) :=
  semanticPreparedFacts I.stage
    (I.toLinkInput.resultsProductionWith_prepared I.lower I.cleanup) hI hg

theorem okB_sound {I : CompilerInput} (hI : okB I = true)
    {B : BaseEnv} {F : BitVec 64 → Prop}
    (hB : BaseOk (ofInput I B F)) (hF : ∀ a, (ofInput I B F).Img a → F a) :
    (ofInput I B F).OkSemanticNI :=
  semanticPreparedResults_sound I.stage (stage_cases I)
    (I.toLinkInput.resultsProductionWith_prepared I.lower I.cleanup) hI hB hF

theorem backend_correct_program_stack (L : LinkSys) (hL : L.OkSemanticNI) {κ : Nat → Clif.Function → Nat}
    (hκ : L.Budget κ) {f : Clif.Function} (b : Nat) (hb : ∀ M, κ M f = b)
    (hf : f ∈ L.P.funcs) (M : Nat) {ra : BitVec 64} {s w₀ : Arm.ArmState} {args : List Clif.Val}
    {cs : Clif.State}
    (hent : AbiEntry (L.A f).fb (L.A f).base ra s)
    (hroom : frameDrop (L.A f).af + b ≤ (spv s).toNat)
    (hgfree : ∀ a, L.Img a → ¬ StackBelow (frameDrop (L.A f).af + b) (spv s) a)
    (hF : L.F = frameWG b (RAFrame.compute (L.A f).vcp (L.A f).rf).intBase
      (RAFrame.compute (L.A f).vcp (L.A f).rf).size (L.A f).af L.Img s)
    (himg : ∀ a, L.Img a → s.mem a = L.imgMem a)
    (hbe : BodyEntry (L.A f).af s w₀) (hargs : ArgsIn f.sig args s) (hcs : ClifEntry f args cs)
    (hsav : StackArgsAvoid L.Img f.sig args s)
    (hrel : Rel.holds ⟨L.F, L.syms, (L.A f).af.slotBase,
      (RAFrame.compute (L.A f).vcp (L.A f).rf).intBase⟩ f cs.frame.slots cs.mem w₀)
    (hpl : L.NeedSlots → L.PlaceAt cs.mem (spv w₀))
    (htr : TrapsExplicit (Clif.linkEnvN L.P L.base M) L.P.bare cs) :
    ArmRefines (L.A f).fb (L.A f).base ra (L.mach M f) s (Clif.runLoop L.base L.P (M + 1) cs) := by
  have hd := L.frameDrop_eq_semantic hL hf
  have hres : StackAvail b (L.A f).af s := by
    unfold StackAvail
    rw [show (L.A f).af.frameSize + 16 + b = frameDrop (L.A f).af + b by omega]
    refine stackRoom_of hroom fun a ha => hgfree a (hL.imgAddr f hf a ?_)
    simpa [CodeAddr, hent.program] using ha
  rw [← hb M] at hres hF hgfree
  exact backend_correct_program_budget_semantic L hL hκ hf M hent hres hF hgfree himg hbe hargs hcs hsav hrel
    hpl htr

abbrev Calls := E2E.StackBound.Calls
abbrev CycleFrom := @E2E.StackBound.CycleFrom

def budO (I : CompilerInput) (g : Clif.Function) : Option Nat := E2E.StackBound.budC I I.results g

/-- The callees' stack budget of `g` (depth-independent; `0` without one). -/
def bud (I : CompilerInput) (g : Clif.Function) : Nat := (budO I g).getD 0

/-- **The stack bound of `f`**: its frame plus its callees' budget. -/
def stackFn (I : CompilerInput) (f : Clif.Function) : Nat := frameDrop (artOf I.results f).af + bud I f

/-- **The stack bound of the program**: the largest `stackFn`, when no call reaches a call cycle
(`none`: the program is recursive; `stackB_isSome_iff`). -/
def stackB (I : CompilerInput) : Option Nat :=
  let R := I.results
  let m := budMap I R
  if (progOf R).funcs.all (fun g => (m.get? g.name).isSome) then
    some ((progOf R).funcs.foldl (fun x g => max x (frameDrop (artOf R g).af + (m.get? g.name).getD 0)) 0)
  else none

/-- The function named `n` has a budget: its calls never reach a call cycle (`goodN_iff`). -/
def goodN (I : CompilerInput) (n : String) : Bool :=
  match (progOf I.results).func? n with
  | some f => (budO I f).isSome
  | none => false

/-- `goodN` of every name of `ns` (`budMap` evaluated once). -/
def goodAll (I : CompilerInput) (ns : List String) : Bool :=
  let R := I.results
  let m := budMap I R
  ns.all fun n => match (progOf R).func? n with
    | some f => (m.get? f.name).isSome
    | none => false

/-! ## Soundness -/

theorem goodN_of_all {I : CompilerInput} {ns : List String} (h : goodAll I ns = true) {n : String}
    (hn : n ∈ ns) : goodN I n = true :=
  List.all_eq_true.1 h n hn

/-- `goodN` of the `k`-th name of `ns` (the generated crate proofs). -/
theorem goodN_of_idx {I : CompilerInput} {ns : List String} (h : goodAll I ns = true) (k : Nat)
    (hk : k < ns.length) : goodN I ns[k] = true :=
  goodN_of_all h (List.getElem_mem hk)

/-- With the stack bound of the program, every function has a budget. -/
theorem stackB_some {I : CompilerInput} {S : Nat} (hS : stackB I = some S) :
    (∀ g ∈ (progOf I.results).funcs, (budO I g).isSome = true) ∧
      S = (progOf I.results).funcs.foldl (fun x g => max x (stackFn I g)) 0 := by
  unfold stackB at hS
  dsimp only at hS
  split at hS
  · rename_i hall
    cases hS
    rw [List.all_eq_true] at hall
    exact ⟨fun g hg => hall g hg, rfl⟩
  · cases hS

/-- Every function's bound is at most the program's. -/
theorem stackFn_le {I : CompilerInput} {S : Nat} (hS : stackB I = some S) {f : Clif.Function}
    (hf : f ∈ (progOf I.results).funcs) : stackFn I f ≤ S := by
  rw [(stackB_some hS).2]
  exact le_foldl_max _ _ _ hf

/-- Under `okB`, a callee of the linked system is an edge of the call graph. -/
theorem edgeB_of_callee {I : CompilerInput} (hI : okB I = true) {B : BaseEnv}
    {F : BitVec 64 → Prop} {g h : Clif.Function} (hg : g ∈ (progOf I.results).funcs)
    (hc : (ofInput I B F).Callee g h) : edgeB (fun n => I.syms.lookup n) g h = true := by
  have hdecl : ∀ e ∈ g.externs, e.2.name = h.name → edgeB (fun n => I.syms.lookup n) g h = true :=
    fun e he hn => by
      simp only [edgeB, edgeW, Bool.or_eq_true, List.any_eq_true, beq_iff_eq]
      exact .inl ⟨e, he, hn⟩
  rcases hc with ⟨info, hs, n, hd, hpf⟩ | ⟨e, he, hpf⟩ | hc
  · have hpf' : (progOf I.results).func? n = some h := hpf
    obtain ⟨⟨e, he, hen⟩, -⟩ := siteOk_sound (site_sound (facts hI hg).sites hs) hd hpf'
    exact hdecl e he (by rw [hen, (Clif.Program.func?_some hpf').2])
  · obtain ⟨e', he', rfl⟩ := List.mem_map.1 he
    exact hdecl e' he' (Clif.Program.func?_some (p := progOf I.results) hpf).2.symm
  · obtain ⟨hh, hmay⟩ := hc
    rcases hmay with hm | ⟨hnf, hsy, hsig⟩
    · obtain ⟨e, he, hen⟩ := List.mem_map.1 hm
      exact hdecl e he hen
    · obtain ⟨sig, hsm, hm⟩ := hsig h (func?_of_mem (okB_names hI) hh)
      have hsy' : (I.syms.lookup h.name).isSome = true := by
        revert hsy; show I.syms.lookup h.name ≠ none → _
        cases I.syms.lookup h.name <;> simp
      simp only [edgeB, edgeW, indFreeB_false hnf, hsy', Bool.not_false, Bool.true_and,
        Bool.or_eq_true, List.any_eq_true, decide_eq_true_eq]
      exact .inr ⟨sig, hsm, hm⟩


theorem goodN_iff {I : CompilerInput} (hI : okB I = true) {n : String} :
    goodN I n = true ↔
      ∃ f, (progOf I.results).func? n = some f ∧ ¬ CycleFrom (Calls I I.results) f := by
  unfold goodN
  cases hf : (progOf I.results).func? n with
  | none => simp
  | some f =>
    simp only [Option.some.injEq, exists_eq_left']
    exact budC_isSome_iff (okB_names hI) (Clif.Program.func?_some hf).1

/-- **The program has a stack bound iff it is not recursive**: under `okB`, `stackB I` is
`some` iff no call cycle is reachable from any function. -/
theorem stackB_isSome_iff {I : CompilerInput} (hI : okB I = true) :
    (stackB I).isSome = true ↔
      ∀ f ∈ (progOf I.results).funcs, ¬ CycleFrom (Calls I I.results) f := by
  have key : (∀ f ∈ (progOf I.results).funcs, ¬ CycleFrom (Calls I I.results) f) ↔
      (progOf I.results).funcs.all (fun g => (E2E.StackBound.budC I I.results g).isSome) = true := by
    rw [List.all_eq_true]
    exact forall₂_congr fun f hf => (budC_isSome_iff (okB_names hI) hf).symm
  rw [key]
  unfold stackB E2E.StackBound.budC
  dsimp only
  split <;> simp_all

/-- The largest frame plus budget of the functions with a budget. -/
def budMax (I : CompilerInput) : Nat := (progOf I.results).funcs.foldl (fun x g => max x (stackFn I g)) 0

/-- **Soundness of the budgets**: under `okB`, `budMap`'s budgets (which meet `budOkW`,
`budOkW_budMap`), completed by the depth budget for the functions without one
(`LinkSys.hybrid`), are a budget of the linked system of the input (whatever the base
environment). -/
theorem budget_of {I : CompilerInput} (hI : okB I = true) (B : BaseEnv) (F : BitVec 64 → Prop) :
    (ofInput I B F).Budget ((ofInput I B F).hybrid (budO I) (budMax I)) := by
  refine LinkSys.budget_hybrid _ _ _ (fun h hh => (facts hI hh).depth) ?_ ?_
  · intro g hg bg hbg h hcl
    have hok := budOkW_budMap (I := I) (R := I.results) (okB_names hI)
    have he := edgeB_of_callee hI hg hcl
    have hh : h ∈ (progOf I.results).funcs := (ofInput I B F).callee_mem hcl
    simp only [E2E.StackBound.budOkW, List.all_eq_true] at hok
    have h1 := hok g hg
    change E2E.StackBound.budC I I.results g = some bg at hbg
    rw [hbg] at h1
    simp only [List.all_eq_true] at h1
    have h2 := h1 h hh
    simp only [edgeB] at he
    rw [he] at h2
    show ∃ bh, E2E.StackBound.budC I I.results h = some bh ∧ _
    cases hch : E2E.StackBound.budC I I.results h with
    | none => rw [hch] at h2; simp at h2
    | some bh =>
      rw [hch] at h2
      simp only [Bool.not_true, Bool.false_or, decide_eq_true_eq] at h2
      exact ⟨bh, rfl, h2⟩
  · intro h hh bh hbh
    have := le_foldl_max (stackFn I) _ 0 hh
    simp only [stackFn, bud, hbh, Option.getD_some] at this
    exact this

/-! ## The crate's theorem with the stack bound -/

/-- **`backend_correct_program_stack` for the function named `n`** of the linked system `L` of
the input `I`, every premise but `L.Ok`: for every fuel `M`, from an entry whose `sp` has
`stackFn I f` bytes below it (without wrapping) holding no code of the program, with the
addresses outside the world that stack and the code. -/
def ProgStmtS (L : LinkSys) (I : CompilerInput) (n : String) : Prop :=
  ∀ (f : Clif.Function), L.P.func? n = some f →
  ∀ (M : Nat) (ra : BitVec 64) (s w₀ : Arm.ArmState) (args : List Clif.Val) (cs : Clif.State),
    AbiEntry (L.A f).fb (L.A f).base ra s →
    stackFn I f ≤ (spv s).toNat → (∀ a, L.Img a → ¬ StackBelow (stackFn I f) (spv s) a) →
    L.F = frameWG (bud I f) (RAFrame.compute (L.A f).vcp (L.A f).rf).intBase
      (RAFrame.compute (L.A f).vcp (L.A f).rf).size (L.A f).af L.Img s →
    (∀ a, L.Img a → s.mem a = L.imgMem a) →
    BodyEntry (L.A f).af s w₀ → ArgsIn f.sig args s → ClifEntry f args cs →
    StackArgsAvoid L.Img f.sig args s →
    Rel.holds ⟨L.F, L.syms, (L.A f).af.slotBase,
      (RAFrame.compute (L.A f).vcp (L.A f).rf).intBase⟩ f cs.frame.slots cs.mem w₀ →
    (L.NeedSlots → L.PlaceAt cs.mem (spv w₀)) →
    TrapsExplicit (Clif.linkEnvN L.P L.base M) L.P.bare cs →
    ArmRefines (L.A f).fb (L.A f).base ra (L.mach M f) s (Clif.runLoop L.base L.P (M + 1) cs)

/-- **The crate's theorem with the stack bound** for its function named `n` (`CrateStmt` with
`ProgStmtS`). -/
def StackStmt (I : CompilerInput) (n : String) : Prop :=
  ∀ (B : BaseEnv) (F : BitVec 64 → Prop), BaseOk (ofInput I B F) →
    (∀ a, (ofInput I B F).Img a → F a) → ProgStmtS (ofInput I B F) I n

/-- **A function whose calls never reach a call cycle** (`goodN`) of an input that passes the
checker refines at every fuel with its stack bound `stackFn I f`. -/
theorem crate_correct_stackN {I : CompilerInput} (hI : okB I = true) {n : String}
    (hn : goodN I n = true) : StackStmt I n := by
  intro B F hB hFI f hf M _ _ _ _ _ hent hroom hgfree hFeq himg hbe hargs hcs hsav hrel hpl htr
  have hf' : (progOf I.results).func? n = some f := hf
  unfold goodN at hn
  rw [hf'] at hn
  obtain ⟨b, hb⟩ := Option.isSome_iff_exists.1 hn
  have hbud : bud I f = b := by simp [bud, hb]
  refine backend_correct_program_stack _ (okB_sound hI hB hFI) (budget_of hI B F) (bud I f)
    (fun M => by simp [LinkSys.hybrid, hb, hbud]) (Clif.Program.func?_some hf).1 M hent hroom
    hgfree hFeq himg hbe hargs hcs hsav hrel hpl htr

/-- **Every function of an input that passes the checker and the stack check** refines at every
fuel with the stack bound `stackFn I f ≤ S` (`stackFn_le`). -/
theorem crate_correct_stack {I : CompilerInput} (hI : okB I = true) {S : Nat}
    (hS : stackB I = some S) (n : String) : StackStmt I n := by
  intro B F hB hFI f hf
  have hf' : (progOf I.results).func? n = some f := hf
  have hn : goodN I n = true := by
    unfold goodN; rw [hf']
    exact (stackB_some hS).1 f (Clif.Program.func?_some hf').1
  exact crate_correct_stackN hI hn B F hB hFI f hf

/-- **`crate_correct_stackN` from the input condition**: a function of an input that passes the
checker from which no call cycle is reachable (`goodN_iff`) refines at every fuel with its stack
bound `stackFn I f`. -/
theorem crate_correct_stack_acyclic {I : CompilerInput} (hI : okB I = true) {n : String}
    {f : Clif.Function} (hf : (progOf I.results).func? n = some f)
    (hc : ¬ CycleFrom (Calls I I.results) f) : StackStmt I n :=
  crate_correct_stackN hI ((goodN_iff hI).2 ⟨f, hf, hc⟩)

/-- **`crate_correct_stack` from the input condition**: when no call cycle is reachable from any
function of an input that passes the checker, the program has a stack bound `S`
(`stackB_isSome_iff`, every function's bound at most `S`, `stackFn_le`) and every function refines
at every fuel with its bound. -/
theorem crate_correct_stack_all {I : CompilerInput} (hI : okB I = true)
    (hc : ∀ f ∈ (progOf I.results).funcs, ¬ CycleFrom (Calls I I.results) f) :
    ∃ S, stackB I = some S ∧ ∀ n, StackStmt I n := by
  obtain ⟨S, hS⟩ := Option.isSome_iff_exists.1 ((stackB_isSome_iff hI).2 hc)
  exact ⟨S, hS, crate_correct_stack hI hS⟩



end E2E.SemanticStackBound

/-! Transactional executable compilation. The legacy layout and compiler are
retained for a failed complete Stock attempt. Output records routing data only. -/
set_option autoImplicit false
namespace Link.SemanticCompilerWith
open Backend E2E E2E.LinkCheck
variable {lower : ProductionLowering}

def attempt (lower : ProductionLowering) (S : LinkSpec) (file0 : ByteArray) (cleanup : Bool) : Except String ByteArray :=
  let scope := if cleanup then inScopePar S.input0 else inScopeInPar S.input0
  if !scope then .error (if cleanup then outOfScopeMsg else outOfScopeInMsg)
  else
    let I := S.inputProductionWith lower cleanup
    if okRSemanticNI (productionStage cleanup) I (I.resultsProductionWith lower cleanup) then
      leanLinkProductionWith lower S file0 cleanup
    else .error "the actual production pipeline checks failed"

structure Output where
  file : ByteArray
  stock : Bool

def legacySpec (S : LinkSpec) (cleanup : Bool) : LinkSpec :=
  if cleanup then DeadCleanup.placedPar S else S.placedPar

def legacyCompile (S : LinkSpec) (file0 : ByteArray) (cleanup : Bool) : Except String ByteArray :=
  if cleanup then DeadCleanup.compileExe S file0 else compileExe S file0

def compile (lower : ProductionLowering) (S : LinkSpec) (file0 : ByteArray) (cleanup : Bool) : Except String Output :=
  match attempt lower (S.placedProductionWith lower cleanup) file0 cleanup with
  | .ok file => .ok ⟨file,true⟩
  | .error _ => (legacyCompile (legacySpec S cleanup) file0 cleanup).map fun file => ⟨file,false⟩

theorem accepts_legacy {S : LinkSpec} {file0 file : ByteArray} {cleanup : Bool}
    (h : legacyCompile (legacySpec S cleanup) file0 cleanup = .ok file) :
    ∃ out, compile lower S file0 cleanup = .ok out := by
  unfold compile
  split
  · exact ⟨_,rfl⟩
  · exact ⟨⟨file,false⟩,by rw [h]; rfl⟩

theorem compile_spec {S : LinkSpec} {file0 : ByteArray} {cleanup : Bool} {out : Output}
    (h : compile lower S file0 cleanup = .ok out) :
    (out.stock = true ∧ attempt lower (S.placedProductionWith lower cleanup) file0 cleanup = .ok out.file) ∨
    (out.stock = false ∧ legacyCompile (legacySpec S cleanup) file0 cleanup = .ok out.file) := by
  unfold compile at h
  split at h
  · rename_i file hp
    cases h
    exact .inl ⟨rfl,hp⟩
  · rename_i e hp
    cases hl : legacyCompile (legacySpec S cleanup) file0 cleanup <;> simp only [hl,Except.map] at h
    · cases h
    · cases h
      exact .inr ⟨rfl,rfl⟩

inductive CompileChoice where
  | current | previous | legacy
  deriving DecidableEq, Repr

structure FallbackOutput where
  file : ByteArray
  choice : CompileChoice

/-- Retry the previously shipped semantic compiler before the legacy compiler.
Every attempt receives the original specification, image and cleanup setting. -/
def compileWithFallback (current previous : ProductionLowering) (S : LinkSpec)
    (file0 : ByteArray) (cleanup : Bool) : Except String FallbackOutput :=
  match attempt current (S.placedProductionWith current cleanup) file0 cleanup with
  | .ok file => .ok ⟨file,.current⟩
  | .error _ => (compile previous S file0 cleanup).map fun out =>
      ⟨out.file,if out.stock then .previous else .legacy⟩

theorem accepts_previous {current previous : ProductionLowering} {S : LinkSpec}
    {file0 : ByteArray} {cleanup : Bool} {out : Output}
    (h : compile previous S file0 cleanup = .ok out) :
    ∃ result, compileWithFallback current previous S file0 cleanup = .ok result := by
  unfold compileWithFallback
  split
  · exact ⟨_,rfl⟩
  · exact ⟨_,by rw [h]; rfl⟩

/-- Each selected result is an existing proved executable attempt or the
retained legacy compiler. Routing data introduces no new source premise. -/
theorem compileWithFallback_spec {current previous : ProductionLowering} {S : LinkSpec}
    {file0 : ByteArray} {cleanup : Bool} {out : FallbackOutput}
    (h : compileWithFallback current previous S file0 cleanup = .ok out) :
    (out.choice = .current ∧
      attempt current (S.placedProductionWith current cleanup) file0 cleanup = .ok out.file) ∨
    (out.choice = .previous ∧
      attempt previous (S.placedProductionWith previous cleanup) file0 cleanup = .ok out.file) ∨
    (out.choice = .legacy ∧ legacyCompile (legacySpec S cleanup) file0 cleanup = .ok out.file) := by
  unfold compileWithFallback at h
  split at h
  · rename_i file succeeded
    cases h
    exact .inl ⟨rfl,succeeded⟩
  · cases older : compile previous S file0 cleanup with
    | error message => simp only [older,Except.map] at h; cases h
    | ok result =>
      simp only [older,Except.map] at h
      cases h
      rcases compile_spec older with ⟨stock,run⟩ | ⟨legacy,run⟩
      · exact .inr (.inl ⟨by simp [stock],run⟩)
      · exact .inr (.inr ⟨by simp [legacy],run⟩)
end Link.SemanticCompilerWith

/-! Per-state linked execution facts for the actual production artifact contract.
Original facts and variants remain available. -/
set_option autoImplicit false
namespace E2E
open Backend Backend.Proof Backend.Proof.Driver
namespace LinkSys
variable (L : LinkSys)
variable {κ : Nat → Clif.Function → Nat}

theorem insnAt_ofLine_semantic {fa : FnAsm} {fb : FnBin} {lm : Std.HashMap Lbl Nat} {base : BitVec 64}
    (hl : fa.layout = .ok fb) (hm : labelOffsets fa.lines = .ok lm)
    (hfit : 4 * fb.words.size ≤ 2 ^ 64) {u : Arm.ArmState} (hprog : u.program = fb.program base)
    {j : Nat} {x : Insn} {t : Option Clif.TrapCode} (hj : fa.lines.toList[j]? = some (.ins x t)) :
    insnAt fa (progBase u) (base + BitVec.ofNat 64 (lineOffset fa.lines.toList j)) = some x := by
  obtain ⟨_, w, hw, hk⟩ := FnAsm.layout_word hl hm hj rfl
  have hne : fb.words.toList ≠ [] := by
    intro h
    have : fb.words.size = 0 := by simpa using congrArg List.length h
    simp [this] at hk
  have hb : progBase u = base := progBase_eq (by rw [hprog]; rfl) hne
  have hsum := layout_sum hl
  rw [hb]
  exact insnAt_line (by omega) hj

theorem progCallG_semantic (hL : L.OkSemanticNI) [hR : L.CrunOk] {M : Nat} (hM : 0 < M) (ihG : L.ThmG κ (M - 1)) {n : String}
    {h : Clif.Function} (hpf : L.P.func? n = some h) (hcal : ∃ g ∈ L.P.funcs, L.Callee g h)
    (hib : ((RAFrame.compute (L.A h).vcp (L.A h).rf).intBase = 0 ∧
      (RAFrame.compute (L.A h).vcp (L.A h).rf).size = (L.A h).af.frameSize) ∨ L.NeedNI)
    {F : BitVec 64 → Prop} (himgF : ∀ a, L.Img a → F a)
    {uses : List CV} {w : Arm.ArmState} (herr : Arm.r .ERR w = .None)
    (hal : (spv w).toNat % 16 = 0)
    (hroom : frameDrop (L.A h).af + κ (M - 1) h ≤ (spv w).toNat)
    (hdead : ∀ a, StackBelow (frameDrop (L.A h).af + κ (M - 1) h) (spv w) a → F a ∧ ¬ L.Img a)
    {vals : List Clif.Val} {cm : Clif.Mem} {cs : Clif.State} {rvals : List Clif.Val}
    {cm' : Clif.Mem} (hmr : MemRel F L.syms cm w) (hargs : ArgsAt h.sig vals uses w)
    (hsav : StackArgsAvoid F h.sig vals w) (hpl : L.NeedSlots → L.PlaceAt cm (spv w))
    (hinit : Clif.initState L.P n vals cm = .ok cs)
    (hrun : L.crun M cs = .returned rvals cm') :
    ∀ t, L.CallerOk F h uses w t → L.RunGoodL (M - 1) h (enterAt (L.A h) t) := by
  obtain ⟨hh, hname⟩ := Clif.Program.func?_some hpf
  subst hname
  have hc := hL.compiled h hh
  have hfr := lowerRFunc_frame hc.alloc
  have hdrop := L.frameDrop_eq_semantic hL hh
  have hfs := L.frameSize_mod_semantic hL hh
  obtain ⟨hnd, harg, hwid⟩ := hL.argRegs h hh
  have hsl0 : ¬ L.NeedSlots → h.slots = [] := fun hn => Classical.byContradiction fun hne => by
    obtain ⟨g, hg, hcg⟩ := hcal
    exact hn ⟨g, hg, h, hcg, hne⟩
  have hcase : h.slots = [] ∨ L.PlaceAt cm (spv w) := by
    by_cases hN : L.NeedSlots
    · exact .inr (hpl hN)
    · exact .inl (hsl0 hN)
  obtain ⟨hsl', hsym', hal', hby', hpl'⟩ := L.initState_mem hpf hinit hcase
  have hslotB : (L.A h).af.slotBase = (RAFrame.compute (L.A h).vcp (L.A h).rf).size :=
    (lowerRFunc_ok hc.alloc).1.2.1
  have hsz_le := size_le_frameSize hc.alloc
  have hfits : ∀ p ∈ h.slots, ∃ off, (slotLayout h.slots).1.lookup p.1 = some off ∧
      (L.A h).af.slotBase + off + p.2.size ≤ (L.A h).af.frameSize := by
    obtain ⟨g, hg, hcg⟩ := hcal
    exact hL.slotFits g hg h hcg
  have hce : ClifEntry h vals cs := clifEntry_initState hpf hinit
  -- the run of the program without functions (program callees: the callee runs one level down)
  obtain ⟨m, hm⟩ := hR.link M hM h hh cs (runInv_entry hh hce)
    (runInv_entry (by simp [Clif.Program.only]) hce) (fun _ => hsym'.trans hmr.symbols)
    (L.envR (M - 1) h) rfl rfl (fun _ hn => L.envR_of (.inl hn)) (L.envR_link hL.names)
    (by rw [hrun]; intro _ e; cases e) (by rw [hrun]; intro e; cases e)
  rw [hrun] at hm
  -- the canonical state and the shared body-entry world
  let cn := L.canon h uses w
  let w₀ := bodyOf (L.A h).af (enterAt (L.A h) cn)
  have hcOk := L.callerOk_canon_semantic hL hh himgF uses w
  have hsp0 : spv cn = spv w := hcOk.world.1 _ (by simp [Masked])
  have hspw₀ : spv w₀ = spv w - BitVec.ofNat 64 (frameDrop (L.A h).af) := by
    rw [spv_bodyOf, spv_enterAt, hsp0]
  obtain ⟨-, -, hB⟩ := off_toNat 0 (spv w) (frameDrop (L.A h).af) (by omega)
  -- the callee's outgoing area (in the caller's dead stack) is outside the callee's `F`
  let ib := (RAFrame.compute (L.A h).vcp (L.A h).rf).intBase
  let spb := spv w - BitVec.ofNat 64 (frameDrop (L.A h).af)
  let sz := (RAFrame.compute (L.A h).vcp (L.A h).rf).size
  let Fh : BitVec 64 → Prop := fun a =>
    F a ∧ ¬ OutAt ib spb a ∧ ¬ SlotAt sz (L.A h).af.frameSize spb a
  have hib_le : ib ≤ sz := intBase_le_size _ _
  have hspb : spb.toNat = (spv w).toNat - frameDrop (L.A h).af := hB
  have hlt := (spv w).isLt
  have hout_reg : ∀ a, OutAt ib spb a →
      StackBelow (frameDrop (L.A h).af + κ (M - 1) h) (spv w) a := by
    intro a ⟨h1, h2⟩
    rw [hspb] at h1 h2
    exact ⟨by omega, by omega⟩
  have hout_F : ∀ a, OutAt ib spb a → F a ∧ ¬ L.Img a := fun a ha => hdead a (hout_reg a ha)
  -- the callee's slot region (in the caller's dead stack) is outside the callee's `F`
  have hslot_reg : ∀ a, SlotAt sz (L.A h).af.frameSize spb a →
      StackBelow (frameDrop (L.A h).af + κ (M - 1) h) (spv w) a := by
    intro a ⟨h1, h2⟩
    rw [hspb] at h1 h2
    exact ⟨by omega, by omega⟩
  have hslot_F : ∀ a, SlotAt sz (L.A h).af.frameSize spb a → F a ∧ ¬ L.Img a :=
    fun a ha => hdead a (hslot_reg a ha)
  have hspb_add : ∀ j < ib, OutAt ib spb (spb + BitVec.ofNat 64 j) := by
    intro j hj
    have e : (spb + BitVec.ofNat 64 j).toNat = spb.toNat + j := by
      rw [BitVec.toNat_add, BitVec.toNat_ofNat, Nat.mod_eq_of_lt (by omega : j < 2 ^ 64), hspb]
      exact Nat.mod_eq_of_lt (by omega)
    exact ⟨by omega, by omega⟩
  have hOut : ∀ (u : Arm.ArmState), spv u = spb →
      (∀ a n, cs.mem.valid a n = true → ∀ k < n, ¬ OutAt ib spb (BitVec.ofNat 64 (a + k))) →
      OutRel Fh ib cs.mem u := by
    intro u hu hv
    refine ⟨by omega, fun j hj hfh => hfh.2.1 (hu ▸ hspb_add j hj), fun a n hva k hk j hj e => ?_⟩
    rw [hu] at e
    exact hv a n hva k hk (e ▸ hspb_add j hj)
  -- the live allocations of the callee's entry: the caller's, and its slots in its slot region
  have hcsv : ∀ a n, cs.mem.valid a n = true → a + n ≤ 2 ^ 64 ∧ ∀ k < n,
      ¬ Fh (BitVec.ofNat 64 (a + k)) ∧ ¬ OutAt ib spb (BitVec.ofNat 64 (a + k)) := by
    intro a n hv
    simp only [Clif.Mem.valid, List.any_eq_true] at hv
    obtain ⟨x, hx, hcx⟩ := hv
    rcases hal' x hx with hx' | ⟨p, hp, rfl⟩
    · have hv' : cm.valid a n = true := List.any_eq_true.mpr ⟨x, hx', hcx⟩
      obtain ⟨h1, h2⟩ := hmr.valid a n hv'
      exact ⟨h1, fun k hk => ⟨fun hf => h2 k hk hf.1, fun ho => h2 k hk (hout_F _ ho).1⟩⟩
    · obtain ⟨off, hoff, hle⟩ := hfits p hp
      simp only [Clif.Alloc.contains, Bool.and_eq_true, decide_eq_true_eq, hoff,
        Option.getD_some] at hcx
      refine ⟨by omega, fun k hk => ?_⟩
      have e : (BitVec.ofNat 64 (a + k)).toNat = a + k := by
        rw [BitVec.toNat_ofNat]; exact Nat.mod_eq_of_lt (by omega)
      refine ⟨fun hf => hf.2.2 ⟨by rw [e]; omega, by rw [e]; omega⟩,
        fun ⟨o1, o2⟩ => by rw [e] at o1 o2; omega⟩
  -- the callee's entry memory is related to a body-entry world agreeing with the caller's
  have hRel : ∀ u, spv u = spb → Arm.r .ERR u = .None →
      (∀ a b, cm.valid a 1 = true → cm.bytes a = some b → Arm.read_mem (BitVec.ofNat 64 a) u = b) →
      RelW ⟨Fh, L.syms, (L.A h).af.slotBase, ib⟩ h (spv w₀) cs.frame.slots cs.mem u := by
    intro u hu herru hbu
    refine ⟨⟨⟨fun a b hv hb => ?_, fun a n hv => ⟨(hcsv a n hv).1,
      fun k hk => ((hcsv a n hv).2 k hk).1⟩, hsym'.trans hmr.symbols⟩, fun id b hl => ?_,
      hOut u hu (fun a n hv k hk => ((hcsv a n hv).2 k hk).2)⟩, by rw [hu, hspw₀], herru⟩
    · obtain ⟨hb', hnot⟩ := hby' a b hb
      refine hbu a b ?_ hb'
      simp only [Clif.Mem.valid, List.any_eq_true] at hv ⊢
      obtain ⟨x, hx, hcx⟩ := hv
      rcases hal' x hx with hx' | ⟨p, hp, rfl⟩
      · exact ⟨x, hx', hcx⟩
      · simp only [Clif.Alloc.contains, Bool.and_eq_true, decide_eq_true_eq] at hcx
        exact absurd ⟨hcx.1, by omega⟩ (hnot p hp)
    · rw [hsl'] at hl
      obtain ⟨p, hp, rfl, rfl⟩ := lookup_map_some hl
      obtain ⟨off, hoff, -⟩ := hfits p hp
      refine ⟨off, hoff, ?_⟩
      simp only [Rel.slotReg, hoff, Option.getD_some, hu]
      omega
  have hWE : L.WorldEntry κ (M - 1) h Fh vals cs w₀ := by
    refine ⟨hce, ?_, ?_, ?_, ?_, ?_, fun a ha => ⟨himgF a ha, fun ho => (hout_F a ho).2 ha,
      fun hs => (hslot_F a hs).2 ha⟩, fun hN => by rw [hspw₀]; exact hpl' (hpl hN)⟩
    · refine hRel w₀ hspw₀ ?_ fun a b hv hb => ?_
      · simp only [w₀]
        rw [r_bodyOf _ _ (by simp) (by simp), r_enterAt _ _ (by simp) (by simp),
          hcOk.world.1 _ (by simp [Masked])]
        exact herr
      · rw [← hmr.bytes a b hv hb]
        simp only [Arm.read_mem, Arm.read_store, w₀, mem_bodyOf, mem_enterAt]
        rw [L.mem_canon, mem_withImg, if_neg]
        intro hi
        exact (hmr.valid a 1 hv).2 0 (by omega) (by simpa using himgF _ hi)
    · intro loc v hmem
      obtain ⟨i, hi⟩ := List.mem_iff_getElem?.mp hmem
      cases loc with
      | stack off =>
        simp only
        have hx29 : Arm.r (.GPR 29#5) w₀ = spv w - 16#64 := by
          have := x29_bodyOf (L.A h).af (enterAt (L.A h) cn)
          rw [if_pos hfr, spv_enterAt, hsp0] at this
          exact this
        rw [hx29, fp_off_eq]
        refine ⟨fun k hk hf => hsav off v hmem k hk hf.1, ?_⟩
        rw [show Arm.read_mem_bytes v.ty.bytes (spv w + BitVec.ofNat 64 off) w₀ =
            Arm.read_mem_bytes v.ty.bytes (spv w + BitVec.ofNat 64 off) w from
          read_mem_bytes_congr _ _ (fun k hk => by
            simp only [w₀, mem_bodyOf, mem_enterAt]
            rw [L.mem_canon, mem_withImg, if_neg (fun hi => hsav off v hmem k hk (himgF _ hi))])]
        exact hargs.2.2 off v hmem
      | reg r =>
        obtain ⟨i, hr, hv⟩ := reg_zip _ _ hi
        have hlen := hargs.2.1.1
        obtain ⟨u, hu⟩ : ∃ u, uses[i]? = some u := by
          have hi' : i < uses.length := by
            rw [← hlen]; exact (List.getElem?_eq_some_iff.mp hv).1
          exact ⟨uses[i]'hi', List.getElem?_eq_getElem _⟩
        have hvh := hargs.2.1.2 i v u hv hu
        have hrA : r.isArgReg = true := harg r (List.mem_of_getElem? hr)
        simp only
        rw [show regVal w₀ r = regVal (placeArgs (regLocs h.sig) uses (L.withImg w)) r by
          simp only [w₀]; rw [regVal_bodyOf _ _ hrA, regVal_enterAt _ _ hrA, L.regVal_canon _ _ _ hrA],
          placeArgs_regVal _ _ _ hnd harg hr hu]
        refine vHolds_setVal ?_ hvh
        have hty := hce.sig
        have hvmem : v ∈ vals := List.of_mem_zip hmem |>.2
        obtain ⟨j, hj⟩ := List.mem_iff_getElem?.mp hvmem
        have e := congrArg (·[j]?) hty
        simp only [List.getElem?_map, hj, Option.map_some] at e
        cases hp : h.sig.params[j]? with
        | none => rw [hp] at e; cases e
        | some p =>
          rw [hp] at e
          simp only [Option.map_some, Option.some.injEq] at e
          rw [e]; exact hwid p (List.mem_of_getElem? hp)
    · rw [hspw₀, hB]; omega
    · intro a ha
      rw [hspw₀] at ha
      obtain ⟨h1, h2⟩ := ha
      rw [hB] at h1 h2
      have hd := hdead a ⟨by omega, by omega⟩
      exact ⟨⟨hd.1, fun ⟨o1, o2⟩ => by rw [hspb] at o1; omega,
        fun ⟨o1, o2⟩ => by rw [hspb] at o1; omega⟩, hd.2⟩
    · rw [hspw₀, hB, hdrop]; omega
  obtain ⟨hallG, hniG⟩ := ihG h hh Fh vals cs w₀ m rvals cm' hWE hm
  -- the callee's activation from a caller state `t`
  let G : BitVec 64 → Prop :=
    fun a => F a ∧ ¬ StackBelow (frameDrop (L.A h).af + κ (M - 1) h) (spv w) a
  have hcode : ∀ t, ∀ a, CodeAddr (enterAt (L.A h) t) a → L.Img a := fun t a ha =>
    hL.imgAddr h hh a (by simpa [CodeAddr] using ha)
  have hME : ∀ t w₀', spv t = spv w → Arm.r .ERR t = .None →
      (∀ a, L.Img a → t.mem a = L.imgMem a) →
      BodyEntryW Fh (L.A h).vcp.EntryArg (L.A h).af (enterAt (L.A h) t) w₀' →
      L.MachEntry κ (M - 1) h Fh G (Arm.r .PC t + 4) (enterAt (L.A h) t) w₀' := by
    intro t w₀' hst herrt himgt hbw
    have hspt : spv (enterAt (L.A h) t) = spv w := by rw [spv_enterAt]; exact hst
    have hFrame : frameWG (κ (M - 1) h) ib (RAFrame.compute (L.A h).vcp (L.A h).rf).size
        (L.A h).af G (enterAt (L.A h) t) = Fh := by
      funext a
      apply propext
      rw [frameWG_out hfr (by rw [hspt, ← hdrop]; exact hroom) hib_le hsz_le, ← hdrop, hspt]
      constructor
      · rintro (⟨hb, hno, hns⟩ | hc | hg)
        · exact ⟨(hdead a hb).1, hno, hns⟩
        · exact ⟨himgF a (hcode t a hc), fun ho => (hout_F a ho).2 (hcode t a hc),
            fun hs => (hslot_F a hs).2 (hcode t a hc)⟩
        · exact ⟨hg.1, fun ho => hg.2 (hout_reg a ho), fun hs => hg.2 (hslot_reg a hs)⟩
      · intro ⟨hF, hno, hns⟩
        by_cases hb : StackBelow (frameDrop (L.A h).af + κ (M - 1) h) (spv w) a
        · exact .inl ⟨hb, hno, hns⟩
        · exact .inr (.inr ⟨hF, hb⟩)
    refine ⟨⟨by simp, fun k wd hk => hL.imgCode h hh _ (fun a ha => by
        rw [mem_enterAt]; exact himgt a ha) k wd hk, by simp, ?_, x30_enterAt _ _, ?_,
        hL.fits h hh⟩, ?_, fun a ha => ?_, hFrame,
      fun a ha => ⟨himgF a ha, fun hb => (hdead a hb).2 ha⟩,
      fun a ha => by rw [mem_enterAt]; exact himgt a ha, hbw⟩
    · rw [r_enterAt _ _ (by simp) (by simp)]; exact herrt
    · rw [hspt]; exact hal
    · refine stackRoom_of (by rw [hspt, ← hdrop]; exact hroom) fun a ha hb => ?_
      rw [hspt, ← hdrop] at hb
      exact (hdead a hb).2 (hcode t a ha)
    · rw [hspt]; exact ha.2
  have hx29 : Arm.r (.GPR 29#5) w₀ = spv w - 16#64 := by
    have := x29_bodyOf (L.A h).af (enterAt (L.A h) cn)
    rw [if_pos hfr, spv_enterAt, hsp0] at this
    exact this
  have key2 : L.NeedNI → ∀ (Z : BitVec 64 → Prop) (t : Arm.ArmState), (∀ a, F a → Z a) →
      SameWorld Z t w → (∀ a, L.Img a → t.mem a = L.imgMem a) →
      (∀ r ∈ regLocs h.sig, regVal t r = regVal (L.canon h uses w) r) →
      MemRel F L.syms cm t →
      (∀ off v, (ArgLoc.stack off, v) ∈ (locsOf h.sig).zip vals → ∀ k < v.ty.bytes,
        t.mem (spv w + BitVec.ofNat 64 off + BitVec.ofNat 64 k) =
          w.mem (spv w + BitVec.ofNat 64 off + BitVec.ofNat 64 k)) →
      L.RunGoodL (M - 1) h (enterAt (L.A h) t) := by
    intro hN Z t hFZ hZ himgt hregt hmt hstkt
    have hst : spv t = spv w := hZ.1 _ (by simp [Masked])
    have herrt : Arm.r .ERR t = .None := by rw [hZ.1 _ (by simp [Masked])]; exact herr
    let w₀' := bodyOf (L.A h).af (enterAt (L.A h) t)
    let D : BitVec 64 → Prop := fun a => Z a ∧ ¬ Fh a
    have hspw₀' : spv w₀' = spb := by
      simp only [w₀']; rw [spv_bodyOf, spv_enterAt, hst]
    have hbw : BodyEntryW Fh (L.A h).vcp.EntryArg (L.A h).af (enterAt (L.A h) t) w₀' :=
      ⟨spv_bodyOf _ _, x29_bodyOf _ _, fun r hr => regVal_bodyOf _ _
        (harg r (hL.entryRegs h hh r hr)), fun f hf h29 h31 => r_bodyOf _ _ h29 h31,
        fun a _ => by simp [w₀'], by simp [w₀']⟩
    have hrel' : RelW ⟨Fh, L.syms, (L.A h).af.slotBase, ib⟩ h (spv w₀) cs.frame.slots cs.mem w₀' := by
      refine hRel w₀' hspw₀' ?_ fun a b hv hb => ?_
      · simp only [w₀']
        rw [r_bodyOf _ _ (by simp) (by simp), r_enterAt _ _ (by simp) (by simp)]
        exact herrt
      · have := hmt.bytes a b hv hb
        simp only [Arm.read_mem, Arm.read_store, w₀', mem_bodyOf, mem_enterAt] at this ⊢
        exact this
    have hsw : SameWorld (fun a => Fh a ∨ D a) w₀ w₀' := by
      refine ⟨fun f hf => ?_, fun a ha => ?_, by simp [w₀, w₀']⟩
      · by_cases h29 : f = .GPR 29#5
        · subst h29
          have e1 := x29_bodyOf (L.A h).af (enterAt (L.A h) cn)
          have e2 := x29_bodyOf (L.A h).af (enterAt (L.A h) t)
          simp only [xreg] at e1 e2
          rw [e1, e2, spv_enterAt, spv_enterAt, hsp0, hst, if_pos hfr, if_pos hfr]
        by_cases h31 : f = .GPR 31#5
        · subst h31
          show spv w₀ = spv w₀'
          rw [hspw₀, hspw₀']
        have hpc : f ≠ .PC := by rintro rfl; exact hf trivial
        have h30 : f ≠ .GPR 30#5 := by rintro rfl; exact hf (by simp [Masked])
        rw [r_bodyOf _ _ h29 h31, r_bodyOf _ _ h29 h31, r_enterAt _ _ hpc h30, r_enterAt _ _ hpc h30,
          hcOk.world.1 f hf, hZ.1 f hf]
      · have hnZ : ¬ Z a := fun hz => by
          by_cases hf : Fh a
          · exact ha (.inl hf)
          · exact ha (.inr ⟨hz, hf⟩)
        simp only [w₀, w₀', mem_bodyOf, mem_enterAt]
        rw [hcOk.world.2.1 a (fun hf => hnZ (hFZ a hf)), hZ.2.1 a hnZ]
    have hreg : ∀ r v, (ArgLoc.reg r, v) ∈ (locsOf h.sig).zip vals →
        regVal w₀' r = regVal w₀ r := by
      intro r v hm
      have hrl : r ∈ regLocs h.sig :=
        List.mem_filterMap.mpr ⟨.reg r, (List.of_mem_zip hm).1, rfl⟩
      have hrA := harg r hrl
      simp only [w₀, w₀']
      rw [regVal_bodyOf _ _ hrA, regVal_bodyOf _ _ hrA, regVal_enterAt _ _ hrA,
        regVal_enterAt _ _ hrA, hregt r hrl]
    have hstk : ∀ off v, (ArgLoc.stack off, v) ∈ (locsOf h.sig).zip vals → ∀ k < v.ty.bytes,
        w₀'.mem (Arm.r (.GPR 29#5) w₀ + BitVec.ofInt 64 (16 + (off : Int)) + BitVec.ofNat 64 k) =
          w₀.mem (Arm.r (.GPR 29#5) w₀ + BitVec.ofInt 64 (16 + (off : Int)) + BitVec.ofNat 64 k) := by
      intro off v hm k hk
      rw [hx29, fp_off_eq]
      have hnF := hsav off v hm k hk
      simp only [w₀, w₀', mem_bodyOf, mem_enterAt]
      rw [hstkt off v hm k hk, hcOk.world.2.1 _ hnF]
    exact hniG hN D w₀' hrel' hsw hreg hstk G (Arm.r .PC t + 4)
      (enterAt (L.A h) t) (hME t w₀' hst herrt himgt hbw)
  intro t ht
  by_cases hN : L.NeedNI
  · refine key2 hN F t (fun _ h => h) ht.world ht.img ht.regs ⟨fun a b hv hb => ?_,
      hmr.valid, hmr.symbols⟩ fun off v hm k hk => ht.world.2.1 _ (hsav off v hm k hk)
    rw [← hmr.bytes a b hv hb]
    simp only [Arm.read_mem, Arm.read_store]
    exact ht.world.2.1 _ (by simpa using (hmr.valid a 1 hv).2 0 (by omega))
  · -- no outgoing area: the canonical body-entry world is the actual activation's
    obtain ⟨hib0, hsz0⟩ := hib.resolve_right hN
    have hFh : Fh = F := funext fun a => propext ⟨fun h => h.1, fun h => ⟨h, fun ⟨o1, o2⟩ => by
      omega, fun ⟨o1, o2⟩ => by omega⟩⟩
    have hbw : BodyEntryW Fh (L.A h).vcp.EntryArg (L.A h).af (enterAt (L.A h) t) w₀ := by
      rw [hFh]; exact L.bodyEntryW_compat_semantic hL hh himgF ht
    have hst : spv t = spv w := ht.world.1 _ (by simp [Masked])
    have herrt : Arm.r .ERR t = .None := by rw [ht.world.1 _ (by simp [Masked])]; exact herr
    exact hallG G (Arm.r .PC t + 4) (enterAt (L.A h) t) (hME t w₀ hst herrt ht.img hbw)

/-- **The callee's states of a returning call of a function of `P`** (`progOsCore_semantic`'s premises):
from `ThmG` one level down. -/
theorem progGoodCore_semantic (hL : L.OkSemanticNI) [L.CrunOk] {M : Nat} (ihG : 0 < M → L.ThmG κ (M - 1))
    {g h : Clif.Function} (hg : g ∈ L.P.funcs) (hh : h ∈ L.P.funcs) (hcallee : L.Callee g h)
    {F G : BitVec 64 → Prop} {s0 : Arm.ArmState} (himgF : ∀ a, L.Img a → F a)
    (himgG : ∀ a, L.Img a → G a) (himgS : ∀ a, L.Img a → s0.mem a = L.imgMem a)
    {Lu : List (Nat × Reg)} (hLu : Lu.map (·.2) = regLocs h.sig)
    {t w w' : Arm.ArmState} {outs : List CV}
    (hG : ∀ a, G a → t.mem a = s0.mem a) (hra : RaOk (L.A h) (Arm.r .PC t))
    (hsw : SameWorld F t w)
    (hx : L.progX κ M F h (Lu.map (fun q => regVal t q.2)) w = some (outs, w')) :
    L.RunGoodL (M - 1) h (enterAt (L.A h) t) := by
  have hpf := func?_of_mem hL.names hh
  have hib : ((RAFrame.compute (L.A h).vcp (L.A h).rf).intBase = 0 ∧
      (RAFrame.compute (L.A h).vcp (L.A h).rf).size = (L.A h).af.frameSize) ∨ L.NeedNI := by
    by_cases h0 : (RAFrame.compute (L.A h).vcp (L.A h).rf).intBase = 0
    · by_cases h1 : (RAFrame.compute (L.A h).vcp (L.A h).rf).size = (L.A h).af.frameSize
      · exact .inl ⟨h0, h1⟩
      · exact .inr ⟨g, hg, h, hcallee, .inr h1⟩
    · exact .inr ⟨g, hg, h, hcallee, .inl h0⟩
  obtain ⟨hnd, harg, -⟩ := hL.argRegs h hh
  generalize huses : Lu.map (fun q => regVal t q.2) = uses at hx
  unfold progX at hx
  have hcond : L.Cond κ M F h uses w ∧
      Arm.r .ERR (L.pcall M h (L.canon h uses w)) = .None :=
    Classical.byContradiction fun hc => by rw [if_neg hc] at hx; cases hx
  obtain ⟨⟨hM, herrw, halw, hroom, hdead, vals, cm, cs, rvals, cm', hmr, hargs, hsav, hpl, hinit,
    hrun⟩, -⟩ := hcond
  have hcOk : L.CallerOk F h uses w t := by
    refine ⟨hsw, fun a ha => (hG a (himgG a ha)).trans (himgS a ha), fun r hr => ?_,
      hra⟩
    rw [← hLu] at hr
    obtain ⟨j, hj⟩ := List.mem_iff_getElem?.mp hr
    have hrA : r.isArgReg = true := harg r (by rw [← hLu]; exact List.mem_of_getElem? hj)
    have hu : uses[j]? = some (regVal t r) := by
      simp only [List.getElem?_map, Option.map_eq_some_iff] at hj
      obtain ⟨q, hq, rfl⟩ := hj
      simp [← huses, hq]
    rw [L.regVal_canon _ _ _ hrA, placeArgs_regVal _ _ _ hnd harg (by rw [← hLu]; exact hj) hu,
      setVal_regVal]
  exact L.progCallG_semantic hL hM (ihG hM) hpf ⟨g, hg, hcallee⟩ hib himgF herrw halw hroom hdead hmr
    hargs hsav hpl hinit hrun t hcOk

/-- **The callee of a `blr` at a call state is one `g` may enter through the call's register**
(`BlrTo`): the callee contract's premise (`RL.CallPre`) is a call through `L.X`, which enters a
function of `P` only when `g` may enter it (`IndTo`), and pins a call through the GOT to its
symbol (`gotGuard`). -/
theorem blrTo_of_pre_semantic (hL : L.OkSemanticNI) {M : Nat} {g : Clif.Function}
    (hg : g ∈ L.P.funcs) {F G : BitVec 64 → Prop} {ra : BitVec 64} {s w₀ : Arm.ArmState}
    (he : L.MachEntry κ M g F G ra s w₀) {u : Arm.ArmState} {h : Clif.Function}
    (hpre : (L.actRL κ M g F G s).CallPre u) (hprog : u.program = (L.A g).fb.program (L.A g).base)
    {xr : Reg} (hx0 : insnAt (L.A g).fa (progBase u) (Arm.r .PC u) = some (.blr xr))
    (hb : (blrTarget u).bind (symCallee L.Xb L.P) = some h) :
    ∃ info tv, (L.A g).vcp.CallSite info ∧ info.dest = .reg (.vreg tv .int) ∧ L.BlrTo g tv h := by
  obtain ⟨ctx, i, ctl, ⟨info, hsite, hi⟩, -, -, hGk, c, wh, ops, regs, i', w, outs, w', hops, hst,
    hasg, hP, -, -, -, hsem⟩ := hpre
  have hsite : (L.A g).vcp.CallSite info := hsite
  have hGk : ∀ a, G a → u.mem a = s.mem a := hGk
  have hFe : (L.actRL κ M g F G s).F = F := he.hF
  have hP : CallAt (L.A g).fa (L.A g).base (Arm.r .PC u) i' := hP
  have hsem : csemV (GotV (L.A g).vcp) F ctx (L.X κ M g F) i (useVals ops regs u) w =
      some (outs, w', ctl) := hFe ▸ hsem
  -- the plain call of the instruction
  obtain ⟨ic, hasgC, hPC, hopsC, hst', hx, hguard⟩ : ∃ ic,
      (MInst.call info).assign regs = .ok (.call ic) ∧
      CallAt (L.A g).fa (L.A g).base (Arm.r .PC u) (.call ic) ∧
      (MInst.call info).operands = .ok ops ∧
      (∃ clob, c.checkStatic wh ops (regs.map .reg) clob = .ok ()) ∧
      (∃ o w2, (L.X κ M g F).call (match info.dest with | .sym n => some n | .reg _ => none)
        (useVals ops regs u) w = some (o, w2)) ∧
      gotGuard (GotV (L.A g).vcp) (L.X κ M g F) info (useVals ops regs u) := by
    rcases hi with rfl | ⟨ti, rfl⟩
    · obtain ⟨ic, rfl⟩ := (assign_call_tryCall info regs).1 i' hasg
      have h0 := csemV_sub hsem
      simp only [csem, Option.map_eq_some_iff] at h0
      obtain ⟨⟨o, w2⟩, hx, -⟩ := h0
      exact ⟨ic, hasg, hP, hops, ⟨_, hst⟩, ⟨o, w2, hx⟩, csemV_guard hsem⟩
    · obtain ⟨ic, rfl, hasg'⟩ := (assign_call_tryCall info regs).2 ti i' hasg
      have h0 := csemV_sub hsem
      simp only [csem, Option.map_eq_some_iff, Option.filter_eq_some_iff] at h0
      obtain ⟨⟨o, w2⟩, ⟨hx, -⟩, -⟩ := h0
      exact ⟨ic, hasg', callAt_tryCall_call hP,
        by rw [← operands_tryCall_call info ti]; exact hops, ⟨_, hst⟩, ⟨o, w2, hx⟩,
        csemV_guard_try hsem⟩
  obtain ⟨j, x, tt, hj, hx', hpc⟩ := hPC
  have hc := hL.compiled g hg
  obtain ⟨lm, hlm⟩ := FnAsm.layout_labelOffsets hc.layout
  have hins : insnAt (L.A g).fa (progBase u) (Arm.r .PC u) = some x := by
    rw [hpc]; exact insnAt_ofLine_semantic hc.layout hlm (by have := hL.fits g hg; omega) hprog hj
  obtain ⟨o, w2, hx⟩ := hx
  obtain ⟨clob, hst'⟩ := hst'
  cases hd : info.dest with
  | sym n =>
    obtain ⟨d0, us0, ds0⟩ := info
    simp only at hd
    subst hd
    obtain ⟨us', ds', hic⟩ := assign_call_sym hasgC
    cases hic
    simp only [MInst.callInsn?, Option.some.injEq] at hx'
    subst hx'
    rw [hins] at hx0; cases hx0
  | reg r =>
    have hreg : ∀ n, info.dest ≠ .sym n := fun n => by rw [hd]; simp
    obtain ⟨tv, Lu, Ld, rfl, hregs⟩ := hL.blrRegs g hg info hsite hreg
    rw [operands_call_reg] at hopsC
    cases hopsC
    obtain ⟨hsz', hloc, -, -⟩ := checkStatic_facts hst'
    obtain ⟨r0, hregs0⟩ := callRegs_eq_reg (regs := regs) (by simpa using hsz')
      (fun p hp r hr => (hloc p hp).2 r hr)
    obtain ⟨n0, rfl, hn0, -⟩ : ∃ n, r0 = .x n ∧ n < 29 ∧ n ≠ 16 := by
      have hmem : (tgtOp tv, Loc.reg r0) ∈
          (((tgtOp tv :: (retOps Lu ++ callDefOps Ld)).toArray).zip (regs.map Loc.reg)).toList := by
        simp [Array.toList_zip, Array.toList_map, hregs0]
      obtain ⟨n, hn, h29, h16, -⟩ := locOk_int (hloc _ hmem).1
      exact ⟨n, hn, h29, h16⟩
    obtain ⟨r1, us', ds', hr1, hic⟩ := assign_call_reg hasgC
    have h0 : regs[0]? = some (.x n0) := by
      rw [← Array.getElem?_toList, hregs0]; rfl
    rw [h0] at hr1
    cases hr1
    cases hic
    simp only [MInst.callInsn?, Option.some.injEq] at hx'
    subst hx'
    have htgt : blrTarget u = some (lo64 (regVal u (.x n0))) := by
      rw [lo64_regVal_x]
      exact blrTarget_of hc.layout hlm hj hn0 hpc
        (fun k wd hk => hL.imgCode g hg u (fun a ha => (hGk a (he.imgG a ha)).trans (he.imgS a ha)) k wd hk)
    have hs : symCallee L.Xb L.P (lo64 (regVal u (.x n0))) = some h := by
      rw [htgt] at hb; exact hb
    have hx2 : (L.X κ M g F).call none (regVal u (.x n0) :: Lu.map (fun q => regVal u q.2)) w =
        some (o, w2) := by
      rw [← call_useVals_reg hregs0]; exact hx
    rw [L.X_ind hs] at hx2
    split at hx2
    · rename_i hdecl
      have hgot : ∀ n, GotV (L.A g).vcp tv n → n = h.name := by
        intro n hn
        have e := hguard tv n _ rfl hn (operands_call_reg tv Lu Ld) (by simp [tgtOp, Operand.isUse])
        rw [call_useVals_reg hregs0] at e
        simp only [List.head?_cons, Option.map_some, Option.some.injEq] at e
        exact L.got_target_semantic hL hs e
      exact ⟨_, tv, hsite, rfl, hdecl.1, hgot⟩
    · cases hx2

/-- **The crux: the callee's states at a call state.** At a state `u` of the activation of `g`
at depth `M` where the callee contract's premise holds (`RL.CallPre`, which `RL.GoodX.call` gives
at a `bl`/`blr` line) and the machine calls `h` (`CallsAtL`), every state of `h`'s run entered
from `u` whose step ends without error has the per-state facts: the premise is the antecedent of
`progOs_semantic`/`progOsReg_semantic` (`calleeOk_semantic`), whose linked call of `h` is the callee activation of
`progCall_semantic`, whose states `ThmG` one level down covers. -/
theorem callGood_semantic (hL : L.OkSemanticNI) [L.CrunOk] {M : Nat} (ihG : 0 < M → L.ThmG κ (M - 1)) {g : Clif.Function}
    (hg : g ∈ L.P.funcs) {F G : BitVec 64 → Prop} {ra : BitVec 64} {s w₀ : Arm.ArmState}
    (he : L.MachEntry κ M g F G ra s w₀) {u : Arm.ArmState} {h : Clif.Function}
    (hpre : (L.actRL κ M g F G s).CallPre u) (hprog : u.program = (L.A g).fb.program (L.A g).base)
    (hcall : L.CallsAtL g u h) : L.RunGoodL (M - 1) h (enterAt (L.A h) u) := by
  obtain ⟨ctx, i, ctl, ⟨info, hsite, hi⟩, -, -, hGk, c, wh, ops, regs, i', w, outs, w', hops, hst,
    hasg, hP, hsw, -, -, hsem⟩ := hpre
  have hsite : (L.A g).vcp.CallSite info := hsite
  have hGk : ∀ a, G a → u.mem a = s.mem a := hGk
  have hFe : (L.actRL κ M g F G s).F = F := he.hF
  have hsw : SameWorld F u w := hFe ▸ hsw
  have hP : CallAt (L.A g).fa (L.A g).base (Arm.r .PC u) i' := hP
  have hsem : csemV (GotV (L.A g).vcp) F ctx (L.X κ M g F) i (useVals ops regs u) w =
      some (outs, w', ctl) := hFe ▸ hsem
  -- the plain call of the instruction
  obtain ⟨ic, hasgC, hPC, hopsC, hst', hx, hguard⟩ : ∃ ic,
      (MInst.call info).assign regs = .ok (.call ic) ∧
      CallAt (L.A g).fa (L.A g).base (Arm.r .PC u) (.call ic) ∧
      (MInst.call info).operands = .ok ops ∧
      (∃ clob, c.checkStatic wh ops (regs.map .reg) clob = .ok ()) ∧
      (∃ o w2, (L.X κ M g F).call (match info.dest with | .sym n => some n | .reg _ => none)
        (useVals ops regs u) w = some (o, w2)) ∧
      gotGuard (GotV (L.A g).vcp) (L.X κ M g F) info (useVals ops regs u) := by
    rcases hi with rfl | ⟨ti, rfl⟩
    · obtain ⟨ic, rfl⟩ := (assign_call_tryCall info regs).1 i' hasg
      have h0 := csemV_sub hsem
      simp only [csem, Option.map_eq_some_iff] at h0
      obtain ⟨⟨o, w2⟩, hx, -⟩ := h0
      exact ⟨ic, hasg, hP, hops, ⟨_, hst⟩, ⟨o, w2, hx⟩, csemV_guard hsem⟩
    · obtain ⟨ic, rfl, hasg'⟩ := (assign_call_tryCall info regs).2 ti i' hasg
      have h0 := csemV_sub hsem
      simp only [csem, Option.map_eq_some_iff, Option.filter_eq_some_iff] at h0
      obtain ⟨⟨o, w2⟩, ⟨hx, -⟩, -⟩ := h0
      exact ⟨ic, hasg', callAt_tryCall_call hP,
        by rw [← operands_tryCall_call info ti]; exact hops, ⟨_, hst⟩, ⟨o, w2, hx⟩,
        csemV_guard_try hsem⟩
  have hcp := hPC.callPc
  obtain ⟨j, x, tt, hj, hx', hpc⟩ := hPC
  have hc := hL.compiled g hg
  obtain ⟨lm, hlm⟩ := FnAsm.layout_labelOffsets hc.layout
  have hins : insnAt (L.A g).fa (progBase u) (Arm.r .PC u) = some x := by
    rw [hpc]; exact insnAt_ofLine_semantic hc.layout hlm (by have := hL.fits g hg; omega) hprog hj
  obtain ⟨o, w2, hx⟩ := hx
  obtain ⟨clob, hst'⟩ := hst'
  cases hd : info.dest with
  | sym n =>
    obtain ⟨d0, us0, ds0⟩ := info
    simp only at hd
    subst hd
    obtain ⟨us', ds', hic⟩ := assign_call_sym hasgC
    cases hic
    simp only [MInst.callInsn?, Option.some.injEq] at hx'
    subst hx'
    have hpf : L.P.func? n = some h := by
      rcases hcall with ⟨n', hn', hpf'⟩ | ⟨⟨r', hr'⟩, -⟩
      · rw [hins] at hn'; cases hn'; exact hpf'
      · rw [hins] at hr'; cases hr'
    obtain ⟨hh, -⟩ := Clif.Program.func?_some hpf
    have hps : L.ProgSite g ⟨.sym n, us0, ds0⟩ h := ⟨hsite, n, rfl, hpf⟩
    obtain ⟨n', Lu, Ld, hinfo, hLu, -⟩ := hL.callRegs g hg _ h hps
    cases hinfo
    rw [operands_call_sym] at hopsC
    cases hopsC
    obtain ⟨hsz', hloc, -, -⟩ := checkStatic_facts hst'
    have hregs := callRegs_eq (regs := regs) (by simpa using hsz')
      (fun p hp r hr => (hloc p hp).2 r hr)
    have hx2 : L.progX κ M F h (Lu.map (fun q => regVal u q.2)) w = some (o, w2) := by
      rw [← L.X_prog (κ := κ) (M := M) (g := g) hpf, ← call_useVals hregs]; exact hx
    exact L.progGoodCore_semantic hL ihG hg hh (.inl ⟨_, hps⟩) he.imgF he.imgG he.imgS hLu hGk
      (hL.raCall g hg _ h hps _ hcp) hsw hx2
  | reg r =>
    have hreg : ∀ n, info.dest ≠ .sym n := fun n => by rw [hd]; simp
    obtain ⟨tv, Lu, Ld, rfl, hregs⟩ := hL.blrRegs g hg info hsite hreg
    rw [operands_call_reg] at hopsC
    cases hopsC
    obtain ⟨hsz', hloc, -, -⟩ := checkStatic_facts hst'
    obtain ⟨r0, hregs0⟩ := callRegs_eq_reg (regs := regs) (by simpa using hsz')
      (fun p hp r hr => (hloc p hp).2 r hr)
    obtain ⟨n0, rfl, hn0, -⟩ : ∃ n, r0 = .x n ∧ n < 29 ∧ n ≠ 16 := by
      have hmem : (tgtOp tv, Loc.reg r0) ∈
          (((tgtOp tv :: (retOps Lu ++ callDefOps Ld)).toArray).zip (regs.map Loc.reg)).toList := by
        simp [Array.toList_zip, Array.toList_map, hregs0]
      obtain ⟨n, hn, h29, h16, -⟩ := locOk_int (hloc _ hmem).1
      exact ⟨n, hn, h29, h16⟩
    obtain ⟨r1, us', ds', hr1, hic⟩ := assign_call_reg hasgC
    have h0 : regs[0]? = some (.x n0) := by
      rw [← Array.getElem?_toList, hregs0]; rfl
    rw [h0] at hr1
    cases hr1
    cases hic
    simp only [MInst.callInsn?, Option.some.injEq] at hx'
    subst hx'
    have htgt : blrTarget u = some (lo64 (regVal u (.x n0))) := by
      rw [lo64_regVal_x]
      exact blrTarget_of hc.layout hlm hj hn0 hpc
        (fun k wd hk => hL.imgCode g hg u (fun a ha => (hGk a (he.imgG a ha)).trans (he.imgS a ha)) k wd hk)
    have hs : symCallee L.Xb L.P (lo64 (regVal u (.x n0))) = some h := by
      rcases hcall with ⟨n', hn', -⟩ | ⟨-, hb⟩
      · rw [hins] at hn'; cases hn'
      · rw [htgt] at hb; exact hb
    have hx2 : (L.X κ M g F).call none (regVal u (.x n0) :: Lu.map (fun q => regVal u q.2)) w =
        some (o, w2) := by
      rw [← call_useVals_reg hregs0]; exact hx
    rw [L.X_ind hs] at hx2
    split at hx2
    · rename_i hdecl
      have hh : h ∈ L.P.funcs := List.mem_of_find?_eq_some hs
      have hgot : ∀ n, GotV (L.A g).vcp tv n → n = h.name := by
        intro n hn
        have e := hguard tv n _ rfl hn (operands_call_reg tv Lu Ld) (by simp [tgtOp, Operand.isUse])
        rw [call_useVals_reg hregs0] at e
        simp only [List.head?_cons, Option.map_some, Option.some.injEq] at e
        exact L.got_target_semantic hL hs e
      obtain ⟨hLu, -⟩ := hregs h hh ⟨hdecl.1, hgot⟩ (by rw [← hdecl.2, List.length_map])
      exact L.progGoodCore_semantic hL ihG hg hh (.inr (.inr ⟨hh, hdecl.1.1⟩)) he.imgF he.imgG he.imgS hLu
        hGk (hL.raBlr g hg _ hsite hreg h hh hdecl.1.1 _ hcp) hsw hx2
    · cases hx2

/-! ## The states of an activation's run -/

/-- **The states of the activation of `g` at depth `M` entered in `s`** from its trace (the
register-level `GoodX` of every state before `n`), when every state before its return whose step
ends without error is before `n`: its own states from the trace, the nested ones from the call
states (`callGood_semantic`). -/
theorem runGood_of_trace_semantic (hL : L.OkSemanticNI) [L.CrunOk] {M : Nat} (ihG : 0 < M → L.ThmG κ (M - 1))
    {g : Clif.Function} (hg : g ∈ L.P.funcs) {F G : BitVec 64 → Prop} {ra : BitVec 64}
    {s w₀ : Arm.ArmState} (he : L.MachEntry κ M g F G ra s w₀) {n : Nat}
    (hgood : ∀ i < n, actGoodX (L.A g).vcp (L.A g).rf (L.A g).af (L.A g).fa (L.A g).fb
      (L.A g).base s (L.X κ M g F) (L.hooks M) (κ M g) G (GotV (L.A g).vcp)
      (runX (L.mach M g) i s))
    (hbound : ∀ k, (∀ j ≤ k, ¬ RetL (L.A g) s (runX (L.mach M g) j s)) →
      Arm.r .ERR (runX (L.mach M g) (k + 1) s) = .None → k < n) :
    L.RunGoodL M g s := by
  intro M' g' c' t hR herrt
  cases hR with
  | act hno =>
    rename_i k
    have hG : (L.actRL κ M g F G s).GoodX (runX (L.mach M g) k s) :=
      hgood k (hbound k hno (by rw [runX_add]; exact herrt))
    refine ⟨L.X κ M g F, κ M g, G, GotV (L.A g).vcp, rfl, hG, he.imgG, he.imgS, ?_⟩
    intro xr h hx hb
    obtain ⟨x, ⟨j, tt, hj, hpc⟩, -⟩ := hG.line
    have hj' : (L.A g).fa.lines.toList[j]? = some (.ins x tt) := hj
    have hc := hL.compiled g hg
    obtain ⟨lm, hlm⟩ := FnAsm.layout_labelOffsets hc.layout
    have hsz : ((L.A g).fa.lines.toList.map Line.size).sum ≤ 2 ^ 64 := by
      rw [layout_sum hc.layout]; have := hL.fits g hg; omega
    have hx' : insnAt (L.A g).fa (L.A g).base (Arm.r .PC (runX (L.mach M g) k s)) = some x := by
      rw [hpc]; exact insnAt_line hsz hj'
    rw [hx'] at hx; cases hx
    have hins : insnAt (L.A g).fa (progBase (runX (L.mach M g) k s))
        (Arm.r .PC (runX (L.mach M g) k s)) = some (.blr xr) := by
      rw [hpc]; exact insnAt_ofLine_semantic hc.layout hlm (by have := hL.fits g hg; omega) hG.prog hj'
    exact L.blrTo_of_pre_semantic hL hg he (hG.call _ ⟨j, tt, hj, hpc⟩ (.inr ⟨xr, rfl⟩)) hG.prog hins hb
  | nest hno hcall herr1 hR' =>
    rename_i M0 k h
    have hG : (L.actRL κ (M0 + 1) g F G s).GoodX (runX (L.mach (M0 + 1) g) k s) :=
      hgood k (hbound k hno herr1)
    obtain ⟨x, ⟨j, tt, hj, hpc⟩, -⟩ := hG.line
    have hj' : (L.A g).fa.lines.toList[j]? = some (.ins x tt) := hj
    have hc := hL.compiled g hg
    obtain ⟨lm, hlm⟩ := FnAsm.layout_labelOffsets hc.layout
    have hins : insnAt (L.A g).fa (progBase (runX (L.mach (M0 + 1) g) k s))
        (Arm.r .PC (runX (L.mach (M0 + 1) g) k s)) = some x := by
      rw [hpc]; exact insnAt_ofLine_semantic hc.layout hlm (by have := hL.fits g hg; omega) hG.prog hj'
    have hpre : (L.actRL κ (M0 + 1) g F G s).CallPre (runX (L.mach (M0 + 1) g) k s) := by
      rcases hcall with ⟨n', hn', -⟩ | ⟨⟨r', hr'⟩, -⟩
      · rw [hins] at hn'; cases hn'; exact hG.call _ ⟨j, tt, hj, hpc⟩ (.inl ⟨n', rfl⟩)
      · rw [hins] at hr'; cases hr'; exact hG.call _ ⟨j, tt, hj, hpc⟩ (.inr ⟨r', rfl⟩)
    exact L.callGood_semantic hL ihG hg he hpre hG.prog hcall _ _ _ _ hR' herrt

/-- A returning activation (`ActRet`) has returned in the sense of `RetL`. -/
theorem retL_of_actRet_semantic {g : Clif.Function} {ra : BitVec 64} {s t : Arm.ArmState}
    {F G : BitVec 64 → Prop} {us : List (Reg × Reg)} {outs : List CV} {wf : Arm.ArmState}
    (habi : AbiCall (L.A g).fb (L.A g).base ra s) (hret : ActRet ra F G us outs wf s t) :
    RetL (L.A g) s t :=
  ⟨hret.ret.pc.trans habi.lr.symm, hret.ret.err, hret.prog.trans habi.program, hret.ret.sp⟩

/-- **The per-state part of the induction step.** -/
theorem thmG_of_semantic (hL : L.OkSemanticNI) [L.CrunOk] (hκ : L.Budget κ) {M : Nat} (ih : 0 < M → L.Thm κ (M - 1))
    (ihG : 0 < M → L.ThmG κ (M - 1)) : L.ThmG κ M := by
  intro g hg F vals cs w₀ fuel rvals cm' hWE hrun
  have hc := hL.compiled g hg
  have hI : Clif.LInv (L.P.only g) cs := runInv_entry (by simp [Clif.Program.only]) hWE.clif
  have hJ : L.ActInv g (spv w₀) cs := ⟨hI, hWE.clif.callers, hWE.place⟩
  have hrun' : Clif.runLoop (L.envOf M g (spv w₀)) L.P.bare fuel cs = .returned rvals cm' := by
    rw [L.runLoop_envOf_semantic hL hg fuel cs hJ]; exact hrun
  have h := backend_correct_world_niX_semantic ((hL.subset g hg).retarget (Clif.Program.bare_func? L.P)) hc
    (X := L.X κ M g F) (syms := L.syms)
    (env := L.envOf M g (spv w₀)) (K := κ M g) (F := F) (c := spv w₀) (hL.covered g hg)
    (L.xCallsOk_semantic hL hκ ih hg hWE.img hWE.room hWE.dead hWE.align)
    (L.xCallsIndOk_semantic hL hκ ih hg hWE.img hWE.room hWE.dead hWE.align)
    (fun n b hn => hL.symOk n b hn) rfl hWE.clif hWE.rel hWE.args
    (trapsExplicit_of_returned hrun') fuel
  obtain ⟨_us, _outs, _wf, -, -, -, -, -, hall, hni⟩ := h rvals cm' hrun'
  have hAE : ∀ G ra s w₀', L.MachEntry κ M g F G ra s w₀' →
      ActEntry (L.A g).vcp (L.A g).rf (L.A g).af (L.A g).fa (L.A g).fb (κ M g) F G (L.X κ M g F)
        (L.hooks M) (L.A g).base ra s w₀' := fun G ra s w₀' hME =>
    ⟨hME.abi, hME.stack, hME.gfree, hME.hF, L.calleeOk_semantic hL hκ ih hg hME,
      fun _ => L.calleeTryOk_semantic hL hκ ih hg hME,
      fun ht => L.tlsOk_hooks (hL.baseTls g hg (hasTls_of_vcode_semantic hc ht) F (κ M g)), hME.body⟩
  refine ⟨fun G ra s hME => ?_, fun hN D w₀' hrel' hsw hreg hstk G ra s hME => ?_⟩
  · obtain ⟨n, hret, -, hgood⟩ := hall (L.hooks M) G (L.A g).base ra s (hAE G ra s w₀ hME)
    exact L.runGood_of_trace_semantic hL ihG hg hME hgood fun k hno _ =>
      Nat.lt_of_not_le fun hle => hno n hle (L.retL_of_actRet_semantic hME.abi hret)
  · obtain ⟨n, hret, -, hgood⟩ := hni (L.xni_semantic hL hN ih hg hWE.img (spv w₀)) (L.xTls_semantic hL hN) D w₀'
      hrel' hsw hreg hstk (L.hooks M) G (L.A g).base ra s (hAE G ra s w₀' hME)
    exact L.runGood_of_trace_semantic hL ihG hg hME hgood fun k hno _ =>
      Nat.lt_of_not_le fun hle => hno n hle (L.retL_of_actRet_semantic hME.abi hret)

/-- **The per-state part of the linking statement at every depth.** -/
theorem thmG_semantic (hL : L.OkSemanticNI) [L.CrunOk] (hκ : L.Budget κ) : ∀ M, L.ThmG κ M
  | 0 => L.thmG_of_semantic hL hκ (fun h => absurd h (Nat.lt_irrefl 0)) fun h => absurd h (Nat.lt_irrefl 0)
  | M + 1 => L.thmG_of_semantic hL hκ (fun _ => L.thm_semantic hL hκ M) fun _ => thmG_semantic hL hκ M

/-- **The induction step of the linking statement with the per-state facts.** -/
theorem thmX_of_semantic (hL : L.OkSemanticNI) [L.CrunOk] (hκ : L.Budget κ) {M : Nat} (ih : 0 < M → L.ThmX κ (M - 1)) :
    L.ThmX κ M :=
  ⟨L.thm_of_semantic hL hκ fun h => (ih h).1, L.thmG_of_semantic hL hκ (fun h => (ih h).1) fun h => (ih h).2⟩

/-- **The linking statement with the per-state facts at every depth.** -/
theorem thmX_semantic (hL : L.OkSemanticNI) [L.CrunOk] (hκ : L.Budget κ) : ∀ M, L.ThmX κ M
  | 0 => L.thmX_of_semantic hL hκ fun h => absurd h (Nat.lt_irrefl 0)
  | M + 1 => L.thmX_of_semantic hL hκ fun _ => thmX_semantic hL hκ M

/-! ## `RunGoodL` does not read the callee runs -/

theorem reachL_withCrun_semantic {L : LinkSys} {cr : Nat → Clif.State → Clif.Outcome} {M : Nat}
    {f : Clif.Function} {c : Arm.ArmState} {M' : Nat} {g : Clif.Function} {c' t : Arm.ArmState}
    (h : L.ReachL M f c M' g c' t) : (L.withCrun cr).ReachL M f c M' g c' t := by
  induction h with
  | act hj =>
    rw [← L.mach_withCrun cr] at hj ⊢
    exact .act hj
  | nest hj hc herr _ ih =>
    rw [← L.mach_withCrun cr] at hj hc herr ih
    exact .nest hj hc herr ih

theorem goodAt_withCrun_semantic {L : LinkSys} {cr : Nat → Clif.State → Clif.Outcome} {M : Nat}
    {g : Clif.Function} {c t : Arm.ArmState} (h : (L.withCrun cr).GoodAt M g c t) :
    L.GoodAt M g c t := by
  obtain ⟨X, K, G, gv, heq, hg, hi⟩ := h
  rw [L.hooks_withCrun, L.mach_withCrun] at heq
  rw [L.hooks_withCrun] at hg
  exact ⟨X, K, G, gv, heq, hg, hi⟩

/-- **`RunGoodL` does not depend on the callee runs** of the linked system (the linked machine
does not read them). -/
theorem runGoodL_withCrun_semantic {L : LinkSys} {cr : Nat → Clif.State → Clif.Outcome} {M : Nat}
    {f : Clif.Function} {c : Arm.ArmState} (h : (L.withCrun cr).RunGoodL M f c) :
    L.RunGoodL M f c := fun M' g c' t hR he =>
  goodAt_withCrun_semantic (h M' g c' t (reachL_withCrun_semantic hR) (by rw [L.mach_withCrun]; exact he))

end LinkSys

/-- **`backend_correct_program_core_semantic` with the run's per-state facts** for a returning or
trapping outcome (`RunGoodL`), for any callee runs (`LinkSys.CrunOk`). -/
theorem backend_correct_program_coreX_semantic (L : LinkSys) (hL : L.OkSemanticNI) [L.CrunOk]
    {κ : Nat → Clif.Function → Nat} (hκ : L.Budget κ) {f : Clif.Function}
    (hf : f ∈ L.P.funcs) (M : Nat) {ra : BitVec 64} {s w₀ : Arm.ArmState} {args : List Clif.Val}
    {cs : Clif.State}
    (hent : AbiEntry (L.A f).fb (L.A f).base ra s) (hres : StackAvail (κ M f) (L.A f).af s)
    (hF : L.F = frameWG (κ M f) (RAFrame.compute (L.A f).vcp (L.A f).rf).intBase
      (RAFrame.compute (L.A f).vcp (L.A f).rf).size (L.A f).af L.Img s)
    (hgfree : ∀ a, L.Img a → ¬ StackBelow (frameDrop (L.A f).af + κ M f) (spv s) a)
    (himg : ∀ a, L.Img a → s.mem a = L.imgMem a)
    (hbe : BodyEntry (L.A f).af s w₀) (hargs : ArgsIn f.sig args s) (hcs : ClifEntry f args cs)
    (hsav : StackArgsAvoid L.Img f.sig args s)
    (hrel : Rel.holds ⟨L.F, L.syms, (L.A f).af.slotBase,
      (RAFrame.compute (L.A f).vcp (L.A f).rf).intBase⟩ f cs.frame.slots cs.mem w₀)
    (hpl : L.NeedSlots → L.PlaceAt cs.mem (spv w₀))
    (htr : TrapsExplicit (Clif.linkEnvR L.P L.base (L.crun M)) L.P.bare cs) {o : Clif.Outcome}
    (hlink : ((∃ vals cm, o = .returned vals cm) ∨ ∃ c, o = .trapped c) →
      ∃ m, Clif.runLoop (L.envR M f) L.P.bare m cs = o) :
    ArmRefines (L.A f).fb (L.A f).base ra (L.mach M f) s o ∧
      ((∃ vals cm, o = .returned vals cm) ∨ (∃ c, o = .trapped c) → L.RunGoodL M f s) := by
  refine ⟨backend_correct_program_core_semantic L hL hκ hf M hent hres hF hgfree himg hbe hargs hcs hsav
    hrel hpl htr hlink, fun hout => ?_⟩
  have hc := hL.compiled f hf
  have hfr := lowerRFunc_frame hc.alloc
  have hst := hres
  obtain ⟨hB, hK⟩ := spBody_toNat hres
  have hd : frameDrop (L.A f).af = (L.A f).af.frameSize + 16 := by simp [frameDrop, hfr]
  -- the world side
  have hWE : L.WorldEntry κ M f L.F args cs w₀ := by
    refine ⟨hcs, ⟨hrel, rfl, ?_⟩, ?_, ?_, ?_, ?_, hL.imgF, hpl⟩
    · rw [hbe.other .ERR (by simp [Masked]) (by simp) (by simp)]; exact hent.err
    · refine argsAtEntry_body hfr hc.entryRegs hbe hargs fun off v hm k hk hk' => ?_
      rw [hF] at hk'
      rcases hk' with hw | hi
      · exact stackArgsAvoid_frameW_semantic hc hres hent hargs off v hm k hk hw
      · exact hsav off v hm k hk hi
    · rw [hbe.sp, hB]; omega
    · intro a ha
      rw [hbe.sp] at ha
      refine ⟨by rw [hF]; exact .inl (.inr ha), fun hi => hgfree a hi ?_⟩
      obtain ⟨h1, h2⟩ := ha
      rw [hB] at h1 h2
      exact ⟨by omega, by omega⟩
    · rw [hbe.sp, hB, hd]
      have := hent.spAligned
      have := L.frameSize_mod_semantic hL hf
      omega
  -- the machine side
  have hME : L.MachEntry κ M f L.F L.Img ra s w₀ :=
    ⟨hent.toCall, hres, hgfree, hF.symm, fun _ h => h, himg,
      hbe.w L.F fun r ⟨_, _, hvb, hi, _, hv⟩ =>
        ((ctlCheck_args (lowerRFunc_ok hc.alloc).2.2 hvb hi).2.2 _ hv).2⟩
  -- the whole-program run is a run of the program without functions
  have hIf : Clif.LInv (L.P.only f) cs := runInv_entry (by simp [Clif.Program.only]) hcs
  obtain ⟨m, hm⟩ := hlink hout
  rcases hout with ⟨vals, cm, rfl⟩ | ⟨c, rfl⟩
  · exact (L.thmG_semantic hL hκ M f hf L.F args cs w₀ m vals cm hWE hm).1 L.Img ra s hME
  · have ih : 0 < M → L.Thm κ (M - 1) := fun _ => L.thm_semantic hL hκ (M - 1)
    have hJ : L.ActInv f (spv w₀) cs := ⟨hIf, hcs.callers, hpl⟩
    have hm' : Clif.runLoop (L.envOf M f (spv w₀)) L.P.bare m cs = .trapped c := by
      rw [L.runLoop_envOf_semantic hL hf m cs hJ]; exact hm
    have h := backend_correct_worldX_semantic ((hL.subset f hf).retarget (Clif.Program.bare_func? L.P)) hc.toSemantic
      (X := L.X κ M f L.F) (syms := L.syms)
      (env := L.envOf M f (spv w₀)) (K := κ M f) (F := L.F) (c := spv w₀) (hL.covered f hf)
      (L.xCallsOk_semantic hL hκ ih hf hL.imgF hWE.room hWE.dead hWE.align)
      (L.xCallsIndOk_semantic hL hκ ih hf hL.imgF hWE.room hWE.dead hWE.align)
      (fun n b hn => hL.symOk n b hn) rfl hWE.clif hWE.rel hWE.args
      (L.trapsExplicit_envOf_semantic hL hf hJ htr) m
    obtain ⟨n, -, hgood, hstuck⟩ := h.2 c hm' (L.hooks M) L.Img (L.A f).base ra s
      ⟨hME.abi, hME.stack, hME.gfree, hME.hF,
        L.calleeOk_semantic hL hκ ih hf hME,
        fun _ => L.calleeTryOk_semantic hL hκ ih hf hME,
        fun ht => L.tlsOk_hooks (hL.baseTls f hf (hasTls_of_vcode_semantic hc ht) L.F (κ M f)), hME.body⟩
    refine L.runGood_of_trace_semantic hL (fun _ => L.thmG_semantic hL hκ (M - 1)) hf hME hgood fun k _ hk => ?_
    refine Nat.lt_of_not_le fun hle => hstuck (k - n) ?_
    rw [show n + (k - n) + 1 = k + 1 by omega]
    exact hk

/-- **`backend_correct_program_budgetX_semantic`**: `backend_correct_program_budget_semantic` with the run's per-state facts for a returning or
trapping outcome. -/
theorem backend_correct_program_budgetX_semantic (L : LinkSys) (hL : L.OkSemanticNI)
    {κ : Nat → Clif.Function → Nat} (hκ : L.Budget κ) {f : Clif.Function}
    (hf : f ∈ L.P.funcs) (M : Nat) {ra : BitVec 64} {s w₀ : Arm.ArmState} {args : List Clif.Val}
    {cs : Clif.State}
    (hent : AbiEntry (L.A f).fb (L.A f).base ra s) (hres : StackAvail (κ M f) (L.A f).af s)
    (hF : L.F = frameWG (κ M f) (RAFrame.compute (L.A f).vcp (L.A f).rf).intBase
      (RAFrame.compute (L.A f).vcp (L.A f).rf).size (L.A f).af L.Img s)
    (hgfree : ∀ a, L.Img a → ¬ StackBelow (frameDrop (L.A f).af + κ M f) (spv s) a)
    (himg : ∀ a, L.Img a → s.mem a = L.imgMem a)
    (hbe : BodyEntry (L.A f).af s w₀) (hargs : ArgsIn f.sig args s) (hcs : ClifEntry f args cs)
    (hsav : StackArgsAvoid L.Img f.sig args s)
    (hrel : Rel.holds ⟨L.F, L.syms, (L.A f).af.slotBase,
      (RAFrame.compute (L.A f).vcp (L.A f).rf).intBase⟩ f cs.frame.slots cs.mem w₀)
    (hpl : L.NeedSlots → L.PlaceAt cs.mem (spv w₀))
    (htr : TrapsExplicit (Clif.linkEnvN L.P L.base M) L.P.bare cs) :
    ArmRefines (L.A f).fb (L.A f).base ra (L.mach M f) s (Clif.runLoop L.base L.P (M + 1) cs) ∧
      ((∃ vals cm, Clif.runLoop L.base L.P (M + 1) cs = .returned vals cm) ∨
        (∃ c, Clif.runLoop L.base L.P (M + 1) cs = .trapped c) → L.RunGoodL M f s) := by
  haveI := L.crunOk_std_semantic hL
  have hIf : Clif.LInv (L.P.only f) cs := runInv_entry (by simp [Clif.Program.only]) hcs
  have h := backend_correct_program_coreX_semantic L.std (hL.withCrun _) hκ hf M hent hres hF hgfree himg
    hbe hargs hcs hsav hrel hpl htr (o := Clif.runLoop L.base L.P (M + 1) cs) fun ho =>
    Clif.runLoop_linkN (base := L.base) (syms := L.syms) M hL.names hf hL.free
      (hL.indScope f hf) (E := L.std.envR M f)
      rfl rfl (fun _ hn => L.std.envR_of (.inl hn))
      (L.std.envR_link hL.names) (M + 1) cs (Nat.le_refl _) (runInv_entry hf hcs) hIf
      (fun _ => hrel.1.symbols)
      (by rcases ho with ⟨_, _, ho⟩ | ⟨_, ho⟩ <;> rw [ho] <;> exact fun _ h => nomatch h)
      (by rcases ho with ⟨_, _, ho⟩ | ⟨_, ho⟩ <;> rw [ho] <;> exact fun h => nomatch h)
  rw [L.mach_std] at h
  exact ⟨h.1, fun hout => LinkSys.runGoodL_withCrun_semantic (h.2 hout)⟩

/-- **`backend_correct_program_peak_semantic` with the run's per-state facts** for a returning or
trapping outcome (L1d): the linked machine of the run's peak call depth `d` (`Clif.DepthLe`),
the program callees with fuel `F` and bounded depth (`Clif.linkEnvD`). -/
theorem backend_correct_program_peakX_semantic (L : LinkSys) (hL : L.OkSemanticNI)
    {κ : Nat → Clif.Function → Nat} (hκ : L.Budget κ) {f : Clif.Function}
    (hf : f ∈ L.P.funcs) (F d : Nat) {ra : BitVec 64} {s w₀ : Arm.ArmState}
    {args : List Clif.Val} {cs : Clif.State}
    (hent : AbiEntry (L.A f).fb (L.A f).base ra s) (hres : StackAvail (κ d f) (L.A f).af s)
    (hF : L.F = frameWG (κ d f) (RAFrame.compute (L.A f).vcp (L.A f).rf).intBase
      (RAFrame.compute (L.A f).vcp (L.A f).rf).size (L.A f).af L.Img s)
    (hgfree : ∀ a, L.Img a → ¬ StackBelow (frameDrop (L.A f).af + κ d f) (spv s) a)
    (himg : ∀ a, L.Img a → s.mem a = L.imgMem a)
    (hbe : BodyEntry (L.A f).af s w₀) (hargs : ArgsIn f.sig args s) (hcs : ClifEntry f args cs)
    (hsav : StackArgsAvoid L.Img f.sig args s)
    (hrel : Rel.holds ⟨L.F, L.syms, (L.A f).af.slotBase,
      (RAFrame.compute (L.A f).vcp (L.A f).rf).intBase⟩ f cs.frame.slots cs.mem w₀)
    (hpl : L.NeedSlots → L.PlaceAt cs.mem (spv w₀))
    (hd : Clif.DepthLe L.base L.P d cs)
    (htr : TrapsExplicit (Clif.linkEnvD L.P L.base F d) L.P.bare cs) :
    ArmRefines (L.A f).fb (L.A f).base ra (L.mach d f) s (Clif.runLoop L.base L.P (F + 1) cs) ∧
      ((∃ vals cm, Clif.runLoop L.base L.P (F + 1) cs = .returned vals cm) ∨
        (∃ c, Clif.runLoop L.base L.P (F + 1) cs = .trapped c) → L.RunGoodL d f s) := by
  haveI := L.crunOk_peak_semantic hL F
  have hIf : Clif.LInv (L.P.only f) cs := runInv_entry (by simp [Clif.Program.only]) hcs
  have h := backend_correct_program_coreX_semantic (L.peak F) (hL.withCrun _) hκ hf d hent hres hF hgfree
    himg hbe hargs hcs hsav hrel hpl htr (o := Clif.runLoop L.base L.P (F + 1) cs) fun ho =>
    Clif.runLoop_linkD (base := L.base) (syms := L.syms) F d hL.names hf hL.free
      (hL.indScope f hf) (E := (L.peak F).envR d f)
      rfl rfl (fun _ hn => (L.peak F).envR_of (.inl hn))
      ((L.peak F).envR_link hL.names) (F + 1) cs (Nat.le_refl _) hd (runInv_entry hf hcs) hIf
      (fun _ => hrel.1.symbols)
      (by rcases ho with ⟨_, _, ho⟩ | ⟨_, ho⟩ <;> rw [ho] <;> exact fun _ h => nomatch h)
      (by rcases ho with ⟨_, _, ho⟩ | ⟨_, ho⟩ <;> rw [ho] <;> exact fun h => nomatch h)
  rw [L.mach_peak] at h
  exact ⟨h.1, fun hout => LinkSys.runGoodL_withCrun_semantic (h.2 hout)⟩

end E2E

/-! # The binary-level theorem (M9, docs/contracts/e2e.md, "Binary level (M9)")

`crate_correct` (`FV/E2E/LinkCheck.lean`) is `backend_correct_program` for every function of a
crate's linked program, with the per-run premises of an Arm entry state `s`, a body-entry world
`w₀` and a CLIF entry state `cs`. Here those premises are stated as a **boundary contract** on
the real machine state `r` in which code outside the program (std's `lang_start`, a fallback
function, a callback) enters a function `f` of the program:

* `OutsideCall I roB f N r args cm` — what the outside caller guarantees at the call: the AAPCS64
  entry (pc at `f`'s link address, return address outside the program's code, `sp` 16-aligned),
  `N` bytes of free stack below `sp` that hold no code, the arguments where AAPCS64 puts them,
  and the CLIF-visible memory `cm` related to `r` (its live bytes are `r`'s, none of them in the
  code or in the free stack except `f`'s own CLIF slot region, the symbol table the CLIF image's).
* `ClifRun I B f r args cs` — the choice of the reference CLIF run (not an obligation on the
  outside code): `cs` is an entry state of `f` on `args`, its stack slots where the compiled frame
  puts them, and (with slotted program callees) the slot-placement oracle at the body's `sp`.
  CLIF leaves slot addresses unspecified; this picks the run the compiled code realises.
* the model state `modelOf I f r`: `r` with the machine's program `f`'s compiled words and the
  memory at the program's code addresses the compiled image (`LinkSys.withImg`). The compiled
  image holds relocated instructions with zero relocation fields, which the model machine runs by
  their link-map semantics (`ArmStepX`); the binary checks (`FV/E2E/BinCheck.lean`) show the
  executable differs from it only there, holding the resolved encodings.

Every other premise of `backend_correct_program` is discharged here: `AbiEntry` (program, code
words, pc, error, return address, alignment, fits), the stack premises (`StackAvail`, the world
complement `F`, the code outside the stack, `hgfree`), `himg`, `BodyEntry` (the body-entry world
is `bodyOf af s`), `ArgsIn` and `StackArgsAvoid` (from `OutsideCall.args` on `r`), and
`Rel.holds`' memory part, `OutRel` (the outgoing area is free stack). `TrapsExplicit` (the CLIF
run traps only explicitly) stays a premise about the CLIF run; `BaseOk` (the contracts of the code
outside the program) stays as in `crate_correct`.

`binary_correct_depth` uses `crate_correct` (a stack of `frameDrop + D * M` bytes for runs of
depth `M`: the statement for recursive programs); `binary_correct` uses the stack bound of a
non-recursive program (`FV/E2E/SemanticStackBound.lean`) and the executable's checks.
-/

set_option autoImplicit false
namespace E2E.SemanticBinary

open Backend Backend.Proof E2E.LinkCheck

/-! ## The compiled program of an input -/

/-- The program of the input (`SemanticStackBound.ofInput`'s `P`). -/
abbrev prog (I : SemanticStackBound.CompilerInput) : Clif.Program := progOf I.results

/-- The compiled image of `f` (`SemanticStackBound.ofInput`'s `A f`). -/
abbrev art (I : SemanticStackBound.CompilerInput) (f : Clif.Function) : Art := artOf I.results f

/-- The program's code addresses (`SemanticStackBound.ofInput`'s `Img`). -/
abbrev img (I : SemanticStackBound.CompilerInput) : BitVec 64 → Prop := ImgT (tabOf I.results)

/-- The program's compiled code bytes (`SemanticStackBound.ofInput`'s `imgMem`). -/
abbrev imgMem (I : SemanticStackBound.CompilerInput) : Arm.Memory := memT (tabOf I.results)

/-- The linked system with no addresses outside the world (`F` only enters premises; `mach`,
`NeedSlots`, `PlaceAt`, `base`, `P` do not depend on it). -/
abbrev sys (I : SemanticStackBound.CompilerInput) (B : BaseEnv) : LinkSys := SemanticStackBound.ofInput I B fun _ => False

/-- The body's stack pointer of an activation of a function with frame `af` entered in `r`. -/
def spBody (af : AFunc) (r : Arm.ArmState) : BitVec 64 := spv r - BitVec.ofNat 64 (frameDrop af)

/-- `a` is in the CLIF stack-slot region of the frame of `af` entered in `r`
(`[sp_body + slotBase, sp_body + frameSize)`). -/
def SlotArea (af : AFunc) (r : Arm.ArmState) (a : BitVec 64) : Prop :=
  af.slotBase ≤ (a - spBody af r).toNat ∧ (a - spBody af r).toNat < af.frameSize

/-- The arguments `args` of a call with signature `sig` where AAPCS64 puts them in `r`: a
register parameter in its register, a stack parameter in the caller's outgoing area at
`sp + off` (inside the address space, outside the code `G`, holding its bits). -/
def ArgsOut (G : BitVec 64 → Prop) (sig : Clif.Signature) (args : List Clif.Val)
    (r : Arm.ArmState) : Prop :=
  ∀ loc v, (loc, v) ∈ (locsOf sig).zip args → match loc with
    | .reg x => VHolds v (regVal r x)
    | .stack off => (spv r).toNat + off + v.ty.bytes ≤ 2 ^ 64 ∧
        Avoids G v.ty.bytes (spv r + BitVec.ofNat 64 off) ∧
        (Arm.read_mem_bytes v.ty.bytes (spv r + BitVec.ofNat 64 off) r).setWidth v.ty.width = v.bits

/-- **The boundary contract**: what code outside the program guarantees when it calls the
function `f` of the program in the machine state `r`, with arguments `args`, its CLIF-visible
memory being `cm`, and `N` bytes of stack. `roB a = some b`: the executable holds the byte `b` of
the CLIF image's read-only data at `a` (`fun _ => none`: no data facts, every live CLIF byte is
required of the caller). -/
structure OutsideCall (I : SemanticStackBound.CompilerInput) (roB : BitVec 64 → Option (BitVec 8)) (f : Clif.Function)
    (N : Nat) (r : Arm.ArmState)
    (args : List Clif.Val) (cm : Clif.Mem) : Prop where
  /-- the pc is `f`'s address (its link-map address) -/
  pc : Arm.r .PC r = (art I f).base
  /-- no model error -/
  err : Arm.r .ERR r = .None
  /-- the return address (x30) is outside the program's code: the caller is outside code -/
  ra : ¬ img I (xreg 30 r)
  /-- AAPCS64: `sp` is 16-aligned -/
  spAligned : (spv r).toNat % 16 = 0
  /-- `N` bytes below `sp` without wrapping -/
  stack : N ≤ (spv r).toNat
  /-- none of them is code -/
  stackFree : ∀ a, img I a → ¬ StackBelow N (spv r) a
  /-- the arguments where AAPCS64 puts them (stack arguments outside the code) -/
  args : ArgsOut (img I) f.sig args r
  /-- the live CLIF bytes outside the executable's read-only CLIF data (`roB`) are the
  machine's -/
  bytes : ∀ a b, cm.valid a 1 = true → cm.bytes a = some b → roB (BitVec.ofNat 64 a) = none →
    Arm.read_mem (BitVec.ofNat 64 a) r = b
  /-- the live CLIF bytes at the read-only CLIF data are the CLIF image's (a CLIF-level fact: a
  store into read-only data is stuck) -/
  image : ∀ a b b', cm.valid a 1 = true → cm.bytes a = some b → roB (BitVec.ofNat 64 a) = some b' →
    b = b'
  /-- the live CLIF allocations fit the address space, hold no code, and lie in the free stack
  only in `f`'s CLIF slot region -/
  valid : ∀ a n, cm.valid a n = true → a + n ≤ 2 ^ 64 ∧ ∀ k < n,
    ¬ img I (BitVec.ofNat 64 (a + k)) ∧
    (StackBelow N (spv r) (BitVec.ofNat 64 (a + k)) → SlotArea (art I f).af r (BitVec.ofNat 64 (a + k)))
  /-- the CLIF symbol table is the CLIF image's -/
  symbols : cm.symbols = fun n => I.syms.lookup n

/-- **The reference CLIF run** of an outside call of `f` in `r` (a choice, not an obligation of
the outside code): an entry state of `f` on `args` whose stack slots are where the compiled frame
puts them, and whose slot-placement oracle (needed only with slotted program callees) is at the
body's `sp` with the program's compiled frames. -/
structure ClifRun (I : SemanticStackBound.CompilerInput) (B : BaseEnv) (f : Clif.Function) (r : Arm.ArmState)
    (args : List Clif.Val) (cs : Clif.State) : Prop where
  entry : ClifEntry f args cs
  slots : SlotRel f ((spBody (art I f).af r).toNat + (art I f).af.slotBase) cs.frame.slots
  place : (sys I B).NeedSlots → (sys I B).PlaceAt cs.mem (spBody (art I f).af r)

open Classical in
/-- **The model state** of the machine state `r` entering `f`: `r` with the machine's program
`f`'s compiled words and the compiled code bytes at the program's code addresses. -/
noncomputable def modelOf (I : SemanticStackBound.CompilerInput) (f : Clif.Function) (r : Arm.ArmState) : Arm.ArmState :=
  Arm.set_program (setMem r fun a => if img I a then imgMem I a else r.mem a)
    ((art I f).fb.program (art I f).base)

theorem r_modelOf (I : SemanticStackBound.CompilerInput) (f : Clif.Function) (r : Arm.ArmState) (fld : Arm.StateField) :
    Arm.r fld (modelOf I f r) = Arm.r fld r := by
  simp only [modelOf]
  rw [r_set_program, r_setMem]

theorem spv_modelOf (I : SemanticStackBound.CompilerInput) (f : Clif.Function) (r : Arm.ArmState) :
    spv (modelOf I f r) = spv r := r_modelOf I f r _

theorem regVal_modelOf (I : SemanticStackBound.CompilerInput) (f : Clif.Function) (r : Arm.ArmState) (x : Reg) :
    regVal (modelOf I f r) x = regVal r x := by
  cases x <;> simp only [regVal, r_modelOf]

open Classical in
theorem mem_modelOf (I : SemanticStackBound.CompilerInput) (f : Clif.Function) (r : Arm.ArmState) (a : BitVec 64) :
    (modelOf I f r).mem a = if img I a then imgMem I a else r.mem a := by
  simp only [modelOf, mem_set_program, mem_setMem]

theorem mem_modelOf_img {I : SemanticStackBound.CompilerInput} {f : Clif.Function} {r : Arm.ArmState} {a : BitVec 64}
    (h : img I a) : (modelOf I f r).mem a = imgMem I a := by
  rw [mem_modelOf]; simp [h]

theorem mem_modelOf_not {I : SemanticStackBound.CompilerInput} {f : Clif.Function} {r : Arm.ArmState} {a : BitVec 64}
    (h : ¬ img I a) : (modelOf I f r).mem a = r.mem a := by
  rw [mem_modelOf]; simp [h]

@[simp] theorem program_modelOf (I : SemanticStackBound.CompilerInput) (f : Clif.Function) (r : Arm.ArmState) :
    (modelOf I f r).program = (art I f).fb.program (art I f).base := by
  simp only [modelOf, program_set_program]

/-- The body-entry world `bodyOf af s` is a body entry of `s`. -/
theorem bodyEntry_bodyOf (af : AFunc) (s : Arm.ArmState) : BodyEntry af s (bodyOf af s) where
  sp := spv_bodyOf af s
  fp := x29_bodyOf af s
  args := fun i hi => r_bodyOf af s
    (fun e => by
      have := congrArg (fun f => match f with | Arm.StateField.GPR j => j.toNat | _ => 0) e
      simp at this; omega)
    (fun e => by
      have := congrArg (fun f => match f with | Arm.StateField.GPR j => j.toNat | _ => 0) e
      simp at this; omega)
  argsV := fun i _ => r_bodyOf af s (by simp) (by simp)
  other := fun _ _ h29 h31 => r_bodyOf af s h29 h31
  mem := mem_bodyOf af s
  program := program_bodyOf af s

/-- `BaseOk` does not depend on the addresses `F` outside the world. -/
theorem baseOk_F {I : SemanticStackBound.CompilerInput} {B : BaseEnv} {F F' : BitVec 64 → Prop}
    (h : BaseOk (SemanticStackBound.ofInput I B F)) : BaseOk (SemanticStackBound.ofInput I B F') :=
  ⟨h.baseNoAlloc, h.keepSyms, h.aliasSyms, h.baseOs, h.basePc, h.baseExt, h.baseX, h.baseXI,
    h.baseTls, h.baseTry, h.baseNI, h.baseTlsNI, h.baseKeepsPlace, h.baseKeepsAllocs⟩

/-- **The addresses outside the entry activation's world** with callees' budget `K`
(`backend_correct_program`'s `hF`): the frame-private addresses, the callees' dead stack and the
program's code. -/
def worldF (I : SemanticStackBound.CompilerInput) (f : Clif.Function) (K : Nat) (r : Arm.ArmState) : BitVec 64 → Prop :=
  frameWG K (RAFrame.compute (art I f).vcp (art I f).rf).intBase
    (RAFrame.compute (art I f).vcp (art I f).rf).size (art I f).af (img I) (modelOf I f r)

/-- The model state's code addresses are the program's. -/
theorem img_of_codeAddr {I : SemanticStackBound.CompilerInput} {B : BaseEnv} {F : BitVec 64 → Prop}
    (hL : (SemanticStackBound.ofInput I B F).OkSemanticNI) {f : Clif.Function} (hf : f ∈ (prog I).funcs)
    {r : Arm.ArmState} {a : BitVec 64} (h : CodeAddr (modelOf I f r) a) : img I a := by
  obtain ⟨p, hp, hpa⟩ := h
  rw [program_modelOf] at hp
  exact hL.imgAddr f hf a ⟨p, hp, hpa⟩

/-- The frame facts of a compiled function. -/
theorem frame_facts {I : SemanticStackBound.CompilerInput} {B : BaseEnv} {F : BitVec 64 → Prop}
    (hL : (SemanticStackBound.ofInput I B F).OkSemanticNI) {f : Clif.Function} (hf : f ∈ (prog I).funcs) :
    frameDrop (art I f).af = (art I f).af.frameSize + 16 ∧
    (art I f).af.slotBase = (RAFrame.compute (art I f).vcp (art I f).rf).size ∧
    (RAFrame.compute (art I f).vcp (art I f).rf).intBase ≤
      (RAFrame.compute (art I f).vcp (art I f).rf).size ∧
    (RAFrame.compute (art I f).vcp (art I f).rf).size ≤ (art I f).af.frameSize := by
  have hc := hL.compiled f hf
  have hfr : (art I f).af.frame = true := lowerRFunc_frame hc.alloc
  exact ⟨by simp [frameDrop, hfr], (lowerRFunc_ok hc.alloc).1.2.1, intBase_le_size _ _,
    size_le_frameSize hc.alloc⟩

/-- A byte of the free stack outside the slot region, or of the code, is outside the world; a
byte that is neither is not. -/
theorem not_worldF {I : SemanticStackBound.CompilerInput} {B : BaseEnv} {F : BitVec 64 → Prop}
    (hL : (SemanticStackBound.ofInput I B F).OkSemanticNI) {f : Clif.Function} (hf : f ∈ (prog I).funcs)
    {K : Nat} {r : Arm.ArmState} (hN : frameDrop (art I f).af + K ≤ (spv r).toNat)
    {x : BitVec 64} (hx : ¬ img I x)
    (hs : StackBelow (frameDrop (art I f).af + K) (spv r) x → SlotArea (art I f).af r x) :
    ¬ worldF I f K r x := by
  obtain ⟨hd, hsb, hib, hsz⟩ := frame_facts hL hf
  have hsp := (spv r).isLt
  have hxl := x.isLt
  have hoff := off_toNat x (spv r) (frameDrop (art I f).af) (by omega)
  simp only [worldF, frameWG, frameW, frameF, spv_modelOf]
  rintro (((⟨h1, h2⟩ | ⟨h1, h2⟩ | hc) | ⟨h1, h2⟩) | hi)
  · obtain ⟨hs1, -⟩ := hs ⟨(hoff.1.1 (by omega)).1, by have := (hoff.1.1 (by omega)).2; omega⟩
    simp only [spBody] at hs1
    omega
  · have := hoff.1.1 (by omega)
    obtain ⟨-, hs2⟩ := hs ⟨this.1, by omega⟩
    simp only [spBody] at hs2
    omega
  · exact hx (img_of_codeAddr hL hf hc)
  · rw [hoff.2.2] at h1 h2
    obtain ⟨-, hs2⟩ := hs ⟨by omega, by omega⟩
    simp only [spBody, BitVec.toNat_sub, hoff.2.2] at hs2
    rw [Nat.mod_eq_of_lt (by omega)] at hs2
    omega
  · exact hx hi

/-- A byte of the outgoing-argument area `[sp_body, sp_body + intBase)` that is not code is in
the world. -/
theorem not_worldF_out {I : SemanticStackBound.CompilerInput} {B : BaseEnv} {F : BitVec 64 → Prop}
    (hL : (SemanticStackBound.ofInput I B F).OkSemanticNI) {f : Clif.Function} (hf : f ∈ (prog I).funcs)
    {K : Nat} {r : Arm.ArmState} (hN : frameDrop (art I f).af + K ≤ (spv r).toNat)
    {j : Nat} (hj : j < (RAFrame.compute (art I f).vcp (art I f).rf).intBase)
    (hx : ¬ img I (spBody (art I f).af r + BitVec.ofNat 64 j)) :
    ¬ worldF I f K r (spBody (art I f).af r + BitVec.ofNat 64 j) := by
  obtain ⟨hd, hsb, hib, hsz⟩ := frame_facts hL hf
  have hsp := (spv r).isLt
  have hspbN : (spBody (art I f).af r).toNat = (spv r).toNat - frameDrop (art I f).af :=
    (off_toNat 0 (spv r) _ (by omega)).2.2
  have hxN : (spBody (art I f).af r + BitVec.ofNat 64 j).toNat = (spBody (art I f).af r).toNat + j := by
    simp only [BitVec.toNat_add, BitVec.toNat_ofNat]
    rw [Nat.mod_eq_of_lt (by omega : j < 2 ^ 64), Nat.mod_eq_of_lt (by omega)]
  have ho : (spBody (art I f).af r + BitVec.ofNat 64 j - (spv (modelOf I f r) -
      BitVec.ofNat 64 (frameDrop (art I f).af))).toNat = j := by
    rw [spv_modelOf, show spv r - BitVec.ofNat 64 (frameDrop (art I f).af) = spBody (art I f).af r from rfl,
      BitVec.add_comm, BitVec.add_sub_cancel]
    simp; omega
  simp only [worldF, frameWG, frameW, frameF]
  rw [ho]
  rintro (((⟨h1, h2⟩ | ⟨h1, h2⟩ | hc) | ⟨h1, h2⟩) | hi)
  · omega
  · omega
  · exact hx (img_of_codeAddr hL hf hc)
  · rw [spv_modelOf, show spv r - BitVec.ofNat 64 (frameDrop (art I f).af) = spBody (art I f).af r
      from rfl, hxN] at h1
    omega
  · exact hx hi

/-- **The per-run premises of `backend_correct_program` from the boundary contract**, for the
model state `s = modelOf I f r`, the body-entry world `bodyOf af s`, the callees' budget `K` and
the addresses outside the world `worldF I f K r`. -/
theorem premises {I : SemanticStackBound.CompilerInput} {B : BaseEnv} {f : Clif.Function} {K : Nat} {r : Arm.ArmState}
    {args : List Clif.Val} {cs : Clif.State}
    (hL : (SemanticStackBound.ofInput I B (worldF I f K r)).OkSemanticNI) (hf : f ∈ (prog I).funcs)
    {roB : BitVec 64 → Option (BitVec 8)} (hro : ∀ a b, roB a = some b → r.mem a = b)
    (ho : OutsideCall I roB f (frameDrop (art I f).af + K) r args cs.mem)
    (hr : ClifRun I B f r args cs) :
    AbiEntry (art I f).fb (art I f).base (xreg 30 r) (modelOf I f r) ∧
    StackAvail K (art I f).af (modelOf I f r) ∧
    (∀ a, img I a → ¬ StackBelow (frameDrop (art I f).af + K) (spv (modelOf I f r)) a) ∧
    (∀ a, img I a → (modelOf I f r).mem a = imgMem I a) ∧
    BodyEntry (art I f).af (modelOf I f r) (bodyOf (art I f).af (modelOf I f r)) ∧
    ArgsIn f.sig args (modelOf I f r) ∧ StackArgsAvoid (img I) f.sig args (modelOf I f r) ∧
    Rel.holds ⟨worldF I f K r, fun n => I.syms.lookup n, (art I f).af.slotBase,
      (RAFrame.compute (art I f).vcp (art I f).rf).intBase⟩ f cs.frame.slots cs.mem
      (bodyOf (art I f).af (modelOf I f r)) ∧
    ((sys I B).NeedSlots → (sys I B).PlaceAt cs.mem (spv (bodyOf (art I f).af (modelOf I f r)))) := by
  obtain ⟨hd, hsb, hib, hsz⟩ := frame_facts hL hf
  have hsp := (spv r).isLt
  have hN := ho.stack
  have himg : ∀ a, img I a → (modelOf I f r).mem a = imgMem I a := fun a h => mem_modelOf_img h
  have hspb : spv (bodyOf (art I f).af (modelOf I f r)) = spBody (art I f).af r := by
    rw [spv_bodyOf, spv_modelOf]; rfl
  have hspbN : (spBody (art I f).af r).toNat = (spv r).toNat - frameDrop (art I f).af :=
    (off_toNat 0 (spv r) _ (by omega)).2.2
  -- a byte at `sp_body + j` with `j` below the frame drop is in the free stack
  have hbelow : ∀ j < frameDrop (art I f).af,
      StackBelow (frameDrop (art I f).af + K) (spv r) (spBody (art I f).af r + BitVec.ofNat 64 j) ∧
      (spBody (art I f).af r + BitVec.ofNat 64 j - spBody (art I f).af r).toNat = j := by
    intro j hj
    refine ⟨?_, by rw [BitVec.add_comm, BitVec.add_sub_cancel]; simp; omega⟩
    simp only [StackBelow, BitVec.toNat_add, BitVec.toNat_ofNat, hspbN]
    rw [Nat.mod_eq_of_lt (by omega : j < 2 ^ 64), Nat.mod_eq_of_lt (by omega)]
    omega
  refine ⟨⟨by simp, hL.imgCode f hf _ himg, by rw [r_modelOf]; exact ho.pc,
    by rw [r_modelOf]; exact ho.err, by simp only [xreg]; rw [r_modelOf], fun k hk e => ?_,
    by rw [spv_modelOf]; exact ho.spAligned, hL.fits f hf⟩, ?_, ?_, himg,
    bodyEntry_bodyOf _ _, ?_, ?_, ⟨⟨fun a b hv hb => ?_, fun a n hv => ?_, ho.symbols⟩, ?_, ?_⟩, ?_⟩
  · -- the return address is outside `f`'s code
    obtain ⟨w, hw⟩ : ∃ w, (art I f).fb.words[k]? = some w := ⟨_, Array.getElem?_eq_getElem hk⟩
    apply ho.ra
    rw [e]
    have := codeAddr_word (s := modelOf I f r) (base := (art I f).base) (by simp) hw (i := 0) (by omega)
    rw [show BitVec.ofNat 64 0 = 0#64 from rfl, BitVec.add_zero] at this
    exact img_of_codeAddr hL hf this
  · -- the stack
    refine stackRoom_of (by rw [spv_modelOf, ← hd]; exact hN) fun a hc hb => ?_
    rw [spv_modelOf, ← hd] at hb
    exact ho.stackFree a (img_of_codeAddr hL hf hc) hb
  · intro a ha
    rw [spv_modelOf]
    exact ho.stackFree a ha
  · -- the arguments
    intro loc v hm
    have h := ho.args loc v hm
    cases loc with
    | reg x => simp only at h ⊢; rw [regVal_modelOf]; exact h
    | stack off =>
      obtain ⟨hfit, hav, hby⟩ := h
      have hbytes : ∀ k < v.ty.bytes, (modelOf I f r).mem (spv r + BitVec.ofNat 64 off + BitVec.ofNat 64 k) =
          r.mem (spv r + BitVec.ofNat 64 off + BitVec.ofNat 64 k) := fun k hk => mem_modelOf_not (hav k hk)
      refine ⟨by rw [spv_modelOf]; exact hfit, fun k hk hc => hav k hk ?_, ?_⟩
      · have := img_of_codeAddr hL hf hc
        rwa [spv_modelOf, BitVec.ofNat_add, ← BitVec.add_assoc] at this
      · rw [spv_modelOf, read_mem_bytes_congr _ _ hbytes]; exact hby
  · intro off v hm
    obtain ⟨-, hav, -⟩ := ho.args (.stack off) v hm
    rw [spv_modelOf]; exact hav
  · -- the live CLIF bytes
    have hni := ((ho.valid a 1 hv).2 0 (by omega)).1
    simp only [Nat.add_zero] at hni
    simp only [Arm.read_mem, mem_bodyOf]
    rw [show Arm.read_store (BitVec.ofNat 64 a) (modelOf I f r).mem = (modelOf I f r).mem (BitVec.ofNat 64 a)
      from rfl, mem_modelOf_not hni]
    cases hroa : roB (BitVec.ofNat 64 a) with
    | none => exact ho.bytes a b hv hb hroa
    | some b' => rw [hro _ _ hroa, ho.image a b b' hv hb hroa]
  · obtain ⟨hfit, hk⟩ := ho.valid a n hv
    exact ⟨hfit, fun k hkn => not_worldF hL hf hN (hk k hkn).1 (hk k hkn).2⟩
  · -- the slots
    rw [Rel.slotReg, hspb]; exact hr.slots
  · -- the outgoing area: free stack below the slot region
    refine ⟨show (RAFrame.compute (art I f).vcp (art I f).rf).intBase ≤ 2 ^ 64 by omega,
      fun j hj => ?_, fun a n hv k hk j hj e => ?_⟩
    · change j < (RAFrame.compute (art I f).vcp (art I f).rf).intBase at hj
      rw [hspb]
      obtain ⟨hb, -⟩ := hbelow j (by omega)
      exact not_worldF_out hL hf hN hj (fun hi => ho.stackFree _ hi hb)
    · change j < (RAFrame.compute (art I f).vcp (art I f).rf).intBase at hj
      rw [hspb] at e
      obtain ⟨hb, ho'⟩ := hbelow j (by omega)
      have := ((ho.valid a n hv).2 k hk).2 (by rw [e]; exact hb)
      rw [e] at this
      unfold SlotArea at this
      omega
  · intro hN'; rw [hspb]; exact hr.place hN'

/-- The linked machine does not depend on the addresses `F` outside the world. -/
theorem hooks_F (I : SemanticStackBound.CompilerInput) (B : BaseEnv) (F F' : BitVec 64 → Prop) :
    ∀ M, (SemanticStackBound.ofInput I B F).hooks M = (SemanticStackBound.ofInput I B F').hooks M
  | 0 => rfl
  | M + 1 => by
    simp only [LinkSys.hooks]
    rw [hooks_F I B F F' M]
    rfl

theorem mach_F (I : SemanticStackBound.CompilerInput) (B : BaseEnv) (F F' : BitVec 64 → Prop) (M : Nat)
    (f : Clif.Function) : (SemanticStackBound.ofInput I B F).mach M f = (SemanticStackBound.ofInput I B F').mach M f := by
  simp only [LinkSys.mach]
  rw [hooks_F I B F F' M]
  rfl

/-! ## The binary-level theorems -/

/-- **The binary-level theorem at depth `M`** (any program, recursive ones included: the stack
premise is `frameDrop + D * M` bytes, `backend_correct_program`'s budget): for a crate input that
passes the checker, a function `f` of the program called by outside code that meets the boundary
contract `OutsideCall` in the machine state `r`, the linked machine of depth `M` from the model
state of `r` refines the whole-program CLIF run of at most `M + 1` steps from the reference entry
state `cs` (`ClifRun`), returning to the caller's return address (x30 of `r`). The premises left:
the base environment's contracts (`BaseOk`) and the CLIF run's explicit traps (`TrapsExplicit`). -/
theorem binary_correct_depth {I : SemanticStackBound.CompilerInput} (hI : SemanticStackBound.okB I = true) (B : BaseEnv)
    (hB : BaseOk (sys I B)) {n : String} {f : Clif.Function} (hf : (prog I).func? n = some f)
    (M : Nat) {r : Arm.ArmState} {args : List Clif.Val} {cs : Clif.State}
    (ho : OutsideCall I (fun _ => none) f (frameDrop (art I f).af + I.D * M) r args cs.mem)
    (hr : ClifRun I B f r args cs)
    (htr : TrapsExplicit (Clif.linkEnvN (prog I) B.env M) (prog I).bare cs) :
    ArmRefines (art I f).fb (art I f).base (xreg 30 r) ((sys I B).mach M f) (modelOf I f r)
      (Clif.runLoop B.env (prog I) (M + 1) cs) := by
  have hB' : BaseOk (SemanticStackBound.ofInput I B (worldF I f (I.D * M) r)) := baseOk_F hB
  have himgF : ∀ a, (SemanticStackBound.ofInput I B (worldF I f (I.D * M) r)).Img a →
      worldF I f (I.D * M) r a := fun _ h => .inr h
  have hL := SemanticStackBound.okB_sound hI hB' himgF
  obtain ⟨hent, hres, hgfree, himg, hbe, hargs, hsav, hrel, hpl⟩ :=
    premises hL (Clif.Program.func?_some hf).1 (fun _ _ h => by cases h) ho hr
  rw [mach_F I B (fun _ => False) (worldF I f (I.D * M) r)]
  exact backend_correct_program_semantic _ hL (Clif.Program.func?_some hf).1 M hent hres rfl hgfree himg hbe hargs hr.entry hsav hrel hpl htr

/-- A contract with more stack gives one with less. -/
theorem OutsideCall.mono {I : SemanticStackBound.CompilerInput} {roB : BitVec 64 → Option (BitVec 8)} {f : Clif.Function}
    {N N' : Nat} {r : Arm.ArmState} {args : List Clif.Val} {cm : Clif.Mem}
    (h : OutsideCall I roB f N' r args cm) (hN : N ≤ N') : OutsideCall I roB f N r args cm where
  pc := h.pc
  err := h.err
  ra := h.ra
  spAligned := h.spAligned
  stack := Nat.le_trans hN h.stack
  stackFree := fun a ha hb => h.stackFree a ha ⟨hb.1, by have := hb.2; omega⟩
  args := h.args
  bytes := h.bytes
  image := h.image
  valid := fun a n hv => ⟨(h.valid a n hv).1, fun k hk => ⟨((h.valid a n hv).2 k hk).1,
    fun hb => ((h.valid a n hv).2 k hk).2 ⟨hb.1, by have := hb.2; omega⟩⟩⟩
  symbols := h.symbols

/-- A returning whole-program CLIF run of `f` satisfies `TrapsExplicit` (as in
`backend_correct_program_returned`): the premise is needed only for trapping runs. -/
theorem trapsExplicit_of_run {L : LinkSys} (hL : L.OkSemanticNI) {f : Clif.Function} (hf : f ∈ L.P.funcs)
    {M : Nat} {args : List Clif.Val} {cs : Clif.State} {vals : List Clif.Val} {cm : Clif.Mem}
    (hcs : ClifEntry f args cs) (hsym : cs.mem.symbols = L.syms)
    (hrun : Clif.runLoop L.base L.P (M + 1) cs = .returned vals cm) :
    TrapsExplicit (Clif.linkEnvN L.P L.base M) L.P.bare cs := by
  have hIf : Clif.LInv (L.P.only f) cs := runInv_entry (by simp [Clif.Program.only]) hcs
  obtain ⟨m, hm⟩ := Clif.runLoop_linkN (base := L.base) (syms := L.syms) M hL.names hf hL.free
    (hL.indScope f hf)
    (E := Clif.linkEnvN L.P L.base M) rfl rfl (fun _ _ => rfl) (fun _ _ _ => rfl)
    (M + 1) cs (Nat.le_refl _) (runInv_entry hf hcs) hIf
    (fun _ => hsym) (by rw [hrun]; exact fun _ h => nomatch h)
    (by rw [hrun]; exact fun h => nomatch h)
  rw [hrun] at hm
  exact trapsExplicit_of_returned hm

/-- `trapsExplicit_of_run` for the environment of the run's peak call depth: a returning
whole-program CLIF run of `f` of at most `F + 1` steps and call depth at most `d`
(`Clif.DepthLe`) satisfies `TrapsExplicit` under `Clif.linkEnvD` (`Clif.runLoop_linkD`). -/
theorem trapsExplicit_of_runD {L : LinkSys} (hL : L.OkSemanticNI) {f : Clif.Function} (hf : f ∈ L.P.funcs)
    {F d : Nat} {args : List Clif.Val} {cs : Clif.State} {vals : List Clif.Val} {cm : Clif.Mem}
    (hcs : ClifEntry f args cs) (hsym : cs.mem.symbols = L.syms)
    (hd : Clif.DepthLe L.base L.P d cs)
    (hrun : Clif.runLoop L.base L.P (F + 1) cs = .returned vals cm) :
    TrapsExplicit (Clif.linkEnvD L.P L.base F d) L.P.bare cs := by
  have hIf : Clif.LInv (L.P.only f) cs := runInv_entry (by simp [Clif.Program.only]) hcs
  obtain ⟨m, hm⟩ := Clif.runLoop_linkD (base := L.base) (syms := L.syms) F d hL.names hf hL.free
    (hL.indScope f hf)
    (E := Clif.linkEnvD L.P L.base F d) rfl rfl (fun _ _ => rfl) (fun _ _ _ => rfl)
    (F + 1) cs (Nat.le_refl _) hd (runInv_entry hf hcs) hIf
    (fun _ => hsym) (by rw [hrun]; exact fun _ h => nomatch h)
    (by rw [hrun]; exact fun h => nomatch h)
  rw [hrun] at hm
  exact trapsExplicit_of_returned hm

/-! ## The binary facts -/

/-- **The executable's loaded segments** as the binary checks read them: the byte at each loaded
address (`mem`), and the addresses nothing writes after loading (`kept`: the read-only segments;
the relocation-read-only data, `PT_GNU_RELRO`). -/
structure Image where
  mem : BitVec 64 → Option (BitVec 8)
  kept : BitVec 64 → Prop

/-- **The loader premise**: the machine state `r` holds the executable's kept bytes (the OS maps
the segments at their link addresses; read-only segments are never written, and no code writes
the relocation-read-only data). -/
def Image.Intact (X : Image) (r : Arm.ArmState) : Prop :=
  ∀ a b, X.kept a → X.mem a = some b → r.mem a = b

/-- **The binary facts** of an executable `X` for a crate input `I` (what the binary checks
establish, `binary_correct_of_checks`): the input passes the crate checker (`SemanticStackBound.okB`); the program's
code bytes are kept bytes of the executable, equal to the compiled image except at the bytes `R`
of relocated instructions (which hold the resolved encodings, `FV/E2E/BinCheck.lean`); the CLIF
image's read-only data `roB` are kept bytes of the executable. -/
structure BinFacts (I : SemanticStackBound.CompilerInput) (X : Image) (R : BitVec 64 → Prop)
    (roB : BitVec 64 → Option (BitVec 8)) : Prop where
  ok : SemanticStackBound.okB I = true
  code : ∀ a, img I a → X.kept a ∧ (X.mem a = some (imgMem I a) ∨ R a)
  data : ∀ a b, roB a = some b → X.kept a ∧ X.mem a = some b

/-- **The binary-level theorem** (`docs/contracts/e2e.md`, "Binary level (M9)"): for an
executable with the binary facts of a crate input (`BinFacts`), whose loaded kept bytes the
machine state `r` holds (`Image.Intact`), a function `f` of the program whose calls reach no call
cycle (`goodN`, the stack check of `FV/E2E/SemanticStackBound.lean`) called by outside code that meets
the boundary contract (`OutsideCall`, with `f`'s stack bound `stackFn I f`), the linked machine
(at every depth `M`) from the model state of `r` refines the whole-program CLIF run of at most
`M + 1` steps from the reference entry state (`ClifRun`), returning to the caller's return
address; and the model state differs from `r` only at the relocated instruction bytes `R`. The
premises left: the base environment's contracts (`BaseOk`) and the CLIF run's explicit traps
(`TrapsExplicit`). -/
theorem binary_correct {I : SemanticStackBound.CompilerInput} {X : Image} {R : BitVec 64 → Prop}
    {roB : BitVec 64 → Option (BitVec 8)} (hbin : BinFacts I X R roB) (B : BaseEnv)
    (hB : BaseOk (sys I B)) {n : String} (hn : SemanticStackBound.goodN I n = true) {f : Clif.Function}
    (hf : (prog I).func? n = some f) (M : Nat) {r : Arm.ArmState}
    {args : List Clif.Val} {cs : Clif.State} (hX : X.Intact r)
    (ho : OutsideCall I roB f (SemanticStackBound.stackFn I f) r args cs.mem)
    (hr : ClifRun I B f r args cs)
    (htr : TrapsExplicit (Clif.linkEnvN (prog I) B.env M) (prog I).bare cs) :
    ArmRefines (art I f).fb (art I f).base (xreg 30 r) ((sys I B).mach M f) (modelOf I f r)
      (Clif.runLoop B.env (prog I) (M + 1) cs) ∧
    ∀ a, (modelOf I f r).mem a ≠ r.mem a → R a := by
  refine ⟨?_, fun a hne => ?_⟩
  · have hB' : BaseOk (SemanticStackBound.ofInput I B (worldF I f (SemanticStackBound.bud I f) r)) := baseOk_F hB
    have himgF : ∀ a, (SemanticStackBound.ofInput I B (worldF I f (SemanticStackBound.bud I f) r)).Img a →
        worldF I f (SemanticStackBound.bud I f) r a := fun _ h => .inr h
    have hL := SemanticStackBound.okB_sound hbin.ok hB' himgF
    have hro : ∀ a b, roB a = some b → r.mem a = b := fun a b h =>
      hX a b (hbin.data a b h).1 (hbin.data a b h).2
    obtain ⟨hent, -, hgfree, himg, hbe, hargs, hsav, hrel, hpl⟩ :=
      premises hL (Clif.Program.func?_some hf).1 hro ho hr
    rw [mach_F I B (fun _ => False) (worldF I f (SemanticStackBound.bud I f) r)]
    exact SemanticStackBound.crate_correct_stackN hbin.ok hn B _ hB' himgF f hf M _ _ _ args cs hent
      (by rw [spv_modelOf]; exact ho.stack) hgfree rfl himg hbe hargs hr.entry hsav hrel hpl htr
  · by_cases hi : img I a
    · rw [mem_modelOf_img hi] at hne
      rcases (hbin.code a hi).2 with h | h
      · exact absurd (hX a _ (hbin.code a hi).1 h).symm hne
      · exact h
    · exact absurd (mem_modelOf_not hi) hne

/-- **`binary_correct` for a non-recursive program** (`stackB I = some S`): every function, with
`S` bytes of stack. -/
theorem binary_correct_bound {I : SemanticStackBound.CompilerInput} {X : Image} {R : BitVec 64 → Prop}
    {roB : BitVec 64 → Option (BitVec 8)} (hbin : BinFacts I X R roB) {S : Nat}
    (hS : SemanticStackBound.stackB I = some S) (B : BaseEnv) (hB : BaseOk (sys I B)) {n : String}
    {f : Clif.Function} (hf : (prog I).func? n = some f) (M : Nat) {r : Arm.ArmState}
    {args : List Clif.Val} {cs : Clif.State} (hX : X.Intact r)
    (ho : OutsideCall I roB f S r args cs.mem) (hr : ClifRun I B f r args cs)
    (htr : TrapsExplicit (Clif.linkEnvN (prog I) B.env M) (prog I).bare cs) :
    ArmRefines (art I f).fb (art I f).base (xreg 30 r) ((sys I B).mach M f) (modelOf I f r)
      (Clif.runLoop B.env (prog I) (M + 1) cs) ∧
    ∀ a, (modelOf I f r).mem a ≠ r.mem a → R a := by
  have hn : SemanticStackBound.goodN I n = true := by
    unfold SemanticStackBound.goodN; rw [show (progOf I.results).func? n = some f from hf]
    exact (SemanticStackBound.stackB_some hS).1 f (Clif.Program.func?_some hf).1
  exact binary_correct hbin B hB hn hf M hX
    (ho.mono (SemanticStackBound.stackFn_le hS (Clif.Program.func?_some hf).1)) hr htr

/-! ## The binary checks -/

/-- **The loaded image of an ELF file** (`FV/E2E/Elf.lean`): its bytes, and the addresses nothing
writes after loading (the read-only segments; the relocation-read-only data). -/
def imageOf (file : ByteArray) : Image := ⟨Elf.loadMem file, fun a => Elf.ro file a ∨ Elf.relro file a⟩

/-- **The binary facts from the checks**: an input that passes the crate checker and an
executable file that passes the binary checks (`BinCheck.BinOk`: its code is the compiled code
with resolved relocations, its CLIF data objects and symbols are the input's). -/
theorem binFacts_of_checks {I : SemanticStackBound.CompilerInput} {D : List Clif.DataObject} {file : ByteArray}
    (hI : SemanticStackBound.okB I = true) (hB : BinCheck.BinOkWithResults I I.results D file) :
    BinFacts I (imageOf file) (BinCheck.RelocAtWithResults I I.results) (BinCheck.roByte I D) where
  ok := hI
  code := fun _ ha =>
    have himg : imgB (tabOf I.results) = true :=
      okRSemanticNI_global I.stage hI ("imgCode: the image reads back",imgB (tabOf I.results))
        (by simp [globalChks])
    have h := BinCheck.img_bytesWithResults hB himg ha
    ⟨.inl h.1, h.2⟩
  data := fun _ _ h =>
    have h' := BinCheck.roByte_sound hB.data h
    ⟨h'.2, h'.1⟩

/-- **The binary-level theorem for an executable file** that passes the checks (`SemanticStackBound.okB` on the
crate input `I`, `BinOk` on the file with the CLIF data objects `D`): `binary_correct` with the
executable's loaded image (`imageOf file`), its relocated instruction bytes `RelocAt I` and its
read-only CLIF data `roByte I D`. -/
theorem binary_correct_of_checks {I : SemanticStackBound.CompilerInput} {D : List Clif.DataObject} {file : ByteArray}
    (hI : SemanticStackBound.okB I = true) (hbin : BinCheck.BinOkWithResults I I.results D file) (B : BaseEnv) (hB : BaseOk (sys I B))
    {n : String} (hn : SemanticStackBound.goodN I n = true) {f : Clif.Function}
    (hf : (prog I).func? n = some f) (M : Nat) {r : Arm.ArmState} {args : List Clif.Val}
    {cs : Clif.State} (hX : (imageOf file).Intact r)
    (ho : OutsideCall I (BinCheck.roByte I D) f (SemanticStackBound.stackFn I f) r args cs.mem)
    (hr : ClifRun I B f r args cs)
    (htr : TrapsExplicit (Clif.linkEnvN (prog I) B.env M) (prog I).bare cs) :
    ArmRefines (art I f).fb (art I f).base (xreg 30 r) ((sys I B).mach M f) (modelOf I f r)
      (Clif.runLoop B.env (prog I) (M + 1) cs) ∧
    ∀ a, (modelOf I f r).mem a ≠ r.mem a → BinCheck.RelocAtWithResults I I.results a :=
  binary_correct (binFacts_of_checks hI hbin) B hB hn hf M hX ho hr htr

/-- **`binary_correct_of_checks` from the input condition**: the stack premise `goodN` replaced by
what it decides (`SemanticStackBound.goodN_iff`): no call cycle of the program's call graph
(`SemanticStackBound.Calls`) is reachable from `f`. Recursive functions (a cycle reachable) keep the
depth-indexed theorem. -/
theorem binary_correct_of_checks_acyclic {I : SemanticStackBound.CompilerInput} {D : List Clif.DataObject}
    {file : ByteArray} (hI : SemanticStackBound.okB I = true) (hbin : BinCheck.BinOkWithResults I I.results D file) (B : BaseEnv)
    (hB : BaseOk (sys I B)) {n : String} {f : Clif.Function} (hf : (prog I).func? n = some f)
    (hc : ¬ SemanticStackBound.CycleFrom (SemanticStackBound.Calls I I.results) f) (M : Nat) {r : Arm.ArmState}
    {args : List Clif.Val} {cs : Clif.State} (hX : (imageOf file).Intact r)
    (ho : OutsideCall I (BinCheck.roByte I D) f (SemanticStackBound.stackFn I f) r args cs.mem)
    (hr : ClifRun I B f r args cs)
    (htr : TrapsExplicit (Clif.linkEnvN (prog I) B.env M) (prog I).bare cs) :
    ArmRefines (art I f).fb (art I f).base (xreg 30 r) ((sys I B).mach M f) (modelOf I f r)
      (Clif.runLoop B.env (prog I) (M + 1) cs) ∧
    ∀ a, (modelOf I f r).mem a ≠ r.mem a → BinCheck.RelocAtWithResults I I.results a :=
  binary_correct_of_checks hI hbin B hB ((SemanticStackBound.goodN_iff hI).2 ⟨f, hf, hc⟩) hf M hX ho hr htr

end E2E.SemanticBinary

/-! # The per-state facts of the run through the stack-bound and binary theorems (L3 (c))

`backend_correct_program_budgetX_semantic` (`FV/E2E/LinkGood.lean`) adds to the whole-program theorem, for a
returning or trapping outcome, `RunGoodL`: the per-state facts of every state of the linked run
whose step ends without error. Here they are carried through the stack-bound wrappers
(`backend_correct_program_stackX_semantic`, `crate_correct_stackNX`) and the binary-level theorems
(`binary_correctX`, `binary_correct_of_checksX`), across the exterior `F` of the proof's linked
system (`runGoodL_F`: the linked machine does not depend on it). `binary_correct_depthX` is the
same for any program, recursive ones included: the stack premise is the depth-`M` budget
`frameDrop + D * M` (`LinkSys.budget_K_semantic`) instead of the stack bound of a non-recursive program.
`binary_correct_peakX` takes the budget at the run's peak call depth `d` instead of its fuel
(`Clif.DepthLe`, `backend_correct_program_peakX_semantic`): `frameDrop + D * d`. -/

namespace E2E

open Backend Backend.Proof Backend.Proof.Driver

/-- `backend_correct_program_stack` with `RunGoodL` for a returning or trapping outcome. -/
theorem backend_correct_program_stackX_semantic (L : LinkSys) (hL : L.OkSemanticNI) {κ : Nat → Clif.Function → Nat}
    (hκ : L.Budget κ) {f : Clif.Function} (b : Nat) (hb : ∀ M, κ M f = b)
    (hf : f ∈ L.P.funcs) (M : Nat) {ra : BitVec 64} {s w₀ : Arm.ArmState} {args : List Clif.Val}
    {cs : Clif.State}
    (hent : AbiEntry (L.A f).fb (L.A f).base ra s)
    (hroom : frameDrop (L.A f).af + b ≤ (spv s).toNat)
    (hgfree : ∀ a, L.Img a → ¬ StackBelow (frameDrop (L.A f).af + b) (spv s) a)
    (hF : L.F = frameWG b (RAFrame.compute (L.A f).vcp (L.A f).rf).intBase
      (RAFrame.compute (L.A f).vcp (L.A f).rf).size (L.A f).af L.Img s)
    (himg : ∀ a, L.Img a → s.mem a = L.imgMem a)
    (hbe : BodyEntry (L.A f).af s w₀) (hargs : ArgsIn f.sig args s) (hcs : ClifEntry f args cs)
    (hsav : StackArgsAvoid L.Img f.sig args s)
    (hrel : Rel.holds ⟨L.F, L.syms, (L.A f).af.slotBase,
      (RAFrame.compute (L.A f).vcp (L.A f).rf).intBase⟩ f cs.frame.slots cs.mem w₀)
    (hpl : L.NeedSlots → L.PlaceAt cs.mem (spv w₀))
    (htr : TrapsExplicit (Clif.linkEnvN L.P L.base M) L.P.bare cs) :
    ArmRefines (L.A f).fb (L.A f).base ra (L.mach M f) s (Clif.runLoop L.base L.P (M + 1) cs) ∧
      ((∃ vals cm, Clif.runLoop L.base L.P (M + 1) cs = .returned vals cm) ∨
        (∃ c, Clif.runLoop L.base L.P (M + 1) cs = .trapped c) → L.RunGoodL M f s) := by
  have hd := L.frameDrop_eq_semantic hL hf
  have hres : StackAvail b (L.A f).af s := by
    unfold StackAvail
    rw [show (L.A f).af.frameSize + 16 + b = frameDrop (L.A f).af + b by omega]
    refine stackRoom_of hroom fun a ha => hgfree a (hL.imgAddr f hf a ?_)
    simpa [CodeAddr, hent.program] using ha
  rw [← hb M] at hres hF hgfree
  exact backend_correct_program_budgetX_semantic L hL hκ hf M hent hres hF hgfree himg hbe hargs hcs hsav
    hrel hpl htr

namespace SemanticStackBound

open LinkCheck

/-- `ProgStmtS` with `RunGoodL` for a returning or trapping outcome. -/
def ProgStmtSX (L : LinkSys) (I : SemanticStackBound.CompilerInput) (n : String) : Prop :=
  ∀ (f : Clif.Function), L.P.func? n = some f →
  ∀ (M : Nat) (ra : BitVec 64) (s w₀ : Arm.ArmState) (args : List Clif.Val) (cs : Clif.State),
    AbiEntry (L.A f).fb (L.A f).base ra s →
    stackFn I f ≤ (spv s).toNat → (∀ a, L.Img a → ¬ StackBelow (stackFn I f) (spv s) a) →
    L.F = frameWG (bud I f) (RAFrame.compute (L.A f).vcp (L.A f).rf).intBase
      (RAFrame.compute (L.A f).vcp (L.A f).rf).size (L.A f).af L.Img s →
    (∀ a, L.Img a → s.mem a = L.imgMem a) →
    BodyEntry (L.A f).af s w₀ → ArgsIn f.sig args s → ClifEntry f args cs →
    StackArgsAvoid L.Img f.sig args s →
    Rel.holds ⟨L.F, L.syms, (L.A f).af.slotBase,
      (RAFrame.compute (L.A f).vcp (L.A f).rf).intBase⟩ f cs.frame.slots cs.mem w₀ →
    (L.NeedSlots → L.PlaceAt cs.mem (spv w₀)) →
    TrapsExplicit (Clif.linkEnvN L.P L.base M) L.P.bare cs →
    ArmRefines (L.A f).fb (L.A f).base ra (L.mach M f) s (Clif.runLoop L.base L.P (M + 1) cs) ∧
      ((∃ vals cm, Clif.runLoop L.base L.P (M + 1) cs = .returned vals cm) ∨
        (∃ c, Clif.runLoop L.base L.P (M + 1) cs = .trapped c) → L.RunGoodL M f s)

/-- `StackStmt` with `ProgStmtSX`. -/
def StackStmtX (I : SemanticStackBound.CompilerInput) (n : String) : Prop :=
  ∀ (B : BaseEnv) (F : BitVec 64 → Prop), BaseOk (SemanticStackBound.ofInput I B F) →
    (∀ a, (SemanticStackBound.ofInput I B F).Img a → F a) → ProgStmtSX (SemanticStackBound.ofInput I B F) I n

/-- `crate_correct_stackN` with `RunGoodL` for a returning or trapping outcome. -/
theorem crate_correct_stackNX {I : SemanticStackBound.CompilerInput} (hI : SemanticStackBound.okB I = true) {n : String}
    (hn : goodN I n = true) : StackStmtX I n := by
  intro B F hB hFI f hf M _ _ _ _ _ hent hroom hgfree hFeq himg hbe hargs hcs hsav hrel hpl htr
  have hf' : (progOf I.results).func? n = some f := hf
  unfold goodN at hn
  rw [hf'] at hn
  obtain ⟨b, hb⟩ := Option.isSome_iff_exists.1 hn
  have hbud : bud I f = b := by simp [bud, hb]
  exact backend_correct_program_stackX_semantic _ (SemanticStackBound.okB_sound hI hB hFI) (budget_of hI B F) (bud I f)
    (fun M => by simp [LinkSys.hybrid, hb, hbud]) (Clif.Program.func?_some hf).1 M hent hroom
    hgfree hFeq himg hbe hargs hcs hsav hrel hpl htr

end SemanticStackBound

namespace SemanticBinary

open LinkCheck

/-! ## `RunGoodL` does not depend on the exterior `F` -/

theorem reachL_F {I : SemanticStackBound.CompilerInput} {B : BaseEnv} {F F' : BitVec 64 → Prop} {M : Nat}
    {f : Clif.Function} {c : Arm.ArmState} {M' : Nat} {g : Clif.Function} {c' t : Arm.ArmState}
    (h : (SemanticStackBound.ofInput I B F').ReachL M f c M' g c' t) :
    (SemanticStackBound.ofInput I B F).ReachL M f c M' g c' t := by
  induction h with
  | act hj =>
    rw [mach_F I B F' F] at hj ⊢
    exact .act hj
  | nest hj hc herr _ ih =>
    rw [mach_F I B F' F] at hj hc herr ih
    exact .nest hj hc herr ih

theorem goodAt_F {I : SemanticStackBound.CompilerInput} {B : BaseEnv} {F F' : BitVec 64 → Prop} {M : Nat}
    {g : Clif.Function} {c t : Arm.ArmState} (h : (SemanticStackBound.ofInput I B F).GoodAt M g c t) :
    (SemanticStackBound.ofInput I B F').GoodAt M g c t := by
  obtain ⟨X, K, G, gv, heq, hg, hi⟩ := h
  rw [hooks_F I B F F' M, mach_F I B F F' M] at heq
  rw [hooks_F I B F F' M] at hg
  exact ⟨X, K, G, gv, heq, hg, hi⟩

/-- **`RunGoodL` does not depend on the exterior `F`** of the linked system. -/
theorem runGoodL_F {I : SemanticStackBound.CompilerInput} {B : BaseEnv} {F F' : BitVec 64 → Prop} {M : Nat}
    {f : Clif.Function} {c : Arm.ArmState} (h : (SemanticStackBound.ofInput I B F).RunGoodL M f c) :
    (SemanticStackBound.ofInput I B F').RunGoodL M f c := fun M' g c' t hR he =>
  goodAt_F (h M' g c' t (reachL_F hR) (by rw [mach_F I B F F']; exact he))

/-! ## The binary-level theorems -/

/-- `binary_correct` with `RunGoodL` of the model's run for a returning or trapping outcome. -/
theorem binary_correctX {I : SemanticStackBound.CompilerInput} {X : Image} {R : BitVec 64 → Prop}
    {roB : BitVec 64 → Option (BitVec 8)} (hbin : BinFacts I X R roB) (B : BaseEnv)
    (hB : BaseOk (sys I B)) {n : String} (hn : SemanticStackBound.goodN I n = true) {f : Clif.Function}
    (hf : (prog I).func? n = some f) (M : Nat) {r : Arm.ArmState}
    {args : List Clif.Val} {cs : Clif.State} (hX : X.Intact r)
    (ho : OutsideCall I roB f (SemanticStackBound.stackFn I f) r args cs.mem)
    (hr : ClifRun I B f r args cs)
    (htr : TrapsExplicit (Clif.linkEnvN (prog I) B.env M) (prog I).bare cs) :
    ArmRefines (art I f).fb (art I f).base (xreg 30 r) ((sys I B).mach M f) (modelOf I f r)
      (Clif.runLoop B.env (prog I) (M + 1) cs) ∧
    (∀ a, (modelOf I f r).mem a ≠ r.mem a → R a) ∧
    ((∃ vals cm, Clif.runLoop B.env (prog I) (M + 1) cs = .returned vals cm) ∨
      (∃ c, Clif.runLoop B.env (prog I) (M + 1) cs = .trapped c) →
      (sys I B).RunGoodL M f (modelOf I f r)) := by
  have hB' : BaseOk (SemanticStackBound.ofInput I B (worldF I f (SemanticStackBound.bud I f) r)) := baseOk_F hB
  have himgF : ∀ a, (SemanticStackBound.ofInput I B (worldF I f (SemanticStackBound.bud I f) r)).Img a →
      worldF I f (SemanticStackBound.bud I f) r a := fun _ h => .inr h
  have hL := SemanticStackBound.okB_sound hbin.ok hB' himgF
  have hro : ∀ a b, roB a = some b → r.mem a = b := fun a b h =>
    hX a b (hbin.data a b h).1 (hbin.data a b h).2
  obtain ⟨hent, -, hgfree, himg, hbe, hargs, hsav, hrel, hpl⟩ :=
    premises hL (Clif.Program.func?_some hf).1 hro ho hr
  obtain ⟨hA, hG⟩ := SemanticStackBound.crate_correct_stackNX hbin.ok hn B _ hB' himgF f hf M _ _ _ args
    cs hent (by rw [spv_modelOf]; exact ho.stack) hgfree rfl himg hbe hargs hr.entry hsav hrel hpl
    htr
  refine ⟨?_, (binary_correct hbin B hB hn hf M hX ho hr htr).2, fun hout => runGoodL_F (hG hout)⟩
  rw [mach_F I B (fun _ => False) (worldF I f (SemanticStackBound.bud I f) r)]
  exact hA

/-- **The model state differs from `r` only at the bytes `R`** (the binary facts, the loader
premise). -/
theorem BinFacts.modelOf_ne {I : SemanticStackBound.CompilerInput} {X : Image} {R : BitVec 64 → Prop}
    {roB : BitVec 64 → Option (BitVec 8)} (hbin : BinFacts I X R roB) {f : Clif.Function}
    {r : Arm.ArmState} (hX : X.Intact r) : ∀ a, (modelOf I f r).mem a ≠ r.mem a → R a := by
  intro a hne
  by_cases hi : img I a
  · rw [mem_modelOf_img hi] at hne
    rcases (hbin.code a hi).2 with h | h
    · exact absurd (hX a _ (hbin.code a hi).1 h).symm hne
    · exact h
  · exact absurd (mem_modelOf_not hi) hne

/-- **`binary_correctX` for any program, recursive ones included**: the stack premise is the
depth-`M` budget `frameDrop + D * M` (`LinkSys.budget_K_semantic`: every frame of a call level is at most
`D`) instead of the stack bound `stackFn` of a non-recursive program, so no call-graph premise
(`goodN`) is left; with read-only data facts `roB` (unlike `binary_correct_depth`). `M` is both
the CLIF run's fuel and the depth of the linked machine. -/
theorem binary_correct_depthX {I : SemanticStackBound.CompilerInput} {X : Image} {R : BitVec 64 → Prop}
    {roB : BitVec 64 → Option (BitVec 8)} (hbin : BinFacts I X R roB) (B : BaseEnv)
    (hB : BaseOk (sys I B)) {n : String} {f : Clif.Function} (hf : (prog I).func? n = some f)
    (M : Nat) {r : Arm.ArmState} {args : List Clif.Val} {cs : Clif.State} (hX : X.Intact r)
    (ho : OutsideCall I roB f (frameDrop (art I f).af + I.D * M) r args cs.mem)
    (hr : ClifRun I B f r args cs)
    (htr : TrapsExplicit (Clif.linkEnvN (prog I) B.env M) (prog I).bare cs) :
    ArmRefines (art I f).fb (art I f).base (xreg 30 r) ((sys I B).mach M f) (modelOf I f r)
      (Clif.runLoop B.env (prog I) (M + 1) cs) ∧
    (∀ a, (modelOf I f r).mem a ≠ r.mem a → R a) ∧
    ((∃ vals cm, Clif.runLoop B.env (prog I) (M + 1) cs = .returned vals cm) ∨
      (∃ c, Clif.runLoop B.env (prog I) (M + 1) cs = .trapped c) →
      (sys I B).RunGoodL M f (modelOf I f r)) := by
  have hB' : BaseOk (SemanticStackBound.ofInput I B (worldF I f (I.D * M) r)) := baseOk_F hB
  have himgF : ∀ a, (SemanticStackBound.ofInput I B (worldF I f (I.D * M) r)).Img a →
      worldF I f (I.D * M) r a := fun _ h => .inr h
  have hL := SemanticStackBound.okB_sound hbin.ok hB' himgF
  have hro : ∀ a b, roB a = some b → r.mem a = b := fun a b h =>
    hX a b (hbin.data a b h).1 (hbin.data a b h).2
  obtain ⟨hent, hres, hgfree, himg, hbe, hargs, hsav, hrel, hpl⟩ :=
    premises hL (Clif.Program.func?_some hf).1 hro ho hr
  obtain ⟨hA, hG⟩ := backend_correct_program_budgetX_semantic _ hL (LinkSys.budget_K_semantic _ hL)
    (Clif.Program.func?_some hf).1 M hent hres rfl hgfree himg hbe hargs hr.entry hsav hrel hpl htr
  refine ⟨?_, hbin.modelOf_ne hX, fun hout => runGoodL_F (hG hout)⟩
  rw [mach_F I B (fun _ => False) (worldF I f (I.D * M) r)]
  exact hA

/-- **`binary_correct_depthX` for the run's peak call depth** (L1d): the whole-program CLIF run
of at most `F + 1` steps reaches no state with more than `d` callers (`Clif.DepthLe`); the stack
premise is the depth-`d` budget `frameDrop + D * d`, independent of the fuel `F`, and the linked
machine has depth `d`. The run premise `TrapsExplicit` is under the environment whose program
callees run with fuel `F` and at most `d - 1` callers of their own (`Clif.linkEnvD`). -/
theorem binary_correct_peakX {I : SemanticStackBound.CompilerInput} {X : Image} {R : BitVec 64 → Prop}
    {roB : BitVec 64 → Option (BitVec 8)} (hbin : BinFacts I X R roB) (B : BaseEnv)
    (hB : BaseOk (sys I B)) {n : String} {f : Clif.Function} (hf : (prog I).func? n = some f)
    (F d : Nat) {r : Arm.ArmState} {args : List Clif.Val} {cs : Clif.State} (hX : X.Intact r)
    (ho : OutsideCall I roB f (frameDrop (art I f).af + I.D * d) r args cs.mem)
    (hr : ClifRun I B f r args cs) (hd : Clif.DepthLe B.env (prog I) d cs)
    (htr : TrapsExplicit (Clif.linkEnvD (prog I) B.env F d) (prog I).bare cs) :
    ArmRefines (art I f).fb (art I f).base (xreg 30 r) ((sys I B).mach d f) (modelOf I f r)
      (Clif.runLoop B.env (prog I) (F + 1) cs) ∧
    (∀ a, (modelOf I f r).mem a ≠ r.mem a → R a) ∧
    ((∃ vals cm, Clif.runLoop B.env (prog I) (F + 1) cs = .returned vals cm) ∨
      (∃ c, Clif.runLoop B.env (prog I) (F + 1) cs = .trapped c) →
      (sys I B).RunGoodL d f (modelOf I f r)) := by
  have hB' : BaseOk (SemanticStackBound.ofInput I B (worldF I f (I.D * d) r)) := baseOk_F hB
  have himgF : ∀ a, (SemanticStackBound.ofInput I B (worldF I f (I.D * d) r)).Img a →
      worldF I f (I.D * d) r a := fun _ h => .inr h
  have hL := SemanticStackBound.okB_sound hbin.ok hB' himgF
  have hro : ∀ a b, roB a = some b → r.mem a = b := fun a b h =>
    hX a b (hbin.data a b h).1 (hbin.data a b h).2
  obtain ⟨hent, hres, hgfree, himg, hbe, hargs, hsav, hrel, hpl⟩ :=
    premises hL (Clif.Program.func?_some hf).1 hro ho hr
  obtain ⟨hA, hG⟩ := backend_correct_program_peakX_semantic _ hL (LinkSys.budget_K_semantic _ hL)
    (Clif.Program.func?_some hf).1 F d hent hres rfl hgfree himg hbe hargs hr.entry hsav hrel hpl
    hd htr
  refine ⟨?_, hbin.modelOf_ne hX, fun hout => runGoodL_F (hG hout)⟩
  rw [mach_F I B (fun _ => False) (worldF I f (I.D * d) r)]
  exact hA

/-- `binary_correct_of_checks` with `RunGoodL` of the model's run for a returning or trapping
outcome. -/
theorem binary_correct_of_checksX {I : SemanticStackBound.CompilerInput} {D : List Clif.DataObject} {file : ByteArray}
    (hI : SemanticStackBound.okB I = true) (hbin : BinCheck.BinOkWithResults I I.results D file) (B : BaseEnv) (hB : BaseOk (sys I B))
    {n : String} (hn : SemanticStackBound.goodN I n = true) {f : Clif.Function}
    (hf : (prog I).func? n = some f) (M : Nat) {r : Arm.ArmState} {args : List Clif.Val}
    {cs : Clif.State} (hX : (imageOf file).Intact r)
    (ho : OutsideCall I (BinCheck.roByte I D) f (SemanticStackBound.stackFn I f) r args cs.mem)
    (hr : ClifRun I B f r args cs)
    (htr : TrapsExplicit (Clif.linkEnvN (prog I) B.env M) (prog I).bare cs) :
    ArmRefines (art I f).fb (art I f).base (xreg 30 r) ((sys I B).mach M f) (modelOf I f r)
      (Clif.runLoop B.env (prog I) (M + 1) cs) ∧
    (∀ a, (modelOf I f r).mem a ≠ r.mem a → BinCheck.RelocAtWithResults I I.results a) ∧
    ((∃ vals cm, Clif.runLoop B.env (prog I) (M + 1) cs = .returned vals cm) ∨
      (∃ c, Clif.runLoop B.env (prog I) (M + 1) cs = .trapped c) →
      (sys I B).RunGoodL M f (modelOf I f r)) :=
  binary_correctX (binFacts_of_checks hI hbin) B hB hn hf M hX ho hr htr

end SemanticBinary

end E2E

/-! # The executable's own instruction words (L3, M9 item 1b)

`binary_correct_of_checks` (`FV/E2E/SemanticBinary.lean`) is about the **model** machine
`(sys I B).mach M f` run from `modelOf I f r`: the machine state `r` with the compiled image (the
compiled words, relocation fields zero) at the program's code addresses. That machine runs
`adrp`/`add`, `adrp`/`ldr` of the GOT, `bl`/`blr` and the TLSDESC sequence through hooks
(`ArmStepX`): the `adrp` writes the symbol's address, the second word of a pair does nothing, a
`bl` of a function of the program runs the callee's code as one step (`linkedCall`). Here the
theorem is moved to the **executable machine** `step I B file`, which runs the executable's own
words.

## The executable machine (`step`)

At the pc it looks up the kind of site there (`siteAt`: the kind, `siteOf`, of the program's
instruction there, from the compiled functions' layouts; only to decide which words are outside
code; two functions sharing code, a self-call alias, have the same kind at each word) and

* a `bl n` / `blr` whose callee is **outside the program**, the TLSDESC `adrp`, and its `ldr`
  (which in the model runs the rest of the sequence, `Hb.tls`): the base environment's hooks, as
  the model (code outside the program is given by its contract);
* every other word, **including** `adrp`+`add`, `adrp`+`ldr` (GOT), `bl`/`blr` to functions of
  the program: `realStep`, which fetches the 32-bit word **from the executable file**
  (`readN (Elf.loadMem file) 4 pc`, the read-only text), decodes it with the Arm model's decoder
  and executes it (`Arm.exec_inst`). The callee of a `bl` then runs in the same machine, and so
  on to its `ret`.

The `program` field of the state is not read by this machine.

## The simulation (`Sim`, `act_sim`)

`Sim I m e`: every register (incl. pc, flags, error) of the executable state `e` is the model
state `m`'s, every byte outside the relocated instruction bytes `RelocAtWithResults I I.results` too (the program
field is not compared). The run of the model's activation of `g` at depth `M` is simulated:

* an instruction without relocation: the same decoded word on both sides (`ArtOk.plain`,
  `Insn.decode_encode`), one step each;
* a pair `adrp`; `add`/`ldr` at `P` (`RelocOk`, `PairOk`, words `ExecWords`): the two model steps
  against the two executable steps; after the first the register holds `page(T)` (resp.
  `page(G)`) in the executable and `T` in the model, after the second `T` in both
  (`adrp_add_val`, `adrp_ldr_addr`; for the GOT the slot's 8 bytes hold `T`);
* a `bl`/`blr` of a function `h` of the program at depth `M + 1`: the real `bl` (`blW_exec`) /
  `blr` (`blr_exec`) enters `h`'s code in the state `enterAt (art I h) m` (up to the program
  field), the callee's activation is simulated at depth `M` (induction on the depth) up to its
  first return (`RetOf`, `firstNat`), which is the model's `linkedCall`;
* outside calls and TLS: the same hook on both sides.

## What the simulation takes from the model run (`StepOk`, `RunOk`)

The model's ArmRefines does not expose its intermediate states, so the per-state facts the
lockstep needs are one explicit hypothesis, `RunOk`: `StepOk` at every state of the model's run
before its return (`Reach`, nested into the linked calls). `StepOk M g m` (`m` a state of an
activation of `g` at depth `M`): no error, the program field is `g`'s, the pc is at an
instruction of `g` (the site lookup, `siteAt`, giving its kind of site), and
* `cf`  (D1): a step that lands on the second word of a pair starts at its first word;
* `insn` / `call` / `tls` (D2): the instruction (resp. outside call, TLS hook) at `m` reads no
  relocated instruction byte (`Sim` before ⇒ `Sim` after);
* `got` (D4): at the `ldr` of a GOT pair the slot's 8 bytes are the file's, not relocated code;
* `blr`: the word the model reads at a `blr` to the program is the file's, and the callee's
  link-map address is its load address.
These hold of the M6 runs by construction (`RL.Good`, `StRel.code`, `StRel.gkeep`); proving them
there is the remaining work (docs/TO-PROVE.md L3).

## Trusted

The TLS local-exec sequence (`movz`/`movk`/`nop`/`nop`, checked by `BinCheck`, then `mrs
tpidr_el0`, `add`) is run through `Hb.tls`, as in the model: the Arm model has no system
registers.
-/

namespace E2E.SemanticExecBytes

open Backend Backend.Proof E2E.LinkCheck E2E.SemanticBinary E2E.BinCheck

/-! ## The executable machine -/

section Machine

variable (I : SemanticStackBound.CompilerInput) (B : BaseEnv) (file : ByteArray)

/-- The executable's 32-bit word at `a` (its loaded image). -/
def fileWord (a : BitVec 64) : Option (BitVec 32) := readN (Elf.loadMem file) 4 a

/-- **One step of the processor on the executable's word at the pc**: fetch it from the file,
decode it, execute it; an error state stays put. -/
def realStep (s : Arm.ArmState) : Arm.ArmState :=
  match Arm.read_err s with
  | .None =>
    match (fileWord file (Arm.r .PC s)).bind Arm.decode_raw_inst with
    | some a => Arm.exec_inst a s
    | none => Arm.w .ERR (.Other "no instruction word") s
  | _ => s

/-- **The kind of a site** of the program's code: what the executable machine does there. Code
shared by two functions of the program (a historical self-call alias `f__fvself` on `f`'s code)
has one kind at each word even where the functions' lines differ (`f`'s `bl f__fvself`,
`f__fvself`'s `bl f`: both a call of a function of the program, `progCall_semantic`). -/
inductive Site where
  /-- the processor on the file's word -/
  | real
  /-- a `bl` of a function of the program: the processor on the file's word -/
  | progCall_semantic
  /-- a `bl n` of code outside the program: the base environment's hook -/
  | extCall (n : String)
  /-- a `blr`: the processor when its target is a function of the program, else the hook -/
  | blr
  /-- the TLSDESC `adrp`: skipped, as in the model -/
  | tlsAdrp
  /-- the TLSDESC `ldr`: the TLS hook -/
  | tls (tmp : Reg) (n : String)

/-- The kind of the site of the instruction `i` of the program `P`. -/
def siteOf (P : Clif.Program) : Insn → Site
  | .bl n => if (P.func? n).isSome then .progCall_semantic else .extCall n
  | .blr _ => .blr
  | .adrpTlsDesc _ _ => .tlsAdrp
  | .ldrTlsDescLo12 tmp _ n => .tls tmp n
  | _ => .real

open Classical in
/-- **The kind of site at the address `a`**: that of the instruction there of some function of
the program whose code has one there (`siteOf`). -/
noncomputable def siteAt (a : BitVec 64) : Option Site :=
  if h : ∃ g ∈ (prog I).funcs, (insnAt (art I g).fa (art I g).base a).isSome then
    (insnAt (art I h.choose).fa (art I h.choose).base a).map (siteOf (prog I))
  else none

/-- The step at a site. -/
noncomputable def stepAt (site : Option Site) (s : Arm.ArmState) : Arm.ArmState :=
  match site with
  | some (.extCall n) => B.hooks.call (some n) s
  | some .blr =>
    if ((blrTarget s).bind (symCallee (sys I B).Xb (prog I))).isSome then realStep file s
    else B.hooks.call none s
  | some .tlsAdrp => Arm.w .PC (Arm.r .PC s + 4) s
  | some (.tls tmp n) => B.hooks.tls n tmp s
  | _ => realStep file s

/-- The step at an instruction of the program (`stepAt` of its kind of site, `stepAt_site`). -/
noncomputable def stepIns (site : Option Insn) (s : Arm.ArmState) : Arm.ArmState :=
  match site with
  | some (.bl n) => if ((prog I).func? n).isSome then realStep file s else B.hooks.call (some n) s
  | some (.blr _) =>
    if ((blrTarget s).bind (symCallee (sys I B).Xb (prog I))).isSome then realStep file s
    else B.hooks.call none s
  | some (.adrpTlsDesc _ _) => Arm.w .PC (Arm.r .PC s + 4) s
  | some (.ldrTlsDescLo12 tmp _ n) => B.hooks.tls n tmp s
  | _ => realStep file s

/-- **The executable machine**: the processor on the executable's words (`realStep`), but at
calls of code outside the program and at the TLS sequence, which run by the base environment's
hooks. -/
noncomputable def step (s : Arm.ArmState) : Arm.ArmState := stepAt I B file (siteAt I (Arm.r .PC s)) s

/-- **The executable machine state `e` simulates the model state `m`**: the same registers,
flags, pc and error, the same bytes but at relocated instruction bytes (the program field, which
neither machine's semantics of a word reads, is not compared). -/
def Sim (m e : Arm.ArmState) : Prop :=
  (∀ fld, Arm.r fld e = Arm.r fld m) ∧ ∀ a, ¬ RelocAtWithResults I I.results a → e.mem a = m.mem a

/-- `a` is the second word of an `adrp` pair of `g` (its `add`/`ldr`). -/
def Second (g : Clif.Function) (a : BitVec 64) : Prop :=
  ∃ rl ∈ (art I g).fb.relocs, (rl.type = .adrGotPage ∨ rl.type = .adrPrelPgHi21) ∧
    a = wAt (art I g) (rl.offset + 4)

/-- The model's activation of `a` entered at `c` has returned in `t` (`RetOf` of the call). -/
def Returned (a : Art) (c t : Arm.ArmState) : Prop :=
  Arm.r .PC t = xreg 30 c ∧ Arm.r .ERR t = .None ∧ t.program = a.fb.program a.base ∧
    spv t = spv c

/-- The model's step at `s` (an activation of `g`) is a linked call of the function `h` of the
program. -/
def CallsAt (g : Clif.Function) (s : Arm.ArmState) (h : Clif.Function) : Prop :=
  (∃ n, insnAt (art I g).fa (progBase s) (Arm.r .PC s) = some (.bl n) ∧ (prog I).func? n = some h) ∨
  ((∃ x, insnAt (art I g).fa (progBase s) (Arm.r .PC s) = some (.blr x)) ∧
    (blrTarget s).bind (symCallee (sys I B).Xb (prog I)) = some h)

/-- **The states of the model's activation of `g` at depth `M` entered at `c`** before its
return, and of the activations it calls (`Reach M g c M' g' t`: `t` is a state of an activation
of `g'` at depth `M'`). -/
inductive Reach : Nat → Clif.Function → Arm.ArmState → Nat → Clif.Function → Arm.ArmState → Prop
  | act {M g c k} : (∀ j ≤ k, ¬ Returned (art I g) c (runX ((sys I B).mach M g) j c)) →
      Reach M g c M g (runX ((sys I B).mach M g) k c)
  | nest {M g c k h M' g' t} :
      (∀ j ≤ k, ¬ Returned (art I g) c (runX ((sys I B).mach (M + 1) g) j c)) →
      CallsAt I B g (runX ((sys I B).mach (M + 1) g) k c) h →
      Reach M h (enterAt (art I h) (runX ((sys I B).mach (M + 1) g) k c)) M' g' t →
      Reach (M + 1) g c M' g' t

/-- **What the lockstep needs of a model state** `m` of an activation of `g` at depth `M` (see the
module doc). -/
structure StepOk (M : Nat) (g : Clif.Function) (m : Arm.ArmState) : Prop where
  err : Arm.r .ERR m = .None
  program : m.program = (art I g).fb.program (art I g).base
  /-- the pc is at an instruction of `g` (the site the executable machine looks up), not inside
  the TLS sequence past its `ldr` -/
  site : ∃ i, insnAt (art I g).fa (art I g).base (Arm.r .PC m) = some i ∧
    siteAt I (Arm.r .PC m) = some (siteOf (prog I) i) ∧ (i.reloc? = none ∨ i.hooked = true)
  /-- D1: only the first word of a pair steps to its second -/
  cf : ∀ rl ∈ (art I g).fb.relocs, (rl.type = .adrGotPage ∨ rl.type = .adrPrelPgHi21) →
    Arm.r .PC ((sys I B).mach M g m) = wAt (art I g) (rl.offset + 4) →
    Arm.r .PC m = wAt (art I g) rl.offset
  /-- D2: an instruction without relocation reads no relocated instruction byte -/
  insn : ∀ i, insnAt (art I g).fa (art I g).base (Arm.r .PC m) = some i → i.hooked = false →
    ∀ a, (fileWord file (Arm.r .PC m)).bind Arm.decode_raw_inst = some a →
    ∀ e, Sim I m e → Sim I (Arm.exec_inst a m) (Arm.exec_inst a e)
  /-- D2: nor does a call of code outside the program -/
  call : ∀ d e, ((∃ n, insnAt (art I g).fa (art I g).base (Arm.r .PC m) = some (.bl n) ∧
        (prog I).func? n = none ∧ d = some n) ∨
      ((∃ x, insnAt (art I g).fa (art I g).base (Arm.r .PC m) = some (.blr x)) ∧
        (blrTarget m).bind (symCallee (sys I B).Xb (prog I)) = none ∧ d = none)) →
    Sim I m e → Sim I (B.hooks.call d m) (B.hooks.call d e)
  /-- D2: nor the TLS sequence -/
  tls : ∀ tmp rn n e, insnAt (art I g).fa (art I g).base (Arm.r .PC m) =
      some (.ldrTlsDescLo12 tmp rn n) →
    Sim I m e → Sim I (B.hooks.tls n tmp m) (B.hooks.tls n tmp e)
  /-- D4: at the `ldr` of a GOT pair (`P`, register `rd`) loading the slot `G`, the slot holds
  the file's bytes, which are not relocated instruction bytes -/
  got : ∀ rl ∈ (art I g).fb.relocs, rl.type = .adrGotPage →
    Arm.r .PC m = wAt (art I g) (rl.offset + 4) → ∀ (rd G : Nat), rd < 31 → G % 8 = 0 →
    inR (-2 ^ 20) (2 ^ 20) (pageOf G - pageOf (wAt (art I g) rl.offset).toNat) = true →
    fileWord file (wAt (art I g) rl.offset) =
      some (adrpW rd (pageOf G - pageOf (wAt (art I g) rl.offset).toNat)) →
    fileWord file (wAt (art I g) (rl.offset + 4)) = some (ldrW rd rd (G % 4096 / 8)) → ∀ i < 8,
    ¬ RelocAtWithResults I I.results (BitVec.ofNat 64 G + BitVec.ofNat 64 i) ∧
    m.mem (BitVec.ofNat 64 G + BitVec.ofNat 64 i) =
      (Elf.loadMem file (BitVec.ofNat 64 G + BitVec.ofNat 64 i)).getD 0
  /-- a `blr` to the program: through a register (not `xzr`), the model reads the file's word,
  and the callee's link-map address is its load address -/
  blr : ∀ x h, insnAt (art I g).fa (art I g).base (Arm.r .PC m) = some (.blr x) →
    (blrTarget m).bind (symCallee (sys I B).Xb (prog I)) = some h →
    x ≠ .xzr ∧ fileWord file (Arm.r .PC m) = some (Arm.read_mem_bytes 4 (Arm.r .PC m) m) ∧
    I.symAddr h.name 0 = (art I h).base
  /-- the instruction word at the pc is no relocated byte of another function -/
  plain : ∀ i, insnAt (art I g).fa (art I g).base (Arm.r .PC m) = some i → i.reloc? = none →
    ∀ k < 4, ¬ RelocAtWithResults I I.results (Arm.r .PC m + BitVec.ofNat 64 k)

/-- **The hypothesis on the model's runs**: `StepOk` at every state of the activation of `f`
at depth `M` entered at `c` (and of the activations it calls) before its return. -/
def RunOk (M : Nat) (f : Clif.Function) (c : Arm.ArmState) : Prop :=
  ∀ M' g t, Reach I B M f c M' g t → StepOk I B file M' g t

end Machine

/-! ## Basic facts -/

section Lemmas

variable {I : SemanticStackBound.CompilerInput} {B : BaseEnv} {file : ByteArray}

theorem runX_succ' (f : Arm.ArmState → Arm.ArmState) (k : Nat) (s : Arm.ArmState) :
    runX f (k + 1) s = f (runX f k s) := by
  rw [runX_add f k 1]; rfl

theorem sim_w {m e : Arm.ArmState} (h : Sim I m e) (fld : Arm.StateField)
    (v : Arm.state_value fld) : Sim I (Arm.w fld v m) (Arm.w fld v e) := by
  refine ⟨fun f => ?_, fun a ha => ?_⟩
  · by_cases hf : f = fld
    · subst hf; rw [Arm.r_of_w_same, Arm.r_of_w_same]
    · rw [Arm.r_of_w_different hf, Arm.r_of_w_different hf]; exact h.1 f
  · rw [Arm.ArmState.mem_w_eq_mem, Arm.ArmState.mem_w_eq_mem]; exact h.2 a ha

theorem sim_set_program {m e : Arm.ArmState} (p : Arm.Program) (h : Sim I m e) :
    Sim I (Arm.set_program m p) e :=
  ⟨fun f => by rw [r_set_program]; exact h.1 f, fun a ha => by rw [mem_set_program]; exact h.2 a ha⟩

theorem insnAt_spec {fa : FnAsm} {base pc : BitVec 64} {i : Insn} (h : insnAt fa base pc = some i) :
    ∃ j t, fa.lines.toList[j]? = some (.ins i t) ∧
      base + BitVec.ofNat 64 (lineOffset fa.lines.toList j) = pc := by
  unfold insnAt at h
  split at h
  · rename_i hex
    obtain ⟨t, h1, h2⟩ := Classical.choose_spec (Classical.choose_spec hex)
    cases h
    exact ⟨_, t, h1, h2⟩
  · cases h

theorem stepAt_real {site : Option Insn} (s : Arm.ArmState) (h1 : ∀ n, site ≠ some (.bl n))
    (h2 : ∀ x, site ≠ some (.blr x)) (h3 : ∀ a b, site ≠ some (.adrpTlsDesc a b))
    (h4 : ∀ a b c, site ≠ some (.ldrTlsDescLo12 a b c)) :
    stepIns I B file site s = realStep file s := by
  unfold stepIns
  split
  · exact absurd rfl (h1 _)
  · exact absurd rfl (h2 _)
  · exact absurd rfl (h3 _ _)
  · exact absurd rfl (h4 _ _ _)
  · rfl

theorem realStep_eq {s : Arm.ArmState} {a : Arm.ArmInst} (herr : Arm.r .ERR s = .None)
    (h : (fileWord file (Arm.r .PC s)).bind Arm.decode_raw_inst = some a) :
    realStep file s = Arm.exec_inst a s := by
  have : Arm.read_err s = .None := herr
  simp only [realStep, this, h]

theorem returned_iff {a : Art} {s t : Arm.ArmState} : RetOf a s t ↔ Returned a (enterAt a s) t := by
  simp only [RetOf, Returned, x30_enterAt, spv_enterAt]

/-! ## Static facts of a compiled function in the executable -/

/-- The static facts of the function `g` of the program (layout, fit, binary check, address). -/
structure FnOk (I : SemanticStackBound.CompilerInput) (file : ByteArray) (g : Clif.Function) : Prop where
  layout : (art I g).fa.layout = .ok (art I g).fb
  fits : (art I g).base.toNat + 4 * (art I g).fb.words.size ≤ 2 ^ 64
  bin : ArtOk I file (art I g)
  base : (art I g).base = BitVec.ofNat 64 (I.baseOf g.name)

theorem fnOk {D : List Clif.DataObject} (hI : SemanticStackBound.okB I = true) (hbin : BinOkWithResults I I.results D file)
    {F : BitVec 64 → Prop} (hL : (SemanticStackBound.ofInput I B F).OkSemanticNI) {g : Clif.Function}
    (hg : g ∈ (prog I).funcs) : FnOk I file g := by
  obtain ⟨-, -, -, hla, hb⟩ := (SemanticStackBound.facts hI hg).pipe
  exact ⟨hla, hL.fits g hg, hbin.code _ (tab_mem (SemanticStackBound.okB_names hI) hg), hb⟩

theorem wAt_inj {a : Art} {x y : Nat} (hx : x < 2 ^ 64) (hy : y < 2 ^ 64)
    (h : wAt a x = wAt a y) : x = y := by
  simp only [wAt] at h
  have h' := congrArg BitVec.toNat ((BitVec.add_right_inj _).mp h)
  simp only [BitVec.toNat_ofNat] at h'
  rwa [Nat.mod_eq_of_lt hx, Nat.mod_eq_of_lt hy] at h'

theorem insnAt_of_line {g : Clif.Function} (hF : FnOk I file g) {j : Nat} {i : Insn}
    {t : Option Clif.TrapCode} (hj : (art I g).fa.lines.toList[j]? = some (.ins i t)) :
    insnAt (art I g).fa (art I g).base (wAt (art I g) (lineOffset (art I g).fa.lines.toList j)) =
      some i :=
  insnAt_line (by rw [layout_sum hF.layout]; have := hF.fits; omega) hj

theorem line_lt {g : Clif.Function} (hF : FnOk I file g) {j : Nat} {i : Insn}
    {t : Option Clif.TrapCode} (hj : (art I g).fa.lines.toList[j]? = some (.ins i t)) :
    lineOffset (art I g).fa.lines.toList j + 4 ≤ 4 * (art I g).fb.words.size := by
  have h1 := lineOffset_succ _ j _ hj
  have h2 := lineOffset_le_size (art I g).fa.lines.toList (j + 1)
  rw [layout_sum hF.layout] at h2
  simp only [Line.size] at h1
  omega

/-- The reloc of a line, and its offset. -/
theorem line_reloc {g : Clif.Function} (hF : FnOk I file g) {j : Nat} {i : Insn}
    {t : Option Clif.TrapCode} (hj : (art I g).fa.lines.toList[j]? = some (.ins i t))
    {ty : RelocType} {s : String} {ad : Int} (hi : i.reloc? = some (ty, s, ad)) :
    (⟨lineOffset (art I g).fa.lines.toList j, ty, s, ad⟩ : Reloc) ∈ (art I g).fb.relocs :=
  (FnAsm.layout_relocs hF.layout _).2 ⟨j, i, t, hj, hi, rfl⟩

/-- Two instructions at the same offset are the same line. -/
theorem line_unique {g : Clif.Function} {j j' : Nat} {i i' : Insn} {t t' : Option Clif.TrapCode}
    (hj : (art I g).fa.lines.toList[j]? = some (.ins i t))
    (hj' : (art I g).fa.lines.toList[j']? = some (.ins i' t'))
    (he : lineOffset (art I g).fa.lines.toList j = lineOffset (art I g).fa.lines.toList j') :
    i = i' := by
  obtain rfl := lineOffset_inj hj hj' he
  rw [hj] at hj'; cases hj'; rfl

/-- The executable's word of an instruction without relocation is the compiled word. -/
theorem fileWord_plain {g : Clif.Function} (hF : FnOk I file g) {lm : Std.HashMap Lbl Nat}
    (hm : labelOffsets (art I g).fa.lines = .ok lm) {j : Nat} {i : Insn}
    {t : Option Clif.TrapCode} (hj : (art I g).fa.lines.toList[j]? = some (.ins i t))
    (hr : i.reloc? = none) :
    ∃ w, i.encode ⟨lineOffset (art I g).fa.lines.toList j, (lm[·]?)⟩ = .ok w ∧
      fileWord file (wAt (art I g) (lineOffset (art I g).fa.lines.toList j)) = some w := by
  obtain ⟨h4, w, hw, hk⟩ := FnAsm.layout_word hF.layout hm hj rfl
  refine ⟨w, hw, ?_⟩
  have := hF.bin.plain _ w hk (fun r hr' ho => by
    obtain ⟨j', i', t', hj', hi', ho'⟩ := (FnAsm.layout_relocs hF.layout r).1 hr'
    have := line_unique hj hj' (by omega)
    subst this
    rw [hr] at hi'; cases hi')
  rw [show 4 * (lineOffset (art I g).fa.lines.toList j / 4) = lineOffset (art I g).fa.lines.toList j
    by omega] at this
  exact this

/-- The executable's word at a `blr` line decodes to the `blr` (a register, not `xzr`). -/
theorem blr_word {g : Clif.Function} (hF : FnOk I file g) {lm : Std.HashMap Lbl Nat}
    (hm : labelOffsets (art I g).fa.lines = .ok lm) {j : Nat} {x : Reg}
    {t : Option Clif.TrapCode} (hj : (art I g).fa.lines.toList[j]? = some (.ins (.blr x) t))
    (hx : x ≠ .xzr) :
    ∃ w rn, rn.toNat < 31 ∧
      fileWord file (wAt (art I g) (lineOffset (art I g).fa.lines.toList j)) = some w ∧
      Arm.decode_raw_inst w =
        some (.BR (.Uncond_branch_reg { opc := 1, op2 := 31, op3 := 0, Rn := rn, op4 := 0 })) := by
  obtain ⟨w, hw, hf⟩ := fileWord_plain hF hm hj rfl
  obtain ⟨a, ha, hd⟩ := Insn.decode_encode hw
  cases x with
  | x n =>
    by_cases hn : n ≤ 30
    · rw [toArmInst_blr _ hn] at ha
      cases ha
      exact ⟨w, _, by simp; omega, hf, hd⟩
    · simp [Insn.toArmInst, Insn.armFields, Reg.encZR, hn, Functor.map, Except.map, bind,
        Except.bind, throw, throwThe, MonadExceptOf.throw] at ha
  | xzr => exact absurd rfl hx
  | _ =>
    simp [Insn.toArmInst, Insn.armFields, Reg.encZR, Functor.map, Except.map, bind,
      Except.bind, throw, throwThe, MonadExceptOf.throw] at ha


theorem progBase_of {g : Clif.Function} (hF : FnOk I file g) {lm : Std.HashMap Lbl Nat}
    (hm : labelOffsets (art I g).fa.lines = .ok lm) {m : Arm.ArmState}
    (hp : m.program = (art I g).fb.program (art I g).base) {j : Nat} {i : Insn}
    {t : Option Clif.TrapCode} (hj : (art I g).fa.lines.toList[j]? = some (.ins i t)) :
    progBase m = (art I g).base := by
  obtain ⟨-, w, -, hk⟩ := FnAsm.layout_word hF.layout hm hj rfl
  refine progBase_eq (by rw [hp]; rfl) ?_
  intro h
  have : (art I g).fb.words.size = 0 := by simpa using congrArg List.length h
  simp [this] at hk

theorem wAt_add4 (a : Art) (o : Nat) : wAt a o + 4 = wAt a (o + 4) := by
  simp only [wAt]; rw [BitVec.ofNat_add, BitVec.add_assoc]; rfl

/-- The register of a compiled `adrp` whose word is `adrpW rdN 0`. -/
theorem adrp_reg {env : Env} {i : Insn} {rd : Reg} {rdN : Nat} (hrd : rdN < 31)
    (hi : (∃ n, i = .adrpGot rd n) ∨ ∃ n off, i = .adrp rd n off)
    (hw : i.encode env = .ok (adrpW rdN 0)) :
    rd.encZR.toOption.getD 31#5 = BitVec.ofNat 5 rdN := by
  obtain ⟨a, ha, hd⟩ := Insn.decode_encode hw
  rw [(ExecWords.adrpW_exec hrd (by decide)).1] at hd
  cases hd
  rcases hi with ⟨n, rfl⟩ | ⟨n, off, rfl⟩ <;>
  · cases hv : rd.encZR with
    | error e =>
      simp [Insn.toArmInst, Insn.armFields, hv, Functor.map, Except.map, bind, Except.bind] at ha
    | ok v =>
      simp [Insn.toArmInst, Insn.armFields, hv, Functor.map, Except.map, bind, Except.bind, pure,
        Except.pure, ExecWords.adrpI, Arm.ArmInst.norm] at ha
      simp [Except.toOption, ha]

/-- The end of a pair: the model wrote `x` at the first word, the executable `y` then `x`. -/
theorem sim_pair_end {m e : Arm.ArmState} (h : Sim I m e) (v : BitVec 5) (x y : BitVec 64)
    (p q q' : BitVec 64) :
    Sim I (Arm.w .PC p (Arm.w .PC q (Arm.w (.GPR v) x m)))
      (Arm.w .PC p (Arm.w (.GPR v) x (Arm.w .PC q' (Arm.w (.GPR v) y e)))) := by
  rw [Arm.w_of_w_shadow, Arm.w_of_w_commute (show Arm.StateField.GPR v ≠ .PC by simp),
    Arm.w_of_w_shadow, Arm.w_of_w_shadow]
  exact sim_w (sim_w h _ _) _ _

/-- The step at an instruction's kind of site is the step at the instruction. -/
theorem stepAt_site (i : Insn) (s : Arm.ArmState) :
    stepAt I B file (some (siteOf (prog I) i)) s = stepIns I B file (some i) s := by
  cases i
  case bl n => by_cases h : ((prog I).func? n).isSome <;> simp [siteOf, stepAt, stepIns, h]
  all_goals rfl

theorem step_site {s : Arm.ArmState} {i : Insn}
    (h : siteAt I (Arm.r .PC s) = some (siteOf (prog I) i)) :
    step I B file s = stepIns I B file (some i) s := by
  unfold step; rw [h, stepAt_site]

theorem siteAt_of {M : Nat} {g : Clif.Function} {m : Arm.ArmState} (h : StepOk I B file M g m)
    {i : Insn} (hi : insnAt (art I g).fa (art I g).base (Arm.r .PC m) = some i) :
    siteAt I (Arm.r .PC m) = some (siteOf (prog I) i) := by
  obtain ⟨i', h1, h2, -⟩ := h.site
  rw [hi] at h1; cases h1; exact h2

/-- The first word of an `adrp` pair is a real site. -/
theorem siteOf_pairFirst {P : Clif.Program} {i : Insn} {ty : RelocType} {s : String} {a : Int}
    (h : i.reloc? = some (ty, s, a)) (ht : ty = .adrGotPage ∨ ty = .adrPrelPgHi21) :
    siteOf P i = .real := by
  cases i <;> simp only [Insn.reloc?, reduceCtorEq, Option.some.injEq, Prod.mk.injEq] at h <;>
    first | rfl | (obtain ⟨rfl, -⟩ := h; rcases ht with h' | h' <;> cases h')

theorem pair_first_pc {M : Nat} {g : Clif.Function} (hF : FnOk I file g) {rl : Reloc}
    (hrl : rl ∈ (art I g).fb.relocs) (ht : rl.type = .adrGotPage ∨ rl.type = .adrPrelPgHi21)
    {m e : Arm.ArmState} (hpc : Arm.r .PC m = wAt (art I g) rl.offset)
    (h0 : StepOk I B file M g m) (hs : Sim I m e) :
    Arm.r .PC ((sys I B).mach M g m) = Arm.r .PC (step I B file e) ∧
      Arm.r .ERR ((sys I B).mach M g m) = Arm.r .ERR (step I B file e) := by
  obtain ⟨lm, hm⟩ := FnAsm.layout_labelOffsets hF.layout
  obtain ⟨j, i, t, hj, hi, ho⟩ := (FnAsm.layout_relocs hF.layout rl).1 hrl
  have hR := hF.bin.reloc rl hrl
  have hins : insnAt (art I g).fa (art I g).base (Arm.r .PC m) = some i := by
    rw [hpc, ← ho]; exact insnAt_of_line hF hj
  have hb : progBase m = (art I g).base := progBase_of hF hm h0.program hj
  -- the instruction and the checked words
  obtain ⟨rd, hrd⟩ : ∃ rd : Reg, (rl.type = .adrGotPage ∧ i = .adrpGot rd rl.sym ∧ rl.addend = 0) ∨
      (rl.type = .adrPrelPgHi21 ∧ i = .adrp rd rl.sym rl.addend) := by
    rcases ht with ht | ht <;> rw [ht] at hi <;> cases i <;> simp [Insn.reloc?] at hi
    · exact ⟨_, .inl ⟨ht, by rw [hi.1], hi.2.symm⟩⟩
    · exact ⟨_, .inr ⟨ht, by rw [hi.1, hi.2]⟩⟩
  have hR' : rl.offset % 4 = 0 ∧ ∃ rdN x0 x1, rdN < 31 ∧
      (art I g).fb.words[rl.offset / 4]? = some (adrpW rdN 0) ∧
      (∃ r' ∈ (art I g).fb.relocs, r'.offset = rl.offset + 4 ∧ r'.type = loOf rl.type) ∧
      fileWord file (wAt (art I g) rl.offset) = some x0 ∧
      fileWord file (wAt (art I g) (rl.offset + 4)) = some x1 ∧
      PairOk (Elf.loadMem file) (wAt (art I g) rl.offset).toNat
        (I.symAddr rl.sym rl.addend).toNat rdN (decide (rl.type = .adrGotPage)) x0 x1 := by
    unfold RelocOk at hR
    rcases ht with ht | ht <;> rw [ht] at hR ⊢ <;>
    · obtain ⟨h4, rdN, x0, x1, hlt, hw0, -, ⟨r', hr', hr'o, hr't, -⟩, hx0, hx1, hp⟩ := hR
      exact ⟨h4, rdN, x0, x1, hlt, hw0, ⟨r', hr', hr'o, hr't⟩, hx0, hx1, hp⟩
  obtain ⟨h4, rdN, x0, x1, hlt, hw0, ⟨r', hr', hr'o, hr't⟩, hx0, hx1, hp⟩ := hR'
  -- the register
  obtain ⟨-, w, hw, hk⟩ := FnAsm.layout_word hF.layout hm hj rfl
  rw [ho, hw0] at hk
  cases hk
  have hv : rd.encZR.toOption.getD 31#5 = BitVec.ofNat 5 rdN :=
    adrp_reg hlt (by
      rcases hrd with ⟨-, h, -⟩ | ⟨-, h⟩
      · exact .inl ⟨_, h⟩
      · exact .inr ⟨_, _, h⟩) hw
  -- the model's first step
  have hm1 : (sys I B).mach M g m = Arm.w .PC (Arm.r .PC m + 4)
      (Arm.w (.GPR (BitVec.ofNat 5 rdN)) (I.symAddr rl.sym rl.addend) m) := by
    show ArmStepX (sys I B).Xb ((sys I B).hooks M) (art I g).fa m = _
    rcases hrd with ⟨-, rfl, ha⟩ | ⟨-, rfl⟩
    · simp only [ArmStepX, hb, hins, ha]
      generalize rd.encZR.toOption.getD 31#5 = v at hv ⊢
      subst hv; rfl
    · simp only [ArmStepX, hb, hins]
      generalize rd.encZR.toOption.getD 31#5 = v at hv ⊢
      subst hv; rfl
  -- the executable's first step
  have hpe : Arm.r .PC e = Arm.r .PC m := hs.1 .PC
  have hee : Arm.r .ERR e = .None := (hs.1 .ERR).trans h0.err
  have hP : (Arm.r .PC e).toNat = (wAt (art I g) rl.offset).toNat := by rw [hpe, hpc]
  have hsite0 : siteAt I (Arm.r .PC e) = some (siteOf (prog I) i) := by
    rw [hpe]; exact siteAt_of h0 hins
  have hstep0 : ∀ a, (fileWord file (Arm.r .PC e)).bind Arm.decode_raw_inst = some a →
      step I B file e = Arm.exec_inst a e := fun a ha => by
    rw [step_site hsite0, stepAt_real _ (by rcases hrd with ⟨-, rfl, -⟩ | ⟨-, rfl⟩ <;> simp)
      (by rcases hrd with ⟨-, rfl, -⟩ | ⟨-, rfl⟩ <;> simp)
      (by rcases hrd with ⟨-, rfl, -⟩ | ⟨-, rfl⟩ <;> simp)
      (by rcases hrd with ⟨-, rfl, -⟩ | ⟨-, rfl⟩ <;> simp), realStep_eq hee ha]
  rw [hm1]
  have hfin : ∀ dp : Int, BinCheck.inR (-2 ^ 20) (2 ^ 20) dp = true →
      fileWord file (wAt (art I g) rl.offset) = some (adrpW rdN dp) →
      Arm.r .PC (Arm.w .PC (Arm.r .PC m + 4)
          (Arm.w (.GPR (BitVec.ofNat 5 rdN)) (I.symAddr rl.sym rl.addend) m)) =
        Arm.r .PC (step I B file e) ∧
      Arm.r .ERR (Arm.w .PC (Arm.r .PC m + 4)
          (Arm.w (.GPR (BitVec.ofNat 5 rdN)) (I.symAddr rl.sym rl.addend) m)) =
        Arm.r .ERR (step I B file e) := by
    intro dp hr hx
    obtain ⟨ha0, hx0e⟩ := ExecWords.adrpW_exec hlt hr
    rw [hstep0 _ (by rw [hpe, hpc, hx, Option.bind_some]; exact ha0), hx0e]
    refine ⟨by rw [Arm.r_of_w_same, Arm.r_of_w_same, hpe], ?_⟩
    rw [Arm.r_of_w_different (show Arm.StateField.ERR ≠ .PC by simp),
      Arm.r_of_w_different (show Arm.StateField.ERR ≠ .GPR (BitVec.ofNat 5 rdN) by simp),
      Arm.r_of_w_different (show Arm.StateField.ERR ≠ .PC by simp),
      Arm.r_of_w_different (show Arm.StateField.ERR ≠ .GPR (BitVec.ofNat 5 rdN) by simp), hs.1]
  cases hp with
  | adrpAdd hr e0 e1 => subst e0; exact hfin _ hr hx0
  | adrpLdr G hgot h8 hr e0 e1 hG => subst e0; exact hfin _ hr hx0


/-- **A pair**: the model's two steps from the first word of an `adrp` pair, against the
executable's two steps on the resolved words. -/
theorem pair_step {M : Nat} {g : Clif.Function} (hF : FnOk I file g) {rl : Reloc}
    (hrl : rl ∈ (art I g).fb.relocs) (ht : rl.type = .adrGotPage ∨ rl.type = .adrPrelPgHi21)
    {m e : Arm.ArmState} (hpc : Arm.r .PC m = wAt (art I g) rl.offset)
    (h0 : StepOk I B file M g m) (h1 : StepOk I B file M g ((sys I B).mach M g m))
    (hs : Sim I m e) :
    Sim I ((sys I B).mach M g ((sys I B).mach M g m)) (step I B file (step I B file e)) := by
  obtain ⟨lm, hm⟩ := FnAsm.layout_labelOffsets hF.layout
  obtain ⟨j, i, t, hj, hi, ho⟩ := (FnAsm.layout_relocs hF.layout rl).1 hrl
  have hR := hF.bin.reloc rl hrl
  have hins : insnAt (art I g).fa (art I g).base (Arm.r .PC m) = some i := by
    rw [hpc, ← ho]; exact insnAt_of_line hF hj
  have hb : progBase m = (art I g).base := progBase_of hF hm h0.program hj
  -- the instruction and the checked words
  obtain ⟨rd, hrd⟩ : ∃ rd : Reg, (rl.type = .adrGotPage ∧ i = .adrpGot rd rl.sym ∧ rl.addend = 0) ∨
      (rl.type = .adrPrelPgHi21 ∧ i = .adrp rd rl.sym rl.addend) := by
    rcases ht with ht | ht <;> rw [ht] at hi <;> cases i <;> simp [Insn.reloc?] at hi
    · exact ⟨_, .inl ⟨ht, by rw [hi.1], hi.2.symm⟩⟩
    · exact ⟨_, .inr ⟨ht, by rw [hi.1, hi.2]⟩⟩
  have hR' : rl.offset % 4 = 0 ∧ ∃ rdN x0 x1, rdN < 31 ∧
      (art I g).fb.words[rl.offset / 4]? = some (adrpW rdN 0) ∧
      (∃ r' ∈ (art I g).fb.relocs, r'.offset = rl.offset + 4 ∧ r'.type = loOf rl.type) ∧
      fileWord file (wAt (art I g) rl.offset) = some x0 ∧
      fileWord file (wAt (art I g) (rl.offset + 4)) = some x1 ∧
      PairOk (Elf.loadMem file) (wAt (art I g) rl.offset).toNat
        (I.symAddr rl.sym rl.addend).toNat rdN (decide (rl.type = .adrGotPage)) x0 x1 := by
    unfold RelocOk at hR
    rcases ht with ht | ht <;> rw [ht] at hR ⊢ <;>
    · obtain ⟨h4, rdN, x0, x1, hlt, hw0, -, ⟨r', hr', hr'o, hr't, -⟩, hx0, hx1, hp⟩ := hR
      exact ⟨h4, rdN, x0, x1, hlt, hw0, ⟨r', hr', hr'o, hr't⟩, hx0, hx1, hp⟩
  obtain ⟨h4, rdN, x0, x1, hlt, hw0, ⟨r', hr', hr'o, hr't⟩, hx0, hx1, hp⟩ := hR'
  -- the register
  obtain ⟨-, w, hw, hk⟩ := FnAsm.layout_word hF.layout hm hj rfl
  rw [ho, hw0] at hk
  cases hk
  have hv : rd.encZR.toOption.getD 31#5 = BitVec.ofNat 5 rdN :=
    adrp_reg hlt (by
      rcases hrd with ⟨-, h, -⟩ | ⟨-, h⟩
      · exact .inl ⟨_, h⟩
      · exact .inr ⟨_, _, h⟩) hw
  -- the model's first step
  have hm1 : (sys I B).mach M g m = Arm.w .PC (Arm.r .PC m + 4)
      (Arm.w (.GPR (BitVec.ofNat 5 rdN)) (I.symAddr rl.sym rl.addend) m) := by
    show ArmStepX (sys I B).Xb ((sys I B).hooks M) (art I g).fa m = _
    rcases hrd with ⟨-, rfl, ha⟩ | ⟨-, rfl⟩
    · simp only [ArmStepX, hb, hins, ha]
      generalize rd.encZR.toOption.getD 31#5 = v at hv ⊢
      subst hv; rfl
    · simp only [ArmStepX, hb, hins]
      generalize rd.encZR.toOption.getD 31#5 = v at hv ⊢
      subst hv; rfl
  -- the partner line
  obtain ⟨j', i', t', hj', hi', ho'⟩ := (FnAsm.layout_relocs hF.layout r').1 hr'
  have hpc1 : Arm.r .PC ((sys I B).mach M g m) = wAt (art I g) (rl.offset + 4) := by
    rw [hm1, Arm.r_of_w_same, hpc, wAt_add4]
  have hins' : insnAt (art I g).fa (art I g).base (Arm.r .PC ((sys I B).mach M g m)) = some i' := by
    rw [hpc1, ← hr'o, ← ho']; exact insnAt_of_line hF hj'
  have hi'' : (∃ a b c, i' = .ldrGotLo12 a b c) ∨ ∃ a b c d, i' = .addLo12 a b c d := by
    rcases ht with ht | ht <;> rw [hr't, ht] at hi' <;> cases i' <;> simp [Insn.reloc?, loOf] at hi'
    · exact .inl ⟨_, _, _, rfl⟩
    · exact .inr ⟨_, _, _, _, rfl⟩
  have hb1 : progBase ((sys I B).mach M g m) = (art I g).base := by
    rw [← hb, hm1]; simp only [progBase, Arm.w_program]
  have hm2 : (sys I B).mach M g ((sys I B).mach M g m) =
      Arm.w .PC (Arm.r .PC ((sys I B).mach M g m) + 4) ((sys I B).mach M g m) := by
    show ArmStepX (sys I B).Xb ((sys I B).hooks M) (art I g).fa _ = _
    rcases hi'' with ⟨a, b, c, rfl⟩ | ⟨a, b, c, d, rfl⟩ <;> simp only [ArmStepX, hb1, hins']
  -- the executable's first step
  have hpe : Arm.r .PC e = Arm.r .PC m := hs.1 .PC
  have hee : Arm.r .ERR e = .None := (hs.1 .ERR).trans h0.err
  have hP : (Arm.r .PC e).toNat = (wAt (art I g) rl.offset).toNat := by rw [hpe, hpc]
  have hsite0 : siteAt I (Arm.r .PC e) = some (siteOf (prog I) i) := by
    rw [hpe]; exact siteAt_of h0 hins
  have hsite1 : ∀ e1 : Arm.ArmState, Arm.r .PC e1 = Arm.r .PC ((sys I B).mach M g m) →
      siteAt I (Arm.r .PC e1) = some (siteOf (prog I) i') := fun e1 h => by
        rw [h]; exact siteAt_of h1 hins'
  have hstep0 : ∀ a, (fileWord file (Arm.r .PC e)).bind Arm.decode_raw_inst = some a →
      step I B file e = Arm.exec_inst a e := fun a ha => by
    rw [step_site hsite0, stepAt_real _ (by rcases hrd with ⟨-, rfl, -⟩ | ⟨-, rfl⟩ <;> simp)
      (by rcases hrd with ⟨-, rfl, -⟩ | ⟨-, rfl⟩ <;> simp)
      (by rcases hrd with ⟨-, rfl, -⟩ | ⟨-, rfl⟩ <;> simp)
      (by rcases hrd with ⟨-, rfl, -⟩ | ⟨-, rfl⟩ <;> simp), realStep_eq hee ha]
  have hstep1 : ∀ e1 a, Arm.r .PC e1 = Arm.r .PC ((sys I B).mach M g m) → Arm.r .ERR e1 = .None →
      (fileWord file (Arm.r .PC e1)).bind Arm.decode_raw_inst = some a →
      step I B file e1 = Arm.exec_inst a e1 := fun e1 a h he ha => by
    rw [step_site (hsite1 e1 h), stepAt_real _ (by rcases hi'' with ⟨_, _, _, rfl⟩ | ⟨_, _, _, _, rfl⟩ <;> simp)
      (by rcases hi'' with ⟨_, _, _, rfl⟩ | ⟨_, _, _, _, rfl⟩ <;> simp)
      (by rcases hi'' with ⟨_, _, _, rfl⟩ | ⟨_, _, _, _, rfl⟩ <;> simp)
      (by rcases hi'' with ⟨_, _, _, rfl⟩ | ⟨_, _, _, _, rfl⟩ <;> simp), realStep_eq he ha]
  have hT : BitVec.ofNat 64 (I.symAddr rl.sym rl.addend).toNat = I.symAddr rl.sym rl.addend := by
    simp
  rw [hm2, hm1]
  cases hp with
  | adrpAdd hr e0 e1 =>
    subst e0 e1
    obtain ⟨ha0, hx0e⟩ := ExecWords.adrpW_exec hlt hr
    have hs0 := hstep0 _ (by rw [hpe, hpc, hx0, Option.bind_some]; exact ha0)
    rw [hx0e, hP] at hs0
    obtain ⟨ha1, hx1e⟩ := ExecWords.addW_exec hlt hlt (Nat.mod_lt _ (by decide))
    rw [hs0, hstep1 _ _ (by rw [Arm.r_of_w_same, hpe, hpc1, ← wAt_add4, hpc])
      (by rw [Arm.r_of_w_different (show Arm.StateField.ERR ≠ .PC by simp),
        Arm.r_of_w_different (show Arm.StateField.ERR ≠ .GPR (BitVec.ofNat 5 rdN) by simp), hee])
      (by rw [Arm.r_of_w_same, hpe, hpc, wAt_add4, hx1, Option.bind_some]; exact ha1), hx1e,
      Arm.r_of_w_different (show Arm.StateField.GPR (BitVec.ofNat 5 rdN) ≠ .PC by simp),
      ]
    simp only [Arm.r_of_w_same, ExecWords.adrp_add_val, hT, hpe]
    exact sim_pair_end hs _ _ _ _ _ _
  | adrpLdr G hgot h8 hr e0 e1 hG =>
    subst e0 e1
    have hgt : rl.type = .adrGotPage := by simpa using hgot
    obtain ⟨ha0, hx0e⟩ := ExecWords.adrpW_exec hlt hr
    have hs0 := hstep0 _ (by rw [hpe, hpc, hx0, Option.bind_some]; exact ha0)
    rw [hx0e, hP] at hs0
    obtain ⟨ha1, hx1e⟩ := ExecWords.ldrW_exec (imm := G % 4096 / 8) hlt hlt (by omega)
    have hgot' := h1.got rl hrl hgt hpc1 rdN G hlt h8 hr hx0 hx1
    have hval : Arm.read_mem_bytes 8 (BitVec.ofNat 64 G) e =
        BitVec.ofNat 64 (I.symAddr rl.sym rl.addend).toNat := by
      obtain ⟨hrb, -⟩ := readN_bytes hG
      rw [← hrb]
      refine rmb_congr 8 _ fun k hk => ?_
      obtain ⟨hnr, hmem⟩ := hgot' k hk
      rw [hs.2 _ hnr, show m.mem _ = ((sys I B).mach M g m).mem _ by
        rw [hm1, Arm.ArmState.mem_w_eq_mem, Arm.ArmState.mem_w_eq_mem], hmem]
      simp [stOf, setMem]
    rw [hs0, hstep1 _ _ (by rw [Arm.r_of_w_same, hpe, hpc1, ← wAt_add4, hpc])
      (by rw [Arm.r_of_w_different (show Arm.StateField.ERR ≠ .PC by simp),
        Arm.r_of_w_different (show Arm.StateField.ERR ≠ .GPR (BitVec.ofNat 5 rdN) by simp), hee])
      (by rw [Arm.r_of_w_same, hpe, hpc, wAt_add4, hx1, Option.bind_some]; exact ha1), hx1e,
      Arm.r_of_w_different (show Arm.StateField.GPR (BitVec.ofNat 5 rdN) ≠ .PC by simp),
      ]
    simp only [Arm.r_of_w_same, ExecWords.adrp_ldr_addr h8, Arm.read_mem_bytes_of_w, hval, hT, hpe]
    exact sim_pair_end hs _ _ _ _ _ _


/-! ## One step of the model against the executable -/

/-- An instruction without relocation: the same word, one step each. -/
theorem plain_step {M : Nat} {g : Clif.Function} (hF : FnOk I file g) {m e : Arm.ArmState}
    (h0 : StepOk I B file M g m) (hs : Sim I m e) {i : Insn}
    (hins : insnAt (art I g).fa (art I g).base (Arm.r .PC m) = some i) (hh : i.hooked = false) :
    Sim I ((sys I B).mach M g m) (step I B file e) := by
  obtain ⟨lm, hm⟩ := FnAsm.layout_labelOffsets hF.layout
  obtain ⟨j, t, hj, hpc⟩ := insnAt_spec hins
  have hr : i.reloc? = none := by
    obtain ⟨i', h1, -, h3⟩ := h0.site
    rw [hins] at h1; cases h1
    rcases h3 with h | h
    · exact h
    · rw [hh] at h; cases h
  obtain ⟨a, ha, hstep⟩ := armStepX_ins (X := (sys I B).Xb) (H := (sys I B).hooks M) hF.layout hm
    (by have := hF.fits; omega) hj hh h0.program hpc.symm h0.err
  obtain ⟨w, hw, hf⟩ := fileWord_plain hF hm hj hr
  have hd := Insn.decode_encode_of ha hw
  have hpe : Arm.r .PC e = Arm.r .PC m := hs.1 .PC
  have hfa : (fileWord file (Arm.r .PC m)).bind Arm.decode_raw_inst = some a := by
    rw [← hpc]; show (fileWord file (wAt _ _)).bind _ = _; rw [hf, Option.bind_some]; exact hd
  have hex : step I B file e = Arm.exec_inst a e := by
    rw [step_site (by rw [hpe]; exact siteAt_of h0 hins),
      stepAt_real _ (fun n h => by cases h; simp [Insn.hooked] at hh)
        (fun n h => by cases h; simp [Insn.hooked] at hh)
        (fun _ _ h => by cases h; simp [Insn.hooked] at hh)
        (fun _ _ _ h => by cases h; simp [Insn.hooked] at hh),
      realStep_eq ((hs.1 .ERR).trans h0.err) (by rw [hpe]; exact hfa)]
  show Sim I (ArmStepX (sys I B).Xb ((sys I B).hooks M) (art I g).fa m) _
  rw [hstep, hex]
  exact h0.insn i hins hh a hfa e hs

theorem hooks_tls (L : LinkSys) (M : Nat) : (L.hooks M).tls = L.Hb.tls := by
  cases M <;> rfl

/-- The executable's `blr` target is the model's. -/
theorem blrTarget_sim {m e : Arm.ArmState} (hs : Sim I m e)
    (hpl : ∀ k < 4, ¬ RelocAtWithResults I I.results (Arm.r .PC m + BitVec.ofNat 64 k)) : blrTarget e = blrTarget m := by
  have hw : Arm.read_mem_bytes 4 (Arm.r .PC e) e = Arm.read_mem_bytes 4 (Arm.r .PC m) m := by
    rw [hs.1 .PC]; exact rmb_congr 4 _ fun k hk => hs.2 _ (hpl k hk)
  unfold blrTarget
  rw [hw]
  split <;> simp [hs.1]

/-- The steps at a call of outside code and at the TLS sequence: the same hook. -/
theorem hook_step {M : Nat} {g : Clif.Function} (hF : FnOk I file g) {m e : Arm.ArmState}
    (h0 : StepOk I B file M g m) (hs : Sim I m e) {i : Insn}
    (hins : insnAt (art I g).fa (art I g).base (Arm.r .PC m) = some i)
    (hk : (∃ n, i = .bl n ∧ (prog I).func? n = none) ∨
      (∃ x, i = .blr x ∧ (blrTarget m).bind (symCallee (sys I B).Xb (prog I)) = none) ∨
      (∃ a b, i = .adrpTlsDesc a b) ∨ ∃ a b c, i = .ldrTlsDescLo12 a b c) :
    Sim I ((sys I B).mach M g m) (step I B file e) := by
  obtain ⟨lm, hm⟩ := FnAsm.layout_labelOffsets hF.layout
  obtain ⟨j, t, hj, hpc⟩ := insnAt_spec hins
  have hb : progBase m = (art I g).base := progBase_of hF hm h0.program hj
  have hpe : Arm.r .PC e = Arm.r .PC m := hs.1 .PC
  have hse : step I B file e = stepIns I B file (some i) e :=
    step_site (by rw [hpe]; exact siteAt_of h0 hins)
  show Sim I (ArmStepX (sys I B).Xb ((sys I B).hooks M) (art I g).fa m) _
  rw [hse]
  rcases hk with ⟨n, rfl, hn⟩ | ⟨x, rfl, hn⟩ | ⟨a, b, rfl⟩ | ⟨a, b, c, rfl⟩
  · simp only [ArmStepX, hb, hins, LinkSys.hooks_call, LinkSys.callHook, stepIns]
    rw [show (sys I B).P.func? n = none from hn, show (prog I).func? n = none from hn]
    exact h0.call _ e (.inl ⟨n, hins, hn, rfl⟩) hs
  · have hpl := h0.plain _ hins rfl
    simp only [ArmStepX, hb, hins, LinkSys.hooks_call, LinkSys.callHook, stepIns,
      blrTarget_sim hs hpl]
    rw [show ((blrTarget m).bind (symCallee (sys I B).Xb (sys I B).P)) = none from hn,
      show ((blrTarget m).bind (symCallee (sys I B).Xb (prog I))) = none from hn]
    exact h0.call _ e (.inr ⟨⟨x, hins⟩, hn, rfl⟩) hs
  · simp only [ArmStepX, hb, hins, stepIns, hpe]
    exact sim_w hs _ _
  · simp only [ArmStepX, hb, hins, stepIns, hooks_tls]
    exact h0.tls a b c e hins hs

theorem add_ofInt_sub (x : BitVec 64) (N : Nat) :
    x + BitVec.ofInt 64 ((N : Int) - x.toNat) = BitVec.ofNat 64 N := by
  apply BitVec.eq_of_toNat_eq
  have hx := x.isLt
  simp only [BitVec.toNat_add, BitVec.toNat_ofInt, BitVec.toNat_ofNat]
  omega

/-- **A `bl`/`blr` of a function `h` of the program**: the executable's word enters `h` in the
model's callee entry state (up to the program field). -/
theorem call_enter {M : Nat} {g h : Clif.Function} (hF : FnOk I file g) (hFh : FnOk I file h)
    {m e : Arm.ArmState} (h0 : StepOk I B file M g m) (hs : Sim I m e)
    (hc : CallsAt I B g m h) : Sim I (enterAt (art I h) m) (step I B file e) := by
  obtain ⟨lm, hm⟩ := FnAsm.layout_labelOffsets hF.layout
  obtain ⟨i0, hi0, -, -⟩ := h0.site
  obtain ⟨j, t, hj, hpc⟩ := insnAt_spec hi0
  have hb : progBase m = (art I g).base := progBase_of hF hm h0.program hj
  have hpe : Arm.r .PC e = Arm.r .PC m := hs.1 .PC
  have hee : Arm.r .ERR e = .None := (hs.1 .ERR).trans h0.err
  have hen : ∀ T : BitVec 64, T = (art I h).base →
      Sim I (enterAt (art I h) m) (Arm.w .PC T (Arm.w (.GPR 30#5) (Arm.r .PC e + 4) e)) := by
    intro T hT
    rw [hT, hpe]
    exact sim_w (sim_w (sim_set_program _ hs) _ _) _ _
  simp only [CallsAt, hb] at hc
  rcases hc with ⟨n, hins, hn⟩ | ⟨⟨x, hins⟩, hcal⟩
  · -- `bl`: the resolved `blW` of `R_AARCH64_CALL26`
    rw [hins] at hi0; cases hi0
    have hrl := line_reloc hF hj (show (Insn.bl n).reloc? = some (.call26, n, 0) from rfl)
    have hR := hF.bin.reloc _ hrl
    simp only [RelocOk] at hR
    obtain ⟨-, -, hrange, hword⟩ := hR
    obtain ⟨hd, hx⟩ := ExecWords.blW_exec hrange
    have hst : step I B file e = Arm.exec_inst (ExecWords.blI ((I.baseOf n : Int) -
        (wAt (art I g) (lineOffset (art I g).fa.lines.toList j)).toNat)) e := by
      rw [step_site (by rw [hpe]; exact siteAt_of h0 hins)]
      simp only [stepIns, hn, Option.isSome_some, ↓reduceIte]
      exact realStep_eq hee (by rw [hpe, ← hpc]; show (readN _ 4 (wAt _ _)).bind _ = _; rw [hword, Option.bind_some]; exact hd)
    rw [hst, hx]
    refine hen _ ?_
    rw [hpe, ← hpc, show (art I g).base + BitVec.ofNat 64 (lineOffset (art I g).fa.lines.toList j) =
      wAt (art I g) (lineOffset (art I g).fa.lines.toList j) from rfl, add_ofInt_sub,
      hFh.base, (Clif.Program.func?_some hn).2]
  · -- `blr`: the register holds the callee's address
    rw [hins] at hi0; cases hi0
    obtain ⟨hx, hfw, hsym⟩ := h0.blr x h hins hcal
    obtain ⟨w, rn, hrn, hw, hdw⟩ := blr_word hF hm hj hx
    rw [show wAt (art I g) (lineOffset (art I g).fa.lines.toList j) = Arm.r .PC m from hpc] at hw
    rw [hw, Option.some.injEq] at hfw
    have htgt : blrTarget m = some (Arm.r (.GPR rn) m) := by
      unfold blrTarget; rw [← hfw, hdw]
    rw [htgt] at hcal
    have hcal' := List.find?_some hcal
    simp only [beq_iff_eq] at hcal'
    have hst : step I B file e = Arm.exec_inst
        (.BR (.Uncond_branch_reg { opc := 1, op2 := 31, op3 := 0, Rn := rn, op4 := 0 })) e := by
      rw [step_site (by rw [hpe]; exact siteAt_of h0 hins)]
      have hpl := h0.plain _ hins rfl
      simp only [stepIns, blrTarget_sim hs hpl, htgt]
      rw [show (Option.some (Arm.r (.GPR rn) m)).bind (symCallee (sys I B).Xb (prog I)) = some h
        from hcal]
      simp only [Option.isSome_some, ↓reduceIte]
      exact realStep_eq hee (by rw [hpe, hw, Option.bind_some]; exact hdw)
    rw [hst, ExecWords.blr_exec rn hrn]
    refine hen _ ?_
    rw [hs.1, ← hsym]
    exact hcal'.symm

/-! ## Static control-flow facts -/

/-- The facts of `RelocOk` for the page relocation of a pair that the control-flow lemmas use. -/
theorem pair_facts {g : Clif.Function} (hF : FnOk I file g) {rl : Reloc}
    (hrl : rl ∈ (art I g).fb.relocs) (ht : rl.type = .adrGotPage ∨ rl.type = .adrPrelPgHi21) :
    rl.offset % 4 = 0 ∧ rl.offset + 4 < 4 * (art I g).fb.words.size ∧
      ∃ r' ∈ (art I g).fb.relocs, r'.offset = rl.offset + 4 ∧ r'.type = loOf rl.type := by
  have hR := hF.bin.reloc rl hrl
  unfold RelocOk at hR
  rcases ht with ht | ht <;> rw [ht] at hR ⊢ <;>
  · obtain ⟨h4, rdN, x0, x1, -, -, hw1, ⟨r', hr', hr'o, hr't, -⟩, -⟩ := hR
    have := (Array.getElem?_eq_some_iff.1 hw1).1
    exact ⟨h4, by omega, r', hr', hr'o, hr't⟩

/-- The entry of a function is no second word of a pair. -/
theorem not_second_base {g : Clif.Function} (hF : FnOk I file g) :
    ¬ Second I g (art I g).base := by
  rintro ⟨rl, hrl, ht, he⟩
  obtain ⟨-, hlt, -⟩ := pair_facts hF hrl ht
  have hfit := hF.fits
  have h0 : wAt (art I g) 0 = wAt (art I g) (rl.offset + 4) := by
    rw [← he]; simp [wAt]
  have := wAt_inj (by omega) (by omega) h0
  omega

/-- The first word of a pair is no second word. -/
theorem first_not_second {g : Clif.Function} (hF : FnOk I file g) {rl : Reloc}
    (hrl : rl ∈ (art I g).fb.relocs) (ht : rl.type = .adrGotPage ∨ rl.type = .adrPrelPgHi21) :
    ¬ Second I g (wAt (art I g) rl.offset) := by
  rintro ⟨rl2, hrl2, ht2, he⟩
  obtain ⟨-, hlt, -⟩ := pair_facts hF hrl ht
  obtain ⟨-, hlt2, r', hr', hr'o, hr't⟩ := pair_facts hF hrl2 ht2
  have hfit := hF.fits
  have hoff := wAt_inj (by omega) (by omega) he
  obtain ⟨j, i, t, hj, hi, ho⟩ := (FnAsm.layout_relocs hF.layout rl).1 hrl
  obtain ⟨j', i', t', hj', hi', ho'⟩ := (FnAsm.layout_relocs hF.layout r').1 hr'
  have := line_unique hj hj' (by omega)
  subst this
  rw [hi] at hi'
  have := congrArg (fun x => x.map Prod.fst) hi'
  simp only [Option.map_some] at this
  injection this with e
  rw [hr't] at e
  rcases ht with h | h <;> rcases ht2 with h2 | h2 <;> rw [h, h2] at e <;> cases e

/-- An `add`/`ldr` of a pair is at a second word. -/
theorem second_of_lo12 {g : Clif.Function} (hF : FnOk I file g) {pc : BitVec 64} {i : Insn}
    (hins : insnAt (art I g).fa (art I g).base pc = some i)
    (hk : (∃ a b c, i = .ldrGotLo12 a b c) ∨ ∃ a b c d, i = .addLo12 a b c d) :
    Second I g pc := by
  obtain ⟨j, t, hj, hpc⟩ := insnAt_spec hins
  obtain ⟨ty, s, ad, hr, hty⟩ : ∃ ty s ad, i.reloc? = some (ty, s, ad) ∧
      (ty = .ld64GotLo12Nc ∨ ty = .addAbsLo12Nc) := by
    rcases hk with ⟨a, b, c, rfl⟩ | ⟨a, b, c, d, rfl⟩
    · exact ⟨_, _, _, rfl, .inl rfl⟩
    · exact ⟨_, _, _, rfl, .inr rfl⟩
  have hR := hF.bin.reloc _ (line_reloc hF hj hr)
  unfold RelocOk at hR
  rcases hty with rfl | rfl <;>
  · obtain ⟨-, r', hr', ho, ht⟩ := hR
    exact ⟨r', hr', ht, by rw [← hpc]; show _ = wAt _ _; rw [ho]; rfl⟩

/-- The model's step at the first word of a pair lands on its second word. -/
theorem adrp_lands {M : Nat} {g : Clif.Function} (hF : FnOk I file g) {m : Arm.ArmState}
    (h0 : StepOk I B file M g m) {i : Insn}
    (hins : insnAt (art I g).fa (art I g).base (Arm.r .PC m) = some i)
    (hk : (∃ a b, i = .adrpGot a b) ∨ ∃ a b c, i = .adrp a b c) :
    Second I g (Arm.r .PC ((sys I B).mach M g m)) := by
  obtain ⟨lm, hm⟩ := FnAsm.layout_labelOffsets hF.layout
  obtain ⟨j, t, hj, hpc⟩ := insnAt_spec hins
  have hb : progBase m = (art I g).base := progBase_of hF hm h0.program hj
  obtain ⟨ty, s, ad, hr, hty⟩ : ∃ ty s ad, i.reloc? = some (ty, s, ad) ∧
      (ty = .adrGotPage ∨ ty = .adrPrelPgHi21) := by
    rcases hk with ⟨a, b, rfl⟩ | ⟨a, b, c, rfl⟩
    · exact ⟨_, _, _, rfl, .inl rfl⟩
    · exact ⟨_, _, _, rfl, .inr rfl⟩
  refine ⟨_, line_reloc hF hj hr, hty, ?_⟩
  show _ = wAt _ _
  rw [← wAt_add4, show wAt (art I g) (lineOffset (art I g).fa.lines.toList j) = Arm.r .PC m from hpc]
  show Arm.r .PC (ArmStepX (sys I B).Xb ((sys I B).hooks M) (art I g).fa m) = _
  rcases hk with ⟨a, b, rfl⟩ | ⟨a, b, c, rfl⟩ <;> simp only [ArmStepX, hb, hins, Arm.r_of_w_same]

/-- The model's step at a call of a function `h` of the program: the linked call (depth `M + 1`),
an error (depth `0`). -/
theorem mach_call {M : Nat} {g h : Clif.Function} {m : Arm.ArmState} (hc : CallsAt I B g m h) :
    (sys I B).mach M g m = (sys I B).pcall M h m := by
  show ArmStepX (sys I B).Xb ((sys I B).hooks M) (art I g).fa m = _
  rcases hc with ⟨n, hins, hn⟩ | ⟨⟨x, hins⟩, hcal⟩
  · simp only [ArmStepX, hins, LinkSys.hooks_call, LinkSys.callHook]
    rw [show (sys I B).P.func? n = some h from hn]
  · simp only [ArmStepX, hins, LinkSys.hooks_call, LinkSys.callHook]
    rw [show (blrTarget m).bind (symCallee (sys I B).Xb (sys I B).P) = some h from hcal]

theorem callee_mem {g h : Clif.Function} {m : Arm.ArmState} (hc : CallsAt I B g m h) :
    h ∈ (prog I).funcs := by
  rcases hc with ⟨n, -, hn⟩ | ⟨-, hcal⟩
  · exact (Clif.Program.func?_some hn).1
  · obtain ⟨a, -, ha⟩ := Option.bind_eq_some_iff.1 hcal
    exact List.mem_of_find?_eq_some ha


/-- The return address of a call of `h` (the word after the `bl`/`blr`) is no second word of a
pair of `h` reached in `h`'s activation: its first word would be the call's word. -/
theorem ret_not_second (hF : ∀ g ∈ (prog I).funcs, FnOk I file g) {M M' : Nat}
    {g h : Clif.Function} (hg : g ∈ (prog I).funcs) (hh : h ∈ (prog I).funcs) {m : Arm.ArmState}
    (hok0 : StepOk I B file M g m) (hc : CallsAt I B g m h)
    (hrun' : RunOk I B file M' h (enterAt (art I h) m)) {N : Nat}
    (hN : RetOf (art I h) m (runX ((sys I B).mach M' h) N (enterAt (art I h) m)))
    (hmin : ∀ j < N, ¬ RetOf (art I h) m (runX ((sys I B).mach M' h) j (enterAt (art I h) m))) :
    ¬ Second I h (Arm.r .PC (runX ((sys I B).mach M' h) N (enterAt (art I h) m))) := by
  rintro ⟨rl, hrl, ht, he⟩
  have hFh := hF h hh
  cases N with
  | zero => exact not_second_base hFh ⟨rl, hrl, ht, (pc_enterAt (art I h) m).symm.trans he⟩
  | succ N1 =>
  have hokc := hrun' _ _ _ (Reach.act (k := N1) fun j hj => fun hr => hmin j (by omega) (returned_iff.2 hr))
  have hpc1 := hokc.cf rl hrl ht (by rw [← runX_succ' ((sys I B).mach M' h) N1]; exact he)
  -- the first word's instruction
  obtain ⟨j, i1, t, hj, hi, ho⟩ := (FnAsm.layout_relocs hFh.layout rl).1 hrl
  have hins1 : insnAt (art I h).fa (art I h).base (wAt (art I h) rl.offset) = some i1 := by
    rw [← ho]; exact insnAt_of_line hFh hj
  have hs1 : siteAt I (wAt (art I h) rl.offset) = some (siteOf (prog I) i1) := by
    rw [← hpc1] at hins1 ⊢; exact siteAt_of hokc hins1
  -- the call's word is there
  have hpcm : Arm.r .PC m = wAt (art I h) rl.offset := by
    have h2 : Arm.r .PC m + 4 = wAt (art I h) rl.offset + 4 := by rw [← hN.1, he, wAt_add4]
    exact (BitVec.add_left_inj _).mp h2
  obtain ⟨lm, hm⟩ := FnAsm.layout_labelOffsets (hF g hg).layout
  obtain ⟨i0, hi0, hs0, -⟩ := hok0.site
  obtain ⟨j0, t0, hj0, -⟩ := insnAt_spec hi0
  have hb := progBase_of (hF g hg) hm hok0.program hj0
  simp only [CallsAt, hb] at hc
  rw [hpcm, hs1, siteOf_pairFirst hi ht] at hs0
  rcases hc with ⟨n, hins, hn⟩ | ⟨⟨x, hins⟩, -⟩ <;> rw [hins] at hi0 <;> cases hi0
  · simp [siteOf, hn] at hs0
  · simp [siteOf] at hs0

end Lemmas

/-! ## The simulation -/

/-- **The simulation of the model's activations at depth `M`** by the executable machine: from
related entry states, every state of the activation before its return that is not a pair's
second word is simulated by a state of the executable's run. -/
def ActSim (I : SemanticStackBound.CompilerInput) (B : BaseEnv) (file : ByteArray) (M : Nat) : Prop :=
  ∀ g c e, g ∈ (prog I).funcs → Arm.r .PC c = (art I g).base → Sim I c e → RunOk I B file M g c →
    ∀ k, (∀ j < k, ¬ Returned (art I g) c (runX ((sys I B).mach M g) j c)) →
    ¬ Second I g (Arm.r .PC (runX ((sys I B).mach M g) k c)) →
    ∃ k', Sim I (runX ((sys I B).mach M g) k c) (runX (step I B file) k' e)

section Core

variable {I : SemanticStackBound.CompilerInput} {B : BaseEnv} {file : ByteArray}

theorem junk_contra {M : Nat} {g : Clif.Function} {c : Arm.ArmState} (hrun : RunOk I B file M g c)
    {k : Nat} (hret : ∀ j < k + 1, ¬ Returned (art I g) c (runX ((sys I B).mach M g) j c))
    (hj : runX ((sys I B).mach M g) (k + 1) c = junkAt (runX ((sys I B).mach M g) k c)) : False := by
  have herr : Arm.r .ERR (runX ((sys I B).mach M g) (k + 1) c) ≠ .None := by
    rw [hj]; simp [junkAt, Arm.r_of_w_same]
  have hok := hrun _ _ _ (Reach.act (k := k + 1) fun j hj' => by
    rcases Nat.lt_or_ge j (k + 1) with h | h
    · exact hret j h
    · obtain rfl : j = k + 1 := by omega
      exact fun hr => herr hr.2.1)
  exact herr hok.err

theorem act_core (hF : ∀ g ∈ (prog I).funcs, FnOk I file g) (M : Nat)
    (hcall : ∀ M', M = M' + 1 → ActSim I B file M') : ActSim I B file M := by
  intro g c e hg hpc hsim hrun k
  induction k using Nat.strongRecOn with
  | ind k ih =>
  intro hret hsec
  have hFg := hF g hg
  have hok : ∀ j, (∀ j' ≤ j, ¬ Returned (art I g) c (runX ((sys I B).mach M g) j' c)) →
      StepOk I B file M g (runX ((sys I B).mach M g) j c) := fun j hj =>
    hrun _ _ _ (Reach.act hj)
  cases k with
  | zero => exact ⟨0, hsim⟩
  | succ k0 =>
  have hok0 : StepOk I B file M g (runX ((sys I B).mach M g) k0 c) :=
    hok k0 fun j hj => hret j (by omega)
  rw [runX_succ'] at hsec ⊢
  by_cases hs : Second I g (Arm.r .PC (runX ((sys I B).mach M g) k0 c))
  · -- the second word of a pair: two steps from its first word
    obtain ⟨rl, hrl, ht, he⟩ := hs
    cases k0 with
    | zero => exact (not_second_base hFg ⟨rl, hrl, ht, hpc.symm.trans he⟩).elim
    | succ k1 =>
    have hok1 : StepOk I B file M g (runX ((sys I B).mach M g) k1 c) :=
      hok k1 fun j hj => hret j (by omega)
    have hpc1 := hok1.cf rl hrl ht (by rw [← runX_succ' ((sys I B).mach M g) k1]; exact he)
    obtain ⟨k', hk'⟩ := ih k1 (by omega) (fun j hj => hret j (by omega))
      (by rw [hpc1]; exact first_not_second hFg hrl ht)
    refine ⟨k' + 2, ?_⟩
    rw [runX_succ', runX_add (step I B file) k' 2]
    exact pair_step hFg hrl ht hpc1 hok1
      (by rw [← runX_succ' ((sys I B).mach M g) k1]; exact hok0) hk'
  · obtain ⟨k', hk'⟩ := ih k0 (by omega) (fun j hj => hret j (by omega)) hs
    obtain ⟨i, hins, -, -⟩ := hok0.site
    obtain ⟨lm, hm⟩ := FnAsm.layout_labelOffsets hFg.layout
    obtain ⟨j0, t0, hj0, -⟩ := insnAt_spec hins
    have hb := progBase_of hFg hm hok0.program hj0
    -- a call of a function of the program
    have hprog : ∀ h, CallsAt I B g (runX ((sys I B).mach M g) k0 c) h →
        ∃ k'', Sim I ((sys I B).mach M g (runX ((sys I B).mach M g) k0 c))
          (runX (step I B file) k'' e) := by
      intro h hc
      have hh := callee_mem hc
      rw [mach_call hc]
      cases M with
      | zero =>
        exact (junk_contra hrun hret (by rw [runX_succ', mach_call hc]; rfl)).elim
      | succ M' =>
      simp only [LinkSys.pcall]
      have hent := call_enter hFg (hF h hh) hok0 hk' hc
      have hrun' : RunOk I B file M' h (enterAt (art I h) (runX ((sys I B).mach (M' + 1) g) k0 c)) :=
        fun M'' g' t hr => hrun _ _ _ (Reach.nest (fun j hj => hret j (by omega)) hc hr)
      unfold linkedCall
      split
      · rename_i hex
        obtain ⟨hN, hmin⟩ := firstNat_spec _ hex
        obtain ⟨k2, hk2⟩ := hcall M' rfl h _ _ hh (pc_enterAt _ _) hent hrun' _
          (fun j hj hr => hmin j hj (returned_iff.2 hr))
          (ret_not_second hF hg hh hok0 hc hrun' hN hmin)
        exact ⟨k' + 1 + k2, by rw [runX_add, runX_add]; exact sim_set_program _ hk2⟩
      · exact (junk_contra hrun hret (by rw [runX_succ', mach_call hc]; simp only [LinkSys.pcall, linkedCall]; simp [‹¬ _›])).elim
    by_cases hhk : i.hooked = false
    · exact ⟨k' + 1, by rw [runX_succ']; exact plain_step hFg hok0 hk' hins hhk⟩
    · cases i <;> simp only [Insn.hooked, Bool.true_eq_false, not_false_eq_true, not_true_eq_false] at hhk
      case bl n =>
        cases hn : (prog I).func? n with
        | none => exact ⟨k' + 1, by rw [runX_succ']; exact hook_step hFg hok0 hk' hins (.inl ⟨n, rfl, hn⟩)⟩
        | some h => exact hprog h (.inl ⟨n, by rw [hb]; exact hins, hn⟩)
      case blr x =>
        cases hn : (blrTarget (runX ((sys I B).mach M g) k0 c)).bind (symCallee (sys I B).Xb (prog I)) with
        | none => exact ⟨k' + 1, by rw [runX_succ']; exact hook_step hFg hok0 hk' hins (.inr (.inl ⟨x, rfl, hn⟩))⟩
        | some h => exact hprog h (.inr ⟨⟨x, by rw [hb]; exact hins⟩, hn⟩)
      case adrpGot a b => exact absurd (adrp_lands hFg hok0 hins (.inl ⟨a, b, rfl⟩)) hsec
      case adrp a b d => exact absurd (adrp_lands hFg hok0 hins (.inr ⟨a, b, d, rfl⟩)) hsec
      case ldrGotLo12 a b d => exact absurd (second_of_lo12 hFg hins (.inl ⟨a, b, d, rfl⟩)) hs
      case addLo12 a b d f => exact absurd (second_of_lo12 hFg hins (.inr ⟨a, b, d, f, rfl⟩)) hs
      case adrpTlsDesc a b =>
        exact ⟨k' + 1, by rw [runX_succ']; exact hook_step hFg hok0 hk' hins (.inr (.inr (.inl ⟨a, b, rfl⟩)))⟩
      case ldrTlsDescLo12 a b d =>
        exact ⟨k' + 1, by rw [runX_succ']; exact hook_step hFg hok0 hk' hins (.inr (.inr (.inr ⟨a, b, d, rfl⟩)))⟩

end Core

/-- **The simulation at every depth.** -/
theorem act_sim {I : SemanticStackBound.CompilerInput} {B : BaseEnv} {file : ByteArray}
    (hF : ∀ g ∈ (prog I).funcs, FnOk I file g) : ∀ M, ActSim I B file M
  | 0 => act_core hF 0 fun _ h => by cases h
  | M + 1 => act_core hF (M + 1) fun M' h => by
    obtain rfl : M = M' := Nat.succ.inj h
    exact act_sim hF M

/-! ## The theorem about the executable -/

/-- **What the executable machine's run does for a CLIF outcome**: `ArmRefines`, with the live
CLIF bytes compared outside the relocated instruction bytes `R` (code bytes). -/
def ExecRefines (fb : FnBin) (base ra : BitVec 64) (astep : Arm.ArmState → Arm.ArmState)
    (s : Arm.ArmState) (R : BitVec 64 → Prop) : Clif.Outcome → Prop
  | .returned vals cm => ∃ n, ArmRet ra s (runX astep n s) ∧
      (∀ (j : Nat) v, vals[j]? = some v → XHolds v (xreg j (runX astep n s))) ∧
      ∀ a b, cm.valid a 1 = true → cm.bytes a = some b → ¬ R (BitVec.ofNat 64 a) →
        Arm.read_mem (BitVec.ofNat 64 a) (runX astep n s) = b
  | .trapped c => ∃ n, TrapAt fb base c (runX astep n s)
  | .stuck _ | .outOfFuel => True

section Transfer

variable {I : SemanticStackBound.CompilerInput} {B : BaseEnv} {file : ByteArray}

/-- The model state of `r` is simulated by `r`. -/
theorem sim_modelOf {f : Clif.Function} {r : Arm.ArmState}
    (hd : ∀ a, (modelOf I f r).mem a ≠ r.mem a → RelocAtWithResults I I.results a) : Sim I (modelOf I f r) r :=
  ⟨fun fld => (r_modelOf I f r fld).symm, fun a ha =>
    Classical.byContradiction fun hne => ha (hd a (Ne.symm hne))⟩

/-- Before the state where the model's run is (`ArmRet` or `TrapAt`: no error) the activation
has not returned: past its return the machine errors for ever. -/
theorem no_return {M : Nat} {f : Clif.Function} (hFf : FnOk I file f) {c : Arm.ArmState}
    (hra : ∀ k < (art I f).fb.words.size, xreg 30 c ≠ (art I f).base + BitVec.ofNat 64 (4 * k))
    {n : Nat} (herr : Arm.r .ERR (runX ((sys I B).mach M f) n c) = .None) :
    ∀ j < n, ¬ Returned (art I f) c (runX ((sys I B).mach M f) j c) := by
  intro j hj hr
  obtain ⟨lm, hm⟩ := FnAsm.layout_labelOffsets hFf.layout
  have := retStuck (X := (sys I B).Xb) (H := (sys I B).hooks M) hFf.layout hm hr.2.2.1
    (by rw [hr.1]; exact hra) (n - j - 1)
  change Arm.r .ERR (runX ((sys I B).mach M f) (n - j - 1 + 1) (runX ((sys I B).mach M f) j c)) ≠ .None
    at this
  rw [← runX_add, show j + (n - j - 1 + 1) = n by omega] at this
  exact this herr

/-- A second word of a pair is a code word of the function. -/
theorem second_code {f : Clif.Function} (hFf : FnOk I file f) {a : BitVec 64}
    (h : Second I f a) : ∃ k < (art I f).fb.words.size, a = (art I f).base + BitVec.ofNat 64 (4 * k) := by
  obtain ⟨rl, hrl, ht, rfl⟩ := h
  obtain ⟨h4, hlt, -⟩ := pair_facts hFf hrl ht
  exact ⟨(rl.offset + 4) / 4, by omega, by simp only [wAt]; congr 2; omega⟩

/-- **The model's outcome transfers to the executable machine**, given the per-state facts of
the model's run (`RunOk`). -/
theorem exec_of_model (hF : ∀ g ∈ (prog I).funcs, FnOk I file g) {M : Nat} {f : Clif.Function}
    (hf : f ∈ (prog I).funcs) {r : Arm.ArmState} (hpc : Arm.r .PC r = (art I f).base)
    (hra : ∀ k < (art I f).fb.words.size, xreg 30 r ≠ (art I f).base + BitVec.ofNat 64 (4 * k))
    (hd : ∀ a, (modelOf I f r).mem a ≠ r.mem a → RelocAtWithResults I I.results a)
    (hrun : RunOk I B file M f (modelOf I f r)) {o : Clif.Outcome}
    (h : ArmRefines (art I f).fb (art I f).base (xreg 30 r) ((sys I B).mach M f) (modelOf I f r) o) :
    ExecRefines (art I f).fb (art I f).base (xreg 30 r) (step I B file) r (RelocAtWithResults I I.results) o := by
  have hFf := hF f hf
  have hsim := sim_modelOf hd
  have hra' : ∀ k < (art I f).fb.words.size,
      xreg 30 (modelOf I f r) ≠ (art I f).base + BitVec.ofNat 64 (4 * k) := by
    simp only [xreg, r_modelOf]; exact hra
  have hpc' : Arm.r .PC (modelOf I f r) = (art I f).base := by rw [r_modelOf]; exact hpc
  have hsimN := act_sim (B := B) hF M f _ r hf hpc' hsim hrun
  cases o with
  | returned vals cm =>
    obtain ⟨n, hret, hx, hmem⟩ := h
    obtain ⟨k', hk'⟩ := hsimN n (no_return hFf hra' hret.err) (fun hs => by
      obtain ⟨k, hk, he⟩ := second_code hFf hs
      exact hra k hk (by rw [← he, hret.pc]))
    refine ⟨k', ⟨?_, ?_, ?_, fun n hn => ?_, fun n h8 h16 => ?_⟩, fun j v hv => ?_, fun a b hv hb hR => ?_⟩
    · rw [hk'.1, hret.pc]
    · rw [hk'.1, hret.err]
    · simp only [spv]; rw [hk'.1]; exact (hret.sp.trans (spv_modelOf I f r))
    · simp only [xreg]; rw [hk'.1]; exact (hret.savedX n hn).trans (r_modelOf I f r _)
    · rw [hk'.1, hret.savedV n h8 h16, r_modelOf]
    · simp only [xreg]; rw [hk'.1]; exact hx j v hv
    · show Arm.read_store _ _ = b
      rw [show Arm.read_store (BitVec.ofNat 64 a) (runX (step I B file) k' r).mem =
        (runX (step I B file) k' r).mem (BitVec.ofNat 64 a) from rfl, hk'.2 _ hR]
      exact hmem a b hv hb
  | trapped c0 =>
    obtain ⟨n, htrap⟩ := h
    have hguard := no_return (B := B) hFf hra' htrap.err
    by_cases hs : Second I f (Arm.r .PC (runX ((sys I B).mach M f) n (modelOf I f r)))
    · -- a trap at a second word: one executable step after the first word
      obtain ⟨rl, hrl, ht, he⟩ := hs
      cases n with
      | zero => exact (not_second_base hFf ⟨rl, hrl, ht, hpc'.symm.trans he⟩).elim
      | succ n1 =>
      have hok1 := hrun _ _ _ (Reach.act (k := n1) fun j hj => hguard j (by omega))
      have hpc1 := hok1.cf rl hrl ht (by rw [← runX_succ' ((sys I B).mach M f) n1]; exact he)
      obtain ⟨k', hk'⟩ := hsimN n1 (fun j hj => hguard j (by omega))
        (by rw [hpc1]; exact first_not_second hFf hrl ht)
      obtain ⟨hpcE, herrE⟩ := pair_first_pc hFf hrl ht hpc1 hok1 hk'
      refine ⟨k' + 1, ?_⟩
      rw [runX_succ'] at htrap ⊢
      exact ⟨by rw [← herrE]; exact htrap.err, by rw [← hpcE]; exact htrap.site⟩
    · obtain ⟨k', hk'⟩ := hsimN n hguard hs
      exact ⟨k', by rw [hk'.1]; exact htrap.err, by rw [hk'.1]; exact htrap.site⟩
  | stuck _ => trivial
  | outOfFuel => trivial

end Transfer


/-- **The binary-level theorem about the executable's own words** (L3; `docs/contracts/e2e.md`,
"Binary level (M9)"): under the premises of `binary_correct_of_checks` and the per-state facts
of the model's run (`RunOk`), the **executable machine** (`step`: the processor on the
executable's words, outside calls and the TLS sequence by the base hooks) run from the machine
state `r` itself refines the whole-program CLIF run: it returns to the caller with the results,
the live CLIF bytes outside the relocated instruction bytes as the CLIF memory, or stops at the
trap site. -/
theorem binary_correct_exec_of_good {I : SemanticStackBound.CompilerInput} {D : List Clif.DataObject} {file : ByteArray}
    (hI : SemanticStackBound.okB I = true) (hbin : BinCheck.BinOkWithResults I I.results D file) (B : BaseEnv) (hB : BaseOk (sys I B))
    {n : String} (hn : SemanticStackBound.goodN I n = true) {f : Clif.Function}
    (hf : (prog I).func? n = some f) (M : Nat) {r : Arm.ArmState} {args : List Clif.Val}
    {cs : Clif.State} (hX : (imageOf file).Intact r)
    (ho : OutsideCall I (BinCheck.roByte I D) f (SemanticStackBound.stackFn I f) r args cs.mem)
    (hr : ClifRun I B f r args cs)
    (htr : TrapsExplicit (Clif.linkEnvN (prog I) B.env M) (prog I).bare cs)
    (hrun : RunOk I B file M f (modelOf I f r)) :
    ExecRefines (art I f).fb (art I f).base (xreg 30 r) (step I B file) r (RelocAtWithResults I I.results)
      (Clif.runLoop B.env (prog I) (M + 1) cs) := by
  obtain ⟨h1, h2⟩ := binary_correct_of_checks hI hbin B hB hn hf M hX ho hr htr
  have hfm := (Clif.Program.func?_some hf).1
  have hB' : BaseOk (SemanticStackBound.ofInput I B (worldF I f (SemanticStackBound.bud I f) r)) := baseOk_F hB
  have hL := SemanticStackBound.okB_sound hI hB' fun _ h => .inr h
  have hfacts := binFacts_of_checks hI hbin
  have hro : ∀ a b, BinCheck.roByte I D a = some b → r.mem a = b := fun a b h =>
    hX a b (hfacts.data a b h).1 (hfacts.data a b h).2
  obtain ⟨hent, -⟩ := premises hL hfm hro ho hr
  exact exec_of_model (fun g hg => fnOk hI hbin hL hg) hfm
    (by rw [← r_modelOf I f r]; exact hent.pc) hent.raOutside h2 hrun h1

/-- **`binary_correct_exec_of_good` from the input condition** (no call cycle reachable from the
entry, as `binary_correct_of_checks_acyclic`). -/
theorem binary_correct_exec {I : SemanticStackBound.CompilerInput} {D : List Clif.DataObject} {file : ByteArray}
    (hI : SemanticStackBound.okB I = true) (hbin : BinCheck.BinOkWithResults I I.results D file) (B : BaseEnv) (hB : BaseOk (sys I B))
    {n : String} {f : Clif.Function} (hf : (prog I).func? n = some f)
    (hc : ¬ SemanticStackBound.CycleFrom (SemanticStackBound.Calls I I.results) f) (M : Nat) {r : Arm.ArmState}
    {args : List Clif.Val} {cs : Clif.State} (hX : (imageOf file).Intact r)
    (ho : OutsideCall I (BinCheck.roByte I D) f (SemanticStackBound.stackFn I f) r args cs.mem)
    (hr : ClifRun I B f r args cs)
    (htr : TrapsExplicit (Clif.linkEnvN (prog I) B.env M) (prog I).bare cs)
    (hrun : RunOk I B file M f (modelOf I f r)) :
    ExecRefines (art I f).fb (art I f).base (xreg 30 r) (step I B file) r (RelocAtWithResults I I.results)
      (Clif.runLoop B.env (prog I) (M + 1) cs) :=
  binary_correct_exec_of_good hI hbin B hB ((SemanticStackBound.goodN_iff hI).2 ⟨f, hf, hc⟩) hf M hX ho hr
    htr hrun

end E2E.SemanticExecBytes

/-! # The static part of `RunOk` (L3)

`E2E.SemanticExecBytes.binary_correct_exec` assumes `RunOk`: `StepOk` at every state of the model's run
before its return. Several of `StepOk`'s facts do not depend on the run; here they are proven for
every input, from the checks and one contract on the base environment, leaving the per-state
hypothesis `RunOkD` (`StepOkD`):

* `site`'s agreement of the site lookup (`siteAt_static`) and `plain` (`plain_static`): from the
  per-program code map check `codeMapB` (`FV/E2E/CodeMap.lean`; `codeMap_sound`, `line_overlap`:
  two functions' overlapping words are alike lines, so one kind of site and one relocation
  status) and the layout (a relocation is at its own instruction line);
* `call` and `tls`: the **outside-code contract `HooksSim`** on the base environment (next to
  `BaseOk`): the hooks for calls outside the program and for the TLS sequence do not read the
  program's relocated instruction bytes nor the machine's program field. `closedBase` meets it
  (`hooksSim_closed`).

`StepOkD` keeps what depends on the run: no error, the program field, the pc at an instruction of
the function (not past a TLSDESC `ldr`), D1 (`cf`), D2 (`insn`), D4 (`got`) and, at a `blr` to the
program, the register (not `xzr`), the model's read of the `blr` word and the callee's link-map
address (from the M6 proof's `BlrAt` and `codeMapB`: `symAddr_of_blrTo`). Discharging it from the
M6 proof is TO-PROVE L3 (c). `binary_correct_exec_static` is `binary_correct_exec` under
`HooksSim` and `RunOkD`.
-/

namespace E2E.SemanticExecBytes

open Backend Backend.Proof E2E.LinkCheck E2E.SemanticBinary E2E.BinCheck

/-! ## The outside-code contract on the hooks -/

/-- **The base environment's hooks do not read the program's relocated instruction bytes nor the
program field** (`Sim` before gives `Sim` after): code outside the program, and the TLS sequence,
compute their effect from the registers and the bytes outside the relocated words. The contract
the executable machine adds to `BaseOk`. -/
structure HooksSim (I : SemanticStackBound.CompilerInput) (B : BaseEnv) : Prop where
  call : ∀ d m e, Sim I m e → Sim I (B.hooks.call d m) (B.hooks.call d e)
  tls : ∀ n tmp m e, Sim I m e → Sim I (B.hooks.tls n tmp m) (B.hooks.tls n tmp e)

/-- The closed base environment meets `HooksSim`. -/
theorem hooksSim_closed (I : SemanticStackBound.CompilerInput) : HooksSim I closedBase where
  call _ m e h := by
    show Sim I (Arm.w .PC (Arm.r .PC m + 4) m) (Arm.w .PC (Arm.r .PC e + 4) e)
    rw [h.1 .PC]; exact sim_w h _ _
  tls _ _ _ _ h := h

/-! ## The per-state hypothesis -/

section Defs

variable (I : SemanticStackBound.CompilerInput) (B : BaseEnv) (file : ByteArray)

/-- **What the lockstep needs of a model state beyond the static facts** (`StepOk` without the
site lookup, `call`, `tls`, `plain` and the callee's link-map address). -/
structure StepOkD (M : Nat) (g : Clif.Function) (m : Arm.ArmState) : Prop where
  err : Arm.r .ERR m = .None
  program : m.program = (art I g).fb.program (art I g).base
  /-- the pc is at an instruction of `g`, not inside the TLS sequence past its `ldr` -/
  site : ∃ i, insnAt (art I g).fa (art I g).base (Arm.r .PC m) = some i ∧
    (i.reloc? = none ∨ i.hooked = true)
  /-- D1 -/
  cf : ∀ rl ∈ (art I g).fb.relocs, (rl.type = .adrGotPage ∨ rl.type = .adrPrelPgHi21) →
    Arm.r .PC ((sys I B).mach M g m) = wAt (art I g) (rl.offset + 4) →
    Arm.r .PC m = wAt (art I g) rl.offset
  /-- D2 -/
  insn : ∀ i, insnAt (art I g).fa (art I g).base (Arm.r .PC m) = some i → i.hooked = false →
    ∀ a, (fileWord file (Arm.r .PC m)).bind Arm.decode_raw_inst = some a →
    ∀ e, Sim I m e → Sim I (Arm.exec_inst a m) (Arm.exec_inst a e)
  /-- D4 -/
  got : ∀ rl ∈ (art I g).fb.relocs, rl.type = .adrGotPage →
    Arm.r .PC m = wAt (art I g) (rl.offset + 4) → ∀ (rd G : Nat), rd < 31 → G % 8 = 0 →
    inR (-2 ^ 20) (2 ^ 20) (pageOf G - pageOf (wAt (art I g) rl.offset).toNat) = true →
    fileWord file (wAt (art I g) rl.offset) =
      some (adrpW rd (pageOf G - pageOf (wAt (art I g) rl.offset).toNat)) →
    fileWord file (wAt (art I g) (rl.offset + 4)) = some (ldrW rd rd (G % 4096 / 8)) → ∀ i < 8,
    ¬ RelocAtWithResults I I.results (BitVec.ofNat 64 G + BitVec.ofNat 64 i) ∧
    m.mem (BitVec.ofNat 64 G + BitVec.ofNat 64 i) =
      (Elf.loadMem file (BitVec.ofNat 64 G + BitVec.ofNat 64 i)).getD 0
  /-- a `blr` to the program: through a register (not `xzr`), the model reads the file's word,
  and the callee's link-map address is its load address -/
  blr : ∀ x h, insnAt (art I g).fa (art I g).base (Arm.r .PC m) = some (.blr x) →
    (blrTarget m).bind (symCallee (sys I B).Xb (prog I)) = some h →
    x ≠ .xzr ∧ fileWord file (Arm.r .PC m) = some (Arm.read_mem_bytes 4 (Arm.r .PC m) m) ∧
    I.symAddr h.name 0 = (art I h).base

/-- **The per-state hypothesis on the model's runs**: `StepOkD` at every state of the activation
of `f` at depth `M` entered at `c` (and of the activations it calls) before its return. -/
def RunOkD (M : Nat) (f : Clif.Function) (c : Arm.ArmState) : Prop :=
  ∀ M' g t, Reach I B M f c M' g t → StepOkD I B file M' g t

end Defs

/-! ## The static facts -/

/-! ## The code map check -/

theorem codeMap_sound {I : SemanticStackBound.CompilerInput} (hI : SemanticStackBound.okB I = true) (hc : codeMapB I (tabOf I.results) = true)
    {g : Clif.Function} (hg : g ∈ (prog I).funcs) :
    (I.symAddr g.name 0 = (art I g).base ∨ noBlrB I (tabOf I.results) g.name = true) ∧
    ∀ g' ∈ (prog I).funcs, g.name ≠ g'.name →
      ((art I g).base.toNat + 4 * (art I g).fb.words.size ≤ (art I g').base.toNat ∨
        (art I g').base.toNat + 4 * (art I g').fb.words.size ≤ (art I g).base.toNat) ∨
      ((art I g).base = (art I g').base ∧
        linesAlikeB (prog I) (art I g).fa.lines.toList (art I g').fa.lines.toList = true) := by
  simp only [codeMapB, progT_tabOf, List.all_eq_true, Bool.and_eq_true, beq_iff_eq,
    Bool.or_eq_true, decide_eq_true_eq] at hc
  have hn := SemanticStackBound.okB_names hI
  have hgt := hc _ (tab_mem hn hg)
  refine ⟨hgt.1, fun g' hg' hne => ?_⟩
  rcases hgt.2 _ (tab_mem hn hg') with (h | h) | h
  · exact absurd h hne
  · exact .inl h
  · exact .inr h

theorem insnAlikeB_site {P : Clif.Program} {i i' : Insn} (h : insnAlikeB P i i' = true) :
    siteOf P i = siteOf P i' := by
  simp only [insnAlikeB, Bool.or_eq_true, decide_eq_true_eq] at h
  rcases h with rfl | h
  · rfl
  · cases i <;> cases i' <;> simp_all [siteOf]

theorem insnAlikeB_reloc {P : Clif.Program} {i i' : Insn} (h : insnAlikeB P i i' = true)
    (hr : i.reloc? = none) : i'.reloc? = none := by
  simp only [insnAlikeB, Bool.or_eq_true, decide_eq_true_eq] at h
  rcases h with rfl | h
  · exact hr
  · cases i <;> cases i' <;> simp_all [Insn.reloc?]

theorem lineAlikeB_refl (P : Clif.Program) (l : Line) : lineAlikeB P l l = true := by
  cases l <;> simp [lineAlikeB, insnAlikeB]

theorem lineAlikeB_size {P : Clif.Program} {l l' : Line} (h : lineAlikeB P l l' = true) :
    l.size = l'.size := by
  cases l <;> cases l' <;> simp_all [lineAlikeB, Line.size]

theorem linesAlikeB_get {P : Clif.Program} :
    ∀ {L L' : List Line}, linesAlikeB P L L' = true → ∀ {j : Nat} {l : Line}, L[j]? = some l →
      ∃ l', L'[j]? = some l' ∧ lineAlikeB P l l' = true
  | [], _, _, _, _, hj => by simp at hj
  | _ :: _, [], h, _, _, _ => by simp [linesAlikeB] at h
  | l0 :: L, l0' :: L', h, j, l, hj => by
    simp only [linesAlikeB, Bool.and_eq_true] at h
    cases j with
    | zero => simp only [List.getElem?_cons_zero, Option.some.injEq] at hj; subst hj; exact ⟨l0', rfl, h.1⟩
    | succ j => simpa using linesAlikeB_get h.2 (by simpa using hj)

theorem linesAlikeB_offset {P : Clif.Program} :
    ∀ {L L' : List Line}, linesAlikeB P L L' = true → ∀ j, lineOffset L j = lineOffset L' j
  | [], [], _, _ => rfl
  | [], _ :: _, h, _ => by simp [linesAlikeB] at h
  | _ :: _, [], h, _ => by simp [linesAlikeB] at h
  | l0 :: L, l0' :: L', h, j => by
    simp only [linesAlikeB, Bool.and_eq_true] at h
    cases j with
    | zero => rfl
    | succ j =>
      have := linesAlikeB_offset h.2 j
      simp only [lineOffset, List.take_succ_cons, List.map_cons, List.sum_cons] at this ⊢
      rw [lineAlikeB_size h.1, this]

theorem blrGotB_sound {vc : VCode} {n : String} (h : blrGotB vc n = true) {info : CallInfo}
    (hs : vc.CallSite info) {t : Nat} (hd : info.dest = .reg (.vreg t .int)) :
    ∃ n', GotV vc t n' ∧ n' ≠ n := by
  obtain ⟨b, vb, k, hb, hi⟩ := hs
  have hvb := (array_all_iff _ _).1 h b vb hb
  have hg : (gotOf vc t).any (· != n) = true := by
    rcases hi with hi | ⟨ti, hi⟩ <;> simpa [hd] using (array_all_iff _ _).1 hvb k _ hi
  cases ho : gotOf vc t with
  | none => simp [ho] at hg
  | some n' =>
    simp only [ho, Option.any_some, bne_iff_ne, ne_eq] at hg
    exact ⟨n', gotOf_sound ho, hg⟩

/-- **The callee of a `blr` of the program has its link-map address at its load address**: a
`blr` of `g` through `t` may enter `h` (`BlrTo`) only if `h`'s link-map address is its load
address (`codeMapB`). -/
theorem symAddr_of_blrTo {I : SemanticStackBound.CompilerInput} {B : BaseEnv} (hI : SemanticStackBound.okB I = true)
    (hc : codeMapB I (tabOf I.results) = true) {g h : Clif.Function} (hg : g ∈ (prog I).funcs)
    (hh : h ∈ (prog I).funcs) {info : CallInfo} {t : Nat} (hs : (art I g).vcp.CallSite info)
    (hd : info.dest = .reg (.vreg t .int)) (hb : (sys I B).BlrTo g t h) :
    I.symAddr h.name 0 = (art I h).base := by
  refine ((codeMap_sound hI hc hh).1).resolve_right fun hn => ?_
  simp only [noBlrB, Bool.and_eq_true, Option.isNone_iff_eq_none, List.all_eq_true,
    Bool.or_eq_true, Bool.not_eq_true', List.any_eq_false, beq_iff_eq] at hn
  obtain ⟨⟨hmay, -⟩, hgot⟩ := hb
  rcases hmay with hdecl | ⟨-, hsym, -⟩
  · rcases hn.2 _ (tab_mem (SemanticStackBound.okB_names hI) hg) with hx | hx
    · obtain ⟨x, hx', he⟩ := List.mem_map.1 hdecl
      exact hx x hx' he
    · obtain ⟨n', hv, hn'⟩ := blrGotB_sound hx hs hd
      exact hn' (hgot n' hv)
  · exact hsym hn.1

section Static

variable {I : SemanticStackBound.CompilerInput} {B : BaseEnv} {file : ByteArray}

/-- The entry of `R` named like `e0 ∈ R` is `e0` (distinct names). -/
theorem find_name {R : Res} : ((R.map (·.1)).map (·.name)).Nodup → ∀ {e0}, e0 ∈ R →
    R.find? (fun e => e.1.name == e0.1.name) = some e0 := by
  induction R with
  | nil => intro _ _ h; cases h
  | cons x R ih =>
    intro hn e0 h
    simp only [List.map_cons, List.nodup_cons] at hn
    rcases List.mem_cons.1 h with rfl | h'
    · simp
    · have hne : x.1.name ≠ e0.1.name := fun he =>
        hn.1 (he ▸ List.mem_map_of_mem (List.mem_map_of_mem h'))
      simp [hne, ih hn.2 h']

/-- A relocated byte is in a relocated word of a function of the program. -/
theorem relocAt_inv (hI : SemanticStackBound.okB I = true) {a : BitVec 64} (h : RelocAtWithResults I I.results a) :
    ∃ g ∈ (prog I).funcs, ∃ rl ∈ (art I g).fb.relocs, ∃ i < 4, a = wAt (art I g) (rl.offset + i) := by
  obtain ⟨e, he, rl, hrl, i, hi, rfl⟩ := h
  obtain ⟨e0, he0, rfl⟩ := List.mem_map.1 he
  have hart : art I e0.1 = getOk e0.2 := by
    simp only [art, artOf, find_name (SemanticStackBound.okB_names hI) he0]
  exact ⟨e0.1, List.mem_map_of_mem he0, rl, by rw [hart]; exact hrl, i, hi, by rw [hart]⟩

/-- An instruction of `g` at `a`: its line, and `a` inside `g`'s code. -/
theorem insn_range {g : Clif.Function} (hF : FnOk I file g) {a : BitVec 64} {i : Insn}
    (hi : insnAt (art I g).fa (art I g).base a = some i) :
    ∃ j t, (art I g).fa.lines.toList[j]? = some (.ins i t) ∧
      a.toNat = (art I g).base.toNat + lineOffset (art I g).fa.lines.toList j ∧
      lineOffset (art I g).fa.lines.toList j + 4 ≤ 4 * (art I g).fb.words.size := by
  obtain ⟨j, t, hj, hpc⟩ := insnAt_spec hi
  have hl := line_lt hF hj
  have hfit := hF.fits
  refine ⟨j, t, hj, ?_, hl⟩
  rw [← hpc, BitVec.toNat_add, BitVec.toNat_ofNat, Nat.mod_eq_of_lt (by omega : _ < 2 ^ 64),
    Nat.mod_eq_of_lt (by omega)]

theorem art_of_name {g h : Clif.Function} (he : g.name = h.name) : art I g = art I h := by
  simp only [art, artOf, he]

/-- Lines of size 4 at the same offset are the same line. -/
theorem lineOffset_inj4 {L : List Line} {j j' : Nat} {ln ln' : Line} (hj : L[j]? = some ln)
    (hj' : L[j']? = some ln') (hs : ln.size = 4) (hs' : ln'.size = 4)
    (he : lineOffset L j = lineOffset L j') : j = j' := by
  rcases Nat.lt_trichotomy j j' with h | h | h
  · have h1 := lineOffset_succ L j _ hj
    have h2 := lineOffset_mono L (show j + 1 ≤ j' by omega)
    omega
  · exact h
  · have h1 := lineOffset_succ L j' _ hj'
    have h2 := lineOffset_mono L (show j' + 1 ≤ j by omega)
    omega

/-- A line of `g` (not a label) is a word inside `g`'s code, at an offset that is a multiple
of 4. -/
theorem line_word {g : Clif.Function} (hF : FnOk I file g) {j : Nat} {l : Line}
    (hj : (art I g).fa.lines.toList[j]? = some l) (hl : l.isLabel = false) :
    l.size = 4 ∧ lineOffset (art I g).fa.lines.toList j % 4 = 0 ∧
      lineOffset (art I g).fa.lines.toList j + 4 ≤ 4 * (art I g).fb.words.size := by
  have hs : l.size = 4 := by cases l <;> simp_all [Line.size, Line.isLabel]
  obtain ⟨lm, hm⟩ := FnAsm.layout_labelOffsets hF.layout
  have h1 := lineOffset_succ _ j _ hj
  have h2 := lineOffset_le_size (art I g).fa.lines.toList (j + 1)
  rw [layout_sum hF.layout] at h2
  exact ⟨hs, (FnAsm.layout_word hF.layout hm hj hl).1, by omega⟩

/-- **Overlapping words of two functions are alike lines** (`codeMapB`): the same function's
same line, or the lines at the same offset of two functions sharing their code. -/
theorem line_overlap (hI : SemanticStackBound.okB I = true) (hc : codeMapB I (tabOf I.results) = true)
    (hF : ∀ g ∈ (prog I).funcs, FnOk I file g) {g h : Clif.Function} (hg : g ∈ (prog I).funcs)
    (hh : h ∈ (prog I).funcs) {j j' : Nat} {l l' : Line}
    (hj : (art I g).fa.lines.toList[j]? = some l) (hj' : (art I h).fa.lines.toList[j']? = some l')
    (hl : l.isLabel = false) (hl' : l'.isLabel = false) {k k' : Nat} (hk : k < 4) (hk' : k' < 4)
    (he : (art I g).base.toNat + lineOffset (art I g).fa.lines.toList j + k =
      (art I h).base.toNat + lineOffset (art I h).fa.lines.toList j' + k') :
    lineAlikeB (prog I) l l' = true := by
  obtain ⟨hs, h4, hlt⟩ := line_word (hF g hg) hj hl
  obtain ⟨hs', h4', hlt'⟩ := line_word (hF h hh) hj' hl'
  by_cases hn : g.name = h.name
  · have hart := art_of_name (I := I) hn
    rw [← hart] at hj' he h4'
    obtain rfl := lineOffset_inj4 hj hj' hs hs' (by omega)
    rw [hj] at hj'; cases hj'
    exact lineAlikeB_refl _ _
  · rcases (codeMap_sound hI hc hg).2 h hh hn with hd | ⟨hb, ha⟩
    · exfalso
      have hfit := (hF g hg).fits
      have hfit' := (hF h hh).fits
      omega
    · rw [hb] at he
      have hoff := linesAlikeB_offset ha j
      obtain ⟨l'', hj'', hal⟩ := linesAlikeB_get ha hj
      have hs'' : l''.size = 4 := by rw [← lineAlikeB_size hal]; exact hs
      obtain rfl := lineOffset_inj4 hj'' hj' hs'' hs' (by omega)
      rw [hj''] at hj'; cases hj'
      exact hal

/-- **The site lookup finds the kind of site of the function's instruction** (the code of
another function there has an alike instruction). -/
theorem siteAt_static (hI : SemanticStackBound.okB I = true) (hc : codeMapB I (tabOf I.results) = true) (hF : ∀ g ∈ (prog I).funcs, FnOk I file g)
    {g : Clif.Function} (hg : g ∈ (prog I).funcs) {a : BitVec 64} {i : Insn}
    (hi : insnAt (art I g).fa (art I g).base a = some i) :
    siteAt I a = some (siteOf (prog I) i) := by
  unfold siteAt
  split
  · rename_i hex
    have hs := hex.choose_spec
    generalize hex.choose = g0 at hs ⊢
    obtain ⟨hg0, hsome⟩ := hs
    obtain ⟨i0, hi0⟩ := Option.isSome_iff_exists.mp hsome
    rw [hi0, Option.map_some]
    obtain ⟨j, t, hj, ha, -⟩ := insn_range (hF g hg) hi
    obtain ⟨j0, t0, hj0, ha0, -⟩ := insn_range (hF g0 hg0) hi0
    have hal := line_overlap hI hc hF hg0 hg hj0 hj rfl rfl (k := 0) (k' := 0) (by omega)
      (by omega) (by omega)
    simp only [lineAlikeB] at hal
    rw [insnAlikeB_site hal]
  · rename_i hne
    exact absurd ⟨g, hg, by rw [hi]; rfl⟩ hne

/-- **An instruction word without relocation is no relocated byte.** -/
theorem plain_static (hI : SemanticStackBound.okB I = true) (hc : codeMapB I (tabOf I.results) = true) (hF : ∀ g ∈ (prog I).funcs, FnOk I file g)
    {g : Clif.Function} (hg : g ∈ (prog I).funcs) {a : BitVec 64} {i : Insn}
    (hi : insnAt (art I g).fa (art I g).base a = some i) (hr : i.reloc? = none) :
    ∀ k < 4, ¬ RelocAtWithResults I I.results (a + BitVec.ofNat 64 k) := by
  intro k hk hR
  obtain ⟨j, t, hj, ha, hl⟩ := insn_range (hF g hg) hi
  obtain ⟨h, hh, rl, hrl, i', hi', he⟩ := relocAt_inv hI hR
  obtain ⟨j', i2, t2, hj', hri, ho⟩ := (FnAsm.layout_relocs (hF h hh).layout rl).1 hrl
  have hl' := line_lt (hF h hh) hj'
  have hfit := (hF h hh).fits
  have hfit' := (hF g hg).fits
  have he' := congrArg BitVec.toNat he
  rw [BitVec.toNat_add, ha, BitVec.toNat_ofNat, Nat.mod_eq_of_lt (by omega : k < 2 ^ 64),
    Nat.mod_eq_of_lt (by omega), wAt, BitVec.toNat_add, BitVec.toNat_ofNat,
    Nat.mod_eq_of_lt (by omega : rl.offset + i' < 2 ^ 64), Nat.mod_eq_of_lt (by omega)] at he'
  have hal := line_overlap hI hc hF hg hh hj hj' rfl rfl hk hi' (by rw [ho]; omega)
  simp only [lineAlikeB] at hal
  rw [insnAlikeB_reloc hal hr] at hri
  cases hri

/-- The states of the run are of functions of the program. -/
theorem reach_mem {M : Nat} {f : Clif.Function} {c : Arm.ArmState} {M' : Nat} {g : Clif.Function}
    {t : Arm.ArmState} (h : Reach I B M f c M' g t) (hf : f ∈ (prog I).funcs) :
    g ∈ (prog I).funcs := by
  induction h with
  | act _ => exact hf
  | nest _ hc _ ih => exact ih (callee_mem hc)

/-- **`StepOk` from `StepOkD`**, the checks and the hooks' contract. -/
theorem stepOk_of_d (hI : SemanticStackBound.okB I = true) (hc : codeMapB I (tabOf I.results) = true) (hF : ∀ g ∈ (prog I).funcs, FnOk I file g)
    (hH : HooksSim I B) {M : Nat} {g : Clif.Function} (hg : g ∈ (prog I).funcs)
    {m : Arm.ArmState} (h : StepOkD I B file M g m) : StepOk I B file M g m where
  err := h.err
  program := h.program
  site := by
    obtain ⟨i, hi, hr⟩ := h.site
    exact ⟨i, hi, siteAt_static hI hc hF hg hi, hr⟩
  cf := h.cf
  insn := h.insn
  call d e _ hs := hH.call d m e hs
  tls tmp _ n e _ hs := hH.tls n tmp m e hs
  got := h.got
  blr := h.blr
  plain i hi hr := plain_static hI hc hF hg hi hr

/-- `StepOk` gives `StepOkD` (the per-state hypothesis is weaker). -/
theorem StepOk.d {M : Nat} {g : Clif.Function} {m : Arm.ArmState} (h : StepOk I B file M g m) :
    StepOkD I B file M g m :=
  ⟨h.err, h.program, let ⟨i, hi, _, hr⟩ := h.site; ⟨i, hi, hr⟩, h.cf, h.insn, h.got,
    h.blr⟩

theorem RunOk.d {M : Nat} {f : Clif.Function} {c : Arm.ArmState} (h : RunOk I B file M f c) :
    RunOkD I B file M f c :=
  fun M' g t hR => (h M' g t hR).d

theorem runOk_of_d (hI : SemanticStackBound.okB I = true) (hc : codeMapB I (tabOf I.results) = true) (hF : ∀ g ∈ (prog I).funcs, FnOk I file g)
    (hH : HooksSim I B) {M : Nat} {f : Clif.Function} (hf : f ∈ (prog I).funcs)
    {c : Arm.ArmState} (h : RunOkD I B file M f c) : RunOk I B file M f c :=
  fun M' g t hR => stepOk_of_d hI hc hF hH (reach_mem hR hf) (h M' g t hR)

end Static

/-- **`binary_correct_exec` with the static facts proven**: under the premises of
`binary_correct_of_checks_acyclic`, the outside-code contract `HooksSim` and the per-state facts
`RunOkD` of the model's run, with the code map check `codeMapB`, the executable machine run from `r` refines the whole-program CLIF
run. -/
theorem binary_correct_exec_static {I : SemanticStackBound.CompilerInput} {D : List Clif.DataObject} {file : ByteArray}
    (hI : SemanticStackBound.okB I = true) (hcm : codeMapB I (tabOf I.results) = true)
    (hbin : BinCheck.BinOkWithResults I I.results D file) (B : BaseEnv) (hB : BaseOk (sys I B)) (hH : HooksSim I B) {n : String} {f : Clif.Function} (hf : (prog I).func? n = some f)
    (hc : ¬ SemanticStackBound.CycleFrom (SemanticStackBound.Calls I I.results) f) (M : Nat) {r : Arm.ArmState}
    {args : List Clif.Val} {cs : Clif.State} (hX : (imageOf file).Intact r)
    (ho : OutsideCall I (BinCheck.roByte I D) f (SemanticStackBound.stackFn I f) r args cs.mem)
    (hr : ClifRun I B f r args cs)
    (htr : TrapsExplicit (Clif.linkEnvN (prog I) B.env M) (prog I).bare cs)
    (hrun : RunOkD I B file M f (modelOf I f r)) :
    ExecRefines (art I f).fb (art I f).base (xreg 30 r) (step I B file) r (RelocAtWithResults I I.results)
      (Clif.runLoop B.env (prog I) (M + 1) cs) := by
  have hL := SemanticStackBound.okB_sound hI (baseOk_F (F' := img I) hB) fun _ h => h
  exact binary_correct_exec hI hbin B hB hf hc M hX ho hr htr
    (runOk_of_d hI hcm (fun g hg => fnOk hI hbin hL hg) hH (Clif.Program.func?_some hf).1 hrun)

end E2E.SemanticExecBytes

/-! # D2 of `RunOkD` from the memory reads (L3 (c))

`exec_sim`: `SemanticExecBytes.Sim I` (registers equal, bytes equal outside the relocated instruction
bytes `RelocAtWithResults I I.results`) is preserved by every decoded instruction whose memory reads (`MemReads`)
avoid `RelocAtWithResults I I.results` (`ExecFrame.exec_simR` at `R = RelocAtWithResults I I.results`). `insn_of_memReads`: so `StepOkD`'s
D2 field `insn` follows from the per-state fact "the reads of the word at the pc avoid
`RelocAtWithResults I I.results`".
-/

namespace E2E.SemanticExecBytes

abbrev MemReads := E2E.ExecBytes.MemReads

open Backend Backend.Proof E2E.LinkCheck E2E.SemanticBinary E2E.BinCheck

variable {I : SemanticStackBound.CompilerInput}

/-- **Frame property of the instruction semantics for `Sim`**: if `e` simulates `m` and the
memory reads of the decoded instruction `a` at `m` avoid the relocated instruction bytes, then
`e` simulates `m` after `a`. -/
theorem exec_sim {m e : Arm.ArmState} (a : Arm.ArmInst) (h : Sim I m e)
    (hR : ∀ p ∈ MemReads a m, ∀ k < p.2, ¬ RelocAtWithResults I I.results (p.1 + BitVec.ofNat 64 k)) :
    Sim I (Arm.exec_inst a m) (Arm.exec_inst a e) :=
  ExecFrame.exec_simR a h hR

/-- `StepOkD.insn` (D2) from the memory reads of the word at the pc. -/
theorem insn_of_memReads {file : ByteArray} {g : Clif.Function} {m : Arm.ArmState}
    (hR : ∀ a, (fileWord file (Arm.r .PC m)).bind Arm.decode_raw_inst = some a →
      ∀ p ∈ MemReads a m, ∀ k < p.2, ¬ RelocAtWithResults I I.results (p.1 + BitVec.ofNat 64 k)) :
    ∀ i, insnAt (art I g).fa (art I g).base (Arm.r .PC m) = some i → i.hooked = false →
      ∀ a, (fileWord file (Arm.r .PC m)).bind Arm.decode_raw_inst = some a →
      ∀ e, Sim I m e → Sim I (Arm.exec_inst a m) (Arm.exec_inst a e) :=
  fun _ _ _ a ha _ h => exec_sim a h (hR a ha)

end E2E.SemanticExecBytes

/-! # The error-guarded per-state hypothesis `RunOkN` (L3 (c))

`binary_correct_exec_static` assumes `RunOkD`: `StepOkD` at every `Reach` state. That includes
the states of an activation after a trap (`StepOkD.err` fails there) and the states of a callee
that never returns (whose caller's step is the error `junkAt`). Neither is needed by the
simulation: it only ever looks at a state whose step ends without error, and it enters a nested
activation only at a call whose step ends without error (the callee returned).

`ReachN` is `Reach` with that guard on nesting, `RunOkN` asks `StepOkD` only at the `ReachN`
states whose step ends without error. `RunOkD.n`: the old hypothesis gives the new one. The
simulation (`act_simN`, `ActSimN`: `ActSim` for target states without error) and the transfer
(`exec_of_modelN`) are re-proven under it, and `binary_correct_exec_staticN` is
`binary_correct_exec_static` under `RunOkN`.
-/

namespace E2E.SemanticExecBytes

open Backend Backend.Proof E2E.LinkCheck E2E.SemanticBinary E2E.BinCheck

section Defs

variable (I : SemanticStackBound.CompilerInput) (B : BaseEnv) (file : ByteArray)

/-- `Reach` where a nested activation is entered only at a call whose step ends without error
(the callee returned). -/
inductive ReachN : Nat → Clif.Function → Arm.ArmState → Nat → Clif.Function → Arm.ArmState → Prop
  | act {M g c k} : (∀ j ≤ k, ¬ Returned (art I g) c (runX ((sys I B).mach M g) j c)) →
      ReachN M g c M g (runX ((sys I B).mach M g) k c)
  | nest {M g c k h M' g' t} :
      (∀ j ≤ k, ¬ Returned (art I g) c (runX ((sys I B).mach (M + 1) g) j c)) →
      CallsAt I B g (runX ((sys I B).mach (M + 1) g) k c) h →
      Arm.r .ERR (runX ((sys I B).mach (M + 1) g) (k + 1) c) = .None →
      ReachN M h (enterAt (art I h) (runX ((sys I B).mach (M + 1) g) k c)) M' g' t →
      ReachN (M + 1) g c M' g' t

/-- **The error-guarded per-state hypothesis**: `StepOkD` at the states of `ReachN` whose step
ends without error. -/
def RunOkN (M : Nat) (f : Clif.Function) (c : Arm.ArmState) : Prop :=
  ∀ M' g t, ReachN I B M f c M' g t → Arm.r .ERR ((sys I B).mach M' g t) = .None →
    StepOkD I B file M' g t

/-- `StepOk` at the states of `ReachN` whose step ends without error (what the simulation
uses). -/
def RunOkSN (M : Nat) (f : Clif.Function) (c : Arm.ArmState) : Prop :=
  ∀ M' g t, ReachN I B M f c M' g t → Arm.r .ERR ((sys I B).mach M' g t) = .None →
    StepOk I B file M' g t

/-- **The simulation of the model's activations at depth `M`** (`ActSim`) at the target states
without error. -/
def ActSimN (M : Nat) : Prop :=
  ∀ g c e, g ∈ (prog I).funcs → Arm.r .PC c = (art I g).base → Sim I c e →
    RunOkSN I B file M g c →
    ∀ k, (∀ j < k, ¬ Returned (art I g) c (runX ((sys I B).mach M g) j c)) →
    ¬ Second I g (Arm.r .PC (runX ((sys I B).mach M g) k c)) →
    Arm.r .ERR (runX ((sys I B).mach M g) k c) = .None →
    ∃ k', Sim I (runX ((sys I B).mach M g) k c) (runX (step I B file) k' e)

end Defs

section Lemmas

variable {I : SemanticStackBound.CompilerInput} {B : BaseEnv} {file : ByteArray}

/-- A `ReachN` state is a `Reach` state. -/
theorem ReachN.reach {M : Nat} {f : Clif.Function} {c : Arm.ArmState} {M' : Nat}
    {g : Clif.Function} {t : Arm.ArmState} (h : ReachN I B M f c M' g t) :
    Reach I B M f c M' g t := by
  induction h with
  | act hj => exact .act hj
  | nest hj hc _ _ ih => exact .nest hj hc ih

theorem RunOk.n {M : Nat} {f : Clif.Function} {c : Arm.ArmState} (h : RunOk I B file M f c) :
    RunOkSN I B file M f c :=
  fun M' g t hR _ => h M' g t hR.reach

/-- `RunOkD` gives `RunOkN` (`binary_correct_exec_static` is an instance of
`binary_correct_exec_staticN`). -/
theorem RunOkD.n {M : Nat} {f : Clif.Function} {c : Arm.ArmState} (h : RunOkD I B file M f c) :
    RunOkN I B file M f c :=
  fun M' g t hR _ => h M' g t hR.reach

/-- The states of the run are of functions of the program. -/
theorem reachN_mem {M : Nat} {f : Clif.Function} {c : Arm.ArmState} {M' : Nat}
    {g : Clif.Function} {t : Arm.ArmState} (h : ReachN I B M f c M' g t)
    (hf : f ∈ (prog I).funcs) : g ∈ (prog I).funcs :=
  reach_mem h.reach hf

theorem runOkSN_of_n (hI : SemanticStackBound.okB I = true) (hc : codeMapB I (tabOf I.results) = true)
    (hF : ∀ g ∈ (prog I).funcs, FnOk I file g) (hH : HooksSim I B) {M : Nat}
    {f : Clif.Function} (hf : f ∈ (prog I).funcs) {c : Arm.ArmState}
    (h : RunOkN I B file M f c) : RunOkSN I B file M f c :=
  fun M' g t hR he => stepOk_of_d hI hc hF hH (reachN_mem hR hf) (h M' g t hR he)

theorem junkAt_err (s : Arm.ArmState) : Arm.r .ERR (junkAt s) ≠ .None := by
  simp [junkAt, Arm.r_of_w_same]

/-- `ret_not_second` under `RunOkSN`. -/
theorem ret_not_secondN (hF : ∀ g ∈ (prog I).funcs, FnOk I file g) {M M' : Nat}
    {g h : Clif.Function} (hg : g ∈ (prog I).funcs) (hh : h ∈ (prog I).funcs) {m : Arm.ArmState}
    (hok0 : StepOk I B file M g m) (hc : CallsAt I B g m h)
    (hrun' : RunOkSN I B file M' h (enterAt (art I h) m)) {N : Nat}
    (hN : RetOf (art I h) m (runX ((sys I B).mach M' h) N (enterAt (art I h) m)))
    (hmin : ∀ j < N, ¬ RetOf (art I h) m (runX ((sys I B).mach M' h) j (enterAt (art I h) m))) :
    ¬ Second I h (Arm.r .PC (runX ((sys I B).mach M' h) N (enterAt (art I h) m))) := by
  rintro ⟨rl, hrl, ht, he⟩
  have hFh := hF h hh
  cases N with
  | zero => exact not_second_base hFh ⟨rl, hrl, ht, (pc_enterAt (art I h) m).symm.trans he⟩
  | succ N1 =>
  have hokc := hrun' _ _ _
    (ReachN.act (k := N1) fun j hj => fun hr => hmin j (by omega) (returned_iff.2 hr))
    (by rw [← runX_succ' ((sys I B).mach M' h)]; exact hN.2.1)
  have hpc1 := hokc.cf rl hrl ht (by rw [← runX_succ' ((sys I B).mach M' h) N1]; exact he)
  -- the first word's instruction
  obtain ⟨j, i1, t, hj, hi, ho⟩ := (FnAsm.layout_relocs hFh.layout rl).1 hrl
  have hins1 : insnAt (art I h).fa (art I h).base (wAt (art I h) rl.offset) = some i1 := by
    rw [← ho]; exact insnAt_of_line hFh hj
  have hs1 : siteAt I (wAt (art I h) rl.offset) = some (siteOf (prog I) i1) := by
    rw [← hpc1] at hins1 ⊢; exact siteAt_of hokc hins1
  -- the call's word is there
  have hpcm : Arm.r .PC m = wAt (art I h) rl.offset := by
    have h2 : Arm.r .PC m + 4 = wAt (art I h) rl.offset + 4 := by rw [← hN.1, he, wAt_add4]
    exact (BitVec.add_left_inj _).mp h2
  obtain ⟨lm, hm⟩ := FnAsm.layout_labelOffsets (hF g hg).layout
  obtain ⟨i0, hi0, hs0, -⟩ := hok0.site
  obtain ⟨j0, t0, hj0, -⟩ := insnAt_spec hi0
  have hb := progBase_of (hF g hg) hm hok0.program hj0
  simp only [CallsAt, hb] at hc
  rw [hpcm, hs1, siteOf_pairFirst hi ht] at hs0
  rcases hc with ⟨n, hins, hn⟩ | ⟨⟨x, hins⟩, -⟩ <;> rw [hins] at hi0 <;> cases hi0
  · simp [siteOf, hn] at hs0
  · simp [siteOf] at hs0

end Lemmas

/-! ## The simulation -/

section Core

variable {I : SemanticStackBound.CompilerInput} {B : BaseEnv} {file : ByteArray}

theorem act_coreN (hF : ∀ g ∈ (prog I).funcs, FnOk I file g) (M : Nat)
    (hcall : ∀ M', M = M' + 1 → ActSimN I B file M') : ActSimN I B file M := by
  intro g c e hg hpc hsim hrun k
  induction k using Nat.strongRecOn with
  | ind k ih =>
  intro hret hsec herr
  have hFg := hF g hg
  have hok : ∀ j, (∀ j' ≤ j, ¬ Returned (art I g) c (runX ((sys I B).mach M g) j' c)) →
      Arm.r .ERR (runX ((sys I B).mach M g) (j + 1) c) = .None →
      StepOk I B file M g (runX ((sys I B).mach M g) j c) := fun j hj he =>
    hrun _ _ _ (ReachN.act hj) (by rw [← runX_succ' ((sys I B).mach M g)]; exact he)
  cases k with
  | zero => exact ⟨0, hsim⟩
  | succ k0 =>
  have hok0 : StepOk I B file M g (runX ((sys I B).mach M g) k0 c) :=
    hok k0 (fun j hj => hret j (by omega)) herr
  rw [runX_succ'] at hsec herr ⊢
  by_cases hs : Second I g (Arm.r .PC (runX ((sys I B).mach M g) k0 c))
  · -- the second word of a pair: two steps from its first word
    obtain ⟨rl, hrl, ht, he⟩ := hs
    cases k0 with
    | zero => exact (not_second_base hFg ⟨rl, hrl, ht, hpc.symm.trans he⟩).elim
    | succ k1 =>
    have hok1 : StepOk I B file M g (runX ((sys I B).mach M g) k1 c) :=
      hok k1 (fun j hj => hret j (by omega)) hok0.err
    have hpc1 := hok1.cf rl hrl ht (by rw [← runX_succ' ((sys I B).mach M g) k1]; exact he)
    obtain ⟨k', hk'⟩ := ih k1 (by omega) (fun j hj => hret j (by omega))
      (by rw [hpc1]; exact first_not_second hFg hrl ht) hok1.err
    refine ⟨k' + 2, ?_⟩
    rw [runX_succ', runX_add (step I B file) k' 2]
    exact pair_step hFg hrl ht hpc1 hok1
      (by rw [← runX_succ' ((sys I B).mach M g) k1]; exact hok0) hk'
  · obtain ⟨k', hk'⟩ := ih k0 (by omega) (fun j hj => hret j (by omega)) hs hok0.err
    obtain ⟨i, hins, -, -⟩ := hok0.site
    obtain ⟨lm, hm⟩ := FnAsm.layout_labelOffsets hFg.layout
    obtain ⟨j0, t0, hj0, -⟩ := insnAt_spec hins
    have hb := progBase_of hFg hm hok0.program hj0
    -- a call of a function of the program
    have hprog : ∀ h, CallsAt I B g (runX ((sys I B).mach M g) k0 c) h →
        ∃ k'', Sim I ((sys I B).mach M g (runX ((sys I B).mach M g) k0 c))
          (runX (step I B file) k'' e) := by
      intro h hc
      have hh := callee_mem hc
      rw [mach_call hc] at herr ⊢
      cases M with
      | zero => exact absurd herr (junkAt_err _)
      | succ M' =>
      have hrun' : RunOkSN I B file M' h
          (enterAt (art I h) (runX ((sys I B).mach (M' + 1) g) k0 c)) :=
        fun M'' g' t hr he => hrun _ _ _ (ReachN.nest (fun j hj => hret j (by omega)) hc
          (by rw [runX_succ', mach_call hc]; exact herr) hr) he
      simp only [LinkSys.pcall] at herr ⊢
      have hent := call_enter hFg (hF h hh) hok0 hk' hc
      unfold linkedCall at herr ⊢
      split
      · rename_i hex
        obtain ⟨hN, hmin⟩ := firstNat_spec _ hex
        obtain ⟨k2, hk2⟩ := hcall M' rfl h _ _ hh (pc_enterAt _ _) hent hrun' _
          (fun j hj hr => hmin j hj (returned_iff.2 hr))
          (ret_not_secondN hF hg hh hok0 hc hrun' hN hmin) hN.2.1
        exact ⟨k' + 1 + k2, by rw [runX_add, runX_add]; exact sim_set_program _ hk2⟩
      · simp [‹¬ _›, junkAt, Arm.r_of_w_same] at herr
    by_cases hhk : i.hooked = false
    · exact ⟨k' + 1, by rw [runX_succ']; exact plain_step hFg hok0 hk' hins hhk⟩
    · cases i <;> simp only [Insn.hooked, Bool.true_eq_false, not_false_eq_true, not_true_eq_false] at hhk
      case bl n =>
        cases hn : (prog I).func? n with
        | none => exact ⟨k' + 1, by rw [runX_succ']; exact hook_step hFg hok0 hk' hins (.inl ⟨n, rfl, hn⟩)⟩
        | some h => exact hprog h (.inl ⟨n, by rw [hb]; exact hins, hn⟩)
      case blr x =>
        cases hn : (blrTarget (runX ((sys I B).mach M g) k0 c)).bind (symCallee (sys I B).Xb (prog I)) with
        | none => exact ⟨k' + 1, by rw [runX_succ']; exact hook_step hFg hok0 hk' hins (.inr (.inl ⟨x, rfl, hn⟩))⟩
        | some h => exact hprog h (.inr ⟨⟨x, by rw [hb]; exact hins⟩, hn⟩)
      case adrpGot a b => exact absurd (adrp_lands hFg hok0 hins (.inl ⟨a, b, rfl⟩)) hsec
      case adrp a b d => exact absurd (adrp_lands hFg hok0 hins (.inr ⟨a, b, d, rfl⟩)) hsec
      case ldrGotLo12 a b d => exact absurd (second_of_lo12 hFg hins (.inl ⟨a, b, d, rfl⟩)) hs
      case addLo12 a b d f => exact absurd (second_of_lo12 hFg hins (.inr ⟨a, b, d, f, rfl⟩)) hs
      case adrpTlsDesc a b =>
        exact ⟨k' + 1, by rw [runX_succ']; exact hook_step hFg hok0 hk' hins (.inr (.inr (.inl ⟨a, b, rfl⟩)))⟩
      case ldrTlsDescLo12 a b d =>
        exact ⟨k' + 1, by rw [runX_succ']; exact hook_step hFg hok0 hk' hins (.inr (.inr (.inr ⟨a, b, d, rfl⟩)))⟩

end Core

/-- **The simulation at every depth** (target states without error). -/
theorem act_simN {I : SemanticStackBound.CompilerInput} {B : BaseEnv} {file : ByteArray}
    (hF : ∀ g ∈ (prog I).funcs, FnOk I file g) : ∀ M, ActSimN I B file M
  | 0 => act_coreN hF 0 fun _ h => by cases h
  | M + 1 => act_coreN hF (M + 1) fun M' h => by
    obtain rfl : M = M' := Nat.succ.inj h
    exact act_simN hF M

/-! ## The theorem about the executable -/

section Transfer

variable {I : SemanticStackBound.CompilerInput} {B : BaseEnv} {file : ByteArray}

/-- **The model's outcome transfers to the executable machine** (`exec_of_model`) under
`RunOkSN`. -/
theorem exec_of_modelN (hF : ∀ g ∈ (prog I).funcs, FnOk I file g) {M : Nat} {f : Clif.Function}
    (hf : f ∈ (prog I).funcs) {r : Arm.ArmState} (hpc : Arm.r .PC r = (art I f).base)
    (hra : ∀ k < (art I f).fb.words.size, xreg 30 r ≠ (art I f).base + BitVec.ofNat 64 (4 * k))
    (hd : ∀ a, (modelOf I f r).mem a ≠ r.mem a → RelocAtWithResults I I.results a)
    (hrun : RunOkSN I B file M f (modelOf I f r)) {o : Clif.Outcome}
    (h : ArmRefines (art I f).fb (art I f).base (xreg 30 r) ((sys I B).mach M f) (modelOf I f r) o) :
    ExecRefines (art I f).fb (art I f).base (xreg 30 r) (step I B file) r (RelocAtWithResults I I.results) o := by
  have hFf := hF f hf
  have hsim := sim_modelOf hd
  have hra' : ∀ k < (art I f).fb.words.size,
      xreg 30 (modelOf I f r) ≠ (art I f).base + BitVec.ofNat 64 (4 * k) := by
    simp only [xreg, r_modelOf]; exact hra
  have hpc' : Arm.r .PC (modelOf I f r) = (art I f).base := by rw [r_modelOf]; exact hpc
  have hsimN := act_simN (B := B) hF M f _ r hf hpc' hsim hrun
  cases o with
  | returned vals cm =>
    obtain ⟨n, hret, hx, hmem⟩ := h
    obtain ⟨k', hk'⟩ := hsimN n (no_return hFf hra' hret.err) (fun hs => by
      obtain ⟨k, hk, he⟩ := second_code hFf hs
      exact hra k hk (by rw [← he, hret.pc])) hret.err
    refine ⟨k', ⟨?_, ?_, ?_, fun n hn => ?_, fun n h8 h16 => ?_⟩, fun j v hv => ?_, fun a b hv hb hR => ?_⟩
    · rw [hk'.1, hret.pc]
    · rw [hk'.1, hret.err]
    · simp only [spv]; rw [hk'.1]; exact (hret.sp.trans (spv_modelOf I f r))
    · simp only [xreg]; rw [hk'.1]; exact (hret.savedX n hn).trans (r_modelOf I f r _)
    · rw [hk'.1, hret.savedV n h8 h16, r_modelOf]
    · simp only [xreg]; rw [hk'.1]; exact hx j v hv
    · show Arm.read_store _ _ = b
      rw [show Arm.read_store (BitVec.ofNat 64 a) (runX (step I B file) k' r).mem =
        (runX (step I B file) k' r).mem (BitVec.ofNat 64 a) from rfl, hk'.2 _ hR]
      exact hmem a b hv hb
  | trapped c0 =>
    obtain ⟨n, htrap⟩ := h
    have hguard := no_return (B := B) hFf hra' htrap.err
    by_cases hs : Second I f (Arm.r .PC (runX ((sys I B).mach M f) n (modelOf I f r)))
    · -- a trap at a second word: one executable step after the first word
      obtain ⟨rl, hrl, ht, he⟩ := hs
      cases n with
      | zero => exact (not_second_base hFf ⟨rl, hrl, ht, hpc'.symm.trans he⟩).elim
      | succ n1 =>
      have hok1 := hrun _ _ _ (ReachN.act (k := n1) fun j hj => hguard j (by omega))
        (by rw [← runX_succ' ((sys I B).mach M f)]; exact htrap.err)
      have hpc1 := hok1.cf rl hrl ht (by rw [← runX_succ' ((sys I B).mach M f) n1]; exact he)
      obtain ⟨k', hk'⟩ := hsimN n1 (fun j hj => hguard j (by omega))
        (by rw [hpc1]; exact first_not_second hFf hrl ht) hok1.err
      obtain ⟨hpcE, herrE⟩ := pair_first_pc hFf hrl ht hpc1 hok1 hk'
      refine ⟨k' + 1, ?_⟩
      rw [runX_succ'] at htrap ⊢
      exact ⟨by rw [← herrE]; exact htrap.err, by rw [← hpcE]; exact htrap.site⟩
    · obtain ⟨k', hk'⟩ := hsimN n hguard hs htrap.err
      exact ⟨k', by rw [hk'.1]; exact htrap.err, by rw [hk'.1]; exact htrap.site⟩
  | stuck _ => trivial
  | outOfFuel => trivial

end Transfer

/-- **`binary_correct_exec_static` under the error-guarded hypothesis `RunOkN`**: under the
premises of `binary_correct_of_checks_acyclic`, the outside-code contract `HooksSim`, the code
map check `codeMapB` and `StepOkD` at the states of the model's run whose step ends without error
(nested only into calls that return), the executable machine run from `r` refines the
whole-program CLIF run. -/
theorem binary_correct_exec_staticN {I : SemanticStackBound.CompilerInput} {D : List Clif.DataObject} {file : ByteArray}
    (hI : SemanticStackBound.okB I = true) (hcm : codeMapB I (tabOf I.results) = true)
    (hbin : BinCheck.BinOkWithResults I I.results D file) (B : BaseEnv) (hB : BaseOk (sys I B)) (hH : HooksSim I B)
    {n : String} {f : Clif.Function} (hf : (prog I).func? n = some f)
    (hc : ¬ SemanticStackBound.CycleFrom (SemanticStackBound.Calls I I.results) f) (M : Nat) {r : Arm.ArmState}
    {args : List Clif.Val} {cs : Clif.State} (hX : (imageOf file).Intact r)
    (ho : OutsideCall I (BinCheck.roByte I D) f (SemanticStackBound.stackFn I f) r args cs.mem)
    (hr : ClifRun I B f r args cs)
    (htr : TrapsExplicit (Clif.linkEnvN (prog I) B.env M) (prog I).bare cs)
    (hrun : RunOkN I B file M f (modelOf I f r)) :
    ExecRefines (art I f).fb (art I f).base (xreg 30 r) (step I B file) r (RelocAtWithResults I I.results)
      (Clif.runLoop B.env (prog I) (M + 1) cs) := by
  have hn := (SemanticStackBound.goodN_iff hI).2 ⟨f, hf, hc⟩
  obtain ⟨h1, h2⟩ := binary_correct_of_checks hI hbin B hB hn hf M hX ho hr htr
  have hfm := (Clif.Program.func?_some hf).1
  have hB' : BaseOk (SemanticStackBound.ofInput I B (worldF I f (SemanticStackBound.bud I f) r)) := baseOk_F hB
  have hL := SemanticStackBound.okB_sound hI hB' fun _ h => .inr h
  have hfacts := binFacts_of_checks hI hbin
  have hro : ∀ a b, BinCheck.roByte I D a = some b → r.mem a = b := fun a b h =>
    hX a b (hfacts.data a b h).1 (hfacts.data a b h).2
  obtain ⟨hent, -⟩ := premises hL hfm hro ho hr
  have hL' := SemanticStackBound.okB_sound hI (baseOk_F (F' := img I) hB) fun _ h => h
  have hF : ∀ g ∈ (prog I).funcs, FnOk I file g := fun g hg => fnOk hI hbin hL' hg
  exact exec_of_modelN hF hfm (by rw [← r_modelOf I f r]; exact hent.pc) hent.raOutside h2
    (runOkSN_of_n hI hcm hF hH hfm hrun) h1

end E2E.SemanticExecBytes

/-! # `RunOkN` from the register-level per-state facts (L3 (c))

`binary_correct_of_checksX` gives, for a returning or trapping outcome, `RunGoodL`: `RL.GoodX` at
every state of the model's linked run whose step ends without error. Here it is turned into
`RunOkN` (`runOkN_of_good`), all but its memory-read fields D2 (`insn`) and D4 (`got`), which
stay a hypothesis (`StepOkR`, `RunReadsN`):

* the states of `ReachN` are states of `ReachL` (`reachL_of_reachN`), entered at an entry whose
  return address is no second word of an `adrp` pair (the top entry: its return address is outside
  the code; a nested one: it follows a call, whose word is no first word of a pair);
* `err`, `program` are `GoodX`'s; `site` is its `line`; `cf` is its `next` (the step ends without
  error, the return address is no second word, and a second word follows its first word in the
  lines, `emitFunc_pairsClosed`); `blr` is its `blr` with the file's word of the `blr` line.

`binary_correct_exec_of_reads` is `binary_correct_exec_static` under `RunReadsN` in place of
`RunOkD`. -/

namespace E2E.SemanticExecBytes

open Backend Backend.Proof E2E.LinkCheck E2E.SemanticBinary E2E.BinCheck

/-- **The memory-read facts of a model state** (`StepOkD`'s D2 `insn` and D4 `got`). -/
structure StepOkR (I : SemanticStackBound.CompilerInput) (B : BaseEnv) (file : ByteArray) (M : Nat) (g : Clif.Function)
    (m : Arm.ArmState) : Prop where
  /-- D2 -/
  insn : ∀ i, insnAt (art I g).fa (art I g).base (Arm.r .PC m) = some i → i.hooked = false →
    ∀ a, (fileWord file (Arm.r .PC m)).bind Arm.decode_raw_inst = some a →
    ∀ e, Sim I m e → Sim I (Arm.exec_inst a m) (Arm.exec_inst a e)
  /-- D4 -/
  got : ∀ rl ∈ (art I g).fb.relocs, rl.type = .adrGotPage →
    Arm.r .PC m = wAt (art I g) (rl.offset + 4) → ∀ (rd G : Nat), rd < 31 → G % 8 = 0 →
    inR (-2 ^ 20) (2 ^ 20) (pageOf G - pageOf (wAt (art I g) rl.offset).toNat) = true →
    fileWord file (wAt (art I g) rl.offset) =
      some (adrpW rd (pageOf G - pageOf (wAt (art I g) rl.offset).toNat)) →
    fileWord file (wAt (art I g) (rl.offset + 4)) = some (ldrW rd rd (G % 4096 / 8)) → ∀ i < 8,
    ¬ RelocAtWithResults I I.results (BitVec.ofNat 64 G + BitVec.ofNat 64 i) ∧
    m.mem (BitVec.ofNat 64 G + BitVec.ofNat 64 i) =
      (Elf.loadMem file (BitVec.ofNat 64 G + BitVec.ofNat 64 i)).getD 0

/-- **The memory-read hypothesis**: `StepOkR` at the states of `ReachN` whose step ends without
error. -/
def RunReadsN (I : SemanticStackBound.CompilerInput) (B : BaseEnv) (file : ByteArray) (M : Nat) (f : Clif.Function)
    (c : Arm.ArmState) : Prop :=
  ∀ M' g t, ReachN I B M f c M' g t → Arm.r .ERR ((sys I B).mach M' g t) = .None →
    StepOkR I B file M' g t

section Conv

variable {I : SemanticStackBound.CompilerInput} {B : BaseEnv} {file : ByteArray}

theorem Insn.reloc_of_tlsTail {x : Insn} (h : x.tlsTail = false) :
    x.reloc? = none ∨ x.hooked = true := by
  cases x <;> simp_all [Insn.tlsTail, Insn.reloc?, Insn.hooked]

theorem Insn.pairSecond_of_reloc {i : Insn} {ty : RelocType} {s : String} {a : Int}
    (h : i.reloc? = some (ty, s, a)) (ht : ty = .ld64GotLo12Nc ∨ ty = .addAbsLo12Nc) :
    i.pairSecond = true := by
  cases i <;> simp only [Insn.reloc?, reduceCtorEq, Option.some.injEq, Prod.mk.injEq] at h <;>
    first | rfl | (obtain ⟨rfl, -⟩ := h; rcases ht with h' | h' <;> cases h')

/-- The lines of a function of the program keep `adrp` pairs adjacent. -/
theorem pairsClosed_art (hI : SemanticStackBound.okB I = true) {g : Clif.Function} (hg : g ∈ (prog I).funcs) :
    PairsClosed (art I g).fa.lines.toList := by
  exact emitFunc_pairsClosed (SemanticStackBound.facts hI hg).pipe.2.2.1

/-- The top entry's return address, outside the code, is no second word. -/
theorem raNotSecond_top {f : Clif.Function} (hF : FnOk I file f) {c : Arm.ArmState}
    (hra : ∀ k < (art I f).fb.words.size, xreg 30 c ≠ (art I f).base + BitVec.ofNat 64 (4 * k)) :
    ¬ Second I f (xreg 30 c) := fun hs => by
  obtain ⟨k, hk, he⟩ := second_code hF hs
  exact hra k hk he

/-- The return address of a callee entered at a call of the program is no second word of the
callee: the call's word would be the first word of the callee's pair. -/
theorem raNotSecond_enter (hI : SemanticStackBound.okB I = true) (hc : codeMapB I (tabOf I.results) = true)
    (hF : ∀ g ∈ (prog I).funcs, FnOk I file g) {g h : Clif.Function} (hg : g ∈ (prog I).funcs)
    {u : Arm.ArmState} (hp : u.program = (art I g).fb.program (art I g).base)
    (hcall : CallsAt I B g u h) : ¬ Second I h (xreg 30 (enterAt (art I h) u)) := by
  rintro ⟨rl, hrl, ht, he⟩
  have hh := callee_mem hcall
  rw [x30_enterAt] at he
  have hpcu : Arm.r .PC u = wAt (art I h) rl.offset := by
    have h2 : Arm.r .PC u + 4 = wAt (art I h) rl.offset + 4 := by rw [he, wAt_add4]
    exact (BitVec.add_left_inj _).mp h2
  obtain ⟨lm, hm⟩ := FnAsm.layout_labelOffsets (hF g hg).layout
  have hins0 : ∃ i0, insnAt (art I g).fa (progBase u) (Arm.r .PC u) = some i0 ∧
      siteOf (prog I) i0 ≠ .real := by
    rcases hcall with ⟨n, hins, hn⟩ | ⟨⟨x, hins⟩, -⟩
    · exact ⟨_, hins, by simp [siteOf, hn]⟩
    · exact ⟨_, hins, by simp [siteOf]⟩
  obtain ⟨i0, hi0, hr0⟩ := hins0
  obtain ⟨j0, t0, hj0, -⟩ := insnAt_spec hi0
  rw [progBase_of (hF g hg) hm hp hj0] at hi0
  have hs0 := siteAt_static hI hc hF hg hi0
  obtain ⟨j, i1, t1, hj, hi1, ho⟩ := (FnAsm.layout_relocs (hF h hh).layout rl).1 hrl
  have hs1 := siteAt_static hI hc hF hh (insnAt_of_line (hF h hh) hj)
  rw [ho, ← hpcu, hs0, siteOf_pairFirst hi1 ht] at hs1
  exact hr0 (Option.some.inj hs1)

/-- **The states of `ReachN` are states of `ReachL`**, of an activation entered at an entry whose
return address is no second word. -/
theorem reachL_of_reachN (hI : SemanticStackBound.okB I = true) (hc : codeMapB I (tabOf I.results) = true)
    (hF : ∀ g ∈ (prog I).funcs, FnOk I file g) {M : Nat} {f : Clif.Function} {c : Arm.ArmState}
    {M' : Nat} {g : Clif.Function} {t : Arm.ArmState} (h : ReachN I B M f c M' g t) :
    f ∈ (prog I).funcs → (sys I B).RunGoodL M f c → ¬ Second I f (xreg 30 c) →
    ∃ c', (sys I B).ReachL M f c M' g c' t ∧ ¬ Second I g (xreg 30 c') := by
  induction h with
  | act hj => exact fun _ _ hs => ⟨_, .act hj, hs⟩
  | nest hj hcall herr _ ih =>
    intro hf hrun _
    have hu := hrun _ _ _ _ (.act hj) (by rw [runX_succ'] at herr; exact herr)
    obtain ⟨X, K, G, gv, -, hG, -⟩ := hu
    unfold actGoodX at hG
    obtain ⟨c', hR', hs'⟩ := ih (callee_mem hcall)
      (fun _ _ _ _ hr he => hrun _ _ _ _ (.nest hj hcall herr hr) he)
      (raNotSecond_enter hI hc hF hf hG.prog hcall)
    exact ⟨c', .nest hj hcall herr hR', hs'⟩

/-- The calls through a register of a function of a linked system with `Ok` are through integer
vregs (`LinkSys.OkSemanticNI.blrRegs`). -/
theorem destsInt_of_ok {L : LinkSys} (hL : L.OkSemanticNI) {g : Clif.Function} (hg : g ∈ L.P.funcs) :
    (L.A g).vcp.DestsInt := by
  intro b vb k info hb hi r hd
  obtain ⟨t, Lu, Ld, he, -⟩ := hL.blrRegs g hg info ⟨b, vb, k, hb, hi⟩ (fun n => by rw [hd]; simp)
  subst he
  simp only [CallDest.reg.injEq] at hd
  exact ⟨t, hd.symm⟩

/-- **`StepOkD` from the register-level per-state facts** and the memory-read facts. -/
theorem stepOkD_of_good (hI : SemanticStackBound.okB I = true) (hc : codeMapB I (tabOf I.results) = true)
    (hF : ∀ g ∈ (prog I).funcs, FnOk I file g)
    (hD : ∀ g ∈ (prog I).funcs, (art I g).vcp.DestsInt)
    {M : Nat} {g : Clif.Function} (hg : g ∈ (prog I).funcs) {c t : Arm.ArmState}
    (hgood : (sys I B).GoodAt M g c t) (hs : ¬ Second I g (xreg 30 c))
    (he : Arm.r .ERR ((sys I B).mach M g t) = .None) (hr : StepOkR I B file M g t) :
    StepOkD I B file M g t := by
  obtain ⟨X, K, G, gv, heq, hG, -, -, hba⟩ := hgood
  unfold actGoodX at hG
  have hFg := hF g hg
  have hfit := hFg.fits
  have hsum := layout_sum hFg.layout
  obtain ⟨lm, hm⟩ := FnAsm.layout_labelOffsets hFg.layout
  refine ⟨hG.err, hG.prog, ?_, ?_, hr.insn, hr.got, ?_⟩
  · -- site
    obtain ⟨x, ⟨j, tt, hj, hpc⟩, htl⟩ := hG.line
    exact ⟨x, by rw [hpc]; exact insnAt_of_line hFg hj, Insn.reloc_of_tlsTail htl⟩
  · -- cf
    intro rl hrl ht hpcv
    have hn := hG.next
    have hstep : ArmStepX X ((sys I B).hooks M) ((sys I B).A g).fa t = (sys I B).mach M g t :=
      congrFun heq t
    simp only [RL.step] at hn
    rw [hstep] at hn
    rcases hn with h | h | h | ⟨j, hj, hpf⟩
    · exact absurd he h
    · exact absurd ⟨rl, hrl, ht, by rw [← h]; exact hpcv⟩ hs
    · have h2 : Arm.r .PC t + 4 = wAt (art I g) rl.offset + 4 := by
        rw [← h, hpcv, wAt_add4]
      exact (BitVec.add_left_inj _).mp h2
    · exfalso
      obtain ⟨-, hlt, r', hr', hr'o, hr't⟩ := pair_facts hFg hrl ht
      obtain ⟨j2, i2, t2, hj2, hi2, ho2⟩ := (FnAsm.layout_relocs hFg.layout r').1 hr'
      have hsec : i2.pairSecond = true := by
        refine Insn.pairSecond_of_reloc hi2 ?_
        rw [hr't]; rcases ht with h' | h' <;> rw [h'] <;> simp [loOf]
      obtain ⟨k', y, t', rfl, hy, hy'⟩ := pairsClosed_art hI hg _ _ _ hj2 hsec
      have hyf : y.pairFirst = true := by
        rcases hy' with ⟨a, b, rfl⟩ | ⟨a, b, d, rfl⟩ <;> rfl
      -- the offsets
      have hoff : BitVec.ofNat 64 (lineOffset (art I g).fa.lines.toList (j + 1)) =
          BitVec.ofNat 64 (rl.offset + 4) := by
        have h1 : (art I g).base + BitVec.ofNat 64 (lineOffset (art I g).fa.lines.toList (j + 1)) =
            (art I g).base + BitVec.ofNat 64 (rl.offset + 4) := by
          exact hj.symm.trans hpcv
        exact (BitVec.add_right_inj _).mp h1
      have hoff' := congrArg BitVec.toNat hoff
      simp only [BitVec.toNat_ofNat] at hoff'
      have hk1 := lineOffset_succ _ k' _ hy
      have hk2 := lineOffset_succ _ (k' + 1) _ hj2
      simp only [Line.size] at hk1 hk2
      have hle := lineOffset_le_size (art I g).fa.lines.toList (j + 1)
      rcases Nat.lt_trichotomy (j + 1) (k' + 1) with hlt' | heq' | hgt'
      · have hmono := lineOffset_mono (art I g).fa.lines.toList (show j + 1 ≤ k' by omega)
        rw [Nat.mod_eq_of_lt (by omega : rl.offset + 4 < 2 ^ 64),
          Nat.mod_eq_of_lt (by omega)] at hoff'
        omega
      · obtain rfl : j = k' := by omega
        rw [hpf y t' hy] at hyf
        cases hyf
      · have hmono := lineOffset_mono (art I g).fa.lines.toList (show k' + 1 + 1 ≤ j + 1 by omega)
        rw [Nat.mod_eq_of_lt (by omega : rl.offset + 4 < 2 ^ 64)] at hoff'
        by_cases hx : lineOffset (art I g).fa.lines.toList (j + 1) < 2 ^ 64
        · rw [Nat.mod_eq_of_lt hx] at hoff'
          omega
        · have hx' : lineOffset (art I g).fa.lines.toList (j + 1) = 2 ^ 64 := by omega
          rw [hx'] at hoff'
          simp at hoff'
  · -- blr
    intro x h' hx ht
    obtain ⟨j, tt, hj, hpc⟩ := insnAt_spec hx
    obtain ⟨hxz, hcode⟩ := hG.blr x ⟨j, tt, hj, hpc.symm⟩
    replace hxz := hxz (hD g hg)
    obtain ⟨h4, w, -, hk⟩ := FnAsm.layout_word hFg.layout hm hj rfl
    have hfw := hFg.bin.plain _ w hk (fun r hr' ho => by
      obtain ⟨j', i', t', hj', hi', ho'⟩ := (FnAsm.layout_relocs hFg.layout r).1 hr'
      have := line_unique hj hj' (by omega)
      subst this
      simp [Insn.reloc?] at hi')
    have hrd := hcode _ w hk
    rw [show 4 * (lineOffset (art I g).fa.lines.toList j / 4) =
      lineOffset (art I g).fa.lines.toList j by omega] at hfw hrd
    obtain ⟨info, tv, hsi, hd, hbt⟩ := hba x h' hx ht
    have hh' : h' ∈ (prog I).funcs := by
      obtain ⟨a, -, ha⟩ := Option.bind_eq_some_iff.1 ht
      exact List.mem_of_find?_eq_some ha
    refine ⟨hxz, ?_, symAddr_of_blrTo hI hc hg hh' hsi hd hbt⟩
    rw [← hpc]
    exact hfw.trans (congrArg some hrd.symm)

/-- **`RunOkN` from the register-level per-state facts** (`RunGoodL`) and the memory-read
facts (`RunReadsN`), for an activation whose return address is outside its code. -/
theorem runOkN_of_good (hI : SemanticStackBound.okB I = true) (hc : codeMapB I (tabOf I.results) = true)
    (hF : ∀ g ∈ (prog I).funcs, FnOk I file g) (hD : ∀ g ∈ (prog I).funcs, (art I g).vcp.DestsInt)
    {M : Nat} {f : Clif.Function}
    (hf : f ∈ (prog I).funcs) {c : Arm.ArmState}
    (hra : ∀ k < (art I f).fb.words.size, xreg 30 c ≠ (art I f).base + BitVec.ofNat 64 (4 * k))
    (hgood : (sys I B).RunGoodL M f c) (hreads : RunReadsN I B file M f c) :
    RunOkN I B file M f c := fun M' g t hR he => by
  obtain ⟨c', hRL, hs⟩ := reachL_of_reachN hI hc hF hR hf hgood (raNotSecond_top (hF f hf) hra)
  exact stepOkD_of_good hI hc hF hD (reachN_mem hR hf) (hgood _ _ _ _ hRL he) hs he
    (hreads _ _ _ hR he)

end Conv

/-- **`binary_correct_exec_static` with the per-state facts of the register-level proof**: under
the premises of `binary_correct_of_checks_acyclic`, the outside-code contract `HooksSim`, the
code map check `codeMapB` and only the memory-read facts `RunReadsN` (D2, D4) of the model's run,
the executable machine run from `r` refines the whole-program CLIF run. -/
theorem binary_correct_exec_of_reads {I : SemanticStackBound.CompilerInput} {D : List Clif.DataObject}
    {file : ByteArray} (hI : SemanticStackBound.okB I = true) (hcm : codeMapB I (tabOf I.results) = true)
    (hbin : BinCheck.BinOkWithResults I I.results D file) (B : BaseEnv) (hB : BaseOk (sys I B)) (hH : HooksSim I B)
    {n : String} {f : Clif.Function} (hf : (prog I).func? n = some f)
    (hc : ¬ SemanticStackBound.CycleFrom (SemanticStackBound.Calls I I.results) f) (M : Nat) {r : Arm.ArmState}
    {args : List Clif.Val} {cs : Clif.State} (hX : (imageOf file).Intact r)
    (ho : OutsideCall I (BinCheck.roByte I D) f (SemanticStackBound.stackFn I f) r args cs.mem)
    (hr : ClifRun I B f r args cs)
    (htr : TrapsExplicit (Clif.linkEnvN (prog I) B.env M) (prog I).bare cs)
    (hreads : RunReadsN I B file M f (modelOf I f r)) :
    ExecRefines (art I f).fb (art I f).base (xreg 30 r) (step I B file) r (RelocAtWithResults I I.results)
      (Clif.runLoop B.env (prog I) (M + 1) cs) := by
  have hn := (SemanticStackBound.goodN_iff hI).2 ⟨f, hf, hc⟩
  obtain ⟨-, -, hG⟩ := binary_correct_of_checksX hI hbin B hB hn hf M hX ho hr htr
  by_cases hout : (∃ vals cm, Clif.runLoop B.env (prog I) (M + 1) cs = .returned vals cm) ∨
      (∃ c, Clif.runLoop B.env (prog I) (M + 1) cs = .trapped c)
  · have hfm := (Clif.Program.func?_some hf).1
    have hB' : BaseOk (SemanticStackBound.ofInput I B (worldF I f (SemanticStackBound.bud I f) r)) := baseOk_F hB
    have hL := SemanticStackBound.okB_sound hI hB' fun _ h => .inr h
    have hfacts := binFacts_of_checks hI hbin
    have hro : ∀ a b, BinCheck.roByte I D a = some b → r.mem a = b := fun a b h =>
      hX a b (hfacts.data a b h).1 (hfacts.data a b h).2
    obtain ⟨hent, -⟩ := premises hL hfm hro ho hr
    have hL' := SemanticStackBound.okB_sound hI (baseOk_F (F' := img I) hB) fun _ h => h
    have hF : ∀ g ∈ (prog I).funcs, FnOk I file g := fun g hg => fnOk hI hbin hL' hg
    have hra : ∀ k < (art I f).fb.words.size,
        xreg 30 (modelOf I f r) ≠ (art I f).base + BitVec.ofNat 64 (4 * k) := by
      simp only [xreg, r_modelOf]; exact hent.raOutside
    exact binary_correct_exec_staticN hI hcm hbin B hB hH hf hc M hX ho hr htr
      (runOkN_of_good hI hcm hF (fun g hg => destsInt_of_ok hL' hg) hfm hra (hG hout) hreads)
  · cases h : Clif.runLoop B.env (prog I) (M + 1) cs with
    | returned vals cm => exact absurd (.inl ⟨vals, cm, h⟩) hout
    | trapped c => exact absurd (.inr ⟨c, h⟩) hout
    | stuck _ => trivial
    | outOfFuel => trivial

end E2E.SemanticExecBytes

/-! # D4: the GOT slots of the executable's `adrp`/`ldr` pairs (L3 (c))

`binary_correct_exec_of_reads` leaves `RunReadsN`: at every guarded state of the model's run the
memory-read facts D2 (`insn`) and D4 (`got`). Here D4 is discharged:

* **which addresses** (`GotSlot I file`): the 8 bytes of every slot `G` that the file's resolved
  `adrp`/`ldr` words of a GOT pair of a function of the program address (in the checked form of
  `PairOk.adrpLdr`: `rd < 31`, `G` aligned, the page in range). The decidable check `gotB` (on an
  excerpt of the file, `gotB_sound`) shows `GotOk`: each such byte is loaded, `ro`/`relro` (so
  `Image.Intact` gives it in `r`) and no relocated instruction byte (`RelocAt`);
* **the kept set** (`LinkSys.extImgProduction`): the linked system of the proof with the code image
  extended by the slots (`Img ∨ S`, holding the model state's bytes). Its `Ok` is the program's
  (`Ok.extImgProduction`), its machine the same (`hooks_extImg_semantic`); so every activation keeps the slots
  (`GoodAt`: `Img ⊆ G`, the entry's image bytes) and `RL.GoodX.got` gives the slot's entry bytes at
  a GOT `ldr`, which are the model state's, which are the file's;
* **the outside code** keeps the slots: the base contracts (`BaseOk.baseOs`, `baseTry`, `baseTls`)
  are stated for every kept set; what the outside caller guarantees in addition
  (`OutsideAvoids`): the slots are not in the free stack, the stack arguments, or the live CLIF
  memory (the conditions `OutsideCall` states for the code image).

`binary_correct_exec_of_insn`: `binary_correct_exec_of_reads` with D2 only (`RunInsnN`).

The system keeping the slots (`sysS`) takes the callees' stack budget `K`; `sysS_entry` gives the
entry premises of the whole-program theorems for it. `runGood_sysS_of` holds for any
`LinkSys.Budget`; `runGood_sysS` is its instance with the stack bound of a non-recursive
program, `runGood_sysS_depth` with the depth budget `D * M` of any program;
`runGood_sysS_peak` is the same for the run's peak call depth `d` (the budget `D * d`,
`backend_correct_program_peakX_semantic`). -/

namespace E2E

open Backend Backend.Proof E2E.LinkCheck E2E.BinCheck Elf

/-! ## The extended code image -/

namespace LinkSys

/-- `L` with exterior `F` and the code image extended by `S`, holding `m`. -/
def extImgProduction (L : LinkSys) (F S : BitVec 64 → Prop) (m : Arm.Memory) : LinkSys :=
  { L with F := F, Img := fun a => L.Img a ∨ S a, imgMem := m }

theorem hooks_extImg_semantic (L : LinkSys) (F S : BitVec 64 → Prop) (m : Arm.Memory) :
    ∀ M, (L.extImgProduction F S m).hooks M = L.hooks M
  | 0 => rfl
  | M + 1 => by
    simp only [LinkSys.hooks]
    rw [hooks_extImg_semantic L F S m M]
    rfl

theorem mach_extImg_semantic (L : LinkSys) (F S : BitVec 64 → Prop) (m : Arm.Memory) (M : Nat)
    (g : Clif.Function) : (L.extImgProduction F S m).mach M g = L.mach M g := by
  simp only [LinkSys.mach]
  rw [hooks_extImg_semantic]
  rfl

/-- **The extended system is a linked program**: the code image's facts hold for any extension
holding the image's bytes on the image, inside the exterior. -/
theorem OkSemanticNI.extImgProduction {L : LinkSys} (hL : L.OkSemanticNI) {F S : BitVec 64 → Prop} {m : Arm.Memory}
    (hm : ∀ a, L.Img a → m a = L.imgMem a) (hF : ∀ a, L.Img a ∨ S a → F a) :
    (L.extImgProduction F S m).OkSemanticNI :=
  { hL with
    imgAddr := fun g hg a ha => .inl (hL.imgAddr g hg a ha)
    imgCode := fun g hg t ht => hL.imgCode g hg t fun a ha => (ht a (.inl ha)).trans (hm a ha)
    imgF := hF }

theorem Budget.extImgProduction {L : LinkSys} {κ : Nat → Clif.Function → Nat} (h : L.Budget κ)
    (F S : BitVec 64 → Prop) (m : Arm.Memory) : (L.extImgProduction F S m).Budget κ := h

theorem reachL_extImg_semantic {L : LinkSys} {F S : BitVec 64 → Prop} {m : Arm.Memory} {M : Nat}
    {f : Clif.Function} {c : Arm.ArmState} {M' : Nat} {g : Clif.Function} {c' t : Arm.ArmState}
    (h : L.ReachL M f c M' g c' t) : (L.extImgProduction F S m).ReachL M f c M' g c' t := by
  induction h with
  | act hj =>
    rw [← mach_extImg_semantic L F S m] at hj ⊢
    exact .act hj
  | nest hj hc herr _ ih =>
    rw [← mach_extImg_semantic L F S m] at hj hc herr ih
    exact .nest hj hc herr ih

end LinkSys

namespace SemanticExecBytes

open SemanticBinary

variable {I : SemanticStackBound.CompilerInput} {B : BaseEnv} {file : ByteArray}

/-! ## The GOT slots and their check -/

/-- **The GOT slot bytes of the executable**: the 8 bytes at `G` for every GOT pair (`adrGotPage`
relocation) of a function of the program whose words in the file are `adrp`/`ldr` of the slot
`G` (aligned, page in range, `rd < 31`: the form of `PairOk.adrpLdr`). -/
def GotSlot (I : SemanticStackBound.CompilerInput) (file : ByteArray) (a : BitVec 64) : Prop :=
  ∃ e ∈ tabOf I.results, ∃ rl ∈ e.2.fb.relocs, rl.type = .adrGotPage ∧ ∃ rd G, rd < 31 ∧
    G % 8 = 0 ∧ inR (-2 ^ 20) (2 ^ 20) (BinCheck.pageOf G - BinCheck.pageOf (wAt e.2 rl.offset).toNat) = true ∧
    fileWord file (wAt e.2 rl.offset) =
      some (adrpW rd (BinCheck.pageOf G - BinCheck.pageOf (wAt e.2 rl.offset).toNat)) ∧
    fileWord file (wAt e.2 (rl.offset + 4)) = some (ldrW rd rd (G % 4096 / 8)) ∧
    ∃ i < 8, a = BitVec.ofNat 64 G + BitVec.ofNat 64 i

/-- **The GOT slots are kept, loaded, unrelocated bytes of the file.** -/
def GotOk (I : SemanticStackBound.CompilerInput) (file : ByteArray) : Prop :=
  ∀ a, GotSlot I file a →
    (Elf.ro file a ∨ Elf.relro file a) ∧ (Elf.loadMem file a).isSome = true ∧ ¬ RelocAtWithResults I I.results a

/-- `a` is a byte of a relocated word of the images `T`. -/
def relocAtB (T : List (Clif.Function × Art)) (a : BitVec 64) : Bool :=
  T.any fun e => e.2.fb.relocs.any fun r => (List.range 4).any fun i => a == wAt e.2 (r.offset + i)

theorem not_relocAt_of {a : BitVec 64} (h : relocAtB (tabOf I.results) a = false) :
    ¬ RelocAtWithResults I I.results a := by
  rintro ⟨e, he, r, hr, i, hi, rfl⟩
  have : relocAtB (tabOf I.results) (wAt e.2 (r.offset + i)) = true := by
    simp only [relocAtB, List.any_eq_true, List.mem_range, beq_iff_eq]
    exact ⟨e, he, r, hr, i, hi, rfl⟩
  rw [this] at h; cases h

/-- **The GOT check** on an excerpt of the file: for every GOT pair of every function, the 8
bytes of the slot its words address (`gotOf`) are loaded, `ro` or `relro`, and no relocated
instruction byte. -/
def gotB (I : SemanticStackBound.CompilerInput) (ex : Excerpt) : Bool :=
  match phdrs (exRd ex) with
  | some phs =>
    let m := memIn (exRd ex) phs
    (tabOf I.results).all fun e => e.2.fb.relocs.all fun rl =>
      !decide (rl.type = .adrGotPage) ||
      match readN m 4 (wAt e.2 rl.offset), readN m 4 (wAt e.2 (rl.offset + 4)) with
      | some x0, some x1 =>
        (List.range 8).all fun i =>
          let a := BitVec.ofNat 64 (BinCheck.gotOf (wAt e.2 rl.offset).toNat x0 x1) + BitVec.ofNat 64 i
          (roB phs a || relroB phs a) && (m a).isSome && !relocAtB (tabOf I.results) a
      | _, _ => false
  | none => false

private theorem ldr_imm {k rd : Nat} (hk : k < 512) (hrd : rd < 32) :
    (0xf9400000 + k * 1024 + rd * 32 + rd) / 1024 % 4096 = k := by
  have e : 0xf9400000 + k * 1024 + rd * 32 + rd = rd * 33 + (4083712 + k) * 1024 := by omega
  rw [e, Nat.add_mul_div_right _ _ (by decide), Nat.div_eq_of_lt (by omega)]
  omega

private theorem adrp_imm {q rd : Nat} (hq : q < 2 ^ 21) (hrd : rd < 32) :
    (1 * 2 ^ 31 + q % 4 * 2 ^ 29 + 0x10000000 + q / 4 * 32 + rd) / 32 % 2 ^ 19 * 4 +
      (1 * 2 ^ 31 + q % 4 * 2 ^ 29 + 0x10000000 + q / 4 * 32 + rd) / 2 ^ 29 % 4 = q := by
  have hu : q % 4 < 4 := Nat.mod_lt _ (by decide)
  have hv : q / 4 < 524288 := by omega
  have hq' : q = q / 4 * 4 + q % 4 := by omega
  generalize q % 4 = u at *
  generalize q / 4 = v at *
  subst hq'
  simp only [Nat.reducePow, Nat.one_mul]
  omega

/-- The slot of a checked `adrp`/`ldr` pair is the one its words decode to. -/
theorem gotOf_pair {P G rd : Nat} (hrd : rd < 32) (h8 : G % 8 = 0)
    (hin : inR (-2 ^ 20) (2 ^ 20) (BinCheck.pageOf G - BinCheck.pageOf P) = true) :
    BinCheck.gotOf P (adrpW rd (BinCheck.pageOf G - BinCheck.pageOf P)) (ldrW rd rd (G % 4096 / 8)) = G := by
  simp only [inR, Bool.and_eq_true, decide_eq_true_eq] at hin
  simp only [BinCheck.gotOf, adrpW, adrLike, ldrW, imm21, BinCheck.pageOf, BitVec.toNat_ofNat] at hin ⊢
  generalize hd : ((G / 4096 : Nat) : Int) - ((P / 4096 : Nat) : Int) = d at hin ⊢
  generalize hq : (d % 2 ^ 21).toNat = q
  have hq1 : q < 2 ^ 21 := by omega
  have hk : G % 4096 / 8 < 512 := by omega
  rw [Nat.mod_eq_of_lt (by omega : 1 * 2 ^ 31 + q % 4 * 2 ^ 29 + 0x10000000 + q / 4 * 32 + rd < 2 ^ 32),
    Nat.mod_eq_of_lt (by omega : 0xf9400000 + G % 4096 / 8 * 1024 + rd * 32 + rd < 2 ^ 32)]
  have e1 : (1 * 2 ^ 31 + q % 4 * 2 ^ 29 + 0x10000000 + q / 4 * 32 + rd) / 32 % 2 ^ 19 * 4 +
      (1 * 2 ^ 31 + q % 4 * 2 ^ 29 + 0x10000000 + q / 4 * 32 + rd) / 2 ^ 29 % 4 = q :=
    adrp_imm hq1 hrd
  have e2 : (0xf9400000 + G % 4096 / 8 * 1024 + rd * 32 + rd) / 1024 % 4096 * 8 = G % 4096 := by
    rw [ldr_imm hk hrd]; omega
  rw [e1, e2]
  have hs : (if q < 2 ^ 20 then (q : Int) else (q : Int) - 2 ^ 21) = d := by
    split <;> omega
  rw [hs]
  omega

theorem gotB_sound {ex : Excerpt} (h : gotB I ex = true) (hA : Agrees file ex) : GotOk I file := by
  unfold gotB at h
  split at h
  · rename_i phs hp
    have hm := memIn_ext hA hp
    rintro a ⟨e, he, rl, hrl, ht, rd, G, hrd, h8, hin, hw0, hw1, i, hi, rfl⟩
    have h1 := List.all_eq_true.1 (List.all_eq_true.1 h e he) rl hrl
    simp only [ht, decide_true, Bool.not_true, Bool.false_or] at h1
    split at h1
    · rename_i x0 x1 e0 e1
      have e0' : x0 = adrpW rd (BinCheck.pageOf G - BinCheck.pageOf (wAt e.2 rl.offset).toNat) := by
        have := readN_ext hm e0
        rw [show readN (loadMem file) 4 (wAt e.2 rl.offset) = fileWord file (wAt e.2 rl.offset)
          from rfl, hw0] at this
        cases this; rfl
      have e1' : x1 = ldrW rd rd (G % 4096 / 8) := by
        have := readN_ext hm e1
        rw [show readN (loadMem file) 4 (wAt e.2 (rl.offset + 4)) =
          fileWord file (wAt e.2 (rl.offset + 4)) from rfl, hw1] at this
        cases this; rfl
      subst e0' e1'
      have h2 := List.all_eq_true.1 h1 i (List.mem_range.2 hi)
      rw [gotOf_pair (rd := rd) (by omega) h8 hin] at h2
      simp only [Bool.and_eq_true, Bool.or_eq_true, Bool.not_eq_true'] at h2
      obtain ⟨⟨hro, hsome⟩, hrel⟩ := h2
      refine ⟨?_, ?_, not_relocAt_of hrel⟩
      · rcases hro with hro | hro
        · exact .inl (roB_sound hA hp hro)
        · exact .inr (relroB_sound hA hp hro)
      · obtain ⟨b, hb⟩ := Option.isSome_iff_exists.1 hsome
        simp [hm _ _ hb]
    · cases h1
  · cases h

/-! ## The outside caller and the slots -/

/-- **The slots are outside the caller's stack and CLIF memory**: what the outside caller of
`OutsideCall` (stack `N`) guarantees about the addresses `S` besides the code: none is in the free
stack, in a stack argument, or in a live CLIF allocation. -/
structure OutsideAvoids (S : BitVec 64 → Prop) (f : Clif.Function) (N : Nat) (r : Arm.ArmState)
    (args : List Clif.Val) (cm : Clif.Mem) : Prop where
  stack : ∀ a, S a → ¬ StackBelow N (spv r) a
  args : ∀ off v, (ArgLoc.stack off, v) ∈ (locsOf f.sig).zip args →
    Avoids S v.ty.bytes (spv r + BitVec.ofNat 64 off)
  valid : ∀ a n, cm.valid a n = true → ∀ k < n, ¬ S (BitVec.ofNat 64 (a + k))

/-- `worldF` with the code image extended by `S`. -/
def worldFS (I : SemanticStackBound.CompilerInput) (f : Clif.Function) (K : Nat) (r : Arm.ArmState)
    (S : BitVec 64 → Prop) : BitVec 64 → Prop :=
  frameWG K (RAFrame.compute (art I f).vcp (art I f).rf).intBase
    (RAFrame.compute (art I f).vcp (art I f).rf).size (art I f).af (fun a => img I a ∨ S a)
    (modelOf I f r)

theorem not_worldFS {f : Clif.Function} {K : Nat} {r : Arm.ArmState} {S : BitVec 64 → Prop}
    {a : BitVec 64} (h1 : ¬ worldF I f K r a) (h2 : ¬ S a) : ¬ worldFS I f K r S a := by
  rintro (h | h | h)
  · exact h1 (.inl h)
  · exact h1 (.inr h)
  · exact h2 h

/-- The proof's linked system of an outside call of `f` in `r` with the callees' stack budget
`K` and the slots `S` kept. -/
noncomputable def sysS (I : SemanticStackBound.CompilerInput) (B : BaseEnv) (f : Clif.Function) (K : Nat)
    (r : Arm.ArmState) (S : BitVec 64 → Prop) : LinkSys :=
  (SemanticStackBound.ofInput I B (worldF I f K r)).extImgProduction (worldFS I f K r S) S (modelOf I f r).mem

theorem mach_sysS (f : Clif.Function) (K : Nat) (r : Arm.ArmState) (S : BitVec 64 → Prop)
    (M : Nat) (g : Clif.Function) : (sysS I B f K r S).mach M g = (sys I B).mach M g := by
  rw [sysS, LinkSys.mach_extImg_semantic, mach_F]

/-- **The entry premises of the whole-program theorems for the system keeping the slots** `S`
with the callees' stack `K` (the outside caller's stack `frameDrop + K`): what
`backend_correct_program_budgetX_semantic` and `backend_correct_program_peakX_semantic` take besides the budget and
the run premises. -/
theorem sysS_entry {D : List Clif.DataObject} (hI : SemanticStackBound.okB I = true) (hbin : BinOkWithResults I I.results D file)
    (hB : BaseOk (sys I B)) {f : Clif.Function} (hfm : f ∈ (prog I).funcs)
    {r : Arm.ArmState} {args : List Clif.Val} {cs : Clif.State} (hX : (imageOf file).Intact r)
    {K : Nat}
    (ho : OutsideCall I (BinCheck.roByte I D) f (frameDrop (art I f).af + K) r args cs.mem)
    {S : BitVec 64 → Prop} (hav : OutsideAvoids S f (frameDrop (art I f).af + K) r args cs.mem)
    (hr : ClifRun I B f r args cs) :
    (sysS I B f K r S).OkSemanticNI ∧
    AbiEntry (art I f).fb (art I f).base (xreg 30 r) (modelOf I f r) ∧
    StackAvail K (art I f).af (modelOf I f r) ∧
    (∀ a, (sysS I B f K r S).Img a →
      ¬ StackBelow (frameDrop (art I f).af + K) (spv (modelOf I f r)) a) ∧
    BodyEntry (art I f).af (modelOf I f r) (bodyOf (art I f).af (modelOf I f r)) ∧
    ArgsIn f.sig args (modelOf I f r) ∧
    StackArgsAvoid (sysS I B f K r S).Img f.sig args (modelOf I f r) ∧
    Rel.holds ⟨(sysS I B f K r S).F, (sysS I B f K r S).syms, (art I f).af.slotBase,
      (RAFrame.compute (art I f).vcp (art I f).rf).intBase⟩ f cs.frame.slots cs.mem
      (bodyOf (art I f).af (modelOf I f r)) ∧
    ((sysS I B f K r S).NeedSlots →
      (sysS I B f K r S).PlaceAt cs.mem (spv (bodyOf (art I f).af (modelOf I f r)))) := by
  have hB' : BaseOk (SemanticStackBound.ofInput I B (worldF I f K r)) := baseOk_F hB
  have himgF : ∀ a, (SemanticStackBound.ofInput I B (worldF I f K r)).Img a →
      worldF I f K r a := fun _ h => .inr h
  have hL0 := SemanticStackBound.okB_sound hI hB' himgF
  have hfacts := binFacts_of_checks hI hbin
  have hro : ∀ a b, BinCheck.roByte I D a = some b → r.mem a = b := fun a b h =>
    hX a b (hfacts.data a b h).1 (hfacts.data a b h).2
  obtain ⟨hent, hres, hgfree, -, hbe, hargs, hsav, hrel, hpl⟩ := premises hL0 hfm hro ho hr
  have hL : (sysS I B f K r S).OkSemanticNI := LinkSys.OkSemanticNI.extImgProduction hL0
    (fun a ha => mem_modelOf_img ha) fun a ha => by
      rcases ha with ha | ha
      · exact .inr (.inl ha)
      · exact .inr (.inr ha)
  obtain ⟨hd, hsb, hib, hsz⟩ := frame_facts hL0 hfm
  have hN := ho.stack
  have hsp := (spv r).isLt
  have hspbN : (spBody (art I f).af r).toNat = (spv r).toNat - frameDrop (art I f).af :=
    (off_toNat 0 (spv r) _ (by omega)).2.2
  have hspb : spv (bodyOf (art I f).af (modelOf I f r)) = spBody (art I f).af r := by
    rw [spv_bodyOf, spv_modelOf]; rfl
  refine ⟨hL, hent, hres, fun a ha => ?_, hbe, hargs, fun off v hm k hk hx => ?_,
    ⟨⟨hrel.1.bytes, fun a n hv => ?_, hrel.1.symbols⟩, hrel.2.1, hrel.2.2.1, fun j hj => ?_,
      hrel.2.2.2.2⟩, hpl⟩
  · rcases ha with ha | ha
    · exact hgfree a ha
    · rw [spv_modelOf]; exact hav.stack a ha
  · rcases hx with hx | hx
    · exact hsav off v hm k hk hx
    · rw [spv_modelOf] at hx; exact hav.args off v hm k hk hx
  · obtain ⟨hfit, hk⟩ := hrel.1.valid a n hv
    exact ⟨hfit, fun k hkn => not_worldFS (hk k hkn) (hav.valid a n hv k hkn)⟩
  · refine not_worldFS (hrel.2.2.2.1 j hj) fun hS => hav.stack _ hS ?_
    change j < (RAFrame.compute (art I f).vcp (art I f).rf).intBase at hj
    rw [hspb]
    show StackBelow (frameDrop (art I f).af + K) _ _
    simp only [StackBelow, BitVec.toNat_add, BitVec.toNat_ofNat, hspbN]
    rw [Nat.mod_eq_of_lt (by omega : j < 2 ^ 64), Nat.mod_eq_of_lt (by omega)]
    omega

/-- **`RunGoodL` of the system keeping the slots** for any callees' budget `κ` of the linked
system (`LinkSys.Budget`) whose value at the entry is `K` (the stack `frameDrop + K`), for a
returning or trapping outcome. -/
theorem runGood_sysS_of {D : List Clif.DataObject} (hI : SemanticStackBound.okB I = true) (hbin : BinOkWithResults I I.results D file)
    (hB : BaseOk (sys I B)) {f : Clif.Function} (hfm : f ∈ (prog I).funcs) (M : Nat)
    {r : Arm.ArmState} {args : List Clif.Val} {cs : Clif.State} (hX : (imageOf file).Intact r)
    {K : Nat} {κ : Nat → Clif.Function → Nat}
    (hκ : (SemanticStackBound.ofInput I B (worldF I f K r)).Budget κ) (hK : κ M f = K)
    (ho : OutsideCall I (BinCheck.roByte I D) f (frameDrop (art I f).af + K) r args cs.mem)
    {S : BitVec 64 → Prop} (hav : OutsideAvoids S f (frameDrop (art I f).af + K) r args cs.mem)
    (hr : ClifRun I B f r args cs)
    (htr : TrapsExplicit (Clif.linkEnvN (prog I) B.env M) (prog I).bare cs)
    (hout : (∃ vals cm, Clif.runLoop B.env (prog I) (M + 1) cs = .returned vals cm) ∨
      (∃ c, Clif.runLoop B.env (prog I) (M + 1) cs = .trapped c)) :
    (sysS I B f K r S).RunGoodL M f (modelOf I f r) := by
  subst hK
  obtain ⟨hL, hent, hres, hgfree, hbe, hargs, hsav, hrel, hpl⟩ :=
    sysS_entry hI hbin hB hfm hX ho hav hr
  exact (backend_correct_program_budgetX_semantic (sysS I B f (κ M f) r S) hL (hκ.extImgProduction _ _ _) hfm M
    hent hres rfl hgfree (fun a _ => rfl) hbe hargs hr.entry hsav hrel hpl htr).2 hout

/-- **`RunGoodL` of the system keeping the slots**, for a returning or trapping outcome: the
stack bound of a non-recursive program (`goodN`; the budget `SemanticStackBound.budget_of`). -/
theorem runGood_sysS {D : List Clif.DataObject} (hI : SemanticStackBound.okB I = true) (hbin : BinOkWithResults I I.results D file)
    (hB : BaseOk (sys I B)) {n : String} (hn : SemanticStackBound.goodN I n = true) {f : Clif.Function}
    (hf : (prog I).func? n = some f) (M : Nat) {r : Arm.ArmState} {args : List Clif.Val}
    {cs : Clif.State} (hX : (imageOf file).Intact r)
    (ho : OutsideCall I (BinCheck.roByte I D) f (SemanticStackBound.stackFn I f) r args cs.mem)
    {S : BitVec 64 → Prop} (hav : OutsideAvoids S f (SemanticStackBound.stackFn I f) r args cs.mem)
    (hr : ClifRun I B f r args cs)
    (htr : TrapsExplicit (Clif.linkEnvN (prog I) B.env M) (prog I).bare cs)
    (hout : (∃ vals cm, Clif.runLoop B.env (prog I) (M + 1) cs = .returned vals cm) ∨
      (∃ c, Clif.runLoop B.env (prog I) (M + 1) cs = .trapped c)) :
    (sysS I B f (SemanticStackBound.bud I f) r S).RunGoodL M f (modelOf I f r) := by
  have hf' : (progOf I.results).func? n = some f := hf
  have hn' := hn
  unfold SemanticStackBound.goodN at hn'
  rw [hf'] at hn'
  obtain ⟨b, hb⟩ := Option.isSome_iff_exists.1 hn'
  have hbud : SemanticStackBound.bud I f = b := by simp [SemanticStackBound.bud, hb]
  exact runGood_sysS_of hI hbin hB (Clif.Program.func?_some hf).1 M hX
    (SemanticStackBound.budget_of hI B (worldF I f (SemanticStackBound.bud I f) r))
    (by simp [LinkSys.hybrid, hb, hbud]) ho hav hr htr hout

/-- **`RunGoodL` of the system keeping the slots for any program**, recursive ones included: the
depth-`M` budget `D * M` (`LinkSys.budget_K_semantic`), the stack `frameDrop + D * M`. -/
theorem runGood_sysS_depth {D : List Clif.DataObject} (hI : SemanticStackBound.okB I = true) (hbin : BinOkWithResults I I.results D file)
    (hB : BaseOk (sys I B)) {f : Clif.Function} (hfm : f ∈ (prog I).funcs) (M : Nat)
    {r : Arm.ArmState} {args : List Clif.Val} {cs : Clif.State} (hX : (imageOf file).Intact r)
    (ho : OutsideCall I (BinCheck.roByte I D) f (frameDrop (art I f).af + I.D * M) r args cs.mem)
    {S : BitVec 64 → Prop}
    (hav : OutsideAvoids S f (frameDrop (art I f).af + I.D * M) r args cs.mem)
    (hr : ClifRun I B f r args cs)
    (htr : TrapsExplicit (Clif.linkEnvN (prog I) B.env M) (prog I).bare cs)
    (hout : (∃ vals cm, Clif.runLoop B.env (prog I) (M + 1) cs = .returned vals cm) ∨
      (∃ c, Clif.runLoop B.env (prog I) (M + 1) cs = .trapped c)) :
    (sysS I B f (I.D * M) r S).RunGoodL M f (modelOf I f r) :=
  runGood_sysS_of hI hbin hB hfm M hX
    (LinkSys.budget_K_semantic _ (SemanticStackBound.okB_sound hI (baseOk_F hB) fun _ h => .inr h)) rfl ho hav hr htr hout

/-- **`RunGoodL` of the system keeping the slots for the run's peak call depth** `d` (L1d): the
whole-program run of at most `F + 1` steps reaches no state with more than `d` callers
(`Clif.DepthLe`); the budget `D * d` (`LinkSys.budget_K_semantic`), the stack `frameDrop + D * d`
(`backend_correct_program_peakX_semantic`). -/
theorem runGood_sysS_peak {D : List Clif.DataObject} (hI : SemanticStackBound.okB I = true) (hbin : BinOkWithResults I I.results D file)
    (hB : BaseOk (sys I B)) {f : Clif.Function} (hfm : f ∈ (prog I).funcs) (F d : Nat)
    {r : Arm.ArmState} {args : List Clif.Val} {cs : Clif.State} (hX : (imageOf file).Intact r)
    (ho : OutsideCall I (BinCheck.roByte I D) f (frameDrop (art I f).af + I.D * d) r args cs.mem)
    {S : BitVec 64 → Prop}
    (hav : OutsideAvoids S f (frameDrop (art I f).af + I.D * d) r args cs.mem)
    (hr : ClifRun I B f r args cs) (hd : Clif.DepthLe B.env (prog I) d cs)
    (htr : TrapsExplicit (Clif.linkEnvD (prog I) B.env F d) (prog I).bare cs)
    (hout : (∃ vals cm, Clif.runLoop B.env (prog I) (F + 1) cs = .returned vals cm) ∨
      (∃ c, Clif.runLoop B.env (prog I) (F + 1) cs = .trapped c)) :
    (sysS I B f (I.D * d) r S).RunGoodL d f (modelOf I f r) := by
  obtain ⟨hL, hent, hres, hgfree, hbe, hargs, hsav, hrel, hpl⟩ :=
    sysS_entry hI hbin hB hfm hX ho hav hr
  exact (backend_correct_program_peakX_semantic (sysS I B f (I.D * d) r S) hL
    ((LinkSys.budget_K_semantic _ (SemanticStackBound.okB_sound hI (baseOk_F hB) fun _ h => .inr h)).extImgProduction _ _ _) hfm F d
    hent hres rfl hgfree (fun a _ => rfl) hbe hargs hr.entry hsav hrel hpl hd htr).2 hout

/-! ## D4 at a state of the run -/

/-- **D4 from the per-state facts** of the system keeping the GOT slots: at the `ldr` of a GOT
pair, the slot's bytes are the activation's entry bytes (`RL.GoodX.got`, the slots kept), which
are the model state's, which are the file's (`GotOk`, `img_bytes`, `Image.Intact`). -/
theorem got_of_good {D : List Clif.DataObject} (hI : SemanticStackBound.okB I = true) (hbin : BinOkWithResults I I.results D file)
    (hgot : GotOk I file) {f : Clif.Function} {r : Arm.ArmState} (hX : (imageOf file).Intact r)
    {g : Clif.Function} (hg : g ∈ (prog I).funcs) (hFg : FnOk I file g) {M Kc : Nat}
    {c t : Arm.ArmState} (hgood : (sysS I B f Kc r (GotSlot I file)).GoodAt M g c t) :
    ∀ rl ∈ (art I g).fb.relocs, rl.type = .adrGotPage →
    Arm.r .PC t = wAt (art I g) (rl.offset + 4) → ∀ (rd G : Nat), rd < 31 → G % 8 = 0 →
    inR (-2 ^ 20) (2 ^ 20) (BinCheck.pageOf G - BinCheck.pageOf (wAt (art I g) rl.offset).toNat) = true →
    fileWord file (wAt (art I g) rl.offset) =
      some (adrpW rd (BinCheck.pageOf G - BinCheck.pageOf (wAt (art I g) rl.offset).toNat)) →
    fileWord file (wAt (art I g) (rl.offset + 4)) = some (ldrW rd rd (G % 4096 / 8)) → ∀ i < 8,
    ¬ RelocAtWithResults I I.results (BitVec.ofNat 64 G + BitVec.ofNat 64 i) ∧
    t.mem (BitVec.ofNat 64 G + BitVec.ofNat 64 i) =
      (Elf.loadMem file (BitVec.ofNat 64 G + BitVec.ofNat 64 i)).getD 0 := by
  intro rl hrl ht hpc rd G hrd h8 hin hw0 hw1 i hi
  obtain ⟨X, K, G', gv, -, hG, himgG, himgS, -⟩ := hgood
  unfold actGoodX at hG
  have hS : GotSlot I file (BitVec.ofNat 64 G + BitVec.ofNat 64 i) :=
    ⟨_, tab_mem (SemanticStackBound.okB_names hI) hg, rl, hrl, ht, rd, G, hrd, h8, hin, hw0, hw1, i, hi, rfl⟩
  obtain ⟨hkept, hsome, hnr⟩ := hgot _ hS
  refine ⟨hnr, ?_⟩
  -- the `ldr` line
  obtain ⟨-, -, r', hr', hr'o, hr't⟩ := pair_facts hFg hrl (.inl ht)
  obtain ⟨j2, i2, t2, hj2, hi2, ho2⟩ := (FnAsm.layout_relocs hFg.layout r').1 hr'
  obtain ⟨a1, b1, c1, rfl⟩ : ∃ a b c, i2 = .ldrGotLo12 a b c := by
    rw [hr't, ht] at hi2
    cases i2 <;> simp [Insn.reloc?, loOf] at hi2
    exact ⟨_, _, _, rfl⟩
  have hat := hG.got a1 b1 c1 ⟨j2, t2, hj2, by
    rw [hpc, ← hr'o, ← ho2]; rfl⟩ _ (himgG _ (.inr hS))
  rw [hat, himgS _ (.inr hS)]
  show (modelOf I f r).mem _ = _
  obtain ⟨b, hb⟩ := Option.isSome_iff_exists.1 hsome
  rw [hb, Option.getD_some]
  by_cases hii : img I (BitVec.ofNat 64 G + BitVec.ofNat 64 i)
  · rw [mem_modelOf_img hii]
    rcases (E2E.BinCheck.img_bytesWithResults hbin (okRSemanticNI_img I.stage hI) hii).2 with h | h
    · rw [hb] at h; cases h; rfl
    · exact absurd h hnr
  · rw [mem_modelOf_not hii]
    exact hX _ _ hkept hb

/-! ## The binary theorem with D2 only -/

/-- **The memory-read fact D2 of a model state** (`StepOkR.insn`). -/
def StepOkI (I : SemanticStackBound.CompilerInput) (file : ByteArray) (g : Clif.Function) (m : Arm.ArmState) : Prop :=
  ∀ i, insnAt (art I g).fa (art I g).base (Arm.r .PC m) = some i → i.hooked = false →
    ∀ a, (fileWord file (Arm.r .PC m)).bind Arm.decode_raw_inst = some a →
    ∀ e, Sim I m e → Sim I (Arm.exec_inst a m) (Arm.exec_inst a e)

/-- **The D2 hypothesis**: `StepOkI` at the states of `ReachN` whose step ends without error. -/
def RunInsnN (I : SemanticStackBound.CompilerInput) (B : BaseEnv) (file : ByteArray) (M : Nat) (f : Clif.Function)
    (c : Arm.ArmState) : Prop :=
  ∀ M' g t, ReachN I B M f c M' g t → Arm.r .ERR ((sys I B).mach M' g t) = .None →
    StepOkI I file g t

/-- **`binary_correct_exec_of_reads` with D4 discharged**: under the premises of
`binary_correct_of_checks_acyclic`, the outside-code contract `HooksSim`, the code map check
`codeMapB`, the GOT check's fact `GotOk` (`gotB_sound`), the outside caller keeping the GOT slots
off its stack and CLIF memory (`OutsideAvoids`), and only the memory-read fact D2 (`RunInsnN`)
of the model's run, the executable machine run from `r` refines the whole-program CLIF run. -/
theorem binary_correct_exec_of_insn {I : SemanticStackBound.CompilerInput} {D : List Clif.DataObject}
    {file : ByteArray} (hI : SemanticStackBound.okB I = true) (hcm : codeMapB I (tabOf I.results) = true)
    (hbin : BinCheck.BinOkWithResults I I.results D file) (hgot : GotOk I file) (B : BaseEnv) (hB : BaseOk (sys I B))
    (hH : HooksSim I B) {n : String} {f : Clif.Function} (hf : (prog I).func? n = some f)
    (hc : ¬ SemanticStackBound.CycleFrom (SemanticStackBound.Calls I I.results) f) (M : Nat) {r : Arm.ArmState}
    {args : List Clif.Val} {cs : Clif.State} (hX : (imageOf file).Intact r)
    (ho : OutsideCall I (BinCheck.roByte I D) f (SemanticStackBound.stackFn I f) r args cs.mem)
    (hav : OutsideAvoids (GotSlot I file) f (SemanticStackBound.stackFn I f) r args cs.mem)
    (hr : ClifRun I B f r args cs)
    (htr : TrapsExplicit (Clif.linkEnvN (prog I) B.env M) (prog I).bare cs)
    (hins : RunInsnN I B file M f (modelOf I f r)) :
    ExecRefines (art I f).fb (art I f).base (xreg 30 r) (step I B file) r (RelocAtWithResults I I.results)
      (Clif.runLoop B.env (prog I) (M + 1) cs) := by
  have hn := (SemanticStackBound.goodN_iff hI).2 ⟨f, hf, hc⟩
  by_cases hout : (∃ vals cm, Clif.runLoop B.env (prog I) (M + 1) cs = .returned vals cm) ∨
      (∃ c, Clif.runLoop B.env (prog I) (M + 1) cs = .trapped c)
  · obtain ⟨-, -, hG⟩ := binary_correct_of_checksX hI hbin B hB hn hf M hX ho hr htr
    have hgS := runGood_sysS hI hbin hB hn hf M hX ho hav hr htr hout
    have hfm := (Clif.Program.func?_some hf).1
    have hL' := SemanticStackBound.okB_sound hI (baseOk_F (F' := img I) hB) fun _ h => h
    have hF : ∀ g ∈ (prog I).funcs, FnOk I file g := fun g hg => fnOk hI hbin hL' hg
    have hent : ∀ k < (art I f).fb.words.size,
        xreg 30 (modelOf I f r) ≠ (art I f).base + BitVec.ofNat 64 (4 * k) := by
      have hB'' : BaseOk (SemanticStackBound.ofInput I B (worldF I f (SemanticStackBound.bud I f) r)) := baseOk_F hB
      have hL0 := SemanticStackBound.okB_sound hI hB'' fun _ h => .inr h
      have hfacts := binFacts_of_checks hI hbin
      have hro : ∀ a b, BinCheck.roByte I D a = some b → r.mem a = b := fun a b h =>
        hX a b (hfacts.data a b h).1 (hfacts.data a b h).2
      obtain ⟨he, -⟩ := premises hL0 hfm hro ho hr
      simp only [xreg, r_modelOf]; exact he.raOutside
    refine binary_correct_exec_of_reads hI hcm hbin B hB hH hf hc M hX ho hr htr
      fun M' g t hR he => ⟨hins M' g t hR he, ?_⟩
    obtain ⟨c', hRL, -⟩ := reachL_of_reachN hI hcm hF hR hfm (hG hout)
      (raNotSecond_top (hF f hfm) hent)
    have hRL' : (sysS I B f (SemanticStackBound.bud I f) r (GotSlot I file)).ReachL M f (modelOf I f r)
        M' g c' t := by
      exact LinkSys.reachL_extImg_semantic (F := worldFS I f (SemanticStackBound.bud I f) r (GotSlot I file))
        (S := GotSlot I file) (m := (modelOf I f r).mem)
        (SemanticBinary.reachL_F (F := worldF I f (SemanticStackBound.bud I f) r) (F' := fun _ => False) hRL)
    have hg := reachN_mem hR hfm
    exact got_of_good hI hbin hgot hX hg (hF g hg)
      (hgS _ _ _ _ hRL' (by rw [mach_sysS]; exact he))
  · cases h : Clif.runLoop B.env (prog I) (M + 1) cs with
    | returned vals cm => exact absurd (.inl ⟨vals, cm, h⟩) hout
    | trapped c => exact absurd (.inr ⟨c, h⟩) hout
    | stuck _ => trivial
    | outOfFuel => trivial

end SemanticExecBytes

end E2E

/-! # D2 of `StepOkR` from the register-level per-state facts (L3 (c))

`RL.GoodX.reads` (every state of the model's run): the memory reads (`MemReads`) of the unhooked
instruction at the pc are outside the activation's kept addresses `G`, or bytes of one of its
jump-table words. At the link level the code image is in `G` (`GoodAt`'s last conjunct, from
`MachEntry.imgG`) and every relocated byte is a code byte (`relocAt_img`) of an instruction line
(`FnAsm.layout_relocs`), never of a jump-table word (`word_static`); the word at an unhooked
instruction line outside the TLS tail is the compiled one (`fileWord_plain`), which decodes to
the instruction's `toArmInst`. So the reads of the decoded word avoid `RelocAtWithResults I I.results`, and
`exec_sim` gives `StepOkR.insn` (`insn_of_good`).

`binary_correct_exec_of_got`: `binary_correct_exec_of_reads` with only the GOT fact (D4,
`RunGotN`) as hypothesis.
-/

namespace E2E.SemanticExecBytes

open Backend Backend.Proof E2E.LinkCheck E2E.SemanticBinary E2E.BinCheck

variable {I : SemanticStackBound.CompilerInput} {B : BaseEnv} {file : ByteArray}

/-- **A relocated byte is a code byte of the image.** -/
theorem relocAt_img (hI : SemanticStackBound.okB I = true) (hF : ∀ g ∈ (prog I).funcs, FnOk I file g)
    {a : BitVec 64} (h : RelocAtWithResults I I.results a) : ImgT (tabOf I.results) a := by
  obtain ⟨g, hg, rl, hrl, i, hi, rfl⟩ := relocAt_inv hI h
  obtain ⟨j, x, t, hj, -, ho⟩ := (FnAsm.layout_relocs (hF g hg).layout rl).1 hrl
  obtain ⟨lm, hm⟩ := FnAsm.layout_labelOffsets (hF g hg).layout
  obtain ⟨h4, w, -, hk⟩ := FnAsm.layout_word (hF g hg).layout hm hj rfl
  have hl := line_lt (hF g hg) hj
  have hfit := (hF g hg).fits
  refine ⟨(g, art I g), tab_mem (SemanticStackBound.okB_names hI) hg,
    ((art I g).base + BitVec.ofNat 64 (4 * (0 + lineOffset (art I g).fa.lines.toList j / 4)), w),
    ?_, ?_⟩
  · have := wordsAt_mem (base := (art I g).base) (k := 0) (ws := (art I g).fb.words.toList)
      (j := lineOffset (art I g).fa.lines.toList j / 4) (w := w) (by simpa using hk)
    simpa [FnBin.program] using this
  show ((wAt (art I g) (rl.offset + i)) - _).toNat < 4
  simp only [wAt, ← ho]
  rw [Nat.zero_add, Nat.mul_div_cancel' (Nat.dvd_of_mod_eq_zero h4), BitVec.ofNat_add,
    ← BitVec.add_assoc, BitVec.add_comm _ (BitVec.ofNat 64 i), BitVec.add_sub_cancel]
  simp only [BitVec.toNat_ofNat]
  omega

/-- **The bytes of a jump-table word of a function are no relocated bytes** (relocations are
at instruction lines, and code ranges are disjoint). -/
theorem word_static (hI : SemanticStackBound.okB I = true) (hc : codeMapB I (tabOf I.results) = true)
    (hF : ∀ g ∈ (prog I).funcs, FnOk I file g) {g : Clif.Function} (hg : g ∈ (prog I).funcs)
    {j : Nat} {tg bs : Lbl} (hj : (art I g).fa.lines.toList[j]? = some (.word tg bs)) :
    ∀ k < 4, ¬ RelocAtWithResults I I.results (wAt (art I g) (lineOffset (art I g).fa.lines.toList j) +
      BitVec.ofNat 64 k) := by
  intro k hk hR
  obtain ⟨h, hh, rl, hrl, i', hi', he⟩ := relocAt_inv hI hR
  obtain ⟨j', i2, t2, hj', -, ho⟩ := (FnAsm.layout_relocs (hF h hh).layout rl).1 hrl
  have hl' := line_lt (hF h hh) hj'
  have hfit := (hF h hh).fits
  have hfit' := (hF g hg).fits
  have hlw : lineOffset (art I g).fa.lines.toList j + 4 ≤ 4 * (art I g).fb.words.size := by
    have h1 := lineOffset_succ _ j _ hj
    have h2 := lineOffset_le_size (art I g).fa.lines.toList (j + 1)
    rw [layout_sum (hF g hg).layout] at h2
    simp only [Line.size] at h1
    omega
  have he' := congrArg BitVec.toNat he
  rw [BitVec.toNat_add, wAt, BitVec.toNat_add, BitVec.toNat_ofNat, BitVec.toNat_ofNat,
    Nat.mod_eq_of_lt (by omega : k < 2 ^ 64),
    Nat.mod_eq_of_lt (by omega : lineOffset (art I g).fa.lines.toList j < 2 ^ 64),
    Nat.mod_eq_of_lt (by omega), Nat.mod_eq_of_lt (by omega), wAt, BitVec.toNat_add,
    BitVec.toNat_ofNat, Nat.mod_eq_of_lt (by omega : rl.offset + i' < 2 ^ 64),
    Nat.mod_eq_of_lt (by omega)] at he'
  have hal := line_overlap hI hc hF hg hh hj hj' rfl rfl hk hi' (by rw [ho]; omega)
  simp [lineAlikeB] at hal

/-- **`StepOkR.insn` (D2) from the per-state facts**: the reads of the decoded word at the pc
avoid the relocated bytes. -/
theorem insn_of_good (hI : SemanticStackBound.okB I = true) (hc : codeMapB I (tabOf I.results) = true)
    (hF : ∀ g ∈ (prog I).funcs, FnOk I file g) {M : Nat} {g : Clif.Function}
    (hg : g ∈ (prog I).funcs) {c t : Arm.ArmState} (hgood : (sys I B).GoodAt M g c t) :
    ∀ i, insnAt (art I g).fa (art I g).base (Arm.r .PC t) = some i → i.hooked = false →
      ∀ a, (fileWord file (Arm.r .PC t)).bind Arm.decode_raw_inst = some a →
      ∀ e, Sim I t e → Sim I (Arm.exec_inst a t) (Arm.exec_inst a e) := by
  obtain ⟨X, K, G, gv, -, hG, himg, -⟩ := hgood
  unfold actGoodX at hG
  have hFg := hF g hg
  obtain ⟨lm, hm⟩ := FnAsm.layout_labelOffsets hFg.layout
  intro i hi hh a ha e hsim
  refine exec_sim a hsim fun p hp k hk hR => ?_
  have hrdA := hG.reads
  obtain ⟨j, tt, hj, hpc⟩ := insnAt_spec hi
  -- the line at the pc is outside the TLS tail, so it carries no relocation
  obtain ⟨x, ⟨jx, tx, hjx, hpcx⟩, htl⟩ := hG.line
  have hxi : x = i := by
    have h1 := insnAt_of_line hFg hjx
    have h2 : wAt (art I g) (lineOffset (art I g).fa.lines.toList jx) = Arm.r .PC t := hpcx.symm
    rw [h2, hi] at h1
    exact (Option.some.inj h1).symm
  subst hxi
  have hr : x.reloc? = none := (Insn.reloc_of_tlsTail htl).resolve_right (by rw [hh]; decide)
  -- the file's word is the compiled one
  obtain ⟨w, hw, hfw⟩ := fileWord_plain hFg hm hj hr
  have hpcw : Arm.r .PC t = wAt (art I g) (lineOffset (art I g).fa.lines.toList j) := hpc.symm
  rw [hpcw, hfw, Option.bind_some] at ha
  obtain ⟨a', ha', hd⟩ := Insn.decode_encode hw
  rw [ha] at hd
  cases hd
  -- the register-level fact
  have hrd := hrdA j x tt hj hpcw hh _ a ha' p hp k hk
  rcases hrd with hnG | ⟨j', tg, bs, hj', q, hq, he⟩
  · exact hnG (himg _ (relocAt_img hI hF hR))
  · rw [he] at hR
    exact word_static hI hc hF hg hj' q hq hR

/-- **The GOT hypothesis** (D4 of `StepOkR`) at the states of `ReachN` whose step ends without
error. -/
def RunGotN (I : SemanticStackBound.CompilerInput) (B : BaseEnv) (file : ByteArray) (M : Nat) (f : Clif.Function)
    (c : Arm.ArmState) : Prop :=
  ∀ M' g t, ReachN I B M f c M' g t → Arm.r .ERR ((sys I B).mach M' g t) = .None →
    ∀ rl ∈ (art I g).fb.relocs, rl.type = .adrGotPage →
    Arm.r .PC t = wAt (art I g) (rl.offset + 4) → ∀ (rd G : Nat), rd < 31 → G % 8 = 0 →
    inR (-2 ^ 20) (2 ^ 20) (pageOf G - pageOf (wAt (art I g) rl.offset).toNat) = true →
    fileWord file (wAt (art I g) rl.offset) =
      some (adrpW rd (pageOf G - pageOf (wAt (art I g) rl.offset).toNat)) →
    fileWord file (wAt (art I g) (rl.offset + 4)) = some (ldrW rd rd (G % 4096 / 8)) → ∀ i < 8,
    ¬ RelocAtWithResults I I.results (BitVec.ofNat 64 G + BitVec.ofNat 64 i) ∧
    t.mem (BitVec.ofNat 64 G + BitVec.ofNat 64 i) =
      (Elf.loadMem file (BitVec.ofNat 64 G + BitVec.ofNat 64 i)).getD 0

/-- **`RunReadsN` from the per-state facts and the GOT hypothesis.** -/
theorem runReadsN_of_good (hI : SemanticStackBound.okB I = true) (hc : codeMapB I (tabOf I.results) = true)
    (hF : ∀ g ∈ (prog I).funcs, FnOk I file g) {M : Nat} {f : Clif.Function}
    (hf : f ∈ (prog I).funcs) {c : Arm.ArmState}
    (hra : ∀ k < (art I f).fb.words.size, xreg 30 c ≠ (art I f).base + BitVec.ofNat 64 (4 * k))
    (hgood : (sys I B).RunGoodL M f c) (hgot : RunGotN I B file M f c) :
    RunReadsN I B file M f c := fun M' g t hR he => by
  obtain ⟨c', hRL, -⟩ := reachL_of_reachN hI hc hF hR hf hgood (raNotSecond_top (hF f hf) hra)
  exact ⟨insn_of_good hI hc hF (reachN_mem hR hf) (hgood _ _ _ _ hRL he), hgot M' g t hR he⟩

/-- **`binary_correct_exec_static` with the per-state facts of the register-level proof and only
the GOT hypothesis**: under the premises of `binary_correct_of_checks_acyclic`, the outside-code
contract `HooksSim`, the code map check `codeMapB` and the GOT fact `RunGotN` (D4) of the model's
run, the executable machine run from `r` refines the whole-program CLIF run. -/
theorem binary_correct_exec_of_got {I : SemanticStackBound.CompilerInput} {D : List Clif.DataObject}
    {file : ByteArray} (hI : SemanticStackBound.okB I = true) (hcm : codeMapB I (tabOf I.results) = true)
    (hbin : BinCheck.BinOkWithResults I I.results D file) (B : BaseEnv) (hB : BaseOk (sys I B)) (hH : HooksSim I B)
    {n : String} {f : Clif.Function} (hf : (prog I).func? n = some f)
    (hc : ¬ SemanticStackBound.CycleFrom (SemanticStackBound.Calls I I.results) f) (M : Nat) {r : Arm.ArmState}
    {args : List Clif.Val} {cs : Clif.State} (hX : (imageOf file).Intact r)
    (ho : OutsideCall I (BinCheck.roByte I D) f (SemanticStackBound.stackFn I f) r args cs.mem)
    (hr : ClifRun I B f r args cs)
    (htr : TrapsExplicit (Clif.linkEnvN (prog I) B.env M) (prog I).bare cs)
    (hgot : RunGotN I B file M f (modelOf I f r)) :
    ExecRefines (art I f).fb (art I f).base (xreg 30 r) (step I B file) r (RelocAtWithResults I I.results)
      (Clif.runLoop B.env (prog I) (M + 1) cs) := by
  have hn := (SemanticStackBound.goodN_iff hI).2 ⟨f, hf, hc⟩
  obtain ⟨-, -, hG⟩ := binary_correct_of_checksX hI hbin B hB hn hf M hX ho hr htr
  by_cases hout : (∃ vals cm, Clif.runLoop B.env (prog I) (M + 1) cs = .returned vals cm) ∨
      (∃ c, Clif.runLoop B.env (prog I) (M + 1) cs = .trapped c)
  · have hfm := (Clif.Program.func?_some hf).1
    have hB' : BaseOk (SemanticStackBound.ofInput I B (worldF I f (SemanticStackBound.bud I f) r)) := baseOk_F hB
    have hL := SemanticStackBound.okB_sound hI hB' fun _ h => .inr h
    have hfacts := binFacts_of_checks hI hbin
    have hro : ∀ a b, BinCheck.roByte I D a = some b → r.mem a = b := fun a b h =>
      hX a b (hfacts.data a b h).1 (hfacts.data a b h).2
    obtain ⟨hent, -⟩ := premises hL hfm hro ho hr
    have hL' := SemanticStackBound.okB_sound hI (baseOk_F (F' := img I) hB) fun _ h => h
    have hF : ∀ g ∈ (prog I).funcs, FnOk I file g := fun g hg => fnOk hI hbin hL' hg
    have hra : ∀ k < (art I f).fb.words.size,
        xreg 30 (modelOf I f r) ≠ (art I f).base + BitVec.ofNat 64 (4 * k) := by
      simp only [xreg, r_modelOf]; exact hent.raOutside
    exact binary_correct_exec_staticN hI hcm hbin B hB hH hf hc M hX ho hr htr
      (runOkN_of_good hI hcm hF (fun g hg => destsInt_of_ok hL' hg) hfm hra (hG hout)
        (runReadsN_of_good hI hcm hF hfm hra (hG hout) hgot))
  · cases h : Clif.runLoop B.env (prog I) (M + 1) cs with
    | returned vals cm => exact absurd (.inl ⟨vals, cm, h⟩) hout
    | trapped c => exact absurd (.inr ⟨c, h⟩) hout
    | stuck _ => trivial
    | outOfFuel => trivial

end E2E.SemanticExecBytes

/-! # The binary theorem with D2 and D4 from the M6 proof (L3 (c))

`binary_correct_exec_of_insn` (`ExecGot.lean`, D4 proven) assumes D2 (`RunInsnN`) at every state
of the model's run whose step ends without error; `insn_of_good` (`ExecGoodReads.lean`) proves it
from the register-level per-state facts (`GoodAt`, `RL.GoodX.reads`), `got_of_good` proves D4.
`exec_of_runGood` composes them with the lockstep (`exec_of_modelN`) from the model-level facts of
the run, whatever the callees' stack budget: the model's refinement, its difference from the
machine state, and `RunGoodL` of the linked system and of the one keeping the GOT slots. Two
instances, no per-state hypothesis left — `RunOkD` of `binary_correct_exec_static` is proven from
the M6 proof:

* `binary_correct_exec_proven`: no call cycle reachable from the entry, the stack bound
  `stackFn` (`binary_correct_of_checksX`, `runGood_sysS`);
* `binary_correct_exec_depth_proven`: any program, recursive ones included, the stack
  `frameDrop + D * M` of the depth-`M` budget (`binary_correct_depthX`, `runGood_sysS_depth`);
* `binary_correct_exec_peak_proven`: the same with the stack `frameDrop + D * d` for the run's
  peak call depth `d` (`Clif.DepthLe`) instead of its fuel (`binary_correct_peakX`,
  `runGood_sysS_peak`).
-/

namespace E2E.SemanticExecBytes

open Backend Backend.Proof E2E.LinkCheck E2E.SemanticBinary E2E.BinCheck

/-- **The executable's run from the model-level facts**: for an entry `hent` of the model state,
the model's refinement `hA` of an outcome `o`, the model state differing from `r` only at the
relocated instruction bytes, and (for a returning or trapping `o`) `RunGoodL` of the linked system
and of the one keeping the GOT slots with some callees' budget `K`, the executable machine run
from `r` refines `o`. -/
theorem exec_of_runGood {I : SemanticStackBound.CompilerInput} {D : List Clif.DataObject} {file : ByteArray}
    (hI : SemanticStackBound.okB I = true) (hcm : codeMapB I (tabOf I.results) = true)
    (hbin : BinCheck.BinOkWithResults I I.results D file) (hgot : GotOk I file) {B : BaseEnv} (hB : BaseOk (sys I B))
    (hH : HooksSim I B) {f : Clif.Function} (hfm : f ∈ (prog I).funcs) {M K : Nat}
    {r : Arm.ArmState} (hX : (imageOf file).Intact r)
    (hent : AbiEntry (art I f).fb (art I f).base (xreg 30 r) (modelOf I f r))
    (hd : ∀ a, (modelOf I f r).mem a ≠ r.mem a → RelocAtWithResults I I.results a) {o : Clif.Outcome}
    (hA : ArmRefines (art I f).fb (art I f).base (xreg 30 r) ((sys I B).mach M f) (modelOf I f r) o)
    (hgood : ((∃ vals cm, o = .returned vals cm) ∨ (∃ c, o = .trapped c)) →
      (sys I B).RunGoodL M f (modelOf I f r) ∧
        (sysS I B f K r (GotSlot I file)).RunGoodL M f (modelOf I f r)) :
    ExecRefines (art I f).fb (art I f).base (xreg 30 r) (step I B file) r (RelocAtWithResults I I.results) o := by
  by_cases hout : (∃ vals cm, o = .returned vals cm) ∨ (∃ c, o = .trapped c)
  · obtain ⟨hG, hgS⟩ := hgood hout
    have hL' := SemanticStackBound.okB_sound hI (baseOk_F (F' := img I) hB) fun _ h => h
    have hF : ∀ g ∈ (prog I).funcs, FnOk I file g := fun g hg => fnOk hI hbin hL' hg
    have hra : ∀ k < (art I f).fb.words.size,
        xreg 30 (modelOf I f r) ≠ (art I f).base + BitVec.ofNat 64 (4 * k) := by
      simp only [xreg, r_modelOf]; exact hent.raOutside
    refine exec_of_modelN hF hfm (by rw [← r_modelOf I f r]; exact hent.pc) hent.raOutside hd
      (runOkSN_of_n hI hcm hF hH hfm (runOkN_of_good hI hcm hF (fun g hg => destsInt_of_ok hL' hg)
        hfm hra hG fun M' g t hR he => ?_)) hA
    obtain ⟨c', hRL, -⟩ := reachL_of_reachN hI hcm hF hR hfm hG (raNotSecond_top (hF f hfm) hra)
    have hg := reachN_mem hR hfm
    have hRL' : (sysS I B f K r (GotSlot I file)).ReachL M f (modelOf I f r) M' g c' t :=
      LinkSys.reachL_extImg_semantic (SemanticBinary.reachL_F (F' := fun _ => False) hRL)
    exact ⟨insn_of_good hI hcm hF hg (hG _ _ _ _ hRL he), got_of_good hI hbin hgot hX hg (hF g hg)
      (hgS _ _ _ _ hRL' (by rw [mach_sysS]; exact he))⟩
  · cases o with
    | returned vals cm => exact absurd (.inl ⟨vals, cm, rfl⟩) hout
    | trapped c => exact absurd (.inr ⟨c, rfl⟩) hout
    | stuck _ => trivial
    | outOfFuel => trivial

/-- **The binary theorem about the executable's own words** (L3; `docs/contracts/e2e.md`): under the premises of `binary_correct_of_checks_acyclic`, the outside-code
contract `HooksSim`, the code map check `codeMapB`, the GOT check (`GotOk`, from `gotB`) and the
outside caller keeping the GOT slots off its stack, arguments and live memory (`OutsideAvoids`),
the executable machine run from `r` refines the whole-program CLIF run. -/
theorem binary_correct_exec_proven {I : SemanticStackBound.CompilerInput} {D : List Clif.DataObject}
    {file : ByteArray} (hI : SemanticStackBound.okB I = true) (hcm : codeMapB I (tabOf I.results) = true)
    (hbin : BinCheck.BinOkWithResults I I.results D file) (hgot : GotOk I file) (B : BaseEnv) (hB : BaseOk (sys I B))
    (hH : HooksSim I B) {n : String} {f : Clif.Function} (hf : (prog I).func? n = some f)
    (hc : ¬ SemanticStackBound.CycleFrom (SemanticStackBound.Calls I I.results) f) (M : Nat) {r : Arm.ArmState}
    {args : List Clif.Val} {cs : Clif.State} (hX : (imageOf file).Intact r)
    (ho : OutsideCall I (BinCheck.roByte I D) f (SemanticStackBound.stackFn I f) r args cs.mem)
    (hav : OutsideAvoids (GotSlot I file) f (SemanticStackBound.stackFn I f) r args cs.mem)
    (hr : ClifRun I B f r args cs)
    (htr : TrapsExplicit (Clif.linkEnvN (prog I) B.env M) (prog I).bare cs) :
    ExecRefines (art I f).fb (art I f).base (xreg 30 r) (step I B file) r (RelocAtWithResults I I.results)
      (Clif.runLoop B.env (prog I) (M + 1) cs) := by
  have hn := (SemanticStackBound.goodN_iff hI).2 ⟨f, hf, hc⟩
  obtain ⟨hA, hd, hG⟩ := binary_correct_of_checksX hI hbin B hB hn hf M hX ho hr htr
  have hfm := (Clif.Program.func?_some hf).1
  have hL := SemanticStackBound.okB_sound hI (baseOk_F (F' := worldF I f (SemanticStackBound.bud I f) r) hB)
    fun _ h => .inr h
  have hfacts := binFacts_of_checks hI hbin
  have hro : ∀ a b, BinCheck.roByte I D a = some b → r.mem a = b := fun a b h =>
    hX a b (hfacts.data a b h).1 (hfacts.data a b h).2
  obtain ⟨hent, -⟩ := premises hL hfm hro ho hr
  exact exec_of_runGood hI hcm hbin hgot hB hH hfm hX hent hd hA fun hout =>
    ⟨hG hout, runGood_sysS hI hbin hB hn hf M hX ho hav hr htr hout⟩

/-- **The binary theorem about the executable's own words for any program**, recursive ones
included: `binary_correct_exec_proven` without the call-graph premise (`¬ CycleFrom`), the outside
caller providing the stack `frameDrop + D * M` of the depth-`M` budget (every call level at most
`D` bytes, `LinkSys.budget_K_semantic`) instead of the stack bound `stackFn` of a non-recursive program.
`M` is the CLIF run's fuel (at most `M + 1` steps of the whole-program run) and the depth of the
proof's linked machine: the stack is proportional to the fuel, not to the run's actual peak call
depth. -/
theorem binary_correct_exec_depth_proven {I : SemanticStackBound.CompilerInput} {D : List Clif.DataObject}
    {file : ByteArray} (hI : SemanticStackBound.okB I = true) (hcm : codeMapB I (tabOf I.results) = true)
    (hbin : BinCheck.BinOkWithResults I I.results D file) (hgot : GotOk I file) (B : BaseEnv) (hB : BaseOk (sys I B))
    (hH : HooksSim I B) {n : String} {f : Clif.Function} (hf : (prog I).func? n = some f)
    (M : Nat) {r : Arm.ArmState} {args : List Clif.Val} {cs : Clif.State}
    (hX : (imageOf file).Intact r)
    (ho : OutsideCall I (BinCheck.roByte I D) f (frameDrop (art I f).af + I.D * M) r args cs.mem)
    (hav : OutsideAvoids (GotSlot I file) f (frameDrop (art I f).af + I.D * M) r args cs.mem)
    (hr : ClifRun I B f r args cs)
    (htr : TrapsExplicit (Clif.linkEnvN (prog I) B.env M) (prog I).bare cs) :
    ExecRefines (art I f).fb (art I f).base (xreg 30 r) (step I B file) r (RelocAtWithResults I I.results)
      (Clif.runLoop B.env (prog I) (M + 1) cs) := by
  have hfacts := binFacts_of_checks hI hbin
  obtain ⟨hA, hd, hG⟩ := binary_correct_depthX hfacts B hB hf M hX ho hr htr
  have hfm := (Clif.Program.func?_some hf).1
  have hL := SemanticStackBound.okB_sound hI (baseOk_F (F' := worldF I f (I.D * M) r) hB) fun _ h => .inr h
  have hro : ∀ a b, BinCheck.roByte I D a = some b → r.mem a = b := fun a b h =>
    hX a b (hfacts.data a b h).1 (hfacts.data a b h).2
  obtain ⟨hent, -⟩ := premises hL hfm hro ho hr
  exact exec_of_runGood hI hcm hbin hgot hB hH hfm hX hent hd hA fun hout =>
    ⟨hG hout, runGood_sysS_depth hI hbin hB hfm M hX ho hav hr htr hout⟩

/-- **The binary theorem about the executable's own words for the run's peak call depth** (L1d):
`binary_correct_exec_depth_proven` with the stack `frameDrop + D * d`, where `d` bounds the call
depth of the whole-program CLIF run (`Clif.DepthLe`: every state it reaches has at most `d`
callers), independent of its fuel `F` (at most `F + 1` steps). The run premise `TrapsExplicit` is
under `Clif.linkEnvD` (program callees with fuel `F` and at most `d - 1` callers of their own). -/
theorem binary_correct_exec_peak_proven {I : SemanticStackBound.CompilerInput} {D : List Clif.DataObject}
    {file : ByteArray} (hI : SemanticStackBound.okB I = true) (hcm : codeMapB I (tabOf I.results) = true)
    (hbin : BinCheck.BinOkWithResults I I.results D file) (hgot : GotOk I file) (B : BaseEnv) (hB : BaseOk (sys I B))
    (hH : HooksSim I B) {n : String} {f : Clif.Function} (hf : (prog I).func? n = some f)
    (F d : Nat) {r : Arm.ArmState} {args : List Clif.Val} {cs : Clif.State}
    (hX : (imageOf file).Intact r)
    (ho : OutsideCall I (BinCheck.roByte I D) f (frameDrop (art I f).af + I.D * d) r args cs.mem)
    (hav : OutsideAvoids (GotSlot I file) f (frameDrop (art I f).af + I.D * d) r args cs.mem)
    (hr : ClifRun I B f r args cs) (hd : Clif.DepthLe B.env (prog I) d cs)
    (htr : TrapsExplicit (Clif.linkEnvD (prog I) B.env F d) (prog I).bare cs) :
    ExecRefines (art I f).fb (art I f).base (xreg 30 r) (step I B file) r (RelocAtWithResults I I.results)
      (Clif.runLoop B.env (prog I) (F + 1) cs) := by
  have hfacts := binFacts_of_checks hI hbin
  obtain ⟨hA, hdiff, hG⟩ := binary_correct_peakX hfacts B hB hf F d hX ho hr hd htr
  have hfm := (Clif.Program.func?_some hf).1
  have hL := SemanticStackBound.okB_sound hI (baseOk_F (F' := worldF I f (I.D * d) r) hB) fun _ h => .inr h
  have hro : ∀ a b, BinCheck.roByte I D a = some b → r.mem a = b := fun a b h =>
    hX a b (hfacts.data a b h).1 (hfacts.data a b h).2
  obtain ⟨hent, -⟩ := premises hL hfm hro ho hr
  exact exec_of_runGood hI hcm hbin hgot hB hH hfm hX hent hdiff hA fun hout =>
    ⟨hG hout, runGood_sysS_peak hI hbin hB hfm F d hX ho hav hr hd htr hout⟩

end E2E.SemanticExecBytes

/-! Closed correctness of the successful production executable attempt.
No program-specific premise beyond the original machine/source boundary remains. -/
set_option autoImplicit false
namespace Link.SemanticCompilerWith
open E2E E2E.LinkCheck E2E.BinCheck E2E.Elf E2E.SemanticBinary E2E.SemanticExecBytes Backend
variable {lower : ProductionLowering}

abbrev input (lower : ProductionLowering) (S : LinkSpec) (cleanup : Bool) : SemanticStackBound.CompilerInput :=
  {toLinkInput := S.inputProductionWith lower cleanup,cleanup,lower}

theorem attempt_spec {S : LinkSpec} {cleanup : Bool} {file0 file : ByteArray}
    (h : attempt lower S file0 cleanup = .ok file) :
    SemanticStackBound.okB (input lower S cleanup) = true ∧
    leanLinkProductionWith lower S file0 cleanup = .ok file := by
  cases cleanup <;> simp [attempt] at h
  all_goals
    split at h
    · cases h
    · split at h
      · rename_i checked
        exact ⟨checked,h⟩
      · cases h


theorem codeMap_leanLink {S : LinkSpec} {cleanup : Bool} {file0 file : ByteArray}
    (h : leanLinkProductionWith lower S file0 cleanup = .ok file) :
    codeMapB (input lower S cleanup) (tabOf (input lower S cleanup).results) = true := by
  obtain ⟨_,_,_,_,_,_,_,hc,_⟩ := ProductionImageWithProof.spec h
  exact hc

theorem leanLink_gotSlot {S : LinkSpec} {cleanup : Bool} {file0 file : ByteArray}
    (h : leanLinkProductionWith lower S file0 cleanup = .ok file) (a : BitVec 64) : ¬ GotSlot (input lower S cleanup) file a := by
  rintro ⟨e, he, rl, hrl, ht, rd, G, hrd, -, -, -, h1, -⟩
  change e ∈ tabOf (ProductionImageWithProof.resultsFor lower S cleanup) at he
  obtain ⟨tp, -, hw⟩ := ProductionImageWithProof.words h
  obtain ⟨hv, -, himg⟩ := hw e he
  simp only [relocsOkB, Bool.and_eq_true, decide_eq_true_eq, List.all_eq_true] at hv
  obtain ⟨hnd, hall⟩ := hv
  have hok := hall rl hrl
  have hra := relocAt?_of_mem hnd hrl rfl
  obtain ⟨o, ty, sym, add⟩ := rl
  simp only at ht h1 hra
  subst ht
  simp only [relocOkB, Bool.and_eq_true, beq_iff_eq, decide_eq_true_eq] at hok
  obtain ⟨⟨ho4, hon⟩, hok⟩ := hok
  simp only [Bool.and_eq_true, beq_iff_eq, decide_eq_true_eq, List.any_eq_true] at hok
  obtain ⟨⟨⟨⟨⟨-, h1'⟩, -⟩, -⟩, ⟨r', hr', ⟨⟨ho', ht'⟩, -⟩, -⟩⟩, -⟩ := hok
  have hra' := relocAt?_of_mem hnd hr' ho'
  have hx1 := himg (o / 4 + 1) h1'
  rw [show 4 * (o / 4 + 1) = o + 4 by omega] at hx1
  simp only [resolveWord, show 4 * (o / 4 + 1) = o + 4 by omega, hra', ht', loOf,
    Nat.add_sub_cancel, hra] at hx1
  simp only [fileWord] at h1
  rw [hx1, Option.some.injEq] at h1
  exact addW_ne_ldrW (Nat.mod_lt _ (by decide)) (Nat.mod_lt _ (by decide))
    (Nat.mod_lt _ (by decide)) (by omega) (by omega) (by omega) h1

/-- **`GotOk` of `leanLink`'s output** (no GOT slot). -/
theorem gotOk_leanLink {S : LinkSpec} {cleanup : Bool} {file0 file : ByteArray}
    (h : leanLinkProductionWith lower S file0 cleanup = .ok file) : GotOk (input lower S cleanup) file :=
  fun a ha => (leanLink_gotSlot h a ha).elim

/-- The outside caller avoids `leanLink`'s GOT slots (there is none). -/
theorem outsideAvoids_leanLink {S : LinkSpec} {cleanup : Bool} {file0 file : ByteArray}
    (h : leanLinkProductionWith lower S file0 cleanup = .ok file) (f : Clif.Function) (N : Nat) (r : Arm.ArmState)
    (args : List Clif.Val) (cm : Clif.Mem) : OutsideAvoids (GotSlot (input lower S cleanup) file) f N r args cm where
  stack a ha := (leanLink_gotSlot h a ha).elim
  args _ _ _ k _ hs := leanLink_gotSlot h _ hs
  valid _ _ _ _ _ hs := leanLink_gotSlot h _ hs

theorem attempt_correct {S : LinkSpec} {cleanup : Bool} {file0 file : ByteArray}
    (h : attempt lower S file0 cleanup = .ok file) (B : BaseEnv) (hB : BaseOk (sys (input lower S cleanup) B))
    (hH : HooksSim (input lower S cleanup) B) {n : String} {f : Clif.Function} (hf : (prog (input lower S cleanup)).func? n = some f)
    (hc : ¬ SemanticStackBound.CycleFrom (SemanticStackBound.Calls (input lower S cleanup) (input lower S cleanup).results) f) (M : Nat)
    {r : Arm.ArmState} {args : List Clif.Val} {cs : Clif.State} (hX : (imageOf file).Intact r)
    (ho : OutsideCall (input lower S cleanup) (BinCheck.roByte (input lower S cleanup) S.data) f (SemanticStackBound.stackFn (input lower S cleanup) f) r
      args cs.mem)
    (hr : ClifRun (input lower S cleanup) B f r args cs)
    (htr : TrapsExplicit (Clif.linkEnvN (prog (input lower S cleanup)) B.env M) (prog (input lower S cleanup)).bare cs) :
    ExecRefines (art (input lower S cleanup) f).fb (art (input lower S cleanup) f).base (xreg 30 r) (step (input lower S cleanup) B file) r
      (RelocAtWithResults (input lower S cleanup) (input lower S cleanup).results) (Clif.runLoop B.env (prog (input lower S cleanup)) (M + 1) cs) := by
  obtain ⟨hin, hl⟩ := attempt_spec h
  exact binary_correct_exec_proven hin
    (codeMap_leanLink hl) (ProductionImageWithProof.bin_ok hl) (gotOk_leanLink hl) B hB hH hf hc M hX ho
    (outsideAvoids_leanLink hl _ _ _ _ _) hr htr

/-- **The executable compiler is correct for recursive programs** (L1d): `attempt_correct`
without the call-graph premise `¬ CycleFrom`. The outside caller of `f` provides
`frameDrop (art (input lower S cleanup) f).af + (input lower S cleanup).D * M` bytes of stack (`(input lower S cleanup).D`: the largest frame of
the program, `LinkSpec.input`), where `M + 1` bounds the whole-program CLIF run's steps; for that
run (returning, or trapping explicitly) the executable machine run of `file`'s own words refines
it (`ExecRefines`). The stack is proportional to the fuel `M`, not to the run's actual peak call
depth: an overestimate of what the code uses (docs/contracts/e2e.md, "Recursive programs"). -/
theorem attempt_correct_depth {S : LinkSpec} {cleanup : Bool} {file0 file : ByteArray}
    (h : attempt lower S file0 cleanup = .ok file) (B : BaseEnv) (hB : BaseOk (sys (input lower S cleanup) B))
    (hH : HooksSim (input lower S cleanup) B) {n : String} {f : Clif.Function} (hf : (prog (input lower S cleanup)).func? n = some f)
    (M : Nat) {r : Arm.ArmState} {args : List Clif.Val} {cs : Clif.State}
    (hX : (imageOf file).Intact r)
    (ho : OutsideCall (input lower S cleanup) (BinCheck.roByte (input lower S cleanup) S.data) f
      (frameDrop (art (input lower S cleanup) f).af + (input lower S cleanup).D * M) r args cs.mem)
    (hr : ClifRun (input lower S cleanup) B f r args cs)
    (htr : TrapsExplicit (Clif.linkEnvN (prog (input lower S cleanup)) B.env M) (prog (input lower S cleanup)).bare cs) :
    ExecRefines (art (input lower S cleanup) f).fb (art (input lower S cleanup) f).base (xreg 30 r) (step (input lower S cleanup) B file) r
      (RelocAtWithResults (input lower S cleanup) (input lower S cleanup).results) (Clif.runLoop B.env (prog (input lower S cleanup)) (M + 1) cs) := by
  obtain ⟨hin, hl⟩ := attempt_spec h
  exact binary_correct_exec_depth_proven hin
    (codeMap_leanLink hl) (ProductionImageWithProof.bin_ok hl) (gotOk_leanLink hl) B hB hH hf M hX ho
    (outsideAvoids_leanLink hl _ _ _ _ _) hr htr

/-- **The executable compiler is correct for recursive programs, with the stack of the run's peak
call depth** (L1d): `attempt_correct_depth` with `frameDrop (art (input lower S cleanup) f).af + (input lower S cleanup).D * d`
bytes of stack, where `d` bounds the call depth of the whole-program CLIF run (`Clif.DepthLe`:
every state the run from `cs` reaches has at most `d` callers, i.e. at most `d + 1` live
activations), independent of its length (at most `F + 1` steps). For that run (returning, or
trapping explicitly; `TrapsExplicit` under the environment whose program callees run with fuel
`F` and at most `d - 1` callers of their own, `Clif.linkEnvD`) the executable machine run of
`file`'s own words refines it (`ExecRefines`). Each level is charged the largest frame of the
program (`(input lower S cleanup).D`). -/
theorem attempt_correct_peak {S : LinkSpec} {cleanup : Bool} {file0 file : ByteArray}
    (h : attempt lower S file0 cleanup = .ok file) (B : BaseEnv) (hB : BaseOk (sys (input lower S cleanup) B))
    (hH : HooksSim (input lower S cleanup) B) {n : String} {f : Clif.Function} (hf : (prog (input lower S cleanup)).func? n = some f)
    (F d : Nat) {r : Arm.ArmState} {args : List Clif.Val} {cs : Clif.State}
    (hX : (imageOf file).Intact r)
    (ho : OutsideCall (input lower S cleanup) (BinCheck.roByte (input lower S cleanup) S.data) f
      (frameDrop (art (input lower S cleanup) f).af + (input lower S cleanup).D * d) r args cs.mem)
    (hr : ClifRun (input lower S cleanup) B f r args cs)
    (hd : Clif.DepthLe B.env (prog (input lower S cleanup)) d cs)
    (htr : TrapsExplicit (Clif.linkEnvD (prog (input lower S cleanup)) B.env F d) (prog (input lower S cleanup)).bare cs) :
    ExecRefines (art (input lower S cleanup) f).fb (art (input lower S cleanup) f).base (xreg 30 r) (step (input lower S cleanup) B file) r
      (RelocAtWithResults (input lower S cleanup) (input lower S cleanup).results) (Clif.runLoop B.env (prog (input lower S cleanup)) (F + 1) cs) := by
  obtain ⟨hin, hl⟩ := attempt_spec h
  exact binary_correct_exec_peak_proven hin
    (codeMap_leanLink hl) (ProductionImageWithProof.bin_ok hl) (gotOk_leanLink hl) B hB hH hf F d hX ho
    (outsideAvoids_leanLink hl _ _ _ _ _) hr hd htr


end Link.SemanticCompilerWith

/-! Original-source and peak-depth variants for the actual production attempt.
The legalisation/world/foreign-code assumptions match the retained variants. -/
set_option autoImplicit false
namespace Link.SemanticCompilerWith
open E2E E2E.LinkCheck E2E.BinCheck E2E.Elf E2E.SemanticBinary E2E.SemanticExecBytes
  E2E.LegalProgram Backend LinkSpec Opt.Legalize128
variable {lower : ProductionLowering}

theorem prog_eq_legal (I : SemanticStackBound.CompilerInput) :
    prog I = legalProg I.toLinkInput.srcProg := by
  rw [← LinkInput.prog_eq]
  simp [prog, ProductionStackBound.CompilerInput.results, LinkInput.resultsProductionWith,
    progOf, LinkInput.prog, Function.comp_def]

theorem attempt_correct_source {S : LinkSpec} {cleanup : Bool} {file0 file : ByteArray}
    (h : attempt lower S file0 cleanup = .ok file) (hsrc : SrcScopeB (input lower S cleanup) = true)
    (B : BaseEnv) (hB : BaseOk (sys (input lower S cleanup) B)) (hH : HooksSim (input lower S cleanup) B)
    (hlegal : (∃ f ∈ (input lower S cleanup).toLinkInput.srcProg.funcs, mentions128 f = true) →
      Opt.Legal.HelperOk B.env ∧ Opt.Legal.ExtLegal B.env ∧ Opt.Legal.EnvKeepsBounded B.env)
    (hsig : (∃ g ∈ (prog (input lower S cleanup)).funcs, ¬ Clif.IndFree g) → ∀ n, B.env.sigOf n = none)
    {n : String} {f : Clif.Function} (hf : (input lower S cleanup).toLinkInput.srcProg.func? n = some f)
    (hc : ¬ SemanticStackBound.CycleFrom (SemanticStackBound.Calls (input lower S cleanup) (input lower S cleanup).results) (legalize f))
    {r : Arm.ArmState} {args args' : List Clif.Val} {cs cs' : Clif.State}
    (hX : (imageOf file).Intact r)
    (ho : OutsideCall (input lower S cleanup) (BinCheck.roByte (input lower S cleanup) S.data) (legalize f)
      (SemanticStackBound.stackFn (input lower S cleanup) (legalize f)) r args' cs'.mem)
    (hr : ClifRun (input lower S cleanup) B (legalize f) r args' cs')
    (hcs : ClifEntry f args cs)
    (hexp : Opt.Legal.ExpRel ((Opt.Legal.groups f.sig.params).getD []) args args')
    (hsl : cs'.frame.slots = cs.frame.slots) (hmem : cs'.mem = cs.mem)
    (hbnd : ∀ s', Opt.Legal.SReach B.env (input lower S cleanup).toLinkInput.srcProg cs s' → Opt.Legal.MemBounded s'.mem)
    (M : Nat) :
    (∀ vals cm, Clif.runLoop B.env (input lower S cleanup).toLinkInput.srcProg M cs = .returned vals cm →
      ∃ vals', Opt.Legal.ExpRel ((Opt.Legal.groups f.sig.returns).getD []) vals vals' ∧
        ExecRefines (art (input lower S cleanup) (legalize f)).fb (art (input lower S cleanup) (legalize f)).base (xreg 30 r)
          (step (input lower S cleanup) B file) r (RelocAtWithResults (input lower S cleanup) (input lower S cleanup).results) (.returned vals' cm)) ∧
    ((∀ M, TrapsExplicit (Clif.linkEnvN (prog (input lower S cleanup)) B.env M) (prog (input lower S cleanup)).bare cs') →
      Opt.Legal.NoMemTrap B.env (input lower S cleanup).toLinkInput.srcProg cs → ∀ c,
      Clif.runLoop B.env (input lower S cleanup).toLinkInput.srcProg M cs = .trapped c →
      ExecRefines (art (input lower S cleanup) (legalize f)).fb (art (input lower S cleanup) (legalize f)).base (xreg 30 r)
        (step (input lower S cleanup) B file) r (RelocAtWithResults (input lower S cleanup) (input lower S cleanup).results) (.trapped c)) := by
  obtain ⟨hin, hl⟩ := attempt_spec h
  have hok := hin
  have hL : (SemanticStackBound.ofInput (input lower S cleanup) B fun _ => True).OkSemanticNI :=
    SemanticStackBound.okB_sound hok (baseOk_F hB) fun _ _ => trivial
  have hpe := prog_eq_legal (input lower S cleanup)
  have hpe' : (input lower S cleanup).toLinkInput.prog = prog (input lower S cleanup) := by rw [hpe, LinkInput.prog_eq]
  -- the source domain
  have hC : ProgCtx (input lower S cleanup).toLinkInput.srcProg B.env (fun n => (input lower S cleanup).syms.lookup n) :=
    srcCtx hsrc (by rw [hpe']; exact hL.names) (by rw [hpe']; exact hL.free)
      (by rw [hpe']; exact hL.declSig) (by rw [hpe']; exact hL.indScope) hlegal
      (by rw [hpe']; exact hsig)
  have hfP := (Clif.Program.func?_some hf).1
  have hf' : (prog (input lower S cleanup)).func? n = some (legalize f) := by
    rw [hpe]; exact hC.func?_some hf
  -- the entries
  have hcs' := hr.entry
  obtain ⟨b, hb, h2, h3, h4, h5⟩ := hcs.entry
  obtain ⟨b', hb', h2', h3', -, h5'⟩ := hcs'.entry
  have hE : EntryRel f args args' cs.frame cs'.frame :=
    ⟨hcs.func, hcs'.func, ⟨b, hb, h2, h3, h4, h5⟩, ⟨b', hb', h2', h3', h5'⟩, hsl, hexp⟩
  have hst : (⟨cs.frame, [], cs.mem⟩ : Clif.State) = cs := by rw [← hcs.callers]
  have hst' : (⟨cs'.frame, [], cs.mem⟩ : Clif.State) = cs' := by rw [← hcs'.callers, ← hmem]
  have hLe : Clif.LInv (input lower S cleanup).toLinkInput.srcProg cs := by
    rw [← hst]; exact ⟨hE.lframe hfP, fun _ h => nomatch h⟩
  -- the symbols of the source run (the target entry's, `OutsideCall.symbols`)
  have hsym : SomeInd (legalProg (input lower S cleanup).toLinkInput.srcProg) →
      Opt.EnvKeepsSymbols B.env ∧ cs.mem.symbols = fun n => (input lower S cleanup).syms.lookup n := by
    intro hI
    refine ⟨(hC.ind hI).1.keep, ?_⟩
    rw [← hmem]; exact ho.symbols
  -- from the target run of the legalised program to the executable
  have hfP' : legalize f ∈ (prog (input lower S cleanup)).funcs := (Clif.Program.func?_some hf').1
  have hexe : ∀ o, (∃ k, Clif.runLoop B.env (legalProg (input lower S cleanup).toLinkInput.srcProg) k cs' = o) →
      o ≠ .outOfFuel →
      (∀ K, Clif.runLoop B.env (prog (input lower S cleanup)) (K + 1) cs' = o →
        TrapsExplicit (Clif.linkEnvN (prog (input lower S cleanup)) B.env K) (prog (input lower S cleanup)).bare cs') →
      ExecRefines (art (input lower S cleanup) (legalize f)).fb (art (input lower S cleanup) (legalize f)).base (xreg 30 r)
        (step (input lower S cleanup) B file) r (RelocAtWithResults (input lower S cleanup) (input lower S cleanup).results) o := by
    rintro o ⟨k, hk⟩ hof htr
    cases k with
    | zero => exact absurd hk.symm (by simpa using hof)
    | succ K =>
      rw [← hpe] at hk
      have := attempt_correct h B hB hH hf' hc K hX ho hr (htr K hk)
      rw [hk] at this
      exact this
  refine ⟨fun vals cm hrun => ?_, fun htr hnmt c hrun => ?_⟩
  · have hG : GoodFrom B.env (input lower S cleanup).toLinkInput.srcProg (SomeInd (legalProg (input lower S cleanup).toLinkInput.srcProg))
        (fun n => (input lower S cleanup).syms.lookup n) ⟨cs.frame, [], cs.mem⟩ := by
      rw [hst]
      exact goodFrom_of hC.free hLe hbnd (memTrapFree_of_returned M cs vals cm hrun) hsym
    rw [← hst] at hrun
    obtain ⟨rv', hrel, k, hk⟩ := (legalProg_refines hC hfP hE hG M).1 vals cm hrun
    rw [hst'] at hk
    exact ⟨rv', hrel, hexe _ ⟨k, hk⟩ (fun h => by cases h) fun K hK =>
      trapsExplicit_of_run hL hfP' hcs' ho.symbols hK⟩
  · have hG : GoodFrom B.env (input lower S cleanup).toLinkInput.srcProg (SomeInd (legalProg (input lower S cleanup).toLinkInput.srcProg))
        (fun n => (input lower S cleanup).syms.lookup n) ⟨cs.frame, [], cs.mem⟩ := by
      rw [hst]
      exact goodFrom_of hC.free hLe hbnd hnmt hsym
    rw [← hst] at hrun
    obtain ⟨k, hk⟩ := (legalProg_refines hC hfP hE hG M).2 c hrun
    rw [hst'] at hk
    exact hexe _ ⟨k, hk⟩ (fun h => by cases h) fun K _ => htr K

/-- **The executable compiler refines the original source program, recursive programs
included** (S3, L1d): `attempt_correct_source` without the call-graph premise. The outside
caller of `legalize f`'s code provides `frameDrop + D * d` bytes of stack, where `d` bounds the
call depth of the **source** run from `cs` (`Clif.DepthLe`: no state the whole-program run of the
original program reaches has more than `d` callers). A return of the source run is the
executable's return of the results split by `f`'s return groups with the same memory; a trap
(of a source run without load/store traps, the target runs' traps explicit under
`Clif.linkEnvD` at every fuel) is the same trap. -/
theorem attempt_correct_source_peak {S : LinkSpec} {cleanup : Bool} {file0 file : ByteArray}
    (h : attempt lower S file0 cleanup = .ok file) (hsrc : SrcScopeB (input lower S cleanup) = true)
    (B : BaseEnv) (hB : BaseOk (sys (input lower S cleanup) B)) (hH : HooksSim (input lower S cleanup) B)
    (hlegal : (∃ f ∈ (input lower S cleanup).toLinkInput.srcProg.funcs, mentions128 f = true) →
      Opt.Legal.HelperOk B.env ∧ Opt.Legal.ExtLegal B.env ∧ Opt.Legal.EnvKeepsBounded B.env)
    (hsig : (∃ g ∈ (prog (input lower S cleanup)).funcs, ¬ Clif.IndFree g) → ∀ n, B.env.sigOf n = none)
    {n : String} {f : Clif.Function} (hf : (input lower S cleanup).toLinkInput.srcProg.func? n = some f) (d : Nat)
    {r : Arm.ArmState} {args args' : List Clif.Val} {cs cs' : Clif.State}
    (hX : (imageOf file).Intact r)
    (ho : OutsideCall (input lower S cleanup) (BinCheck.roByte (input lower S cleanup) S.data) (legalize f)
      (frameDrop (art (input lower S cleanup) (legalize f)).af + (input lower S cleanup).D * d) r args' cs'.mem)
    (hr : ClifRun (input lower S cleanup) B (legalize f) r args' cs')
    (hcs : ClifEntry f args cs)
    (hexp : Opt.Legal.ExpRel ((Opt.Legal.groups f.sig.params).getD []) args args')
    (hsl : cs'.frame.slots = cs.frame.slots) (hmem : cs'.mem = cs.mem)
    (hbnd : ∀ s', Opt.Legal.SReach B.env (input lower S cleanup).toLinkInput.srcProg cs s' → Opt.Legal.MemBounded s'.mem)
    (hd : Clif.DepthLe B.env (input lower S cleanup).toLinkInput.srcProg d cs)
    (M : Nat) :
    (∀ vals cm, Clif.runLoop B.env (input lower S cleanup).toLinkInput.srcProg M cs = .returned vals cm →
      ∃ vals', Opt.Legal.ExpRel ((Opt.Legal.groups f.sig.returns).getD []) vals vals' ∧
        ExecRefines (art (input lower S cleanup) (legalize f)).fb (art (input lower S cleanup) (legalize f)).base (xreg 30 r)
          (step (input lower S cleanup) B file) r (RelocAtWithResults (input lower S cleanup) (input lower S cleanup).results) (.returned vals' cm)) ∧
    ((∀ F, TrapsExplicit (Clif.linkEnvD (prog (input lower S cleanup)) B.env F d) (prog (input lower S cleanup)).bare cs') →
      Opt.Legal.NoMemTrap B.env (input lower S cleanup).toLinkInput.srcProg cs → ∀ c,
      Clif.runLoop B.env (input lower S cleanup).toLinkInput.srcProg M cs = .trapped c →
      ExecRefines (art (input lower S cleanup) (legalize f)).fb (art (input lower S cleanup) (legalize f)).base (xreg 30 r)
        (step (input lower S cleanup) B file) r (RelocAtWithResults (input lower S cleanup) (input lower S cleanup).results) (.trapped c)) := by
  obtain ⟨hin, hl⟩ := attempt_spec h
  have hok := hin
  have hL : (SemanticStackBound.ofInput (input lower S cleanup) B fun _ => True).OkSemanticNI :=
    SemanticStackBound.okB_sound hok (baseOk_F hB) fun _ _ => trivial
  have hpe := prog_eq_legal (input lower S cleanup)
  have hpe' : (input lower S cleanup).toLinkInput.prog = prog (input lower S cleanup) := by rw [hpe, LinkInput.prog_eq]
  -- the source domain
  have hC : ProgCtx (input lower S cleanup).toLinkInput.srcProg B.env (fun n => (input lower S cleanup).syms.lookup n) :=
    srcCtx hsrc (by rw [hpe']; exact hL.names) (by rw [hpe']; exact hL.free)
      (by rw [hpe']; exact hL.declSig) (by rw [hpe']; exact hL.indScope) hlegal
      (by rw [hpe']; exact hsig)
  have hfP := (Clif.Program.func?_some hf).1
  have hf' : (prog (input lower S cleanup)).func? n = some (legalize f) := by
    rw [hpe]; exact hC.func?_some hf
  -- the entries
  have hcs' := hr.entry
  obtain ⟨b, hb, h2, h3, h4, h5⟩ := hcs.entry
  obtain ⟨b', hb', h2', h3', -, h5'⟩ := hcs'.entry
  have hE : EntryRel f args args' cs.frame cs'.frame :=
    ⟨hcs.func, hcs'.func, ⟨b, hb, h2, h3, h4, h5⟩, ⟨b', hb', h2', h3', h5'⟩, hsl, hexp⟩
  have hst : (⟨cs.frame, [], cs.mem⟩ : Clif.State) = cs := by rw [← hcs.callers]
  have hst' : (⟨cs'.frame, [], cs.mem⟩ : Clif.State) = cs' := by rw [← hcs'.callers, ← hmem]
  have hLe : Clif.LInv (input lower S cleanup).toLinkInput.srcProg cs := by
    rw [← hst]; exact ⟨hE.lframe hfP, fun _ h => nomatch h⟩
  have hd' : Clif.DepthLe B.env (input lower S cleanup).toLinkInput.srcProg d ⟨cs.frame, [], cs.mem⟩ := by rw [hst]; exact hd
  -- the symbols of the source run (the target entry's, `OutsideCall.symbols`)
  have hsym : SomeInd (legalProg (input lower S cleanup).toLinkInput.srcProg) →
      Opt.EnvKeepsSymbols B.env ∧ cs.mem.symbols = fun n => (input lower S cleanup).syms.lookup n := by
    intro hI
    refine ⟨(hC.ind hI).1.keep, ?_⟩
    rw [← hmem]; exact ho.symbols
  -- from the target run of the legalised program, of call depth at most `d`, to the executable
  have hfP' : legalize f ∈ (prog (input lower S cleanup)).funcs := (Clif.Program.func?_some hf').1
  have hexe : ∀ o, (∃ k, Clif.runLoop B.env (legalProg (input lower S cleanup).toLinkInput.srcProg) k cs' = o) →
      o ≠ .outOfFuel → Clif.DepthLe B.env (prog (input lower S cleanup)) d cs' →
      (∀ F, Clif.runLoop B.env (prog (input lower S cleanup)) (F + 1) cs' = o →
        TrapsExplicit (Clif.linkEnvD (prog (input lower S cleanup)) B.env F d) (prog (input lower S cleanup)).bare cs') →
      ExecRefines (art (input lower S cleanup) (legalize f)).fb (art (input lower S cleanup) (legalize f)).base (xreg 30 r)
        (step (input lower S cleanup) B file) r (RelocAtWithResults (input lower S cleanup) (input lower S cleanup).results) o := by
    rintro o ⟨k, hk⟩ hof hdT htr
    cases k with
    | zero => exact absurd hk.symm (by simpa using hof)
    | succ F =>
      rw [← hpe] at hk
      have := attempt_correct_peak h B hB hH hf' F d hX ho hr hdT (htr F hk)
      rw [hk] at this
      exact this
  refine ⟨fun vals cm hrun => ?_, fun htr hnmt c hrun => ?_⟩
  · have hG : GoodFrom B.env (input lower S cleanup).toLinkInput.srcProg (SomeInd (legalProg (input lower S cleanup).toLinkInput.srcProg))
        (fun n => (input lower S cleanup).syms.lookup n) ⟨cs.frame, [], cs.mem⟩ := by
      rw [hst]
      exact goodFrom_of hC.free hLe hbnd (memTrapFree_of_returned M cs vals cm hrun) hsym
    rw [← hst] at hrun
    obtain ⟨rv', hrel, ⟨k, hk⟩, hdT⟩ := (legalProg_refines_depth hC hfP hE hG hd' M).1 vals cm hrun
    rw [hst'] at hk hdT
    rw [← hpe] at hdT
    exact ⟨rv', hrel, hexe _ ⟨k, hk⟩ (fun h => by cases h) hdT fun F hF =>
      trapsExplicit_of_runD hL hfP' hcs' ho.symbols hdT hF⟩
  · have hG : GoodFrom B.env (input lower S cleanup).toLinkInput.srcProg (SomeInd (legalProg (input lower S cleanup).toLinkInput.srcProg))
        (fun n => (input lower S cleanup).syms.lookup n) ⟨cs.frame, [], cs.mem⟩ := by
      rw [hst]
      exact goodFrom_of hC.free hLe hbnd hnmt hsym
    rw [← hst] at hrun
    obtain ⟨⟨k, hk⟩, hdT⟩ := (legalProg_refines_depth hC hfP hE hG hd' M).2 c hrun
    rw [hst'] at hk hdT
    rw [← hpe] at hdT
    exact hexe _ ⟨k, hk⟩ (fun h => by cases h) hdT fun F _ => htr F


end Link.SemanticCompilerWith

namespace Backend.Stock.Arithmetic
set_option autoImplicit false

/-- One shared executable choice for compiler, checker, linker and generated
proofs. A candidate rejected by paired semantic validation retries the shipped
selector before any later stage observes code or rule history. -/
def lowerValidated (f : Clif.Function) : Except String VCode :=
  if D0.eligible f || ScalarAdd.activationEligible f || !eligible f then ScalarAdd.lower f
  else
    let attempt := do
      let vc ← lowerCandidate f
      if SemanticNI.check f vc then pure vc
      else throw "Stock candidate failed paired semantic validation"
    match attempt with
    | .ok vc => .ok vc
    | .error _ => ScalarAdd.lower f


/-- Consumer routing data records retained artifacts discovered in a mixed
executable. It carries no proof: the ordinary semantic/allocation/binary checks
validate either selected route. No function name restricts the proved class. -/
def lowerWithFallbacks (retained : List String) (f : Clif.Function) : Except String VCode :=
  if retained.contains f.name then ScalarAdd.lower f else lowerValidated f

end Backend.Stock.Arithmetic

namespace E2E.StockArithmeticNIWitness
open Backend Backend.Proof Backend.Proof.Driver Backend.Stock.D0
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm

/-- Two arithmetic operations, an actually read ninth stack parameter, six
unused parameters and an explicit source slot, across all six shipped ABIs. -/
def function (config : Configuration) : Clif.Function :=
  let ty := valueType config
  {source "stock_arithmetic_ni" config [] with
    sig := {
      params := List.replicate 9 ⟨ty,.none,.normal⟩
      returns := [⟨ty,.none,.normal⟩]
      callConv := convention config}
    slots := [(7,⟨8,some 8⟩)]
    blocks := [{
      id := 0
      params := (List.range 9).map (fun i => (i,ty))
      body := [⟨[9],.binary .iadd ty 0 8⟩,⟨[10],.binary .isub ty 9 1⟩]
      term := .ret [10]}]}

private def checks (config : Configuration) (cleanup : Bool) : Bool :=
  Stock.Arithmetic.sourceOk (function config) &&
  match Stock.lower (function config) with
  | .error _ => false
  | .ok result =>
    !lowerCheck (function config) result.code && SemanticNI.check (function config) result.code &&
    ABIReadOnly.check (function config).sig result.code &&
    match Backend.prepare (Stock.Arithmetic.stage cleanup result.code) with
    | .error _ => false
    | .ok vcp =>
      prepCheck (Stock.Arithmetic.stage cleanup result.code) vcp &&
      match leanAlloc vcp with
      | .error _ => false
      | .ok rf =>
        (checkAlloc vcp rf).isOk &&
        match lowerRFunc vcp rf with
        | .error _ => false
        | .ok af =>
          match emitFunc 0 af with
          | .error _ => false
          | .ok fa => formsCoveredB ⟨fa.k,af.slotBase⟩ vcp && fa.layout.isOk

private def grid : Bool := configurations.all fun config => checks config false && checks config true

/-- Fixed compiler-data witness only: all twelve ABI/cleanup combinations
complete the real pipeline, including an actually consumed stack argument. -/
theorem checks_true : grid = true := by native_decide

/-- Actual artifacts jointly inhabit the source, ABI-read, paired consumer,
allocator and emitted/layout contracts beyond the legacy checker domain. -/
theorem compiled_exists (config : Configuration) (cleanup : Bool) :
    Stock.Arithmetic.Domain (function config) ∧
    ∃ result vcp rf af fa fb,
      CompiledStockArithmeticStage (function config) cleanup 0 result vcp rf af fa fb ∧
      CompiledSemanticNI (function config) 0 result.code vcp rf af fa fb ∧
      ABIReadOnly.check (function config).sig result.code = true ∧
      leanAlloc vcp = .ok rf ∧ FormsCovered ⟨fa.k,af.slotBase⟩ vcp ∧
      lowerCheck (function config) result.code = false := by
  have h : checks config cleanup = true := by
    have both := List.all_eq_true.mp checks_true config
      (by cases config <;> simp [configurations])
    simp only [Bool.and_eq_true] at both
    cases cleanup with
    | false => exact both.1
    | true => exact both.2
  simp only [checks,Bool.and_eq_true] at h
  obtain ⟨source,h⟩ := h
  refine ⟨Stock.Arithmetic.sourceOk_sound source,?_⟩
  cases lowered : Stock.lower (function config) with
  | error message => simp [lowered] at h
  | ok result =>
    simp only [lowered,Bool.and_eq_true,Bool.not_eq_true'] at h
    obtain ⟨⟨⟨legacy,semantic⟩,reads⟩,h⟩ := h
    cases prepared : Backend.prepare (Stock.Arithmetic.stage cleanup result.code) with
    | error message => simp [prepared] at h
    | ok vcp =>
      simp only [prepared,Bool.and_eq_true] at h
      obtain ⟨prepOk,h⟩ := h
      cases allocated : leanAlloc vcp with
      | error message => simp [allocated] at h
      | ok rf =>
        simp only [allocated,Bool.and_eq_true] at h
        obtain ⟨checked,h⟩ := h
        cases physical : lowerRFunc vcp rf with
        | error message => simp [physical] at h
        | ok af =>
          cases emitted : emitFunc 0 af with
          | error message => simp [physical,emitted] at h
          | ok fa =>
            simp only [physical,emitted,Bool.and_eq_true] at h
            obtain ⟨covered,layoutOk⟩ := h
            cases layout : fa.layout with
            | error message => rw [layout] at layoutOk; change false = true at layoutOk; cases layoutOk
            | ok fb =>
              have check : checkAlloc vcp rf = .ok () := by
                cases check : checkAlloc vcp rf with
                | error message => rw [check] at checked; change false = true at checked; cases checked
                | ok value => cases value; rfl
              exact ⟨result,vcp,rf,af,fa,fb,
                ⟨lowered,prepared,prepOk,check,physical,emitted,layout⟩,
                CompiledSemanticNI.of_checks semantic prepared prepOk check physical emitted layout,
                reads,allocated,(formsCoveredB_iff _ _).mp covered,legacy⟩

/-- Arbitrary entry values, including every unused parameter. -/
def arguments (config : Configuration) (input : Nat → BitVec (valueType config).width) : List Clif.Val :=
  (List.range 9).map fun i => ⟨valueType config,input i⟩

def frame (config : Configuration) (input : Nat → BitVec (valueType config).width) (slot : Nat) : Clif.Frame := {
  func := function config
  regs := (Clif.Regs.empty.setMany (List.range 9) (arguments config input)).getD Clif.Regs.empty
  slots := [(7,slot)]
  body := (function config).blocks[0]!.body
  term := .ret [10] }

/-- The original source entry permits arbitrary values and caller slot
addresses, including the seven values not returned directly. -/
theorem source_entry (config : Configuration) (input : Nat → BitVec (valueType config).width) (slot : Nat) :
    ClifEntry (function config) (arguments config input) ⟨frame config input slot,[],Clif.Mem.empty⟩ := by
  cases config <;> exact ⟨rfl,rfl,rfl,⟨_,rfl,rfl,rfl,rfl,rfl⟩,rfl⟩

/-- Both arithmetic steps and the return run on arbitrary source values. -/
theorem source_returns (config : Configuration) (input : Nat → BitVec (valueType config).width) (slot : Nat) :
    Clif.runLoop Clif.Env.empty {funcs := []} 3 ⟨frame config input slot,[],Clif.Mem.empty⟩ =
      .returned [⟨valueType config,(input 0 + input 8) - input 1⟩] Clif.Mem.empty := by
  cases config <;> rfl

end E2E.StockArithmeticNIWitness

namespace E2E.SemanticCompilerWitness
open Backend Backend.Proof Backend.Proof.Driver Backend.Stock.D0 E2E.LinkCheck Link
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm

def initial (config : Configuration) : LinkSpec := {
  funcs := [{clif := (StockArithmeticNIWitness.function config).print,ra := "null"}]
  names := []
  sizes := []
  outside := []
  symNames := ["stock_arithmetic_ni"]
  R := 0x200160 }

def spec (config : Configuration) (cleanup : Bool) : LinkSpec :=
  (initial config).placedProductionWith Stock.Arithmetic.lowerValidated cleanup

def plan (S : LinkSpec) : Link.Ld.Plan :=
  let size := 0x160 + S.size
  {base := 0x200000,entry := S.R,
   segs := [{kind := 1,vaddr := 0x200000,offset := 0,filesz := size,memsz := size}],
   tlsAddr := 0x200000+size,tlsOff := size,tlsFilesz := 0,tlsMemsz := 0,tlsAlign := 1,
   ehOff := 0,ehAddr := 0,ehSize := 0,size,pieces := [],secs := #[],
   syms := S.addrs.toArray.map fun (n,v) => {name := E2E.BinCheck.symName n,value := v,info := 18,shndx := 0xfff1}}

def file0 (config : Configuration) (cleanup : Bool) : ByteArray :=
  match Link.Ld.assemble (plan (spec config cleanup)) with | .ok image => image.write | .error _ => ByteArray.empty

def input (config : Configuration) (cleanup : Bool) : SemanticStackBound.CompilerInput :=
  SemanticCompilerWith.input Stock.Arithmetic.lowerValidated (spec config cleanup) cleanup

def attempt (config : Configuration) (cleanup : Bool) : Except String ByteArray :=
  SemanticCompilerWith.attempt Stock.Arithmetic.lowerValidated (spec config cleanup) (file0 config cleanup) cleanup

private def checks (config : Configuration) (cleanup : Bool) : Bool :=
  (attempt config cleanup).isOk && SemanticStackBound.okB (input config cleanup) &&
  (input config cleanup).results.all fun row =>
    match row.2 with
    | .error _ => false
    | .ok a => !lowerCheck row.1 a.vc

private def grid : Bool := configurations.all fun config => checks config false && checks config true

/-- Fixed compiler-data witness only: the real ELF byte writer and complete
semantic program checker succeed for every ABI/cleanup combination, using raw
Stock code beyond the old checker rather than taking legacy fallback. -/
theorem checks_true : grid = true := by native_decide

/-- The executable compiler succeeds jointly with the whole-program semantic
checker; the retained old validator rejects every actual program artifact. -/
theorem compiler_success (config : Configuration) (cleanup : Bool) :
    ∃ file, attempt config cleanup = .ok file ∧
      SemanticStackBound.okB (input config cleanup) = true ∧
      ((input config cleanup).results.all fun row => match row.2 with
        | .error _ => false
        | .ok a => !lowerCheck row.1 a.vc) = true := by
  have h : checks config cleanup = true := by
    have both := List.all_eq_true.mp checks_true config
      (by cases config <;> simp [configurations])
    simp only [Bool.and_eq_true] at both
    cases cleanup with
    | false => exact both.1
    | true => exact both.2
  simp only [checks,Bool.and_eq_true] at h
  cases compiled : attempt config cleanup with
  | error message =>
    have impossible := h.1.1
    simp only [compiled,Except.isOk,Except.toBool] at impossible
    cases impossible
  | ok file => exact ⟨file,rfl,h.1.2,h.2⟩

end E2E.SemanticCompilerWitness

namespace Backend.Stock.Mixed
set_option autoImplicit false

/-- A complete new candidate is checked before consumers see it. Every other
input or failed candidate retains the previous arithmetic production route. -/
def lowerValidated (f : Clif.Function) : Except String VCode :=
  if !activationEligible f then Arithmetic.lowerValidated f
  else
    let attempt := do
      let vc ← lowerCandidate f
      if check f vc && ABIReadFlags.check f.sig vc then pure vc
      else throw "Stock mixed candidate failed paired semantic validation"
    match attempt with
    | .ok vc => .ok vc
    | .error _ => Arithmetic.lowerValidated f

/-- Retained-artifact reconstruction is selected from actual artifact checks;
names carry routing data and never restrict the proved source class. -/
def lowerWithFallbacks (retained : List String) (f : Clif.Function) : Except String VCode :=
  if retained.contains f.name then Arithmetic.lowerWithFallbacks retained f
  else lowerValidated f

end Backend.Stock.Mixed

namespace E2E.StockMixedNIWitness
open Backend Backend.Proof Backend.Proof.Driver Backend.Stock.D0
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm

/-- Dependent add/select/sub, a consumed ninth stack argument, five unused
parameters, an explicit source slot and an omitted dead operation. -/
def function (config : Configuration) : Clif.Function :=
  let ty := valueType config
  {source "stock_mixed_ni" config [] with
    sig := {
      params := List.replicate 9 ⟨ty,.none,.normal⟩
      returns := [⟨ty,.none,.normal⟩]
      callConv := convention config}
    slots := [(7,⟨8,some 8⟩)]
    blocks := [{
      id := 0
      params := (List.range 9).map (fun i => (i,ty))
      body := [⟨[9],.binary .iadd ty 1 8⟩,⟨[10],.select ty 0 9 1⟩,
        ⟨[11],.binary .isub ty 10 2⟩,⟨[12],.binary .iadd ty 1 8⟩]
      term := .ret [11]}]}

private def checks (config : Configuration) (cleanup : Bool) : Bool :=
  lowerScopeB (function config) && dominatedB (function config) && sigAbiOk (function config).sig &&
  match Stock.lower (function config) with
  | .error _ => false
  | .ok result =>
    !lowerCheck (function config) result.code &&
    MixedFlagBoundary.check (function config).sig result.code &&
    match Backend.prepare (Stock.Arithmetic.stage cleanup result.code) with
    | .error _ => false
    | .ok vcp =>
      prepCheck (Stock.Arithmetic.stage cleanup result.code) vcp &&
      match leanAlloc vcp with
      | .error _ => false
      | .ok rf =>
        (checkAlloc vcp rf).isOk &&
        match lowerRFunc vcp rf with
        | .error _ => false
        | .ok af =>
          match emitFunc 0 af with
          | .error _ => false
          | .ok fa => formsCoveredB ⟨fa.k,af.slotBase⟩ vcp && fa.layout.isOk

private def grid : Bool := configurations.all fun config => checks config false && checks config true
-- witness: native_decide (twelve fixed actual pipeline configurations only)
theorem checks_true : grid = true := by native_decide
end E2E.StockMixedNIWitness



namespace E2E.StockMixedNIWitness
open Backend Backend.Proof Backend.Proof.Driver Backend.Stock.D0

private theorem family (config : Configuration) :
    ∀ stm ∈ (function config).blocks[0]!.body, Stock.Proof.MixedBody.Family stm.inst := by
  intro stm member
  let ty := valueType config
  change stm ∈ [⟨[9],.binary .iadd ty 1 8⟩,⟨[10],.select ty 0 9 1⟩,
    ⟨[11],.binary .isub ty 10 2⟩,⟨[12],.binary .iadd ty 1 8⟩] at member
  simp only [List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact .inl ⟨false,ty,1,8,rfl⟩
  · exact .inr ⟨ty,0,9,1,rfl⟩
  · exact .inl ⟨true,ty,10,2,rfl⟩
  · exact .inl ⟨false,ty,1,8,rfl⟩

/-- Actual checked/allocated/emitted artifacts inhabit the complete mixed
semantic domain in every ABI and cleanup mode, beyond the legacy checker. -/
theorem compiled_exists (config : Configuration) (cleanup : Bool) :
    Stock.Mixed.Domain (function config) ∧
    ∃ result vcp rf af fa fb,
      CompiledStockArithmeticStage (function config) cleanup 0 result vcp rf af fa fb ∧
      MixedFlagBoundary.check (function config).sig result.code = true ∧
      leanAlloc vcp = .ok rf ∧ FormsCovered ⟨fa.k,af.slotBase⟩ vcp ∧
      lowerCheck (function config) result.code = false := by
  have h : checks config cleanup = true := by
    have both := List.all_eq_true.mp checks_true config (by cases config <;> simp [configurations])
    simp only [Bool.and_eq_true] at both
    cases cleanup with
    | false => exact both.1
    | true => exact both.2
  simp only [checks,Bool.and_eq_true] at h
  obtain ⟨⟨⟨scope,dominated⟩,abi⟩,h⟩ := h
  have domain : Stock.Mixed.Domain (function config) :=
    ⟨lowerScope_of scope,dominated_of dominated,abi,
      ⟨(function config).blocks[0]!,[11],rfl,rfl,family config⟩,by rfl⟩
  refine ⟨domain,?_⟩
  cases lowered : Stock.lower (function config) with
  | error message => simp [lowered] at h
  | ok result =>
    simp only [lowered,Bool.and_eq_true,Bool.not_eq_true'] at h
    obtain ⟨⟨legacy,reads⟩,h⟩ := h
    cases prepared : Backend.prepare (Stock.Arithmetic.stage cleanup result.code) with
    | error message => simp [prepared] at h
    | ok vcp =>
      simp only [prepared,Bool.and_eq_true] at h
      obtain ⟨prepOk,h⟩ := h
      cases allocated : leanAlloc vcp with
      | error message => simp [allocated] at h
      | ok rf =>
        simp only [allocated,Bool.and_eq_true] at h
        obtain ⟨checked,h⟩ := h
        cases physical : lowerRFunc vcp rf with
        | error message => simp [physical] at h
        | ok af =>
          cases emitted : emitFunc 0 af with
          | error message => simp [physical,emitted] at h
          | ok fa =>
            simp only [physical,emitted,Bool.and_eq_true] at h
            obtain ⟨covered,layoutOk⟩ := h
            cases layout : fa.layout with
            | error message => rw [layout] at layoutOk; change false = true at layoutOk; cases layoutOk
            | ok fb =>
              have check : checkAlloc vcp rf = .ok () := by
                cases check : checkAlloc vcp rf with
                | error message => rw [check] at checked; change false = true at checked; cases checked
                | ok value => cases value; rfl
              exact ⟨result,vcp,rf,af,fa,fb,
                ⟨lowered,prepared,prepOk,check,physical,emitted,layout⟩,
                reads,allocated,(formsCoveredB_iff _ _).mp covered,legacy⟩

def arguments (config : Configuration) (input : Nat → BitVec (valueType config).width) : List Clif.Val :=
  (List.range 9).map fun i => ⟨valueType config,input i⟩

def frame (config : Configuration) (input : Nat → BitVec (valueType config).width) (slot : Nat) : Clif.Frame := {
  func := function config
  regs := (Clif.Regs.empty.setMany (List.range 9) (arguments config input)).getD Clif.Regs.empty
  slots := [(7,slot)]
  body := (function config).blocks[0]!.body
  term := .ret [11] }

/-- All entry values and the original explicit-slot address remain arbitrary. -/
theorem source_entry (config : Configuration) (input : Nat → BitVec (valueType config).width) (slot : Nat) :
    ClifEntry (function config) (arguments config input) ⟨frame config input slot,[],Clif.Mem.empty⟩ := by
  cases config <;> exact ⟨rfl,rfl,rfl,⟨_,rfl,rfl,rfl,rfl,rfl⟩,rfl⟩

/-- Full reference execution includes dependent selection, the consumed stack
argument and the dead statement, for arbitrary values in all six configurations. -/
theorem source_returns (config : Configuration) (input : Nat → BitVec (valueType config).width) (slot : Nat) :
    Clif.runLoop Clif.Env.empty {funcs := []} 5 ⟨frame config input slot,[],Clif.Mem.empty⟩ =
      .returned [⟨valueType config,Clif.Sem.select (input 0) (input 1 + input 8) (input 1) - input 2⟩]
        Clif.Mem.empty := by
  cases config <;> rfl
end E2E.StockMixedNIWitness

namespace E2E.StockMixedNIWitness
private def classChecks (config : Backend.Stock.D0.Configuration) : Bool :=
  Backend.Stock.Mixed.sourceOk (function config) &&
  match Backend.Stock.lower (function config) with
  | .error _ => false
  | .ok result => Backend.Stock.Mixed.check (function config) result.code

-- witness: native_decide (six fixed actual source/provenance checks only)
theorem source_checks_true : Backend.Stock.D0.configurations.all classChecks = true := by native_decide

/-- Actual source inputs and outputs jointly inhabit both new executable
checks in every ABI, including the guarded empty-edge property. -/
theorem classifier_accepts (config : Backend.Stock.D0.Configuration) :
    ∃ result, Backend.Stock.lower (function config) = .ok result ∧
      Backend.Stock.Mixed.sourceOk (function config) = true ∧
      Backend.Stock.Mixed.check (function config) result.code = true := by
  have h := List.all_eq_true.mp source_checks_true config
    (by cases config <;> simp [Backend.Stock.D0.configurations])
  simp only [classChecks,Bool.and_eq_true] at h
  obtain ⟨source,h⟩ := h
  cases lowered : Backend.Stock.lower (function config) with
  | error message => simp [lowered] at h
  | ok result => exact ⟨result,rfl,source,by simpa only [lowered] using h⟩
end E2E.StockMixedNIWitness

namespace E2E.StockMixedNIWitness
open Backend Backend.Proof Backend.Proof.Driver Backend.Stock.D0

/-- The actual mixed artifacts inhabit the shared production consumer, rather
than a separate experimental checker or a caller-provided proof contract. -/
theorem compiled_semantic_exists (config : Configuration) (cleanup : Bool) :
    ∃ (result : Stock.Result), ∃ vcp rf af fa fb,
      CompiledSemanticNI (function config) 0 result.code vcp rf af fa fb ∧
      CompiledStockArithmeticStage (function config) cleanup 0 result vcp rf af fa fb ∧
      FormsCovered ⟨fa.k,af.slotBase⟩ vcp := by
  obtain ⟨domain,result,vcp,rf,af,fa,fb,stage,reads,allocated,covered,legacy⟩ :=
    compiled_exists config cleanup
  exact ⟨result,vcp,rf,af,fa,fb,.mixed domain rfl reads stage,stage,covered⟩

end E2E.StockMixedNIWitness

namespace E2E.SemanticMixedCompilerWitness
open Backend Backend.Proof Backend.Proof.Driver Backend.Stock.D0 E2E.LinkCheck Link
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm

def initial (config : Configuration) : LinkSpec := {
  funcs := [{clif := (StockMixedNIWitness.function config).print,ra := "null"}]
  names := []
  sizes := []
  outside := []
  symNames := ["stock_mixed_ni"]
  R := 0x200160 }

def spec (config : Configuration) (cleanup : Bool) : LinkSpec :=
  (initial config).placedProductionWith Stock.Mixed.lowerValidated cleanup

def plan (S : LinkSpec) : Link.Ld.Plan :=
  let size := 0x160 + S.size
  {base := 0x200000,entry := S.R,
   segs := [{kind := 1,vaddr := 0x200000,offset := 0,filesz := size,memsz := size}],
   tlsAddr := 0x200000+size,tlsOff := size,tlsFilesz := 0,tlsMemsz := 0,tlsAlign := 1,
   ehOff := 0,ehAddr := 0,ehSize := 0,size,pieces := [],secs := #[],
   syms := S.addrs.toArray.map fun (n,v) => {name := E2E.BinCheck.symName n,value := v,info := 18,shndx := 0xfff1}}

def file0 (config : Configuration) (cleanup : Bool) : ByteArray :=
  match Link.Ld.assemble (plan (spec config cleanup)) with | .ok image => image.write | .error _ => ByteArray.empty

def input (config : Configuration) (cleanup : Bool) : SemanticStackBound.CompilerInput :=
  SemanticCompilerWith.input Stock.Mixed.lowerValidated (spec config cleanup) cleanup

def attempt (config : Configuration) (cleanup : Bool) : Except String ByteArray :=
  SemanticCompilerWith.attempt Stock.Mixed.lowerValidated (spec config cleanup) (file0 config cleanup) cleanup

private def checks (config : Configuration) (cleanup : Bool) : Bool :=
  (attempt config cleanup).isOk && SemanticStackBound.okB (input config cleanup) &&
  (input config cleanup).results.all fun row =>
    match row.2 with
    | .error _ => false
    | .ok a => !lowerCheck row.1 a.vc

private def grid : Bool := configurations.all fun config => checks config false && checks config true

/-- Fixed compiler-data witness only: the real ELF byte writer and complete
semantic program checker succeed for every ABI/cleanup combination, using raw
Stock code beyond the old checker rather than taking legacy fallback. -/
theorem checks_true : grid = true := by native_decide

/-- The executable compiler succeeds jointly with the whole-program semantic
checker; the retained old validator rejects every actual program artifact. -/
theorem compiler_success (config : Configuration) (cleanup : Bool) :
    ∃ file, attempt config cleanup = .ok file ∧
      SemanticStackBound.okB (input config cleanup) = true ∧
      ((input config cleanup).results.all fun row => match row.2 with
        | .error _ => false
        | .ok a => !lowerCheck row.1 a.vc) = true := by
  have h : checks config cleanup = true := by
    have both := List.all_eq_true.mp checks_true config
      (by cases config <;> simp [configurations])
    simp only [Bool.and_eq_true] at both
    cases cleanup with
    | false => exact both.1
    | true => exact both.2
  simp only [checks,Bool.and_eq_true] at h
  cases compiled : attempt config cleanup with
  | error message =>
    have impossible := h.1.1
    simp only [compiled,Except.isOk,Except.toBool] at impossible
    cases impossible
  | ok file => exact ⟨file,rfl,h.1.2,h.2⟩

end E2E.SemanticMixedCompilerWitness


namespace E2E.SemanticFallbackWitness
open Backend Backend.Stock.D0 Link
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000

/-- A lowering error can recover inside the per-function pipeline. Instead,
produce allocatable code for a different computation so the complete program's
semantic checker rejects the first attempt. -/
private def mismatch (f : Clif.Function) : Except String VCode :=
  lowerFunction {f with blocks := f.blocks.map fun b =>
    {b with body := b.body.map fun stm =>
      {stm with inst := match stm.inst with
        | .binary .iadd ty x y => .binary .isub ty x y
        | inst => inst}}}

private def selected (r : Except String SemanticCompilerWith.FallbackOutput)
    (wanted : SemanticCompilerWith.CompileChoice) : Bool :=
  match r with | .error _ => false | .ok out => out.choice == wanted

private def legacyFile0 (config : Configuration) (cleanup : Bool) : ByteArray :=
  let spec := SemanticCompilerWith.legacySpec (SemanticCompilerWitness.initial config) cleanup
  match Link.Ld.assemble (SemanticCompilerWitness.plan spec) with
  | .ok image => image.write
  | .error _ => ByteArray.empty

private def mixedPreviousFile0 (config : Configuration) (cleanup : Bool) : ByteArray :=
  let spec := (SemanticMixedCompilerWitness.initial config).placedProductionWith
    Stock.Arithmetic.lowerValidated cleanup
  match Link.Ld.assemble (SemanticMixedCompilerWitness.plan spec) with
  | .ok image => image.write
  | .error _ => ByteArray.empty

private def mixedLegacyFile0 (config : Configuration) (cleanup : Bool) : ByteArray :=
  let spec := SemanticCompilerWith.legacySpec (SemanticMixedCompilerWitness.initial config) cleanup
  match Link.Ld.assemble (SemanticMixedCompilerWitness.plan spec) with
  | .ok image => image.write
  | .error _ => ByteArray.empty

private def checks (config : Configuration) (cleanup : Bool) : Bool :=
  selected (SemanticCompilerWith.compileWithFallback Stock.Mixed.lowerValidated
    Stock.Arithmetic.lowerValidated (SemanticMixedCompilerWitness.initial config)
    (SemanticMixedCompilerWitness.file0 config cleanup) cleanup) .current &&
  selected (SemanticCompilerWith.compileWithFallback mismatch Stock.Arithmetic.lowerValidated
    (SemanticCompilerWitness.initial config) (SemanticCompilerWitness.file0 config cleanup) cleanup) .previous &&
  selected (SemanticCompilerWith.compileWithFallback mismatch mismatch
    (SemanticCompilerWitness.initial config) (legacyFile0 config cleanup) cleanup) .legacy &&
  selected (SemanticCompilerWith.compileWithFallback mismatch Stock.Arithmetic.lowerValidated
    (SemanticMixedCompilerWitness.initial config) (mixedPreviousFile0 config cleanup) cleanup) .previous &&
  selected (SemanticCompilerWith.compileWithFallback mismatch mismatch
    (SemanticMixedCompilerWitness.initial config) (mixedLegacyFile0 config cleanup) cleanup) .legacy

-- witness: native_decide (all three actual compiler choices, twelve configurations)
theorem checks_true : configurations.all (fun config => checks config false && checks config true) = true := by
  native_decide

end E2E.SemanticFallbackWitness
#print axioms E2E.SemanticMixedCompilerWitness.checks_true
#print axioms E2E.SemanticFallbackWitness.checks_true
