import FV.Backend.Proof.StockLogicalForms
import FV.Backend.Proof.IselTermsALUAExtr

namespace Backend.Stock.Proof.LogicalExtr
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
attribute [local irreducible] Isle.Aarch64.program

private theorem sem_ctor (ctx : Ctx) (t : Term) (vs : List V) (st : State) :
    (Stock.sem ctx).ctor t vs st = Stock.externCtor ctx t vs st := rfl
private theorem sem_mkData (ctx : Ctx) (t k : Nat) (vs : List V) :
    (Stock.sem ctx).mkData t k vs = .data t k vs := rfl
private theorem extr_shift_32 (ctx : Ctx) (st : State) (amount : Nat) :
    Stock.externCtor ctx T.a64_extr_imm [.ty (.int 32),.op (.immShift amount)] st =
      .ok (.op (.shiftOpAndAmt ⟨.lsl,amount⟩),st) := by
  rw [stock_ctor_baseOnly ctx T.a64_extr_imm _ st (by decide)]
  rfl
private theorem extr_shift_64 (ctx : Ctx) (st : State) (amount : Nat) :
    Stock.externCtor ctx T.a64_extr_imm [.ty (.int 64),.op (.immShift amount)] st =
      .ok (.op (.shiftOpAndAmt ⟨.lsr,amount⟩),st) := by
  rw [stock_ctor_baseOnly ctx T.a64_extr_imm _ st (by decide)]
  rfl
private theorem immediate_shift (ctx : Ctx) (st : State) {amount : Int} (fits : amount < 64) :
    Stock.externCtor ctx T.imm_shift_from_u8 [.int amount] st =
      .ok (.op (.immShift amount.toNat),st) := by
  rw [stock_ctor_baseOnly ctx T.imm_shift_from_u8 _ st (by decide),
    ctor_imm_shift_from_u8 ctx st.base fits]
private theorem output_run {p : Program} (hp : Data p) (ctx : Ctx) (st : State)
    (tr : Array RuleId) (n : Nat) (r : Reg) :
    (applyTerm p (Stock.sem ctx) {} (n+10) 25 172 [.reg r]).run (st,tr) =
      .ok (some (.regsVec [[r]]),st,tr.push rule_prelude_lower_105.id) := by
  have value : ∀ q,Stock.externCtor ctx T.value_reg [.reg r] q = .ok (.regs [r],q) := by
    intro q; rw [stock_ctor_baseOnly ctx T.value_reg _ q (by decide)]; rfl
  have output : ∀ q,Stock.externCtor ctx T.output [.regs [r]] q = .ok (.regsVec [[r]],q) := by
    intro q; rw [stock_ctor_baseOnly ctx T.output _ q (by decide)]; rfl
  cases hp
  isel_eval [*,rule_prelude_lower_105,sem_ctor]

def shiftFor (w amount : Nat) : ShiftOpAndAmt :=
  if w ≤ 32 then ⟨.lsl,amount⟩ else ⟨.lsr,amount⟩

/-- The real two-register EXTR helper preserves all Stock scheduling fields. -/
theorem helper_run {p : Program} (hp : Data p) (ctx : Ctx) {w : Nat}
    (width : w = 32 ∨ w = 64) (st : State) (tr : Array RuleId) (n : Nat)
    (rx ry : Reg) (amount : Nat) :
    (applyTerm p (Stock.sem ctx) {} (n+30) 27 515
      [.ty (.int w),.reg rx,.reg ry,.op (.immShift amount)]).run (st,tr) =
      .ok (some (.reg (st.base.fresh .int).1),
        {st with base := (st.base.fresh .int).2.emit (.aluRRRShift .extr (szOf w) (st.base.fresh .int).1 rx ry (shiftFor w amount))},
        ((tr.push (if w ≤ 32 then rule_inst_1592.id else rule_inst_1593.id)).push rule_inst_2656.id).push
          rule_inst_3487.id) := by
  have small : w ≤ 64 := by rcases width with rfl | rfl <;> decide
  have inner := fun q trace fuel sh => LogicalForms.stock_logical_shift_helper hp ctx (cfg := {})
    rfl small (k := 15) (op := .extr) rfl q trace fuel rx ry sh
  have ctor32 := fun q => extr_shift_32 ctx q amount
  have ctor64 := fun q => extr_shift_64 ctx q amount
  cases hp
  rcases width with rfl | rfl
  all_goals simp only [shiftFor,szOf,Nat.reduceLeDiff,ite_true,ite_false] at *
  all_goals isel_eval [*,rule_inst_3487,sem_mkData,sem_ctor]
  all_goals rfl

def extrRule (mirrored : Bool) : Rule := if mirrored then rule_lower_1507 else rule_lower_1501

def extrEnv (mirrored : Bool) (w x : Nat) (X : Int) (y : Nat) (Y : Int) : Isle.Interp.Env V :=
  if mirrored then env5 (.ty (.int w)) (.value y) (.int Y) (.value x) (.int X)
  else env5 (.ty (.int w)) (.value x) (.int X) (.value y) (.int Y)

/-- Both original fused-OR RHSs request only the underlying source words,
retain complete Stock scheduling state, and emit the actual EXTR instruction. -/
theorem rhs_forward {p : Program} (hp : Data p) (ctx : Ctx) (mirrored : Bool)
    {w x y : Nat} {X Y : Int} {rx ry : Reg}
    (mappedX : ctx.valueReg? x = some rx) (mappedY : ctx.valueReg? y = some ry)
    (width : w = 32 ∨ w = 64) (fits : Y < 64)
    (st : State) (safeX : DemandAllowed ctx st x) (safeY : DemandAllowed ctx st y)
    (tr : Array RuleId) (n : Nat) :
    ∃ trace,(evalExpr p (Stock.sem ctx) {} (n+60) (extrRule mirrored).rhs
      (extrEnv mirrored w x X y Y)).run (st,tr) =
      .ok (some (.regsVec [[(st.base.fresh .int).1]]),
        {(st.mark x).mark y with base := (st.base.fresh .int).2.emit (.aluRRRShift .extr (szOf w) (st.base.fresh .int).1 rx ry (shiftFor w Y.toNat))},trace) := by
  have requestX := stock_put_in_reg ctx st x rx mappedX safeX
  have requestY := stock_put_in_reg ctx (st.mark x) y ry mappedY safeY
  have shift := fun q => immediate_shift ctx q fits
  have helper := fun q trace fuel => helper_run hp ctx width q trace fuel rx ry Y.toNat
  have output := fun q trace fuel r => output_run hp ctx q trace fuel r
  cases hp
  cases mirrored
  all_goals simp only [extrRule,extrEnv,Bool.false_eq_true,ite_true,ite_false]
  all_goals refine Exists.intro ?trace ?proof
  all_goals isel_eval [*,rule_lower_1501,rule_lower_1507,sem_ctor]
  all_goals rfl

/-- Concrete mapped words inhabit both RHS routes and supported widths; the
source match/binding and complete-function witness remain separate obligations. -/
theorem rhs_witness (mirrored : Bool) (w : Nat) (width : w = 32 ∨ w = 64) :
    ∃ trace,(evalExpr program (Stock.sem sinkCtx) {} 60 (extrRule mirrored).rhs
      (extrEnv mirrored w 0 1 1 1)).run (sinkState,#[]) =
      .ok (some (.regsVec [[(sinkState.base.fresh .int).1]]),
        {(sinkState.mark 0).mark 1 with base := (sinkState.base.fresh .int).2.emit (.aluRRRShift .extr (szOf w) (sinkState.base.fresh .int).1 (.vreg 192 .int)
            (.vreg 193 .int) (shiftFor w 1))},trace) := by
  have safe0 := stock_put_in_reg_witness.1
  have safe1 : DemandAllowed sinkCtx sinkState 1 := by
    intro i found
    change (none : Option Nat) = some i at found
    cases found
  exact rhs_forward data_program sinkCtx mirrored (w := w) (x := 0) (y := 1)
    (X := 1) (Y := 1) rfl rfl width (by decide) sinkState safe0 safe1 #[] 0

end Backend.Stock.Proof.LogicalExtr
#print axioms Backend.Stock.Proof.LogicalExtr.helper_run
#print axioms Backend.Stock.Proof.LogicalExtr.rhs_forward
#print axioms Backend.Stock.Proof.LogicalExtr.rhs_witness
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let mut count : Nat := 0
  for (name,_) in env.constants.toList do
    if (env.getModuleIdxFor? name).isSome then continue
    for ax in ← collectAxioms name do
      unless #[``propext,``Classical.choice,``Quot.sound].contains ax do
        throwError "unexpected axiom {ax} in {name}"
    count := count+1
  logInfo m!"STOCK_EXTR_RHS_STANDARD_ONLY {count}"
