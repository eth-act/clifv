from pathlib import Path
import subprocess as sp,os,json,hashlib,datetime
root=Path('/home/lee/clifv/.worktrees/stock-mixed-production')
def git(*a,env=None,data=None):return sp.check_output(['git',*a],cwd=root,env=env,input=data).decode().strip()
parent=git('rev-parse','agent/stock-logical-production');assert parent=='371a3a2d2fc406814ff78814e9d9e13fb579e025'
head=git('rev-parse','HEAD');assert head=='4b861517ed14b6e84254458ef765b583a5d43dca';assert not git('status','--porcelain')
entries={}
for scratch,target in [('StockExtrSemantics','FV/Backend/Proof/StockLogicalExtrSemantics.lean'),('StockExtrRhs','FV/Backend/Proof/StockLogicalExtrRhs.lean'),('StockLogicalExtrWitness','FV/E2E/StockLogicalExtrWitness.lean')]:
 s=Path('/tmp/'+scratch+'.lean').read_text().split('#print axioms')[0].rstrip()+'\n'
 entries[target]=s
# Audits scan all new namespace declarations, including imported private/generated declarations.
entries['scripts/audit/stock-logical-extr.lean']='''import FV.Backend.Proof.StockLogicalExtrSemantics
import FV.Backend.Proof.StockLogicalExtrRhs
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let mut count : Nat := 0
  for (name,_) in env.constants.toList do
    if !(name.toString.contains "LogicalExtr") then continue
    for ax in ← collectAxioms name do
      unless #[``propext,``Classical.choice,``Quot.sound].contains ax do
        throwError "unexpected axiom {ax} in {name}"
    count := count+1
  logInfo m!"STOCK_LOGICAL_EXTR_CORE_STANDARD_ONLY {count}"
'''
entries['scripts/audit/stock-logical-extr-witness.lean']='''import FV.E2E.StockLogicalExtrWitness
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let mut count : Nat := 0
  for (name,_) in env.constants.toList do
    if !(name.toString.contains "StockLogicalExtrWitness") then continue
    for ax in ← collectAxioms name do
      unless #[``propext,``Classical.choice,``Quot.sound,
        ``E2E.StockLogicalExtrWitness.checks_true._native.native_decide.ax_1].contains ax do
        throwError "unexpected axiom {ax} in {name}"
    count := count+1
  logInfo m!"STOCK_LOGICAL_EXTR_FIXED_WITNESS_AUDIT {count}"
'''
logs={n:Path('/tmp/stock-mixed-draft-check/'+n+'.log').read_text() for n in ['extr-semantics-witness','extr-rhs-source-compatible-witness-fixed','logical-extr-pipeline-selected-witness']}
assert 'STOCK_EXTR_SEMANTICS_STANDARD_ONLY 3' in logs['extr-semantics-witness']
assert 'STOCK_EXTR_RHS_STANDARD_ONLY 108' in logs['extr-rhs-source-compatible-witness-fixed']
assert 'STOCK_LOGICAL_EXTR_PIPELINE_FIXED_WITNESS_AUDIT 29' in logs['logical-extr-pipeline-selected-witness']
assert all('error:' not in s and 'sorryAx' not in s for s in logs.values())
receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'parent':parent,'state':'verified two-input EXTR next-class prerequisite, not complete logical activation or a proof-fragment PR','core_standard_only_declarations':111,'fixed_pipeline_declarations':29,'fixed_pipeline_native_facts':1,'pipeline_configurations':24,'source_hashes':{p:hashlib.sha256(s.encode()).hexdigest() for p,s in entries.items()},'logs':logs,'proof_scope':'Actual two-register aluRRRShift.extr, arbitrary distinct input words, final alias resolution and fresh-only write frame. Both original1501/1507 RHS routes, internally derived safe requests/maps, exact output and complete demand/emission state. Concrete RHS shifts now positive and sum to supported width.','pipeline_scope':'24 actual Stock full-pipeline cases:6existing ABI/width configurations x2ORoperandorders x2cleanup. Native facts assert original LowerScope/dominance/ABI, actual862or863selected rule, oldlowerCheckfalse, actualprepare/prepCheck/Leanallocation/checkAlloc/physicalallocation/emission/layout/formcoverage. Consumed ninth stack argument, unused parameters, explicit slot, omitted deadoperation; no legacy fallback substitution.','limits':'Core proof/helper/RHS scratch checks are standard-only; fixed finite data pipeline witnesses use the one explicitly identified native fact. Normal module/private-name port and shipped-native consumer gates pending. Actual source/lookthrough match+record/resultbinding+guarded source transfer for EXTR still need integration. Full11root logical body/entry/return/NI/classifier/consumer integration and every original#140 family/effect/CFG/whole-driver/completeness obligation remain.','resources':'No new worktree/FVcache.3GiB scratch beside sole<=13GiB authorchild, strict16GiBaggregate, launcher held/resumed in finally. Existing arithmetic087 and mixed4b source trees unchanged.','current_main':'ddfeb764','reconciliation':'Kev#350/#351 float interfaces read; read-only merge-tree arithmetic087+ddfeb764 conflict-free; reconcile affected imports before activation, current old-source gate remains live.'}
entries['docs/research/stock-logical-extr-checkpoint.json']=json.dumps(receipt,indent=2)+'\n'
packet=Path('/tmp/stock-extr-published-packet');packet.mkdir(exist_ok=True)
for p,s in entries.items():q=packet/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(s)
idx='/tmp/stock-extr-publish.index';Path(idx).unlink(missing_ok=True);env=dict(os.environ,GIT_INDEX_FILE=idx)
git('read-tree',parent,env=env)
for p,s in entries.items():
 blob=git('hash-object','-w','--stdin',data=s.encode());git('update-index','--add','--cacheinfo','100644',blob,p,env=env)
tree=git('write-tree',env=env);commit=git('commit-tree',tree,'-p',parent,data=b'Prove two-input Stock EXTR RHS and checked pipeline witnesses\n');git('update-ref','refs/heads/agent/stock-logical-production',commit,parent)
assert git('rev-parse','HEAD')==head and not git('status','--porcelain')
Path('/tmp/stock-logical-extr-publish-result.json').write_text(json.dumps({'commit':commit,'parent':parent,'files':list(entries),'checked_out_head_unchanged':True},indent=2)+'\n');print(commit)
