import FV.Backend.Proof.StockScalarAddScanWitness
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let targets : Array String := #["FV.Backend.Proof.StockScalarAddScanWitness"]
  let mut count : Nat := 0
  for (name, _) in env.constants.toList do
    let some i := env.getModuleIdxFor? name | continue
    unless targets.contains env.header.moduleNames[i]!.toString do continue
    let axioms ← collectAxioms name
    for ax in axioms do
      unless #[``propext, ``Classical.choice, ``Quot.sound].contains ax ||
          (ax.toString.startsWith "Backend.Stock.Proof.ScalarAddScanWitness." && (ax.toString.splitOn "._native.native_decide.ax_").length == 2) do
        throwError "disallowed axiom {ax} in {name}"
    count := count + 1
  unless count > 0 do throwError "empty consumer constant audit"
  logInfo m!"FIXED_WITNESS_CONSTANTS_STANDARD_OR_OWN_NATIVE_ONLY {count}"
