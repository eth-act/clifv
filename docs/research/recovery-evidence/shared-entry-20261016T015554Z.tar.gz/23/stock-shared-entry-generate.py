from pathlib import Path
import json,hashlib,re,datetime,subprocess
name='stock-shared-entry';base='stock-preentry';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
old=json.loads(Path('docs/research/'+base+'-checkpoint.json').read_text());assert all(sha(n)==h for n,h in old['sources'].items())
modules={'PerEdgeSpillSharedJump':'Backend.Proof.PerEdgeSpill.','StockSharedJump':'Backend.Stock.Proof.','PerEdgeSpillSharedFixture':'Backend.Stock.Proof.SharedJumpFixture.','StockSharedJumpWitness':'Backend.Stock.Proof.SharedJumpWitness.'}
paths=['FV/Backend/Proof/'+m+'.lean' for m in modules]
roots=[ns+n for m,ns in modules.items() for n in re.findall(r'^theorem (\w+)',Path('FV/Backend/Proof/'+m+'.lean').read_text(),re.M)];assert len(roots)==4
p={k:old[k] for k in ['goal','status','full_goal_checklist','comparison_preservation']}
p.update(updated_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),baseline_checkpoint='docs/research/'+base+'-checkpoint.json',previous_goal_turn_classification='progress: canonical unique entry runs/real function-entry saves/witnesses;1915-root/full2474/remoteec0e20a7 verified',scope='Actual shared-target copy/jump/edge execution establishes successor GoodAt and canonical shared pre-entry inclusion. Stock derives copy metadata/storage under original scope/SSA. Complete cyclic witness runs actual synthetic allocated block. Universal shared-source classification, arbitrary full blocks, original-input static/dataflow, actual fixpoint/fallback completeness and original full source/driver/production obligations remain open.',sources=old['sources']|{n:sha(n) for n in paths},new_or_appended_source_paths=paths,new_public_roots=roots,next_steps=['Prove actual Stock/prepared shared-target predecessor classification: remaining pre-jump copy sources are operandless jumps; preserve TryCall one-successor forced splitting','Compose arbitrary full block/edge verification for no-copy terminators and shared jumps with actual entry/pre-body states; derive universal Stock static/class/must-availability/EntryAvailAt under original source conditions, actual checker/fallback fixpoint acceptance/completeness','Complete all original source/DFG/world/block/driver simulation/completeness, uncovered families/effects/traps/sinking and actual compiler/checker/linker/generated-proof production integration; final full audits/gates/fresh complete comparison preserving original input/theorem/axiom/identity/stage/#179 parity'],new_root_witness_coverage={'stock_shared_jump_block_witness':['spill_shared_jump_runs','stock_spill_shared_jump_runs','shared_jump_layout','complete original LowerScope/Dominated cyclic source with raw preparation/global checked allocation/physical lowering; exact synthetic block3 jump1 and two live virtual-int loop parameters194/195; real copy swaps arguments195/194 before actual jump; actual whole runBlock3 and edgeAt rename establish both successor parameter homes/save invariant and canonical shared pre-entry inclusion']})
Path('docs/research/'+name+'-checkpoint.json').write_text(json.dumps(p,indent=2)+'\n')
code=Path('docs/research/'+base+'-all-axioms.lean').read_text()
imports='\n'.join('import FV.Backend.Proof.'+m for m in modules)
Path('docs/research/'+name+'-all-axioms.lean').write_text(imports+'\n'+code+'\n'+'\n'.join('#print axioms '+n for n in roots)+'\n')
Path('/tmp/'+name+'-mcp-code.lean').write_text(imports+'\n'+'\n'.join('#print axioms '+n for n in roots)+'\n')
Path('/tmp/'+name+'-full-gates.py').write_text(Path('/tmp/'+base+'-full-gates.py').read_text().replace(base,name))
audit=Path('/tmp/'+base+'-audit-check.py').read_text().replace('stock-entry-good','OLD_BASE').replace(base,name).replace('OLD_BASE',base).replace('1915','1919').replace('1904','1915').replace('all11_sets','all4_sets').replace('11 new','4 new');Path('/tmp/'+name+'-audit-check.py').write_text(audit)
ref='ec0e20a7770807e11cbb8ba196b3c3de616bb84b';manifest={}
for line in subprocess.check_output(['git','ls-tree','-r',ref,'--','FV','FVTest'],text=True).splitlines():
 meta,n=line.split('\t');blob=meta.split()[2]
 if not n.endswith('.lean'):continue
 data=Path(n).read_bytes();assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==blob,n
 manifest[n]=sha(n)
new=sorted(str(x) for top in ['FV','FVTest'] for x in Path(top).rglob('*.lean') if str(x) not in manifest);assert new==sorted(paths),new
Path('/tmp/'+name+'-source-preservation.json').write_text(json.dumps({'baseline':ref,'existing_Lean_files':len(manifest),'all_existing_sources_byte_identical':True,'new_sources':new,'source_sha256':manifest},indent=2)+'\n')
print(len(manifest),'old files unchanged;',len(p['sources']),'recorded paths;',len(roots),'new roots')
