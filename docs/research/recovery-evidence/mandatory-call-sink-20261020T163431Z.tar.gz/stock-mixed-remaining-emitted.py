from pathlib import Path
import json,hashlib
base=Path('/tmp/StockMixedPortLinked.lean').read_text();base=base[:base.rindex('#eval ')]
included={p[:-5].replace('/','.') for p in json.loads(Path('/tmp/StockMixedPortLinked-inputs.json').read_text())};root=Path('/tmp/stock-mixed-linked-combined');ordered=[];seen=set();imports=[];bodies=[]
def visit(p):
 if p in seen:return
 seen.add(p)
 for l in p.read_text().splitlines():
  if l.startswith('import Crates.'):visit(root/(l[7:].replace('.','/')+'.lean'))
 ordered.append(p)
completed={'StockMixed6MixedCleanupFallbackGlobal','StockMixed33CleanupFallbackEntries'}
roots=[p for p in sorted((root/'Crates').glob('*.lean')) if p.stem not in completed]
for p in roots:visit(p)
for p in ordered:
 lines=[]
 for l in p.read_text().splitlines():
  if l.startswith('import '):
   m=l[7:]
   if not m.startswith('Crates.') and m not in included and ('import '+m+'\n') not in base and m not in imports:imports.append(m)
  else:lines.append(l)
 bodies.append('\n'.join(lines))
audit='''
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let mut count : Nat := 0
  for (name,_) in env.constants.toList do
    if (env.getModuleIdxFor? name).isSome then continue
    if !name.toString.startsWith "Crates.StockMixed" then continue
    for ax in ← collectAxioms name do
      if #[``propext,``Classical.choice,``Quot.sound].contains ax then continue
      unless ax.toString.startsWith "Crates.StockMixed" &&
        (ax.toString.splitOn "._native.native_decide.ax_").length > 1 do
        throwError "unexpected axiom {ax} in {name}"
    count := count + 1
  unless count > 0 do throwError "empty generated partition"
  logInfo m!"MIXED_REMAINING_EMITTED_AXIOMS_PASS {count}"
'''
s='\n'.join('import '+m for m in imports)+'\n'+base+'\n'+'\n'.join(bodies)+'\n'+audit
Path('/tmp/StockMixedRemainingEmittedChecks.lean').write_text(s);Path('/tmp/StockMixedRemainingEmittedChecks-inputs.json').write_text(json.dumps({str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in ordered},indent=2)+'\n');print(json.dumps({'root_count':len(roots),'generated_files':len(ordered),'combined_bytes':len(s),'additional_imports':imports}))
