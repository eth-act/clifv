import FV.Backend.Lowering.StockArithmetic
import FV.Backend.StockArithmeticCheck
import FV.Backend.ABIReadOnly
import FV.Backend.ArithmeticProduction
import FV.Backend
import FV.Opt.Legalize128Pass
import FV.Opt.LegalExn
import FVTest.Opt.Common
import FVTest.Backend.StockConfig
import FVTest.Backend.AllocChoice
import FV.Backend.Proof.LowerSimUCheck
import FV.E2E.RegLevelFrameSaved
import FV.E2E.RegLevelUTry

namespace Backend.Stock.Mixed
set_option autoImplicit false

abbrev abiEligible := Arithmetic.abiEligible

def bodyEligible (stm : Clif.Stmt) : Bool :=
  match stm.inst with
  | .binary op ty _ _ => (op == .iadd || op == .isub) && (ty == .i32 || ty == .i64)
  | .select ty _ _ _ => ty == .i32 || ty == .i64
  | _ => false

def eligible (f : Clif.Function) : Bool :=
  match f.blocks with
  | [b] => b.body.all bodyEligible &&
      (match b.term with | .ret _ => true | _ => false) &&
      f.sig.params.all abiEligible && f.sig.returns.all abiEligible
  | _ => false

/-- Previously shipped arithmetic classes retain their exact selector. -/
def activationEligible (f : Clif.Function) : Bool :=
  eligible f && !Arithmetic.eligible f

def lowerCandidate (f : Clif.Function) : Except String VCode :=
  if !activationEligible f then Arithmetic.lowerCandidate f
  else do
    let result ← Stock.lower f
    if result.edgeArgs.all (fun row => row.all (·.isEmpty)) then pure result.code
    else throw "Stock mixed candidate has nonempty edge arguments"


end Backend.Stock.Mixed

namespace Backend.Stock.Mixed
open Backend.Proof.Driver
set_option autoImplicit false

def sourceOk (f : Clif.Function) : Bool :=
  eligible f && lowerScopeB f && dominatedB f && sigAbiOk f.sig

/-- Only the new actual-Stock branch; the production union retains its previous
legacy/arithmetic alternatives and transactional fallbacks. -/
def check (f : Clif.Function) (vc : VCode) : Bool :=
  sourceOk f && match Stock.lower f with
  | .error _ => false
  | .ok result => decide (result.code = vc) && result.edgeArgs.all (fun row => row.all (·.isEmpty))


end Backend.Stock.Mixed

namespace Backend.ABIReadFlags
set_option autoImplicit false

def extra : MInst → Bool
  | .aluRRR .subS _ .xzr (.vreg _ .int) .xzr => true
  | .csel (.vreg _ .int) (.vreg _ .int) (.vreg _ .int) _ => true
  | _ => false

def instruction (sig : Clif.Signature) (b k : Nat) (i : MInst) : Bool :=
  Backend.ABIReadOnly.instruction sig b k i || extra i

def check (sig : Clif.Signature) (vc : VCode) : Bool :=
  vc.blocks.toList.zipIdx.all fun (block,b) =>
    block.insts.toList.zipIdx.all fun (i,k) => instruction sig b k i


end Backend.ABIReadFlags

namespace Backend.SemanticNI
set_option autoImplicit false

/-- Keep the legacy lowering verdict, or validate actual Stock provenance and
its finite ABI read boundary. No proof object is supplied by the input. -/
def check (f : Clif.Function) (vc : VCode) : Bool :=
  Proof.Driver.lowerCheck f vc ||
    ((Stock.Arithmetic.check f vc && ABIReadOnly.check f.sig vc) ||
      (Stock.Mixed.check f vc && ABIReadFlags.check f.sig vc))

end Backend.SemanticNI

namespace Backend.Stock.Arithmetic
set_option autoImplicit false

/-- One shared executable choice for compiler, checker, linker and generated
proofs. A candidate rejected by paired semantic validation retries the shipped
selector before any later stage observes code or rule history. -/
def lowerValidated (f : Clif.Function) : Except String VCode :=
  if D0.eligible f || ScalarAdd.activationEligible f || !eligible f then ScalarAdd.lower f
  else
    let attempt := do
      let vc ← lowerCandidate f
      if SemanticNI.check f vc then pure vc
      else throw "Stock candidate failed paired semantic validation"
    match attempt with
    | .ok vc => .ok vc
    | .error _ => ScalarAdd.lower f


/-- Consumer routing data records retained artifacts discovered in a mixed
executable. It carries no proof: the ordinary semantic/allocation/binary checks
validate either selected route. No function name restricts the proved class. -/
def lowerWithFallbacks (retained : List String) (f : Clif.Function) : Except String VCode :=
  if retained.contains f.name then ScalarAdd.lower f else lowerValidated f

end Backend.Stock.Arithmetic

namespace Backend
set_option autoImplicit false

/-- The complete paired semantic checker validates actual selected code before
it can reach a verified allocation. Failure retries the shipped lowerer. -/
def lowerCheckedArithmeticNI (f : Clif.Function) (verify : Bool) : Except String VCode :=
  let attempt := do
    let vc ← Stock.Arithmetic.lowerValidated f
    if verify && !SemanticNI.check f vc then
      throw "lowering rejected by the paired semantic lowering validator"
    pure vc
  match attempt with
  | .ok vc => .ok vc
  | .error _ => lowerCheckedProductionWith Stock.ScalarAdd.lower f verify

def lowerForAllocationArithmeticNI (f : Clif.Function) (verify cleanup : Bool) : Except String VCode :=
  (lowerCheckedArithmeticNI f verify).map (Stock.Arithmetic.stage cleanup)

/-- One complete transactional file attempt, using the same source, allocator,
verification and cleanup settings. Earlier shipped classes keep their selectors. -/
def compileFileArithmeticNIWhen {m : Type → Type} [Monad m] (enabled : Bool)
    (alloc : Array VCode → m (Array (Except String AFunc))) (pf : Clif.ParsedFile)
    (preUnverified : List (String × String) := []) (cleanup : Bool := true) : m FileAsm := do
  if !enabled then return ← compileFileScalarWhen false alloc pf preUnverified cleanup
  if !(pf.funcs.any fun p => p.func.toOption.any Stock.Arithmetic.eligible) then
    return ← compileFileScalarWhen true alloc pf preUnverified cleanup
  let attempt ← compileFileWithLowering lowerForAllocationArithmeticNI VCode.rulesFired
    alloc pf preUnverified cleanup
  if !attempt.unsupported.isEmpty || !attempt.layout.isOk then
    compileFileScalarWhen true alloc pf preUnverified cleanup
  else pure attempt

end Backend

namespace Backend.Stock.Mixed
set_option autoImplicit false

/-- A complete new candidate is checked before consumers see it. Every other
input or failed candidate retains the previous arithmetic production route. -/
def lowerValidated (f : Clif.Function) : Except String VCode :=
  if !activationEligible f then Arithmetic.lowerValidated f
  else
    let attempt := do
      let vc ← lowerCandidate f
      if check f vc && ABIReadFlags.check f.sig vc then pure vc
      else throw "Stock mixed candidate failed paired semantic validation"
    match attempt with
    | .ok vc => .ok vc
    | .error _ => Arithmetic.lowerValidated f

/-- Retained-artifact reconstruction is selected from actual artifact checks;
names carry routing data and never restrict the proved source class. -/
def lowerWithFallbacks (retained : List String) (f : Clif.Function) : Except String VCode :=
  if retained.contains f.name then Arithmetic.lowerWithFallbacks retained f
  else lowerValidated f

end Backend.Stock.Mixed

namespace Backend
set_option autoImplicit false

def lowerCheckedMixedNI (f : Clif.Function) (verify : Bool) : Except String VCode :=
  let attempt := do
    let vc ← Stock.Mixed.lowerValidated f
    if verify && !SemanticNI.check f vc then
      throw "lowering rejected by the paired semantic lowering validator"
    pure vc
  match attempt with
  | .ok vc => .ok vc
  | .error _ => lowerCheckedArithmeticNI f verify

def lowerForAllocationMixedNI (f : Clif.Function) (verify cleanup : Bool) : Except String VCode :=
  (lowerCheckedMixedNI f verify).map (Stock.Arithmetic.stage cleanup)

/-- A failed complete attempt retries the previous complete arithmetic pipeline
with the original source, allocator and verification/cleanup settings. -/
def compileFileMixedNIWhen {m : Type → Type} [Monad m] (enabled : Bool)
    (alloc : Array VCode → m (Array (Except String AFunc))) (pf : Clif.ParsedFile)
    (preUnverified : List (String × String) := []) (cleanup : Bool := true) : m FileAsm := do
  if !enabled then return ← compileFileArithmeticNIWhen false alloc pf preUnverified cleanup
  if !(pf.funcs.any fun p => p.func.toOption.any Stock.Mixed.activationEligible) then
    return ← compileFileArithmeticNIWhen true alloc pf preUnverified cleanup
  let attempt ← compileFileWithLowering lowerForAllocationMixedNI VCode.rulesFired
    alloc pf preUnverified cleanup
  if !attempt.unsupported.isEmpty || !attempt.layout.isOk then
    compileFileArithmeticNIWhen true alloc pf preUnverified cleanup
  else pure attempt

end Backend

/-!
`lake exe lean-backend <in.clif> <out.o|out.s> [--traps <out.json>] [--rules <out.txt>]
[--dump <dir>] [--regalloc lean|regalloc2|spill|stack|regalloc2-small] [--personality <sym>]
[--opt [--opt-* options]]`: compile every function of a `.clif` file with the
Lean backend (`FV/Backend.lean`). Register allocation: `lean` (default; the Lean allocator
`leanAlloc`, `FV/Backend/LinearScan.lean`, every allocation validated by the Lean checker
`checkAlloc` with the spill allocation as fallback, `docs/contracts/regalloc.md`; with
`$FV_RA_OUT` set, its answers are written there, `FVTest/Backend/AllocChoice.lean`),
`regalloc2` (the external `lean-regalloc` oracle, `$LEAN_REGALLOC` or
`rust/target/release/lean-regalloc`, validated the same way; the default under
`--stock-config`), `spill` (the fallback for every function), `stack` (the
stack-slot baseline), or `regalloc2-small` (regalloc2 with the 10-register stress environment
`smallEnv`, for testing spill code). If the output path ends in `.o`, write an ELF relocatable object encoded
by the Lean encoder (`FV/Backend/{Encode,Obj}.lean`, no assembler); otherwise write assembly
text (for `llvm-mc`, the encoder's test oracle). Optionally write the function/trap table that
`clif-native --functions-obj` reads (`--traps`), the names of the ISLE rules that fired
(`--rules`, one per line), and per function `name.bin`/`name.relocs.json`/`name.traps.json`
into `dir` (`--dump`, the schema of `clif2obj`'s dumps). Functions the backend does not
support are listed on stderr (and in the table), as is every fired rule outside the
emitter-subset closure (`Isle.Aarch64.Closure.rules`). Exit status 0 unless the arguments are
wrong, the input cannot be read, or encoding fails (an encoder or backend bug; the message
names the function and instruction). With `--opt`, every function is first optimised by the
Lean mid-end (`Opt.optimizeExe`, the executable compiler's mid-end, `docs/contracts/midend.md`;
options in `FVTest/Opt/Common.lean`).
With `--personality <sym>` (`cargo fv`: `rust_eh_personality`), functions with landing pads
(`try_call`) get cg_clif's LSDA and a `zLPR` CIE with that personality routine
(`FV/Backend/Obj.lean`); without it their landing pads have no LSDA (as Cranelift's own
objects, which leave the LSDA to the embedder).

Every function that mentions `i128` is first legalised by `Opt.Legalize128` (rewritten to
plain `i8..i64` CLIF before the mid-end and the backend). A legalised function the validator
`Opt.Legal.checkW` accepts is covered by `E2E.backend_correct_legal_wide` and treated like any other
function (`InSubset` and `lowerCheck` decided on the legalised form); a rejected one is
reported unverified ("i128 legalized (outside backend_correct: …)"). Under `--opt` with the
proven rule sets (`--opt-proven-only`) a legalised function is covered by
`E2E.backend_correct_legal_opt_wide` (the legalisation composed with the mid-end), every other by
`E2E.backend_correct_opt_exe` (`call_indirect`, `try_call`, `try_call_indirect` included); with
unproven rules every legalised function is reported unverified. The unwinding of a legalised
function with a `try_call` is covered by `E2E.backend_correct_legal_unwind` when the
handler-edge check `Opt.Legal.exnOk` and the unwinding theorem's checks pass (dead cleanup,
no `--opt`). Under `--opt` with the proven rule sets, the unwinding of a function that is not
legalised is covered by `E2E.backend_correct_opt_exe_cleanup_unwind` (without dead cleanup
`E2E.backend_correct_opt_exe_unwind`) when its compiled form is the mid-end's output on its
source function and the unwinding theorem's checks pass on the optimised function; a legalised
one by `E2E.backend_correct_legal_opt_unwind` (dead cleanup) when its compiled form is the
mid-end's output on the source function's legalisation, which `Opt.Legal.check` and
`Opt.Legal.exnOk` accept, and the checks pass.

A function inside the theorem's scope whose size is over the validation budget
(`Backend.validationBudget`, blocks × values) is compiled without running the lowering
validator and listed as `compiled, unverified (validation budget)`.
-/

open Backend

def usage : String :=
  "usage: lean-backend <in.clif> <out.o|out.s> [--traps <out.json>] [--rules <out.txt>] [--dump <dir>] [--regalloc lean|regalloc2|spill|stack|regalloc2-small] [--personality <sym>] [--opt] [--dead-cleanup|--no-dead-cleanup] [--stock-config <request.json> --config-receipt <receipt.json>]"

/-- The rules the end-to-end theorem covers: the emitter-subset closure, and the `try_call`
rules of `lower_branch` (ids 1034 `bl`, 1035 GOT + `blr`: `Backend.Proof.tryRootRule`, proven by
`tryRulesCorrect`; 1036 `try_call_indirect`: `Backend.Proof.tryIndRootRule`, proven by
`tryIndRulesCorrect`), which are outside the generated closure (its opcodes have no
`try_call`). -/
def closureIds : Std.HashSet Isle.RuleId :=
  Isle.Aarch64.Closure.rules.foldl (fun s r => s.insert r.rule) ({} : Std.HashSet Isle.RuleId)
    |>.insert 1034 |>.insert 1035 |>.insert 1036

structure Opts where
  traps : Option String := none
  rules : Option String := none
  dump : Option String := none
  /-- `--regalloc`; default `lean` (`regalloc2` under `--stock-config`). -/
  regalloc : Option String := none
  opt : Option Opt.Config := none
  personality : Option String := none
  stockConfig : Option String := none
  configReceipt : Option String := none
  deadCleanup : Bool := true

/-- One function's allocation as the backend lowered it: the prepared VCode `vcp`, the
allocation `rf` with `lowerRFunc vcp rf = .ok af` (`lowerAllocReady_eq`, `lowerAlloc_eq`), and
`af`; `none` without an `RFunc` (the stack allocator) or when `prepare` failed. -/
abbrev AllocRecord := Option (VCode × RFunc × AFunc)

/-- `Allocator.run`, also returning each function's `AllocRecord` (the objects the unwinding
theorems name). The `regalloc2` case is `allocateRegalloc2` with the allocation it lowers
(`allocResult vcp (readyAnswer vcp ra)`) kept. -/
def allocRecording (a : Allocator) (vcs : Array VCode) :
    IO (Array (Except String AFunc) × Array AllocRecord) := do
  match a with
  | .stack => pure (vcs.map allocate, vcs.map fun _ => none)
  | .spill =>
    let ps := vcs.map prepareChecked
    let afs := ps.map (·.bind fun vcp => lowerRFunc vcp (spillAlloc vcp))
    pure (afs, (ps.zip afs).map fun (p, af) => match p, af with
      | .ok vcp, .ok af => some (vcp, spillAlloc vcp, af)
      | _, _ => none)
  | .regalloc2 bin env =>
    let prepared := vcs.map prepareChecked
    let ok := prepared.filterMap (·.toOption)
    let rs : Array (Except String RFunc) ← do
      try
        match ← runLeanRegalloc bin env ok with
        | .error e => pure (ok.map fun _ => .error e)
        | .ok rs => pure (rs.map (·.bind RAResult.oracle))
      catch e => pure (ok.map fun _ => .error (toString e))
    let mut out : Array (Except String AFunc) := #[]
    let mut recs : Array AllocRecord := #[]
    let mut j := 0
    for p in prepared do
      match p with
      | .error e =>
        out := out.push (.error e)
        recs := recs.push none
      | .ok vcp =>
        let ra := rs[j]?.getD (.error "lean-regalloc: missing result")
        let af := lowerAllocReady vcp ra
        out := out.push af
        recs := recs.push (af.toOption.map (vcp, allocResult vcp (readyAnswer vcp ra), ·))
        j := j + 1
    pure (out, recs)

/-- `allocRunOfName? n` with the `AllocRecord`s: the Lean allocator (`n = "lean"`:
`allocateLeanAnswers`, writing the answers to `$FV_RA_OUT` when set) records its allocation as
the `regalloc2` case does (`allocResult vcp (readyAnswer vcp ra)` with `ra = leanAlloc vcp`);
other names run `allocRecording a`. -/
def allocRecordingNamed (n : String) (a : Allocator) (vcs : Array VCode) :
    IO (Array (Except String AFunc) × Array AllocRecord) := do
  if n != "lean" then return ← allocRecording a vcs
  let (afs, ans) := allocateLeanAnswers vcs
  if let some p ← IO.getEnv "FV_RA_OUT" then
    IO.FS.writeFile p ("{\"functions\":[" ++ ",".intercalate ans.toList ++ "]}\n")
  let recs := (vcs.zip afs).map fun (vc, af) => match prepareChecked vc, af with
    | .ok vcp, .ok af => some (vcp, allocResult vcp (readyAnswer vcp (leanAlloc vcp)), af)
    | _, _ => none
  pure (afs, recs)

/-- The first check of the unwinding theorem (`E2E.backend_correct_final_cleanup_unwind`, or
`E2E.backend_correct_final_unwind` without dead cleanup) that fails for a compiled function `f`
with a `try_call`, on the objects the theorem names: the lowering `vc` of `f` (`unwCheck`, the
exceptional-edge half of `lowerCheckU`; `lowerCheck` ran during compilation), the prepared
VCode and the allocation (`savedCheck vcp rf`), the allocated function and its final code
(`lastCallsOk af fa`, `padsNonzeroB af fa`). `callSites`/`unwindRows` succeed for every compiled
function (compilation fails otherwise). -/
def unwindCheckFailure? (f : Clif.Function) (rec : AllocRecord) (fa? : Option FnAsm) :
    Option String :=
  match lowerFunction f with
  | .error _ => some "lowerFunction"
  | .ok vc =>
    if !Proof.Driver.unwCheck f vc then some "unwCheck"
    else match rec, fa? with
      | some (vcp, rf, af), some fa =>
        if !savedCheck vcp rf then some "savedCheck"
        else if !Proof.lastCallsOk af fa then some "lastCallsOk"
        else if !Proof.padsNonzeroB af fa then some "padsNonzeroB"
        else none
      | _, _ => some "no lowerRFunc allocation (allocator)"

def run (input output : String) (o : Opts) : IO UInt32 := do
  let src ← IO.FS.readFile input
  if o.configReceipt.isSome != o.stockConfig.isSome then
    IO.eprintln "lean-backend: --stock-config and --config-receipt must be supplied together"
    return 2
  if o.stockConfig.isSome && (o.opt.isSome || o.regalloc.any (· != "regalloc2") || o.personality.isSome) then
    IO.eprintln "lean-backend: stock configuration forbids independent opt/regalloc/personality overrides"
    return 2
  let mut stock : Option StockConfig.Config := none
  if let some path := o.stockConfig then
    let request ← match Lean.Json.parse (← IO.FS.readFile path) with
      | .ok j => pure j
      | .error e => do IO.eprintln s!"lean-backend: invalid configuration JSON: {e}"; return 2
    let checked := StockConfig.parse request
    let error := match checked with | .ok _ => none | .error e => some e
    if let some receipt := o.configReceipt then
      IO.FS.writeFile receipt ((StockConfig.receipt request error none o.deadCleanup).pretty ++ "\n")
    match checked with
    | .error e => IO.eprintln s!"lean-backend: unsupported stock configuration: {e}"; return 3
    | .ok c => stock := some c
  let ra := o.regalloc.getD (if o.stockConfig.isSome then "regalloc2" else "lean")
  let some runAlloc ← allocRunOfName? ra
    | do IO.eprintln s!"lean-backend: unknown allocator {ra}"; return 2
  -- the stock configuration requires regalloc2 (checked above)
  let alloc := (← Allocator.ofName? ra).getD .spill
  let source := Clif.parseFile src
  let lg := Opt.Legalize128.parsedFile128 source
  let pf := match o.opt with | some c => Opt.optimizeParsedFile c lg.file | none => lg.file
  -- the mid-end theorems (`E2E.backend_correct_opt_exe`, `E2E.backend_correct_legal_opt`) cover
  -- every function, legalised ones included, for the proven rule sets
  let unv128 := match o.opt with
    | some c => if c.rules == .cranelift && c.ruleAllow == .proven then lg.unverified
      else lg.unverified ++ lg.accepted.map
        (·, "i128 legalized and optimised with unproven rules (outside backend_correct_legal_opt: --opt)")
    | none => lg.unverified
  let unvTry : List (String × String) := []
  -- The settings checks see each function before and after `i128` legalisation.
  let clif (name : String) : List Clif.Function :=
    (source.funcs ++ pf.funcs).filterMap fun p => if p.name == name then p.func.toOption else none
  let rejected ← IO.mkRef (#[] : Array (String × String))
  -- the allocation of each function as lowered (by VCode name), for the unwinding checks
  let records ← IO.mkRef (#[] : Array (String × AllocRecord))
  let fa ← match stock with
    | none => compileFileMixedNIWhen (!o.opt.isSome &&
        !(pf.funcs.any fun p => p.func.toOption.any fun f => f.blocks.any (·.term.isTry))) (fun vcs => do
        let (afs, recs) ← allocRecordingNamed ra alloc vcs
        records.set ((vcs.map (·.name)).zip recs)
        pure afs) pf (unv128 ++ unvTry) o.deadCleanup
    | some c => (compileFileWith (StockConfig.allocate c clif rejected alloc) pf
        (unv128 ++ unvTry ++ pf.funcs.map (fun p => (p.name, "experimental stock-configured driver (outside backend_correct)"))) o.deadCleanup)
  if let (some request, some receipt) := (stock.map (·.request), o.configReceipt) then
    IO.FS.writeFile receipt
      ((StockConfig.receipt request none (some (← rejected.get).toList) o.deadCleanup).pretty ++ "\n")
  let fa := match stock with
    | some c => if c.unwind then fa else { fa with unwind := [] }
    | none => fa
  if output.endsWith ".o" || o.dump.isSome then
    match fa.layout with
    | .error e =>
      IO.eprintln s!"lean-backend: {input}: encoding failed: {e}"
      return 1
    | .ok fbs =>
      if output.endsWith ".o" then IO.FS.writeBinFile output (elfObject fbs fa.unwind fa.lsda o.personality)
      if let some d := o.dump then
        IO.FS.createDirAll d
        for (_, fb) in fbs do
          IO.FS.writeBinFile (System.FilePath.mk d / s!"{fb.name}.bin") (wordsBytes fb.words)
          IO.FS.writeFile (System.FilePath.mk d / s!"{fb.name}.relocs.json") fb.relocsJson
          IO.FS.writeFile (System.FilePath.mk d / s!"{fb.name}.traps.json") fb.trapsJson
          if let some c := stock then
            let metadata := Lean.Json.mkObj [
              ("name", Lean.toJson fb.name), ("alignment", Lean.toJson (4 : Nat)),
              ("unwind_disabled", Lean.toJson (!c.unwind)),
              ("stack_maps", Lean.toJson ([] : List String)),
              ("exception_metadata_comparison_supported", Lean.toJson false)]
            IO.FS.writeFile (System.FilePath.mk d / s!"{fb.name}.metadata.json") (metadata.pretty ++ "\n")
  if !output.endsWith ".o" then IO.FS.writeFile output fa.text
  if let some t := o.traps then IO.FS.writeFile t fa.tableJson
  let names := Isle.Aarch64.program.ruleNames fa.rules
  if let some r := o.rules then IO.FS.writeFile r (String.join (names.map (· ++ "\n")))
  for (id, n) in fa.rules.zip names do
    if !closureIds.contains id then
      IO.eprintln s!"lean-backend: {input}: rule {n} fired outside the emitter-subset closure"
  for (n, why) in fa.unsupported do
    IO.eprintln s!"lean-backend: {input}: %{n}: unsupported: {why}"
  for (n, why) in fa.unverified do
    IO.eprintln s!"lean-backend: {input}: %{n}: compiled, unverified (outside backend_correct): {why}"
  for (n, why) in fa.unvalidated do
    IO.eprintln s!"lean-backend: {input}: %{n}: compiled, unverified (validation budget): {why}"
  -- A function with a `try_call` is inside `backend_correct_final` for the runs in which every
  -- callee of a `try_call` returns normally (callee contract `CalleeTryOk`: the results only; the
  -- exception payload registers are havocked on the normal return). Its unwinding (landing
  -- pads, the LSDA, the frame unwound by the CFI) is inside the unwinding theorem
  -- (`E2E.backend_correct_final_cleanup_unwind`, without dead cleanup
  -- `E2E.backend_correct_final_unwind`) when that theorem's checks pass on its compiled objects
  -- (`unwindCheckFailure?`). An `i128`-legalised function is inside
  -- `E2E.backend_correct_legal_unwind` (dead cleanup only) when, in addition, its legalisation
  -- is recomputed from the source function with the same result, and `Opt.Legal.check` and the
  -- handler-edge check `Opt.Legal.exnOk` accept it (`legalUnwOk`). Under `--opt` with the proven
  -- rule sets, a function that is not legalised is inside
  -- `E2E.backend_correct_opt_exe_cleanup_unwind` (without dead cleanup
  -- `E2E.backend_correct_opt_exe_unwind`) when its compiled form is `Opt.optimizeExe` of its
  -- source function, recomputed (`optUnwOk`), and the checks pass on the optimised function; a
  -- legalised one is inside `E2E.backend_correct_legal_opt_unwind` (dead cleanup only) when its
  -- compiled form is `Opt.optimizeExe` of the source function's legalisation, recomputed, which
  -- `Opt.Legal.check` and `Opt.Legal.exnOk` accept (`legalOptUnwOk`). No unwinding theorem
  -- composes unproven rule sets.
  let recs ← records.get
  let thm := if o.deadCleanup then "backend_correct_final_cleanup_unwind"
    else "backend_correct_final_unwind"
  let optThm := if o.deadCleanup then "backend_correct_opt_exe_cleanup_unwind"
    else "backend_correct_opt_exe_unwind"
  let legalUnwOk (name : String) (g : Clif.Function) : Bool :=
    match (source.funcs.find? (·.name == name)).bind (·.func.toOption) with
    | some f => match Opt.Legalize128.function128Cert f with
      | .ok (g', cert) => g' == g && Opt.Legal.check f g cert && Opt.Legal.exnOk f g cert
      | .error _ => false
    | none => false
  let provenOpt : Bool := match o.opt with
    | some c => c.rules == .cranelift && c.ruleAllow == .proven
    | none => false
  let optUnwOk (name : String) (g : Clif.Function) : Bool :=
    match o.opt, (source.funcs.find? (·.name == name)).bind (·.func.toOption) with
    | some c, some f => provenOpt && Opt.optimizeExe f c == g
    | _, _ => false
  let legalOptUnwOk (name : String) (g : Clif.Function) : Bool :=
    match o.opt, (source.funcs.find? (·.name == name)).bind (·.func.toOption) with
    | some c, some f => match Opt.Legalize128.function128Cert f with
      | .ok (g', cert) => provenOpt && Opt.optimizeExe g' c == g && Opt.Legal.check f g' cert &&
        Opt.Legal.exnOk f g' cert
      | .error _ => false
    | _, _ => false
  for p in pf.funcs do
    if let .ok f := p.func then
      if hasTryCall f && fa.funcs.any (·.name == p.name) && !fa.unverified.any (·.1 == p.name) &&
          !fa.unvalidated.any (·.1 == p.name) then
        let legal := lg.accepted.contains p.name
        let why? : Option String :=
          if o.opt.isSome && !provenOpt then
            some "--opt with unproven rule sets: no unwinding theorem composes them (--opt-proven-only)"
          else if legal && !o.deadCleanup then
            some "i128 legalized: no unwinding theorem composes the legalisation without dead cleanup"
          else if o.opt.isSome && legal && !legalOptUnwOk p.name f then
            some "--opt, i128 legalized: not Opt.optimizeExe of the source function's legalisation accepted by Opt.Legal.check and Opt.Legal.exnOk"
          else if o.opt.isSome && !legal && !optUnwOk p.name f then
            some "--opt: the compiled function is not Opt.optimizeExe of its source function"
          else if o.opt.isNone && legal && !legalUnwOk p.name f then
            some "i128 legalized: Opt.Legal.check (no try_call_indirect, no call_indirect at an i128 signature) or Opt.Legal.exnOk (the handler edges) rejects"
          else (unwindCheckFailure? f ((recs.find? (·.1 == p.name)).bind (·.2))
            (fa.funcs.find? (·.name == p.name))).map (s!"unwinding check failed: {·}")
        let thm := if legal && o.opt.isSome then "backend_correct_legal_opt_unwind"
          else if legal then "backend_correct_legal_unwind"
          else if o.opt.isSome then optThm else thm
        match why? with
        | none =>
          IO.eprintln s!"lean-backend: {input}: %{p.name}: compiled, verified (try_call: unwinding by {thm}; the unwinder/personality model and the decoding of the emitted tables trusted)"
        | some why =>
          IO.eprintln s!"lean-backend: {input}: %{p.name}: compiled, verified for normal returns (try_call: unwinding, landing pads and the LSDA trusted; {why})"
  return 0

def main (args : List String) : IO UInt32 := do
  let rec opts (o : Opts) : List String → Option Opts
    | [] => some o
    | "--traps" :: t :: rest => opts { o with traps := some t } rest
    | "--rules" :: r :: rest => opts { o with rules := some r } rest
    | "--dump" :: d :: rest => opts { o with dump := some d } rest
    | "--regalloc" :: a :: rest => opts { o with regalloc := some a } rest
    | "--personality" :: p :: rest => opts { o with personality := some p } rest
    | "--stock-config" :: c :: rest => opts { o with stockConfig := some c } rest
    | "--config-receipt" :: c :: rest => opts { o with configReceipt := some c } rest
    | "--dead-cleanup" :: rest => opts { o with deadCleanup := true } rest
    | "--no-dead-cleanup" :: rest => opts { o with deadCleanup := false } rest
    | _ => none
  let (optCfg, args) ← match Opt.parseOptArgs args with
    | .ok r => pure r
    | .error e => do IO.eprintln s!"lean-backend: {e}"; return 2
  match args with
  | i :: out :: rest =>
    match opts { opt := optCfg } rest with
    | some o => run i out o
    | none => do IO.eprintln usage; return 2
  | _ => do IO.eprintln usage; return 2
#eval do
  for (mode, flags) in [("Plain", ["--no-dead-cleanup"]), ("Cleanup", [])] do
    for allocator in ["lean", "regalloc2"] do
      let caseDir := "/tmp/stock-mixed-backend-cli/" ++ mode ++ allocator
      IO.FS.createDirAll caseDir
      let code ← main (["/tmp/stock-mixed-backend-input.clif", caseDir ++ "/output.s", "--regalloc", allocator, "--rules", caseDir ++ "/rules.txt", "--dump", caseDir ++ "/dump"] ++ flags)
      unless code == 0 do throw (IO.userError s!"backend CLI failed: {mode} {allocator} {code}")
      let asm ← IO.FS.readFile (caseDir ++ "/output.s")
      unless (asm.splitOn "stock_mixed_cli:").length > 1 && (asm.splitOn "csel").length > 1 do
        throw (IO.userError "missing actual mixed function or select instruction")
      IO.println s!"MIXED_BACKEND_CLI_PASS {mode} {allocator}"
