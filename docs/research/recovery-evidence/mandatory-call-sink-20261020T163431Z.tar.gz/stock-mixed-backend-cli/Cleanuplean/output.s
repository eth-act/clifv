  .text
  .globl stock_mixed_cli
  .type stock_mixed_cli, %function
  .p2align 2
stock_mixed_cli:
.L0_b0:
  stp x29, x30, [sp, #-16]!
  mov x29, sp
  sub sp, sp, #16
  ldur x8, [x29, #16]
  add x8, x1, x8
  subs xzr, x0, xzr
  csel x8, x8, x1, ne
  sub x0, x8, x2
  add sp, sp, #16
  ldp x29, x30, [sp], #16
  ret
  .ifne . - stock_mixed_cli - 44
  .error "function size mismatch"
  .endif
  .size stock_mixed_cli, . - stock_mixed_cli

