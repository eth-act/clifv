  .text
  .globl stock_mixed_cli
  .type stock_mixed_cli, %function
  .p2align 2
stock_mixed_cli:
.L0_b0:
  stp x29, x30, [sp, #-16]!
  mov x29, sp
  sub sp, sp, #288
  stur x19, [sp, #192]
  stur x20, [sp, #200]
  stur x21, [sp, #208]
  stur x22, [sp, #216]
  stur x23, [sp, #224]
  stur x24, [sp, #232]
  stur x25, [sp, #240]
  stur x26, [sp, #248]
  str x27, [sp, #256]
  str x28, [sp, #264]
  stur q8, [sp, #64]
  stur q9, [sp, #80]
  stur q10, [sp, #96]
  stur q11, [sp, #112]
  stur q12, [sp, #128]
  stur q13, [sp, #144]
  stur q14, [sp, #160]
  stur q15, [sp, #176]
  stur x0, [sp, #0]
  stur x1, [sp, #8]
  stur x2, [sp, #16]
  ldur x0, [x29, #16]
  stur x0, [sp, #24]
  ldur x1, [sp, #8]
  ldur x2, [sp, #24]
  add x0, x1, x2
  stur x0, [sp, #32]
  ldur x0, [sp, #0]
  subs xzr, x0, xzr
  ldur x1, [sp, #32]
  ldur x2, [sp, #8]
  csel x0, x1, x2, ne
  stur x0, [sp, #40]
  ldur x1, [sp, #40]
  ldur x2, [sp, #16]
  sub x0, x1, x2
  stur x0, [sp, #48]
  ldur x19, [sp, #192]
  ldur x20, [sp, #200]
  ldur x21, [sp, #208]
  ldur x22, [sp, #216]
  ldur x23, [sp, #224]
  ldur x24, [sp, #232]
  ldur x25, [sp, #240]
  ldur x26, [sp, #248]
  ldr x27, [sp, #256]
  ldr x28, [sp, #264]
  ldur q8, [sp, #64]
  ldur q9, [sp, #80]
  ldur q10, [sp, #96]
  ldur q11, [sp, #112]
  ldur q12, [sp, #128]
  ldur q13, [sp, #144]
  ldur q14, [sp, #160]
  ldur q15, [sp, #176]
  ldur x0, [sp, #48]
  add sp, sp, #288
  ldp x29, x30, [sp], #16
  ret
  .ifne . - stock_mixed_cli - 248
  .error "function size mismatch"
  .endif
  .size stock_mixed_cli, . - stock_mixed_cli

