from pathlib import Path
import re,subprocess,json,hashlib,sys
root=Path('/home/lee/clifv/.worktrees/stock-mixed-production');deps={};files={};pat=re.compile(r'^import\s+(\S+)\s*$')
for folder in ['FV','FVTest']:
 for p in (root/folder).rglob('*.lean'):
  m=str(p.relative_to(root))[:-5].replace('/','.');files[m]=p;deps[m]=[v[1] for l in p.read_text().splitlines() if (v:=pat.match(l))]
changed=subprocess.check_output(['git','diff','--name-only','087e91d1615c8c944e560c050c1eb7c60981d205'],cwd=root,text=True).splitlines();affected={p[:-5].replace('/','.') for p in changed if p.endswith('.lean') and p.startswith(('FV/','FVTest/'))}
while True:
 more={m for m,ds in deps.items() if set(ds)&affected}-affected
 if not more:break
 affected|=more
ordered=[];seen=set()
def visit(m):
 if m in seen or m not in affected:return
 seen.add(m)
 for d in deps[m]:visit(d)
 ordered.append(m)
visit(sys.argv[1]);imports=[];bodies=[]
for m in ordered:
 lines=[]
 for l in files[m].read_text().splitlines():
  v=pat.match(l)
  if v:
   if v[1] not in seen and v[1] not in imports:imports.append(v[1])
  else:lines.append(l)
 bodies.append('\n'.join(lines))
s='\n'.join('import '+m for m in imports)+'\n'+'\n'.join(bodies)+'\n'+sys.argv[3]+'\n'
out=Path(sys.argv[2]);out.write_text(s);out.with_name(out.stem+'-inputs.json').write_text(json.dumps({str(files[m].relative_to(root)):hashlib.sha256(files[m].read_bytes()).hexdigest() for m in ordered},indent=2)+'\n');print(json.dumps({'combined_sources':len(ordered),'bytes':len(s),'external_imports':len(imports),'output':str(out)}))
