import StockTryOutgoingColumns
import StockTryNormalNumbers
import StockTryFinalReturnValues
namespace Backend.Stock.Proof.TryNormalWholeVectorsDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open TryOutgoingOriginDraft TryOutgoingColumnsDraft TryNormalNumbersDraft SourceIndexWholeDraft
open TryBranchAbiDraft TrySourceContextDraft TryBranchSelectionDraft TryRetsTotalDraft TryResultMapDraft TryFinalReturnValuesDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private theorem isTryOfTable {term : Clif.Terminator} {et : Clif.ExnTable}
    (kind : sourceTable term = some et) : IsTryWith term et := by
  cases shape : term <;> simp only [sourceTable,shape] at kind
  all_goals try contradiction
  case tryCall fn args table => cases kind; exact .inl ⟨fn,args,rfl⟩
  case tryCallIndirect callee args table => cases kind; exact .inr ⟨callee,args,rfl⟩
/-- ORIGINAL whole lowering supplies the SAME real selected call helper and
actual collected normal successor vector. Canonical slot agreement, mapped
.val operands, .ret bounds/registers and final alias resolution are derived;
no extra caller layout, selected helper, state or outgoing-vector certificate. -/
theorem stock_lower_try_normal_outgoing_numbers {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f) (input : Prg.iselInB f = true)
    {label bi : Nat} {b : Clif.Block} (node : result.order.nodes[label]? = some (.original bi))
    (block : f.blocks[bi]? = some b) {et : Clif.ExnTable} {sig : Clif.Signature} {items : List (Option Nat)}
    (kind : sourceTable b.term = some et) (table : exnTableOpnd f et = .ok (sig,items))
    {targetLabel targetBi : Nat}
    (successor : result.order.successors[label]![et.handlers.length]? = some targetLabel)
    (target : result.order.nodes[targetLabel]? = some (.original targetBi)) :
    ∃ (source : TryBranchSource f result label bi b) (_selected : TryBranchSelection source)
      (base : Nat) (before : State) (value : V) (after edgeInput edgeNext : State) (args : Array Reg),
      result.initial.tryRegs[source.ti]! = (reservedReturns base sig.returns.length,reservedPayloads base sig.returns.length) ∧
      Stock.externCtor source.ctx T.gen_try_call_rets [.op (.sig sig)] before = .ok (value,after) ∧
      value = .op (.callRets (callDefs (resultDefs base sig.returns.length))) ∧
      branchArgs result.ctx edgeInput bi et.handlers.length = .ok (args,edgeNext) ∧
      args.map (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1)) =
        ((normalArgumentNumbers result base et).map (fun n => Reg.vreg n .int)).toArray ∧
      (result.edgeArgs[label]?.bind fun row => row[et.handlers.length]?) = some
        ((normalArgumentNumbers result base et).map (fun n => Reg.vreg n .int)).toArray := by
  obtain ⟨source,selected,base,before,value,after,layout,helper,defs,values⟩ :=
    stock_lower_original_try_actual_result_values lowered scope input node block kind table
  obtain ⟨ranges,starting,finishing,row,build,collect,metadata,reservations,stored⟩ :=
    stock_lower_original_outgoing_tables lowered node
  obtain ⟨args,edgeInput,edgeNext,present,call,edgeMetadata,edgeReservations⟩ :=
    stock_collectOutgoing_original_column build metadata reservations collect successor target
  have mapped := buildCtx_mappedInv scope build
  have slots : edgeInput.tryRegs[(edgeInput.instBlock.findIdx? (· == bi)).getD 0+b.body.length]! =
      (reservedReturns base sig.returns.length,reservedPayloads base sig.returns.length) := by
    rw [edgeMetadata,stock_buildCtx_instBlock_find build block,Option.getD_some,edgeReservations]
    simpa only [source.index] using layout
  have numbers := stock_branchArgs_try_normal_numbers mapped block (isTryOfTable kind) call base sig.returns.length slots
  refine ⟨source,selected,base,before,value,after,edgeInput,edgeNext,args,layout,helper,defs,call,numbers,?_⟩
  simp only [stored,Option.bind_some,Array.getElem?_map,present,Option.map_some,numbers]
end Backend.Stock.Proof.TryNormalWholeVectorsDraft
