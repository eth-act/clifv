from pathlib import Path
import json,hashlib,re,datetime,tarfile,shutil
root=Path('/home/lee/clifv/.worktrees/driver-proof-resume');docs=root/'docs/research'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
now=datetime.datetime.now(datetime.timezone.utc);stamp=now.strftime('%Y%m%dT%H%M%SZ')
batch=json.loads(Path('/tmp/stock-try-normal-vector-batch.json').read_text());old=json.loads((docs/'stock-source-index-scratch.json').read_text())
log=Path('/tmp/stock-try-normal-vector-combined-axioms.log').read_text()
sets={m.group(1):sorted(x.strip() for x in m.group(2).split(',') if x.strip()) for m in re.finditer(r"'([^']+)' depends on axioms:\s*\[([^]]*)\]",log)}
for m in re.finditer(r"'([^']+)' does not depend on any axioms",log):sets[m.group(1)]=[]
for n,a in old['normal_audit']['sets'].items():assert sorted(a)==sets[n],n
assert len(sets)==len(old['normal_audit']['sets'])+len(batch['public_roots'])+len(batch['models'])
allowed={'propext','Classical.choice','Quot.sound'}
for n in batch['public_roots']+batch['models']:assert set(sets[n])<=allowed,n
constants=[json.loads(line.split('DELIVERY_CONSTANT ',1)[1]) for line in Path('/tmp/stock-try-normal-vector-all-constants.log').read_text().splitlines() if line.startswith('DELIVERY_CONSTANT ')]
assert constants
for n,a in constants:assert set(a)<=allowed,n
mods={}
for m in batch['modules']:
 p=Path('/tmp')/m;check=json.loads(p.with_suffix('.check.json').read_text());assert check['actual_exit']==0
 rec={}
 for key,ext in [('source','.lean'),('object','.olean'),('log','.log'),('check','.check.json')]:
  f=p.with_suffix(ext);rec[key]=str(f);rec[key+'_sha256']=sha(f)
 for k in ['source','object','log']:assert rec[k+'_sha256']==check[k+'_sha256']
 assert not re.search(r'\b(sorry|admit|axiom|trace_state|native_decide)\b',p.with_suffix('.lean').read_text()),m
 mods[m]=rec
for audit in ['stock-try-normal-vector-combined-axioms','stock-try-normal-vector-all-constants']:
 p=Path('/tmp')/audit;check=json.loads(p.with_suffix('.check.json').read_text());assert check['actual_exit']==0
 for k,ext in [('source','.lean'),('object','.olean'),('log','.log')]:assert sha(p.with_suffix(ext))==check[k+'_sha256']
prior={}
for name in ['source-execution-x','try-source','try-context','try-rule','try-rets','try-reservation','try-outgoing','try-values','try-emitted','try-machine','try-got','try-indirect','try-rename','try-resolved','try-gap','try-got-rename','try-normal-frame','try-metadata','source-index']:
 d=json.loads((docs/f'stock-{name}-scratch.json').read_text())
 for m,rec in d['modules'].items():
  for k in ['source','object','log']:assert sha(rec[k])==rec[k+'_sha256'],(m,k)
  prior[m]=rec
freeze=json.loads(Path('/tmp/stock-coherent-build-inputs.json').read_text())
for group in ['source_sha256','validation_script_sha256']:
 for p,h in freeze[group].items():assert sha(root/p)==h,p
progress=json.loads(Path('/tmp/stock-pr246-gates-progress.json').read_text());progress.pop('completed_phases',None)
remaining=old['remaining_checklist']
remaining.append({'requirement':'Actual normal TryCall outgoing .val/.ret register vector tied to SAME selected helper and returned Result.edgeArgs column','state':'Proved for normal successors that are actual original nodes, using original lowering/scope/input/case data. Actual whole original-core collection occurs with initial metadata/reservations; every earlier successor collection retains those tables. SAME selected actual branchArgs run produces exact .val mappings/.ret lookups, excludes .exn/missing returns, and final resolution matches source/return numeric model. Actual selected RHS gen_try_call_rets, its exact defs and actual stored normal Result.edgeArgs column share an internally derived canonical base. Complete near/GOT/indirect mixed two-element columns and nine-argGOT16byte actual one-return column compiler/prepare/fallback/checker/physical/source17 witnesses pass. Actual synthetic TryCall normal-column composition/witness, machine live-source/reserved-write frame, normal argument VALUE transfer/parameter copies/source continuation and whole simulation/completeness remain open.'})
counts={'modules':len(mods),'public_roots':len(batch['public_roots']),'models':len(batch['models']),'combined_roots_models':len(sets),'previous_preserved':len(old['normal_audit']['sets']),'all_new_module_constants':len(constants),'previous_modules_hashes_preserved':len(prior)}
receipt={'utc':now.isoformat(),'goal':'Original full #140 ACTIVE/INCOMPLETE; production LEGACY','scope':'Scratch-only additive Stock proofs, not coherent integration or merge-ready','delivery_target':'roughly eight substantive validated squash merges/day; prioritize landing coherent backlog, remote backups and cleanup; drafts do not count','modules':mods,'public_roots':batch['public_roots'],'models':batch['models'],'counts':counts,'normal_audit':{'path':'/tmp/stock-try-normal-vector-combined-axioms.log','sha256':sha('/tmp/stock-try-normal-vector-combined-axioms.log'),'sets':sets},'all_constant_audit':{'path':'/tmp/stock-try-normal-vector-all-constants.log','sha256':sha('/tmp/stock-try-normal-vector-all-constants.log'),'all_standard_only':True,'count':len(constants)},'previous_modules_hashes_preserved':list(prior),'canonical2246_source_and_script_freeze_preserved':True,'kernel_resources':'All new modules and both audits actual exit0/object verified at8GiB through memcap; one heavy delivery worker retained','MCP':'No new calls; bundled audit deferred until coherent integration','active_exact_PR246_validation':progress,'remaining_checklist':remaining}
(docs/'stock-try-normal-vector-scratch.json').write_text(json.dumps(receipt,indent=2)+'\n')
text=f'''Actual TryCall normal outgoing vectors and selected call reservation — {now.isoformat()}

Seven scratch modules/seven public roots/three semantic models pass actual8GiB kernel checks. The {len(sets)}-root/model audit preserves all613prior exact axiom sets. All{len(constants)}new-module constants including private collector/control/loop/state/fixture helpers use only standard axioms. All{len(prior)}previous scratch source/object/log hashes and frozen2246canonical sources plus49validation scripts remain unchanged. Prior turn PROGRESS: original all-block sourceMetadata labels/first-match/canonical reservation queries, complete three-form/nonidentity critical witnesses,613audit/188constants, verifiedda857e5 backup and2.8GBcleanup.

Successful ACTUAL branchArgs at normal index=handler count yields the exact original .val mappings and reserved .ret lookups. Missing source/return registers and .exn cannot be hidden in a successful receipt. Under internally derived reserved layout and mapped context, real final alias resolution equals the explicit normalArgumentNumbers model, including resolved base+i for each return. The Option-reader model normalReg? is audited with its full identifier (the inventory handles punctuation), alongside raw/resolved numeric models.

The SAME actual original-node core collector sees initial instBlock and reservation tables after real branch emission. Its SAME row survives node installation, full traversal and final resolution into Result.edgeArgs. Every earlier outgoing successor collection preserves those tables, so selected-column extraction returns the ACTUAL branchArgs intermediate state and exact row entry. It does not replay a separately chosen helper. The whole original-source consumer constructs the SAME selected branch, actual intermediate gen_try_call_rets and exact result defs internally; its canonical initial slot supplies the base/layout used by this actual collected normal .val/.ret column. Original lowering/scope/input and CFG case facts suffice. No accepted layout/state/alias/selected-helper/outgoing-vector certificate is introduced.

Complete near/GOT/true-indirect compiler→prepareAt→forced checkedfallback→checker→physical witnesses connect actual RHS helper/defs, real branchArgs vector and actual returned normal Result.edgeArgs column, after the handler column has already been collected. All three exercise MIXED two-element .ret/.val columns and full source run17. Complete nine-argument GOT16byte pipeline exercises its ACTUAL one-element .ret normal column and full nine-argument source run17; its existing table has no .val normal argument, so that witness preserves the real fixture rather than changing it. Existing cached compiler/physical witnesses reused; no cold heavy build/new warm cache.

These are actual outgoing REGISTER-VECTOR proofs, not machine argument VALUE preservation or complete source/edge simulation. Next: prove live original-source/reserved-write machine noninterference, combine actual renamed call returned values with inherited .val values, execute real normal parameter copies/source continuation, and cover actual synthetic TryCall normal-column composition with a complete Try-critical witness. Existing ordinary critical metadata witness does not substitute for that Try-specific case. Existing actual final-renamed direct/GOT/indirect branch/world/result and source-side definedness proofs remain unchanged.

ALL original exact shared payload endpoints/exception machine semantics, full zero-return/sret/x8/width/handler/Try-critical matrix, uncovered families/effects/sinking/source/block/whole-driver simulation AND completeness, original-input context/visitor/static/checker/fallback/physical totality, coherent scratch integration/MCP/public/private/compiler audits, full/crates/runtime/encoder/BOTH E2E identity-stage parity, actual production compiler/checker/linker/generated consumers and FRESH COMPLETE comparison remain mandatory. Full#140 ACTIVE/INCOMPLETE; production LEGACY. Shared S10 interfaces remain @kevaundray #232/#233.

Main0ec59a028dd3a27911cb22554b3e292b20a5c45f unchanged. Delivery246/247 remain drafts; same live3247835/exclusive shared warm-cache lease and deliberately held canonical1233457. Preserve old-head receipts, reconcile latest main and rerun all required actual-head gates before dependent squash merges. Target roughly8substantive validated merges/day, semantic grouping, remote backups and cleanup. No new worktree/MCP/heavy retry/gate restart/merge this batch.

Hashed evidence/full remaining checklist: stock-try-normal-vector-scratch.json.
'''
(docs/'stock-try-normal-vector-scratch.md').write_text(text)
plan=root/'docs/plans/test-binary-alignment-recovery.md';plan.write_text(plan.read_text()+'\n\n'+text)
files=[]
for rec in mods.values():files.extend(Path(rec[k]) for k in ['source','object','log','check'])
for name in ['stock-try-normal-vector-combined-axioms','stock-try-normal-vector-all-constants']:
 for ext in ['.lean','.log','.olean','.check.json']:files.append(Path('/tmp')/(name+ext))
files.extend(Path(p) for p in ['/tmp/stock-try-normal-vector-batch.json','/tmp/stock-try-rule-inputs.json','/tmp/stock-try-reservation-check.py','/tmp/stock-try-normal-vector-close.py','/tmp/stock-try-normal-vector-make-audit.py','/tmp/stock-try-normal-vector-extra-inputs.py','/tmp/stock-try-normal-vector-status44.json','/tmp/stock-try-normal-vector-status52.json','/tmp/stock-try-normal-vector-status71.json','/tmp/stock-try-normal-vector-task140.json'])
files.extend([docs/'stock-try-normal-vector-scratch.json',docs/'stock-try-normal-vector-scratch.md',docs/'stock-delivery-main-drift.json',plan])
archive=Path('/home/lee/.clifv-recovery')/(stamp+'-try-normal-vector')/'checkpoint.tar.gz';archive.parent.mkdir(parents=True)
with tarfile.open(archive,'w:gz',compresslevel=1) as t:
 for p in files:t.add(p,arcname=str(p).lstrip('/'),recursive=False)
with tarfile.open(archive,'r:gz') as t:
 for p in files:assert t.extractfile(str(p).lstrip('/')).read()==p.read_bytes(),p
snapshot=Path('/tmp/stock-try-rule-inputs');size=sum(p.stat().st_size for p in snapshot.rglob('*') if p.is_file());shutil.rmtree(snapshot)
backup={'utc':now.isoformat(),'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(files),'all_members_byte_verified':True,'previous_remote_backup':json.loads((docs/'stock-source-index-backup.json').read_text())['remote'],'cleanup':{'duplicate_dependency_snapshot_removed':True,'bytes_reclaimed':size,'unique_sources_objects_logs_checks_audits_preserved':True,'one_shared_warm_cache_retained':True,'other_projects_touched':False,'free_bytes':shutil.disk_usage(root).free}}
(docs/'stock-try-normal-vector-backup.json').write_text(json.dumps(backup,indent=2)+'\n');Path('/tmp/stock-try-normal-vector-archive-path').write_text(str(archive))
print(json.dumps({'counts':counts,'archive':str(archive),'cleanup':backup['cleanup'],'gate':progress},indent=2))
