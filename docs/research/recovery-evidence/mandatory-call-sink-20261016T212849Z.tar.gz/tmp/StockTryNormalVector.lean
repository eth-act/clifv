import StockSourceIndexWhole
import StockTryRetsTotal
import FV.Backend.Proof.StockSelectedArguments
namespace Backend.Stock.Proof.TryNormalVectorDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64 TryRetsTotalDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
/-- The actual normal edge reads source mappings or reserved returns.
Exception payloads are unavailable on a successful normal edge. -/
def normalReg? (ctx : Ctx) (rets : List Reg) : Clif.TryArg → Option Reg
  | .val x => ctx.valueReg? x
  | .ret i => rets[i]?
  | .exn _ => none
private def argStep (ctx : Ctx) (rets pays : List Reg) (index nh : Nat)
    (arg : Clif.TryArg) (acc : State × Array Reg) : Except String (ForInStep (State × Array Reg)) := do
  match arg with
  | .val v =>
    let some r := ctx.valueReg? v | throw s!"unknown value v{v}"
    pure (.yield (acc.1.mark v,acc.2.push r))
  | .ret i =>
    if index < nh then throw "try_call return on exception edge"
    let some r := rets[i]? | throw "try_call return index"
    pure (.yield (acc.1,acc.2.push r))
  | .exn i =>
    if index == nh then throw "try_call payload on normal edge"
    let some r := pays[i]? | throw "try_call payload index"
    pure (.yield (acc.1,acc.2.push r))
private theorem normal_loop {ctx : Ctx} {rets pays : List Reg} {nh : Nat} {xs : List Clif.TryArg}
    {st next : State} {before after : Array Reg}
    (run : forIn xs (st,before) (argStep ctx rets pays nh nh) = .ok (next,after)) :
    ∃ rs,xs.mapM (normalReg? ctx rets) = some rs ∧ after = before ++ rs.toArray := by
  induction xs generalizing st before with
  | nil =>
    simp only [List.forIn_nil,pure,Except.pure] at run
    cases run
    exact ⟨[],rfl,by simp⟩
  | cons a xs ih =>
    have extend {r : Reg} {state : State} (lookup : normalReg? ctx rets a = some r)
        (rest : forIn xs (state,before.push r) (argStep ctx rets pays nh nh) = .ok (next,after)) :
        ∃ rs,(a :: xs).mapM (normalReg? ctx rets) = some rs ∧ after = before ++ rs.toArray := by
      obtain ⟨rs,mapped,code⟩ := ih rest
      refine ⟨r :: rs,?_,?_⟩
      · simp only [List.mapM_cons,lookup,mapped]; rfl
      · rw [code]
        apply Array.toList_inj.mp
        simp [Array.toList_push,List.append_assoc]
    cases a with
    | val x =>
      simp only [List.forIn_cons,argStep] at run
      cases lookup : ctx.valueReg? x with
      | none => simp only [lookup,bind,Except.bind] at run; cases run
      | some r =>
        simp only [lookup,bind,Except.bind,pure,Except.pure] at run
        exact extend lookup run
    | ret i =>
      simp only [List.forIn_cons,argStep,Nat.lt_irrefl,ite_false] at run
      cases lookup : rets[i]? with
      | none => simp only [lookup,bind,Except.bind] at run; cases run
      | some r =>
        simp only [lookup,bind,Except.bind,pure,Except.pure] at run
        exact extend lookup run
    | exn i => simp [List.forIn_cons,argStep] at run
/-- Actual successful normal branchArgs yields its EXACT .val/.ret vector;
failed/missing returns and .exn arguments cannot be hidden by the receipt. -/
theorem stock_branchArgs_try_normal_regs {f : Clif.Function} {ctx : Ctx} (func : ctx.func = f)
    {bi : Nat} {b : Clif.Block} (block : f.blocks[bi]? = some b) {et : Clif.ExnTable}
    (kind : IsTryWith b.term et) {input next : State} {args : Array Reg}
    (call : branchArgs ctx input bi et.handlers.length = .ok (args,next)) :
    et.normal.args.mapM (normalReg? ctx (input.tryRegs[
      (input.instBlock.findIdx? (· == bi)).getD 0+b.body.length]!).1) = some args.toList := by
  have source : ctx.func.blocks[bi]! = b := by simp only [func,getElem!_def,block]
  have selected : (destinations b.term)[et.handlers.length]? = some (et.normal.block,et.normal.args) := by
    rcases kind with ⟨fn,as,term⟩ | ⟨callee,as,term⟩ <;> rw [term] <;>
      simp [destinations,Clif.ExnTable.dests,List.getElem?_append_right]
  have count : (match b.term with | .tryCall _ _ et | .tryCallIndirect _ _ et => et.handlers.length | _ => 0) = et.handlers.length := by
    rcases kind with ⟨fn,as,term⟩ | ⟨callee,as,term⟩ <;> rw [term]
  unfold branchArgs at call
  rw [source] at call
  dsimp only at call
  rw [selected] at call
  dsimp only at call
  split at call
  · split at call
    · cases call
    · let ti := (input.instBlock.findIdx? (· == bi)).getD 0+b.body.length
      let reserved := input.tryRegs[ti]!
      change (do
        let result ← forIn et.normal.args (input,#[]) (argStep ctx reserved.1 reserved.2 et.handlers.length
          (match b.term with | .tryCall _ _ et | .tryCallIndirect _ _ et => et.handlers.length | _ => 0))
        pure (result.2,result.1)) = .ok (args,next) at call
      rw [count] at call
      obtain ⟨⟨state,registers⟩,loop,done⟩ := Except.bind_ok call
      cases done
      obtain ⟨rs,mapped,vector⟩ := normal_loop loop
      simpa only [vector,Array.empty_append,List.toList_toArray] using mapped
  · cases call
end Backend.Stock.Proof.TryNormalVectorDraft
