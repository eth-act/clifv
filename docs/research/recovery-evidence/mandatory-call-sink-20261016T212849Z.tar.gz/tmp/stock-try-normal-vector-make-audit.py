from pathlib import Path
import re,json
mods=['StockTryNormalVector','StockTryNormalNumbers','StockTryOutgoingOrigin','StockTryOutgoingColumns','StockTryNormalWholeVectors','StockTryNormalVectorWitness','StockTryNormalVectorStackWitness'];roots=[];models=[]
for m in mods:
 s=Path('/tmp',m+'.lean').read_text();ns=re.search(r'^namespace (\S+)',s,re.M).group(1)
 roots.extend(ns+'.'+x for x in re.findall(r'^theorem (\w+)',s,re.M));models.extend(ns+'.'+x for x in re.findall(r'^(?:def|abbrev) ([A-Za-z_][A-Za-z_0-9!?]*)',s,re.M))
batch={'modules':mods,'public_roots':roots,'models':models};Path('/tmp/stock-try-normal-vector-batch.json').write_text(json.dumps(batch,indent=2)+'\n')
imports=''.join('import '+m+'\n' for m in mods)
Path('/tmp/stock-try-normal-vector-combined-axioms.lean').write_text(imports+Path('/tmp/stock-source-index-combined-axioms.lean').read_text()+'\n'+''.join('#print axioms '+n+'\n' for n in roots+models))
old=Path('/tmp/stock-source-index-all-constants.lean').read_text();tail=old[old.index('open Lean'):];tail=re.sub(r'let targets : Array String := #\[.*?\]', 'let targets : Array String := #['+', '.join(json.dumps(m) for m in mods)+' ]',tail)
Path('/tmp/stock-try-normal-vector-all-constants.lean').write_text('import Lean\n'+imports+tail)
