import StockTryNormalVector
namespace Backend.Stock.Proof.TryNormalNumbersDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64 TryRetsTotalDraft TryNormalVectorDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
/-- Source values use the actual dense source map; returns use the SAME
reserved return prefix as the call. Successful normal collection excludes .exn. -/
def normalArgNum (ctx : Ctx) (base : Nat) : Clif.TryArg → Nat
  | .val x => edgeValueNum ctx x
  | .ret i => base+i
  | .exn _ => 0
def normalArgumentNumbers (result : Result) (base : Nat) (et : Clif.ExnTable) : List Nat :=
  et.normal.args.map (fun arg => aliasNum result.final.alias (normalArgNum result.ctx base arg))
private theorem mapped_numbers {f : Clif.Function} {ctx : Ctx} (mapped : MappedCtxInv f ctx) (base count : Nat) :
    ∀ {xs : List Clif.TryArg} {rs : List Reg},xs.mapM (normalReg? ctx (reservedReturns base count)) = some rs →
      rs = xs.map (fun arg => Reg.vreg (normalArgNum ctx base arg) .int)
  | [],rs,mapping => by simp at mapping; subst rs; rfl
  | a :: xs,rs,mapping => by
    simp only [List.mapM_cons,Option.bind_eq_bind,Option.bind_eq_some_iff,Option.pure_def,Option.some.injEq] at mapping
    obtain ⟨r,lookup,tail,rest,rfl⟩ := mapping
    rw [mapped_numbers mapped base count rest]
    cases a with
    | val x =>
      obtain ⟨n,rfl⟩ := mapped.valueReg x r lookup
      simp only [List.map_cons,normalArgNum,edgeValueNum,show ctx.valueReg? x = some (.vreg n .int) from lookup]
    | ret i =>
      have bound : i < count := by
        have inside := (List.getElem?_eq_some_iff.mp lookup).1
        simpa only [reservedReturns,List.length_map,List.length_range] using inside
      have actual : (reservedReturns base count)[i]? = some (.vreg (base+i) .int) := by simp [reservedReturns,bound]
      have equal := Option.some.inj (actual.symm.trans lookup)
      subst r
      rfl
    | exn i => cases lookup
/-- Internal actual-collector composition: its source map and reserved layout
identify the exact final-resolved .val/.ret numbers. Whole-driver consumers
below derive these helpers/layouts from original inputs and the real run. -/
theorem stock_branchArgs_try_normal_numbers {f : Clif.Function} {result : Result}
    (mapped : MappedCtxInv f result.ctx) {bi : Nat} {b : Clif.Block} (block : f.blocks[bi]? = some b)
    {et : Clif.ExnTable} (kind : IsTryWith b.term et) {input next : State} {args : Array Reg}
    (call : branchArgs result.ctx input bi et.handlers.length = .ok (args,next)) (base count : Nat)
    (slots : input.tryRegs[(input.instBlock.findIdx? (· == bi)).getD 0+b.body.length]! =
      (reservedReturns base count,reservedPayloads base count)) :
    args.map (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1)) =
      ((normalArgumentNumbers result base et).map (fun n => Reg.vreg n .int)).toArray := by
  have mapping := stock_branchArgs_try_normal_regs mapped.func block kind call
  rw [slots] at mapping
  have numbers := mapped_numbers mapped base count mapping
  apply Array.toList_inj.mp
  simp [numbers,normalArgumentNumbers,List.map_map,Function.comp_def,resolve_vreg,aliasNum]
end Backend.Stock.Proof.TryNormalNumbersDraft
