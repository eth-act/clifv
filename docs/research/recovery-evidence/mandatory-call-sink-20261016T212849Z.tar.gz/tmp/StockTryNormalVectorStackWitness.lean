import StockTryNormalWholeVectors
import StockTryStackFixture
namespace Backend.Stock.Proof.TryNormalVectorStackWitnessDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open TryNormalWholeVectorsDraft TryNormalNumbersDraft TrySourceContextDraft TryBranchSelectionDraft TryBranchAbiDraft
open TryRetsTotalDraft TryResultMapDraft TryStackFixtureDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private def f := TryStackSourceDraft.function
private def entry := f.blocks[0]!
private def table := TryStackSourceDraft.table
private def environment : Clif.Env := {
  extern := fun _ => some (fun _ cm => .returned [⟨.i64,17⟩] cm),names := ["callee"],sigOf := fun _ => some f.sig }
private def sourceValues : List Clif.Val := List.replicate 9 ⟨.i64,0⟩
/-- COMPLETE nine-argument GOT pipeline, real sixteen-byte outgoing area and
actual returned .ret normal column tied to its real helper.
The original source program also executes all nine arguments and returns17. -/
theorem stock_complete_nine_argument_normal_outgoing_vector_witness :
    ∃ (out : TryStackFixtureDraft.Output) (source : TryBranchSource f out.result 0 0 entry)
      (_selected : TryBranchSelection source) (base : Nat) (before : State) (value : V)
      (after edgeInput edgeNext : State) (args : Array Reg),
      LowerScope f ∧ Dominated f ∧ ArityOk f ∧
      Stock.lower f = .ok out.result ∧ prepareAt out.result.code out.result.edgeArgs = .ok out.prepared ∧
      out.rf = spillAllocAt out.prepared.code out.prepared.edges ∧
      checkAllocAt out.prepared.code out.prepared.edges out.rf = .ok () ∧ lowerRFunc out.prepared.code out.rf = .ok out.af ∧
      out.result.initial.tryRegs[source.ti]! = (reservedReturns base f.sig.returns.length,reservedPayloads base f.sig.returns.length) ∧
      Stock.externCtor source.ctx T.gen_try_call_rets [.op (.sig f.sig)] before = .ok (value,after) ∧
      value = .op (.callRets (callDefs (resultDefs base f.sig.returns.length))) ∧
      branchArgs out.result.ctx edgeInput 0 table.handlers.length = .ok (args,edgeNext) ∧
      args.map (Backend.lowerFunction.resolve out.result.final.alias (out.result.final.alias.size+1)) =
        ((normalArgumentNumbers out.result base table).map (fun n => Reg.vreg n .int)).toArray ∧
      (out.result.edgeArgs[0]?.bind fun row => row[table.handlers.length]?) = some
        ((normalArgumentNumbers out.result base table).map (fun n => Reg.vreg n .int)).toArray ∧
      (normalArgumentNumbers out.result base table).length = 1 ∧
      out.result.code.outgoing = 16 ∧ f.sig.params.length = 9 ∧
      Clif.runWith environment {funcs := [f]} f.name sourceValues Clif.Mem.empty 6 = .returned [⟨.i64,17⟩] Clif.Mem.empty := by
  obtain ⟨out⟩ := stock_nine_argument_try_fixture
  have order : blockOrder f = .ok {nodes := #[.original 0,.original 1,.original 2],successors := #[#[2,1],#[],#[]]} := by cbv
  have sameOrder := Except.ok.inj ((stock_lower_order out.lowered).symm.trans order)
  have node : out.result.order.nodes[0]? = some (.original 0) := by rw [sameOrder]; rfl
  have successor : out.result.order.successors[0]![table.handlers.length]? = some 1 := by rw [sameOrder]; rfl
  have target : out.result.order.nodes[1]? = some (.original 1) := by rw [sameOrder]; rfl
  have block : f.blocks[0]? = some entry := rfl
  have input : Prg.iselInB f = true := by decide +kernel
  have kind : sourceTable entry.term = some table := rfl
  have decoded : exnTableOpnd f table = .ok (f.sig,[some 7]) := rfl
  obtain ⟨source,selected,base,before,value,after,edgeInput,edgeNext,args,layout,helper,defs,call,numbers,stored⟩ :=
    stock_lower_try_normal_outgoing_numbers out.lowered out.scope input node block kind decoded successor target
  refine ⟨out,source,selected,base,before,value,after,edgeInput,edgeNext,args,out.scope,out.dominated,out.arity,
    out.lowered,out.prepare,out.fallback,out.accepted,out.physical,layout,helper,defs,call,numbers,stored,rfl,out.outgoing,rfl,?_⟩
  rfl
end Backend.Stock.Proof.TryNormalVectorStackWitnessDraft
