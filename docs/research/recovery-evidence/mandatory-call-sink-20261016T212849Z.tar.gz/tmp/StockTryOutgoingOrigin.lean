import StockSourceIndexWhole
import FV.Backend.Proof.StockOutgoingOrigin
namespace Backend.Stock.Proof.TryOutgoingOriginDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open TryIndexFrameDraft TryIndexControlDraft SourceIndexWholeDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
attribute [local irreducible] Stock.runTerm lowerBlockCore branchArgs emitBranch collectOutgoing scanBlock
private theorem node_install {ctx : Ctx} {ranges : Array (Nat × Nat)} {order : Order}
    {f : Clif.Function} {params : List Nat} {label : Nat} {input output : DriverState}
    (run : lowerNode ctx ranges order f params label input = .ok output) :
    ∃ block, output.edgeArgs = input.edgeArgs.set! label block := by
  unfold lowerNode at run
  dsimp only at run
  repeat' first
    | (solve | cases run)
    | simp only [bind, Except.bind, pure, Except.pure] at run
    | split at run
  all_goals
    cases run
    exact ⟨_,rfl⟩

private theorem node_size {ctx : Ctx} {ranges : Array (Nat × Nat)} {order : Order}
    {f : Clif.Function} {params : List Nat} {label : Nat} {input output : DriverState}
    (run : lowerNode ctx ranges order f params label input = .ok output) :
    output.edgeArgs.size = input.edgeArgs.size := by
  obtain ⟨block,installed⟩ := node_install run
  rw [installed]
  simp

private theorem node_frame {ctx : Ctx} {ranges : Array (Nat × Nat)} {order : Order}
    {f : Clif.Function} {params : List Nat} {label other : Nat} {input output : DriverState}
    (run : lowerNode ctx ranges order f params label input = .ok output) (different : other ≠ label) :
    output.edgeArgs[other]? = input.edgeArgs[other]? := by
  obtain ⟨block,installed⟩ := node_install run
  rw [installed]
  simp [Array.getElem?_setIfInBounds,Ne.symm different]

private theorem nodes_size {ctx : Ctx} {ranges : Array (Nat × Nat)} {order : Order}
    {f : Clif.Function} {params labels : List Nat} {input output : DriverState}
    (run : labels.foldlM (fun d k => lowerNode ctx ranges order f params k d) input = .ok output) :
    output.edgeArgs.size = input.edgeArgs.size := by
  induction labels generalizing input with
  | nil => cases run; rfl
  | cons label rest ih =>
    rw [List.foldlM_cons] at run
    cases call : lowerNode ctx ranges order f params label input with
    | error e => simp only [call,bind,Except.bind] at run; cases run
    | ok middle =>
      simp only [call,bind,Except.bind] at run
      exact (ih run).trans (node_size call)

private theorem nodes_frame {ctx : Ctx} {ranges : Array (Nat × Nat)} {order : Order}
    {f : Clif.Function} {params labels : List Nat} {other : Nat} {input output : DriverState}
    (run : labels.foldlM (fun d k => lowerNode ctx ranges order f params k d) input = .ok output)
    (different : ∀ k ∈ labels,other ≠ k) : output.edgeArgs[other]? = input.edgeArgs[other]? := by
  induction labels generalizing input with
  | nil => cases run; rfl
  | cons label rest ih =>
    rw [List.foldlM_cons] at run
    cases call : lowerNode ctx ranges order f params label input with
    | error e => simp only [call,bind,Except.bind] at run; cases run
    | ok middle =>
      simp only [call,bind,Except.bind] at run
      exact (ih run (fun k member => different k (List.mem_cons_of_mem _ member))).trans
        (node_frame call (different label (by simp)))

private def startDriver (initial : State) (n : Nat) : DriverState := {
  state := initial,blocks := Array.replicate n default,edgeArgs := Array.replicate n #[],
  schedule := #[],scans := #[],blockScans := #[],rules := #[] }

private theorem lower_code_origin {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) :
    ∃ (ranges : Array (Nat × Nat)) (params : List Nat) (driver : DriverState),
      Stock.buildCtx f = .ok (result.ctx,ranges,result.initial) ∧
      blockOrder f = .ok result.order ∧
      (Array.range result.order.nodes.size).reverse.toList.foldlM
        (fun d k => lowerNode result.ctx ranges result.order f params k d)
        (startDriver result.initial result.order.nodes.size) = .ok driver ∧
      result.blockScans = driver.blockScans ∧ result.final = driver.state ∧
      result.edgeArgs = driver.edgeArgs.map (fun args => args.map (fun rs =>
        rs.map (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1)))) := by
  unfold Stock.lower at run
  dsimp only at run
  repeat' first
    | (solve | cases run)
    | simp only [bind,Except.bind,pure,Except.pure] at run
    | split at run
  cases run
  exact ⟨_,_,_,by assumption,by assumption,by assumption,rfl,rfl,rfl⟩


private theorem node_origin {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) {label : Nat} (bound : label < result.order.nodes.size) :
    ∃ (ranges : Array (Nat × Nat)) (params : List Nat) (input output : DriverState),
      Stock.buildCtx f = .ok (result.ctx,ranges,result.initial) ∧
      input.state.instBlock = result.initial.instBlock ∧ input.state.tryRegs = result.initial.tryRegs ∧
      label < input.edgeArgs.size ∧
      lowerNode result.ctx ranges result.order f params label input = .ok output ∧
      result.edgeArgs[label]? = (output.edgeArgs[label]?).map (fun args => args.map (fun rs =>
        rs.map (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1)))) := by
  obtain ⟨ranges,params,driver,build,ordered,folded,events,final,vectors⟩ := lower_code_origin run
  have member : label ∈ (Array.range result.order.nodes.size).reverse.toList := by simpa using bound
  obtain ⟨earlier,suffix,parts,noEarlier⟩ := List.eq_append_cons_of_mem member
  rw [parts,List.foldlM_append] at folded
  cases first : earlier.foldlM (fun d k => lowerNode result.ctx ranges result.order f params k d)
      (startDriver result.initial result.order.nodes.size) with
  | error e => simp only [first,bind,Except.bind] at folded; cases folded
  | ok before =>
    simp only [first,bind,Except.bind] at folded
    rw [List.foldlM_cons] at folded
    cases step : lowerNode result.ctx ranges result.order f params label before with
    | error e => simp only [step,bind,Except.bind] at folded; cases folded
    | ok after =>
      simp only [step,bind,Except.bind] at folded
      have beforeBound : label < before.edgeArgs.size := by
        rw [nodes_size first]
        simpa only [startDriver,Array.size_replicate] using bound
      have finalVector : driver.edgeArgs[label]? = after.edgeArgs[label]? := by
        rw [nodes_frame folded]
        intro k member
        rw [(stock_backward_suffix_split parts).2] at member
        have small : k < label := by simpa using member
        omega
      have metadata : before.state.instBlock = result.initial.instBlock := stock_nodes_instBlock first
      have empty : result.initial.alias = #[] := by
        obtain ⟨original,st0,requests,oldBuild,requestRun,same⟩ := buildCtx_allocation build
        exact congrArg (fun q : Ctx × Array (Nat × Nat) × State => q.2.2.alias) same
      have allocation := stock_lowerNodes_allocationBounds build
        (input := startDriver result.initial result.order.nodes.size)
        ⟨by change result.initial.alias.size ≤ result.initial.base.nextVreg; rw [empty]; exact Nat.zero_le _,Nat.le_refl _,rfl⟩ first
      exact ⟨ranges,params,before,after,build,metadata,allocation.2.2,beforeBound,step,
        by simp only [vectors,Array.getElem?_map,finalVector]⟩


private theorem node_original_assembled {ctx : Ctx} {ranges : Array (Nat × Nat)} {order : Order}
    {f : Clif.Function} {params : List Nat} {label bi : Nat} {input output : DriverState}
    (run : lowerNode ctx ranges order f params label input = .ok output)
    (node : order.nodes[label]! = .original bi) :
    ∃ (data : Backend.V) (core : LoweredBlockCore) (block : VBlock),
      lowerBlockCore ctx order f f.blocks[bi]! bi ranges[bi]!.1 ranges[bi]!.2
        data order.successors[label]! input.state = .ok core ∧
      assembleOriginalBlock ctx f f.blocks[bi]! bi label order.successors[label]!
        core.outgoing params core.state.uses core.code = .ok block ∧
      output.edgeArgs = input.edgeArgs.set! label core.outgoing := by
  let fetchData : Except String Backend.V := match f.blocks[bi]!.term with
    | .tryCall .. | .tryCallIndirect .. => tryCallData f f.blocks[bi]!.term
    | _ => termData (abiTerm f f.blocks[bi]!.term)
  let reject : Bool := (match f.blocks[bi]!.term with | .ret .. => true | _ => false) &&
    (sretRet f).isEmpty && (sigRets f.sig != f.sig.returns)
  have normal : lowerNode ctx ranges order f params label input = (do
      let data ← fetchData
      if reject then throw "sret parameter is not an entry-block parameter"
      let core ← lowerBlockCore ctx order f f.blocks[bi]! bi ranges[bi]!.1 ranges[bi]!.2
        data order.successors[label]! input.state
      let block ← assembleOriginalBlock ctx f f.blocks[bi]! bi label order.successors[label]!
        core.outgoing params core.state.uses core.code
      pure { recordCore input core bi ranges[bi]!.2 with
        blocks := input.blocks.set! label block,
        edgeArgs := input.edgeArgs.set! label core.outgoing }) := by
    unfold lowerNode
    simp only [node]
    dsimp only [fetchData, reject]
    split <;> simp_all only [reject] <;> rfl
  rw [normal] at run
  cases dataRun : fetchData with
  | error e => simp only [dataRun, bind, Except.bind] at run; cases run
  | ok data =>
    simp only [dataRun, bind, Except.bind] at run
    split at run
    · cases run
    · cases coreRun : lowerBlockCore ctx order f f.blocks[bi]! bi ranges[bi]!.1 ranges[bi]!.2
        data order.successors[label]! input.state with
      | error e => simp only [coreRun] at run; cases run
      | ok core =>
        simp only [coreRun] at run
        cases assembled : assembleOriginalBlock ctx f f.blocks[bi]! bi label order.successors[label]!
          core.outgoing params core.state.uses core.code with
        | error e => simp only [assembled] at run; cases run
        | ok block =>
          simp only [assembled, pure, Except.pure] at run
          cases run
          exact ⟨data,core,block,coreRun,assembled,rfl⟩

/-- Actual original-node outgoing vectors come from its successful core,
with all per-successor vectors retained and finally alias-resolved. This
covers multi-successor branches without using legacy single-vector branchArgs. -/
private theorem named_alloc {ctx : Ctx} {term : String} {args : List V}
    {st next : State} {out : Option V} {trace : List RuleId}
    (h : Stock.runTerm ctx term args st = .ok (out, next, trace)) :
    AllocationLe st next := by
  unfold Stock.runTerm at h
  cases hr : Isle.Interp.run program (Stock.sem ctx) {} term args st with
  | error e => rw [hr] at h; cases h
  | ok result =>
    rw [hr] at h
    cases h
    unfold Isle.Interp.run at hr
    cases ht : program.termByName? term with
    | none => simp only [ht] at hr; cases hr
    | some t =>
      simp only [ht] at hr
      cases ha : (applyTerm program (Stock.sem ctx) {} (Config.fuel ({} : Config))
          t.ret t.id args).run (st, #[]) with
      | error e => simp only [ha, bind, Except.bind] at hr; cases hr
      | ok result =>
        rcases result with ⟨out, next, trace⟩
        simp only [ha, bind, Except.bind, pure, Except.pure] at hr
        cases hr
        exact stock_apply_allocationLe ha

private theorem emit_regs {ctx : Ctx} {f : Clif.Function} {term : Clif.Terminator}
    {bi ti : Nat} {targets : Array Nat} {input : State} {out : BranchEmission}
    (run : emitBranch ctx f term bi ti targets input = .ok out) : out.state.tryRegs = input.tryRegs := by
  unfold emitBranch at run
  dsimp only at run
  let before := {input with current := some ti,color := none,base.emitted := #[]}
  change ((do
    let (value,next,trace) ← Stock.runTerm ctx "lower_branch" [.inst ti,.labels targets.toList] before
    if value.isNone then throw s!"no lowering rule for terminator {repr term}"
    let code ← branchCode f term targets next.base.emitted
    pure ⟨next,code,⟨bi,ti,.emitted,before,next,[],trace,code⟩,trace⟩) : Except String BranchEmission) = .ok out at run
  cases root : Stock.runTerm ctx "lower_branch" [.inst ti,.labels targets.toList] before with
  | error err => simp only [root,bind,Except.bind] at run; cases run
  | ok result =>
    rcases result with ⟨value,next,trace⟩
    simp only [root,bind,Except.bind] at run
    split at run
    · cases run
    · cases code : branchCode f term targets next.base.emitted with
      | error err => simp only [code,bind,Except.bind] at run; cases run
      | ok instructions =>
        simp only [code,pure,Except.pure] at run
        cases run
        exact (named_alloc (st := before) root).2

private def finishCore (ctx localCtx : Ctx) (order : Order) (bi ti start stop : Nat)
    (isBranch : Bool) (targets : Array Nat) (input : State) (branch : Option BranchEmission) :
    Except String LoweredBlockCore := do
  let beforeEdges := branch.map (·.state) |>.getD input
  let (next,outgoing) ← collectOutgoing ctx order bi targets beforeEdges
  let beforeScan := {next with color := some next.endColor[bi]!}
  let indices := ((Array.range (stop-start)).map (start+·)).reverse.toList
  let bodyScan ← scanBlock localCtx bi ti isBranch indices beforeScan
  pure ⟨bodyScan.state,bodyScan.code ++ (branch.map (·.code) |>.getD #[]),outgoing,branch,
    ⟨localCtx,bi,ti,isBranch,indices,beforeScan,bodyScan⟩⟩
/-- Actual complete original block lowering retains the exact source metadata. -/
private theorem core_collection {ctx : Ctx} {order : Order} {f : Clif.Function} {b : Clif.Block}
    {bi start stop : Nat} {data : V} {targets : Array Nat} {input : State} {output : LoweredBlockCore}
    (run : lowerBlockCore ctx order f b bi start stop data targets input = .ok output) :
    ∃ before after,collectOutgoing ctx order bi targets before = .ok (after,output.outgoing) ∧
      before.instBlock = input.instBlock ∧ before.tryRegs = input.tryRegs := by
  let ti := stop-1
  let localCtx := {ctx with insts := ctx.insts.set! ti ⟨data,[],[],none⟩,tryRegs := input.tryRegs[ti]!}
  let flag : Bool := match b.term with | .ret .. | .trap .. | .returnCall .. => false | _ => true
  unfold lowerBlockCore at run
  change (do
    let branch ← if flag then some <$> emitBranch localCtx f b.term bi ti targets input else pure none
    finishCore ctx localCtx order bi ti start stop flag targets input branch) = .ok output at run
  have finish (branch : Option BranchEmission)
      (branchFrame : ((branch.map (·.state)).getD input).instBlock = input.instBlock ∧
        ((branch.map (·.state)).getD input).tryRegs = input.tryRegs)
      (rest : finishCore ctx localCtx order bi ti start stop flag targets input branch = .ok output) :
      ∃ before after,collectOutgoing ctx order bi targets before = .ok (after,output.outgoing) ∧
      before.instBlock = input.instBlock ∧ before.tryRegs = input.tryRegs := by
    unfold finishCore at rest
    obtain ⟨⟨next,outgoing⟩,collected,rest⟩ := Except.bind_ok rest
    obtain ⟨scan,scanned,rest⟩ := Except.bind_ok rest
    cases rest
    exact ⟨_,_,collected,branchFrame.1,branchFrame.2⟩
  cases hflag : flag with
  | false =>
    simp only [hflag,Bool.false_eq_true,ite_false,pure,Except.pure,bind,Except.bind] at run
    exact finish none ⟨rfl,rfl⟩ (by simpa only [hflag] using run)
  | true =>
    simp only [hflag,ite_true] at run
    cases call : emitBranch localCtx f b.term bi ti targets input with
    | error e => simp only [call,Except.map,bind,Except.bind] at run; cases run
    | ok emitted =>
      have mapped : some <$> (Except.ok emitted : Except String BranchEmission) = .ok (some emitted) := rfl
      rw [call,mapped] at run
      simp only [bind,Except.bind] at run
      exact finish (some emitted) ⟨stock_emitBranch_instBlock call,emit_regs call⟩ (by simpa only [hflag] using run)

/-- The actual complete original-node outgoing collector sees the initial
source/reservation tables; its SAME row is returned after final resolution. -/
theorem stock_lower_original_outgoing_tables {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) {label bi : Nat}
    (tag : result.order.nodes[label]? = some (.original bi)) :
    ∃ (ranges : Array (Nat × Nat)) (before after : State) (row : Array (Array Reg)),
      Stock.buildCtx f = .ok (result.ctx,ranges,result.initial) ∧
      collectOutgoing result.ctx result.order bi result.order.successors[label]! before = .ok (after,row) ∧
      before.instBlock = result.initial.instBlock ∧ before.tryRegs = result.initial.tryRegs ∧
      result.edgeArgs[label]? = some (row.map (fun args =>
        args.map (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1)))) := by
  obtain ⟨ranges,params,input,output,build,metadata,reservations,bound,nodeRun,stored⟩ :=
    node_origin run (Array.getElem?_eq_some_iff.mp tag).1
  have node : result.order.nodes[label]! = .original bi := by simp [getElem!_def,tag]
  obtain ⟨data,core,block,coreRun,assembled,installed⟩ := node_original_assembled nodeRun node
  obtain ⟨before,after,collect,coreMetadata,coreReservations⟩ := core_collection coreRun
  rw [installed,Array.set!_eq_setIfInBounds,Array.getElem?_setIfInBounds_self_of_lt bound] at stored
  exact ⟨ranges,before,after,core.outgoing,build,collect,coreMetadata.trans metadata,
    coreReservations.trans reservations,stored⟩
end Backend.Stock.Proof.TryOutgoingOriginDraft
