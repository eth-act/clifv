import StockTryOutgoingOrigin
import FV.Backend.Proof.StockBranchArgumentShape
namespace Backend.Stock.Proof.TryOutgoingColumnsDraft
open Backend.Proof Backend.Proof.Driver TryIndexControlDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private def Collected (ctx : Ctx) (order : Order) (bi : Nat) (initial : State) (item : Nat × Nat) (args : Array Reg) : Prop :=
  match order.nodes[item.1]! with
  | .edge .. => args = #[]
  | .original _ => ∃ before after,branchArgs ctx before bi item.2 = .ok (args,after) ∧
      before.instBlock = initial.instBlock ∧ before.tryRegs = initial.tryRegs
private theorem outgoing_vector {f : Clif.Function} {ctx : Ctx} {ranges : Array (Nat × Nat)} {initial : State}
    (build : Stock.buildCtx f = .ok (ctx,ranges,initial)) {order : Order} {bi : Nat}
    {before after : State × Array (Array Reg)} {item : Nat × Nat}
    (metadata : before.1.instBlock = initial.instBlock) (reservations : before.1.tryRegs = initial.tryRegs)
    (run : outgoingStep ctx order bi before item = .ok after) :
    after.1.instBlock = initial.instBlock ∧ after.1.tryRegs = initial.tryRegs ∧
    ∃ args,after.2 = before.2.push args ∧ Collected ctx order bi initial item args := by
  unfold outgoingStep at run
  cases tag : order.nodes[item.1]! with
  | edge pred index target =>
    simp only [tag,pure,Except.pure,Except.ok.injEq] at run
    subst after
    exact ⟨metadata,reservations,#[],rfl,by simp [Collected,tag]⟩
  | original target =>
    simp only [tag] at run
    cases call : branchArgs ctx before.1 bi item.2 with
    | error e => simp only [call,bind,Except.bind] at run; cases run
    | ok pair =>
      obtain ⟨args,next⟩ := pair
      simp only [call,bind,Except.bind,pure,Except.pure,Except.ok.injEq] at run
      subst after
      exact ⟨(stock_branchArgs_instBlock call).trans metadata,
        (stock_branchArgs_shape build reservations call).2.2.trans reservations,args,rfl,
        by simp only [Collected,tag]; exact ⟨before.1,next,call,metadata,reservations⟩⟩
private theorem outgoing_fold {f : Clif.Function} {ctx : Ctx} {ranges : Array (Nat × Nat)} {initial : State}
    (build : Stock.buildCtx f = .ok (ctx,ranges,initial)) {order : Order} {bi : Nat}
    {items : List (Nat × Nat)} {before after : State × Array (Array Reg)}
    (metadata : before.1.instBlock = initial.instBlock) (reservations : before.1.tryRegs = initial.tryRegs)
    (run : items.foldlM (outgoingStep ctx order bi) before = .ok after) :
    after.1.instBlock = initial.instBlock ∧ after.1.tryRegs = initial.tryRegs ∧
    after.2.size = before.2.size+items.length ∧
    (∀ j,j < before.2.size → after.2[j]? = before.2[j]?) ∧
    (∀ j item,items[j]? = some item → ∃ args,
      after.2[before.2.size+j]? = some args ∧ Collected ctx order bi initial item args) := by
  induction items generalizing before with
  | nil =>
    simp only [List.foldlM_nil,pure,Except.pure,Except.ok.injEq] at run
    subst after
    exact ⟨metadata,reservations,by simp,fun _ _ => rfl,fun j item h => by simp at h⟩
  | cons item rest ih =>
    rw [List.foldlM_cons] at run
    cases step : outgoingStep ctx order bi before item with
    | error e => simp only [step,bind,Except.bind] at run; cases run
    | ok middle =>
      simp only [step,bind,Except.bind] at run
      obtain ⟨middleMeta,middleRegs,args,installed,meaning⟩ := outgoing_vector build metadata reservations step
      obtain ⟨afterMeta,afterRegs,size,prelude,selected⟩ := ih middleMeta middleRegs run
      have middleSize : middle.2.size = before.2.size+1 := by simp [installed]
      refine ⟨afterMeta,afterRegs,by simpa [middleSize,Nat.add_comm,Nat.add_left_comm,Nat.add_assoc] using size,?_,?_⟩
      · intro j bound
        rw [prelude j (by omega),installed,Array.getElem?_push]
        simp [bound,show j ≠ before.2.size by omega]
      · intro j pair found
        cases j with
        | zero =>
          simp only [List.getElem?_cons_zero,Option.some.injEq] at found
          subst pair
          refine ⟨args,?_,meaning⟩
          rw [Nat.add_zero,prelude before.2.size (by omega),installed,Array.getElem?_push]
          simp
        | succ j =>
          simp only [List.getElem?_cons_succ] at found
          obtain ⟨vector,present,value⟩ := selected j pair found
          exact ⟨vector,by simpa [middleSize,Nat.add_comm,Nat.add_left_comm,Nat.add_assoc] using present,value⟩
/-- The SAME selected original-successor column supplies its actual branchArgs
run from unchanged original tables, even after earlier successor collections. -/
theorem stock_collectOutgoing_original_column {f : Clif.Function} {ctx : Ctx} {ranges : Array (Nat × Nat)} {initial : State}
    (build : Stock.buildCtx f = .ok (ctx,ranges,initial)) {order : Order} {bi index targetLabel targetBi : Nat}
    {targets : Array Nat} {before after : State} {row : Array (Array Reg)}
    (metadata : before.instBlock = initial.instBlock) (reservations : before.tryRegs = initial.tryRegs)
    (run : collectOutgoing ctx order bi targets before = .ok (after,row))
    (selected : targets[index]? = some targetLabel) (target : order.nodes[targetLabel]? = some (.original targetBi)) :
    ∃ (args : Array Reg) (input next : State),row[index]? = some args ∧
      branchArgs ctx input bi index = .ok (args,next) ∧ input.instBlock = initial.instBlock ∧ input.tryRegs = initial.tryRegs := by
  unfold collectOutgoing at run
  obtain ⟨_,_,_,_,present⟩ := outgoing_fold build metadata reservations run
  have item : targets.zipIdx.toList[index]? = some (targetLabel,index) := by simpa using selected
  obtain ⟨args,found,meaning⟩ := present index (targetLabel,index) item
  have node : order.nodes[targetLabel]! = .original targetBi := by simp only [getElem!_def,target]
  simp only [Collected,node] at meaning
  obtain ⟨input,next,call,metadata,reservations⟩ := meaning
  exact ⟨args,input,next,by simpa using found,call,metadata,reservations⟩
end Backend.Stock.Proof.TryOutgoingColumnsDraft
