import FV.Backend.Proof.StockLogicalRecordValues
import FV.Backend.Proof.StockRootOpcodeMatch
open Backend.Stock.Proof
#eval sourceOpcodeIds 97
#eval sourceOpcodeIds 98
#eval sourceOpcodeIds 99
#print Backend.Stock.Proof.stock_selected_source_opcode_ids
#print Backend.Stock.Proof.LogicalSelected.logical_data
