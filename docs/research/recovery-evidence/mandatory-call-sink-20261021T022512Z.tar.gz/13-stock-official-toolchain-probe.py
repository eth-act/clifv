from pathlib import Path
import os,subprocess as sp,json,signal,time,hashlib,datetime,shutil
out=Path('/tmp/stock-ci-toolchain-compatibility');out.mkdir(exist_ok=True);prefix=Path('/home/lee/.local/share/clifv-test-tools');official=prefix/'lean-4.34.1-linux';archive=prefix/'lean-4.34.1-official.tar.zst';old=Path('/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1');work=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');mixed=Path('/home/lee/clifv/.worktrees/stock-mixed-production');cache=Path('/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache');sched=3859380;stopped=False;state='waiting_for_IO_budget';details={}
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(1048576):h.update(b)
 return h.hexdigest()
def report():
 (out/'receipt.json').write_text(json.dumps({'state':state,'pid':os.getpid(),'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'official':str(official),'no_user_toolchain_overwrite':True,'scheduler_resumed':not stopped,**details},indent=2)+'\n')
try:
 os.nice(10);assert not official.exists() and not archive.exists()
 assert shutil.disk_usage(prefix).free>100*1024**3
 p=Path(f'/proc/{sched}');assert b'stock-execute-scheduler.py' in p.joinpath('cmdline').read_bytes() and p.joinpath('stat').read_text().split()[2]!='T';os.kill(sched,signal.SIGSTOP);stopped=True;report();deadline=time.monotonic()+60
 while True:
  caps=[]
  for k in p.joinpath('task',str(sched),'children').read_text().split():
   child=Path('/proc')/k
   try:
    if child.joinpath('stat').read_text().split()[2]=='Z':continue
    c=next(x.decode().split('=',1)[1] for x in child.joinpath('environ').read_bytes().split(b'\0') if x.startswith(b'FV_MEMCAP='));caps.append(int(c[:-1])*(1024 if c[-1]=='G' else 1))
   except FileNotFoundError:continue
   except PermissionError:caps.append(16384)
  if sum(caps)+1024<=16384:break
  assert time.monotonic()<deadline,('no IO budget',caps);time.sleep(.2)
 env=dict(os.environ,FV_MEMCAP='1G',OMP_NUM_THREADS='1',OMP_THREAD_LIMIT='1',LEAN_NUM_THREADS='1');memcap=str(work/'scripts/memcap.sh');details.update(existing_compiler_caps_MiB=caps,IO_cap_MiB=1024)
 state='downloading_exact_CI_pinned_toolchain';report()
 with (out/'download.log').open('w') as f:r=sp.run([memcap,'curl','--fail','--location','--retry','3','--output',str(archive),'https://github.com/leanprover/lean4/releases/download/v4.34.1/lean-4.34.1-linux.tar.zst'],env=env,stdout=f,stderr=sp.STDOUT)
 assert r.returncode==0,('download failed',str(out/'download.log'));actual=sha(archive);assert actual=='47bf4bbd78f70c2e9670598ab7124d92b6efb7330ff33e5fbb4030f6fd72e4e4';details.update(archive_sha256=actual,archive_bytes=archive.stat().st_size)
 state='extracting_verified_toolchain';report()
 with (out/'extract.log').open('w') as f:r=sp.run([memcap,'tar','--zstd','-xf',str(archive),'-C',str(prefix)],env=env,stdout=f,stderr=sp.STDOUT)
 assert r.returncode==0,('extract failed',str(out/'extract.log'));archive.unlink();details['temporary_archive_removed']=True
 comparisons={}
 for name in ['lib/lean/Init.olean','lib/lean/Std.olean','lib/lean/Lean.olean','lib/lean/Std/Tactic/BVDecide.olean','lib/lean/Lean/Elab/Tactic/Omega.olean','lib/lean/Lake/Build/Module.olean']:
  a=old/name;b=official/name
  if a.is_file() and b.is_file():comparisons[name]={'old_sha256':sha(a),'official_sha256':sha(b),'equal':sha(a)==sha(b)}
 details['toolchain_artifact_comparisons']=comparisons
 for label,toolchain in [('existing',old),('official',official)]:
  pe=dict(env,FV_ROOT=str(mixed),FV_LAKE_CACHE=str(cache),LAKE_CACHE_DIR=str(cache),LAKE_ARTIFACT_CACHE='true',LAKE_RESTORE_ARTIFACTS='true',PATH=str(toolchain/'bin')+':'+env['PATH'])
  for key in ['LEAN_SYSROOT','LEAN_PATH','LEAN_SRC_PATH','LEAN','LEANC','LAKE_HOME','LEAN_GITHASH','ELAN_TOOLCHAIN']:pe.pop(key,None)
  version=sp.check_output([str(toolchain/'bin/lean'),'--version'],text=True,env=pe).strip();state='cache_only_probe_'+label;details[label+'_version']=version;report();log=out/(label+'-cache-probe.log')
  with log.open('w') as f:r=sp.run([memcap,str(toolchain/'bin/lake'),'build','--no-build','FV.Backend.Proof.IselCmpEmit'],cwd=mixed,env=pe,stdout=f,stderr=sp.STDOUT)
  trace=mixed/'.lake/build/lib/lean/FV/Backend/Proof/IselCmpEmit.trace';details[label+'_probe']={'returncode':r.returncode,'log':str(log),'log_sha256':sha(log),'trace_depHash':json.loads(trace.read_text()).get('depHash') if trace.exists() else None,'no_compile_requested':True}
 state='compatibility_probe_completed_no_running_toolchain_changed';report()
except BaseException as e:
 state='failed';details['error']=repr(e);report();raise
finally:
 if stopped:os.kill(sched,signal.SIGCONT);stopped=False
 report();print(json.dumps({'state':state,'details':details,'scheduler_resumed':not stopped}),flush=True)
