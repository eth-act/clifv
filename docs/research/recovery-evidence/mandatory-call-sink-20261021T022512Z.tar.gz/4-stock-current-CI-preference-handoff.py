from pathlib import Path
import os,signal,time,subprocess as sp,json,hashlib,tarfile,datetime,re,shutil,traceback
out=Path('/tmp/stock-current-CI-preference-handoff');intent=json.loads((out/'intent.json').read_text());view=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');cache=Path('/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache');root=Path('/tmp/stock-arithmetic-arm-model-author-gates');prior=Path('/tmp/stock-arithmetic-arm-model-before-CI-preference');sched=intent['old_scheduler'];parent=intent['old_controller'];controller=Path('/tmp/stock-arithmetic-arm-model-author-gates.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return sp.check_output(['git',*args],cwd=view,text=True).strip()
def stat(pid):
 p=Path(f'/proc/{pid}/stat');return p.read_text().split() if p.exists() else None
def report(state,**kw):
 j={'state':state,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':os.getpid(),'head':intent['head'],'old_controller':parent,'old_scheduler':sched,**kw};(out/'progress.json').write_text(json.dumps(j,indent=2)+'\n');print(json.dumps(j),flush=True)
def retire_metadata(pid,signature):
 s=stat(pid)
 if not s or s[2]=='Z':return
 p=Path(f'/proc/{pid}');assert signature in p.joinpath('cmdline').read_bytes() and s[2]=='T'
 assert all(not stat(int(k)) or stat(int(k))[2]=='Z' for k in p.joinpath('task',str(pid),'children').read_text().split())
 os.kill(pid,signal.SIGTERM);os.kill(pid,signal.SIGCONT);deadline=time.monotonic()+30
 while stat(pid) and stat(pid)[2]!='Z':
  assert time.monotonic()<deadline,('metadata did not exit',pid);time.sleep(.2)
try:
 report('draining_same_current_model_kernels',jobs=intent['jobs'],no_proof_kernel_signalled=True)
 while True:
  assert stat(sched)[2]=='T' and stat(parent)[2]=='T';drained=[];live=[]
  for job in intent['jobs']:
   s=stat(job['pid']);assert s and s[21]==job['start_ticks']
   if s[2]!='Z':live.append(job['pid']);continue
   p=Path(job['time_file']);m=re.search(r'Exit status: (-?\d+)',p.read_text());assert m
   drained.append({**job,'exit_status':int(m[1]),'raw_wait_status':int(s[51]),'time_sha256':sha(p)})
  if not live:break
  time.sleep(2)
 assert all(x['exit_status']==0 and x['raw_wait_status']==0 for x in drained),('inspect actual kernel error before cache preference',drained)
 assert git('rev-parse','HEAD')==intent['head'] and not git('status','--porcelain','--untracked-files=no')
 frozen=json.loads((root/'inputs.json').read_text());assert all(sha(view/p)==h for p,h in frozen['sources'].items())
 log=root/'all-modules/sched.log';latest=dict(re.findall(r'done (\S+) rc=(\S+)',log.read_text()));assert all(rc=='0' for rc in latest.values())
 mapping=dict(json.loads(x) for x in Path('/tmp/stock-ci-toolchain-compatibility/stage-w1-2-original-outputs.jsonl').read_text().splitlines()[1:]);assert mapping[intent['cache_input_key']]==intent['CI_bundle']
 oldrecord=cache/'outputs/fv'/(intent['cache_input_key']+'.json');oldraw=oldrecord.read_bytes();(out/'previous-exact-key-output-record.json').write_bytes(oldraw)
 assert json.loads(oldraw)['data']['o']==[intent['retained_local_olean']]
 proof=json.loads(Path('/tmp/stock-ci-toolchain-compatibility/generic-trace-byte-comparisons.json').read_text());rows=[x for x in proof['rows'] if x['module']=='FV.Backend.Proof.RegallocLemmas'];assert len(rows)==1 and rows[0]['exact_same_input_key']==intent['cache_input_key'];assert rows[0]['CI_outputs']['o']==[intent['CI_olean']] and rows[0]['byte_equality']=={'o':False,'i':True,'c':True}
 receipt={'state':'current_model_kernels_drained_for_exact_key_CI_artifact_preference','head':intent['head'],'source_files_verified':len(frozen['sources']),'completed_log_records':len(latest),'drained_jobs':drained,'no_proof_kernel_interrupted':True,'no_source_compiler_or_axiom_change':True,'old_epoch_complete':False,'existing22_named_and_dynamic_gates_preserved':True,'cache_preference':rows[0]};(out/'drain-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 report('preserving_current_epoch_before_cache_alignment',completed_log_records=len(latest),drained_jobs=len(drained))
 archive=out/'current-epoch-and-cache-evidence.tar.gz';paths=[root,out/'intent.json',out/'drain-receipt.json',out/'previous-exact-key-output-record.json',Path(__file__),controller,Path('/tmp/stock-arithmetic-arm-model-ready-to-land.py'),Path('/tmp/stock-08020-ci-extra-stages'),Path('/tmp/stock-ci-toolchain-compatibility'),Path('/tmp/stock-import-08020-current-extra-stages.py'),Path('/tmp/stock-ci-cache-overlap-review.py'),Path('/tmp/stock-ci-generic-trace-review.py'),Path('/tmp/stock-ci-map-source-review.py'),Path('/tmp/stock-official-toolchain-probe.py'),Path('/tmp/stock-current-resume.json'),Path('/tmp/stock-ni-current-status44.md'),cache/'artifacts'/intent['CI_bundle'],cache/'artifacts'/intent['retained_local_olean']]
 with tarfile.open(archive,'w:gz',compresslevel=1) as t:
  for i,p in enumerate(paths):assert p.exists(),p;t.add(p,arcname=str(i)+'-'+p.name)
 env=dict(os.environ,FV_MEMCAP='1G',FV_LAKE_CACHE=str(cache),PATH='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:'+os.environ['PATH'],LEAN_NUM_THREADS='1',OMP_NUM_THREADS='1',OMP_THREAD_LIMIT='1',STOCK_RECOVERY_EVIDENCE=str(archive),GIT_CONFIG_COUNT='1',GIT_CONFIG_KEY_0='pack.threads',GIT_CONFIG_VALUE_0='1');memcap=str(view/'scripts/memcap.sh')
 with (out/'backup.log').open('w') as f:r=sp.run(['nice','-n','10',memcap,'python3','/tmp/stock-mandatory-backup.py'],cwd=view,env=env,stdout=f,stderr=sp.STDOUT)
 assert r.returncode==0;backup=json.loads(Path('/tmp/stock-backup-captured-result.json').read_text());assert backup['remote_commit_and_all_captured_blobs_verified'] and backup['index_and_active_head_unchanged']
 report('current_epoch_remotely_preserved',backup_commit=backup['commit'],archive_sha256=sha(archive))
 stage=out/'one-exact-key-stage';stage.mkdir(exist_ok=False);shutil.copyfile(cache/'artifacts'/intent['CI_bundle'],stage/intent['CI_bundle']);(stage/'outputs.jsonl').write_text(json.dumps('2026-03-17')+'\n'+json.dumps([intent['cache_input_key'],intent['CI_bundle']])+'\n')
 with (out/'exact-key-unstage.log').open('w') as f:r=sp.run([memcap,'lake','cache','unstage',str(stage),'--force-overwrite'],cwd=view,env=env,stdout=f,stderr=sp.STDOUT)
 assert r.returncode==0;assert json.loads(oldrecord.read_text())['data']==intent['CI_bundle']
 with (out/'normal-key-verified-materialization.log').open('w') as f:r=sp.run([memcap,'lake','build','--no-build','FV.Backend.Proof.RegallocLemmas'],cwd=view,env=env,stdout=f,stderr=sp.STDOUT)
 assert r.returncode==0,('exact key failed normal Lake source check',str(out/'normal-key-verified-materialization.log'))
 trace=json.loads((view/'.lake/build/lib/lean/FV/Backend/Proof/RegallocLemmas.trace').read_text());assert trace['depHash']==intent['cache_input_key'] and trace['outputs']['o']==[intent['CI_olean']]
 with (out/'downstream-key-probe.log').open('w') as f:downstream=sp.run([memcap,'lake','build','--no-build','FV.Backend.Proof.IselCmpEmit'],cwd=view,env=env,stdout=f,stderr=sp.STDOUT)
 alignment={'state':'exact_current_input_key_CI_output_adopted_and_normally_verified','head':intent['head'],'input_key':intent['cache_input_key'],'CI_olean':intent['CI_olean'],'local_old_olean_preserved':intent['retained_local_olean'],'old_output_record_sha256':hashlib.sha256(oldraw).hexdigest(),'normal_Lake_input_key_verification':True,'downstream_no_build_probe_returncode':downstream.returncode,'downstream_probe_log':str(out/'downstream-key-probe.log'),'previous_epoch_backup':backup['commit'],'source_and_theorem_and_gate_changes':False};(out/'alignment-receipt.json').write_text(json.dumps(alignment,indent=2)+'\n');shutil.rmtree(stage)
 assert all(sha(view/p)==h for p,h in frozen['sources'].items())
 retire_metadata(sched,b'stock-execute-scheduler.py');retire_metadata(parent,b'stock-arithmetic-arm-model-author-gates.py');assert not prior.exists();root.rename(prior)
 log=Path('/tmp/stock-arithmetic-arm-model-author-controller.log');oldlog=Path('/tmp/stock-arithmetic-arm-model-before-CI-preference-controller.log');assert not oldlog.exists();log.rename(oldlog)
 with log.open('w') as f:p=sp.Popen(['python3',str(controller)],cwd=view,stdout=f,stderr=sp.STDOUT,start_new_session=True)
 report('current_source_gates_started_with_CI_canonical_proof_artifact',controller_pid=p.pid,prior_epoch=str(prior),controller_log=str(log),backup_commit=backup['commit'],backup_branch=backup['branch'],no_proof_kernel_interrupted=True,source_or_axiom_or_gate_changes=False,downstream_cache_probe_returncode=downstream.returncode)
except BaseException as e:
 report('failed',error=repr(e),traceback=traceback.format_exc(),note='Inspect actual state; preserve current held metadata and all kernels; never resume/restart blindly.');raise
