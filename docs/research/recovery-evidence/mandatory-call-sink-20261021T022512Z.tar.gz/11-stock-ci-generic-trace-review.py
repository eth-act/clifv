from pathlib import Path
import os,time,signal,subprocess as sp,json,hashlib,shutil,datetime
out=Path('/tmp/stock-ci-toolchain-compatibility');source=json.loads((out/'first-divergence-review.json').read_text());root=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');cache=Path('/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache');sched=3859380;p=Path(f'/proc/{sched}');stopped=False;rows=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
try:
 os.nice(10)
 while True:
  assert b'stock-execute-scheduler.py' in p.joinpath('cmdline').read_bytes()
  if p.joinpath('stat').read_text().split()[2]=='T':time.sleep(2);continue
  os.kill(sched,signal.SIGSTOP);stopped=True;caps=[]
  for k in p.joinpath('task',str(sched),'children').read_text().split():
   child=Path('/proc')/k
   try:
    if child.joinpath('stat').read_text().split()[2]=='Z':continue
    c=next(x.decode().split('=',1)[1] for x in child.joinpath('environ').read_bytes().split(b'\0') if x.startswith(b'FV_MEMCAP='));caps.append(int(c[:-1])*(1024 if c[-1]=='G' else 1))
   except FileNotFoundError:continue
   except PermissionError:caps.append(16384)
  if sum(caps)+1024<=16384:break
  os.kill(sched,signal.SIGCONT);stopped=False;time.sleep(2)
 env=dict(os.environ,FV_MEMCAP='1G',OMP_NUM_THREADS='1',OMP_THREAD_LIMIT='1')
 for item in source['need_full_trace_unpack']:
  m=item['module'];dest=out/('generic-'+m);lean=dest/'lean';ir=dest/'ir';lean.mkdir(parents=True);ir.mkdir();local=json.loads((root/'.lake/build/lib/lean'/(m.replace('.','/')+'.trace')).read_text());log=out/(m+'.generic-unpack.log')
  with log.open('w') as f:r=sp.run([str(root/'scripts/memcap.sh'),'/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin/leantar','--jobs','1','-C',str(lean),'-C',str(ir),'-x','-j','-'],input=json.dumps([{'file':str(cache/'artifacts'/item['bundle']),'hash':local['depHash']}]).encode(),env=env,stdout=f,stderr=sp.STDOUT)
  assert r.returncode==0,(m,str(log));ci_trace=json.loads(next(lean.rglob('*.trace')).read_text());same={}
  for field,ext in [('o','.olean'),('i','.ilean'),('c','.c')]:
   refs=local['outputs'][field];refs=refs if isinstance(refs,list) else [refs];files=sorted(dest.rglob('*'+ext));assert len(refs)==len(files)
   same[field]=all(sha(file)==sha(cache/'artifacts'/ref) for file,ref in zip(files,refs))
  rows.append({**item,'exact_same_input_key':local['depHash'],'byte_equality':same,'CI_outputs':ci_trace['outputs'],'local_outputs':local['outputs']});shutil.rmtree(dest)
 (out/'generic-trace-byte-comparisons.json').write_text(json.dumps({'state':'same_key_module_bundle_bytes_compared','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'rows':rows},indent=2)+'\n');print(json.dumps({'checked':len(rows),'differences':[x for x in rows if not all(x['byte_equality'].values())]},indent=2))
finally:
 if stopped:os.kill(sched,signal.SIGCONT)
