from pathlib import Path
import os,signal,time,subprocess as sp,json,hashlib,shutil,datetime
out=Path('/tmp/stock-08020-ci-extra-stages');cache=Path('/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache');work=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');sched=3859380;stopped=False
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();five=json.loads((out/'remaining-five-preimages.json').read_text());results={}
try:
 p=Path(f'/proc/{sched}');assert b'stock-execute-scheduler.py' in p.joinpath('cmdline').read_bytes();assert p.joinpath('stat').read_text().split()[2]!='T';os.kill(sched,signal.SIGSTOP);stopped=True;deadline=time.monotonic()+60
 while True:
  caps=[]
  for k in p.joinpath('task',str(sched),'children').read_text().split():
   c=Path('/proc')/k
   try:
    if c.joinpath('stat').read_text().split()[2]=='Z':continue
    x=next(v.decode().split('=',1)[1] for v in c.joinpath('environ').read_bytes().split(b'\0') if v.startswith(b'FV_MEMCAP='));caps.append(int(x[:-1])*(1024 if x[-1]=='G' else 1))
   except FileNotFoundError:continue
   except PermissionError:caps.append(16384)
  if sum(caps)+1024<=16384:break
  assert time.monotonic()<deadline,('no IO budget; preserve existing kernels',caps);time.sleep(.2)
 env=dict(os.environ,FV_MEMCAP='1G',OMP_NUM_THREADS='1',OMP_THREAD_LIMIT='1',LEAN_NUM_THREADS='1');leantar='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin/leantar'
 for key,old in five.items():
  dest=out/('inspect-'+key);lean=dest/'lean';ir=dest/'ir';lean.mkdir(parents=True);ir.mkdir();bundle=cache/'artifacts'/old['bundle'];current=json.loads((cache/'outputs/fv'/(key+'.json')).read_text())
  args=[str(work/'scripts/memcap.sh'),leantar,'--jobs','1','-C',str(lean),'-C',str(ir),'-x','-j','-'];log=out/(key+'.unpack.log')
  with log.open('w') as f:r=sp.run(args,input=json.dumps([{'file':str(bundle),'hash':key}]).encode(),env=env,stdout=f,stderr=sp.STDOUT)
  assert r.returncode==0,(key,str(log))
  data=current['data'];comparisons=[]
  for field,ext in [('o','.olean'),('i','.ilean'),('c','.c')]:
   refs=data[field] if isinstance(data[field],list) else [data[field]];files=sorted(dest.rglob('*'+ext));assert len(refs)==len(files),(key,field,len(refs),len(files))
   for reference,file in zip(refs,files):
    same=sha(file)==sha(cache/'artifacts'/reference);comparisons.append({'field':field,'file':str(file.relative_to(dest)),'artifact':reference,'equal_sha256':same});assert same,(key,field,file)
  results[key]={'old_packed_reference_record':old['old_record'],'bundle':old['bundle'],'bundle_sha256':sha(bundle),'all_compared_module_artifacts_identical':True,'comparisons':comparisons,'unpack_log_sha256':sha(log)};shutil.rmtree(dest)
 (out/'five-bundles-byte-comparison.json').write_text(json.dumps({'state':'all_five_packed_and_fresh_module_outputs_identical','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'records':results,'temporary_inspection_directories_removed':True},indent=2)+'\n');print(json.dumps({'all_five_same_olean_ilean_C_bytes':True,'records':len(results)}))
finally:
 if stopped:os.kill(sched,signal.SIGCONT)
