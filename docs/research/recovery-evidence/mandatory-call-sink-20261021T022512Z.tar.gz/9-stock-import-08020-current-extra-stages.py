from pathlib import Path
import os,subprocess as sp,json,signal,time,re,hashlib,zipfile,shutil,datetime,traceback
out=Path('/tmp/stock-08020-ci-extra-stages');out.mkdir(exist_ok=True);work=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');cache=Path('/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache');sched=3859380
expected=[(12313514310,'stage-w1-2'),(12313471505,'stage-w1-0'),(12313297812,'stage-w1-3')];base='08020ed34bea4a3656c1b080c55087da40f2ebbe';records=[];keys={};artifacts=set();stopped=False;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();state='waiting_for_cache_IO_budget'
def report(**kw):
 j={'state':state,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':os.getpid(),'main':base,'run':39519636227,'records':records,'unique_output_record_sha256':keys,'unique_keys_verified':len(keys),'referenced_artifacts_verified':len(artifacts),'scheduler_resumed':not stopped,'no_new_cache_or_proof_job':True,**kw};(out/'receipt.json').write_text(json.dumps(j,indent=2)+'\n')
def verify_ref(v):
 if isinstance(v,str):
  assert (cache/'artifacts'/v).is_file(),v;artifacts.add(v)
 elif isinstance(v,list):
  for x in v:verify_ref(x)
 elif isinstance(v,dict):
  for x in v.values():verify_ref(x)
 else:assert isinstance(v,(bool,int,float)) or v is None,type(v)
try:
 os.nice(10)
 gate=json.loads(Path('/tmp/stock-arithmetic-arm-model-author-gates/progress.json').read_text());assert gate['state']=='running' and gate['phase']=='all-modules'
 assert sp.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip()=='672c4dc4820b31c477a5e075926c72cd2b267dd8'
 p=Path(f'/proc/{sched}');assert b'stock-execute-scheduler.py' in p.joinpath('cmdline').read_bytes() and p.joinpath('stat').read_text().split()[2]!='T'
 os.kill(sched,signal.SIGSTOP);stopped=True;report();deadline=time.monotonic()+60
 while True:
  caps=[];live=[]
  for k in p.joinpath('task',str(sched),'children').read_text().split():
   child=Path('/proc')/k
   try:
    if child.joinpath('stat').read_text().split()[2]=='Z':continue
    cap=next(v.decode().split('=',1)[1] for v in child.joinpath('environ').read_bytes().split(b'\0') if v.startswith(b'FV_MEMCAP='));amount=int(cap[:-1])*(1024 if cap[-1]=='G' else 1)
   except FileNotFoundError:continue
   except PermissionError:amount=16384
   caps.append(amount);live.append(int(k))
  if len(live)<=2 and sum(caps)+1024<=16384:break
  if time.monotonic()>=deadline:
   state='deferred_existing_kernels_preserved';report(caps_MiB=caps);raise SystemExit(0)
  time.sleep(.2)
 env=dict(os.environ,FV_MEMCAP='1G',FV_LAKE_CACHE=str(cache),LEAN_NUM_THREADS='1',OMP_NUM_THREADS='1',OMP_THREAD_LIMIT='1',PATH='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:'+os.environ['PATH']);memcap=str(work/'scripts/memcap.sh')
 for ident,name in expected:
  meta=json.loads(sp.check_output(['gh','api',f'repos/eth-act/clifv/actions/artifacts/{ident}'],text=True));assert meta['name']==name and meta['workflow_run']['head_sha']==base and meta['workflow_run']['id']==39519636227 and not meta['expired']
  archive=out/(name+'.zip');state='downloading';report(current_stage=name,caps_MiB=caps,aggregate_reserved_MiB=sum(caps)+1024)
  with archive.open('wb') as f:r=sp.run([memcap,'gh','api',f'repos/eth-act/clifv/actions/artifacts/{ident}/zip'],cwd=work,env=env,stdout=f)
  assert r.returncode==0 and archive.stat().st_size==meta['size_in_bytes']
  stage=out/name;stage.mkdir(exist_ok=False);item={'artifact':ident,'stage':name,'zip_sha256':sha(archive),'zip_bytes':archive.stat().st_size,'state':'downloaded_not_unstaged'};records.append(item);report(current_stage=name)
  with zipfile.ZipFile(archive) as z:
   assert len(z.namelist())==len(set(z.namelist())) and all(n=='outputs.jsonl' or re.fullmatch('[0-9a-f]{16}\\.ltar',n) for n in z.namelist());z.extractall(stage)
  lines=(stage/'outputs.jsonl').read_text().splitlines();assert json.loads(lines[0])=='2026-03-17';pairs=[json.loads(x) for x in lines[1:]];assert all((stage/name).is_file() for key,name in pairs)
  state='unstaging';report(current_stage=name);log=out/(name+'.unstage.log')
  with log.open('w') as f:r=sp.run([memcap,'lake','cache','unstage',str(stage)],cwd=work,env=env,stdout=f,stderr=sp.STDOUT)
  item.update(state='unstaged_validation_pending',unstage_rc=r.returncode,log=str(log),log_sha256=sha(log));report(current_stage=name);assert r.returncode==0
  types={}
  for key,_ in pairs:
   path=cache/'outputs/fv'/(key+'.json');assert path.is_file();digest=sha(path)
   if key in keys:assert keys[key]==digest,('same-key output drift',key)
   keys[key]=digest;data=json.loads(path.read_text())['data'];types[type(data).__name__]=types.get(type(data).__name__,0)+1;verify_ref(data)
  item.update(state='all_output_records_and_artifact_references_verified',output_keys=len(pairs),schema_types=types);shutil.rmtree(stage);archive.unlink();item['temporary_download_and_staging_removed']=True;report(current_stage=name)
 prior={}
 for p,field in [(Path('/tmp/stock-08020-ci-cache-stages/receipt.json'),'output_record_sha256'),(Path('/tmp/stock-08020-ci-cache-heavy-stage5/receipt.json'),'output_record_sha256')]:prior.update(json.loads(p.read_text())[field])
 overlap=set(keys)&set(prior);assert all(keys[k]==prior[k] for k in overlap)
 state='imported_to_existing_source_keyed_cache_not_gate_pass';report(prior_keys=len(prior),overlap_with_prior_keys=len(overlap),new_keys=len(set(keys)-set(prior)),existing_compiler_caps_MiB=caps,cache_IO_cap_MiB=1024,aggregate_reserved_MiB=sum(caps)+1024)
except SystemExit:raise
except BaseException as e:
 state='failed';report(error=repr(e),traceback=traceback.format_exc());raise
finally:
 if stopped:
  p=Path(f'/proc/{sched}/cmdline')
  if p.exists() and b'stock-execute-scheduler.py' in p.read_bytes():os.kill(sched,signal.SIGCONT)
  stopped=False
 # Keep final detailed fields while recording actual release of the owned hold.
 p=out/'receipt.json';j=json.loads(p.read_text()) if p.exists() else {};j.update(scheduler_resumed=True,utc=datetime.datetime.now(datetime.timezone.utc).isoformat());p.write_text(json.dumps(j,indent=2)+'\n');print(json.dumps({k:j.get(k) for k in ['state','unique_keys_verified','referenced_artifacts_verified','new_keys','scheduler_resumed','error']}),flush=True)
