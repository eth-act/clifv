from pathlib import Path
import os,time,signal,subprocess as sp,json,zipfile,datetime,shutil
out=Path('/tmp/stock-ci-toolchain-compatibility');work=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');cache=Path('/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache');sched=3859380;stopped=False
state='waiting_for_1GiB_cache_IO_headroom';p=Path(f'/proc/{sched}')
def caps():
 values=[]
 for k in p.joinpath('task',str(sched),'children').read_text().split():
  child=Path('/proc')/k
  try:
   if child.joinpath('stat').read_text().split()[2]=='Z':continue
   c=next(x.decode().split('=',1)[1] for x in child.joinpath('environ').read_bytes().split(b'\0') if x.startswith(b'FV_MEMCAP='));values.append(int(c[:-1])*(1024 if c[-1]=='G' else 1))
  except FileNotFoundError:continue
  except PermissionError:values.append(16384)
 return values
try:
 os.nice(10)
 (out/'map-review-progress.json').write_text(json.dumps({'state':state,'pid':os.getpid(),'scheduler':sched,'no_proof_kernel_signalled':True})+'\n')
 while True:
  assert b'stock-execute-scheduler.py' in p.joinpath('cmdline').read_bytes()
  if sum(caps())+1024>16384:time.sleep(2);continue
  if p.joinpath('stat').read_text().split()[2]=='T':time.sleep(2);continue
  os.kill(sched,signal.SIGSTOP);stopped=True
  if sum(caps())+1024<=16384:break
  os.kill(sched,signal.SIGCONT);stopped=False;time.sleep(2)
 env=dict(os.environ,FV_MEMCAP='1G',OMP_NUM_THREADS='1',OMP_THREAD_LIMIT='1');archive=out/'stage-w1-2-map-review.zip'
 with archive.open('wb') as f:r=sp.run([str(work/'scripts/memcap.sh'),'gh','api','repos/eth-act/clifv/actions/artifacts/12313514310/zip'],env=env,stdout=f)
 assert r.returncode==0
 with zipfile.ZipFile(archive) as z:raw=z.read('outputs.jsonl')
 (out/'stage-w1-2-original-outputs.jsonl').write_bytes(raw);archive.unlink();mapping=dict(json.loads(x) for x in raw.decode().splitlines()[1:]);rows=[]
 for module in ['FV.Isle.Generated.RuleArray','FV.Isle.Generated.RuleTable','FV.Isle.Syntax','FV.Clif.Syntax','FV.Backend.Proof.IselCmpIcmp','FV.Backend.Proof.IselCmpEmit']:
  t=json.loads((work/'.lake/build/lib/lean'/(module.replace('.','/')+'.trace')).read_text());key=t['depHash'];bundle=mapping.get(key);o=None
  if bundle:
   with (cache/'artifacts'/bundle).open('rb') as f:b=f.read(180)
   n=b.find(b'\0',5)
   if b[n+1]==6:o=f'{int.from_bytes(b[n+2:n+10],"little"):016x}.olean'
  rows.append({'module':module,'local_input_key':key,'CI_bundle_for_exact_same_key':bundle,'CI_bundle_header_olean_candidate':o,'local_olean':t['outputs']['o']})
 (out/'same-input-map-review.json').write_text(json.dumps({'state':'original_CI_mapping_compared','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'rows':rows},indent=2)+'\n')
 # Exact CI official binary was unnecessary: version, six library fingerprints and
 # both ordinary no-build probes agree. Keep only the measured receipt and logs.
 official=Path('/home/lee/.local/share/clifv-test-tools/lean-4.34.1-linux');receipt=json.loads((out/'receipt.json').read_text());assert receipt['official']==str(official) and receipt['no_user_toolchain_overwrite'];assert all(x['equal'] for x in receipt['toolchain_artifact_comparisons'].values());assert receipt['existing_probe']['trace_depHash']==receipt['official_probe']['trace_depHash'];shutil.rmtree(official);receipt.update(unneeded_official_toolchain_removed=True,existing_user_toolchain_untouched=True);(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 state='same_input_mapping_reviewed_unneeded_toolchain_removed';print(json.dumps({'state':state,'rows':rows}),flush=True)
finally:
 if stopped:os.kill(sched,signal.SIGCONT)
 (out/'map-review-progress.json').write_text(json.dumps({'state':state,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':os.getpid(),'scheduler':sched,'scheduler_resumed':True,'no_proof_kernel_signalled':True},indent=2)+'\n')
