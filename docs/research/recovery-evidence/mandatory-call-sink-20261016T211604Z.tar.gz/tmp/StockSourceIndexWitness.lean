import StockSourceIndexWhole
import StockTryEmittedWitness
namespace Backend.Stock.Proof.SourceIndexWitnessDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open TryEmittedWitnessDraft (Kind)
open SourceIndexWholeDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private def function : Kind → Clif.Function
  | .near => TryNearFixtureDraft.function false
  | .got => SpillEntryFixture.function false
  | .indirect => SpillEntryFixture.function true
private def entry (k : Kind) := (function k).blocks[0]!
private def table : Clif.ExnTable := {
  sig := 0,normal := ⟨1,[.ret 0,.val 0]⟩,items := [.tag 7 ⟨2,[.exn 0,.exn 1,.val 0]⟩] }
private structure Fixture (k : Kind) where
  result : Result
  prepared : EdgeVCode
  rf : RFunc
  af : AFunc
  lowered : Stock.lower (function k) = .ok result
  scope : LowerScope (function k)
  dominated : Dominated (function k)
  arity : ArityOk (function k)
  prepare : prepareAt result.code result.edgeArgs = .ok prepared
  fallback : rf = spillAllocAt prepared.code prepared.edges
  accepted : checkAllocAt prepared.code prepared.edges rf = .ok ()
  physical : lowerRFunc prepared.code rf = .ok af
private theorem fixture (k : Kind) : Nonempty (Fixture k) := by
  cases k with
  | near =>
    obtain ⟨out⟩ := TryNearFixtureDraft.stock_near_try_fixture
    exact ⟨⟨out.result,out.prepared,out.rf,out.af,out.lowered,out.scope,out.dominated,out.arity,
      out.prepare,out.fallback,out.accepted,out.physical⟩⟩
  | got =>
    obtain ⟨out⟩ := SpillEntryFixture.try_fixture false
    exact ⟨⟨out.result,out.prepared,out.rf,out.af,out.lowered,out.scope,out.dominated,out.arity,
      out.prepare,out.fallback,out.accepted,out.physical⟩⟩
  | indirect =>
    obtain ⟨out⟩ := SpillEntryFixture.try_fixture true
    exact ⟨⟨out.result,out.prepared,out.rf,out.af,out.lowered,out.scope,out.dominated,out.arity,
      out.prepare,out.fallback,out.accepted,out.physical⟩⟩
private theorem order (k : Kind) : blockOrder (function k) = .ok {
    nodes := #[.original 0,.original 1,.original 2],successors := #[#[2,1],#[],#[]]} := by cases k <;> cbv


/-- COMPLETE near/GOT/indirect compiler and physical pipelines exercise EVERY
source block's canonical label/start and actual original-node reservation query,
including nonzero empty normal/handler blocks. -/
theorem stock_complete_source_canonical_indices_witness (k : Kind) :
    ∃ (out : Fixture k) (ranges : Array (Nat × Nat)),
      LowerScope (function k) ∧ Dominated (function k) ∧ ArityOk (function k) ∧
      Stock.lower (function k) = .ok out.result ∧ prepareAt out.result.code out.result.edgeArgs = .ok out.prepared ∧
      out.rf = spillAllocAt out.prepared.code out.prepared.edges ∧
      checkAllocAt out.prepared.code out.prepared.edges out.rf = .ok () ∧ lowerRFunc out.prepared.code out.rf = .ok out.af ∧
      Stock.buildCtx (function k) = .ok (out.result.ctx,ranges,out.result.initial) ∧
      (function k).blocks[1]!.body = [] ∧ 0 < blockStart (function k) 1 ∧
      out.result.initial.instBlock.findIdx? (· == 1) = some (blockStart (function k) 1) ∧
      (∀ bi b,(function k).blocks[bi]? = some b →
        out.result.initial.instBlock.findIdx? (· == bi) = some (blockStart (function k) bi) ∧
        ∀ j,j ≤ b.body.length → out.result.initial.instBlock[blockStart (function k) bi+j]? = some bi) ∧
      ∀ label bi b,out.result.order.nodes[label]? = some (.original bi) → (function k).blocks[bi]? = some b →
        ∃ ranges' params input output,
          Stock.buildCtx (function k) = .ok (out.result.ctx,ranges',out.result.initial) ∧
          lowerNode out.result.ctx ranges' out.result.order (function k) params label input = .ok output ∧
          input.state.instBlock = out.result.initial.instBlock ∧ input.state.tryRegs = out.result.initial.tryRegs ∧
          input.state.instBlock.findIdx? (· == bi) = some (blockStart (function k) bi) ∧
          input.state.tryRegs[(input.state.instBlock.findIdx? (· == bi)).getD 0 + out.result.ctx.func.blocks[bi]!.body.length]! =
            out.result.initial.tryRegs[blockStart (function k) bi+b.body.length]! := by
  obtain ⟨out⟩ := fixture k
  have sameOrder := Except.ok.inj ((stock_lower_order out.lowered).symm.trans (order k))
  have node : out.result.order.nodes[0]? = some (.original 0) := by rw [sameOrder]; rfl
  have block : (function k).blocks[0]? = some (entry k) := by cases k <;> rfl
  obtain ⟨ranges,params,input,output,build,rest⟩ := stock_lower_original_reservation_slot out.lowered node block
  have normal : (function k).blocks[1]? = some (function k).blocks[1]! := by cases k <;> rfl
  refine ⟨out,ranges,out.scope,out.dominated,out.arity,out.lowered,out.prepare,out.fallback,out.accepted,out.physical,
    build,?_,?_,stock_buildCtx_instBlock_find build normal,?_,?_⟩
  · cases k <;> rfl
  · cases k <;> decide +kernel
  · intro bi b found
    exact ⟨stock_buildCtx_instBlock_find build found,fun j inside => stock_buildCtx_instBlock_at build found inside⟩
  · intro label bi b tag found
    exact stock_lower_original_reservation_slot out.lowered tag found
end Backend.Stock.Proof.SourceIndexWitnessDraft
