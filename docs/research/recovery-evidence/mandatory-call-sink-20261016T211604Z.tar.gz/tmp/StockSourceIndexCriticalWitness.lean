import FV.Backend.Proof.StockCriticalEdgeArity
import FV.Backend.Proof.SpillArity
import StockSourceIndexWhole
import FV.Backend.Proof.StockPerEdgeCriticalAllocatorWitness
namespace Backend.Stock.Proof.SourceIndexCriticalWitnessDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill TryIndexControlDraft TryIndexWholeDraft SourceIndexWholeDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private def reduce : Clif.Stmt := ⟨[17],.ireduce .i8 7⟩
private def function : Clif.Function := {
  name := "stock_critical_values_alias"
  sig := {params := [⟨.i64,.none,.normal⟩],returns := [⟨.i8,.none,.normal⟩],callConv := some .systemV}
  blocks := [{id := 0,params := [(7,.i64)],body := [reduce],term := .brif 7 ⟨1,[17]⟩ ⟨1,[17]⟩},
    {id := 1,params := [(31,.i8)],term := .ret [31]}] }
/-- A COMPLETE critical-edge compiler/fallback/physical pipeline inhabits
collection from unchanged original metadata, a real nonempty outgoing vector
and actual final alias resolution. Cached physical validation is reused. -/
theorem stock_complete_critical_canonical_slot_witness :
    ∃ (result : Result) (prepared : EdgeVCode) (rf : RFunc) (af : AFunc)
      (ranges : Array (Nat × Nat)) (input next : State) (args : Array Reg),
      Stock.lower function = .ok result ∧ LowerScope function ∧ Dominated function ∧ ArityOk function ∧
      prepareAt result.code result.edgeArgs = .ok prepared ∧ rf = spillAllocAt prepared.code prepared.edges ∧
      checkAllocAt prepared.code prepared.edges rf = .ok () ∧ lowerRFunc prepared.code rf = .ok af ∧
      Stock.buildCtx function = .ok (result.ctx,ranges,result.initial) ∧
      branchArgs result.ctx input 0 0 = .ok (args,next) ∧ args.size = 1 ∧
      input.instBlock = result.initial.instBlock ∧ input.tryRegs = result.initial.tryRegs ∧
      input.instBlock.findIdx? (· == 0) = some (blockStart function 0) ∧
      input.tryRegs[(input.instBlock.findIdx? (· == 0)).getD 0 + result.ctx.func.blocks[0]!.body.length]! =
        result.initial.tryRegs[blockStart function 0+function.blocks[0]!.body.length]! ∧
      next.instBlock = result.initial.instBlock ∧ result.final.instBlock = result.initial.instBlock ∧
      (result.final.alias[193]?).join = some 192 ∧
      result.edgeArgs[1]? = some #[args.map
        (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1))] := by
  obtain ⟨result,prepared,rf,af,lowered,scope,dominated,prepare,v0,v1,v2,reorder,fallback,selected,checked,physical,final,simulation⟩ :=
    PerEdgeCriticalAllocatorWitness.stock_per_edge_critical_allocator_fallback_witness
  change Stock.lower function = .ok result at lowered
  change LowerScope function at scope
  change Dominated function at dominated
  obtain ⟨same,tl,targetLabel,rho,loweredSame,scopeSame,dominatedSame,alias,rest⟩ :=
    CriticalValuesWitness.stock_critical_selected_route_witness (0 : BitVec 64) 0 (by decide)
  change Stock.lower function = .ok same at loweredSame
  have equal : same = result := Except.ok.inj (loweredSame.symm.trans lowered)
  subst same
  have order : blockOrder function = .ok {
      nodes := #[.original 0,.edge 0 0 1,.edge 0 1 1,.original 1],successors := #[#[1,2],#[3],#[3],#[]]} := by cbv
  have sameOrder := Except.ok.inj ((stock_lower_order lowered).symm.trans order)
  have tag : result.order.nodes[1]? = some (.edge 0 0 1) := by rw [sameOrder]; rfl
  obtain ⟨ranges,input,next,args,build,call,metadata,reservations,query,sameSlot,stored⟩ :=
    stock_lower_critical_reservation_slot lowered tag (show function.blocks[0]? = some function.blocks[0]! from rfl)
  have func : result.ctx.func = function := (buildCtx_mappedInv scope build).func
  obtain ⟨id,sourceArgs,target,destination,found,length⟩ := stock_branchArgs_target_arity call
  rw [func] at destination found
  change some (1,[Clif.TryArg.val 17]) = some (id,sourceArgs) at destination
  cases destination
  change some {id := 1,params := [(31,Clif.Ty.i8)],body := [],term := .ret [31]} = some target at found
  cases found
  have count : args.size = 1 := length
  exact ⟨result,prepared,rf,af,ranges,input,next,args,lowered,scope,dominated,
    arityOk_of (by decide +kernel),prepare,fallback,checked,physical,build,call,count,metadata,reservations,
    query,sameSlot,(stock_branchArgs_instBlock call).trans metadata,stock_lower_instBlock lowered,alias,stored⟩
end Backend.Stock.Proof.SourceIndexCriticalWitnessDraft
