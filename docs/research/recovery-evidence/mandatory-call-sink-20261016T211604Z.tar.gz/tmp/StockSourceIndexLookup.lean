import FV.Backend.Proof.StockDFG
import StockSourceIndexModel
namespace Backend.Stock.Proof.SourceIndexLookupDraft
open Backend.Proof Backend.Proof.Driver SourceIndexModelDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private theorem interval_unique : ∀ (Bs : List Clif.Block) {bi bj : Nat} {b c : Clif.Block},
    Bs[bi]? = some b → Bs[bj]? = some c → ∀ i j,i ≤ b.body.length → j ≤ c.body.length →
      bsl Bs bi+i = bsl Bs bj+j → bi = bj := by
  intro Bs
  induction Bs with
  | nil => intro bi bj b c left; simp at left
  | cons first rest ih =>
    intro bi bj b c left right i j il jl same
    cases bi with
    | zero =>
      simp only [List.getElem?_cons_zero,Option.some.injEq] at left
      subst b
      cases bj with
      | zero => rfl
      | succ bj =>
        rw [bsl_zero,bsl_cons] at same
        omega
    | succ bi =>
      cases bj with
      | zero =>
        simp only [List.getElem?_cons_zero,Option.some.injEq] at right
        subst c
        rw [bsl_cons,bsl_zero] at same
        omega
      | succ bj =>
        simp only [List.getElem?_cons_succ] at left right
        rw [bsl_cons,bsl_cons] at same
        have equal : bsl rest bi+i = bsl rest bj+j := by omega
        exact congrArg Nat.succ (ih left right i j il jl equal)
private theorem writes_keep (xs : List (Nat × Nat)) {a : Array Nat} {key value : Nat}
    (before : a[key]? = some value)
    (same : ∀ p ∈ xs,p.1 = key → p.2 = value) :
    (xs.foldl (fun a p => a.set! p.1 p.2) a)[key]? = some value := by
  induction xs generalizing a with
  | nil => exact before
  | cons p xs ih =>
    apply ih ?_ (fun q member => same q (List.mem_cons_of_mem _ member))
    by_cases equal : p.1 = key
    · have inside := (Array.getElem?_eq_some_iff.mp before).1
      simp only [Array.set!_eq_setIfInBounds,Array.getElem?_setIfInBounds,if_pos equal,equal,if_pos inside,
        same p (List.mem_cons_self ..) equal,ite_true]
    · simpa only [Array.set!_eq_setIfInBounds,Array.getElem?_setIfInBounds,if_neg equal] using before
private theorem writes_hit (xs : List (Nat × Nat)) {a : Array Nat} {key value : Nat}
    (inside : key < a.size) (member : (key,value) ∈ xs)
    (same : ∀ p ∈ xs,p.1 = key → p.2 = value) :
    (xs.foldl (fun a p => a.set! p.1 p.2) a)[key]? = some value := by
  induction xs generalizing a with
  | nil => cases member
  | cons p xs ih =>
    change (xs.foldl (fun a p => a.set! p.1 p.2) (a.set! p.1 p.2))[key]? = some value
    by_cases equal : p.1 = key
    · apply writes_keep xs ?_ (fun q member => same q (List.mem_cons_of_mem _ member))
      simp only [Array.set!_eq_setIfInBounds,Array.getElem?_setIfInBounds,if_pos equal,equal,if_pos inside,
        same p (List.mem_cons_self ..) equal,ite_true]
    · apply ih (by simpa using inside) ?_ (fun q member => same q (List.mem_cons_of_mem _ member))
      rcases List.mem_cons.mp member with first | tail
      · exact False.elim (equal (congrArg Prod.fst first.symm))
      · exact tail
private theorem writes_ne (xs : List (Nat × Nat)) {a : Array Nat} {key value : Nat}
    (before : a[key]? ≠ some value)
    (never : ∀ p ∈ xs,p.1 = key → p.2 ≠ value) :
    (xs.foldl (fun a p => a.set! p.1 p.2) a)[key]? ≠ some value := by
  induction xs generalizing a with
  | nil => exact before
  | cons p xs ih =>
    apply ih ?_ (fun q member => never q (List.mem_cons_of_mem _ member))
    simp only [Array.set!_eq_setIfInBounds,Array.getElem?_setIfInBounds]
    by_cases equal : p.1 = key
    · rw [if_pos equal]
      split
      · exact fun h => never p (List.mem_cons_self ..) equal (Option.some.inj h)
      · exact fun h => by cases h
    · rw [if_neg equal]
      exact before
private theorem write_owner {f : Clif.Function} {ctx : Ctx} {ranges : Array (Nat × Nat)} {st0 : LState}
    (sp : CtxSpec f ctx ranges st0) {key owner : Nat} (member : (key,owner) ∈ sourceIndexWrites ctx ranges) :
    ∃ b j,f.blocks[owner]? = some b ∧ j ≤ b.body.length ∧ key = blockStart f owner+j := by
  obtain ⟨b,block,alternative⟩ := sourceIndexWrites_mem.mp member
  rw [sp.func] at block
  have range : ranges[owner]! = (blockStart f owner,blockStart f owner+b.body.length+1) := by
    simp only [getElem!_def,sp.ranges owner b block,Option.getD_some]
  rcases alternative with body | terminal
  · obtain ⟨j,inside,keyEq⟩ := body
    rw [range] at keyEq
    exact ⟨b,j,block,Nat.le_of_lt inside,keyEq⟩
  · rw [range] at terminal
    exact ⟨b,b.body.length,block,Nat.le_refl _,by simpa using terminal⟩
private theorem at_slot {f : Clif.Function} {ctx : Ctx} {ranges : Array (Nat × Nat)} {st0 : LState}
    (sp : CtxSpec f ctx ranges st0) {bi : Nat} {b : Clif.Block} (block : f.blocks[bi]? = some b)
    {j : Nat} (inside : j ≤ b.body.length) :
    (sourceMetadata ctx ranges).instBlock[blockStart f bi+j]? = some bi := by
  have range : ranges[bi]! = (blockStart f bi,blockStart f bi+b.body.length+1) := by
    simp only [getElem!_def,sp.ranges bi b block,Option.getD_some]
  have member : (blockStart f bi+j,bi) ∈ sourceIndexWrites ctx ranges := by
    apply sourceIndexWrites_mem.mpr
    refine ⟨b,by rw [sp.func]; exact block,?_⟩
    by_cases below : j < b.body.length
    · exact .inl ⟨j,below,by rw [range]⟩
    · have equal : j = b.body.length := by omega
      exact .inr (by rw [range,equal]; simp)
  have bound : blockStart f bi+j < ctx.insts.size := by
    have terminal := sp.facts.term bi b block
    have last := (Array.getElem?_eq_some_iff.mp terminal).1
    omega
  rw [sourceMetadata_instBlock_writes]
  apply writes_hit _ (by simpa using bound) member
  intro p present same
  obtain ⟨other,k,atBlock,offset,position⟩ := write_owner sp present
  have inSame : p.2 = bi := by
    apply interval_unique f.blocks atBlock block k j offset inside
    simpa only [← blockStart_eq] using position.symm.trans same
  exact inSame
/-- ORIGINAL successful context construction gives the correct label at EVERY
real body and terminator slot of the ACTUAL metadata constructor. -/
theorem sourceMetadata_instBlock_at {f : Clif.Function} {ctx : Ctx} {ranges : Array (Nat × Nat)} {st0 : LState}
    (build : Backend.buildCtx f = .ok (ctx,ranges,st0)) {bi : Nat} {b : Clif.Block}
    (block : f.blocks[bi]? = some b) {j : Nat} (inside : j ≤ b.body.length) :
    (sourceMetadata ctx ranges).instBlock[blockStart f bi+j]? = some bi :=
  at_slot (ctxSpec_of build) block inside
private theorem before_slot {f : Clif.Function} {ctx : Ctx} {ranges : Array (Nat × Nat)} {st0 : LState}
    (sp : CtxSpec f ctx ranges st0) {bi : Nat} {b : Clif.Block} (block : f.blocks[bi]? = some b)
    {key : Nat} (earlier : key < blockStart f bi) :
    (sourceMetadata ctx ranges).instBlock[key]? ≠ some bi := by
  rw [sourceMetadata_instBlock_writes]
  apply writes_ne
  · simp only [Array.getElem?_replicate]
    split
    · intro equality
      have zero : bi = 0 := (Option.some.inj equality).symm
      simp only [zero,blockStart,List.take_zero,List.map_nil,List.sum_nil] at earlier
      omega
    · intro equality; cases equality
  · intro p member keyEq valueEq
    obtain ⟨other,k,atBlock,offset,position⟩ := write_owner sp member
    rw [valueEq] at atBlock position
    have same : other = b := Option.some.inj (atBlock.symm.trans block)
    subst other
    have lower : blockStart f bi ≤ key := by
      rw [← keyEq,position]
      exact Nat.le_add_right _ _
    exact (Nat.not_le_of_gt earlier) lower
/-- For EVERY original source block, the actual constructor's first matching
label is exactly its canonical start, including empty bodies and block0. -/
theorem sourceMetadata_instBlock_find {f : Clif.Function} {ctx : Ctx} {ranges : Array (Nat × Nat)} {st0 : LState}
    (build : Backend.buildCtx f = .ok (ctx,ranges,st0)) {bi : Nat} {b : Clif.Block}
    (block : f.blocks[bi]? = some b) :
    (sourceMetadata ctx ranges).instBlock.findIdx? (· == bi) = some (blockStart f bi) := by
  have sp := ctxSpec_of build
  have first := at_slot sp block (Nat.zero_le b.body.length)
  simp only [Nat.add_zero] at first
  have inside := (Array.getElem?_eq_some_iff.mp first).1
  have label := (Array.getElem?_eq_some_iff.mp first).2
  apply Array.findIdx?_eq_some_iff_getElem.mpr
  refine ⟨inside,?_,?_⟩
  · simp only [label,beq_self_eq_true]
  · intro key earlier hit
    apply before_slot sp block earlier
    have equal := beq_iff_eq.mp hit
    simp only [Array.getElem?_eq_getElem (Nat.lt_trans earlier inside),equal]
end Backend.Stock.Proof.SourceIndexLookupDraft
