import FV.Backend.Proof.StockContext
namespace Backend.Stock.Proof.SourceIndexModelDraft
open Backend.Proof Backend.Proof.Driver
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private abbrev BodyAcc := Array Nat × Array Nat × Array (List Nat) × Nat
private abbrev BlockAcc := Array Nat × Array Nat × Array Nat × Array (List Nat) × Nat
private def bodyStep (start bi : Nat) (item : Clif.Stmt × Nat) (acc : BodyAcc) : Id (ForInStep BodyAcc) := do
  let (stm,j) := item
  let (blocks,colors,args,color) := acc
  let i := start+j
  let blocks := blocks.set! i bi
  let args := args.set! i (instArgs stm.inst)
  if colored stm.inst then
    pure (.yield (blocks,colors.set! i color,args,color+1))
  else pure (.yield (blocks,colors,args,color))
private def blockStep (ranges : Array (Nat × Nat)) (item : Clif.Block × Nat) (acc : BlockAcc) : Id (ForInStep BlockAcc) := do
  let (b,bi) := item
  let (blocks,colors,ends,args,color) := acc
  let (start,stop) := ranges[bi]!
  let (blocks,colors,args,color) ← forIn b.body.zipIdx (blocks,colors,args,color+1) (bodyStep start bi)
  pure (.yield (blocks.set! (stop-1) bi,colors.set! (stop-1) color,ends.push (color+1),
    args.set! (stop-1) (termArgs b.term),color+1))
private theorem forIn_project {α β γ : Type} (project : α → γ) (step : β → α → Id (ForInStep α))
    (update : γ → β → γ)
    (keeps : ∀ x a,∃ next,step x a = .yield next ∧ project next = update (project a) x)
    (xs : List β) (a : α) : project (forIn xs a step) = xs.foldl update (project a) := by
  induction xs generalizing a with
  | nil => rfl
  | cons x xs ih =>
    obtain ⟨next,called,framed⟩ := keeps x a
    rw [List.forIn_cons,called]
    change project (forIn xs next step) = xs.foldl update (update (project a) x)
    rw [← framed]
    exact ih next
private theorem body_keeps (start bi : Nat) (item : Clif.Stmt × Nat) (acc : BodyAcc) :
    ∃ next,bodyStep start bi item acc = .yield next ∧ next.1 = acc.1.set! (start+item.2) bi := by
  rcases item with ⟨stm,j⟩
  rcases acc with ⟨blocks,colors,args,color⟩
  unfold bodyStep
  dsimp only
  split <;> exact ⟨_,rfl,rfl⟩
private def blockUpdate (ranges : Array (Nat × Nat)) (blocks : Array Nat) (item : Clif.Block × Nat) : Array Nat :=
  ((item.1.body.zipIdx).foldl (fun a item' => a.set! (ranges[item.2]!.1+item'.2) item.2) blocks).set! (ranges[item.2]!.2-1) item.2
private theorem block_keeps (ranges : Array (Nat × Nat)) (item : Clif.Block × Nat) (acc : BlockAcc) :
    ∃ next,blockStep ranges item acc = .yield next ∧ next.1 = blockUpdate ranges acc.1 item := by
  rcases item with ⟨b,bi⟩
  rcases acc with ⟨blocks,colors,ends,args,color⟩
  let body := forIn b.body.zipIdx (blocks,colors,args,color+1) (bodyStep ranges[bi]!.1 bi)
  have projection := forIn_project (fun a : BodyAcc => a.1) (bodyStep ranges[bi]!.1 bi)
    (fun a item => a.set! (ranges[bi]!.1+item.2) bi) (body_keeps ranges[bi]!.1 bi)
    b.body.zipIdx (blocks,colors,args,color+1)
  refine ⟨(body.1.set! (ranges[bi]!.2-1) bi,body.2.1.set! (ranges[bi]!.2-1) body.2.2.2,
    ends.push (body.2.2.2+1),body.2.2.1.set! (ranges[bi]!.2-1) (termArgs b.term),body.2.2.2+1),?_,?_⟩
  · rfl
  · exact congrArg (fun a => a.set! (ranges[bi]!.2-1) bi) projection
/-- A pure index-table model of the ACTUAL sourceMetadata writes: every body
instruction is labelled, followed by its terminator. Color and operand tables
are projected out, not changed or assumed by the caller. -/
def sourceIndexTable (ctx : Ctx) (ranges : Array (Nat × Nat)) : Array Nat :=
  ctx.func.blocks.zipIdx.foldl (blockUpdate ranges) (Array.replicate ctx.insts.size 0)
/-- The actual constructor's instruction-to-block table is exactly its pure
write model, for arbitrary contexts and ranges; no new acceptance conditions. -/
theorem sourceMetadata_instBlock_model (ctx : Ctx) (ranges : Array (Nat × Nat)) :
    (sourceMetadata ctx ranges).instBlock = sourceIndexTable ctx ranges := by
  have projection := forIn_project (fun a : BlockAcc => a.1) (blockStep ranges) (blockUpdate ranges)
    (block_keeps ranges) ctx.func.blocks.zipIdx
    (Array.replicate ctx.insts.size 0,Array.replicate ctx.insts.size 0,#[],Array.replicate ctx.insts.size [],0)
  exact projection
private def blockWrites (ranges : Array (Nat × Nat)) (item : Clif.Block × Nat) : List (Nat × Nat) :=
  item.1.body.zipIdx.map (fun x => (ranges[item.2]!.1+x.2,item.2)) ++ [(ranges[item.2]!.2-1,item.2)]
/-- The exact ordered index writes performed by sourceMetadata. -/
def sourceIndexWrites (ctx : Ctx) (ranges : Array (Nat × Nat)) : List (Nat × Nat) :=
  ctx.func.blocks.zipIdx.flatMap (blockWrites ranges)
private theorem trace_fold (ranges : Array (Nat × Nat)) (items : List (Clif.Block × Nat)) (a : Array Nat) :
    items.foldl (blockUpdate ranges) a =
      (items.flatMap (blockWrites ranges)).foldl (fun a p => a.set! p.1 p.2) a := by
  induction items generalizing a with
  | nil => rfl
  | cons item items ih =>
    simp only [List.foldl_cons,List.flatMap_cons,List.foldl_append]
    rw [ih]
    congr 1
    simp only [blockUpdate,blockWrites,List.foldl_append,List.foldl_cons,List.foldl_nil,List.foldl_map]
/-- The real table constructor equals its exact ordered write trace. -/
theorem sourceMetadata_instBlock_writes (ctx : Ctx) (ranges : Array (Nat × Nat)) :
    (sourceMetadata ctx ranges).instBlock =
      (sourceIndexWrites ctx ranges).foldl (fun a p => a.set! p.1 p.2) (Array.replicate ctx.insts.size 0) := by
  rw [sourceMetadata_instBlock_model]
  exact trace_fold ranges ctx.func.blocks.zipIdx _
/-- Membership in the exact write trace identifies a real source body index
or its block's real terminator index, with the actual block owner. -/
theorem sourceIndexWrites_mem {ctx : Ctx} {ranges : Array (Nat × Nat)} {key owner : Nat} :
    (key,owner) ∈ sourceIndexWrites ctx ranges ↔
      ∃ b,ctx.func.blocks[owner]? = some b ∧
        ((∃ j,j < b.body.length ∧ key = ranges[owner]!.1+j) ∨ key = ranges[owner]!.2-1) := by
  constructor
  · intro member
    obtain ⟨⟨b,bi⟩,blocks,written⟩ := List.mem_flatMap.mp member
    have block := List.mk_mem_zipIdx_iff_getElem?.mp blocks
    simp only [blockWrites,List.mem_append,List.mem_map,List.mem_singleton] at written
    rcases written with ⟨⟨stm,j⟩,statement,equality⟩ | equality
    · have atStmt := List.mk_mem_zipIdx_iff_getElem?.mp statement
      obtain ⟨keyEq,ownerEq⟩ := Prod.mk.inj equality
      try dsimp only at keyEq ownerEq
      subst bi
      exact ⟨b,block,.inl ⟨j,(List.getElem?_eq_some_iff.mp atStmt).1,keyEq.symm⟩⟩
    · obtain ⟨keyEq,ownerEq⟩ := Prod.mk.inj equality
      try dsimp only at keyEq ownerEq
      subst bi
      exact ⟨b,block,.inr keyEq⟩
  · rintro ⟨b,block,body | terminal⟩
    · obtain ⟨j,inside,rfl⟩ := body
      let stm := b.body[j]
      refine List.mem_flatMap.mpr ⟨(b,owner),List.mk_mem_zipIdx_iff_getElem?.mpr block,?_⟩
      apply List.mem_append_left
      exact List.mem_map.mpr ⟨(stm,j),List.mk_mem_zipIdx_iff_getElem?.mpr (List.getElem?_eq_getElem inside),rfl⟩
    · subst key
      refine List.mem_flatMap.mpr ⟨(b,owner),List.mk_mem_zipIdx_iff_getElem?.mpr block,?_⟩
      exact List.mem_append_right _ (List.mem_singleton_self _)
end Backend.Stock.Proof.SourceIndexModelDraft
