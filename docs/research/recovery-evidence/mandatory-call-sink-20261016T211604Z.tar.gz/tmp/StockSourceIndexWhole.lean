import StockSourceIndexLookup
import StockTryIndexWhole
namespace Backend.Stock.Proof.SourceIndexWholeDraft
open Backend.Proof Backend.Proof.Driver SourceIndexModelDraft SourceIndexLookupDraft TryIndexWholeDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private theorem built_metadata {f : Clif.Function} {ctx : Ctx} {ranges : Array (Nat × Nat)} {initial : State}
    (build : Stock.buildCtx f = .ok (ctx,ranges,initial)) :
    ∃ original st0,Backend.buildCtx f = .ok (original,ranges,st0) ∧
      initial.instBlock = (sourceMetadata original ranges).instBlock := by
  obtain ⟨original,st0,requests,oldBuild,requestRun,same⟩ := buildCtx_allocation build
  exact ⟨original,st0,oldBuild,congrArg (fun q : Ctx × Array (Nat × Nat) × State => q.2.2.instBlock) same⟩
/-- The ACTUAL original Stock build labels every source body/terminator slot. -/
theorem stock_buildCtx_instBlock_at {f : Clif.Function} {ctx : Ctx} {ranges : Array (Nat × Nat)} {initial : State}
    (build : Stock.buildCtx f = .ok (ctx,ranges,initial)) {bi : Nat} {b : Clif.Block}
    (block : f.blocks[bi]? = some b) {j : Nat} (inside : j ≤ b.body.length) :
    initial.instBlock[blockStart f bi+j]? = some bi := by
  obtain ⟨original,st0,oldBuild,metadata⟩ := built_metadata build
  rw [metadata]
  exact sourceMetadata_instBlock_at oldBuild block inside
/-- EVERY real source block's actual initial metadata first match is its
canonical start, derived from successful original Stock context construction. -/
theorem stock_buildCtx_instBlock_find {f : Clif.Function} {ctx : Ctx} {ranges : Array (Nat × Nat)} {initial : State}
    (build : Stock.buildCtx f = .ok (ctx,ranges,initial)) {bi : Nat} {b : Clif.Block}
    (block : f.blocks[bi]? = some b) : initial.instBlock.findIdx? (· == bi) = some (blockStart f bi) := by
  obtain ⟨original,st0,oldBuild,metadata⟩ := built_metadata build
  rw [metadata]
  exact sourceMetadata_instBlock_find oldBuild block
private theorem built_func {f : Clif.Function} {ctx : Ctx} {ranges : Array (Nat × Nat)} {initial : State}
    (build : Stock.buildCtx f = .ok (ctx,ranges,initial)) : ctx.func = f := by
  obtain ⟨original,st0,oldBuild,sp,view⟩ := buildCtx_source build
  exact view.func.trans sp.func
/-- An actual original-node pre-state queries precisely the canonical source
terminator's reservation slot. Both the node run and the equality are derived
from original lowering; no dynamic lookup/layout certificate is accepted. -/
theorem stock_lower_original_reservation_slot {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) {label bi : Nat} {b : Clif.Block}
    (tag : result.order.nodes[label]? = some (.original bi)) (block : f.blocks[bi]? = some b) :
    ∃ (ranges : Array (Nat × Nat)) (params : List Nat) (input output : DriverState),
      Stock.buildCtx f = .ok (result.ctx,ranges,result.initial) ∧
      lowerNode result.ctx ranges result.order f params label input = .ok output ∧
      input.state.instBlock = result.initial.instBlock ∧ input.state.tryRegs = result.initial.tryRegs ∧
      input.state.instBlock.findIdx? (· == bi) = some (blockStart f bi) ∧
      input.state.tryRegs[(input.state.instBlock.findIdx? (· == bi)).getD 0 + result.ctx.func.blocks[bi]!.body.length]! =
        result.initial.tryRegs[blockStart f bi+b.body.length]! := by
  obtain ⟨ranges,params,input,output,build,metadata,reservations,node⟩ := stock_lower_original_node_metadata run tag
  have query : input.state.instBlock.findIdx? (· == bi) = some (blockStart f bi) := by
    rw [metadata]
    exact stock_buildCtx_instBlock_find build block
  refine ⟨ranges,params,input,output,build,node,metadata,reservations,query,?_⟩
  have source : result.ctx.func.blocks[bi]! = b := by simp only [built_func build,getElem!_def,block]
  rw [query,Option.getD_some,source,reservations]
/-- Actual synthetic-edge collection queries the SAME original source terminal
reservation as its call, for every source block including nonzero/empty ones.
The actual resolved vector is retained for subsequent .val/.ret composition. -/
theorem stock_lower_critical_reservation_slot {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) {label pred index target : Nat} {b : Clif.Block}
    (tag : result.order.nodes[label]? = some (.edge pred index target)) (block : f.blocks[pred]? = some b) :
    ∃ (ranges : Array (Nat × Nat)) (input next : State) (args : Array Reg),
      Stock.buildCtx f = .ok (result.ctx,ranges,result.initial) ∧
      branchArgs result.ctx input pred index = .ok (args,next) ∧
      input.instBlock = result.initial.instBlock ∧ input.tryRegs = result.initial.tryRegs ∧
      input.instBlock.findIdx? (· == pred) = some (blockStart f pred) ∧
      input.tryRegs[(input.instBlock.findIdx? (· == pred)).getD 0 + result.ctx.func.blocks[pred]!.body.length]! =
        result.initial.tryRegs[blockStart f pred+b.body.length]! ∧
      result.edgeArgs[label]? = some #[args.map
        (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1))] := by
  obtain ⟨ranges,input,next,args,build,call,metadata,reservations,after,sameSlot,stored⟩ :=
    stock_lower_critical_argument_metadata run tag
  have query : input.instBlock.findIdx? (· == pred) = some (blockStart f pred) := by
    rw [metadata]
    exact stock_buildCtx_instBlock_find build block
  refine ⟨ranges,input,next,args,build,call,metadata,reservations,query,?_,stored⟩
  have source : result.ctx.func.blocks[pred]! = b := by simp only [built_func build,getElem!_def,block]
  rw [query,Option.getD_some,source,reservations]
end Backend.Stock.Proof.SourceIndexWholeDraft
