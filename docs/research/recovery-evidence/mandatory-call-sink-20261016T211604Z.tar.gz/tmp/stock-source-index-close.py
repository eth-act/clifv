from pathlib import Path
import json,hashlib,re,datetime,tarfile,shutil
root=Path('/home/lee/clifv/.worktrees/driver-proof-resume');docs=root/'docs/research'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
now=datetime.datetime.now(datetime.timezone.utc);stamp=now.strftime('%Y%m%dT%H%M%SZ')
batch=json.loads(Path('/tmp/stock-source-index-batch.json').read_text());old=json.loads((docs/'stock-try-metadata-scratch.json').read_text())
log=Path('/tmp/stock-source-index-combined-axioms.log').read_text()
sets={m.group(1):sorted(x.strip() for x in m.group(2).split(',') if x.strip()) for m in re.finditer(r"'([^']+)' depends on axioms:\s*\[([^]]*)\]",log)}
for m in re.finditer(r"'([^']+)' does not depend on any axioms",log):sets[m.group(1)]=[]
for n,a in old['normal_audit']['sets'].items():assert sorted(a)==sets[n],n
assert len(sets)==len(old['normal_audit']['sets'])+len(batch['public_roots'])+len(batch['models'])
allowed={'propext','Classical.choice','Quot.sound'}
for n in batch['public_roots']+batch['models']:assert set(sets[n])<=allowed,n
constants=[json.loads(line.split('DELIVERY_CONSTANT ',1)[1]) for line in Path('/tmp/stock-source-index-all-constants.log').read_text().splitlines() if line.startswith('DELIVERY_CONSTANT ')]
assert constants
for n,a in constants:assert set(a)<=allowed,n
mods={}
for m in batch['modules']:
 p=Path('/tmp')/m;check=json.loads(p.with_suffix('.check.json').read_text());assert check['actual_exit']==0
 rec={}
 for key,ext in [('source','.lean'),('object','.olean'),('log','.log'),('check','.check.json')]:
  f=p.with_suffix(ext);rec[key]=str(f);rec[key+'_sha256']=sha(f)
 for k in ['source','object','log']:assert rec[k+'_sha256']==check[k+'_sha256']
 assert not re.search(r'\b(sorry|admit|axiom|trace_state|native_decide)\b',p.with_suffix('.lean').read_text()),m
 mods[m]=rec
for audit in ['stock-source-index-combined-axioms','stock-source-index-all-constants']:
 p=Path('/tmp')/audit;check=json.loads(p.with_suffix('.check.json').read_text());assert check['actual_exit']==0
 for k,ext in [('source','.lean'),('object','.olean'),('log','.log')]:assert sha(p.with_suffix(ext))==check[k+'_sha256']
prior={}
for name in ['source-execution-x','try-source','try-context','try-rule','try-rets','try-reservation','try-outgoing','try-values','try-emitted','try-machine','try-got','try-indirect','try-rename','try-resolved','try-gap','try-got-rename','try-normal-frame','try-metadata']:
 d=json.loads((docs/f'stock-{name}-scratch.json').read_text())
 for m,rec in d['modules'].items():
  for k in ['source','object','log']:assert sha(rec[k])==rec[k+'_sha256'],(m,k)
  prior[m]=rec
freeze=json.loads(Path('/tmp/stock-coherent-build-inputs.json').read_text())
for group in ['source_sha256','validation_script_sha256']:
 for p,h in freeze[group].items():assert sha(root/p)==h,p
progress=json.loads(Path('/tmp/stock-pr246-gates-progress.json').read_text());progress.pop('completed_phases',None)
remaining=old['remaining_checklist']
for item in remaining:
 if item['requirement']=='Actual instruction-to-block metadata framing at helpers/scans/blocks/nodes/traversal and outgoing collection':
  item['state']='Proved and completely witnessed. General initial sourceMetadata canonical slot labels and first-match correctness now also proved for ALL blocks/empty bodies from original buildCtx, with actual original/critical reservation queries connected to canonical terminal slots. Remaining actual .val/.ret outgoing value vector, machine source/reserved-write frame and normal parameter-copy/continuation composition stay open.'
remaining.append({'requirement':'Original sourceMetadata canonical block labels/first-match lookup and actual whole-driver reservation query','state':'Proved: actual nested constructor projects exactly to ordered body/terminator writes. Original buildCtx ranges give unique disjoint block intervals, every body/terminal label and no same-owner label before its start; actual findIdx equals blockStart for EVERY block including zero/nonzero/empty bodies. Original Stock.buildCtx derives these facts internally; actual original-node and critical collection queries select the canonical source terminal reservation, keeping their actual runs/resolved vectors. Complete near/GOT/true-indirect all-block and nonidentity one-arg critical compiler/prepare/fallback/checker/physical witnesses pass. Actual .val/.ret outgoing value transfer and machine noninterference/normal copies/whole simulation/completeness remain open.'})
counts={'modules':len(mods),'public_roots':len(batch['public_roots']),'models':len(batch['models']),'combined_roots_models':len(sets),'previous_preserved':len(old['normal_audit']['sets']),'all_new_module_constants':len(constants),'previous_modules_hashes_preserved':len(prior)}
receipt={'utc':now.isoformat(),'goal':'Original full #140 ACTIVE/INCOMPLETE; production LEGACY','scope':'Scratch-only additive Stock proofs, not coherent integration or merge-ready','delivery_target':'roughly eight substantive validated squash merges/day; prioritize landing coherent backlog, remote backups and cleanup; drafts do not count','modules':mods,'public_roots':batch['public_roots'],'models':batch['models'],'counts':counts,'normal_audit':{'path':'/tmp/stock-source-index-combined-axioms.log','sha256':sha('/tmp/stock-source-index-combined-axioms.log'),'sets':sets},'all_constant_audit':{'path':'/tmp/stock-source-index-all-constants.log','sha256':sha('/tmp/stock-source-index-all-constants.log'),'all_standard_only':True,'count':len(constants)},'previous_modules_hashes_preserved':list(prior),'canonical2246_source_and_script_freeze_preserved':True,'kernel_resources':'All new modules and both audits actual exit0/object verified at8GiB through memcap; one heavy delivery worker retained','MCP':'No new calls; bundled audit deferred until coherent integration','active_exact_PR246_validation':progress,'remaining_checklist':remaining}
(docs/'stock-source-index-scratch.json').write_text(json.dumps(receipt,indent=2)+'\n')
text=f'''Original sourceMetadata canonical indices and reservation queries — {now.isoformat()}

Five scratch modules/11public roots/two pure models pass actual8GiB kernel checks. The {len(sets)}-root/model audit preserves all600prior exact axiom sets. All{len(constants)}new-module constants including private nested-loop/write/interval/fixture helpers use only standard axioms. All{len(prior)}previous scratch source/object/log hashes and frozen2246canonical sources plus49validation scripts remain unchanged. Prior turn PROGRESS: full instBlock mutation framing and actual critical collection tables/resolved vector, complete three-form/critical witnesses,600audit/337constants, verified59fa0e7 backup and2.8GBcleanup.

The ACTUAL sourceMetadata nested Id loops project exactly to the pure block-label table and exact ordered body/terminator write trace. Color/operand processing is projected out, not assumed or changed. Trace membership identifies a real block owner and source body or terminator slot. Original successful Backend.buildCtx supplies canonical ranges and real instruction bounds; block intervals are disjoint, actual writes cover every body/terminal slot with its real owner, and no earlier table entry bears that block label. Therefore actual findIdx(block)=blockStart for EVERY actual source block, including block0, nonzero blocks and empty bodies. No scope/numeric/table/membership/lookup assumption was added to accepted inputs.

Successful ORIGINAL Stock.buildCtx derives the same constructor facts internally from its original context. Actual original-node pre-states and critical-edge argument collection already retain initial metadata/reservations; composing those facts proves their DYNAMIC findIdx+body-length query selects exactly the original canonical terminator reservation. Both actual node/branchArgs runs and actual final-resolved returned vectors are retained. No caller dynamic-slot/layout/state/alias certificate is accepted. This closes the general initial lookup and reservation-query gap left by the prior batch.

Complete near/GOT/true-indirect compiler→prepareAt→forced checkedfallback→checker→physical fixtures exercise EVERY block's canonical start and EVERY body/terminator label, actual original-node queries, and explicit nonzero empty normal/handler blocks. Complete real critical-edge compiler/fallback/physical pipeline exercises a one-register outgoing vector, canonical terminal reservation query, real final resolution and NONIDENTITY193→192 source alias. Existing cached compiler/physical witnesses reused; no new cold heavy compiler build. Pure models and private operational/array proof definitions are included in normal/all-constant audits.

Next: use the SAME canonical reservation to prove actual normal outgoing .val/.ret vectors match the final-resolved call's returned values and inherited source values, then compose real parameter copies and normal continuation. Available-source/reserved-write machine noninterference remains OPEN; source-side synthetic result preservation and destination definedness are separate already-proved facts. Local direct/GOT/true-indirect final-renamed retained branch execution/world/results remain unchanged. Ordinary .val-only branch vector theorems cannot substitute for TryCall .ret composition.

ALL original exact shared payload endpoints/exception machine semantics, full zero-return/sret/x8/width/handler matrix (including actual TryCall critical paths), uncovered families/effects/sinking/source/block/whole-driver simulation AND completeness, original-input context/visitor/static/checker/fallback/physical totality, coherent scratch integration/MCP/public/private/compiler audits, full/crates/runtime/encoder/BOTH E2E identity-stage parity, actual production compiler/checker/linker/generated consumers and FRESH COMPLETE comparison remain mandatory. Full#140 ACTIVE/INCOMPLETE; production LEGACY. Shared S10 exceptional interfaces remain @kevaundray #232/#233.

Main rechecked0ec59a028dd3a27911cb22554b3e292b20a5c45f unchanged. Delivery246/247 remain drafts; same live3247835/exclusive shared warm-cache lease and deliberately held canonical1233457. Preserve old-head receipts, reconcile latest main and rerun required actual-head gates before dependent squash merges. Target roughly8substantive validated merges/day, semantic grouping, remote backups/cleanup. No new worktree/MCP/heavy retry/gate restart/merge this batch.

Hashed evidence/full remaining checklist: stock-source-index-scratch.json.
'''
(docs/'stock-source-index-scratch.md').write_text(text)
plan=root/'docs/plans/test-binary-alignment-recovery.md';plan.write_text(plan.read_text()+'\n\n'+text)
files=[]
for rec in mods.values():files.extend(Path(rec[k]) for k in ['source','object','log','check'])
for name in ['stock-source-index-combined-axioms','stock-source-index-all-constants']:
 for ext in ['.lean','.log','.olean','.check.json']:files.append(Path('/tmp')/(name+ext))
files.extend(Path(p) for p in ['/tmp/stock-source-index-batch.json','/tmp/stock-try-rule-inputs.json','/tmp/stock-try-reservation-check.py','/tmp/stock-source-index-close.py','/tmp/stock-source-index-make-audit.py','/tmp/StockSourceMetadataInspect.lean','/tmp/StockSourceMetadataInspect.olean','/tmp/StockSourceMetadataInspect.log','/tmp/StockSourceMetadataInspect.check.json','/tmp/stock-source-index-status44.json','/tmp/stock-source-index-status52.json','/tmp/stock-source-index-status71.json','/tmp/stock-source-index-task140.json'])
files.extend([docs/'stock-source-index-scratch.json',docs/'stock-source-index-scratch.md',docs/'stock-delivery-main-drift.json',plan])
archive=Path('/home/lee/.clifv-recovery')/(stamp+'-source-index')/'checkpoint.tar.gz';archive.parent.mkdir(parents=True)
with tarfile.open(archive,'w:gz',compresslevel=1) as t:
 for p in files:t.add(p,arcname=str(p).lstrip('/'),recursive=False)
with tarfile.open(archive,'r:gz') as t:
 for p in files:assert t.extractfile(str(p).lstrip('/')).read()==p.read_bytes(),p
snapshot=Path('/tmp/stock-try-rule-inputs');size=sum(p.stat().st_size for p in snapshot.rglob('*') if p.is_file());shutil.rmtree(snapshot)
backup={'utc':now.isoformat(),'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(files),'all_members_byte_verified':True,'previous_remote_backup':json.loads((docs/'stock-try-metadata-backup.json').read_text())['remote'],'cleanup':{'duplicate_dependency_snapshot_removed':True,'bytes_reclaimed':size,'unique_sources_objects_logs_checks_audits_preserved':True,'one_shared_warm_cache_retained':True,'other_projects_touched':False,'free_bytes':shutil.disk_usage(root).free}}
(docs/'stock-source-index-backup.json').write_text(json.dumps(backup,indent=2)+'\n');Path('/tmp/stock-source-index-archive-path').write_text(str(archive))
print(json.dumps({'counts':counts,'archive':str(archive),'cleanup':backup['cleanup'],'gate':progress},indent=2))
