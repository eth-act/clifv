import FV.Backend.Proof.StockRotateSemantics
import FV.Backend.Proof.StockValues
import FV.Backend.Proof.IselFamALUAExtr
import FV.Backend.Proof.StockLogicalForms
import FV.Backend.Proof.IselTermsALUAExtr

namespace Backend.Stock.Proof.LogicalExtr
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000

private theorem fresh_reg {aliases : Array (Option Nat)} {d : Nat} (bounded : aliases.size ≤ d) :
    Backend.lowerFunction.resolve aliases (aliases.size+1) (.vreg d .int) = .vreg d .int := by
  rw [resolve_vreg]
  have fresh : aliasNum aliases d = d := by
    apply chaseF_none
    rw [Array.getElem?_eq_none bounded]
    rfl
  change Reg.vreg (aliasNum aliases d) .int = _
  rw [fresh]

/-- A two-input EXTR uses original values through final aliases and writes
only its fresh destination. The concatenated inputs need not be equal. -/
theorem extr_resolved {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem}
    (refines : Refines F isem) {ty : Clif.Ty} (width : ty.width = 32 ∨ ty.width = 64)
    {aliases : Array (Option Nat)} {ρ : Nat → CV} {d x y X : Nat} {sh : ShiftOpAndAmt}
    (bounded : aliases.size ≤ d) (sum : X + sh.amt = ty.width) (count : sh.amt < ty.width)
    {u v : BitVec ty.width} (heldX : VHolds ⟨ty,u⟩ (ρ (aliasNum aliases x)))
    (heldY : VHolds ⟨ty,v⟩ (ρ (aliasNum aliases y))) :
    ∃ ρ', PRun F isem
      [(MInst.aluRRRShift .extr (szOf ty.width) (.vreg d .int) (.vreg x .int)
        (.vreg y .int) sh).mapRegs (Backend.lowerFunction.resolve aliases (aliases.size+1))] ρ ρ' ∧
      VHolds ⟨ty,(u <<< X) ||| (v >>> sh.amt)⟩ (ρ' d) ∧ ∀ n,n ≠ d → ρ' n = ρ n := by
  have bits : (szOf ty.width).bits = ty.width := by
    rcases width with h | h <;> simp [szOf,h,OperandSize.bits]
  have fits : sh.amt < (szOf ty.width).bits := by rwa [bits]
  let r := resX (szOf ty.width)
    (((opnd (szOf ty.width) (ρ (aliasNum aliases x)) ++
       opnd (szOf ty.width) (ρ (aliasNum aliases y))) >>> sh.amt).setWidth (szOf ty.width).bits)
  refine ⟨upd ρ d r,?_,?_,?_⟩
  · simp only [MInst.mapRegs]
    rw [fresh_reg bounded,resolve_vreg,resolve_vreg]
    exact prun_rrr refines (operands_aluRRRShift _ _ _ _ _ _)
      (fun _ => ispec_extr fits) (prun_nil _)
  · rw [upd_same]
    exact extr_holds width heldX heldY sum
  · intro n different
    simp only [upd,different,ite_false]

/-- Both source widths have actual executable instances for arbitrary, distinct
machine words and caller state, with the destination separate from the inputs. -/
theorem extr_resolved_witness (ty : Clif.Ty) (supported : ty = .i32 ∨ ty = .i64) (a b : CV) :
    let ρ : Nat → CV := fun n => if n = 0 then a else if n = 1 then b else 0
    ∃ ρ', PRun (fun _ => True) ispec
      [(MInst.aluRRRShift .extr (szOf ty.width) (.vreg 2 .int) (.vreg 0 .int)
        (.vreg 1 .int) ⟨.lsr,1⟩).mapRegs (Backend.lowerFunction.resolve #[] 1)] ρ ρ' ∧
      VHolds ⟨ty,(a.setWidth ty.width <<< (ty.width-1)) ||| (b.setWidth ty.width >>> 1)⟩ (ρ' 2) ∧
      ∀ n,n ≠ 2 → ρ' n = ρ n := by
  dsimp only
  have width : ty.width = 32 ∨ ty.width = 64 := by rcases supported with rfl | rfl <;> simp [Clif.Ty.width]
  have sum : ty.width-1+1 = ty.width := by rcases supported with rfl | rfl <;> decide
  have count : 1 < ty.width := by rcases supported with rfl | rfl <;> decide
  have self : Refines (fun _ => True) ispec := fun _ _ _ _ w' _ h => ⟨w',h,SameWorld.refl _ _⟩
  exact extr_resolved self width (aliases := #[]) (d := 2) (x := 0) (y := 1)
    (X := ty.width-1) (sh := ⟨.lsr,1⟩) (by decide) sum count (by rfl) (by rfl)

end Backend.Stock.Proof.LogicalExtr

namespace Backend.Stock.Proof.LogicalExtr
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
attribute [local irreducible] Isle.Aarch64.program

private theorem sem_ctor (ctx : Ctx) (t : Term) (vs : List V) (st : State) :
    (Stock.sem ctx).ctor t vs st = Stock.externCtor ctx t vs st := rfl
private theorem sem_mkData (ctx : Ctx) (t k : Nat) (vs : List V) :
    (Stock.sem ctx).mkData t k vs = .data t k vs := rfl
private theorem extr_shift_32 (ctx : Ctx) (st : State) (amount : Nat) :
    Stock.externCtor ctx T.a64_extr_imm [.ty (.int 32),.op (.immShift amount)] st =
      .ok (.op (.shiftOpAndAmt ⟨.lsl,amount⟩),st) := by
  rw [stock_ctor_baseOnly ctx T.a64_extr_imm _ st (by decide)]
  rfl
private theorem extr_shift_64 (ctx : Ctx) (st : State) (amount : Nat) :
    Stock.externCtor ctx T.a64_extr_imm [.ty (.int 64),.op (.immShift amount)] st =
      .ok (.op (.shiftOpAndAmt ⟨.lsr,amount⟩),st) := by
  rw [stock_ctor_baseOnly ctx T.a64_extr_imm _ st (by decide)]
  rfl
private theorem immediate_shift (ctx : Ctx) (st : State) {amount : Int} (fits : amount < 64) :
    Stock.externCtor ctx T.imm_shift_from_u8 [.int amount] st =
      .ok (.op (.immShift amount.toNat),st) := by
  rw [stock_ctor_baseOnly ctx T.imm_shift_from_u8 _ st (by decide),
    ctor_imm_shift_from_u8 ctx st.base fits]
private theorem output_run {p : Program} (hp : Data p) (ctx : Ctx) (st : State)
    (tr : Array RuleId) (n : Nat) (r : Reg) :
    (applyTerm p (Stock.sem ctx) {} (n+10) 25 172 [.reg r]).run (st,tr) =
      .ok (some (.regsVec [[r]]),st,tr.push rule_prelude_lower_105.id) := by
  have value : ∀ q,Stock.externCtor ctx T.value_reg [.reg r] q = .ok (.regs [r],q) := by
    intro q; rw [stock_ctor_baseOnly ctx T.value_reg _ q (by decide)]; rfl
  have output : ∀ q,Stock.externCtor ctx T.output [.regs [r]] q = .ok (.regsVec [[r]],q) := by
    intro q; rw [stock_ctor_baseOnly ctx T.output _ q (by decide)]; rfl
  cases hp
  isel_eval [*,rule_prelude_lower_105,sem_ctor]

def shiftFor (w amount : Nat) : ShiftOpAndAmt :=
  if w ≤ 32 then ⟨.lsl,amount⟩ else ⟨.lsr,amount⟩

/-- The real two-register EXTR helper preserves all Stock scheduling fields. -/
theorem helper_run {p : Program} (hp : Data p) (ctx : Ctx) {w : Nat}
    (width : w = 32 ∨ w = 64) (st : State) (tr : Array RuleId) (n : Nat)
    (rx ry : Reg) (amount : Nat) :
    (applyTerm p (Stock.sem ctx) {} (n+30) 27 515
      [.ty (.int w),.reg rx,.reg ry,.op (.immShift amount)]).run (st,tr) =
      .ok (some (.reg (st.base.fresh .int).1),
        {st with base := (st.base.fresh .int).2.emit (.aluRRRShift .extr (szOf w) (st.base.fresh .int).1 rx ry (shiftFor w amount))},
        ((tr.push (if w ≤ 32 then rule_inst_1592.id else rule_inst_1593.id)).push rule_inst_2656.id).push
          rule_inst_3487.id) := by
  have small : w ≤ 64 := by rcases width with rfl | rfl <;> decide
  have inner := fun q trace fuel sh => LogicalForms.stock_logical_shift_helper hp ctx (cfg := {})
    rfl small (k := 15) (op := .extr) rfl q trace fuel rx ry sh
  have ctor32 := fun q => extr_shift_32 ctx q amount
  have ctor64 := fun q => extr_shift_64 ctx q amount
  cases hp
  rcases width with rfl | rfl
  all_goals simp only [shiftFor,szOf,Nat.reduceLeDiff,ite_true,ite_false] at *
  all_goals isel_eval [*,rule_inst_3487,sem_mkData,sem_ctor]
  all_goals rfl

def extrRule (mirrored : Bool) : Rule := if mirrored then rule_lower_1507 else rule_lower_1501

def extrEnv (mirrored : Bool) (w x : Nat) (X : Int) (y : Nat) (Y : Int) : Isle.Interp.Env V :=
  if mirrored then env5 (.ty (.int w)) (.value y) (.int Y) (.value x) (.int X)
  else env5 (.ty (.int w)) (.value x) (.int X) (.value y) (.int Y)

/-- Both original fused-OR RHSs request only the underlying source words,
retain complete Stock scheduling state, and emit the actual EXTR instruction. -/
theorem rhs_forward {p : Program} (hp : Data p) (ctx : Ctx) (mirrored : Bool)
    {w x y : Nat} {X Y : Int} {rx ry : Reg}
    (mappedX : ctx.valueReg? x = some rx) (mappedY : ctx.valueReg? y = some ry)
    (width : w = 32 ∨ w = 64) (fits : Y < 64)
    (st : State) (safeX : DemandAllowed ctx st x) (safeY : DemandAllowed ctx st y)
    (tr : Array RuleId) (n : Nat) :
    ∃ trace,(evalExpr p (Stock.sem ctx) {} (n+60) (extrRule mirrored).rhs
      (extrEnv mirrored w x X y Y)).run (st,tr) =
      .ok (some (.regsVec [[(st.base.fresh .int).1]]),
        {(st.mark x).mark y with base := (st.base.fresh .int).2.emit (.aluRRRShift .extr (szOf w) (st.base.fresh .int).1 rx ry (shiftFor w Y.toNat))},trace) := by
  have requestX := stock_put_in_reg ctx st x rx mappedX safeX
  have requestY := stock_put_in_reg ctx (st.mark x) y ry mappedY safeY
  have shift := fun q => immediate_shift ctx q fits
  have helper := fun q trace fuel => helper_run hp ctx width q trace fuel rx ry Y.toNat
  have output := fun q trace fuel r => output_run hp ctx q trace fuel r
  cases hp
  cases mirrored with
  | false =>
    refine Exists.intro ?trace0 ?proof0
    case proof0 =>
      simp only [extrRule,extrEnv,Bool.false_eq_true,ite_true,ite_false]
      isel_eval [*,rule_lower_1501,sem_ctor]
      rfl
  | true =>
    refine Exists.intro ?trace1 ?proof1
    case proof1 =>
      simp only [extrRule,extrEnv,Bool.false_eq_true,ite_true,ite_false]
      isel_eval [*,rule_lower_1507,sem_ctor]
      rfl

/-- Successful actual RHS execution supplies both guarded source requests;
no caller-provided register map or scheduling certificate is needed. -/
theorem rhs_requests {p : Program} (hp : Data p) (ctx : Ctx) (mirrored : Bool)
    {w x y n : Nat} {X Y : Int} {st next : State} {tr trace : Array RuleId} {out : V}
    (run : (evalExpr p (Stock.sem ctx) {} (n+60) (extrRule mirrored).rhs
      (extrEnv mirrored w x X y Y)).run (st,tr) = .ok (some out,next,trace)) :
    DemandAllowed ctx st x ∧ DemandAllowed ctx st y ∧
      (∃ rx,ctx.valueReg? x = some rx) ∧ ∃ ry,ctx.valueReg? y = some ry := by
  cases hp
  cases mirrored
  all_goals
    isel_inv [*,extrRule,extrEnv,rule_lower_1501,rule_lower_1507,sem_ctor,stock_put_in_reg_iff] at run
    all_goals simp only [stock_put_in_reg_iff,ExtResult.ok.injEq,Prod.mk.injEq] at *
    all_goals isel_destruct <;> subst_vars
  all_goals
    exact ⟨‹DemandAllowed ctx st x›,‹DemandAllowed ctx (st.mark x) y›,
      ⟨_,‹ctx.valueReg? x = some _›⟩,⟨_,‹ctx.valueReg? y = some _›⟩⟩

/-- Actual success determines the complete output and marking/emission state.
Root match guards will supply the width and immediate facts. -/
theorem rhs_observed {p : Program} (hp : Data p) (ctx : Ctx) (mirrored : Bool)
    {w x y n : Nat} {X Y : Int} (width : w = 32 ∨ w = 64) (fits : Y < 64)
    {st next : State} {tr trace : Array RuleId} {out : V}
    (run : (evalExpr p (Stock.sem ctx) {} (n+60) (extrRule mirrored).rhs
      (extrEnv mirrored w x X y Y)).run (st,tr) = .ok (some out,next,trace)) :
    DemandAllowed ctx st x ∧ DemandAllowed ctx st y ∧
      ∃ rx ry,ctx.valueReg? x = some rx ∧ ctx.valueReg? y = some ry ∧
        out = .regsVec [[(st.base.fresh .int).1]] ∧
        next = {(st.mark x).mark y with base := (st.base.fresh .int).2.emit (.aluRRRShift .extr
          (szOf w) (st.base.fresh .int).1 rx ry (shiftFor w Y.toNat))} := by
  obtain ⟨safeX,safeY,⟨rx,mappedX⟩,ry,mappedY⟩ := rhs_requests hp ctx mirrored run
  obtain ⟨actualTrace,forward⟩ := rhs_forward hp ctx mirrored mappedX mappedY width fits st safeX safeY tr n
  rw [forward] at run
  simp only [Except.ok.injEq,Prod.mk.injEq,Option.some.injEq] at run
  obtain ⟨outEq,stateEq,_⟩ := run
  exact ⟨safeX,safeY,rx,ry,mappedX,mappedY,outEq.symm,stateEq.symm⟩

/-- Concrete mapped words inhabit both RHS routes and supported widths; the
source match/binding and complete-function witness remain separate obligations. -/
theorem rhs_witness (mirrored : Bool) (w : Nat) (width : w = 32 ∨ w = 64) :
    ∃ trace,(evalExpr program (Stock.sem sinkCtx) {} 60 (extrRule mirrored).rhs
      (extrEnv mirrored w 0 (w-1 : Nat) 1 1)).run (sinkState,#[]) =
      .ok (some (.regsVec [[(sinkState.base.fresh .int).1]]),
        {(sinkState.mark 0).mark 1 with base := (sinkState.base.fresh .int).2.emit (.aluRRRShift .extr (szOf w) (sinkState.base.fresh .int).1 (.vreg 192 .int)
            (.vreg 193 .int) (shiftFor w 1))},trace) := by
  have safe0 := stock_put_in_reg_witness.1
  have safe1 : DemandAllowed sinkCtx sinkState 1 := by
    intro i found
    change (none : Option Nat) = some i at found
    cases found
  exact rhs_forward data_program sinkCtx mirrored (w := w) (x := 0) (y := 1)
    (X := (w-1 : Nat)) (Y := 1) rfl rfl width (by decide) sinkState safe0 safe1 #[] 0

/-- Successful concrete runs inhabit the observation theorem for both mirrors
and source-compatible positive shifts summing to the supported width. -/
theorem rhs_observed_witness (mirrored : Bool) (w : Nat) (width : w = 32 ∨ w = 64) :
    DemandAllowed sinkCtx sinkState 0 ∧ DemandAllowed sinkCtx sinkState 1 ∧
      ∃ rx ry,sinkCtx.valueReg? 0 = some rx ∧ sinkCtx.valueReg? 1 = some ry ∧
        (.regsVec [[(sinkState.base.fresh .int).1]] : V) =
          .regsVec [[(sinkState.base.fresh .int).1]] ∧
        {(sinkState.mark 0).mark 1 with base := (sinkState.base.fresh .int).2.emit (.aluRRRShift .extr (szOf w) (sinkState.base.fresh .int).1 (.vreg 192 .int)
            (.vreg 193 .int) (shiftFor w 1))} =
        {(sinkState.mark 0).mark 1 with base := (sinkState.base.fresh .int).2.emit (.aluRRRShift .extr (szOf w) (sinkState.base.fresh .int).1 rx ry
            (shiftFor w (1 : Int).toNat))} := by
  obtain ⟨trace,run⟩ := rhs_witness mirrored w width
  exact rhs_observed data_program sinkCtx mirrored width (by decide) (n := 0) run

end Backend.Stock.Proof.LogicalExtr
namespace Backend.Stock.Proof.LogicalExtr
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000

/-- Actual RHS output, emitted instruction execution and source-word result,
with final aliases and the fresh-only write frame. -/
def ValueOut (F : BitVec 64 → Prop) (isem : Backend.Proof.Sem) (ty : Clif.Ty)
    (u v : BitVec ty.width) (X Y : Nat) (st next : State) (out : V)
    (aliases : Array (Option Nat)) (ρ : Nat → CV) : Prop :=
  ∃ (mi : MInst) (ρ' : Nat → CV),
    out = .regsVec [[.vreg st.base.nextVreg .int]] ∧
    next.base = (st.base.fresh .int).2.emit mi ∧
    PRun F isem [mi.mapRegs (Backend.lowerFunction.resolve aliases (aliases.size+1))] ρ ρ' ∧
    VHolds ⟨ty,(u <<< X) ||| (v >>> Y)⟩ (ρ' st.base.nextVreg) ∧
    ∀ z,z ≠ st.base.nextVreg → ρ' z = ρ z

private theorem marked (st : State) (x : Nat) (bound : x < st.demand.size) : Demanded (st.mark x) x := by
  rw [Demanded,(mark_demand st x bound).1]
  omega
private theorem twice_marked (st : State) (x y : Nat) (bx : x < st.demand.size) (by_ : y < st.demand.size) :
    Demanded ((st.mark x).mark y) x ∧ Demanded ((st.mark x).mark y) y := by
  have afterBound : y < (st.mark x).demand.size := by rw [(mark_demand st x bx).2.2]; exact by_
  exact ⟨(demanded_mark_iff (st.mark x) y x afterBound).mpr (Or.inr (marked st x bx)),
    marked (st.mark x) y afterBound⟩

/-- A successful actual EXTR RHS internally derives its integer mappings and
operand demands from the original held-values relation, then executes the real
two-word instruction. No caller-supplied register/request certificate is used. -/
theorem rhs_values {p : Program} (hp : Data p) {ctx : Ctx} (mirrored : Bool)
    {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem} (refines : Refines F isem)
    {ty : Clif.Ty} (width : ty.width = 32 ∨ ty.width = 64)
    {X Y : Int} (sum : X.toNat+Y.toNat = ty.width) (count : Y.toNat < ty.width)
    {x y n : Nat} {u v : BitVec ty.width} {fr : Clif.Frame}
    (sourceX : fr.getAs x ty = .ok u) (sourceY : fr.getAs y ty = .ok v)
    {st next : State} {out : V} {tr trace : Array RuleId}
    {aliases : Array (Option Nat)} {ρ : Nat → CV}
    (bounded : aliases.size ≤ st.base.nextVreg)
    (extent : ∀ z r,ctx.valueReg? z = some r → z < st.demand.size)
    (held : ValuesHeld (Demanded next) ctx fr (fun z => ρ (aliasNum aliases z)))
    (run : (evalExpr p (Stock.sem ctx) {} (n+60) (extrRule mirrored).rhs
      (extrEnv mirrored ty.width x X y Y)).run (st,tr) = .ok (some out,next,trace)) :
    ValueOut F isem ty u v X.toNat Y.toNat st next out aliases ρ := by
  have fits : Y < 64 := by rcases width with h | h <;> omega
  obtain ⟨safeX,safeY,rx,ry,mappedX,mappedY,outEq,stateEq⟩ := rhs_observed hp ctx mirrored width fits run
  have needed : Demanded next x ∧ Demanded next y := by
    rw [stateEq]
    exact twice_marked st x y (extent x rx mappedX) (extent y ry mappedY)
  obtain ⟨nx,mx,heldX⟩ := held x needed.1 ⟨ty,u⟩ (getAs_ok sourceX)
  obtain ⟨ny,my,heldY⟩ := held y needed.2 ⟨ty,v⟩ (getAs_ok sourceY)
  have rxEq := Option.some.inj (mappedX.symm.trans mx)
  have ryEq := Option.some.inj (mappedY.symm.trans my)
  subst rx ry
  have amount : (shiftFor ty.width Y.toNat).amt = Y.toNat := by unfold shiftFor; split <;> rfl
  obtain ⟨ρ',execution,value,kept⟩ := extr_resolved refines width
    (sh := shiftFor ty.width Y.toNat) bounded (by simpa only [amount] using sum)
    (by simpa only [amount] using count) heldX heldY
  refine ⟨.aluRRRShift .extr (szOf ty.width) (.vreg st.base.nextVreg .int)
    (.vreg nx .int) (.vreg ny .int) (shiftFor ty.width Y.toNat),ρ',outEq,?_,execution,?_,kept⟩
  · exact congrArg State.base stateEq
  · simpa only [amount] using value

end Backend.Stock.Proof.LogicalExtr

namespace Backend.Stock.Proof.LogicalExtr
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000

private def inputFrame (ty : Clif.Ty) (a b : CV) : Clif.Frame := {
  func := default
  regs := fun z => if z = 0 then some ⟨ty,a.setWidth ty.width⟩
    else if z = 1 then some ⟨ty,b.setWidth ty.width⟩ else none
  slots := []
  body := []
  term := .ret [] }
private def inputRF (a b : CV) : Nat → CV :=
  fun n => if n = 192 then a else if n = 193 then b else 0
private def afterRhs (w : Nat) : State :=
  {(sinkState.mark 0).mark 1 with base := (sinkState.base.fresh .int).2.emit (.aluRRRShift .extr
    (szOf w) (sinkState.base.fresh .int).1 (.vreg 192 .int) (.vreg 193 .int) (shiftFor w 1))}

/-- Actual successful RHSs at both source-compatible shifts inhabit the whole
value bridge for arbitrary independent machine words, at both widths and mirrors. -/
theorem rhs_values_witness (mirrored : Bool) (ty : Clif.Ty)
    (supported : ty = .i32 ∨ ty = .i64) (a b : CV) :
    ∃ trace,
      (evalExpr program (Stock.sem sinkCtx) {} 60 (extrRule mirrored).rhs
        (extrEnv mirrored ty.width 0 (ty.width-1 : Nat) 1 1)).run (sinkState,#[]) =
        .ok (some (.regsVec [[(sinkState.base.fresh .int).1]]),afterRhs ty.width,trace) ∧
      ValueOut (fun _ => True) ispec ty (a.setWidth ty.width) (b.setWidth ty.width)
        (ty.width-1) 1 sinkState (afterRhs ty.width)
        (.regsVec [[(sinkState.base.fresh .int).1]]) #[] (inputRF a b) := by
  have width : ty.width = 32 ∨ ty.width = 64 := by
    rcases supported with rfl | rfl <;> simp [Clif.Ty.width]
  obtain ⟨trace,run⟩ := rhs_witness mirrored ty.width width
  refine ⟨trace,run,?_⟩
  have sourceX : (inputFrame ty a b).getAs 0 ty = .ok (a.setWidth ty.width) := by
    simp [Clif.Frame.getAs,Clif.Frame.get,inputFrame,Clif.Res.ofOption]
  have sourceY : (inputFrame ty a b).getAs 1 ty = .ok (b.setWidth ty.width) := by
    simp [Clif.Frame.getAs,Clif.Frame.get,inputFrame,Clif.Res.ofOption]
  have extent : ∀ z r,sinkCtx.valueReg? z = some r → z < sinkState.demand.size := by
    intro z r mapped
    change z < 2
    by_cases small : z < 2
    · exact small
    · have bound : 2 ≤ z := Nat.le_of_not_lt small
      change (#[some (.vreg 192 .int),some (.vreg 193 .int)][z]?).join = some r at mapped
      rw [Array.getElem?_eq_none bound] at mapped
      cases mapped
  have held : ValuesHeld (Demanded (afterRhs ty.width)) sinkCtx (inputFrame ty a b)
      (fun z => inputRF a b (aliasNum #[] z)) := by
    intro z needed val found
    by_cases h0 : z = 0
    · subst z
      simp only [inputFrame,ite_true] at found
      cases found
      exact ⟨192,rfl,by rfl⟩
    · by_cases h1 : z = 1
      · subst z
        simp only [inputFrame,h0,ite_false,ite_true] at found
        cases found
        exact ⟨193,rfl,by rfl⟩
      · simp only [inputFrame,h0,h1,ite_false] at found
        cases found
  have self : Refines (fun _ => True) ispec := fun _ _ _ _ w' _ h => ⟨w',h,SameWorld.refl _ _⟩
  have sum : ((ty.width-1 : Nat) : Int).toNat+(1 : Int).toNat = ty.width := by
    simp only [Int.toNat_natCast,show (1 : Int).toNat = 1 from rfl]
    rcases width with h | h <;> omega
  have count : (1 : Int).toNat < ty.width := by rcases width with h | h <;> omega
  simpa only [Int.toNat_natCast,show (1 : Int).toNat = 1 from rfl] using
    rhs_values data_program mirrored self width sum count sourceX sourceY
      (aliases := #[]) (ρ := inputRF a b) (by decide) extent held (n := 0) run
end Backend.Stock.Proof.LogicalExtr

#print axioms Backend.Stock.Proof.LogicalExtr.rhs_values
#print axioms Backend.Stock.Proof.LogicalExtr.rhs_values_witness
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let mut count : Nat := 0
  for (name,_) in env.constants.toList do
    if (env.getModuleIdxFor? name).isSome then continue
    for ax in ← collectAxioms name do
      unless #[``propext,``Classical.choice,``Quot.sound].contains ax do
        throwError "unexpected axiom {ax} in {name}"
    count := count+1
  logInfo m!"STOCK_EXTR_VALUES_WITH_WITNESSES_STANDARD_ONLY {count}"
