import FV.E2E.StockArithmeticStage
import FV.Backend.LinearScan
import FV.Backend.Lowering.StockD0
import FV.Backend.Proof.StockRotateSemantics
import FV.Backend.Proof.IselFamALUAExtr
import FV.Backend.Proof.StockLogicalForms
import FV.Backend.Proof.IselTermsALUAExtr

namespace Backend.Stock.Proof.LogicalExtr
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000

private theorem fresh_reg {aliases : Array (Option Nat)} {d : Nat} (bounded : aliases.size ≤ d) :
    Backend.lowerFunction.resolve aliases (aliases.size+1) (.vreg d .int) = .vreg d .int := by
  rw [resolve_vreg]
  have fresh : aliasNum aliases d = d := by
    apply chaseF_none
    rw [Array.getElem?_eq_none bounded]
    rfl
  change Reg.vreg (aliasNum aliases d) .int = _
  rw [fresh]

/-- A two-input EXTR uses original values through final aliases and writes
only its fresh destination. The concatenated inputs need not be equal. -/
theorem extr_resolved {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem}
    (refines : Refines F isem) {ty : Clif.Ty} (width : ty.width = 32 ∨ ty.width = 64)
    {aliases : Array (Option Nat)} {ρ : Nat → CV} {d x y X : Nat} {sh : ShiftOpAndAmt}
    (bounded : aliases.size ≤ d) (sum : X + sh.amt = ty.width) (count : sh.amt < ty.width)
    {u v : BitVec ty.width} (heldX : VHolds ⟨ty,u⟩ (ρ (aliasNum aliases x)))
    (heldY : VHolds ⟨ty,v⟩ (ρ (aliasNum aliases y))) :
    ∃ ρ', PRun F isem
      [(MInst.aluRRRShift .extr (szOf ty.width) (.vreg d .int) (.vreg x .int)
        (.vreg y .int) sh).mapRegs (Backend.lowerFunction.resolve aliases (aliases.size+1))] ρ ρ' ∧
      VHolds ⟨ty,(u <<< X) ||| (v >>> sh.amt)⟩ (ρ' d) ∧ ∀ n,n ≠ d → ρ' n = ρ n := by
  have bits : (szOf ty.width).bits = ty.width := by
    rcases width with h | h <;> simp [szOf,h,OperandSize.bits]
  have fits : sh.amt < (szOf ty.width).bits := by rwa [bits]
  let r := resX (szOf ty.width)
    (((opnd (szOf ty.width) (ρ (aliasNum aliases x)) ++
       opnd (szOf ty.width) (ρ (aliasNum aliases y))) >>> sh.amt).setWidth (szOf ty.width).bits)
  refine ⟨upd ρ d r,?_,?_,?_⟩
  · simp only [MInst.mapRegs]
    rw [fresh_reg bounded,resolve_vreg,resolve_vreg]
    exact prun_rrr refines (operands_aluRRRShift _ _ _ _ _ _)
      (fun _ => ispec_extr fits) (prun_nil _)
  · rw [upd_same]
    exact extr_holds width heldX heldY sum
  · intro n different
    simp only [upd,different,ite_false]

/-- Both source widths have actual executable instances for arbitrary, distinct
machine words and caller state, with the destination separate from the inputs. -/
theorem extr_resolved_witness (ty : Clif.Ty) (supported : ty = .i32 ∨ ty = .i64) (a b : CV) :
    let ρ : Nat → CV := fun n => if n = 0 then a else if n = 1 then b else 0
    ∃ ρ', PRun (fun _ => True) ispec
      [(MInst.aluRRRShift .extr (szOf ty.width) (.vreg 2 .int) (.vreg 0 .int)
        (.vreg 1 .int) ⟨.lsr,1⟩).mapRegs (Backend.lowerFunction.resolve #[] 1)] ρ ρ' ∧
      VHolds ⟨ty,(a.setWidth ty.width <<< (ty.width-1)) ||| (b.setWidth ty.width >>> 1)⟩ (ρ' 2) ∧
      ∀ n,n ≠ 2 → ρ' n = ρ n := by
  dsimp only
  have width : ty.width = 32 ∨ ty.width = 64 := by rcases supported with rfl | rfl <;> simp [Clif.Ty.width]
  have sum : ty.width-1+1 = ty.width := by rcases supported with rfl | rfl <;> decide
  have count : 1 < ty.width := by rcases supported with rfl | rfl <;> decide
  have self : Refines (fun _ => True) ispec := fun _ _ _ _ w' _ h => ⟨w',h,SameWorld.refl _ _⟩
  exact extr_resolved self width (aliases := #[]) (d := 2) (x := 0) (y := 1)
    (X := ty.width-1) (sh := ⟨.lsr,1⟩) (by decide) sum count (by rfl) (by rfl)

end Backend.Stock.Proof.LogicalExtr

namespace Backend.Stock.Proof.LogicalExtr
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
attribute [local irreducible] Isle.Aarch64.program

private theorem sem_ctor (ctx : Ctx) (t : Term) (vs : List V) (st : State) :
    (Stock.sem ctx).ctor t vs st = Stock.externCtor ctx t vs st := rfl
private theorem sem_mkData (ctx : Ctx) (t k : Nat) (vs : List V) :
    (Stock.sem ctx).mkData t k vs = .data t k vs := rfl
private theorem extr_shift_32 (ctx : Ctx) (st : State) (amount : Nat) :
    Stock.externCtor ctx T.a64_extr_imm [.ty (.int 32),.op (.immShift amount)] st =
      .ok (.op (.shiftOpAndAmt ⟨.lsl,amount⟩),st) := by
  rw [stock_ctor_baseOnly ctx T.a64_extr_imm _ st (by decide)]
  rfl
private theorem extr_shift_64 (ctx : Ctx) (st : State) (amount : Nat) :
    Stock.externCtor ctx T.a64_extr_imm [.ty (.int 64),.op (.immShift amount)] st =
      .ok (.op (.shiftOpAndAmt ⟨.lsr,amount⟩),st) := by
  rw [stock_ctor_baseOnly ctx T.a64_extr_imm _ st (by decide)]
  rfl
private theorem immediate_shift (ctx : Ctx) (st : State) {amount : Int} (fits : amount < 64) :
    Stock.externCtor ctx T.imm_shift_from_u8 [.int amount] st =
      .ok (.op (.immShift amount.toNat),st) := by
  rw [stock_ctor_baseOnly ctx T.imm_shift_from_u8 _ st (by decide),
    ctor_imm_shift_from_u8 ctx st.base fits]
private theorem output_run {p : Program} (hp : Data p) (ctx : Ctx) (st : State)
    (tr : Array RuleId) (n : Nat) (r : Reg) :
    (applyTerm p (Stock.sem ctx) {} (n+10) 25 172 [.reg r]).run (st,tr) =
      .ok (some (.regsVec [[r]]),st,tr.push rule_prelude_lower_105.id) := by
  have value : ∀ q,Stock.externCtor ctx T.value_reg [.reg r] q = .ok (.regs [r],q) := by
    intro q; rw [stock_ctor_baseOnly ctx T.value_reg _ q (by decide)]; rfl
  have output : ∀ q,Stock.externCtor ctx T.output [.regs [r]] q = .ok (.regsVec [[r]],q) := by
    intro q; rw [stock_ctor_baseOnly ctx T.output _ q (by decide)]; rfl
  cases hp
  isel_eval [*,rule_prelude_lower_105,sem_ctor]

def shiftFor (w amount : Nat) : ShiftOpAndAmt :=
  if w ≤ 32 then ⟨.lsl,amount⟩ else ⟨.lsr,amount⟩

/-- The real two-register EXTR helper preserves all Stock scheduling fields. -/
theorem helper_run {p : Program} (hp : Data p) (ctx : Ctx) {w : Nat}
    (width : w = 32 ∨ w = 64) (st : State) (tr : Array RuleId) (n : Nat)
    (rx ry : Reg) (amount : Nat) :
    (applyTerm p (Stock.sem ctx) {} (n+30) 27 515
      [.ty (.int w),.reg rx,.reg ry,.op (.immShift amount)]).run (st,tr) =
      .ok (some (.reg (st.base.fresh .int).1),
        {st with base := (st.base.fresh .int).2.emit (.aluRRRShift .extr (szOf w) (st.base.fresh .int).1 rx ry (shiftFor w amount))},
        ((tr.push (if w ≤ 32 then rule_inst_1592.id else rule_inst_1593.id)).push rule_inst_2656.id).push
          rule_inst_3487.id) := by
  have small : w ≤ 64 := by rcases width with rfl | rfl <;> decide
  have inner := fun q trace fuel sh => LogicalForms.stock_logical_shift_helper hp ctx (cfg := {})
    rfl small (k := 15) (op := .extr) rfl q trace fuel rx ry sh
  have ctor32 := fun q => extr_shift_32 ctx q amount
  have ctor64 := fun q => extr_shift_64 ctx q amount
  cases hp
  rcases width with rfl | rfl
  all_goals simp only [shiftFor,szOf,Nat.reduceLeDiff,ite_true,ite_false] at *
  all_goals isel_eval [*,rule_inst_3487,sem_mkData,sem_ctor]
  all_goals rfl

def extrRule (mirrored : Bool) : Rule := if mirrored then rule_lower_1507 else rule_lower_1501

def extrEnv (mirrored : Bool) (w x : Nat) (X : Int) (y : Nat) (Y : Int) : Isle.Interp.Env V :=
  if mirrored then env5 (.ty (.int w)) (.value y) (.int Y) (.value x) (.int X)
  else env5 (.ty (.int w)) (.value x) (.int X) (.value y) (.int Y)

/-- Both original fused-OR RHSs request only the underlying source words,
retain complete Stock scheduling state, and emit the actual EXTR instruction. -/
theorem rhs_forward {p : Program} (hp : Data p) (ctx : Ctx) (mirrored : Bool)
    {w x y : Nat} {X Y : Int} {rx ry : Reg}
    (mappedX : ctx.valueReg? x = some rx) (mappedY : ctx.valueReg? y = some ry)
    (width : w = 32 ∨ w = 64) (fits : Y < 64)
    (st : State) (safeX : DemandAllowed ctx st x) (safeY : DemandAllowed ctx st y)
    (tr : Array RuleId) (n : Nat) :
    ∃ trace,(evalExpr p (Stock.sem ctx) {} (n+60) (extrRule mirrored).rhs
      (extrEnv mirrored w x X y Y)).run (st,tr) =
      .ok (some (.regsVec [[(st.base.fresh .int).1]]),
        {(st.mark x).mark y with base := (st.base.fresh .int).2.emit (.aluRRRShift .extr (szOf w) (st.base.fresh .int).1 rx ry (shiftFor w Y.toNat))},trace) := by
  have requestX := stock_put_in_reg ctx st x rx mappedX safeX
  have requestY := stock_put_in_reg ctx (st.mark x) y ry mappedY safeY
  have shift := fun q => immediate_shift ctx q fits
  have helper := fun q trace fuel => helper_run hp ctx width q trace fuel rx ry Y.toNat
  have output := fun q trace fuel r => output_run hp ctx q trace fuel r
  cases hp
  cases mirrored with
  | false =>
    refine Exists.intro ?trace0 ?proof0
    case proof0 =>
      simp only [extrRule,extrEnv,Bool.false_eq_true,ite_true,ite_false]
      isel_eval [*,rule_lower_1501,sem_ctor]
      rfl
  | true =>
    refine Exists.intro ?trace1 ?proof1
    case proof1 =>
      simp only [extrRule,extrEnv,Bool.false_eq_true,ite_true,ite_false]
      isel_eval [*,rule_lower_1507,sem_ctor]
      rfl

/-- Successful actual RHS execution supplies both guarded source requests;
no caller-provided register map or scheduling certificate is needed. -/
theorem rhs_requests {p : Program} (hp : Data p) (ctx : Ctx) (mirrored : Bool)
    {w x y n : Nat} {X Y : Int} {st next : State} {tr trace : Array RuleId} {out : V}
    (run : (evalExpr p (Stock.sem ctx) {} (n+60) (extrRule mirrored).rhs
      (extrEnv mirrored w x X y Y)).run (st,tr) = .ok (some out,next,trace)) :
    DemandAllowed ctx st x ∧ DemandAllowed ctx st y ∧
      (∃ rx,ctx.valueReg? x = some rx) ∧ ∃ ry,ctx.valueReg? y = some ry := by
  cases hp
  cases mirrored
  all_goals
    isel_inv [*,extrRule,extrEnv,rule_lower_1501,rule_lower_1507,sem_ctor,stock_put_in_reg_iff] at run
    all_goals simp only [stock_put_in_reg_iff,ExtResult.ok.injEq,Prod.mk.injEq] at *
    all_goals isel_destruct <;> subst_vars
  all_goals
    exact ⟨‹DemandAllowed ctx st x›,‹DemandAllowed ctx (st.mark x) y›,
      ⟨_,‹ctx.valueReg? x = some _›⟩,⟨_,‹ctx.valueReg? y = some _›⟩⟩

/-- Actual success determines the complete output and marking/emission state.
Root match guards will supply the width and immediate facts. -/
theorem rhs_observed {p : Program} (hp : Data p) (ctx : Ctx) (mirrored : Bool)
    {w x y n : Nat} {X Y : Int} (width : w = 32 ∨ w = 64) (fits : Y < 64)
    {st next : State} {tr trace : Array RuleId} {out : V}
    (run : (evalExpr p (Stock.sem ctx) {} (n+60) (extrRule mirrored).rhs
      (extrEnv mirrored w x X y Y)).run (st,tr) = .ok (some out,next,trace)) :
    DemandAllowed ctx st x ∧ DemandAllowed ctx st y ∧
      ∃ rx ry,ctx.valueReg? x = some rx ∧ ctx.valueReg? y = some ry ∧
        out = .regsVec [[(st.base.fresh .int).1]] ∧
        next = {(st.mark x).mark y with base := (st.base.fresh .int).2.emit (.aluRRRShift .extr
          (szOf w) (st.base.fresh .int).1 rx ry (shiftFor w Y.toNat))} := by
  obtain ⟨safeX,safeY,⟨rx,mappedX⟩,ry,mappedY⟩ := rhs_requests hp ctx mirrored run
  obtain ⟨actualTrace,forward⟩ := rhs_forward hp ctx mirrored mappedX mappedY width fits st safeX safeY tr n
  rw [forward] at run
  simp only [Except.ok.injEq,Prod.mk.injEq,Option.some.injEq] at run
  obtain ⟨outEq,stateEq,_⟩ := run
  exact ⟨safeX,safeY,rx,ry,mappedX,mappedY,outEq.symm,stateEq.symm⟩

/-- Concrete mapped words inhabit both RHS routes and supported widths; the
source match/binding and complete-function witness remain separate obligations. -/
theorem rhs_witness (mirrored : Bool) (w : Nat) (width : w = 32 ∨ w = 64) :
    ∃ trace,(evalExpr program (Stock.sem sinkCtx) {} 60 (extrRule mirrored).rhs
      (extrEnv mirrored w 0 (w-1 : Nat) 1 1)).run (sinkState,#[]) =
      .ok (some (.regsVec [[(sinkState.base.fresh .int).1]]),
        {(sinkState.mark 0).mark 1 with base := (sinkState.base.fresh .int).2.emit (.aluRRRShift .extr (szOf w) (sinkState.base.fresh .int).1 (.vreg 192 .int)
            (.vreg 193 .int) (shiftFor w 1))},trace) := by
  have safe0 := stock_put_in_reg_witness.1
  have safe1 : DemandAllowed sinkCtx sinkState 1 := by
    intro i found
    change (none : Option Nat) = some i at found
    cases found
  exact rhs_forward data_program sinkCtx mirrored (w := w) (x := 0) (y := 1)
    (X := (w-1 : Nat)) (Y := 1) rfl rfl width (by decide) sinkState safe0 safe1 #[] 0

/-- Successful concrete runs inhabit the observation theorem for both mirrors
and source-compatible positive shifts summing to the supported width. -/
theorem rhs_observed_witness (mirrored : Bool) (w : Nat) (width : w = 32 ∨ w = 64) :
    DemandAllowed sinkCtx sinkState 0 ∧ DemandAllowed sinkCtx sinkState 1 ∧
      ∃ rx ry,sinkCtx.valueReg? 0 = some rx ∧ sinkCtx.valueReg? 1 = some ry ∧
        (.regsVec [[(sinkState.base.fresh .int).1]] : V) =
          .regsVec [[(sinkState.base.fresh .int).1]] ∧
        {(sinkState.mark 0).mark 1 with base := (sinkState.base.fresh .int).2.emit (.aluRRRShift .extr (szOf w) (sinkState.base.fresh .int).1 (.vreg 192 .int)
            (.vreg 193 .int) (shiftFor w 1))} =
        {(sinkState.mark 0).mark 1 with base := (sinkState.base.fresh .int).2.emit (.aluRRRShift .extr (szOf w) (sinkState.base.fresh .int).1 rx ry
            (shiftFor w (1 : Int).toNat))} := by
  obtain ⟨trace,run⟩ := rhs_witness mirrored w width
  exact rhs_observed data_program sinkCtx mirrored width (by decide) (n := 0) run

end Backend.Stock.Proof.LogicalExtr

namespace Backend.Stock.Proof.LogicalExtr
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
attribute [local irreducible] Isle.Aarch64.program

private def literalPattern (slot : Nat) : Pattern :=
  .term 15 1 [.term 18 209 [.wildcard 14,.term 152 2482
    [.term 151 2341 [],.term 134 144 [.term 4 1527 [.bind 1 slot (.wildcard 1)]]]]]
private def wordPattern (left : Bool) (wordSlot countSlot : Nat) : Pattern :=
  .term 15 1 [.term 18 209 [.wildcard 14,.term 152 2449
    [.term 151 (if left then 2387 else 2388) [],.term 147 1614
      [.bind 15 wordSlot (.wildcard 15),literalPattern countSlot]]]]

/-- Both original source definitions are retained, including the shift count's
own typed literal definition. These are not caller-supplied lookthrough facts. -/
def WordSource (ctx : Ctx) (value : Nat) (left : Bool) : Prop :=
  ∃ (j x count k : Nat) (info literal : IInfo) (ty literalTy : Clif.Ty) (bits : BitVec literalTy.width),
    ctx.defInst? value = some j ∧ ctx.insts[j]? = some info ∧
    info.clif = some (.binary (if left then .ishl else .ushr) ty x count) ∧
    ctx.defInst? count = some k ∧ ctx.insts[k]? = some literal ∧
    literal.clif = some (.iconst literalTy bits)

private theorem word_source {p : Program} (hp : Data p) {f : Clif.Function} {ctx : Ctx}
    (inv : MappedCtxInv f ctx) (left : Bool) {v wordSlot countSlot : Nat}
    {st : LState} {env env' : Isle.Interp.Env V}
    (matched : matchPat p (Backend.sem ctx) st (wordPattern left wordSlot countSlot)
      (.value v) env = .ok (some env')) : WordSource ctx v left := by
  have opTerm : termOf p (if left then 2387 else 2388) =
      .ok (if left then T.«Opcode.Ishl» else T.«Opcode.Ushr») := by
    cases left <;> first | exact hp.t2387 | exact hp.t2388
  have opKind : (if left then T.«Opcode.Ishl» else T.«Opcode.Ushr»).kind =
      .enumVariant (if left then 103 else 104) := by cases left <;> rfl
  obtain ⟨j,info,fs,env0,defined,found,data,rest⟩ :=
    defInst_match_inv hp ctx hp.t2449 term_2449_kind opTerm opKind matched
  obtain ⟨original,clif,raw⟩ := ctxInv_clif inv.identityView defined found
  rw [data] at raw
  have name : (variantNames 151)[if left then 103 else 104]? =
      some (if left then "Ishl" else "Ushr") := by
    cases left <;> first | exact variantNames_Ishl | exact variantNames_Ushr
  have opcode : binaryOpcode (if left then .ishl else .ushr) =
      some (if left then "Ishl" else "Ushr") := by cases left <;> rfl
  obtain ⟨ty,x,count,rfl,_,rfl⟩ := instData_binary_inv name opcode raw
  obtain ⟨env1,_,constant⟩ := values2_match_inv hp ctx rest
  obtain ⟨k,literal,fields,env2,countDefined,countFound,literalData,_⟩ :=
    defInst_match_inv hp ctx hp.t2482 term_2482_kind hp.t2341 term_2341_kind constant
  obtain ⟨sourceLiteral,literalClif,literalRaw⟩ := ctxInv_clif inv.identityView countDefined countFound
  rw [literalData] at literalRaw
  obtain ⟨literalTy,bits,rfl,rfl⟩ := instData_iconst_inv literalRaw
  exact ⟨j,x,count,k,info,literal,ty,literalTy,bits,defined,found,clif,countDefined,countFound,literalClif⟩

/-- Actual successful Stock matches follow both original operands through their
shift and literal definitions, including the mirrored OR route. -/
theorem matched_sources {p : Program} (hp : Data p) {f : Clif.Function} {ctx : Ctx}
    (inv : MappedCtxInv f ctx) (mirrored : Bool) {i a b n : Nat} {info : IInfo}
    (source : ctx.insts[i]? = some info)
    (data : info.data = .data 152 2 [.data 151 98 [],.values [a,b]])
    {st : State} {tr : Array RuleId} {env : Isle.Interp.Env V} {middle : State × Array RuleId}
    (matched : (matchRule p (Stock.sem ctx) {} (n+20) (extrRule mirrored) [.inst i]).run (st,tr) =
      .ok (some env,middle)) : WordSource ctx a (!mirrored) ∧ WordSource ctx b mirrored := by
  have shape : (extrRule mirrored).args = [.term 18 209
    [.term 14 120 [.bind 14 0 (.wildcard 14)],.term 152 2449
      [.term 151 2382 [],.term 147 1614 [wordPattern (!mirrored) 1 2,wordPattern mirrored 3 4]]]] := by
    cases mirrored <;> rfl
  obtain ⟨initial,args,_⟩ := matchRule_some_inv matched
  rw [stock_matchArgs,shape] at args
  obtain ⟨e1,root,_⟩ := matchArgs_cons_inv args
  obtain ⟨fields,extracted,patterns⟩ := matchPat_extract_inv hp.t209 term_209_kind rfl root
  rw [Backend.Proof.sem_extract,ext_inst_data_value ctx st.base source,data] at extracted
  cases extracted
  obtain ⟨e2,_,tail⟩ := matchArgs_cons_inv patterns
  obtain ⟨e3,binary,_⟩ := matchArgs_cons_inv tail
  obtain ⟨fs,decoded,matchedFields⟩ := matchPat_enum_inv hp.t2449 term_2449_kind binary
  have decode : (Backend.sem ctx).unData 152 (.data 152 2 [.data 151 98 [],.values [a,b]]) =
      some (2,[.data 151 98 [],.values [a,b]]) := rfl
  rw [decode] at decoded
  cases decoded
  obtain ⟨e4,_,values⟩ := matchArgs_cons_inv matchedFields
  obtain ⟨e5,first,second⟩ := values2_match_inv hp ctx values
  exact ⟨word_source hp inv (!mirrored) first,word_source hp inv mirrored second⟩
end Backend.Stock.Proof.LogicalExtr



namespace E2E.StockLogicalExtrWitness
open Backend Backend.Proof Backend.Proof.Driver Backend.Stock.D0
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm

/-- Distinct shift operands, a consumed ninth ABI argument, unused parameters,
an explicit slot and a dead statement. Both original OR operand orders occur. -/
def function (config : Configuration) (mirrored : Bool) : Clif.Function :=
  let ty := valueType config
  {source "stock_logical_extr" config [] with
    sig := {
      params := List.replicate 9 ⟨ty,.none,.normal⟩
      returns := [⟨ty,.none,.normal⟩]
      callConv := convention config}
    slots := [(7,⟨8,some 8⟩)]
    blocks := [{
      id := 0
      params := (List.range 9).map (fun i => (i,ty))
      body := [⟨[9],.iconst ty (ty.width-1 : Nat)⟩,⟨[10],.iconst ty 1⟩,
        ⟨[11],.binary .ishl ty 1 9⟩,⟨[12],.binary .ushr ty 8 10⟩,
        ⟨[13],.binary .bor ty (if mirrored then 12 else 11) (if mirrored then 11 else 12)⟩,
        ⟨[14],.binary .bxor ty 0 2⟩]
      term := .ret [13]}]}
def selected (result : Stock.Result) (mirrored : Bool) : Bool :=
  result.schedule.any fun step => step.rules.contains
    (if mirrored then Isle.Aarch64.rule_lower_1507.id else Isle.Aarch64.rule_lower_1501.id)

private def checks (config : Configuration) (mirrored cleanup : Bool) : Bool :=
  lowerScopeB (function config mirrored) && dominatedB (function config mirrored) && sigAbiOk (function config mirrored).sig &&
  match Stock.lower (function config mirrored) with
  | .error _ => false
  | .ok result =>
    (!lowerCheck (function config mirrored) result.code && selected result mirrored) &&
    match Backend.prepare (Stock.Arithmetic.stage cleanup result.code) with
    | .error _ => false
    | .ok vcp =>
      prepCheck (Stock.Arithmetic.stage cleanup result.code) vcp &&
      match leanAlloc vcp with
      | .error _ => false
      | .ok rf =>
        (checkAlloc vcp rf).isOk &&
        match lowerRFunc vcp rf with
        | .error _ => false
        | .ok af =>
          match emitFunc 0 af with
          | .error _ => false
          | .ok fa => formsCoveredB ⟨fa.k,af.slotBase⟩ vcp && fa.layout.isOk


private def grid : Bool := configurations.all fun config =>
  [false,true].all fun mirrored => [false,true].all fun cleanup => checks config mirrored cleanup
-- witness: native_decide (24 fixed actual full-pipeline configurations only)
theorem checks_true : grid = true := by native_decide

/-- Real Stock EXTR programs pass both cleanup modes through checked Lean
allocation and emitted bytes in every existing integer ABI configuration. -/
theorem compiled_exists (config : Configuration) (mirrored cleanup : Bool) :
    LowerScope (function config mirrored) ∧ Dominated (function config mirrored) ∧
    sigAbiOk (function config mirrored).sig = true ∧
    ∃ result vcp rf af fa fb,
      CompiledStockArithmeticStage (function config mirrored) cleanup 0 result vcp rf af fa fb ∧
      selected result mirrored = true ∧ leanAlloc vcp = .ok rf ∧ FormsCovered ⟨fa.k,af.slotBase⟩ vcp ∧
      lowerCheck (function config mirrored) result.code = false := by
  have h : checks config mirrored cleanup = true := by
    have allConfig := List.all_eq_true.mp checks_true config (by cases config <;> simp [configurations])
    have allMirror := List.all_eq_true.mp allConfig mirrored (by cases mirrored <;> simp)
    exact List.all_eq_true.mp allMirror cleanup (by cases cleanup <;> simp)
  simp only [checks,Bool.and_eq_true] at h
  obtain ⟨⟨⟨scope,dominated⟩,abi⟩,h⟩ := h
  refine ⟨lowerScope_of scope,dominated_of dominated,abi,?_⟩
  cases lowered : Stock.lower (function config mirrored) with
  | error message => simp [lowered] at h
  | ok result =>
    simp only [lowered,Bool.and_eq_true,Bool.not_eq_true'] at h
    obtain ⟨⟨legacy,selectedRoot⟩,h⟩ := h
    cases prepared : Backend.prepare (Stock.Arithmetic.stage cleanup result.code) with
    | error message => simp [prepared] at h
    | ok vcp =>
      simp only [prepared,Bool.and_eq_true] at h
      obtain ⟨prepOk,h⟩ := h
      cases allocated : leanAlloc vcp with
      | error message => simp [allocated] at h
      | ok rf =>
        simp only [allocated,Bool.and_eq_true] at h
        obtain ⟨checked,h⟩ := h
        cases physical : lowerRFunc vcp rf with
        | error message => simp [physical] at h
        | ok af =>
          cases emitted : emitFunc 0 af with
          | error message => simp [physical,emitted] at h
          | ok fa =>
            simp only [physical,emitted,Bool.and_eq_true] at h
            obtain ⟨covered,layoutOk⟩ := h
            cases layout : fa.layout with
            | error message => rw [layout] at layoutOk; change false = true at layoutOk; cases layoutOk
            | ok fb =>
              have check : checkAlloc vcp rf = .ok () := by
                cases check : checkAlloc vcp rf with
                | error message => rw [check] at checked; change false = true at checked; cases checked
                | ok value => cases value; rfl
              exact ⟨result,vcp,rf,af,fa,fb,
                ⟨lowered,prepared,prepOk,check,physical,emitted,layout⟩,
                selectedRoot,allocated,(formsCoveredB_iff _ _).mp covered,legacy⟩

end E2E.StockLogicalExtrWitness
namespace E2E.StockLogicalExtrWitness
open Backend Backend.Proof Backend.Proof.Driver Backend.Stock.D0 Backend.Stock.Proof
open Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm

private def built (config : Configuration) (mirrored : Bool) : Ctx × Array (Nat × Nat) × Stock.State :=
  (Stock.buildCtx (function config mirrored)).toOption.getD (sinkCtx,#[],sinkState)
private theorem build (config : Configuration) (mirrored : Bool) :
    Stock.buildCtx (function config mirrored) = .ok (built config mirrored) := by
  cases config <;> cases mirrored <;> rfl
private def matchChecks (config : Configuration) (mirrored : Bool) : Bool :=
  let ctx := (built config mirrored).1
  let st := (built config mirrored).2.2
  lowerScopeB (function config mirrored) &&
  match ctx.insts[4]? with
  | none => false
  | some info =>
    decide (info.data = .data 152 2 [.data 151 98 [],
      .values [if mirrored then 12 else 11,if mirrored then 11 else 12]]) &&
    match (matchRule program (Stock.sem ctx) {} 20 (LogicalExtr.extrRule mirrored) [.inst 4]).run (st,#[]) with
    | .ok (some _,_) => true
    | _ => false
private def matchGrid : Bool := configurations.all fun config =>
  [false,true].all fun mirrored => matchChecks config mirrored
-- witness: native_decide (twelve fixed source contexts and actual rule matches only)
theorem match_checks_true : matchGrid = true := by native_decide

/-- Each ABI/width and mirrored root has an actual successful source match
inhabiting the original two-shift/two-literal definition theorem. -/
theorem source_matches (config : Configuration) (mirrored : Bool) :
    let ctx := (built config mirrored).1
    let st := (built config mirrored).2.2
    ∃ info env middle,
      ctx.insts[4]? = some info ∧
      info.data = .data 152 2 [.data 151 98 [],
        .values [if mirrored then 12 else 11,if mirrored then 11 else 12]] ∧
      (matchRule program (Stock.sem ctx) {} 20 (LogicalExtr.extrRule mirrored) [.inst 4]).run (st,#[]) =
        .ok (some env,middle) ∧
      LogicalExtr.WordSource ctx (if mirrored then 12 else 11) (!mirrored) ∧
      LogicalExtr.WordSource ctx (if mirrored then 11 else 12) mirrored := by
  dsimp only
  have h : matchChecks config mirrored = true := by
    have allConfig := List.all_eq_true.mp match_checks_true config (by cases config <;> simp [configurations])
    exact List.all_eq_true.mp allConfig mirrored (by cases mirrored <;> simp)
  simp only [matchChecks,Bool.and_eq_true] at h
  obtain ⟨scope,h⟩ := h
  have inv := buildCtx_mappedInv (lowerScope_of scope) (build config mirrored)
  cases found : (built config mirrored).1.insts[4]? with
  | none => simp [found] at h
  | some info =>
    simp only [found,Bool.and_eq_true,decide_eq_true_eq] at h
    obtain ⟨data,h⟩ := h
    cases run : (matchRule program (Stock.sem (built config mirrored).1) {} 20
        (LogicalExtr.extrRule mirrored) [.inst 4]).run ((built config mirrored).2.2,#[]) with
    | error message => simp [run] at h
    | ok result =>
      rcases result with ⟨value,middle⟩
      cases value with
      | none => simp [run] at h
      | some env =>
        obtain ⟨first,second⟩ := LogicalExtr.matched_sources data_program inv mirrored found data (n := 0) run
        exact ⟨info,env,middle,rfl,data,rfl,first,second⟩
end E2E.StockLogicalExtrWitness

#print axioms Backend.Stock.Proof.LogicalExtr.matched_sources
#print axioms E2E.StockLogicalExtrWitness.source_matches
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let mut count : Nat := 0
  for (name,_) in env.constants.toList do
    if (env.getModuleIdxFor? name).isSome then continue
    for ax in ← collectAxioms name do
      unless #[``propext,``Classical.choice,``Quot.sound,
        ``E2E.StockLogicalExtrWitness.checks_true._native.native_decide.ax_1,
        ``E2E.StockLogicalExtrWitness.match_checks_true._native.native_decide.ax_1].contains ax do
        throwError "unexpected axiom {ax} in {name}"
    count := count+1
  logInfo m!"STOCK_EXTR_SOURCE_MATCH_WITH_FIXED_WITNESSES_AUDIT {count}"
