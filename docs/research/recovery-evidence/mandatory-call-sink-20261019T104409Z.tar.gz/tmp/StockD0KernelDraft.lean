import Lean
import FV.Backend.Lowering.Stock

namespace Backend.Stock.D0Draft

deriving instance DecidableEq for VBlock
deriving instance DecidableEq for VCode
deriving instance DecidableEq for Except

/-- An input-defined first production class; the name is arbitrary. -/
def parameterReturn (name : String) (ty : Clif.Ty) : Clif.Function := {
  name
  sig := { params := [⟨ty, .none, .normal⟩], returns := [⟨ty, .none, .normal⟩] }
  blocks := [{ id := 0, params := [(0, ty)], term := .ret [0] }] }

/-- Dense numbering is an adapter for this proved class, not an assertion about
arbitrary Stock output. Per-successor vectors are empty on the D0 return graph. -/
def denseReg : Reg → Reg
  | .vreg n cls => .vreg (n - firstUserVreg) cls
  | r => r

def denseCode (vc : VCode) : VCode := {
  vc with
  classes := vc.classes.extract firstUserVreg vc.classes.size
  blocks := vc.blocks.map fun b => { b with
    insts := b.insts.map (·.mapRegs denseReg)
    params := b.params.map denseReg
    branchArgs := b.branchArgs.map denseReg } }

set_option maxRecDepth 20000
set_option maxHeartbeats 8000000

def eraseName (vc : VCode) : VCode := {vc with name := ""}

/-- Kernel reduction can ignore the arbitrary source name once output names are
projected away. This is a proof term, not native_decide or a runtime certificate. -/
theorem erased64 (name : String) :
    (Stock.lower (parameterReturn name .i64)).map (fun r => eraseName (denseCode r.code)) =
      (lowerFunction (parameterReturn name .i64)).map eraseName := by
  run_tac do
    let g ← Lean.Elab.Tactic.getMainGoal
    let proof ← Lean.Meta.mkDecideProof (← g.getType)
    g.assign proof

#print axioms erased64
end Backend.Stock.D0Draft
