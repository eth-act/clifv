import StockD0GuardedProofDraft
import StockConsumerAdapterDraft

namespace Backend.Stock.IncrementalD0Draft
open E2E.LinkCheck E2E.LinkCheck.IncrementalAdapterDraft

/-- The exact artifact/error computation, including every downstream fallback,
is shared for arbitrary functions and arbitrary allocator oracle answers. -/
theorem consumer_total_eq (f : Clif.Function) (k : Nat) (base : BitVec 64)
    (answer : Lean.Json) :
    pipeTWith defaultLower id f k base answer = pipeT f k base answer := by
  rw [pipeTWith_congr defaultLower_eq_legacy]
  rfl

theorem consumer_cleanup_total_eq (f : Clif.Function) (k : Nat) (base : BitVec 64)
    (answer : Lean.Json) :
    pipeTWith defaultLower DeadCleanup.prune f k base answer =
      pipeCleanupT f k base answer := by
  rw [pipeTWith_congr defaultLower_eq_legacy]
  rfl

theorem consumer_strict_eq (f : Clif.Function) (k : Nat) (base : BitVec 64)
    (answer : Lean.Json) :
    pipeWith defaultLower id f k base answer = pipe f k base answer := by
  rw [pipeWith_congr defaultLower_eq_legacy]
  rfl

theorem consumer_cleanup_strict_eq (f : Clif.Function) (k : Nat) (base : BitVec 64)
    (answer : Lean.Json) :
    pipeWith defaultLower DeadCleanup.prune f k base answer =
      pipeCleanup f k base answer := by
  rw [pipeWith_congr defaultLower_eq_legacy]
  rfl

/-- Existing successful artifacts and every field of their allocator/proof
provenance survive; this does not assume success of a new validator. -/
theorem consumer_success_iff (f : Clif.Function) (k : Nat) (base : BitVec 64)
    (answer : Lean.Json) (artifact : E2E.Art) :
    (pipeTWith defaultLower id f k base answer = .ok artifact ↔
      pipeT f k base answer = .ok artifact) ∧
    (pipeTWith defaultLower DeadCleanup.prune f k base answer = .ok artifact ↔
      pipeCleanupT f k base answer = .ok artifact) := by
  rw [consumer_total_eq, consumer_cleanup_total_eq]
  exact ⟨Iff.rfl, Iff.rfl⟩

/-- An inhabited structural source witnesses all four routes for all answers;
the separate Stock-success witness proves the Stock branch is reachable. -/
theorem consumer_compatibility_witness (name : String) (c : Configuration)
    (runs : List Clif.RunCommand) (k : Nat) (base : BitVec 64) (answer : Lean.Json) :
    pipeTWith defaultLower id (source name c runs) k base answer =
      pipeT (source name c runs) k base answer ∧
    pipeTWith defaultLower DeadCleanup.prune (source name c runs) k base answer =
      pipeCleanupT (source name c runs) k base answer ∧
    pipeWith defaultLower id (source name c runs) k base answer =
      pipe (source name c runs) k base answer ∧
    pipeWith defaultLower DeadCleanup.prune (source name c runs) k base answer =
      pipeCleanup (source name c runs) k base answer :=
  ⟨consumer_total_eq .., consumer_cleanup_total_eq ..,
    consumer_strict_eq .., consumer_cleanup_strict_eq ..⟩

#print axioms consumer_total_eq
#print axioms consumer_cleanup_total_eq
#print axioms consumer_strict_eq
#print axioms consumer_cleanup_strict_eq
#print axioms consumer_success_iff
#print axioms consumer_compatibility_witness
end Backend.Stock.IncrementalD0Draft
