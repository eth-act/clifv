import StockD0RuntimeDraft
import Lean

namespace Backend.Stock.IncrementalD0Draft
set_option maxRecDepth 20000
set_option maxHeartbeats 200000
set_option Elab.async false
attribute [local irreducible] emitBranch scanBlock

deriving instance DecidableEq for Order
macro "edge_kernel_decide" : tactic => `(tactic|
  run_tac do
    let g ← Lean.Elab.Tactic.getMainGoal
    let proof ← Lean.Meta.mkDecideProof (← g.getType)
    g.assign proof)

private theorem bind_ok {α β : Type} {x : Except String α}
    {k : α → Except String β} {b : β} (h : (x >>= k) = .ok b) :
    ∃ a, x = .ok a ∧ k a = .ok b := by
  cases x with
  | error err => cases h
  | ok a => exact ⟨a, rfl, h⟩

private theorem source_order (name : String) (c : Configuration) (runs : List Clif.RunCommand) :
    blockOrder (source name c runs) =
      .ok {nodes := #[.original 0], successors := #[#[]]} := by
  cbv


#print axioms source_order

/-- Zero outgoing vectors follow from the real collector for zero targets,
without evaluating the ISLE scan or importing unrelated rule-family proofs. -/
private theorem core_empty_outgoing {ctx : Ctx} {order : Order} {f : Clif.Function}
    {b : Clif.Block} {bi start stop : Nat} {data : Backend.V}
    {input : State} {output : LoweredBlockCore}
    (run : lowerBlockCore ctx order f b bi start stop data #[] input = .ok output) :
    output.outgoing = #[] := by
  simp only [lowerBlockCore, collectOutgoing, bind, Except.bind,
    pure, Except.pure] at run
  repeat' first
    | (solve | cases run)
    | split at run
  all_goals
    cases run
    rfl

#print axioms core_empty_outgoing
end Backend.Stock.IncrementalD0Draft
