import StockD0RuntimeDraft
import Lean
namespace Backend.Stock.IncrementalD0Draft
set_option maxRecDepth 20000
set_option maxHeartbeats 200000
set_option Elab.async false
#check blockOrder
private theorem source_order (name : String) (c : Configuration) (runs : List Clif.RunCommand) :
    blockOrder (source name c runs) =
      .ok {nodes := #[.original 0], successors := #[#[]]} := by
  cases c <;> cbv
#print axioms source_order
end Backend.Stock.IncrementalD0Draft
