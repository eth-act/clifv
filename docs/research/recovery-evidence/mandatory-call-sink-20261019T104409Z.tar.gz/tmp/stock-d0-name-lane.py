from pathlib import Path
import os,signal,subprocess as sp,time,json,datetime
scheduler=2408034;assert b'/tmp/stock-execute-scheduler.py' in (Path('/proc')/str(scheduler)/'cmdline').read_bytes();target=Path('/tmp/StockD0NameDraft.lean')
def active_cap():
 parents={};groups={}
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:parents[int(p.name)]=int((p/'stat').read_text().split(') ',1)[1].split()[1])
  except (OSError,ValueError,IndexError):pass
 descendants={scheduler};change=True
 while change:
  add={p for p,parent in parents.items() if parent in descendants}-descendants;change=bool(add);descendants|=add
 for pid in descendants:
  try:
   rel=(Path('/proc')/str(pid)/'cgroup').read_text().strip().split('::')[-1];g=Path('/sys/fs/cgroup')/rel.lstrip('/');mx=(g/'memory.max').read_text().strip()
   if g.name.startswith('run-') and g.name.endswith('.scope') and mx!='max':groups[str(g)]=int(mx)
  except OSError:pass
 return sum(groups.values()),groups
os.kill(scheduler,signal.SIGSTOP)
def finish(signum,frame):raise SystemExit(signum)
signal.signal(signal.SIGTERM,finish)
try:
 total,groups=active_cap();print(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'current_build_caps':total,'groups':groups,'reserved_prototype_bytes':4*2**30}),flush=True)
 while total>12*2**30:time.sleep(1);total,groups=active_cap()
 env=dict(os.environ,PATH='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:'+os.environ['PATH'],FV_LAKE_CACHE='/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache',FV_MEMCAP='4G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2');os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:4])
 with Path('/tmp/StockD0NameDraft.log').open('w') as f:r=sp.run(['scripts/memcap.sh','lake','env','lean','--root=/tmp',str(target)],cwd='/home/lee/clifv/.worktrees/stock-driver-incremental',env=env,stdout=f,stderr=sp.STDOUT)
 print(json.dumps({'returncode':r.returncode,'build_caps_plus_prototype_max_bytes':total+4*2**30,'within_16GiB':total+4*2**30<=16*2**30}),flush=True)
finally:
 os.kill(scheduler,signal.SIGCONT);print('Scheduler resumed; running validation kernels never interrupted.',flush=True)
