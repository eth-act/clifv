import StockD0RuntimeDraft
import FV.Backend.Proof.StockPrepareInputs

namespace Backend.Stock.IncrementalD0Draft
open Backend.Stock.Proof

private theorem source_order (name : String) (c : Configuration) (runs : List Clif.RunCommand) :
    blockOrder (source name c runs) =
      .ok {nodes := #[.original 0], successors := #[#[]]} := rfl

/-- No per-successor vectors are erased on the selected class: the real Stock
traversal's dimension theorem and its computed source graph derive an empty row. -/
theorem stock_edges_empty (name : String) (c : Configuration) (runs : List Clif.RunCommand)
    {r : Result} (run : Stock.lower (source name c runs) = .ok r) :
    r.edgeArgs = #[#[]] := by
  have order : r.order = {nodes := #[.original 0], successors := #[#[]]} :=
    Except.ok.inj ((stock_lower_order run).symm.trans (source_order name c runs))
  obtain ⟨_, size, rows⟩ := stock_prepare_dimensions run
  have count : r.edgeArgs.size = 1 := by simpa only [order] using size
  apply Array.ext
  · exact count
  · intro i hi _
    have zero : i = 0 := by omega
    subst i
    have row := rows 0 r.edgeArgs[0] (Array.getElem?_eq_getElem hi)
    have empty : r.edgeArgs[0].size = 0 := by simpa [order] using row
    simpa using Array.eq_empty_of_size_eq_zero empty

#print axioms stock_edges_empty
end Backend.Stock.IncrementalD0Draft
