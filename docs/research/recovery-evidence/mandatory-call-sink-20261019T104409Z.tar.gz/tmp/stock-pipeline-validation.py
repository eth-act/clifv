from pathlib import Path
import subprocess as sp,os,json,time,datetime,hashlib,shutil,traceback
view=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');canon=Path('/home/lee/clifv/.worktrees/driver-proof-resume');cache=canon/'.lake/artifact-cache';progress=Path('/tmp/stock-pipeline-validation-progress.json');logroot=Path('/tmp/stock-pipeline-validation-logs');logroot.mkdir(exist_ok=True);download_pid=2387873
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();head=sp.check_output(['git','rev-parse','HEAD'],cwd=view,text=True).strip()
env=dict(os.environ,PATH='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:/home/lee/.cargo/bin:'+os.environ['PATH'],FV_LAKE_CACHE=str(cache),OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',FV_MEMCAP='8G');lake='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin/lake';cap=str(view/'scripts/memcap.sh');os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:8]);steps={}
def report(state,**kw):
 d={'utc':now(),'state':state,'head':head,'pid':os.getpid(),'view':str(view),'cache':str(cache),'completed':steps,**kw};progress.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items() if k!='completed'}),flush=True)
def run(name,args,cwd=view):
 p=logroot/(name+'.log');report('running',phase=name,log=str(p));
 with p.open('w') as f:r=sp.run(args,cwd=cwd,env=env,stdout=f,stderr=sp.STDOUT)
 assert r.returncode==0,f'{name} rc={r.returncode}; {p}'
 steps[name]={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()};return p
try:
 report('waiting_baseline_download',download_pid=download_pid)
 while (Path('/proc')/str(download_pid)).exists():
  cmd=(Path('/proc')/str(download_pid)/'cmdline').read_bytes()
  if b'gh\x00run\x00download' not in cmd:break
  time.sleep(5)
 base=view/'.lake/ci-stage-base';assert (base/'outputs.jsonl').exists(),'baseline download absent/incomplete'
 cache.mkdir(exist_ok=True)
 run('unstage-baseline',[cap,lake,'cache','unstage',str(base)]);shutil.rmtree(base)
 stage=view/'.lake/ci-stage-current'
 run('download-current-stages',['gh','run','download','39168595158','--pattern','stage-w*','-D',str(stage)])
 manifests=sorted(stage.rglob('outputs.jsonl'));assert manifests
 for n,m in enumerate(manifests):run('unstage-current-'+str(n),[cap,lake,'cache','unstage',str(m.parent)])
 shutil.rmtree(stage)
 assert sp.check_output(['git','rev-parse','HEAD'],cwd=view,text=True).strip()==head
 run('effective-workers',[cap,'nproc'])
 args=['python3','scripts/lake-serial-build.py','--budget','16G','--max-jobs','4','--max-cap','16G','--default-cap','8G','--others-by-usage','--out',str(logroot/'targeted-modules'),'FV.Backend.Proof.LoweringPipeline','FVTest.Backend.Lowering.StockComparison']
 run('targeted-build',args)
 report('targeted_build_passed')
except BaseException as error:
 report('failed',error=repr(error),traceback=traceback.format_exc());raise
