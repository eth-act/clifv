import StockD0RuntimeDraft

namespace Backend.Stock.IncrementalD0Draft

inductive Origin where
  | stockD0 | legacy
  deriving DecidableEq, Repr, Inhabited

/-- A pure internal route result for testing the actual branch. Its tag carries
no correctness certificate; the shipped route has fixed universal Lean proofs. -/
def selectWith (stock : Clif.Function → Except String Result) (f : Clif.Function) :
    Except String (Origin × VCode) :=
  let legacy := (lowerFunction f).map fun vc => (Origin.legacy, vc)
  if eligible f then
    match stock f with
    | .ok r =>
      if r.edgeArgs.all (·.isEmpty) then .ok (.stockD0, compact f.name r)
      else legacy
    | .error _ => legacy
  else legacy

def defaultLower (f : Clif.Function) : Except String VCode :=
  (selectWith Stock.lower f).map Prod.snd

end Backend.Stock.IncrementalD0Draft
