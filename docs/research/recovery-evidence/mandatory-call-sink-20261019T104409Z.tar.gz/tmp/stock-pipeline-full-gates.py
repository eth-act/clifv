from pathlib import Path
import os,subprocess as sp,json,datetime,hashlib,traceback
view=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');canon=Path('/home/lee/clifv/.worktrees/driver-proof-resume');cache=canon/'.lake/artifact-cache';logroot=Path('/tmp/stock-pipeline-full-gates');logroot.mkdir(exist_ok=True);state=Path('/tmp/stock-pipeline-full-gates-progress.json');head=sp.check_output(['git','rev-parse','HEAD'],cwd=view,text=True).strip();env=dict(os.environ,PATH='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:/home/lee/.cargo/bin:'+os.environ['PATH'],FV_LAKE_CACHE=str(cache),OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',FV_MEMCAP='16G',CLIF_NATIVE_QEMU='/home/lee/.local/share/clifv-test-tools/usr/bin/qemu-aarch64-static',LLVM_MC='/home/lee/.local/share/clifv-test-tools/usr/bin/llvm-mc');cap=str(view/'scripts/memcap.sh');lake='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin/lake';logs={};now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:8]);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest={'head':head,'sources':{str(p.relative_to(view)):sha(p) for d in ['FV','FVTest'] for p in (view/d).rglob('*.lean')},'scripts':{str(p.relative_to(view)):sha(p) for p in (view/'scripts').rglob('*') if p.is_file()},'cache':str(cache),'one_physical_build':str((view/'.lake/build').resolve())};Path('/tmp/stock-pipeline-first-gate-inputs.json').write_text(json.dumps(manifest,indent=2)+'\n')
def report(status,**kw):
 d={'utc':now(),'state':status,'pid':os.getpid(),'head':head,'logs':logs,**kw};state.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items() if k!='logs'}),flush=True)
def frozen():
 assert sp.check_output(['git','rev-parse','HEAD'],cwd=view,text=True).strip()==head
 assert {str(p.relative_to(view)):sha(p) for d in ['FV','FVTest'] for p in (view/d).rglob('*.lean')}==manifest['sources']
def run(name,args,cwd=view):
 frozen();p=logroot/(name+'.log');report('running',phase=name,log=str(p));
 with p.open('w') as f:r=sp.run(args,cwd=cwd,env=env,stdout=f,stderr=sp.STDOUT)
 assert r.returncode==0,f'{name} rc={r.returncode}, log={p}';frozen();logs[name]={'path':str(p),'sha256':sha(p)};return p
try:
 run('modules',['python3','/tmp/stock-execute-scheduler.py','--budget','16G','--max-jobs','4','--max-cap','16G','--default-cap','8G','--others-by-usage','--out',str(logroot/'modules'),'FV','FVTest'])
 run('tools',[cap,lake,'build','FV','FVTest','lean-backend','lean-e2e-check','link-check','lean-link','clif-decode','lean-stock-lowering-compare'])
 run('e2e-axiom-audit',[cap,'python3','scripts/axiom-audit.py'])
 audit=logroot/'new-roots.lean';audit.write_text('import FV.Backend.Proof.LoweringPipeline\n#print axioms Backend.Proof.LoweringPipeline.compileFileWith_legacy\n#print axioms Backend.Proof.LoweringPipeline.successor_payload_witness\n#print axioms Backend.Proof.LoweringPipeline.legacy_specialization_witness\n')
 run('new-roots',[cap,lake,'env','lean','--root='+str(logroot),str(audit)])
 run('runtime',[cap,'bash','scripts/lean-backend-filetests.sh'])
 run('encoder',[cap,'bash','scripts/lean-backend-encode-check.sh'])
 for label,flags in [('e2e',[]),('legacy-e2e',['--no-dead-cleanup'])]:run(label,[cap,lake,'exe','lean-e2e-check',*flags,'--identity-report',str(logroot/(label+'-identities.json'))])
 report('local_kernel_runtime_e2e_gates_passed',remaining='verified cargo fv-demo/survey; focused Stock artifact and payload regressions; transitive new-module audit and ONE bundled MCP; actual test count/identity assertions; PR/rebase review')
except BaseException as error:report('failed',error=repr(error),traceback=traceback.format_exc());raise
