from pathlib import Path
import os,signal,subprocess as sp,sys,time,json
worker=2933913;scheduler=2408034
assert b'/tmp/stock-pipeline-affected-resume.py' in Path(f'/proc/{worker}/cmdline').read_bytes()
assert Path(f'/proc/{scheduler}/stat').read_text().split(') ',1)[1].split()[0]=='T'
target=Path(sys.argv[1]);assert target.parent==Path('/tmp') and target.suffix=='.lean'
s=Path('/tmp/stock-d0-witness-lane.py').read_text();a=s.index('def active_cap():');b=s.index('\nos.kill(scheduler',a)
def caps(pid):
 ns={'Path':Path,'scheduler':pid};exec(s[a:b],ns);return ns['active_cap']()[0]
def stop(signum,frame):raise SystemExit(signum)
signal.signal(signal.SIGTERM,stop)
os.kill(worker,signal.SIGSTOP)
try:
 while caps(worker)+caps(scheduler)>12*2**30:time.sleep(1)
 assert Path(f'/proc/{worker}/stat').read_text().split(') ',1)[1].split()[0]=='T'
 assert Path(f'/proc/{scheduler}/stat').read_text().split(') ',1)[1].split()[0]=='T'
 print(json.dumps({'existing_caps':caps(worker)+caps(scheduler),'borrowed_aux_cap':4*2**30,'aggregate_limit':16*2**30}),flush=True)
 env=dict(os.environ,PATH='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:'+os.environ['PATH'],FV_LAKE_CACHE='/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache',FV_MEMCAP='4G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',LEAN_PATH='/tmp:/home/lee/clifv/.worktrees/stock-driver-incremental/.lake/build/lib/lean')
 os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:2])
 with target.with_suffix('.log').open('w') as f:r=sp.run(['scripts/memcap.sh','lean','--root=/tmp','-o',str(target.with_suffix('.olean')),str(target)],cwd='/home/lee/clifv/.worktrees/stock-driver-incremental',env=env,stdout=f,stderr=sp.STDOUT)
 print(json.dumps({'returncode':r.returncode}),flush=True)
finally:
 os.kill(worker,signal.SIGCONT);print('Affected controller resumed; existing kernels were never interrupted.',flush=True)
