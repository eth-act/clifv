import FV.Backend.Lowering.Stock

namespace Backend.Stock.D0Draft

attribute [local semireducible] Isle.Aarch64.program Stock.runTerm Backend.runTerm

/-- An input-defined first production class; the name is arbitrary. -/
def parameterReturn (name : String) (ty : Clif.Ty) : Clif.Function := {
  name
  sig := { params := [⟨ty, .none, .normal⟩], returns := [⟨ty, .none, .normal⟩] }
  blocks := [{ id := 0, params := [(0, ty)], term := .ret [0] }] }

/-- Dense numbering is an adapter for this proved class, not an assertion about
arbitrary Stock output. Per-successor vectors are empty on the D0 return graph. -/
def denseReg : Reg → Reg
  | .vreg n cls => .vreg (n - firstUserVreg) cls
  | r => r

def denseCode (vc : VCode) : VCode := {
  vc with
  classes := vc.classes.extract firstUserVreg vc.classes.size
  blocks := vc.blocks.map fun b => { b with
    insts := b.insts.map (·.mapRegs denseReg)
    params := b.params.map denseReg
    branchArgs := b.branchArgs.map denseReg } }

set_option maxRecDepth 20000
set_option maxHeartbeats 500000

/-- The proof target is universal in names; no output-equality runtime test or
per-program certificate can establish this equation. -/
example (name : String) :
    (Stock.lower (parameterReturn name .i64)).map (fun r => denseCode r.code) =
      lowerFunction (parameterReturn name .i64) := by
  rfl

example (name : String) :
    (Stock.lower (parameterReturn name .i32)).map (fun r => denseCode r.code) =
      lowerFunction (parameterReturn name .i32) := by
  rfl

end Backend.Stock.D0Draft
