import FV.Backend.Lowering.Stock

namespace Backend.Stock.D0Draft



/-- An input-defined first production class; the name is arbitrary. -/
def parameterReturn (name : String) (ty : Clif.Ty) : Clif.Function := {
  name
  sig := { params := [⟨ty, .none, .normal⟩], returns := [⟨ty, .none, .normal⟩] }
  blocks := [{ id := 0, params := [(0, ty)], term := .ret [0] }] }

/-- Dense numbering is an adapter for this proved class, not an assertion about
arbitrary Stock output. Per-successor vectors are empty on the D0 return graph. -/
def denseReg : Reg → Reg
  | .vreg n cls => .vreg (n - firstUserVreg) cls
  | r => r

def denseCode (vc : VCode) : VCode := {
  vc with
  classes := vc.classes.extract firstUserVreg vc.classes.size
  blocks := vc.blocks.map fun b => { b with
    insts := b.insts.map (·.mapRegs denseReg)
    params := b.params.map denseReg
    branchArgs := b.branchArgs.map denseReg } }

def summary (vc : VCode) :=
  (vc.name, vc.blocks.toList.map fun b => (b.label, b.insts.toList, b.params.toList, b.branchArgs.toList),
   vc.classes.toList, vc.slotBytes, vc.outgoing, vc.rulesFired.toList)
#eval do
  let f := parameterReturn "any_name" .i64
  IO.println (reprStr ((Stock.lower f).map (fun (r : Backend.Stock.Result) => summary (denseCode r.code))))
  IO.println (reprStr ((lowerFunction f).map summary))
end Backend.Stock.D0Draft
