import Lean
import StockD0RuntimeDraft
import FV.Backend.Proof.LowerLoopCode

namespace Backend.Stock.IncrementalD0Draft
open Backend.Proof.Driver
set_option maxRecDepth 100000
set_option maxHeartbeats 8000000
set_option Elab.async false

deriving instance DecidableEq for VBlock
deriving instance DecidableEq for VCode
deriving instance DecidableEq for Except
attribute [-instance] instDecidableEqVBlock_stockD0ProofDraft instDecidableEqVCode_stockD0ProofDraft instDecidableEqExcept_stockD0ProofDraft
attribute [local instance] instDecidableEqVBlock_stockD0ProofDraft instDecidableEqVCode_stockD0ProofDraft instDecidableEqExcept_stockD0ProofDraft

macro "d0_open_kernel_decide" : tactic => `(tactic|
  run_tac do
    let g ← Lean.Elab.Tactic.getMainGoal
    let proof ← Lean.Meta.mkDecideProof (← g.getType)
    g.assign proof)

def eraseName (vc : VCode) : VCode := {vc with name := ""}

private theorem erased_n32 (name : String) (runs : List Clif.RunCommand) :
    (Stock.lower (source name .n32 runs)).map (fun r => eraseName (denseCode r.code)) =
      (lowerFunction (source name .n32 runs)).map eraseName := by d0_open_kernel_decide
private theorem erased_s32 (name : String) (runs : List Clif.RunCommand) :
    (Stock.lower (source name .s32 runs)).map (fun r => eraseName (denseCode r.code)) =
      (lowerFunction (source name .s32 runs)).map eraseName := by d0_open_kernel_decide
private theorem erased_f32 (name : String) (runs : List Clif.RunCommand) :
    (Stock.lower (source name .f32 runs)).map (fun r => eraseName (denseCode r.code)) =
      (lowerFunction (source name .f32 runs)).map eraseName := by d0_open_kernel_decide
private theorem erased_n64 (name : String) (runs : List Clif.RunCommand) :
    (Stock.lower (source name .n64 runs)).map (fun r => eraseName (denseCode r.code)) =
      (lowerFunction (source name .n64 runs)).map eraseName := by d0_open_kernel_decide
private theorem erased_s64 (name : String) (runs : List Clif.RunCommand) :
    (Stock.lower (source name .s64 runs)).map (fun r => eraseName (denseCode r.code)) =
      (lowerFunction (source name .s64 runs)).map eraseName := by d0_open_kernel_decide
private theorem erased_f64 (name : String) (runs : List Clif.RunCommand) :
    (Stock.lower (source name .f64 runs)).map (fun r => eraseName (denseCode r.code)) =
      (lowerFunction (source name .f64 runs)).map eraseName := by d0_open_kernel_decide

theorem erased_code (name : String) (c : Configuration) (runs : List Clif.RunCommand) :
    (Stock.lower (source name c runs)).map (fun r => eraseName (denseCode r.code)) =
      (lowerFunction (source name c runs)).map eraseName := by
  cases c with
  | n32 => exact erased_n32 name runs
  | s32 => exact erased_s32 name runs
  | f32 => exact erased_f32 name runs
  | n64 => exact erased_n64 name runs
  | s64 => exact erased_s64 name runs
  | f64 => exact erased_f64 name runs

theorem legacy_name {f : Clif.Function} {vc : VCode}
    (h : lowerFunction f = .ok vc) : vc.name = f.name := by
  rw [lowerFunction_eq] at h
  simp only [lowerFunction', bind, Except.bind, pure, Except.pure] at h
  repeat' first | split at h | cases h
  all_goals rfl

theorem normalized_eq_legacy (name : String) (c : Configuration) (runs : List Clif.RunCommand) :
    (Stock.lower (source name c runs)).map (compact name) =
      lowerFunction (source name c runs) := by
  have h := congrArg (Except.map (fun vc : VCode => {vc with name})) (erased_code name c runs)
  have hl :
      ((Stock.lower (source name c runs)).map (fun r => eraseName (denseCode r.code))).map
          (fun vc : VCode => {vc with name}) =
        (Stock.lower (source name c runs)).map (compact name) := by
    cases Stock.lower (source name c runs) <;> rfl
  rw [hl] at h
  rw [h]
  cases hr : lowerFunction (source name c runs) with
  | error e => rfl
  | ok vc =>
    change Except.ok {eraseName vc with name} = Except.ok vc
    have hn : vc.name = name := legacy_name hr
    cases vc
    cases hn
    rfl

theorem eligible_sound {f : Clif.Function} (h : eligible f = true) :
    ∃ c ∈ configurations, f = source f.name c f.runs := by
  simpa [eligible, List.any_eq_true] using h

theorem lower_eq_legacy (f : Clif.Function) : lower f = lowerFunction f := by
  unfold lower
  split
  next h =>
    obtain ⟨c, _, hf⟩ := eligible_sound h
    have same : (Stock.lower f).map (compact f.name) = lowerFunction f := by
      simpa only [← hf] using normalized_eq_legacy f.name c f.runs
    cases hs : Stock.lower f with
    | error e => rfl
    | ok r => simpa only [hs, Except.map] using same
  next => rfl

#print axioms erased_code
#print axioms normalized_eq_legacy
#print axioms lower_eq_legacy
end Backend.Stock.IncrementalD0Draft
