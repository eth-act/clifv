import Lean
import StockD0RuntimeDraft
import FV.Backend.Proof.LowerLoopCode

namespace Backend.Stock.IncrementalD0Draft
open Backend.Proof.Driver
set_option maxRecDepth 100000
set_option maxHeartbeats 8000000
set_option Elab.async false

deriving instance DecidableEq for VBlock
deriving instance DecidableEq for VCode
deriving instance DecidableEq for Except


#synth DecidableEq VBlock
#synth DecidableEq VCode
#synth DecidableEq (Except String VCode)
end Backend.Stock.IncrementalD0Draft
