import StockD0DispatchWitnessDraft
import StockD0ConsumerDraft
import FV.E2E.LinkScopeInput
import FV.E2E.DeadCleanupLinkScope
import FV.E2E.SpillDefined

namespace Backend.Stock.IncrementalD0Draft
open E2E E2E.LinkCheck E2E.LinkCheck.IncrementalAdapterDraft
set_option maxRecDepth 100000
set_option maxHeartbeats 8000000
set_option Elab.async false

private theorem source_input_scope (name : String) (c : Configuration)
    (runs : List Clif.RunCommand) : fnScopeInB (source name c runs) = true := by
  cases c <;> d0_open_kernel_decide

/-- Inhabited full pipelines, with real Stock selection, both cleanup settings,
all six input configurations, arbitrary metadata and arbitrary allocator answers.
The existing checked-allocation/spill and emission fallbacks remain the real ones. -/
theorem complete_pipeline_witness (name : String) (c : Configuration)
    (runs : List Clif.RunCommand) (k : Nat) (base : BitVec 64) (answer : Lean.Json) :
    ∃ (result : Result) (plain clean : E2E.Art),
      Stock.lower (source name c runs) = .ok result ∧
      selectWith Stock.lower (source name c runs) = .ok (.stockD0, compact name result) ∧
      pipeTWith defaultLower id (source name c runs) k base answer = .ok plain ∧
      pipeTWith defaultLower DeadCleanup.prune (source name c runs) k base answer = .ok clean := by
  have scope := fnScopeB_of_input (source_input_scope name c runs)
  obtain ⟨result, run, selected, _⟩ := default_source_success name c runs
  obtain ⟨plain, hp, _, _, _, _⟩ := pipeT_ok scope spillDefinedHyp k base answer
  obtain ⟨clean, hc, _, _, _, _⟩ := pipeCleanupT_ok scope spillDefinedHyp k base answer
  refine ⟨result, plain, clean, run, selected, ?_, ?_⟩
  · rw [consumer_total_eq]
    exact hp
  · rw [consumer_cleanup_total_eq]
    exact hc

#print axioms source_input_scope
#print axioms complete_pipeline_witness
end Backend.Stock.IncrementalD0Draft
