from pathlib import Path
import os,subprocess as sp,json,time,datetime,hashlib,traceback
view=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');canon=Path('/home/lee/clifv/.worktrees/driver-proof-resume');root=Path('/tmp/stock-pipeline-affected-gates');root.mkdir(exist_ok=True);state=Path('/tmp/stock-pipeline-affected-gates-progress.json');head='5f4f9bf65638071f61db2de3ea27396b6cff8503';logs=json.loads(Path('/tmp/stock-affected-completed-receipts.json').read_text());now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
baseenv=dict(os.environ);baseenv.update(PATH='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:/home/lee/.cargo/bin:/home/lee/.local/share/clifv-test-tools/usr/bin:/home/lee/.rustup/toolchains/nightly-2026-09-26-x86_64-unknown-linux-gnu/lib/rustlib/x86_64-unknown-linux-gnu/bin:'+str(view/'rust/target/release')+':'+baseenv['PATH'],FV_ROOT=str(view),FV_AR='/home/lee/.local/share/clifv-test-tools/usr/bin/llvm-ar',FV_OBJCOPY='/home/lee/.local/share/clifv-test-tools/usr/bin/llvm-objcopy',FV_LAKE_CACHE=str(canon/'.lake/artifact-cache'),FV_MEMCAP='8G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',CARGO_BUILD_JOBS='2',CLIF_NATIVE_QEMU='/home/lee/.local/share/clifv-test-tools/usr/bin/qemu-aarch64-static',LLVM_MC='/home/lee/.local/share/clifv-test-tools/usr/bin/llvm-mc',PYTHONPATH=str(view/'scripts'))
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:8])
def report(status,**kw):
 state.write_text(json.dumps({'utc':now(),'state':status,'pid':os.getpid(),'head':head,'logs':logs,**kw},indent=2)+'\n');print(json.dumps({'utc':now(),'state':status,**kw}),flush=True)
def frozen():
 manifest=json.loads(Path('/tmp/stock-pipeline-first-gate-inputs.json').read_text());assert sp.check_output(['git','rev-parse','HEAD'],cwd=view,text=True).strip()==head
 assert {str(p.relative_to(view)):sha(p) for d in ['FV','FVTest'] for p in (view/d).rglob('*.lean')}==manifest['sources']
def run(name,args,cwd=view,env=None):
 frozen();p=root/(name+'.log')
 if name in logs and p.is_file() and sha(p)==logs[name]['sha256']:
  report('reusing_passed_source_matching_gate',phase=name,log=str(p));return p
 report('running',phase=name,log=str(p))
 with p.open('w') as f:r=sp.run([str(view/'scripts/memcap.sh'),*args],cwd=cwd,env=env or baseenv,stdout=f,stderr=sp.STDOUT)
 assert r.returncode==0,f'{name} rc={r.returncode}, log={p}';frozen();logs[name]={'path':str(p),'sha256':sha(p)};return p
try:
 report('independent_affected_gates_while_module_gate_pending')
 frozen()
 tools=root/'tools.log';assert 'Build completed successfully (1391 jobs).' in tools.read_text();logs['tools']={'path':str(tools),'sha256':sha(tools),'reused_current_frozen_source':True}
 report('required_audit_deferred_until_missing_module_outputs_built', previous_failure_log=str(root/'e2e-axiom-audit.log'))
 audit=root/'new-roots.lean'
 audit.write_text('import FV.Backend.Proof.LoweringPipeline\n#print axioms Backend.Proof.LoweringPipeline.compileFileWith_legacy\n#print axioms Backend.Proof.LoweringPipeline.successor_payload_witness\n#print axioms Backend.Proof.LoweringPipeline.legacy_specialization_witness\n')
 run('new-roots',['lake','env','lean','--root='+str(root),str(audit)])
 run('runtime',['bash','scripts/lean-backend-filetests.sh'])
 run('encoder',['bash','scripts/lean-backend-encode-check.sh'])
 for label,flags in [('e2e',[]),('legacy-e2e',['--no-dead-cleanup'])]:
  run(label,['lake','exe','lean-e2e-check',*flags,'--identity-report',str(root/(label+'-identities.json'))])
 frozen()
 run('new-module-all-constants',['lake','env','lean','--root=/tmp','/tmp/stock-pipeline-all-constants.lean'])
 run('stock-development-artifacts',['python3','-m','unittest','-v','test_stock_compiler_compare.StockDevelopmentIntegrationTests'])
 src=Path('/home/lee/clifv/.worktrees/rust-cgclif-source-20260926');metadata=json.loads(Path('/tmp/stock-cgclif-source.json').read_text());assert sp.check_output(['git','rev-parse','HEAD'],cwd=src,text=True).strip()==metadata['commit'];assert sha(view/'scripts/patches/cg-clif-extnames.patch')==metadata['patch_sha256'];sp.run(['git','apply','--reverse','--check',str(view/'scripts/patches/cg-clif-extnames.patch')],cwd=src,check=True)
 sysroot=sp.check_output(['rustc','+nightly-2026-09-26','--print','sysroot'],env=baseenv,text=True).strip();cg_env=dict(baseenv,CARGO_TARGET_DIR=str(canon/'rust/target'),RUSTFLAGS='-L native='+sysroot+'/lib')
 run('patched-cgclif',['cargo','+nightly-2026-09-26','build','--release','--locked','--features','unwinding'],cwd=src/'compiler/rustc_codegen_cranelift',env=cg_env)
 import shutil
 out=canon/'target/cg_clif/unwind/librustc_codegen_cranelift.so';out.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(canon/'rust/target/release/librustc_codegen_cranelift.so',out);metadata.update(build_status='built exact pinned patched frontend',output_sha256=sha(out));Path('/tmp/stock-cgclif-source.json').write_text(json.dumps(metadata,indent=2)+'\n')
 run('rust-frontend-tools',['cargo','build','--release','--locked','-p','cargo-fv','-p','clif-data-export','-p','lean-regalloc'],cwd=view/'rust')
 for example in ['fv-demo','survey']:
  run('verified-'+example,['bash','examples/compare.sh','examples/'+example,'--lean-link','--verified','--keep-temps'])
 # Compare the original acceptance identities and every successful stage, both modes.
 baseline_root=Path('/tmp');current=root;parity={}
 def identity(d):
  fs=d['functions'];keys=[(f['file'],f['index'],f['function']) for f in fs];assert len(keys)==len(set(keys));return {k:tuple(f['stages']) for k,f in zip(keys,fs)}
 for label,old in [('e2e','legacy-dead-cleanup-final-e2e-identities.json'),('legacy-e2e','legacy-dead-cleanup-final-legacy-e2e-identities.json')]:
  previous=baseline_root/old;actual=current/(label+'-identities.json');a=identity(json.loads(previous.read_text()));b=identity(json.loads(actual.read_text()));assert len(a)==1150;missing=set(a)-set(b);changed=[k for k in a.keys()&b.keys() if not set(a[k])<=set(b[k])];assert not missing and not changed,(missing,changed)
  parity[label]={'original':1150,'current':len(b),'lost':0,'lost_successful_stages':0,'gained':len(b.keys()-a.keys()),'original_sha256':sha(previous),'current_sha256':sha(actual),'exact_identity_and_ordered_stage_parity':a==b}
 (root/'identity-stage-parity.json').write_text(json.dumps(parity,indent=2)+'\n')
 report('runtime_gates_finished_required_audit_and_module_gate_pending',identity_stage_parity=parity,remaining='inspect actual gate counts and provenance; ONE bundled MCP; source-matching final evidence/PR/main reconciliation/author squash')
except BaseException as error:report('failed',error=repr(error),traceback=traceback.format_exc());raise
