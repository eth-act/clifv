from pathlib import Path
import os,signal,subprocess as sp,sys,time,json
# Borrow4GiB beside the existing8GiB affected-gate reservation. Freeze only its
# waiting coordinator so it cannot release the scheduler before this job ends.
worker=2615240;scheduler=2408034
assert b'/tmp/stock-pipeline-affected-gates.py' in (Path('/proc')/str(worker)/'cmdline').read_bytes()
parent=int((Path('/proc')/str(worker)/'stat').read_text().split(') ',1)[1].split()[1])
assert b'/tmp/stock-affected-gates-lane.py' in (Path('/proc')/str(parent)/'cmdline').read_bytes()
assert (Path('/proc')/str(scheduler)/'stat').read_text().split(') ',1)[1].split()[0]=='T'
target=Path(sys.argv[1]);assert target.parent==Path('/tmp') and target.suffix=='.lean'
base=Path('/tmp/stock-d0-witness-lane.py').read_text();start=base.index('def active_cap():');end=base.index('\nos.kill(scheduler',start);ns={'Path':Path,'scheduler':scheduler};exec(base[start:end],ns);active_cap=ns['active_cap']
os.kill(parent,signal.SIGSTOP)
def stop(signum,frame):raise SystemExit(signum)
signal.signal(signal.SIGTERM,stop)
try:
 total,_=active_cap()
 while total>4*2**30:time.sleep(1);total,_=active_cap()
 print(json.dumps({'full_remaining_caps':total,'affected_reserved':8*2**30,'auxiliary_reserved':4*2**30,'within16GiB':total+12*2**30<=16*2**30}),flush=True)
 env=dict(os.environ,PATH='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:'+os.environ['PATH'],FV_LAKE_CACHE='/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache',FV_MEMCAP='4G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',LEAN_PATH='/tmp:/home/lee/clifv/.worktrees/stock-driver-incremental/.lake/build/lib/lean')
 os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:2])
 with target.with_suffix('.log').open('w') as f:r=sp.run(['scripts/memcap.sh','lean','--root=/tmp','-o',str(target.with_suffix('.olean')),str(target)],cwd='/home/lee/clifv/.worktrees/stock-driver-incremental',env=env,stdout=f,stderr=sp.STDOUT)
 print(json.dumps({'returncode':r.returncode}),flush=True)
finally:
 os.kill(parent,signal.SIGCONT);print('Affected-gate coordinator resumed; all running kernels were preserved.',flush=True)
