from pathlib import Path
import difflib,json,subprocess as sp
view=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');out=Path('/tmp/stock-consumer-adapter-packet');files={}
for file in ['FV/E2E/LinkCheck.lean','FV/E2E/DeadCleanupLinkCheck.lean']:
 source=out/Path(file).name;files[file]=source.read_text().replace('\n\ndef pipe (','\ndef pipe (').replace('\n\ndef pipeT (','\ndef pipeT (')
changes={
 'FV/Link/Total.lean':('[pipeT, bind','[pipeT, pipeTWithLowering, bind'),
 'FV/Link/DeadCleanupTotal.lean':('[pipeCleanupT, bind','[pipeCleanupT, pipeTWithLowering, bind'),
 'FV/Link/LayoutFacts.lean':('unfold pipeT at h','unfold pipeT pipeTWithLowering at h'),
 'FV/Link/DeadCleanupLayoutFacts.lean':('unfold pipeCleanupT at h','unfold pipeCleanupT pipeTWithLowering at h'),
 'FV/E2E/LinkScope.lean':('[pipeT, hl','[pipeT, pipeTWithLowering, hl'),
 'FV/E2E/DeadCleanupLinkScope.lean':('[pipeCleanupT, hl','[pipeCleanupT, pipeTWithLowering, hl')}
for file,(old,new) in changes.items():
 s=(view/file).read_text();assert s.count(old)==1,(file,s.count(old));files[file]=s.replace(old,new)
s=Path('/tmp/StockConsumerAdapterDraft.lean').read_text();s=s[s.index('theorem pipe_legacy'):];s=s.replace('pipeTWith','pipeTWithLowering').replace('pipeWith','pipeWithLowering').replace('end E2E.LinkCheck.IncrementalAdapterDraft','end E2E.LinkCheck.LoweringPipeline')
files['FV/E2E/LoweringPipeline.lean']='import FV.E2E.DeadCleanupLinkCheck\n\nnamespace E2E.LinkCheck.LoweringPipeline\nopen Backend\n\n'+s
patch=[]
for file,body in files.items():
 target=out/file;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(body)
 original=(view/file).read_text() if (view/file).exists() else ''
 patch.extend(difflib.unified_diff(original.splitlines(True),body.splitlines(True),fromfile='a/'+file if original else '/dev/null',tofile='b/'+file))
(out/'implementation.patch').write_text(''.join(patch));sp.run(['git','apply','--check',str(out/'implementation.patch')],cwd=view,check=True)
(out/'packet.json').write_text(json.dumps({'status':'prepared source patch; actual consumer modules require next-batch compilation, not first-packet gates','base':sp.check_output(['git','rev-parse','HEAD'],cwd=view,text=True).strip(),'files':list(files),'reason':'four pipeline variants plus all six direct production proof unfold sites; original theorem statements unchanged; private NonVacuityLink.pipe is independent and untouched'},indent=2)+'\n')
print('Prepared',len(files),'source files; git apply --check passed; active frozen tree unchanged.')
