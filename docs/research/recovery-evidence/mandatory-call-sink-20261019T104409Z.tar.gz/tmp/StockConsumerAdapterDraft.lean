import FV.E2E.DeadCleanupLinkCheck

namespace E2E.LinkCheck.IncrementalAdapterDraft
open Backend

/-- Lowering and cleanup are supplied before the unchanged allocation-answer,
physical lowering, emission and layout consumers. -/
def pipeWith (lower : Clif.Function → Except String VCode) (stage : VCode → VCode)
    (f : Clif.Function) (k : Nat) (base : BitVec 64) (o : Lean.Json) : Except String Art := do
  let vc ← lower f
  let vcp ← prepare (stage vc)
  let o ← parseRAOut o
  let rf ← buildRFunc vcp o
  let af ← lowerRFunc vcp rf
  let fa ← emitFunc k af
  let fb ← fa.layout
  pure ⟨k, vc, vcp, rf, af, fa, fb, base⟩

/-- Preserve the exact ready-answer/spill fallback selected by the real total
pipeline. The answer attached to the artifact is the answer actually lowered. -/
def pipeTWith (lower : Clif.Function → Except String VCode) (stage : VCode → VCode)
    (f : Clif.Function) (k : Nat) (base : BitVec 64) (o : Lean.Json) : Except String Art := do
  let vc ← lower f
  let vcp ← prepare (stage vc)
  let ra := raAnswer vcp o
  let af ← lowerAllocReady vcp ra
  let fa ← emitFunc k af
  let fb ← fa.layout
  pure ⟨k, vc, vcp, allocResult vcp (readyAnswer vcp ra), af, fa, fb, base⟩

theorem pipe_legacy (f : Clif.Function) (k : Nat) (base : BitVec 64) (o : Lean.Json) :
    pipeWith lowerFunction id f k base o = pipe f k base o := rfl

theorem pipeT_legacy (f : Clif.Function) (k : Nat) (base : BitVec 64) (o : Lean.Json) :
    pipeTWith lowerFunction id f k base o = pipeT f k base o := rfl

theorem pipeCleanup_legacy (f : Clif.Function) (k : Nat) (base : BitVec 64) (o : Lean.Json) :
    pipeWith lowerFunction DeadCleanup.prune f k base o = pipeCleanup f k base o := rfl

theorem pipeCleanupT_legacy (f : Clif.Function) (k : Nat) (base : BitVec 64) (o : Lean.Json) :
    pipeTWith lowerFunction DeadCleanup.prune f k base o = pipeCleanupT f k base o := rfl

/-- Pointwise equality preserves successes, errors and all artifact fields, for
arbitrary allocator answers and input settings. No successful-output test is used. -/
theorem pipeWith_congr {lower other : Clif.Function → Except String VCode}
    (same : ∀ f, lower f = other f) (stage : VCode → VCode)
    (f : Clif.Function) (k : Nat) (base : BitVec 64) (o : Lean.Json) :
    pipeWith lower stage f k base o = pipeWith other stage f k base o := by
  simp only [pipeWith, same]

theorem pipeTWith_congr {lower other : Clif.Function → Except String VCode}
    (same : ∀ f, lower f = other f) (stage : VCode → VCode)
    (f : Clif.Function) (k : Nat) (base : BitVec 64) (o : Lean.Json) :
    pipeTWith lower stage f k base o = pipeTWith other stage f k base o := by
  simp only [pipeTWith, same]

private def source : Clif.Function := {
  name := "consumer_compatibility"
  sig := { params := [⟨.i64, .none, .normal⟩], returns := [⟨.i64, .none, .normal⟩] }
  blocks := [{ id := 0, params := [(0, .i64)], term := .ret [0] }] }

/-- Inhabited source, all metadata and allocator answers, both cleanup modes and
both allocation modes. This witnesses compatibility, not pipeline totality. -/
theorem legacy_consumer_witness (k : Nat) (base : BitVec 64) (o : Lean.Json) :
    pipeWith lowerFunction id source k base o = pipe source k base o ∧
    pipeTWith lowerFunction id source k base o = pipeT source k base o ∧
    pipeWith lowerFunction DeadCleanup.prune source k base o = pipeCleanup source k base o ∧
    pipeTWith lowerFunction DeadCleanup.prune source k base o = pipeCleanupT source k base o ∧
    (∀ f, lowerFunction f = lowerFunction f) := by
  exact ⟨rfl, rfl, rfl, rfl, fun _ => rfl⟩

#print axioms pipe_legacy
#print axioms pipeT_legacy
#print axioms pipeCleanup_legacy
#print axioms pipeCleanupT_legacy
#print axioms pipeWith_congr
#print axioms pipeTWith_congr
#print axioms legacy_consumer_witness
end E2E.LinkCheck.IncrementalAdapterDraft
