import FV.Backend.Proof.LowerLoopCode
namespace Backend.Stock.D0NameDraft
open Backend.Proof.Driver
set_option maxRecDepth 100000
set_option maxHeartbeats 500000

theorem legacy_name {f : Clif.Function} {vc : VCode}
    (h : lowerFunction f = .ok vc) : vc.name = f.name := by
  rw [lowerFunction_eq] at h
  simp only [lowerFunction', bind, Except.bind, pure, Except.pure] at h
  repeat' first
    | split at h
    | cases h
  all_goals rfl
#print axioms legacy_name
end Backend.Stock.D0NameDraft
