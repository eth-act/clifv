import FV.Backend.Lowering.Stock

namespace Backend.Stock.IncrementalD0Draft

inductive Configuration where
  | n32 | s32 | f32 | n64 | s64 | f64
  deriving DecidableEq, Repr, Inhabited

def configurations : List Configuration := [.n32, .s32, .f32, .n64, .s64, .f64]
def valueType : Configuration → Clif.Ty
  | .n32 | .s32 | .f32 => .i32
  | .n64 | .s64 | .f64 => .i64
def convention : Configuration → Option Clif.CallConv
  | .n32 | .n64 => none
  | .s32 | .s64 => some .systemV
  | .f32 | .f64 => some .fast

/-- Structural class with arbitrary symbol names and filetest metadata. -/
def source (name : String) (c : Configuration) (runs : List Clif.RunCommand := []) : Clif.Function := {
  name
  sig := { params := [⟨valueType c, .none, .normal⟩],
           returns := [⟨valueType c, .none, .normal⟩], callConv := convention c }
  blocks := [{ id := 0, params := [(0, valueType c)], term := .ret [0] }]
  runs }

def eligible (f : Clif.Function) : Bool :=
  configurations.any fun c => decide (f = source f.name c f.runs)

def denseReg : Reg → Reg
  | .vreg n cls => .vreg (n - firstUserVreg) cls
  | r => r

def denseCode (vc : VCode) : VCode := {
  vc with
  classes := vc.classes.extract firstUserVreg vc.classes.size
  blocks := vc.blocks.map fun b => { b with
    insts := b.insts.map (·.mapRegs denseReg)
    params := b.params.map denseReg
    branchArgs := b.branchArgs.map denseReg } }

def compact (name : String) (r : Result) : VCode := {denseCode r.code with name}

/-- A candidate runtime route only. Production must not use it until the fixed
all-input compatibility theorem and consumer agreement are checked. -/
def lower (f : Clif.Function) : Except String VCode :=
  if eligible f then
    match Stock.lower f with
    | .ok r => .ok (compact f.name r)
    | .error _ => lowerFunction f
  else lowerFunction f

end Backend.Stock.IncrementalD0Draft
