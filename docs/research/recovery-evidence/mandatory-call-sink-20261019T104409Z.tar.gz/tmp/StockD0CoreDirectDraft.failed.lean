import StockD0RuntimeDraft
import Lean
namespace Backend.Stock.IncrementalD0Draft
set_option maxRecDepth 20000
set_option maxHeartbeats 30000
set_option Elab.async false
attribute [local irreducible] emitBranch scanBlock
private theorem collect_empty (ctx : Ctx) (order : Order) (bi : Nat) (input : State) :
    collectOutgoing ctx order bi #[] input = .ok (input, #[]) := rfl
#print axioms collect_empty
/-- Zero outgoing vectors follow from the real collector for zero targets,
without evaluating the ISLE scan or importing unrelated rule-family proofs. -/
private theorem core_empty_outgoing {ctx : Ctx} {order : Order} {f : Clif.Function}
    {b : Clif.Block} {bi start stop : Nat} {data : Backend.V}
    {input : State} {output : LoweredBlockCore}
    (run : lowerBlockCore ctx order f b bi start stop data #[] input = .ok output) :
    output.outgoing = #[] := by
  simp only [lowerBlockCore, collect_empty, bind, Except.bind,
    pure, Except.pure] at run
  repeat' first
    | (solve | cases run)
    | split at run
  all_goals
    cases run
    rfl

#print axioms core_empty_outgoing
end Backend.Stock.IncrementalD0Draft
