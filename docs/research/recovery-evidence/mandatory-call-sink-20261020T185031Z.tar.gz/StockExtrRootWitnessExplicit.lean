import StockExtrCanonicalMatch
import FV.E2E.StockArithmeticStage
import FV.Backend.LinearScan
import FV.Backend.Lowering.StockD0
namespace E2E.StockLogicalExtrWitness
open Backend Backend.Proof Backend.Proof.Driver Backend.Stock.D0
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm

/-- Distinct shift operands, a consumed ninth ABI argument, unused parameters,
an explicit slot and a dead statement. Both original OR operand orders occur. -/
def function (config : Configuration) (mirrored : Bool) : Clif.Function :=
  let ty := valueType config
  {source "stock_logical_extr" config [] with
    sig := {
      params := List.replicate 9 ⟨ty,.none,.normal⟩
      returns := [⟨ty,.none,.normal⟩]
      callConv := convention config}
    slots := [(7,⟨8,some 8⟩)]
    blocks := [{
      id := 0
      params := (List.range 9).map (fun i => (i,ty))
      body := [⟨[9],.iconst ty (ty.width-1 : Nat)⟩,⟨[10],.iconst ty 1⟩,
        ⟨[11],.binary .ishl ty 1 9⟩,⟨[12],.binary .ushr ty 8 10⟩,
        ⟨[13],.binary .bor ty (if mirrored then 12 else 11) (if mirrored then 11 else 12)⟩,
        ⟨[14],.binary .bxor ty 0 2⟩]
      term := .ret [13]}]}
def selected (result : Stock.Result) (mirrored : Bool) : Bool :=
  result.schedule.any fun step => step.rules.contains
    (if mirrored then Isle.Aarch64.rule_lower_1507.id else Isle.Aarch64.rule_lower_1501.id)

private def checks (config : Configuration) (mirrored cleanup : Bool) : Bool :=
  lowerScopeB (function config mirrored) && dominatedB (function config mirrored) && sigAbiOk (function config mirrored).sig &&
  match Stock.lower (function config mirrored) with
  | .error _ => false
  | .ok result =>
    (!lowerCheck (function config mirrored) result.code && selected result mirrored) &&
    match Backend.prepare (Stock.Arithmetic.stage cleanup result.code) with
    | .error _ => false
    | .ok vcp =>
      prepCheck (Stock.Arithmetic.stage cleanup result.code) vcp &&
      match leanAlloc vcp with
      | .error _ => false
      | .ok rf =>
        (checkAlloc vcp rf).isOk &&
        match lowerRFunc vcp rf with
        | .error _ => false
        | .ok af =>
          match emitFunc 0 af with
          | .error _ => false
          | .ok fa => formsCoveredB ⟨fa.k,af.slotBase⟩ vcp && fa.layout.isOk


private def grid : Bool := configurations.all fun config =>
  [false,true].all fun mirrored => [false,true].all fun cleanup => checks config mirrored cleanup
-- witness: native_decide (24 fixed actual full-pipeline configurations only)
theorem checks_true : grid = true := by native_decide

/-- Real Stock EXTR programs pass both cleanup modes through checked Lean
allocation and emitted bytes in every existing integer ABI configuration. -/
theorem compiled_exists (config : Configuration) (mirrored cleanup : Bool) :
    LowerScope (function config mirrored) ∧ Dominated (function config mirrored) ∧
    sigAbiOk (function config mirrored).sig = true ∧
    ∃ result vcp rf af fa fb,
      CompiledStockArithmeticStage (function config mirrored) cleanup 0 result vcp rf af fa fb ∧
      selected result mirrored = true ∧ leanAlloc vcp = .ok rf ∧ FormsCovered ⟨fa.k,af.slotBase⟩ vcp ∧
      lowerCheck (function config mirrored) result.code = false := by
  have h : checks config mirrored cleanup = true := by
    have allConfig := List.all_eq_true.mp checks_true config (by cases config <;> simp [configurations])
    have allMirror := List.all_eq_true.mp allConfig mirrored (by cases mirrored <;> simp)
    exact List.all_eq_true.mp allMirror cleanup (by cases cleanup <;> simp)
  simp only [checks,Bool.and_eq_true] at h
  obtain ⟨⟨⟨scope,dominated⟩,abi⟩,h⟩ := h
  refine ⟨lowerScope_of scope,dominated_of dominated,abi,?_⟩
  cases lowered : Stock.lower (function config mirrored) with
  | error message => simp [lowered] at h
  | ok result =>
    simp only [lowered,Bool.and_eq_true,Bool.not_eq_true'] at h
    obtain ⟨⟨legacy,selectedRoot⟩,h⟩ := h
    cases prepared : Backend.prepare (Stock.Arithmetic.stage cleanup result.code) with
    | error message => simp [prepared] at h
    | ok vcp =>
      simp only [prepared,Bool.and_eq_true] at h
      obtain ⟨prepOk,h⟩ := h
      cases allocated : leanAlloc vcp with
      | error message => simp [allocated] at h
      | ok rf =>
        simp only [allocated,Bool.and_eq_true] at h
        obtain ⟨checked,h⟩ := h
        cases physical : lowerRFunc vcp rf with
        | error message => simp [physical] at h
        | ok af =>
          cases emitted : emitFunc 0 af with
          | error message => simp [physical,emitted] at h
          | ok fa =>
            simp only [physical,emitted,Bool.and_eq_true] at h
            obtain ⟨covered,layoutOk⟩ := h
            cases layout : fa.layout with
            | error message => rw [layout] at layoutOk; change false = true at layoutOk; cases layoutOk
            | ok fb =>
              have check : checkAlloc vcp rf = .ok () := by
                cases check : checkAlloc vcp rf with
                | error message => rw [check] at checked; change false = true at checked; cases checked
                | ok value => cases value; rfl
              exact ⟨result,vcp,rf,af,fa,fb,
                ⟨lowered,prepared,prepOk,check,physical,emitted,layout⟩,
                selectedRoot,allocated,(formsCoveredB_iff _ _).mp covered,legacy⟩

end E2E.StockLogicalExtrWitness
namespace E2E.StockLogicalExtrWitness
open Backend Backend.Proof Backend.Proof.Driver Backend.Stock.D0 Backend.Stock.Proof
open Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm

private def built (config : Configuration) (mirrored : Bool) : Ctx × Array (Nat × Nat) × Stock.State :=
  (Stock.buildCtx (function config mirrored)).toOption.getD (sinkCtx,#[],sinkState)
private theorem build (config : Configuration) (mirrored : Bool) :
    Stock.buildCtx (function config mirrored) = .ok (built config mirrored) := by
  cases config <;> cases mirrored <;> rfl
private def matchChecks (config : Configuration) (mirrored : Bool) : Bool :=
  let ctx := (built config mirrored).1
  let st := (built config mirrored).2.2
  lowerScopeB (function config mirrored) &&
  match ctx.insts[4]? with
  | none => false
  | some info =>
    decide (info.data = .data 152 2 [.data 151 98 [],
      .values [if mirrored then 12 else 11,if mirrored then 11 else 12]]) &&
    match (matchRule program (Stock.sem ctx) {} 20 (LogicalExtr.extrRule mirrored) [.inst 4]).run (st,#[]) with
    | .ok (some _,_) => true
    | _ => false
private def matchGrid : Bool := configurations.all fun config =>
  [false,true].all fun mirrored => matchChecks config mirrored
-- witness: native_decide (twelve fixed source contexts and actual rule matches only)
theorem match_checks_true : matchGrid = true := by native_decide

/-- Each ABI/width and mirrored root has an actual successful source match
inhabiting the original two-shift/two-literal definition theorem. -/
theorem source_matches (config : Configuration) (mirrored : Bool) :
    let ctx := (built config mirrored).1
    let st := (built config mirrored).2.2
    ∃ info env middle,
      ctx.insts[4]? = some info ∧
      info.data = .data 152 2 [.data 151 98 [],
        .values [if mirrored then 12 else 11,if mirrored then 11 else 12]] ∧
      (matchRule program (Stock.sem ctx) {} 20 (LogicalExtr.extrRule mirrored) [.inst 4]).run (st,#[]) =
        .ok (some env,middle) ∧
      LogicalExtr.WordSource ctx (if mirrored then 12 else 11) (!mirrored) ∧
      LogicalExtr.WordSource ctx (if mirrored then 11 else 12) mirrored := by
  dsimp only
  have h : matchChecks config mirrored = true := by
    have allConfig := List.all_eq_true.mp match_checks_true config (by cases config <;> simp [configurations])
    exact List.all_eq_true.mp allConfig mirrored (by cases mirrored <;> simp)
  simp only [matchChecks,Bool.and_eq_true] at h
  obtain ⟨scope,h⟩ := h
  have inv := buildCtx_mappedInv (lowerScope_of scope) (build config mirrored)
  cases found : (built config mirrored).1.insts[4]? with
  | none => simp [found] at h
  | some info =>
    simp only [found,Bool.and_eq_true,decide_eq_true_eq] at h
    obtain ⟨data,h⟩ := h
    cases run : (matchRule program (Stock.sem (built config mirrored).1) {} 20
        (LogicalExtr.extrRule mirrored) [.inst 4]).run ((built config mirrored).2.2,#[]) with
    | error message => simp [run] at h
    | ok result =>
      rcases result with ⟨value,middle⟩
      cases value with
      | none => simp [run] at h
      | some env =>
        obtain ⟨first,second⟩ := LogicalExtr.matched_sources data_program inv mirrored found data (n := 0) run
        exact ⟨info,env,middle,rfl,data,rfl,first,second⟩
end E2E.StockLogicalExtrWitness


namespace E2E.StockLogicalExtrWitness
open Backend Backend.Proof Backend.Proof.Driver Backend.Stock.D0 Backend.Stock.Proof
open Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm

private def canonicalBuilt (config : Configuration) (mirrored : Bool) : Ctx × Array (Nat × Nat) × Stock.State :=
  (Stock.buildCtx (function config mirrored)).toOption.getD (sinkCtx,#[],sinkState)
private theorem canonicalBuild (config : Configuration) (mirrored : Bool) :
    Stock.buildCtx (function config mirrored) = .ok (canonicalBuilt config mirrored) := by
  cases config <;> cases mirrored <;> rfl

/-- All twelve original source contexts inhabit the canonical environment and
shift-guard theorem, using their real successful matches and unchanged inputs. -/
theorem canonical_matches (config : Configuration) (mirrored : Bool) :
    let ctx := (canonicalBuilt config mirrored).1
    let st := (canonicalBuilt config mirrored).2.2
    let ty := valueType config
    ∃ (env : Isle.Interp.Env V) (middle : Stock.State × Array RuleId)
      (first : LogicalExtr.SourceWord ctx (if mirrored then 12 else 11) (!mirrored))
      (second : LogicalExtr.SourceWord ctx (if mirrored then 11 else 12) mirrored),
      (matchRule program (Stock.sem ctx) {} 20 (LogicalExtr.extrRule mirrored) [.inst 4]).run (st,#[]) =
        .ok (some env,middle) ∧
      (ty.width = 32 ∨ ty.width = 64) ∧
      ExtrOk ty.width (if mirrored then second.amount else first.amount)
        (if mirrored then first.amount else second.amount) ∧
      env = LogicalExtr.extrEnv mirrored ty.width
        (if mirrored then second.word else first.word) (if mirrored then second.amount else first.amount)
        (if mirrored then first.word else second.word) (if mirrored then first.amount else second.amount) ∧
      middle = (st,#[]) := by
  dsimp only
  obtain ⟨info,env,middle,found,data,run,_,_⟩ := source_matches config mirrored
  have expected : ((canonicalBuilt config mirrored).1.insts[4]?).bind IInfo.clif =
      some (.binary .bor (valueType config) (if mirrored then 12 else 11) (if mirrored then 11 else 12)) := by
    cases config <;> cases mirrored <;> rfl
  change (canonicalBuilt config mirrored).1.insts[4]? = some info at found
  rw [found] at expected
  have clif : info.clif = some (.binary .bor (valueType config)
      (if mirrored then 12 else 11) (if mirrored then 11 else 12)) := expected
  have scope : LowerScope (function config mirrored) := by
    apply lowerScope_of
    cases config <;> cases mirrored <;> decide +kernel
  have inv := buildCtx_mappedInv scope (canonicalBuild config mirrored)
  obtain ⟨first,second,width,guard,envEq,stateEq⟩ :=
    LogicalExtr.match_receipt data_program inv mirrored found clif (n := 0) run
  exact ⟨env,middle,first,second,run,width,guard,envEq,stateEq⟩
end E2E.StockLogicalExtrWitness



namespace E2E.StockLogicalExtrWitness
open Backend Backend.Proof Backend.Proof.Driver Backend.Stock.D0 Backend.Stock.Proof
open Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm
private def rootBuilt (config : Configuration) (mirrored : Bool) : Ctx × Array (Nat × Nat) × Stock.State :=
  (Stock.buildCtx (function config mirrored)).toOption.getD (sinkCtx,#[],sinkState)
private def sourceFrame (config : Configuration) (mirrored : Bool) (a b : CV) : Clif.Frame :=
  let ty := valueType config
  {
   func := function config mirrored
   regs := fun x => if x = 1 then some ⟨ty,a.setWidth ty.width⟩
     else if x = 8 then some ⟨ty,b.setWidth ty.width⟩
     else if x = 9 then some (.ofInt ty (ty.width-1 : Nat))
     else if x = 10 then some (.ofInt ty 1)
     else if x = 11 then some ⟨ty,a.setWidth ty.width <<< (ty.width-1)⟩
     else if x = 12 then some ⟨ty,b.setWidth ty.width >>> 1⟩ else none
   slots := []
   body := []
   term := .ret [13] }
/-- The real looked-through shifts and literals are source-available while
being absent from the machine register file in the fused EXTR witness. -/
private theorem sourceDFG (config : Configuration) (mirrored : Bool) (a b : CV) :
    DFGCons (rootBuilt config mirrored).1 (sourceFrame config mirrored a b) := by
  constructor
  · intro x j info cl v defined found original pure lookup
    by_cases h1 : x = 1
    · subst x
      have absent : (rootBuilt config mirrored).1.defInst? 1 = none := by
        cases config <;> cases mirrored <;> rfl
      rw [absent] at defined
      cases defined
    · 
      by_cases h8 : x = 8
      · subst x
        have absent : (rootBuilt config mirrored).1.defInst? 8 = none := by
          cases config <;> cases mirrored <;> rfl
        rw [absent] at defined
        cases defined
      · 
        by_cases h9 : x = 9
        · subst x
          cases config <;> cases mirrored
          all_goals
            change some 0 = some j at defined
            cases defined
            obtain ⟨bound,equal⟩ := Array.getElem?_eq_some_iff.mp found
            subst info
            cases original
            cases lookup
            exact ⟨[_],fun cm => rfl,rfl⟩
        · 
          by_cases h10 : x = 10
          · subst x
            cases config <;> cases mirrored
            all_goals
              change some 1 = some j at defined
              cases defined
              obtain ⟨bound,equal⟩ := Array.getElem?_eq_some_iff.mp found
              subst info
              cases original
              cases lookup
              exact ⟨[_],fun cm => rfl,rfl⟩
          · 
            by_cases h11 : x = 11
            · subst x
              cases config <;> cases mirrored
              all_goals
                change some 2 = some j at defined
                cases defined
                obtain ⟨bound,equal⟩ := Array.getElem?_eq_some_iff.mp found
                subst info
                cases original
                cases lookup
                exact ⟨[_],fun cm => rfl,rfl⟩
            · 
              by_cases h12 : x = 12
              · subst x
                cases config <;> cases mirrored
                all_goals
                  change some 3 = some j at defined
                  cases defined
                  obtain ⟨bound,equal⟩ := Array.getElem?_eq_some_iff.mp found
                  subst info
                  cases original
                  cases lookup
                  exact ⟨[_],fun cm => rfl,rfl⟩
              · simp [sourceFrame,h1,h8,h9,h10,h11,h12] at lookup
  · intro x t v typed lookup
    by_cases present : x = 1 ∨ x = 8 ∨ x = 9 ∨ x = 10 ∨ x = 11 ∨ x = 12
    · rcases present with rfl | rfl | rfl | rfl | rfl | rfl
      all_goals
        cases config <;> cases mirrored
        all_goals first
        | (change some (.int 32) = some t at typed; cases typed; cases lookup; rfl)
        | (change some (.int 64) = some t at typed; cases typed; cases lookup; rfl)
    · simp only [not_or] at present
      simp [sourceFrame,present.1,present.2.1,present.2.2.1,present.2.2.2.1,
        present.2.2.2.2.1,present.2.2.2.2.2] at lookup
end E2E.StockLogicalExtrWitness


open Lean Elab Command
run_cmd do
  for (newText,suffix) in [("rootMatch1501",".stock_match_1501"),("rootMatch1507",".stock_match_1507")] do
    let env ← getEnv
    let some (oldName,info) := env.constants.toList.find? (fun (name,_) => name.toString.endsWith suffix)
      | throwError "missing pinned prototype theorem {suffix}"
    liftCoreM <| addDecl <| .defnDecl {
      name := Name.mkSimple newText
      levelParams := info.levelParams
      type := info.type
      value := mkConst oldName (info.levelParams.map Level.param)
      hints := .abbrev
      safety := .safe }

namespace Backend.Stock.Proof.LogicalExtr
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000

/-- Actual RHS output, emitted instruction execution and source-word result,
with final aliases and the fresh-only write frame. -/
def ValueOut (F : BitVec 64 → Prop) (isem : Backend.Proof.Sem) (ty : Clif.Ty)
    (u v : BitVec ty.width) (X Y : Nat) (st next : State) (out : V)
    (aliases : Array (Option Nat)) (ρ : Nat → CV) : Prop :=
  ∃ (mi : MInst) (ρ' : Nat → CV),
    out = .regsVec [[.vreg st.base.nextVreg .int]] ∧
    next.base = (st.base.fresh .int).2.emit mi ∧
    PRun F isem [mi.mapRegs (Backend.lowerFunction.resolve aliases (aliases.size+1))] ρ ρ' ∧
    VHolds ⟨ty,(u <<< X) ||| (v >>> Y)⟩ (ρ' st.base.nextVreg) ∧
    ∀ z,z ≠ st.base.nextVreg → ρ' z = ρ z

private theorem marked (st : State) (x : Nat) (bound : x < st.demand.size) : Demanded (st.mark x) x := by
  rw [Demanded,(mark_demand st x bound).1]
  omega
private theorem twice_marked (st : State) (x y : Nat) (bx : x < st.demand.size) (by_ : y < st.demand.size) :
    Demanded ((st.mark x).mark y) x ∧ Demanded ((st.mark x).mark y) y := by
  have afterBound : y < (st.mark x).demand.size := by rw [(mark_demand st x bx).2.2]; exact by_
  exact ⟨(demanded_mark_iff (st.mark x) y x afterBound).mpr (Or.inr (marked st x bx)),
    marked (st.mark x) y afterBound⟩

/-- A successful actual EXTR RHS internally derives its integer mappings and
operand demands from the original held-values relation, then executes the real
two-word instruction. No caller-supplied register/request certificate is used. -/
theorem rhs_values {p : Program} (hp : Data p) {ctx : Ctx} (mirrored : Bool)
    {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem} (refines : Refines F isem)
    {ty : Clif.Ty} (width : ty.width = 32 ∨ ty.width = 64)
    {X Y : Int} (sum : X.toNat+Y.toNat = ty.width) (count : Y.toNat < ty.width)
    {x y n : Nat} {u v : BitVec ty.width} {fr : Clif.Frame}
    (sourceX : fr.getAs x ty = .ok u) (sourceY : fr.getAs y ty = .ok v)
    {st next : State} {out : V} {tr trace : Array RuleId}
    {aliases : Array (Option Nat)} {ρ : Nat → CV}
    (bounded : aliases.size ≤ st.base.nextVreg)
    (extent : ∀ z r,ctx.valueReg? z = some r → z < st.demand.size)
    (held : ValuesHeld (Demanded next) ctx fr (fun z => ρ (aliasNum aliases z)))
    (run : (evalExpr p (Stock.sem ctx) {} (n+60) (extrRule mirrored).rhs
      (extrEnv mirrored ty.width x X y Y)).run (st,tr) = .ok (some out,next,trace)) :
    ValueOut F isem ty u v X.toNat Y.toNat st next out aliases ρ := by
  have fits : Y < 64 := by rcases width with h | h <;> omega
  obtain ⟨safeX,safeY,rx,ry,mappedX,mappedY,outEq,stateEq⟩ := rhs_observed hp ctx mirrored width fits run
  have needed : Demanded next x ∧ Demanded next y := by
    rw [stateEq]
    exact twice_marked st x y (extent x rx mappedX) (extent y ry mappedY)
  obtain ⟨nx,mx,heldX⟩ := held x needed.1 ⟨ty,u⟩ (getAs_ok sourceX)
  obtain ⟨ny,my,heldY⟩ := held y needed.2 ⟨ty,v⟩ (getAs_ok sourceY)
  have rxEq := Option.some.inj (mappedX.symm.trans mx)
  have ryEq := Option.some.inj (mappedY.symm.trans my)
  subst rx ry
  have amount : (shiftFor ty.width Y.toNat).amt = Y.toNat := by unfold shiftFor; split <;> rfl
  obtain ⟨ρ',execution,value,kept⟩ := extr_resolved refines width
    (sh := shiftFor ty.width Y.toNat) bounded (by simpa only [amount] using sum)
    (by simpa only [amount] using count) heldX heldY
  refine ⟨.aluRRRShift .extr (szOf ty.width) (.vreg st.base.nextVreg .int)
    (.vreg nx .int) (.vreg ny .int) (shiftFor ty.width Y.toNat),ρ',outEq,?_,execution,?_,kept⟩
  · exact congrArg State.base stateEq
  · simpa only [amount] using value

end Backend.Stock.Proof.LogicalExtr

namespace Backend.Stock.Proof.LogicalExtr
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000

private theorem original_word_value {f : Clif.Function} {ctx : Ctx} (inv : MappedCtxInv f ctx)
    {value : Nat} {left : Bool} (word : SourceWord ctx value left)
    {fr : Clif.Frame} (dfg : DFGCons ctx fr) {ty : Clif.Ty} {v : BitVec ty.width}
    (getter : fr.getAs value ty = .ok v) (count : word.amount.toNat < ty.width) :
    ∃ u,fr.getAs word.word ty = .ok u ∧
      v = if left then u <<< word.amount.toNat else u >>> word.amount.toNat := by
  have accepted := inv.instE word.literalInst word.literal _ word.countFound word.countOriginal
  have literalSupported : eTy word.literalTy = true := by
    simpa [Compile.instE,Compile.tyE,eTy] using accepted
  have amount : word.amount.toNat = word.bits.toNat := by
    unfold SourceWord.amount
    rw [Int.toNat_natCast,u64_imm64OfIconst (eTy_width literalSupported)]
  have shift : (if left then Clif.BinaryOp.ishl else .ushr).isShift = true := by cases left <;> rfl
  obtain ⟨u,source,shifted⟩ := shift_const_value dfg shift word.defined word.found word.original
    word.countDefined word.countFound word.countOriginal getter
  have bounded : word.bits.toNat < ty.width := by rwa [amount] at count
  cases left
  · simp only [Bool.false_eq_true,ite_false,ite_true,Clif.Sem.shift,Clif.Sem.ishl,Clif.Sem.ushr,Clif.Sem.shiftAmt,Nat.mod_eq_of_lt bounded,Option.some.injEq] at shifted
    exact ⟨u,source,by simpa only [amount,Bool.false_eq_true,ite_false,ite_true] using shifted.symm⟩
  · simp only [Bool.false_eq_true,ite_false,ite_true,Clif.Sem.shift,Clif.Sem.ishl,Clif.Sem.ushr,Clif.Sem.shiftAmt,Nat.mod_eq_of_lt bounded,Option.some.injEq] at shifted
    exact ⟨u,source,by simpa only [amount,Bool.false_eq_true,ite_false,ite_true] using shifted.symm⟩

/-- Actual matching and RHS execution derive all EXTR width/count/source-word
facts internally. The emitted instruction computes the original source OR,
including its mirrored operand order, through final aliases and a fresh write. -/
theorem matched_values {p : Program} (hp : Data p) {f : Clif.Function} {ctx : Ctx}
    (inv : MappedCtxInv f ctx) (mirrored : Bool) {i a b m n : Nat} {ty : Clif.Ty} {info : IInfo}
    (source : ctx.insts[i]? = some info) (clif : info.clif = some (.binary .bor ty a b))
    {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem} (refines : Refines F isem)
    {fr : Clif.Frame} (dfg : DFGCons ctx fr) {u v : BitVec ty.width}
    (sourceX : fr.getAs a ty = .ok u) (sourceY : fr.getAs b ty = .ok v)
    {st next : State} {out : V} {tr trace : Array RuleId}
    {env : Isle.Interp.Env V} {middle : State × Array RuleId}
    {aliases : Array (Option Nat)} {ρ : Nat → CV}
    (bounded : aliases.size ≤ st.base.nextVreg)
    (extent : ∀ z r,ctx.valueReg? z = some r → z < st.demand.size)
    (held : ValuesHeld (Demanded next) ctx fr (fun z => ρ (aliasNum aliases z)))
    (matched : (matchRule p (Stock.sem ctx) {} (m+20) (extrRule mirrored) [.inst i]).run (st,tr) =
      .ok (some env,middle))
    (rhs : (evalExpr p (Stock.sem ctx) {} (n+60) (extrRule mirrored).rhs env).run middle =
      .ok (some out,next,trace)) :
    ∃ (mi : MInst) (ρ' : Nat → CV),out = .regsVec [[.vreg st.base.nextVreg .int]] ∧
      next.base = (st.base.fresh .int).2.emit mi ∧
      PRun F isem [mi.mapRegs (Backend.lowerFunction.resolve aliases (aliases.size+1))] ρ ρ' ∧
      VHolds ⟨ty,Clif.Sem.binary .bor u v⟩ (ρ' st.base.nextVreg) ∧
      ∀ z,z ≠ st.base.nextVreg → ρ' z = ρ z := by
  obtain ⟨first,second,width,guard,envEq,middleEq⟩ := match_receipt hp inv mirrored source clif matched
  rw [envEq,middleEq] at rhs
  have narrow : ty.width ≤ 64 := by rcases width with h | h <;> omega
  cases mirrored with
  | false =>
    simp only [Bool.false_eq_true,ite_false,ite_true] at *
    obtain ⟨sum,positiveX,positiveY,_,_,_⟩ := extrOk_nat narrow guard
    have countX : first.amount.toNat < ty.width := by omega
    have countY : second.amount.toNat < ty.width := by omega
    obtain ⟨x,getX,valueX⟩ := original_word_value inv first dfg sourceX countX
    obtain ⟨y,getY,valueY⟩ := original_word_value inv second dfg sourceY countY
    obtain ⟨mi,ρ',output,state,execution,value,kept⟩ :=
      rhs_values hp false refines width sum countY getX getY bounded extent held rhs
    exact ⟨mi,ρ',output,state,execution,by simpa only [Bool.not_false,Bool.not_true,Bool.false_eq_true,ite_false,ite_true,Clif.Sem.binary,Clif.Sem.bor,valueX,valueY] using value,kept⟩
  | true =>
    simp only [Bool.false_eq_true,ite_false,ite_true] at *
    obtain ⟨sum,positiveX,positiveY,_,_,_⟩ := extrOk_nat narrow guard
    have countX : second.amount.toNat < ty.width := by omega
    have countY : first.amount.toNat < ty.width := by omega
    obtain ⟨x,getX,valueX⟩ := original_word_value inv second dfg sourceY countX
    obtain ⟨y,getY,valueY⟩ := original_word_value inv first dfg sourceX countY
    obtain ⟨mi,ρ',output,state,execution,value,kept⟩ :=
      rhs_values hp true refines width sum countY getX getY bounded extent held rhs
    exact ⟨mi,ρ',output,state,execution,
      by simpa only [Bool.not_false,Bool.not_true,Bool.false_eq_true,ite_false,ite_true,Clif.Sem.binary,Clif.Sem.bor,valueX,valueY,BitVec.or_comm] using value,kept⟩
end Backend.Stock.Proof.LogicalExtr

namespace E2E.StockLogicalExtrWitness
open Backend Backend.Proof Backend.Proof.Driver Backend.Stock.D0 Backend.Stock.Proof
open Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm
private def rootRF (a b : CV) : Nat → CV := fun n => if n = 193 then a else if n = 200 then b else 0
private def rootAfter (config : Configuration) (mirrored : Bool) : Stock.State :=
  let st := (rootBuilt config mirrored).2.2
  { (st.mark 1).mark 8 with base := (st.base.fresh .int).2.emit (.aluRRRShift .extr
      (szOf (valueType config).width) (st.base.fresh .int).1 (.vreg 193 .int) (.vreg 200 .int)
      (LogicalExtr.shiftFor (valueType config).width 1)) }

private theorem root_match (config : Configuration) (mirrored : Bool) :
    let ctx := (rootBuilt config mirrored).1
    let st := (rootBuilt config mirrored).2.2
    let ty := valueType config
    (matchRule program (Stock.sem ctx) {} 20 (LogicalExtr.extrRule mirrored) [.inst 4]).run (st,#[]) =
      .ok (some (LogicalExtr.extrEnv mirrored ty.width 1 (ty.width-1 : Nat) 8 1),st,#[]) := by
  dsimp only
  cases config with
  | defaultI32 =>
    cases mirrored with
    | false =>
      apply rootMatch1501 data_program (rootBuilt .defaultI32 false).1 (rootBuilt .defaultI32 false).2.2 #[] 0 (cfg := {}) (i := 4) (a := 11) (b := 12) (x := 1) (y := 8) (c1 := 9) (c2 := 10) (j1 := 2) (j2 := 0) (j3 := 3) (j4 := 1) (w := 32) (kx := 31) (ky := 1)
        (info := (rootBuilt .defaultI32 false).1.insts[4]!) (info1 := (rootBuilt .defaultI32 false).1.insts[2]!) (info2 := (rootBuilt .defaultI32 false).1.insts[0]!) (info3 := (rootBuilt .defaultI32 false).1.insts[3]!) (info4 := (rootBuilt .defaultI32 false).1.insts[1]!)
      all_goals first | rfl | decide +kernel
    | true =>
      apply rootMatch1507 data_program (rootBuilt .defaultI32 true).1 (rootBuilt .defaultI32 true).2.2 #[] 0 (cfg := {}) (i := 4) (a := 12) (b := 11) (x := 1) (y := 8) (c1 := 10) (c2 := 9) (j1 := 3) (j2 := 1) (j3 := 2) (j4 := 0) (w := 32) (kx := 31) (ky := 1)
        (info := (rootBuilt .defaultI32 true).1.insts[4]!) (info1 := (rootBuilt .defaultI32 true).1.insts[3]!) (info2 := (rootBuilt .defaultI32 true).1.insts[1]!) (info3 := (rootBuilt .defaultI32 true).1.insts[2]!) (info4 := (rootBuilt .defaultI32 true).1.insts[0]!)
      all_goals first | rfl | decide +kernel
  | systemVI32 =>
    cases mirrored with
    | false =>
      apply rootMatch1501 data_program (rootBuilt .systemVI32 false).1 (rootBuilt .systemVI32 false).2.2 #[] 0 (cfg := {}) (i := 4) (a := 11) (b := 12) (x := 1) (y := 8) (c1 := 9) (c2 := 10) (j1 := 2) (j2 := 0) (j3 := 3) (j4 := 1) (w := 32) (kx := 31) (ky := 1)
        (info := (rootBuilt .systemVI32 false).1.insts[4]!) (info1 := (rootBuilt .systemVI32 false).1.insts[2]!) (info2 := (rootBuilt .systemVI32 false).1.insts[0]!) (info3 := (rootBuilt .systemVI32 false).1.insts[3]!) (info4 := (rootBuilt .systemVI32 false).1.insts[1]!)
      all_goals first | rfl | decide +kernel
    | true =>
      apply rootMatch1507 data_program (rootBuilt .systemVI32 true).1 (rootBuilt .systemVI32 true).2.2 #[] 0 (cfg := {}) (i := 4) (a := 12) (b := 11) (x := 1) (y := 8) (c1 := 10) (c2 := 9) (j1 := 3) (j2 := 1) (j3 := 2) (j4 := 0) (w := 32) (kx := 31) (ky := 1)
        (info := (rootBuilt .systemVI32 true).1.insts[4]!) (info1 := (rootBuilt .systemVI32 true).1.insts[3]!) (info2 := (rootBuilt .systemVI32 true).1.insts[1]!) (info3 := (rootBuilt .systemVI32 true).1.insts[2]!) (info4 := (rootBuilt .systemVI32 true).1.insts[0]!)
      all_goals first | rfl | decide +kernel
  | fastI32 =>
    cases mirrored with
    | false =>
      apply rootMatch1501 data_program (rootBuilt .fastI32 false).1 (rootBuilt .fastI32 false).2.2 #[] 0 (cfg := {}) (i := 4) (a := 11) (b := 12) (x := 1) (y := 8) (c1 := 9) (c2 := 10) (j1 := 2) (j2 := 0) (j3 := 3) (j4 := 1) (w := 32) (kx := 31) (ky := 1)
        (info := (rootBuilt .fastI32 false).1.insts[4]!) (info1 := (rootBuilt .fastI32 false).1.insts[2]!) (info2 := (rootBuilt .fastI32 false).1.insts[0]!) (info3 := (rootBuilt .fastI32 false).1.insts[3]!) (info4 := (rootBuilt .fastI32 false).1.insts[1]!)
      all_goals first | rfl | decide +kernel
    | true =>
      apply rootMatch1507 data_program (rootBuilt .fastI32 true).1 (rootBuilt .fastI32 true).2.2 #[] 0 (cfg := {}) (i := 4) (a := 12) (b := 11) (x := 1) (y := 8) (c1 := 10) (c2 := 9) (j1 := 3) (j2 := 1) (j3 := 2) (j4 := 0) (w := 32) (kx := 31) (ky := 1)
        (info := (rootBuilt .fastI32 true).1.insts[4]!) (info1 := (rootBuilt .fastI32 true).1.insts[3]!) (info2 := (rootBuilt .fastI32 true).1.insts[1]!) (info3 := (rootBuilt .fastI32 true).1.insts[2]!) (info4 := (rootBuilt .fastI32 true).1.insts[0]!)
      all_goals first | rfl | decide +kernel
  | defaultI64 =>
    cases mirrored with
    | false =>
      apply rootMatch1501 data_program (rootBuilt .defaultI64 false).1 (rootBuilt .defaultI64 false).2.2 #[] 0 (cfg := {}) (i := 4) (a := 11) (b := 12) (x := 1) (y := 8) (c1 := 9) (c2 := 10) (j1 := 2) (j2 := 0) (j3 := 3) (j4 := 1) (w := 64) (kx := 63) (ky := 1)
        (info := (rootBuilt .defaultI64 false).1.insts[4]!) (info1 := (rootBuilt .defaultI64 false).1.insts[2]!) (info2 := (rootBuilt .defaultI64 false).1.insts[0]!) (info3 := (rootBuilt .defaultI64 false).1.insts[3]!) (info4 := (rootBuilt .defaultI64 false).1.insts[1]!)
      all_goals first | rfl | decide +kernel
    | true =>
      apply rootMatch1507 data_program (rootBuilt .defaultI64 true).1 (rootBuilt .defaultI64 true).2.2 #[] 0 (cfg := {}) (i := 4) (a := 12) (b := 11) (x := 1) (y := 8) (c1 := 10) (c2 := 9) (j1 := 3) (j2 := 1) (j3 := 2) (j4 := 0) (w := 64) (kx := 63) (ky := 1)
        (info := (rootBuilt .defaultI64 true).1.insts[4]!) (info1 := (rootBuilt .defaultI64 true).1.insts[3]!) (info2 := (rootBuilt .defaultI64 true).1.insts[1]!) (info3 := (rootBuilt .defaultI64 true).1.insts[2]!) (info4 := (rootBuilt .defaultI64 true).1.insts[0]!)
      all_goals first | rfl | decide +kernel
  | systemVI64 =>
    cases mirrored with
    | false =>
      apply rootMatch1501 data_program (rootBuilt .systemVI64 false).1 (rootBuilt .systemVI64 false).2.2 #[] 0 (cfg := {}) (i := 4) (a := 11) (b := 12) (x := 1) (y := 8) (c1 := 9) (c2 := 10) (j1 := 2) (j2 := 0) (j3 := 3) (j4 := 1) (w := 64) (kx := 63) (ky := 1)
        (info := (rootBuilt .systemVI64 false).1.insts[4]!) (info1 := (rootBuilt .systemVI64 false).1.insts[2]!) (info2 := (rootBuilt .systemVI64 false).1.insts[0]!) (info3 := (rootBuilt .systemVI64 false).1.insts[3]!) (info4 := (rootBuilt .systemVI64 false).1.insts[1]!)
      all_goals first | rfl | decide +kernel
    | true =>
      apply rootMatch1507 data_program (rootBuilt .systemVI64 true).1 (rootBuilt .systemVI64 true).2.2 #[] 0 (cfg := {}) (i := 4) (a := 12) (b := 11) (x := 1) (y := 8) (c1 := 10) (c2 := 9) (j1 := 3) (j2 := 1) (j3 := 2) (j4 := 0) (w := 64) (kx := 63) (ky := 1)
        (info := (rootBuilt .systemVI64 true).1.insts[4]!) (info1 := (rootBuilt .systemVI64 true).1.insts[3]!) (info2 := (rootBuilt .systemVI64 true).1.insts[1]!) (info3 := (rootBuilt .systemVI64 true).1.insts[2]!) (info4 := (rootBuilt .systemVI64 true).1.insts[0]!)
      all_goals first | rfl | decide +kernel
  | fastI64 =>
    cases mirrored with
    | false =>
      apply rootMatch1501 data_program (rootBuilt .fastI64 false).1 (rootBuilt .fastI64 false).2.2 #[] 0 (cfg := {}) (i := 4) (a := 11) (b := 12) (x := 1) (y := 8) (c1 := 9) (c2 := 10) (j1 := 2) (j2 := 0) (j3 := 3) (j4 := 1) (w := 64) (kx := 63) (ky := 1)
        (info := (rootBuilt .fastI64 false).1.insts[4]!) (info1 := (rootBuilt .fastI64 false).1.insts[2]!) (info2 := (rootBuilt .fastI64 false).1.insts[0]!) (info3 := (rootBuilt .fastI64 false).1.insts[3]!) (info4 := (rootBuilt .fastI64 false).1.insts[1]!)
      all_goals first | rfl | decide +kernel
    | true =>
      apply rootMatch1507 data_program (rootBuilt .fastI64 true).1 (rootBuilt .fastI64 true).2.2 #[] 0 (cfg := {}) (i := 4) (a := 12) (b := 11) (x := 1) (y := 8) (c1 := 10) (c2 := 9) (j1 := 3) (j2 := 1) (j3 := 2) (j4 := 0) (w := 64) (kx := 63) (ky := 1)
        (info := (rootBuilt .fastI64 true).1.insts[4]!) (info1 := (rootBuilt .fastI64 true).1.insts[3]!) (info2 := (rootBuilt .fastI64 true).1.insts[1]!) (info3 := (rootBuilt .fastI64 true).1.insts[2]!) (info4 := (rootBuilt .fastI64 true).1.insts[0]!)
      all_goals first | rfl | decide +kernel

private theorem rootHeld (config : Configuration) (mirrored : Bool) (a b : CV) :
    ValuesHeld (Demanded (rootAfter config mirrored)) (rootBuilt config mirrored).1
      (sourceFrame config mirrored a b) (fun n => rootRF a b (aliasNum #[] n)) := by
  let st := (rootBuilt config mirrored).2.2
  have bound1 : 1 < st.demand.size := by cases config <;> cases mirrored <;> decide +kernel
  have bound8 : 8 < (st.mark 1).demand.size := by cases config <;> cases mirrored <;> decide +kernel
  have initialZero : st.demand = Array.replicate 15 0 := by cases config <;> cases mirrored <;> rfl
  intro x needed value found
  change Demanded ((st.mark 1).mark 8) x at needed
  rw [demanded_mark_iff _ _ _ bound8,demanded_mark_iff _ _ _ bound1] at needed
  rcases needed with rfl | rfl | old
  · cases found
    exact ⟨200,by cases config <;> cases mirrored <;> rfl,by rfl⟩
  · cases found
    exact ⟨193,by cases config <;> cases mirrored <;> rfl,by rfl⟩
  · rw [Demanded,initialZero] at old
    simp [getElem!_def,Array.getElem?_replicate] at old

/-- The complete actual root match and RHS inhabit original-source EXTR value
semantics for arbitrary independent words in all ABI/width and mirror cases.
Only the two underlying parameters are held; fused intermediate values remain
available in the original source frame without materialized machine registers. -/
theorem root_values_witness (config : Configuration) (mirrored : Bool) (a b : CV) :
    let ctx := (rootBuilt config mirrored).1
    let st := (rootBuilt config mirrored).2.2
    let ty := valueType config
    let fr := sourceFrame config mirrored a b
    ∃ trace,
      (matchRule program (Stock.sem ctx) {} 20 (LogicalExtr.extrRule mirrored) [.inst 4]).run (st,#[]) =
        .ok (some (LogicalExtr.extrEnv mirrored ty.width 1 (ty.width-1 : Nat) 8 1),st,#[]) ∧
      (evalExpr program (Stock.sem ctx) {} 60 (LogicalExtr.extrRule mirrored).rhs
        (LogicalExtr.extrEnv mirrored ty.width 1 (ty.width-1 : Nat) 8 1)).run (st,#[]) =
        .ok (some (.regsVec [[(st.base.fresh .int).1]]),rootAfter config mirrored,trace) ∧
      ∃ (mi : MInst) (ρ' : Nat → CV),
        (.regsVec [[(st.base.fresh .int).1]] : V) = .regsVec [[.vreg st.base.nextVreg .int]] ∧
        (rootAfter config mirrored).base = (st.base.fresh .int).2.emit mi ∧
        PRun (fun _ => True) ispec [mi.mapRegs (Backend.lowerFunction.resolve #[] 1)] (rootRF a b) ρ' ∧
        VHolds ⟨ty,Clif.Sem.binary .bor
          (if mirrored then b.setWidth ty.width >>> 1 else a.setWidth ty.width <<< (ty.width-1))
          (if mirrored then a.setWidth ty.width <<< (ty.width-1) else b.setWidth ty.width >>> 1)⟩
          (ρ' st.base.nextVreg) ∧
        ∀ z,z ≠ st.base.nextVreg → ρ' z = rootRF a b z := by
  dsimp only
  let ctx := (rootBuilt config mirrored).1
  let st := (rootBuilt config mirrored).2.2
  let ty := valueType config
  have width : ty.width = 32 ∨ ty.width = 64 := by cases config <;> simp [ty,valueType,Clif.Ty.width]
  have mx : ctx.valueReg? 1 = some (.vreg 193 .int) := by cases config <;> cases mirrored <;> rfl
  have my : ctx.valueReg? 8 = some (.vreg 200 .int) := by cases config <;> cases mirrored <;> rfl
  have safeX : DemandAllowed ctx st 1 := by
    intro i found
    have absent : ctx.defInst? 1 = none := by cases config <;> cases mirrored <;> rfl
    rw [absent] at found
    cases found
  have safeY : DemandAllowed ctx st 8 := by
    intro i found
    have absent : ctx.defInst? 8 = none := by cases config <;> cases mirrored <;> rfl
    rw [absent] at found
    cases found
  obtain ⟨trace,rhs⟩ := LogicalExtr.rhs_forward data_program ctx mirrored mx my width (by decide)
    st safeX safeY #[] 0 (X := (ty.width-1 : Nat)) (Y := 1)
  refine ⟨trace,root_match config mirrored,rhs,?_⟩
  have scope : LowerScope (function config mirrored) := lowerScope_of (by cases config <;> cases mirrored <;> decide +kernel)
  have build : Stock.buildCtx (function config mirrored) = .ok (rootBuilt config mirrored) := by
    cases config <;> cases mirrored <;> rfl
  have inv := buildCtx_mappedInv scope build
  have source : ctx.insts[4]? = some ctx.insts[4]! := by cases config <;> cases mirrored <;> rfl
  have clif : ctx.insts[4]!.clif = some (.binary .bor ty
      (if mirrored then 12 else 11) (if mirrored then 11 else 12)) := by
    cases config <;> cases mirrored <;> rfl
  have getterX : (sourceFrame config mirrored a b).getAs (if mirrored then 12 else 11) ty =
      .ok (if mirrored then b.setWidth ty.width >>> 1 else a.setWidth ty.width <<< (ty.width-1)) := by
    cases config <;> cases mirrored <;> rfl
  have getterY : (sourceFrame config mirrored a b).getAs (if mirrored then 11 else 12) ty =
      .ok (if mirrored then a.setWidth ty.width <<< (ty.width-1) else b.setWidth ty.width >>> 1) := by
    cases config <;> cases mirrored <;> rfl
  have extent : ∀ z r,ctx.valueReg? z = some r → z < st.demand.size := by
    intro z r mapped
    have size : st.demand.size = ctx.valReg.size := by cases config <;> cases mirrored <;> rfl
    rw [size]
    by_cases small : z < ctx.valReg.size
    · exact small
    · rw [Ctx.valueReg?,Array.getElem?_eq_none (Nat.le_of_not_lt small)] at mapped
      cases mapped
  have self : Refines (fun _ => True) ispec := fun _ _ _ _ w' _ h => ⟨w',h,SameWorld.refl _ _⟩
  exact LogicalExtr.matched_values data_program inv mirrored source clif self (sourceDFG config mirrored a b)
    getterX getterY (aliases := #[]) (ρ := rootRF a b) (by simp) extent (rootHeld config mirrored a b)
    (m := 0) (n := 0) (root_match config mirrored) rhs
end E2E.StockLogicalExtrWitness

#print axioms E2E.StockLogicalExtrWitness.root_values_witness
