from pathlib import Path
p=Path('/tmp/StockExtrRootWitnessOnly.lean');s=p.read_text();a=s.index('  cases config <;> cases mirrored\n',s.index('private theorem root_match'));b=s.index('\nprivate theorem rootHeld',a)
proof='  cases config with\n'
for config,w in [('defaultI32',32),('systemVI32',32),('fastI32',32),('defaultI64',64),('systemVI64',64),('fastI64',64)]:
 proof+='  | '+config+' =>\n    cases mirrored with\n'
 for mirror in [False,True]:
  bv=str(mirror).lower();num='1507' if mirror else '1501';ctx=f'(rootBuilt .{config} {bv})'
  v={'i':4,'a':12 if mirror else 11,'b':11 if mirror else 12,'x':1,'y':8,'c1':10 if mirror else 9,'c2':9 if mirror else 10,'j1':3 if mirror else 2,'j2':1 if mirror else 0,'j3':2 if mirror else 3,'j4':0 if mirror else 1,'w':w,'kx':w-1,'ky':1}
  args=' '.join('('+k+' := '+str(n)+')' for k,n in v.items())
  infos=' '.join('('+key+' := '+ctx+'.1.insts['+str(idx)+']!)' for key,idx in [('info',4),('info1',v['j1']),('info2',v['j2']),('info3',v['j3']),('info4',v['j4'])])
  proof+=f'    | {bv} =>\n      apply rootMatch{num} data_program {ctx}.1 {ctx}.2.2 #[] 0 (cfg := {{}}) {args}\n        {infos}\n      all_goals first | rfl | decide +kernel\n'
s=s[:a]+proof+s[b:];Path('/tmp/StockExtrRootWitnessOnly-explicit.lean').write_text(s)
old=Path('/tmp/StockExtrRootWitness.lean').read_text();a=old.index('private def rootRF');Path('/tmp/StockExtrRootWitnessExplicit.lean').write_text(old[:a]+s[s.index('private def rootRF'):]+'\n#print axioms E2E.StockLogicalExtrWitness.root_values_witness\n')
