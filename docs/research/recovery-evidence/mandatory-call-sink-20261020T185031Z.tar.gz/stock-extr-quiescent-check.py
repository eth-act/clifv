from pathlib import Path
import subprocess as sp,os,signal,time,json,sys
root=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');sched=3016520
out=Path('/tmp/stock-mixed-draft-check');out.mkdir(exist_ok=True)
scratch_gib=int(os.environ.get('STOCK_SCRATCH_GIB','4'));assert 1<=scratch_gib<=4
scratch_timeout=int(os.environ.get('STOCK_SCRATCH_TIMEOUT','60'));assert 1<=scratch_timeout<=180
env=dict(os.environ,PATH='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:'+os.environ['PATH'],FV_MEMCAP=str(scratch_gib)+'G',FV_LAKE_CACHE='/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache',LEAN_NUM_THREADS='2',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2')
head=sp.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert head=='087e91d1615c8c944e560c050c1eb7c60981d205'
controller=3016495
assert Path(f'/proc/{controller}/stat').read_text().split()[2]=='T'
assert b'stock-arithmetic-activation-repaired-author-gates.py' in Path(f'/proc/{controller}/cmdline').read_bytes()
kids=Path(f'/proc/{controller}/task/{controller}/children').read_text().split()
kids=[k for k in kids if Path(f'/proc/{k}/stat').exists() and Path(f'/proc/{k}/stat').read_text().split()[2]!='Z']
assert len(kids)<=1,kids
for k in kids:
 cap=[v for v in Path(f'/proc/{k}/environ').read_bytes().split(b'\0') if v.startswith(b'FV_MEMCAP=')]
 assert cap==[b'FV_MEMCAP=8G'],cap
stopped=False
try:
 cache=Path('/tmp/stock-extr-kernel-cache');cache.mkdir(exist_ok=True)
 leanpath=sp.check_output([str(root/'scripts/memcap.sh'),'lake','env','printenv','LEAN_PATH'],cwd=root,env=env,text=True).strip()
 env['LEAN_PATH']=str(cache)+':'+leanpath
 extra=[]
 if os.environ.get('STOCK_SCRATCH_OLEAN'):
  target=cache/os.environ['STOCK_SCRATCH_OLEAN'];assert target.parent==cache and target.suffix=='.olean'
  extra=['-o',str(target)]
 with (out/(sys.argv[2]+'.log')).open('w') as f:
  p=sp.run([str(root/'scripts/memcap.sh'),'lean',*extra,'--root=/tmp',sys.argv[1]],cwd=root,env=env,stdout=f,stderr=sp.STDOUT,timeout=scratch_timeout)
 assert sp.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head
 print(json.dumps({'candidate_returncode':p.returncode,'head_unchanged':True,'existing_jobs':len(kids),'reserved_GiB':16,'log':str(out/(sys.argv[2]+'.log'))}))
finally:
 if stopped:os.kill(sched,signal.SIGCONT)
 print(json.dumps({'scheduler_resumed':True}),flush=True)
