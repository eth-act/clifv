from pathlib import Path
import re
for src,dst,consumer,form in [('StockTryNormalCopyWitness','StockTryNormalNearEntryWitness','StockTryNormalNearEntry','direct'),('StockTryNormalGotCopyWitness','StockTryNormalGotEntryWitness','StockTryNormalGotEntry','got'),('StockTryNormalIndirectCopyWitness','StockTryNormalIndirectEntryWitness','StockTryNormalIndirectEntry','indirect')]:
 s=Path('/tmp',src+'.lean').read_text();oldns=re.search(r'^namespace (\S+)',s,re.M).group(1);ns='Backend.Stock.Proof.TryNormal'+('Near' if form=='direct' else form.capitalize())+'EntryWitnessDraft'
 s='import '+consumer+'\n'+s.replace('namespace '+oldns,'namespace '+ns,1).replace('end '+oldns,'end '+ns)
 at=s.index('set_option maxRecDepth');s=s[:at]+'open TryNormalEntryCaseDraft TryNormal'+('Near' if form=='direct' else form.capitalize())+'EntryDraft\n'+s[at:]
 a=re.search(r'^theorem ',s,re.M).start();b=s.index(' := by',a);t=s[a:b];t=t.replace('normal_copy_values_witness','normal_entry_values_witness').replace('(finalWorld : Arm.ArmState) (args : Array Reg),','(finalWorld : Arm.ArmState),')
 tail=t.index('          (out.result.edgeArgs[0]?')
 end=t.index('      Clif.runWith',tail)
 f='function' if form=='indirect' else 'f'
 t=t[:tail]+f'''          raw.info.handlers.length = table.handlers.length ∧
          NormalEntryAgreement {f} out.result 0 1 1 raw.info.handlers.length normalCall enteredFrame (vdefUpd ops outs atCall)) ∧
'''+t[end:]
 
 t=t.replace('      Clif.enterBlock pendingFrame normalCall = .ok enteredFrame ∧',f'      SourceDefinedAt {f} out.result.ctx 0 {f}.blocks[0]!.body.length fr ∧\n      SourceDefinedAt {f} out.result.ctx 1 0 enteredFrame ∧\n      Clif.enterBlock pendingFrame normalCall = .ok enteredFrame ∧')
 proof=f'''private theorem source_defined (ctx : Ctx) : SourceDefinedAt {f} ctx 0 {f}.blocks[0]!.body.length fr := by
  have block : {f}.blocks[0]? = some {f}.blocks[0]! := rfl
  intro x available
  obtain ⟨present,_⟩ := (mem_av block).mp available
  rcases present with parameter | incoming | ⟨j,stm,earlier,statement,member⟩
'''
 if form=='got':
  proof+='''  · have small : x < 9 := by simpa [f,TryStackSourceDraft.function,List.map_map] using parameter
    refine ⟨⟨.i64,0⟩,?_⟩
    change (if x < 9 then some (⟨.i64,0⟩ : Clif.Val) else none) = some ⟨.i64,0⟩
    rw [if_pos small]
'''
 else:
  proof+='''  · change x ∈ ([] : List Nat) at parameter
    cases parameter
'''
 proof+=f'''  · have impossible := (inFix_fixOk (f := {f}) (ctx := ctx) (gn := id)).cand 0 x incoming
    omega
'''
 if form=='got':
  proof+='''  · change ([] : List Clif.Stmt)[j]? = some stm at statement
    cases statement
'''
 elif form=='direct':
  proof+='''  · have choices : ∀ stm ∈ f.blocks[0]!.body,∀ y ∈ stm.results,y = 0 := by
      simp [f,TryNearFixtureDraft.function]
    have same := choices stm (List.mem_of_getElem? statement) x member
    subst x
    exact ⟨⟨.i64,9⟩,rfl⟩
'''
 else:
  proof+='''  · have choices : ∀ stm ∈ function.blocks[0]!.body,∀ y ∈ stm.results,y = 0 ∨ y = 1 := by
      simp [function,SpillEntryFixture.function]
    rcases choices stm (List.mem_of_getElem? statement) x member with rfl | rfl
    · exact ⟨⟨.i64,9⟩,rfl⟩
    · exact ⟨⟨.i64,4096⟩,rfl⟩
'''

 s=s[:a]+proof+t+s[b:]
 s=s.replace('  have run := stock_lower_', '  have sourceEntered : Clif.enterBlock pendingFrame normalCall = .ok enteredFrame := rfl\n  have run := stock_lower_',1)
 s=s.replace(f'stock_lower_{form}_try_normal_column_source_values',f'stock_lower_{form}_try_normal_entry_source_values',1)
 start=s.index('  have run :=');end=s.index('\n  obtain ⟨raw,k,i,ops',start)
 call=s[start:end];assert call.rstrip().endswith('normalRead');s=s[:start]+call.rstrip()+' rfl sourceEntered'+s[end:]
 at=s.index('  obtain ⟨raw,k,i,ops');s=s[:at]+'''  obtain ⟨raw,k,i,ops,atCall,world,outs,finalWorld,execute,related,returns,postHeld,column,normalIndex,entryAgreement,defined⟩ := run
'''
 if form=='indirect':
  s+='''  have changed : keyMap out.result 193 ≠ 193 := by
    have observed := TryIndirectAliasObservationDraft.observed
    rw [out.lowered] at observed
    exact bne_iff_ne.mp observed
'''
 initial='out,out.scope,out.dominated,out.arity,'+('abi,' if form=='indirect' else '')+'out.lowered,out.prepare,out.fallback,out.accepted,out.physical,'
 middle='xind,contract,changed,' if form=='indirect' else 'xcalls,contract,stable,memory,outgoing,'
 s+='  exact ⟨'+initial+middle+'source_defined out.result.ctx,defined (source_defined out.result.ctx),sourceEntered,⟨raw,k,i,ops,atCall,world,outs,finalWorld,execute,column,normalIndex,entryAgreement⟩,rfl⟩\nend '+ns+'\n'
 Path('/tmp',dst+'.lean').write_text(s)
