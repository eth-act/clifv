import StockTryGotLocalAreaColumns
import StockTryNormalGraph
import StockTryCriticalNormalWitness
import FV.Backend.Proof.MemRefines
import FV.E2E.RegLevelDriverSem
namespace Backend.Stock.Proof.TryCriticalGotValuesWitnessDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open TryGotLocalAreaColumnsDraft TryNormalValueColumnsDraft TryNormalGraphDraft TryNormalCfgDraft
open TryNormalEdgeValuesDraft TryNormalCopiesDraft TryNormalControlDraft
open TryGotSourceRunDraft TryBranchAbiDraft TryResolvedRunsDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private def function := CriticalSplitFixture.function false
private def ext : Clif.ExtFunc := {name := "callee",sig := function.sig,colocated := false}
private def table : Clif.ExnTable := {sig := 0,normal := ⟨1,[.ret 0]⟩,items := []}
private def model : ExtSem := ⟨fun _ _ w => some ([17],w),fun _ _ => 4096,0,fun _ w => Arm.read_pstate w⟩
private def environment : Clif.Env := {
  extern := fun _ => some (fun _ cm => .returned [⟨.i64,17⟩] cm),names := ["callee"],sigOf := fun _ => some function.sig }
private def fr : Clif.Frame := {func := function,regs := Clif.Regs.empty,slots := [],body := [],term := function.blocks[0]!.term}
private def resultRegs : Clif.Regs := fr.regs.set function.freshValue ⟨.i64,17⟩
private def normalCall : Clif.BlockCall := ⟨1,[function.freshValue]⟩
private def pending : Clif.Frame := {fr with regs := resultRegs,body := [],term := .jump normalCall}
private def entered : Clif.Frame := {pending with regs := resultRegs.set 2 ⟨.i64,17⟩,body := [],term := .ret [2]}
private theorem held : PrefixHold [⟨.i64,17⟩] ([17] : List CV) := by
  refine ⟨by decide,?_⟩
  intro j v x atValue atOut
  cases j with
  | zero => cases atValue; cases atOut; rfl
  | succ j => simp at atValue
private theorem xcalls : XCallsOk environment [ext] (fun _ _ _ => True) model := by
  intro e member g sl cm w dest used args vals rvals cm' found target arguments memory returned length
  have same := List.mem_singleton.mp member
  subst e
  simp only [environment,Option.some.injEq] at found
  subst g
  cases returned
  exact ⟨[17],w,rfl,rfl,held,trivial⟩
/-- COMPLETE forced-critical GOT machine/value/source/compiler/physical witness.
The original full source retains its unreachable second predecessor. The local
outgoing contract concerns the actual zero-stack call, with no cold observation
of the whole compiler's outgoing projection. -/
theorem stock_complete_critical_got_normal_values_witness :
    ∃ (result : Result) (p : EdgeVCode) (rf : RFunc) (af : AFunc),
      Stock.lower function = .ok result ∧ LowerScope function ∧ Dominated function ∧ ArityOk function ∧
      prepareAt result.code result.edgeArgs = .ok p ∧ rf = spillAllocAt p.code p.edges ∧
      checkAllocAt p.code p.edges rf = .ok () ∧ lowerRFunc p.code rf = .ok af ∧
      stockSourceTable function = .ok #[#[1],#[],#[1]] ∧
      sourceIndegree #[#[1],#[],#[1]] function.blocks.length = .ok #[0,2,0] ∧
      Node.original 2 ∉ result.order.nodes.toList ∧ result.order.nodes[1]? = some (.edge 0 0 1) ∧
      XCallsOk environment [ext] (fun _ _ _ => True) model ∧
      MRStable (fun _ => False) (fun _ _ _ => True) ∧
      MemRefinesR (fun _ => True) (fun _ => False) 0 (fun _ => none) (csem (fun _ => False) ⟨0,0⟩ model) ∧
      OutArgsOk (fun _ => False) (stackBytes ext.sig) (fun _ _ _ => True) ∧
      Clif.enterBlock pending normalCall = .ok entered ∧
      (∃ raw : GotTryRun function result 0 0 function.blocks[0]! ext
        (csem (fun _ => False) ⟨0,0⟩ model) (fun _ _ _ => True) fr (fun _ => 0) Arm.ArmState.default [⟨.i64,17⟩] Clif.Mem.empty,
        ∃ (k : Nat) (i : MInst) (ops : Array Operand) (atCall : Nat → CV) (world : Arm.ArmState)
          (outs : List CV) (finalWorld : Arm.ArmState) (args : Array Reg),
          seqRun (csem (fun _ => False) ⟨0,0⟩ model)
            (raw.source.branch.step.emitted.toList.map (·.mapRegs (resolver result))) (fun _ => 0) Arm.ArmState.default =
            some (.stop k i ops atCall world outs finalWorld (.goto raw.info.handlers.length)) ∧
          raw.info.handlers.length = 0 ∧ succOf result.code 0 raw.info.handlers.length = some 1 ∧ succOf result.code 1 0 = some 2 ∧
          NormalColumnValues result 1 0 [⟨.i64,17⟩] (vdefUpd ops outs atCall) ∧
          (result.edgeArgs[1]?.bind fun row => row[0]?) = some args ∧
          edgeEnvAt result.code result.edgeArgs 1 2 0 (vdefUpd ops outs atCall) =
            some (parCopyEnv (vdefUpd ops outs atCall) (edgeParamNumbers result function.blocks[1]!) (columnNumbers args)) ∧
          ValuesHeld (fun x => x ∈ availOf function (availIn function result.ctx) 1 0) result.ctx entered
            (fun key => parCopyEnv (vdefUpd ops outs atCall) (edgeParamNumbers result function.blocks[1]!)
              (columnNumbers args) (aliasNum result.final.alias key))) ∧
      Clif.runWith environment {funcs := [function]} function.name [] Clif.Mem.empty 6 = .returned [⟨.i64,17⟩] Clif.Mem.empty := by
  obtain ⟨result,p,rf,af,source,selected,base,before,value,after,edgeInput,edgeNext,args,
    lowered,scope,dominated,arity,prepared,fallback,accepted,physical,srcRun,degreeRun,complete,
    unreachable,edge,layout,helper,defs,call,numbers,stored,length,sourceRun⟩ :=
    TryCriticalNormalWitnessDraft.stock_complete_try_critical_normal_vectors_witness false
  have order : blockOrder function = .ok {nodes := #[.original 0,.edge 0 0 1,.original 1],successors := #[#[1],#[2],#[]]} := by cbv
  have sameOrder := Except.ok.inj ((stock_lower_order lowered).symm.trans order)
  have node : result.order.nodes[0]? = some (.original 0) := by rw [sameOrder]; rfl
  have block : function.blocks[0]? = some function.blocks[0]! := rfl
  have kind : function.blocks[0]!.term = .tryCall 0 [] table := rfl
  have input : Prg.iselInB function = true := by decide +kernel
  have stable : MRStable (fun _ => False) (fun _ _ _ => True) := by intro _ _ _ _ _ _; trivial
  have memory : MemRefinesR (fun _ => True) (fun _ => False) 0 (fun _ => none) (csem (fun _ => False) ⟨0,0⟩ model) :=
    memRefinesR_of (memRefines_csem _ _ _ rfl (by intro n b found; cases found))
  have localArea : OutArgsOk (fun _ => False) (stackBytes ext.sig) (fun _ _ _ => True) := by
    change OutArgsOk (fun _ => False) 0 (fun _ _ _ => True)
    intro sl cm w related
    exact ⟨by decide,by intro k bound bad; exact bad,by intro k n y inside; trivial⟩
  have heldArgs : ValuesHeld (fun x => x ∈ ([] : List Nat)) result.ctx fr (fun _ => 0) := by
    intro x member; cases member
  have liveHeld : ValuesHeld (fun _ => True) result.ctx fr (fun _ => 0) := by
    intro x available v lookup
    change none = some v at lookup
    cases lookup
  have sourceBind : fr.regs.setMany ((List.range 1).map (function.freshValue + ·)) [⟨.i64,17⟩] = some resultRegs := rfl
  have normalRead : ({fr with regs := resultRegs} : Clif.Frame).getMany normalCall.args = .ok [⟨.i64,17⟩] := rfl
  have run := stock_lower_got_try_critical_normal_column_source_values_local_area (ρ := fun _ => 0) (w := Arm.ArmState.default)
    (cm := Clif.Mem.empty) (cm' := Clif.Mem.empty) lowered scope dominated input node block kind
    (show function.extern? 0 = some ext from rfl) rfl edge stable memory localArea xcalls
    (show ext ∈ [ext] from by simp) heldArgs (show fr.getMany [] = .ok [] from rfl)
    (show ([] : List Clif.Val).map (·.ty) = Clif.AbiParam.tys ext.sig.params from rfl)
    (show (fun _ _ _ => True) fr.slots Clif.Mem.empty Arm.ArmState.default from trivial)
    (show environment.extern ext.name = some (fun _ cm => .returned [⟨.i64,17⟩] cm) from rfl)
    rfl rfl (fun x available v lookup => liveHeld x trivial v lookup) sourceBind
    (show Clif.tryNormal table function.freshValue = .ok normalCall from rfl) normalRead
  obtain ⟨raw,k,i,ops,atCall,world,outs,finalWorld,execute,related,returns,postHeld,column⟩ := run
  obtain ⟨copyArgs,actual,properties⟩ := column
  have argumentValues : NormalColumnValues result 1 0 [⟨.i64,17⟩] (vdefUpd ops outs atCall) := ⟨copyArgs,actual,properties⟩
  have sourceEntered : Clif.enterBlock pending normalCall = .ok entered := rfl
  have control := stock_got_try_normal_control raw (et := table) (by rfl)
  have normalZero : raw.info.handlers.length = 0 := control.1
  have first : succOf result.code 0 raw.info.handlers.length = some 1 := by
    rw [stock_lower_actual_successor lowered scope,normalZero,sameOrder]; rfl
  have second : succOf result.code 1 0 = some 2 := by
    rw [stock_lower_actual_successor lowered scope,sameOrder]; rfl
  have targetTag : result.order.nodes[2]? = some (.original 1) := by rw [sameOrder]; rfl
  have identified := stock_lower_try_normal_critical_target lowered scope block
    (show IsTryWith function.blocks[0]!.term table from .inl ⟨0,[],rfl⟩) edge
  have copied := stock_lower_try_normal_edge_values (rvals := [⟨.i64,17⟩]) lowered scope dominated block rfl
    (show IsTryWith function.blocks[0]!.term table from .inl ⟨0,[],rfl⟩) sourceBind
    (show Clif.tryNormal table function.freshValue = .ok normalCall from rfl) normalRead sourceEntered
    (show function.blocks[1]? = some function.blocks[1]! from rfl)
    (show function.block? normalCall.block = some function.blocks[1]! from rfl)
    identified.1 targetTag identified.2 actual argumentValues postHeld
  exact ⟨result,p,rf,af,lowered,scope,dominated,arity,prepared,fallback,accepted,physical,srcRun,degreeRun,
    unreachable,edge,xcalls,stable,memory,localArea,sourceEntered,⟨raw,k,i,ops,atCall,world,outs,finalWorld,copyArgs,execute,
      normalZero,first,second,argumentValues,actual,copied.1,copied.2⟩,rfl⟩
end Backend.Stock.Proof.TryCriticalGotValuesWitnessDraft
