import StockTryNormalGraph
namespace Backend.Stock.Proof.TryNormalEntryCaseDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Driver.Fix
open TryNormalGraphDraft TryNormalCfgDraft TryNormalEdgeValuesDraft TryNormalValueColumnsDraft TryNormalCopiesDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
/-- A derived runtime conclusion, never an accepted-program certificate: the
actual selected VCode edge and source destination agree on every available
value after the actual column-sourced parallel copies. -/
def NormalEntryAgreement (f : Clif.Function) (result : Result) (label targetLabel targetBi column : Nat)
    (bc : Clif.BlockCall) (fr' : Clif.Frame) (rho : Nat → CV) : Prop :=
  blockIdx? f bc.block = some targetBi ∧ targetBi ≠ 0 ∧
    succOf result.code label column = some targetLabel ∧
    ∃ (target : Clif.Block) (args : Array Reg),
      f.blocks[targetBi]? = some target ∧ f.block? bc.block = some target ∧
      fr'.func = f ∧ fr'.body = target.body ∧ fr'.term = target.term ∧
      (result.edgeArgs[label]?.bind fun row => row[column]?) = some args ∧
      edgeEnvAt result.code result.edgeArgs label targetLabel column rho =
        some (parCopyEnv rho (edgeParamNumbers result target) (columnNumbers args)) ∧
      ValuesHeld (fun x => x ∈ availOf f (availIn f result.ctx) targetBi 0) result.ctx fr'
        (fun key => parCopyEnv rho (edgeParamNumbers result target) (columnNumbers args) (aliasNum result.final.alias key))
/-- Original successful lowering/scope/dominance and actual runtime source
binding/read/entry derive normal target identity, nonentry, selected executable
CFG and the complete value-correct copy conclusion internally. -/
theorem stock_lower_original_try_normal_entry {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    {label bi targetLabel targetBi : Nat} {b : Clif.Block} {et : Clif.ExnTable}
    (node : result.order.nodes[label]? = some (.original bi)) (block : f.blocks[bi]? = some b)
    (kind : IsTryWith b.term et)
    (successor : result.order.successors[label]![et.handlers.length]? = some targetLabel)
    (targetTag : result.order.nodes[targetLabel]? = some (.original targetBi))
    {fr fr' : Clif.Frame} (func : fr.func = f) {rvals values : List Clif.Val} {regs : Clif.Regs}
    (bound : fr.regs.setMany ((List.range rvals.length).map (f.freshValue + ·)) rvals = some regs)
    {bc : Clif.BlockCall} (normal : Clif.tryNormal et f.freshValue = .ok bc)
    (read : ({fr with regs} : Clif.Frame).getMany bc.args = .ok values)
    (entered : Clif.enterBlock {fr with regs,body := [],term := .jump bc} bc = .ok fr')
    {rho : Nat → CV} (arguments : NormalColumnValues result label et.handlers.length values rho)
    (held : ValuesHeld (fun x => x ∈ availOf f (availIn f result.ctx) bi b.body.length) result.ctx fr
      (fun key => rho (aliasNum result.final.alias key))) :
    NormalEntryAgreement f result label targetLabel targetBi et.handlers.length bc fr' rho := by
  have identified := stock_lower_try_normal_original_target lowered scope node block kind successor targetTag
  have bcBlock : bc.block = et.normal.block := by rw [tryNormal_ok normal]
  have index : blockIdx? f bc.block = some targetBi := by rw [bcBlock]; exact identified.1
  obtain ⟨target,vals,targetRegs,found,actualRead,types,set,frame⟩ := enterBlock_spec entered
  change fr.func.block? bc.block = some target at found
  rw [func] at found
  have source := blockIdx_block index found
  obtain ⟨args,stored,properties⟩ := arguments
  have column : NormalColumnValues result label et.handlers.length values rho := ⟨args,stored,properties⟩
  have agreement := stock_lower_try_normal_edge_values lowered scope dominated block func kind bound normal read entered
    source found index targetTag identified.2 stored column held
  have selected : succOf result.code label et.handlers.length = some targetLabel := by
    rw [stock_lower_actual_successor lowered scope]
    cases row : result.order.successors[label]? with
    | none => simp only [getElem!_def,row] at successor; cases successor
    | some ss => simpa only [getElem!_def,row,Option.getD_some,Option.bind_some] using successor
  refine ⟨index,identified.2,selected,target,args,source,found,?_,?_,?_,stored,agreement.1,agreement.2⟩
  · simpa only [frame] using func
  · simp only [frame]
  · simp only [frame]
end Backend.Stock.Proof.TryNormalEntryCaseDraft
