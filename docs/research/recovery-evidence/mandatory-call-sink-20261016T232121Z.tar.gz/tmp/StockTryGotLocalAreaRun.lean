import StockTryGotSourceRun
import StockTryGotSourceSeparation
namespace Backend.Stock.Proof.TryGotLocalAreaRunDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open TryGotSourceRunDraft TryGotSourceSeparationDraft
open TrySourceContextDraft TryBranchSelectionDraft TryBranchAbiDraft TrySelectedCallsDraft
open TryWholeSourceReservationDraft TryRetsTotalDraft TryGotCodeDraft TryGotSemDraft TryWholeOutgoingDraft
open TryResultMapDraft TryFinalReturnValuesDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
/-- Build the actual raw GOT execution together with internally derived target
terminal and argument final-alias exclusion, preserving all original contracts. -/
theorem stock_lower_got_try_live_separated_normal_source_run_local_area {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f) (input : Prg.iselInB f = true)
    {label bi : Nat} {b : Clif.Block} (node : result.order.nodes[label]? = some (.original bi))
    (block : f.blocks[bi]? = some b) {fn : Nat} {args : List Nat} {et : Clif.ExnTable}
    (kind : b.term = .tryCall fn args et) {ext : Clif.ExtFunc} (external : f.extern? fn = some ext)
    (far : ext.colocated = false)
    {Rd F : BitVec 64 → Prop} {asm : FnCtx} {X : ExtSem} {MR : MemRelT} {sb : Nat} {syms : String → Option Nat}
    (stable : MRStable F MR) (memory : MemRefinesR Rd F sb syms (csem F asm X))
    (outgoing : OutArgsOk F (stackBytes ext.sig) MR)
    {env : Clif.Env} {exts : List Clif.ExtFunc}
    (calls : XCallsOk env exts MR X) (member : ext ∈ exts)
    {fr : Clif.Frame} {ρ : Nat → CV} {w : Arm.ArmState} {cm cm' : Clif.Mem} {vals rvals : List Clif.Val}
    (held : ValuesHeld (fun x => x ∈ args) result.ctx fr ρ) (read : fr.getMany args = .ok vals)
    (typed : vals.map (·.ty) = Clif.AbiParam.tys ext.sig.params) (related : MR fr.slots cm w)
    {g : List Clif.Val → Clif.Mem → Clif.Outcome} (found : env.extern ext.name = some g)
    (returned : g vals cm = .returned rvals cm')
    (results : rvals.length = ext.sig.returns.length) :
    ∃ raw : GotTryRun f result label bi b ext (csem F asm X) MR fr ρ w rvals cm',
      aliasNum result.final.alias raw.target = raw.target ∧
      (∀ n ∈ raw.ns,aliasNum result.final.alias n ≠ raw.target) ∧
      (∀ x key,x ∈ availOf f (availIn f result.ctx) bi b.body.length →
        result.ctx.valueReg? x = some (.vreg key .int) → aliasNum result.final.alias key ≠ raw.target) := by
  have isTry : b.term.isTry = true := by rw [kind]; rfl
  obtain ⟨original,⟨originalSelected⟩⟩ := stock_lower_try_source_selection lowered scope node block isTry
  obtain ⟨items,table,_,_,_,_,_⟩ := stock_selected_try_got_rhs_calls originalSelected kind external far
  have sourceTableEq : sourceTable b.term = some et := by rw [kind]; rfl
  obtain ⟨ranges,source,selected,base,ns,bytes,locs,stack,target,build,allocation,slots,
    mapping,byteRun,locations,targetIs,branchFrontier,targetFixed,raw,availableGap,separation⟩ :=
    stock_lower_got_try_source_alias_separation lowered scope dominated input node block kind external far
  change selected.next.base.emitted = ((#[] ++ _).push _).push _ at raw
  change target = source.input.base.nextVreg at targetIs
  simp only [Array.empty_append] at raw
  obtain ⟨et',sig',items',info,call,tableKind,decoded,metadata,abiCount,last,code,finalLast⟩ :=
    stock_try_branch_explicit_abi isTry selected.code
  have sameTable : et' = et := Option.some.inj (tableKind.symm.trans sourceTableEq)
  subst et'
  have sameSig := Except.ok.inj (decoded.symm.trans table)
  cases sameSig
  rw [raw,Array.back?_push] at last
  have sameCall := Option.some.inj last
  cases sameCall
  have exactCode : source.branch.step.emitted = (((stackEnts ((locs.zip ns).zip bytes)).map argStore) ++
    [MInst.loadExtNameGot (.vreg target .int) ext.name,MInst.tryCall ⟨.reg (.vreg target .int),retPairs (regPairsOf ((locs.zip ns).zip bytes)),callDefs (resultDefs base ext.sig.returns.length)⟩
      {info with rets := ext.sig.returns.length}]).toArray := by
    rw [selected.stepCode,code,raw,Array.pop_push]
    apply Array.toList_inj.mp
    simp only [Array.toList_push,List.toList_toArray,List.append_assoc,List.cons_append,List.nil_append]
  have heldSource : ValuesHeld (fun x => x ∈ args) source.ctx fr ρ := by
    intro x member v lookup
    obtain ⟨n,mapped,value⟩ := held x member v lookup
    exact ⟨n,by rw [source.valueMap]; exact mapped,value⟩
  have allValues := requested_values_hold heldSource read mapping
  simp only [List.map_map,Function.comp_def,registerView] at allValues
  have counts : ns.length = vals.length := by simpa using allValues.1.symm
  have values : ∀ (j : Nat) (v : Clif.Val) (n : Nat),vals[j]? = some v → ns[j]? = some n → VHolds v (ρ n) := by
    intro j v n atValue atReg
    apply allValues.2 j v (ρ n) atValue
    simp only [List.getElem?_map,atReg,Option.map_some]
  have fresh : ∀ n ∈ ns,n ≠ target := by
    intro n member same
    have mappedMember : Reg.vreg n .int ∈ ns.map (fun k => Reg.vreg k .int) := List.mem_map_of_mem member
    obtain ⟨x,_,lookup⟩ := Backend.Proof.Flow.mapM_mem mapping _ mappedMember
    rw [source.valueMap] at lookup
    have below := (buildCtx_allocated build).1 x n lookup
    have initial := allocation.1
    rw [targetIs] at same
    omega
  have wholeStack := stock_lower_direct_try_stack lowered scope node block kind external
  have stackOk : SigStackOk ext.sig (stackBytes ext.sig) := ⟨Nat.le_refl _,wholeStack.2⟩
  obtain ⟨outs,atCall,w',run,length,heldResults,world,normal⟩ := stock_try_got_stores_normal_execution
    stable memory outgoing calls member stackOk byteRun locations typed counts values related found returned results base target info far fresh
  have layout : result.initial.tryRegs[source.ti]! = (reservedReturns base ext.sig.returns.length,reservedPayloads base ext.sig.returns.length) := by
    rw [← allocation.2]
    exact source.tryRegs.symm.trans slots
  refine ⟨{
    source := source
    selected := selected
    base := base
    target := target
    symbol := X.sym ext.name 0
    ns := ns
    bytes := bytes
    locs := locs
    stack := stack
    info := info
    outs := outs
    atCall := atCall
    finalWorld := w'
    layout := layout
    code := exactCode
    run := ?_
    returnedWorld := world
    normalValues := ?_ },targetFixed,separation,availableGap⟩
  · rw [exactCode,List.toList_toArray]
    exact run
  · intro j v atValue
    rw [vdefUpd_call_reg]
    exact stock_lower_try_normal_reserved_values lowered layout (upd ρ target (ofX (X.sym ext.name 0))) heldResults results length atValue
end Backend.Stock.Proof.TryGotLocalAreaRunDraft
