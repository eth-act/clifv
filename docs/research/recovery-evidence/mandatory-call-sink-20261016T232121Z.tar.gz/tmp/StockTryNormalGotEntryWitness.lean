import StockTryNormalGotEntry
import StockTryNormalEdgeValues
import StockTryNormalGotSourceValues
import StockTryStackFixture
import FV.Backend.Proof.MemRefines
import FV.E2E.RegLevelDriverSem
namespace Backend.Stock.Proof.TryNormalGotEntryWitnessDraft
open TryNormalGotSourceValuesDraft TryNormalValueColumnsDraft
open TryLiveNormalDraft
open TryNormalEntryValuesDraft TryNormalCopiesDraft TryNormalEdgeValuesDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open TryGotLiveResolvedSourceDraft TryResolvedRunsDraft TryGotSourceRunDraft TryStackSourceDraft TryStackFixtureDraft
open TryWholeSourceReservationDraft TryBranchAbiDraft
open TryNormalEntryCaseDraft TryNormalGotEntryDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private def f := TryStackSourceDraft.function
private def ext : Clif.ExtFunc := {name := "callee",sig := f.sig,colocated := false}
private def table := TryStackSourceDraft.table
private def sourceValues : List Clif.Val := List.replicate 9 ⟨.i64,0⟩
private def fr : Clif.Frame := {
  func := f
  regs := fun x => if x < 9 then some ⟨.i64,0⟩ else none
  slots := []
  body := []
  term := f.blocks[0]!.term }
private def built : Ctx × Array (Nat × Nat) × State := (Stock.buildCtx f).toOption.getD (sinkCtx,#[],default)
private theorem built_ok : Stock.buildCtx f = .ok built := rfl
private theorem mapped_facts : (List.range 9).all (fun x => built.1.valueReg? x == some (.vreg (192+x) .int)) = true := by
  decide +kernel
private def model : ExtSem := ⟨fun _ _ w => some ([17],w),fun _ _ => 4096,0,fun _ w => Arm.read_pstate w⟩
private def environment : Clif.Env := {
  extern := fun _ => some (fun _ cm => .returned [⟨.i64,17⟩] cm),names := ["callee"],sigOf := fun _ => some f.sig }
private def resultRegs : Clif.Regs := fr.regs.set f.freshValue ⟨.i64,17⟩
private def normalCall : Clif.BlockCall := ⟨1,[f.freshValue]⟩
private def pendingFrame : Clif.Frame := {fr with regs := resultRegs,body := [],term := .jump normalCall}
private def enteredFrame : Clif.Frame := {pendingFrame with regs := (resultRegs.set 20 ⟨.i64,17⟩),body := [],term := .ret [20]}
private theorem held : PrefixHold [⟨.i64,17⟩] ([17] : List CV) := by
  refine ⟨by decide,?_⟩
  intro j v x atValue atOut
  cases j with
  | zero => cases atValue; cases atOut; rfl
  | succ j => simp at atValue
private theorem xcalls : XCallsOk environment [ext] (fun _ _ _ => True) model := by
  intro e member g sl cm w dest used args vals rvals cm' found target arguments memory returned length
  have same := List.mem_singleton.mp member
  subst e
  simp only [environment,Option.some.injEq] at found
  subst g
  cases returned
  exact ⟨[17],w,rfl,rfl,held,trivial⟩
/-- A COMPLETE original-condition compiler/prepare/checked-fallback/physical
pipeline inhabits the original memory/callee contracts and the actual FINAL-RENAMED
branch execution with nonempty stack stores. The actual symbol load and normal operand update return17 through
final aliases; the source program also really runs to17. -/
private theorem source_defined (ctx : Ctx) : SourceDefinedAt f ctx 0 f.blocks[0]!.body.length fr := by
  have block : f.blocks[0]? = some f.blocks[0]! := rfl
  intro x available
  obtain ⟨present,_⟩ := (mem_av block).mp available
  rcases present with parameter | incoming | ⟨j,stm,earlier,statement,member⟩
  · have small : x < 9 := by simpa [f,TryStackSourceDraft.function,List.map_map] using parameter
    refine ⟨⟨.i64,0⟩,?_⟩
    change (if x < 9 then some (⟨.i64,0⟩ : Clif.Val) else none) = some ⟨.i64,0⟩
    rw [if_pos small]
  · have impossible := (inFix_fixOk (f := f) (ctx := ctx) (gn := id)).cand 0 x incoming
    omega
  · change ([] : List Clif.Stmt)[j]? = some stm at statement
    cases statement
theorem stock_complete_nine_argument_got_normal_entry_values_witness :
    ∃ out : Output,
      LowerScope f ∧ Dominated f ∧ ArityOk f ∧ Stock.lower f = .ok out.result ∧
      prepareAt out.result.code out.result.edgeArgs = .ok out.prepared ∧
      out.rf = spillAllocAt out.prepared.code out.prepared.edges ∧
      checkAllocAt out.prepared.code out.prepared.edges out.rf = .ok () ∧ lowerRFunc out.prepared.code out.rf = .ok out.af ∧
      XCallsOk environment [ext] (fun _ _ _ => True) model ∧
      CallsRefineP (fun _ _ _ _ => True) (fun _ => False) environment [ext] (fun _ _ _ => True) (csem (fun _ => False) ⟨0,0⟩ model) ∧
      MRStable (fun _ => False) (fun _ _ _ => True) ∧
      MemRefinesR (fun _ => True) (fun _ => False) 0 (fun _ => none) (csem (fun _ => False) ⟨0,0⟩ model) ∧
      OutArgsOk (fun _ => False) out.result.code.outgoing (fun _ _ _ => True) ∧
      SourceDefinedAt f out.result.ctx 0 f.blocks[0]!.body.length fr ∧
      SourceDefinedAt f out.result.ctx 1 0 enteredFrame ∧
      Clif.enterBlock pendingFrame normalCall = .ok enteredFrame ∧
      (∃ raw : GotTryRun f out.result 0 0 f.blocks[0]! ext (csem (fun _ => False) ⟨0,0⟩ model)
        (fun _ _ _ => True) fr (fun _ => 0) Arm.ArmState.default [⟨.i64,17⟩] Clif.Mem.empty,
        ∃ (k : Nat) (i : MInst) (ops : Array Operand) (atCall : Nat → CV) (world : Arm.ArmState)
          (outs : List CV) (finalWorld : Arm.ArmState),
          seqRun (csem (fun _ => False) ⟨0,0⟩ model)
            (raw.source.branch.step.emitted.toList.map (·.mapRegs (resolver out.result))) (fun _ => 0) Arm.ArmState.default =
            some (.stop k i ops atCall world outs finalWorld (.goto raw.info.handlers.length)) ∧
          NormalColumnValues out.result 0 table.handlers.length [⟨.i64,17⟩] (vdefUpd ops outs atCall) ∧
          raw.info.handlers.length = table.handlers.length ∧
          NormalEntryAgreement f out.result 0 1 1 raw.info.handlers.length normalCall enteredFrame (vdefUpd ops outs atCall)) ∧
      Clif.runWith environment {funcs := [f]} f.name sourceValues Clif.Mem.empty 4 = .returned [⟨.i64,17⟩] Clif.Mem.empty := by
  obtain ⟨out⟩ := stock_nine_argument_try_fixture
  have order : blockOrder f = .ok {nodes := #[.original 0,.original 1,.original 2],successors := #[#[2,1],#[],#[]]} := by cbv
  have sameOrder := Except.ok.inj ((stock_lower_order out.lowered).symm.trans order)
  have node : out.result.order.nodes[0]? = some (.original 0) := by rw [sameOrder]; rfl
  have block : f.blocks[0]? = some f.blocks[0]! := rfl
  have kind : f.blocks[0]!.term = .tryCall 0 (List.range 9) table := rfl
  have external : f.extern? 0 = some ext := rfl
  have area : out.result.code.outgoing = 16 := out.outgoing
  obtain ⟨ranges,source,selected,base,value,next,build,rest⟩ := stock_lower_original_try_reservation
    out.lowered out.scope (show Prg.iselInB f = true from by decide +kernel) node block
    (show sourceTable f.blocks[0]!.term = some table from rfl)
    (show exnTableOpnd f table = .ok (f.sig,[some 7]) from rfl)
  have ctxEq : out.result.ctx = built.1 := congrArg Prod.fst (Except.ok.inj (build.symm.trans built_ok))
  have stable : MRStable (fun _ => False) (fun _ _ _ => True) := by intro _ _ _ _ _ _; trivial
  have memory : MemRefinesR (fun _ => True) (fun _ => False) 0 (fun _ => none) (csem (fun _ => False) ⟨0,0⟩ model) :=
    memRefinesR_of (memRefines_csem _ _ _ rfl (by intro n b found; cases found))
  have outgoing : OutArgsOk (fun _ => False) out.result.code.outgoing (fun _ _ _ => True) := by
    rw [area]
    intro sl cm w related
    exact ⟨by decide,by intro k bound bad; exact bad,by intro k n y inside; trivial⟩
  have contract : CallsRefineP (fun _ _ _ _ => True) (fun _ => False) environment [ext] (fun _ _ _ => True)
      (csem (fun _ => False) ⟨0,0⟩ model) := (callsRefine_csem xcalls).toP _
  have heldArgs : ValuesHeld (fun x => x ∈ List.range 9) out.result.ctx fr (fun _ => 0) := by
    intro x member v lookup
    have bound := List.mem_range.mp member
    have mapped : out.result.ctx.valueReg? x = some (.vreg (192+x) .int) := by
      rw [ctxEq]
      exact beq_iff_eq.mp (List.all_eq_true.mp mapped_facts x member)
    have same : v = ⟨.i64,0⟩ := by simpa only [fr,if_pos bound,Option.some.injEq] using lookup.symm
    subst v
    exact ⟨192+x,mapped,rfl⟩
  have successor : out.result.order.successors[0]![table.handlers.length]? = some 1 := by rw [sameOrder]; rfl
  have target : out.result.order.nodes[1]? = some (.original 1) := by rw [sameOrder]; rfl
  have sourceBind : fr.regs.setMany ((List.range 1).map (f.freshValue + ·)) [⟨.i64,17⟩] = some resultRegs := rfl
  have normalRead : ({fr with regs := resultRegs} : Clif.Frame).getMany normalCall.args = .ok [⟨.i64,17⟩] := rfl
  have heldLive : ValuesHeld (fun x => x ∈ availOf f (availIn f out.result.ctx) 0 f.blocks[0]!.body.length)
      out.result.ctx fr (fun _ => 0) := by
    intro x available v lookup
    by_cases small : x < 9
    · exact heldArgs x (List.mem_range.mpr small) v lookup
    · change (if x < 9 then some ⟨.i64,0⟩ else none) = some v at lookup
      rw [if_neg small] at lookup
      cases lookup
  have sourceEntered : Clif.enterBlock pendingFrame normalCall = .ok enteredFrame := rfl
  have run := stock_lower_got_try_normal_entry_source_values (ρ := fun _ => 0) (w := Arm.ArmState.default) (cm := Clif.Mem.empty) (cm' := Clif.Mem.empty) out.lowered out.scope out.dominated
    (show Prg.iselInB f = true from by decide +kernel) node block kind external rfl successor target stable memory outgoing
    xcalls (show ext ∈ [ext] from by simp) heldArgs (show fr.getMany (List.range 9) = .ok sourceValues from rfl)
    (show sourceValues.map (·.ty) = Clif.AbiParam.tys ext.sig.params from rfl)
    (show (fun _ _ _ => True) fr.slots Clif.Mem.empty Arm.ArmState.default from trivial)
    (show environment.extern ext.name = some (fun _ cm => .returned [⟨.i64,17⟩] cm) from rfl)
    rfl rfl heldLive sourceBind (show Clif.tryNormal table f.freshValue = .ok normalCall from rfl) normalRead rfl sourceEntered
  obtain ⟨raw,k,i,ops,atCall,world,outs,finalWorld,execute,related,returns,postHeld,column,normalIndex,entryAgreement,defined⟩ := run
  exact ⟨out,out.scope,out.dominated,out.arity,out.lowered,out.prepare,out.fallback,out.accepted,out.physical,xcalls,contract,stable,memory,outgoing,source_defined out.result.ctx,defined (source_defined out.result.ctx),sourceEntered,⟨raw,k,i,ops,atCall,world,outs,finalWorld,execute,column,normalIndex,entryAgreement⟩,rfl⟩
end Backend.Stock.Proof.TryNormalGotEntryWitnessDraft
