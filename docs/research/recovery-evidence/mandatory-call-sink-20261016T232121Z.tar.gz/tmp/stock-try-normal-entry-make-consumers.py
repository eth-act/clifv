from pathlib import Path
import re
forms=[('direct','StockTryNormalSourceValues','StockTryNormalNearEntry','near'),('got','StockTryNormalGotSourceValues','StockTryNormalGotEntry','got'),('indirect','StockTryNormalIndirectSourceValues','StockTryNormalIndirectEntry','indirect')]
for family,src,dst,control in forms:
 old=Path('/tmp',src+'.lean').read_text();a=re.search(r'^theorem ',old,re.M).start();b=old.index(' := by',a)
 signature=old[a:b];name=re.search(r'^theorem (\w+)',signature).group(1);newname=name.replace('column_source_values','entry_source_values');signature=signature.replace(name,newname,1)
 needle='(normalRead : ({fr with regs} : Clif.Frame).getMany bc.args = .ok normalValues) :'
 signature=signature.replace(needle,'''(normalRead : ({fr with regs} : Clif.Frame).getMany bc.args = .ok normalValues)
    {fr' : Clif.Frame} (func : fr.func = f)
    (entered : Clif.enterBlock {fr with regs,body := [],term := .jump bc} bc = .ok fr') :''')
 assert '{fr\' : Clif.Frame}' in signature
 signature=signature.replace("MR fr.slots cm' finalWorld ∧","MR fr'.slots cm' finalWorld ∧")
 signature+=''' ∧
      raw.info.handlers.length = et.handlers.length ∧
      NormalEntryAgreement f result label targetLabel targetBi raw.info.handlers.length bc fr' (vdefUpd ops outs atCall) ∧
      (SourceDefinedAt f result.ctx bi b.body.length fr → SourceDefinedAt f result.ctx targetBi 0 fr')'''
 ns='Backend.Stock.Proof.TryNormal'+('Near' if family=='direct' else family.capitalize())+'EntryDraft'
 header=f'''import StockTryNormalSourceEntry
import StockTryNormalEntryCase
import {src}
namespace {ns}
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open TryNormalSourceEntryDraft TryNormalEntryCaseDraft TryNormalControlDraft TryNormalValueColumnsDraft
open TryNormalSourceValuesDraft TryNormalGotSourceValuesDraft TryNormalIndirectSourceValuesDraft
open TryBranchAbiDraft TryResolvedRunsDraft TryDirectSourceRunDraft TryGotSourceRunDraft TryIndirectSourceRunDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
'''
 # Only open namespaces that this source actually imports.
 header=header.replace('open TryNormalSourceValuesDraft TryNormalGotSourceValuesDraft TryNormalIndirectSourceValuesDraft','open TryNormalSourceValuesDraft'+(' TryNormalGotSourceValuesDraft' if family=='got' else ' TryNormalIndirectSourceValuesDraft' if family=='indirect' else ''))
 if family=='direct':args='lowered scope dominated input node block kind external near successor target driver stable memory outgoing calls member held read typed related found pin returned results liveHeld bound normal normalRead'
 elif family=='got':args='lowered scope dominated input node block kind external far successor target stable memory outgoing calls member held read typed related found returned results liveHeld bound normal normalRead'
 else:args='lowered scope dominated input abi node block kind table successor target driver calls held read typed related calleeValue symbol signature found pin returned results liveHeld bound normal normalRead'
 kind='Or.inr ⟨callee,args,kind⟩' if family=='indirect' else 'Or.inl ⟨fn,args,kind⟩'
 body=f''' := by
  obtain ⟨raw,k,i,ops,atCall,world,outs,finalWorld,execute,returnedWorld,returns,postHeld,column⟩ :=
    {name} {args}
  have sourceTableEq : sourceTable b.term = some et := by rw [kind]; rfl
  have control := stock_{control}_try_normal_control raw sourceTableEq
  have agreement := stock_lower_original_try_normal_entry lowered scope dominated node block
    (show IsTryWith b.term et from {kind}) successor target func bound normal normalRead entered column postHeld
  have actualAgreement : NormalEntryAgreement f result label targetLabel targetBi raw.info.handlers.length bc fr' (vdefUpd ops outs atCall) := by
    rw [control.1]
    exact agreement
  have defined : SourceDefinedAt f result.ctx bi b.body.length fr → SourceDefinedAt f result.ctx targetBi 0 fr' := by
    intro original
    exact source_defined_try_normal_entry (count := rvals.length) dominated.ssa result.ctx block func
      (show IsTryWith b.term et from {kind}) original bound normal agreement.1 entered
  have slots : fr'.slots = fr.slots := by
    obtain ⟨source,vals,targetRegs,targetFound,sourceRead,types,set,frame⟩ := enterBlock_spec entered
    simp only [frame]
  exact ⟨raw,k,i,ops,atCall,world,outs,finalWorld,execute,by rw [slots]; exact returnedWorld,
    returns,postHeld,column,control.1,actualAgreement,defined⟩
end {ns}
'''
 Path('/tmp',dst+'.lean').write_text(header+signature+body)
