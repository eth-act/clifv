import StockTryGotLocalAreaResolved
import StockTryNormalSourceValues
import StockTryGotLiveResolvedSource
namespace Backend.Stock.Proof.TryGotLocalAreaColumnsDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open TryLiveResolvedSourceDraft TryGotLiveResolvedSourceDraft TryLiveNormalDraft TryResolvedRunsDraft
open TryDirectSourceRunDraft TryGotSourceRunDraft TryIndirectSourceRunDraft
open TryNormalValueColumnsDraft TrySelectedCallsDraft TryBranchAbiDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
open TryGotLocalAreaResolvedDraft
theorem stock_lower_got_try_critical_normal_column_source_values_local_area {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f) (input : Prg.iselInB f = true)
    {label bi : Nat} {b : Clif.Block} (node : result.order.nodes[label]? = some (.original bi))
    (block : f.blocks[bi]? = some b) {fn : Nat} {args : List Nat} {et : Clif.ExnTable}
    (kind : b.term = .tryCall fn args et) {ext : Clif.ExtFunc} (external : f.extern? fn = some ext)
    (far : ext.colocated = false)
    {edgeLabel targetBi : Nat}
    (edge : result.order.nodes[edgeLabel]? = some (.edge bi et.handlers.length targetBi))
    {Rd F : BitVec 64 → Prop} {asm : FnCtx} {X : ExtSem} {MR : MemRelT} {sb : Nat} {syms : String → Option Nat}
    (stable : MRStable F MR) (memory : MemRefinesR Rd F sb syms (csem F asm X))
    (outgoing : OutArgsOk F (stackBytes ext.sig) MR)
    {env : Clif.Env} {exts : List Clif.ExtFunc}
    (calls : XCallsOk env exts MR X) (member : ext ∈ exts)
    {fr : Clif.Frame} {ρ : Nat → CV} {w : Arm.ArmState} {cm cm' : Clif.Mem} {vals rvals : List Clif.Val}
    (held : ValuesHeld (fun x => x ∈ args) result.ctx fr (fun key => ρ (keyMap result key))) (read : fr.getMany args = .ok vals)
    (typed : vals.map (·.ty) = Clif.AbiParam.tys ext.sig.params) (related : MR fr.slots cm w)
    {g : List Clif.Val → Clif.Mem → Clif.Outcome} (found : env.extern ext.name = some g)
    (returned : g vals cm = .returned rvals cm')
    (results : rvals.length = ext.sig.returns.length)    (liveHeld : ValuesHeld (fun x => x ∈ availOf f (availIn f result.ctx) bi b.body.length) result.ctx fr
      (fun key => ρ (keyMap result key)))
    {regs : Clif.Regs} {bc : Clif.BlockCall} {normalValues : List Clif.Val}
    (bound : fr.regs.setMany ((List.range rvals.length).map (f.freshValue + ·)) rvals = some regs)
    (normal : Clif.tryNormal et f.freshValue = .ok bc)
    (normalRead : ({fr with regs} : Clif.Frame).getMany bc.args = .ok normalValues) :
    ∃ (raw : GotTryRun f result label bi b ext (csem F asm X) MR fr (fun key => ρ (keyMap result key)) w rvals cm')
      (k : Nat) (i : MInst) (ops : Array Operand) (atCall : Nat → CV) (world : Arm.ArmState)
      (outs : List CV) (finalWorld : Arm.ArmState),
      seqRun (csem F asm X) (raw.source.branch.step.emitted.toList.map (·.mapRegs (resolver result))) ρ w =
        some (.stop k i ops atCall world outs finalWorld (.goto raw.info.handlers.length)) ∧
      MR fr.slots cm' finalWorld ∧
      (∀ (j : Nat) (v : Clif.Val),rvals[j]? = some v → VHolds v (vdefUpd ops outs atCall (keyMap result (raw.base+j)))) ∧
      ValuesHeld (fun x => x ∈ availOf f (availIn f result.ctx) bi b.body.length) result.ctx fr
        (fun key => vdefUpd ops outs atCall (keyMap result key)) ∧
      NormalColumnValues result edgeLabel 0 normalValues (vdefUpd ops outs atCall) := by
  obtain ⟨raw,targetFixed,arguments,sources,run⟩ := stock_lower_got_try_resolved_live_normal_source_run_local_area lowered scope dominated input
    node block kind external far stable memory outgoing calls member held read typed related found returned results
  obtain ⟨k,i,ops,atCall,world,outs,finalWorld,execute,returnedWorld,returns,frame⟩ := run
  have postHeld : ValuesHeld (fun x => x ∈ availOf f (availIn f result.ctx) bi b.body.length) result.ctx fr
      (fun key => vdefUpd ops outs atCall (keyMap result key)) := by
    intro x available v present
    obtain ⟨key,mapped,value⟩ := liveHeld x available v present
    refine ⟨key,mapped,?_⟩
    change VHolds v (vdefUpd ops outs atCall (keyMap result key))
    rw [(frame x key available mapped).2]
    exact value
  obtain ⟨items,table,_,_,_,_,_⟩ := stock_selected_try_got_rhs_calls raw.selected kind external far
  have sourceTableEq : sourceTable b.term = some et := by rw [kind]; rfl
  have column := stock_lower_critical_normal_column_values lowered scope dominated input node block sourceTableEq table
    edge raw.source raw.base raw.layout results bound normal normalRead postHeld returns
  exact ⟨raw,k,i,ops,atCall,world,outs,finalWorld,execute,returnedWorld,returns,postHeld,column⟩

end Backend.Stock.Proof.TryGotLocalAreaColumnsDraft
