import StockTryNormalIndirectSourceValues
import StockTryNormalGraph
import StockTryCriticalNormalWitness
import FV.E2E.RegLevelDriverSem
namespace Backend.Stock.Proof.TryCriticalIndirectValuesWitnessDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open TryNormalIndirectSourceValuesDraft TryNormalValueColumnsDraft TryNormalGraphDraft TryNormalCfgDraft
open TryNormalEdgeValuesDraft TryNormalCopiesDraft TryNormalControlDraft
open TryIndirectSourceRunDraft TryBranchAbiDraft TryResolvedRunsDraft TryWholeSourceReservationDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private def function := CriticalSplitFixture.function true
private def signature := function.sig
private def table : Clif.ExnTable := {sig := 0,normal := ⟨1,[.ret 0]⟩,items := []}
private def model : ExtSem := ⟨fun _ _ w => some ([17],w),fun _ _ => 4096,0,fun _ w => Arm.read_pstate w⟩
private def environment : Clif.Env := {
  extern := fun _ => some (fun _ cm => .returned [⟨.i64,17⟩] cm),names := ["callee"],sigOf := fun _ => some signature }
private def symbols : String → Option Nat := fun name => if name = "callee" then some 4096 else none
private def memory : Clif.Mem := {Clif.Mem.empty with symbols}
private def relation : MemRelT := fun _ cm _ => cm.symbols = symbols
private def fr : Clif.Frame := {
  func := function,regs := Clif.Regs.empty.set 0 ⟨.i64,4096⟩,slots := [],body := [],term := function.blocks[0]!.term }
private def resultRegs : Clif.Regs := fr.regs.set function.freshValue ⟨.i64,17⟩
private def normalCall : Clif.BlockCall := ⟨1,[function.freshValue]⟩
private def pending : Clif.Frame := {fr with regs := resultRegs,body := [],term := .jump normalCall}
private def entered : Clif.Frame := {pending with regs := resultRegs.set 2 ⟨.i64,17⟩,body := [],term := .ret [2]}
private theorem held : PrefixHold [⟨.i64,17⟩] ([17] : List CV) := by
  refine ⟨by decide,?_⟩
  intro j v x atValue atOut
  cases j with
  | zero => cases atValue; cases atOut; rfl
  | succ j => simp at atValue
private theorem xind : XCallsIndOk environment [signature] relation model := by
  intro sig member name g sl cm w u args vals rvals cm' found declared symbol count arguments related returned length typed
  have same := List.mem_singleton.mp member
  subst sig
  simp only [environment,Option.some.injEq] at found
  subst g
  cases returned
  exact ⟨[17],w,rfl,rfl,held,related⟩
private theorem abi : AbiSigsOk function := by
  constructor
  · constructor
    · decide +kernel
    · intro e member
      change e ∈ [(0,{name := "callee",sig := signature,colocated := false})] at member
      cases List.mem_singleton.mp member
      decide +kernel
  · intro sig member
    change sig ∈ [signature] at member
    cases List.mem_singleton.mp member
    exact ⟨by decide +kernel,by decide +kernel⟩
/-- COMPLETE original-condition critical INDIRECT compiler/physical/source AND
machine/value witness. The source indegree includes an unreachable predecessor;
the SAME actual stopped call feeds real synthetic-row copies into the original
normal target, with all available source values preserved. -/
theorem stock_complete_critical_indirect_normal_values_witness :
    ∃ (result : Result) (p : EdgeVCode) (rf : RFunc) (af : AFunc),
      Stock.lower function = .ok result ∧ LowerScope function ∧ Dominated function ∧ ArityOk function ∧ AbiSigsOk function ∧
      prepareAt result.code result.edgeArgs = .ok p ∧ rf = spillAllocAt p.code p.edges ∧
      checkAllocAt p.code p.edges rf = .ok () ∧ lowerRFunc p.code rf = .ok af ∧
      stockSourceTable function = .ok #[#[1],#[],#[1]] ∧
      sourceIndegree #[#[1],#[],#[1]] function.blocks.length = .ok #[0,2,0] ∧
      Node.original 2 ∉ result.order.nodes.toList ∧ result.order.nodes[1]? = some (.edge 0 0 1) ∧
      XCallsIndOk environment [signature] relation model ∧
      IndCallsRefineP (fun _ _ _ _ => True) environment (indSigs function) relation (csem (fun _ => False) ⟨0,0⟩ model) ∧
      Clif.enterBlock pending normalCall = .ok entered ∧
      (∃ raw : IndirectTryRun function result 0 0 function.blocks[0]! signature
        (csem (fun _ => False) ⟨0,0⟩ model) relation fr (fun _ => 4096) Arm.ArmState.default [⟨.i64,17⟩] memory,
        ∃ (k : Nat) (i : MInst) (ops : Array Operand) (atCall : Nat → CV) (world : Arm.ArmState)
          (outs : List CV) (finalWorld : Arm.ArmState) (args : Array Reg),
          seqRun (csem (fun _ => False) ⟨0,0⟩ model)
            (raw.source.branch.step.emitted.toList.map (·.mapRegs (resolver result))) (fun _ => 4096) Arm.ArmState.default =
            some (.stop k i ops atCall world outs finalWorld (.goto raw.info.handlers.length)) ∧
          relation entered.slots memory finalWorld ∧ raw.info.handlers.length = 0 ∧
          succOf result.code 0 raw.info.handlers.length = some 1 ∧ succOf result.code 1 0 = some 2 ∧
          NormalColumnValues result 1 0 [⟨.i64,17⟩] (vdefUpd ops outs atCall) ∧
          (result.edgeArgs[1]?.bind fun row => row[0]?) = some args ∧
          edgeEnvAt result.code result.edgeArgs 1 2 0 (vdefUpd ops outs atCall) =
            some (parCopyEnv (vdefUpd ops outs atCall) (edgeParamNumbers result function.blocks[1]!) (columnNumbers args)) ∧
          ValuesHeld (fun x => x ∈ availOf function (availIn function result.ctx) 1 0) result.ctx entered
            (fun key => parCopyEnv (vdefUpd ops outs atCall) (edgeParamNumbers result function.blocks[1]!)
              (columnNumbers args) (aliasNum result.final.alias key))) ∧
      Clif.runWith environment {funcs := [function]} function.name [] memory 6 = .returned [⟨.i64,17⟩] memory := by
  obtain ⟨result,p,rf,af,source,selected,base,before,value,after,edgeInput,edgeNext,args,
    lowered,scope,dominated,arity,prepared,fallback,accepted,physical,srcRun,degreeRun,complete,
    unreachable,edge,layout,helper,defs,call,numbers,stored,length,sourceRun⟩ :=
    TryCriticalNormalWitnessDraft.stock_complete_try_critical_normal_vectors_witness true
  have order : blockOrder function = .ok {nodes := #[.original 0,.edge 0 0 1,.original 1],successors := #[#[1],#[2],#[]]} := by cbv
  have sameOrder := Except.ok.inj ((stock_lower_order lowered).symm.trans order)
  have node : result.order.nodes[0]? = some (.original 0) := by rw [sameOrder]; rfl
  have block : function.blocks[0]? = some function.blocks[0]! := rfl
  have kind : function.blocks[0]!.term = .tryCallIndirect 0 [] table := rfl
  have tableRun : exnTableOpnd function table = .ok (signature,[]) := rfl
  have input : Prg.iselInB function = true := by decide +kernel
  obtain ⟨ranges,source',selected',base',value',next',build,rest⟩ := stock_lower_original_try_reservation
    lowered scope input node block (show sourceTable function.blocks[0]!.term = some table from rfl) tableRun
  have projection : ((Stock.buildCtx function).toOption.map (fun q => q.1.valueReg? 0)) = some (some (.vreg 192 .int)) := rfl
  change Stock.buildCtx function = .ok (result.ctx,ranges,result.initial) at build
  rw [build] at projection
  have mapping : result.ctx.valueReg? 0 = some (.vreg 192 .int) := Option.some.inj projection
  have liveHeld : ValuesHeld (fun _ => True) result.ctx fr (fun _ => 4096) := by
    intro x available v lookup
    by_cases zero : x = 0
    · subst x
      change some ⟨.i64,4096⟩ = some v at lookup
      cases lookup
      exact ⟨192,mapping,rfl⟩
    · simp [fr,Clif.Regs.empty,Clif.Regs.set,zero] at lookup
  have heldArgs : ValuesHeld (fun x => x = 0 ∨ x ∈ ([] : List Nat)) result.ctx fr (fun _ => 4096) := by
    intro x member v lookup
    exact liveHeld x trivial v lookup
  have contract : IndCallsRefineP (fun _ _ _ _ => True) environment (indSigs function) relation
      (csem (fun _ => False) ⟨0,0⟩ model) := (indCallsRefine_csem (syms := symbols) xind
        (by intro n b found; by_cases same : n = "callee" <;> simp [symbols,same] at found; cases found; rfl)
        (by intro sl cm w related; exact related)).toP _
  have sourceBind : fr.regs.setMany ((List.range 1).map (function.freshValue + ·)) [⟨.i64,17⟩] = some resultRegs := rfl
  have normalRead : ({fr with regs := resultRegs} : Clif.Frame).getMany normalCall.args = .ok [⟨.i64,17⟩] := rfl
  have run := stock_lower_indirect_try_critical_normal_column_source_values (ρ := fun _ => 4096) (w := Arm.ArmState.default)
    (cm := memory) (cm' := memory) lowered scope dominated input abi node block kind tableRun edge
    (driverSem_csem _ _ _) contract heldArgs (show fr.getMany [] = .ok [] from rfl)
    (show ([] : List Clif.Val).map (·.ty) = Clif.AbiParam.tys signature.params from rfl)
    (show relation fr.slots memory Arm.ArmState.default from rfl)
    (show fr.get 0 = .ok ⟨.i64,BitVec.ofNat 64 4096⟩ from rfl)
    (show memory.symbols "callee" = some 4096 from rfl)
    (by intro s hs; cases Option.some.inj hs; rfl)
    (show environment.extern "callee" = some (fun _ cm => .returned [⟨.i64,17⟩] cm) from rfl)
    trivial rfl rfl (fun x available v lookup => liveHeld x trivial v lookup) sourceBind
    (show Clif.tryNormal table function.freshValue = .ok normalCall from rfl) normalRead
  obtain ⟨raw,k,i,ops,atCall,world,outs,finalWorld,execute,related,returns,postHeld,column⟩ := run
  obtain ⟨copyArgs,actual,properties⟩ := column
  have argumentValues : NormalColumnValues result 1 0 [⟨.i64,17⟩] (vdefUpd ops outs atCall) := ⟨copyArgs,actual,properties⟩
  have sourceEntered : Clif.enterBlock pending normalCall = .ok entered := rfl
  have control := stock_indirect_try_normal_control raw (et := table) (by rfl)
  have normalZero : raw.info.handlers.length = 0 := control.1
  have first : succOf result.code 0 raw.info.handlers.length = some 1 := by
    rw [stock_lower_actual_successor lowered scope,normalZero,sameOrder]; rfl
  have second : succOf result.code 1 0 = some 2 := by
    rw [stock_lower_actual_successor lowered scope,sameOrder]; rfl
  have targetTag : result.order.nodes[2]? = some (.original 1) := by rw [sameOrder]; rfl
  have identified := stock_lower_try_normal_critical_target lowered scope block
    (show IsTryWith function.blocks[0]!.term table from .inr ⟨0,[],rfl⟩) edge
  have copied := stock_lower_try_normal_edge_values (rvals := [⟨.i64,17⟩]) lowered scope dominated block rfl
    (show IsTryWith function.blocks[0]!.term table from .inr ⟨0,[],rfl⟩) sourceBind
    (show Clif.tryNormal table function.freshValue = .ok normalCall from rfl) normalRead sourceEntered
    (show function.blocks[1]? = some function.blocks[1]! from rfl)
    (show function.block? normalCall.block = some function.blocks[1]! from rfl)
    identified.1 targetTag identified.2 actual argumentValues postHeld
  exact ⟨result,p,rf,af,lowered,scope,dominated,arity,abi,prepared,fallback,accepted,physical,srcRun,degreeRun,
    unreachable,edge,xind,contract,sourceEntered,⟨raw,k,i,ops,atCall,world,outs,finalWorld,copyArgs,execute,related,
      normalZero,first,second,argumentValues,actual,copied.1,copied.2⟩,rfl⟩
end Backend.Stock.Proof.TryCriticalIndirectValuesWitnessDraft
