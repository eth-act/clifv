from pathlib import Path
import json,hashlib,re,datetime,tarfile,shutil,subprocess
root=Path('/home/lee/clifv/.worktrees/driver-proof-resume');docs=root/'docs/research';prefix='stock-try-normal-entry'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
now=datetime.datetime.now(datetime.timezone.utc);stamp=now.strftime('%Y%m%dT%H%M%SZ')
batch=json.loads(Path('/tmp/'+prefix+'-batch.json').read_text());old=json.loads((docs/'stock-try-normal-control-scratch.json').read_text())
log=Path('/tmp/'+prefix+'-combined-axioms.log').read_text()
sets={m.group(1):sorted(x.strip() for x in m.group(2).split(',') if x.strip()) for m in re.finditer(r"'([^']+)' depends on axioms:\s*\[([^]]*)\]",log)}
for m in re.finditer(r"'([^']+)' does not depend on any axioms",log):sets[m.group(1)]=[]
for n,a in old['normal_audit']['sets'].items():assert sorted(a)==sets[n],n
assert len(sets)==len(old['normal_audit']['sets'])+len(batch['public_roots'])+len(batch['models'])
allowed={'propext','Classical.choice','Quot.sound'}
for n in batch['public_roots']+batch['models']:assert set(sets[n])<=allowed,n
constants=[json.loads(line.split('DELIVERY_CONSTANT ',1)[1]) for line in Path('/tmp/'+prefix+'-all-constants.log').read_text().splitlines() if line.startswith('DELIVERY_CONSTANT ')]
assert constants
for n,a in constants:assert set(a)<=allowed,n
mods={}
for m in batch['modules']:
 p=Path('/tmp')/m;check=json.loads(p.with_suffix('.check.json').read_text());assert check['actual_exit']==0
 rec={}
 for key,ext in [('source','.lean'),('object','.olean'),('log','.log'),('check','.check.json')]:
  f=p.with_suffix(ext);rec[key]=str(f);rec[key+'_sha256']=sha(f)
 for k in ['source','object','log']:assert rec[k+'_sha256']==check[k+'_sha256']
 assert not re.search(r'\b(sorry|admit|axiom|trace_state|native_decide)\b',p.with_suffix('.lean').read_text()),m
 mods[m]=rec
for audit in [prefix+'-combined-axioms',prefix+'-all-constants']:
 p=Path('/tmp')/audit;check=json.loads(p.with_suffix('.check.json').read_text());assert check['actual_exit']==0
 for k,ext in [('source','.lean'),('object','.olean'),('log','.log')]:assert sha(p.with_suffix(ext))==check[k+'_sha256']
prior={}
for name in ['source-execution-x','try-source','try-context','try-rule','try-rets','try-reservation','try-outgoing','try-values','try-emitted','try-machine','try-got','try-indirect','try-rename','try-resolved','try-gap','try-got-rename','try-normal-frame','try-metadata','source-index','try-normal-vector','try-critical-normal','source-erase','source-origin','try-live-frame','try-normal-values','try-normal-copy','try-normal-control']:
 d=json.loads((docs/f'stock-{name}-scratch.json').read_text())
 for m,rec in d['modules'].items():
  for k in ['source','object','log']:assert sha(rec[k])==rec[k+'_sha256'],(m,k)
  prior[m]=rec
assert len(prior)==175
freeze=json.loads(Path('/tmp/stock-coherent-build-inputs.json').read_text())
for group in ['source_sha256','validation_script_sha256']:
 for p,h in freeze[group].items():assert sha(root/p)==h,p
imports=json.loads(Path('/tmp/stock-try-rule-inputs.json').read_text())
for m,r in imports['modules'].items():
 assert sha(r['snapshot'])==r['object_sha256'],(m,'snapshot')
 assert sha(r['source'])==r['source_sha256'],(m,'source')
progress=json.loads(Path('/tmp/stock-pr246-gates-progress.json').read_text());progress.pop('completed_phases',None)
subprocess.run(['ps','-p','3247835','-o','pid,stat,etime,args'],check=True)
remaining=list(old['remaining_checklist']);remaining.append({'requirement':'Whole near/GOT/indirect actual normal source entry and COMPLETE critical machine/value non-vacuity','state':'Original-contract consumers construct SAME stopped raw/final-renamed machine run, returned memory relation at entered-frame slots, actual normal index, source-target identity/nonentry, actual executable CFG, actual stored column/copy environment and ALL destination-available source register agreement. Existing source-definedness invariant is preserved as a conclusion, no new accepted-input condition. Complete near/GOT/indirect full pipelines exercise actual defined-before/after source frames. COMPLETE critical INDIRECT AND GOT machine/value/source/copy/CFG/compiler/fallback/checker/physical witnesses now PASS using saved cached critical pipelines; true unreachable predecessor/indegree2 retained. GOT additive local-area variants weaken OutArgsOk from whole result area to actual callee stackBytes, retaining old variants/original semantic contracts; critical zero-stack call needs no cold outgoing projection. Near critical full machine/value/compiler observation remains PENDING after archived8GiB failures, larger kernel queued after delivery lane frees. Actual branch placement/whole-block VStepAt/prepared continuation, whole-driver simulation/completeness and production/final gates remain OPEN.'})
counts={'modules':len(mods),'public_roots':len(batch['public_roots']),'models':len(batch['models']),'combined_roots_models':len(sets),'previous_preserved':len(old['normal_audit']['sets']),'all_new_module_constants':len(constants),'previous_modules_hashes_preserved':len(prior)}
receipt={'utc':now.isoformat(),'goal':'Original full #140 ACTIVE/INCOMPLETE; production LEGACY','scope':'Additive scratch proofs, coherent integration and full gates pending','delivery_target':'roughly8 substantive validated squash merges/day; semantic grouping, remote backup and cleanup','modules':mods,'public_roots':batch['public_roots'],'models':batch['models'],'counts':counts,'normal_audit':{'path':'/tmp/'+prefix+'-combined-axioms.log','sha256':sha('/tmp/'+prefix+'-combined-axioms.log'),'sets':sets},'all_constant_audit':{'path':'/tmp/'+prefix+'-all-constants.log','sha256':sha('/tmp/'+prefix+'-all-constants.log'),'all_standard_only':True,'count':len(constants)},'previous_modules_hashes_preserved':list(prior),'canonical2246_source_and_script_freeze_preserved':True,'import_generation':{'source_and_snapshot_hashes_checked':len(imports['modules']),'manifest_sha256':sha('/tmp/stock-try-rule-inputs.json'),'shared_cache_writes':False,'canonical_import_repair':'stock-try-normal-copy-scratch.json'},'nonvacuity':{'original_near_GOT_indirect':'COMPLETE original source/runtime/memory/callee/compiler/prepare/checkedfallback/checker/physical/source17 plus composed normal entry/control/copies/ALL destination agreement and actual source defined-before/after','critical_indirect':'COMPLETE machine/value/source/copy/CFG/compiler/checker/fallback/physical, true unreachable predecessor/indegree2','critical_GOT':'COMPLETE machine/value/source/copy/CFG/compiler/checker/fallback/physical, true unreachable predecessor/indegree2; actual local-area contract derived at zero stack bytes','critical_near':'PENDING; cached other forms do not substitute; larger kernel queued AFTER delivery lane frees, saved8GiB failures/VM candidate not proof'},'GOT_local_area_contract':'Additive premise weakening to OutArgsOk F (stackBytes ext.sig) MR; source scope/callee/memory/contracts unchanged, old whole-area variants retained; applies to arbitrary successfully lowered GOT signatures, not an accepted-program filter or zero-argument restriction','MCP':'Deferred until coherent integration; no new calls','active_exact_PR246_validation':progress,'remaining_checklist':remaining}
(docs/(prefix+'-scratch.json')).write_text(json.dumps(receipt,indent=2)+'\n')
text=f'''Composed normal source entries and COMPLETE critical GOT/indirect machine values — {now.isoformat()}

{len(mods)} scratch modules/{len(batch['public_roots'])} public roots/{len(batch['models'])} semantic model pass actual8GiB kernels. Cumulative{len(sets)}root/model audit preserves ALL698prior exact axiom sets; ALL{len(constants)}new-module constants including private source-definedness/witness/contract helpers standard-only. ALL175prior scratch source/object/log hashes, frozen2246canonical sources/49scripts and1049imported source/object snapshot hashes unchanged. No shared-cache writes.

Whole near/GOT/true-indirect normal-entry consumers now construct the SAME actual stopped raw/final-renamed call run, original returned memory relation at the ENTERED source frame slots, actual normal control index, internally derived source-target identity/nonentry, actual executable CFG edge, exact stored outgoing column and actual copy environment. They establish ALL available destination source values, including inherited nonparameters. Actual fr.func/source binding/read/enterBlock observations are ordinary runtime simulation conditions, not new accepted-program predicates. Source definedness preservation is an output implication, so no new definedness input is imposed. The derived NormalEntryAgreement is only a conclusion, never a caller acceptance certificate.

COMPLETE original near/GOT/indirect pipelines exercise these composed consumers with actual source-defined frames BEFORE and AFTER entry, original input/scope/dominance/arity/ABI/callee/memory contracts, compiler/prepare/forced checkedfallback/checker/physical stages and full source return17. Near/indirect use actual mixed17/9, nine-argument GOT16byte uses actual one-element17 normal vector. No old theorem variant changed.

COMPLETE CRITICAL INDIRECT machine/value witness now PASSES using the preserved critical compiler/physical pipeline, with actual nonidentity compiler aliases, source callee4096, actual renamed stopped call/returned17, nontrivial memory-symbol relation, actual synthetic-row values/copies, ALL original target available values and BOTH executable CFG hops. It retains the unreachable predecessor/original indegree2 and full source return17. No new cold compiler projection or heavy kernel was needed.

COMPLETE CRITICAL GOT machine/value witness now PASSES too. New additive variants weaken the outgoing-memory premise from the whole returned area to the ACTUAL callee stackBytes, retaining original contracts and all old variants. Original scope derives the same stack layout; the raw GOT target/argument/source alias separation and final renamed live frame are unchanged. This is generic in successful signatures/arguments, not a zero-argument input filter. The fixed critical witness's actual stack requirement is0, so its local contract is inhabited directly and no whole-output projection observation is needed. It includes actual symbol load/stopped call/returned17, synthetic-row copies/destination agreement/BOTH CFG hops/compiler/checker/fallback/physical and full source return17, retaining the unreachable predecessor/indegree2.

Near-critical COMPLETE machine/value/compiler observation remains PENDING after archived ordinary8GiB failures; one larger kernel waits until the active delivery heavy lane frees. VM output is not proof and the new critical GOT/indirect witnesses do not substitute for the near case. Next actual branch placement/whole-block VStepAt/prepared source continuation and whole-driver composition; remaining zero-return/sret/x8/width/handler/Try-critical matrix, shared payload/exception semantics, uncovered families/effects/sinking/source/block/whole-driver simulation AND completeness, original-input context/static/visitor/checker/fallback/physical totality, coherent integration/public/private/compiler/MCP/full build/crates/runtime/encoder/BOTH E2E identity-stage parity, actual compiler/checker/linker/generated consumers and FRESH COMPLETE comparison remain mandatory. Full#140 ACTIVE/INCOMPLETE; production LEGACY. Original input/theorem/axiom/identity-stage/#179parity preserved.

Delivery #246 same3247835 confirmedLIVE at{progress.get('index')}/{progress.get('total')}; canonical1233457deliberately held/exclusive single-cache lease. Both draft246/247 all3CIeachPASS freshly rechecked, main789152e freshly rechecked unchanged. Preserve old-head receipts, reconcile currentmain/shared machine assumptions and rerun affected kernel/trust plus ALL full/crates/runtime/encoder/BOTH E2E actual integrated-head gates before dependent squash246→247. Targetroughly8 substantive validated merges/day; coherent grouping, remote backup and cleanup. No merge/new tree/agent/MCP/cold compiler projection/larger kernel/heavyretry/restart/other-project cleanup. Shared Kev S10/FP/Link boundaries preserved; contributor52/71/task140 reread. Hashed evidence/full remaining checklist: stock-try-normal-entry-scratch.json.
'''
(docs/(prefix+'-scratch.md')).write_text(text);plan=root/'docs/plans/test-binary-alignment-recovery.md';plan.write_text(plan.read_text()+'\n\n'+text)
current=docs/'stock-full-goal-current.md';s=current.read_text();Path('/tmp/'+prefix+'-full-goal-before.md').write_text(s)
lines=s.splitlines()
for i,line in enumerate(lines):
 if line.startswith('| Complete non-vacuity witnesses |'):
  lines[i]='| Complete non-vacuity witnesses | COMPLETE near/GOT/indirect composed normal source-entry/value/control/CFG/copy/source-defined-before-and-after/compiler/checkedfallback/physical/source17. COMPLETE critical GOT AND indirect machine/value/copy/CFG/source/compiler/checker/physical witnesses preserve unreachable predecessor/indegree2. All earlier ABI/static/source witnesses retained | Near-critical complete machine/value/compiler observation remains pending; one larger kernel after live heavy lane frees. Finish all zero-return/sret/x8/width/handler/Try-critical, whole-driver/production ABI and every remaining public-root premise witness; graph witnesses alone do not substitute |'
 elif line.startswith('| Public-root/kernel/transitive axiom audit |'):
  lines[i]=f'| Public-root/kernel/transitive axiom audit | Latest continuation scratch cumulative{len(sets)}roots/models preserve698prior exact sets;{len(constants)}new-module constants including private helpers Std-only,175prior module hashes preserved; source freeze unchanged | Coherent canonical integration/current integrated public/private/model/compiler audit, ONE bundled MCP and final production audit. Scratch{len(sets)}does not establish complete integrated/cutover audit |'
 elif line.startswith('| Register agreement, fresh writes and final aliases |'):
  lines[i]='| Register agreement, fresh writes and final aliases | Actual source result binding, original normal source entries and critical GOT/indirect machine/value witnesses retain final aliases, exact stored columns, actual CFG/copies and ALL destination-available values. Composed entry consumers preserve source definedness; original-condition full witnesses pass | Integrate after frozen validation; complete near-critical/full ABI matrix, actual placed whole-block/prepared continuation, universal source/world agreement/fresh-write noninterference and whole-driver simulation/completeness |'
current.write_text(f'Latest checkpoint {now.isoformat()}: [composed normal entry and complete critical GOT/indirect machine values](stock-try-normal-entry-scratch.md). {len(mods)}modules/{len(batch["public_roots"])}roots/{len(batch["models"])}model, cumulative{len(sets)}preserves698prior exact sets;{len(constants)}new-module constants standard-only. Critical GOT/indirect now have COMPLETE machine/value/copy/CFG/source/compiler/physical witnesses. Near-critical remains pending. Full#140 ACTIVE/INCOMPLETE; production LEGACY; all original final obligations below remain mandatory. Same live246gate at{progress.get("index")}/{progress.get("total")}; no merge.\n\n'+'\n'.join(lines)+'\n')
files=[]
for rec in mods.values():files.extend(Path(rec[k]) for k in ['source','object','log','check'])
for name in [prefix+'-combined-axioms',prefix+'-all-constants']:
 for ext in ['.lean','.log','.olean','.check.json']:files.append(Path('/tmp')/(name+ext))
for p in Path('/tmp').glob(prefix+'*'):
 if p.is_file():files.append(p)
files.extend([Path('/tmp/stock-try-rule-inputs.json'),Path('/tmp/stock-try-reservation-check.py'),Path('/tmp/stock-source-erase-restore.py'),docs/(prefix+'-scratch.json'),docs/(prefix+'-scratch.md'),docs/'stock-delivery-main-drift.json',plan,current])
files=list(dict.fromkeys(files))
archive=Path('/home/lee/.clifv-recovery')/(stamp+'-try-normal-entry')/'checkpoint.tar.gz';archive.parent.mkdir(parents=True)
with tarfile.open(archive,'w:gz',compresslevel=1) as t:
 for p in files:t.add(p,arcname=str(p).lstrip('/'),recursive=False)
with tarfile.open(archive,'r:gz') as t:
 for p in files:assert t.extractfile(str(p).lstrip('/')).read()==p.read_bytes(),p
snapshot=Path('/tmp/stock-try-rule-inputs');size=sum(p.stat().st_size for p in snapshot.rglob('*') if p.is_file());shutil.rmtree(snapshot)
backup={'utc':now.isoformat(),'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(files),'all_members_byte_verified':True,'previous_remote_backup':json.loads((docs/'stock-try-normal-control-backup.json').read_text())['remote'],'cleanup':{'duplicate_dependency_snapshot_removed':True,'bytes_reclaimed':size,'all_unique_sources_objects_logs_checks_audits_preserved':True,'one_shared_warm_cache_retained':True,'other_projects_touched':False,'free_bytes':shutil.disk_usage(root).free}}
(docs/(prefix+'-backup.json')).write_text(json.dumps(backup,indent=2)+'\n');Path('/tmp/'+prefix+'-archive-path').write_text(str(archive))
print(json.dumps({'counts':counts,'archive':str(archive),'cleanup':backup['cleanup'],'gate':progress},indent=2))
