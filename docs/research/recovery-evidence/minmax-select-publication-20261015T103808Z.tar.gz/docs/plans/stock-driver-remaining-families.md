# Remaining Stock-driver semantic obligations (#140)

## Consolidated minmax/select publication — 2026-10-15T10:37:54.065478+00:00

Active checkpoint 2026-10-15T10:37:54.065478+00:00: squash-merged https://github.com/eth-act/clifv/pull/202 at63fdd773bac9583870442f494625575e7c7a839e (single parentce20c38), validated headd4e70db34c78b6d41d29cd09a84e962c54ad8fff. One consolidated semantic batch:67 new minmax/select proof modules/77 standard-only roots,69 additions only; no existing compiler/theorem sources changed. All3CI checks pass for the exact head, all671 exact matched identities and every CI total equal main,0 gained/0 lost, unchanged harness. Merged tree equals validated PR tree; all67 source hashes verified. This is ONE additional backlog merge since corrected discipline (maximum nine), clearing the validated minmax/select backlog as one batch. Future completed work stays in substantial batches, rough3/day up to6 after catch-up.

Local full2298/crates1171/runtime4672/0/0 with same7 nonrunnable/family counts/encoder1292 identical0different/bothE2E1150accepted0rejected with original identity/stage bytes preserved. Normal1556-root audit preserves all1479 former main sets and7 compiler sets exactly; all77 new roots standard-only. Publication checks use2316 byte-identical non-documentation inputs. Source witnesses include48 narrow minmax families,16 parameter-select families,32 direct/uextended ult comparison-select families over arbitrary original comparison words, actual unmaterialized condition zero-demand/DFG/availability/source-step/memory/post-frame. All530 previously gated proof sources are now on main. Recovery receipts stock-select-retained-comparison-checkpoint.json and stock-minmax-select-publication.json retain evidence. #140 full objective remains active/incomplete; production legacy.

Execution note: an extra pre-merge assertion incorrectly demanded global full_artifact_equivalence_verified=true. It failed because existing stock-corpus coverage gaps leave that flag false; the shell continued to the authorized merge after the Python failure. Required CI/head/base/identity checks and post-merge tree/source/squash-parent checks pass. Downloaded main and PR summaries confirm that global flag, every total, full matched-entry list and harness hashes are unchanged. This does not claim full corpus or full-goal completion. Future prerequisite validation and mutations must run in separate tool calls so a failed prerequisite cannot fall through to a merge.

Canonical recovery /home/lee/clifv/.worktrees/driver-proof-resume, agent/stock-logic-not-values-pr localHEAD01081291 preserved; primary untouched. Publication stock-casts-scope-pr remains clean at authored headd4e70db. Verified backup0a206b04 captures688 dirty paths plus33-member evidence archive; fresh merged/CI evidence snapshot follows. Contributor statuses52/71 and claimed140 reread, no shared T6/README overlap.

Next, tentative/not a reservation: continue additional comparison/form retained witness coverage and remaining accepted rule families/effects, deferred traps/sinking, source/block/node/whole-driver simulation and completeness, then actual compiler/checker/linker/generated-proof production integration. Preserve original conditions/old variants/accepted identities/stages/trust/#179 baseline; fresh complete Stock comparison required before cutover. Keep #140 open and active.


## Complete retained comparison-select witness checkpoint — 2026-10-15T10:29:28.188925+00:00

Three modules/three standard-only public roots prove32 complete original direct/uextended ult comparison-select driver/retained/source-step families at every8/16/32/64 comparison/result width, over every original comparison operand pair. Real records prove zero demand for unmaterialized original100/101 condition values; the source frame nevertheless contains the actual icmp/uextend values with DFG consistency. Four distinct parameters, chosen7/9 values, dirty high machine bits, actual context key/aliases/root2267, retained binding, memory and guarded post-frame are included. The finite context metadata is checked with normal kernel decisions, and the full32-case actual Stock.lower kernel matrix passed in846s. This is not whole-driver simulation/completeness.

Full2298/crates1171/runtime4672/0/0 with same7 nonrunnable/family counts/encoder1292 identical0different/bothE2E1150accepted0rejected and original identity/stage bytes preserved. Normal1556-root audit preserves all1553 prior sets and seven compiler sets exactly; one bundled3-root MCP agrees. All527 prior proof source hashes unchanged. Receipt `docs/research/stock-select-retained-comparison-checkpoint.json`. Saved prevalidation69030ec5 captures682 dirty paths; final evidence snapshot follows.

Prepared a single consolidated semantic publication in the existing clean stock-casts-scope-pr worktree, branch `agent/stock-minmax-select-source-pr`, from maince20c38:67 new minmax/select proof modules/77 standard-only roots, universal narrow minmax and original select condition/consumer/root/retained/source semantics. Publication full2298 build and exact1556-root audit pass, all1479 main root sets preserved,2316 non-documentation inputs byte-identical to the recovery tree; runtime/crate/encoder/bothE2E evidence therefore applies. Receipt `docs/research/stock-minmax-select-source-integration.json`. No commit/PR/merge yet; zero of maximum nine additional backlog PRs used. Keep this as one substantial batch; after catch-up rough3/day, up to6, backup pushes independent.

Next: commit/push this reviewable semantic batch, open one PR, require all CI checks and original identity parity, then squash merge within the corrected limit. Additional retained witness variants for other comparison conditions and constant/fused/mirrored forms remain useful coverage. All remaining uncovered families/effects, deferred traps/sinking, source/block/node/whole-driver simulation/completeness and actual compiler/checker/linker/generated-proof production integration remain. Preserve original conditions, variants, successful identities/stages, exact trust and#179 baseline; fresh complete Stock comparison required before cutover. #140 active/incomplete; production legacy.


## Universal original select source checkpoint — 2026-10-15T09:57:22.609859+00:00

Twelve further modules/13 standard-only public roots pass full2295/crates1171/runtime4672/0/0 with the same7 nonrunnable and family counts/encoder1292 identical0different/bothE2E1150accepted0rejected and identity/stage report bytes unchanged. Normal1553-root audit preserves all1540 earlier axiom sets and exact7 compiler sets; one bundled13-root MCP agrees. All515 preceding proof source hashes preserved. Receipt: `docs/research/stock-select-original-source-checkpoint.json`.

Actual comparison652→659 computes original selected values for every scalar comparison width and every operand form, including the actual zero producer change and arbitrary extension prefixes. Forty complete helper witness families cover every original operand-word pair with dirty high bits and nonidentity aliases. Generic producer replacement and decoded659 observation now have all-width/form/size/outcome witnesses. Decoded scalar conditions construct actual659 success internally.

The general original650 condition/source theorem covers ordinary definitions as well as direct/zero-extended comparison look-through; parameter restrictions are absent. Unique root2267 composes with the actual output, retained result binding and guarded original source-step/memory/post-frame. The retained theorem internally derives every getter's context type and final alias separation outside the whole scratch/result interval from original availability, keeping the original input guards and older variants unchanged. Sixteen complete original parameter driver/source families over every condition word now call this universal source theorem.

Remaining select work is its full original comparison-retained/source witness matrix, not these source theorem bodies. Exact checked continuation `docs/research/stock-select-comparison-driver-draft.lean` proves real complete Stock.lower runs for direct and zero-extended .i64 ult selects with four distinct source operands, original source context key, actual unique select record/root and all four parameter aliases. It is normal-kernel standard-only but outside this12-module gated scope. Generalize supported condition/result widths and source condition/form matrix, construct original source frames with actual icmp/uextend values and restricted DFG/availability facts, then call `stock_lower_select_source_values` for complete source-step/memory/post-frame witnesses. Keep those witnesses and the current minmax/select proofs together for substantial semantic publication. Earlier parameter-specific and typed variants remain byte-identical.

All other uncovered families/effects, deferred traps/sinking, source/block/node/whole-driver simulation/completeness and compiler/checker/linker/generated-proof production cutover remain; fresh complete Stock comparison required before cutover. Original conditions/theorems/identities/stages/trust/#179 baseline preserved. #140 active/incomplete; production legacy. Zero PRs/merges since corrected discipline; maximum9 additional backlog PRs then rough3/day up to6, backups independent. Remote recovery snapshot follows.


## Comparison condition/companion checkpoint — 2026-10-15T09:41:42.030081+00:00

Ten further modules/13 new standard-only public roots pass full2283/crates1171/runtime4672/0/0 with the same7 nonrunnable and original family counts/encoder1292 identical0different/bothE2E1150accepted0rejected with identity/stage report bytes unchanged. The normal1540-root audit preserves every1527 prior axiom set and all7 compiler sets exactly; a single bundled13-root MCP agrees. All505 prior proof source hashes unchanged. Receipt: `docs/research/stock-select-comparison-condition-checkpoint.json`.

Actual651 decoded condition shape, full-state649 inversion and all mirrored zero RHSs now compose; actual652 scalar comparison shape covers every12 first-match branches, all8/16/32/64 widths and source integer conditions without operand-classification certificates. Decoded shape constructs an actual715 proof companion internally and the existing complete comparison semantics proves its original source predicate. Forty complete comparison-companion families hold over every original pair of operand words with dirty high machine bits and nonidentity final aliases, plus condition/inversion/zero-RHS witnesses. These facts do not yet prove actual659 csel/source select execution.

Exact next continuation: `docs/research/stock-select-condition-observed-draft.lean` normal-kernel proves actual659 observation under CondShape, deriving the actual cmpXzr/explicit producer and proof-only cmpImm0/explicit producer CondFlag relations, real guarded requests, fresh result and complete full state. `docs/research/stock-select-condition-replacement-draft.lean` normal-kernel proves generic final-resolver producer/cset-to-actual-producer/csel replacement from those relations, covering all three scalar shapes. Both drafts are standard-only but outside this10-module gated scope and still need explicit non-vacuity witnesses/audit. Promote them, use empty retained buffer plus Frag to extract exact comparison prefix, transport boolean comparison execution to actual csel with both chosen values held outside the entire allocation interval, then compose actual650 direct/uextended source truth, root2267, retained binding and original guarded source-step/memory/post-frame. Derive comparison and selected operand types/availability/scratch separation internally from original source guards. Complete the full direct/uextended/fused/constant/width witness matrix, and handle general source definitions taking650→651 (parameter coverage alone is insufficient).

All other uncovered families/effects, deferred traps/sinking, source/block/node/whole-driver simulation/completeness and actual compiler/checker/linker/generated-proof consumer production cutover remain. Preserve original conditions, variants, accepted identities/stages, exact trust sets and#179 baseline; fresh complete Stock comparison remains required before cutover. #140 active/incomplete; production legacy. Zero new PRs/merges, keep substantial semantic batches together, fewer than ten additional backlog PRs then rough3/day up to6; recovery backups independent. Remote recovery snapshot follows.


## Original select source integration checkpoint — 2026-10-15T09:21:48.971734+00:00

Twenty further modules/23 new standard-only public roots pass full2273/crates1171/runtime4672/0/0 with same7 nonrunnable and original family counts/encoder1292 identical0different/bothE2E1150accepted0rejected with original identity/stage report bytes preserved. Combined normal1527-root audit preserves all1504 preceding exact axiom sets and7 compiler trust sets, plus all20 earlier local integration root sets exactly. One bundled23-root MCP agrees exactly with normal root sets; source scans clean and all485 previous source hashes unchanged. Receipt: `docs/research/stock-select-source-integration-checkpoint.json`. Earlier1524-root checkpoint/raw evidence and exact pre-derived-type witness source retained for recovery.

Actual zero producer/cset→register-zero producer/csel replacement and final-resolver transport now have nonempty-prefix/all scalar-width/both test-size/form/outcome/nonidentity-alias witnesses. Actual651+659 source semantics cover8/16/32/64 source conditions, including the real16-bit extension scratch and complete outside-allocation frame. Actual650 dispatch derives scalar651 versus original direct/uextended-icmp652 source provenance; original DFG derives both comparison getters and original condition truth.

For parameter conditions, actual unique root2267, allocation, retained result binding/copy absence, guarded original source-step transfer, memory and demanded/available post-frame now compose. Complete16 actual condition/result-width driver/source families hold over every original condition word with distinct7/9 operands and dirty upper machine bits. Shared `StockAvailableTypes` derives original declared-value type existence in actual scan contexts, and availability+restricted DFG+getter determines the exact source type. A new source variant internally derives supported condition width and context typing; earlier explicit-type variants remain unchanged. Complete witnesses call the derived-type variant.

Exact next comparison look-through work: promote `docs/research/stock-nonzero-condition-shape-draft.lean` with non-vacuity/audit (normal-kernel standard-only actual651 CondShape already checked). Derive CondShape for actual scalar652 without operand classifications:12 original first-match branches; zero/inverse-zero reuse this651 shape and `StockCmpFlagInvert`/`StockCmpZeroHelpers`, while immediate/register/predecessor/narrow branch observers already expose exact flag producers. Classify the raw scalar condition into Zero/NotZero/explicit flags, construct actual715 proof-only companion at the same producer state, and compose the complete existing wide/narrow `CmpExecution` once. Explicit flags use existing cset/csel replacement; Zero/NotZero use new cmpImm0+cset→cmpXzr+csel replacement. Empty scan buffer plus Frag yields exact companion prefix/code, and all real selected operands/comparison operands must resolve outside the actual retained allocation interval from original availability. `StockSelectConditionOriginValues` supplies original comparison getters/truth, and `StockAvailableTypes` supplies exact context types from those restricted getters; derive supported comparison width from original definition scope. Then compose selected/root/retained/source-step transfer and complete direct/uextended comparison/fused-condition witness matrices. Other source definitions falling through650 to651 also need the general branch wrapper; parameter coverage does not close them.

All other uncovered rule families/effects, deferred trapping/sinking semantics, source/block/node/whole-driver simulation and completeness and actual compiler/checker/linker/generated-proof production integration remain. Fresh complete Stock comparison before cutover, original conditions/theorem variants/accepted identities/stages/axiom sets/#179 baseline preserved. #140 active/incomplete; production legacy. No PR or merge this checkpoint; zero of maximum nine additional backlog PRs used. Remote recovery snapshot follows, independent of merges.


## Checked narrow minmax and original select continuation — 2026-10-15T08:28:11.519047+00:00

Combined22 modules/25 new public roots pass kernel builds and1504-root audit, preserving all1479 earlier exact axiom sets plus16 narrow sets and seven compiler trust sets. All463 landed comparison/select/minmax proof sources unchanged; source scans clean and two bundled MCP audits agree exactly with all25 normal root sets, standard-only. Full2253/crates1171/runtime4672/0/0 plus same7 nonrunnable and family counts/encoder1292 identical0different/bothE2E1150accepted0rejected with original identity/stage report bytes preserved. Durable receipt: `docs/research/stock-narrow-select-checkpoint.json`. No new PR/merge; zero of maximum nine additional backlog PRs used since corrected discipline.

Narrow minmax is complete at the original retained/source-step level for all8/16 forms with internal two-register scratch/alias separation, unified8/16/32/64 dispatch and48 complete narrow source witness families (32 single-constant over every parameter word). Original select now has actual source data/matching, unique root2267 and650/659/output decomposition; a complete actual Stock.lower run inhabits these results and retained binding. Actual Zero/NotZero659 source-value consumer and dirty-upper-bit/nonidentity-alias witnesses pass. These original select results do not yet establish whole original select source-step execution.

Exact next bridge: `docs/research/stock-select-zero-replacement-draft.lean` has a normal-kernel standard-only proof replacing cmpImm0+cset by actual cmpXzr+csel after an arbitrary executed prefix, with source operands/outside frame and arbitrary refining semantics. It is outside the gated22 modules and still needs complete non-vacuity witnesses, resolver transport and actual650/659 composition. Then prove original650 condition truth for every651 scalar width and direct/uextended-icmp look-through, derive all final alias/scratch separation from original retained availability, compose original select binding/source-step transfer and complete its full witness matrix.

All other original families/effects, deferred trapping/sinking semantics, source/block/whole-driver simulation and completeness, compiler/checker/linker/generated-proof production integration and fresh complete Stock comparison remain. Original input conditions, theorem variants, accepted identities/stages/trust and #179 baseline preserved. #140 active/incomplete; production legacy. Remote backup for this checkpoint follows; previous verified601-path snapshot29dee626 remains retained.


## Current continuation 2026-10-15T08:17:03.886047+00:00

Narrow minmax15 modules/16 public roots now pass normal kernel builds and the1495-root combined audit; all1479 prior exact axiom sets and463 landed proof source hashes preserved. Bundled MCP16-root audit passes, all standard-only. Complete48 narrow source families include8 register,32 single-constant over every parameter word and8 both-constant cases. Unified8/16/32/64 original-source dispatch is proved. Receipt: docs/research/stock-minmax-narrow-integrated-checkpoint.json. Full validation remains pending: an early full build was deliberately stopped because it duplicated a live select elaboration; no full-gate pass or merge-ready claim.

Remote prevalidation snapshot agent/stock-driver-wip-backup-20261015T080507Z at29dee6266c368840e66c3c83e43d483dc95173f5 captured601 dirty paths; remote blobs verified and active HEAD/index unchanged. New select additions since this snapshot need a fresh backup.

Original select continuation now derives actual RHS650/659/output calls, source match data and unique root2267. The latter source selector is under validation. Zero/NotZero659 request/state inversion is in progress; its actual cmpXzr producer differs from the715 boolean companion cmpImm0 and needs its own semantic composition. New source consumer/witness drafts depend on successful inversion. Complete650/651 condition truth including icmp/uextend look-through, all condition shapes, retained binding/original guarded source transfer and full source witness matrix remain unfinished. Keep these related changes local for a consolidated semantic batch.

Merge discipline: zero of the maximum nine additional backlog PRs used since2026-10-15T08:03:54Z correction. Thereafter roughly three/day, up to six when justified; backups independent. No new PR or merge. #140 active/incomplete, production legacy. All remaining families/effects, source/block/whole-driver simulation/completeness and compiler/checker/linker/generated-proof integration remain; original conditions/variants/trust/accepted identities/stages and a fresh complete Stock comparison required before cutover.


Worktree: `/home/lee/clifv/.worktrees/driver-proof-resume`; recover from
[test-binary-alignment-recovery.md](test-binary-alignment-recovery.md).

The machine-readable [root inventory](../research/stock-driver-rule-inventory.json)
lists all 517 generated term686 `lower` rules with source locations and hashes.
It identifies 28 roots with guarded actual Stock record-value bridges: constants,
base add/subtract, three logical roots, scalar/shift NOT, six mirrored logical-NOT
roots and NOT-of-XOR, plus base multiplication, three multiply-add/subtract fusions, all six scalar shift roots base zero/sign extension and reduction. This is a source inventory, not a reachable-rule inventory,
a correctness proof or a completion percentage. Helper selection subcases have
separate obligations. Source/context/record guards still need internal composition.

## Next semantic batch

- Classify remaining roots against the original `LowerScope`, keeping the scope
  unchanged. Derive impossible matches from actual mapped contexts; otherwise
  prove the actual Stock request/state/emission semantics.
- Continue remaining extension/look-through,
  comparisons/selects and arithmetic/logical families.
  Reuse legacy machine lemmas and actual Stock selection/request receipts.
- Each batch must connect retained records, binding and original availability-
  restricted source transfer, with complete non-vacuity witnesses and fresh
  standard-only audits. Do not count a helper value theorem as driver completion.

## Effectful and control cases

- Prove memory loads/stores, atomics, stack/global/symbol addressing and call/try-
  call execution with the required world and memory relations.
- Prove branches, successor arguments, critical-edge moves, returns and traps;
  reservation terminality alone does not establish reserved-register values.
- Supply a deferred-effect invariant for omitted/sunk instructions and trapping
  paths. `StockScanSemantics` composes successful fall-through under local
  obligations; it does not discharge those obligations or trapping simulation.

## Driver and consumers

- Derive the local obligations under the original input conditions; compose
  source, block, node and whole-driver simulation and completeness.
- Preserve old theorem variants and integrate the actual Stock driver into
  compiler, checker, linker and generated-proof consumers.
- Before production/default changes, run the full recovery-plan gates and a
  fresh complete stock comparison, preserving accepted identities, successful
  stages and theorem trust sets. Only the completed production cutover satisfies
  #140. User authorization permits independent remote backup pushes and squash merges in substantial semantic batches: at most nine additional backlog PRs from the 2026-10-15 discipline correction, then roughly three per day, up to six.


## Generated family classification

[stock-driver-rule-families.json](../research/stock-driver-rule-families.json)
classifies every one of the517 generated term686 patterns by its first opcode,
all nested opcode terms, literal type constraints and instruction-data forms.
The source term files are hashed. This is static pattern evidence; none of its
entries is a scope-reachability or exclusion proof.

Next kernel obligations are scope-derived exclusion of unsupported opcodes and
non-scalar type literals, and actual execution/source transfer for the remaining
accepted integer arithmetic, rotations/counts/reversals, comparisons/selects,
loads/stores/atomics, addressing, calls/returns/traps. Branch roots and traversal
obligations are additional to this term686 inventory. Preserve the original
Compile.instE/LowerScope and derive exclusions from mapped source data.


## Ordinary-source root exclusions validated locally

Updated UTC: 2026-10-14T00:25:34.544757+00:00

Original mapped source scope proves372 of517 generated lower roots cannot match ordinary source instructions. Actual first-match and retained-record selection derives membership in the145 remaining closure roots internally. Exact partition counts are kernel-checked; concrete excluded-root and complete emitted-source witnesses pass. This is scope exclusion, not execution coverage; terminator/branch contexts remain separate.

All10 new roots normal/MCP standard-only;342 prior sets unchanged (352 total),0 source warnings. Full1528/crates1171/runtime4672 with0fail/0disagree and7known non-runnable; encoder1292/0; bothE2E1150/0 with full identity/stage parity. Receipt docs/research/stock-source-scope-audit.json; plan docs/plans/stock-source-scope.md. Inventory/family classification now links proof-backed ordinary-source exclusions. No legacy Cov/T6/IselLcf/optimizer interface or production changes. Next remaining closure execution/source transfer, effects/control/deferred semantics, full simulation/completeness and actual production integration/complete stock comparison. Full #140 active/incomplete; no push/merge.
