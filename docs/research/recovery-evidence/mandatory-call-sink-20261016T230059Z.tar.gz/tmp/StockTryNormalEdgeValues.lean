import StockTryNormalEntryValues
import FV.Backend.Proof.StockEdgeCode
import FV.Backend.Proof.PerEdgeVCodeSem
namespace Backend.Stock.Proof.TryNormalEdgeValuesDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Driver.Fix
open TryNormalCopiesDraft TryNormalValueColumnsDraft TryNormalEntryValuesDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private theorem actual_column_shape {result : Result} {label column : Nat} {args : Array Reg}
    {values : List Clif.Val} {rho : Nat → CV}
    (stored : (result.edgeArgs[label]?.bind fun row => row[column]?) = some args)
    (arguments : NormalColumnValues result label column values rho) :
    args = ((columnNumbers args).map (fun n => Reg.vreg n .int)).toArray := by
  obtain ⟨actual,present,length,held⟩ := arguments
  have same := Option.some.inj (present.symm.trans stored)
  subst actual
  have shape : ∀ reg ∈ args.toList, ∃ n,reg = .vreg n .int := by
    intro reg member
    obtain ⟨i,inside,equal⟩ := List.getElem_of_mem member
    have valueBound : i < values.length := by simpa only [Array.length_toList,length] using inside
    have atReg : args[i]? = some reg := by
      rw [← Array.getElem?_toList,List.getElem?_eq_getElem inside,equal]
    obtain ⟨n,register,_⟩ := held i values[i] reg (List.getElem?_eq_getElem valueBound) atReg
    exact ⟨n,register⟩
  apply Array.toList_inj.mp
  simp only [columnNumbers,List.map_map]
  symm
  calc
    _ = args.toList.map id := by
      apply List.map_congr_left
      intro reg member
      obtain ⟨n,rfl⟩ := shape reg member
      rfl
    _ = _ := List.map_id _
/-- The actual per-successor VCode edge operation performs the source normal
binding proved above. Returned target parameters and virtual source columns are
derived from whole lowering and actual column values. This applies to both
original columns and synthetic row zero; CFG selection remains a separate gate. -/
theorem stock_lower_try_normal_edge_values {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    {bi : Nat} {b : Clif.Block} (block : f.blocks[bi]? = some b)
    {fr fr' : Clif.Frame} (func : fr.func = f) {et : Clif.ExnTable} (kind : IsTryWith b.term et)
    {rvals values : List Clif.Val} {regs : Clif.Regs}
    (bound : fr.regs.setMany ((List.range rvals.length).map (f.freshValue + ·)) rvals = some regs)
    {bc : Clif.BlockCall} (normal : Clif.tryNormal et f.freshValue = .ok bc)
    (read : ({fr with regs} : Clif.Frame).getMany bc.args = .ok values)
    (entered : Clif.enterBlock {fr with regs,body := [],term := .jump bc} bc = .ok fr')
    {tl : Nat} {target : Clif.Block} (destination : f.blocks[tl]? = some target)
    (found : f.block? bc.block = some target) (index : blockIdx? f bc.block = some tl)
    {label column targetLabel : Nat} {args : Array Reg}
    (targetTag : result.order.nodes[targetLabel]? = some (.original tl)) (nonentry : tl ≠ 0)
    (stored : (result.edgeArgs[label]?.bind fun row => row[column]?) = some args)
    {rho : Nat → CV} (arguments : NormalColumnValues result label column values rho)
    (held : ValuesHeld (fun x => x ∈ availOf f (availIn f result.ctx) bi b.body.length) result.ctx fr
      (fun key => rho (aliasNum result.final.alias key))) :
    edgeEnvAt result.code result.edgeArgs label targetLabel column rho =
      some (parCopyEnv rho (edgeParamNumbers result target) (columnNumbers args)) ∧
      ValuesHeld (fun x => x ∈ availOf f (availIn f result.ctx) tl 0) result.ctx fr'
        (fun key => parCopyEnv rho (edgeParamNumbers result target) (columnNumbers args) (aliasNum result.final.alias key)) := by
  have agreement := stock_lower_try_normal_entry_values lowered scope dominated block func kind bound normal read entered
    destination found index stored arguments held
  obtain ⟨targetBlock,placed,_,parameters⟩ := stock_lower_original_block_params lowered scope dominated.ssa targetTag destination nonentry
  have shape := actual_column_shape stored arguments
  have columnLength : (columnNumbers args).length = values.length := by
    obtain ⟨actual,present,length,_⟩ := arguments
    have same := Option.some.inj (present.symm.trans stored)
    subst actual
    simpa only [columnNumbers,List.length_map,Array.length_toList] using length
  obtain ⟨source,vals,targetRegs,targetFound,actualRead,types,set,frame⟩ := enterBlock_spec entered
  change fr.func.block? bc.block = some source at targetFound
  rw [func] at targetFound
  cases Option.some.inj (targetFound.symm.trans found)
  have pendingRead : ({fr with regs,body := [],term := .jump bc} : Clif.Frame).getMany bc.args = .ok values :=
    (Clif.Frame.getMany_with {fr with regs} [] (.jump bc) bc.args).trans read
  cases Clif.Res.ok.inj (actualRead.symm.trans pendingRead)
  have targetLength := setMany_length set
  have length : (edgeParamNumbers result target).length = (columnNumbers args).length := by
    simp only [edgeParamNumbers,List.length_map]
    simp only [List.length_map] at targetLength
    omega
  refine ⟨?_,agreement⟩
  exact edgeEnvAt_eq placed (stored.trans (congrArg some shape)) parameters length rho
end Backend.Stock.Proof.TryNormalEdgeValuesDraft
