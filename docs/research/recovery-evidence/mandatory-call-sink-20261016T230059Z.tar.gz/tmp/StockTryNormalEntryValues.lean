import StockTryNormalCopies
import StockTryNormalDefined
namespace Backend.Stock.Proof.TryNormalEntryValuesDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Driver.Fix
open TryNormalCopiesDraft TryNormalValueColumnsDraft TryNormalDefinedDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
/-- The actual successful source result binding preserves ordinary machine
agreement at every originally available source ID, without a new ID bound. -/
theorem stock_try_result_bind_source_values {f : Clif.Function} {result : Result}
    {bi : Nat} {b : Clif.Block} (block : f.blocks[bi]? = some b)
    {fr : Clif.Frame} {rvals : List Clif.Val} {regs : Clif.Regs}
    (bound : fr.regs.setMany ((List.range rvals.length).map (f.freshValue + ·)) rvals = some regs)
    {rho : Nat → CV} (held : ValuesHeld (fun x => x ∈ availOf f (availIn f result.ctx) bi b.body.length)
      result.ctx fr (fun key => rho (aliasNum result.final.alias key))) (bc : Clif.BlockCall) :
    ValuesHeld (fun x => x ∈ availOf f (availIn f result.ctx) bi b.body.length) result.ctx
      {fr with regs,body := [],term := .jump bc} (fun key => rho (aliasNum result.final.alias key)) := by
  intro x available v lookup
  have preserved : regs x = fr.regs x := by
    apply setMany_other bound
    intro member
    obtain ⟨j,inside,same⟩ := List.mem_map.mp member
    have small := source_available_below_try_fresh block available
    have lower : f.freshValue ≤ x := by rw [← same]; exact Nat.le_add_right _ _
    exact (Nat.not_le_of_gt small) lower
  change regs x = some v at lookup
  rw [preserved] at lookup
  exact held x available v lookup
private theorem inherited_available {f : Clif.Function} {ctx : Ctx} {bi tl x : Nat} {b target : Clif.Block}
    (block : f.blocks[bi]? = some b) (destination : f.blocks[tl]? = some target)
    {bc : Clif.BlockCall} (edge : bc.block ∈ succIds b.term) (index : blockIdx? f bc.block = some tl)
    (available : x ∈ availOf f (availIn f ctx) tl 0) (notParameter : x ∉ target.params.map (·.1)) :
    x ∈ availOf f (availIn f ctx) bi b.body.length := by
  obtain ⟨present,_⟩ := (mem_av destination).mp available
  rcases present with parameter | incoming | ⟨j,stm,earlier,_,_⟩
  · exact (notParameter parameter).elim
  · have fixed := inFix_fixOk (f := f) (ctx := ctx) (gn := id)
    have successor : tl ∈ succIdx f bi := by
      simp only [succIdx,block]
      exact List.mem_filterMap.mpr ⟨bc.block,edge,index⟩
    refine (mem_av block).mpr ⟨?_,?_⟩
    · rcases fixed.out tl x incoming bi successor with parameter | result | inherited
      · exact .inl (by rwa [parsOf_of block] at parameter)
      · obtain ⟨original,j,stm,originalBlock,statement,result⟩ := mem_defsOf.mp result
        cases Option.some.inj (originalBlock.symm.trans block)
        exact .inr (.inr ⟨j,stm,lt_of_getElem? statement,statement,result⟩)
      · exact .inr (.inl inherited)
    · rintro ⟨j,stm,later,statement,_⟩
      have bound := lt_of_getElem? statement
      omega
  · omega
/-- Actual normal enterBlock and actual column-sourced parallel copies agree
on EVERY available destination value, including inherited non-parameters.
All copy destinations/separation and source availability are derived from the
original source conditions; synthetic source return IDs are never mapped. -/
theorem stock_lower_try_normal_entry_values {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    {bi : Nat} {b : Clif.Block} (block : f.blocks[bi]? = some b)
    {fr fr' : Clif.Frame} (func : fr.func = f) {et : Clif.ExnTable} (kind : IsTryWith b.term et)
    {rvals values : List Clif.Val} {regs : Clif.Regs}
    (bound : fr.regs.setMany ((List.range rvals.length).map (f.freshValue + ·)) rvals = some regs)
    {bc : Clif.BlockCall} (normal : Clif.tryNormal et f.freshValue = .ok bc)
    (read : ({fr with regs} : Clif.Frame).getMany bc.args = .ok values)
    (entered : Clif.enterBlock {fr with regs,body := [],term := .jump bc} bc = .ok fr')
    {tl : Nat} {target : Clif.Block} (destination : f.blocks[tl]? = some target)
    (found : f.block? bc.block = some target) (index : blockIdx? f bc.block = some tl)
    {label column : Nat} {args : Array Reg}
    (stored : (result.edgeArgs[label]?.bind fun row => row[column]?) = some args)
    {rho : Nat → CV} (arguments : NormalColumnValues result label column values rho)
    (held : ValuesHeld (fun x => x ∈ availOf f (availIn f result.ctx) bi b.body.length) result.ctx fr
      (fun key => rho (aliasNum result.final.alias key))) :
    ValuesHeld (fun x => x ∈ availOf f (availIn f result.ctx) tl 0) result.ctx fr'
      (fun key => parCopyEnv rho (edgeParamNumbers result target) (columnNumbers args) (aliasNum result.final.alias key)) := by
  have pending := stock_try_result_bind_source_values block bound held bc
  have edge : bc.block ∈ succIds b.term := by
    have bcEq := tryNormal_ok normal
    rw [bcEq]
    rcases kind with ⟨fn,args,term⟩ | ⟨callee,args,term⟩ <;> rw [term] <;> simp [succIds,Clif.ExnTable.dests]
  have inherited : ValuesHeld
      (fun x => x ∈ availOf f (availIn f result.ctx) tl 0 ∧ x ∉ target.params.map (·.1)) result.ctx
      {fr with regs,body := [],term := .jump bc} (fun key => rho (aliasNum result.final.alias key)) := by
    intro x need
    exact pending x (inherited_available block destination edge index need.1 need.2)
  exact stock_lower_normal_column_copies lowered scope dominated destination
    (show ({fr with regs,body := [],term := .jump bc} : Clif.Frame).func = f from func) found entered
    ((Clif.Frame.getMany_with {fr with regs} [] (.jump bc) bc.args).trans read) stored arguments
    (fun _ member => member) inherited
end Backend.Stock.Proof.TryNormalEntryValuesDraft
