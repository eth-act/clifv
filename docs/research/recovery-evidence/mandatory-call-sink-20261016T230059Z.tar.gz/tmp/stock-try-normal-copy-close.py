from pathlib import Path
import json,hashlib,re,datetime,tarfile,shutil,subprocess
root=Path('/home/lee/clifv/.worktrees/driver-proof-resume');docs=root/'docs/research';prefix='stock-try-normal-copy'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
now=datetime.datetime.now(datetime.timezone.utc);stamp=now.strftime('%Y%m%dT%H%M%SZ')
batch=json.loads(Path('/tmp/'+prefix+'-batch.json').read_text());old=json.loads((docs/'stock-try-normal-values-scratch.json').read_text())
log=Path('/tmp/'+prefix+'-combined-axioms.log').read_text()
sets={m.group(1):sorted(x.strip() for x in m.group(2).split(',') if x.strip()) for m in re.finditer(r"'([^']+)' depends on axioms:\s*\[([^]]*)\]",log)}
for m in re.finditer(r"'([^']+)' does not depend on any axioms",log):sets[m.group(1)]=[]
for n,a in old['normal_audit']['sets'].items():assert sorted(a)==sets[n],n
assert len(sets)==len(old['normal_audit']['sets'])+len(batch['public_roots'])+len(batch['models'])
allowed={'propext','Classical.choice','Quot.sound'}
for n in batch['public_roots']+batch['models']:assert set(sets[n])<=allowed,n
constants=[json.loads(line.split('DELIVERY_CONSTANT ',1)[1]) for line in Path('/tmp/'+prefix+'-all-constants.log').read_text().splitlines() if line.startswith('DELIVERY_CONSTANT ')]
assert constants
for n,a in constants:assert set(a)<=allowed,n
mods={}
for m in batch['modules']:
 p=Path('/tmp')/m;check=json.loads(p.with_suffix('.check.json').read_text());assert check['actual_exit']==0
 rec={}
 for key,ext in [('source','.lean'),('object','.olean'),('log','.log'),('check','.check.json')]:
  f=p.with_suffix(ext);rec[key]=str(f);rec[key+'_sha256']=sha(f)
 for k in ['source','object','log']:assert rec[k+'_sha256']==check[k+'_sha256']
 assert not re.search(r'\b(sorry|admit|axiom|trace_state|native_decide)\b',p.with_suffix('.lean').read_text()),m
 mods[m]=rec
for audit in [prefix+'-combined-axioms',prefix+'-all-constants']:
 p=Path('/tmp')/audit;check=json.loads(p.with_suffix('.check.json').read_text());assert check['actual_exit']==0
 for k,ext in [('source','.lean'),('object','.olean'),('log','.log')]:assert sha(p.with_suffix(ext))==check[k+'_sha256']
prior={}
for name in ['source-execution-x','try-source','try-context','try-rule','try-rets','try-reservation','try-outgoing','try-values','try-emitted','try-machine','try-got','try-indirect','try-rename','try-resolved','try-gap','try-got-rename','try-normal-frame','try-metadata','source-index','try-normal-vector','try-critical-normal','source-erase','source-origin','try-live-frame','try-normal-values']:
 d=json.loads((docs/f'stock-{name}-scratch.json').read_text())
 for m,rec in d['modules'].items():
  for k in ['source','object','log']:assert sha(rec[k])==rec[k+'_sha256'],(m,k)
  prior[m]=rec
assert len(prior)==162
freeze=json.loads(Path('/tmp/stock-coherent-build-inputs.json').read_text())
for group in ['source_sha256','validation_script_sha256']:
 for p,h in freeze[group].items():assert sha(root/p)==h,p
imports=json.loads(Path('/tmp/stock-try-rule-inputs.json').read_text())
for m,r in imports['modules'].items():
 assert sha(r['snapshot'])==r['object_sha256'],(m,'snapshot')
 assert sha(r['source'])==r['source_sha256'],(m,'source')
refresh=json.loads(Path('/tmp/'+prefix+'-import-refresh.json').read_text())
assert len(refresh['modules'])==7
for m,r in refresh['modules'].items():
 p=Path('/tmp/'+prefix+'-canonical')/(m.replace('.','/')+'.lean')
 assert r['actual_exit']==0 and r['canonical_source_unchanged']
 for k,ext in [('source','.lean'),('object','.olean'),('log','.log')]:assert sha(p.with_suffix(ext))==r[k+'_sha256']
progress=json.loads(Path('/tmp/stock-pr246-gates-progress.json').read_text());progress.pop('completed_phases',None)
subprocess.run(['ps','-p','3247835','-o','pid,stat,etime,args'],check=True)
remaining=list(old['remaining_checklist'])
remaining.append({'requirement':'Actual normal outgoing values through source enterBlock and actual VCode per-successor copies','state':'Kernel proved stored column numeric shape, original-source result-bind preservation, destination parameter binding and ALL inherited available values, with separation/uniqueness derived from original scope/SSA/dominance. The actual returned VCode target params and edgeEnvAt perform those copies; original near/GOT/true-indirect complete compiler/checker/fallback/physical/memory/callee/source witnesses include actual edgeEnvAt and all destination agreement. Generic copy/edge lemma applies to original stored columns and synthetic row0; complete critical machine/value witnesses remain pending. Actual normal control-index/CFG selection, VNextAt/VStepAt and prepared execution/source continuation/whole-driver composition still OPEN.'})
counts={'modules':len(mods),'public_roots':len(batch['public_roots']),'models':len(batch['models']),'combined_roots_models':len(sets),'previous_preserved':len(old['normal_audit']['sets']),'all_new_module_constants':len(constants),'previous_modules_hashes_preserved':len(prior)}
receipt={'utc':now.isoformat(),'goal':'Original full #140 ACTIVE/INCOMPLETE; production LEGACY','scope':'Additive scratch Stock proofs; coherent integration and full gates remain pending','delivery_target':'roughly eight substantive validated squash merges/day; semantic grouping, backup and cleanup','modules':mods,'public_roots':batch['public_roots'],'models':batch['models'],'counts':counts,'normal_audit':{'path':'/tmp/'+prefix+'-combined-axioms.log','sha256':sha('/tmp/'+prefix+'-combined-axioms.log'),'sets':sets},'all_constant_audit':{'path':'/tmp/'+prefix+'-all-constants.log','sha256':sha('/tmp/'+prefix+'-all-constants.log'),'all_standard_only':True,'count':len(constants)},'previous_modules_hashes_preserved':list(prior),'canonical2246_source_and_script_freeze_preserved':True,'import_generation':{'source_and_snapshot_hashes_checked':len(imports['modules']),'refresh':refresh,'previous_import_manifest':'/tmp/'+prefix+'-imports-before.json','new_import_manifest':'/tmp/stock-try-rule-inputs.json','shared_cache_writes':False,'note':'Live exact-PR worker replaced seven objects; rebuilt SAME frozen canonical sources into isolated unique objects, including additive canonical ReturnSourceWitness roots. All680 prior public/model exact axiom sets still match on refreshed imports.'},'nonvacuity':{'original_near_GOT_indirect':'COMPLETE compiler/prepare/checkedfallback/checker/physical/source and actual stored values + actual edgeEnvAt parameter/inherited agreement','critical_machine_value':'PENDING; ordinary8GiB failures preserved, larger kernel queued AFTER live heavy delivery gate'},'MCP':'Deferred until coherent integration; no new calls','active_exact_PR246_validation':progress,'remaining_checklist':remaining}
(docs/(prefix+'-scratch.json')).write_text(json.dumps(receipt,indent=2)+'\n')
text=f'''Actual normal source entry and per-successor VCode copies — {now.isoformat()}

{len(mods)} scratch modules/{len(batch['public_roots'])} public roots/{len(batch['models'])} model pass actual 8 GiB kernel checks. Cumulative audit: {len(sets)} roots/models, all 680 prior exact axiom sets preserved. All {len(constants)} new-module constants, including private shape, inherited-availability, mapping and non-vacuity helpers, use only standard axioms. All 162 prior scratch source/object/log hashes and frozen 2246 canonical source/49 script hashes remain unchanged.

Actual source result binding preserves agreement at EVERY originally available source ID. Actual successful normal enterBlock then agrees with copies from the ACTUAL stored outgoing register column, including synthetic fresh source return IDs that have no original context mapping. Destination uniqueness, parameter mappings and inherited-source separation are derived from original LowerScope/SSA/Dominated; no new source input filter or caller register/disjointness certificate. The result covers ALL destination-available values, including inherited nonparameters.

The VCode edge proof derives the actual returned destination block parameters from whole lowering and normalizes the actual column using its value relation. The actual per-successor edgeEnvAt operation produces the SAME parallel-copy environment that holds every destination source value. This is usable with original columns or synthetic row zero. COMPLETE original near/GOT/true-indirect witnesses include actual source enterBlock, exact stored column values, actual edgeEnvAt, destination agreement, original compiler/prepare/forced checkedfallback/checker/physical stages, memory/callee contracts and full source return17. Near/indirect use mixed17/9, the actual nine-argument GOT16byte fixture uses its existing one-element17 column. Older theorem variants remain unchanged.

The live exact-PR cache advanced during import restoration. Hash checks caught seven changed imported objects. All seven were rebuilt successfully from the SAME frozen canonical sources into unique isolated artifacts; no shared cache writes or unchecked version substitution. Six sources are byte-identical to the delivery view; canonical ReturnSourceWitness retains additive roots required by saved source proofs. All1049 imported source/snapshot hashes and all680 prior exact public/model axiom sets pass after rebuilding. Keep these seven unique source/object/log/check artifacts and both import manifests for recovery; remove only the duplicate temporary snapshot after archive byte verification.

Still OPEN: actual normal control-index/CFG selection and VNextAt/VStepAt, prepared execution/source continuation and whole-driver composition. COMPLETE critical machine/value non-vacuity remains pending after preserved ordinary8GiB failures; one larger kernel waits for the active heavy delivery lane. Prior critical consumers and generic copy support are not substitutes for complete critical witnesses. Shared payload/exception semantics, full zero-return/sret/x8/width/handler/Try-critical matrix, uncovered families/effects/sinking, source/block/whole-driver simulation AND completeness, original-input context/static/visitor/checker/fallback/physical totality, coherent integration/public/private/compiler/MCP/full build/crates/runtime/encoder/BOTH E2E identity-stage parity, actual production compiler/checker/linker/generated consumers and FRESH COMPLETE comparison all remain mandatory. Full #140 ACTIVE/INCOMPLETE; production LEGACY.

Delivery #246 same live supervisor3247835 is at {progress.get('index')}/{progress.get('total')}; canonical1233457 remains deliberately held under the exclusive single-cache lease. Both draft246/247 CI checks passed when freshly inspected. Current-main reconciliation and ALL actual integrated-head gates remain required before squash246→247. Roughly8 substantive validated merges/day remains the delivery target; no quota-driven tiny slices or gate waiver. Contributor52/71/task140 reread; shared Kev S10/FP/Link boundaries preserved. No merge/new worktree/agent/MCP/heavy retry/gate restart or other-project cleanup.

Next: tie actual normal stopped-call control index and actual Stock CFG to these value-correct copies, then source/whole-driver continuation; finish critical full witnesses when the heavy lane frees. Hashed evidence and full remaining checklist: stock-try-normal-copy-scratch.json.
'''
(docs/(prefix+'-scratch.md')).write_text(text)
plan=root/'docs/plans/test-binary-alignment-recovery.md';plan.write_text(plan.read_text()+'\n\n'+text)
files=[]
for rec in mods.values():files.extend(Path(rec[k]) for k in ['source','object','log','check'])
for name in [prefix+'-combined-axioms',prefix+'-all-constants']:
 for ext in ['.lean','.log','.olean','.check.json']:files.append(Path('/tmp')/(name+ext))
for name in [prefix+'-batch.json','stock-try-rule-inputs.json','stock-try-reservation-check.py',prefix+'-close.py',prefix+'-make-audit.py',prefix+'-status44-start.md',prefix+'-status44-current.md',prefix+'-status52.json',prefix+'-status71.json',prefix+'-task140.json',prefix+'-issues.json',prefix+'-refresh-imports.py',prefix+'-import-refresh.json',prefix+'-imports-before.json','stock-merge-eight-status44-before.md','stock-merge-eight-status44.md']:
 p=Path('/tmp')/name
 if p.exists():files.append(p)
for p in Path('/tmp/'+prefix+'-canonical').rglob('*'):
 if p.is_file():files.append(p)
for p in Path('/tmp/'+prefix+'-before-vcode').rglob('*'):
 if p.is_file():files.append(p)
files.extend([docs/(prefix+'-scratch.json'),docs/(prefix+'-scratch.md'),docs/'stock-delivery-main-drift.json',plan])
files=list(dict.fromkeys(files))
archive=Path('/home/lee/.clifv-recovery')/(stamp+'-try-normal-copy')/'checkpoint.tar.gz';archive.parent.mkdir(parents=True)
with tarfile.open(archive,'w:gz',compresslevel=1) as t:
 for p in files:t.add(p,arcname=str(p).lstrip('/'),recursive=False)
with tarfile.open(archive,'r:gz') as t:
 for p in files:assert t.extractfile(str(p).lstrip('/')).read()==p.read_bytes(),p
snapshot=Path('/tmp/stock-try-rule-inputs');size=sum(p.stat().st_size for p in snapshot.rglob('*') if p.is_file());shutil.rmtree(snapshot)
backup={'utc':now.isoformat(),'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(files),'all_members_byte_verified':True,'previous_remote_backup':json.loads((docs/'stock-try-normal-values-backup.json').read_text())['remote'],'cleanup':{'duplicate_dependency_snapshot_removed':True,'bytes_reclaimed':size,'unique_sources_objects_logs_checks_audits_import_repairs_preserved':True,'one_shared_warm_cache_retained':True,'other_projects_touched':False,'free_bytes':shutil.disk_usage(root).free}}
(docs/(prefix+'-backup.json')).write_text(json.dumps(backup,indent=2)+'\n');Path('/tmp/'+prefix+'-archive-path').write_text(str(archive))
print(json.dumps({'counts':counts,'archive':str(archive),'cleanup':backup['cleanup'],'gate':progress},indent=2))
