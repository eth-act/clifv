from pathlib import Path
import json,hashlib,subprocess as sp,os,datetime,re,shutil
root=Path('/home/lee/clifv/.worktrees/driver-proof-resume');manifest=Path('/tmp/stock-try-rule-inputs.json');old=json.loads(manifest.read_text());before=Path('/tmp/stock-try-normal-copy-imports-before.json');before.write_text(json.dumps(old,indent=2)+'\n');records=old['modules'];scratch=Path('/tmp/stock-try-normal-copy-canonical');changed={};sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for m,r in records.items():
 dst=Path(r['snapshot']);src=Path(r['object'])
 if dst.exists() and sha(dst)==r['object_sha256']:continue
 data=src.read_bytes()
 if hashlib.sha256(data).hexdigest()!=r['object_sha256']:changed[m]=r;continue
 dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(data)
assert changed
imports={m:[d for line in re.findall(r'^import\s+([^\n]+)',Path(r['source']).read_text(),re.M) for d in line.split() if d in changed] for m,r in changed.items()};order=[];seen=set()
def visit(m):
 if m in seen:return
 seen.add(m)
 for d in imports[m]:visit(d)
 order.append(m)
for m in changed:visit(m)
env=dict(os.environ,OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',FV_MEMCAP='8G',LEAN_PATH='/tmp/stock-try-rule-inputs:/tmp')
results={}
for m in order:
 r=changed[m];src=Path(r['source']);assert sha(src)==r['source_sha256'],m
 p=scratch/(m.replace('.','/')+'.lean');p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(src.read_bytes());obj=p.with_suffix('.olean');log=p.with_suffix('.log')
 with log.open('w') as out:run=sp.run([str(root/'scripts/memcap.sh'),'/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin/lean','--root='+str(scratch),str(p),'-o',str(obj)],cwd=root,env=env,stdout=out,stderr=sp.STDOUT)
 check={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actual_exit':run.returncode,'module':m,'source_sha256':sha(p),'object_sha256':sha(obj) if obj.exists() else None,'log_sha256':sha(log),'canonical_source_unchanged':sha(src)==r['source_sha256'],'old_expected_object_sha256':r['object_sha256']};p.with_suffix('.check.json').write_text(json.dumps(check,indent=2)+'\n');print(m,'ACTUAL_RC',run.returncode,flush=True)
 if run.returncode:print(log.read_text()[-6000:],flush=True);raise SystemExit(run.returncode)
 assert check['canonical_source_unchanged'];dst=Path(r['snapshot']);dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(obj.read_bytes());r.update(object=str(obj),object_sha256=check['object_sha256'],bytes=obj.stat().st_size,canonical_rebuild_check=str(p.with_suffix('.check.json')));results[m]=check
old.update(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),modules=records,refresh={'reason':'Shared exact delivery cache advanced; rebuild changed objects from SAME frozen canonical sources, no shared cache writes','modules':results,'before_manifest':str(before)})
manifest.write_text(json.dumps(old,indent=2)+'\n');Path('/tmp/stock-try-normal-copy-import-refresh.json').write_text(json.dumps(old['refresh'],indent=2)+'\n');print('sealed imported objects',len(records),'rebuilt',len(results),flush=True)
