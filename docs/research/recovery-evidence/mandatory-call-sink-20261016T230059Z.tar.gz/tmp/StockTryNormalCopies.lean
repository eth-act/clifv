import StockTryNormalValueColumns
import FV.Backend.Proof.StockEdgeValues
namespace Backend.Stock.Proof.TryNormalCopiesDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Driver.Fix
open TryNormalValueColumnsDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
/-- Numeric sources of the ACTUAL returned column. Its value relation proves
all entries are integer virtual registers before these numbers are used. -/
def columnNumbers (regs : Array Reg) : List Nat := regs.toList.map fun
  | .vreg n .int => n
  | _ => 0
private theorem column_values {result : Result} {label column : Nat} {values : List Clif.Val} {rho : Nat → CV}
    (held : NormalColumnValues result label column values rho) {args : Array Reg}
    (stored : (result.edgeArgs[label]?.bind fun row => row[column]?) = some args) :
    (columnNumbers args).length = values.length ∧
      ∀ (i : Nat) (v : Clif.Val) (n : Nat),values[i]? = some v → (columnNumbers args)[i]? = some n → VHolds v (rho n) := by
  obtain ⟨regs,actual,length,held⟩ := held
  have same := Option.some.inj (actual.symm.trans stored)
  subst regs
  refine ⟨by simpa only [columnNumbers,List.length_map,Array.length_toList] using length,?_⟩
  intro i v n atValue atNumber
  simp only [columnNumbers,List.getElem?_map] at atNumber
  cases atReg : args.toList[i]? with
  | none => rw [atReg] at atNumber; cases atNumber
  | some r =>
    have arrayAt : args[i]? = some r := by simpa only [Array.getElem?_toList] using atReg
    obtain ⟨key,equal,value⟩ := held i v r atValue arrayAt
    subst r
    rw [atReg] at atNumber
    simp only [Option.map_some,Option.some.injEq] at atNumber
    subst n
    exact value
private theorem number_eq {ctx : Ctx} {x n : Nat} (mapped : ctx.valueReg? x = some (.vreg n .int)) :
    edgeValueNum ctx x = n := by simp only [edgeValueNum,mapped]

private theorem built_context {f : Clif.Function} {result : Result} (run : Stock.lower f = .ok result) :
    ∃ ranges,Stock.buildCtx f = .ok (result.ctx,ranges,result.initial) := by
  unfold Stock.lower at run
  dsimp only at run
  repeat' first
    | (solve | cases run)
    | simp only [bind,Except.bind,pure,Except.pure] at run
    | split at run
  cases run
  exact ⟨_,by assumption⟩

private theorem parameter_mapped {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (ssa : (valueDefs f).Nodup)
    {tl : Nat} {b : Clif.Block} (block : f.blocks[tl]? = some b) {x : Nat}
    (parameter : x ∈ b.params.map (·.1)) : ∃ key,result.ctx.valueReg? x = some (.vreg key .int) := by
  obtain ⟨ranges,build⟩ := built_context run
  obtain ⟨original,st0,sourceBuild,spec,view⟩ := buildCtx_source build
  obtain ⟨q,member,rfl⟩ := List.mem_map.mp parameter
  have old := (spec.facts.types ssa).2 b (List.mem_of_getElem? block) q member
  have typed : result.ctx.valueType? q.1 = some (CTy.ofClif q.2) := by
    simpa only [Ctx.valueType?,view.valTy] using old
  exact (buildCtx_mappedInv scope build).typedReg q.1 _ typed

private theorem destinations_nodup {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (ssa : (valueDefs f).Nodup)
    {tl : Nat} {b : Clif.Block} (block : f.blocks[tl]? = some b) : (edgeParamNumbers result b).Nodup := by
  obtain ⟨ranges,build⟩ := built_context run
  have original := (List.nodup_append.mp (block_nodup ssa block)).1
  change List.Pairwise (fun a b : Nat => a ≠ b)
    ((b.params.map (·.1)).map (fun x => aliasNum result.final.alias (edgeValueNum result.ctx x)))
  rw [List.pairwise_map]
  apply List.Pairwise.imp_of_mem ?_ original
  intro x y hx hy different equal
  obtain ⟨nx,mx⟩ := parameter_mapped run scope ssa block hx
  obtain ⟨ny,my⟩ := parameter_mapped run scope ssa block hy
  rw [number_eq mx,number_eq my,stock_lower_parameter_resolves run ssa block hx mx,
    stock_lower_parameter_resolves run ssa block hy my] at equal
  subst ny
  exact different ((buildCtx_allocated build).2.1 x y nx mx my)

/-- Successful source enterBlock agrees with copies sourced from its ACTUAL
normal column, including returned fresh IDs that have no original context map.
Original scope/SSA/dominance derive destination uniqueness and inherited-value
separation; no caller map/disjointness certificate is used. -/
theorem stock_lower_normal_column_copies {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    {tl : Nat} {b : Clif.Block} (block : f.blocks[tl]? = some b)
    {fr fr' : Clif.Frame} (func : fr.func = f) {bc : Clif.BlockCall}
    (target : f.block? bc.block = some b) (entered : Clif.enterBlock fr bc = .ok fr')
    {values : List Clif.Val} (read : fr.getMany bc.args = .ok values)
    {label column : Nat} {args : Array Reg}
    (stored : (result.edgeArgs[label]?.bind fun row => row[column]?) = some args)
    {rho : Nat → CV} (arguments : NormalColumnValues result label column values rho)
    {needed : Nat → Prop} (available : ∀ x,needed x → x ∈ availOf f (availIn f result.ctx) tl 0)
    (inherited : ValuesHeld (fun x => needed x ∧ x ∉ b.params.map (·.1)) result.ctx fr
      (fun key => rho (aliasNum result.final.alias key))) :
    ValuesHeld needed result.ctx fr' (fun key => parCopyEnv rho (edgeParamNumbers result b)
      (columnNumbers args) (aliasNum result.final.alias key)) := by
  obtain ⟨original,vals,regs,found,actualRead,types,set,frame⟩ := enterBlock_spec entered
  rw [func] at found
  cases Option.some.inj (found.symm.trans target)
  cases Clif.Res.ok.inj (actualRead.symm.trans read)
  have parameterNodup := (List.nodup_append.mp (block_nodup dominated.ssa block)).1
  have copyNodup := destinations_nodup run scope dominated.ssa block
  have sourceValues := column_values arguments stored
  have targetLength := setMany_length set
  have copyLength : (edgeParamNumbers result b).length = (columnNumbers args).length := by
    simp only [edgeParamNumbers,List.length_map]
    simp only [List.length_map] at targetLength
    omega
  intro x need value lookup
  have actual : regs x = some value := by simpa only [frame] using lookup
  by_cases parameter : x ∈ b.params.map (·.1)
  · obtain ⟨m,v,pm,vm,bound⟩ := setMany_mem set parameterNodup x parameter
    have same := Option.some.inj (bound.symm.trans actual)
    subst v
    have mBound : m < (columnNumbers args).length := by
      have present := (List.getElem?_eq_some_iff.mp pm).1
      simp only [List.length_map] at present
      have length := copyLength
      simp only [edgeParamNumbers,List.length_map] at length
      omega
    let sourceNum := (columnNumbers args)[m]
    have sourceAt : (columnNumbers args)[m]? = some sourceNum := List.getElem?_eq_getElem mBound
    have sourceHeld := sourceValues.2 m value sourceNum vm sourceAt
    obtain ⟨key,mapped⟩ := parameter_mapped run scope dominated.ssa block parameter
    refine ⟨key,mapped,?_⟩
    have destinationAt : (edgeParamNumbers result b)[m]? = some (aliasNum result.final.alias key) := by
      simp only [edgeParamNumbers,List.getElem?_map,pm,Option.map_some,number_eq mapped]
    dsimp only
    rw [parCopyEnv_param (ρ := rho) copyNodup copyLength m destinationAt sourceAt]
    exact sourceHeld
  · have before : fr.regs x = some value := by
      rw [setMany_other set parameter] at actual
      exact actual
    obtain ⟨key,mapped,sourceHeld⟩ := inherited x ⟨need,parameter⟩ value before
    refine ⟨key,mapped,?_⟩
    have outside : aliasNum result.final.alias key ∉ edgeParamNumbers result b := by
      intro member
      obtain ⟨y,yp,equals⟩ := List.mem_map.mp member
      obtain ⟨parameterKey,targetMapped⟩ := parameter_mapped run scope dominated.ssa block yp
      have apart := stock_lower_entry_alias_apart run scope dominated block (available x need) parameter mapped yp targetMapped
      apply apart
      rw [number_eq targetMapped] at equals
      exact equals.symm
    dsimp only
    rw [parCopyEnv_other (ρ := rho) outside]
    exact sourceHeld
end Backend.Stock.Proof.TryNormalCopiesDraft
