import FV.E2E.ABIReadOnlyMachine
import FV.Backend.Proof.IselCmpRun

namespace E2E.MixedFlagBoundary
open Backend Backend.Proof Backend.Proof.Driver Backend.DeadCleanup
set_option autoImplicit false
set_option Elab.async false

/-- Additional forms actually used by parameter-conditioned scalar select.
This classifier does not change the dead-code-removal whitelist. -/
def extra : MInst → Bool
  | .aluRRR .subS _ .xzr (.vreg _ .int) .xzr => true
  | .csel (.vreg _ .int) (.vreg _ .int) (.vreg _ .int) _ => true
  | _ => false

/-- Executable facts expose only concrete instruction shapes. -/
theorem extra_cases {i : MInst} (checked : extra i = true) :
    (∃ sz n, i = .aluRRR .subS sz .xzr (.vreg n .int) .xzr) ∨
    (∃ d n m c, i = .csel (.vreg d .int) (.vreg n .int) (.vreg m .int) c) := by
  cases i with
  | aluRRR op sz rd rn rm =>
    cases op <;> try cases checked
    cases rd <;> try cases checked
    cases rn <;> try cases checked
    case vreg n cls =>
      cases cls <;> try cases checked
      cases rm <;> try cases checked
      exact .inl ⟨sz,n,rfl⟩
  | csel rd rn rm c =>
    cases rd <;> try cases checked
    case vreg d cls =>
      cases cls <;> try cases checked
      cases rn <;> try cases checked
      case vreg n cls =>
        cases cls <;> try cases checked
        cases rm <;> try cases checked
        case vreg m cls =>
          cases cls <;> try cases checked
          exact .inr ⟨d,n,m,c,rfl⟩
  | _ => cases checked

private theorem no_mem {i : MInst} (checked : extra i = true) : i.isMemAcc = false := by
  rcases extra_cases checked with ⟨sz,n,rfl⟩ | ⟨d,n,m,c,rfl⟩ <;> rfl

private theorem spec_eq {i : MInst} (checked : extra i = true) (sb : Nat)
    (us : List CV) (w : Arm.ArmState) : mspec sb i us w = ispec i us w := by
  rcases extra_cases checked with ⟨sz,n,rfl⟩ | ⟨d,n,m,c,rfl⟩ <;> rfl

/-- Extra select forms may change NZCV, while preserving the full memory and
all non-flag world fields required by the source memory relation. -/
theorem step_frame {i : MInst} (checked : extra i = true) {sb : Nat}
    {us outs : List CV} {w t : Arm.ArmState} {ctl : Ctl}
    (run : mspec sb i us w = some (outs,t,ctl)) :
    SameWorldNF (fun _ => False) t w ∧ ctl = .next := by
  rw [spec_eq checked] at run
  rcases extra_cases checked with ⟨sz,n,rfl⟩ | ⟨d,n,m,c,rfl⟩
  · cases us with
    | nil => cases run
    | cons a rest =>
      cases rest with
      | cons b tail =>
        cases tail with
        | cons c rest => simp [ispec] at run
        | nil =>
          simp only [ispec,Option.some.injEq,Prod.mk.injEq] at run
          obtain ⟨rfl,rfl,rfl⟩ := run
          exact ⟨SameWorldNF.write_pstate _ _ _,rfl⟩
      | nil =>
        simp only [ispec,Option.some.injEq,Prod.mk.injEq] at run
        obtain ⟨rfl,rfl,rfl⟩ := run
        exact ⟨SameWorldNF.write_pstate _ _ _,rfl⟩
  · cases us with
    | nil => cases run
    | cons a rest =>
      cases rest with
      | nil => cases run
      | cons b tail =>
        cases tail with
        | cons c rest => cases run
        | nil =>
          simp only [ispec,Option.some.injEq,Prod.mk.injEq] at run
          obtain ⟨rfl,rfl,rfl⟩ := run
          exact ⟨SameWorld.nf (SameWorld.refl _ _),rfl⟩

/-- Equal virtual operands on related worlds produce equal values/control and
related successor worlds, including the newly computed flags. -/
theorem step_transport {i : MInst} (checked : extra i = true) {sb : Nat}
    {Z : BitVec 64 → Prop} {w w' : Arm.ArmState} (worlds : SameWorld Z w w')
    {us outs : List CV} {t : Arm.ArmState} {ctl : Ctl}
    (run : mspec sb i us w = some (outs,t,ctl)) :
    ∃ t', mspec sb i us w' = some (outs,t',ctl) ∧ SameWorld Z t t' :=
  mspec_lockstep (no_mem checked) worlds run

/-- Realize the flag-threaded specification through the existing shipped
value semantics, retaining identical outputs and flags on related worlds. -/
theorem step_realize {i : MInst} (checked : extra i = true)
    {F : BitVec 64 → Prop} {ctx : FnCtx} {X : ExtSem}
    {us outs : List CV} {w w' t : Arm.ArmState} {ctl : Ctl}
    (worlds : SameWorld F w' w)
    (run : mspec ctx.slotBase i us w = some (outs,t,ctl)) :
    ∃ t', valueSem F ctx X i us w' = some (outs,t',ctl) ∧ SameWorld F t' t := by
  obtain ⟨spec,executed,related⟩ := step_transport checked worlds.symm run
  rw [spec_eq checked] at executed
  obtain ⟨actual,realized,related'⟩ := refines_valueSem F ctx X i us w' outs spec executed
  exact ⟨actual,realized,related'.trans related.symm⟩

/-- A real compare step and dependent conditional select preserve the flag
thread; both outcomes are covered for arbitrary words and caller state. -/
theorem compare_select_witness (sz : OperandSize) (a x y : CV) (w : Arm.ArmState) :
    ∃ t,
      mspec 0 (.aluRRR .subS sz .xzr (.vreg 0 .int) .xzr) [a] w = some ([],t,.next) ∧
      mspec 0 (.csel (.vreg 3 .int) (.vreg 1 .int) (.vreg 2 .int) .ne) [x,y] t =
        some ([ofX (if Arm.ConditionHolds Cond.ne.bits t then lo64 x else lo64 y)],t,.next) := by
  exact ⟨_,rfl,rfl⟩

end E2E.MixedFlagBoundary
