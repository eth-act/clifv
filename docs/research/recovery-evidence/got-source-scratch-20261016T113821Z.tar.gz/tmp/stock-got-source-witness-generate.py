from pathlib import Path
s=Path('/tmp/StockCallRecordSourceWitness.lean').read_text().replace('import StockCallResolvedSource','import StockGotResolvedSource\nimport StockGotCallWitness').replace('CallRecordSourceWitnessDraft','GotSourceWitnessDraft')
s=s.replace('open CallStaticFixture ExplicitCallWitnessDraft ExplicitCallSemDraft CallStoreSemDraft CallRecordSourceDraft CallRecordFootprintDraft CallResolvedSourceDraft','open CallStaticFixture (signature arguments calleeName callStatement)\nopen GotCallFixture ExplicitCallWitnessDraft ExplicitCallSemDraft GotStoreSemDraft GotRecordCodeDraft GotRecordFootprintDraft GotResolvedSourceDraft GotCallWitnessDraft')
s=s.replace('(function false implicit)','(function implicit)').replace('func := function false implicit','func := function implicit').replace('fr.func = function false implicit','fr.func = function implicit').replace('Facts false implicit out','Facts implicit out').replace('colocated := true','colocated := false').replace('stock_complete_direct_call_source_record_witness','stock_complete_got_call_source_record_witness').replace('stock_lower_direct_call_guarded_source_run','stock_lower_got_call_guarded_source_run')
s=s.replace('simp only [function,List.mem_singleton] at block','simp only [function,CallStaticFixture.function,List.mem_singleton] at block')
a=s.index('  obtain ⟨out,event,record,info,step,call,');b=s.index('  obtain ⟨b,j,stm,block,statement,current,inst⟩',a)
s=s[:a]+'''  obtain ⟨out,event,record,info,step,scope,dominated,arity,abi,lowered,prepared,fallback,checked,physical,
    facts,events,records,slot,clif,recorded,emitted,protocol,emission,placed⟩ :=
    stock_complete_got_call_emission_witness implicit
  have external : XCallsOk (sourceEnv false implicit) ((function implicit).externs.map (·.2)) (fun _ _ _ => True) (model implicit) :=
    xcalls implicit
  obtain ⟨ns,locs,bytes,stackBytes,target,mapping,byteRun,locations,targetEq,code⟩ := stock_lower_got_call_record_code
    lowered scope dominated.ssa abi events records slot clif
    (show (function implicit).extern? 0 = some {name := calleeName,sig := signature false implicit,colocated := false} from rfl)
    rfl recorded emitted
''' +s[b:]
a=s.index('    · have mapped : event.ctx.valueReg? x');b=s.index('      have same : v =',a)
s=s[:a]+'''    · obtain ⟨r,map⟩ := domain event.ctx.valueReg? (arguments false implicit) mapping x present
      obtain ⟨n,rfl⟩ := (stock_lower_record_context lowered scope events).1.valueReg x r map
''' +s[b:]
s=s.replace('exact ⟨192+x,mapped,rfl⟩','exact ⟨n,map,rfl⟩')
a=s.index('private theorem set_exists')
extra=Path('/tmp/StockExplicitCallWitness.lean').read_text();extra=extra[extra.index('private theorem held '):extra.index('private theorem xind ')]
extra=extra.replace('private theorem xcalls (indirect implicit : Bool) (ext : Clif.ExtFunc)\n    (sig : ext.sig = signature indirect implicit) :\n    XCallsOk (sourceEnv indirect implicit) [ext] (fun _ _ _ => True) (model implicit) := by','private theorem xcalls (implicit : Bool) :\n    XCallsOk (sourceEnv false implicit) ((function implicit).externs.map (·.2)) (fun _ _ _ => True) (model implicit) := by')
extra=extra.replace('  simp only [List.mem_singleton] at member\n  subst e','  change e ∈ [{name := calleeName,sig := signature false implicit,colocated := false}] at member\n  have same := List.mem_singleton.mp member\n  subst e').replace('(by rw [sig]; cases indirect <;> cases implicit <;> rfl)','(by cases implicit <;> rfl)')
domain=Path('/tmp/StockCallRecordFootprint.lean').read_text();domain=domain[domain.index('private theorem domain '):domain.index('private theorem scan_demand')]
s=s[:a]+extra+domain+s[a:]
s=s.replace('  have external : XCallsOk (sourceEnv false implicit) ((function implicit).externs.map (·.2)) (fun _ _ _ => True) (model implicit) := external\n','')
Path('/tmp/StockGotSourceWitness.lean').write_text(s)
