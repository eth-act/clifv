from pathlib import Path
import json,re
root=Path('/home/lee/clifv/.worktrees/driver-proof-resume'); old=json.loads((root/'docs/research/stock-indirect-source-scratch.json').read_text())
mods=['StockCallFreshResolvedFrame','StockGotRecordCode','StockGotRecordFootprint','StockGotStoreSem','StockGotRecordSource','StockGotResolvedSource','StockGotSourceWitness']
new=[]
for m in mods:
 s=Path('/tmp',m+'.lean').read_text();ns=re.search(r'^namespace (\S+)',s,re.M).group(1)
 new += [ns+'.'+n for n in re.findall(r'^theorem (\w+)',s,re.M)]
roots=list(old['normal_axiom_audit']['roots'])+new+list(old['normal_axiom_audit']['legacy_dependency_exact_sets'])
imports=sorted({Path(p).stem for p in old['scratch_sources']}|set(mods))
Path('/tmp/stock-got-source-all-axioms.lean').write_text('\n'.join('import '+m for m in imports)+'\n'+'\n'.join('#print axioms '+n for n in roots)+'\n')
Path('/tmp/stock-got-source-new-roots.json').write_text(json.dumps(new,indent=2)+'\n')
print('modules',len(imports),'roots',len(roots)-4,'new',len(new))
