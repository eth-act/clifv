# Current work — #140 Stock production driver

Updated UTC: 2026-10-21T01:03:39.426707+00:00. State: **active**. Full original #140 remains unfinished.

## Shipped and pending

Main `08020ed34bea4a3656c1b080c55087da40f2ebbe` already ships the D0 parameter-return, all-six prologue and scalar-add classes (#328–#336), with legacy fallback. General arithmetic and select/add/sub Mixed are **not activated**. No author PR is currently open; these candidates are backed up as branches, not merge-ready PRs.

- Arithmetic delivery checkout: `agent/stock-arithmetic-production-current-main`, frozen/pushed `213fe68bfbda3ed5d237cb7df6651f47e5a189bc`, old base `ddfeb764`. Same module scheduler PID1763255 live; 1116 distinct latest module successes, zero latest failures. Parent1762992 intentionally held, not a stopped proof kernel. Normal leaf coordinators can briefly hold only the scheduler while existing proof kernels continue.
- Current-Arm arithmetic candidate: pushed `672c4dc4820b31c477a5e075926c72cd2b267dd8`, branch `agent/stock-arithmetic-arm-model-20261021T001904Z`, based on main08020. Includes strict real-oracle arithmetic runtime repair. Observer2890710 and verified handoff2912219 retain the existing old module run, back up its terminal evidence, then switch the clean delivery checkout and run all affected current-source and activation gates. A newer main causes review before switching. No old-head full-pass/activation claim.
- Mixed source: pushed `48bca5b4e899d2ba5fda525b245f94756bc263b6`, branch `agent/stock-mixed-production-current-main`. Normal module port has359 distinct actual successful builds through batch65, including complete Mixed/function and compiler-choice witnesses; latest bounded batch66 remains active. These are **old Arm-model port checks**, not a current-main activation pass. Current-Arm source candidate `0ad366fe24d0f778301ba5e2db89043eb84b3924` on `agent/stock-mixed-arm-model-20261021T003711Z` preserves all30 changed code blobs and depends on arithmetic672. Metadata evidence48 is separately pushed.
- New source22aa7ab3 adds a reproducible normal `scripts/check-stock-mixed-integration.py` and a missing-regalloc2-binary negative control. Python syntax/help and dependency ordering checked against12 actual generated roots/18 files; the new end-to-end runtime/link/CLI/axiom gate still requires execution. Existing native624 calls/24objects and combined-source proofs remain qualified historical evidence.
- Current-main CI cache reused in the **existing** store: earlier123 output keys, new stage-w1-5 has317 verified records/639 referenced files (257 keys beyond the earlier import). String-valued ltar and object-valued facet records both verified after correcting a metadata-validator assumption; original failure retained. Temporary downloads/staging removed. Cache reuse is not a source gate pass.

## Next work and coordination

Finish the same live handles without restarting proofs. Complete exact current-Arm arithmetic gates (strict oracle, all owned/public axioms and prior sets, complete old/new witnesses, runtime/encoding, both E2E identity/stage reports, actual compiler/checker/linker/generated proofs and verified fv-demo/survey); author a substantive non-draft PR and squash promptly after gates, then notify#261/#140. Next tentatively: reconcile Mixed onto the actual squash main, normal/full integration and final bundled MCP review, activate; then logical95d72 and every remaining original#140 obligation. Tentative next tasks are not additional reservations.

Contributor statuses#52/#71 read; stale dates are uncertain. Shared interface request to @kevaundray: [specific #354 ArmState/TPIDR/MInst/Cov boundary and cache request](https://github.com/eth-act/clifv/issues/140#issuecomment-6304759270). No reply observed. Our integer classes do not claim TLS/overflow/FP expansion. Preserve old theorem variants, original input conditions, accepted identities and ordered successful stages, and exact required axiom sets. Uncovered families/effects, omitted/sunk memory/trap/call/CFG, source/block/whole-driver simulation, Stock-only completeness, optimizer/unwind and all proof consumers remain mandatory.

## Ownership, recovery and resource budget

All five local worktrees remain needed; no new worktree/cache was created:

- `/home/lee/clifv`: user primary checkout, saved dirty source; do not overwrite.
- `.worktrees/driver-proof-resume`: preserved original1874 dirty saved paths at01081291; canonical shared Lake artifact store and Rust target. Never overwrite/stash.
- `.worktrees/stock-lowering`: additional saved dirty source; preserve.
- `.worktrees/stock-driver-incremental`: owned frozen arithmetic validation and verified current-Arm handoff.
- `.worktrees/stock-mixed-production`: owned current Mixed source and normal import view; hardlinks share the one physical cache.

Aggregate16GiB cap, at most2 actual compiler jobs, OMP threads2; no actual proof wall timeout or pattern kill. Cache-only I/O reserves1GiB within the same aggregate. Last disk check768GiB free. Archive unique logs before deleting completed helpers and staging; remove unneeded clean trees/caches when their work ends.

Latest prior full saved-source remote recovery: `02a00405b1143f5b13168831b3cf05523b32a303`, branch `agent/stock-driver-wip-backup-20261021T004202Z`, with all1874 dirty source paths and verified handoff scripts/evidence. Source candidates and latest Mixed commits are separately pushed. Local live-state index: `/tmp/stock-current-resume.json`; gate evidence under `/tmp/stock-arithmetic-current-main-author-gates`, `/tmp/stock-arm-verified-handoff`, normal batch receipts57–66 and checked-in `docs/research/stock-mixed-current-main-normal-build.json`. Previous long#44 body archived at `/tmp/stock-status44-before-current-refresh.md` for the next remote recovery snapshot.
