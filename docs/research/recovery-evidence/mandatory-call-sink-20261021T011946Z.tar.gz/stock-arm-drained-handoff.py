from pathlib import Path
import os,signal,time,subprocess as sp,json,datetime,hashlib,tarfile,re,traceback
view=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');out=Path('/tmp/stock-arm-drained-handoff');sched=1763255;parent=1762992;candidate='672c4dc4820b31c477a5e075926c72cd2b267dd8';branch='agent/stock-arithmetic-arm-model-20261021T001904Z';base='08020ed34bea4a3656c1b080c55087da40f2ebbe';controller=Path('/tmp/stock-arithmetic-arm-model-author-gates.py')
intent=json.loads((out/'drain-intent.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return sp.check_output(['git',*args],cwd=view,text=True).strip()
def status(pid):
 p=Path(f'/proc/{pid}/stat');return p.read_text().split() if p.exists() else None
def report(state,**kw):
 j={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':state,'pid':os.getpid(),'old_scheduler':sched,'old_author':parent,'candidate':candidate,'main':base,**kw};(out/'progress.json').write_text(json.dumps(j,indent=2)+'\n');print(json.dumps(j),flush=True)
def retired(pid):
 s=status(pid);return s is None or s[2]=='Z'
def retire_metadata(pid,signature):
 if retired(pid):return
 p=Path(f'/proc/{pid}');assert signature in p.joinpath('cmdline').read_bytes();assert status(pid)[2]=='T'
 assert all(retired(int(k)) for k in p.joinpath('task',str(pid),'children').read_text().split()),('metadata still owns running children',pid)
 os.kill(pid,signal.SIGTERM);os.kill(pid,signal.SIGCONT)
 deadline=time.monotonic()+30
 while not retired(pid):
  assert time.monotonic()<deadline,('metadata did not exit',pid);time.sleep(.2)
try:
 report('draining_same_running_old_proof_kernels',jobs=intent['captured_live_jobs'],no_proof_kernel_signalled=True)
 while True:
  assert status(sched)[2]=='T' and status(parent)[2]=='T','metadata hold changed; inspect same handles before any source switch'
  live=[];drained=[]
  for job in intent['captured_live_jobs']:
   s=status(job['pid']);assert s and s[21]==job['start_ticks'],('captured process identity changed',job)
   if s[2]!='Z':live.append(job['pid']);continue
   timing=Path(job['time_file']);assert timing.exists();match=re.search(r'Exit status: (-?\d+)',timing.read_text());assert match
   result={**job,'exit_status':int(match[1]),'time_sha256':sha(timing),'raw_wait_status':int(s[51])};drained.append(result)
  if not live:break
  time.sleep(2)
 assert all(j['exit_status']==0 and j['raw_wait_status']==0 for j in drained),('inspect drained kernel failure before continuing',drained)
 assert all(retired(int(k)) for k in Path(f'/proc/{sched}/task/{sched}/children').read_text().split())
 assert git('rev-parse','HEAD')==intent['source'] and not git('status','--porcelain','--untracked-files=no')
 frozen=json.loads(Path('/tmp/stock-arithmetic-current-main-author-gates/inputs.json').read_text());assert all(sha(view/p)==h for p,h in frozen['sources'].items())
 log=Path('/tmp/stock-arithmetic-current-main-author-gates/all-modules/sched.log');latest=dict(re.findall(r'done (\S+) rc=(\S+)',log.read_text()))
 receipt={'state':'old_active_kernels_drained_no_full_old_gate_claim','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':intent['source'],'all_frozen_sources_verified':len(frozen['sources']),'no_live_old_proof_kernels':True,'old_module_epoch_complete':False,'drained_jobs':drained,'completed_log_records':len(latest),'latest_nonzero_log_records':{m:r for m,r in latest.items() if r!='0'},'log':str(log),'log_sha256':sha(log),'current_validation_policy':'Check all current FV/FVTest module keys and all22 original named activation gates plus dynamic ones; no old completion/reuse assumption. Preserve existing matching artifacts through Lake keys.'};assert not receipt['latest_nonzero_log_records'];(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 git('fetch','origin','main');assert git('rev-parse','origin/main')==base,'newer main needs reconciliation before switch';assert git('rev-parse',branch)==candidate
 report('preserving_drained_source_epoch',completed_log_records=len(latest),drained_jobs=len(drained))
 archive=out/'completed-old-source-epoch.tar.gz';paths=[Path('/tmp/stock-arithmetic-current-main-author-gates'),out/'drain-intent.json',out/'receipt.json',Path(__file__),controller,Path('/tmp/stock-arithmetic-arm-model-ready-to-land.py'),Path('/tmp/stock-arm-next-validation-prepared.json'),Path('/tmp/stock-current-resume.json'),Path('/tmp/stock-ni-current-status44.md'),Path('/tmp/stock-mixed-arm-source-prep.json')]
 with tarfile.open(archive,'w:gz',compresslevel=1) as t:
  for p in paths:t.add(p,arcname=p.name)
 env=dict(os.environ,STOCK_RECOVERY_EVIDENCE=str(archive),FV_MEMCAP='1G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',GIT_CONFIG_COUNT='1',GIT_CONFIG_KEY_0='pack.threads',GIT_CONFIG_VALUE_0='1')
 with (out/'backup.log').open('w') as f:r=sp.run(['nice','-n','10',str(view/'scripts/memcap.sh'),'python3','/tmp/stock-mandatory-backup.py'],cwd=view,env=env,stdout=f,stderr=sp.STDOUT)
 assert r.returncode==0,('drained evidence backup failed',str(out/'backup.log'));backup=json.loads(Path('/tmp/stock-backup-captured-result.json').read_text());assert backup['remote_commit_and_all_captured_blobs_verified'] and backup['index_and_active_head_unchanged']
 report('drained_epoch_remotely_verified',backup_commit=backup['commit'],archive_sha256=sha(archive),completed_log_records=len(latest))
 assert all(sha(view/p)==h for p,h in frozen['sources'].items())
 git('fetch','origin','main');assert git('rev-parse','origin/main')==base,'newer main: preserve held source and reconcile first'
 retire_metadata(sched,b'stock-execute-scheduler.py');retire_metadata(parent,b'stock-arithmetic-current-main-author-gates.py')
 assert git('rev-parse','HEAD')==intent['source'] and not git('status','--porcelain','--untracked-files=no')
 git('switch',branch);assert git('rev-parse','HEAD')==candidate
 assert sha(view/'FVTest/Backend/Lowering/StockArithmeticRuntime.lean')=='b00043a15c8616e6b4b78bfa2d24634eeacb825bbd75d56db6aa1b1626641b1c'
 log=Path('/tmp/stock-arithmetic-arm-model-author-controller.log')
 with log.open('w') as f:p=sp.Popen(['python3',str(controller)],cwd=view,stdout=f,stderr=sp.STDOUT,start_new_session=True)
 report('current_arm_author_gates_started',controller_pid=p.pid,controller_log=str(log),old_epoch_backup=backup['commit'],backup_branch=backup['branch'],no_proof_kernel_interrupted=True,old_modules_not_built_after_upstream_invalidation=True,all_current_module_keys_checked=True)
except BaseException as e:
 report('failed',error=repr(e),traceback=traceback.format_exc(),note='Do not resume obsolete metadata or restart proofs blindly; inspect actual source/process state and retained evidence.');raise
