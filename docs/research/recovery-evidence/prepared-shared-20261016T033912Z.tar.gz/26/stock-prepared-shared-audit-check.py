import re,json,hashlib
from pathlib import Path
parse=lambda s:{m.group(1):sorted(x.strip() for x in m.group(2).split(',') if x.strip()) for m in re.finditer(r"'([^']+)' depends on axioms:\s*\[([^]]*)\]",s)}|{n:[] for n in re.findall(r"'([^']+)' does not depend on any axioms",s)}
old=parse(Path('/tmp/stock-prepare-no-split-axioms.log').read_text());log=Path('/tmp/stock-prepared-shared-axioms.log').read_text();new=parse(log)
assert len(old)==1961 and len(new)==1969,(len(old),len(new))
assert not re.search(r'(^|\n).*error:',log)
assert all(new.get(n)==v for n,v in old.items())
p=json.loads(Path('docs/research/stock-prepared-shared-checkpoint.json').read_text());roots=p['new_public_roots'];std={'Classical.choice','Quot.sound','propext'}
assert set(new)-set(old)==set(roots);assert all(set(new[n])<=std for n in roots)
mcp=Path('docs/research/stock-prepared-shared-mcp.json');m=json.loads(mcp.read_text());assert m['success'] and not m['timed_out']
assert parse('\n'.join(d['message'] for d in m['diagnostics']))=={n:new[n] for n in roots}
scans={f:[(i,l) for i,l in enumerate(Path(f).read_text().splitlines(),1) if re.search(r'\b(sorry|admit|axiom|trace_state)\b',l)] for f in p['new_or_appended_source_paths']};assert not any(scans.values()),scans
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
r={'normal_audit':{'path':'/tmp/stock-prepared-shared-axioms.log','sha256':sha('/tmp/stock-prepared-shared-axioms.log'),'roots':len(new),'all1961_previous_sets_including_7_compiler_sets_preserved':True,'new_axioms':{n:new[n] for n in roots}},'mcp_audit':{'path':str(mcp),'sha256':sha(mcp),'one_bundled_run':True,'all8_sets_match_normal_kernel':True},'source_scan_warnings':scans}
Path('/tmp/stock-prepared-shared-audit-receipt.json').write_text(json.dumps(r,indent=2)+'\n')
print('PASS',len(new),'roots;',len(old),'prior sets unchanged; 8 new standard-only; one MCP agrees; source scans clear')
