import StockTryIndirectSem
import StockTryWholeOutgoing
import StockTryFinalReturnValues
namespace Backend.Stock.Proof.TryIndirectSourceRunDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open TrySourceContextDraft TryBranchSelectionDraft TryBranchAbiDraft TrySelectedCallsDraft
open TryWholeSourceReservationDraft TryRetsTotalDraft TryIndirectCodeDraft TryIndirectSemDraft TryWholeOutgoingDraft
open TryResultMapDraft TryFinalReturnValuesDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
/-- A conclusion about the actual retained source branch and its normal machine
execution. It is constructed internally, never an accepted-program premise. -/
structure IndirectTryRun (f : Clif.Function) (result : Result) (label bi : Nat) (b : Clif.Block)
    (sig : Clif.Signature) (isem : Sem) (MR : MemRelT) (fr : Clif.Frame)
    (ρ : Nat → CV) (w : Arm.ArmState) (rvals : List Clif.Val) (cm' : Clif.Mem) where
  source : TryBranchSource f result label bi b
  selected : TryBranchSelection source
  base : Nat
  target : Nat
  ns : List Nat
  bytes : List Nat
  locs : List ArgLoc
  stack : Nat
  info : TryInfo
  outs : List CV
  atCall : Arm.ArmState
  finalWorld : Arm.ArmState
  layout : result.initial.tryRegs[source.ti]! = (reservedReturns base sig.returns.length,reservedPayloads base sig.returns.length)
  code : source.branch.step.emitted = (((stackEnts ((locs.zip ns).zip bytes)).map argStore) ++
    [MInst.tryCall ⟨.reg (.vreg target .int),retPairs (regPairsOf ((locs.zip ns).zip bytes)),callDefs (resultDefs base sig.returns.length)⟩
      {info with rets := sig.returns.length}]).toArray
  run : seqRun isem source.branch.step.emitted.toList ρ w =
    some (.stop 0
      (.tryCall ⟨.reg (.vreg target .int),retPairs (regPairsOf ((locs.zip ns).zip bytes)),callDefs (resultDefs base sig.returns.length)⟩
        {info with rets := sig.returns.length})
      (tgtOp target :: (retOps (regPairsOf ((locs.zip ns).zip bytes)) ++ callDefOps (resultDefs base sig.returns.length))).toArray
      ρ atCall outs finalWorld (.goto info.handlers.length))
  returnedWorld : MR fr.slots cm' finalWorld
  normalValues : ∀ (j : Nat) (v : Clif.Val),rvals[j]? = some v →
    VHolds v (vdefUpd (tgtOp target :: (retOps (regPairsOf ((locs.zip ns).zip bytes)) ++ callDefOps (resultDefs base sig.returns.length))).toArray
      outs ρ (aliasNum result.final.alias (base+j)))
/-- Actual whole Stock lowering derives the indirect TryCall's exact branch code
and final reserved aliases, executes its real requested target and call under the original indirect contract, and transfers
normal returned values/world. All source/static/layout premises are derived
from the original build/scope/input; memory and callee contracts are unchanged. -/
theorem stock_lower_indirect_try_normal_source_run {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f) (input : Prg.iselInB f = true)
    (abi : Backend.Proof.Spill.AbiSigsOk f)
    {label bi : Nat} {b : Clif.Block} (node : result.order.nodes[label]? = some (.original bi))
    (block : f.blocks[bi]? = some b) {callee : Nat} {args : List Nat} {et : Clif.ExnTable}
    (kind : b.term = .tryCallIndirect callee args et) {sig : Clif.Signature} {items : List (Option Nat)}
    (table : exnTableOpnd f et = .ok (sig,items))
    {isem : Sem} {MR : MemRelT}
    {Pc : String → Clif.Signature → List Clif.Val → Clif.Mem → Prop} {env : Clif.Env}
    (calls : IndCallsRefineP Pc env (indSigs f) MR isem)
    {fr : Clif.Frame} {ρ : Nat → CV} {w : Arm.ArmState} {cm cm' : Clif.Mem} {vals rvals : List Clif.Val}
    (held : ValuesHeld (fun x => x = callee ∨ x ∈ args) result.ctx fr ρ) (read : fr.getMany args = .ok vals)
    (typed : vals.map (·.ty) = Clif.AbiParam.tys sig.params) (related : MR fr.slots cm w)
    {name : String} {address : Nat}
    (calleeValue : fr.get callee = .ok ⟨.i64,BitVec.ofNat 64 address⟩)
    (symbol : cm.symbols name = some address)
    (signature : ∀ s,env.sigOf name = some s → sig.abiMatch s = true)
    {g : List Clif.Val → Clif.Mem → Clif.Outcome} (found : env.extern name = some g)
    (pin : Pc name sig vals cm) (returned : g vals cm = .returned rvals cm')
    (results : rvals.length = sig.returns.length) :
    Nonempty (IndirectTryRun f result label bi b sig isem MR fr ρ w rvals cm') := by
  have isTry : b.term.isTry = true := by rw [kind]; rfl
  have sourceTableEq : sourceTable b.term = some et := by rw [kind]; rfl
  obtain ⟨ranges,source,selected,base,replay,replayAfter,build,allocation,slots,replayRun,frame⟩ :=
    stock_lower_original_try_reservation lowered scope input node block sourceTableEq table
  obtain ⟨sig',actualItems,actualTable,_,_,_,_,protocol⟩ := stock_selected_try_indirect_rhs_calls selected kind
  have same : sig' = sig := congrArg Prod.fst (Except.ok.inj (actualTable.symm.trans table))
  change sig' = sig at same
  subst sig'
  obtain ⟨ns,bytes,locs,stack,target,targetMap,mapping,byteRun,locations,raw⟩ := stock_indirect_try_actual_code data_program
    source.mapped protocol base (exnTableOpnd_cc table) slots
  change selected.next.base.emitted = (#[] ++ _).push _ at raw
  simp only [Array.empty_append] at raw
  obtain ⟨et',sig',items',info,call,tableKind,decoded,metadata,abiCount,last,code,finalLast⟩ :=
    stock_try_branch_explicit_abi isTry selected.code
  have sameTable : et' = et := Option.some.inj (tableKind.symm.trans sourceTableEq)
  subst et'
  have sameSig := Except.ok.inj (decoded.symm.trans table)
  cases sameSig
  rw [raw,Array.back?_push] at last
  have sameCall := Option.some.inj last
  cases sameCall
  have exactCode : source.branch.step.emitted = (((stackEnts ((locs.zip ns).zip bytes)).map argStore) ++
    [MInst.tryCall ⟨.reg (.vreg target .int),retPairs (regPairsOf ((locs.zip ns).zip bytes)),callDefs (resultDefs base sig.returns.length)⟩
      {info with rets := sig.returns.length}]).toArray := by
    rw [selected.stepCode,code,raw,Array.pop_push]
    apply Array.toList_inj.mp
    simp only [Array.toList_push,List.toList_toArray]
  have heldSource : ValuesHeld (fun x => x ∈ args) source.ctx fr ρ := by
    intro x member v lookup
    obtain ⟨n,mapped,value⟩ := held x (.inr member) v lookup
    exact ⟨n,by rw [source.valueMap]; exact mapped,value⟩
  have allValues := requested_values_hold heldSource read mapping
  simp only [List.map_map,Function.comp_def,registerView] at allValues
  have counts : ns.length = vals.length := by simpa using allValues.1.symm
  have values : ∀ (j : Nat) (v : Clif.Val) (n : Nat),vals[j]? = some v → ns[j]? = some n → VHolds v (ρ n) := by
    intro j v n atValue atReg
    apply allValues.2 j v (ρ n) atValue
    simp only [List.getElem?_map,atReg,Option.map_some]
  have declared := exnTableOpnd_sig table
  have member : sig ∈ indSigs f := by
    unfold indSigs
    refine List.mem_flatMap.mpr ⟨b,List.mem_of_getElem? block,?_⟩
    simp only [kind,declared]
    exact List.mem_append_right _ (by simp)
  have bound := (abi.2 sig member).1
  have targetGlobal : result.ctx.valueReg? callee = some (.vreg target .int) := by rw [← source.valueMap]; exact targetMap
  obtain ⟨key,keyMap,heldCallee⟩ := held callee (.inl rfl) _ (frame_get_regs calleeValue)
  have keyEq : key = target := by
    have regs := Option.some.inj (keyMap.symm.trans targetGlobal)
    cases regs
    rfl
  subst key
  have calleeWord : lo64 (ρ target) = BitVec.ofNat 64 address := heldCallee
  obtain ⟨outs,w',run,length,heldResults,world,normal⟩ := stock_try_indirect_actual_normal_execution
    calls member bound byteRun locations typed counts values found signature symbol calleeWord related pin returned results base info
  have layout : result.initial.tryRegs[source.ti]! = (reservedReturns base sig.returns.length,reservedPayloads base sig.returns.length) := by
    rw [← allocation.2]
    exact source.tryRegs.symm.trans slots
  refine ⟨{
    source := source
    selected := selected
    base := base
    target := target
    ns := ns
    bytes := bytes
    locs := locs
    stack := stack
    info := info
    outs := outs
    atCall := w
    finalWorld := w'
    layout := layout
    code := exactCode
    run := ?_
    returnedWorld := world
    normalValues := ?_ }⟩
  · rw [exactCode,List.toList_toArray]
    exact run
  · intro j v atValue
    rw [vdefUpd_call_reg]
    exact stock_lower_try_normal_reserved_values lowered layout ρ heldResults results length atValue
end Backend.Stock.Proof.TryIndirectSourceRunDraft
