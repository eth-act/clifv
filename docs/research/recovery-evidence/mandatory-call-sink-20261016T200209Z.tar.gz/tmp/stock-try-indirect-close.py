from pathlib import Path
import json,hashlib,re,datetime,tarfile,shutil
root=Path('/home/lee/clifv/.worktrees/driver-proof-resume');docs=root/'docs/research'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
now=datetime.datetime.now(datetime.timezone.utc);stamp=now.strftime('%Y%m%dT%H%M%SZ')
batch=json.loads(Path('/tmp/stock-try-indirect-batch.json').read_text());old=json.loads((docs/'stock-try-got-scratch.json').read_text())
sets={m.group(1):sorted(x.strip() for x in m.group(2).split(',') if x.strip()) for m in re.finditer(r"'([^']+)' depends on axioms:\s*\[([^]]*)\]",Path('/tmp/stock-try-indirect-combined-axioms.log').read_text())}
for m in re.finditer(r"'([^']+)' does not depend on any axioms",Path('/tmp/stock-try-indirect-combined-axioms.log').read_text()):sets[m.group(1)]=[]
for n,a in old['normal_audit']['sets'].items():assert sorted(a)==sets[n],n
allowed={'propext','Classical.choice','Quot.sound'}
for n in batch['public_roots']+batch['models']:assert set(sets[n])<=allowed,n
constants=[json.loads(line.split('DELIVERY_CONSTANT ',1)[1]) for line in Path('/tmp/stock-try-indirect-all-constants.log').read_text().splitlines() if line.startswith('DELIVERY_CONSTANT ')]
assert constants
for n,a in constants:assert set(a)<=allowed,n
mods={}
for m in batch['modules']:
 p=Path('/tmp')/m;check=json.loads(p.with_suffix('.check.json').read_text());assert check['actual_exit']==0
 rec={}
 for key,ext in [('source','.lean'),('object','.olean'),('log','.log'),('check','.check.json')]:
  f=p.with_suffix(ext);rec[key]=str(f);rec[key+'_sha256']=sha(f)
 for k in ['source','object','log']:assert rec[k+'_sha256']==check[k+'_sha256']
 assert not re.search(r'\b(sorry|admit|axiom|trace_state|native_decide)\b',p.with_suffix('.lean').read_text())
 mods[m]=rec
prior={}
for name in ['source-execution-x','try-source','try-context','try-rule','try-rets','try-reservation','try-outgoing','try-values','try-emitted','try-machine','try-got']:
 d=json.loads((docs/f'stock-{name}-scratch.json').read_text())
 for m,rec in d['modules'].items():
  for k in ['source','object','log']:assert sha(rec[k])==rec[k+'_sha256'],(m,k)
  prior[m]=rec
freeze=json.loads(Path('/tmp/stock-coherent-build-inputs.json').read_text())
for group in ['source_sha256','validation_script_sha256']:
 for p,h in freeze[group].items():assert sha(root/p)==h,p
progress=json.loads(Path('/tmp/stock-pr246-gates-progress.json').read_text());progress.pop('completed_phases',None)
remaining=old['remaining_checklist']
for item in remaining:
 if 'Actual emitted direct/GOT/indirect TryCall outgoing' in item['requirement']:
  item['state']='All three actual retained raw branches now have normal machine execution/value/world proofs. Indirect original≤8 bound derives internally from original AbiSigsOk via actual table signature membership; actual request/target and empty ABI stores derive internally. Complete original-condition direct/GOT/indirect compiler-to-physical witnesses pass, including9argGOT nonempty-stack execution. Exceptional machine/payload execution and actual final-renamed/source-frame/block/whole composition remain open.'
remaining.append({'requirement':'Actual true-indirect retained branch normal machine execution','state':'Proved with original IndCallsRefineP and original AbiSigsOk; no additional accepted input bound/layout/target certificate. Complete genuine indirect target/source program and compiler/prepare/checkedfallback/checker/physical witness passes. Additional nonzero-argument/width/sret/x8/handler matrix remains required.'})
receipt={'utc':now.isoformat(),'goal':'Original full #140 ACTIVE/INCOMPLETE; production LEGACY','scope':'Scratch-only additive Stock proofs, not coherent integration or merge-ready','delivery_target':'roughly eight substantive validated squash merges/day; remote backups and cleanup; drafts do not count','modules':mods,'public_roots':batch['public_roots'],'models':batch['models'],'counts':{'modules':len(mods),'public_roots':len(batch['public_roots']),'models':len(batch['models']),'combined_roots_models':len(sets),'previous_preserved':len(old['normal_audit']['sets']),'all_new_module_constants':len(constants)},'normal_audit':{'path':'/tmp/stock-try-indirect-combined-axioms.log','sha256':sha('/tmp/stock-try-indirect-combined-axioms.log'),'sets':sets},'all_constant_audit':{'path':'/tmp/stock-try-indirect-all-constants.log','sha256':sha('/tmp/stock-try-indirect-all-constants.log'),'all_standard_only':True,'count':len(constants)},'previous77_modules_hashes_preserved':list(prior),'canonical2246_source_and_script_freeze_preserved':True,'kernel_resources':'All new modules and both audits actual exit0 / object verified at8GiB through memcap; one heavy delivery worker retained','MCP':'No new calls; bundled provenance audit deferred until coherent integration','active_exact_PR246_validation':progress,'remaining_checklist':remaining}
(docs/'stock-try-indirect-scratch.json').write_text(json.dumps(receipt,indent=2)+'\n')
text=f'''Actual true-indirect TryCall normal machine execution — {now.isoformat()}

Four scratch modules, {len(batch['public_roots'])} public theorem roots and one public execution model pass actual kernel checks at8GiB. The {len(sets)}-root/model audit preserves all528prior exact axiom sets. All {len(constants)} constants in new modules, including private operational helpers, use only standard axioms. All77previous scratch source/object/log hashes and frozen2246canonical sources plus scripts are unchanged. Previous goal turn classified PROGRESS: actual GOT branch execution, complete9argument/nonempty-stack witness, audits, archive and verified remote backup.

The SAME actual indirect RHS requests the original callee value and emits exact mapped source ABI arguments and the reserved-result call to its actual requested target. Whole lowering derives original source/selection/layout, exact retained TryCall branch, target mapping and final return aliases internally. The original≤8 signature bound is derived from ORIGINAL AbiSigsOk via the actual exception signature's membership in indSigs f (which includes TryCallIndirect). This derives empty generated stack stores and actual AllHold arguments, preserving the ORIGINAL IndCallsRefineP contract and old theorem variants. No new input filter, bound, target-map or layout certificate is introduced.

Actual seqRun of the retained raw branch returns normal control, related world and values read through actual vdefUpd and whole-driver final aliases. The COMPLETE genuine indirect compiler/prepare/forced checkedfallback/checker/physical witness inhabits ORIGINAL XCallsIndOk/IndCallsRefineP, uses real source function pointer4096, executes its actual branch and runs the source program to17. Its argument vector is empty; the broader nonzero-argument/width/zero-return/sret/x8/handler matrix remains required. Existing complete9argumentGOT nonempty-stack machine witness is preserved.

Normal raw retained branches are now proved for direct/GOT/true-indirect forms. Open: actual final-renamed instruction, available source-frame/DFG/reserved-write noninterference, normal block-edge parameter continuation; exact payload endpoints/exception machine semantics and explicit/sret/x8 matrix. Shared csemU/ExtSem exceptional interfaces remain @kevaundray #232/#233. ALL original family/effect/sinking/source/block/whole-driver simulation AND completeness, original-input context/visitor/static/checker/fallback/physical totality, coherent scratch integration and public/private/compiler/MCP/full/crates/runtime/encoder/BOTH E2E identity-stage gates, production compiler/checker/linker/generated consumers and fresh complete comparison remain required. Production LEGACY. Same live delivery supervisor3247835/canonicalheld1233457 retained; roughly eight substantive validated squash merges/day remains target. No merge/new worktree/MCP/heavy retry/restarted validation this batch.

See stock-try-indirect-scratch.json for hashed evidence and full remaining checklist.
'''
(docs/'stock-try-indirect-scratch.md').write_text(text)
plan=root/'docs/plans/test-binary-alignment-recovery.md';plan.write_text(plan.read_text()+'\n\n'+text)
files=[]
for rec in mods.values():files.extend(Path(rec[k]) for k in ['source','object','log','check'])
for name in ['stock-try-indirect-combined-axioms','stock-try-indirect-all-constants']:
 for ext in ['.lean','.log','.olean','.check.json']:files.append(Path('/tmp')/(name+ext))
files.extend(Path(p) for p in ['/tmp/stock-try-indirect-batch.json','/tmp/stock-try-rule-inputs.json','/tmp/stock-try-reservation-check.py','/tmp/stock-try-indirect-close.py','/tmp/stock-try-indirect-status44.json','/tmp/stock-try-indirect-status52.json','/tmp/stock-try-indirect-status71.json','/tmp/stock-try-indirect-task140.json'])
files.extend([docs/'stock-try-indirect-scratch.json',docs/'stock-try-indirect-scratch.md',docs/'stock-delivery-main-drift.json',plan])
archive=Path('/home/lee/.clifv-recovery')/(stamp+'-try-indirect')/'checkpoint.tar.gz';archive.parent.mkdir(parents=True)
with tarfile.open(archive,'w:gz',compresslevel=1) as t:
 for p in files:t.add(p,arcname=str(p).lstrip('/'),recursive=False)
with tarfile.open(archive,'r:gz') as t:
 for p in files:assert t.extractfile(str(p).lstrip('/')).read()==p.read_bytes(),p
snapshot=Path('/tmp/stock-try-rule-inputs');size=sum(p.stat().st_size for p in snapshot.rglob('*') if p.is_file());shutil.rmtree(snapshot)
backup={'utc':now.isoformat(),'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(files),'all_members_byte_verified':True,'previous_remote_backup':json.loads((docs/'stock-try-got-backup.json').read_text())['remote'],'cleanup':{'duplicate_dependency_snapshot_removed':True,'bytes_reclaimed':size,'unique_sources_objects_logs_checks_audits_preserved':True,'one_shared_warm_cache_retained':True,'other_projects_touched':False,'free_bytes':shutil.disk_usage(root).free}}
(docs/'stock-try-indirect-backup.json').write_text(json.dumps(backup,indent=2)+'\n');Path('/tmp/stock-try-indirect-archive-path').write_text(str(archive))
print(json.dumps({'counts':receipt['counts'],'archive':str(archive),'cleanup':backup['cleanup'],'gate':progress},indent=2))
