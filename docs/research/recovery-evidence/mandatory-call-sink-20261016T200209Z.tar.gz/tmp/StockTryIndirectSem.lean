import StockTryIndirectCode
import StockTryNormalCallValues
namespace Backend.Stock.Proof.TryIndirectSemDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open TryResultMapDraft TryResultWritesDraft TryNormalCallValuesDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private theorem no_stack : ∀ (ps ns bytes : List Nat),
    stackEnts ((((ps.map fun n => ArgLoc.reg (.x n)).zip ns).zip bytes)) = []
  | [],_,_ => rfl
  | _ :: _,[],_ => rfl
  | _ :: _,_ :: _,[] => rfl
  | _ :: ps,_ :: ns,_ :: bytes => no_stack ps ns bytes
/-- Original indirect ABI bound derives that the actual generated stores are
empty and the actual register uses hold all original source arguments. -/
theorem stock_try_indirect_register_layout {sig : Clif.Signature} (bound : sig.params.length ≤ 8)
    {bytes : List Nat} {locs : List ArgLoc} {stack : Nat}
    (byteRun : sigParamBytes sig = .ok bytes) (locations : sigArgLocs sig = .ok (locs,stack))
    {ns : List Nat} {vals : List Clif.Val} {ρ : Nat → CV}
    (typed : vals.map (·.ty) = Clif.AbiParam.tys sig.params) (count : ns.length = vals.length)
    (held : ∀ (j : Nat) (v : Clif.Val) (n : Nat),vals[j]? = some v → ns[j]? = some n → VHolds v (ρ n)) :
    stack = 0 ∧ stackEnts ((locs.zip ns).zip bytes) = [] ∧
      AllHold vals ((regPairsOf ((locs.zip ns).zip bytes)).map (ρ ·.1)) := by
  have byteCount := sigParamBytes_length byteRun
  have byteBound : bytes.length ≤ 8 := by omega
  have valueCount : vals.length = sig.params.length := by
    have sizes := congrArg List.length typed
    simpa only [List.length_map,Clif.AbiParam.tys] using sizes
  have locEq := Except.ok.inj (locations.symm.trans (sigArgLocs_regs byteRun byteBound))
  have zero : stack = 0 := congrArg Prod.snd locEq
  have locsEq : locs = (abiArgIdx sig.params 0).map fun n => ArgLoc.reg (.x n) := congrArg Prod.fst locEq
  have empty : stackEnts ((locs.zip ns).zip bytes) = [] := by
    rw [locsEq]
    exact no_stack _ _ _
  have all := allHold_regPairs locs vals ns bytes count.symm (by omega) held
  have locsOfEq : locsOf sig = locs := by simp only [locsOf,locations]
  have regValues := regArgVals_of_regs byteRun byteBound valueCount
  unfold regArgVals at regValues
  rw [locsOfEq] at regValues
  have converted := congrArg (fun vs => AllHold vs ((regPairsOf ((locs.zip ns).zip bytes)).map (ρ ·.1))) regValues
  have allFinal := Eq.mp converted all
  exact ⟨zero,empty,allFinal⟩
/-- The ORIGINAL indirect contract executes the actual reserved-result
TryCall with the actual full ABI use vector and normal operand result writes.
Empty stores follow from its original≤8 parameter condition internally. -/
theorem stock_try_indirect_actual_normal_execution
    {Pc : String → Clif.Signature → List Clif.Val → Clif.Mem → Prop}
    {env : Clif.Env} {sigs : List Clif.Signature} {MR : MemRelT} {isem : Sem}
    (calls : IndCallsRefineP Pc env sigs MR isem) {sig : Clif.Signature} (member : sig ∈ sigs)
    (bound : sig.params.length ≤ 8)
    {bytes : List Nat} {locs : List ArgLoc} {stack : Nat}
    (byteRun : sigParamBytes sig = .ok bytes) (locations : sigArgLocs sig = .ok (locs,stack))
    {ns : List Nat} {vals rvals : List Clif.Val} {ρ : Nat → CV}
    (typed : vals.map (·.ty) = Clif.AbiParam.tys sig.params) (count : ns.length = vals.length)
    (held : ∀ (j : Nat) (v : Clif.Val) (n : Nat),vals[j]? = some v → ns[j]? = some n → VHolds v (ρ n))
    {name : String} {g : List Clif.Val → Clif.Mem → Clif.Outcome} {sl : List (Clif.SlotId × Nat)}
    {cm cm' : Clif.Mem} {w : Arm.ArmState} {address target : Nat}
    (found : env.extern name = some g) (signature : ∀ s,env.sigOf name = some s → sig.abiMatch s = true)
    (symbol : cm.symbols name = some address) (callee : lo64 (ρ target) = BitVec.ofNat 64 address)
    (memory : MR sl cm w) (pin : Pc name sig vals cm) (returned : g vals cm = .returned rvals cm')
    (results : rvals.length = sig.returns.length) (base : Nat) (info : TryInfo) :
    ∃ (outs : List CV) (w' : Arm.ArmState),
      let L := regPairsOf ((locs.zip ns).zip bytes)
      let D := resultDefs base sig.returns.length
      let call := MInst.tryCall ⟨.reg (.vreg target .int),retPairs L,callDefs D⟩ {info with rets := sig.returns.length}
      seqRun isem (((stackEnts ((locs.zip ns).zip bytes)).map argStore) ++ [call]) ρ w =
        some (.stop 0 call (tgtOp target :: (retOps L ++ callDefOps D)).toArray ρ w outs w' (.goto info.handlers.length)) ∧
      outs.length = max sig.returns.length 2 ∧ PrefixHold rvals outs ∧ MR sl cm' w' ∧
      ∀ (j : Nat) (v : Clif.Val),rvals[j]? = some v →
        VHolds v (vdefUpd (tgtOp target :: (retOps L ++ callDefOps D)).toArray outs ρ (base+j)) := by
  obtain ⟨zero,empty,arguments⟩ := stock_try_indirect_register_layout bound byteRun locations typed count held
  have valueBound : vals.length ≤ 8 := by
    have sizes := congrArg List.length typed
    simp only [List.length_map,Clif.AbiParam.tys] at sizes
    omega
  obtain ⟨outs,w',run,length,values,world,normal⟩ := stock_try_indirect_normal_call_values calls member info base
    found signature symbol callee valueBound arguments memory pin returned results typed
  have defsLength : outs.length = (resultDefs base sig.returns.length).length := by
    simpa only [resultDefs,List.length_map,List.length_range] using length
  refine ⟨outs,w',?_,length,values,world,?_⟩
  · rw [empty]
    exact seqRun_tryCall_reg run defsLength
  · intro j v atValue
    rw [vdefUpd_call_reg]
    exact normal ρ j v atValue
end Backend.Stock.Proof.TryIndirectSemDraft
