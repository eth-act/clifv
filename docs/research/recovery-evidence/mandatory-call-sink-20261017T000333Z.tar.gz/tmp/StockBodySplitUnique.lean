import StockBodySteps
namespace Backend.Stock.Proof.BodySplitUniqueDraft
open Backend.Proof Backend.Proof.Driver
/-- Different proof paths recover the same actual source block, terminator
record and ordinary body; composition cannot silently switch scan fragments. -/
theorem sourceBodySplit_unique {f : Clif.Function} {event : BlockScanEvent}
    {b b' : Clif.Block} {term term' : ScanRecord} {body body' : BlockScan}
    (one : SourceBodySplit f event b term body) (two : SourceBodySplit f event b' term' body') :
    b = b' ∧ term = term' ∧ body = body' := by
  have block := Option.some.inj (one.block.symm.trans two.block)
  have records := List.cons.inj (one.records.symm.trans two.records)
  have state := one.state.trans two.state.symm
  have code : body.code = body'.code := by
    have equal := one.code.symm.trans two.code
    rw [records.1] at equal
    apply Array.toList_inj.mp
    apply List.append_cancel_right
    simpa only [Array.toList_append] using congrArg Array.toList equal
  refine ⟨block,records.1,?_⟩
  cases body; cases body'
  cases state; cases records.2; cases code
  rfl
end Backend.Stock.Proof.BodySplitUniqueDraft
