from pathlib import Path
import re,json,hashlib,datetime
root=Path('/home/lee/clifv/.worktrees/driver-proof-resume');p=Path('/tmp/stock-try-rule-inputs.json');d=json.loads(p.read_text());records=d['modules'];freeze=json.load(open('/tmp/stock-coherent-build-inputs.json'))['source_sha256'];added=[]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def visit(m):
 if m in records:return
 src=root/(m.replace('.','/')+'.lean')
 if not src.exists():return
 assert sha(src)==freeze[str(src.relative_to(root))],m
 obj=root/'.lake/build/lib/lean'/(m.replace('.','/')+'.olean');assert obj.exists(),m
 data=obj.read_bytes();dst=Path('/tmp/stock-try-rule-inputs')/(m.replace('.','/')+'.olean');dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(data)
 records[m]={'source':str(src),'source_sha256':sha(src),'object':str(obj),'snapshot':str(dst),'object_sha256':sha(dst),'bytes':len(data)};added.append(m)
 for line in re.findall(r'^(?:(?:public|private)\s+)?import\s+([^\n]+)',src.read_text(),re.M):
  for n in line.split():visit(n)
for m in ['FV.Backend.Proof.StockActualBodyRefines','FV.Backend.Proof.StockMixedBodyWitness']:visit(m)
d['modules']=records;d['body_extension']={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'new_modules':added,'canonical_frozen_sources_verified':True};p.write_text(json.dumps(d,indent=2)+'\n');print('Added',added,'total',len(records))
