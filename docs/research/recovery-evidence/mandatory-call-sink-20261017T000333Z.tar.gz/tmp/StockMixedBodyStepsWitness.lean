import StockBodySplitUnique
import FV.Backend.Proof.StockMixedBodyWitness
import FV.Backend.Proof.RefinesCSem
namespace Backend.Stock.Proof.MixedBodyStepsWitnessDraft
open Backend.Proof Backend.Proof.Driver
open BodyStepsDraft BodySplitUniqueDraft FallStepsDraft PreparedSegmentsDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private def firstPoint {step : Nat → SourcePoint → SourcePoint → Prop} {indices : List Nat}
    {s t : SourcePoint} (_ : SourceSteps step indices s t) : SourcePoint := s
private def lastPoint {step : Nat → SourcePoint → SourcePoint → Prop} {indices : List Nat}
    {s t : SourcePoint} (_ : SourceSteps step indices s t) : SourcePoint := t
private def incomingRegisters {f : Clif.Function} {result : Result} {ctx : Ctx} {bi : Nat}
    {MR : MemRelT} {st : State} {s : SourcePoint} {rho : Nat → CV} {w : Arm.ArmState}
    (_ : GuardedScanRel f result ctx bi MR st s rho w) : Nat → CV := rho
/-- A real ignored load and emitted select execute in their SAME returned
block, retaining source/DFG/world agreement. Production csem also executes
this body in the SAME actual prepared output, for every external model/world. -/
theorem stock_complete_mixed_body_prepared_witness (word : BitVec 64) :
    ∃ (f : Clif.Function) (result : Result) (prepared : EdgeVCode) (event : BlockScanEvent)
      (b : Clif.Block) (term : ScanRecord) (body : BlockScan)
      (initial finalSource : SourcePoint) (rho : Nat → CV),
      Stock.lower f = .ok result ∧ LowerScope f ∧ Dominated f ∧
      prepareAt result.code result.edgeArgs = .ok prepared ∧
      prepareCheckedAt result.code result.edgeArgs = .ok prepared ∧
      event ∈ result.blockScans.toList ∧ SourceBodySplit f event b term body ∧
      initial.1 = 0 ∧ finalSource.1 = 2 ∧ b.body.length = 2 ∧
      initial.2.1.regs 7 = some ⟨.i64,word⟩ ∧
      finalSource.2.1.regs 0 = some ⟨.i8,9⟩ ∧
      finalSource.2.1.regs 100 = some ⟨.i64,Clif.Sem.select word 7 9⟩ ∧
      (∀ r ∈ body.records,SelectOrOmittedRecord f event.ctx event.block r) ∧
      SourceSteps (IndexedSourceInst Clif.Env.empty {funcs := []} f event.ctx event.block)
        ((List.range b.body.length).map (blockStart f event.block + ·)) initial finalSource ∧
      SourceDefinedAt f result.ctx 0 initial.1 initial.2.1 ∧
      SourceDefinedAt f result.ctx 0 finalSource.1 finalSource.2.1 ∧
      (∀ w,GuardedScanRel f result event.ctx event.block (fun _ cm _ => cm = initial.2.2)
        event.output.state initial rho w) ∧
      (∀ w,∃ (vb : VBlock) (prelude : Array MInst) (final : Nat → CV) (w' : Arm.ArmState),
        result.code.blocks[0]? = some vb ∧
        seqRun ispec (body.code.toList.map (·.mapRegs
          (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1)))) rho w = some (.fall final w') ∧
        Star (VStepAt result.code result.edgeArgs ispec) (.run ⟨0,prelude.size,rho,w⟩)
          (.run ⟨0,prelude.size+body.code.size,final,w'⟩) ∧
        GuardedScanRel f result event.ctx event.block (fun _ cm _ => cm = initial.2.2)
          term.output.state finalSource final w') ∧
      (∀ (F : BitVec 64 → Prop) (ctx : FnCtx) (X : ExtSem) (w : Arm.ArmState),
        ∃ (vb : VBlock) (prelude : Array MInst) (final : Nat → CV) (w' : Arm.ArmState),
          result.code.blocks[0]? = some vb ∧
          seqRun (csem F ctx X) (body.code.toList.map (·.mapRegs
            (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1)))) rho w = some (.fall final w') ∧
          Star (VStepAt result.code result.edgeArgs (csem F ctx X)) (.run ⟨0,prelude.size,rho,w⟩)
            (.run ⟨0,prelude.size+body.code.size,final,w'⟩) ∧
          Star (VStepAt prepared.code prepared.edges (csem F ctx X)) (.run ⟨0,prelude.size,rho,w⟩)
            (.run ⟨0,prelude.size+body.code.size,final,w'⟩) ∧
          GuardedScanRel f result event.ctx event.block (fun _ cm _ => cm = initial.2.2)
            term.output.state finalSource final w') := by
  obtain ⟨result,event,b,term,body,lowered,scope,dominated,events,split,entry,bodyLength,
    termIndex,order,families,source,executions⟩ := MixedBodyWitness.stock_mixed_actual_body_split_witness word
  obtain ⟨prepared,raw,checked,accepted⟩ := stock_prepare_total lowered scope
  have nodes : result.order.nodes = #[.original 0] := by
    have computed := congrArg (fun x => x.toOption.map (fun o => o.nodes)) (stock_lower_order lowered)
    conv at computed => lhs; cbv
    change some #[Node.original 0] = some result.order.nodes at computed
    exact (Option.some.inj computed).symm
  have size : result.code.blocks.size = 1 := by
    rw [← (stock_prepare_dimensions lowered).1,(stock_prepare_dimensions lowered).2.1,nodes]
    rfl
  have labelZero : ∀ label vb,result.code.blocks[label]? = some vb → label = 0 := by
    intro label vb placed
    have bound := (Array.getElem?_eq_some_iff.mp placed).1
    rw [size] at bound
    omega
  obtain ⟨definedResult,_,definedRun,_,_,_,initialDefined,_,finalDefined⟩ :=
    MixedBodyWitness.stock_mixed_source_defined_witness word
  rw [lowered] at definedRun
  cases definedRun
  refine ⟨_,result,prepared,event,b,term,body,firstPoint source,lastPoint source,incomingRegisters (executions Arm.ArmState.default).1,lowered,scope,dominated,raw,checked,events,split,
    rfl,rfl,bodyLength,?_,?_,?_,families,source,initialDefined,finalDefined,(fun w => (executions w).1),?_,?_⟩
  · rfl
  · rfl
  · rfl
  · intro w
    have self : Refines (fun _ => True) ispec := fun _ _ _ _ world _ h => ⟨world,h,SameWorld.refl _ _⟩
    have stable : MRStable (fun _ => True) (fun _ cm _ => cm = (firstPoint source).2.2) := by intro _ _ _ _ _ h; exact h
    obtain ⟨b2,term2,body2,label,vb,prelude,split2,placed,semantic⟩ :=
      stock_lower_actual_select_omitted_body_steps lowered scope dominated events self
        (fun _ ends _ _ _ _ => ispec_terminal_no_next ends) stable (env := Clif.Env.empty) (cp := {funcs := []})
    obtain ⟨rfl,rfl,rfl⟩ := sourceBodySplit_unique split split2
    have zero := labelZero label vb placed
    subst label
    obtain ⟨final,w',run,steps,post⟩ := semantic families _ _ source _ w (executions w).1
    exact ⟨vb,prelude,final,w',placed,run,steps,post⟩
  · intro F ctx X w
    have stable : MRStable F (fun _ cm _ => cm = (firstPoint source).2.2) := by intro _ _ _ _ _ h; exact h
    obtain ⟨b2,term2,body2,label,vb,prelude,split2,placed,semantic⟩ :=
      stock_lower_actual_select_omitted_body_steps lowered scope dominated events (refines_csem F ctx X)
        (fun _ ends _ _ _ _ => csem_terminal_no_next ends) stable (env := Clif.Env.empty) (cp := {funcs := []})
    obtain ⟨rfl,rfl,rfl⟩ := sourceBodySplit_unique split split2
    have zero := labelZero label vb placed
    subst label
    obtain ⟨final,w',run,steps,post⟩ := semantic families _ _ source _ w (executions w).1
    obtain ⟨mapped,mapping,transported⟩ := stock_prepare_entry_star lowered scope raw
      (driverSem_csem F ctx X).toDriverSemG steps
    have zeroMap : sigmaOf result.code prepared.code 0 = some 0 := by
      dsimp only [Backend.Proof.PerEdgePrep.prepCheckAt] at accepted
      split at accepted
      · simp only [Bool.and_eq_true,decide_eq_true_eq] at accepted
        exact accepted.1.1.1
      · cases accepted
    have same := Option.some.inj (mapping.symm.trans zeroMap)
    subst mapped
    exact ⟨vb,prelude,final,w',placed,run,steps,transported,post⟩
end Backend.Stock.Proof.MixedBodyStepsWitnessDraft
