import StockPreparedSegments
import FV.Backend.Proof.StockCfgTotal
import FV.E2E.RegLevelDriverSem
namespace Backend.Stock.Proof.FallStepsDraft
open Backend.Proof Backend.Proof.Driver
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
/-- Real production terminators never report straight-line fallthrough. -/
theorem csem_terminal_no_next {F : BitVec 64 → Prop} {ctx : FnCtx} {X : ExtSem}
    {i : MInst} (terminal : i.isTerminator = true) {uses outs : List CV} {w w' : Arm.ArmState} :
    csem F ctx X i uses w ≠ some (outs,w',.next) := by
  intro run
  cases i <;> simp only [MInst.isTerminator,MInst.isBranch,MInst.isRet] at terminal
  all_goals try contradiction
  all_goals simp only [csem] at run
  all_goals try { simp only [Option.map_eq_some_iff,Prod.mk.injEq] at run; obtain ⟨_,_,_,_,bad⟩ := run; cases bad }
  all_goals try { cases run }
  all_goals cases uses with
  | nil => cases run
  | cons a rest =>
    cases rest with
    | cons b rest => cases run
    | nil =>
      dsimp only at run
      repeat' split at run
      all_goals cases run
/-- Primitive instruction-specification terminators likewise never fall through. -/
theorem ispec_terminal_no_next {i : MInst} (terminal : i.isTerminator = true)
    {uses outs : List CV} {w w' : Arm.ArmState} :
    ispec i uses w ≠ some (outs,w',.next) := by
  intro run
  cases i <;> simp only [MInst.isTerminator,MInst.isBranch,MInst.isRet] at terminal
  all_goals try contradiction
  all_goals cases uses with
  | nil => simp [ispec] at run
  | cons a rest =>
    cases rest with
    | cons b rest => simp [ispec] at run
    | nil => simp [ispec] at run <;> (repeat' split at run) <;> simp_all

/-- The actual terminal instruction derives every straight-line segment's
internal next-PC bounds. No end-index certificate is required. -/
theorem seqRun_fall_star_at {V W : Type} {vc : VCode} {edges : Array (Array (Array Reg))}
    {sem : ISem V W}
    (terminalSem : ∀ i,i.isTerminator = true → ∀ uses outs w w',sem i uses w ≠ some (outs,w',.next))
    {b : Nat} {vb : VBlock} (placed : vc.blocks[b]? = some vb)
    {last : MInst} (back : vb.insts.back? = some last) (ends : last.isTerminator = true) :
    ∀ {ms : List MInst} {k0 : Nat} {rho final : Nat → V} {w w' : W},
      SegAt vb k0 ms → seqRun sem ms rho w = some (.fall final w') →
      Star (VStepAt vc edges sem) (.run ⟨b,k0,rho,w⟩) (.run ⟨b,k0+ms.length,final,w'⟩) := by
  intro ms
  induction ms with
  | nil =>
    intro k0 rho final w w' segment run
    simp only [seqRun,Option.some.injEq,SeqEnd.fall.injEq] at run
    obtain ⟨rfl,rfl⟩ := run
    exact .refl _
  | cons i ms ih =>
    intro k0 rho final w w' segment run
    obtain ⟨ops,outs,world,operands,semantics,arity,rest⟩ := seqRun_cons_fall run
    have inside := (Array.getElem?_eq_some_iff.mp segment.head).1
    have next : k0+1 < vb.insts.size := by
      by_cases good : k0+1 < vb.insts.size
      · exact good
      exfalso
      have index : vb.insts.size-1 = k0 := by omega
      have lastAt := back
      rw [Array.back?_eq_getElem?,index,segment.head] at lastAt
      cases lastAt
      exact terminalSem _ ends _ _ _ _ semantics
    have first : VStepAt vc edges sem (.run ⟨b,k0,rho,w⟩)
        (.run ⟨b,k0+1,vdefUpd ops outs rho,world⟩) :=
      .step placed segment.head operands semantics arity (.next next)
    have after := ih segment.tail rest
    simp only [List.length_cons] at after ⊢
    rw [show k0+(ms.length+1) = k0+1+ms.length by omega]
    exact .step first after

/-- Original Stock CFG totality supplies terminal facts for any actually
executed straight-line segment, under the unchanged original source scope. -/
theorem stock_lower_fall_steps {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f)
    {V W : Type} {sem : ISem V W}
    (terminalSem : ∀ i,i.isTerminator = true → ∀ uses outs w w',sem i uses w ≠ some (outs,w',.next))
    {b k : Nat} {vb : VBlock} (placed : result.code.blocks[b]? = some vb)
    {ms : List MInst} (segment : SegAt vb k ms) {rho final : Nat → V} {w w' : W}
    (run : seqRun sem ms rho w = some (.fall final w')) :
    Star (VStepAt result.code result.edgeArgs sem) (.run ⟨b,k,rho,w⟩)
      (.run ⟨b,k+ms.length,final,w'⟩) := by
  obtain ⟨last,_,back,ends,_⟩ := (stock_lower_cfg lowered scope).blk b vb placed
  exact seqRun_fall_star_at terminalSem placed back ends segment run
end Backend.Stock.Proof.FallStepsDraft
