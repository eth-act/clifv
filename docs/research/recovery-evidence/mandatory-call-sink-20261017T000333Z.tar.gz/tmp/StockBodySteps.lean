import StockFallSteps
import FV.Backend.Proof.StockActualBodyRefines
import FV.Backend.Proof.StockBlockCode
namespace Backend.Stock.Proof.BodyStepsDraft
open Backend.Proof Backend.Proof.Driver FallStepsDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private theorem segment_of_factor {block : VBlock} {preludeCode code afterCode : Array MInst}
    (parts : block.insts = preludeCode ++ code ++ afterCode) : SegAt block preludeCode.size code.toList := by
  intro k hk
  have bound : k < code.size := by simpa using hk
  rw [parts,Array.append_assoc,Array.getElem?_append_right (by omega)]
  simp only [Nat.add_sub_cancel_left]
  rw [Array.getElem?_append_left bound]
  simp [bound]
/-- Actual source-body splitting supplies the SAME placed body segment and
all indexed execution bounds internally, including empty omitted bodies. -/
theorem stock_lower_body_fall_steps {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f)
    {event : BlockScanEvent} (events : event ∈ result.blockScans.toList)
    {b : Clif.Block} {term : ScanRecord} {body : BlockScan}
    (split : SourceBodySplit f event b term body) :
    ∃ (label : Nat) (vb : VBlock) (prelude afterCode : Array MInst),
      result.code.blocks[label]? = some vb ∧
      vb.insts = prelude ++ body.code.map (·.mapRegs
        (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1))) ++ afterCode ∧
      ∀ (V W : Type) (sem : ISem V W),
        (∀ i,i.isTerminator = true → ∀ uses outs w w',sem i uses w ≠ some (outs,w',.next)) →
        ∀ (rho final : Nat → V) (w w' : W),
        seqRun sem (body.code.toList.map (·.mapRegs
          (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1)))) rho w = some (.fall final w') →
        Star (VStepAt result.code result.edgeArgs sem) (.run ⟨label,prelude.size,rho,w⟩)
          (.run ⟨label,prelude.size+body.code.size,final,w'⟩) := by
  obtain ⟨label,vb,prelude,afterCode,placed,code⟩ := stock_lower_block_scan_code lowered events
  let resolve := Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1)
  have factor : vb.insts = prelude ++ body.code.map (·.mapRegs resolve) ++
      (term.output.emitted.map (·.mapRegs resolve) ++ afterCode) := by
    simp only [code,split.code,Array.map_append,Array.append_assoc,resolve]
  refine ⟨label,vb,prelude,_,placed,factor,?_⟩
  intro V W sem terminalSem rho final w w' run
  have segment := segment_of_factor factor
  have executed := stock_lower_fall_steps lowered scope terminalSem placed segment
    (by simpa only [Array.toList_map,resolve] using run)
  simpa only [Array.length_toList,Array.size_map] using executed

/-- Lift discharged source/DFG/world body semantics into its actual installed
VCode block. The existing select/omission coverage boundary stays explicit;
it is an unfinished internal family obligation, never a source input filter. -/
theorem stock_lower_actual_select_omitted_body_steps {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    {event : BlockScanEvent} (events : event ∈ result.blockScans.toList)
    {F : BitVec 64 → Prop} {isem : Sem} (refines : Refines F isem)
    (terminalSem : ∀ i,i.isTerminator = true → ∀ uses outs w w',isem i uses w ≠ some (outs,w',.next))
    {MR : MemRelT} (stable : MRStable F MR) {env : Clif.Env} {cp : Clif.Program} :
    ∃ (b : Clif.Block) (term : ScanRecord) (body : BlockScan) (label : Nat) (vb : VBlock) (prelude : Array MInst),
      SourceBodySplit f event b term body ∧ result.code.blocks[label]? = some vb ∧
      ((∀ r ∈ body.records,SelectOrOmittedRecord f event.ctx event.block r) →
        ∀ s s',SourceSteps (IndexedSourceInst env cp f event.ctx event.block)
          ((List.range b.body.length).map (blockStart f event.block + ·)) s s' →
        ∀ rho w,GuardedScanRel f result event.ctx event.block MR event.output.state s rho w →
          ∃ final w',seqRun isem (body.code.toList.map (·.mapRegs
            (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1)))) rho w = some (.fall final w') ∧
            Star (VStepAt result.code result.edgeArgs isem) (.run ⟨label,prelude.size,rho,w⟩)
              (.run ⟨label,prelude.size+body.code.size,final,w'⟩) ∧
            GuardedScanRel f result event.ctx event.block MR term.output.state s' final w') := by
  obtain ⟨b,term,body,split,semantic⟩ := stock_lower_actual_select_omitted_body_refines lowered scope dominated events refines stable
    (env := env) (cp := cp)
  obtain ⟨label,vb,prelude,afterCode,placed,code,execution⟩ := stock_lower_body_fall_steps lowered scope events split
  refine ⟨b,term,body,label,vb,prelude,split,placed,?_⟩
  intro families s s' source rho w related
  obtain ⟨final,w',run,post⟩ := semantic families s s' source rho w related
  exact ⟨final,w',run,execution _ _ isem terminalSem _ _ _ _ run,post⟩
end Backend.Stock.Proof.BodyStepsDraft
