from pathlib import Path
import json,hashlib,re,datetime,tarfile,shutil,subprocess
root=Path('/home/lee/clifv/.worktrees/driver-proof-resume');docs=root/'docs/research';prefix='stock-body-compose'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
now=datetime.datetime.now(datetime.timezone.utc);stamp=now.strftime('%Y%m%dT%H%M%SZ')
batch=json.loads(Path('/tmp/'+prefix+'-batch.json').read_text());old=json.loads((docs/'stock-try-prepared-scratch.json').read_text())
log=Path('/tmp/'+prefix+'-combined-axioms.log').read_text()
sets={m.group(1):sorted(x.strip() for x in m.group(2).split(',') if x.strip()) for m in re.finditer(r"'([^']+)' depends on axioms:\s*\[([^]]*)\]",log)}
for m in re.finditer(r"'([^']+)' does not depend on any axioms",log):sets[m.group(1)]=[]
for n,a in old['normal_audit']['sets'].items():assert sorted(a)==sets[n],n
assert len(sets)==len(old['normal_audit']['sets'])+len(batch['public_roots'])+len(batch['models'])
allowed={'propext','Classical.choice','Quot.sound'}
for n in batch['public_roots']+batch['models']:assert set(sets[n])<=allowed,n
constants=[json.loads(line.split('DELIVERY_CONSTANT ',1)[1]) for line in Path('/tmp/'+prefix+'-all-constants.log').read_text().splitlines() if line.startswith('DELIVERY_CONSTANT ')]
assert constants
for n,a in constants:assert set(a)<=allowed,n
mods={}
for m in batch['modules']:
 p=Path('/tmp')/m;check=json.loads(p.with_suffix('.check.json').read_text());assert check['actual_exit']==0
 rec={}
 for key,ext in [('source','.lean'),('object','.olean'),('log','.log'),('check','.check.json')]:
  f=p.with_suffix(ext);rec[key]=str(f);rec[key+'_sha256']=sha(f)
 for k in ['source','object','log']:assert rec[k+'_sha256']==check[k+'_sha256']
 assert not re.search(r'\b(sorry|admit|axiom|trace_state|native_decide)\b',p.with_suffix('.lean').read_text()),m
 mods[m]=rec
for audit in [prefix+'-combined-axioms',prefix+'-all-constants']:
 p=Path('/tmp')/audit;check=json.loads(p.with_suffix('.check.json').read_text());assert check['actual_exit']==0
 for k,ext in [('source','.lean'),('object','.olean'),('log','.log')]:assert sha(p.with_suffix(ext))==check[k+'_sha256']
prior={}
for name in ['source-execution-x','try-source','try-context','try-rule','try-rets','try-reservation','try-outgoing','try-values','try-emitted','try-machine','try-got','try-indirect','try-rename','try-resolved','try-gap','try-got-rename','try-normal-frame','try-metadata','source-index','try-normal-vector','try-critical-normal','source-erase','source-origin','try-live-frame','try-normal-values','try-normal-copy','try-normal-control','try-normal-entry','try-placement','try-edge-step','try-prepared']:
 d=json.loads((docs/f'stock-{name}-scratch.json').read_text())
 for m,rec in d['modules'].items():
  for k in ['source','object','log']:assert sha(rec[k])==rec[k+'_sha256'],(m,k)
  prior[m]=rec
assert len(prior)==213
freeze=json.loads(Path('/tmp/stock-coherent-build-inputs.json').read_text())
for group in ['source_sha256','validation_script_sha256']:
 for p,h in freeze[group].items():assert sha(root/p)==h,p
imports=json.loads(Path('/tmp/stock-try-rule-inputs.json').read_text())
for m,r in imports['modules'].items():
 assert sha(r['snapshot'])==r['object_sha256'],(m,'snapshot')
 assert sha(r['source'])==r['source_sha256'],(m,'source')
progress=json.loads(Path('/tmp/stock-pr246-gates-progress.json').read_text());progress.pop('completed_phases',None)
live=subprocess.check_output(['ps','-p','3247835','-o','pid,stat,etime,args'],text=True)
remaining=list(old['remaining_checklist']);remaining.append({'requirement':'Actual ordinary body smallstep execution and source/DFG/world composition','state':'PROGRESS: universal production/spec terminal non-fallthrough and ANY falling placed segment indexed VCode simulation, with PC bounds derived from actual Stock CFG rather than caller certificates; actual body splitting/placement and SAME fragment uniqueness. Existing select/omission source body semantics now lift to actual VStepAt. COMPLETE mixed ignored-load/select witness for all input words and all production F/context/external/world retains initial/final source-definedness, initial/final DFG/value/memory relation, loaded9/selected7-or9, actual raw body steps and SAME prepared-body steps. This is body-boundary execution AFTER entry materialization; all uncovered source families/effects/sinking, initial entry/body-to-branch/function/whole-driver simulation AND completeness and production cutover remain OPEN. Generic machine lift covers all falling machine fragments, not all source rule semantics. Near-critical and older whole-area GOT root-specific witness gates remain pending.'})
counts={'modules':len(mods),'public_roots':len(batch['public_roots']),'models':len(batch['models']),'combined_roots_models':len(sets),'previous_preserved':len(old['normal_audit']['sets']),'all_new_module_constants':len(constants),'previous_modules_hashes_preserved':len(prior)}
receipt={'utc':now.isoformat(),'goal':'Original full #140 ACTIVE/INCOMPLETE; production LEGACY','scope':'Scratch actual body smallstep/source composition; full original goal unchanged','delivery_target':'roughly8 substantive validated squash merges/day; coherent semantic batches, remote backups and cleanup','modules':mods,'public_roots':batch['public_roots'],'models':batch['models'],'counts':counts,'normal_audit':{'path':'/tmp/'+prefix+'-combined-axioms.log','sha256':sha('/tmp/'+prefix+'-combined-axioms.log'),'sets':sets},'all_constant_audit':{'path':'/tmp/'+prefix+'-all-constants.log','sha256':sha('/tmp/'+prefix+'-all-constants.log'),'count':len(constants),'all_standard_only':True},'previous_modules_hashes_preserved':list(prior),'canonical2246_source_and_script_freeze_preserved':True,'import_generation':{'source_and_snapshot_hashes_checked':len(imports['modules']),'manifest_sha256':sha('/tmp/stock-try-rule-inputs.json'),'shared_cache_writes':False,'Link_same_frozen_source_repair':'/tmp/stock-body-compose-import-refresh.json','new_frozen_source_modules':imports['body_extension']},'nonvacuity':{'complete_mixed_body':'All word64 inputs; actual original lower/scope/dominance, actual raw/checked preparation, initial/final source definedness and initial/final DFG/value/memory relations, real ignored load binds9 and selected value is select(word,7,9), actual ispec body sequence and indexed VCode execution. All production F/FnCtx/ExtSem/world likewise run actual csem body and SAME prepared body, exact endpoint register/world preservation. Starts after entry materialization, not function entry; physical allocation is not proved for this mixed witness here.','prior_complete_pipelines':'All213 prior post-source modules and complete ordinary3/critical2 pipeline/source/call/prepared witnesses preserved byte-for-byte','near_critical':'PENDING one larger kernel after active heavy lane frees; old8GiB failures retained','older_whole_area_GOT':'PENDING old root-specific contract/non-vacuity; local-area witness not substituted'},'fidelity':'Original inputs and old theorem variants/axiom sets unchanged. Existing SelectOrOmittedRecord is an explicitly incomplete internal family-dispatch obligation, never a new compiler acceptance predicate. Machine fall-step theorem is universal across actual falling fragments; source coverage remains select/omission. No caller PC end-bound added. Actual split uniqueness prevents accidentally substituting different scan fragments.','MCP':'Deferred until coherent integration; no new calls','active_exact_PR246_validation':progress,'live_worker':live,'remaining_checklist':remaining}
(docs/(prefix+'-scratch.json')).write_text(json.dumps(receipt,indent=2)+'\n')
text=f'''Actual ordinary-body VCode steps and source/DFG/world composition — {now.isoformat()}

{len(mods)} scratch modules / {len(batch['public_roots'])} public roots: actual8GiB kernel PASS. Cumulative{len(sets)} root/model audit preserves ALL{len(old['normal_audit']['sets'])} prior exact axiom sets; ALL{len(constants)} new-module constants including private/generated/witness helpers STANDARD-only. ALL{len(prior)} prior scratch source/object/log hashes,2246canonical source/49-script freeze and{len(imports['modules'])} imported source/snapshot hashes preserved. Shared exact gate refreshed FV.E2E.Link object: SAME frozen canonical source rebuilt in isolated8GiB kernel PASS, old/new manifests and hash evidence retained; no shared-source/cache writes. Three body dependencies added from frozen sources.

Real production csem and primitive ispec terminators never fall through. Therefore every successful straight-line segment in actual returned Stock code lifts into actual indexed Star(VStepAt), deriving all next-PC bounds from the actual CFG's terminal instruction. No caller end-index certificate or new source acceptance condition. Empty omitted bodies are handled by reflexive execution. Actual SourceBodySplit supplies the SAME placed body segment with entry prefix and terminal/branch suffix retained; split uniqueness proves block/term/body identity across composition paths.

Existing actual select/omission source-body semantics now compose source steps, demanded-and-available value agreement, restricted DFG and memory/world relation with actual returned VCode steps. COMPLETE mixed ignored-load/emitted-select witness covers every input word and real initial/final source-definedness, initial/final DFG/value/memory relation, actual loaded9 and selected7-or9. Actual ispec sequence and VCode body execute; for EVERY production F/FnCtx/ExtSem/world, actual csem sequence/raw VCode body AND the SAME prepared body execute with exact endpoint registers/world. Actual raw/checked preparation derived under original scope. This witness begins at actual BODY boundary after entry materialization, and does not assert physical allocation or whole function execution.

The generic machine-segment lift covers all successfully falling machine fragments. Source-family composition still covers selects/omissions only: that explicit internal boundary is NOT a new accepted-input restriction and MUST be extended through all remaining source families/effects/sinking. Initial ABI entry/body-to-branch/source continuations, universal source/DFG/world/function/whole-driver simulation AND completeness and actual production cutover remain OPEN. Near-critical full compiler/machine/value observation remains pending after saved8GiB failures, one larger kernel AFTER delivery heavy lane frees. Older critical GOT WHOLE-RESULT-AREA root-specific contract/non-vacuity remains pending; local-area witness not substituted. Physical lowering is not an outgoing bound/projection proof; VM is not proof.

All remaining zero-return/sret/x8/width/handler/Try-critical matrix, shared payload/exception semantics, uncovered families/effects/sinking, original-input context/static/visitor/checker/fallback/physical totality, coherent integration/public/private/compiler/MCP/full build/crates/runtime/encoder/BOTH E2E identity-stage parity, compiler/checker/linker/generated consumers and FRESH COMPLETE comparison remain mandatory. Original inputs/old variants/exact axiom sets/accepted identities/successful stages/at least#179baseline preserved. Full#140 ACTIVE/INCOMPLETE; production LEGACY.

Same246supervisor3247835 confirmed LIVE at{progress.get('index')}/{progress.get('total')}; canonical1233457deliberately held/exclusive one-cache lease. No restart. Preserve old-head receipts, reconcile currentmain/shared assumptions/changed-deleted roots, rerun affected kernel/trust and ALL full/crates/runtime/encoder/BOTH E2E actual integrated-head gates before dependent squash246→247. Roughly8 substantive validated merges/day, coherent semantic batches/remote backups/cleanup. No merge/new tree/agent/MCP/heavyretry/other-project cleanup. Contributor52/71/task140 reread, Kev shared Arm/FP/ExtSem/csemU/Link/runtime/S10 boundaries preserved. Full evidence/checklist: stock-body-compose-scratch.json.
'''
(docs/(prefix+'-scratch.md')).write_text(text)
plan=root/'docs/plans/test-binary-alignment-recovery.md';plan.write_text(plan.read_text()+'\n\n'+text)
current=docs/'stock-full-goal-current.md';previous=current.read_text();Path('/tmp/'+prefix+'-full-goal-before.md').write_text(previous);lines=previous.splitlines()
for i,line in enumerate(lines):
 if line.startswith('| Source, DFG, world, block and whole-driver simulation |'):
  lines[i]='| Source, DFG, world, block and whole-driver simulation | Actual normal TryCall raw/prepared transitions with ordinary3+critical2 complete pipelines; actual ordinary-body source/DFG/world semantics for select/omission now compose with indexed VCode steps. Complete mixed ignored-load/select all-word/all-production-world body witness has raw/prepared execution, initial/final source-definedness and source-value agreement | Extend all source families/effects/sinking, compose ABI initial entry/body-to-branch/source continuations and universal DFG/world/function/whole-driver simulation AND completeness. Body/branch boundary is not function entry; production still legacy |'
 elif line.startswith('| CFG and preparation |'):
  lines[i]='| CFG and preparation | Original-input CFG/preparation totality; actual complete normal branch and body segments transport to SAME prepared code/register/world. Runtime history derives nonentry live/maps internally; actual terminal facts derive straight-line next-PC bounds | Integrate after frozen validation; finish remaining control ABI/static/visitor/dataflow/whole-driver obligations and every integrated-head/final gate |'
 elif line.startswith('| Public-root/kernel/transitive axiom audit |'):
  lines[i]=f'| Public-root/kernel/transitive axiom audit | Latest scratch cumulative{len(sets)} roots/models preserve{len(old["normal_audit"]["sets"])} prior exact sets;{len(constants)} new-module constants Std-only;213 prior module hashes and canonical source/script freeze preserved | Coherent integrated public/private/model/compiler audit, ONE bundled MCP and final production audit; scratch audit does not establish integration/cutover |'
current.write_text(f'Latest checkpoint {now.isoformat()}: [actual ordinary-body VCode/source composition](stock-body-compose-scratch.md). {len(mods)}modules/{len(batch["public_roots"])}public roots; cumulative{len(sets)}preserves{len(old["normal_audit"]["sets"])}prior exact sets;{len(constants)}new-module constants Std-only. Universal falling machine-segment lift derives PC bounds from actual CFG; source-body coverage remains select/omission. Complete mixed ignored-load/select all-word/all-production-world source/DFG/value/definedness and raw/prepared body witness PASS. Initial entry/body-to-branch/all source families/effects/whole-driver simulation AND completeness/cutover remain OPEN. Full#140 ACTIVE/INCOMPLETE; production LEGACY. Same246livegate{progress.get("index")}/{progress.get("total")}; no merge.\n\n'+'\n'.join(lines)+'\n')
files=[]
for rec in mods.values():files.extend(Path(rec[k]) for k in ['source','object','log','check'])
for name in [prefix+'-combined-axioms',prefix+'-all-constants',prefix+'-refines-audit']:
 for ext in ['.lean','.log','.olean','.check.json']:files.append(Path('/tmp')/(name+ext))
files.extend(p for p in Path('/tmp').glob(prefix+'*') if p.is_file())
files.extend(p for p in Path('/tmp/stock-body-compose-canonical').rglob('*') if p.is_file())
files.extend([Path('/tmp/stock-try-rule-inputs.json'),Path('/tmp/stock-try-reservation-check.py'),Path('/tmp/stock-source-erase-restore.py'),docs/(prefix+'-scratch.json'),docs/(prefix+'-scratch.md'),docs/'stock-delivery-main-drift.json',plan,current])
files=list(dict.fromkeys(files));archive=Path('/home/lee/.clifv-recovery')/(stamp+'-body-compose')/'checkpoint.tar.gz';archive.parent.mkdir(parents=True)
with tarfile.open(archive,'w:gz',compresslevel=1) as t:
 for p in files:t.add(p,arcname=str(p).lstrip('/'),recursive=False)
with tarfile.open(archive,'r:gz') as t:
 for p in files:assert t.extractfile(str(p).lstrip('/')).read()==p.read_bytes(),p
snapshot=Path('/tmp/stock-try-rule-inputs');size=sum(p.stat().st_size for p in snapshot.rglob('*') if p.is_file());shutil.rmtree(snapshot)
backup={'utc':now.isoformat(),'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(files),'all_members_byte_verified':True,'previous_remote_backup':json.loads((docs/'stock-try-prepared-backup.json').read_text())['remote'],'cleanup':{'duplicate_dependency_snapshot_removed':True,'bytes_reclaimed':size,'all_unique_sources_objects_logs_checks_audits_import_repairs_preserved':True,'one_shared_warm_cache_retained':True,'other_projects_touched':False,'free_bytes':shutil.disk_usage(root).free}}
(docs/(prefix+'-backup.json')).write_text(json.dumps(backup,indent=2)+'\n');Path('/tmp/'+prefix+'-archive-path').write_text(str(archive));print(json.dumps({'counts':counts,'archive':str(archive),'cleanup':backup['cleanup'],'gate':{k:progress.get(k) for k in ['state','index','total','module']}},indent=2))
