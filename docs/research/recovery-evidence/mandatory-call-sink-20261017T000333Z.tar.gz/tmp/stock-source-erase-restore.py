from pathlib import Path
import hashlib,json
p=Path('/tmp/stock-try-rule-inputs.json');d=json.loads(p.read_text());count=0
for m,r in d['modules'].items():
 src=Path(r['object']);dest=Path(r['snapshot'])
 if dest.exists():continue
 data=src.read_bytes();assert hashlib.sha256(data).hexdigest()==r['object_sha256'],m
 dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data);count+=len(data)
print('verified restored',len(d['modules']),'modules;',count,'bytes')
