import StockSourceExecutingTry
import StockSourceTryHandlerCoverage
import FV.Backend.Proof.PerEdgeSpillEntryFixture
namespace Backend.Stock.Proof.SourceExecutingTryWitnessDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open SourceExecutionXCoreDraft SourceExecutionXSourceDraft SourceExecutingTryDraft TryBranchRecordsDraft
open SourceExecutionGraphDraft SourceTryHandlerCoverageDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
attribute [local irreducible] Stock.lower Stock.runTerm Isle.Aarch64.program
private def function := SpillEntryFixture.function
private def program (indirect : Bool) : Clif.Program := {funcs := [function indirect]}
private def memory : Clif.Mem := {Clif.Mem.empty with symbols := fun n => if n = "callee" then some 4096 else none}
private def exception : Clif.Exn := {catches := fun n => n == 7,payload := [⟨.i64,42⟩,⟨.i64,99⟩]}
private def environment (indirect handler : Bool) : Clif.XEnv := {
  extern := fun n => if n = "callee" then some (fun _ mem =>
    if handler then .unwound exception mem else .returned [⟨.i64,17⟩] mem) else none
  names := ["callee"]
  sigOf := fun n => if n = "callee" then some (function indirect).sig else none }
private def initial (indirect : Bool) : Clif.State := {
  frame := {
    func := function indirect
    regs := Clif.Regs.empty
    slots := []
    body := ((function indirect).blocks[0]!).body
    term := ((function indirect).blocks[0]!).term }
  callers := []
  mem := memory }
private def first (indirect : Bool) : Clif.State := {
  initial indirect with frame := {(initial indirect).frame with
    regs := Clif.Regs.empty.set 0 ⟨.i64,9⟩
    body := if indirect then [⟨[1],.iconst .i64 4096⟩] else []} }
private def current (indirect : Bool) : Clif.State :=
  if indirect then {first indirect with frame := {(first indirect).frame with
    regs := (first indirect).frame.regs.set 1 ⟨.i64,4096⟩,body := []}} else first indirect
private def afterTry (indirect handler : Bool) : Clif.XState := {
  s := {current indirect with frame := {(current indirect).frame with
    regs := if handler then ((current indirect).frame.regs.set 7 ⟨.i64,42⟩).set 8 ⟨.i64,99⟩
      else (current indirect).frame.regs.set 7 ⟨.i64,17⟩
    term := if handler then .jump ⟨2,[7,8,0]⟩ else .jump ⟨1,[7,0]⟩} }
  tries := [] }
private def afterJump (indirect handler : Bool) : Clif.XState :=
  match Clif.stepX (environment indirect handler) (program indirect) (afterTry indirect handler) with
  | .next xs => xs
  | _ => (current indirect).toX
private def source : Array (Array Nat) := #[#[2,1],#[],#[]]
private theorem computed (indirect : Bool) : stockSourceTable (function indirect) = .ok source := by cases indirect <;> cbv
private theorem entered (indirect : Bool) :
    Clif.initState (program indirect) (function indirect).name [] memory = .ok (initial indirect) := by cases indirect <;> rfl
private theorem setup (indirect handler : Bool) :
    XRunPrefix (environment indirect handler) (program indirect) (initial indirect).toX (current indirect).toX := by
  have firstStep : Clif.stepX (environment indirect handler) (program indirect) (initial indirect).toX =
      .next (first indirect).toX := by cases indirect <;> cases handler <;> rfl
  cases indirect with
  | false => exact .next firstStep (.refl _)
  | true =>
    refine .next firstStep (.next ?_ (.refl _))
    cases handler <;> rfl
private theorem actual (indirect handler : Bool) :
    Clif.stepX (environment indirect handler) (program indirect) (current indirect).toX =
      .next (afterTry indirect handler) := by cases indirect <;> cases handler <;> rfl
private theorem jumping (indirect handler : Bool) :
    Clif.stepX (environment indirect handler) (program indirect) (afterTry indirect handler) =
      .next (afterJump indirect handler) := by cases indirect <;> cases handler <;> rfl
private theorem complete (indirect handler : Bool) :
    Clif.runWithX (environment indirect handler) (program indirect) (function indirect).name [] memory
      (if indirect then 6 else 5) = .returned [⟨.i64,if handler then 42 else 17⟩] memory := by
  cases indirect <;> cases handler <;> rfl
/-- Complete original direct/indirect TryCall compiler pipelines exercise the
new actual-execution→branch-schedule/VCode bridge and finish both real normal
and tagged exceptional source paths, with live ordinary and fresh payload args. -/
theorem stock_complete_reached_try_schedule_witness (indirect handler : Bool) :
    ∃ (out : SpillEntryFixture.Output indirect) (label bi : Nat) (b : Clif.Block)
      (ctx : Ctx) (input : State) (ti : Nat) (branch : BranchEmission) (block : VBlock) (last : MInst),
      LowerScope (function indirect) ∧ Dominated (function indirect) ∧ ArityOk (function indirect) ∧
      Stock.lower (function indirect) = .ok out.result ∧
      prepareAt out.result.code out.result.edgeArgs = .ok out.prepared ∧
      out.rf = spillAllocAt out.prepared.code out.prepared.edges ∧
      checkAllocAt out.prepared.code out.prepared.edges out.rf = .ok () ∧
      lowerRFunc out.prepared.code out.rf = .ok out.af ∧
      (function indirect).blocks[bi]? = some b ∧ b.term = (current indirect).frame.term ∧
      out.result.order.nodes[label]? = some (.original bi) ∧
      emitBranch ctx (function indirect) b.term bi ti out.result.order.successors[label]! input = .ok branch ∧
      branch.step ∈ out.result.schedule.toList ∧ branch.step.block = bi ∧ branch.step.inst = ti ∧
      branch.step.decision = .emitted ∧ branch.step.after = branch.state ∧ branch.step.emitted = branch.code ∧
      (∃ call info,branch.code.back? = some (.tryCall call info)) ∧
      out.result.code.blocks[label]? = some block ∧ block.insts.back? = some last ∧
      last.isTerminator = true ∧ last.targets = out.result.order.successors[label]!.toList ∧
      Clif.stepX (environment indirect handler) (program indirect) (current indirect).toX = .next (afterTry indirect handler) ∧
      SourceXLocated (function indirect) source (afterTry indirect handler) ∧
      SourceXLocated (function indirect) source (afterJump indirect handler) ∧
      Clif.runWithX (environment indirect handler) (program indirect) (function indirect).name [] memory
        (if indirect then 6 else 5) = .returned [⟨.i64,if handler then 42 else 17⟩] memory := by
  obtain ⟨out⟩ := SpillEntryFixture.try_fixture indirect
  have kind : (current indirect).frame.term.isTry = true := by cases indirect <;> rfl
  have same : (current indirect).frame.func = function indirect := by cases indirect <;> rfl
  have empty : (current indirect).frame.body = [] := by cases indirect <;> rfl
  obtain ⟨label,bi,b,ctx,input,ti,branch,block,last,atSource,term,node,emitted,scheduled,blockStep,index,
      decision,state,code,placed,atLast,terminal,targets⟩ :=
    stock_lower_xexecuting_try_scheduled out.lowered out.scope (entered indirect) (setup indirect handler) same empty kind
  have sourceKind : b.term.isTry = true := by rw [term]; exact kind
  have shape := stock_emitBranch_try_kind sourceKind emitted
  have during := stock_source_xrunPrefix_original_located (computed indirect) (entered indirect) (setup indirect handler)
  have after := stock_source_stepX_original_located (computed indirect) during (actual indirect handler)
  have target := stock_source_stepX_original_located (computed indirect) after (jumping indirect handler)
  exact ⟨out,label,bi,b,ctx,input,ti,branch,block,last,out.scope,out.dominated,out.arity,out.lowered,
    out.prepare,out.fallback,out.accepted,out.physical,atSource,term,node,emitted,scheduled,blockStep,index,
    decision,state,code,shape,placed,atLast,terminal,targets,actual indirect handler,after,target,complete indirect handler⟩
private def table : Clif.ExnTable := {
  sig := 0,normal := ⟨1,[.ret 0,.val 0]⟩,items := [.tag 7 ⟨2,[.exn 0,.exn 1,.val 0]⟩] }
/-- The same complete original-condition compiler pipelines inhabit actual
caught-handler coverage, including live ordinary and two fresh payload arguments.
The actual handler jump and its Stock original node are derived internally. -/
theorem stock_complete_reached_handler_node_witness (indirect : Bool) :
    ∃ (out : SpillEntryFixture.Output indirect) (bc : Clif.BlockCall) (target label : Nat) (b : Clif.Block),
      LowerScope (function indirect) ∧ Dominated (function indirect) ∧ ArityOk (function indirect) ∧
      Stock.lower (function indirect) = .ok out.result ∧
      prepareAt out.result.code out.result.edgeArgs = .ok out.prepared ∧
      out.rf = spillAllocAt out.prepared.code out.prepared.edges ∧
      checkAllocAt out.prepared.code out.prepared.edges out.rf = .ok () ∧
      lowerRFunc out.prepared.code out.rf = .ok out.af ∧
      Clif.catchIn (current indirect).frame table exception = some (.ok (afterTry indirect true).s.frame) ∧
      (afterTry indirect true).s.frame.term = .jump bc ∧
      (function indirect).blocks[target]? = some b ∧ (function indirect).block? bc.block = some b ∧
      out.result.order.nodes[label]? = some (.original target) ∧
      SourceXLocated (function indirect) source (afterJump indirect true) ∧
      Clif.runWithX (environment indirect true) (program indirect) (function indirect).name [] memory
        (if indirect then 6 else 5) = .returned [⟨.i64,42⟩] memory := by
  obtain ⟨out⟩ := SpillEntryFixture.try_fixture indirect
  have same : (current indirect).frame.func = function indirect := by cases indirect <;> rfl
  have empty : (current indirect).frame.body = [] := by cases indirect <;> rfl
  have kind : (∃ fn xs,(current indirect).frame.term = .tryCall fn xs table) ∨
      (∃ callee xs,(current indirect).frame.term = .tryCallIndirect callee xs table) := by
    cases indirect with
    | false => exact .inl ⟨0,[],rfl⟩
    | true => exact .inr ⟨1,[],rfl⟩
  have caught : Clif.catchIn (current indirect).frame table exception = some (.ok (afterTry indirect true).s.frame) := by
    cases indirect <;> rfl
  obtain ⟨bc,target,label,b,jump,atBlock,found,node⟩ :=
    stock_lower_xcaught_handler_node out.lowered out.scope (entered indirect) (setup indirect true) same empty kind caught
  have located := stock_source_xrunPrefix_original_located (computed indirect) (entered indirect) (setup indirect true)
  have after := stock_source_stepX_original_located (computed indirect) located (actual indirect true)
  have handler := stock_source_stepX_original_located (computed indirect) after (jumping indirect true)
  exact ⟨out,bc,target,label,b,out.scope,out.dominated,out.arity,out.lowered,out.prepare,out.fallback,
    out.accepted,out.physical,caught,jump,atBlock,found,node,handler,complete indirect true⟩
end Backend.Stock.Proof.SourceExecutingTryWitnessDraft
