import StockSourceExecutingTry
namespace Backend.Stock.Proof.SourceTryHandlerCoverageDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open SourceExecutionGraphDraft SourceExecutionXCoreDraft SourceExecutionXSourceDraft
open SourceExecutionUnwindDraft SourceExecutingTryDraft CallSourceCoverageDraft
private theorem caught_member {et : Clif.ExnTable} {e : Clif.Exn} {d : Clif.TryDest}
    (found : et.catch? e = some d) : d ∈ et.handlers := by
  obtain ⟨item,member,selected⟩ := List.exists_of_findSome?_eq_some found
  apply List.mem_filterMap.mpr
  refine ⟨item,member,?_⟩
  cases item with
  | context v => cases selected
  | default target => cases selected; rfl
  | tag n target =>
    dsimp only at selected
    split at selected
    · cases selected; rfl
    · cases selected
private theorem catch_destination {fr next : Clif.Frame} {et : Clif.ExnTable} {e : Clif.Exn}
    (run : Clif.catchIn fr et e = some (.ok next)) :
    ∃ (d : Clif.TryDest) (bc : Clif.BlockCall),d ∈ et.handlers ∧
      bc.block = d.block ∧ next.term = .jump bc := by
  unfold Clif.catchIn at run
  cases found : et.catch? e with
  | none => simp only [found,Option.map_none] at run; cases run
  | some d =>
    simp only [found,Option.map_some,Option.some.injEq,Opt.Res.bind_eq_ok,Opt.Res.ofOption_eq_ok,Opt.Res.pure_eq_ok] at run
    obtain ⟨bc,handler,regs,bound,equality⟩ := run
    cases equality
    exact ⟨d,bc,caught_member found,stock_source_tryHandler_block handler,rfl⟩
/-- A real caught handler of an actually reached TryCall has a reachable
original output node. Its actual jump, handler selection, first matching source
block and Stock node are derived; no handler/reachability certificate is supplied. -/
theorem stock_lower_xcaught_handler_node {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f)
    {env : Clif.XEnv} {p : Clif.Program} {name : String} {args : List Clif.Val} {mem : Clif.Mem}
    {initial : Clif.State} {current : Clif.XState} (entry : Clif.initState p name args mem = .ok initial)
    (execution : XRunPrefix env p initial.toX current) (function : current.s.frame.func = f)
    (empty : current.s.frame.body = []) {et : Clif.ExnTable}
    (kind : (∃ fn xs,current.s.frame.term = .tryCall fn xs et) ∨
      (∃ callee xs,current.s.frame.term = .tryCallIndirect callee xs et))
    {e : Clif.Exn} {caught : Clif.Frame} (run : Clif.catchIn current.s.frame et e = some (.ok caught)) :
    ∃ (bc : Clif.BlockCall) (target label : Nat) (b : Clif.Block),
      caught.term = .jump bc ∧ f.blocks[target]? = some b ∧ f.block? bc.block = some b ∧
      result.order.nodes[label]? = some (.original target) := by
  obtain ⟨source,computed,size,bounds⟩ := stock_blockOrder_sourceTable (stock_lower_order lowered)
  have located := stock_source_xrunPrefix_original_located computed entry execution
  have isTry : current.s.frame.term.isTry = true := by
    rcases kind with ⟨fn,xs,term⟩ | ⟨callee,xs,term⟩
    all_goals rw [term]; rfl
  obtain ⟨bi,original,block,reached,term,body⟩ :=
    stock_source_executing_try_terminator located.1 function empty isTry
  obtain ⟨d,bc,member,target,jump⟩ := catch_destination run
  have destination : (bc.block,d.args) ∈ destinations original.term := by
    rw [term,target]
    rcases kind with ⟨fn,xs,actual⟩ | ⟨callee,xs,actual⟩
    all_goals
      rw [actual]
      exact List.mem_map.mpr ⟨d,List.mem_append_left _ member,rfl⟩
  obtain ⟨index,b,atBlock,found,edge,reachable⟩ := stock_source_destination_reachable computed block reached destination
  obtain ⟨label,node⟩ := stock_lower_reachable_original_node lowered scope computed reachable
  exact ⟨bc,index,label,b,jump,atBlock,found,node⟩
end Backend.Stock.Proof.SourceTryHandlerCoverageDraft
