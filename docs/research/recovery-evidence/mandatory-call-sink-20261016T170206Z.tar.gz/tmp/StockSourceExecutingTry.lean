import StockTrySchedule
import StockSourceExecutionXSource
import StockCallSourceCoverage
import FV.Backend.Proof.StockTryCfg
namespace Backend.Stock.Proof.SourceExecutingTryDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open SourceExecutionGraphDraft SourceExecutionXCoreDraft SourceExecutionXSourceDraft CallSourceCoverageDraft TryScheduleDraft
/-- An actual executing TryCall terminator belongs to a reachable original
block, rather than to the pending jump of an earlier normal/exception return. -/
theorem stock_source_executing_try_terminator {f : Clif.Function} {source : Array (Array Nat)}
    {fr : Clif.Frame} (located : FrameLocated f source fr) (function : fr.func = f)
    (empty : fr.body = []) (isTry : fr.term.isTry = true) :
    ∃ (bi : Nat) (b : Clif.Block),f.blocks[bi]? = some b ∧ Prep.Reach source bi ∧
      b.term = fr.term ∧ fr.body = [] := by
  obtain ⟨bi,b,block,reached,suffix,control⟩ := located function
  rcases control with original | ⟨body,bc,args,jump,member⟩
  · exact ⟨bi,b,block,reached,original.symm,empty⟩
  · rw [jump] at isTry
    cases isTry
/-- Every actually reached original TryCall has its emitted branch record in
the final schedule and its assembled final-alias-resolved terminal in VCode.
The real source position, original node and emission are derived internally. -/
theorem stock_lower_xexecuting_try_scheduled {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f)
    {env : Clif.XEnv} {p : Clif.Program} {name : String} {args : List Clif.Val} {mem : Clif.Mem}
    {initial : Clif.State} {current : Clif.XState} (entry : Clif.initState p name args mem = .ok initial)
    (execution : XRunPrefix env p initial.toX current) (function : current.s.frame.func = f)
    (empty : current.s.frame.body = []) (isTry : current.s.frame.term.isTry = true) :
    ∃ (label bi : Nat) (b : Clif.Block) (ctx : Ctx) (input : State) (ti : Nat)
      (branch : BranchEmission) (block : VBlock) (last : MInst),
      f.blocks[bi]? = some b ∧ b.term = current.s.frame.term ∧
      result.order.nodes[label]? = some (.original bi) ∧
      emitBranch ctx f b.term bi ti result.order.successors[label]! input = .ok branch ∧
      branch.step ∈ result.schedule.toList ∧ branch.step.block = bi ∧ branch.step.inst = ti ∧
      branch.step.decision = .emitted ∧ branch.step.after = branch.state ∧ branch.step.emitted = branch.code ∧
      result.code.blocks[label]? = some block ∧ block.insts.back? = some last ∧
      last.isTerminator = true ∧ last.targets = result.order.successors[label]!.toList := by
  obtain ⟨source,computed,size,bounds⟩ := stock_blockOrder_sourceTable (stock_lower_order lowered)
  have located := stock_source_xrunPrefix_original_located computed entry execution
  obtain ⟨bi,b,sourceBlock,reached,term,body⟩ := stock_source_executing_try_terminator located.1 function empty isTry
  obtain ⟨label,node⟩ := stock_lower_reachable_original_node lowered scope computed reached
  have original : f.blocks[bi]! = b := by simp only [getElem!_def,sourceBlock,Option.getD_some]
  have kind : f.blocks[bi]!.term.isTry = true := by rw [original,term]; exact isTry
  obtain ⟨ctx,input,ti,branch,emitted,scheduled,biStep,index,decision,state,code⟩ :=
    stock_lower_try_branch_scheduled lowered node kind
  rw [original] at emitted
  obtain ⟨block,last,placed,atLast,terminal,targets⟩ := stock_lower_try_targets lowered node kind
  exact ⟨label,bi,b,ctx,input,ti,branch,block,last,sourceBlock,term,node,emitted,scheduled,biStep,index,
    decision,state,code,placed,atLast,terminal,targets⟩
end Backend.Stock.Proof.SourceExecutingTryDraft
