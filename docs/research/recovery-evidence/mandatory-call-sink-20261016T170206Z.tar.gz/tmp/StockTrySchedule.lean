import StockTryBranchRecords
import FV.Backend.Proof.StockNodeCoverage
namespace Backend.Stock.Proof.TryScheduleDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64 TryBranchRecordsDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
attribute [local irreducible] Stock.runTerm lowerBlockCore branchArgs emitBranch collectOutgoing scanBlock
private theorem node_core {ctx : Ctx} {ranges : Array (Nat × Nat)} {order : Order}
    {f : Clif.Function} {params : List Nat} {label bi : Nat} {input output : DriverState}
    (node : order.nodes[label]! = .original bi)
    (run : lowerNode ctx ranges order f params label input = .ok output) :
    ∃ (data : Backend.V) (core : LoweredBlockCore),
      lowerBlockCore ctx order f f.blocks[bi]! bi ranges[bi]!.1 ranges[bi]!.2
        data order.successors[label]! input.state = .ok core ∧
      output.schedule = (recordCore input core bi ranges[bi]!.2).schedule := by
  unfold lowerNode at run
  simp only [node] at run
  repeat' first
    | (solve | cases run)
    | simp only [bind,Except.bind,pure,Except.pure] at run
    | split at run
  all_goals cases run; exact ⟨_,_,by assumption,rfl⟩
private theorem node_mono {ctx : Ctx} {ranges : Array (Nat × Nat)} {order : Order}
    {f : Clif.Function} {params : List Nat} {label : Nat} {input output : DriverState}
    {step : Step} (run : lowerNode ctx ranges order f params label input = .ok output)
    (member : step ∈ input.schedule.toList) : step ∈ output.schedule.toList := by
  unfold lowerNode at run
  dsimp only at run
  repeat' first
    | (solve | cases run)
    | simp only [bind,Except.bind,pure,Except.pure] at run
    | split at run
  all_goals
    cases run
    first | exact member | exact stock_recordCore_schedule_preserved member
private theorem nodes_mono {ctx : Ctx} {ranges : Array (Nat × Nat)} {order : Order}
    {f : Clif.Function} {params labels : List Nat} {input output : DriverState} {step : Step}
    (run : labels.foldlM (fun d k => lowerNode ctx ranges order f params k d) input = .ok output)
    (member : step ∈ input.schedule.toList) : step ∈ output.schedule.toList := by
  induction labels generalizing input with
  | nil => cases run; exact member
  | cons label rest ih =>
    rw [List.foldlM_cons] at run
    obtain ⟨middle,call,rest⟩ := Except.bind_ok run
    exact ih rest (node_mono call member)
private theorem origin {f : Clif.Function} {result : Result} (run : Stock.lower f = .ok result) :
    ∃ (ranges : Array (Nat × Nat)) (params : List Nat) (starting finishing : DriverState),
      (Array.range result.order.nodes.size).reverse.toList.foldlM
        (fun d k => lowerNode result.ctx ranges result.order f params k d) starting = .ok finishing ∧
      result.schedule = finishing.schedule := by
  unfold Stock.lower at run
  dsimp only at run
  repeat' first
    | (solve | cases run)
    | simp only [bind,Except.bind,pure,Except.pure] at run
    | split at run
  cases run
  exact ⟨_,_,_,_,by assumption,rfl⟩
/-- Every actual original TryCall node has its real separately emitted branch
step in the final whole-driver schedule, with real source slot, state, and code.
No body-record emission premise or schedule-membership certificate is supplied. -/
theorem stock_lower_try_branch_scheduled {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) {label bi : Nat}
    (node : result.order.nodes[label]? = some (.original bi))
    (isTry : f.blocks[bi]!.term.isTry = true) :
    ∃ (ctx : Ctx) (input : State) (ti : Nat) (branch : BranchEmission),
      emitBranch ctx f f.blocks[bi]!.term bi ti result.order.successors[label]! input = .ok branch ∧
      branch.step ∈ result.schedule.toList ∧ branch.step.block = bi ∧ branch.step.inst = ti ∧
      branch.step.decision = .emitted ∧ branch.step.after = branch.state ∧
      branch.step.emitted = branch.code := by
  obtain ⟨ranges,params,starting,finishing,folded,schedule⟩ := origin run
  have bound := (Array.getElem?_eq_some_iff.mp node).1
  have member : label ∈ (Array.range result.order.nodes.size).reverse.toList := by simpa using bound
  obtain ⟨earlier,suffix,parts,_⟩ := List.eq_append_cons_of_mem member
  rw [parts,List.foldlM_append] at folded
  obtain ⟨before,_,rest⟩ := Except.bind_ok folded
  rw [List.foldlM_cons] at rest
  obtain ⟨after,call,last⟩ := Except.bind_ok rest
  have tag : result.order.nodes[label]! = .original bi := by simp only [getElem!_def,node]
  obtain ⟨data,core,lowered,afterSchedule⟩ := node_core tag call
  obtain ⟨branch,selected,emitted⟩ := stock_lowerBlockCore_try_branch isTry lowered
  have retained : branch.step ∈ after.schedule.toList := by
    rw [afterSchedule]
    exact stock_recordCore_branch_retained selected
  have survived := nodes_mono last retained
  have fields := stock_emitBranch_record emitted
  refine ⟨_,_,_,branch,emitted,?_,fields.1,fields.2.1,fields.2.2.1,fields.2.2.2.1,fields.2.2.2.2⟩
  rw [schedule]
  exact survived
end Backend.Stock.Proof.TryScheduleDraft
