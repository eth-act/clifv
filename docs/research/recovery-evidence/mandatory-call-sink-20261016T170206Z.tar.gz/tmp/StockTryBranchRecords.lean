import FV.Backend.Proof.StockBranchCfg
namespace Backend.Stock.Proof.TryBranchRecordsDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
attribute [local irreducible] Stock.runTerm lowerBlockCore branchArgs collectOutgoing scanBlock
private def addRecord (core : LoweredBlockCore) (bi stop : Nat)
    (acc : Array Step × Array ScanEvent × Array RuleId) (record : ScanRecord) :
    Array Step × Array ScanEvent × Array RuleId :=
  let scans := acc.2.1.push ⟨core.scan.ctx,bi,record.inst,stop-1,core.scan.isBranch,record.input,record.output⟩
  match record.output.step with
  | some step => (acc.1.push step,scans,acc.2.2 ++ step.rules.toArray)
  | none => (acc.1,scans,acc.2.2)
private theorem fold_preserves (core : LoweredBlockCore) (bi stop : Nat)
    (records : List ScanRecord) (acc : Array Step × Array ScanEvent × Array RuleId)
    {step : Step} (member : step ∈ acc.1.toList) :
    step ∈ (records.foldl (addRecord core bi stop) acc).1.toList := by
  induction records generalizing acc with
  | nil => exact member
  | cons record rest ih =>
    apply ih
    cases selected : record.output.step with
    | none => simpa only [addRecord,selected] using member
    | some next =>
      simp only [addRecord,selected]
      change step ∈ (acc.1.push next).toList
      simp only [Array.toList_push,List.mem_append,List.mem_singleton]
      exact .inl member
/-- The separately emitted branch step is retained in the actual schedule;
color-only terminal scanning does not need to emit a second step. -/
theorem stock_recordCore_branch_retained {input : DriverState} {core : LoweredBlockCore}
    {branch : BranchEmission} {bi stop : Nat} (actual : core.branch = some branch) :
    branch.step ∈ (recordCore input core bi stop).schedule.toList := by
  unfold recordCore
  simp only [actual]
  apply fold_preserves
  simp
/-- Existing schedule entries survive appending all real branch/body records. -/
theorem stock_recordCore_schedule_preserved {input : DriverState} {core : LoweredBlockCore}
    {bi stop : Nat} {step : Step} (member : step ∈ input.schedule.toList) :
    step ∈ (recordCore input core bi stop).schedule.toList := by
  unfold recordCore
  apply fold_preserves
  cases selected : core.branch with
  | none => simpa only [selected] using member
  | some branch =>
    simp only [selected]
    change step ∈ (input.schedule.push branch.step).toList
    simp only [Array.toList_push,List.mem_append,List.mem_singleton]
    exact .inl member
/-- Successful actual branch emission records its real source slot, emitted
code and state transition; it is not a body-scan record. -/
theorem stock_emitBranch_record {ctx : Ctx} {f : Clif.Function} {t : Clif.Terminator}
    {bi ti : Nat} {targets : Array Nat} {input : State} {emission : BranchEmission}
    (run : emitBranch ctx f t bi ti targets input = .ok emission) :
    emission.step.block = bi ∧ emission.step.inst = ti ∧
    emission.step.decision = .emitted ∧ emission.step.after = emission.state ∧
    emission.step.emitted = emission.code := by
  unfold emitBranch at run
  dsimp only at run
  repeat' first
    | (solve | cases run)
    | simp only [bind,Except.bind,pure,Except.pure] at run
    | split at run
  all_goals cases run; exact ⟨rfl,rfl,rfl,rfl,rfl⟩
private theorem map_some_inv {α : Type} {call : Except String α} {out : Option α}
    (run : (some <$> call) = .ok out) : ∃ value,call = .ok value ∧ out = some value := by
  cases call with
  | error err => cases run
  | ok value => cases run; exact ⟨value,rfl,rfl⟩
/-- Every successful original TryCall core has its actual separately emitted
branch and terminal code, with its real run retained. -/
theorem stock_lowerBlockCore_try_branch {ctx : Ctx} {order : Order} {f : Clif.Function}
    {b : Clif.Block} {bi start stop : Nat} {data : Backend.V} {targets : Array Nat}
    {input : State} {core : LoweredBlockCore} (isTry : b.term.isTry = true)
    (run : lowerBlockCore ctx order f b bi start stop data targets input = .ok core) :
    ∃ branch,core.branch = some branch ∧
      emitBranch {ctx with
        insts := ctx.insts.set! (stop-1) ⟨data,[],[],none⟩
        tryRegs := input.tryRegs[stop-1]!} f b.term bi (stop-1) targets input = .ok branch := by
  cases term : b.term <;> simp only [term,Clif.Terminator.isTry] at isTry
  all_goals try contradiction
  all_goals
    unfold lowerBlockCore at run
    simp only [term] at run
    repeat' first
      | (solve | cases run)
      | simp only [bind,Except.bind,pure,Except.pure,Functor.map,Except.map] at run
      | split at run
    all_goals
      cases run
      rename_i _ branch branchRun _ outgoing outgoingRun _ scan scanRun
      obtain ⟨emission,emitted,wrapped⟩ := map_some_inv branchRun
      subst branch
      exact ⟨emission,rfl,emitted⟩
private theorem branchCode_kind {f : Clif.Function} {t : Clif.Terminator}
    {targets : Array Nat} {before after : Array MInst} (kind : t.isTry = true)
    (run : branchCode f t targets before = .ok after) :
    ∃ (call : CallInfo) (info : TryInfo),after.back? = some (.tryCall call info) := by
  cases t <;> simp only [Clif.Terminator.isTry] at kind
  all_goals try contradiction
  all_goals
    unfold branchCode at run
    dsimp only at run
    repeat' first
      | (solve | cases run)
      | simp only [bind,Except.bind,pure,Except.pure] at run
      | split at run
    all_goals
      cases run
      rename_i _ sigItems _ _ info _ _ call _
      exact ⟨call,{info with rets := sigItems.1.returns.length},by simp only [Array.back?_push]⟩
/-- A successful real TryCall branch emission ends in the actual TryCall
constructor, carrying its real call and handler metadata. -/
theorem stock_emitBranch_try_kind {ctx : Ctx} {f : Clif.Function} {t : Clif.Terminator}
    {bi ti : Nat} {targets : Array Nat} {input : State} {emission : BranchEmission}
    (kind : t.isTry = true) (run : emitBranch ctx f t bi ti targets input = .ok emission) :
    ∃ (call : CallInfo) (info : TryInfo),emission.code.back? = some (.tryCall call info) := by
  unfold emitBranch at run
  dsimp only at run
  repeat' first
    | (solve | cases run)
    | simp only [bind,Except.bind,pure,Except.pure] at run
    | split at run
  all_goals cases run; exact branchCode_kind kind (by assumption)
end Backend.Stock.Proof.TryBranchRecordsDraft
