from pathlib import Path
import json,hashlib,datetime,re,subprocess
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
base='stock-node-coverage';name='stock-conditional-targets'
old=json.loads(Path('docs/research/'+base+'-checkpoint.json').read_text())
assert all(sha(n)==h for n,h in old['sources'].items())
modules={'StockConditionalTargets':'ConditionalTargets','StockConditionalRootTargets':'ConditionalRoots','StockConditionalTargetsWitness':'ConditionalTargetsWitness'}
paths=['FV/Backend/Proof/'+m+'.lean' for m in modules];roots=[]
for m,ns in modules.items():roots+=['Backend.Stock.Proof.'+ns+'.'+n for n in re.findall(r'^theorem (\w+)',Path('FV/Backend/Proof/'+m+'.lean').read_text(),re.M)]
assert len(roots)==5,roots
p={k:old[k] for k in ['goal','status','full_goal_checklist','comparison_preservation']}
p.update({'updated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseline_checkpoint':'docs/research/'+base+'-checkpoint.json','previous_goal_turn_classification':'progress: reclaimed obsolete secondary cache and recorded shared footprint discipline; current proof continuation checks terminal failed build before retry','scope':'Actual conditional helper722 and emitter242 preserve exact final target labels for every successful condition-result form, with one/two/three-instruction descriptors. Actual selected ordinary brif derives those calls from its real match/RHS execution. Structural control facts only; test-bit/table roots, whole CFG, universal semantics and production obligations remain.','sources':old['sources']|{n:sha(n) for n in paths},'all652_prior_recorded_source_hashes_unchanged':True,'new_or_appended_source_paths':paths,'new_public_roots':roots,'new_root_witness_coverage':{'conditional_builder_and_emitter':'Complete original-scope/dominated three-block conditional source driver with actual result context/initial state; all five condition-result forms plus two-instruction flag producer exercising three-instruction descriptor','ordinary_brif_selection':'Complete conditional source driver; actual named lower_branch execution internally yields chosen ordinary brif rule and final target labels, no supplied helper receipts'},'targeted_validation':{'log':'/tmp/'+name+'-witness.log','success':False},'next_steps':['Complete actual test-bit/table roots and whole jump/ordinary branch CFG correspondence; universally discharge stock_prepare_total_of_graph under original conditions, audit accepted tail calls','Complete indexed fallback acceptance/totality/lowering/emission for every call/try/terminator-result case','All original source/DFG/world/block/whole-driver simulation/completeness/family/effect/deferred-trap/sinking obligations, actual Arm/bytes/compiler/checker/linker/generated-proof production integration, complete production witnesses/final audits/full gates/fresh comparison preserving original parity/#179 remain mandatory']})
Path('docs/research/'+name+'-checkpoint.json').write_text(json.dumps(p,indent=2)+'\n')
code=Path('docs/research/'+base+'-all-axioms.lean').read_text();imports=[l for l in code.splitlines() if l.startswith('import ')]+['import FV.Backend.Proof.'+m for m in modules];body=[l for l in code.splitlines() if not l.startswith('import ')]
Path('docs/research/'+name+'-all-axioms.lean').write_text('\n'.join(dict.fromkeys(imports))+'\n'+'\n'.join('#print axioms '+n for n in roots)+'\n'+'\n'.join(body)+'\n')
Path('/tmp/'+name+'-mcp-code.lean').write_text('\n'.join('import FV.Backend.Proof.'+m for m in modules)+'\n'+'\n'.join('#print axioms '+n for n in roots)+'\n')
Path('/tmp/'+name+'-full-gates.py').write_text(Path('/tmp/'+base+'-full-gates.py').read_text().replace(base,name))
a=Path('/tmp/'+base+'-audit-check.py').read_text().replace('stock-control-cfg','OLD_AUDIT').replace(base,name).replace('OLD_AUDIT',base).replace('1818','1823').replace('1811','1818').replace('7 new','5 new').replace('all7_sets','all5_sets')
Path('/tmp/'+name+'-audit-check.py').write_text(a)
ref='580a5a60be4c40c793c7b3095097e25844dae290';manifest={}
for line in subprocess.check_output(['git','ls-tree','-r',ref,'--','FV','FVTest'],text=True).splitlines():
 meta,n=line.split('\t');blob=meta.split()[2]
 if not n.endswith('.lean'):continue
 data=Path(n).read_bytes();assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==blob,n
 manifest[n]=sha(n)
new=sorted(str(x) for top in ['FV','FVTest'] for x in Path(top).rglob('*.lean') if str(x) not in manifest);assert new==sorted(paths),new
Path('/tmp/'+name+'-source-preservation.json').write_text(json.dumps({'baseline':ref,'existing_Lean_files':len(manifest),'all_existing_sources_byte_identical':True,'new_sources':new,'source_sha256':manifest},indent=2)+'\n')
print(len(manifest),'old Lean sources preserved;',len(p['sources']),'recorded paths;',len(roots),'new roots')
