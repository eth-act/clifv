import StockTryPlacedExecution
import StockTryPlacedBranch
import StockTryCriticalGotValuesWitness
import StockTryGotLocalAreaColumns
import StockTryNormalGraph
import StockTryCriticalNormalWitness
import FV.Backend.Proof.MemRefines
import FV.E2E.RegLevelDriverSem
namespace Backend.Stock.Proof.TryCriticalGotPlacementWitnessDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open TryGotLocalAreaColumnsDraft TryNormalValueColumnsDraft TryNormalGraphDraft TryNormalCfgDraft
open TryNormalEdgeValuesDraft TryNormalCopiesDraft TryNormalControlDraft
open TryGotSourceRunDraft TryBranchAbiDraft TryResolvedRunsDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
open TryPlacedBranchDraft TryPlacedExecutionDraft
private def function := CriticalSplitFixture.function false
private def ext : Clif.ExtFunc := {name := "callee",sig := function.sig,colocated := false}
private def table : Clif.ExnTable := {sig := 0,normal := ⟨1,[.ret 0]⟩,items := []}
private def model : ExtSem := ⟨fun _ _ w => some ([17],w),fun _ _ => 4096,0,fun _ w => Arm.read_pstate w⟩
private def environment : Clif.Env := {
  extern := fun _ => some (fun _ cm => .returned [⟨.i64,17⟩] cm),names := ["callee"],sigOf := fun _ => some function.sig }
private def fr : Clif.Frame := {func := function,regs := Clif.Regs.empty,slots := [],body := [],term := function.blocks[0]!.term}
private def resultRegs : Clif.Regs := fr.regs.set function.freshValue ⟨.i64,17⟩
private def normalCall : Clif.BlockCall := ⟨1,[function.freshValue]⟩
private def pending : Clif.Frame := {fr with regs := resultRegs,body := [],term := .jump normalCall}
private def entered : Clif.Frame := {pending with regs := resultRegs.set 2 ⟨.i64,17⟩,body := [],term := .ret [2]}
theorem stock_complete_critical_got_normal_values_placed_witness :
    ∃ (result : Result) (p : EdgeVCode) (rf : RFunc) (af : AFunc),
      Stock.lower function = .ok result ∧ LowerScope function ∧ Dominated function ∧ ArityOk function ∧
      prepareAt result.code result.edgeArgs = .ok p ∧ rf = spillAllocAt p.code p.edges ∧
      checkAllocAt p.code p.edges rf = .ok () ∧ lowerRFunc p.code rf = .ok af ∧
      stockSourceTable function = .ok #[#[1],#[],#[1]] ∧
      sourceIndegree #[#[1],#[],#[1]] function.blocks.length = .ok #[0,2,0] ∧
      Node.original 2 ∉ result.order.nodes.toList ∧ result.order.nodes[1]? = some (.edge 0 0 1) ∧
      XCallsOk environment [ext] (fun _ _ _ => True) model ∧
      MRStable (fun _ => False) (fun _ _ _ => True) ∧
      MemRefinesR (fun _ => True) (fun _ => False) 0 (fun _ => none) (csem (fun _ => False) ⟨0,0⟩ model) ∧
      OutArgsOk (fun _ => False) (stackBytes ext.sig) (fun _ _ _ => True) ∧
      Clif.enterBlock pending normalCall = .ok entered ∧
      (∃ raw : GotTryRun function result 0 0 function.blocks[0]! ext
        (csem (fun _ => False) ⟨0,0⟩ model) (fun _ _ _ => True) fr (fun _ => 0) Arm.ArmState.default [⟨.i64,17⟩] Clif.Mem.empty,
        ∃ (k : Nat) (i : MInst) (ops : Array Operand) (atCall : Nat → CV) (world : Arm.ArmState)
          (outs : List CV) (finalWorld : Arm.ArmState) (args : Array Reg),
          seqRun (csem (fun _ => False) ⟨0,0⟩ model)
            (raw.source.branch.step.emitted.toList.map (·.mapRegs (resolver result))) (fun _ => 0) Arm.ArmState.default =
            some (.stop k i ops atCall world outs finalWorld (.goto raw.info.handlers.length)) ∧
          raw.info.handlers.length = 0 ∧ succOf result.code 0 raw.info.handlers.length = some 1 ∧ succOf result.code 1 0 = some 2 ∧
          NormalColumnValues result 1 0 [⟨.i64,17⟩] (vdefUpd ops outs atCall) ∧
          (result.edgeArgs[1]?.bind fun row => row[0]?) = some args ∧
          edgeEnvAt result.code result.edgeArgs 1 2 0 (vdefUpd ops outs atCall) =
            some (parCopyEnv (vdefUpd ops outs atCall) (edgeParamNumbers result function.blocks[1]!) (columnNumbers args)) ∧
          ValuesHeld (fun x => x ∈ availOf function (availIn function result.ctx) 1 0) result.ctx entered
            (fun key => parCopyEnv (vdefUpd ops outs atCall) (edgeParamNumbers result function.blocks[1]!)
              (columnNumbers args) (aliasNum result.final.alias key)) ∧
          (∃ (vb : VBlock) (prelude : Array MInst),result.code.blocks[0]? = some vb ∧
            vb.insts = prelude ++ raw.source.branch.step.emitted.map
              (·.mapRegs (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1))) ∧
            Star (VStepAt result.code result.edgeArgs (csem (fun _ => False) ⟨0,0⟩ model))
              (.run ⟨0,prelude.size,(fun _ => 0),Arm.ArmState.default⟩) (.run ⟨0,prelude.size+k,atCall,world⟩) ∧
            k < raw.source.branch.step.emitted.size ∧ vb.insts[prelude.size+k]? = some i ∧ i.operands = .ok ops ∧
            csem (fun _ => False) ⟨0,0⟩ model i (vuses ops atCall) world = some (outs,finalWorld,.goto raw.info.handlers.length) ∧
            outs.length = (ops.toList.filter Operand.isDef).length ∧ (.goto raw.info.handlers.length : Ctl) ≠ .next)) ∧
      Clif.runWith environment {funcs := [function]} function.name [] Clif.Mem.empty 6 = .returned [⟨.i64,17⟩] Clif.Mem.empty := by
  obtain ⟨result,p,rf,af,lowered,scope,dominated,arity,prepared,fallback,accepted,physical,srcRun,degreeRun,unreachable,edge,xcalls,stable,memory,localArea,sourceEntered,⟨raw,k,i,ops,atCall,world,outs,finalWorld,args,execute,normalZero,first,second,argumentValues,actual,copied1,copied2⟩,sourceRun⟩ := Backend.Stock.Proof.TryCriticalGotValuesWitnessDraft.stock_complete_critical_got_normal_values_witness
  have order : blockOrder function = .ok {nodes := #[.original 0,.edge 0 0 1,.original 1],successors := #[#[1],#[2],#[]]} := by cbv
  have sameOrder := Except.ok.inj ((stock_lower_order lowered).symm.trans order)
  have placed := stock_lower_try_branch_stop_prefix lowered scope
    (show result.order.nodes[0]? = some (.original 0) from by rw [sameOrder]; rfl)
    (show function.blocks[0]? = some function.blocks[0]! from rfl)
    (show function.blocks[0]!.term.isTry = true from rfl) raw.source execute
  exact ⟨result,p,rf,af,lowered,scope,dominated,arity,prepared,fallback,accepted,physical,srcRun,degreeRun,unreachable,edge,xcalls,stable,memory,localArea,sourceEntered,⟨raw,k,i,ops,atCall,world,outs,finalWorld,args,execute,normalZero,first,second,argumentValues,actual,copied1,copied2,placed⟩,sourceRun⟩
end Backend.Stock.Proof.TryCriticalGotPlacementWitnessDraft
