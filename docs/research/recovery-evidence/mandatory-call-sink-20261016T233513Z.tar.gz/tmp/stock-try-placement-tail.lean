/-- A SAME actual scheduled TryCall branch is the terminal suffix of its SAME
returned VCode original block. Membership/origin, source label, term index,
assembly, traversal preservation and final aliases are all derived internally. -/
theorem stock_lower_try_branch_placed {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f)
    {label bi : Nat} {b : Clif.Block} (node : result.order.nodes[label]? = some (.original bi))
    (block : f.blocks[bi]? = some b) (isTry : b.term.isTry = true)
    (source : TryBranchSource f result label bi b) :
    ∃ (vb : VBlock) (prelude : Array MInst),result.code.blocks[label]? = some vb ∧
      vb.insts = prelude ++ source.branch.step.emitted.map
        (·.mapRegs (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1))) := by
  obtain ⟨ranges,placedLabel,actualBi,input,data,core,vb,prelude,build,actualNode,coreRun,placed,assembled,origin⟩ :=
    stock_lower_scheduled_core_origin lowered source.scheduled
  have actualFacts := stock_emitBranch_record source.emitted
  have metadata := stock_lowerBlockCore_scanOrigin coreRun
  have current : actualBi = bi := by
    rcases origin with ⟨branch,selected,equal⟩ | ⟨record,inside,recorded⟩
    · have emitted := core_branch_run coreRun selected
      have fields := stock_emitBranch_record emitted
      exact fields.1.symm.trans ((congrArg Step.block equal).symm.trans actualFacts.1)
    · have scan := record_run metadata.2.2.2.2.2 record inside
      have fields := scan_fields scan recorded
      exact metadata.2.2.1.symm.trans (fields.1.symm.trans actualFacts.1)
  subst actualBi
  have original : f.blocks[bi]! = b := by simp only [getElem!_def,block,Option.getD_some]
  have selected : ∃ branch,core.branch = some branch ∧ source.branch.step = branch.step := by
    rcases origin with actual | ⟨record,inside,recorded⟩
    · exact actual
    · have scan := record_run metadata.2.2.2.2.2 record inside
      have fields := scan_fields scan recorded
      obtain ⟨oldCtx,oldState,oldBuild,spec,view⟩ := buildCtx_source build
      have range : ranges[bi]! = (blockStart f bi,blockStart f bi+b.body.length+1) := by
        simp only [getElem!_def,spec.ranges bi b block,Option.getD_some]
      have sameIndex : record.inst = core.scan.termInst := by
        have first : record.inst = source.ti := fields.2.1.symm.trans actualFacts.2.1
        rw [first,source.index,metadata.2.2.2.1,range]
        simp
      have branchKind : core.scan.isBranch = true := core_isBranch coreRun (by rw [original]; exact isTry)
      rw [sameIndex,branchKind] at scan
      exact (term_scan_not_emitted scan recorded actualFacts.2.2.1).elim
  obtain ⟨branch,branchSelected,equal⟩ := selected
  have nonempty : f.blocks.length ≠ 0 := fun h => scope.nonempty (List.length_eq_zero_iff.mp h)
  have sameLabel := stock_blockOrder_original_unique (stock_lower_order lowered) nonempty actualNode node
  subst placedLabel
  have emitted := core_branch_run coreRun branchSelected
  have code : branch.code = source.branch.step.emitted := by
    rw [equal,(stock_emitBranch_record emitted).2.2.2.2]
  refine ⟨vb,prelude ++ core.scan.output.code.map
    (·.mapRegs (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1))),placed,?_⟩
  rw [assembled,core_code coreRun branchSelected,Array.map_append,code,Array.append_assoc]
end Backend.Stock.Proof.TryPlacedBranchDraft
