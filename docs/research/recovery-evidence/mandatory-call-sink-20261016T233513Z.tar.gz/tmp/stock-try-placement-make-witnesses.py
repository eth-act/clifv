from pathlib import Path
import re
sources=[('StockTryNormalNearEntryWitness','StockTryNearPlacementWitness','near'),('StockTryNormalGotEntryWitness','StockTryGotPlacementWitness','got'),('StockTryNormalIndirectEntryWitness','StockTryIndirectPlacementWitness','indirect'),('StockTryCriticalIndirectValuesWitness','StockTryCriticalIndirectPlacementWitness','critical_indirect'),('StockTryCriticalGotValuesWitness','StockTryCriticalGotPlacementWitness','critical_got')]
for src,dst,form in sources:
 s=Path('/tmp',src+'.lean').read_text();oldns=re.search(r'^namespace (\S+)',s,re.M).group(1);newns='Backend.Stock.Proof.'+dst[len('Stock'):]+'Draft'
 head=s[:s.index('private def')].replace('namespace '+oldns,'namespace '+newns);head='import StockTryPlacedExecution\nimport StockTryPlacedBranch\nimport '+src+'\n'+head+'open TryPlacedBranchDraft TryPlacedExecutionDraft\n'
 defs=''.join(re.findall(r'^private def .*?(?=^private (?:def|theorem)|^/--|^theorem)',s,re.M|re.S))
 a=re.search(r'^theorem ',s,re.M).start();b=s.index(' := by',a);statement=s[a:b];oldroot=re.search(r'^theorem (\w+)',statement).group(1);newroot=oldroot.replace('_witness','_placed_witness');statement=statement.replace(oldroot,newroot,1)
 f='function' if 'indirect' in form or form=='critical_got' else 'f';result='result' if form.startswith('critical') else 'out.result'
 at=statement.index('      Clif.runWith');end=statement.rfind(') ∧',0,at)
 assert end>=0
 rho='rho out.result' if form=='indirect' else '(fun _ => 4096)' if form=='critical_indirect' else '(fun _ => 9)' if form=='near' else '(fun _ => 0)'
 statement=statement[:end]+f''' ∧
          (∃ (vb : VBlock) (prelude : Array MInst),{result}.code.blocks[0]? = some vb ∧
            vb.insts = prelude ++ raw.source.branch.step.emitted.map
              (·.mapRegs (Backend.lowerFunction.resolve {result}.final.alias ({result}.final.alias.size+1))) ∧
            Star (VStepAt {result}.code {result}.edgeArgs (csem (fun _ => False) ⟨0,0⟩ model))
              (.run ⟨0,prelude.size,{rho},Arm.ArmState.default⟩) (.run ⟨0,prelude.size+k,atCall,world⟩) ∧
            k < raw.source.branch.step.emitted.size ∧ vb.insts[prelude.size+k]? = some i ∧ i.operands = .ok ops ∧
            csem (fun _ => False) ⟨0,0⟩ model i (vuses ops atCall) world = some (outs,finalWorld,.goto raw.info.handlers.length) ∧
            outs.length = (ops.toList.filter Operand.isDef).length ∧ (.goto raw.info.handlers.length : Ctl) ≠ .next)) ∧'''+statement[end+3:]
 if not form.startswith('critical'):
  fields='out,scope,dominated,arity,'+('abi,' if form=='indirect' else '')+'lowered,prepare,fallback,accepted,physical,'
  fields+='xind,contract,changed,' if form=='indirect' else 'xcalls,contract,stable,memory,outgoing,'
  fields+='beforeDefined,afterDefined,sourceEntered,⟨raw,k,i,ops,atCall,world,outs,finalWorld,execute,column,normalIndex,entryAgreement⟩,sourceRun'
  exact=fields.replace('entryAgreement⟩','entryAgreement,placed⟩')
  order='{nodes := #[.original 0,.original 1,.original 2],successors := #[#[2,1],#[],#[]]}'
 else:
  fields='result,p,rf,af,lowered,scope,dominated,arity,'+('abi,' if form=='critical_indirect' else '')+'prepared,fallback,accepted,physical,srcRun,degreeRun,unreachable,edge,'
  fields+='xind,contract,' if form=='critical_indirect' else 'xcalls,stable,memory,localArea,'
  fields+='sourceEntered,⟨raw,k,i,ops,atCall,world,outs,finalWorld,args,execute,'+('related,' if form=='critical_indirect' else '')+'normalZero,first,second,argumentValues,actual,copied1,copied2⟩,sourceRun'
  exact=fields.replace('copied2⟩','copied2,placed⟩')
  order='{nodes := #[.original 0,.edge 0 0 1,.original 1],successors := #[#[1],#[2],#[]]}'
 body=f''' := by
  obtain ⟨{fields}⟩ := {oldns}.{oldroot}
  have order : blockOrder {f} = .ok {order} := by cbv
  have sameOrder := Except.ok.inj ((stock_lower_order lowered).symm.trans order)
  have placed := stock_lower_try_branch_stop_prefix lowered scope
    (show {result}.order.nodes[0]? = some (.original 0) from by rw [sameOrder]; rfl)
    (show {f}.blocks[0]? = some {f}.blocks[0]! from rfl)
    (show {f}.blocks[0]!.term.isTry = true from rfl) raw.source execute
  exact ⟨{exact}⟩
end {newns}
'''
 Path('/tmp',dst+'.lean').write_text(head+defs+statement+body)
