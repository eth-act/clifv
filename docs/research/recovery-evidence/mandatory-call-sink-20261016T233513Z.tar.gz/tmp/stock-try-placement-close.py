from pathlib import Path
import json,hashlib,re,datetime,tarfile,shutil,subprocess
root=Path('/home/lee/clifv/.worktrees/driver-proof-resume');docs=root/'docs/research';prefix='stock-try-placement'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
now=datetime.datetime.now(datetime.timezone.utc);stamp=now.strftime('%Y%m%dT%H%M%SZ')
batch=json.loads(Path('/tmp/'+prefix+'-batch.json').read_text());old=json.loads((docs/'stock-try-normal-entry-scratch.json').read_text())
log=Path('/tmp/'+prefix+'-combined-axioms.log').read_text()
sets={m.group(1):sorted(x.strip() for x in m.group(2).split(',') if x.strip()) for m in re.finditer(r"'([^']+)' depends on axioms:\s*\[([^]]*)\]",log)}
for m in re.finditer(r"'([^']+)' does not depend on any axioms",log):sets[m.group(1)]=[]
for n,a in old['normal_audit']['sets'].items():assert sorted(a)==sets[n],n
assert len(sets)==len(old['normal_audit']['sets'])+len(batch['public_roots'])+len(batch['models'])
allowed={'propext','Classical.choice','Quot.sound'}
for n in batch['public_roots']+batch['models']:assert set(sets[n])<=allowed,n
constants=[json.loads(line.split('DELIVERY_CONSTANT ',1)[1]) for line in Path('/tmp/'+prefix+'-all-constants.log').read_text().splitlines() if line.startswith('DELIVERY_CONSTANT ')]
assert constants
for n,a in constants:assert set(a)<=allowed,n
mods={}
for m in batch['modules']:
 p=Path('/tmp')/m;check=json.loads(p.with_suffix('.check.json').read_text());assert check['actual_exit']==0
 rec={}
 for key,ext in [('source','.lean'),('object','.olean'),('log','.log'),('check','.check.json')]:
  f=p.with_suffix(ext);rec[key]=str(f);rec[key+'_sha256']=sha(f)
 for k in ['source','object','log']:assert rec[k+'_sha256']==check[k+'_sha256']
 assert not re.search(r'\b(sorry|admit|axiom|trace_state|native_decide)\b',p.with_suffix('.lean').read_text()),m
 mods[m]=rec
for audit in [prefix+'-combined-axioms',prefix+'-all-constants']:
 p=Path('/tmp')/audit;check=json.loads(p.with_suffix('.check.json').read_text());assert check['actual_exit']==0
 for k,ext in [('source','.lean'),('object','.olean'),('log','.log')]:assert sha(p.with_suffix(ext))==check[k+'_sha256']
prior={}
for name in ['source-execution-x','try-source','try-context','try-rule','try-rets','try-reservation','try-outgoing','try-values','try-emitted','try-machine','try-got','try-indirect','try-rename','try-resolved','try-gap','try-got-rename','try-normal-frame','try-metadata','source-index','try-normal-vector','try-critical-normal','source-erase','source-origin','try-live-frame','try-normal-values','try-normal-copy','try-normal-control','try-normal-entry']:
 d=json.loads((docs/f'stock-{name}-scratch.json').read_text())
 for m,rec in d['modules'].items():
  for k in ['source','object','log']:assert sha(rec[k])==rec[k+'_sha256'],(m,k)
  prior[m]=rec
assert len(prior)==187
freeze=json.loads(Path('/tmp/stock-coherent-build-inputs.json').read_text())
for group in ['source_sha256','validation_script_sha256']:
 for p,h in freeze[group].items():assert sha(root/p)==h,p
imports=json.loads(Path('/tmp/stock-try-rule-inputs.json').read_text())
for m,r in imports['modules'].items():
 assert sha(r['snapshot'])==r['object_sha256'],(m,'snapshot')
 assert sha(r['source'])==r['source_sha256'],(m,'source')
progress=json.loads(Path('/tmp/stock-pr246-gates-progress.json').read_text());progress.pop('completed_phases',None)
subprocess.run(['ps','-p','3247835','-o','pid,stat,etime,args'],check=True)
remaining=list(old['remaining_checklist']);remaining.append({'requirement':'Actual scheduled branch placement and actual per-successor VCode execution prefix','state':'EVERY scheduled step has actual node/core/assembly/traversal origin and returned-block placement. Actual TryBranchSource membership/step metadata/source index/original-node uniqueness exclude body/term-scan alternatives and prove SAME final-resolved branch fragment is terminal suffix of SAME returned original VCode block. Generic indexed seqRun stop lift derives actual Star(VStepAt) to executing stopped instruction with exact code position/operands/semantic run/output arity/register+world state. COMPLETE ordinary near/GOT/indirect and critical indirect/local-area-GOT compiler/physical/source/value/copy witnesses include actual placed branch execution prefix. Last-call index/end-of-block proof and VNextAt.goto/copy step, whole branch/source-block/prepared/source-world/whole-driver simulation/completeness remain OPEN. Near-critical and older critical GOT whole-area root-specific non-vacuity remain PENDING; new local-area witness does not substitute.'})
counts={'modules':len(mods),'public_roots':len(batch['public_roots']),'models':len(batch['models']),'combined_roots_models':len(sets),'previous_preserved':len(old['normal_audit']['sets']),'all_new_module_constants':len(constants),'previous_modules_hashes_preserved':len(prior)}
receipt={'utc':now.isoformat(),'goal':'Original full #140 ACTIVE/INCOMPLETE; production LEGACY','scope':'Additive scratch placement/execution proofs, coherent integration and full gates pending','delivery_target':'roughly8 substantive validated squash merges/day; grouping/remote backup/cleanup','modules':mods,'public_roots':batch['public_roots'],'models':batch['models'],'counts':counts,'normal_audit':{'path':'/tmp/'+prefix+'-combined-axioms.log','sha256':sha('/tmp/'+prefix+'-combined-axioms.log'),'sets':sets},'all_constant_audit':{'path':'/tmp/'+prefix+'-all-constants.log','sha256':sha('/tmp/'+prefix+'-all-constants.log'),'all_standard_only':True,'count':len(constants)},'previous_modules_hashes_preserved':list(prior),'canonical2246_source_and_script_freeze_preserved':True,'import_generation':{'source_and_snapshot_hashes_checked':len(imports['modules']),'manifest_sha256':sha('/tmp/stock-try-rule-inputs.json'),'shared_cache_writes':False,'canonical_import_repair':'stock-try-normal-copy-scratch.json'},'nonvacuity':{'ordinary_near_GOT_indirect':'COMPLETE original runtime/source/memory/callee/compiler/prepare/checkedfallback/checker/physical/source17 plus exact placed terminal branch and actual Star(VStepAt) execution prefix to call with all normal-entry value/copy/definedness conclusions','critical_indirect':'COMPLETE actual placed prefix/call-state/value/source/copy/CFG/compiler/checker/fallback/physical; unreachable predecessor/indegree2 retained','critical_GOT_local_area':'COMPLETE same placed prefix/call-state/value/source/copy/CFG/compiler/checker/fallback/physical using generic additive actual-callee-stack-area contract, unreachable predecessor/indegree2 retained','critical_near':'PENDING complete compiler/machine/value observation, saved8GiB failures; larger kernel queued after heavy delivery lane frees','older_critical_GOT_whole_area':'PENDING root-specific old whole-result-area premise/non-vacuity; local-area witness is not substituted'},'MCP':'Deferred until coherent integration; no new calls','active_exact_PR246_validation':progress,'remaining_checklist':remaining}
(docs/(prefix+'-scratch.json')).write_text(json.dumps(receipt,indent=2)+'\n')
text=f'''Actual scheduled branch placement and per-successor VCode prefix execution — {now.isoformat()}

{len(mods)} scratch modules/{len(batch['public_roots'])} public roots actual8GiB kernelPASS. Cumulative{len(sets)}root/model audit preserves ALL711prior exact axiom sets. ALL{len(constants)}new-module constants including private record/node/core/traversal/origin/scan/placement helpers and witness definitions STANDARD-only. ALL187prior scratch source/object/log hashes, frozen2246canonical sources/49scripts and1049imported source/snapshot hashes unchanged. No shared-cache writes.

EVERY step retained in the actual schedule now has an internally derived original-node/core origin, actual branch OR actual recorded scan, real assembled returned block, traversal-prefix/suffix and final-resolved code placement. Synthetic nodes introduce no new scheduled steps; node/body/branch diagnostic membership is inverted through the real recordCore fold, not supplied by callers. Entry materialization is preserved as a real prefix and later reverse traversal frames the installed block.

The SAME actual scheduled TryBranchSource has its EXACT final-renamed branch fragment as terminal suffix of its SAME returned original VCode block. Actual emitBranch step block/index/decision, actual core scan metadata and source build ranges exclude a body/term-scan record at that index. Original-node uniqueness identifies the same output label; branch/core assembly and final aliases derive the exact suffix. No caller code-placement/rule/map certificate or new source input condition.

An indexed sequence-run lift now proves actual Star(VStepAt) execution of that placed fragment up to the executing stopped call, with its exact instruction position, actual operands, actual semantics, output arity and register/world state. COMPLETE original near/GOT/true-indirect and critical indirect/local-area-GOT witnesses retain compiler/prepare/forced checkedfallback/checker/physical/source17/value/copy/CFG contracts and now include the SAME actual placed VCode execution prefix. Critical cases preserve real unreachable predecessor/indegree2 and synthetic-row copies; ordinary cases preserve defined source frames BEFORE/AFTER normal entry.

The stopped-call LAST-index/end-of-block proof and actual VNextAt.goto/copy step still need composition; this batch proves the real executable prefix and executing instruction, not a completed whole block/source simulation. Next prove last-call position then actual edge step, prepared/source continuation and whole-driver composition. Near-critical full compiler/machine/value observation remains PENDING after saved8GiB failures; one larger kernel after live delivery heavy lane frees. Older critical GOT WHOLE-RESULT-AREA root-specific non-vacuity remains PENDING; local-area witness is not substituted, successful physical lowering is not treated as an outgoing bound/projection proof. VM output is not proof.

All remaining zero-return/sret/x8/width/handler/Try-critical matrix, shared payload/exception semantics, uncovered rule families/effects/sinking, source/DFG/world/block/whole-driver simulation AND completeness, original-input context/static/visitor/checker/fallback/physical totality, coherent integration/public/private/compiler/MCP/full build/crates/runtime/encoder/BOTH E2E identity-stage parity, actual compiler/checker/linker/generated consumers and FRESH COMPLETE comparison remain mandatory. Original input/theorem/axiom/identity-stage/#179parity preserved. Full#140 ACTIVE/INCOMPLETE; production LEGACY.

Same246supervisor3247835confirmedLIVE at{progress.get('index')}/{progress.get('total')}; canonical1233457deliberately held/exclusive single-cache lease. Preserve old-head receipts, reconcile currentmain and changed/deleted roots/shared machine assumptions, rerun affected kernel/trust plus ALL full/crates/runtime/encoder/BOTH E2E actual integrated-head gates before dependent squash246→247. Targetroughly8substantive validated merges/day; semantic grouping/remote backup/cleanup. No merge/new tree/agent/MCP/cold compiler projection/larger kernel/heavyretry/restart/other-project cleanup. Shared Kev S10/FP/Link boundaries preserved; contributor52/71/task140 freshly read. Full hashed evidence/checklist: stock-try-placement-scratch.json.
'''
(docs/(prefix+'-scratch.md')).write_text(text);plan=root/'docs/plans/test-binary-alignment-recovery.md';plan.write_text(plan.read_text()+'\n\n'+text)
current=docs/'stock-full-goal-current.md';s=current.read_text();Path('/tmp/'+prefix+'-full-goal-before.md').write_text(s);lines=s.splitlines()
for i,line in enumerate(lines):
 if line.startswith('| Source, DFG, world, block and whole-driver simulation |'):
  lines[i]='| Source, DFG, world, block and whole-driver simulation | SAME actual scheduled TryCall branches now have terminal-suffix placement in returned VCode and actual Star(VStepAt) execution prefix to the executing stopped call; complete original near/GOT/indirect and critical indirect/local-area-GOT pipeline/source/value/copy witnesses pass. Earlier source reachability/definedness retained | Prove last-call index and VNextAt.goto/actual-copy step, complete whole source-block/prepared continuation, DFG/world/effect and whole-driver simulation AND completeness; generic runX/unwind invariant and all uncovered families remain required |'
 elif line.startswith('| Public-root/kernel/transitive axiom audit |'):
  lines[i]=f'| Public-root/kernel/transitive axiom audit | Latest scratch cumulative{len(sets)}roots/models preserve711prior exact sets;{len(constants)}new-module constants including private helpers standard-only,187prior module hashes preserved; frozen source/script bytes unchanged | Coherent canonical integration/current integrated public/private/model/compiler audit, ONE bundled MCP and final production audit. Scratch{len(sets)}does not establish complete integrated/cutover audit |'
current.write_text(f'Latest checkpoint {now.isoformat()}: [actual scheduled branch placement and per-successor VCode prefix execution](stock-try-placement-scratch.md). {len(mods)}modules/{len(batch["public_roots"])}roots; cumulative{len(sets)}preserves711prior exact sets;{len(constants)}new-module constants Std-only. Full#140 ACTIVE/INCOMPLETE; production LEGACY. Last-call/edge/prepared/source/whole-driver composition, near-critical and old whole-area-GOT root-specific witnesses and every final obligation remain open. Same live246gate at{progress.get("index")}/{progress.get("total")}; no merge.\n\n'+'\n'.join(lines)+'\n')
files=[]
for rec in mods.values():files.extend(Path(rec[k]) for k in ['source','object','log','check'])
for name in [prefix+'-combined-axioms',prefix+'-all-constants']:
 for ext in ['.lean','.log','.olean','.check.json']:files.append(Path('/tmp')/(name+ext))
for p in Path('/tmp').glob(prefix+'*'):
 if p.is_file():files.append(p)
files.extend([Path('/tmp/stock-try-rule-inputs.json'),Path('/tmp/stock-try-reservation-check.py'),Path('/tmp/stock-source-erase-restore.py'),docs/(prefix+'-scratch.json'),docs/(prefix+'-scratch.md'),docs/'stock-delivery-main-drift.json',plan,current])
files=list(dict.fromkeys(files))
archive=Path('/home/lee/.clifv-recovery')/(stamp+'-try-placement')/'checkpoint.tar.gz';archive.parent.mkdir(parents=True)
with tarfile.open(archive,'w:gz',compresslevel=1) as t:
 for p in files:t.add(p,arcname=str(p).lstrip('/'),recursive=False)
with tarfile.open(archive,'r:gz') as t:
 for p in files:assert t.extractfile(str(p).lstrip('/')).read()==p.read_bytes(),p
snapshot=Path('/tmp/stock-try-rule-inputs');size=sum(p.stat().st_size for p in snapshot.rglob('*') if p.is_file());shutil.rmtree(snapshot)
backup={'utc':now.isoformat(),'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(files),'all_members_byte_verified':True,'previous_remote_backup':json.loads((docs/'stock-try-normal-entry-backup.json').read_text())['remote'],'cleanup':{'duplicate_dependency_snapshot_removed':True,'bytes_reclaimed':size,'all_unique_sources_objects_logs_checks_audits_preserved':True,'one_shared_warm_cache_retained':True,'other_projects_touched':False,'free_bytes':shutil.disk_usage(root).free}}
(docs/(prefix+'-backup.json')).write_text(json.dumps(backup,indent=2)+'\n');Path('/tmp/'+prefix+'-archive-path').write_text(str(archive))
print(json.dumps({'counts':counts,'archive':str(archive),'cleanup':backup['cleanup'],'gate':progress},indent=2))
