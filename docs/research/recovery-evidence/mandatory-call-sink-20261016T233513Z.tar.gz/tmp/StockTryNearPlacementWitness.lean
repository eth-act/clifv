import StockTryPlacedExecution
import StockTryPlacedBranch
import StockTryNormalNearEntryWitness
import StockTryNormalNearEntry
import StockTryNormalEdgeValues
import StockTryNormalSourceValues
import StockTryLiveValues
import StockTryLiveResolvedSource
import StockTryNearOutgoingObservation
import FV.Backend.Proof.MemRefines
import FV.E2E.RegLevelDriverSem
namespace Backend.Stock.Proof.TryNearPlacementWitnessDraft
open TryNormalSourceValuesDraft TryNormalValueColumnsDraft
open TryLiveValuesDraft TryLiveNormalDraft
open TryNormalEntryValuesDraft TryNormalCopiesDraft TryNormalEdgeValuesDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open TryDirectSourceRunDraft TryNearFixtureDraft
open TryResolvedRunsDraft TryLiveResolvedSourceDraft
open TryNormalEntryCaseDraft TryNormalNearEntryDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
open TryPlacedBranchDraft TryPlacedExecutionDraft
private def f := function false
private def ext : Clif.ExtFunc := {name := "callee",sig := f.sig,colocated := true}
private def table : Clif.ExnTable := {
  sig := 0,normal := ⟨1,[.ret 0,.val 0]⟩,items := [.tag 7 ⟨2,[.exn 0,.exn 1,.val 0]⟩] }
private def fr : Clif.Frame := {func := f,regs := Clif.Regs.empty.set 0 ⟨.i64,9⟩,slots := [],body := [],term := f.blocks[0]!.term}
private def model : ExtSem := ⟨fun _ _ w => some ([17],w),fun _ _ => 4096,0,fun _ w => Arm.read_pstate w⟩
private def environment : Clif.Env := {
  extern := fun _ => some (fun _ cm => .returned [⟨.i64,17⟩] cm),names := ["callee"],sigOf := fun _ => some f.sig }
private def resultRegs : Clif.Regs := fr.regs.set f.freshValue ⟨.i64,17⟩
private def normalCall : Clif.BlockCall := ⟨1,[f.freshValue,0]⟩
private def pendingFrame : Clif.Frame := {fr with regs := resultRegs,body := [],term := .jump normalCall}
private def enteredFrame : Clif.Frame := {pendingFrame with regs := ((resultRegs.set 2 ⟨.i64,17⟩).set 3 ⟨.i64,9⟩),body := [],term := .ret [2]}
private def built : Ctx × Array (Nat × Nat) × State := (Stock.buildCtx f).toOption.getD (sinkCtx,#[],sinkState)
theorem stock_complete_near_try_normal_entry_values_placed_witness :
    ∃ out : Output,
      LowerScope f ∧ Dominated f ∧ ArityOk f ∧ Stock.lower f = .ok out.result ∧
      prepareAt out.result.code out.result.edgeArgs = .ok out.prepared ∧
      out.rf = spillAllocAt out.prepared.code out.prepared.edges ∧
      checkAllocAt out.prepared.code out.prepared.edges out.rf = .ok () ∧ lowerRFunc out.prepared.code out.rf = .ok out.af ∧
      XCallsOk environment [ext] (fun _ _ _ => True) model ∧
      CallsRefineP (fun _ _ _ _ => True) (fun _ => False) environment [ext] (fun _ _ _ => True) (csem (fun _ => False) ⟨0,0⟩ model) ∧
      MRStable (fun _ => False) (fun _ _ _ => True) ∧
      MemRefinesR (fun _ => True) (fun _ => False) 0 (fun _ => none) (csem (fun _ => False) ⟨0,0⟩ model) ∧
      OutArgsOk (fun _ => False) out.result.code.outgoing (fun _ _ _ => True) ∧
      SourceDefinedAt f out.result.ctx 0 f.blocks[0]!.body.length fr ∧
      SourceDefinedAt f out.result.ctx 1 0 enteredFrame ∧
      Clif.enterBlock pendingFrame normalCall = .ok enteredFrame ∧
      (∃ raw : DirectTryRun f out.result 0 0 f.blocks[0]! ext (csem (fun _ => False) ⟨0,0⟩ model)
        (fun _ _ _ => True) fr (fun _ => 9) Arm.ArmState.default [⟨.i64,17⟩] Clif.Mem.empty,
        ∃ (k : Nat) (i : MInst) (ops : Array Operand) (atCall : Nat → CV) (world : Arm.ArmState)
          (outs : List CV) (finalWorld : Arm.ArmState),
          seqRun (csem (fun _ => False) ⟨0,0⟩ model)
            (raw.source.branch.step.emitted.toList.map (·.mapRegs (resolver out.result))) (fun _ => 9) Arm.ArmState.default =
            some (.stop k i ops atCall world outs finalWorld (.goto raw.info.handlers.length)) ∧
          NormalColumnValues out.result 0 table.handlers.length [⟨.i64,17⟩,⟨.i64,9⟩] (vdefUpd ops outs atCall) ∧
          raw.info.handlers.length = table.handlers.length ∧
          NormalEntryAgreement f out.result 0 1 1 raw.info.handlers.length normalCall enteredFrame (vdefUpd ops outs atCall) ∧
          (∃ (vb : VBlock) (prelude : Array MInst),out.result.code.blocks[0]? = some vb ∧
            vb.insts = prelude ++ raw.source.branch.step.emitted.map
              (·.mapRegs (Backend.lowerFunction.resolve out.result.final.alias (out.result.final.alias.size+1))) ∧
            Star (VStepAt out.result.code out.result.edgeArgs (csem (fun _ => False) ⟨0,0⟩ model))
              (.run ⟨0,prelude.size,(fun _ => 9),Arm.ArmState.default⟩) (.run ⟨0,prelude.size+k,atCall,world⟩) ∧
            k < raw.source.branch.step.emitted.size ∧ vb.insts[prelude.size+k]? = some i ∧ i.operands = .ok ops ∧
            csem (fun _ => False) ⟨0,0⟩ model i (vuses ops atCall) world = some (outs,finalWorld,.goto raw.info.handlers.length) ∧
            outs.length = (ops.toList.filter Operand.isDef).length ∧ (.goto raw.info.handlers.length : Ctl) ≠ .next)) ∧
      Clif.runWith environment {funcs := [f]} f.name [] Clif.Mem.empty 6 = .returned [⟨.i64,17⟩] Clif.Mem.empty := by
  obtain ⟨out,scope,dominated,arity,lowered,prepare,fallback,accepted,physical,xcalls,contract,stable,memory,outgoing,beforeDefined,afterDefined,sourceEntered,⟨raw,k,i,ops,atCall,world,outs,finalWorld,execute,column,normalIndex,entryAgreement⟩,sourceRun⟩ := Backend.Stock.Proof.TryNormalNearEntryWitnessDraft.stock_complete_near_try_normal_entry_values_witness
  have order : blockOrder f = .ok {nodes := #[.original 0,.original 1,.original 2],successors := #[#[2,1],#[],#[]]} := by cbv
  have sameOrder := Except.ok.inj ((stock_lower_order lowered).symm.trans order)
  have placed := stock_lower_try_branch_stop_prefix lowered scope
    (show out.result.order.nodes[0]? = some (.original 0) from by rw [sameOrder]; rfl)
    (show f.blocks[0]? = some f.blocks[0]! from rfl)
    (show f.blocks[0]!.term.isTry = true from rfl) raw.source execute
  exact ⟨out,scope,dominated,arity,lowered,prepare,fallback,accepted,physical,xcalls,contract,stable,memory,outgoing,beforeDefined,afterDefined,sourceEntered,⟨raw,k,i,ops,atCall,world,outs,finalWorld,execute,column,normalIndex,entryAgreement,placed⟩,sourceRun⟩
end Backend.Stock.Proof.TryNearPlacementWitnessDraft
