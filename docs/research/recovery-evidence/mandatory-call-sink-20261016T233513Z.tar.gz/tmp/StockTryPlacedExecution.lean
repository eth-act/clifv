import StockTryPlacedBranch
import FV.Backend.Proof.PerEdgeVCodeSem
namespace Backend.Stock.Proof.TryPlacedExecutionDraft
open Backend.Proof Backend.Proof.Driver
open TryPlacedBranchDraft TrySourceContextDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
variable {V W : Type} {vc : VCode} {edges : Array (Array (Array Reg))} {sem : ISem V W}
theorem seqRun_stop_star_at {b : Nat} {vb : VBlock} (hvb : vc.blocks[b]? = some vb) :
    ∀ {ms : List MInst} {k0 : Nat} {ρ : Nat → V} {w : W} {k : Nat} {i : MInst}
      {ops : Array Operand} {ρ₁ : Nat → V} {w₁ : W} {outs : List V} {w₂ : W} {ctl : Ctl},
    SegAt vb k0 ms → seqRun sem ms ρ w = some (.stop k i ops ρ₁ w₁ outs w₂ ctl) →
    Star (VStepAt vc edges sem) (.run ⟨b, k0, ρ, w⟩) (.run ⟨b, k0 + k, ρ₁, w₁⟩) ∧ k < ms.length ∧
      vb.insts[k0 + k]? = some i ∧ i.operands = .ok ops ∧
      sem i (vuses ops ρ₁) w₁ = some (outs, w₂, ctl) ∧
      outs.length = (ops.toList.filter Operand.isDef).length ∧ ctl ≠ .next := by
  intro ms
  induction ms with
  | nil => intro _ _ _ _ _ _ _ _ _ _ _ _ h; simp [seqRun] at h
  | cons i₀ ms ih =>
    intro k0 ρ w k i ops ρ₁ w₁ outs w₂ ctl hseg h
    rcases seqRun_cons_stop h with
      ⟨rfl, rfl, hops, rfl, rfl, hsem, hlen, hne⟩ | ⟨k', ops₀, outs₀, w₃, rfl, hops₀, hsem₀, hlen₀, hrest⟩
    · exact ⟨by simpa using Star.refl _, by simp, by simpa using hseg.head, hops, hsem, hlen, hne⟩
    · obtain ⟨hstar, hk, hi, hops, hsem, hlen, hne⟩ := ih hseg.tail hrest
      have hlt : k0 + 1 < vb.insts.size := by
        have := (Array.getElem?_eq_some_iff.mp hi).1; omega
      have hstep : VStepAt vc edges sem (.run ⟨b, k0, ρ, w⟩)
          (.run ⟨b, k0 + 1, vdefUpd ops₀ outs₀ ρ, w₃⟩) :=
        VStepAt.step hvb hseg.head hops₀ hsem₀ hlen₀ (VNextAt.next hlt)
      refine ⟨?_, by simp; omega, by simpa [Nat.add_assoc, Nat.add_comm 1 k'] using hi, hops,
        hsem, hlen, hne⟩
      rw [show k0 + (k' + 1) = k0 + 1 + k' by omega]
      exact .step hstep hstar

/-- The SAME actual TryCall fragment's stopped run is a real per-successor
VCode prefix up to its executing call, with exact instruction, operands,
semantic execution, output arity and register/world state at that position. -/
theorem stock_lower_try_branch_stop_prefix {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f)
    {label bi : Nat} {b : Clif.Block} (node : result.order.nodes[label]? = some (.original bi))
    (block : f.blocks[bi]? = some b) (isTry : b.term.isTry = true)
    (source : TryBranchSource f result label bi b)
    {isem : Sem} {rho atCall : Nat → CV} {w world finalWorld : Arm.ArmState}
    {k : Nat} {i : MInst} {ops : Array Operand} {outs : List CV} {ctl : Ctl}
    (run : seqRun isem (source.branch.step.emitted.toList.map (·.mapRegs
      (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1)))) rho w =
        some (.stop k i ops atCall world outs finalWorld ctl)) :
    ∃ (vb : VBlock) (prelude : Array MInst),result.code.blocks[label]? = some vb ∧
      vb.insts = prelude ++ source.branch.step.emitted.map
        (·.mapRegs (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1))) ∧
      Star (VStepAt result.code result.edgeArgs isem) (.run ⟨label,prelude.size,rho,w⟩)
        (.run ⟨label,prelude.size+k,atCall,world⟩) ∧ k < source.branch.step.emitted.size ∧
      vb.insts[prelude.size+k]? = some i ∧ i.operands = .ok ops ∧
      isem i (vuses ops atCall) world = some (outs,finalWorld,ctl) ∧
      outs.length = (ops.toList.filter Operand.isDef).length ∧ ctl ≠ .next := by
  obtain ⟨vb,prelude,placed,code⟩ := stock_lower_try_branch_placed lowered scope node block isTry source
  let mapped := source.branch.step.emitted.map
    (·.mapRegs (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1)))
  have segment : SegAt vb prelude.size mapped.toList := by
    intro j bound
    have inside : j < mapped.size := by simpa only [Array.length_toList] using bound
    change vb.insts[prelude.size+j]? = some mapped[j]
    rw [code,Array.getElem?_append_right (by omega)]
    simp only [Nat.add_sub_cancel_left]
    exact Array.getElem?_eq_getElem inside
  have execute : seqRun isem mapped.toList rho w = some (.stop k i ops atCall world outs finalWorld ctl) := by
    simpa only [mapped,Array.toList_map] using run
  obtain ⟨executedSteps,bound,atInst,operands,semantics,arity,control⟩ :=
    seqRun_stop_star_at (edges := result.edgeArgs) placed segment execute
  exact ⟨vb,prelude,placed,code,executedSteps,by simpa only [mapped,Array.length_toList,Array.size_map] using bound,
    atInst,operands,semantics,arity,control⟩
end Backend.Stock.Proof.TryPlacedExecutionDraft
