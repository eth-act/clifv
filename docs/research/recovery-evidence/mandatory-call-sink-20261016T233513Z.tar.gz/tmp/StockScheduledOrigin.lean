import StockTryBranchRecords
import FV.Backend.Proof.StockBlockCode
import FV.Backend.Proof.StockCoreScanOrigin
namespace Backend.Stock.Proof.ScheduledOriginDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open TryBranchRecordsDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
attribute [local irreducible] Stock.runTerm lowerBlockCore branchArgs emitBranch collectOutgoing scanBlock
private def addRecord (core : LoweredBlockCore) (bi stop : Nat)
    (acc : Array Step × Array ScanEvent × Array RuleId) (record : ScanRecord) :
    Array Step × Array ScanEvent × Array RuleId :=
  let scans := acc.2.1.push ⟨core.scan.ctx,bi,record.inst,stop-1,core.scan.isBranch,record.input,record.output⟩
  match record.output.step with
  | some step => (acc.1.push step,scans,acc.2.2 ++ step.rules.toArray)
  | none => (acc.1,scans,acc.2.2)
private theorem fold_origin (core : LoweredBlockCore) (bi stop : Nat) (records : List ScanRecord)
    (acc : Array Step × Array ScanEvent × Array RuleId) {step : Step}
    (member : step ∈ (records.foldl (addRecord core bi stop) acc).1.toList) :
    step ∈ acc.1.toList ∨ ∃ record ∈ records,record.output.step = some step := by
  induction records generalizing acc with
  | nil => exact .inl member
  | cons record rest ih =>
    have next := ih (addRecord core bi stop acc record) member
    rcases next with before | ⟨record',inside,actual⟩
    · cases selected : record.output.step with
      | none => exact .inl (by simpa only [addRecord,selected] using before)
      | some actual =>
        simp only [addRecord,selected,Array.toList_push,List.mem_append,List.mem_singleton] at before
        rcases before with old | same
        · exact .inl old
        · exact .inr ⟨record,by simp,by simpa only [same] using selected⟩
    · exact .inr ⟨record',List.mem_cons_of_mem _ inside,actual⟩
private theorem record_origin {input : DriverState} {core : LoweredBlockCore} {bi stop : Nat} {step : Step}
    (member : step ∈ (recordCore input core bi stop).schedule.toList)
    (fresh : step ∉ input.schedule.toList) :
    (∃ branch,core.branch = some branch ∧ step = branch.step) ∨
      ∃ record ∈ core.scan.output.records,record.output.step = some step := by
  unfold recordCore at member
  change step ∈ (core.scan.output.records.foldl (addRecord core bi stop) _).1.toList at member
  rcases fold_origin core bi stop _ _ member with initial | recorded
  · cases branch : core.branch with
    | none => exact (fresh (by simpa only [branch] using initial)).elim
    | some emission =>
      simp only [branch,Array.toList_push,List.mem_append,List.mem_singleton] at initial
      rcases initial with old | same
      · exact (fresh old).elim
      · exact .inl ⟨emission,rfl,same⟩
  · exact .inr recorded

private theorem assemble_suffix {ctx : Ctx} {f : Clif.Function} {b : Clif.Block}
    {bi label : Nat} {targets : Array Nat} {outgoing : Array (Array Reg)}
    {params : List Nat} {uses : Array UseState} {code : Array MInst} {block : VBlock}
    (run : assembleOriginalBlock ctx f b bi label targets outgoing params uses code = .ok block) :
    ∃ preludeCode : Array MInst, block.insts = preludeCode ++ code := by
  unfold assembleOriginalBlock at run
  dsimp only at run
  repeat' first
    | (solve | cases run)
    | simp only [bind, Except.bind, pure, Except.pure] at run
    | split at run
  all_goals
    cases run
    first | exact ⟨_,rfl⟩ | exact ⟨#[],by simp⟩

private theorem node_origin {ctx : Ctx} {ranges : Array (Nat × Nat)} {order : Order}
    {f : Clif.Function} {params : List Nat} {label : Nat} {input output : DriverState} {step : Step}
    (run : lowerNode ctx ranges order f params label input = .ok output)
    (member : step ∈ output.schedule.toList) (fresh : step ∉ input.schedule.toList) :
    ∃ (bi : Nat) (data : Backend.V) (core : LoweredBlockCore) (block : VBlock) (prelude : Array MInst),
      order.nodes[label]! = .original bi ∧
      lowerBlockCore ctx order f f.blocks[bi]! bi ranges[bi]!.1 ranges[bi]!.2 data order.successors[label]! input.state = .ok core ∧
      block.insts = prelude ++ core.code ∧ output.blocks = input.blocks.set! label block ∧
      ((∃ branch,core.branch = some branch ∧ step = branch.step) ∨
        ∃ record ∈ core.scan.output.records,record.output.step = some step) := by
  cases node : order.nodes[label]! with
  | edge pred k target =>
    unfold lowerNode at run
    simp only [node] at run
    cases args : branchArgs ctx input.state pred k with
    | error e => simp only [args, bind, Except.bind] at run; cases run
    | ok pair =>
      rcases pair with ⟨args, next⟩
      simp only [args, bind, Except.bind, pure, Except.pure] at run
      cases run
      exact False.elim (fresh member)
  | original bi =>
    let fetchData : Except String Backend.V := match f.blocks[bi]!.term with
      | .tryCall .. | .tryCallIndirect .. => tryCallData f f.blocks[bi]!.term
      | _ => termData (abiTerm f f.blocks[bi]!.term)
    let reject : Bool := (match f.blocks[bi]!.term with | .ret .. => true | _ => false) &&
      (sretRet f).isEmpty && (sigRets f.sig != f.sig.returns)
    have normal : lowerNode ctx ranges order f params label input = (do
        let data ← fetchData
        if reject then throw "sret parameter is not an entry-block parameter"
        let core ← lowerBlockCore ctx order f f.blocks[bi]! bi ranges[bi]!.1 ranges[bi]!.2
          data order.successors[label]! input.state
        let block ← assembleOriginalBlock ctx f f.blocks[bi]! bi label order.successors[label]!
          core.outgoing params core.state.uses core.code
        pure { recordCore input core bi ranges[bi]!.2 with
          blocks := input.blocks.set! label block,
          edgeArgs := input.edgeArgs.set! label core.outgoing }) := by
      unfold lowerNode
      simp only [node]
      dsimp only [fetchData, reject]
      split <;> simp_all only [reject] <;> rfl
    rw [normal] at run
    cases dataRun : fetchData with
    | error e => simp only [dataRun, bind, Except.bind] at run; cases run
    | ok data =>
      simp only [dataRun, bind, Except.bind] at run
      split at run
      · cases run
      · cases coreRun : lowerBlockCore ctx order f f.blocks[bi]! bi ranges[bi]!.1 ranges[bi]!.2
          data order.successors[label]! input.state with
        | error e => simp only [coreRun] at run; cases run
        | ok core =>
          simp only [coreRun] at run
          cases assembled : assembleOriginalBlock ctx f f.blocks[bi]! bi label order.successors[label]!
            core.outgoing params core.state.uses core.code with
          | error e => simp only [assembled] at run; cases run
          | ok block =>
            simp only [assembled, pure, Except.pure] at run
            cases run
            change step ∈ (recordCore input core bi ranges[bi]!.2).schedule.toList at member
            obtain ⟨prelude,assembledCode⟩ := assemble_suffix assembled
            exact ⟨bi,data,core,block,prelude,rfl,coreRun,assembledCode,rfl,record_origin member fresh⟩
private theorem nodes_origin {ctx : Ctx} {ranges : Array (Nat × Nat)} {order : Order}
    {f : Clif.Function} {params labels : List Nat} {input output : DriverState} {scheduled : Step}
    (run : labels.foldlM (fun d label => lowerNode ctx ranges order f params label d) input = .ok output)
    (member : scheduled ∈ output.schedule.toList) (fresh : scheduled ∉ input.schedule.toList) :
    ∃ (earlier suffix : List Nat) (label bi : Nat) (before after : DriverState)
      (data : Backend.V) (core : LoweredBlockCore) (block : VBlock) (prelude : Array MInst),
      labels = earlier ++ label :: suffix ∧
      earlier.foldlM (fun d k => lowerNode ctx ranges order f params k d) input = .ok before ∧
      lowerNode ctx ranges order f params label before = .ok after ∧
      suffix.foldlM (fun d k => lowerNode ctx ranges order f params k d) after = .ok output ∧
      order.nodes[label]! = .original bi ∧
      lowerBlockCore ctx order f f.blocks[bi]! bi ranges[bi]!.1 ranges[bi]!.2 data order.successors[label]! before.state = .ok core ∧
      block.insts = prelude ++ core.code ∧ after.blocks = before.blocks.set! label block ∧
      ((∃ branch,core.branch = some branch ∧ scheduled = branch.step) ∨
        ∃ record ∈ core.scan.output.records,record.output.step = some scheduled) := by
  induction labels generalizing input with
  | nil =>
    simp only [List.foldlM_nil,pure,Except.pure] at run
    cases run
    exact (fresh member).elim
  | cons label rest ih =>
    rw [List.foldlM_cons] at run
    obtain ⟨middle,call,remaining⟩ := Except.bind_ok run
    by_cases now : scheduled ∈ middle.schedule.toList
    · obtain ⟨bi,data,core,block,prelude,node,coreRun,assembled,installed,origin⟩ := node_origin call now fresh
      exact ⟨[],rest,label,bi,input,middle,data,core,block,prelude,rfl,rfl,call,remaining,node,coreRun,assembled,installed,origin⟩
    · obtain ⟨earlier,suffix,k,bi,before,after,data,core,block,prelude,parts,first,nodeRun,last,node,coreRun,assembled,installed,origin⟩ :=
        ih remaining now
      refine ⟨label::earlier,suffix,k,bi,before,after,data,core,block,prelude,?_,?_,nodeRun,last,node,coreRun,assembled,installed,origin⟩
      · simp only [List.cons_append,parts]
      · simpa only [List.foldlM_cons,call,bind,Except.bind] using first

private theorem node_install {ctx : Ctx} {ranges : Array (Nat × Nat)} {order : Order}
    {f : Clif.Function} {params : List Nat} {label : Nat} {input output : DriverState}
    (run : lowerNode ctx ranges order f params label input = .ok output) :
    ∃ block, output.blocks = input.blocks.set! label block := by
  unfold lowerNode at run
  dsimp only at run
  repeat' first
    | (solve | cases run)
    | simp only [bind, Except.bind, pure, Except.pure] at run
    | split at run
  all_goals
    cases run
    exact ⟨_,rfl⟩

private theorem node_size {ctx : Ctx} {ranges : Array (Nat × Nat)} {order : Order}
    {f : Clif.Function} {params : List Nat} {label : Nat} {input output : DriverState}
    (run : lowerNode ctx ranges order f params label input = .ok output) :
    output.blocks.size = input.blocks.size := by
  obtain ⟨block,installed⟩ := node_install run
  rw [installed]
  simp

private theorem node_frame {ctx : Ctx} {ranges : Array (Nat × Nat)} {order : Order}
    {f : Clif.Function} {params : List Nat} {label other : Nat} {input output : DriverState}
    (run : lowerNode ctx ranges order f params label input = .ok output) (different : other ≠ label) :
    output.blocks[other]? = input.blocks[other]? := by
  obtain ⟨block,installed⟩ := node_install run
  rw [installed]
  simp [Array.getElem?_setIfInBounds,Ne.symm different]


private theorem nodes_size {ctx : Ctx} {ranges : Array (Nat × Nat)} {order : Order}
    {f : Clif.Function} {params labels : List Nat} {input output : DriverState}
    (run : labels.foldlM (fun d k => lowerNode ctx ranges order f params k d) input = .ok output) :
    output.blocks.size = input.blocks.size := by
  induction labels generalizing input with
  | nil => cases run; rfl
  | cons label rest ih =>
    rw [List.foldlM_cons] at run
    cases call : lowerNode ctx ranges order f params label input with
    | error e => simp only [call,bind,Except.bind] at run; cases run
    | ok middle =>
      simp only [call,bind,Except.bind] at run
      exact (ih run).trans (node_size call)

private theorem nodes_frame {ctx : Ctx} {ranges : Array (Nat × Nat)} {order : Order}
    {f : Clif.Function} {params labels : List Nat} {other : Nat} {input output : DriverState}
    (run : labels.foldlM (fun d k => lowerNode ctx ranges order f params k d) input = .ok output)
    (different : ∀ k ∈ labels,other ≠ k) : output.blocks[other]? = input.blocks[other]? := by
  induction labels generalizing input with
  | nil => cases run; rfl
  | cons label rest ih =>
    rw [List.foldlM_cons] at run
    cases call : lowerNode ctx ranges order f params label input with
    | error e => simp only [call,bind,Except.bind] at run; cases run
    | ok middle =>
      simp only [call,bind,Except.bind] at run
      exact (ih run (fun k member => different k (List.mem_cons_of_mem _ member))).trans
        (node_frame call (different label (by simp)))


private def startDriver (initial : State) (n : Nat) : DriverState := {
  state := initial,blocks := Array.replicate n default,edgeArgs := Array.replicate n #[],
  schedule := #[],scans := #[],blockScans := #[],rules := #[] }

private theorem lower_code_origin {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) :
    ∃ (ranges : Array (Nat × Nat)) (params : List Nat) (driver : DriverState),
      Stock.buildCtx f = .ok (result.ctx,ranges,result.initial) ∧
      (Array.range result.order.nodes.size).reverse.toList.foldlM
        (fun d k => lowerNode result.ctx ranges result.order f params k d)
        (startDriver result.initial result.order.nodes.size) = .ok driver ∧
      result.schedule = driver.schedule ∧ result.final = driver.state ∧
      result.code.blocks = driver.blocks.map (fun b => {b with
        insts := b.insts.map (·.mapRegs (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1)))
        params := b.params.map (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1))
        branchArgs := b.branchArgs.map (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1))}) := by
  unfold Stock.lower at run
  dsimp only at run
  repeat' first
    | (solve | cases run)
    | simp only [bind,Except.bind,pure,Except.pure] at run
    | split at run
  cases run
  exact ⟨_,_,_,by assumption,by assumption,rfl,rfl,rfl⟩

/-- EVERY scheduled step has an actual original-node/core origin and placement
in the returned VCode, either as its separate branch or an actual scan record.
The witness is derived from the successful whole driver, not supplied by callers. -/
theorem stock_lower_scheduled_core_origin {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) {scheduled : Step}
    (member : scheduled ∈ result.schedule.toList) :
    ∃ (ranges : Array (Nat × Nat)) (label bi : Nat) (input : State) (data : Backend.V)
      (core : LoweredBlockCore) (block : VBlock) (prelude : Array MInst),
      Stock.buildCtx f = .ok (result.ctx,ranges,result.initial) ∧
      result.order.nodes[label]? = some (.original bi) ∧
      lowerBlockCore result.ctx result.order f f.blocks[bi]! bi ranges[bi]!.1 ranges[bi]!.2
        data result.order.successors[label]! input = .ok core ∧
      result.code.blocks[label]? = some block ∧
      block.insts = prelude.map (·.mapRegs (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1))) ++
        core.code.map (·.mapRegs (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1))) ∧
      ((∃ branch,core.branch = some branch ∧ scheduled = branch.step) ∨
        ∃ record ∈ core.scan.output.records,record.output.step = some scheduled) := by
  obtain ⟨ranges,params,driver,build,folded,schedule,final,blocks⟩ := lower_code_origin run
  rw [schedule] at member
  obtain ⟨earlier,suffix,label,bi,before,after,data,core,block,prelude,
    parts,first,nodeRun,last,node,coreRun,assembled,installed,origin⟩ := nodes_origin folded member (by simp [startDriver])
  have split := stock_backward_suffix_split parts
  have bound : label < before.blocks.size := by
    rw [nodes_size first]
    simpa only [startDriver,Array.size_replicate] using split.1
  have afterBlock : after.blocks[label]? = some block := by
    rw [installed,Array.set!_eq_setIfInBounds,Array.getElem?_setIfInBounds_self_of_lt bound]
  have finalBlock : driver.blocks[label]? = some block := by
    rw [nodes_frame last,afterBlock]
    intro k inside
    rw [split.2] at inside
    have small : k < label := by simpa using inside
    omega
  have atNode : result.order.nodes[label]? = some (.original bi) := by
    rw [getElem!_pos result.order.nodes label split.1] at node
    rw [Array.getElem?_eq_getElem split.1,node]
  let actual : VBlock := {block with
    insts := block.insts.map (·.mapRegs (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1)))
    params := block.params.map (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1))
    branchArgs := block.branchArgs.map (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1))}
  refine ⟨ranges,label,bi,before.state,data,core,actual,prelude,build,atNode,coreRun,?_,?_,origin⟩
  · simp only [blocks,Array.getElem?_map,finalBlock,Option.map_some,actual]
  · simp only [actual,assembled,Array.map_append]
end Backend.Stock.Proof.ScheduledOriginDraft
