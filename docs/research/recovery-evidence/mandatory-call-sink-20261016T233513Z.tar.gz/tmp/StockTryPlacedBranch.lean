import StockScheduledOrigin
import StockTrySourceContext
import FV.Backend.Proof.StockEmittedScan
namespace Backend.Stock.Proof.TryPlacedBranchDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open ScheduledOriginDraft TrySourceContextDraft TryBranchRecordsDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
attribute [local irreducible] Stock.runTerm emitInstruction emitBranch branchArgs collectOutgoing scanBlock lowerBlockCore
private theorem scan_fields {ctx : Ctx} {block i ti : Nat} {branch : Bool} {input : State} {output : Scan} {step : Step}
    (run : scanInstruction ctx block i ti branch input = .ok output) (recorded : output.step = some step) :
    step.block = block ∧ step.inst = i ∧ step.emitted = output.emitted := by
  unfold scanInstruction at run
  dsimp only at run
  repeat' first
    | (solve | cases run)
    | simp only [bind,Except.bind,pure,Except.pure] at run
    | split at run
  all_goals cases run <;> cases recorded <;> exact ⟨rfl,rfl,rfl⟩
private theorem record_run {ctx : Ctx} {block ti : Nat} {branch : Bool} {indices : List Nat}
    {input : State} {output : BlockScan}
    (run : scanBlock ctx block ti branch indices input = .ok output) :
    ∀ record ∈ output.records,scanInstruction ctx block record.inst ti branch record.input = .ok record.output := by
  unfold scanBlock at run
  have cert := runScans_spec run
  clear run
  induction cert with
  | nil input => simp
  | cons head rest ih =>
    intro record member
    simp only [List.mem_cons] at member
    rcases member with rfl | member
    · exact head
    · exact ih record member
private theorem core_branch_run {ctx : Ctx} {order : Order} {f : Clif.Function} {b : Clif.Block}
    {bi start stop : Nat} {data : Backend.V} {targets : Array Nat} {input : State} {core : LoweredBlockCore}
    (run : lowerBlockCore ctx order f b bi start stop data targets input = .ok core)
    {branch : BranchEmission} (selected : core.branch = some branch) :
    emitBranch {ctx with insts := ctx.insts.set! (stop-1) ⟨data,[],[],none⟩,tryRegs := input.tryRegs[stop-1]!}
      f b.term bi (stop-1) targets input = .ok branch := by
  cases call : emitBranch {ctx with insts := ctx.insts.set! (stop-1) ⟨data,[],[],none⟩,tryRegs := input.tryRegs[stop-1]!}
      f b.term bi (stop-1) targets input <;>
    unfold lowerBlockCore at run <;> dsimp only at run <;>
    simp only [call,Functor.map,Except.map] at run
  all_goals
    repeat' first
      | (solve | cases run)
      | simp only [bind,Except.bind,pure,Except.pure] at run
      | split at run
    all_goals cases run <;> cases selected <;> first | rfl | exact call
private theorem core_code {ctx : Ctx} {order : Order} {f : Clif.Function} {b : Clif.Block}
    {bi start stop : Nat} {data : Backend.V} {targets : Array Nat} {input : State} {core : LoweredBlockCore}
    (run : lowerBlockCore ctx order f b bi start stop data targets input = .ok core)
    {branch : BranchEmission} (selected : core.branch = some branch) :
    core.code = core.scan.output.code ++ branch.code := by
  unfold lowerBlockCore at run
  dsimp only at run
  repeat' first
    | (solve | cases run)
    | simp only [bind,Except.bind,pure,Except.pure,Functor.map,Except.map] at run
    | split at run
  all_goals cases run <;> simp_all
private theorem core_isBranch {ctx : Ctx} {order : Order} {f : Clif.Function} {b : Clif.Block}
    {bi start stop : Nat} {data : Backend.V} {targets : Array Nat} {input : State} {core : LoweredBlockCore}
    (run : lowerBlockCore ctx order f b bi start stop data targets input = .ok core)
    (isTry : b.term.isTry = true) : core.scan.isBranch = true := by
  cases term : b.term <;> simp only [term,Clif.Terminator.isTry] at isTry
  all_goals try contradiction
  all_goals
    unfold lowerBlockCore at run
    simp only [term] at run
    try dsimp only at run
    repeat' first
      | (solve | cases run)
      | simp only [bind,Except.bind,pure,Except.pure,Functor.map,Except.map] at run
      | split at run
    all_goals cases run; rfl
private theorem term_scan_not_emitted {ctx : Ctx} {block ti : Nat} {input : State} {output : Scan} {step : Step}
    (run : scanInstruction ctx block ti ti true input = .ok output) (recorded : output.step = some step)
    (emitted : step.decision = .emitted) : False := by
  cases sunk : input.sunk[ti]! with
  | false => simp only [scanInstruction,sunk,beq_self_eq_true,Bool.true_and,ite_true,Bool.false_eq_true,ite_false] at run
             cases run; cases recorded
  | true => simp only [scanInstruction,sunk,ite_true] at run
            cases run; cases recorded; cases emitted
/-- A SAME actual scheduled TryCall branch is the terminal suffix of its SAME
returned VCode original block. Membership/origin, source label, term index,
assembly, traversal preservation and final aliases are all derived internally. -/
theorem stock_lower_try_branch_placed {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f)
    {label bi : Nat} {b : Clif.Block} (node : result.order.nodes[label]? = some (.original bi))
    (block : f.blocks[bi]? = some b) (isTry : b.term.isTry = true)
    (source : TryBranchSource f result label bi b) :
    ∃ (vb : VBlock) (prelude : Array MInst),result.code.blocks[label]? = some vb ∧
      vb.insts = prelude ++ source.branch.step.emitted.map
        (·.mapRegs (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1))) := by
  obtain ⟨ranges,placedLabel,actualBi,input,data,core,vb,prelude,build,actualNode,coreRun,placed,assembled,origin⟩ :=
    stock_lower_scheduled_core_origin lowered source.scheduled
  have actualFacts := stock_emitBranch_record source.emitted
  have metadata := stock_lowerBlockCore_scanOrigin coreRun
  have current : actualBi = bi := by
    rcases origin with ⟨branch,selected,equal⟩ | ⟨record,inside,recorded⟩
    · have emitted := core_branch_run coreRun selected
      have fields := stock_emitBranch_record emitted
      exact fields.1.symm.trans ((congrArg Step.block equal).symm.trans actualFacts.1)
    · have scan := record_run metadata.2.2.2.2.2 record inside
      have fields := scan_fields scan recorded
      exact metadata.2.2.1.symm.trans (fields.1.symm.trans actualFacts.1)
  subst actualBi
  have original : f.blocks[bi]! = b := by simp only [getElem!_def,block,Option.getD_some]
  have selected : ∃ branch,core.branch = some branch ∧ source.branch.step = branch.step := by
    rcases origin with actual | ⟨record,inside,recorded⟩
    · exact actual
    · have scan := record_run metadata.2.2.2.2.2 record inside
      have fields := scan_fields scan recorded
      obtain ⟨oldCtx,oldState,oldBuild,spec,view⟩ := buildCtx_source build
      have range : ranges[bi]! = (blockStart f bi,blockStart f bi+b.body.length+1) := by
        simp only [getElem!_def,spec.ranges bi b block,Option.getD_some]
      have sameIndex : record.inst = core.scan.termInst := by
        have first : record.inst = source.ti := fields.2.1.symm.trans actualFacts.2.1
        rw [first,source.index,metadata.2.2.2.1,range]
        simp
      have branchKind : core.scan.isBranch = true := core_isBranch coreRun (by rw [original]; exact isTry)
      rw [sameIndex,branchKind] at scan
      exact (term_scan_not_emitted scan recorded actualFacts.2.2.1).elim
  obtain ⟨branch,branchSelected,equal⟩ := selected
  have nonempty : f.blocks.length ≠ 0 := fun h => scope.nonempty (List.length_eq_zero_iff.mp h)
  have sameLabel := stock_blockOrder_original_unique (stock_lower_order lowered) nonempty actualNode node
  subst placedLabel
  have emitted := core_branch_run coreRun branchSelected
  have code : branch.code = source.branch.step.emitted := by
    rw [equal,(stock_emitBranch_record emitted).2.2.2.2]
  refine ⟨vb,prelude.map (·.mapRegs (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1))) ++ core.scan.output.code.map
    (·.mapRegs (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1))),placed,?_⟩
  rw [assembled,core_code coreRun branchSelected,Array.map_append,code,Array.append_assoc]
end Backend.Stock.Proof.TryPlacedBranchDraft
