from pathlib import Path
import os,signal,subprocess as sp,time,json,datetime
root=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');pid=4094834
assert '/tmp/stock-execute-scheduler.py' in Path(f'/proc/{pid}/cmdline').read_text()
# Reuse the exact environment, input freeze and logged command runner, with a
# separate evidence directory. No duplicate proof workers are launched.
prefix=Path('/tmp/stock-d0-affected-gates.py').read_text().split('\ntry:\n')[0]
prefix=prefix.replace("Path('/tmp/stock-d0-affected-gates')", "Path('/tmp/stock-d0-independent-gates')")
exec(compile(prefix,'/tmp/stock-d0-affected-gates.py','exec'),globals())
def held_caps():
 active={}
 for line in Path('/tmp/stock-d0-complete-witness-controller.log').read_text().splitlines():
  a=line.split()
  if len(a)>3 and a[1]=='start': active[a[2]]=float(a[3].split('=')[1].rstrip('G'))
  elif len(a)>2 and a[1]=='done': active.pop(a[2],None)
 held={}
 for proc in Path('/proc').iterdir():
  if not proc.name.isdigit():continue
  try:
   status=(proc/'status').read_text();parent=int(next(l.split()[1] for l in status.splitlines() if l.startswith('PPid:')))
   if parent!=pid or '\nState:\tZ' in status:continue
   cmd=(proc/'cmdline').read_bytes().decode().replace('\x00',' ')
   for module,cap in active.items():
    if '/'+module+'.time ' in cmd: held[module]=cap
  except (OSError,StopIteration,ValueError):continue
 return held
os.kill(pid,signal.SIGSTOP)
try:
 report('waiting_for_reserved_proof_caps',suspended_scheduler=pid)
 while sum(held_caps().values())+8>16:time.sleep(2)
 held=held_caps();assert set(held)<= {'FV.Backend.Proof.DefGenTab'},held
 assert 'Build completed successfully' in Path('/tmp/stock-d0-complete-witness-build/FV.Backend.Proof.IselShpTotal.log').read_text()
 report('running_independent_gates',reserved_proof_caps=held,total_reserved_gib=sum(held.values())+8)
 run('tool-modules',['python3','/tmp/stock-execute-scheduler.py','--budget','8G','--max-jobs','2','--max-cap','8G','--default-cap','6G','--others-by-usage','--out',str(root/'tool-modules'),'FVTest.Backend.Main','FVTest.E2E.Check','FVTest.E2E.LinkCheckMain','FVTest.Front.DecodeMain','FVTest.Backend.Lowering.StockComparison'])
 run('tools',['lake','build','lean-backend','lean-e2e-check','link-check','clif-decode','lean-stock-lowering-compare'])
 run('runtime',['bash','scripts/lean-backend-filetests.sh'])
 run('encoder',['bash','scripts/lean-backend-encode-check.sh'])
 for label,flags in [('e2e',[]),('legacy-e2e',['--no-dead-cleanup'])]:
  run(label,['lake','exe','lean-e2e-check',*flags,'--identity-report',str(root/(label+'-identities.json'))])
 parity={}
 for label,old in [('e2e','legacy-dead-cleanup-final-e2e-identities.json'),('legacy-e2e','legacy-dead-cleanup-final-legacy-e2e-identities.json')]:
  def ids(p):
   fs=json.loads(p.read_text())['functions'];d={(f['file'],f['index'],f['function']):tuple(f['stages']) for f in fs};assert len(d)==len(fs);return d
  a=ids(Path('/tmp')/old);b=ids(root/(label+'-identities.json'));assert len(a)==1150 and a.keys()<=b.keys();assert all(a[k]==b[k] for k in a)
  parity[label]={'original':len(a),'current':len(b),'all_original_identities_and_ordered_stages_preserved':True,'gained':len(b.keys()-a.keys())}
 (root/'identity-stage-parity.json').write_text(json.dumps(parity,indent=2)+'\n')
 report('independent_runtime_encoder_e2e_passed',identity_stage_parity=parity,remaining='formal witness/linker module gate; lean-link and verified crates; trust audit; full FV/FVTest gate and main reconciliation')
except BaseException as e:report('failed',error=repr(e));raise
finally:os.kill(pid,signal.SIGCONT)
