import FV.Backend
open Backend Backend.Stock.D0

def main (paths : List String) : IO Unit := do
  if paths.isEmpty then throw (IO.userError "no production dumps selected")
  for path in paths do
    let parsed := Clif.parseFile (← IO.FS.readFile path)
    if parsed.funcs.length != 1 then throw (IO.userError s!"expected one decoded function: {path}")
    for pf in parsed.funcs do
      let f ← match pf.func with
        | .ok f => pure f
        | .error _ => throw (IO.userError s!"production dump does not parse: {path}")
      match selectWith Stock.lower f with
      | .ok (.stockD0, _) => IO.println s!"PRODUCTION_STOCK_ROUTE {f.name} {path}"
      | _ => throw (IO.userError s!"production fixture failed to select Stock: {path}")
