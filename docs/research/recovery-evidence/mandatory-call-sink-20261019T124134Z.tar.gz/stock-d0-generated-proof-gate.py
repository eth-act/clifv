from pathlib import Path
import subprocess as sp,json,os,re,datetime,hashlib,traceback
view=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');gate=Path('/tmp/stock-d0-generated-proof-gate');gate.mkdir(exist_ok=True)
env=dict(os.environ,PATH='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:/home/lee/.cargo/bin:/home/lee/.local/share/clifv-test-tools/usr/bin:'+str(view/'rust/target/release')+':'+os.environ['PATH'],FV_ROOT=str(view),FV_MEMCAP='8G',FV_LAKE_CACHE='/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache',OMP_NUM_THREADS='2',LEAN_NUM_THREADS='2')
head=sp.check_output(['git','rev-parse','HEAD'],cwd=view,text=True).strip();logs=[]
def state(status,**kw):
 (gate/'progress.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':status,'pid':os.getpid(),'head':head,'logs':logs,**kw},indent=2)+'\n');print(status,kw,flush=True)
def run(name,args,cwd=view):
 assert sp.check_output(['git','rev-parse','HEAD'],cwd=view,text=True).strip()==head
 log=gate/(name+'.log');state('running',phase=name)
 with log.open('w') as f:r=sp.run([str(view/'scripts/memcap.sh'),*args],cwd=cwd,env=env,stdout=f,stderr=sp.STDOUT)
 assert r.returncode==0,(name,r.returncode,str(log));logs.append({'phase':name,'path':str(log),'sha256':hashlib.sha256(log.read_bytes()).hexdigest()})
try:
 units=view/'examples/fv-demo/target/fv/plain-leanlink-verified-leanld/units';candidates=[]
 for p in units.glob('*.json'):
  d=json.loads(p.read_text());fns=[f for f in d.get('functions',[]) if any(n in f.get('instance','') for n in ['stock_entry_return::identity32','stock_entry_return::identity64'])]
  if d.get('kind')=='test' and d.get('src')=='src/lib.rs' and len(fns)==2:candidates.append((p.stat().st_mtime,d,fns))
 assert candidates,'verified mixed test executable missing';_,unit,fns=max(candidates,key=lambda c:c[0]);assert all(f['status']=='verified' for f in fns)
 source=gate/'StockD0Mixed.lean'
 run('generate',['cargo','fv','link-proof','--exe',unit['artifact'],'--crate','fv_demo','--out',str(gate/'input'),'--lean',str(source),'--module','StockD0Mixed','--entries',','.join(f['symbol'] for f in fns)],cwd=view/'examples/fv-demo')
 assert source.is_file();seen=set();order=[]
 def visit(p):
  if p in seen:return
  seen.add(p)
  for name in re.findall(r'^import\s+(\S+)',p.read_text(),re.M):
   q=gate/(name.replace('.','/')+'.lean')
   if q.is_file():visit(q)
  order.append(p)
 visit(source)
 leanpath=sp.check_output(['lake','env','printenv','LEAN_PATH'],cwd=view,env=env,text=True).strip();env['LEAN_PATH']=str(gate)+':'+leanpath
 for i,p in enumerate(order):run(f'kernel-{i:03}', ['lean','--root='+str(gate),'-o',str(p.with_suffix('.olean')),str(p)])
 (gate/'manifest.json').write_text(json.dumps({'head':head,'artifact':unit['artifact'],'selected_verified_functions':fns,'generated_modules':[{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in order],'scope':'Generated instance proofs retain the existing per-program native_decide checks; the fixed compiler and D0 semantic theorem audit is separate and standard-three only.'},indent=2)+'\n')
 state('passed_generated_mixed_program_proofs',modules=len(order),entries=len(fns))
except BaseException as e:state('failed',error=repr(e),traceback=traceback.format_exc());raise
