from pathlib import Path
import os,signal,subprocess as sp,json
root=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');pid=4094834
assert '/tmp/stock-execute-scheduler.py' in Path(f'/proc/{pid}/cmdline').read_text()
os.kill(pid,signal.SIGSTOP)
try:
 active={}
 for line in Path('/tmp/stock-d0-complete-witness-controller.log').read_text().splitlines():
  parts=line.split()
  if len(parts)>3 and parts[1]=='start':active[parts[2]]=float(parts[3].split('=')[1].rstrip('G'))
  elif len(parts)>2 and parts[1]=='done':active.pop(parts[2],None)
 assert 'FVTest.Backend.Lowering.StockD0Runtime' not in active,'target already compiling'
 assert sum(active.values())+4<=16,active
 env=dict(os.environ,PATH='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:'+os.environ['PATH'],FV_MEMCAP='4G',FV_LAKE_CACHE='/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache',OMP_NUM_THREADS='2',LEAN_NUM_THREADS='2')
 with open('/tmp/stock-d0-actual-runtime.log','w') as log:r=sp.run(['scripts/memcap.sh','lake','env','lean','--run','FVTest/Backend/Lowering/StockD0Runtime.lean'],cwd=root,env=env,stdout=log,stderr=sp.STDOUT)
 Path('/tmp/stock-d0-runtime-lane-result.json').write_text(json.dumps({'returncode':r.returncode,'other_reserved_caps':active,'total_cap_gib':sum(active.values())+4,'log':'/tmp/stock-d0-actual-runtime.log'},indent=2)+'\n')
 print('Runtime returncode',r.returncode)
finally:os.kill(pid,signal.SIGCONT)
