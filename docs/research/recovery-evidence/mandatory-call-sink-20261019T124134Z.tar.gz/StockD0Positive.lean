import FV.Backend.Proof.StockD0Code
namespace Backend.Stock.D0
set_option maxRecDepth 100000
set_option maxHeartbeats 8000000
set_option Elab.async false
theorem direct_actual_stock_positive (name : String) (c : Configuration) (runs : List Clif.RunCommand) :
    (Stock.lower (source name c runs)).isOk = true := by
  cases c <;> d0_open_kernel_decide
#print axioms direct_actual_stock_positive
end Backend.Stock.D0
