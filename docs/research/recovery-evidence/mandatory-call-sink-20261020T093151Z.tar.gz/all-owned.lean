import FV.E2E.ArithmeticPipelineWitness
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let core := #["FV.Backend.ArithmeticProduction", "FV.Backend.Lowering.StockArithmetic", "FV.Backend.Proof.ArithmeticProduction", "FV.Backend.Proof.StockArithmeticCheck", "FV.Backend.StockArithmeticCheck", "FV.E2E.ArithmeticPipeline", "FV.E2E.CompiledSemantic", "FV.E2E.StockArithmeticStage", "FV.E2E.StockArithmeticWorldX"]
  let witnesses := #["FV.E2E.StockArithmeticStageWitness", "FV.E2E.ArithmeticPipelineWitness"]
  let mut ncore : Nat := 0
  let mut nwitness : Nat := 0
  for (name,_) in env.constants.toList do
    let some i := env.getModuleIdxFor? name | continue
    let owned := env.header.moduleNames[i]!.toString
    unless core.contains owned || witnesses.contains owned do continue
    for ax in ← collectAxioms name do
      if #[``propext,``Classical.choice,``Quot.sound].contains ax then continue
      let permittedNative := #["E2E.StockArithmeticStageWitness.checks_true._native.native_decide.ax_1", "E2E.ArithmeticPipelineWitness.checks_true._native.native_decide.ax_1"].contains ax.toString
      unless witnesses.contains owned && permittedNative do
        throwError "disallowed axiom {ax} in {name}"
    if core.contains owned then ncore := ncore+1 else nwitness := nwitness+1
  unless ncore > 0 do throwError "empty core partition"
  unless nwitness > 0 do throwError "empty witness partition"
  logInfo m!"ENTRY_CORE_STANDARD_ONLY {ncore}; FIXED_WITNESS_CONSTANTS {nwitness}"
