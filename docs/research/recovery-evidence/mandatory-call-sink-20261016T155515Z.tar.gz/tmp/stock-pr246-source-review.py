from pathlib import Path
import subprocess as sp,json,hashlib,datetime,ast
root=Path('/home/lee/clifv/.worktrees/driver-proof-resume');base='032d576442e48aeb5de9062103c970d18b8d0739';head='44abfd79cbe4cda5ed868054b7f9e166152cf709'
for p in ['/tmp/stock-pr246-gates.py','/tmp/stock-pr246-completion-audit.py','/tmp/stock-pr246-mcp-bundle.py']:ast.parse(Path(p).read_text())
def tree(ref):
 out={}
 for row in sp.check_output(['git','ls-tree','-r',ref],cwd=root,text=True).splitlines():
  meta,p=row.split('\t',1);out[p]=meta.split()[2]
 return out
before=tree(base);after=tree(head);modified=[p for p,b in before.items() if after.get(p)!=b];added=[p for p in after if p not in before]
assert not [p for p in modified if p.startswith('FV/')]
assert set(modified)=={'FVTest/Backend/Lowering/StockComparison.lean','FVTest/Backend/Lowering/StockTest.lean','FVTest/Backend/StockConfig.lean'}
b=json.loads((root/'docs/research/stock-body-form-checkpoint.json').read_text());core=json.loads(Path('/tmp/stock-delivery-core-paths.json').read_text());matching={}
for p in core['paths']:
 raw=sp.check_output(['git','show',head+':'+p],cwd=root);digest=hashlib.sha256(raw).hexdigest();assert b['sources'][p]==digest,p;matching[p]=digest
r={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pr':246,'base':base,'head':head,'all_preexisting_FV_library_sources_byte_identical':True,'all_preexisting_FV_FVTest_sources_except3Stock_consumers_unchanged':True,'modified_existing_paths':modified,'added_paths':added,'all55_changed_Lean_sources_match_historically_full_validated_snapshot':matching,'historical_checkpoint':'docs/research/stock-body-form-checkpoint.json','historical_normal_audit':b['normal_full_audit']['normal_audit']['path'],'historical_validation_is_NOT_current_gate_evidence':True,'old_library_theorem_variants_input_conditions_and_production_defaults':'No preexisting FV library source or production/compiler/checker/linker source modified; new runtime and proof names added. StockConfig only imports the new indexed driver and adds allocateAt; its old allocate implementation remains unchanged. Stock comparison/test consumers use indexed preparation/allocation.','current_full_gates':'RUNNING in clean exact44abfd79 view under exclusive one-cache lease','MCP_plan':'ONE bundled check of every exact-PR public root plus all documented compiler theorem variants after current gates; script /tmp/stock-pr246-mcp-bundle.py; no extra scratch MCP calls','full_goal':'ORIGINAL#140 active/incomplete; production legacy'}
(root/'docs/research/stock-pr246-source-review.json').write_text(json.dumps(r,indent=2)+'\n');print('PASS existing FV library bytes preserved;55/55 historical changed-source hashes match; exactly3existing Stock consumers change')
