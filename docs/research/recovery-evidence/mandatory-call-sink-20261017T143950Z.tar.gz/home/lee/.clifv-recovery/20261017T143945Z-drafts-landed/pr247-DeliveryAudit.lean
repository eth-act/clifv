import Lean
import FV.Backend.Proof.Encode
import FV.Backend.Proof.FilteredGraphIncoming
import FV.Backend.Proof.FormsCoverComplete
import FV.Backend.Proof.IndexedPredMultiplicity
import FV.Backend.Proof.LowerComplete
import FV.Backend.Proof.LowerLoop
import FV.Backend.Proof.PerEdgeArgumentShape
import FV.Backend.Proof.PerEdgeParameterShape
import FV.Backend.Proof.PerEdgePrepSplitWitness
import FV.Backend.Proof.PerEdgePrepareJump
import FV.Backend.Proof.PerEdgePrepareNoSplit
import FV.Backend.Proof.PerEdgePrepareUnsplitGraph
import FV.Backend.Proof.PerEdgePreparedArity
import FV.Backend.Proof.PerEdgeRouteArity
import FV.Backend.Proof.PerEdgeSpillBlock
import FV.Backend.Proof.PerEdgeSpillCopy
import FV.Backend.Proof.PerEdgeSpillCycleFixture
import FV.Backend.Proof.PerEdgeSpillEdge
import FV.Backend.Proof.PerEdgeSpillEntry
import FV.Backend.Proof.PerEdgeSpillEntryFixture
import FV.Backend.Proof.PerEdgeSpillEntryGood
import FV.Backend.Proof.PerEdgeSpillEntrySaves
import FV.Backend.Proof.PerEdgeSpillEntrySymbols
import FV.Backend.Proof.PerEdgeSpillEntryWitness
import FV.Backend.Proof.PerEdgeSpillHomes
import FV.Backend.Proof.PerEdgeSpillInst
import FV.Backend.Proof.PerEdgeSpillInstFixture
import FV.Backend.Proof.PerEdgeSpillInstWitness
import FV.Backend.Proof.PerEdgeSpillJumpWitness
import FV.Backend.Proof.PerEdgeSpillPreState
import FV.Backend.Proof.PerEdgeSpillRoutes
import FV.Backend.Proof.PerEdgeSpillSharedFixture
import FV.Backend.Proof.PerEdgeSpillSharedJump
import FV.Backend.Proof.PerEdgeSpillStateAt
import FV.Backend.Proof.PerEdgeSpillTerminalBlock
import FV.Backend.Proof.PerEdgeSpillWitness
import FV.Backend.Proof.PrepareComplete
import FV.Backend.Proof.PrepareDirect
import FV.Backend.Proof.PrepareReachability
import FV.Backend.Proof.PreparedArityWitness
import FV.Backend.Proof.ReorderedGraphIncoming
import FV.Backend.Proof.StockBranchArgumentShape
import FV.Backend.Proof.StockBranchCfg
import FV.Backend.Proof.StockBranchHelperProjection
import FV.Backend.Proof.StockBranchHelperTargets
import FV.Backend.Proof.StockBranchRootTargets
import FV.Backend.Proof.StockBranchSelection
import FV.Backend.Proof.StockBranchTargetsWitness
import FV.Backend.Proof.StockCfgTotal
import FV.Backend.Proof.StockCfgTotalWitness
import FV.Backend.Proof.StockConditionalRootTargets
import FV.Backend.Proof.StockConditionalTargets
import FV.Backend.Proof.StockConditionalTargetsWitness
import FV.Backend.Proof.StockControlCfgWitness
import FV.Backend.Proof.StockControlShape
import FV.Backend.Proof.StockCriticalEdgeArity
import FV.Backend.Proof.StockEdgeArity
import FV.Backend.Proof.StockEdgeValuesWitness
import FV.Backend.Proof.StockEmittedGraph
import FV.Backend.Proof.StockEmittedGraphWitness
import FV.Backend.Proof.StockEntryCode
import FV.Backend.Proof.StockEntryGraph
import FV.Backend.Proof.StockEntryOrder
import FV.Backend.Proof.StockGraphBounds
import FV.Backend.Proof.StockGraphEdges
import FV.Backend.Proof.StockJumpEdgeValues
import FV.Backend.Proof.StockNamedBranchTargets
import FV.Backend.Proof.StockNodeCoverage
import FV.Backend.Proof.StockNodeCoverageWitness
import FV.Backend.Proof.StockOrderGraphWitness
import FV.Backend.Proof.StockOrdinaryCfg
import FV.Backend.Proof.StockOutgoingShape
import FV.Backend.Proof.StockParameterShape
import FV.Backend.Proof.StockPerEdgeDirectWitness
import FV.Backend.Proof.StockPerEdgeM6DivergenceWitness
import FV.Backend.Proof.StockPerEdgeM6StuckWitness
import FV.Backend.Proof.StockPrepareTotal
import FV.Backend.Proof.StockPreparedArity
import FV.Backend.Proof.StockReturnContract
import FV.Backend.Proof.StockReturnScanShape
import FV.Backend.Proof.StockReturnSourceWitness
import FV.Backend.Proof.StockReturnVCode
import FV.Backend.Proof.StockSourceCallWitness
import FV.Backend.Proof.StockSourceResults
import FV.Backend.Proof.StockSpillCopyMetadata
import FV.Backend.Proof.StockSpillCopyMetadataWitness
import FV.Backend.Proof.StockTerminalCfg
import FV.Backend.Proof.StockTerminalPlacement
import FV.Backend.Proof.StockTryCfg
import FV.E2E.AllocDirect
import FV.E2E.AllocTotal
import FV.E2E.BinaryGood
import FV.E2E.DeadCleanupExecBytes
import FV.E2E.DeadCleanupExecGoodReads
import FV.E2E.DeadCleanupExecGoodRun
import FV.E2E.DeadCleanupExecGot
import FV.E2E.DeadCleanupExecPeak
import FV.E2E.DeadCleanupExecProven
import FV.E2E.DeadCleanupExecRunN
import FV.E2E.DeadCleanupExecStatic
import FV.E2E.DeadCleanupFinal
import FV.E2E.DeadCleanupLegal
import FV.E2E.DeadCleanupLegalDirect
import FV.E2E.DeadCleanupOptProven
import FV.E2E.DeadCleanupSize
import FV.E2E.DeadCleanupStackBound
import FV.E2E.DeadCleanupTotal
import FV.E2E.EmitTotal
import FV.E2E.EmitTotalIn
import FV.E2E.ExecBytes
import FV.E2E.ExecGoodReads
import FV.E2E.ExecGoodRun
import FV.E2E.ExecGot
import FV.E2E.ExecProven
import FV.E2E.ExecRunN
import FV.E2E.ExecStatic
import FV.E2E.Final
import FV.E2E.FinalDirect
import FV.E2E.Legal
import FV.E2E.LegalDepth
import FV.E2E.LegalDirect
import FV.E2E.LegalProgram
import FV.E2E.LinkArm
import FV.E2E.LinkGood
import FV.E2E.NonVacuity
import FV.E2E.OptProven
import FV.E2E.RelaxTotal
import FV.E2E.SizeIn
import FV.E2E.SpillDefined
import FV.E2E.SpillKillFree
import FV.E2E.StackBound
import FV.Front.BundleProof
import FV.Front.Exe
import FV.Front.Raw
import FV.Front.RawExe
import FV.Front.RawProof
import FV.Front.RenameRun
import FV.Link.Correct
import FV.Link.DeadCleanupCorrect
import FV.Link.DeadCleanupExe
import FV.Link.DeadCleanupExePeak
import FV.Link.DeadCleanupExeSource
import FV.Link.DeadCleanupExeTotal
import FV.Link.DeadCleanupLayoutProof
import FV.Link.Exe
import FV.Link.ExeInput
import FV.Link.ExeInputCleanup
import FV.Link.ExeInputReach
import FV.Link.ExeInputReachCleanup
import FV.Link.ExeSource
import FV.Link.ExeTotal
import FV.Link.LayoutProof
import FV.Link.NonVacuityDeadCleanupExeSource
import FV.Link.NonVacuityExeSource
import FV.Opt.Proof.LegalPre
import FV.Opt.Proof.RuleAll
import FV.Opt.Proof.SimpPass
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
namespace StockDeliveryAudit
def Root (P : Prop) (_proof : P) : Prop := P
theorem pr247_bundle :
  Root _ (@Backend.AState.parCopy.eq_1) ∧
  Root _ (@Backend.CheckCtx.checkStatic.eq_1) ∧
  Root _ (@Backend.CheckCtx.stepOp.eq_1) ∧
  Root _ (@Backend.Insn.decode_encode) ∧
  Root _ (@Backend.MInst.isBranch.eq_def) ∧
  Root _ (@Backend.MInst.isRet.eq_1) ∧
  Root _ (@Backend.MInst.isRet.eq_2) ∧
  Root _ (@Backend.MInst.isRet.eq_3) ∧
  Root _ (@Backend.MInst.isRet.eq_def) ∧
  Root _ (@Backend.MInst.isTerminator.eq_1) ∧
  Root _ (@Backend.MInst.isTerminator.eq_2) ∧
  Root _ (@Backend.MInst.isTerminator.eq_def) ∧
  Root _ (@Backend.MInst.targets.eq_def) ∧
  Root _ (@Backend.Proof.Driver.formsCovered_complete) ∧
  Root _ (@Backend.Proof.Driver.lowerCheck_complete) ∧
  Root _ (@Backend.Proof.Driver.prepDomain_of_lower) ∧
  Root _ (@Backend.Proof.PerEdgePrep.innerStepAt.eq_1) ∧
  Root _ (@Backend.Proof.PerEdgePrep.keepOrigin_injective) ∧
  Root _ (@Backend.Proof.PerEdgePrep.keepOrigin_spec) ∧
  Root _ (@Backend.Proof.PerEdgePrep.keep_cfg_edge) ∧
  Root _ (@Backend.Proof.PerEdgePrep.keep_no_critical) ∧
  Root _ (@Backend.Proof.PerEdgePrep.outerLoopAt_no_new_edges) ∧
  Root _ (@Backend.Proof.PerEdgePrep.prepareAt_all_reachable) ∧
  Root _ (@Backend.Proof.PerEdgePrep.prepareAt_argument_shape) ∧
  Root _ (@Backend.Proof.PerEdgePrep.prepareAt_edge_arguments) ∧
  Root _ (@Backend.Proof.PerEdgePrep.prepareAt_edge_arity) ∧
  Root _ (@Backend.Proof.PerEdgePrep.prepareAt_jump_counterpart) ∧
  Root _ (@Backend.Proof.PerEdgePrep.prepareAt_no_new_edges) ∧
  Root _ (@Backend.Proof.PerEdgePrep.prepareAt_parameter_shape) ∧
  Root _ (@Backend.Proof.PerEdgePrep.prepareAt_routed_edge_arity) ∧
  Root _ (@Backend.Proof.PerEdgePrep.reorder_cfg_edge) ∧
  Root _ (@Backend.Proof.PerEdgePrep.reorder_index_injective) ∧
  Root _ (@Backend.Proof.PerEdgePrep.unsplit_cfg_eq) ∧
  Root _ (@Backend.Proof.PerEdgePrepSplitWitness.per_edge_prepare_actual_split_step_witness) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.EdgeTransferAt.checked) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.EdgeTransferAt.entry) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.EdgeTransferAt.formula) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.EdgeTransferAt.other) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.EdgeTransferAt.parameter) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.EdgeTransferAt.size) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.EntryAvailAt.argClasses) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.EntryAvailAt.arguments) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.EntryAvailAt.ordinary) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.EntryAvailAt.paramClasses) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.GoodAt.home) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.GoodAt.save) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.GoodAt.size) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.HomesSpec.code) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.HomesSpec.outgoing) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.HomesSpec.valid) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.bodyContentAt.eq_1) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.bodyContentAt.eq_2) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.bodyContentAt.eq_3) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.bodyItem.eq_1) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.bodyStateAt.eq_1) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.bodyStateAt_good) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.bodyStateAt_le) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.edgeAt_of_metadata) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.entryState_saved) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.homeLookup.eq_1) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.p2.eq_1) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.preEntryStateAt_shared_le) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.preEntryStateAt_unique_le) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.preEntryStateAt_unique_runs) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.spillAllocAt_block) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.spillAllocAt_storage) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.spillArgMovesAt_runs) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.spillHomeKeyAt_injective) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.spillHomesAt_spec) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.spillInstAt_runs) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.spill_body_prefix_runs) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.spill_entry_good_runs) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.spill_entry_route) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.spill_entry_runs) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.spill_entry_saves_runs) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.spill_entry_stores_runs) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.spill_entry_symbols_runs) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.spill_jump_route) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.spill_return_block_after_entry) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.spill_shared_jump_runs) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.stateSizeAt.eq_1) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.termStateAt.eq_1) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.termStateAt_good) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.termStateAt_kept) ∧
  Root _ (@Backend.Proof.PerEdgeSpill.termStateAt_le) ∧
  Root _ (@Backend.Proof.Prep.prepCheck_complete) ∧
  Root _ (@Backend.Proof.Prep.prepare_correct) ∧
  Root _ (@Backend.Proof.Prep.rpo_selected_reachable) ∧
  Root _ (@Backend.Proof.Spill.cfg_multiple_preds_other) ∧
  Root _ (@Backend.Proof.Spill.cfg_pred_size_le_one_of_unique) ∧
  Root _ (@Backend.Proof.Spill.cfg_pred_size_le_one_unique) ∧
  Root _ (@Backend.Reg.homeNum.eq_1) ∧
  Root _ (@Backend.Reg.homeNum.eq_2) ∧
  Root _ (@Backend.Stock.Proof.ArgumentShape.eq_1) ∧
  Root _ (@Backend.Stock.Proof.BranchHelperTargets.stock_table_impl_targets) ∧
  Root _ (@Backend.Stock.Proof.BranchHelperTargets.stock_test_bit_emitted_targets) ∧
  Root _ (@Backend.Stock.Proof.BranchHelpers.stock_br_cond_result_projects) ∧
  Root _ (@Backend.Stock.Proof.BranchRootTargets.stock_selected_table_targets) ∧
  Root _ (@Backend.Stock.Proof.BranchRootTargets.stock_selected_test_bit_targets) ∧
  Root _ (@Backend.Stock.Proof.BranchSelection.candidates) ∧
  Root _ (@Backend.Stock.Proof.BranchSelection.fired) ∧
  Root _ (@Backend.Stock.Proof.BranchSelection.fuelBound) ∧
  Root _ (@Backend.Stock.Proof.BranchSelection.matchedRun) ∧
  Root _ (@Backend.Stock.Proof.BranchSelection.mk.inj) ∧
  Root _ (@Backend.Stock.Proof.BranchSelection.mk.injEq) ∧
  Root _ (@Backend.Stock.Proof.BranchSelection.mk.sizeOf_spec) ∧
  Root _ (@Backend.Stock.Proof.BranchSelection.rejected) ∧
  Root _ (@Backend.Stock.Proof.BranchSelection.rhsRun) ∧
  Root _ (@Backend.Stock.Proof.BranchTargetsWitness.stock_branch_named_targets_witness) ∧
  Root _ (@Backend.Stock.Proof.BranchTargetsWitness.stock_table_helper_targets_witness) ∧
  Root _ (@Backend.Stock.Proof.BranchTargetsWitness.stock_test_bit_helper_targets_witness) ∧
  Root _ (@Backend.Stock.Proof.CfgTotalWitness.stock_branch_cfg_prepare_witness) ∧
  Root _ (@Backend.Stock.Proof.CfgTotalWitness.stock_critical_cfg_prepare_witness) ∧
  Root _ (@Backend.Stock.Proof.CfgTotalWitness.stock_return_cfg_prepare_witness) ∧
  Root _ (@Backend.Stock.Proof.CfgTotalWitness.stock_trap_cfg_prepare_witness) ∧
  Root _ (@Backend.Stock.Proof.CfgTotalWitness.stock_try_cfg_prepare_witness) ∧
  Root _ (@Backend.Stock.Proof.ConditionalRoots.stock_selected_brif_targets) ∧
  Root _ (@Backend.Stock.Proof.ConditionalTargets.stock_conditional_descriptor_targets) ∧
  Root _ (@Backend.Stock.Proof.ConditionalTargets.stock_conditional_emitted_targets) ∧
  Root _ (@Backend.Stock.Proof.ConditionalTargetsWitness.stock_conditional_targets_witness) ∧
  Root _ (@Backend.Stock.Proof.ConditionalTargetsWitness.stock_selected_brif_targets_witness) ∧
  Root _ (@Backend.Stock.Proof.Control.stock_named_jump_shape) ∧
  Root _ (@Backend.Stock.Proof.Control.stock_named_trap_shape) ∧
  Root _ (@Backend.Stock.Proof.ControlCfgWitness.stock_jump_shape_witness) ∧
  Root _ (@Backend.Stock.Proof.ControlCfgWitness.stock_return_cfg_witness) ∧
  Root _ (@Backend.Stock.Proof.ControlCfgWitness.stock_trap_cfg_witness) ∧
  Root _ (@Backend.Stock.Proof.EdgeValuesWitness.stock_edge_parameter_field_witness) ∧
  Root _ (@Backend.Stock.Proof.EdgeValuesWitness.stock_edge_values_alias_witness) ∧
  Root _ (@Backend.Stock.Proof.EdgeValuesWitness.stock_jump_edge_env_witness) ∧
  Root _ (@Backend.Stock.Proof.EmittedGraphWitness.stock_critical_cfg_witness) ∧
  Root _ (@Backend.Stock.Proof.EmittedGraphWitness.stock_try_targets_witness) ∧
  Root _ (@Backend.Stock.Proof.IndexedInstFixture.firstInstructions.eq_1) ∧
  Root _ (@Backend.Stock.Proof.IndexedInstFixture.indexed_inst_layout) ∧
  Root _ (@Backend.Stock.Proof.IndexedInstWitness.stock_indexed_instructions_witness) ∧
  Root _ (@Backend.Stock.Proof.IndexedInstWitness.stock_indexed_prefix_call_witness) ∧
  Root _ (@Backend.Stock.Proof.IndexedSpillFixture.Output.accepted) ∧
  Root _ (@Backend.Stock.Proof.IndexedSpillFixture.Output.blockCount) ∧
  Root _ (@Backend.Stock.Proof.IndexedSpillFixture.Output.codeSize) ∧
  Root _ (@Backend.Stock.Proof.IndexedSpillFixture.Output.dominated) ∧
  Root _ (@Backend.Stock.Proof.IndexedSpillFixture.Output.edgeRow) ∧
  Root _ (@Backend.Stock.Proof.IndexedSpillFixture.Output.fallback) ∧
  Root _ (@Backend.Stock.Proof.IndexedSpillFixture.Output.firstSymbol) ∧
  Root _ (@Backend.Stock.Proof.IndexedSpillFixture.Output.installedCopy) ∧
  Root _ (@Backend.Stock.Proof.IndexedSpillFixture.Output.lowered) ∧
  Root _ (@Backend.Stock.Proof.IndexedSpillFixture.Output.mk.inj) ∧
  Root _ (@Backend.Stock.Proof.IndexedSpillFixture.Output.mk.injEq) ∧
  Root _ (@Backend.Stock.Proof.IndexedSpillFixture.Output.mk.sizeOf_spec) ∧
  Root _ (@Backend.Stock.Proof.IndexedSpillFixture.Output.params) ∧
  Root _ (@Backend.Stock.Proof.IndexedSpillFixture.Output.physical) ∧
  Root _ (@Backend.Stock.Proof.IndexedSpillFixture.Output.prepare) ∧
  Root _ (@Backend.Stock.Proof.IndexedSpillFixture.Output.scope) ∧
  Root _ (@Backend.Stock.Proof.IndexedSpillFixture.Output.secondSymbol) ∧
  Root _ (@Backend.Stock.Proof.IndexedSpillFixture.cycle_fixture) ∧
  Root _ (@Backend.Stock.Proof.IndexedSpillFixture.function.eq_1) ∧
  Root _ (@Backend.Stock.Proof.IndexedSpillFixture.initial.eq_1) ∧
  Root _ (@Backend.Stock.Proof.IndexedSpillWitness.stock_indexed_spill_cycle_witness) ∧
  Root _ (@Backend.Stock.Proof.NamedBranchTargets.stock_named_brif_targets) ∧
  Root _ (@Backend.Stock.Proof.NamedBranchTargets.stock_named_table_targets) ∧
  Root _ (@Backend.Stock.Proof.NodeCoverageWitness.stock_branch_helper_projection_witness) ∧
  Root _ (@Backend.Stock.Proof.NodeCoverageWitness.stock_original_scan_coverage_witness) ∧
  Root _ (@Backend.Stock.Proof.NodeCoverageWitness.stock_return_node_cfg_witness) ∧
  Root _ (@Backend.Stock.Proof.NodeCoverageWitness.stock_trap_node_cfg_witness) ∧
  Root _ (@Backend.Stock.Proof.OrderGraphWitness.stock_critical_code_witness) ∧
  Root _ (@Backend.Stock.Proof.OrderGraphWitness.stock_critical_order_witness) ∧
  Root _ (@Backend.Stock.Proof.OrderGraphWitness.stock_jump_order_witness) ∧
  Root _ (@Backend.Stock.Proof.OrdinaryCfg.ordinary.eq_1) ∧
  Root _ (@Backend.Stock.Proof.OrdinaryCfg.ordinary.eq_2) ∧
  Root _ (@Backend.Stock.Proof.OrdinaryCfg.ordinary.eq_3) ∧
  Root _ (@Backend.Stock.Proof.OrdinaryCfg.ordinary.eq_4) ∧
  Root _ (@Backend.Stock.Proof.OrdinaryCfg.stock_lower_ordinary_cfg) ∧
  Root _ (@Backend.Stock.Proof.OrdinaryCfg.stock_lower_ordinary_targets) ∧
  Root _ (@Backend.Stock.Proof.OrdinaryCfg.stock_lower_original_code_origin) ∧
  Root _ (@Backend.Stock.Proof.PerEdgeDirectWitness.stock_direct_per_edge_step_witness) ∧
  Root _ (@Backend.Stock.Proof.PerEdgeDirectWitness.stock_direct_selected_route_witness) ∧
  Root _ (@Backend.Stock.Proof.PerEdgeM6DivergenceWitness.stock_per_edge_m6_divergence_witness) ∧
  Root _ (@Backend.Stock.Proof.PerEdgeM6StuckWitness.stock_per_edge_m6_stuck_witness) ∧
  Root _ (@Backend.Stock.Proof.PreparedArityWitness.generic_prepared_arity_witness) ∧
  Root _ (@Backend.Stock.Proof.PreparedArityWitness.stock_prepared_cyclic_copy_arity_witness) ∧
  Root _ (@Backend.Stock.Proof.PreparedArityWitness.stock_prepared_try_arity_witness) ∧
  Root _ (@Backend.Stock.Proof.ReturnFixture.abiXs.eq_1) ∧
  Root _ (@Backend.Stock.Proof.ReturnFixture.explicitXs.eq_1) ∧
  Root _ (@Backend.Stock.Proof.ReturnFixture.function.eq_1) ∧
  Root _ (@Backend.Stock.Proof.ReturnFixture.pins.eq_1) ∧
  Root _ (@Backend.Stock.Proof.ReturnFixture.registers.eq_1) ∧
  Root _ (@Backend.Stock.Proof.ReturnSourceWitness.stock_return_auto_source_witness) ∧
  Root _ (@Backend.Stock.Proof.ReturnSourceWitness.stock_return_complete_source_witness) ∧
  Root _ (@Backend.Stock.Proof.ReturnSourceWitness.stock_return_retained_source_witness) ∧
  Root _ (@Backend.Stock.Proof.ReturnSourceWitness.stock_return_run_contract_witness) ∧
  Root _ (@Backend.Stock.Proof.ReturnSourceWitness.stock_return_vcode_contract_witness) ∧
  Root _ (@Backend.Stock.Proof.RowArgumentShape.eq_1) ∧
  Root _ (@Backend.Stock.Proof.SharedJumpFixture.shared_jump_layout) ∧
  Root _ (@Backend.Stock.Proof.SourceCallWitness.stock_source_call_result_witness) ∧
  Root _ (@Backend.Stock.Proof.SpillCopyMetadataWitness.stock_spill_copy_metadata_witness) ∧
  Root _ (@Backend.Stock.Proof.SpillCopyMetadataWitness.stock_try_prepared_copy_metadata_witness) ∧
  Root _ (@Backend.Stock.Proof.SpillEntryFixture.Output.accepted) ∧
  Root _ (@Backend.Stock.Proof.SpillEntryFixture.Output.arity) ∧
  Root _ (@Backend.Stock.Proof.SpillEntryFixture.Output.dominated) ∧
  Root _ (@Backend.Stock.Proof.SpillEntryFixture.Output.fallback) ∧
  Root _ (@Backend.Stock.Proof.SpillEntryFixture.Output.lowered) ∧
  Root _ (@Backend.Stock.Proof.SpillEntryFixture.Output.metadata) ∧
  Root _ (@Backend.Stock.Proof.SpillEntryFixture.Output.mk.inj) ∧
  Root _ (@Backend.Stock.Proof.SpillEntryFixture.Output.mk.injEq) ∧
  Root _ (@Backend.Stock.Proof.SpillEntryFixture.Output.mk.sizeOf_spec) ∧
  Root _ (@Backend.Stock.Proof.SpillEntryFixture.Output.physical) ∧
  Root _ (@Backend.Stock.Proof.SpillEntryFixture.Output.prepare) ∧
  Root _ (@Backend.Stock.Proof.SpillEntryFixture.Output.scope) ∧
  Root _ (@Backend.Stock.Proof.SpillEntryFixture.function.eq_1) ∧
  Root _ (@Backend.Stock.Proof.SpillEntryFixture.initial.eq_1) ∧
  Root _ (@Backend.Stock.Proof.SpillEntryFixture.target.eq_1) ∧
  Root _ (@Backend.Stock.Proof.SpillEntryFixture.try_fixture) ∧
  Root _ (@Backend.Stock.Proof.SpillEntryWitness.stock_try_spill_entry_witness) ∧
  Root _ (@Backend.Stock.Proof.SpillJumpWitness.stock_spill_jump_route_witness) ∧
  Root _ (@Backend.Stock.Proof.runOkABI_of_return_stop) ∧
  Root _ (@Backend.Stock.Proof.source_defined_continueWith) ∧
  Root _ (@Backend.Stock.Proof.source_defined_returnValues) ∧
  Root _ (@Backend.Stock.Proof.source_defined_setMany) ∧
  Root _ (@Backend.Stock.Proof.stock_blockOrder_edges_nonentry) ∧
  Root _ (@Backend.Stock.Proof.stock_blockOrder_entry) ∧
  Root _ (@Backend.Stock.Proof.stock_branchArgs_shape) ∧
  Root _ (@Backend.Stock.Proof.stock_branchArgs_target_arity) ∧
  Root _ (@Backend.Stock.Proof.stock_branchCode_try_targets) ∧
  Root _ (@Backend.Stock.Proof.stock_lowerBlockCore_try_targets) ∧
  Root _ (@Backend.Stock.Proof.stock_lower_cfg) ∧
  Root _ (@Backend.Stock.Proof.stock_lower_critical_cfg) ∧
  Root _ (@Backend.Stock.Proof.stock_lower_critical_edge_arity) ∧
  Root _ (@Backend.Stock.Proof.stock_lower_critical_source) ∧
  Root _ (@Backend.Stock.Proof.stock_lower_dense_labels) ∧
  Root _ (@Backend.Stock.Proof.stock_lower_edge_arity) ∧
  Root _ (@Backend.Stock.Proof.stock_lower_entry_code) ∧
  Root _ (@Backend.Stock.Proof.stock_lower_graph_bounds) ∧
  Root _ (@Backend.Stock.Proof.stock_lower_graph_nonentry) ∧
  Root _ (@Backend.Stock.Proof.stock_lower_indexed_successor_origin) ∧
  Root _ (@Backend.Stock.Proof.stock_lower_jump_edge_values) ∧
  Root _ (@Backend.Stock.Proof.stock_lower_original_scan) ∧
  Root _ (@Backend.Stock.Proof.stock_lower_outgoing_shape) ∧
  Root _ (@Backend.Stock.Proof.stock_lower_parameter_shape) ∧
  Root _ (@Backend.Stock.Proof.stock_lower_return_cfg) ∧
  Root _ (@Backend.Stock.Proof.stock_lower_return_record_runOk) ∧
  Root _ (@Backend.Stock.Proof.stock_lower_return_runOk) ∧
  Root _ (@Backend.Stock.Proof.stock_lower_return_scan_last) ∧
  Root _ (@Backend.Stock.Proof.stock_lower_terminal_cfg_at) ∧
  Root _ (@Backend.Stock.Proof.stock_lower_terminal_scan_code) ∧
  Root _ (@Backend.Stock.Proof.stock_lower_terminal_successors) ∧
  Root _ (@Backend.Stock.Proof.stock_lower_trap_cfg) ∧
  Root _ (@Backend.Stock.Proof.stock_lower_trap_scan_last) ∧
  Root _ (@Backend.Stock.Proof.stock_lower_try_cfg) ∧
  Root _ (@Backend.Stock.Proof.stock_lower_try_targets) ∧
  Root _ (@Backend.Stock.Proof.stock_named_branch_selection) ∧
  Root _ (@Backend.Stock.Proof.stock_parameter_numbers_nodup) ∧
  Root _ (@Backend.Stock.Proof.stock_prepare_copy_metadata) ∧
  Root _ (@Backend.Stock.Proof.stock_prepare_edge_arity) ∧
  Root _ (@Backend.Stock.Proof.stock_prepare_parameter_shape) ∧
  Root _ (@Backend.Stock.Proof.stock_prepare_total) ∧
  Root _ (@Backend.Stock.Proof.stock_prepare_total_of_graph) ∧
  Root _ (@Backend.Stock.Proof.stock_sourceTable_nonentry) ∧
  Root _ (@Backend.Stock.Proof.stock_spillArgMovesAt_edge_runs) ∧
  Root _ (@Backend.Stock.Proof.stock_spillArgMovesAt_runs) ∧
  Root _ (@Backend.VBlock.insts.eq_1) ∧
  Root _ (@Backend.VBlock.label.eq_1) ∧
  Root _ (@Backend.VCode.blocks.eq_1) ∧
  Root _ (@Backend.VCode.cfg.eq_1) ∧
  Root _ (@Backend.retCheck.eq_1) ∧
  Root _ (@Backend.retCheck.eq_2) ∧
  Root _ (@Backend.spillHomeAt.eq_1) ∧
  Root _ (@Backend.spillHomeKeyAt.eq_1) ∧
  Root _ (@Backend.spillHomeKeyAt.eq_2) ∧
  Root _ (@Backend.spillLocs.eq_1) ∧
  Root _ (@Clif.Regs.empty.eq_1) ∧
  Root _ (@Clif.enterSlots.eq_1) ∧
  Root _ (@Clif.runLoop_ren) ∧
  Root _ (@E2E.DeadCleanupExecBytes.binary_correct_exec) ∧
  Root _ (@E2E.DeadCleanupExecBytes.binary_correct_exec_of_good) ∧
  Root _ (@E2E.DeadCleanupExecBytes.binary_correct_exec_of_got) ∧
  Root _ (@E2E.DeadCleanupExecBytes.binary_correct_exec_of_insn) ∧
  Root _ (@E2E.DeadCleanupExecBytes.binary_correct_exec_of_reads) ∧
  Root _ (@E2E.DeadCleanupExecBytes.binary_correct_exec_peak_proven) ∧
  Root _ (@E2E.DeadCleanupExecBytes.binary_correct_exec_proven) ∧
  Root _ (@E2E.DeadCleanupExecBytes.binary_correct_exec_static) ∧
  Root _ (@E2E.DeadCleanupExecBytes.binary_correct_exec_staticN) ∧
  Root _ (@E2E.DeadCleanupStackBound.goodN_iff) ∧
  Root _ (@E2E.DeadCleanupStackBound.stackB_isSome_iff) ∧
  Root _ (@E2E.ExecBytes.binary_correct_exec) ∧
  Root _ (@E2E.ExecBytes.binary_correct_exec_depth_proven) ∧
  Root _ (@E2E.ExecBytes.binary_correct_exec_of_good) ∧
  Root _ (@E2E.ExecBytes.binary_correct_exec_of_got) ∧
  Root _ (@E2E.ExecBytes.binary_correct_exec_of_insn) ∧
  Root _ (@E2E.ExecBytes.binary_correct_exec_of_reads) ∧
  Root _ (@E2E.ExecBytes.binary_correct_exec_peak_proven) ∧
  Root _ (@E2E.ExecBytes.binary_correct_exec_proven) ∧
  Root _ (@E2E.ExecBytes.binary_correct_exec_static) ∧
  Root _ (@E2E.ExecBytes.binary_correct_exec_staticN) ∧
  Root _ (@E2E.LegalProgram.legalProg_refines) ∧
  Root _ (@E2E.LegalProgram.legalProg_refines_depth) ∧
  Root _ (@E2E.LinkCheck.crate_correct_inScope_proven) ∧
  Root _ (@E2E.StackBound.budOkW_budMap) ∧
  Root _ (@E2E.StackBound.goodN_iff) ∧
  Root _ (@E2E.StackBound.stackB_isSome_iff) ∧
  Root _ (@E2E.backend_correct_final) ∧
  Root _ (@E2E.backend_correct_final_alloc) ∧
  Root _ (@E2E.backend_correct_final_alloc_proven) ∧
  Root _ (@E2E.backend_correct_final_cleanup) ∧
  Root _ (@E2E.backend_correct_final_cleanup_ex) ∧
  Root _ (@E2E.backend_correct_final_cleanup_total) ∧
  Root _ (@E2E.backend_correct_final_cleanup_total_emit) ∧
  Root _ (@E2E.backend_correct_final_cleanup_total_emit_in) ∧
  Root _ (@E2E.backend_correct_final_cleanup_total_emit_input) ∧
  Root _ (@E2E.backend_correct_final_cleanup_total_ready) ∧
  Root _ (@E2E.backend_correct_final_ex) ∧
  Root _ (@E2E.backend_correct_final_id) ∧
  Root _ (@E2E.backend_correct_final_indirectFree) ∧
  Root _ (@E2E.backend_correct_final_of_lower) ∧
  Root _ (@E2E.backend_correct_final_of_lower_ex) ∧
  Root _ (@E2E.backend_correct_final_total) ∧
  Root _ (@E2E.backend_correct_final_total_emit) ∧
  Root _ (@E2E.backend_correct_final_total_emit_in) ∧
  Root _ (@E2E.backend_correct_final_total_emit_input) ∧
  Root _ (@E2E.backend_correct_final_total_ready) ∧
  Root _ (@E2E.backend_correct_final_total_relaxed) ∧
  Root _ (@E2E.backend_correct_final_try_witness) ∧
  Root _ (@E2E.backend_correct_final_witness) ∧
  Root _ (@E2E.backend_correct_legal) ∧
  Root _ (@E2E.backend_correct_legal_callFree) ∧
  Root _ (@E2E.backend_correct_legal_callFree_cleanup) ∧
  Root _ (@E2E.backend_correct_legal_cleanup) ∧
  Root _ (@E2E.backend_correct_legal_direct) ∧
  Root _ (@E2E.backend_correct_legal_direct_cleanup) ∧
  Root _ (@E2E.backend_correct_legal_env) ∧
  Root _ (@E2E.backend_correct_legal_env_cleanup) ∧
  Root _ (@E2E.backend_correct_opt_proven) ∧
  Root _ (@E2E.backend_correct_opt_proven_cleanup) ∧
  Root _ (@E2E.backend_correct_program) ∧
  Root _ (@E2E.backend_correct_program_budget) ∧
  Root _ (@E2E.backend_correct_program_budgetX) ∧
  Root _ (@E2E.backend_correct_program_core) ∧
  Root _ (@E2E.backend_correct_program_coreX) ∧
  Root _ (@E2E.backend_correct_program_peak) ∧
  Root _ (@E2E.backend_correct_program_peakX) ∧
  Root _ (@E2E.backend_correct_program_returned) ∧
  Root _ (@E2E.backend_correct_program_returned_budget) ∧
  Root _ (@E2E.backend_correct_program_stack) ∧
  Root _ (@E2E.backend_correct_program_stackX) ∧
  Root _ (@E2E.emitReady_spill) ∧
  Root _ (@E2E.lowerRFunc_spillAlloc) ∧
  Root _ (@E2E.spillAccepted) ∧
  Root _ (@Front.buildSpec_spec) ∧
  Root _ (@Front.buildSpec_srcProg) ∧
  Root _ (@Front.bundle_correct_raw) ∧
  Root _ (@Front.bundle_correct_raw_baseline) ∧
  Root _ (@Front.bundle_correct_raw_peak) ∧
  Root _ (@Front.bundle_correct_raw_peak_baseline) ∧
  Root _ (@Front.bundle_correct_source) ∧
  Root _ (@Front.bundle_correct_source_baseline) ∧
  Root _ (@Front.bundle_correct_source_peak) ∧
  Root _ (@Front.bundle_correct_source_peak_baseline) ∧
  Root _ (@Front.data_complete) ∧
  Root _ (@Front.decodeFn_spec) ∧
  Root _ (@Front.link_alpha) ∧
  Root _ (@Front.parseUnit_raw) ∧
  Root _ (@Front.rawLink_eq_link) ∧
  Root _ (@Isle.Aarch64.rule_lower_3247.eq_1) ∧
  Root _ (@Link.DeadCleanup.SourceWitness.compileExe_correct_source_helper) ∧
  Root _ (@Link.DeadCleanup.SourceWitness.compileExe_correct_source_peak_helper) ∧
  Root _ (@Link.DeadCleanup.binOk_leanLink) ∧
  Root _ (@Link.DeadCleanup.compileExe_correct) ∧
  Root _ (@Link.DeadCleanup.compileExe_correct_peak) ∧
  Root _ (@Link.DeadCleanup.compileExe_correct_source) ∧
  Root _ (@Link.DeadCleanup.compileExe_correct_source_peak) ∧
  Root _ (@Link.DeadCleanup.compileExe_total) ∧
  Root _ (@Link.DeadCleanup.compileExe_total_input) ∧
  Root _ (@Link.DeadCleanup.compileExe_total_reach) ∧
  Root _ (@Link.DeadCleanup.leanLink_linkerOk) ∧
  Root _ (@Link.DeadCleanup.relocOk_tab) ∧
  Root _ (@Link.SourceWitness.compileExe_correct_source_helper) ∧
  Root _ (@Link.SourceWitness.compileExe_correct_source_peak_helper) ∧
  Root _ (@Link.binOk_leanLink) ∧
  Root _ (@Link.compileExe_correct) ∧
  Root _ (@Link.compileExe_correct_depth) ∧
  Root _ (@Link.compileExe_correct_peak) ∧
  Root _ (@Link.compileExe_correct_source) ∧
  Root _ (@Link.compileExe_correct_source_peak) ∧
  Root _ (@Link.compileExe_total) ∧
  Root _ (@Link.compileExe_total_input) ∧
  Root _ (@Link.compileExe_total_reach) ∧
  Root _ (@Link.leanLink_linkerOk) ∧
  Root _ (@Link.relocOk_tab) ∧
  Root _ (@Opt.Legal.Complete.check_complete_of_preB) ∧
  Root _ (@Opt.Legal.Complete.preB_iff) ∧
  Root _ (@Opt.Proof.simplifyRulesCorrect_proven) ∧
  Root _ (@Opt.optimize_sim_proven) :=
  And.intro (@Backend.AState.parCopy.eq_1) (And.intro (@Backend.CheckCtx.checkStatic.eq_1) (And.intro (@Backend.CheckCtx.stepOp.eq_1) (And.intro (@Backend.Insn.decode_encode) (And.intro (@Backend.MInst.isBranch.eq_def) (And.intro (@Backend.MInst.isRet.eq_1) (And.intro (@Backend.MInst.isRet.eq_2) (And.intro (@Backend.MInst.isRet.eq_3) (And.intro (@Backend.MInst.isRet.eq_def) (And.intro (@Backend.MInst.isTerminator.eq_1) (And.intro (@Backend.MInst.isTerminator.eq_2) (And.intro (@Backend.MInst.isTerminator.eq_def) (And.intro (@Backend.MInst.targets.eq_def) (And.intro (@Backend.Proof.Driver.formsCovered_complete) (And.intro (@Backend.Proof.Driver.lowerCheck_complete) (And.intro (@Backend.Proof.Driver.prepDomain_of_lower) (And.intro (@Backend.Proof.PerEdgePrep.innerStepAt.eq_1) (And.intro (@Backend.Proof.PerEdgePrep.keepOrigin_injective) (And.intro (@Backend.Proof.PerEdgePrep.keepOrigin_spec) (And.intro (@Backend.Proof.PerEdgePrep.keep_cfg_edge) (And.intro (@Backend.Proof.PerEdgePrep.keep_no_critical) (And.intro (@Backend.Proof.PerEdgePrep.outerLoopAt_no_new_edges) (And.intro (@Backend.Proof.PerEdgePrep.prepareAt_all_reachable) (And.intro (@Backend.Proof.PerEdgePrep.prepareAt_argument_shape) (And.intro (@Backend.Proof.PerEdgePrep.prepareAt_edge_arguments) (And.intro (@Backend.Proof.PerEdgePrep.prepareAt_edge_arity) (And.intro (@Backend.Proof.PerEdgePrep.prepareAt_jump_counterpart) (And.intro (@Backend.Proof.PerEdgePrep.prepareAt_no_new_edges) (And.intro (@Backend.Proof.PerEdgePrep.prepareAt_parameter_shape) (And.intro (@Backend.Proof.PerEdgePrep.prepareAt_routed_edge_arity) (And.intro (@Backend.Proof.PerEdgePrep.reorder_cfg_edge) (And.intro (@Backend.Proof.PerEdgePrep.reorder_index_injective) (And.intro (@Backend.Proof.PerEdgePrep.unsplit_cfg_eq) (And.intro (@Backend.Proof.PerEdgePrepSplitWitness.per_edge_prepare_actual_split_step_witness) (And.intro (@Backend.Proof.PerEdgeSpill.EdgeTransferAt.checked) (And.intro (@Backend.Proof.PerEdgeSpill.EdgeTransferAt.entry) (And.intro (@Backend.Proof.PerEdgeSpill.EdgeTransferAt.formula) (And.intro (@Backend.Proof.PerEdgeSpill.EdgeTransferAt.other) (And.intro (@Backend.Proof.PerEdgeSpill.EdgeTransferAt.parameter) (And.intro (@Backend.Proof.PerEdgeSpill.EdgeTransferAt.size) (And.intro (@Backend.Proof.PerEdgeSpill.EntryAvailAt.argClasses) (And.intro (@Backend.Proof.PerEdgeSpill.EntryAvailAt.arguments) (And.intro (@Backend.Proof.PerEdgeSpill.EntryAvailAt.ordinary) (And.intro (@Backend.Proof.PerEdgeSpill.EntryAvailAt.paramClasses) (And.intro (@Backend.Proof.PerEdgeSpill.GoodAt.home) (And.intro (@Backend.Proof.PerEdgeSpill.GoodAt.save) (And.intro (@Backend.Proof.PerEdgeSpill.GoodAt.size) (And.intro (@Backend.Proof.PerEdgeSpill.HomesSpec.code) (And.intro (@Backend.Proof.PerEdgeSpill.HomesSpec.outgoing) (And.intro (@Backend.Proof.PerEdgeSpill.HomesSpec.valid) (And.intro (@Backend.Proof.PerEdgeSpill.bodyContentAt.eq_1) (And.intro (@Backend.Proof.PerEdgeSpill.bodyContentAt.eq_2) (And.intro (@Backend.Proof.PerEdgeSpill.bodyContentAt.eq_3) (And.intro (@Backend.Proof.PerEdgeSpill.bodyItem.eq_1) (And.intro (@Backend.Proof.PerEdgeSpill.bodyStateAt.eq_1) (And.intro (@Backend.Proof.PerEdgeSpill.bodyStateAt_good) (And.intro (@Backend.Proof.PerEdgeSpill.bodyStateAt_le) (And.intro (@Backend.Proof.PerEdgeSpill.edgeAt_of_metadata) (And.intro (@Backend.Proof.PerEdgeSpill.entryState_saved) (And.intro (@Backend.Proof.PerEdgeSpill.homeLookup.eq_1) (And.intro (@Backend.Proof.PerEdgeSpill.p2.eq_1) (And.intro (@Backend.Proof.PerEdgeSpill.preEntryStateAt_shared_le) (And.intro (@Backend.Proof.PerEdgeSpill.preEntryStateAt_unique_le) (And.intro (@Backend.Proof.PerEdgeSpill.preEntryStateAt_unique_runs) (And.intro (@Backend.Proof.PerEdgeSpill.spillAllocAt_block) (And.intro (@Backend.Proof.PerEdgeSpill.spillAllocAt_storage) (And.intro (@Backend.Proof.PerEdgeSpill.spillArgMovesAt_runs) (And.intro (@Backend.Proof.PerEdgeSpill.spillHomeKeyAt_injective) (And.intro (@Backend.Proof.PerEdgeSpill.spillHomesAt_spec) (And.intro (@Backend.Proof.PerEdgeSpill.spillInstAt_runs) (And.intro (@Backend.Proof.PerEdgeSpill.spill_body_prefix_runs) (And.intro (@Backend.Proof.PerEdgeSpill.spill_entry_good_runs) (And.intro (@Backend.Proof.PerEdgeSpill.spill_entry_route) (And.intro (@Backend.Proof.PerEdgeSpill.spill_entry_runs) (And.intro (@Backend.Proof.PerEdgeSpill.spill_entry_saves_runs) (And.intro (@Backend.Proof.PerEdgeSpill.spill_entry_stores_runs) (And.intro (@Backend.Proof.PerEdgeSpill.spill_entry_symbols_runs) (And.intro (@Backend.Proof.PerEdgeSpill.spill_jump_route) (And.intro (@Backend.Proof.PerEdgeSpill.spill_return_block_after_entry) (And.intro (@Backend.Proof.PerEdgeSpill.spill_shared_jump_runs) (And.intro (@Backend.Proof.PerEdgeSpill.stateSizeAt.eq_1) (And.intro (@Backend.Proof.PerEdgeSpill.termStateAt.eq_1) (And.intro (@Backend.Proof.PerEdgeSpill.termStateAt_good) (And.intro (@Backend.Proof.PerEdgeSpill.termStateAt_kept) (And.intro (@Backend.Proof.PerEdgeSpill.termStateAt_le) (And.intro (@Backend.Proof.Prep.prepCheck_complete) (And.intro (@Backend.Proof.Prep.prepare_correct) (And.intro (@Backend.Proof.Prep.rpo_selected_reachable) (And.intro (@Backend.Proof.Spill.cfg_multiple_preds_other) (And.intro (@Backend.Proof.Spill.cfg_pred_size_le_one_of_unique) (And.intro (@Backend.Proof.Spill.cfg_pred_size_le_one_unique) (And.intro (@Backend.Reg.homeNum.eq_1) (And.intro (@Backend.Reg.homeNum.eq_2) (And.intro (@Backend.Stock.Proof.ArgumentShape.eq_1) (And.intro (@Backend.Stock.Proof.BranchHelperTargets.stock_table_impl_targets) (And.intro (@Backend.Stock.Proof.BranchHelperTargets.stock_test_bit_emitted_targets) (And.intro (@Backend.Stock.Proof.BranchHelpers.stock_br_cond_result_projects) (And.intro (@Backend.Stock.Proof.BranchRootTargets.stock_selected_table_targets) (And.intro (@Backend.Stock.Proof.BranchRootTargets.stock_selected_test_bit_targets) (And.intro (@Backend.Stock.Proof.BranchSelection.candidates) (And.intro (@Backend.Stock.Proof.BranchSelection.fired) (And.intro (@Backend.Stock.Proof.BranchSelection.fuelBound) (And.intro (@Backend.Stock.Proof.BranchSelection.matchedRun) (And.intro (@Backend.Stock.Proof.BranchSelection.mk.inj) (And.intro (@Backend.Stock.Proof.BranchSelection.mk.injEq) (And.intro (@Backend.Stock.Proof.BranchSelection.mk.sizeOf_spec) (And.intro (@Backend.Stock.Proof.BranchSelection.rejected) (And.intro (@Backend.Stock.Proof.BranchSelection.rhsRun) (And.intro (@Backend.Stock.Proof.BranchTargetsWitness.stock_branch_named_targets_witness) (And.intro (@Backend.Stock.Proof.BranchTargetsWitness.stock_table_helper_targets_witness) (And.intro (@Backend.Stock.Proof.BranchTargetsWitness.stock_test_bit_helper_targets_witness) (And.intro (@Backend.Stock.Proof.CfgTotalWitness.stock_branch_cfg_prepare_witness) (And.intro (@Backend.Stock.Proof.CfgTotalWitness.stock_critical_cfg_prepare_witness) (And.intro (@Backend.Stock.Proof.CfgTotalWitness.stock_return_cfg_prepare_witness) (And.intro (@Backend.Stock.Proof.CfgTotalWitness.stock_trap_cfg_prepare_witness) (And.intro (@Backend.Stock.Proof.CfgTotalWitness.stock_try_cfg_prepare_witness) (And.intro (@Backend.Stock.Proof.ConditionalRoots.stock_selected_brif_targets) (And.intro (@Backend.Stock.Proof.ConditionalTargets.stock_conditional_descriptor_targets) (And.intro (@Backend.Stock.Proof.ConditionalTargets.stock_conditional_emitted_targets) (And.intro (@Backend.Stock.Proof.ConditionalTargetsWitness.stock_conditional_targets_witness) (And.intro (@Backend.Stock.Proof.ConditionalTargetsWitness.stock_selected_brif_targets_witness) (And.intro (@Backend.Stock.Proof.Control.stock_named_jump_shape) (And.intro (@Backend.Stock.Proof.Control.stock_named_trap_shape) (And.intro (@Backend.Stock.Proof.ControlCfgWitness.stock_jump_shape_witness) (And.intro (@Backend.Stock.Proof.ControlCfgWitness.stock_return_cfg_witness) (And.intro (@Backend.Stock.Proof.ControlCfgWitness.stock_trap_cfg_witness) (And.intro (@Backend.Stock.Proof.EdgeValuesWitness.stock_edge_parameter_field_witness) (And.intro (@Backend.Stock.Proof.EdgeValuesWitness.stock_edge_values_alias_witness) (And.intro (@Backend.Stock.Proof.EdgeValuesWitness.stock_jump_edge_env_witness) (And.intro (@Backend.Stock.Proof.EmittedGraphWitness.stock_critical_cfg_witness) (And.intro (@Backend.Stock.Proof.EmittedGraphWitness.stock_try_targets_witness) (And.intro (@Backend.Stock.Proof.IndexedInstFixture.firstInstructions.eq_1) (And.intro (@Backend.Stock.Proof.IndexedInstFixture.indexed_inst_layout) (And.intro (@Backend.Stock.Proof.IndexedInstWitness.stock_indexed_instructions_witness) (And.intro (@Backend.Stock.Proof.IndexedInstWitness.stock_indexed_prefix_call_witness) (And.intro (@Backend.Stock.Proof.IndexedSpillFixture.Output.accepted) (And.intro (@Backend.Stock.Proof.IndexedSpillFixture.Output.blockCount) (And.intro (@Backend.Stock.Proof.IndexedSpillFixture.Output.codeSize) (And.intro (@Backend.Stock.Proof.IndexedSpillFixture.Output.dominated) (And.intro (@Backend.Stock.Proof.IndexedSpillFixture.Output.edgeRow) (And.intro (@Backend.Stock.Proof.IndexedSpillFixture.Output.fallback) (And.intro (@Backend.Stock.Proof.IndexedSpillFixture.Output.firstSymbol) (And.intro (@Backend.Stock.Proof.IndexedSpillFixture.Output.installedCopy) (And.intro (@Backend.Stock.Proof.IndexedSpillFixture.Output.lowered) (And.intro (@Backend.Stock.Proof.IndexedSpillFixture.Output.mk.inj) (And.intro (@Backend.Stock.Proof.IndexedSpillFixture.Output.mk.injEq) (And.intro (@Backend.Stock.Proof.IndexedSpillFixture.Output.mk.sizeOf_spec) (And.intro (@Backend.Stock.Proof.IndexedSpillFixture.Output.params) (And.intro (@Backend.Stock.Proof.IndexedSpillFixture.Output.physical) (And.intro (@Backend.Stock.Proof.IndexedSpillFixture.Output.prepare) (And.intro (@Backend.Stock.Proof.IndexedSpillFixture.Output.scope) (And.intro (@Backend.Stock.Proof.IndexedSpillFixture.Output.secondSymbol) (And.intro (@Backend.Stock.Proof.IndexedSpillFixture.cycle_fixture) (And.intro (@Backend.Stock.Proof.IndexedSpillFixture.function.eq_1) (And.intro (@Backend.Stock.Proof.IndexedSpillFixture.initial.eq_1) (And.intro (@Backend.Stock.Proof.IndexedSpillWitness.stock_indexed_spill_cycle_witness) (And.intro (@Backend.Stock.Proof.NamedBranchTargets.stock_named_brif_targets) (And.intro (@Backend.Stock.Proof.NamedBranchTargets.stock_named_table_targets) (And.intro (@Backend.Stock.Proof.NodeCoverageWitness.stock_branch_helper_projection_witness) (And.intro (@Backend.Stock.Proof.NodeCoverageWitness.stock_original_scan_coverage_witness) (And.intro (@Backend.Stock.Proof.NodeCoverageWitness.stock_return_node_cfg_witness) (And.intro (@Backend.Stock.Proof.NodeCoverageWitness.stock_trap_node_cfg_witness) (And.intro (@Backend.Stock.Proof.OrderGraphWitness.stock_critical_code_witness) (And.intro (@Backend.Stock.Proof.OrderGraphWitness.stock_critical_order_witness) (And.intro (@Backend.Stock.Proof.OrderGraphWitness.stock_jump_order_witness) (And.intro (@Backend.Stock.Proof.OrdinaryCfg.ordinary.eq_1) (And.intro (@Backend.Stock.Proof.OrdinaryCfg.ordinary.eq_2) (And.intro (@Backend.Stock.Proof.OrdinaryCfg.ordinary.eq_3) (And.intro (@Backend.Stock.Proof.OrdinaryCfg.ordinary.eq_4) (And.intro (@Backend.Stock.Proof.OrdinaryCfg.stock_lower_ordinary_cfg) (And.intro (@Backend.Stock.Proof.OrdinaryCfg.stock_lower_ordinary_targets) (And.intro (@Backend.Stock.Proof.OrdinaryCfg.stock_lower_original_code_origin) (And.intro (@Backend.Stock.Proof.PerEdgeDirectWitness.stock_direct_per_edge_step_witness) (And.intro (@Backend.Stock.Proof.PerEdgeDirectWitness.stock_direct_selected_route_witness) (And.intro (@Backend.Stock.Proof.PerEdgeM6DivergenceWitness.stock_per_edge_m6_divergence_witness) (And.intro (@Backend.Stock.Proof.PerEdgeM6StuckWitness.stock_per_edge_m6_stuck_witness) (And.intro (@Backend.Stock.Proof.PreparedArityWitness.generic_prepared_arity_witness) (And.intro (@Backend.Stock.Proof.PreparedArityWitness.stock_prepared_cyclic_copy_arity_witness) (And.intro (@Backend.Stock.Proof.PreparedArityWitness.stock_prepared_try_arity_witness) (And.intro (@Backend.Stock.Proof.ReturnFixture.abiXs.eq_1) (And.intro (@Backend.Stock.Proof.ReturnFixture.explicitXs.eq_1) (And.intro (@Backend.Stock.Proof.ReturnFixture.function.eq_1) (And.intro (@Backend.Stock.Proof.ReturnFixture.pins.eq_1) (And.intro (@Backend.Stock.Proof.ReturnFixture.registers.eq_1) (And.intro (@Backend.Stock.Proof.ReturnSourceWitness.stock_return_auto_source_witness) (And.intro (@Backend.Stock.Proof.ReturnSourceWitness.stock_return_complete_source_witness) (And.intro (@Backend.Stock.Proof.ReturnSourceWitness.stock_return_retained_source_witness) (And.intro (@Backend.Stock.Proof.ReturnSourceWitness.stock_return_run_contract_witness) (And.intro (@Backend.Stock.Proof.ReturnSourceWitness.stock_return_vcode_contract_witness) (And.intro (@Backend.Stock.Proof.RowArgumentShape.eq_1) (And.intro (@Backend.Stock.Proof.SharedJumpFixture.shared_jump_layout) (And.intro (@Backend.Stock.Proof.SourceCallWitness.stock_source_call_result_witness) (And.intro (@Backend.Stock.Proof.SpillCopyMetadataWitness.stock_spill_copy_metadata_witness) (And.intro (@Backend.Stock.Proof.SpillCopyMetadataWitness.stock_try_prepared_copy_metadata_witness) (And.intro (@Backend.Stock.Proof.SpillEntryFixture.Output.accepted) (And.intro (@Backend.Stock.Proof.SpillEntryFixture.Output.arity) (And.intro (@Backend.Stock.Proof.SpillEntryFixture.Output.dominated) (And.intro (@Backend.Stock.Proof.SpillEntryFixture.Output.fallback) (And.intro (@Backend.Stock.Proof.SpillEntryFixture.Output.lowered) (And.intro (@Backend.Stock.Proof.SpillEntryFixture.Output.metadata) (And.intro (@Backend.Stock.Proof.SpillEntryFixture.Output.mk.inj) (And.intro (@Backend.Stock.Proof.SpillEntryFixture.Output.mk.injEq) (And.intro (@Backend.Stock.Proof.SpillEntryFixture.Output.mk.sizeOf_spec) (And.intro (@Backend.Stock.Proof.SpillEntryFixture.Output.physical) (And.intro (@Backend.Stock.Proof.SpillEntryFixture.Output.prepare) (And.intro (@Backend.Stock.Proof.SpillEntryFixture.Output.scope) (And.intro (@Backend.Stock.Proof.SpillEntryFixture.function.eq_1) (And.intro (@Backend.Stock.Proof.SpillEntryFixture.initial.eq_1) (And.intro (@Backend.Stock.Proof.SpillEntryFixture.target.eq_1) (And.intro (@Backend.Stock.Proof.SpillEntryFixture.try_fixture) (And.intro (@Backend.Stock.Proof.SpillEntryWitness.stock_try_spill_entry_witness) (And.intro (@Backend.Stock.Proof.SpillJumpWitness.stock_spill_jump_route_witness) (And.intro (@Backend.Stock.Proof.runOkABI_of_return_stop) (And.intro (@Backend.Stock.Proof.source_defined_continueWith) (And.intro (@Backend.Stock.Proof.source_defined_returnValues) (And.intro (@Backend.Stock.Proof.source_defined_setMany) (And.intro (@Backend.Stock.Proof.stock_blockOrder_edges_nonentry) (And.intro (@Backend.Stock.Proof.stock_blockOrder_entry) (And.intro (@Backend.Stock.Proof.stock_branchArgs_shape) (And.intro (@Backend.Stock.Proof.stock_branchArgs_target_arity) (And.intro (@Backend.Stock.Proof.stock_branchCode_try_targets) (And.intro (@Backend.Stock.Proof.stock_lowerBlockCore_try_targets) (And.intro (@Backend.Stock.Proof.stock_lower_cfg) (And.intro (@Backend.Stock.Proof.stock_lower_critical_cfg) (And.intro (@Backend.Stock.Proof.stock_lower_critical_edge_arity) (And.intro (@Backend.Stock.Proof.stock_lower_critical_source) (And.intro (@Backend.Stock.Proof.stock_lower_dense_labels) (And.intro (@Backend.Stock.Proof.stock_lower_edge_arity) (And.intro (@Backend.Stock.Proof.stock_lower_entry_code) (And.intro (@Backend.Stock.Proof.stock_lower_graph_bounds) (And.intro (@Backend.Stock.Proof.stock_lower_graph_nonentry) (And.intro (@Backend.Stock.Proof.stock_lower_indexed_successor_origin) (And.intro (@Backend.Stock.Proof.stock_lower_jump_edge_values) (And.intro (@Backend.Stock.Proof.stock_lower_original_scan) (And.intro (@Backend.Stock.Proof.stock_lower_outgoing_shape) (And.intro (@Backend.Stock.Proof.stock_lower_parameter_shape) (And.intro (@Backend.Stock.Proof.stock_lower_return_cfg) (And.intro (@Backend.Stock.Proof.stock_lower_return_record_runOk) (And.intro (@Backend.Stock.Proof.stock_lower_return_runOk) (And.intro (@Backend.Stock.Proof.stock_lower_return_scan_last) (And.intro (@Backend.Stock.Proof.stock_lower_terminal_cfg_at) (And.intro (@Backend.Stock.Proof.stock_lower_terminal_scan_code) (And.intro (@Backend.Stock.Proof.stock_lower_terminal_successors) (And.intro (@Backend.Stock.Proof.stock_lower_trap_cfg) (And.intro (@Backend.Stock.Proof.stock_lower_trap_scan_last) (And.intro (@Backend.Stock.Proof.stock_lower_try_cfg) (And.intro (@Backend.Stock.Proof.stock_lower_try_targets) (And.intro (@Backend.Stock.Proof.stock_named_branch_selection) (And.intro (@Backend.Stock.Proof.stock_parameter_numbers_nodup) (And.intro (@Backend.Stock.Proof.stock_prepare_copy_metadata) (And.intro (@Backend.Stock.Proof.stock_prepare_edge_arity) (And.intro (@Backend.Stock.Proof.stock_prepare_parameter_shape) (And.intro (@Backend.Stock.Proof.stock_prepare_total) (And.intro (@Backend.Stock.Proof.stock_prepare_total_of_graph) (And.intro (@Backend.Stock.Proof.stock_sourceTable_nonentry) (And.intro (@Backend.Stock.Proof.stock_spillArgMovesAt_edge_runs) (And.intro (@Backend.Stock.Proof.stock_spillArgMovesAt_runs) (And.intro (@Backend.VBlock.insts.eq_1) (And.intro (@Backend.VBlock.label.eq_1) (And.intro (@Backend.VCode.blocks.eq_1) (And.intro (@Backend.VCode.cfg.eq_1) (And.intro (@Backend.retCheck.eq_1) (And.intro (@Backend.retCheck.eq_2) (And.intro (@Backend.spillHomeAt.eq_1) (And.intro (@Backend.spillHomeKeyAt.eq_1) (And.intro (@Backend.spillHomeKeyAt.eq_2) (And.intro (@Backend.spillLocs.eq_1) (And.intro (@Clif.Regs.empty.eq_1) (And.intro (@Clif.enterSlots.eq_1) (And.intro (@Clif.runLoop_ren) (And.intro (@E2E.DeadCleanupExecBytes.binary_correct_exec) (And.intro (@E2E.DeadCleanupExecBytes.binary_correct_exec_of_good) (And.intro (@E2E.DeadCleanupExecBytes.binary_correct_exec_of_got) (And.intro (@E2E.DeadCleanupExecBytes.binary_correct_exec_of_insn) (And.intro (@E2E.DeadCleanupExecBytes.binary_correct_exec_of_reads) (And.intro (@E2E.DeadCleanupExecBytes.binary_correct_exec_peak_proven) (And.intro (@E2E.DeadCleanupExecBytes.binary_correct_exec_proven) (And.intro (@E2E.DeadCleanupExecBytes.binary_correct_exec_static) (And.intro (@E2E.DeadCleanupExecBytes.binary_correct_exec_staticN) (And.intro (@E2E.DeadCleanupStackBound.goodN_iff) (And.intro (@E2E.DeadCleanupStackBound.stackB_isSome_iff) (And.intro (@E2E.ExecBytes.binary_correct_exec) (And.intro (@E2E.ExecBytes.binary_correct_exec_depth_proven) (And.intro (@E2E.ExecBytes.binary_correct_exec_of_good) (And.intro (@E2E.ExecBytes.binary_correct_exec_of_got) (And.intro (@E2E.ExecBytes.binary_correct_exec_of_insn) (And.intro (@E2E.ExecBytes.binary_correct_exec_of_reads) (And.intro (@E2E.ExecBytes.binary_correct_exec_peak_proven) (And.intro (@E2E.ExecBytes.binary_correct_exec_proven) (And.intro (@E2E.ExecBytes.binary_correct_exec_static) (And.intro (@E2E.ExecBytes.binary_correct_exec_staticN) (And.intro (@E2E.LegalProgram.legalProg_refines) (And.intro (@E2E.LegalProgram.legalProg_refines_depth) (And.intro (@E2E.LinkCheck.crate_correct_inScope_proven) (And.intro (@E2E.StackBound.budOkW_budMap) (And.intro (@E2E.StackBound.goodN_iff) (And.intro (@E2E.StackBound.stackB_isSome_iff) (And.intro (@E2E.backend_correct_final) (And.intro (@E2E.backend_correct_final_alloc) (And.intro (@E2E.backend_correct_final_alloc_proven) (And.intro (@E2E.backend_correct_final_cleanup) (And.intro (@E2E.backend_correct_final_cleanup_ex) (And.intro (@E2E.backend_correct_final_cleanup_total) (And.intro (@E2E.backend_correct_final_cleanup_total_emit) (And.intro (@E2E.backend_correct_final_cleanup_total_emit_in) (And.intro (@E2E.backend_correct_final_cleanup_total_emit_input) (And.intro (@E2E.backend_correct_final_cleanup_total_ready) (And.intro (@E2E.backend_correct_final_ex) (And.intro (@E2E.backend_correct_final_id) (And.intro (@E2E.backend_correct_final_indirectFree) (And.intro (@E2E.backend_correct_final_of_lower) (And.intro (@E2E.backend_correct_final_of_lower_ex) (And.intro (@E2E.backend_correct_final_total) (And.intro (@E2E.backend_correct_final_total_emit) (And.intro (@E2E.backend_correct_final_total_emit_in) (And.intro (@E2E.backend_correct_final_total_emit_input) (And.intro (@E2E.backend_correct_final_total_ready) (And.intro (@E2E.backend_correct_final_total_relaxed) (And.intro (@E2E.backend_correct_final_try_witness) (And.intro (@E2E.backend_correct_final_witness) (And.intro (@E2E.backend_correct_legal) (And.intro (@E2E.backend_correct_legal_callFree) (And.intro (@E2E.backend_correct_legal_callFree_cleanup) (And.intro (@E2E.backend_correct_legal_cleanup) (And.intro (@E2E.backend_correct_legal_direct) (And.intro (@E2E.backend_correct_legal_direct_cleanup) (And.intro (@E2E.backend_correct_legal_env) (And.intro (@E2E.backend_correct_legal_env_cleanup) (And.intro (@E2E.backend_correct_opt_proven) (And.intro (@E2E.backend_correct_opt_proven_cleanup) (And.intro (@E2E.backend_correct_program) (And.intro (@E2E.backend_correct_program_budget) (And.intro (@E2E.backend_correct_program_budgetX) (And.intro (@E2E.backend_correct_program_core) (And.intro (@E2E.backend_correct_program_coreX) (And.intro (@E2E.backend_correct_program_peak) (And.intro (@E2E.backend_correct_program_peakX) (And.intro (@E2E.backend_correct_program_returned) (And.intro (@E2E.backend_correct_program_returned_budget) (And.intro (@E2E.backend_correct_program_stack) (And.intro (@E2E.backend_correct_program_stackX) (And.intro (@E2E.emitReady_spill) (And.intro (@E2E.lowerRFunc_spillAlloc) (And.intro (@E2E.spillAccepted) (And.intro (@Front.buildSpec_spec) (And.intro (@Front.buildSpec_srcProg) (And.intro (@Front.bundle_correct_raw) (And.intro (@Front.bundle_correct_raw_baseline) (And.intro (@Front.bundle_correct_raw_peak) (And.intro (@Front.bundle_correct_raw_peak_baseline) (And.intro (@Front.bundle_correct_source) (And.intro (@Front.bundle_correct_source_baseline) (And.intro (@Front.bundle_correct_source_peak) (And.intro (@Front.bundle_correct_source_peak_baseline) (And.intro (@Front.data_complete) (And.intro (@Front.decodeFn_spec) (And.intro (@Front.link_alpha) (And.intro (@Front.parseUnit_raw) (And.intro (@Front.rawLink_eq_link) (And.intro (@Isle.Aarch64.rule_lower_3247.eq_1) (And.intro (@Link.DeadCleanup.SourceWitness.compileExe_correct_source_helper) (And.intro (@Link.DeadCleanup.SourceWitness.compileExe_correct_source_peak_helper) (And.intro (@Link.DeadCleanup.binOk_leanLink) (And.intro (@Link.DeadCleanup.compileExe_correct) (And.intro (@Link.DeadCleanup.compileExe_correct_peak) (And.intro (@Link.DeadCleanup.compileExe_correct_source) (And.intro (@Link.DeadCleanup.compileExe_correct_source_peak) (And.intro (@Link.DeadCleanup.compileExe_total) (And.intro (@Link.DeadCleanup.compileExe_total_input) (And.intro (@Link.DeadCleanup.compileExe_total_reach) (And.intro (@Link.DeadCleanup.leanLink_linkerOk) (And.intro (@Link.DeadCleanup.relocOk_tab) (And.intro (@Link.SourceWitness.compileExe_correct_source_helper) (And.intro (@Link.SourceWitness.compileExe_correct_source_peak_helper) (And.intro (@Link.binOk_leanLink) (And.intro (@Link.compileExe_correct) (And.intro (@Link.compileExe_correct_depth) (And.intro (@Link.compileExe_correct_peak) (And.intro (@Link.compileExe_correct_source) (And.intro (@Link.compileExe_correct_source_peak) (And.intro (@Link.compileExe_total) (And.intro (@Link.compileExe_total_input) (And.intro (@Link.compileExe_total_reach) (And.intro (@Link.leanLink_linkerOk) (And.intro (@Link.relocOk_tab) (And.intro (@Opt.Legal.Complete.check_complete_of_preB) (And.intro (@Opt.Legal.Complete.preB_iff) (And.intro (@Opt.Proof.simplifyRulesCorrect_proven) ((@Opt.optimize_sim_proven)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
end StockDeliveryAudit

#print axioms StockDeliveryAudit.pr247_bundle
