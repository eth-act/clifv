import Lean
import FV.Backend.Proof.FilteredGraphIncoming
import FV.Backend.Proof.IndexedPredMultiplicity
import FV.Backend.Proof.PerEdgeArgumentShape
import FV.Backend.Proof.PerEdgeParameterShape
import FV.Backend.Proof.PerEdgePrepSplitWitness
import FV.Backend.Proof.PerEdgePrepareJump
import FV.Backend.Proof.PerEdgePrepareNoSplit
import FV.Backend.Proof.PerEdgePrepareUnsplitGraph
import FV.Backend.Proof.PerEdgePreparedArity
import FV.Backend.Proof.PerEdgeRouteArity
import FV.Backend.Proof.PerEdgeSpillBlock
import FV.Backend.Proof.PerEdgeSpillCopy
import FV.Backend.Proof.PerEdgeSpillCycleFixture
import FV.Backend.Proof.PerEdgeSpillEdge
import FV.Backend.Proof.PerEdgeSpillEntry
import FV.Backend.Proof.PerEdgeSpillEntryFixture
import FV.Backend.Proof.PerEdgeSpillEntryGood
import FV.Backend.Proof.PerEdgeSpillEntrySaves
import FV.Backend.Proof.PerEdgeSpillEntrySymbols
import FV.Backend.Proof.PerEdgeSpillEntryWitness
import FV.Backend.Proof.PerEdgeSpillHomes
import FV.Backend.Proof.PerEdgeSpillInst
import FV.Backend.Proof.PerEdgeSpillInstFixture
import FV.Backend.Proof.PerEdgeSpillInstWitness
import FV.Backend.Proof.PerEdgeSpillJumpWitness
import FV.Backend.Proof.PerEdgeSpillPreState
import FV.Backend.Proof.PerEdgeSpillRoutes
import FV.Backend.Proof.PerEdgeSpillSharedFixture
import FV.Backend.Proof.PerEdgeSpillSharedJump
import FV.Backend.Proof.PerEdgeSpillStateAt
import FV.Backend.Proof.PerEdgeSpillTerminalBlock
import FV.Backend.Proof.PerEdgeSpillWitness
import FV.Backend.Proof.PrepareReachability
import FV.Backend.Proof.PreparedArityWitness
import FV.Backend.Proof.ReorderedGraphIncoming
import FV.Backend.Proof.StockBranchArgumentShape
import FV.Backend.Proof.StockBranchCfg
import FV.Backend.Proof.StockBranchHelperProjection
import FV.Backend.Proof.StockBranchHelperTargets
import FV.Backend.Proof.StockBranchRootTargets
import FV.Backend.Proof.StockBranchSelection
import FV.Backend.Proof.StockBranchTargetsWitness
import FV.Backend.Proof.StockCfgTotal
import FV.Backend.Proof.StockCfgTotalWitness
import FV.Backend.Proof.StockConditionalRootTargets
import FV.Backend.Proof.StockConditionalTargets
import FV.Backend.Proof.StockConditionalTargetsWitness
import FV.Backend.Proof.StockControlCfgWitness
import FV.Backend.Proof.StockControlShape
import FV.Backend.Proof.StockCriticalEdgeArity
import FV.Backend.Proof.StockEdgeArity
import FV.Backend.Proof.StockEdgeValuesWitness
import FV.Backend.Proof.StockEmittedGraph
import FV.Backend.Proof.StockEmittedGraphWitness
import FV.Backend.Proof.StockEntryCode
import FV.Backend.Proof.StockEntryGraph
import FV.Backend.Proof.StockEntryOrder
import FV.Backend.Proof.StockGraphBounds
import FV.Backend.Proof.StockGraphEdges
import FV.Backend.Proof.StockJumpEdgeValues
import FV.Backend.Proof.StockNamedBranchTargets
import FV.Backend.Proof.StockNodeCoverage
import FV.Backend.Proof.StockNodeCoverageWitness
import FV.Backend.Proof.StockOrderGraphWitness
import FV.Backend.Proof.StockOrdinaryCfg
import FV.Backend.Proof.StockOutgoingShape
import FV.Backend.Proof.StockParameterShape
import FV.Backend.Proof.StockPerEdgeDirectWitness
import FV.Backend.Proof.StockPerEdgeM6DivergenceWitness
import FV.Backend.Proof.StockPerEdgeM6StuckWitness
import FV.Backend.Proof.StockPrepareTotal
import FV.Backend.Proof.StockPreparedArity
import FV.Backend.Proof.StockReturnContract
import FV.Backend.Proof.StockReturnScanShape
import FV.Backend.Proof.StockReturnSourceWitness
import FV.Backend.Proof.StockReturnVCode
import FV.Backend.Proof.StockSourceCallWitness
import FV.Backend.Proof.StockSourceResults
import FV.Backend.Proof.StockSpillCopyMetadata
import FV.Backend.Proof.StockSpillCopyMetadataWitness
import FV.Backend.Proof.StockTerminalCfg
import FV.Backend.Proof.StockTerminalPlacement
import FV.Backend.Proof.StockTryCfg
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let targets : Array String := #[ "FV.Backend.Proof.FilteredGraphIncoming","FV.Backend.Proof.IndexedPredMultiplicity","FV.Backend.Proof.PerEdgeArgumentShape","FV.Backend.Proof.PerEdgeParameterShape","FV.Backend.Proof.PerEdgePrepSplitWitness","FV.Backend.Proof.PerEdgePrepareJump","FV.Backend.Proof.PerEdgePrepareNoSplit","FV.Backend.Proof.PerEdgePrepareUnsplitGraph","FV.Backend.Proof.PerEdgePreparedArity","FV.Backend.Proof.PerEdgeRouteArity","FV.Backend.Proof.PerEdgeSpillBlock","FV.Backend.Proof.PerEdgeSpillCopy","FV.Backend.Proof.PerEdgeSpillCycleFixture","FV.Backend.Proof.PerEdgeSpillEdge","FV.Backend.Proof.PerEdgeSpillEntry","FV.Backend.Proof.PerEdgeSpillEntryFixture","FV.Backend.Proof.PerEdgeSpillEntryGood","FV.Backend.Proof.PerEdgeSpillEntrySaves","FV.Backend.Proof.PerEdgeSpillEntrySymbols","FV.Backend.Proof.PerEdgeSpillEntryWitness","FV.Backend.Proof.PerEdgeSpillHomes","FV.Backend.Proof.PerEdgeSpillInst","FV.Backend.Proof.PerEdgeSpillInstFixture","FV.Backend.Proof.PerEdgeSpillInstWitness","FV.Backend.Proof.PerEdgeSpillJumpWitness","FV.Backend.Proof.PerEdgeSpillPreState","FV.Backend.Proof.PerEdgeSpillRoutes","FV.Backend.Proof.PerEdgeSpillSharedFixture","FV.Backend.Proof.PerEdgeSpillSharedJump","FV.Backend.Proof.PerEdgeSpillStateAt","FV.Backend.Proof.PerEdgeSpillTerminalBlock","FV.Backend.Proof.PerEdgeSpillWitness","FV.Backend.Proof.PrepareReachability","FV.Backend.Proof.PreparedArityWitness","FV.Backend.Proof.ReorderedGraphIncoming","FV.Backend.Proof.StockBranchArgumentShape","FV.Backend.Proof.StockBranchCfg","FV.Backend.Proof.StockBranchHelperProjection","FV.Backend.Proof.StockBranchHelperTargets","FV.Backend.Proof.StockBranchRootTargets","FV.Backend.Proof.StockBranchSelection","FV.Backend.Proof.StockBranchTargetsWitness","FV.Backend.Proof.StockCfgTotal","FV.Backend.Proof.StockCfgTotalWitness","FV.Backend.Proof.StockConditionalRootTargets","FV.Backend.Proof.StockConditionalTargets","FV.Backend.Proof.StockConditionalTargetsWitness","FV.Backend.Proof.StockControlCfgWitness","FV.Backend.Proof.StockControlShape","FV.Backend.Proof.StockCriticalEdgeArity","FV.Backend.Proof.StockEdgeArity","FV.Backend.Proof.StockEdgeValuesWitness","FV.Backend.Proof.StockEmittedGraph","FV.Backend.Proof.StockEmittedGraphWitness","FV.Backend.Proof.StockEntryCode","FV.Backend.Proof.StockEntryGraph","FV.Backend.Proof.StockEntryOrder","FV.Backend.Proof.StockGraphBounds","FV.Backend.Proof.StockGraphEdges","FV.Backend.Proof.StockJumpEdgeValues","FV.Backend.Proof.StockNamedBranchTargets","FV.Backend.Proof.StockNodeCoverage","FV.Backend.Proof.StockNodeCoverageWitness","FV.Backend.Proof.StockOrderGraphWitness","FV.Backend.Proof.StockOrdinaryCfg","FV.Backend.Proof.StockOutgoingShape","FV.Backend.Proof.StockParameterShape","FV.Backend.Proof.StockPerEdgeDirectWitness","FV.Backend.Proof.StockPerEdgeM6DivergenceWitness","FV.Backend.Proof.StockPerEdgeM6StuckWitness","FV.Backend.Proof.StockPrepareTotal","FV.Backend.Proof.StockPreparedArity","FV.Backend.Proof.StockReturnContract","FV.Backend.Proof.StockReturnScanShape","FV.Backend.Proof.StockReturnSourceWitness","FV.Backend.Proof.StockReturnVCode","FV.Backend.Proof.StockSourceCallWitness","FV.Backend.Proof.StockSourceResults","FV.Backend.Proof.StockSpillCopyMetadata","FV.Backend.Proof.StockSpillCopyMetadataWitness","FV.Backend.Proof.StockTerminalCfg","FV.Backend.Proof.StockTerminalPlacement","FV.Backend.Proof.StockTryCfg" ]
  let mut count : Nat := 0
  for (name, info) in env.constants.toList do
    if false then continue
    let some index := env.getModuleIdxFor? name | continue
    let mod := env.header.moduleNames[index]!
    if !targets.contains mod.toString then continue
    let axioms ← collectAxioms name
    logInfo m!"DELIVERY_CONSTANT {Json.compress (toJson (name.toString, axioms.map Name.toString))}"
    count := count + 1
  logInfo m!"DELIVERY_AXIOM_COUNT {count}"
