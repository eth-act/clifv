import Lean
import FV.Backend.Proof.Encode
import FV.Backend.Proof.FormsCoverComplete
import FV.Backend.Proof.LowerComplete
import FV.Backend.Proof.LowerLoop
import FV.Backend.Proof.PerEdgeAllocDriverSound
import FV.Backend.Proof.PerEdgePrepareComplete
import FV.Backend.Proof.PerEdgePrepareFacts
import FV.Backend.Proof.PerEdgePrepareFilterFacts
import FV.Backend.Proof.PerEdgePrepareInputTotal
import FV.Backend.Proof.PerEdgePrepareLoopFacts
import FV.Backend.Proof.PerEdgePrepareLoopWitness
import FV.Backend.Proof.PerEdgePrepareOrderFacts
import FV.Backend.Proof.PerEdgePrepareOuterFacts
import FV.Backend.Proof.PerEdgePrepareOuterWitness
import FV.Backend.Proof.PerEdgePrepareSound
import FV.Backend.Proof.PerEdgePrepareTotal
import FV.Backend.Proof.PerEdgePrepareTotalWitness
import FV.Backend.Proof.PerEdgePrepareWitness
import FV.Backend.Proof.PerEdgePreparedDriverSound
import FV.Backend.Proof.PerEdgeRegallocFwd
import FV.Backend.Proof.PerEdgeRegallocLemmas
import FV.Backend.Proof.PerEdgeRegallocSound
import FV.Backend.Proof.PerEdgeVCodeSem
import FV.Backend.Proof.PrepareComplete
import FV.Backend.Proof.PrepareDirect
import FV.Backend.Proof.StockBlockCode
import FV.Backend.Proof.StockBranchArgumentCode
import FV.Backend.Proof.StockCriticalCode
import FV.Backend.Proof.StockCriticalValues
import FV.Backend.Proof.StockCriticalValuesWitness
import FV.Backend.Proof.StockEdgeCode
import FV.Backend.Proof.StockEdgeValues
import FV.Backend.Proof.StockEntryAliases
import FV.Backend.Proof.StockOrderGraph
import FV.Backend.Proof.StockOutgoingOrigin
import FV.Backend.Proof.StockOutgoingVectors
import FV.Backend.Proof.StockPerEdgeAllocatorWitness
import FV.Backend.Proof.StockPerEdgeCheckerWitness
import FV.Backend.Proof.StockPerEdgeCriticalAllocatorWitness
import FV.Backend.Proof.StockPerEdgeM6HaltWitness
import FV.Backend.Proof.StockPerEdgeM6Witness
import FV.Backend.Proof.StockPerEdgeValues
import FV.Backend.Proof.StockPerSuccessorWitness
import FV.Backend.Proof.StockPrepareComplete
import FV.Backend.Proof.StockPrepareCompleteWitness
import FV.Backend.Proof.StockPrepareInputs
import FV.Backend.Proof.StockPreparedForwardWitness
import FV.Backend.Proof.StockSelectedArguments
import FV.Backend.Proof.StockSelectedGraph
import FV.Backend.Proof.StockSelectedRoutes
import FV.Backend.Proof.StockSourceEdges
import FV.Backend.Proof.StockTermContract
import FV.Backend.Proof.StockTermContractWitness
import FV.Backend.RegallocPerEdge
import FV.Backend.RegallocPerEdgeDriver
import FV.Backend.RegallocPerEdgePrepare
import FV.Backend.RegallocPerEdgePrepareCheck
import FV.Backend.RegallocPerEdgeSpill
import FV.E2E.AllocDirect
import FV.E2E.AllocTotal
import FV.E2E.BinaryGood
import FV.E2E.DeadCleanupExecBytes
import FV.E2E.DeadCleanupExecGoodReads
import FV.E2E.DeadCleanupExecGoodRun
import FV.E2E.DeadCleanupExecGot
import FV.E2E.DeadCleanupExecPeak
import FV.E2E.DeadCleanupExecProven
import FV.E2E.DeadCleanupExecRunN
import FV.E2E.DeadCleanupExecStatic
import FV.E2E.DeadCleanupFinal
import FV.E2E.DeadCleanupLegal
import FV.E2E.DeadCleanupLegalDirect
import FV.E2E.DeadCleanupOptProven
import FV.E2E.DeadCleanupSize
import FV.E2E.DeadCleanupStackBound
import FV.E2E.DeadCleanupTotal
import FV.E2E.EmitTotal
import FV.E2E.EmitTotalIn
import FV.E2E.ExecBytes
import FV.E2E.ExecGoodReads
import FV.E2E.ExecGoodRun
import FV.E2E.ExecGot
import FV.E2E.ExecProven
import FV.E2E.ExecRunN
import FV.E2E.ExecStatic
import FV.E2E.Final
import FV.E2E.FinalDirect
import FV.E2E.Legal
import FV.E2E.LegalDepth
import FV.E2E.LegalDirect
import FV.E2E.LegalProgram
import FV.E2E.LinkArm
import FV.E2E.LinkGood
import FV.E2E.NonVacuity
import FV.E2E.OptProven
import FV.E2E.RelaxTotal
import FV.E2E.SizeIn
import FV.E2E.SpillDefined
import FV.E2E.SpillKillFree
import FV.E2E.StackBound
import FV.Front.BundleProof
import FV.Front.Exe
import FV.Front.Raw
import FV.Front.RawExe
import FV.Front.RawProof
import FV.Front.RenameRun
import FV.Link.Correct
import FV.Link.DeadCleanupCorrect
import FV.Link.DeadCleanupExe
import FV.Link.DeadCleanupExePeak
import FV.Link.DeadCleanupExeSource
import FV.Link.DeadCleanupExeTotal
import FV.Link.DeadCleanupLayoutProof
import FV.Link.Exe
import FV.Link.ExeInput
import FV.Link.ExeInputCleanup
import FV.Link.ExeInputReach
import FV.Link.ExeInputReachCleanup
import FV.Link.ExeSource
import FV.Link.ExeTotal
import FV.Link.LayoutProof
import FV.Link.NonVacuityDeadCleanupExeSource
import FV.Link.NonVacuityExeSource
import FV.Opt.Proof.LegalPre
import FV.Opt.Proof.RuleAll
import FV.Opt.Proof.SimpPass
import FVTest.Backend.StockConfig
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let targets : Array String := #[ "FV.Backend.Proof.PerEdgeAllocDriverSound","FV.Backend.Proof.PerEdgePrepareComplete","FV.Backend.Proof.PerEdgePrepareFacts","FV.Backend.Proof.PerEdgePrepareFilterFacts","FV.Backend.Proof.PerEdgePrepareInputTotal","FV.Backend.Proof.PerEdgePrepareLoopFacts","FV.Backend.Proof.PerEdgePrepareLoopWitness","FV.Backend.Proof.PerEdgePrepareOrderFacts","FV.Backend.Proof.PerEdgePrepareOuterFacts","FV.Backend.Proof.PerEdgePrepareOuterWitness","FV.Backend.Proof.PerEdgePrepareSound","FV.Backend.Proof.PerEdgePrepareTotal","FV.Backend.Proof.PerEdgePrepareTotalWitness","FV.Backend.Proof.PerEdgePrepareWitness","FV.Backend.Proof.PerEdgePreparedDriverSound","FV.Backend.Proof.PerEdgeRegallocFwd","FV.Backend.Proof.PerEdgeRegallocLemmas","FV.Backend.Proof.PerEdgeRegallocSound","FV.Backend.Proof.PerEdgeVCodeSem","FV.Backend.Proof.StockBlockCode","FV.Backend.Proof.StockBranchArgumentCode","FV.Backend.Proof.StockCriticalCode","FV.Backend.Proof.StockCriticalValues","FV.Backend.Proof.StockCriticalValuesWitness","FV.Backend.Proof.StockEdgeCode","FV.Backend.Proof.StockEdgeValues","FV.Backend.Proof.StockEntryAliases","FV.Backend.Proof.StockOrderGraph","FV.Backend.Proof.StockOutgoingOrigin","FV.Backend.Proof.StockOutgoingVectors","FV.Backend.Proof.StockPerEdgeAllocatorWitness","FV.Backend.Proof.StockPerEdgeCheckerWitness","FV.Backend.Proof.StockPerEdgeCriticalAllocatorWitness","FV.Backend.Proof.StockPerEdgeM6HaltWitness","FV.Backend.Proof.StockPerEdgeM6Witness","FV.Backend.Proof.StockPerEdgeValues","FV.Backend.Proof.StockPerSuccessorWitness","FV.Backend.Proof.StockPrepareComplete","FV.Backend.Proof.StockPrepareCompleteWitness","FV.Backend.Proof.StockPrepareInputs","FV.Backend.Proof.StockPreparedForwardWitness","FV.Backend.Proof.StockSelectedArguments","FV.Backend.Proof.StockSelectedGraph","FV.Backend.Proof.StockSelectedRoutes","FV.Backend.Proof.StockSourceEdges","FV.Backend.Proof.StockTermContract","FV.Backend.Proof.StockTermContractWitness","FV.Backend.RegallocPerEdge","FV.Backend.RegallocPerEdgeDriver","FV.Backend.RegallocPerEdgePrepare","FV.Backend.RegallocPerEdgePrepareCheck","FV.Backend.RegallocPerEdgeSpill","FVTest.Backend.StockConfig" ]
  let mut count : Nat := 0
  for (name, info) in env.constants.toList do
    if !info.isTheorem || name.toString.startsWith "_private." || name.isInternal then continue
    let some index := env.getModuleIdxFor? name | continue
    let mod := env.header.moduleNames[index]!
    if !targets.contains mod.toString then continue
    let axioms ← collectAxioms name
    logInfo m!"DELIVERY_AXIOMS {name} {Json.compress (toJson (axioms.map Name.toString))}"
    count := count + 1
  logInfo m!"DELIVERY_AXIOM_COUNT {count}"

#print axioms Front.buildSpec_spec
#print axioms Front.buildSpec_srcProg
#print axioms Front.data_complete
#print axioms Front.link_alpha
#print axioms Front.parseUnit_raw
#print axioms Front.bundle_correct_source
#print axioms Front.bundle_correct_source_baseline
#print axioms Front.bundle_correct_source_peak
#print axioms Front.bundle_correct_source_peak_baseline
#print axioms Front.decodeFn_spec
#print axioms Front.bundle_correct_raw
#print axioms Front.bundle_correct_raw_baseline
#print axioms Front.bundle_correct_raw_peak
#print axioms Front.bundle_correct_raw_peak_baseline
#print axioms Front.rawLink_eq_link
#print axioms Clif.runLoop_ren
#print axioms Link.binOk_leanLink
#print axioms Link.DeadCleanup.binOk_leanLink
#print axioms Link.DeadCleanup.compileExe_correct
#print axioms Link.DeadCleanup.compileExe_correct_peak
#print axioms Link.DeadCleanup.compileExe_correct_source
#print axioms Link.DeadCleanup.compileExe_correct_source_peak
#print axioms Link.DeadCleanup.compileExe_total
#print axioms Link.DeadCleanup.leanLink_linkerOk
#print axioms Link.compileExe_correct
#print axioms Link.compileExe_correct_depth
#print axioms Link.compileExe_correct_peak
#print axioms Link.compileExe_total_input
#print axioms Link.DeadCleanup.compileExe_total_input
#print axioms Link.compileExe_total_reach
#print axioms Link.relocOk_tab
#print axioms Link.DeadCleanup.compileExe_total_reach
#print axioms Link.DeadCleanup.relocOk_tab
#print axioms Link.compileExe_correct_source
#print axioms Link.compileExe_correct_source_peak
#print axioms Link.compileExe_total
#print axioms Link.leanLink_linkerOk
#print axioms E2E.backend_correct_final_alloc
#print axioms E2E.backend_correct_final_total
#print axioms E2E.lowerRFunc_spillAlloc
#print axioms E2E.backend_correct_program_stackX
#print axioms E2E.DeadCleanupExecBytes.binary_correct_exec
#print axioms E2E.DeadCleanupExecBytes.binary_correct_exec_of_good
#print axioms E2E.DeadCleanupExecBytes.binary_correct_exec_of_got
#print axioms E2E.DeadCleanupExecBytes.binary_correct_exec_of_reads
#print axioms E2E.DeadCleanupExecBytes.binary_correct_exec_of_insn
#print axioms E2E.DeadCleanupExecBytes.binary_correct_exec_peak_proven
#print axioms E2E.DeadCleanupExecBytes.binary_correct_exec_proven
#print axioms E2E.DeadCleanupExecBytes.binary_correct_exec_staticN
#print axioms E2E.DeadCleanupExecBytes.binary_correct_exec_static
#print axioms E2E.backend_correct_final_cleanup
#print axioms E2E.backend_correct_final_cleanup_ex
#print axioms E2E.backend_correct_legal_callFree_cleanup
#print axioms E2E.backend_correct_legal_cleanup
#print axioms E2E.backend_correct_legal_env_cleanup
#print axioms E2E.backend_correct_legal_direct_cleanup
#print axioms E2E.backend_correct_opt_proven_cleanup
#print axioms E2E.backend_correct_final_cleanup_total_emit_input
#print axioms E2E.DeadCleanupStackBound.goodN_iff
#print axioms E2E.DeadCleanupStackBound.stackB_isSome_iff
#print axioms E2E.backend_correct_final_cleanup_total
#print axioms E2E.backend_correct_final_cleanup_total_emit
#print axioms E2E.backend_correct_final_cleanup_total_emit_in
#print axioms E2E.backend_correct_final_cleanup_total_ready
#print axioms E2E.backend_correct_final_total_emit
#print axioms E2E.backend_correct_final_total_ready
#print axioms E2E.emitReady_spill
#print axioms E2E.backend_correct_final_total_emit_in
#print axioms E2E.ExecBytes.binary_correct_exec
#print axioms E2E.ExecBytes.binary_correct_exec_of_good
#print axioms E2E.ExecBytes.binary_correct_exec_of_got
#print axioms E2E.ExecBytes.binary_correct_exec_of_reads
#print axioms E2E.ExecBytes.binary_correct_exec_of_insn
#print axioms E2E.ExecBytes.binary_correct_exec_depth_proven
#print axioms E2E.ExecBytes.binary_correct_exec_peak_proven
#print axioms E2E.ExecBytes.binary_correct_exec_proven
#print axioms E2E.ExecBytes.binary_correct_exec_staticN
#print axioms E2E.ExecBytes.binary_correct_exec_static
#print axioms E2E.backend_correct_final
#print axioms E2E.backend_correct_final_ex
#print axioms E2E.backend_correct_final_indirectFree
#print axioms E2E.backend_correct_final_of_lower
#print axioms E2E.backend_correct_final_of_lower_ex
#print axioms E2E.backend_correct_legal
#print axioms E2E.backend_correct_legal_callFree
#print axioms E2E.backend_correct_legal_env
#print axioms E2E.LegalProgram.legalProg_refines_depth
#print axioms E2E.backend_correct_legal_direct
#print axioms E2E.LegalProgram.legalProg_refines
#print axioms E2E.backend_correct_program
#print axioms E2E.backend_correct_program_budget
#print axioms E2E.backend_correct_program_core
#print axioms E2E.backend_correct_program_peak
#print axioms E2E.backend_correct_program_returned
#print axioms E2E.backend_correct_program_returned_budget
#print axioms E2E.backend_correct_program_budgetX
#print axioms E2E.backend_correct_program_coreX
#print axioms E2E.backend_correct_program_peakX
#print axioms E2E.backend_correct_final_id
#print axioms E2E.backend_correct_opt_proven
#print axioms E2E.backend_correct_final_total_relaxed
#print axioms E2E.backend_correct_final_total_emit_input
#print axioms E2E.LinkCheck.crate_correct_inScope_proven
#print axioms E2E.backend_correct_final_alloc_proven
#print axioms E2E.spillAccepted
#print axioms E2E.StackBound.budOkW_budMap
#print axioms E2E.StackBound.goodN_iff
#print axioms E2E.StackBound.stackB_isSome_iff
#print axioms E2E.backend_correct_program_stack
#print axioms Backend.Insn.decode_encode
#print axioms Backend.Proof.Driver.formsCovered_complete
#print axioms Backend.Proof.Driver.lowerCheck_complete
#print axioms Backend.Proof.Driver.prepDomain_of_lower
#print axioms Backend.Proof.Prep.prepCheck_complete
#print axioms Backend.Proof.Prep.prepare_correct
#print axioms Opt.Legal.Complete.check_complete_of_preB
#print axioms Opt.Legal.Complete.preB_iff
#print axioms Opt.Proof.simplifyRulesCorrect_proven
#print axioms Opt.optimize_sim_proven
#print axioms E2E.backend_correct_final_try_witness
#print axioms E2E.backend_correct_final_witness
#print axioms Link.DeadCleanup.SourceWitness.compileExe_correct_source_helper
#print axioms Link.DeadCleanup.SourceWitness.compileExe_correct_source_peak_helper
#print axioms Link.SourceWitness.compileExe_correct_source_helper
#print axioms Link.SourceWitness.compileExe_correct_source_peak_helper
