from pathlib import Path
import subprocess as sp,json,re,hashlib,datetime
root=Path('/home/lee/clifv/.worktrees/driver-proof-resume');base='44abfd79cbe4cda5ed868054b7f9e166152cf709';head='e5a9cd6ce7a339ffab9fc6b0a26d574296d3f8de'
def tree(ref):
 out={}
 for row in sp.check_output(['git','ls-tree','-r',ref],cwd=root,text=True).splitlines():
  meta,p=row.split('\t',1);out[p]=meta.split()[2]
 return out
before=tree(base);after=tree(head);modified=[p for p,b in before.items() if after.get(p)!=b];added=[p for p in after if p not in before]
assert modified==['FV/Backend/Proof/StockReturnSourceWitness.lean'],modified
changed=[p for p in modified+added if p.endswith('.lean')];assert len(changed)==83
assert all(p.startswith('FV/Backend/Proof/') for p in changed)
blob=lambda p:sp.check_output(['git','cat-file','blob',after[p]],cwd=root,text=True)
old=sp.check_output(['git','cat-file','blob',before[modified[0]]],cwd=root,text=True);new=blob(modified[0]);oldLines=old.splitlines();newLines=new.splitlines();deletions=[op for op in __import__('difflib').SequenceMatcher(a=oldLines,b=newLines,autojunk=False).get_opcodes() if op[0] in ['delete','replace']];assert not deletions,deletions
# Existing imports and complete original declaration bodies are preserved;
# the only edits are new imports and declarations before the closing namespace.
oldBody=old[old.index('namespace '):];newBody=new[new.index('namespace '):];oldPrefix=oldBody[:oldBody.rfind('end Backend.Stock.Proof.ReturnSourceWitness')];assert newBody.startswith(oldPrefix)
modules={p[:-5].replace('/','.') for p in after if p.startswith(('FV/','FVTest/')) and p.endswith('.lean')};missing={}
for p in after:
 if not p.startswith(('FV/','FVTest/')) or not p.endswith('.lean'):continue
 for line in re.findall(r'^(?:(?:public|private)\s+)?import\s+([^\n]+)',blob(p),re.M):
  for m in line.split():
   if m.startswith(('FV.','FVTest.')) and m not in modules:missing.setdefault(m,[]).append(p)
assert not missing,missing
historical=json.loads((root/'docs/research/stock-body-form-checkpoint.json').read_text())['sources'];sourceHashes={};matched=[];different=[];absent=[]
for p in changed:
 digest=hashlib.sha256(blob(p).encode()).hexdigest();sourceHashes[p]=digest
 (absent if p not in historical else matched if historical[p]==digest else different).append(p)
r={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pr':247,'base':base,'head':head,'source_module_count':len(modules),'added_Lean_proof_files':len(changed)-1,'only_modified_existing_path':modified[0],'all_original_return_witness_imports_and_complete_declaration_bodies_preserved':True,'deletions_or_replacements_in_return_witness':0,'runtime_production_compiler_checker_linker_and_harness_sources_changed':False,'all_FV_FVTest_imports_resolve_in_exact_proposed_source_tree':True,'source_sha256':sourceHashes,'historical_full_snapshot_source_matches':len(matched),'historical_source_differences':different,'historical_missing_sources':absent,'historical_evidence_is_NOT_current_gate_evidence':True,'current_full_gate_status':'pending exact PR247 gates after PR246; no merge-ready claim','full_goal':'ORIGINAL#140 active/incomplete; production legacy'}
(root/'docs/research/stock-pr247-source-review.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='source_sha256'}))
