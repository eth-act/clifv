from pathlib import Path
import tarfile,hashlib,datetime,json,shutil,os
os.nice(15);root=Path('/tmp/stock-try-rule-inputs');assert root.is_dir() and not root.is_symlink()
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');dest=Path('/home/lee/.clifv-recovery')/(stamp+'-obsolete-proof-inputs');dest.mkdir();files=sorted(p for p in root.rglob('*') if p.is_file());assert files
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();manifest={str(p.relative_to(root)):sha(p) for p in files};total=sum(p.stat().st_size for p in files);archive=dest/'stock-try-rule-inputs.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=1) as t:
 for p in files:t.add(p,arcname=str(p.relative_to(root)),recursive=False)
with tarfile.open(archive) as t:
 assert set(t.getnames())==set(manifest)
 for name,h in manifest.items():assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==h,name
assert {str(p.relative_to(root)):sha(p) for p in root.rglob('*') if p.is_file()}==manifest
shutil.copy2('/tmp/stock-try-rule-inputs.json',dest/'original-inputs-manifest.json')
r={'utc':stamp,'removed_expendable_snapshot':str(root),'archive':str(archive),'archive_sha256':sha(archive),'bytes_before':total,'archive_bytes':archive.stat().st_size,'member_count':len(files),'member_sha256':manifest,'every_archived_byte_verified':True,'scratch_sources_and_logs_preserved':True}
(dest/'manifest.json').write_text(json.dumps(r,indent=2)+'\n');shutil.rmtree(root)
Path('/tmp/stock-delivery-obsolete-inputs-cleanup.json').write_text(json.dumps(r,indent=2)+'\n');Path('/home/lee/clifv/.worktrees/driver-proof-resume/docs/research/stock-delivery-obsolete-inputs-cleanup.json').write_text(json.dumps({k:v for k,v in r.items() if k!='member_sha256'},indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='member_sha256'}))
