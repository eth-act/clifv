@kevaundray Both requested drafts are now on main through squash merges:

- #246: fc4a06f39f3840f27fc2e41e158b2ada0bbbcf60 (per-successor preparation).
- #247: 5a3ad2bb0ab37d7f97d96b5406541682b3b5352e (CFG correspondence/preparation totality and witnesses).

Each landed tree exactly equals its fully validated candidate tree. Full FV/FVTest/tools/crates builds, runtime/encoding, both original 1,150-identity/stage E2E baselines, all-constant/standard compiler audits, one bundled MCP per PR and fresh ready-event CI passed. Production still uses the legacy driver; #140 remains incomplete.

This is the agreed ping so you can rebase floats-types onto both merges. Preserve the previously agreed integer-domain/old-theorem compatibility boundary; list the StockReturnSourceWitness overlap and any newly needed proof-only arms before the type-interface merge. I am finishing recovery backup/cleanup and stopping for the user's driver-status review, not starting the next Stock proof batch. No new task reservation.
