Stock preparation needs a proof that its emitted terminators and indexed edges describe the same graph. This PR derives that correspondence from successful Stock lowering under the original source scope, then proves raw and checked preparation success without a caller-supplied graph certificate.

It also carries argument/parameter shape through preparation and connects actual spill-copy execution, with complete source, CFG, branch/return/TryCall and pipeline witnesses. It preserves existing theorem variants and production defaults. Whole-driver source simulation/completeness and production integration remain open in #140.

#246 is now squash merged as fc4a06f39f3840f27fc2e41e158b2ada0bbbcf60. This PR is rebased onto that actual main commit; all 83 Lean proof modules plus the delivery note retain the original delta byte for byte. Whole-driver simulation, completeness and production cutover remain open in #140.

Validation passed on exact head 0ffe7e5830aa240bfb70e3b1f47f72197f922a9a:

- Full 2,102-module FV/FVTest build, compiler/checker/linker/decoder tools, and crate proofs.
- Runtime suites: 114/114, 22/22, and 4,672 passes with no failures/errors/native disagreements (seven existing nonrunnable cases).
- Encoding: 1,308/1,308 identical; both E2E runs preserve all original 1,150 function identities and stages, with byte-identical reports and zero rejections.
- All 3,412 changed-module constants, including private/generated helpers, use only standard axioms. One bundled MCP verification covers all 389 public/compiler theorem roots: propext, Classical.choice, Quot.sound; no source warnings. Prior exact axiom sets unchanged.
- GitHub CI passed on this exact head; fresh ready-event checks must also pass before squash.

Frozen canonical source and scripts remain unchanged and backed up remotely. Production remains legacy, and full #140 simulation/completeness/cutover work remains unfinished. Evidence: docs/research/stock-cfg-preparation-delivery.md and contributor status #44.
