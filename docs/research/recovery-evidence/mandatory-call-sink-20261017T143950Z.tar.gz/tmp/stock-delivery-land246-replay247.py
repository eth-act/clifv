import subprocess as s,json,datetime,pathlib,hashlib
P=pathlib.Path; root=P('/home/lee/clifv'); canon=root/'.worktrees/driver-proof-resume';view=root/'.worktrees/stock-delivery-gates'
def g(*args):return s.check_output(['git',*args],cwd=root,text=True).strip()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
base='fc4a06f39f3840f27fc2e41e158b2ada0bbbcf60'; old='b700671120ddb1f60d86d7e8769b2ed7c17e3d14'; branch='agent/stock-cfg-preparation-proof-pr'; tree=g('rev-parse',old+'^{tree}')
assert g('rev-parse','origin/main')==base
assert g('rev-parse',base+'^{tree}')=='893a471a98cfd23a2ac18c66a94f856bebf38bc1'
land={'utc':now(),'pr':246,'merge_commit':base,'validated_head':'a071e715d1feea0266c86c3b46d5cb96db885c91','landed_tree_equals_validated_tree':True,'production':'legacy','full_goal_complete':False}
for p in [P('/tmp/stock-pr246-landed.json'),canon/'docs/research/stock-pr246-landed.json']:p.write_text(json.dumps(land,indent=2)+'\n')
body=s.check_output(['gh','issue','view','44','--json','body','--jq','.body'],text=True)
body+='\n\n'+now()+' ACTIVE — #246 SQUASH MERGED as '+base+'. Landed tree exactly equals fully validated a071e715 tree; full local gates, original E2E identities/stages, all-constant/336-root MCP audits and ready-event CI passed. Canonical saved source unchanged and backed up remotely. Next: replay only #247 delta on this squash, complete exact-head full gates, then squash #247; no proof-plan expansion. Production remains legacy; #140 remains incomplete. Validation view active; one shared warm cache; old canonical queue held.\n'
p=P('/tmp/stock-delivery-current44.md');p.write_text(body);s.run(['gh','issue','edit','44','--body-file',str(p)],check=True)
s.run(['git','update-ref','refs/heads/agent/stock-pr247-before-246-squash',old],cwd=root,check=True)
new=s.check_output(['git','commit-tree',tree,'-p',base],cwd=root,input='Prove Stock CFG preparation and retained successor records\n\nReplay the existing #247 proof-only delta onto the squash merge of #246.\n',text=True).strip()
assert g('diff','--name-only',base,new)==g('diff','--name-only','a071e715d1feea0266c86c3b46d5cb96db885c91',old)
for path in g('diff','--name-only',base,new).splitlines():assert g('rev-parse',new+':'+path)==g('rev-parse',old+':'+path),path
s.run(['git','push','origin',new+':refs/heads/'+branch,'--force-with-lease=refs/heads/'+branch+':'+old],cwd=root,check=True)
s.run(['gh','pr','edit','247','--base','main'],check=True)
cfg={'utc':now(),'head':new,'base':base,'tree':tree,'branch':branch,'old_head':old,'original_delta_path_set_and_bytes_preserved':True,'remote_head_verified':g('ls-remote','origin','refs/heads/'+branch).split()[0]==new}
P('/tmp/stock-pr247-after-squash.json').write_text(json.dumps(cfg,indent=2)+'\n')
a=view/'DeliveryAudit.lean';assert hashlib.sha256(a.read_bytes()).hexdigest()==json.loads(P('/tmp/stock-pr246-mcp-bundle.json').read_text())['source_sha256'];P('/tmp/stock-pr246-DeliveryAudit.lean').write_bytes(a.read_bytes());a.unlink()
body+='\n'+now()+' #247 replay pushed at '+new+' on actual #246 squash '+base+'; existing 83 Lean proof modules plus note are byte-identical to prior delta. Full exact-head validation starting with continuously exclusive shared cache.\n';p.write_text(body);s.run(['gh','issue','edit','44','--body-file',str(p)],check=True)
print(json.dumps(cfg))
