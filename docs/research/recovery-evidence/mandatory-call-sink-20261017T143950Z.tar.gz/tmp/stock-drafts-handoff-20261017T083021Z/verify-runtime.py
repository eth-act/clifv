from pathlib import Path
import subprocess as s,os,json,hashlib,datetime
import sys
bundle=Path(__file__).resolve().parent
v=Path(sys.argv[1]).resolve();expected=sys.argv[2]
assert s.check_output(['git','rev-parse','HEAD'],cwd=v,text=True).strip()==expected
assert not s.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=v,text=True).strip()
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:8])
base=Path(sys.argv[3]).resolve();base.mkdir(exist_ok=True)
env=dict(os.environ,PATH=os.environ['PATH'],OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',FV_MEMCAP=os.environ.get('FV_MEMCAP','12G'))
cap=str(v/'scripts/memcap.sh');oracle=str(v/'rust/target/release/lean-regalloc');assert Path(oracle).exists();assert Path('/usr/bin/false').exists()
def run(key,args,extra=None):
 log=base/(key+'.log');e=dict(env,LEAN_REGALLOC=oracle);e.update(extra or {})
 with log.open('w') as f:r=s.run([cap,*args],cwd=v,env=e,stdout=f,stderr=s.STDOUT)
 assert r.returncode==0,(key,r.returncode,str(log))
 return {'rc':0,'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
build=run('build-experimental-tools',['lake','build','lean-stock-lowering-test','lean-stock-lowering-compare'])
smoke={}
for mode in ['oracle','forced-fallback']:
 out=base/('smoke-'+mode);keep=base/('smoke-'+mode+'-allocator-input.json');r=run('smoke-'+mode,[str(v/'.lake/build/bin/lean-stock-lowering-test'),str(bundle/'smoke.clif'),str(out)],{'LEAN_REGALLOC':oracle if mode=='oracle' else '/usr/bin/false','LEAN_REGALLOC_KEEP':str(keep)})
 bins=list(out.glob('*.bin'));assert len(bins)==2 and all(p.stat().st_size>0 for p in bins)
 assert len(json.loads(keep.read_text())['functions'])==2;r.update(allocator_input=str(keep),artifacts={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.is_file()});smoke[mode]=r
cases=json.loads((bundle/'cases/manifest.json').read_text())['cases'];unconfigured={};configured={}
for case in cases:case['directory']=str(bundle/'cases'/case['key'])
# Four original function shapes: differing vectors, duplicate edges/arguments,
# loop, recursive call. Check actual indexed oracle/checker and forced fallback.
for case in [c for c in cases if c['original_identity']['variant']==0]:
 for mode in ['oracle','forced-fallback']:
  key='original-'+case['key']+'-'+mode;out=base/key;r=run(key,[str(v/'.lake/build/bin/lean-stock-lowering-test'),str(Path(case['directory'])/'input.clif'),str(out)],{'LEAN_REGALLOC':oracle if mode=='oracle' else '/usr/bin/false'})
  bins=list(out.glob('*.bin'));assert len(bins)==1 and bins[0].stat().st_size>0;r.update(identity=case['original_identity'],artifacts={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.is_file()});unconfigured[key]=r
# All eight issue78 occurrences, retaining exact original requested settings.
# The five formerly compiled identities must emit. The three preexisting PIC
# rejections may remain exactly the same or improve to successful compilation.
for case in cases:
 key='configured-'+case['key'];dest=base/key;dest.mkdir(exist_ok=True);source=Path(case['directory']);receipt=dest/'configuration-receipt.json';dump=dest/'dump'
 r=run(key,[str(v/'.lake/build/bin/lean-stock-lowering-compare'),str(source/'input.clif'),str(dest/'program.o'),'--stock-config',str(source/'stock-config.json'),'--config-receipt',str(receipt),'--dump',str(dump),'--traps',str(dest/'traps.json')])
 result=json.loads(receipt.read_text());assert result['configuration_accepted'] and result['error'] is None,result
 name=case['original_identity']['name'].lstrip('%');bins=list(dump.glob('*.bin'));old=json.loads((source/'baseline-configuration-receipt.json').read_text()).get('function_rejections',{}).get(name);new=result['function_rejections'].get(name)
 if bins:
  assert len(bins)==1 and bins[0].stat().st_size>0 and new is None
  outcome='emitted';r['native_bytes_identical']=bins[0].read_bytes()==(source/'stock.bin').read_bytes()
 else:
  assert old is not None and new==old,(key,old,new,Path(r['log']).read_text())
  outcome='original_configuration_rejection_preserved'
 r.update(identity=case['original_identity'],outcome=outcome,configuration_rejection=new,artifacts={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in dest.rglob('*') if p.is_file()});configured[key]=r
assert sum(c['outcome']=='emitted' for c in configured.values())>=5
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commit':expected,'build':build,'smoke':smoke,'original_four_shapes_oracle_and_forced_fallback':unconfigured,'original_eight_exact_configured_identities':configured,'actual_runtime':'Stock.lower -> prepareCheckedAt -> indexed oracle/checker or forced checked spill -> lowerAllocAt -> emitFunc/layout','scope':'Actual pipeline compilation/checker/fallback acceptance and original configuration behavior; not a source/machine execution or whole-driver theorem. Byte comparisons are raw, with no normalization.','success':True}
(base/'receipt.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS actual indexed oracle/fallback compilation, original4 shapes in both modes, all8 original configured identities; >=5 emitted, any remaining rejection exactly preserved')
