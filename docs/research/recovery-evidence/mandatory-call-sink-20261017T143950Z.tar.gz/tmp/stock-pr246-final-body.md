A Stock conditional branch can pass different parameter vectors to each successor. The experimental Stock harness previously rejected these branches. This change preserves each vector through preparation, critical-edge splitting, indexed allocation checking, checked spill fallback and lowering, with forward realization and preparation-totality proofs and complete split/loop/outer/allocation/control witnesses.

Existing compiler/theorem variants and production defaults are preserved. This is a substantive delivery batch toward #78 and #140; whole-Stock simulation/completeness and production cutover remain open. #247 follows with original-source CFG correspondence and preparation totality.

Validation on exact commit `a071e715` with main `9a3e5f8c` incorporated:

- All 2,020 module checks, full FV/FVTest and compiler/checker/linker/decoder tool build and crate build passed.
- Runtime: corpus114/114, extra22/22, runtests4672 passes/0 failures/0 runnable errors; the same seven non-runnable cases; zero native disagreements.
- Encoder:1308 functions identical,0 different.
- Both E2E modes:1150 accepted/0 rejected; both original complete identity/stage reports are byte-identical.
- 211 public roots and125 documented compiler roots audited; one336-root MCP bundle uses only the standard three axioms, no warnings. All1640 changed-module constants, including private/generated/runtime definitions, were audited in isolated environments where necessary; old audited axiom sets are unchanged.
- Actual per-successor runtime: differing vectors/critical edges; four original #78 shapes through both real oracle and forced checked-spill fallback. All eight original configured identities checked: five formerly compiled cases emit; three existing recursive PIC-setting rejections remain exactly unchanged. These were already differing-byte cases; no native-byte-equivalence claim.
- GitHub comparison preserves671 exact outputs,+0/-0. CI is a partial comparison, not production-cutover evidence.

Evidence and recovery/status links: #44. Scope note: `docs/research/stock-per-successor-delivery.md`. Original selected delta bytes were retained through both upstream reconciliations.
