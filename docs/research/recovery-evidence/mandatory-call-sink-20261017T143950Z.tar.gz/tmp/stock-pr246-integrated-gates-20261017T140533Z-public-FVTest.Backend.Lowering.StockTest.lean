import Lean
import FVTest.Backend.Lowering.StockTest
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let targets : Array String := #[ "FVTest.Backend.Lowering.StockTest" ]
  let mut count : Nat := 0
  for (name, info) in env.constants.toList do
    if !info.isTheorem || name.toString.startsWith "_private." || name.isInternal then continue
    let some index := env.getModuleIdxFor? name | continue
    let mod := env.header.moduleNames[index]!
    if !targets.contains mod.toString then continue
    let axioms ← collectAxioms name
    logInfo m!"DELIVERY_AXIOMS {name} {Json.compress (toJson (axioms.map Name.toString))}"
    count := count + 1
  logInfo m!"DELIVERY_AXIOM_COUNT {count}"
