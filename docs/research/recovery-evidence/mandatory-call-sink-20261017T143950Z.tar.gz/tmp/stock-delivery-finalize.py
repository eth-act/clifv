from pathlib import Path
import json,hashlib,subprocess as s,datetime,os,signal,tarfile,io,shutil
P=Path;canon=P('/home/lee/clifv/.worktrees/driver-proof-resume');view=P('/home/lee/clifv/.worktrees/stock-delivery-gates');now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');dest=P('/home/lee/.clifv-recovery')/(stamp+'-drafts-landed');dest.mkdir()
for pr in [246,247]:
 d=json.loads(P(f'/tmp/stock-pr{pr}-landed.json').read_text());assert d['landed_tree_equals_validated_tree']
a=view/'DeliveryAudit.lean';cfg=json.loads(P('/tmp/stock-pr247-mcp-bundle.json').read_text());assert hashlib.sha256(a.read_bytes()).hexdigest()==cfg['source_sha256'];P('/tmp/stock-pr247-DeliveryAudit.lean').write_bytes(a.read_bytes());(dest/'pr247-DeliveryAudit.lean').write_bytes(a.read_bytes());shutil.copy2('/tmp/stock-pr246-DeliveryAudit.lean',dest/'pr246-DeliveryAudit.lean')
assert not s.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=view,text=True).strip();u=s.check_output(['git','ls-files','--others','--exclude-standard'],cwd=view,text=True).splitlines();assert set(u)=={'DeliveryAudit.lean','rust/target'},u
a.unlink();links={}
for rel in ['rust/target','.lake/build','crate-proofs/.lake/build','third_party/wasmtime','third_party/lnsym-upstream']:
 p=view/rel;assert p.is_symlink(),p;links[rel]=str(p.resolve());p.unlink()
assert P(links['.lake/build']).is_dir() and P(links['rust/target']).is_dir();s.run(['git','worktree','remove',str(view)],cwd='/home/lee/clifv',check=True);assert not view.exists()
pid=1233457;proc=P('/proc')/str(pid);retired=False
if proc.exists():
 state=(proc/'stat').read_text().split(') ',1)[1].split()[0];cmd=(proc/'cmdline').read_bytes().replace(b'\0',b' ').decode();assert state in ['T','t'] and cmd.strip()=='python3 /tmp/stock-coherent-serial-build.py',(state,cmd)
 children=s.run(['pgrep','-P',str(pid)],text=True,capture_output=True).stdout.split()
 for child in children:assert (P('/proc')/child/'stat').read_text().split(') ',1)[1].split()[0]=='Z',child
 (dest/'retired-controller.json').write_text(json.dumps({'pid':pid,'state':state,'cmdline':cmd,'children_zombies_only':children,'reason':'Both requested drafts landed; do not resume stale-source queue or continue original proof plan before user review.'},indent=2)+'\n');os.kill(pid,signal.SIGKILL);retired=True
lease=json.loads(P('/tmp/stock-delivery-cache-lease.json').read_text());assert lease['pr']==247 and lease['worker_finished'];lease.update(state='completed_and_released_after_merges',finished_utc=now(),canonical_controller_retired=retired,validation_view_removed=True,policy='One physical warm cache retained. No background proof-plan continuation. Revalidate source graph before next build.');P('/tmp/stock-delivery-cache-lease.json').write_text(json.dumps(lease,indent=2)+'\n')
free=shutil.disk_usage(canon).free;r={'utc':now(),'both_drafts_squash_merged':True,'removed_clean_worktree':str(view),'shared_cache_targets_preserved':links,'one_canonical_warm_cache_retained':True,'stale_idle_queue_retired_without_resuming':retired,'dirty_worktrees_and_unpublished_sources_preserved':True,'obsolete_input_snapshot_cleanup':'docs/research/stock-delivery-obsolete-inputs-cleanup.json','free_GiB':round(free/2**30,1),'no_proof_plan_continuation':True};P('/tmp/stock-delivery-final-cleanup.json').write_text(json.dumps(r,indent=2)+'\n');(canon/'docs/research/stock-delivery-final-cleanup.json').write_text(json.dumps(r,indent=2)+'\n')
files=set();suffixes={'.json','.py','.log','.time','.lean','.md','.clif','.bin','.txt','.tsv'}
for pattern in ['stock-pr246*','stock-pr247*','stock-delivery*','stock-drafts*','stock-coherent*']:
 for p in P('/tmp').glob(pattern):
  if p.is_file() and p.suffix in suffixes:files.add(p)
  elif p.is_dir():files.update(q for q in p.rglob('*') if q.is_file() and q.suffix in suffixes)
files.update(p for p in dest.iterdir() if p.is_file());captured={str(p):p.read_bytes() for p in sorted(files)};archive=dest/'checkpoint.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=1) as t:
 for name,data in captured.items():
  ent=tarfile.TarInfo(name.lstrip('/'));ent.size=len(data);t.addfile(ent,io.BytesIO(data))
with tarfile.open(archive) as t:
 for name,data in captured.items():assert t.extractfile(name.lstrip('/')).read()==data,name
assert archive.stat().st_size<95_000_000,archive.stat().st_size
m={'utc':now(),'archive':str(archive),'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'member_count':len(captured),'member_sha256':{n:hashlib.sha256(d).hexdigest() for n,d in captured.items()},'every_archived_byte_verified':True,'both_landings_verified':True};(dest/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
P('/tmp/stock-delivery-final-evidence.json').write_text(json.dumps(m,indent=2)+'\n');(canon/'docs/research/stock-drafts-final-evidence.json').write_text(json.dumps(m,indent=2)+'\n')
env=dict(os.environ,STOCK_RECOVERY_EVIDENCE=str(archive));s.run(['python3','/tmp/stock-mandatory-backup.py'],env=env,check=True);b=json.loads(P('/tmp/stock-backup-captured-result.json').read_text());small={k:v for k,v in b.items() if k!='captured'};small['checkpoint']={k:v for k,v in m.items() if k!='member_sha256'};(canon/'docs/research/stock-drafts-validation-backup.json').write_text(json.dumps(small,indent=2)+'\n');print(json.dumps({'cleanup':r,'backup':small}))
