from pathlib import Path
import os,sys,json,datetime,hashlib,re,subprocess as sp,time,signal,traceback
canon=Path('/home/lee/clifv/.worktrees/driver-proof-resume');view=Path('/home/lee/clifv/.worktrees/stock-delivery-gates');expected='e5a9cd6ce7a339ffab9fc6b0a26d574296d3f8de';pr=247
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');prefix=Path('/tmp/stock-pr247-gates-'+stamp);progress=Path('/tmp/stock-pr247-gates-progress.json');leasePath=Path('/tmp/stock-delivery-cache-lease.json');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();controller=1233457
logs={};lease={};held=False;finished=False

def proc(pid):
 try:
  fields=Path('/proc',str(pid),'stat').read_text().split(') ',1)[1].split()
  return {'state':fields[0],'exit_code':int(fields[49]),'cmdline':Path('/proc',str(pid),'cmdline').read_bytes().replace(b'\0',b' ').decode()}
 except FileNotFoundError:return None

def frozen():
 f=json.loads(Path('/tmp/stock-coherent-build-inputs.json').read_text())
 assert {str(p.relative_to(canon)):sha(p) for d in ['FV','FVTest'] for p in (canon/d).rglob('*.lean')}==f['source_sha256']
 for p,h in f['validation_script_sha256'].items():assert sha(canon/p)==h,p

def report(state,**kw):
 d={'utc':now(),'state':state,'pid':os.getpid(),'pr':pr,'view':str(view),'commit':expected,'canonical_controller':controller,'cache_lease':str(leasePath),'completed_phases':logs,**kw};progress.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items() if k!='completed_phases'}),flush=True)

def release(reason):
 global held
 if held:
  frozen();p=proc(controller)
  if p:
   assert 'python3 /tmp/stock-coherent-serial-build.py' in p['cmdline'],p
   os.kill(controller,signal.SIGCONT)
  lease.update(state='released',released_utc=now(),reason=reason,canonical_handle_present=bool(p));leasePath.write_text(json.dumps(lease,indent=2)+'\n');held=False

if '--release' in sys.argv:
 lease=json.loads(leasePath.read_text());assert lease['pr']==pr and lease['state'] in ['waiting_current_kernel','running_exact_PR_gates','held_for_review'];held=True;release('Explicit release after review/gate scheduling');print('Same canonical controller resumed');sys.exit(0)

env=dict(os.environ,PATH='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:/home/lee/.cargo/bin:'+os.environ['PATH'],OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',FV_MEMCAP='22G',CLIF_NATIVE_QEMU='/home/lee/.local/share/clifv-test-tools/usr/bin/qemu-aarch64-static',LLVM_MC='/home/lee/.local/share/clifv-test-tools/usr/bin/llvm-mc')
lake='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin/lake';cap=str(canon/'scripts/memcap.sh')

def clean_view():
 assert sp.check_output(['git','rev-parse','HEAD'],cwd=view,text=True).strip()==expected
 assert not sp.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=view,text=True).strip()
 if 'manifest' in globals():
  assert {str(p.relative_to(view)):sha(p) for d in ['FV','FVTest'] for p in (view/d).rglob('*.lean')}==manifest['sources']
  for p,h in manifest['scripts'].items():assert sha(view/p)==h,p

def check(kind,command,cwd=view,capSize='22G'):
 clean_view();frozen();log=Path(str(prefix)+'-'+kind+'.log');report('running',phase=kind,log=str(log),memory_cap=capSize)
 stageEnv=dict(env,FV_MEMCAP=capSize)
 with log.open('w') as out:p=sp.run([cap,*command],cwd=cwd,env=stageEnv,stdout=out,stderr=sp.STDOUT)
 assert p.returncode==0,f'{kind} rc={p.returncode} log={log}'
 logs[kind]={'path':str(log),'sha256':sha(log)};clean_view();return log

try:
 frozen();clean_view();assert sp.check_output(['nproc'],env=env,text=True).strip()=='2'
 for p in ['lean-toolchain','lake-manifest.json']:
  assert (view/p).read_bytes()==(canon/p).read_bytes(),p
 old=proc(controller);assert old and old['state'] in ['T','t'] and 'python3 /tmp/stock-coherent-serial-build.py' in old['cmdline'],old
 previous=json.loads(leasePath.read_text());assert previous['state']=='held_for_review' and previous['pr']==246 and previous['worker_finished']
 oldWorker=proc(previous['worker_pid']);assert not oldWorker or oldWorker['state']=='Z'
 first=json.loads(Path('/tmp/stock-pr246-gates-receipt.json').read_text());assert first['success'] and not first['trust_review_required']
 completion=json.loads(Path('/tmp/stock-pr246-completion-audit.json').read_text());assert completion['success_pending_MCP_provenance_review']
 mcp=json.loads((canon/'docs/research/stock-pr246-mcp-audit.json').read_text());assert mcp['success'] and mcp['expected_and_actual_union_axioms_match']
 firstPR=json.loads(sp.check_output(['gh','pr','view','246','--json','state,mergeCommit'],text=True,cwd=view));assert firstPR['state']=='MERGED'
 held=True
 for _ in range(100):
  if proc(controller)['state'] in ['T','t']:break
  time.sleep(.01)
 assert proc(controller)['state'] in ['T','t']
 main=json.loads(Path('/tmp/stock-coherent-serial-progress.json').read_text());children=[int(x) for x in Path('/proc',str(controller),'task',str(controller),'children').read_text().split()]
 lease={'utc':now(),'state':'waiting_current_kernel','owner':'codygunton / #44 / root','worker_pid':os.getpid(),'pr':pr,'view':str(view),'commit':expected,'canonical_controller':controller,'canonical_previous_progress':main,'current_children':children,'policy':'Current kernel finishes; same controller held only to serialize exact-PR access to one shared cache. Source/script freeze unchanged. No kernel restart/cache copy/new warm cache.','release_command':'python3 /tmp/stock-pr247-gates.py --release','previous_PR246_lease':previous};leasePath.write_text(json.dumps(lease,indent=2)+'\n')
 report('waiting_current_kernel',children=children,module=main.get('current'),canonical_queue_state='intentionally held; current kernel continues')
 while True:
  states={c:proc(c) for c in children}
  if all(p is None or p['state']=='Z' for p in states.values()):break
  assert proc(controller) and proc(controller)['state'] in ['T','t']
  time.sleep(5)
 for c,p in states.items():
  if p:assert p['exit_code']==0,(c,p)
 if children:assert 'Build completed successfully' in Path(main['log']).read_text(),main['log']
 frozen();lease.update(state='running_exact_PR_gates',cache_quiescent_utc=now(),terminal_original_children=states);leasePath.write_text(json.dumps(lease,indent=2)+'\n')
 for relative in ['.lake/build','crate-proofs/.lake/build','rust/target']:
  p=view/relative;target=canon/relative;assert target.is_dir(),target;p.parent.mkdir(parents=True,exist_ok=True)
  if p.is_symlink():assert p.resolve()==target.resolve()
  else:assert not p.exists(),p;p.symlink_to(target,target_is_directory=True)
 manifest={'utc':now(),'pr':pr,'commit':expected,'tree':sp.check_output(['git','rev-parse','HEAD^{tree}'],cwd=view,text=True).strip(),'sources':{str(p.relative_to(view)):sha(p) for d in ['FV','FVTest'] for p in (view/d).rglob('*.lean')},'scripts':{str(p.relative_to(view)):sha(p) for p in (view/'scripts').rglob('*') if p.is_file()},'cache':'single canonical cache, exclusive lease; NO copy','lake_source_hashing':'Lake Module.recFetchInput reads and hashes actual source contents, verified in installed4.34.1; final full build uses --rehash'}
 Path('/tmp/stock-pr247-gates-inputs.json').write_text(json.dumps(manifest,indent=2)+'\n')
 modules={p[:-5].replace('/','.') : view/p for p in manifest['sources']};imports={m:[d for line in re.findall(r'^(?:(?:public|private)\s+)?import\s+([^\n]+)',p.read_text(),re.M) for d in line.split() if d in modules] for m,p in modules.items()};seen=set();order=[]
 def visit(m):
  if m in seen:return
  seen.add(m)
  for d in imports[m]:visit(d)
  order.append(m)
 for m in sorted(modules):visit(m)
 # Reuse completed canonical targets only if their complete source import
 # closure is byte-identical in this exact PR tree. Full --rehash gate follows.
 f=json.loads(Path('/tmp/stock-coherent-build-inputs.json').read_text());done=set();canonicalOrder=[]
 def canonical_visit(m):
  if m in done:return
  done.add(m)
  for d in f['imports'][m]:
   if d in f['affected']:canonical_visit(d)
  canonicalOrder.append(m)
 for m in sorted(f['affected']):canonical_visit(m)
 completed=set(canonicalOrder[:main['completed_modules']]);
 if children and Path(main['log']).exists() and 'Build completed successfully' in Path(main['log']).read_text():completed.add(main['current'])
 mismatch={m for m,p in modules.items() if not (canon/p.relative_to(view)).exists() or sha(p)!=sha(canon/p.relative_to(view))};incompatible=set(mismatch)
 for m in order:
  if any(d in incompatible for d in imports[m]):incompatible.add(m)
 # Exact PR246 gates finished under this SAME continuously held cache lease.
 # Rebuild only the PR247 source/import changes and missing artifacts; final
 # --rehash FV/FVTest/tools independently checks every cached dependency.
 p1=json.loads(Path('/tmp/stock-pr246-gates-inputs.json').read_text())
 changedFromP1={m for m,p in modules.items() if p1['sources'].get(str(p.relative_to(view)))!=sha(p)}
 refresh=set(changedFromP1)
 for m in order:
  if any(d in refresh for d in imports[m]):refresh.add(m)
 affected=refresh|{m for m in modules if not (canon/'.lake/build/lib/lean'/Path(m.replace('.','/')+'.olean')).exists()}
 needed=[m for m in order if m in affected]
 Path('/tmp/stock-pr247-gates-build-plan.json').write_text(json.dumps({'total_source_modules':len(modules),'canonical_completed_reused':sorted(completed&set(modules)-incompatible),'mismatched_sources':sorted(mismatch),'incompatible_closure':sorted(incompatible),'serial_targets':needed,'source_manifest':'/tmp/stock-pr247-gates-inputs.json'},indent=2)+'\n')
 for i,m in enumerate(needed):
  size='32G' if m=='FV.Backend.Proof.StockCmpWithFlags' else '22G'
  log=Path(str(prefix)+'-module-'+m+'.log');report('serial_build',index=i+1,total=len(needed),module=m,log=str(log),memory_cap=size)
  with log.open('w') as out:p=sp.run([cap,lake,'build',m],cwd=view,env=dict(env,FV_MEMCAP=size),stdout=out,stderr=sp.STDOUT)
  assert p.returncode==0 and 'Build completed successfully' in log.read_text(),f'{m} rc={p.returncode} log={log}'
  logs['module:'+m]={'path':str(log),'sha256':sha(log)}
 clean_view();frozen()
 full=check('full',[lake,'--rehash','build','FV','FVTest','lean-backend','lean-e2e-check','link-check','lean-link','clif-decode'])
 assert 'Build completed successfully' in full.read_text()
 crates=check('crates',[lake,'build'],view/'crate-proofs');assert 'Build completed successfully' in crates.read_text()
 core=json.loads(Path('/tmp/stock-delivery-pr247-paths.json').read_text());targetmods=[p[:-5].replace('/','.') for p in core['paths'] if p.endswith('.lean')]
 compiler=[]
 for n,m in re.findall(r'^\| `([^`]+)` \| `(FV\.[^`]+)` \| standard \|', (view/'docs/research/axiom-audit.md').read_text(),re.M):compiler.append((n,m))
 assert len(compiler)>=100,len(compiler)
 audit=Path(str(prefix)+'-axioms.lean');smoke=Path('/tmp/stock-delivery-audit-smoke.lean').read_text();body=smoke[smoke.index('open Lean'):].replace('#["FV.Clif.Syntax"]','#[ '+','.join(json.dumps(m) for m in targetmods)+' ]')
 audit.write_text('import Lean\n'+'\n'.join('import '+m for m in sorted(set(targetmods+[m for n,m in compiler])))+'\n'+body+'\n'+'\n'.join('#print axioms '+n for n,m in compiler)+'\n')
 auditlog=check('axioms',[lake,'env','lean','--root=/tmp',str(audit)])
 txt=auditlog.read_text();assert not re.search(r'error[:(]',txt);roots={n:sorted(json.loads(v)) for n,v in re.findall(r'DELIVERY_AXIOMS (\S+) (\[[^\n]*\])',txt)};std={'propext','Classical.choice','Quot.sound'}
 compiled={m.group(1):sorted(x.strip() for x in m.group(2).split(',') if x.strip()) for m in re.finditer(r"'([^']+)' depends on axioms:\s*\[([^]]*)\]",txt)};compiled.update({n:[] for n in re.findall(r"'([^']+)' does not depend on any axioms",txt)})
 assert set(n for n,m in compiler)<=set(compiled);assert all(set(compiled[n])<=std for n,m in compiler)
 assert roots;unknown_native={n:a for n,a in roots.items() if set(a)-std};assert not any('sorryAx' in a for a in roots.values())
 runtime=check('runtime',['bash','scripts/lean-backend-filetests.sh']);rt=runtime.read_text();match=re.search(r'runs: lean pass (\d+) fail (\d+) error (\d+).*not-runnable (\d+) file-error (\d+)',rt);assert match,rt[-1000:];counts=[int(x) for x in match.groups()];assert counts[0]>=4672 and counts[1:]==[0,0,7,0],counts
 encoder=check('encoder',['bash','scripts/lean-backend-encode-check.sh']);enc=re.search(r'functions (\d+): identical (\d+), differ (\d+)',encoder.read_text());assert enc and int(enc[1])>=1292 and enc[1]==enc[2] and enc[3]=='0'
 identities={}
 for label,flags,baseline in [('e2e',[],'/tmp/stock-body-form-full-identities.json'),('legacy-e2e',['--no-dead-cleanup'],'/tmp/stock-body-form-full-legacy-identities.json')]:
  reportPath=Path(str(prefix)+'-'+label+'-identities.json');log=check(label,[lake,'exe','lean-e2e-check',*flags,'--identity-report',str(reportPath)])
  old=json.loads(Path(baseline).read_text());new=json.loads(reportPath.read_text());key=lambda r:(r['file'],r['index'],r['function']);oldmap={key(r):r['stages'] for r in old['functions']};newmap={key(r):r['stages'] for r in new['functions']};assert len(oldmap)==1150
  losses={str(k):{'before':v,'after':newmap.get(k)} for k,v in oldmap.items() if newmap.get(k)!=v};assert not losses,losses
  assert new['dead_cleanup']==old['dead_cleanup'] and new['schema']==old['schema'];assert 'rejected 0' in log.read_text() or re.search(r'0 rejected',log.read_text()),log.read_text()[-1200:]
  identities[label]={'path':str(reportPath),'sha256':sha(reportPath),'baseline':baseline,'baseline_sha256':sha(baseline),'all1150_original_identity_stage_lists_preserved':True,'current_accepted_identities':len(newmap),'byte_identical':reportPath.read_bytes()==Path(baseline).read_bytes()}
 clean_view();frozen();result={'utc':now(),'pr':pr,'commit':expected,'success':not unknown_native,'trust_review_required':unknown_native,'source_manifest':'/tmp/stock-pr247-gates-inputs.json','serial_plan':'/tmp/stock-pr247-gates-build-plan.json','normal_audit':{'public_root_count':len(roots),'public_roots':roots,'compiler_roots':compiled,'documented_standard_compiler_roots':len(compiler),'log':str(auditlog)},'full_build':str(full),'crates':str(crates),'runtime_counts':counts,'encoder_counts':[int(enc[1]),int(enc[2]),int(enc[3])],'identities':identities,'logs':logs,'canonical_source_script_freeze_preserved':True,'new_warm_cache':False,'view_tracked_clean':True,'MCP':'Historical unchanged-source receipts need review; no new MCP invoked by worker','full_goal':'ORIGINAL#140 active/incomplete; production legacy'}
 receipt=Path('/tmp/stock-pr247-gates-receipt.json');receipt.write_text(json.dumps(result,indent=2)+'\n');lease.update(state='held_for_review',gates_terminal_utc=now(),receipt=str(receipt),worker_finished=True);leasePath.write_text(json.dumps(lease,indent=2)+'\n');finished=True;report('trust_review' if unknown_native else 'review_ready',receipt=str(receipt),canonical_queue_state='held for exact-PR review; release command in lease')
except BaseException as e:
 report('failed',error=repr(e),traceback=traceback.format_exc());raise
finally:
 if held and not finished:release('Gate worker failed/stopped; preserve completed cache work and resume original controller')
