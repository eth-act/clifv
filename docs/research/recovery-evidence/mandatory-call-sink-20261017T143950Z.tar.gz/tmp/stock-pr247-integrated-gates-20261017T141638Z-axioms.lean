import Lean
import FV.Backend.Proof.Encode
import FV.Backend.Proof.FilteredGraphIncoming
import FV.Backend.Proof.FormsCoverComplete
import FV.Backend.Proof.IndexedPredMultiplicity
import FV.Backend.Proof.LowerComplete
import FV.Backend.Proof.LowerLoop
import FV.Backend.Proof.PerEdgeArgumentShape
import FV.Backend.Proof.PerEdgeParameterShape
import FV.Backend.Proof.PerEdgePrepSplitWitness
import FV.Backend.Proof.PerEdgePrepareJump
import FV.Backend.Proof.PerEdgePrepareNoSplit
import FV.Backend.Proof.PerEdgePrepareUnsplitGraph
import FV.Backend.Proof.PerEdgePreparedArity
import FV.Backend.Proof.PerEdgeRouteArity
import FV.Backend.Proof.PerEdgeSpillBlock
import FV.Backend.Proof.PerEdgeSpillCopy
import FV.Backend.Proof.PerEdgeSpillCycleFixture
import FV.Backend.Proof.PerEdgeSpillEdge
import FV.Backend.Proof.PerEdgeSpillEntry
import FV.Backend.Proof.PerEdgeSpillEntryFixture
import FV.Backend.Proof.PerEdgeSpillEntryGood
import FV.Backend.Proof.PerEdgeSpillEntrySaves
import FV.Backend.Proof.PerEdgeSpillEntrySymbols
import FV.Backend.Proof.PerEdgeSpillEntryWitness
import FV.Backend.Proof.PerEdgeSpillHomes
import FV.Backend.Proof.PerEdgeSpillInst
import FV.Backend.Proof.PerEdgeSpillInstFixture
import FV.Backend.Proof.PerEdgeSpillInstWitness
import FV.Backend.Proof.PerEdgeSpillJumpWitness
import FV.Backend.Proof.PerEdgeSpillPreState
import FV.Backend.Proof.PerEdgeSpillRoutes
import FV.Backend.Proof.PerEdgeSpillSharedFixture
import FV.Backend.Proof.PerEdgeSpillSharedJump
import FV.Backend.Proof.PerEdgeSpillStateAt
import FV.Backend.Proof.PerEdgeSpillTerminalBlock
import FV.Backend.Proof.PerEdgeSpillWitness
import FV.Backend.Proof.PrepareComplete
import FV.Backend.Proof.PrepareDirect
import FV.Backend.Proof.PrepareReachability
import FV.Backend.Proof.PreparedArityWitness
import FV.Backend.Proof.ReorderedGraphIncoming
import FV.Backend.Proof.StockBranchArgumentShape
import FV.Backend.Proof.StockBranchCfg
import FV.Backend.Proof.StockBranchHelperProjection
import FV.Backend.Proof.StockBranchHelperTargets
import FV.Backend.Proof.StockBranchRootTargets
import FV.Backend.Proof.StockBranchSelection
import FV.Backend.Proof.StockBranchTargetsWitness
import FV.Backend.Proof.StockCfgTotal
import FV.Backend.Proof.StockCfgTotalWitness
import FV.Backend.Proof.StockConditionalRootTargets
import FV.Backend.Proof.StockConditionalTargets
import FV.Backend.Proof.StockConditionalTargetsWitness
import FV.Backend.Proof.StockControlCfgWitness
import FV.Backend.Proof.StockControlShape
import FV.Backend.Proof.StockCriticalEdgeArity
import FV.Backend.Proof.StockEdgeArity
import FV.Backend.Proof.StockEdgeValuesWitness
import FV.Backend.Proof.StockEmittedGraph
import FV.Backend.Proof.StockEmittedGraphWitness
import FV.Backend.Proof.StockEntryCode
import FV.Backend.Proof.StockEntryGraph
import FV.Backend.Proof.StockEntryOrder
import FV.Backend.Proof.StockGraphBounds
import FV.Backend.Proof.StockGraphEdges
import FV.Backend.Proof.StockJumpEdgeValues
import FV.Backend.Proof.StockNamedBranchTargets
import FV.Backend.Proof.StockNodeCoverage
import FV.Backend.Proof.StockNodeCoverageWitness
import FV.Backend.Proof.StockOrderGraphWitness
import FV.Backend.Proof.StockOrdinaryCfg
import FV.Backend.Proof.StockOutgoingShape
import FV.Backend.Proof.StockParameterShape
import FV.Backend.Proof.StockPerEdgeDirectWitness
import FV.Backend.Proof.StockPerEdgeM6DivergenceWitness
import FV.Backend.Proof.StockPerEdgeM6StuckWitness
import FV.Backend.Proof.StockPrepareTotal
import FV.Backend.Proof.StockPreparedArity
import FV.Backend.Proof.StockReturnContract
import FV.Backend.Proof.StockReturnScanShape
import FV.Backend.Proof.StockReturnSourceWitness
import FV.Backend.Proof.StockReturnVCode
import FV.Backend.Proof.StockSourceCallWitness
import FV.Backend.Proof.StockSourceResults
import FV.Backend.Proof.StockSpillCopyMetadata
import FV.Backend.Proof.StockSpillCopyMetadataWitness
import FV.Backend.Proof.StockTerminalCfg
import FV.Backend.Proof.StockTerminalPlacement
import FV.Backend.Proof.StockTryCfg
import FV.E2E.AllocDirect
import FV.E2E.AllocTotal
import FV.E2E.BinaryGood
import FV.E2E.DeadCleanupExecBytes
import FV.E2E.DeadCleanupExecGoodReads
import FV.E2E.DeadCleanupExecGoodRun
import FV.E2E.DeadCleanupExecGot
import FV.E2E.DeadCleanupExecPeak
import FV.E2E.DeadCleanupExecProven
import FV.E2E.DeadCleanupExecRunN
import FV.E2E.DeadCleanupExecStatic
import FV.E2E.DeadCleanupFinal
import FV.E2E.DeadCleanupLegal
import FV.E2E.DeadCleanupLegalDirect
import FV.E2E.DeadCleanupOptProven
import FV.E2E.DeadCleanupSize
import FV.E2E.DeadCleanupStackBound
import FV.E2E.DeadCleanupTotal
import FV.E2E.EmitTotal
import FV.E2E.EmitTotalIn
import FV.E2E.ExecBytes
import FV.E2E.ExecGoodReads
import FV.E2E.ExecGoodRun
import FV.E2E.ExecGot
import FV.E2E.ExecProven
import FV.E2E.ExecRunN
import FV.E2E.ExecStatic
import FV.E2E.Final
import FV.E2E.FinalDirect
import FV.E2E.Legal
import FV.E2E.LegalDepth
import FV.E2E.LegalDirect
import FV.E2E.LegalProgram
import FV.E2E.LinkArm
import FV.E2E.LinkGood
import FV.E2E.NonVacuity
import FV.E2E.OptProven
import FV.E2E.RelaxTotal
import FV.E2E.SizeIn
import FV.E2E.SpillDefined
import FV.E2E.SpillKillFree
import FV.E2E.StackBound
import FV.Front.BundleProof
import FV.Front.Exe
import FV.Front.Raw
import FV.Front.RawExe
import FV.Front.RawProof
import FV.Front.RenameRun
import FV.Link.Correct
import FV.Link.DeadCleanupCorrect
import FV.Link.DeadCleanupExe
import FV.Link.DeadCleanupExePeak
import FV.Link.DeadCleanupExeSource
import FV.Link.DeadCleanupExeTotal
import FV.Link.DeadCleanupLayoutProof
import FV.Link.Exe
import FV.Link.ExeInput
import FV.Link.ExeInputCleanup
import FV.Link.ExeInputReach
import FV.Link.ExeInputReachCleanup
import FV.Link.ExeSource
import FV.Link.ExeTotal
import FV.Link.LayoutProof
import FV.Link.NonVacuityDeadCleanupExeSource
import FV.Link.NonVacuityExeSource
import FV.Opt.Proof.LegalPre
import FV.Opt.Proof.RuleAll
import FV.Opt.Proof.SimpPass
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let targets : Array String := #[ "FV.Backend.Proof.FilteredGraphIncoming","FV.Backend.Proof.IndexedPredMultiplicity","FV.Backend.Proof.PerEdgeArgumentShape","FV.Backend.Proof.PerEdgeParameterShape","FV.Backend.Proof.PerEdgePrepSplitWitness","FV.Backend.Proof.PerEdgePrepareJump","FV.Backend.Proof.PerEdgePrepareNoSplit","FV.Backend.Proof.PerEdgePrepareUnsplitGraph","FV.Backend.Proof.PerEdgePreparedArity","FV.Backend.Proof.PerEdgeRouteArity","FV.Backend.Proof.PerEdgeSpillBlock","FV.Backend.Proof.PerEdgeSpillCopy","FV.Backend.Proof.PerEdgeSpillCycleFixture","FV.Backend.Proof.PerEdgeSpillEdge","FV.Backend.Proof.PerEdgeSpillEntry","FV.Backend.Proof.PerEdgeSpillEntryFixture","FV.Backend.Proof.PerEdgeSpillEntryGood","FV.Backend.Proof.PerEdgeSpillEntrySaves","FV.Backend.Proof.PerEdgeSpillEntrySymbols","FV.Backend.Proof.PerEdgeSpillEntryWitness","FV.Backend.Proof.PerEdgeSpillHomes","FV.Backend.Proof.PerEdgeSpillInst","FV.Backend.Proof.PerEdgeSpillInstFixture","FV.Backend.Proof.PerEdgeSpillInstWitness","FV.Backend.Proof.PerEdgeSpillJumpWitness","FV.Backend.Proof.PerEdgeSpillPreState","FV.Backend.Proof.PerEdgeSpillRoutes","FV.Backend.Proof.PerEdgeSpillSharedFixture","FV.Backend.Proof.PerEdgeSpillSharedJump","FV.Backend.Proof.PerEdgeSpillStateAt","FV.Backend.Proof.PerEdgeSpillTerminalBlock","FV.Backend.Proof.PerEdgeSpillWitness","FV.Backend.Proof.PrepareReachability","FV.Backend.Proof.PreparedArityWitness","FV.Backend.Proof.ReorderedGraphIncoming","FV.Backend.Proof.StockBranchArgumentShape","FV.Backend.Proof.StockBranchCfg","FV.Backend.Proof.StockBranchHelperProjection","FV.Backend.Proof.StockBranchHelperTargets","FV.Backend.Proof.StockBranchRootTargets","FV.Backend.Proof.StockBranchSelection","FV.Backend.Proof.StockBranchTargetsWitness","FV.Backend.Proof.StockCfgTotal","FV.Backend.Proof.StockCfgTotalWitness","FV.Backend.Proof.StockConditionalRootTargets","FV.Backend.Proof.StockConditionalTargets","FV.Backend.Proof.StockConditionalTargetsWitness","FV.Backend.Proof.StockControlCfgWitness","FV.Backend.Proof.StockControlShape","FV.Backend.Proof.StockCriticalEdgeArity","FV.Backend.Proof.StockEdgeArity","FV.Backend.Proof.StockEdgeValuesWitness","FV.Backend.Proof.StockEmittedGraph","FV.Backend.Proof.StockEmittedGraphWitness","FV.Backend.Proof.StockEntryCode","FV.Backend.Proof.StockEntryGraph","FV.Backend.Proof.StockEntryOrder","FV.Backend.Proof.StockGraphBounds","FV.Backend.Proof.StockGraphEdges","FV.Backend.Proof.StockJumpEdgeValues","FV.Backend.Proof.StockNamedBranchTargets","FV.Backend.Proof.StockNodeCoverage","FV.Backend.Proof.StockNodeCoverageWitness","FV.Backend.Proof.StockOrderGraphWitness","FV.Backend.Proof.StockOrdinaryCfg","FV.Backend.Proof.StockOutgoingShape","FV.Backend.Proof.StockParameterShape","FV.Backend.Proof.StockPerEdgeDirectWitness","FV.Backend.Proof.StockPerEdgeM6DivergenceWitness","FV.Backend.Proof.StockPerEdgeM6StuckWitness","FV.Backend.Proof.StockPrepareTotal","FV.Backend.Proof.StockPreparedArity","FV.Backend.Proof.StockReturnContract","FV.Backend.Proof.StockReturnScanShape","FV.Backend.Proof.StockReturnSourceWitness","FV.Backend.Proof.StockReturnVCode","FV.Backend.Proof.StockSourceCallWitness","FV.Backend.Proof.StockSourceResults","FV.Backend.Proof.StockSpillCopyMetadata","FV.Backend.Proof.StockSpillCopyMetadataWitness","FV.Backend.Proof.StockTerminalCfg","FV.Backend.Proof.StockTerminalPlacement","FV.Backend.Proof.StockTryCfg" ]
  let mut count : Nat := 0
  for (name, info) in env.constants.toList do
    if !info.isTheorem || name.toString.startsWith "_private." || name.isInternal then continue
    let some index := env.getModuleIdxFor? name | continue
    let mod := env.header.moduleNames[index]!
    if !targets.contains mod.toString then continue
    let axioms ← collectAxioms name
    logInfo m!"DELIVERY_AXIOMS {name} {Json.compress (toJson (axioms.map Name.toString))}"
    count := count + 1
  logInfo m!"DELIVERY_AXIOM_COUNT {count}"

#print axioms Front.buildSpec_spec
#print axioms Front.buildSpec_srcProg
#print axioms Front.data_complete
#print axioms Front.link_alpha
#print axioms Front.parseUnit_raw
#print axioms Front.bundle_correct_source
#print axioms Front.bundle_correct_source_baseline
#print axioms Front.bundle_correct_source_peak
#print axioms Front.bundle_correct_source_peak_baseline
#print axioms Front.decodeFn_spec
#print axioms Front.bundle_correct_raw
#print axioms Front.bundle_correct_raw_baseline
#print axioms Front.bundle_correct_raw_peak
#print axioms Front.bundle_correct_raw_peak_baseline
#print axioms Front.rawLink_eq_link
#print axioms Clif.runLoop_ren
#print axioms Link.binOk_leanLink
#print axioms Link.DeadCleanup.binOk_leanLink
#print axioms Link.DeadCleanup.compileExe_correct
#print axioms Link.DeadCleanup.compileExe_correct_peak
#print axioms Link.DeadCleanup.compileExe_correct_source
#print axioms Link.DeadCleanup.compileExe_correct_source_peak
#print axioms Link.DeadCleanup.compileExe_total
#print axioms Link.DeadCleanup.leanLink_linkerOk
#print axioms Link.compileExe_correct
#print axioms Link.compileExe_correct_depth
#print axioms Link.compileExe_correct_peak
#print axioms Link.compileExe_total_input
#print axioms Link.DeadCleanup.compileExe_total_input
#print axioms Link.compileExe_total_reach
#print axioms Link.relocOk_tab
#print axioms Link.DeadCleanup.compileExe_total_reach
#print axioms Link.DeadCleanup.relocOk_tab
#print axioms Link.compileExe_correct_source
#print axioms Link.compileExe_correct_source_peak
#print axioms Link.compileExe_total
#print axioms Link.leanLink_linkerOk
#print axioms E2E.backend_correct_final_alloc
#print axioms E2E.backend_correct_final_total
#print axioms E2E.lowerRFunc_spillAlloc
#print axioms E2E.backend_correct_program_stackX
#print axioms E2E.DeadCleanupExecBytes.binary_correct_exec
#print axioms E2E.DeadCleanupExecBytes.binary_correct_exec_of_good
#print axioms E2E.DeadCleanupExecBytes.binary_correct_exec_of_got
#print axioms E2E.DeadCleanupExecBytes.binary_correct_exec_of_reads
#print axioms E2E.DeadCleanupExecBytes.binary_correct_exec_of_insn
#print axioms E2E.DeadCleanupExecBytes.binary_correct_exec_peak_proven
#print axioms E2E.DeadCleanupExecBytes.binary_correct_exec_proven
#print axioms E2E.DeadCleanupExecBytes.binary_correct_exec_staticN
#print axioms E2E.DeadCleanupExecBytes.binary_correct_exec_static
#print axioms E2E.backend_correct_final_cleanup
#print axioms E2E.backend_correct_final_cleanup_ex
#print axioms E2E.backend_correct_legal_callFree_cleanup
#print axioms E2E.backend_correct_legal_cleanup
#print axioms E2E.backend_correct_legal_env_cleanup
#print axioms E2E.backend_correct_legal_direct_cleanup
#print axioms E2E.backend_correct_opt_proven_cleanup
#print axioms E2E.backend_correct_final_cleanup_total_emit_input
#print axioms E2E.DeadCleanupStackBound.goodN_iff
#print axioms E2E.DeadCleanupStackBound.stackB_isSome_iff
#print axioms E2E.backend_correct_final_cleanup_total
#print axioms E2E.backend_correct_final_cleanup_total_emit
#print axioms E2E.backend_correct_final_cleanup_total_emit_in
#print axioms E2E.backend_correct_final_cleanup_total_ready
#print axioms E2E.backend_correct_final_total_emit
#print axioms E2E.backend_correct_final_total_ready
#print axioms E2E.emitReady_spill
#print axioms E2E.backend_correct_final_total_emit_in
#print axioms E2E.ExecBytes.binary_correct_exec
#print axioms E2E.ExecBytes.binary_correct_exec_of_good
#print axioms E2E.ExecBytes.binary_correct_exec_of_got
#print axioms E2E.ExecBytes.binary_correct_exec_of_reads
#print axioms E2E.ExecBytes.binary_correct_exec_of_insn
#print axioms E2E.ExecBytes.binary_correct_exec_depth_proven
#print axioms E2E.ExecBytes.binary_correct_exec_peak_proven
#print axioms E2E.ExecBytes.binary_correct_exec_proven
#print axioms E2E.ExecBytes.binary_correct_exec_staticN
#print axioms E2E.ExecBytes.binary_correct_exec_static
#print axioms E2E.backend_correct_final
#print axioms E2E.backend_correct_final_ex
#print axioms E2E.backend_correct_final_indirectFree
#print axioms E2E.backend_correct_final_of_lower
#print axioms E2E.backend_correct_final_of_lower_ex
#print axioms E2E.backend_correct_legal
#print axioms E2E.backend_correct_legal_callFree
#print axioms E2E.backend_correct_legal_env
#print axioms E2E.LegalProgram.legalProg_refines_depth
#print axioms E2E.backend_correct_legal_direct
#print axioms E2E.LegalProgram.legalProg_refines
#print axioms E2E.backend_correct_program
#print axioms E2E.backend_correct_program_budget
#print axioms E2E.backend_correct_program_core
#print axioms E2E.backend_correct_program_peak
#print axioms E2E.backend_correct_program_returned
#print axioms E2E.backend_correct_program_returned_budget
#print axioms E2E.backend_correct_program_budgetX
#print axioms E2E.backend_correct_program_coreX
#print axioms E2E.backend_correct_program_peakX
#print axioms E2E.backend_correct_final_id
#print axioms E2E.backend_correct_opt_proven
#print axioms E2E.backend_correct_final_total_relaxed
#print axioms E2E.backend_correct_final_total_emit_input
#print axioms E2E.LinkCheck.crate_correct_inScope_proven
#print axioms E2E.backend_correct_final_alloc_proven
#print axioms E2E.spillAccepted
#print axioms E2E.StackBound.budOkW_budMap
#print axioms E2E.StackBound.goodN_iff
#print axioms E2E.StackBound.stackB_isSome_iff
#print axioms E2E.backend_correct_program_stack
#print axioms Backend.Insn.decode_encode
#print axioms Backend.Proof.Driver.formsCovered_complete
#print axioms Backend.Proof.Driver.lowerCheck_complete
#print axioms Backend.Proof.Driver.prepDomain_of_lower
#print axioms Backend.Proof.Prep.prepCheck_complete
#print axioms Backend.Proof.Prep.prepare_correct
#print axioms Opt.Legal.Complete.check_complete_of_preB
#print axioms Opt.Legal.Complete.preB_iff
#print axioms Opt.Proof.simplifyRulesCorrect_proven
#print axioms Opt.optimize_sim_proven
#print axioms E2E.backend_correct_final_try_witness
#print axioms E2E.backend_correct_final_witness
#print axioms Link.DeadCleanup.SourceWitness.compileExe_correct_source_helper
#print axioms Link.DeadCleanup.SourceWitness.compileExe_correct_source_peak_helper
#print axioms Link.SourceWitness.compileExe_correct_source_helper
#print axioms Link.SourceWitness.compileExe_correct_source_peak_helper
