from pathlib import Path
import subprocess as sp,json
root=Path('/home/lee/clifv/.worktrees/stock-driver-incremental')
files=sp.check_output(['git','diff','--name-only','693b9b24','--','FV'],cwd=root,text=True).splitlines()
mods=[p[:-5].replace('/','.') for p in files if p.endswith('.lean')]
s='import Lean\n'+''.join('import '+m+'\n' for m in mods)+'open Lean Elab Command\nrun_cmd do\n  let env ← getEnv\n  let targets : Array String := #['+','.join(json.dumps(m) for m in mods)+']\n  let mut count : Nat := 0\n  for (name, _) in env.constants.toList do\n    let some index := env.getModuleIdxFor? name | continue\n    if !targets.contains env.header.moduleNames[index]!.toString then continue\n    let axioms ← collectAxioms name\n    for ax in axioms do\n      unless #[``propext, ``Classical.choice, ``Quot.sound].contains ax do\n        throwError "disallowed axiom {ax} in {name}"\n    logInfo m!"DELIVERY_CONSTANT {Json.compress (toJson (name.toString, axioms.map Name.toString))}"\n    count := count + 1\n  unless count > 0 do throwError "empty constant audit"\n  logInfo m!"DELIVERY_AXIOM_COUNT {count}"\n'
Path('/tmp/stock-d0-all-constants.lean').write_text(s)
print('Audit covers all public/private/generated constants in',len(mods),'changed FV modules')
