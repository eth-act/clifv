from pathlib import Path
import os,subprocess as sp,json,datetime,hashlib,traceback
view=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');canon=Path('/home/lee/clifv/.worktrees/driver-proof-resume');root=Path('/tmp/stock-d0-affected-gates');root.mkdir(exist_ok=True);state=root/'progress.json';logs={}
head=sp.check_output(['git','rev-parse','HEAD'],cwd=view,text=True).strip()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def inputs():
 return {str(p.relative_to(view)):sha(p) for d in ['FV','FVTest','examples/fv-demo/src','scripts/audit'] for p in (view/d).rglob('*') if p.is_file() and p.suffix in ['.lean','.rs']}
frozen_sources=inputs();(root/'inputs.json').write_text(json.dumps({'head':head,'sources':frozen_sources},indent=2)+'\n')
env=dict(os.environ);env.update(PATH='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:/home/lee/.cargo/bin:/home/lee/.local/share/clifv-test-tools/usr/bin:/home/lee/.rustup/toolchains/nightly-2026-09-26-x86_64-unknown-linux-gnu/lib/rustlib/x86_64-unknown-linux-gnu/bin:'+str(view/'rust/target/release')+':'+env['PATH'],FV_ROOT=str(view),FV_AR='/home/lee/.local/share/clifv-test-tools/usr/bin/llvm-ar',FV_OBJCOPY='/home/lee/.local/share/clifv-test-tools/usr/bin/llvm-objcopy',FV_LAKE_CACHE=str(canon/'.lake/artifact-cache'),FV_MEMCAP='8G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',CARGO_BUILD_JOBS='2',CLIF_NATIVE_QEMU='/home/lee/.local/share/clifv-test-tools/usr/bin/qemu-aarch64-static',LLVM_MC='/home/lee/.local/share/clifv-test-tools/usr/bin/llvm-mc',PYTHONPATH=str(view/'scripts'))
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:8])
def report(status,**kw):
 d={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':status,'pid':os.getpid(),'head':head,'logs':logs,**kw};state.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items() if k!='logs'}),flush=True)
def frozen():
 assert sp.check_output(['git','rev-parse','HEAD'],cwd=view,text=True).strip()==head
 assert inputs()==frozen_sources,'source changed during gates'
def run(name,args,cwd=view):
 frozen();p=root/(name+'.log');report('running',phase=name,log=str(p))
 with p.open('w') as f:
  command=args if args[:2]==['python3','/tmp/stock-execute-scheduler.py'] else [str(view/'scripts/memcap.sh'),*args]
  r=sp.run(command,cwd=cwd,env=env,stdout=f,stderr=sp.STDOUT)
 assert r.returncode==0,(name,r.returncode,str(p));frozen();logs[name]={'path':str(p),'sha256':sha(p)};return p
try:
 run('d0-runtime',['lake','env','lean','--run','FVTest/Backend/Lowering/StockD0Runtime.lean'])
 run('tool-modules',['python3','/tmp/stock-execute-scheduler.py','--budget','16G','--max-jobs','3','--max-cap','16G','--default-cap','8G','--others-by-usage','--out',str(root/'tool-modules'),'FVTest.Backend.Main','FVTest.E2E.Check','FVTest.E2E.LinkCheckMain','FVTest.Link.LeanLinkMain','FVTest.Front.DecodeMain','FVTest.Backend.Lowering.StockComparison'])
 run('tools',['lake','build','lean-backend','lean-e2e-check','link-check','lean-link','clif-decode','lean-stock-lowering-compare'])
 run('runtime',['bash','scripts/lean-backend-filetests.sh'])
 run('encoder',['bash','scripts/lean-backend-encode-check.sh'])
 for label,flags in [('e2e',[]),('legacy-e2e',['--no-dead-cleanup'])]:
  run(label,['lake','exe','lean-e2e-check',*flags,'--identity-report',str(root/(label+'-identities.json'))])
 parity={}
 def identities(path):
  fs=json.loads(path.read_text())['functions'];result={(f['file'],f['index'],f['function']):tuple(f['stages']) for f in fs};assert len(result)==len(fs);return result
 for label,old in [('e2e','legacy-dead-cleanup-final-e2e-identities.json'),('legacy-e2e','legacy-dead-cleanup-final-legacy-e2e-identities.json')]:
  a=identities(Path('/tmp')/old);b=identities(root/(label+'-identities.json'));assert len(a)==1150
  assert a.keys()<=b.keys();assert all(a[k]==b[k] for k in a),'original ordered stages changed'
  parity[label]={'original':len(a),'current':len(b),'all_original_identities_and_ordered_stages_preserved':True,'gained':len(b.keys()-a.keys())}
 (root/'identity-stage-parity.json').write_text(json.dumps(parity,indent=2)+'\n')
 run('all-changed-constants',['lake','env','lean','--root=/tmp','/tmp/stock-d0-all-constants.lean'])
 run('stock-development-artifacts',['python3','-m','unittest','-v','test_stock_compiler_compare.StockDevelopmentIntegrationTests'])
 meta=json.loads(Path('/tmp/stock-cgclif-source.json').read_text());assert sha(Path(meta['output']))==meta['output_sha256'];assert sha(view/'scripts/patches/cg-clif-extnames.patch')==meta['patch_sha256']
 run('rust-tools',['cargo','build','--release','--locked','-p','cargo-fv','-p','clif-data-export','-p','lean-regalloc'],cwd=view/'rust')
 for example in ['fv-demo','survey']:
  run('verified-'+example,['bash','examples/compare.sh','examples/'+example,'--lean-link','--verified','--keep-temps'])
 units=view/'examples/fv-demo/target/fv/plain-leanlink-verified-leanld/units';found={}
 for unit in units.glob('*.json'):
  data=json.loads(unit.read_text())
  for fn in data.get('functions',[]):
   for name in ['stock_entry_return::identity32','stock_entry_return::identity64']:
    if name in fn.get('instance',''):found.setdefault(name,[]).append({'unit':str(unit),'symbol':fn['symbol'],'status':fn['status']})
 assert len(found)==2,found
 assert all(row['status']=='verified' for rows in found.values() for row in rows),found
 (root/'mixed-program-verified-functions.json').write_text(json.dumps(found,indent=2)+'\n')
 report('affected_runtime_gates_passed',remaining='full FV/FVTest module gate and E2E audit; one bundled MCP; generated-proof witness/build; current-main reconciliation and squash landing')
except BaseException as e:report('failed',error=repr(e),traceback=traceback.format_exc());raise
