from pathlib import Path
import os,signal,subprocess as sp,json,datetime
root=Path('/tmp/stock-ddfeb-ci-heavy-stages');work=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');sched=1763255
receipt=json.loads((root/'receipt.json').read_text());assert receipt['state']=='downloaded_not_imported'
assert b'stock-execute-scheduler.py' in Path(f'/proc/{sched}/cmdline').read_bytes()
assert sp.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip()=='213fe68bfbda3ed5d237cb7df6651f47e5a189bc'
env=dict(os.environ,PATH='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:'+os.environ['PATH'],FV_MEMCAP='1G',FV_LAKE_CACHE='/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache',LEAN_NUM_THREADS='1',OMP_NUM_THREADS='1',OMP_THREAD_LIMIT='1')
stopped=False
try:
 os.kill(sched,signal.SIGSTOP);stopped=True
 total=0
 for child in Path(f'/proc/{sched}/task/{sched}/children').read_text().split():
  p=Path(f'/proc/{child}')
  if not p.exists() or (p/'stat').read_text().split()[2]=='Z':continue
  cap=next(v.decode().split('=',1)[1] for v in (p/'environ').read_bytes().split(b'\0') if v.startswith(b'FV_MEMCAP='))
  total+=int(cap[:-1])*(1024 if cap[-1]=='G' else 1)
 assert total<=15360,('retain author kernels; insufficient budget for cache import',total)
 receipt['existing_author_cap_MiB']=total
 for item in receipt['records']:
  log=root/(item['stage']+'.unstage.log')
  with log.open('w') as f:
   result=sp.run([str(work/'scripts/memcap.sh'),'lake','cache','unstage',str(root/item['stage'])],cwd=work,env=env,stdout=f,stderr=sp.STDOUT)
  item['unstage_rc']=result.returncode;item['unstage_log']=str(log)
  assert result.returncode==0,log
 receipt['state']='unstaged_to_shared_source_keyed_cache_not_gate_pass'
finally:
 if stopped:os.kill(sched,signal.SIGCONT)
 receipt['scheduler_resumed']=stopped;receipt['utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();receipt['import_cap_MiB']=1024
 (root/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps({'state':receipt['state'],'scheduler_resumed':stopped,'records':[{k:v for k,v in r.items() if k in ['stage','output_keys','unstage_rc']} for r in receipt['records']]}),flush=True)
