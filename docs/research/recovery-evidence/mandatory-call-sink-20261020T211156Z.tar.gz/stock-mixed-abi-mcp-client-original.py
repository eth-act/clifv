from pathlib import Path
import asyncio,json,os,re,hashlib
from mcp import ClientSession,StdioServerParameters
from mcp.client.stdio import stdio_client
root='/home/lee/clifv/.worktrees/stock-mixed-production'
out=Path('/tmp/stock-mixed-abi-mcp-review');out.mkdir(exist_ok=True)
code='''import FV.E2E.ABIReadOnlySem
open Backend Backend.Proof Backend.Proof.Driver
example (F : BitVec 64 → Prop) (ctx : FnCtx) (X : ExtSem) :
    Refines F (E2E.ABIReadOnly.sem F ctx X) := E2E.ABIReadOnly.refines F ctx X
example (F : BitVec 64 → Prop) (ctx : FnCtx) (X : ExtSem) :
    DriverSem (E2E.ABIReadOnly.sem F ctx X) := E2E.ABIReadOnly.driver F ctx X
example (F : BitVec 64 → Prop) (ctx : FnCtx) (X : ExtSem) :
    MemRefines F ctx.slotBase (fun _ => none) (E2E.ABIReadOnly.sem F ctx X) := by
  apply E2E.ABIReadOnly.memory F ctx X rfl
  intro n b h
  cases h
#print axioms E2E.ABIReadOnly.sem
#print axioms E2E.ABIReadOnly.refines
#print axioms E2E.ABIReadOnly.memory
#print axioms E2E.ABIReadOnly.driver
'''
(out/'review.lean').write_text(code)
async def main():
 env=dict(os.environ,LEAN_PROJECT_PATH=root,LEAN_REPL='false',LOOGLE_LOCAL='false',LEAN_MCP_PREWARM_FILES='',LEAN_LSP_MAX_OPEN_FILES='1',LEAN_MCP_SCRATCH_SLOTS='1',LEAN_NUM_THREADS='1',OMP_NUM_THREADS='1',OMP_THREAD_LIMIT='1')
 params=StdioServerParameters(command='/home/lee/.nix-profile/bin/lean-lsp-mcp',args=['--lean-project-path',root,'--disable-tools','lean_build'],env=env,cwd=root)
 with (out/'server.stderr').open('w') as stderr:
  async with stdio_client(params,errlog=stderr) as (read,write):
   async with ClientSession(read,write,read_timeout_seconds=300) as session:
    await session.initialize()
    result=await session.call_tool('lean_run_code',{'code':code})
    raw=result.model_dump(mode='json');(out/'mcp-result.json').write_text(json.dumps(raw,indent=2)+'\n')
    assert not result.isError,raw
    data=result.structuredContent
    if not isinstance(data,dict):
     data=json.loads('\n'.join(c.text for c in result.content if c.type=='text'))
    assert data.get('success') and not data.get('timed_out'),data
    text=' '.join(str(d.get('message',d)) for d in data['diagnostics'])
    axioms={n:set(x.strip() for x in a.split(',') if x.strip()) for n,a in re.findall(r"'([^']+)' depends on axioms: \[([^\]]*)\]",text)}
    axioms.update({n:set() for n in re.findall(r"'([^']+)' does not depend on any axioms",text)})
    expected={'E2E.ABIReadOnly.'+name for name in ['sem','refines','memory','driver']}
    assert set(axioms)==expected,axioms
    assert all(v<={'propext','Classical.choice','Quot.sound'} for v in axioms.values()),axioms
    (out/'axiom-sets.json').write_text(json.dumps({n:sorted(v) for n,v in axioms.items()},indent=2)+'\n')
 print(json.dumps({'state':'passed','project':root,'mcp_tool':'lean_run_code','calls':1,'owned_constants_standard_only':4,'compatibility_applications':3,'code_sha256':hashlib.sha256(code.encode()).hexdigest(),'server_context_closed':True}),flush=True)
asyncio.run(main())
