from pathlib import Path
import subprocess as sp,os,signal,time,json,hashlib,datetime
root=Path('/home/lee/clifv/.worktrees/stock-mixed-production');sched=1763255;out=Path('/tmp/stock-mixed-abi-mcp-review');out.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
head=sp.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert head=='a2d324c83c9cd9601b91ebab085b4aa4ef4e723b'
assert not sp.check_output(['git','diff','--name-only'],cwd=root,text=True).strip()
frozen={str(p.relative_to(root)):sha(p) for p in (root/'FV').rglob('*.lean')}
env=dict(os.environ,PATH='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:'+os.environ['PATH'],FV_LAKE_CACHE='/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache',LEAN_NUM_THREADS='1',OMP_NUM_THREADS='1',OMP_THREAD_LIMIT='1')
stopped=False;records=[];state='not_started'
try:
 assert b'stock-execute-scheduler.py' in Path(f'/proc/{sched}/cmdline').read_bytes()
 os.kill(sched,signal.SIGSTOP);stopped=True
 deadline=time.monotonic()+60
 while True:
  live=[]
  for k in Path(f'/proc/{sched}/task/{sched}/children').read_text().split():
   p=Path('/proc')/k
   if p.exists() and (p/'stat').read_text().split()[2]!='Z':live.append(k)
  if len(live)<=1:break
  if time.monotonic()>deadline:raise RuntimeError('retain existing author kernels; no available slot')
  time.sleep(.2)
 cap=8192
 for k in live:
  c=next(e.decode().split('=',1)[1] for e in Path(f'/proc/{k}/environ').read_bytes().split(b'\0') if e.startswith(b'FV_MEMCAP='));amount=int(c[:-1])*(1024 if c[-1]=='G' else 1);cap=min(cap,16384-amount)
 assert cap>=4096,('MCP deferred: insufficient remaining reserved cap',cap)
 env['FV_MEMCAP']=str(cap)+'M'
 for label,args in [('current_abi_source_keys',['lake','build','--no-build','FV.E2E.ABIReadOnlySem']),('single_mcp_bundle',['/nix/store/8nf68ja9x78m7x0ni1gplic4b6w8x3bq-lean-lsp-mcp-env/bin/python3.13','/tmp/stock-mixed-abi-mcp-client.py'])]:
  log=out/(label+'.log')
  with log.open('w') as f:r=sp.run([str(root/'scripts/memcap.sh'),*args],cwd=root,env=env,stdout=f,stderr=sp.STDOUT)
  records.append({'label':label,'returncode':r.returncode,'log':str(log),'sha256':sha(log)});assert r.returncode==0,(label,str(log))
 assert all(sha(root/p)==h for p,h in frozen.items())
 assert sp.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head
 state='passed'
finally:
 if stopped:os.kill(sched,signal.SIGCONT)
 result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':state,'head':head,'source_sha256':{'FV/E2E/ABIReadOnlySem.lean':frozen['FV/E2E/ABIReadOnlySem.lean']},'all_FV_sources_unchanged':state=='passed','records':records,'cap_MiB':locals().get('cap'),'aggregate_MiB':16384,'max_active_builds':2,'scheduler_resumed':stopped,'project':str(root),'tool':'lean_run_code','calls':1 if state=='passed' else None,'remaining':'ABI semantic contracts only. Normal full class source/body/machine/consumers and every current per-PR activation gate still required; arithmetic first/full original140active.'};(out/'controller-receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['records','source_sha256']}),flush=True)
