import FV.E2E.ABIReadOnlySem
open Backend Backend.Proof Backend.Proof.Driver
example (F : BitVec 64 → Prop) (ctx : FnCtx) (X : ExtSem) :
    Refines F (E2E.ABIReadOnly.sem F ctx X) := E2E.ABIReadOnly.refines F ctx X
example (F : BitVec 64 → Prop) (ctx : FnCtx) (X : ExtSem) :
    DriverSem (E2E.ABIReadOnly.sem F ctx X) := E2E.ABIReadOnly.driver F ctx X
example (F : BitVec 64 → Prop) (ctx : FnCtx) (X : ExtSem) :
    MemRefines F ctx.slotBase (fun _ => none) (E2E.ABIReadOnly.sem F ctx X) := by
  apply E2E.ABIReadOnly.memory F ctx X rfl
  intro n b h
  cases h
#print axioms E2E.ABIReadOnly.sem
#print axioms E2E.ABIReadOnly.refines
#print axioms E2E.ABIReadOnly.memory
#print axioms E2E.ABIReadOnly.driver
