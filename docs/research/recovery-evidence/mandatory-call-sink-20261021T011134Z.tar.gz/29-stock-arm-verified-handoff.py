from pathlib import Path
import os,signal,time,subprocess as sp,json,datetime,hashlib,tarfile
view=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');out=Path('/tmp/stock-arm-verified-handoff');out.mkdir(exist_ok=True)
oldparent=1762992;oldsched=1763255;candidate='672c4dc4820b31c477a5e075926c72cd2b267dd8';branch='agent/stock-arithmetic-arm-model-20261021T001904Z';base='08020ed34bea4a3656c1b080c55087da40f2ebbe';boundary=Path('/tmp/stock-arm-module-boundary-observer/receipt.json')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return sp.check_output(['git',*args],cwd=view,text=True).strip()
def report(state,**kw):
 j={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':state,'pid':os.getpid(),'old_author':oldparent,'old_scheduler':oldsched,'candidate':candidate,'main':base,**kw};(out/'progress.json').write_text(json.dumps(j,indent=2)+'\n');print(json.dumps(j),flush=True)
report('waiting_for_same_old_module_epoch')
while not boundary.exists():
 p=Path(f'/proc/{oldsched}/stat')
 if not p.exists() or p.read_text().split()[2]=='Z':
  # Allow the already-running read-only observer to finish its source verification.
  time.sleep(1)
 else:time.sleep(2)
j=json.loads(boundary.read_text());assert j['state']=='old_module_epoch_passed_ready_for_verified_handoff',j
assert j['head']=='213fe68bfbda3ed5d237cb7df6651f47e5a189bc' and sha(Path(j['log']))==j['log_sha256']
assert Path(f'/proc/{oldparent}/stat').read_text().split()[2]=='T'
assert b'stock-arithmetic-current-main-author-gates.py' in Path(f'/proc/{oldparent}/cmdline').read_bytes()
p=Path(f'/proc/{oldsched}/stat');assert not p.exists() or p.read_text().split()[2]=='Z'
assert git('rev-parse','HEAD')==j['head'] and not git('status','--porcelain','--untracked-files=no')
frozen=json.loads(Path('/tmp/stock-arithmetic-current-main-author-gates/inputs.json').read_text());assert all(sha(view/p)==h for p,h in frozen['sources'].items())
git('fetch','origin','main');assert git('rev-parse','origin/main')==base,'newer main: reconcile before switching'
assert git('rev-parse',branch)==candidate
# Preserve every old module log and input/manifest, without copying build artifacts.
report('archiving_completed_old_module_epoch')
archive=out/'completed-old-module-epoch.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=1) as t:
 t.add('/tmp/stock-arithmetic-current-main-author-gates',arcname='completed-old-module-epoch')
 for p in [boundary,Path('/tmp/stock-arm-current-source-prep.json'),Path('/tmp/stock-arm-next-validation-prepared.json')]:t.add(p,arcname=p.name)
env=dict(os.environ,STOCK_RECOVERY_EVIDENCE=str(archive))
with (out/'backup.log').open('w') as f:r=sp.run(['nice','-n','10','python3','/tmp/stock-mandatory-backup.py'],cwd=view,env=env,stdout=f,stderr=sp.STDOUT)
assert r.returncode==0,('completed epoch remote backup failed',str(out/'backup.log'))
backup=json.loads(Path('/tmp/stock-backup-captured-result.json').read_text());assert backup['remote_commit_and_all_captured_blobs_verified']
report('old_epoch_verified_and_remotely_preserved',backup_commit=backup['commit'],archive_sha256=sha(archive))
# Only the stopped obsolete metadata parent remains; no proof kernel is signalled.
os.kill(oldparent,signal.SIGTERM);os.kill(oldparent,signal.SIGCONT)
deadline=time.monotonic()+30
while Path(f'/proc/{oldparent}/cmdline').exists():
 assert time.monotonic()<deadline,'old author not reaped; verify its actual state before handoff'
 time.sleep(.2)
assert not git('status','--porcelain','--untracked-files=no') and git('rev-parse','HEAD')==j['head']
git('switch',branch);assert git('rev-parse','HEAD')==candidate
assert sha(view/'FVTest/Backend/Lowering/StockArithmeticRuntime.lean')=='b00043a15c8616e6b4b78bfa2d24634eeacb825bbd75d56db6aa1b1626641b1c'
report('starting_current_arm_author_gates',backup_commit=backup['commit'])
log=Path('/tmp/stock-arithmetic-arm-model-author-controller.log')
with log.open('w') as f:
 p=sp.Popen(['python3','/tmp/stock-arithmetic-arm-model-author-gates.py'],cwd=view,stdout=f,stderr=sp.STDOUT,start_new_session=True)
report('current_arm_author_gates_started',controller_pid=p.pid,controller_log=str(log),old_epoch_backup=backup['commit'],no_proof_kernel_interrupted=True,no_worktree_cache_created=True)
