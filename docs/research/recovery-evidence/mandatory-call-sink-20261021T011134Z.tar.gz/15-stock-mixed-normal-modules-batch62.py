from pathlib import Path
import subprocess as sp,os,signal,time,json,re,hashlib,datetime
primary=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');root=Path('/home/lee/clifv/.worktrees/stock-mixed-production');sched=1763255
out=Path('/tmp/stock-mixed-current-main-normal-modules-batch62');out.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sp.check_output(['git','rev-parse','HEAD'],cwd=primary,text=True).strip()=='213fe68bfbda3ed5d237cb7df6651f47e5a189bc'
head=sp.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert head=='22aa7ab3ddbad7d02940f433916339f735ba2aa6'
assert not sp.check_output(['git','diff','--name-only'],cwd=root,text=True).strip()
assert b'stock-execute-scheduler.py' in Path(f'/proc/{sched}/cmdline').read_bytes()
env=dict(os.environ,PATH='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:'+os.environ['PATH'],FV_MEMCAP='8G',FV_LAKE_CACHE='/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache',LEAN_NUM_THREADS='2',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2')
pat=re.compile(r'^(?:public\s+|private\s+|meta\s+)*import\s+(\S+)');deps={};ordered=[];seen=set()
def visit(m):
 if m in seen:return
 p=root/(m.replace('.','/')+'.lean')
 if not p.exists():return
 seen.add(m);ds=[x[1] for l in p.read_text().splitlines() if (x:=pat.match(l))];deps[m]=ds
 for d in ds:visit(d)
 ordered.append(m)
changed=sp.check_output(['git','diff','--name-only','213fe68bfbda3ed5d237cb7df6651f47e5a189bc..HEAD'],cwd=root,text=True).splitlines()
wanted={p[:-5].replace('/','.') for p in changed if p.endswith('.lean') and p.startswith(('FV/','FVTest/'))}
mixed_changed=set(wanted)
# Small unchanged data adapter: immediate imports must already be current.
# Build it once into the shared store, never launch its legacy dependency closure.
wanted.update({'FV.Backend.StockArithmeticCheck','FV.Backend.Unwind','FV.Backend.Proof.RelaxLayout'})
wanted.add('FV.Backend.Proof.RefinesInsts')
wanted.update({'FV.Backend.Proof.LowerTotalCtx','FV.Backend.Proof.LowerTotalDefs','FV.Backend.Proof.KillTryDefs','FV.E2E.LinkOwnRetsIsel'})
wanted.add('FV.E2E.RegLevelCorrect')
wanted.update({'FV.Backend.Proof.IselEmitFns','FV.Backend.Proof.SpillStep4Edge','FV.Backend.Proof.DeadCleanupDeletion','FV.Backend.Proof.DeadCleanupPositions','FV.E2E.PairLines','FV.Unw.Model'})
wanted.update({'FV.Backend.Proof.StockSinkFrame','FV.Backend.Proof.StockPureSourceColors','FV.Backend.Proof.StockBlockCode'})
wanted.update({'FV.Backend.Proof.StockSourceSinkTable','FV.Backend.Proof.StockReturnABI','FV.Backend.Proof.StockSourceDFG','FV.Backend.Proof.StockEntryAliases','FV.Backend.Proof.StockEntryOrder'})
wanted.update({'FV.E2E.ValidatedLowering','FV.Backend.Proof.IselEmitDefs'})
wanted.update({'FV.Backend.Proof.IselFloatBitcast','FV.Backend.Proof.IselMemNoIconst','FV.Backend.Proof.IselFloatVac'})
wanted.update({'FV.Backend.Proof.PerEdgePrepareComplete','FV.Backend.Proof.PerEdgeVCodeSem','FV.Backend.Proof.SpillEdges','FV.Backend.Proof.SpillClsCheck','FV.Backend.Proof.SpillClsInst','FV.Backend.Proof.DeadCleanupAvailability','FV.Backend.Proof.DefGenSoundAt','FV.E2E.UnwindSem','FV.Backend.Proof.IselSzCall','FV.Backend.Proof.IselSzBrTable','FV.Backend.Proof.IselSzSound'})
wanted.add('FV.Backend.Proof.StockCoverageInvariant')
wanted.update({'FV.Backend.Proof.IselPrgDom','FV.Backend.Proof.DefAssembleBase','FV.Backend.Proof.SpillDefinedArgs','FV.E2E.DeadCleanupCover','FV.E2E.DeadCleanupDirect','FV.Backend.Proof.PrepareTotalIsel'})
all_deps={}
for folder in ['FV','FVTest']:
 for file in (root/folder).rglob('*.lean'):
  module=str(file.relative_to(root))[:-5].replace('/','.')
  all_deps[module]={x[1] for line in file.read_text().splitlines() if (x:=pat.match(line))}
real_affected=set(mixed_changed)
while True:
 more={m for m,ds in all_deps.items() if ds&real_affected}-real_affected
 if not more:break
 real_affected|=more
known_seconds={};known_peak_mib={}
for peak_file in [root/'scripts/lake-module-peaks.tsv',root/'.lake/lake-module-peaks.tsv',primary/'.lake/lake-module-peaks.tsv']:
 if not peak_file.exists():continue
 for row in peak_file.read_text().splitlines():
  fields=row.split()
  if len(fields)>=3 and not row.startswith('#'):
   try:
    known_peak_mib[fields[0]]=max(known_peak_mib.get(fields[0],0),float(fields[1]))
    known_seconds[fields[0]]=max(known_seconds.get(fields[0],0),float(fields[2]))
   except ValueError:pass
known_seconds.setdefault('FV.Backend.Proof.StockSourceSinkTable',600)
# Normal kernel observed beyond eight minutes at unchanged shared source/import closure.
known_seconds['FV.Backend.Proof.IselPrgTab']=max(known_seconds.get('FV.Backend.Proof.IselPrgTab',0),495)
affected=set(wanted)
while True:
 more={m for m,ds in all_deps.items() if ds&affected}-affected
 if not more:break
 affected|=more
for m in sorted(wanted):visit(m)
ordered=[m for m in ordered if m in affected]
frozen={m:sha(root/(m.replace('.','/')+'.lean')) for m in ordered};records=[];stopped=False;bulk_probe=None;initial_current=set();skip_reason=None;leaf_cap_mib=8192;waiting=set()
try:
 os.kill(sched,signal.SIGSTOP);stopped=True
 deadline=time.monotonic()+60
 while True:
  kids=Path(f'/proc/{sched}/task/{sched}/children').read_text().split();live=[k for k in kids if Path(f'/proc/{k}/stat').exists() and Path(f'/proc/{k}/stat').read_text().split()[2]!='Z']
  if len(live)<=1:break
  
  if time.monotonic()>=deadline:
   skip_reason='two existing author kernels retained; no available slot';break
  time.sleep(.2)
 for k in live:
  caps=[v.decode().split('=',1)[1] for v in Path(f'/proc/{k}/environ').read_bytes().split(b'\0') if v.startswith(b'FV_MEMCAP=')];assert len(caps)==1
  cap=caps[0];amount=int(cap[:-1])*(1024 if cap[-1]=='G' else 1)
  leaf_cap_mib=min(leaf_cap_mib,16384-amount)
  if leaf_cap_mib<3072:skip_reason='existing author cap '+cap+' leaves less than 3G for a profiled leaf'
 env['FV_MEMCAP']=str(leaf_cap_mib)+'M'
 if not skip_reason:
  bulk_log=out/'initial-source-keys.log'
  with bulk_log.open('w') as f:bulk=sp.run([str(root/'scripts/memcap.sh'),'lake','build','--no-build',*ordered],cwd=root,env=env,stdout=f,stderr=sp.STDOUT)
  bulk_text=bulk_log.read_text()
  missing=set(re.findall(r'✖ \[[^\]]+\] Building (\S+)',bulk_text))
  errors=[line for line in bulk_text.splitlines() if line.startswith('error:')]
  assert bulk.returncode==0 or (missing and errors and all(line=='error: target is out-of-date and needs to be rebuilt' for line in errors)),('unexpected bulk source-key failure',bulk.returncode,str(bulk_log))
  assert missing<=all_deps.keys(),('unrecognized missing bulk targets',sorted(missing-all_deps.keys()))
  memo={}
  def closure_missing(m):
   if m in memo:return memo[m]
   memo[m]=m in missing or any(closure_missing(d) for d in all_deps.get(m,()))
   return memo[m]
  initial_current={m for m in ordered if not closure_missing(m)}
  verified_current_log=out/'verified-current-source-keys.log'
  if initial_current:
   with verified_current_log.open('w') as f:verified=sp.run([str(root/'scripts/memcap.sh'),'lake','build','--no-build',*sorted(initial_current)],cwd=root,env=env,stdout=f,stderr=sp.STDOUT)
   assert verified.returncode==0,('bulk-current classification failed direct all-target verification',str(verified_current_log))
  bulk_probe={'log':str(bulk_log),'returncode':bulk.returncode,'missing':sorted(missing),'current_targets':sorted(initial_current),'source_key_check_only':True,'compile_jobs_started':0,'all_current_targets_directly_verified_log':str(verified_current_log)}
  print(json.dumps({'bulk_source_key_current':len(initial_current),'missing':len(missing),'log':str(bulk_log)}),flush=True)
  if os.environ.get('STOCK_NORMAL_BULK_PREVIEW')=='1':ordered=[]
 started=time.monotonic();built=0
 for m in ([] if skip_reason else ordered):
  if m in initial_current:
   records.append({'module':m,'state':'source_key_current_or_restored','probe_log':bulk_probe['log']});continue
  active=set()
  for event in Path('/tmp/stock-arithmetic-current-main-author-gates/all-modules/sched.log').read_text().splitlines():
   fields=event.split()
   if len(fields)>2 and fields[1]=='start':active.add(fields[2])
   elif len(fields)>2 and fields[1]=='done':active.discard(fields[2])
  if m=='FV.Backend.Proof.StockSourceSinkTable' or (m not in real_affected and known_seconds.get(m,0)>120):
   log=out/(m+'.slow-shared-probe.log')
   with log.open('w') as f:r=sp.run([str(root/'scripts/memcap.sh'),'lake','build','--no-build',m],cwd=root,env=env,stdout=f,stderr=sp.STDOUT,timeout=25)
   if r.returncode==0:
    records.append({'module':m,'state':'source_key_current_or_restored','probe_log':str(log)});continue
   waiting.add(m);records.append({'module':m,'state':'waiting_for_author_slow_shared_prerequisite','recorded_seconds':known_seconds[m],'log':str(log)});continue
  if m in active:
   waiting.add(m);records.append({'module':m,'state':'waiting_for_active_author_build'});continue
  if time.monotonic()-started>120 or built>=8:break
  upstream=[d for d in deps[m] if d in waiting]
  if upstream:
   waiting.add(m);records.append({'module':m,'state':'waiting_for_transitive_imports','dependencies':upstream});continue
  log=out/(m+'.probe.log')
  with log.open('w') as f:r=sp.run([str(root/'scripts/memcap.sh'),'lake','build','--no-build',m],cwd=root,env=env,stdout=f,stderr=sp.STDOUT,timeout=25)
  if r.returncode==0:
   records.append({'module':m,'state':'source_key_current_or_restored','probe_log':str(log)});continue
  imports=[d for d in deps[m] if (root/(d.replace('.','/')+'.lean')).exists()];imports_log=out/(m+'.imports.log')
  with imports_log.open('w') as f:r=sp.run([str(root/'scripts/memcap.sh'),'lake','build','--no-build',*imports],cwd=root,env=env,stdout=f,stderr=sp.STDOUT,timeout=25) if imports else sp.CompletedProcess([],0)
  if r.returncode:
   waiting.add(m)
   records.append({'module':m,'state':'waiting_for_current_imports','log':str(imports_log)});continue
  if leaf_cap_mib<4096 and m not in known_peak_mib:
   waiting.add(m);records.append({'module':m,'state':'waiting_for_profiled_leaf_budget','available_MiB':leaf_cap_mib});continue
  required_mib=int(known_peak_mib.get(m,0)*1.2+512)
  if required_mib>leaf_cap_mib:
   waiting.add(m);records.append({'module':m,'state':'waiting_for_larger_leaf_budget','required_MiB':required_mib,'available_MiB':leaf_cap_mib});continue
  log=out/(m+'.build.log')
  with log.open('w') as f:r=sp.run([str(root/'scripts/memcap.sh'),'lake','build',m],cwd=root,env=env,stdout=f,stderr=sp.STDOUT,)
  records.append({'module':m,'state':'built' if r.returncode==0 else 'failed','log':str(log),'returncode':r.returncode});built+=1
  assert r.returncode==0,('normal module failed',m,str(log))
 assert sp.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head
 assert all(sha(root/(m.replace('.','/')+'.lean'))==h for m,h in frozen.items())
finally:
 if stopped:os.kill(sched,signal.SIGCONT)
 result={'bulk_probe':bulk_probe,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'primary_head':'213fe68bfbda3ed5d237cb7df6651f47e5a189bc','source_sha256':frozen,'records':records,'skip_reason':skip_reason,'scheduler_resumed':stopped,'budget_GiB':16,'normal_leaf_cap_MiB':leaf_cap_mib,'max_active_builds':2,'cache':'own ignored .lake view, shared source-keyed artifactstore/hardlinks; no cachecopy','remaining':'Continue source-keyed normalmixedproof/consumer/tool/runtime gates; arithmeticcandidate must landfirst.'}
 (out/'receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'head':head,'counts':{s:sum(r['state']==s for r in records) for s in ['source_key_current_or_restored','built','waiting_for_current_imports','failed']},'scheduler_resumed':stopped,'skip_reason':skip_reason,'normal_leaf_cap_MiB':leaf_cap_mib,'receipt':str(out/'receipt.json')}),flush=True)
