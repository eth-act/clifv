from pathlib import Path
import subprocess as sp,os,signal,time,json,hashlib,datetime,re
view=Path('/home/lee/clifv/.worktrees/stock-mixed-production');primary=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');out=Path('/tmp/stock-mixed-normal-runtime-current');out.mkdir(exist_ok=False);sched=1763255
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
head=sp.check_output(['git','rev-parse','HEAD'],cwd=view,text=True).strip();assert head=='48bca5b4e899d2ba5fda525b245f94756bc263b6'
assert sp.check_output(['git','rev-parse','HEAD'],cwd=primary,text=True).strip()=='213fe68bfbda3ed5d237cb7df6651f47e5a189bc'
sources={str(p.relative_to(view)):sha(p) for folder in ['FV','FVTest'] for p in (view/folder).rglob('*.lean')};records={};stopped=False;state='waiting_for_budget';details={}
assert b'stock-execute-scheduler.py' in Path(f'/proc/{sched}/cmdline').read_bytes()
env=dict(os.environ,PATH='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:'+os.environ['PATH'],FV_MEMCAP='8G',FV_LAKE_CACHE='/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache',LEAN_NUM_THREADS='2',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2')
def report():
 (out/'receipt.json').write_text(json.dumps({'state':state,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':os.getpid(),'head':head,'source_sha256':sources,'records':records,'details':details,'scheduler_resumed':not stopped,'aggregate_MiB':16384,'leaf_cap_MiB':8192,'max_active_builds':2,'limits':'Exact normal checked-in files on the preserved old Arm model; current-Arm activation gates remain mandatory.'},indent=2)+'\n')
def run(name,args):
 global state
 state='running';details['phase']=name;report();log=out/(name+'.log')
 with log.open('w') as f:r=sp.run([str(view/'scripts/memcap.sh'),*args],cwd=view,env=env,stdout=f,stderr=sp.STDOUT)
 records[name]={'returncode':r.returncode,'log':str(log),'sha256':sha(log)};assert r.returncode==0,(name,r.returncode,str(log));return log.read_text()
try:
 os.kill(sched,signal.SIGSTOP);stopped=True;deadline=time.monotonic()+60
 while True:
  caps=[];live=[]
  for k in Path(f'/proc/{sched}/task/{sched}/children').read_text().split():
   p=Path('/proc')/k
   try:
    if p.joinpath('stat').read_text().split()[2]=='Z':continue
    cap=next(v.decode().split('=',1)[1] for v in p.joinpath('environ').read_bytes().split(b'\0') if v.startswith(b'FV_MEMCAP='))
    amount=int(cap[:-1])*(1024 if cap[-1]=='G' else 1)
   except FileNotFoundError:continue
   except PermissionError:amount=16384
   caps.append(amount);live.append(k)
  if len(live)<=1 and sum(caps)+8192<=16384:break
  if time.monotonic()>=deadline:
   state='deferred_existing_author_kernels_retained';details.update(author_caps_MiB=caps,live=live);raise SystemExit(0)
  time.sleep(.2)
 details.update(author_caps_MiB=caps,live=live)
 run('source-keys',['lake','build','--no-build','FVTest.Backend.Lowering.StockMixedRuntime','FVTest.Backend.Lowering.StockArithmeticRuntime'])
 env['STOCK_MIXED_NATIVE_OUT']=str(out/'objects')
 mixed=run('mixed',['lake','env','lean','--run','FVTest/Backend/Lowering/StockMixedRuntime.lean'])
 assert mixed.count('Stock mixed lean ')==6 and mixed.count('Stock mixed regalloc2 ')==6 and 'Stock mixed missing-binary negative control passed' in mixed
 env.pop('STOCK_MIXED_NATIVE_OUT')
 arith=run('arithmetic',['lake','env','lean','--run','FVTest/Backend/Lowering/StockArithmeticRuntime.lean'])
 assert arith.count('Stock arithmetic lean ')==6 and arith.count('Stock arithmetic regalloc2 ')==6 and 'Stock arithmetic missing-binary negative control passed' in arith
 assert sources['FVTest/Backend/Lowering/StockArithmeticRuntime.lean']=='b00043a15c8616e6b4b78bfa2d24634eeacb825bbd75d56db6aa1b1626641b1c'
 oldpath=Path('/tmp/stock-mixed-current-native-execution-pass/objects/native-receipt.json');old=json.loads(oldpath.read_text());same=[];different=[]
 assert old['state']=='passed' and len(old['records'])==24
 for r in old['records']:
  stem=f"{r['allocator']}-Backend.Stock.D0.Configuration.{r['configuration']}-{r['cleanup']}"
  checks={ext:sha(out/'objects'/(stem+ext))==r[key] for ext,key in [('.o','object_sha256'),('.json','table_sha256'),('.clif','original_source_sha256')]}
  (same if all(checks.values()) else different).append({'stem':stem,'equal':checks})
 details.update(positive_runtime_cases=48,missing_binary_negative_controls=2,regalloc_binary_sha256=sha(view/'rust/target/release/lean-regalloc'),native_prior_receipt=str(oldpath),native_prior_receipt_sha256=sha(oldpath),native_same_input_object_table=len(same),native_differences=different,all_native_comparisons=same+different)
 assert sp.check_output(['git','rev-parse','HEAD'],cwd=view,text=True).strip()==head
 assert all(sha(view/p)==h for p,h in sources.items())
 state='normal_checked_in_runtimes_passed'
except SystemExit:raise
except BaseException as e:
 state='failed';details['error']=repr(e);raise
finally:
 if stopped:os.kill(sched,signal.SIGCONT);stopped=False
 report();print(json.dumps({'state':state,'head':head,'scheduler_resumed':not stopped,'details':details,'receipt':str(out/'receipt.json')}),flush=True)
