from pathlib import Path
import subprocess as sp,os,signal,json,zipfile,re,hashlib,datetime,shutil,time
root=Path('/tmp/stock-08020-ci-cache-heavy-stage5');root.mkdir(exist_ok=True);work=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');cache=Path('/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache');sched=1763255;watch=0
j={'run':39519636227,'main':'08020ed34bea4a3656c1b080c55087da40f2ebbe','state':'pending_download_and_import','records':[]}
assert sp.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip()=='213fe68bfbda3ed5d237cb7df6651f47e5a189bc'
watch_stopped=False;sched_stopped=False;key_records={};artifacts=set()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
try:
 cmd=Path(f'/proc/{watch}/cmdline')
 if cmd.exists():
  assert b'stock-mixed-next-four-gib-slot-batch56.py' in cmd.read_bytes()
  state=json.loads(Path('/tmp/stock-mixed-next-four-gib-slot-batch56/progress.json').read_text());assert state['state']=='waiting_for_at_least_4GiB_and_one_build_slot'
  os.kill(watch,signal.SIGSTOP);watch_stopped=True
  kids=Path(f'/proc/{watch}/task/{watch}/children').read_text().split();assert not [k for k in kids if Path(f'/proc/{k}/stat').exists() and Path(f'/proc/{k}/stat').read_text().split()[2]!='Z'],'watcher acquired proof slot; retain it and defer import'
 assert b'stock-execute-scheduler.py' in Path(f'/proc/{sched}/cmdline').read_bytes();os.kill(sched,signal.SIGSTOP);sched_stopped=True
 deadline=time.monotonic()+60
 while True:
  live=[];caps=[]
  for k in Path(f'/proc/{sched}/task/{sched}/children').read_text().split():
   p=Path('/proc')/k
   try:
    if p.joinpath('stat').read_text().split()[2]=='Z':continue
    c=next(v.decode().split('=',1)[1] for v in p.joinpath('environ').read_bytes().split(b'\0') if v.startswith(b'FV_MEMCAP='))
   except FileNotFoundError:continue
   except PermissionError:live.append(k);caps.append(16384);continue
   caps.append(int(c[:-1])*(1024 if c[-1]=='G' else 1));live.append(k)
  if len(live)<=2 and sum(caps)+1024<=16384:break
  assert time.monotonic()<deadline,('retain author jobs; no import slot',live,caps)
  time.sleep(.2)
 env=dict(os.environ,PATH='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:'+os.environ['PATH'],FV_MEMCAP='1G',FV_LAKE_CACHE=str(cache),LEAN_NUM_THREADS='1',OMP_NUM_THREADS='1',OMP_THREAD_LIMIT='1')
 metadata=json.loads(sp.check_output(['gh','api','repos/eth-act/clifv/actions/artifacts/12311913967'],text=True))
 assert metadata['name']=='stage-w1-5' and metadata['workflow_run']['head_sha']==j['main'] and metadata['workflow_run']['id']==j['run'] and not metadata['expired']
 archive=root/'stage-w1-5.zip'
 with archive.open('wb') as f:
  r=sp.run([str(work/'scripts/memcap.sh'),'gh','api','repos/eth-act/clifv/actions/artifacts/12311913967/zip'],cwd=work,env=env,stdout=f)
 assert r.returncode==0 and archive.stat().st_size==metadata['size_in_bytes']
 j.update(state='downloaded_not_imported',records=[{'stage':'stage-w1-5','artifact_id':metadata['id'],'zip':str(archive),'zip_bytes':archive.stat().st_size,'zip_sha256':sha(archive)}])
 (root/'downloaded.json').write_text(json.dumps(j,indent=2)+'\n')
 for item in j['records']:
  archive=Path(item['zip']);assert sha(archive)==item['zip_sha256'];stage=root/item['stage'];stage.mkdir(exist_ok=True)
  with zipfile.ZipFile(archive) as z:
   assert all(n=='outputs.jsonl' or re.fullmatch(r'[0-9a-f]{16}\.ltar',n) for n in z.namelist())
   z.extractall(stage)
  lines=(stage/'outputs.jsonl').read_text().splitlines();assert json.loads(lines[0])=='2026-03-17';pairs=[json.loads(l) for l in lines[1:]];assert all((stage/name).is_file() for key,name in pairs)
  log=root/(item['stage']+'.unstage.log')
  with log.open('w') as f:r=sp.run(['nice','-n','10',str(work/'scripts/memcap.sh'),'lake','cache','unstage',str(stage)],cwd=work,env=env,stdout=f,stderr=sp.STDOUT)
  assert r.returncode==0,('cache unstage failed',str(log))
  for key,name in pairs:
   p=cache/'outputs/fv'/(key+'.json');assert p.is_file();key_records[key]=sha(p);data=json.loads(p.read_text())['data']
   for value in data.values():
    values=value if isinstance(value,list) else [value]
    for a in values:
     if isinstance(a,str):assert (cache/'artifacts'/a).is_file(),a;artifacts.add(a)
  item.update(output_keys=len(pairs),unstage_rc=r.returncode,unstage_log=str(log),unstage_log_sha256=sha(log));shutil.rmtree(stage);archive.unlink()
 j.update(state='unstaged_to_existing_shared_source_keyed_cache_not_gate_pass',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),existing_author_handles=live,existing_author_caps_MiB=caps,import_cap_MiB=1024,max_active_compiler_jobs=2,cache_only_io_jobs=1,aggregate_reserved_MiB=sum(caps)+1024,unique_keys_verified=len(key_records),referenced_artifacts_verified=len(artifacts),output_record_sha256=key_records,temporary_downloads_removed=True,new_cache_created=False)
finally:
 if sched_stopped:os.kill(sched,signal.SIGCONT)
 if watch_stopped:os.kill(watch,signal.SIGCONT)
 j.update(scheduler_resumed=sched_stopped,watcher_resumed=watch_stopped,held_author1762992_untouched=True);(root/'receipt.json').write_text(json.dumps(j,indent=2)+'\n');print(json.dumps({k:j.get(k) for k in ['state','unique_keys_verified','referenced_artifacts_verified','scheduler_resumed','watcher_resumed']}),flush=True)
