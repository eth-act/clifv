from pathlib import Path
import os,re,json,datetime,tarfile,hashlib,subprocess
os.nice(10)
base=Path('/tmp/stock-logical-selected-normal-attempt2'); out=Path('/tmp/stock-logical-selected-recovery');out.mkdir(exist_ok=True)
sched=(base/'modules/sched.log').read_text();done=[];active={}
for line in sched.splitlines():
 m=re.search(r' start (\S+) cap=(\S+)',line)
 if m:active[m[1]]=m[2]
 m=re.search(r' done (\S+) rc=(\d+)',line)
 if m:done.append({'module':m[1],'exit_status':int(m[2]),'record':line});active.pop(m[1],None)
manifest={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':'partial_normal_validation_not_activation_or_merge_pass','head':subprocess.check_output(['git','rev-parse','HEAD'],cwd='/home/lee/clifv/.worktrees/stock-mixed-production',text=True).strip(),'completed':done,'active_jobs':active,'source_packet_manifest':'/tmp/stock-logical-selected-normal/source-inputs.json','normal_controller':2186400,'arithmetic_scheduler_held':1235140,'resumed_in_finally':True,'next':['Finish RootWitness normal build; fix actual diagnostics','Normal-build StockLogicalSourceWitness complete eleven-root composition','Bundle owned/normal/MCP trust audits and parity','Finish arithmetic activation gates and land arithmetic first','Reconcile/land Mixed then logical production and every original140 obligation']}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
paths=[out/'manifest.json',Path('/tmp/stock-logical-normal-batch-attempt2.py'),Path('/tmp/stock-execute-scheduler.py'),Path('/tmp/stock-delivery-time.py'),Path('/tmp/stock-current-resume.json'),Path('/tmp/stock-ni-current-status44.md'),Path('/tmp/stock-current-ci-stage6-failure.log'),Path('/tmp/stock-logical-selected-normal/source-inputs.json'),Path('/tmp/stock-logical-selected-normal/build.log'),base/'progress.json',base/'build.log',base/'modules/sched.log']
for record in done:
 for suffix in ['.log','.time']:
  p=base/'modules'/(record['module']+suffix)
  if p.exists():paths.append(p)
archive=out/'evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=3) as tar:
 for p in paths:
  if p.exists():tar.add(p,arcname=str(p).lstrip('/'))
receipt={'archive':str(archive),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'paths':len(paths),'completed_module_records':len(done),'actual_build_records':sum(' built -> ok' in r['record'] for r in done),'partial':True}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
