from pathlib import Path
root=Path('/home/lee/clifv/.worktrees/stock-mixed-production/FV/Backend/Proof')
def section(file,start,end):
 s=(root/file).read_text();return s[s.index(start):s.index(end,s.index(start))]
def adapt(s):
 return s.replace('(subtract : Bool)','(kind : Kind)').replace('(if subtract then .isub else .iadd)','kind.cop').replace('cases subtract','cases kind').replace('[instOutcome]','[Kind.cop,instOutcome]').replace('[instOutcome,Clif.evalInst','[Kind.cop,instOutcome,Clif.evalInst')
operands=adapt(section('StockAddSubSourceValues.lean','theorem stock_lower_addsub_source_operands','theorem stock_lower_addsub_fused_available_source')).replace('stock_lower_addsub_source_operands','source_operands')
available=adapt(section('StockAddSubAllSourceValues.lean','theorem stock_lower_addsub_available_source','theorem stock_lower_addsub_source_by_instruction')).replace('stock_lower_addsub_available_source','available_source').replace('stock_lower_addsub_available_values','LogicalSelected.stock_lower_logical_available_values')
fromstep=adapt(section('StockAddSubAllSourceValues.lean','theorem stock_lower_addsub_source_by_instruction','end Backend.Stock.Proof.ScalarAddSub')).replace('stock_lower_addsub_source_by_instruction','source_from_step').replace('stock_lower_addsub_source_operands','source_operands').replace('stock_lower_addsub_available_source','available_source')
for name in ['available','fromstep']:
 s=locals()[name];s=s.replace('(emitted : step.decision = .emitted)','(emitted : step.decision = .emitted)\n    (selectedId : step.rules.getLast? = some kind.rule.id)');s=s.replace('mapped recorded emitted refines','mapped recorded emitted selectedId refines');locals()[name]=s
old=(root/'StockLogicalRecordValues.lean').read_text();a=old.index('theorem stock_lower_logical_available_values');b=old.index(' := by',a);helper=old[a:b].replace('theorem stock_lower_logical_available_values','private theorem not_values_same_order').replace('(kind : Kind)','(kind : Kind) (left : Bool)').replace('some kind.rule.id','some (LogicalNot.notRule kind left).id')+''' := by
  cases left with
  | false => exact LogicalNot.stock_lower_logical_not_available_values
      run scope dominated events records block statement current kind false source clif results statementResults
      mapped recorded emitted selectedId refines dfg held sourceX sourceY
  | true => exact LogicalNot.stock_lower_logical_not_available_values (x := y) (y := x)
      run scope dominated events records block statement current kind true source clif results statementResults
      mapped recorded emitted selectedId refines dfg held sourceY sourceX

'''
notavailable=available.replace('theorem available_source','theorem not_available_source').replace('(kind : Kind)','(kind : Kind) (left : Bool)').replace('some kind.rule.id','some (LogicalNot.notRule kind left).id').replace('LogicalSelected.stock_lower_logical_available_values','not_values_same_order').replace('block statement current kind source','block statement current kind left source')
notfromstep=fromstep.replace('theorem source_from_step','theorem not_source_from_step').replace('(kind : Kind)','(kind : Kind) (left : Bool)').replace('some kind.rule.id','some (LogicalNot.notRule kind left).id').replace(':= available_source',':= not_available_source').replace(' := available_source',' := not_available_source').replace(' :=\n    available_source',' :=\n    not_available_source').replace(' :=\n    stock_lower',' :=\n    stock_lower')
notfromstep=notfromstep.replace('⟨ρ\',execution,value,memEq,kept,post⟩ := available_source','⟨ρ\',execution,value,memEq,kept,post⟩ := not_available_source')
notfromstep=notfromstep.replace('⟨ρ\',execution,value,memEq,kept,post⟩ :=\n    available_source','⟨ρ\',execution,value,memEq,kept,post⟩ :=\n    not_available_source')
# Add left only to the value-transfer call, keeping the common original-source operand derivation.
notfromstep=notfromstep.replace('run scope dominated events records block statement current kind source','run scope dominated events records block statement current kind left source')
header='''import FV.Backend.Proof.StockLogicalRecordValues
import FV.Backend.Proof.StockLogicalNotRecord
import FV.Backend.Proof.StockAddSubSourceValues

namespace Backend.Stock.Proof.LogicalComplete
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open LogicalSelected
set_option autoImplicit false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm

'''
s=header+operands+available+fromstep+helper+notavailable+notfromstep+'\nend Backend.Stock.Proof.LogicalComplete\n'
for n in ['source_operands','available_source','source_from_step','not_available_source','not_source_from_step']:s+='\n#print axioms Backend.Stock.Proof.LogicalComplete.'+n+'\n'
s+='''
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let mut count : Nat := 0
  for (name,_) in env.constants.toList do
    if (env.getModuleIdxFor? name).isSome then continue
    for ax in ← collectAxioms name do
      unless #[``propext,``Classical.choice,``Quot.sound].contains ax do
        throwError "unexpected axiom {ax} in {name}"
    count := count+1
  logInfo m!"LOGICAL_SOURCE_TRANSFER_STANDARD_ONLY {count}"
'''
Path('/tmp/StockLogicalSourceTransfer.lean').write_text(s);print({'lines':len(s.splitlines())})
