import json,re,hashlib
from pathlib import Path
baseline=json.loads(Path('docs/research/stock-logical-values-audit.json').read_text())
log=Path('/tmp/stock-logical-record-axioms.log').read_text()
roots={n:sorted(set(a.strip() for a in ax.split(',') if a.strip())) for n,ax in re.findall(r"'([^']+)' depends on axioms: \[([^]]*)\]",log,re.S)}
assert roots, 'No theorem audits found'
final={}
for name,prior in baseline['axiom_roots'].items():
 current=roots[name]
 if isinstance(prior,list):
  assert current==sorted(set(prior)), (name,prior,current)
 else:
  digest=hashlib.sha256('\n'.join(current).encode()).hexdigest()
  assert len(current)==prior['count'] and digest==prior['sorted_axioms_sha256'],(name,prior,len(current),digest)
  final[name]={'count':len(current),'sorted_axioms_sha256':digest}
new=Path('/tmp/stock-logical-record-new-roots.txt').read_text().splitlines()
standard={'propext','Classical.choice','Quot.sound'}
for name in new: assert set(roots[name])<=standard,(name,roots[name])
summary={'previous_audit':'docs/research/stock-logical-values-audit.json','previous_roots_checked':len(baseline['axiom_roots']),'previous_axiom_sets_unchanged':True,'new_roots':{name:roots[name] for name in new},'final_compiler_roots':final}
Path('/tmp/stock-logical-record-audit-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(f"PASS: {len(roots)} roots; all {len(baseline['axiom_roots'])} prior sets unchanged; {len(new)} new standard-only roots")
