from pathlib import Path
import os,json,datetime,tarfile,hashlib,io,subprocess
os.nice(10)
root=Path('/tmp/stock-logical-current-verified-recovery-final');root.mkdir(exist_ok=True)
paths=set()
for pattern in ['stock-logical-core-priority*','stock-logical-record-source-priority*','stock-extr-core-normal-audit*','stock-logical-compact-witness*']:
 for p in Path('/tmp').glob(pattern):
  if p.is_file():paths.add(p)
  elif p.is_dir():paths.update(q for q in p.rglob('*') if q.is_file() and q.suffix in ['.log','.time','.json','.txt','.py','.lean'])
for p in ['/tmp/stock-current-resume.json','/tmp/stock-ni-current-status44.md','/tmp/stock-stage-contract-corrected-build.log','/tmp/stock-execute-scheduler.py','/tmp/stock-delivery-time.py','/tmp/stock-logical-normal-batch-attempt2.py','/tmp/stock-logical-selected-normal-attempt2/progress.json','/tmp/stock-logical-selected-normal-attempt2/modules/sched.log','/tmp/stock-logical-selected-normal/source-inputs.json','/tmp/stock-logical-selected-normal/source-inputs-before-narrow-imports.json']:
 if Path(p).exists():paths.add(Path(p))
files={}
archive=root/'evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=3) as tar:
 for p in sorted(paths):
  data=p.read_bytes();name=str(p).lstrip('/');files[str(p)]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)};info=tarfile.TarInfo(name);info.size=len(data);info.mtime=int(p.stat().st_mtime);tar.addfile(info,io.BytesIO(data))
 manifest={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':'nine_normal_EXTR_semantic_modules_and_six_Std3_roots_passed_complete_witness_and_activation_pending','source_branch':'agent/stock-logical-current-model','source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd='/home/lee/clifv/.worktrees/stock-mixed-production',text=True).strip(),'files':files,'live_or_queued_handles':[2186400,2201390,3244768,3249812,3369724,3349630,1235132,1235140],'active_logs_are_partial_snapshots_not_passes':True}
 data=(json.dumps(manifest,indent=2)+'\n').encode();info=tarfile.TarInfo('snapshot-manifest.json');info.size=len(data);tar.addfile(info,io.BytesIO(data))
(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
r={'archive':str(archive),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'paths':len(files)+1,'source_head':manifest['source_head']};(root/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
