from pathlib import Path
import os,signal,subprocess as sp,time,json,datetime,hashlib,sys
root=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');sched=3016520
out=Path('/tmp/stock-logical-drain-check');out.mkdir(exist_ok=True)
source=Path('/tmp/StockLogicalDispatch.lean');source_hash=hashlib.sha256(source.read_bytes()).hexdigest()
head=sp.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert head=='087e91d1615c8c944e560c050c1eb7c60981d205'
assert b'stock-execute-scheduler.py' in Path(f'/proc/{sched}/cmdline').read_bytes()
env=dict(os.environ,PATH='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:'+os.environ['PATH'],FV_MEMCAP='8G',FV_LAKE_CACHE='/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache',LEAN_NUM_THREADS='2',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2')
def report(state,**kw):
 d={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':state,'pid':os.getpid(),'scheduler_pid':sched,'source_sha256':source_hash,'frozen_head':head,**kw};(out/'progress.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)
stopped=False
try:
 os.kill(sched,signal.SIGSTOP);stopped=True
 deadline=time.monotonic()+120
 report('waiting_for_existing_kernels_without_interrupting')
 while True:
  kids=Path(f'/proc/{sched}/task/{sched}/children').read_text().split();live=[k for k in kids if Path(f'/proc/{k}/stat').exists() and Path(f'/proc/{k}/stat').read_text().split()[2]!='Z']
  if not live:break
  assert time.monotonic()<deadline,'existing kernel still live; retain it and return launcher'
  time.sleep(.2)
 report('running_solo_scratch',cap_GiB=8,log=str(out/'dispatch.log'))
 with (out/'dispatch.log').open('w') as log:
  p=sp.run([str(root/'scripts/memcap.sh'),'lake','env','lean','--root=/tmp',str(source)],cwd=root,env=env,stdout=log,stderr=sp.STDOUT,timeout=180)
 assert sp.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head
 assert hashlib.sha256(source.read_bytes()).hexdigest()==source_hash
 report('passed' if p.returncode==0 else 'failed',returncode=p.returncode,log=str(out/'dispatch.log'))
except BaseException as e:
 report('failed',error=repr(e));raise
finally:
 if stopped:os.kill(sched,signal.SIGCONT)
 print(json.dumps({'scheduler_resumed':True}),flush=True)
