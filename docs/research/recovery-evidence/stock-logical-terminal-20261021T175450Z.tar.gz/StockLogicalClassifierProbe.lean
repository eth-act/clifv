import FV.Backend.StockLogicalCheck
import FV.Backend.Proof.StockLogicalFixtures
open Backend.Stock.Proof.LogicalSemantics Backend.Proof.Driver
#eval Backend.Stock.Logical.eligible (formFunction .registers)
#eval lowerScopeB (formFunction .registers)
#eval dominatedB (formFunction .registers)
#eval Backend.sigAbiOk (formFunction .registers).sig
#eval Backend.Stock.Logical.sourceOk (formFunction .registers)
