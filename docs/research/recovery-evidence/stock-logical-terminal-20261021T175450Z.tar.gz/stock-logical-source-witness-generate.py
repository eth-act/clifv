from pathlib import Path
import re
root=Path('/home/lee/clifv/.worktrees/stock-mixed-production/FV/Backend/Proof')
core=Path('/tmp/StockLogicalSourceTransfer.lean').read_text()
names=[l.split('WITNESS_NAME ',1)[1] for l in Path('/tmp/stock-mixed-draft-check/logical-witness-names-typed.log').read_text().splitlines() if 'WITNESS_NAME ' in l]
lookup={n.rsplit('.',1)[1]:n for n in names}
aliases={'function':'oldNotFunction','inputs':'oldNotInputs','frame':'oldNotFrame','scope':'oldNotScope','dominated':'oldNotDominated','frame_available':'oldNotAvailable','regs':'oldNotRegs','rrFrame':'oldRrFrame','rrDominated':'oldRrDominated','rrRestricted':'oldRrRestricted'}
fields=['result','event','record','info','step','run','events','records','current','source','clif','results','mapped','recorded','emitted','selectedId','dfg','held']
for field in fields:
 aliases['Input_'+field]='oldNotInput'+field[0].upper()+field[1:]
 lookup['Input_'+field]=lookup['inputs'].rsplit('.',1)[0]+'.Inputs.'+field
entries=',\n    '.join('("'+aliases[k]+'", "'+lookup[k]+'")' for k in aliases)
pre='''import FV.Backend.Proof.StockLogicalNotRecordWitness
import FV.Backend.Proof.StockLogicalSourceWitness
'''
aliascode='''
open Lean Elab Command
-- Test-only aliases refer to the existing checked concrete witnesses. The
-- kernel checks each definition; no private name enters the production module.
run_cmd do
  let aliases : List (String × String) := [ENTRIES]
  for (newName, oldText) in aliases do
    let env ← getEnv
    let some (oldName,info) := env.constants.toList.find? (fun (name,_) => name.toString == oldText)
      | throwError "missing pinned witness {oldText}"
    liftCoreM <| addDecl <| .defnDecl {
      name := Name.mkSimple newName
      levelParams := info.levelParams
      type := info.type
      value := mkConst oldName (info.levelParams.map Level.param)
      hints := .abbrev
      safety := .safe }

namespace Backend.Stock.Proof.LogicalSourceTests
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open LogicalSelected LogicalComplete LogicalSemantics
set_option autoImplicit false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
'''.replace('ENTRIES',entries)
s=(root/'StockLogicalNotRecordWitness.lean').read_text();s=s[s.index('theorem stock_lower_logical_not_source_values_witness'):s.index('end Backend.Stock.Proof.LogicalNot.MirrorWitness')]
s=s.replace('stock_lower_logical_not_source_values_witness','mirrored_source_witness')
for old,new in aliases.items():
 if old.startswith('rr'):continue
 s=re.sub(r'(?<![\w.])'+old+r'\b(?!\s*:=)',new,s)
a=s.index('  have getX :');b=s.index('  have restrictedDFG',a);s=s[:a]+s[b:]
a=s.index('  obtain ⟨ρ\',execution,value,kept,installed⟩ :=');b=s.index('  let val :',a);s=s[:a]+s[b:]
a=s.index('  have sourceHeld := source_single_result_values');b=s.index('  exact ⟨',a)
s=s[:a]+'''  obtain ⟨u,v,ρ',getU,getV,execution,value,memory,kept,sourceHeld⟩ :=
    not_source_from_step input.run (oldNotScope kind left ty supported)
      (oldNotDominated kind left ty supported) input.events input.records block statement current kind left
      input.source input.clif input.results rfl input.mapped input.recorded input.emitted input.selectedId
      self restrictedDFG guarded sourceStep
'''+s[b:]
for field in sorted(fields,key=len,reverse=True):
 s=re.sub(r'input\.'+field+r'\b','('+aliases['Input_'+field]+' input)',s)
# Base OR witness uses the original concrete register fixture, with getters now
# derived inside the new theorem instead of supplied by this test.
t=(root/'StockLogicalSourceWitness.lean').read_text();t=t[t.index('theorem stock_lower_logical_source_values_witness'):t.index('end Backend.Stock.Proof.LogicalSelected')]
t=t.replace('stock_lower_logical_source_values_witness','base_source_witness')
for old,new in aliases.items():
 if not old.startswith('rr'):continue
 t=re.sub(r'(?<![\w.])'+old+r'\b',new,t)
a=t.index('  have sourceX :');b=t.index('  have restrictedDFG',a);t=t[:a]+t[b:]
a=t.index('  obtain ⟨ρ\',execution,value,kept,installed⟩ :=');b=t.index('  let val :',a);t=t[:a]+t[b:]
a=t.index('  have sourceHeld := source_single_result_values');b=t.index('  exact ⟨',a)
t=t[:a]+'''  obtain ⟨u,v,ρ',getU,getV,execution,value,memory,kept,sourceHeld⟩ :=
    source_from_step input.run (formScope .registers) oldRrDominated input.events input.records
      block statement current .bor input.source input.clif input.results rfl input.mapped
      input.recorded input.emitted input.selectedId self restrictedDFG guarded sourceStep
'''+t[b:]
end='''
end Backend.Stock.Proof.LogicalSourceTests
#print axioms Backend.Stock.Proof.LogicalSourceTests.mirrored_source_witness
#print axioms Backend.Stock.Proof.LogicalSourceTests.base_source_witness
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let mut count : Nat := 0
  for (name,_) in env.constants.toList do
    if (env.getModuleIdxFor? name).isSome then continue
    for ax in ← collectAxioms name do
      unless #[``propext,``Classical.choice,``Quot.sound].contains ax do
        throwError "unexpected axiom {ax} in {name}"
    count := count+1
  logInfo m!"LOGICAL_SOURCE_TRANSFER_WITH_WITNESSES_STANDARD_ONLY {count}"
'''
Path('/tmp/StockLogicalSourceTransferWitness.lean').write_text(pre+core+aliascode+s+t+end)
