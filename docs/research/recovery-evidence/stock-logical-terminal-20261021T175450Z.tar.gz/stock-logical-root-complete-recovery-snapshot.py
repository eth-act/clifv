from pathlib import Path
import os,json,datetime,tarfile,hashlib,io,subprocess
os.nice(10);out=Path('/tmp/stock-logical-root-complete-recovery');out.mkdir(exist_ok=True)
paths=set()
for pattern in ['stock-logical-root-complete-handoff*','stock-logical-compact-witness*','stock-extr-core-normal-audit*','stock-logical-core-priority*','stock-logical-record-source-priority*']:
 for p in Path('/tmp').glob(pattern):
  if p.is_file():paths.add(p)
  elif p.is_dir():paths.update(q for q in p.rglob('*') if q.is_file() and q.suffix in ['.log','.time','.json','.txt','.py','.lean','.trace'])
old=Path('/tmp/stock-logical-selected-normal-attempt2')
paths.update(q for q in (old/'modules').iterdir() if q.suffix in ['.log','.time'])
for name in ['/tmp/stock-current-resume.json','/tmp/stock-ni-current-status44.md','/tmp/stock-logical-normal-batch-attempt2.py','/tmp/stock-stage-contract-corrected-build.log','/tmp/stock-execute-scheduler.py','/tmp/stock-delivery-time.py','/tmp/stock-arithmetic-arm-model-author-gates.py','/tmp/stock-arithmetic-arm-model-ready-to-land.py',str(old/'progress.json'),str(old/'arithmetic-resumed.json'),'/tmp/stock-arithmetic-arm-model-author-gates/progress.json']:
 if Path(name).exists():paths.add(Path(name))
files={};archive=out/'evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=3) as tar:
 for p in sorted(paths):
  data=p.read_bytes();name=str(p).lstrip('/');files[str(p)]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)};info=tarfile.TarInfo(name);info.size=len(data);info.mtime=int(p.stat().st_mtime);tar.addfile(info,io.BytesIO(data))
 manifest={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':'complete_checked_in_EXTR_witness_normal_and_single_MCP_passed_arithmetic_first_landing_resumed','source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd='/home/lee/clifv/.worktrees/stock-mixed-production',text=True).strip(),'normal_general_roots':6,'normal_fixed_witness_roots':3,'actual_pipeline_cases':24,'current_target_modules':440,'old777_full_pass_claimed':False,'source_body_layer_normal_validation_pending':True,'aligned_logical_replay_pending':True,'arithmetic_controller':1235132,'arithmetic_scheduler':1235140,'full_original_goal_complete':False,'files':files}
 data=(json.dumps(manifest,indent=2)+'\n').encode();info=tarfile.TarInfo('snapshot-manifest.json');info.size=len(data);tar.addfile(info,io.BytesIO(data))
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');r={'archive':str(archive),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'paths':len(files)+1,'source_head':manifest['source_head']};(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
