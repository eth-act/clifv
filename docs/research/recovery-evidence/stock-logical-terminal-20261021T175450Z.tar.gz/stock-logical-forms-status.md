Persistent status for @codygunton and agents working for this contributor. Edit this body; keep this issue open.

Current: Read-only explanation of the i128 alias-to-copy change and its validator/proof requirements. Historical source and commit a848be2 checked; no broader policy decision or new compiler/proof changes inferred. Existing diagnostic report remains local and complete.
Task: User diagnostic report; no proof WP claimed and no PR opened. Report: docs/research/stock-artifact-mismatch-sample.md; source run https://github.com/eth-act/clifv/actions/runs/37265516388.
Branch / latest commit: main; c8e1bdec10881f66700846b622a32cf54ce36fbf (published base). Report and evidence changes are local, uncommitted, unpublished.
Likely changes: docs/STOCK-COMPILER-COMPARISON.md; docs/research/stock-artifact-mismatch-sample.md; docs/research/artifact-mismatch-sample/ (manifest, 32 source/code/metadata snapshots, reproduction and verification scripts). No compiler/proof changes.
Verification: All 32 comparisons recomputed from archived stock buffers and Lean ELF objects; settings receipts and stock repeats verified; source hashes match checkout; evidence reproduced byte-for-byte; every report identity, size and local link checked. No generated-function execution tests performed.
Next, tentatively: Prioritize use-aware lowering/dead selected instruction removal, i128 simplification and remaining isolated gaps if requested; no task reserved.
State: idle
Updated: 2026-10-05T13:23:08Z


### Claude agent: byte agreement leads

Current: Daily reports in #46 are now one table with the change in each row (#74, merged by the user as ec161c4). Rewrote #46's intro and re-rendered its two existing bot reports in the new format (edited in place, same digest markers). Bot-managed section untouched.
Task: daily report format (#46), done; leads stay in #59 (no work package).
Branch / latest commit: main ec161c4. Worktree /home/lee/clifv/.worktrees/report-tables (branch merged).
Likely changes: none pending. No compiler or proof changes.
Next, tentatively: lead 5 (VCode/vreg numbering) and lead 4 (29 framed outputs) in #59; both read-only.
State: idle
Updated: 2026-10-06T19:59:39Z

### Codex agent: stock instruction selection

- State: idle; 2026-10-10T22:58:58.377940+00:00.
- Completed goal/task: narrow legacy-driver dead-instruction cleanup #60. Measurement #136 and proved/default-enabled implementation #137 are squash-merged. Replacement-driver #135 remains paused; no broader work resumed.
- Branch/commit: `agent/legacy-dead-cleanup-proof`, published final head `0bd8e7c`; landed main `bc3a34cf018ea024ef8df4b3bda3fde28ebd5874`. Head-locked squash and exact landed-tree equality verified. Active worktree `/home/lee/clifv/.worktrees/legacy-dead-cleanup-proof`; original branches and primary dirty diagnostic report preserved.
- Modules: conservative `FV/Backend/DeadCleanup`; prepared proof transports; matched E2E/compiler/linker/generated-proof consumers, defaults and lowering diagnostics. Original driver, theorem variants and baseline source scope retained.
- Validation: normal full 1417 jobs and crates 1171 jobs pass at validated source `735a762` and rerun on final head `0bd8e7c`, whose compiler/proof sources are unchanged. All three final-head CI checks pass, run 38093094760. Runtime 114/114 corpus, 22/22 external runtime, 4672 passing runtests with zero failures/errors/disagreements and unchanged seven native-unsupported cases. Stack allocator 114/114 and 22/22. Encoder 1292 identical/0 differ; 1332 relocations. Both E2E modes preserve all 1150 identities and successful stages, including 161 legalized identities. Python 79 pass/two skips. Fresh stock comparison 465 -> 671 (+206), zero lost identities/new rejections, all three focused cases exact.
- Proof audits: exact original/cleanup axiom-set parity: final/executable instruction 764, spill checker 113, linked-input completeness 826, optimizer-proven 8937, legalization direct 884, totality 803, emission from input 819, input-size totality 853, executable correctness/totality 830/823. No disallowed additions. Optimizer MCP diagnostics, verification and source scan pass and match the capped audit. Actual deletion, compiler/linker and generated one/split witnesses pass. Original source declaration inventory has no missing occurrences; it is not a kernel proof count. Receipts and plan are committed in #137.
- Coordination: Kev #52 still reports unpublished T6 work; #137 preserves original fixed-proof statements and makes no `movK_ident` change. Historical replacement-driver work remains deferred in #135.
- Tentative next: await user decision on additional agreement work; no reservation and no active proof migration.

### Codex agent: worktree location migration

Current: Migration complete: all nine linked worktrees now under ~/clifv/.worktrees, original branch tips and dirty-file contents verified. AGENTS, ignore rules, primary creation helper and workflow docs updated. User requested resuming #60; V5 is now landed and active V6/L3 work is outside source-lowering ownership.
Task: Worktree housekeeping, then #60. No additional proof WP claimed.
Branch / latest commit: main f866008 (worktree housekeeping commit local/unpublished); agent/stock-lowering b6ca3ea (local/unpublished).
Likely modules: AGENTS.md, .gitignore, scripts/agent-worktree.sh, docs/TO-PROVE.md, docs/ARCHITECTURE.md; Git worktree registration and directories; plan's current location note.
Next, tentatively: Resume #60 implementation preserving current V6/L3 downstream theorem contracts; no next task reserved.
State: active (#60 implementation resumed)
Updated: 2026-10-06T13:35:32Z

### Codex agent: movK_ident investigation

- State: idle; completed read-only investigation; 2026-10-11T02:09:36.800292+00:00.
- Result: current movK_ident proves MOVK masked slice replacement equals subtraction/addition; six bv_decide dependencies confirmed with Lean MCP. Stock constant transfer inherits exactly those six. Published #137 did not modify IselLcf/IselContract/StockImm/StockAliasSemantics. No semantic/interface conflict found with Kev's proposed proof-only, same-statement migration.
- Task/boundary: #42 remains Kev-owned; no proof WP claimed or implementation changed. Recommend preserving statement and runtime definitions, replacing only proof/helpers, adding fresh reduced-axiom audits for legacy/cleanup roots and Stock constants; retain historical receipts. Kev's unpublished 131de61 is unavailable locally and via GitHub, so its patch could not be reviewed.
- Branch/commit: published main bc3a34c; inspected matching validated agent/legacy-dead-cleanup-proof 0bd8e7c. Primary checkout/dirty report preserved.
- Modules inspected: FV/Backend/Proof/IselLcf.lean, IselContract.lean, StockImm.lean, StockAliasSemantics.lean; constant and final cleanup axiom receipts.
- Tentative next: await user direction; no reservation. Replacement-driver #135 remains paused.

### Codex agent: movK_ident handoff

- State: idle; completed; 2026-10-11T02:46:44.924459+00:00.
- Result: user-authorized acknowledgment posted: https://github.com/eth-act/clifv/issues/42#issuecomment-6104740250. Kev can proceed with proof-only, same-statement movK_ident migration; no competing implementation/claim. Historical receipts retained; fresh current-main audits recommended.
- Branch/commit: published main bc3a34c; draft #135 on agent/stock-input-noalias-pr; .worktrees/stock-driver-production preserved. No code changes or PRs created.
- Tentative next: await user decision on deferred replacement driver; #135 remains paused, no reservation.

### Codex agent: post-cleanup 96-case disagreement sample

- State: idle; completed report and published review; 2026-10-11T14:02:37.931444+00:00.
- Task/PR: user-requested 96-case sample completed in https://github.com/eth-act/clifv/pull/138. Single seeded draw from939 main-bc3a34c disagreements; no compiler/proof changes or WP claimed.
- Branch/commit: published agent/artifact-sample-96 at 141117a; worktree /home/lee/clifv/.worktrees/artifact-sample-96.
- Modules: docs/research/artifact-mismatch-sample-96.md and evidence/manifest/classification/reproduction/verification scripts. All96 sources, receipts, stock repeats, ELF comparison rows and disassemblies independently checked; all snapshots/draw reproduced byte-for-byte, source provenance/counts/links verified.
- Results: register33/frame16/repeated-compare16/i12814/retained-pure13/instruction-order1/CFG-layout1/atomic-extension1/dead-notrap-load1. Root-cause certainty and mixed cases explicit; no prediction that any one change guarantees byte agreement.
- Tentative next: await prioritization or report review; no task reserved. Replacement-driver #135 remains paused.

### Codex agent: worktree cleanup

- State: idle; completed; 2026-10-11T23:25:04.873323+00:00.
- Result: removed20 obsolete worktrees, retained5 linked checkouts, reclaimed148.53GiB (available199GiB). All original branches and explicit archive refs retained; detached tips also anchored. Uncommitted files/staging state, source snapshots and ignored target evidence preserved in /home/lee/.clifv-worktree-archive/20261011T232414Z; RESTORE.md and per-tree manifests record recovery. Dirty files verified in source archives before removal.
- Retained: artifact-sample-96 (#138 review), legacy-dead-cleanup-proof (validated warm baseline), stock-foundations-pr (paused draft #135), stock-driver-production (paused driver development), stock-lowering (original dirty migration). All retained heads/dirty states and primary dirty report unchanged.
- Branch/commit: primary test-push f866008; no compiler/proof/source commits. Removed worktree paths in historical status entries are archival paths now; their branches remain recoverable.
- Tentative next: await user direction/review; no task reservation and replacement driver remains paused.

### Codex agent: consolidate disagreement investigation

- State: idle; completed and published; 2026-10-12T09:14:00.708954+00:00.
- Task/PR: https://github.com/eth-act/clifv/pull/138 updated with docs/research/compiler-artifact-disagreements.md: all32 historical and96 current case analyses, provenance, limitations, opportunity ranking and paused-WIP relationship. Former report paths redirect; evidence stays separate and unchanged.
- Branch/commit: published agent/artifact-sample-96 at f294436; .worktrees/artifact-sample-96.
- Validation: all128 analyses and local links checked; historical evidence copied byte-for-byte; primary dirty report untouched. Existing96 snapshot/receipt/repeat/ELF/disassembly verification retained. No compiler/proof changes or WP claimed.
- Tentative next: await review/prioritization; register alignment is part of broader paused driver work, not evidence that full driver replacement is necessary. Draft135 remains paused.

### Codex agent: minimal register alignment

- State: checkpoint published; broader active goal continues; 2026-10-12T11:41:25.223044+00:00.
- Task/PR: https://github.com/eth-act/clifv/pull/139 (CI running), actual opt-in wrapper671->959 (+288/-0), zero new rejections,28/33 focused matches. Full1422/crates1171, E2E1150/0, runtime114+22+4672 with zero failures/errors/disagreements and7knownnonrunnable, encoder1292/0,8tests all pass.1366fresh receipts/161reference repeats/all1610 baseline rows reverified. Compiler/proof/defaults unchanged.
- Branch/commit: published agent/register-alignment; .worktrees/register-alignment. Receipts/plan committed.
- Active full goal/task: #140 https://github.com/eth-act/clifv/issues/140, completing new driver proofs and switching production. Not satisfied by the wrapper. Preserved alias slice135 now applied cleanly to fresh-main .worktrees/driver-proof-resume (agent/driver-proof-resume, local/unpublished basebc3a34c); normal full build running in memory cap.
- Modules: alias proof connection/SSA/recorded flow and existing audit receipt only at resumed checkpoint. No T6/IselLcf/optimizer-proof overlap; baseline interfaces retained. Old paused worktrees unchanged.
- Tentative next: validate/land alias slice with current-main gates; then source-available final paths/reservation semantics/noninterference/whole simulation-completeness and real production cutover. No broad completion claim.

Latest coordination update UTC: 2026-10-12T11:43:34.349784+00:00. PR139 published at c8f60b9. Goal140 claimed; resumed alias proof build handle23389 last confirmed running. Primary dirty report and archived work remain preserved.

### Codex agent: active driver proof cutover #140

Goal: Complete actual Stock driver proofs and switch production with baseline input/proof parity. #140 active/claimed.
Current: Logical immediate/shift helper slice validated; published PR172; CI running. Seven new Std3 roots; all173 normal roots preserve prior sets, full1454/crates1171/runtime4672/0/0 with7knownnotrunnable/encoder1292/0/E2E1150/0 pass; all E2E identities/stages unchanged.
Branch/commit: agent/stock-logical-forms-pr, published8025f6b; .worktrees/driver-proof-resume.
Modules: StockLogicalForms; focused plan/audit. No runtime/compiler change; T6 boundary retained.
Next, tentative: selected logical helper/root composition and value semantics; remaining families/effects, whole simulation/completeness and production switch remain.
State: active
Updated UTC: 2026-10-13T00:22:02.565103+00:00
