import Crates.StockLogical2CleanupFallbackGlobal
import Crates.StockLogical2PlainFallbackGlobal
import Crates.StockLogical2RetainedCleanupFallbackGlobal
import Crates.StockLogical2RetainedPlainFallbackGlobal
import Crates.StockLogical33CleanupFallbackEntries
import Crates.StockLogical33CleanupFallbackGlobal
import Crates.StockLogical6CleanupFallbackGlobal
import Crates.StockLogical6CleanupStrictGlobal
import Crates.StockLogical6MixedCleanupFallbackGlobal
import Crates.StockLogical6MixedPlainFallbackGlobal
import Crates.StockLogical6PlainFallbackGlobal
import Crates.StockLogical6PlainStrictGlobal
import Crates.LogicalCLIcurrentPlain
import Crates.LogicalCLIretainedPlain
import Crates.LogicalCLIcurrentCleanup
import Crates.LogicalCLIretainedCleanup
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let generated := fun (name : Name) =>
    name.toString.startsWith "Crates.StockLogical" || name.toString.startsWith "Crates.LogicalCLI"
  let mut count : Nat := 0
  for (name, _) in env.constants.toList do
    unless generated name do continue
    for ax in ← collectAxioms name do
      if #[``propext, ``Classical.choice, ``Quot.sound].contains ax then continue
      unless generated ax && (ax.toString.splitOn "._native.native_decide.ax_").length > 1 do
        throwError "unexpected generated-proof axiom {ax} in {name}"
    count := count + 1
  unless count > 0 do throwError "empty generated-proof audit"
  logInfo m!"STOCK_LOGICAL_GENERATED_AXIOMS_PASS {count}"
