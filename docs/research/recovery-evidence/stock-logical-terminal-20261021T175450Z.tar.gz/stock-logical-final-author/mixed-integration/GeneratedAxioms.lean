import Crates.StockMixed2CleanupFallbackGlobal
import Crates.StockMixed2PlainFallbackGlobal
import Crates.StockMixed2RetainedCleanupFallbackGlobal
import Crates.StockMixed2RetainedPlainFallbackGlobal
import Crates.StockMixed33CleanupFallbackEntries
import Crates.StockMixed33CleanupFallbackGlobal
import Crates.StockMixed6CleanupFallbackGlobal
import Crates.StockMixed6CleanupStrictGlobal
import Crates.StockMixed6MixedCleanupFallbackGlobal
import Crates.StockMixed6MixedPlainFallbackGlobal
import Crates.StockMixed6PlainFallbackGlobal
import Crates.StockMixed6PlainStrictGlobal
import Crates.MixedCLIcurrentPlain
import Crates.MixedCLIretainedPlain
import Crates.MixedCLIcurrentCleanup
import Crates.MixedCLIretainedCleanup
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let generated := fun (name : Name) =>
    name.toString.startsWith "Crates.StockMixed" || name.toString.startsWith "Crates.MixedCLI"
  let mut count : Nat := 0
  for (name, _) in env.constants.toList do
    unless generated name do continue
    for ax in ← collectAxioms name do
      if #[``propext, ``Classical.choice, ``Quot.sound].contains ax then continue
      unless generated ax && (ax.toString.splitOn "._native.native_decide.ax_").length > 1 do
        throwError "unexpected generated-proof axiom {ax} in {name}"
    count := count + 1
  unless count > 0 do throwError "empty generated-proof audit"
  logInfo m!"STOCK_MIXED_GENERATED_AXIOMS_PASS {count}"
