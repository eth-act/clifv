from pathlib import Path
import os,json,datetime,hashlib,tarfile,io,subprocess
os.nice(10);root=Path('/tmp/stock-logical-source-run-progress-recovery');root.mkdir(exist_ok=True)
base=Path('/tmp/stock-arithmetic-arm-model-author-gates');paths=[Path('/tmp/stock-current-resume.json'),Path('/tmp/stock-ni-current-status44.md'),base/'progress.json',base/'inputs.json',base/'all-modules/sched.log',Path('/tmp/stock-arithmetic-arm-model-author-gates.py'),Path('/tmp/stock-arithmetic-arm-model-ready-to-land.py')]
for n in ['IselSzTab','IselTermFactsCallT']:
 for suffix in ['.log','.time']:paths.append(base/'all-modules'/('FV.Backend.Proof.'+n+suffix))
view=Path('/home/lee/clifv/.worktrees/stock-mixed-production');source_files=['FV/Backend/Proof/StockLogicalSourceExecution.lean','FV/Backend/Proof/StockLogicalSourceWitness.lean','scripts/audit/stock-logical-complete-values.lean']
manifest={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':'new_logical_actual_source_run_bridge_pushed_normal_validation_pending_arithmetic_author_gates_active','source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=view,text=True).strip(),'source_sha256':{p:hashlib.sha256((view/p).read_bytes()).hexdigest() for p in source_files},'arithmetic_controller':1235132,'arithmetic_scheduler':1235140,'new_actual_source_bridge_normal_pass_claimed':False,'first_production_landing_pending':True,'full_original140_complete':False,'files':{}}
archive=root/'evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=3) as tar:
 for p in paths:
  data=p.read_bytes();manifest['files'][str(p)]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)};t=tarfile.TarInfo(str(p).lstrip('/'));t.size=len(data);tar.addfile(t,io.BytesIO(data))
 data=(json.dumps(manifest,indent=2)+'\n').encode();t=tarfile.TarInfo('snapshot-manifest.json');t.size=len(data);tar.addfile(t,io.BytesIO(data))
(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');r={'archive':str(archive),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'paths':len(paths)+1};(root/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
