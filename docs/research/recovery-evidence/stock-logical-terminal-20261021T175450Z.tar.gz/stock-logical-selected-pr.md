Derive typed AND/OR/XOR root execution receipts from actual retained Stock records. The final selected rule ID and existing source/context facts now supply width, match environment and successful RHS execution internally, using the existing rule uniqueness and selection receipts.

The witness kernel-checks complete sparse-ID runs for all three operations. Existing compiler behavior and contracts are retained. Part of #140; logical helper-case value composition and production cutover remain.

Validation: full1455/crates1171 jobs pass; runtime114+22+4672 passes with zero runnable failures/disagreements and seven unchanged not-runnable cases; encoder1292 identical/0 differ; E2E1150 accepted/0 rejected, every identity/stage field equals baseline. Lean MCP verifies all three new public roots with standard axioms, clean source scans and zero errors. Normal176-root audit preserves all173 prior sets, including seven final compiler roots. Plan/audit committed.
