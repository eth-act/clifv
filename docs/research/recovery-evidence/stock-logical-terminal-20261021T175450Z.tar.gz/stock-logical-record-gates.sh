#!/usr/bin/env bash
set -euo pipefail
cd /home/lee/clifv/.worktrees/driver-proof-resume
export PATH=/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:/home/lee/.cargo/bin:$PATH
export LEAN_NUM_THREADS=2 FV_MEMCAP=22G
scripts/memcap.sh lake build FV FVTest lean-backend lean-e2e-check link-check > /tmp/stock-logical-record-full.log 2>&1
(cd crate-proofs && ../scripts/memcap.sh lake build > /tmp/stock-logical-record-crates.log 2>&1)
CLIF_NATIVE_QEMU=/tmp/register-alignment-tools/usr/bin/qemu-aarch64-static scripts/memcap.sh bash scripts/lean-backend-filetests.sh > /tmp/stock-logical-record-runtime.log 2>&1
LLVM_MC=/home/lee/.local/share/clifv-test-tools/usr/bin/llvm-mc scripts/memcap.sh bash scripts/lean-backend-encode-check.sh > /tmp/stock-logical-record-encoder.log 2>&1
scripts/memcap.sh lake exe lean-e2e-check --identity-report /tmp/stock-logical-record-identities.json > /tmp/stock-logical-record-e2e.log 2>&1
scripts/memcap.sh lake env lean /tmp/stock-logical-record-axioms.lean > /tmp/stock-logical-record-axioms.log 2>&1
python3 /tmp/stock-logical-record-audit-check.py
