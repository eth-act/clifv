import FV.Backend.Proof.StockLogicalCheck
import FV.Backend.Proof.StockLogicalFixtures
open Backend.Stock.Proof.LogicalSemantics Backend.Proof.Driver
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
example : Backend.Stock.Logical.sourceOk (formFunction .registers) = true := by
  simp only [Backend.Stock.Logical.sourceOk,Bool.and_eq_true]
  refine ⟨⟨⟨by decide +kernel,by decide +kernel⟩,?_⟩,by decide +kernel⟩
  have unique : nodupB (valueDefs (formFunction .registers)) = true := by
    change nodupB [7,31,100] = true
    simp [nodupB,Std.HashSet.contains_insert]
  simp only [dominatedB,unique,Bool.true_and,Std.HashSet.contains_ofList]
  decide +kernel
