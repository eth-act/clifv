import FV.Backend.Proof.StockLogicalLookthrough
import FV.Backend.Proof.StockLogicalSemantics
import FV.Backend.Proof.StockLogicalSelected
import FV.Backend.Proof.StockLogicalForms
import FV.Backend.Proof.StockLogicalRrr
import FV.Backend.Proof.StockAluSelectedValues
import FV.Backend.Proof.StockSelectionReceipts
import FV.Backend.Proof.StockAluOperandCoverage
import FV.Backend.Proof.StockDemandExtent
import FV.Backend.Proof.StockAluRecordValues
import FV.Backend.Proof.StockRequestSuccess
import FV.Backend.Proof.StockDemandMono
import FV.Backend.Proof.StockGuardedRecordValues
import FV.Backend.Proof.StockFreshRecordValues
import FV.Backend.Proof.StockAlu
import FV.Backend.Proof.StockConstantRecordValues
import FV.Backend.Proof.StockAvailableValues
import FV.Backend.Proof.StockRecordIntervals
import FV.Backend.Proof.StockAliasAvailable
import FV.Backend.Proof.StockAliasTerminal
import FV.Backend.Proof.StockAliasDomain
import FV.Backend.Proof.StockSourceAliasRecords
import FV.Backend.Proof.StockSourceAliasRank
import FV.Backend.Proof.StockPayloadAliasOrigins
import FV.Backend.Proof.StockReservedTerminal
import FV.Backend.Proof.StockSourceTerminal
import FV.Backend.Proof.StockCoverageRecords
import FV.E2E.SizeIn
import FV.E2E.RelaxTotal
import FV.Link.ExeTotal
import FV.Link.Exe
import FV.E2E.LinkArm
#print axioms Backend.Stock.Proof.Coverage.statement_noOpportunity
#print axioms Backend.Stock.Proof.Coverage.branch_noOpportunity
#print axioms Backend.Stock.Proof.Coverage.emission_noOpportunity
#print axioms Backend.Stock.Proof.Coverage.statement_noOpportunity_witness
#print axioms Backend.Stock.Proof.Coverage.branch_noOpportunity_witness
#print axioms Backend.Stock.Proof.Coverage.emission_noOpportunity_witness
#print axioms Backend.Stock.Proof.Coverage.bindResults_noOpportunity
#print axioms Backend.Stock.Proof.Coverage.bindResults_noOpportunity_witness
#print axioms Backend.Stock.Proof.Coverage.retTrap_noOpportunity
#print axioms Backend.Stock.Proof.Coverage.retTrap_noOpportunity_witness
#print axioms Backend.Stock.Proof.Coverage.emission_retTrap_noOpportunity
#print axioms Backend.Stock.Proof.Coverage.emission_retTrap_noOpportunity_witness
#print axioms Backend.Stock.Proof.Coverage.scan_retTrap_noOpportunity
#print axioms Backend.Stock.Proof.Coverage.scan_retTrap_noOpportunity_witness
#print axioms Backend.Stock.Proof.Coverage.buildCtx_noOpportunity
#print axioms Backend.Stock.Proof.Coverage.buildCtx_noOpportunity_witness
#print axioms Backend.Stock.Proof.Coverage.scan_source_noOpportunity
#print axioms Backend.Stock.Proof.Coverage.scan_source_noOpportunity_witness
#print axioms Backend.Stock.Proof.Coverage.scanBlock_noOpportunity
#print axioms Backend.Stock.Proof.Coverage.scanBlock_noOpportunity_witness
#print axioms Backend.Stock.Proof.Coverage.built_scan_slots
#print axioms Backend.Stock.Proof.Coverage.built_scan_slots_witness
#print axioms Backend.Stock.Proof.Coverage.built_scanBlock_noOpportunity
#print axioms Backend.Stock.Proof.Coverage.built_scanBlock_noOpportunity_witness
#print axioms Backend.Stock.Proof.Coverage.branchArgs_noOpportunity
#print axioms Backend.Stock.Proof.Coverage.branchArgs_noOpportunity_witness
#print axioms Backend.Stock.Proof.Coverage.blockCore_noOpportunity
#print axioms Backend.Stock.Proof.Coverage.blockCore_noOpportunity_witness
#print axioms Backend.Stock.Proof.Coverage.node_noOpportunity
#print axioms Backend.Stock.Proof.Coverage.node_noOpportunity_witness
#print axioms Backend.Stock.Proof.Coverage.lower_noOpportunity
#print axioms Backend.Stock.Proof.Coverage.lower_noOpportunity_witness
#print axioms Backend.Stock.Proof.Coverage.scanBlock_records_noOpportunity
#print axioms Backend.Stock.Proof.Coverage.scanBlock_records_noOpportunity_witness
#print axioms Backend.Stock.Proof.Coverage.blockCore_records_noOpportunity
#print axioms Backend.Stock.Proof.Coverage.blockCore_records_noOpportunity_witness
#print axioms Backend.Stock.Proof.Coverage.lower_records_noOpportunity
#print axioms Backend.Stock.Proof.Coverage.lower_records_noOpportunity_witness
#print axioms Backend.Stock.Proof.Coverage.scan_noOpportunistic
#print axioms Backend.Stock.Proof.Coverage.scan_noOpportunistic_witness
#print axioms Backend.Stock.Proof.Coverage.lower_record_noOpportunistic
#print axioms Backend.Stock.Proof.Coverage.lower_record_noOpportunistic_witness
#print axioms Backend.Stock.Proof.stock_lower_undefinedSource_terminal
#print axioms Backend.Stock.Proof.stock_lower_undefinedSource_terminal_witness
#print axioms Backend.Stock.Proof.stock_lower_undefinedSource_value
#print axioms Backend.Stock.Proof.stock_lower_undefinedSource_value_witness
#print axioms Backend.Stock.Proof.allocateRequests_returnsPayloadsDisjoint
#print axioms Backend.Stock.Proof.allocateRequests_returnsPayloadsDisjoint_witness
#print axioms Backend.Stock.Proof.buildCtx_returnsPayloadsDisjoint
#print axioms Backend.Stock.Proof.buildCtx_returnsPayloadsDisjoint_witness
#print axioms Backend.Stock.Proof.stock_lower_reservedReturn_terminal
#print axioms Backend.Stock.Proof.stock_lower_reservedReturn_terminal_witness
#print axioms Backend.Stock.Proof.stock_lower_reservedReturn_resolves
#print axioms Backend.Stock.Proof.stock_lower_reservedReturn_resolves_witness
#print axioms Backend.Stock.Proof.stock_lower_reservedReturn_value
#print axioms Backend.Stock.Proof.stock_lower_reservedReturn_value_witness
#print axioms E2E.backend_correct_final_total
#print axioms E2E.backend_correct_final_total_emit_input
#print axioms E2E.backend_correct_final_total_relaxed
#print axioms E2E.LinkCheck.crate_correct_inScope_proven
#print axioms Link.compileExe_correct
#print axioms Link.compileExe_total
#print axioms Link.compileExe_spec

#print axioms Backend.Stock.Proof.stock_ctor_aliasTargetsAllowed
#print axioms Backend.Stock.Proof.stock_apply_aliasTargetsAllowed
#print axioms Backend.Stock.Proof.stock_lower_payload_aliasOrigin
#print axioms Backend.Stock.Proof.stock_lower_payload_resolves
#print axioms Backend.Stock.Proof.stock_lower_payload_terminal
#print axioms Backend.Stock.Proof.stock_lower_payload_value
#print axioms Backend.Stock.Proof.stock_ctor_aliasTargetsAllowed_witness
#print axioms Backend.Stock.Proof.stock_apply_aliasTargetsAllowed_witness
#print axioms Backend.Stock.Proof.stock_lower_payload_witness

#print axioms Backend.Stock.Proof.stock_source_provenance_rank
#print axioms Backend.Stock.Proof.stock_recorded_source_alias_provenance
#print axioms Backend.Stock.Proof.stock_recorded_source_alias_rank
#print axioms Backend.Stock.Proof.stock_recorded_source_chain_rank
#print axioms Backend.Stock.Proof.stock_recorded_source_chain_noCycle
#print axioms Backend.Stock.Proof.stock_source_provenance_rank_witness
#print axioms Backend.Stock.Proof.stock_recorded_source_chain_witness

#print axioms Backend.Stock.Proof.stock_lower_source_alias_record
#print axioms Backend.Stock.Proof.stock_lower_source_alias_emitted_record
#print axioms Backend.Stock.Proof.stock_lower_final_source_alias_recorded
#print axioms Backend.Stock.Proof.stock_lower_final_source_chain_rank
#print axioms Backend.Stock.Proof.stock_lower_final_source_chain_noCycle
#print axioms Backend.Stock.Proof.stock_lower_final_source_chain_witness

#print axioms Backend.Stock.Proof.stock_lower_alias_key_origin
#print axioms Backend.Stock.Proof.stock_lower_alias_key_origin_witness

#print axioms Backend.Stock.Proof.stock_lower_alias_wellFounded
#print axioms Backend.Stock.Proof.stock_lower_alias_terminal
#print axioms Backend.Stock.Proof.stock_lower_alias_idempotent
#print axioms Backend.Stock.Proof.stock_lower_alias_step
#print axioms Backend.Stock.Proof.stock_lower_alias_value
#print axioms Backend.Stock.Proof.stock_lower_alias_terminal_witness

#print axioms Backend.Stock.Proof.stock_lower_blockScanInitialFrontier
#print axioms Backend.Stock.Proof.stock_lower_blockScanInitialFrontier_witness
#print axioms Backend.Stock.Proof.stock_lower_source_alias_provenance
#print axioms Backend.Stock.Proof.stock_lower_source_alias_available
#print axioms Backend.Stock.Proof.stock_lower_source_path_available
#print axioms Backend.Stock.Proof.stock_lower_source_path_fresh_origin
#print axioms Backend.Stock.Proof.stock_lower_source_alias_available_witness
#print axioms Backend.Stock.Proof.stock_lower_source_path_fresh_origin_witness

#print axioms Backend.Stock.Proof.stock_lower_record_intervals
#print axioms Backend.Stock.Proof.stock_lower_record_intervals_disjoint
#print axioms Backend.Stock.Proof.stock_lower_available_alias_outside_record
#print axioms Backend.Stock.Proof.stock_lower_available_fresh_frame
#print axioms Backend.Stock.Proof.stock_lower_record_intervals_witness

#print axioms Backend.Stock.Proof.available_before_of_after_not_result

#print axioms Backend.Stock.Proof.ValuesHeld.resolvedResult_change_needed

#print axioms Backend.Stock.Proof.ValuesHeld.resolvedResult_available

#print axioms Backend.Stock.Proof.stock_iconst_available_resolved

#print axioms Backend.Stock.Proof.stock_available_values_witness

#print axioms Backend.Stock.Proof.stock_iconst_resolved

#print axioms Backend.Stock.Proof.stock_lower_record_context

#print axioms Backend.Stock.Proof.stock_lower_constant_available_values

#print axioms Backend.Stock.Proof.stock_lower_constant_available_values_witness

#print axioms Backend.Stock.Proof.stock_statement_selectedConstant_context_receipts

#print axioms Backend.Stock.Proof.stock_lower_constant_available_source

#print axioms Backend.Stock.Proof.stock_match_86

#print axioms Backend.Stock.Proof.stock_match_801

#print axioms Backend.Stock.Proof.stock_rhs_86

#print axioms Backend.Stock.Proof.stock_rhs_801

#print axioms Backend.Stock.Proof.stock_alu_rrr_resolved

#print axioms Backend.Stock.Proof.stock_alu_roots_witness

#print axioms Backend.Stock.Proof.stock_lower_record_fresh_result

#print axioms Backend.Stock.Proof.stock_lower_record_fresh_result_witness

#print axioms Backend.Stock.Proof.stock_lower_fresh_record_values

#print axioms Backend.Stock.Proof.source_single_result_values

#print axioms Backend.Stock.Proof.stock_lower_fresh_record_values_witness

#print axioms Backend.Stock.Proof.stock_ctor_demand_mono

#print axioms Backend.Stock.Proof.stock_apply_demand_mono

#print axioms Backend.Stock.Proof.stock_named_demand_mono

#print axioms Backend.Stock.Proof.stock_lower_record_demand_mono

#print axioms Backend.Stock.Proof.stock_demand_mono_witness

#print axioms Backend.Stock.Proof.stock_lower_fresh_record_values_auto_demand

#print axioms Backend.Stock.Proof.stock_put_in_reg_iff

#print axioms Backend.Stock.Proof.stock_rhs_86_requests

#print axioms Backend.Stock.Proof.stock_rhs_801_requests

#print axioms Backend.Stock.Proof.stock_rhs_86_observed

#print axioms Backend.Stock.Proof.stock_rhs_801_observed

#print axioms Backend.Stock.Proof.stock_request_success_witness

#print axioms Backend.Stock.Proof.stock_lower_alu_record_shape

#print axioms Backend.Stock.Proof.stock_lower_alu_available_values

#print axioms Backend.Stock.Proof.stock_lower_alu_available_values_witness

#print axioms Backend.Stock.Proof.Extent.ctor_demand_size

#print axioms Backend.Stock.Proof.Extent.apply_demand_size

#print axioms Backend.Stock.Proof.Extent.named_demand_size

#print axioms Backend.Stock.Proof.Extent.scan_demand_size

#print axioms Backend.Stock.Proof.Extent.scanBlock_demand_size

#print axioms Backend.Stock.Proof.Extent.lower_record_demand_size

#print axioms Backend.Stock.Proof.Extent.lower_mapped_demand_bounds

#print axioms Backend.Stock.Proof.Extent.demand_extent_witness

#print axioms Backend.Stock.Proof.stock_lower_record_args_available

#print axioms Backend.Stock.Proof.stock_lower_alu_operand_coverage

#print axioms Backend.Stock.Proof.stock_lower_alu_available_values_auto_operands

#print axioms Backend.Stock.Proof.stock_lower_alu_auto_values_witness

#print axioms Backend.Stock.Proof.stock_named_lower_selection

#print axioms Backend.Stock.Proof.stock_lower_record_selection

#print axioms Backend.Stock.Proof.LowerSelection.rule_mem

#print axioms Backend.Stock.Proof.LowerSelection.last_rule

#print axioms Backend.Stock.Proof.stock_lower_record_selection_witness

#print axioms Backend.Stock.Proof.stock_lower_alu_selected_receipts

#print axioms Backend.Stock.Proof.stock_lower_alu_selected_values

#print axioms Backend.Stock.Proof.stock_lower_alu_selected_values_witness

#print axioms Backend.Stock.Proof.stock_alu_rrr_helper

#print axioms Backend.Stock.Proof.stock_rhs_3916

#print axioms Backend.Stock.Proof.stock_logical_rrr_witness

#print axioms Backend.Stock.Proof.LogicalForms.stock_logical_imm_helper

#print axioms Backend.Stock.Proof.LogicalForms.stock_logical_shift_helper

#print axioms Backend.Stock.Proof.LogicalForms.stock_rhs_3920

#print axioms Backend.Stock.Proof.LogicalForms.stock_rhs_3923

#print axioms Backend.Stock.Proof.LogicalForms.stock_rhs_3928

#print axioms Backend.Stock.Proof.LogicalForms.stock_rhs_3931

#print axioms Backend.Stock.Proof.LogicalForms.stock_logical_forms_witness

#print axioms Backend.Stock.Proof.LogicalSelected.stock_match_logical

#print axioms Backend.Stock.Proof.LogicalSelected.stock_lower_logical_selected_receipts

#print axioms Backend.Stock.Proof.LogicalSelected.stock_logical_selected_witness

#print axioms Backend.Stock.Proof.LogicalSelected.stock_logical_rhs_helper

#print axioms Backend.Stock.Proof.LogicalSelected.stock_logical_helper_witness

#print axioms Backend.Stock.Proof.LogicalSemantics.stock_logical_imm_resolved

#print axioms Backend.Stock.Proof.LogicalSemantics.stock_logical_shift_resolved

#print axioms Backend.Stock.Proof.LogicalSemantics.stock_logical_semantics_witness

#print axioms Backend.Stock.Proof.LogicalSemantics.stock_logical_constant_match_value

#print axioms Backend.Stock.Proof.LogicalSemantics.stock_logical_shift_match_value

#print axioms Backend.Stock.Proof.LogicalSemantics.stock_logical_imm_match_receipts

#print axioms Backend.Stock.Proof.LogicalSemantics.stock_logical_shift_match_receipts

#print axioms Backend.Stock.Proof.LogicalSemantics.stock_logical_constant_match_witness

#print axioms Backend.Stock.Proof.LogicalSemantics.stock_logical_imm_receipts_witness

#print axioms Backend.Stock.Proof.LogicalSemantics.stock_logical_shift_match_witness

#print axioms Backend.Stock.Proof.LogicalSemantics.stock_logical_shift_receipts_witness
