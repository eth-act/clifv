from pathlib import Path
import datetime,hashlib,json,subprocess
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
records=[]
for root,expected in [('/tmp/stock-logical-final-author',10),('/tmp/stock-logical-retention-author',25),('/tmp/stock-logical-examples-author',2)]:
 got=[]
 for p in Path(root).glob('*.json'):
  try:d=json.loads(p.read_text())
  except ValueError:continue
  if p.stem!=d.get('id') or d.get('state')!='passed':continue
  assert d.get('returncode')==0,('command',p)
  assert sha(d['log'])==d['log_sha256'],('log',p)
  got.append(d)
 assert len(got)==expected,('gate count',root,len(got),expected)
 records.extend(got)
owned=[]
for root,ids in [('/tmp/stock-logical-owned-strict-author',[0,1,2]),('/tmp/stock-logical-executable-owned-author',[3,4,5])]:
 for i in ids:
  d=json.loads((Path(root)/f'owned-{i}.json').read_text())
  assert d['state']=='passed' and d['returncode']==0,('owned',root,i)
  assert sha(d['log'])==d['log_sha256'],('owned log',root,i)
  owned.append(d)
review=json.loads(Path('/tmp/stock-logical-mcp-review.json').read_text())
assert set(review['axioms'])=={'propext','Classical.choice','Quot.sound'} and review['warnings']==[], 'MCP'
parity=json.loads(Path('/tmp/stock-logical-current-parity.json').read_text())
assert not parity['missing'] and not parity['changed_sets'],'axiom/header parity'
identity=json.loads(Path('/tmp/stock-logical-identity-stage-parity.json').read_text())
assert all(d['current']==1159 and d['all_original_and_prior_identities_and_ordered_stages_preserved'] for d in identity.values()),'identity/stage parity'
native=json.loads(Path('/tmp/stock-logical-repaired-author/native/native-receipt.json').read_text())
assert native['state']=='passed' and native['actual_lean_encoded_objects']==24 and native['lean_byte_executions']==792 and native['failures']==native['disagreements']==0,'native'
assert sha('rust/target/release/clif-native')==native['native_binary_sha256'],'native binary changed'
assert subprocess.check_output(['git','diff','4f2694da','HEAD','--name-only'],text=True).splitlines()==['FVTest/Link/LeanLinkMain.lean'],'later source delta'
result={'state':'per_pr_gates_passed','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'validated_source_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'base_main':'40333cb4c8544fa06d9d6a69e56a49a3632e1410','primary_gate_records':records,'primary_gate_count':len(records),'owned_gate_records':owned,'owned_core_constants':2338,'owned_fixed_witness_constants':566,'exact_declared_native_facts':json.loads(Path('/tmp/stock-logical-owned/partitions.json').read_text())['exact_native_facts'],'mcp_review':review,'parity':parity,'identity_stage_parity':identity,'native_execution':native,'first_stage_source':'4f2694daff7a5d469faa54232a4f35a98a7550dd','only_later_source_delta':'Verified linker diagnostic cites compileWithRoutes_accepts_legacy. No FV/proof/generator/lowering input changed; current normal/tool keys and actual Logical/Mixed linker CLI modes rerun, linked artifact hashes unchanged. Original first-stage provenance retained.','prior_failures_preserved':['saved witness elaboration and resource attempts','private fixed-witness audit annotations/names','overstrict optional diagnostic assertion','example PATH missing cargo-fv; corrected examples pass'],'full_original_140_complete':False}
Path('/tmp/stock-logical-terminal-author-receipt.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['state','validated_source_head','primary_gate_count','owned_core_constants','owned_fixed_witness_constants','full_original_140_complete']}))
