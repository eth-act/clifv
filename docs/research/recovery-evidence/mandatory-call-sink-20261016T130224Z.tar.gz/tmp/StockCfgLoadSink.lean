import FV.Backend.Proof.StockSinkProvenance
import FV.Backend.Proof.StockPatternBindings

/-! Load-pattern sink helpers obtain their instruction targets from actual
installed instruction data. These facts exclude trap terminator slots; they do
not yet establish the full evaluator's sunk-bit preservation invariant. -/
namespace Backend.Stock.Proof.CfgLoadSinkDraft
open Backend.Proof Isle Isle.Interp Isle.Aarch64
variable {cfg : Config}
set_option maxRecDepth 4096
attribute [local irreducible] Isle.Aarch64.program

private theorem installed_extract_inv {ctx : Ctx} {ii : Nat} {st : LState} {fs : List V}
    (h : Backend.externExtract ctx T.inst_data_value (.inst ii) st = .ok fs) :
    ∃ info, ctx.insts[ii]? = some info ∧
      fs = [.ty (info.resTys.head?.getD .invalid), info.data] := by
  change (match ctx.insts[ii]? with
    | some info => ExtResult.ok [.ty (info.resTys.head?.getD .invalid), info.data]
    | none => ExtResult.unmodeled s!"inst {ii}") = ExtResult.ok fs at h
  cases hi : ctx.insts[ii]? with
  | none => rw [hi] at h; cases h
  | some info => rw [hi] at h; cases h; exact ⟨info, rfl, rfl⟩

private theorem installed_format {ctx : Ctx} {st : State} {ii b ft fmt : Nat}
    {rest : List Pattern} {env bound : Isle.Interp.Env V} {term : Term}
    (ht : termOf program ft = .ok term) (hk : term.kind = .enumVariant fmt)
    (h : matchPat program (Stock.sem ctx) st
      (.bind 18 b (.term 18 209 [.wildcard 14, .term 152 ft rest]))
      (.inst ii) env = .ok (some bound)) :
    ∃ info fields, ctx.insts[ii]? = some info ∧
      (Backend.sem ctx).unData 152 info.data = some (fmt, fields) := by
  obtain ⟨_, h⟩ := matchPat_bind_inv h
  obtain ⟨values, hx, ha⟩ := matchPat_extract_inv data_program.t209 term_209_kind rfl h
  change Backend.externExtract ctx T.inst_data_value (.inst ii) st.base = .ok values at hx
  obtain ⟨info, hi, rfl⟩ := installed_extract_inv hx
  obtain ⟨env1, _, ha⟩ := matchArgs_cons_inv ha
  obtain ⟨env2, hp, _⟩ := matchArgs_cons_inv ha
  obtain ⟨fields, hu, _⟩ := matchPat_enum_inv ht hk hp
  exact ⟨info, fields, hi, hu⟩

/-- Successful actual matching of either pattern-based sink helper requires
installed ordinary-load (16) or atomic-load (17) data at its instruction input. -/
theorem stock_loadSink_pattern {ctx : Ctx} {st matched : State}
    {tr tr' : Array RuleId} {bound : Isle.Interp.Env V} {ii n : Nat} {ty : CTy}
    (atomic : Bool)
    (hm : (matchRule program (Stock.sem ctx) cfg (n + 1)
      (if atomic then rule_inst_3905 else rule_inst_4203)
      (if atomic then [.inst ii] else [.ty ty, .inst ii])).run (st, tr) =
        .ok (some bound, matched, tr')) :
    ∃ info fields, ctx.insts[ii]? = some info ∧
      (Backend.sem ctx).unData 152 info.data = some (if atomic then 17 else 16, fields) := by
  obtain ⟨env, ha, _⟩ := matchRule_some_inv hm
  cases atomic with
  | false =>
    simp only [Bool.false_eq_true, ↓reduceIte, rule_inst_4203] at ha
    obtain ⟨env1, _, ha⟩ := matchArgs_cons_inv ha
    obtain ⟨env2, hp, _⟩ := matchArgs_cons_inv ha
    exact installed_format data_program.t2463 rfl hp
  | true =>
    simp only [↓reduceIte, rule_inst_3905] at ha
    obtain ⟨env1, hp, _⟩ := matchArgs_cons_inv ha
    exact installed_format data_program.t2464 rfl hp

private theorem noIflet_match {ctx : Ctx} {st matched : State}
    {tr tr' : Array RuleId} {bound : Isle.Interp.Env V} {n : Nat} {r : Rule} {vs : List V}
    (hil : r.iflets = [])
    (hm : (matchRule program (Stock.sem ctx) cfg (n + 1) r vs).run (st, tr) =
        .ok (some bound, matched, tr')) :
    matched = st ∧ tr' = tr ∧
      matchArgs program (Stock.sem ctx) st r.args vs
        (Array.replicate r.vars.length none) = .ok (some bound) := by
  obtain ⟨env, ha, hi⟩ := matchRule_some_inv hm
  rw [hil] at hi
  cases n with
  | zero => rw [matchIfLets.eq_1] at hi; cases hi
  | succ n =>
    rw [matchIfLets.eq_2] at hi
    cases hi
    exact ⟨rfl, rfl, ha⟩

/-- Complete matching binds the sink target to its actual instruction input
and retains the original state/trace; inner address/offset bindings cannot
replace that instruction variable. -/
theorem stock_loadSink_binding {ctx : Ctx} {st matched : State}
    {tr tr' : Array RuleId} {bound : Isle.Interp.Env V} {ii n : Nat} {ty : CTy}
    (atomic : Bool)
    (hm : (matchRule program (Stock.sem ctx) cfg (n + 1)
      (if atomic then rule_inst_3905 else rule_inst_4203)
      (if atomic then [.inst ii] else [.ty ty, .inst ii])).run (st, tr) =
        .ok (some bound, matched, tr')) :
    matched = st ∧ tr' = tr ∧ bound[if atomic then 1 else 3]? = some (some (.inst ii)) := by
  obtain ⟨hs, ht, ha⟩ := noIflet_match (by cases atomic <;> rfl) hm
  refine ⟨hs, ht, ?_⟩
  cases atomic with
  | false =>
    simp only [Bool.false_eq_true, ↓reduceIte, rule_inst_4203] at ha
    obtain ⟨env1, hp, ha⟩ := matchArgs_cons_inv ha
    obtain ⟨_, hp⟩ := matchPat_bind_inv hp
    simp only [matchPat, pure, Except.pure] at hp
    cases hp
    obtain ⟨env2, hp, ht⟩ := matchArgs_cons_inv ha
    simp only [matchArgs, pure, Except.pure] at ht
    cases ht
    obtain ⟨_, hp⟩ := matchPat_bind_inv hp
    have h := stock_pattern_keeps (k := 3) (by decide) hp
    exact h.trans (by rfl)
  | true =>
    simp only [↓reduceIte, rule_inst_3905] at ha
    obtain ⟨env1, hp, ht⟩ := matchArgs_cons_inv ha
    simp only [matchArgs, pure, Except.pure] at ht
    cases ht
    obtain ⟨_, hp⟩ := matchPat_bind_inv hp
    have h := stock_pattern_keeps (k := 1) (by decide) hp
    exact h.trans (by rfl)

private theorem rhs_sink_receipt {ctx : Ctx} {st next : State} {tr tr' : Array RuleId}
    {env : Isle.Interp.Env V} {m j k ty : Nat} {body : Expr} {out : V}
    (hs : (evalExpr program (Stock.sem ctx) cfg (m + 5)
      (.let ty [(j, 13, .term 13 236 [.var 18 k])] body) env).run (st, tr) =
        .ok (some out, next, tr')) :
    ∃ unit sunk trace,
      (evalExpr program (Stock.sem ctx) cfg (m + 3)
        (.term 13 236 [.var 18 k]) env).run (st, tr) =
          .ok (some unit, sunk, trace) := by
  rw [evalExpr.eq_6, evalBinds.eq_3] at hs
  simp only [isel_monad] at hs
  cases he : (evalExpr program (Stock.sem ctx) cfg (m + 3)
      (.term 13 236 [.var 18 k]) env).run (st, tr) with
  | error e => rw [he] at hs; cases hs
  | ok pair =>
    obtain ⟨value, state⟩ := pair
    cases value with
    | none => rw [he] at hs; simp only [isel_monad] at hs; cases hs
    | some unit => exact ⟨unit, state.1, state.2, rfl⟩

private theorem sink_call_receipt {ctx : Ctx} {st next : State} {tr tr' : Array RuleId}
    {env : Isle.Interp.Env V} {m k ii : Nat} {out : V}
    (hk : env[k]? = some (some (.inst ii)))
    (he : (evalExpr program (Stock.sem ctx) cfg (m + 3)
      (.term 13 236 [.var 18 k]) env).run (st, tr) = .ok (some out, next, tr')) :
    Stock.externCtor ctx T.sink_inst [.inst ii] st = .ok (.op .unit, next) := by
  simp only [evalExpr.eq_7, evalArgs.eq_3, evalExpr.eq_2, evalArgs.eq_2,
    hk, isel_monad, applyTerm.eq_2, data_program.t236, T.sink_inst, Stock.sem] at he
  cases hc : Stock.externCtor ctx T.sink_inst [.inst ii] st with
  | fail => simp only [T.sink_inst] at hc; rw [hc] at he; simp only [isel_monad] at he; cases he
  | unmodeled e => simp only [T.sink_inst] at hc; rw [hc] at he; simp only [isel_monad] at he; cases he
  | ok pair =>
    obtain ⟨value, final⟩ := pair
    have hunit := (sink_accepted hc).2.2.2.1
    subst value
    have hc' := hc
    simp only [T.sink_inst] at hc'
    rw [hc'] at he
    simp only [isel_monad, Except.ok.injEq, Prod.mk.injEq, Option.some.injEq] at he
    obtain ⟨_, hn, _⟩ := he
    subst next
    rfl

/-- Successful complete match and full RHS evaluation of either exported load
helper supply its actual sink call on the instruction matched at the input.
The intermediate sink update and installed load-format provenance are derived. -/
theorem stock_loadSink_call {ctx : Ctx} {st matched next : State}
    {tr tr' tr'' : Array RuleId} {bound : Isle.Interp.Env V} {ii n m : Nat}
    {ty : CTy} {out : V} (atomic : Bool)
    (hm : (matchRule program (Stock.sem ctx) cfg (n + 1)
      (if atomic then rule_inst_3905 else rule_inst_4203)
      (if atomic then [.inst ii] else [.ty ty, .inst ii])).run (st, tr) =
        .ok (some bound, matched, tr'))
    (hs : (evalExpr program (Stock.sem ctx) cfg (m + 5)
      (if atomic then rule_inst_3905 else rule_inst_4203).rhs bound).run (matched, tr') =
        .ok (some out, next, tr'')) :
    ∃ sunk info fields,
      Stock.externCtor ctx T.sink_inst [.inst ii] st = .ok (.op .unit, sunk) ∧
      sunk = { st with color := some st.entryColor[ii]!, sunk := st.sunk.set! ii true } ∧
      ctx.insts[ii]? = some info ∧
      (Backend.sem ctx).unData 152 info.data = some (if atomic then 17 else 16, fields) := by
  obtain ⟨info, fields, hi, hf⟩ := stock_loadSink_pattern atomic hm
  obtain ⟨hstate, htrace, hk⟩ := stock_loadSink_binding atomic hm
  subst matched
  subst tr'
  have hcall : ∃ sunk, Stock.externCtor ctx T.sink_inst [.inst ii] st =
      .ok (.op .unit, sunk) := by
    cases atomic with
    | false =>
      simp only [Bool.false_eq_true, ↓reduceIte, rule_inst_4203] at hs
      obtain ⟨unit, sunk, trace, he⟩ := rhs_sink_receipt hs
      exact ⟨sunk, sink_call_receipt hk he⟩
    | true =>
      simp only [↓reduceIte, rule_inst_3905] at hs
      obtain ⟨unit, sunk, trace, he⟩ := rhs_sink_receipt hs
      exact ⟨sunk, sink_call_receipt hk he⟩
  obtain ⟨sunk, hc⟩ := hcall
  exact ⟨sunk, info, fields, hc, (sink_accepted hc).2.2.2.2, hi, hf⟩

end Backend.Stock.Proof.CfgLoadSinkDraft
