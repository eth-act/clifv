import FV.Backend.Proof.IselCmpBase
import StockCfgLoadSink
import FV.Backend.Proof.StockSinkFrame
namespace Backend.Stock.Proof.AtomicProtectedDraft
open Backend.Proof Isle Isle.Interp Isle.Aarch64 CfgLoadSinkDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
attribute [local irreducible] Isle.Aarch64.program
private theorem sem_ctor (ctx : Ctx) (t : Term) (vs : List V) (st : State) :
    (Stock.sem ctx).ctor t vs st = Stock.externCtor ctx t vs st := rfl
/-- Actual atomic-load helper execution changes at most its own input's sunk
bit. The following put-in-register constructor preserves the complete table. -/
theorem stock_atomic_load_sink_frame {ctx : Ctx} {cfg : Config} (overlap : cfg.checkOverlap = false) {n ty ii : Nat} {before next : State}
    {tr trace : Array RuleId} {out : V}
    (run : ApplyInternal program (Stock.sem ctx) cfg n ty 564 [.inst ii] (before,tr) out (next,trace)) :
    ∃ sunk,
      Stock.externCtor ctx T.sink_inst [.inst ii] before = .ok (.op .unit,sunk) ∧
      next.sunk = sunk.sunk ∧
      ∃ info fields,ctx.insts[ii]? = some info ∧
        (Backend.sem ctx).unData 152 info.data = some (17,fields) := by
  obtain ⟨r,pre,post,list,failed,m,env,middle,after,trace',bound,matched,rhs,final⟩ :=
    applyTerm_internal_some_first overlap
      data_program.t564 (show T.sink_atomic_load.kind = _ from rfl) rfl run
  rw [data_program.r564] at list
  have chosen : r = rule_inst_3905 := by
    have member : r ∈ ([rule_inst_3905] : List Rule) := by rw [list]; simp
    exact List.mem_singleton.mp member
  subst r
  rcases middle with ⟨atMatch,matchTrace⟩
  rcases m with _ | m
  · rw [matchRule.eq_1] at matched; cases matched
  obtain ⟨sameState,sameTrace,targetBinding⟩ := stock_loadSink_binding (ty := .int 8) true matched
  simp only [↓reduceIte] at sameState sameTrace targetBinding
  subst atMatch
  subst matchTrace
  have shape := stock_loadSink_pattern (ty := .int 8) true matched
  rcases n with _ | (_ | (_ | (_ | (_ | n))))
  all_goals try solve | rw [evalExpr.eq_1] at rhs; cases rhs
  all_goals try solve | isel_inv [*,rule_inst_3905,sem_ctor,data_program.t182,data_program.t236,T.put_in_reg,T.sink_inst,evalExpr.eq_1,evalArgs.eq_1,evalBinds.eq_1,applyTerm.eq_1] at rhs
  obtain ⟨sunk,info,fields,sinkRun,sinkState,slot,format⟩ := stock_loadSink_call (ty := .int 8) true matched rhs
  have nextEq : next = after := congrArg Prod.fst final
  subst next
  have evaluation := rhs
  isel_inv_simp [*,rule_inst_3905,sem_ctor,data_program.t182,data_program.t236,T.put_in_reg,T.sink_inst,evalExpr.eq_1,evalArgs.eq_1,evalBinds.eq_1,applyTerm.eq_1] at evaluation
  isel_destruct
  subst_vars
  refine ⟨_,sinkRun,?_,info,fields,slot,format⟩
  have finish {a b : State} {unit value : V} {uses : List V}
      (sink : Stock.externCtor ctx T.sink_inst [.inst ii] before = .ok (unit,a))
      (put : Stock.externCtor ctx T.put_in_reg uses a = .ok (value,b)) :
      b.sunk = before.sunk.set! ii true := by
    rw [stock_ctor_noSink (t := T.put_in_reg) (by decide) put,(sink_accepted sink).2.2.2.2]
  change _ = before.sunk.set! ii true
  solve_by_elim [finish]
/-- Any guardedIndex slot with non-atomic-load data retains its exact sunk bit
under the full atomic helper, without an input-unsunk or fuel lower-bound filter. -/
theorem stock_atomic_load_preserves_other_sunk {ctx : Ctx} {cfg : Config} (overlap : cfg.checkOverlap = false) {n ty ii guardedIndex : Nat}
    {before next : State} {tr trace : Array RuleId} {out : V}
    (different : ∀ info fields,ctx.insts[guardedIndex]? = some info →
      (Backend.sem ctx).unData 152 info.data ≠ some (17,fields))
    (run : ApplyInternal program (Stock.sem ctx) cfg n ty 564 [.inst ii] (before,tr) out (next,trace)) :
    next.sunk[guardedIndex]! = before.sunk[guardedIndex]! := by
  obtain ⟨sunk,sinkRun,frame,info,fields,slot,format⟩ := stock_atomic_load_sink_frame overlap run
  have ne : guardedIndex ≠ ii := by
    intro same
    subst ii
    exact different info fields slot format
  rw [frame,(sink_accepted sinkRun).2.2.2.2]
  simp [getElem!_def,Array.getElem?_setIfInBounds,ne,Ne.symm ne]
end Backend.Stock.Proof.AtomicProtectedDraft
