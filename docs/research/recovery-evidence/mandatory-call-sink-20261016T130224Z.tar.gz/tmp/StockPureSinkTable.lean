import FV.Backend.Proof.StockSourceSinkTable
namespace Backend.Stock.Proof.PureSinkDraft
open Backend.Proof Backend.Proof.Cov Isle Isle.Interp Isle.Aarch64
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
attribute [local irreducible] Isle.Aarch64.program
/-- Closed helper terms used after load sinking; ordinary constructors cannot
introduce another sunk bit on these paths. This restricts proof analysis only. -/
def pureTerms : List Nat := [1, 2, 93, 111, 113, 120, 144, 157, 175, 182, 201, 209, 219, 235, 287, 305, 318, 319, 320, 321, 325, 339, 352, 358, 359, 360, 362, 376, 432, 433, 498, 553, 554, 574, 575, 576, 577, 580, 581, 582, 584, 702, 978, 1157, 1182, 1378, 1431, 1455, 1508, 1514, 1614, 1820, 1822, 1823, 1844, 1962, 1964, 1989, 1990, 1998, 2002, 2012, 2013, 2014, 2015, 2016, 2017, 2024, 2028, 2029, 2235, 2331, 2341, 2357, 2387, 2425, 2426, 2449, 2468, 2476, 2482]
def pureTab : Tab := (covTab.filter (fun e => pureTerms.contains e.1)) ++ [(584,[.reg 1,.c0],.reg 1)]
def purePre (t : TermId) (args : List AW) : Bool := noOpportunityPre t args && t != TId.sink_inst
/-- The complete fixed helper summary subset checks with sinking forbidden. -/
theorem stock_pure_noSink_table_checked :
    chkTab program pureTab aext actor purePre aOracle = true := by
  decide +kernel
end Backend.Stock.Proof.PureSinkDraft
