import StockAtomicProtected
namespace Backend.Stock.Proof.AtomicNoNoneDraft
open Backend.Proof Isle Isle.Interp Isle.Aarch64
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
attribute [local irreducible] Isle.Aarch64.program
/-- The real total atomic-load helper cannot successfully return no value. -/
theorem stock_atomic_helper_not_none {ctx : Ctx} {cfg : Config} (overlap : cfg.checkOverlap = false)
    {n ty : Nat} {vs : List V} {before after : State} {tr trace : Array RuleId}
    (run : (applyTerm program (Stock.sem ctx) cfg n ty 564 vs).run (before,tr) = .ok (none,after,trace)) : False := by
  cases n with
  | zero => rw [applyTerm.eq_1] at run; cases run
  | succ n =>
    obtain impossible | ⟨rule,member,m,env,middle,matched,rhs⟩ := applyTerm_internal_none overlap
      data_program.t564 (show T.sink_atomic_load.kind = _ from rfl) rfl run
    · cases impossible.1
    · rw [data_program.r564] at member
      have same := List.mem_singleton.mp member
      subst rule
      rcases n with _ | (_ | (_ | (_ | (_ | n))))
      all_goals revert rhs
      all_goals isel_eval [rule_inst_3905,data_program.t182,data_program.t236,T.put_in_reg,T.sink_inst,
        evalExpr.eq_1,evalArgs.eq_1,evalBinds.eq_1,applyTerm.eq_1]
      all_goals repeat' first
        | (solve | simp)
        | (solve | intro impossible; cases impossible)
        | (split <;> isel_eval [data_program.t182,data_program.t236,T.put_in_reg,T.sink_inst,
            evalExpr.eq_1,evalArgs.eq_1,evalBinds.eq_1,applyTerm.eq_1])
end Backend.Stock.Proof.AtomicNoNoneDraft
