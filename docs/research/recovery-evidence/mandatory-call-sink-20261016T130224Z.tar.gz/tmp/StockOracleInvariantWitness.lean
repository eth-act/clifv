import StockOracleInvariant
import FV.Backend.Proof.StockCoverageRoots
import FV.Backend.Proof.StockSelectionReceipts
namespace Backend.Stock.Proof.OracleInvariantWitnessDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Cov Isle Isle.Interp Isle.Aarch64
open Coverage.OracleInvariant
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
/-- The previous fixed-oracle model is preserved as an actual instance. -/
def fromFixed {p : Program} {f : Clif.Function} {ctx : Ctx} (md : Coverage.Model p f ctx) :
    Model actor noOpportunityPre aOracle p f ctx :=
  { Is := md.Is,source := md.source,ctor := md.ctor,oracle := md.oracle }
/-- Original source/build/model/table premises remain inhabited by the actual
full-program allocating interpreter run, with its real nonempty arguments. -/
theorem stock_oracle_invariant_original_witness :
    ∃ (f : Clif.Function) (ctx : Ctx) (ranges : Array (Nat × Nat)) (initial after : State)
      (md : Model actor noOpportunityPre aOracle program f ctx) (value : V) (args : List V),
      LowerScope f ∧ Stock.buildCtx f = .ok (ctx,ranges,initial) ∧
      MappedCtxInv f ctx ∧ Clean (sourceIdentityCtx ctx) ∧ md.Is initial ∧
      chkTab program covTab aext actor noOpportunityPre aOracle = true ∧
      SoundAt md {} covTab 1 ∧
      (applyTerm program (Stock.sem ctx) {} 1 T.temp_writable_reg.ret TId.temp_writable_reg args).run
        (initial,#[]) = .ok (some value,after,#[]) ∧ after.base.nextVreg = initial.base.nextVreg+1 := by
  obtain ⟨f,ctx,ranges,initial,after,old,value,scope,build,mapped,clean,invariant,sound,run,allocated⟩ :=
    Coverage.soundAt_witness
  let md := fromFixed old
  exact ⟨f,ctx,ranges,initial,after,md,value,_,scope,build,mapped,clean,invariant,
    stock_noOpportunity_table_checked,
    Coverage.OracleInvariant.soundAt mapped md {} covTab rfl stock_noOpportunity_table_checked 1,run,allocated⟩
private theorem stock_lower_nonroot_nomatch {f : Clif.Function} {ctx original : Ctx}
    (view : DFGViewEq ctx original) (hctx : CtxInv f original) {ii : Nat}
    {info : IInfo} {inst : Clif.Inst} (hi : original.insts[ii]? = some info)
    (hc : info.clif = some inst) {r : Rule} (hr : r ∈ program.rulesOf TId.lower)
    (hroot : closureRootIds.contains r.id = false) :
    ∀ m s0 env s1, (matchRule program (Stock.sem ctx) {} m r [.inst ii]).run s0 ≠
      .ok (some env, s1) := by
  intro m s0 env' s1 hmatch
  have hok := List.all_eq_true.mp exclOk_program r hr
  simp only [exclOk, hroot, Bool.false_or] at hok
  cases m with
  | zero => rw [matchRule.eq_1] at hmatch; cases hmatch
  | succ m =>
    obtain ⟨env0, ha, -⟩ := matchRule_some_inv hmatch
    rw [stock_matchArgs_source view] at ha
    split at hok
    · rename_i q hargs
      rw [hargs] at ha
      obtain ⟨e1, h1, -⟩ := matchArgs_cons_inv ha
      exact fails_sound hctx q .inst _ _ _ _ hok
        ⟨ii, info, inst, rfl, hi, hc, hctx.data ii info inst hi hc⟩ h1
    · cases hok

/-- The selected-rule interface is inhabited by the SAME actual constant
source, real first-match receipt and full RHS, with all original model inputs. -/
theorem stock_oracle_selected_original_witness :
    ∃ (f : Clif.Function) (ctx : Ctx) (ranges : Array (Nat × Nat)) (initial after : State)
      (info : IInfo) (trace : List RuleId)
      (selected : LowerSelection ctx 0 sinkState (.regsVec [[.vreg 194 .int]]) after trace)
      (md : Model actor noOpportunityPre aOracle program f ctx),
      LowerScope f ∧ Stock.buildCtx f = .ok (ctx,ranges,initial) ∧
      MappedCtxInv f ctx ∧ Clean (sourceIdentityCtx ctx) ∧ md.Is sinkState ∧
      chkTab program covTab aext actor noOpportunityPre aOracle = true ∧
      Holds2 f (sourceIdentityCtx ctx) [.xv .inst] [.inst 0] ∧
      aRule program covTab aext actor noOpportunityPre aOracle [.xv .inst] AW.top selected.rule = true ∧
      md.Is after ∧ γ f (sourceIdentityCtx ctx) AW.top (.regsVec [[.vreg 194 .int]]) := by
  obtain ⟨f,ctx,ranges,initial,after,info,trace,scope,build,mapped,clean,slot,clif,valueMap,run,unchanged⟩ :=
    Coverage.statement_noOpportunity_witness
  obtain ⟨selected⟩ := stock_named_lower_selection run
  have view : DFGViewEq ctx (sourceIdentityCtx ctx) := ⟨rfl,rfl,rfl,rfl,rfl⟩
  have checked : aRule program covTab aext actor noOpportunityPre aOracle [.xv .inst] AW.top selected.rule = true := by
    have both := List.all_eq_true.mp stock_noOpportunity_roots_checked.1 selected.rule selected.rule_mem
    simp only [Bool.or_eq_true,Bool.not_eq_true'] at both
    rcases both with excluded | checked
    · exact False.elim (stock_lower_nonroot_nomatch view mapped.identityView slot clif selected.rule_mem excluded
        selected.matchFuel _ _ _ selected.matchedRun)
    · exact checked
  have held := holds_inst mapped.identityView (show (sourceIdentityCtx ctx).insts[0]? = some info from slot) clif
  let md := fromFixed (Coverage.model mapped clean sinkState.opportunistic)
  have result := selected_rule_sound mapped md {} covTab rfl stock_noOpportunity_table_checked checked held
    (show md.Is sinkState from rfl) selected.matchedRun selected.rhsRun
  exact ⟨f,ctx,ranges,initial,after,info,trace,selected,md,scope,build,mapped,clean,rfl,
    stock_noOpportunity_table_checked,held,checked,result.1,result.2 _ rfl⟩
end Backend.Stock.Proof.OracleInvariantWitnessDraft
