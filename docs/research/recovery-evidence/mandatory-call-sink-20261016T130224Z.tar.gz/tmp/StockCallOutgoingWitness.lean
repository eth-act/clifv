import StockCallOutgoing
import StockGotOutgoing
import StockCallEmissionWitness
import StockGotCallWitness
namespace Backend.Stock.Proof.CallOutgoingWitnessDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Backend.Proof.PerEdgePrep Isle Isle.Interp Isle.Aarch64
open CallOutgoingDraft GotOutgoingDraft OutgoingWholeDraft
open CallStaticFixture (arguments)
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm Stock.lower
section
open CallStaticFixture
theorem stock_complete_direct_call_outgoing_witness (implicit : Bool) :
    ∃ (out : Output) (event : BlockScanEvent) (record : ScanRecord) (info : IInfo) (step : Step),
      LowerScope (function false implicit) ∧ Dominated (function false implicit) ∧
      ArityOk (function false implicit) ∧ AbiSigsOk (function false implicit) ∧
      Stock.lower (function false implicit) = .ok out.result ∧
      prepareAt out.result.code out.result.edgeArgs = .ok out.prepared ∧
      out.rf = spillAllocAt out.prepared.code out.prepared.edges ∧
      checkAllocAt out.prepared.code out.prepared.edges out.rf = .ok () ∧
      lowerRFunc out.prepared.code out.rf = .ok out.af ∧ Facts false implicit out ∧
      event ∈ out.result.blockScans.toList ∧ record ∈ event.output.records ∧
      event.ctx.insts[record.inst]? = some info ∧ info.clif = some (.call 0 (arguments false implicit)) ∧
      record.output.step = some step ∧ step.decision = .emitted ∧
      SigStackOk (CallStaticFixture.signature false implicit) record.output.state.base.outgoing ∧
      SigStackOk (CallStaticFixture.signature false implicit) out.result.code.outgoing ∧
      record.output.state.base.outgoing ≤ out.result.code.outgoing ∧
      out.result.code.outgoing = out.result.final.base.outgoing ∧
      (if implicit then 0 else 16) ≤ out.result.code.outgoing := by
  obtain ⟨out,event,record,info,step,scope,dominated,arity,abi,lowered,prepared,fallback,checked,physical,
    facts,events,records,slot,clif,recorded,emitted,emission,placed⟩ :=
    CallEmissionWitnessDraft.stock_complete_direct_call_emission_witness implicit
  let ext : Clif.ExtFunc := {name := CallStaticFixture.calleeName,sig := CallStaticFixture.signature false implicit,colocated := true}
  have declared : (function false implicit).extern? 0 = some ext := rfl
  have localBound := stock_lower_direct_call_record_outgoing lowered scope dominated.ssa abi events records slot clif declared rfl recorded emitted
  have codeBound := stock_lower_direct_call_code_outgoing lowered scope dominated.ssa abi events records slot clif declared rfl recorded emitted
  have bytes : stackBytes ext.sig = (if implicit then 0 else 16) := by cases implicit <;> rfl
  exact ⟨out,event,record,info,step,scope,dominated,arity,abi,lowered,prepared,fallback,checked,physical,
    facts,events,records,slot,clif,recorded,emitted,localBound,codeBound,
    stock_lower_record_code_outgoing lowered events records,stock_lower_code_outgoing lowered,
    by rw [← bytes]; exact codeBound.1⟩
end
section
open GotCallFixture
theorem stock_complete_got_call_outgoing_witness (implicit : Bool) :
    ∃ (out : Output) (event : BlockScanEvent) (record : ScanRecord) (info : IInfo) (step : Step),
      LowerScope (function implicit) ∧ Dominated (function implicit) ∧ ArityOk (function implicit) ∧
      AbiSigsOk (function implicit) ∧ Stock.lower (function implicit) = .ok out.result ∧
      prepareAt out.result.code out.result.edgeArgs = .ok out.prepared ∧
      out.rf = spillAllocAt out.prepared.code out.prepared.edges ∧
      checkAllocAt out.prepared.code out.prepared.edges out.rf = .ok () ∧
      lowerRFunc out.prepared.code out.rf = .ok out.af ∧ Facts implicit out ∧
      event ∈ out.result.blockScans.toList ∧ record ∈ event.output.records ∧
      event.ctx.insts[record.inst]? = some info ∧ info.clif = some (.call 0 (arguments false implicit)) ∧
      record.output.step = some step ∧ step.decision = .emitted ∧
      SigStackOk (CallStaticFixture.signature false implicit) record.output.state.base.outgoing ∧
      SigStackOk (CallStaticFixture.signature false implicit) out.result.code.outgoing ∧
      record.output.state.base.outgoing ≤ out.result.code.outgoing ∧
      out.result.code.outgoing = out.result.final.base.outgoing ∧
      (if implicit then 0 else 16) ≤ out.result.code.outgoing := by
  obtain ⟨out,event,record,info,step,scope,dominated,arity,abi,lowered,prepared,fallback,checked,physical,
    facts,events,records,slot,clif,recorded,emitted,protocol,emission,placed⟩ :=
    GotCallWitnessDraft.stock_complete_got_call_emission_witness implicit
  let ext : Clif.ExtFunc := {name := CallStaticFixture.calleeName,sig := CallStaticFixture.signature false implicit,colocated := false}
  have declared : (function implicit).extern? 0 = some ext := rfl
  have localBound := stock_lower_got_call_record_outgoing lowered scope dominated.ssa abi events records slot clif declared rfl recorded emitted
  have codeBound := stock_lower_got_call_code_outgoing lowered scope dominated.ssa abi events records slot clif declared rfl recorded emitted
  have bytes : stackBytes ext.sig = (if implicit then 0 else 16) := by cases implicit <;> rfl
  exact ⟨out,event,record,info,step,scope,dominated,arity,abi,lowered,prepared,fallback,checked,physical,
    facts,events,records,slot,clif,recorded,emitted,localBound,codeBound,
    stock_lower_record_code_outgoing lowered events records,stock_lower_code_outgoing lowered,
    by rw [← bytes]; exact codeBound.1⟩
end
end Backend.Stock.Proof.CallOutgoingWitnessDraft
