import FV.Backend.Proof.StockSourceSinkTable
namespace Backend.Stock.Proof.CallSinkDraft
open Backend.Proof Backend.Proof.Cov Isle Isle.Interp Isle.Aarch64
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
attribute [local irreducible] Isle.Aarch64.program
/-- Only the actual atomic-load sink helper receives a separately proved
semantic summary. Every other helper uses the preserved original summaries. -/
def callSinkOracle (t : TermId) (as : List AW) : Option AW :=
  if t == 564 then (match as with | [.xv .inst] => some (.reg 1) | _ => none) else aOracle t as
def callSinkTab : Tab := sourceSinkTab.filter (fun e => e.1 != 564)
def callSinkPre (t : TermId) (as : List AW) : Bool := sourceSinkPre t as && t != TId.sink_inst
/-- Every retained helper summary checks with raw sinking forbidden and the
one actual atomic-load helper isolated behind its semantic contract. -/
theorem stock_callSink_table_checked :
    chkTab program callSinkTab aext sourceSinkActor callSinkPre callSinkOracle = true := by
  decide +kernel
/-- All original roots except the two explicitly handled extension-load rules
check under the same source-input descriptions and original root exclusions. -/
theorem stock_callSink_roots_checked :
    (program.rulesOf TId.lower).all (fun r =>
      !closureRootIds.contains r.id || r.id == 815 || r.id == 824 ||
        aRule program callSinkTab aext sourceSinkActor callSinkPre callSinkOracle [.xv .inst] AW.top r) = true ∧
    (program.rulesOf TId.lower).all (fun r => !(r.id == 964 || r.id == 1037) ||
      aRule program callSinkTab aext sourceSinkActor callSinkPre callSinkOracle [.c0] AW.top r) = true ∧
    (program.rulesOf TId.lower_branch).all
      (aRule program callSinkTab aext sourceSinkActor callSinkPre callSinkOracle [.c0,.c0] AW.top) = true := by
  exact ⟨by decide +kernel,by decide +kernel,by decide +kernel⟩
end Backend.Stock.Proof.CallSinkDraft
