import StockAtomicProtected
import FV.Backend.Proof.StockDFG
namespace Backend.Stock.Proof.AtomicCallProtectedDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64 AtomicProtectedDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
attribute [local irreducible] Isle.Aarch64.program
private theorem call_data {f : Clif.Function} {ctx : Ctx} (mapped : MappedCtxInv f ctx)
    {ti fn : Nat} {info : IInfo} {args : List Nat}
    (slot : ctx.insts[ti]? = some info) (clif : info.clif = some (.call fn args)) :
    info.data = .data 152 6 [.data 151 8 [],.values args,.op (.funcRef fn)] := by
  have data := mapped.data ti info _ slot clif
  simp only [instData] at data
  cases external : f.extern? fn with
  | none => simp only [external] at data; cases data
  | some ext =>
    simp only [external] at data
    split at data
    · unfold instDataV opcodeV mkVariant variantIdx variantNames Isle.Aarch64.program at data
      change Except.ok (V.data 152 6 [.data 151 8 [],.values args,.op (.funcRef fn)]) = .ok info.data at data
      exact (Except.ok.inj data).symm
    · cases data

private theorem indirect_data {f : Clif.Function} {ctx : Ctx} (mapped : MappedCtxInv f ctx)
    {ti ref callee : Nat} {info : IInfo} {args : List Nat}
    (slot : ctx.insts[ti]? = some info) (clif : info.clif = some (.callIndirect ref callee args)) :
    ∃ sig,f.sigDecls.lookup ref = some sig ∧
      info.data = .data 152 7 [.data 151 9 [],.values (callee :: args),.op (.sig sig)] := by
  have data := mapped.data ti info _ slot clif
  simp only [instData] at data
  cases declared : f.sigDecls.lookup ref with
  | none => simp only [declared] at data; cases data
  | some sig =>
    simp only [declared] at data
    unfold instDataV opcodeV mkVariant variantIdx variantNames Isle.Aarch64.program at data
    change Except.ok (V.data 152 7 [.data 151 9 [],.values (callee :: args),.op (.sig sig)]) = .ok info.data at data
    exact ⟨sig,rfl,(Except.ok.inj data).symm⟩

/-- The actual source direct call cannot be an atomic-load sink target.
The source/DFG mapping supplies the data distinction internally. -/
theorem stock_atomic_load_preserves_direct_source_call {f : Clif.Function} {ctx : Ctx}
    (mapped : MappedCtxInv f ctx) {cfg : Config} (overlap : cfg.checkOverlap = false) {guardedIndex : Nat} {info : IInfo} {fn : Nat} {args : List Nat}
    (slot : ctx.insts[guardedIndex]? = some info) (clif : info.clif = some (.call fn args))
    {n ty ii : Nat} {before next : State} {tr trace : Array RuleId} {out : V}
    (run : ApplyInternal program (Stock.sem ctx) cfg n ty 564 [.inst ii] (before,tr) out (next,trace)) :
    next.sunk[guardedIndex]! = before.sunk[guardedIndex]! := by
  have data := call_data mapped slot clif
  apply stock_atomic_load_preserves_other_sunk overlap ?_ run
  intro actual fields found format
  have same := Option.some.inj (slot.symm.trans found)
  subst actual
  rw [data] at format
  simp [Backend.sem] at format
/-- The actual source indirect call cannot be an atomic-load sink target.
The source/DFG mapping supplies the data distinction internally. -/
theorem stock_atomic_load_preserves_indirect_source_call {f : Clif.Function} {ctx : Ctx}
    (mapped : MappedCtxInv f ctx) {cfg : Config} (overlap : cfg.checkOverlap = false) {guardedIndex : Nat} {info : IInfo} {ref callee : Nat} {args : List Nat}
    (slot : ctx.insts[guardedIndex]? = some info) (clif : info.clif = some (.callIndirect ref callee args))
    {n ty ii : Nat} {before next : State} {tr trace : Array RuleId} {out : V}
    (run : ApplyInternal program (Stock.sem ctx) cfg n ty 564 [.inst ii] (before,tr) out (next,trace)) :
    next.sunk[guardedIndex]! = before.sunk[guardedIndex]! := by
  obtain ⟨sig,declared,data⟩ := indirect_data mapped slot clif
  apply stock_atomic_load_preserves_other_sunk overlap ?_ run
  intro actual fields found format
  have same := Option.some.inj (slot.symm.trans found)
  subst actual
  rw [data] at format
  simp [Backend.sem] at format
end Backend.Stock.Proof.AtomicCallProtectedDraft
