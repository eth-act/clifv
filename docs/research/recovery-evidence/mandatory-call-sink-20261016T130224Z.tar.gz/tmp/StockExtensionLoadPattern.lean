import StockCfgLoadSink
import FV.Backend.Proof.IselCmpBase
namespace Backend.Stock.Proof.ExtensionLoadPatternDraft
open Backend.Proof Isle Isle.Interp Isle.Aarch64
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
attribute [local irreducible] Isle.Aarch64.program
private theorem installed_extract_inv {ctx : Ctx} {ii : Nat} {st : LState} {fs : List V}
    (h : Backend.externExtract ctx T.inst_data_value (.inst ii) st = .ok fs) :
    ∃ info, ctx.insts[ii]? = some info ∧
      fs = [.ty (info.resTys.head?.getD .invalid), info.data] := by
  change (match ctx.insts[ii]? with
    | some info => ExtResult.ok [.ty (info.resTys.head?.getD .invalid), info.data]
    | none => ExtResult.unmodeled s!"inst {ii}") = ExtResult.ok fs at h
  cases hi : ctx.insts[ii]? with
  | none => rw [hi] at h; cases h
  | some info => rw [hi] at h; cases h; exact ⟨info, rfl, rfl⟩

private theorem installed_format {ctx : Ctx} {st : State} {ii ft fmt : Nat} {typePattern : Pattern}
    {rest : List Pattern} {env bound : Isle.Interp.Env V} {term : Term}
    (ht : termOf program ft = .ok term) (hk : term.kind = .enumVariant fmt)
    (h : matchPat program (Stock.sem ctx) st
      (.term 18 209 [typePattern, .term 152 ft rest])
      (.inst ii) env = .ok (some bound)) :
    ∃ info fields, ctx.insts[ii]? = some info ∧
      (Backend.sem ctx).unData 152 info.data = some (fmt, fields) := by
  obtain ⟨values, hx, ha⟩ := matchPat_extract_inv data_program.t209 term_209_kind rfl h
  change Backend.externExtract ctx T.inst_data_value (.inst ii) st.base = .ok values at hx
  obtain ⟨info, hi, rfl⟩ := installed_extract_inv hx
  obtain ⟨env1, _, ha⟩ := matchArgs_cons_inv ha
  obtain ⟨env2, hp, _⟩ := matchArgs_cons_inv ha
  obtain ⟨fields, hu, _⟩ := matchPat_enum_inv ht hk hp
  exact ⟨info, fields, hi, hu⟩

private theorem defInst_extract {ctx : Ctx} {st : LState} {v : V} {vs : List V}
    (run : Backend.externExtract ctx T.def_inst v st = .ok vs) :
    ∃ x i,v = .value x ∧ ctx.defInst? x = some i ∧ vs = [.inst i] := by
  cases v <;> try cases run
  rename_i x
  change (match ctx.defInst? x with
    | some i => ExtResult.ok [V.inst i]
    | none => ExtResult.fail) = .ok vs at run
  cases found : ctx.defInst? x with
  | none => rw [found] at run; cases run
  | some i => rw [found] at run; cases run; exact ⟨x,i,rfl,found,rfl⟩
private theorem args_two {ctx : Ctx} {st : State} {p q : Pattern} {values : List V}
    {env bound : Isle.Interp.Env V}
    (run : matchArgs program (Stock.sem ctx) st [p,q] values env = .ok (some bound)) :
    ∃ x y,values = [x,y] ∧ ∃ middle,
      matchPat program (Stock.sem ctx) st p x env = .ok (some middle) ∧
      matchPat program (Stock.sem ctx) st q y middle = .ok (some bound) := by
  cases values with
  | nil => cases run
  | cons x values =>
    obtain ⟨middle,first,rest⟩ := matchArgs_cons_inv run
    cases values with
    | nil => cases rest
    | cons y values =>
      obtain ⟨last,second,empty⟩ := matchArgs_cons_inv rest
      cases values with
      | nil =>
        simp only [matchArgs,pure,Except.pure,Except.ok.injEq,Option.some.injEq] at empty
        subst last
        exact ⟨x,y,rfl,middle,first,second⟩
      | cons v values => cases empty
/-- Both actual extension-load root matches identify the exact source producer
and its real installed ordinary-load format before eligibility is evaluated. -/
theorem stock_extension_load_match_source {ctx : Ctx} {cfg : Config} {root fuel : Nat}
    {before matched : State} {tr trace : Array RuleId} {bound : Isle.Interp.Env V}
    (signed : Bool)
    (run : (matchRule program (Stock.sem ctx) cfg fuel
      (if signed then rule_lower_1359 else rule_lower_1300) [.inst root]).run (before,tr) =
      .ok (some bound,matched,trace)) :
    ∃ (x i : Nat) (info : IInfo) (fields : List V) (env : Isle.Interp.Env V),
      ctx.defInst? x = some i ∧ ctx.insts[i]? = some info ∧
      (Backend.sem ctx).unData 152 info.data = some (16,fields) ∧
      env[4]? = some (some (.value x)) ∧
      (matchIfLets program (Stock.sem ctx) cfg (fuel-1)
        [⟨.bind 18 5 (.wildcard 18),.term 18 221 [.var 15 4]⟩] env).run (before,tr) =
        .ok (some bound,matched,trace) := by
  cases fuel with
  | zero => rw [matchRule.eq_1] at run; cases run
  | succ fuel =>
    obtain ⟨env,args,iflets⟩ := matchRule_some_inv run
    cases signed <;> simp only [Bool.false_eq_true,↓reduceIte,rule_lower_1300,rule_lower_1359] at args iflets
    all_goals
      obtain ⟨env1,outer,empty⟩ := matchArgs_cons_inv args
      simp only [matchArgs,pure,Except.pure,Except.ok.injEq,Option.some.injEq] at empty
      subst env1
      obtain ⟨values,extract,fieldsMatch⟩ := matchPat_extract_inv data_program.t209 term_209_kind rfl outer
      change Backend.externExtract ctx T.inst_data_value (.inst root) before.base = .ok values at extract
      obtain ⟨rootInfo,rootSlot,rfl⟩ := installed_extract_inv extract
      obtain ⟨env2,_,fieldsMatch⟩ := matchArgs_cons_inv fieldsMatch
      obtain ⟨env3,unary,emptyFields⟩ := matchArgs_cons_inv fieldsMatch
      obtain ⟨fields,unpacked,unaryArgs⟩ := matchPat_enum_inv data_program.t2476 term_2476_kind unary
      obtain ⟨opcode,producerValue,rfl,opcodeEnv,opcodePattern,valuePattern⟩ := args_two unaryArgs
      obtain ⟨space,nested⟩ := matchPat_bind_inv valuePattern
      have kept := stock_pattern_keeps (k := 4) (by decide) nested
      obtain ⟨producerFields,producer,loadArgs⟩ := matchPat_extract_inv data_program.t1 term_1_kind rfl nested
      change Backend.externExtract ctx T.def_inst _ before.base = .ok producerFields at producer
      obtain ⟨x,i,rfl,defined,rfl⟩ := defInst_extract producer
      obtain ⟨loadEnv,loadPattern,_⟩ := matchArgs_cons_inv loadArgs
      obtain ⟨info,loadFields,slot,format⟩ := installed_format data_program.t2463 term_2463_kind loadPattern
      have envValue : env[4]? = some (some (.value x)) := by
        simp only [matchArgs,pure,Except.pure,Except.ok.injEq,Option.some.injEq] at emptyFields
        subst env3
        exact kept.trans (by simp [space])
      exact ⟨x,i,info,loadFields,env,defined,slot,format,envValue,iflets⟩
end Backend.Stock.Proof.ExtensionLoadPatternDraft
