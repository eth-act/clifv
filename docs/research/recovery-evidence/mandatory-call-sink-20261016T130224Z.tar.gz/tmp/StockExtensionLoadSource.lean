import StockExtensionLoadPattern
import StockCfgSinkProvenance
namespace Backend.Stock.Proof.ExtensionLoadSourceDraft
open Backend.Proof Isle Isle.Interp Isle.Aarch64 ExtensionLoadPatternDraft
variable {cfg : Config}
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
attribute [local irreducible] Isle.Aarch64.program
private theorem sink_rhs_receipt {ctx : Ctx} {st next : State} {tr tr' : Array RuleId}
    {env : Isle.Interp.Env V} {m j k ty : Nat} {body : Expr} {out : V}
    (hs : (evalExpr program (Stock.sem ctx) cfg (m + 5)
      (.let ty [(j, 13, .term 13 236 [.var 18 k])] body) env).run (st, tr) =
        .ok (some out, next, tr')) :
    ∃ unit sunk trace,
      (evalExpr program (Stock.sem ctx) cfg (m + 3)
        (.term 13 236 [.var 18 k]) env).run (st, tr) =
          .ok (some unit, sunk, trace) := by
  rw [evalExpr.eq_6] at hs
  rw [evalBinds.eq_3] at hs
  simp only [isel_monad] at hs
  cases he : (evalExpr program (Stock.sem ctx) cfg (m + 3)
      (.term 13 236 [.var 18 k]) env).run (st, tr) with
  | error e => rw [he] at hs; cases hs
  | ok pair =>
    obtain ⟨value, state⟩ := pair
    cases value with
    | none => rw [he] at hs; simp only [isel_monad] at hs; cases hs
    | some unit => exact ⟨unit, state.1, state.2, rfl⟩

/-- Actual matching and full extension-load RHS execution supply the SAME
leading sink subexecution and its real ordinary-load producer. The target and
state are derived; no producer, target binding or side-effect certificate is given. -/
theorem stock_extension_load_sink_source {ctx : Ctx} {root m n : Nat}
    {before matched next : State} {tr matchTrace trace : Array RuleId}
    {bound : Isle.Interp.Env V} {out : V} (signed : Bool)
    (matchRun : (matchRule program (Stock.sem ctx) cfg (m+5)
      (if signed then rule_lower_1359 else rule_lower_1300) [.inst root]).run (before,tr) =
      .ok (some bound,matched,matchTrace))
    (rhsRun : (evalExpr program (Stock.sem ctx) cfg (n+5)
      (if signed then rule_lower_1359 else rule_lower_1300).rhs bound).run (matched,matchTrace) =
      .ok (some out,next,trace)) :
    ∃ (i : Nat) (info : IInfo) (fields : List V) (unit : V) (sunk : State) (sinkTrace : Array RuleId),
      ctx.insts[i]? = some info ∧ (Backend.sem ctx).unData 152 info.data = some (16,fields) ∧
      (evalExpr program (Stock.sem ctx) cfg (n+3) (.term 13 236 [.var 18 5]) bound).run (matched,matchTrace) =
        .ok (some unit,sunk,sinkTrace) ∧
      sunk.sunk = before.sunk.set! i true := by
  obtain ⟨x,i,info,fields,env,defined,slot,format,envValue,iflets⟩ := stock_extension_load_match_source signed matchRun
  have eligibility : (matchIfLets program (Stock.sem ctx) cfg (m+4)
      [⟨.bind 18 5 (.wildcard 18),.term 18 221 [.var 15 4]⟩] env).run (before,tr) =
      .ok (some bound,matched,matchTrace) := by simpa using iflets
  cases signed <;> simp only [Bool.false_eq_true,↓reduceIte,rule_lower_1300,rule_lower_1359] at rhsRun
  all_goals
    obtain ⟨unit,sunk,sinkTrace,actualSink⟩ := sink_rhs_receipt rhsRun
    obtain ⟨j,definition,once,count,value,traceSame,state⟩ :=
      CfgSinkProvenanceDraft.stock_iflet_sink_resultful envValue eligibility actualSink
    have same := Option.some.inj (defined.symm.trans definition)
    subst j
    exact ⟨i,info,fields,unit,sunk,sinkTrace,slot,format,actualSink,by rw [state]⟩
end Backend.Stock.Proof.ExtensionLoadSourceDraft
