import StockOracleInvariant
import StockCallSinkTable
import StockAtomicProtected
import StockAtomicNoNone
import FV.Backend.Proof.StockSourceSinkModel
namespace Backend.Stock.Proof.CallSinkDraft
open Backend.Proof Backend.Proof.Cov Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open AtomicProtectedDraft AtomicNoNoneDraft Coverage.OracleInvariant
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
attribute [local irreducible] Isle.Aarch64.program
private theorem fresh_slot (ctx : Ctx) (st : State) :
    ctx.insts[max ctx.insts.size st.sunk.size]!.clif = none ∧
      st.sunk[max ctx.insts.size st.sunk.size]! = false := by
  constructor
  · rw [getElem!_def,Array.getElem?_eq_none (Nat.le_max_left _ _)]; rfl
  · rw [getElem!_def,Array.getElem?_eq_none (Nat.le_max_right _ _)]; rfl
private theorem atomic_answer {as : List AW} {a : AW}
    (answer : callSinkOracle 564 as = some a) : as = [.xv .inst] ∧ a = .reg 1 := by
  unfold callSinkOracle at answer
  simp only [beq_self_eq_true,ite_true] at answer
  split at answer
  · cases answer; exact ⟨rfl,rfl⟩
  · cases answer
private theorem one_input {f : Clif.Function} {ctx : Ctx} {a : AW} {vs : List V}
    (held : Holds2 f ctx [a] vs) : ∃ v,vs = [v] ∧ γ f ctx a v := by
  cases vs with
  | nil => cases held
  | cons v rest =>
    cases rest with
    | nil => exact ⟨v,rfl,held.1⟩
    | cons w rest => cases held.2
/-- All semantic contracts are derived from the original source model and the
actual atomic helper. The protected data condition is an internal source fact;
source-call wrappers derive it from their original mapped CLIF slots. -/
def callSinkModel {f : Clif.Function} {ctx : Ctx} (mapped : MappedCtxInv f ctx)
    (clean : Clean (sourceIdentityCtx ctx)) (guardedIndex : Nat)
    (different : ∀ info fields,ctx.insts[guardedIndex]? = some info →
      (Backend.sem ctx).unData 152 info.data ≠ some (17,fields)) (remembered : Bool) :
    Model sourceSinkActor callSinkPre callSinkOracle program f ctx where
  Is := fun st => st.sunk[guardedIndex]! = remembered
  source := covModel logicImmComplete mapped.identityView clean sinkState.base
  ctor := by
    intro t term lookup as vs value st next held invariant pre run
    have parts := Bool.and_eq_true.mp pre
    have fresh := fresh_slot ctx st
    let old := Coverage.sourceSinkModel mapped clean (max ctx.insts.size st.sunk.size) fresh.1
    have described := (old.ctor t term lookup as vs value st next held fresh.2 parts.1 run).1
    refine ⟨described,?_⟩
    rw [stock_ctor_noSink (bne_iff_ne.mp parts.2) run]
    exact invariant
  oracle := by
    intro cfg overlap n ty t as vs a before tr out after trace answer held invariant run
    by_cases atomic : t = 564
    · subst t
      obtain ⟨rfl,rfl⟩ := atomic_answer answer
      obtain ⟨input,rfl,described⟩ := one_input held
      obtain ⟨ii,info,inst,rfl,slot,clif,data⟩ := described.1
      cases out with
      | none => exact False.elim (stock_atomic_helper_not_none overlap run)
      | some value =>
        cases n with
        | zero => rw [applyTerm.eq_1] at run; cases run
        | succ n =>
          have frame := stock_atomic_load_preserves_other_sunk overlap different run
          have fresh := fresh_slot ctx before
          let old := Coverage.sourceSinkModel mapped clean (max ctx.insts.size before.sunk.size) fresh.1
          have checked : aApply program sourceSinkTab sourceSinkActor sourceSinkPre aOracle ty 564 [.xv .inst] = some (.reg 1) := by
            simp only [aApply,data_program.t564,T.sink_atomic_load,List.any_cons,List.any_nil,AW.isBot,
              Bool.false_or,aOracle]
            decide +kernel
          have result := (Coverage.Invariant.soundAt mapped old cfg sourceSinkTab overlap stock_sourceSink_table_checked (n+1)).apply
            ty 564 [.xv .inst] (.reg 1) [.inst ii] before tr (some value) after trace checked held fresh.2 run
          exact ⟨frame.trans invariant,result.2⟩
    · have original : aOracle t as = some a := by
        simpa only [callSinkOracle,beq_iff_eq,atomic,ite_false] using answer
      exact Coverage.oracle_sound _ cfg overlap n ty t as vs a before tr out after trace original held invariant run
end Backend.Stock.Proof.CallSinkDraft
