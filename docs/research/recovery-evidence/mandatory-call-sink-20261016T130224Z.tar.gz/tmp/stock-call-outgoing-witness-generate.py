from pathlib import Path
head='''import StockCallOutgoing
import StockGotOutgoing
import StockCallEmissionWitness
import StockGotCallWitness
namespace Backend.Stock.Proof.CallOutgoingWitnessDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Backend.Proof.PerEdgePrep Isle Isle.Interp Isle.Aarch64
open CallOutgoingDraft GotOutgoingDraft OutgoingWholeDraft
open CallStaticFixture (arguments)
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm Stock.lower
'''
allsource=head
for kind,mod,ns,cond in [('direct','StockCallEmissionWitness','CallStaticFixture','false implicit'),('got','StockGotCallWitness','GotCallFixture','implicit')]:
 s=Path('/tmp',mod+'.lean').read_text();name='stock_complete_'+kind+'_call_emission_witness';a=s.index('theorem '+name);end=s.index('      DirectRecordEmission' if kind=='direct' else '      (∃ receipt',a);sig=s[a:end].replace(name,'stock_complete_'+kind+'_call_outgoing_witness')
 signature='CallStaticFixture.signature false implicit'
 sig+='''      SigStackOk ('''+signature+''') record.output.state.base.outgoing ∧
      SigStackOk ('''+signature+''') out.result.code.outgoing ∧
      record.output.state.base.outgoing ≤ out.result.code.outgoing ∧
      out.result.code.outgoing = out.result.final.base.outgoing ∧
      (if implicit then 0 else 16) ≤ out.result.code.outgoing := by
'''
 proof='''  obtain ⟨out,event,record,info,step,scope,dominated,arity,abi,lowered,prepared,fallback,checked,physical,
    facts,events,records,slot,clif,recorded,emitted,'''+('emission,placed' if kind=='direct' else 'protocol,emission,placed')+'''⟩ :=
    '''+('CallEmissionWitnessDraft' if kind=='direct' else 'GotCallWitnessDraft')+'.'+name+''' implicit
  let ext : Clif.ExtFunc := {name := CallStaticFixture.calleeName,sig := CallStaticFixture.signature false implicit,colocated := '''+('true' if kind=='direct' else 'false')+'''}
  have declared : (function '''+cond+''').extern? 0 = some ext := rfl
  have localBound := stock_lower_'''+kind+'''_call_record_outgoing lowered scope dominated.ssa abi events records slot clif declared rfl recorded emitted
  have codeBound := stock_lower_'''+kind+'''_call_code_outgoing lowered scope dominated.ssa abi events records slot clif declared rfl recorded emitted
  have bytes : stackBytes ext.sig = (if implicit then 0 else 16) := by cases implicit <;> rfl
  exact ⟨out,event,record,info,step,scope,dominated,arity,abi,lowered,prepared,fallback,checked,physical,
    facts,events,records,slot,clif,recorded,emitted,localBound,codeBound,
    stock_lower_record_code_outgoing lowered events records,stock_lower_code_outgoing lowered,
    by rw [← bytes]; exact codeBound.1⟩
'''
 allsource+='section\nopen '+ns+'\n'+sig+proof+'end\n'
allsource+='end Backend.Stock.Proof.CallOutgoingWitnessDraft\n';Path('/tmp/StockCallOutgoingWitness.lean').write_text(allsource)
