from pathlib import Path
import os,subprocess as sp,json,datetime,hashlib,traceback
view=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');canon=Path('/home/lee/clifv/.worktrees/driver-proof-resume');root=Path('/tmp/stock-arithmetic-current-main-author-gates');root.mkdir(exist_ok=True);state=root/'progress.json';logs={}
head=sp.check_output(['git','rev-parse','HEAD'],cwd=view,text=True).strip()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def inputs():
 return {str(p.relative_to(view)):sha(p) for d in ['FV','FVTest','rust/crates','examples/fv-demo/src','scripts/audit'] for p in (view/d).rglob('*') if p.is_file() and p.suffix in ['.lean','.rs']}
frozen_sources=inputs();(root/'inputs.json').write_text(json.dumps({'head':head,'sources':frozen_sources},indent=2)+'\n')
env=dict(os.environ);env.update(PATH='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:/home/lee/.cargo/bin:/home/lee/.local/share/clifv-test-tools/usr/bin:/home/lee/.rustup/toolchains/nightly-2026-09-26-x86_64-unknown-linux-gnu/lib/rustlib/x86_64-unknown-linux-gnu/bin:'+str(view/'rust/target/release')+':'+env['PATH'],FV_ROOT=str(view),FV_AR='/home/lee/.local/share/clifv-test-tools/usr/bin/llvm-ar',FV_OBJCOPY='/home/lee/.local/share/clifv-test-tools/usr/bin/llvm-objcopy',FV_LAKE_CACHE=str(canon/'.lake/artifact-cache'),FV_MEMCAP='8G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',CARGO_BUILD_JOBS='2',CLIF_NATIVE_QEMU='/home/lee/.local/share/clifv-test-tools/usr/bin/qemu-aarch64-static',LLVM_MC='/home/lee/.local/share/clifv-test-tools/usr/bin/llvm-mc',PYTHONPATH=str(view/'scripts'))
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:8])
def report(status,**kw):
 d={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':status,'pid':os.getpid(),'head':head,'logs':logs,**kw};state.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items() if k!='logs'}),flush=True)
def frozen():
 assert sp.check_output(['git','rev-parse','HEAD'],cwd=view,text=True).strip()==head
 assert inputs()==frozen_sources,'source changed during gates'
def run(name,args,cwd=view):
 frozen();p=root/(name+'.log');report('running',phase=name,log=str(p))
 with p.open('w') as f:
  command=args if args[:2]==['python3','/tmp/stock-execute-scheduler.py'] else [str(view/'scripts/memcap.sh'),*args]
  r=sp.run(command,cwd=cwd,env=env,stdout=f,stderr=sp.STDOUT)
 assert r.returncode==0,(name,r.returncode,str(p));frozen();logs[name]={'path':str(p),'sha256':sha(p)};return p
try:
 prior_root=Path('/tmp/stock-arithmetic-semantic-reconciled-author-gates')
 prior=json.loads((prior_root/'progress.json').read_text());assert prior['state']=='per_pr_gates_passed'
 import re,tomllib
 previous_epoch=Path('/tmp/stock-arithmetic-activation-repaired-author-gates')
 old=json.loads((previous_epoch/'inputs.json').read_text());old_sources=old['sources']
 boundary=json.loads(Path('/tmp/stock-arithmetic-087-boundary-handoff.json').read_text())
 assert boundary['old_head']==old['head'] and boundary['module_source_keys_passed'] and boundary['all_modules_passed']
 assert boundary['source_fingerprints_unchanged_at_handoff']
 deps={};pat=re.compile(r'^(?:public\s+|private\s+|meta\s+)*import\s+(\S+)')
 for folder in ['FV','FVTest']:
  for p in (view/folder).rglob('*.lean'):
   deps[str(p.relative_to(view))[:-5].replace('/','.')]=set(m.group(1) for line in p.read_text().splitlines() if (m:=pat.match(line)))
 changed={p for p,h in old_sources.items() if frozen_sources.get(p)!=h}|(set(frozen_sources)-set(old_sources))
 affected={p[:-5].replace('/','.') for p in changed if p.endswith('.lean') and p.startswith(('FV/','FVTest/'))}
 while True:
  more={m for m,d in deps.items() if d&affected}-affected
  if not more:break
  affected|=more
 config_paths=['lean-toolchain','lakefile.toml','lake-manifest.json','scripts/memcap.sh']
 old_config={p:hashlib.sha256(sp.check_output(['git','show',old['head']+':'+p],cwd=view)).hexdigest() for p in config_paths}
 new_config={p:sha(view/p) for p in config_paths}
 if old_config!=new_config:affected=set(deps)
 reusable=set(deps)-affected
 assert all(old_sources.get(m.replace('.','/')+'.lean')==frozen_sources.get(m.replace('.','/')+'.lean') for m in reusable)
 affected&=set(deps)
 only=root/'affected-modules.txt';only.write_text('\n'.join(sorted(affected))+'\n')
 manifest={'old_verified_module_epoch':old['head'],'current_head':head,'upstream_main':sp.check_output(['git','rev-parse','origin/main'],cwd=view,text=True).strip(),'old_boundary_evidence':boundary,'old_config':old_config,'current_config':new_config,'changed_sources':sorted(changed),'source_and_transitive_import_closure_unchanged':sorted(reusable),'modules_remaining_to_schedule':sorted(affected),'strict_reserved_caps':True,'max_jobs':2,'budget_GiB':16,'reason':'Actual upstream main changed; preserve completed module/tools/Rust source-matching evidence, revalidate every affected import and every remaining current per-PR activation gate. No old full-gate pass claimed.'}
 (root/'reuse-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 run('all-modules',['python3','/tmp/stock-execute-scheduler.py','--budget','16G','--max-jobs','2','--max-cap','16G','--default-cap','8G','--only',str(only),'--out',str(root/'all-modules'),'FV','FVTest'])
 run('source-module-keys-current',['lake','build','--no-build','FV','FVTest'])
 run('library-and-affected-tools',['lake','build','FV','FVTest','lean-backend','lean-e2e-check','link-check','lean-link'])
 run('rust-tools',['rustup','run','nightly-2026-09-26','cargo','build','--locked','--release','--manifest-path','rust/Cargo.toml'])
 run('all-axiom-audits',['python3','scripts/axiom-audit.py','--log-dir',str(root/'axiom-audit')])
 run('owned-constants',['lake','env','lean','--root=/tmp','/tmp/stock-arithmetic-activation-all-owned.lean'])
 run('crate-proofs',['lake','build'],view/'crate-proofs')
 run('runtime',['bash','scripts/lean-backend-filetests.sh'])
 run('encoder',['bash','scripts/lean-backend-encode-check.sh'])
 parity={}
 def ids(path):
  fs=json.loads(path.read_text())['functions'];d={(f['file'],f['index'],f['function']):tuple(f['stages']) for f in fs};assert len(d)==len(fs);return d
 for label,flags,previous in [('e2e',[],'legacy-dead-cleanup-final-e2e-identities.json'),('legacy-e2e',['--no-dead-cleanup'],'legacy-dead-cleanup-final-legacy-e2e-identities.json')]:
  actual=root/(label+'-identities.json')
  run(label,['lake','exe','lean-e2e-check',*flags,'--identity-report',str(actual)])
  a=ids(Path('/tmp')/previous);b=ids(actual);assert len(a)==1150 and a.keys()<=b.keys();assert all(a[k]==b[k] for k in a)
  prior=ids(Path('/tmp/stock-all-reconcile-gates')/(label+'-identities.json'));assert len(prior)==1159 and prior.keys()<=b.keys();assert all(prior[k]==b[k] for k in prior)
  parity[label]={'original':len(a),'prior_shipped':len(prior),'current':len(b),'all_original_and_prior_identities_and_ordered_stages_preserved':True}
 (root/'identity-stage-parity.json').write_text(json.dumps(parity,indent=2)+'\n')
 bundles=sorted((view/'examples/fv-demo/target/fv/plain-leanlink-verified-leanld/bin-check').glob('*/bundle.json'))
 assert bundles,'verified fv-demo source bundle missing'
 for i,p in enumerate(bundles):
  run(f'link-check-{i}',['lake','exe','link-check',str(p.parent)])
 generated=Path('/tmp/stock-d0-linked-fixture')
 leanpath=sp.check_output(['lake','env','printenv','LEAN_PATH'],cwd=view,env=env,text=True).strip()
 env['LEAN_PATH']=str(generated)+':'+leanpath
 for name in ['StockD0MixedPlain','StockD0MixedCleanup']:
  p=generated/'Crates'/(name+'.lean');assert p.is_file()
  run('generated-'+name,['lean','--root='+str(generated),'-o',str(p.with_suffix('.olean')),str(p)])
 env.pop('LEAN_PATH',None)
 run('actual-linked-generated-proofs',['python3','/tmp/stock-production-linked-proper-check.py'])
 run('production-runtime',['lake','env','lean','--run','FVTest/Backend/Lowering/StockProductionRuntime.lean'])
 run('all-configurations-runtime',['lake','env','lean','--run','FVTest/Backend/Lowering/StockProductionAllRuntime.lean'])
 run('all-configurations-linked-proofs',['python3','/tmp/stock-production-all-linked-check.py'])
 run('production-cli-original-bundles',['python3','/tmp/stock-production-cli-original-bundles-check-semantic.py'])
 run('production-cli-all-configurations',['python3','/tmp/stock-production-all-cli-check-semantic.py'])
 run('scalar-runtime',['lake','env','lean','--run','FVTest/Backend/Lowering/StockScalarRuntime.lean'])
 run('scalar-regalloc2-matched',['lake','env','lean','--root=/tmp','--run','/tmp/StockScalarRegalloc2Comparison.lean'])
 run('scalar-linked-proofs',['python3','/tmp/stock-scalar-linked-check.py'])
 run('scalar-real-cli',['python3','/tmp/stock-scalar-cli-check-semantic.py'])
 run('arithmetic-dual-allocator-runtime',['lake','env','lean','--run','FVTest/Backend/Lowering/StockArithmeticRuntime.lean'])
 run('arithmetic-linked-generated-proofs',['python3','/tmp/stock-arithmetic-linked-check.py'])
 run('arithmetic-native-cli',['python3','/tmp/stock-arithmetic-cli-check.py'])
 for example in ['fv-demo','survey']:
  run('verified-'+example,['bash','examples/compare.sh','examples/'+example,'--lean-link','--verified','--keep-temps'])
 def axioms(folder):
  out={}
  for p in Path(folder).glob('*.log'):
   flat=' '.join(p.read_text().split())
   for n,a in re.findall(r"'(.+?)' depends on axioms: \[([^\]]*)\]",flat):out[n]=sorted(x.strip() for x in a.split(',') if x.strip())
   for n in re.findall(r"'(.+?)' does not depend on any axioms",flat):out[n]=[]
  return out
 before=axioms(prior_root/'axiom-audit');after=axioms(root/'axiom-audit');assert len(before)>=1181
 missing=sorted(set(before)-set(after));drift={n:{'before':v,'after':after.get(n)} for n,v in before.items() if n in after and after[n]!=v}
 parity_axioms={'previous_roots':len(before),'current_roots':len(after),'missing':missing,'changed_sets':drift,'all_previous_axiom_sets_preserved':not missing and not drift};(root/'axiom-set-parity.json').write_text(json.dumps(parity_axioms,indent=2)+'\n');assert parity_axioms['all_previous_axiom_sets_preserved'],parity_axioms
 report('per_pr_gates_passed',identity_stage_parity=parity,remaining='Fetch current main, reconcile if needed, open non-draft implementation PR and author squash promptly. Full original #140 remains active.')
except BaseException as e:
 report('failed',error=repr(e),traceback=traceback.format_exc());raise
