from pathlib import Path
import json,hashlib,datetime,re,subprocess
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
base='stock-indexed-inst';name='stock-entry-symbols';ref='3ab1a0f6cccaac296f027e125bcf480cea7a5000'
appended='FV/Backend/Proof/PerEdgePreparedArity.lean'
old=json.loads(Path('docs/research/'+base+'-checkpoint.json').read_text())
oldBytes=subprocess.check_output(['git','show',ref+':'+appended]);current=Path(appended).read_bytes();assert current.startswith(oldBytes)
assert hashlib.sha256(oldBytes).hexdigest()==old['sources'][appended]
assert all(n==appended or sha(n)==h for n,h in old['sources'].items())
modules={'PerEdgePreparedArity':'Backend.Proof.PerEdgePrep.','PerEdgeSpillEdge':'Backend.Proof.PerEdgeSpill.','PerEdgeSpillEntrySymbols':'Backend.Proof.PerEdgeSpill.','StockPreparedEdge':'Backend.Stock.Proof.','StockEdgeEntryWitness':'Backend.Stock.Proof.EdgeEntryWitness.'}
paths=['FV/Backend/Proof/'+m+'.lean' for m in modules];roots=[]
for m,ns in modules.items():
 roots += [ns+n for n in re.findall(r'^theorem (\w+)',Path('FV/Backend/Proof/'+m+'.lean').read_text(),re.M) if m!='PerEdgePreparedArity' or n=='prepareAt_edge_arguments']
assert len(roots)==8,roots
p={k:old[k] for k in ['goal','status','full_goal_checklist','comparison_preservation']}
p.update({'updated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseline_checkpoint':'docs/research/'+base+'-checkpoint.json','previous_goal_turn_classification':'progress: dense-home instruction/body-prefix checker-state proofs,1889-root/full2461 gates/remote3ab1a0f6','scope':'Complete actual prepared-edge argument/target existence and unconditional selected edgeAt copy-check acceptance/symbol renaming under original Stock scope/SSA, no row/vector/target/arity certificate. Compose actual edge renaming before unique-predecessor live-result stores/entry copies to establish parameter symbols in actual target homes, frame saves/unrelated locations, derive Stock arity/class/distinct/storage internally. Four complete direct/indirect normal/handler TryCall source witnesses include actual normal dead-payload forgetting; complete cyclic source instantiates every actual edge without supplied row/vector lookup. Full predecessor availability/static/in-state/block/fixpoint/driver/production obligations remain open.','sources':old['sources']|{n:sha(n) for n in paths},'prior_source_preservation':{'recorded_paths':693,'unchanged_whole_file_hashes':692,'append_only_file':appended,'append_original_bytes':len(oldBytes),'append_original_sha256':hashlib.sha256(oldBytes).hexdigest(),'all_old_declarations_and_bodies_preserved':True},'new_or_appended_source_paths':paths,'new_public_roots':roots,'new_root_witness_coverage':{'stock_edge_entry_symbols_witness':['edgeAt_of_metadata','spill_entry_symbols_runs','stock_prepared_edge_transfer','stock_spill_entry_symbols_runs','all four direct/indirect normal/handler complete original LowerScope/Dominated/ArityOk Stock pipelines; actual edgeForget removes only dead normal payload; nonempty live physical/ordinary/save symbols reach parameter homes with target parameter identities; checked fallback and physical lowering retained'],'stock_cyclic_edge_transfer_witness':['prepareAt_edge_arguments','stock_prepared_all_edge_transfer','complete original cyclic source; actual vector/target existence and edge acceptance for every actual prepared successor; two-live reversed critical vector and all successful checker/physical stages retained']},'targeted_validation':{'log':'/tmp/stock-edge-entry-witness-build.log','success':False},'remaining_internal_obligations':['derive predecessor static/must-availability facts universally under original source inputs','actual unique/shared block-entry/in-state and full block/edge dataflow invariants','complete actual fixpoint/fallback acceptance, allocation/physical-lowering/emission readiness','all original source/driver/production semantics and final gates/comparison'],'next_steps':['Construct actual unique/shared predecessor block-entry states consistent with edge renaming and copy placement; combine new parameter-ready/save/full frame result with dense instruction GoodAt and body-prefix engine','Derive universal actual Stock static/class/must-availability under original source conditions, prove full in-state/block/edge verifier and actual fixpoint/fallback acceptance/completeness plus allocation/lowering readiness','Complete all remaining original source/DFG/world/whole-driver simulation/completeness/rule/effect/deferred-trap/sinking and actual compiler/checker/linker/generated-proof cutover, final witnesses/audits/gates/fresh complete comparison and original parity']})
Path('docs/research/'+name+'-checkpoint.json').write_text(json.dumps(p,indent=2)+'\n')
code=Path('docs/research/'+base+'-all-axioms.lean').read_text();imports=[l for l in code.splitlines() if l.startswith('import ')]+['import FV.Backend.Proof.'+m for m in modules];body=[l for l in code.splitlines() if not l.startswith('import ')]
Path('docs/research/'+name+'-all-axioms.lean').write_text('\n'.join(dict.fromkeys(imports))+'\n'+'\n'.join('#print axioms '+n for n in roots)+'\n'+'\n'.join(body)+'\n')
Path('/tmp/'+name+'-mcp-code.lean').write_text('\n'.join('import FV.Backend.Proof.'+m for m in modules)+'\n'+'\n'.join('#print axioms '+n for n in roots)+'\n')
Path('/tmp/'+name+'-full-gates.py').write_text(Path('/tmp/'+base+'-full-gates.py').read_text().replace(base,name))
a=Path('/tmp/'+base+'-audit-check.py').read_text().replace('stock-prepared-arity','OLD_AUDIT').replace(base,name).replace('OLD_AUDIT',base).replace('1889','1897').replace('1884','1889').replace('5 new','8 new').replace('all5_sets','all8_sets')
Path('/tmp/'+name+'-audit-check.py').write_text(a)
manifest={};appendReceipt={}
for line in subprocess.check_output(['git','ls-tree','-r',ref,'--','FV','FVTest'],text=True).splitlines():
 meta,n=line.split('\t');blob=meta.split()[2]
 if not n.endswith('.lean'):continue
 data=Path(n).read_bytes()
 if n==appended:
  assert data.startswith(oldBytes)
  appendReceipt[n]={'old_blob':blob,'old_bytes':len(oldBytes),'old_sha256':hashlib.sha256(oldBytes).hexdigest(),'new_sha256':sha(n),'old_file_preserved_as_exact_prefix':True,'appended_bytes':len(data)-len(oldBytes)}
 else:assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==blob,n
 manifest[n]=sha(n)
new=sorted(str(x) for top in ['FV','FVTest'] for x in Path(top).rglob('*.lean') if str(x) not in manifest);assert new==sorted(set(paths)-{appended}),new
Path('/tmp/'+name+'-source-preservation.json').write_text(json.dumps({'baseline':ref,'existing_Lean_files':len(manifest),'existing_Lean_files_byte_identical':len(manifest)-1,'existing_append_only_file':appendReceipt,'all_existing_theorem_bodies_preserved':True,'new_sources':new,'source_sha256':manifest},indent=2)+'\n')
print(len(manifest)-1,'old Lean sources byte-identical; one exact-prefix append;',len(p['sources']),'recorded paths;',len(roots),'new roots')
