from pathlib import Path
import json,hashlib,datetime,tarfile,subprocess,re
root=Path('/home/lee/clifv/.worktrees/driver-proof-resume');name='stock-prepare-no-split'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
receipt=root/'docs/research'/f'{name}-checkpoint.json';p=json.loads(receipt.read_text())
assert p['full_gates']['full_build_jobs']>=2499
for n,h in p['sources'].items():assert sha(root/n)==h,n
p.update(json.loads(Path('/tmp/'+name+'-audit-receipt.json').read_text()))
preserve=Path('/tmp/'+name+'-source-preservation.json');p['all_existing_source_preservation']={k:v for k,v in json.loads(preserve.read_text()).items() if k!='source_sha256'};p['all_existing_source_preservation'].update(manifest=str(preserve),sha256=sha(preserve))
log=Path('/tmp/stock-prepare-no-split-witness-build.log');assert 'Build completed successfully' in log.read_text()
p['targeted_validation']={'path':str(log),'sha256':sha(log),'success':True,'jobs':int(re.search(r'Build completed successfully \((\d+) jobs\)',log.read_text())[1])}
p['full_goal_checklist']['per_successor_consumer_migration']='Stock actual initial/reachable-filtered CFG is critical-edge free under unchanged original scope. Actual prepareAt creates no further synthetic blocks/rows/fresh labels; full indexed pre-RPO graph preserved, including duplicate destinations. Actual generic predecessor multiplicity/selected-edge uniqueness and real filtered-edge reflection/injective origin established. Complete cyclic and direct/indirect forced TryCall witnesses retain all original conditions/raw/checked/physical stages. RPO incoming reflection and universal prepared shared-target jump classification remain required; full static/class/dataflow/EntryAvailAt/block/edge/fixpoint/fallback acceptance/completeness/allocation/physical readiness still open. No new source filter.'
p['full_goal_checklist']['kernel_public_root_transitive_axiom_audits']='1961 normal roots pass; all1945 old sets/seven exact compiler sets preserved;16 new roots standard-only and match one bundled MCP. Final production audits remain required.'
p['full_goal_checklist']['build_crates_runtime_encoder_both_E2E_identity_stage']='Full2499/crates1171/runtime4672/0/0(same7/families)/encoder1292/0/both E2E1150/0; all original identity/stage report bytes/420 comparison-source hashes preserved. Final production gates/fresh complete comparison remain mandatory.'
p['resources']['free_GiB']=int(subprocess.check_output(['df','-B1','--output=avail',str(root)],text=True).splitlines()[-1])//2**30
p['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
text=f'''Seven additive proof/witness modules derive actual Stock preparation's no-additional-split property under the original source scope. All1973 previous FV/FVTest Lean files and all724 previous recorded hashes remain byte-identical to remote WIP e24299ff. No compiler/runtime/input predicate or old theorem body changed.

IndexedPredMultiplicity relates the executable predecessor arrays to distinct indexed incoming occurrences, counts duplicate destinations separately, derives a second occurrence for shared targets, and proves exact indexed uniqueness for low-degree targets. FilteredGraphIncoming reflects each actual kept CFG edge to its original selected successor index and injective original block index; successor counts and critical-free graph shape survive real reachable filtering. StockNoCriticalEdges combines actual shared-source singleton-jump classification and actual multiplicity to derive critical-free initial/kept graphs. These are internal producer-derived properties, never new accepted-source conditions.

PerEdgePrepareNoSplit proves that the real inner/outer execution adds no synthetic blocks/rows or fresh labels when its actual graph is critical-edge free. PerEdgePrepareUnsplitGraph uses the existing complete splitting invariant to prove full indexed successor graph equality when synthetic blocks are empty; labels, edge indices and duplicate destinations are retained. StockPrepareNoSplit derives the actual original scope/domain/graph premises internally and exposes real kept CFG, outer execution, empty synthetic vectors, unchanged next label, unchanged pre-RPO successor graph, and exact final RPO result. Existing generic preparation and source theorem variants remain intact.

StockPrepareNoSplitWitness retains complete original LowerScope/Dominated/ArityOk cyclic and direct/indirect forced one-successor TryCall sources, including the unreachable source predecessor, with every raw preparation/global checked fallback/physical stage. Actual no-additional-split/graph-equality stage premises are inhabited. The cyclic witness additionally exercises actual shared-loop predecessor multiplicity, low-degree exit indexed uniqueness and real reachability-filter selected-edge/origin reflection. These structural/checker-stage results do not establish full source/Arm simulation or universal fallback acceptance.

Normal1961-root audit preserves all1945 prior/seven exact compiler axiom sets;16 new standard-only roots match one bundled MCP. Target{p['targeted_validation']['jobs']}/full{p['full_gates']['full_build_jobs']}/crates1171/runtime4672/0/0(same7/families)/encoder1292/0/both E2E1150/0 pass. Original identity/stage report bytes and all420 comparison source hashes unchanged. Final production audits/gates/fresh complete comparison remain required. OMP2/LEAN2, bounded memcap, persistent project QEMU; no new tree/cache;{p['resources']['free_GiB']}GiB free. Cleanup reviewed; all dirty work/source/evidence/recovery archives retained; other projects untouched.

Next reflect RPO incoming occurrences injectively through the unchanged pre-RPO graph and actual reachable filtering; derive universal prepared shared-target predecessor jump classification. Compose arbitrary full block/edge verification, derive universal original-input static/class/must-availability/EntryAvailAt and checker/fallback fixpoint acceptance/completeness/allocation/physical readiness. Every original source/DFG/world/block/whole-driver simulation/completeness, uncovered families/effects/traps/sinking and actual compiler/checker/linker/generated-proof production cutover remains mandatory, with complete production witnesses, final audits/gates/fresh full comparison and original input/theorem/axiom/identity/stage/#179 parity. Coordinate kevaundray FV/Link/source/depth/peak/default/verified interfaces before cutover. #140 active/incomplete; production legacy.
'''
source=root/'docs/research'/f'{name}-source.md';source.write_text('# Actual preparation without additional splits\n\n'+text)
plan=root/'docs/plans/test-binary-alignment-recovery.md';plan.write_text('## Actual preparation without additional splits — '+p['updated_utc']+'\n\n'+text+'\n'+plan.read_text())
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');folder=Path('/home/lee/.clifv-recovery')/(stamp+'-prepare-no-split');folder.mkdir(parents=True);archive=folder/'checkpoint.tar.gz'
p['evidence_archive']={'path':str(archive),'sha256_receipt':'separate receipt after archive creation'};receipt.write_text(json.dumps(p,indent=2)+'\n')
paths=[receipt,source,plan,root/'docs/research'/f'{name}-all-axioms.lean',root/'docs/research'/f'{name}-mcp.json',preserve,log,Path('/tmp/'+name+'-axioms.log'),Path('/tmp/'+name+'-audit-receipt.json'),Path('/tmp/'+name+'-full-controller.log')]
paths += [Path(x['path']) for x in p['full_gate_logs'].values()]+[Path('/tmp/'+name+'-full-'+s+'.json') for s in ['identities','legacy-identities']]
paths += [root/n for n in p['new_or_appended_source_paths']]
paths += [Path('/tmp/'+name+'-'+s+'.py') for s in ['generate','full-gates','audit-check','finalize','backup']]
paths += [Path('/tmp/clifv-footprint-statuses.json'),Path('/tmp/clifv-footprint-prior44.md'),Path('/tmp/clifv-footprint-updated44.md'),Path('/tmp/stock-prepare-no-split-progress44.md'),root/'docs/research/workspace-footprint-audit.json',root/'AGENTS.md',Path('/home/lee/clifv/AGENTS.md'),Path('/home/lee/clifv/scripts/agent-worktree.sh')]
with tarfile.open(archive,'w:gz') as t:
 for i,path in enumerate(paths):t.add(path,arcname=f'{i:02d}/'+path.name)
with tarfile.open(archive,'r:gz') as t:
 assert len(t.getmembers())==len(paths)
 for member,path in zip(t.getmembers(),paths):assert t.extractfile(member).read()==path.read_bytes(),str(path)
r={'path':str(archive),'sha256':sha(archive),'members':len(paths),'bytes':archive.stat().st_size};Path('/tmp/'+name+'-archive-receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
