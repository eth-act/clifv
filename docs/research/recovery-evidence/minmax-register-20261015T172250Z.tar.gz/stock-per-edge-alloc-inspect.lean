import FV.Backend.Proof.StockCriticalValues
import FV.Backend.RegallocPerEdge
open Backend Backend.Stock
private def f : Clif.Function := {
  name := "stock_per_successor_migration"
  sig := {params := [⟨.i64,.none,.normal⟩],returns := [⟨.i64,.none,.normal⟩],callConv := some .systemV}
  blocks := [{id := 0,params := [(7,.i64)],term := .brif 7 ⟨1,[7]⟩ ⟨2,[7]⟩},
    {id := 1,params := [(31,.i64)],term := .ret [31]}, {id := 2,params := [(47,.i64)],term := .ret [47]}] }
private def rf : RFunc := { spillSlots := 0,saved := [],blocks := #[
  #[.op 0 #[.reg (.x 0)],.op 1 #[.reg (.x 0)]],
  #[.op 0 #[.reg (.x 0)]],#[.op 0 #[.reg (.x 0)]]] }
#eval (Stock.lower f).map fun r => (checkAlloc r.code rf,checkAllocAt r.code r.edgeArgs rf)
