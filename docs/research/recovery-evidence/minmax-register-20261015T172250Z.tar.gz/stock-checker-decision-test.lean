import FV.Backend.RegallocPerEdge
local instance : DecidableEq (Except String Unit) := fun a b =>
  match a,b with
  | .ok (),.ok () => isTrue rfl
  | .error a,.error b =>
    if h : a = b then isTrue (congrArg Except.error h)
    else isFalse (fun eq => h (Except.error.inj eq))
  | .ok (),.error _ => isFalse (fun h => by cases h)
  | .error _,.ok () => isFalse (fun h => by cases h)
example : (Except.ok () : Except String Unit) = .ok () := by decide +kernel
example : (Except.error "x" : Except String Unit) ≠ .ok () := by decide +kernel
