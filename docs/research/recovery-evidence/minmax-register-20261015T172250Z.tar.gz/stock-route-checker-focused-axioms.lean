import FV.Backend.Proof.StockPerEdgeCheckerWitness
import FV.Backend.Proof.StockPerEdgeDirectWitness
import FV.Backend.Proof.StockCriticalValuesWitness
#print axioms Backend.Stock.Proof.stock_lower_selected_route_values
#print axioms Backend.Proof.PerEdge.verifyBlock_ok
#print axioms Backend.Proof.PerEdge.verify_ok
#print axioms Backend.Proof.PerEdge.checkAlloc_ok
#print axioms Backend.Proof.PerEdge.edgeCopy_ok
#print axioms Backend.Proof.PerEdge.edge_ok
#print axioms Backend.Stock.Proof.PerEdgeCheckerWitness.stock_per_edge_checker_witness
#print axioms Backend.Stock.Proof.PerEdgeCheckerWitness.stock_per_edge_checker_value_witness
#print axioms Backend.Stock.Proof.CriticalValuesWitness.stock_critical_selected_route_witness
#print axioms Backend.Stock.Proof.PerEdgeDirectWitness.stock_direct_selected_route_witness
