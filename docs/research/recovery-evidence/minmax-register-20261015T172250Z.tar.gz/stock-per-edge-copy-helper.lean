import FV.Backend.Proof.PerEdgeRegallocLemmas
import FV.Backend.Proof.StockPerSuccessorWitness
namespace Backend.Stock.Proof.PerEdgeCopyTest
open Backend.Proof Backend.Proof.Driver
private def allocated : RFunc := { spillSlots := 0,saved := [],blocks := #[
  #[.op 0 #[.reg (.x 0)],.op 1 #[.reg (.x 0)]],
  #[.op 0 #[.reg (.x 0)]],#[.op 0 #[.reg (.x 0)]]] }
private def checker (result : Result) : CheckCtx := ⟨result.code,#[#[2,1],#[],#[]],allocated,128⟩
private def before : AState := AState.define (Array.replicate 128 []) (.reg (.x 0)) (.vreg 192)
private def after (index : Nat) : AState := before.parCopy [if index = 0 then 193 else 194] [192]
private def memory (word : CV) : Loc → CV := upd (fun _ => 0) (.reg (.x 0)) word
private def registers (word : CV) : Nat → CV := upd (fun _ => 0) 192 word
private theorem before_inv (word : CV) : Inv (fun _ value => value) before (memory word) (registers word) (fun _ => 0) := by
  have empty : Inv (fun (_ : Reg) (value : CV) => value) (Array.replicate 128 [])
      (fun _ => 0) (fun _ => 0) (fun _ => 0) := by
    intro location symbol member
    cases found : location.index <;> simp [AState.get,found,Array.getD] at member
  exact Inv_define (.reg (.x 0)) 192 word empty
private theorem copied_member (index : Nat) (bound : index < 2) :
    Sym.vreg (if index = 0 then 193 else 194) ∈ (after index).get (.reg (.x 0)) := by
  have positions : index = 0 ∨ index = 1 := by omega
  rcases positions with rfl | rfl <;> decide +kernel
private theorem copy_run {result : Result} (size : result.code.blocks.size = 3)
    (row : result.edgeArgs[0]? = some #[#[Reg.vreg 192 .int],#[Reg.vreg 192 .int]])
    (params1 : (result.code.blocks[1]!).params = #[.vreg 194 .int])
    (params2 : (result.code.blocks[2]!).params = #[.vreg 193 .int])
    (index : Nat) (bound : index < 2) :
    (checker result).edgeCopyAt result.edgeArgs 0 (2-index) index before = .ok (after index) := by
  have h0 : 0 < result.code.blocks.size := by omega
  have ht : 2-index < result.code.blocks.size := by omega
  have source : result.code.blocks[0]? = some result.code.blocks[0]! := by
    simp [getElem!_def,Array.getElem?_eq_getElem h0]
  have target : result.code.blocks[2-index]? = some result.code.blocks[2-index]! := by
    simp [getElem!_def,Array.getElem?_eq_getElem ht]
  have positions : index = 0 ∨ index = 1 := by omega
  unfold CheckCtx.edgeCopyAt
  dsimp only [checker]
  rw [source,target]
  rcases positions with rfl | rfl <;> simp [row,params1,params2,ensure,vregNum,after,List.mapM_cons]
end Backend.Stock.Proof.PerEdgeCopyTest
