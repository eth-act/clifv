"""Verify terminal evidence before preparing the arithmetic activation PR.
Read-only while gates run; never edits a worktree or pushes/merges anything.
"""
from pathlib import Path
import ast,datetime,hashlib,json,subprocess as sp
view=Path('/home/lee/clifv/.worktrees/stock-driver-incremental')
root=Path('/tmp/stock-arithmetic-activation-repaired-author-gates')
controller=Path('/tmp/stock-arithmetic-activation-repaired-author-gates.py')
expected_head='087e91d1615c8c944e560c050c1eb7c60981d205'
expected_base='7e88a27a3a15fd855177ca0b666e61a0ca6e5866'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(*args):return sp.check_output(['git',*args],cwd=view,text=True).strip()
def emit(state,**kw):print(json.dumps({'state':state,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),**kw}),flush=True)
state=json.loads((root/'progress.json').read_text())
assert state['head']==expected_head
if state['state']!='per_pr_gates_passed':
 pid=state['pid'];cmd=Path(f'/proc/{pid}/cmdline')
 live=cmd.exists() and str(controller).encode() in cmd.read_bytes()
 emit('author_gate_in_progress' if live else 'author_gate_not_live',controller_live=live,controller_pid=pid,gate_state=state['state'],phase=state.get('phase'),evidence=str(root/'progress.json'))
 raise SystemExit(0)
assert git('rev-parse','HEAD')==expected_head
assert git('branch','--show-current')=='agent/stock-arithmetic-production-landing'
assert not git('diff','--name-only') and not git('diff','--cached','--name-only')
frozen=json.loads((root/'inputs.json').read_text());assert frozen['head']==expected_head
actual={str(p.relative_to(view)):sha(p) for d in ['FV','FVTest','rust/crates','examples/fv-demo/src','scripts/audit'] for p in (view/d).rglob('*') if p.is_file() and p.suffix in ['.lean','.rs']}
assert actual==frozen['sources'],'frozen source set/hash changed'
required=set()
for node in ast.walk(ast.parse(controller.read_text())):
 if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id=='run' and node.args and isinstance(node.args[0],ast.Constant):required.add(node.args[0].value)
required.update(['e2e','legacy-e2e','verified-fv-demo','verified-survey','generated-StockD0MixedPlain','generated-StockD0MixedCleanup'])
logs=state['logs'];assert required<=logs.keys(),sorted(required-logs.keys())
assert any(k.startswith('link-check-') for k in logs),'missing actual example bundle link-check'
for name,record in logs.items():assert sha(record['path'])==record['sha256'],('gate output changed',name)
axioms=json.loads((root/'axiom-set-parity.json').read_text())
assert axioms['previous_roots']>=1181 and axioms['all_previous_axiom_sets_preserved']
assert not axioms['missing'] and not axioms['changed_sets']
identity=json.loads((root/'identity-stage-parity.json').read_text())
assert set(identity)=={'e2e','legacy-e2e'}
for mode,record in identity.items():
 assert record['original']==1150 and record['prior_shipped']==1159 and record['current']>=1159 and record['all_original_and_prior_identities_and_ordered_stages_preserved'],(mode,record)
# Fetch only after terminal validation; new main requires an explicit reconciliation review.
git('fetch','origin','main');current_main=git('rev-parse','origin/main')
result={'state':'ready_for_receipt_and_pr' if current_main==expected_base else 'main_reconciliation_required','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'validated_head':expected_head,'base_main':expected_base,'current_main':current_main,'source_files_verified':len(actual),'gate_records_verified':len(logs),'identity_stage_parity':identity,'axiom_set_parity':axioms,'gate_logs':logs,'remaining':'Write source+receipt documentation commit, open non-draft substantive PR, author squash after final source/tree review, verify squash tree, notify integrator; full original#140 remains active.'}
Path('/tmp/stock-arithmetic-ready-to-land.json').write_text(json.dumps(result,indent=2)+'\n')
emit(result['state'],validated_head=expected_head,current_main=current_main,source_files_verified=len(actual),gate_records_verified=len(logs),receipt='/tmp/stock-arithmetic-ready-to-land.json')
