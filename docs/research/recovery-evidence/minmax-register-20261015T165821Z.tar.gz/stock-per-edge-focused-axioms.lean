import FV.Backend.Proof.StockPerEdgeDirectWitness
import FV.Backend.Proof.StockCriticalValuesWitness
#print axioms Backend.Stock.Proof.stock_lower_original_outgoing
#print axioms Backend.Stock.Proof.stock_lower_critical_outgoing
#print axioms Backend.Stock.Proof.stock_lower_selected_outgoing
#print axioms Backend.Stock.Proof.stock_lower_deferred_outgoing
#print axioms Backend.Stock.Proof.stock_lower_critical_argument_vector
#print axioms Backend.Proof.edgeEnvAt_eq
#print axioms Backend.Stock.Proof.stock_lower_direct_per_edge_values
#print axioms Backend.Stock.Proof.stock_lower_critical_per_edge_values
#print axioms Backend.Stock.Proof.CriticalValuesWitness.stock_critical_per_edge_step_witness
#print axioms Backend.Stock.Proof.PerEdgeDirectWitness.stock_direct_per_edge_step_witness
