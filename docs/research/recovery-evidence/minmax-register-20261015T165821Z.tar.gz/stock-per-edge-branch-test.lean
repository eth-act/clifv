import FV.Backend.Proof.StockPerEdgeValues
namespace Backend.Stock.Proof.PerEdgeDirectTest
open Backend.Proof Backend.Proof.Driver
set_option pp.explicit true
private def function : Clif.Function := {
  name := "stock_per_successor_migration"
  sig := {params := [⟨.i64,.none,.normal⟩],returns := [⟨.i64,.none,.normal⟩],callConv := some .systemV}
  blocks := [{id := 0,params := [(7,.i64)],term := .brif 7 ⟨1,[7]⟩ ⟨2,[7]⟩},
    {id := 1,params := [(31,.i64)],term := .ret [31]}, {id := 2,params := [(47,.i64)],term := .ret [47]}] }
private def first (word : BitVec 64) : Clif.Frame := {
  func := function,regs := Clif.Regs.empty.set 7 ⟨.i64,word⟩,slots := [],body := [],term := .brif 7 ⟨1,[7]⟩ ⟨2,[7]⟩ }
private def after (word : BitVec 64) (index : Nat) : Clif.Frame := {
  first word with regs := (first word).regs.set (if index = 0 then 31 else 47) ⟨.i64,word⟩,term := .ret [if index = 0 then 31 else 47] }
example (word : BitVec 64) :
    let index := if word = (0#64) then 1 else 0
    Clif.stepTerm Clif.Env.empty {funcs := []} ⟨first word,[],Clif.Mem.empty⟩
      (.brif 7 ⟨1,[7]⟩ ⟨2,[7]⟩) = .next ⟨after word index,[],Clif.Mem.empty⟩ := by
  dsimp only
  by_cases zero : word = (0#64)
  · subst word; rfl
  · have truth : Clif.Sem.truthy (⟨.i64,word⟩ : Clif.Val).bits = true := by
      unfold Clif.Sem.truthy
      exact bne_iff_ne.mpr zero
    simp only [Clif.stepTerm]
    have get : (first word).get 7 = .ok (⟨.i64,word⟩ : Clif.Val) := rfl
    rw [get]
    simp only [Clif.StepResult.ofRes,truth,ite_true,zero,ite_false]
    rfl
end Backend.Stock.Proof.PerEdgeDirectTest
