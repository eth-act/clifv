import FV.Backend.Proof.IselCtlBrif
namespace Backend.Proof
example (word : BitVec 64) (world : Arm.ArmState) (a : CV) (low : opnd .size64 a = word) :
    ispec (.condBr 2 1 (.notZero (.vreg 192 .int) .size64)) [a] world =
      some ([],world,.goto (if word = (0#64) then 1 else 0)) := by
  by_cases zero : word = (0#64)
  · have holds : condBrHolds (.notZero (.vreg 192 .int) .size64) [a] world = false := by
      rw [condBrHolds_notZero]
      exact bne_eq_false_iff_eq.mpr (low.trans zero)
    simp only [ispec,holds,zero,ite_true,Bool.false_eq_true,ite_false]
  · have holds : condBrHolds (.notZero (.vreg 192 .int) .size64) [a] world = true := by
      rw [condBrHolds_notZero]
      exact bne_iff_ne.mpr (fun eq => zero (low.symm.trans eq))
    simp only [ispec,holds,zero,ite_true,ite_false]
end Backend.Proof
