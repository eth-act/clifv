from pathlib import Path
import os,signal,time,subprocess as sp,json,datetime
sched=1763255;out=Path('/tmp/stock-mixed-next-four-gib-slot-batch56');out.mkdir(exist_ok=True)
def report(state,**kw):
 j={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':state,'pid':os.getpid(),'scheduler':sched,**kw};(out/'progress.json').write_text(json.dumps(j,indent=2)+'\n');print(json.dumps(j),flush=True)
def available():
 caps=[];handles=[]
 for k in Path(f'/proc/{sched}/task/{sched}/children').read_text().split():
  p=Path('/proc')/k
  try:
   if p.joinpath('stat').read_text().split()[2]=='Z':continue
   values=[v.decode().split('=',1)[1] for v in p.joinpath('environ').read_bytes().split(b'\0') if v.startswith(b'FV_MEMCAP=')]
  except FileNotFoundError:continue
  assert len(values)==1,(k,values)
  c=values[0];caps.append(int(c[:-1])*(1024 if c[-1]=='G' else 1));handles.append(k)
 return handles,caps
report('waiting_for_at_least_4GiB_and_one_build_slot')
while True:
 cmd=Path(f'/proc/{sched}/cmdline')
 if not cmd.exists():report('primary_scheduler_terminal_revalidate_before_build');raise SystemExit(0)
 assert b'stock-execute-scheduler.py' in cmd.read_bytes()
 handles,caps=available()
 if len(handles)<=1 and sum(caps)<=12288:
  stopped=False
  try:
   os.kill(sched,signal.SIGSTOP);stopped=True
   report('running_bounded_normal_batch56',existing_author_handles=handles,existing_caps_MiB=caps)
   with (out/'batch.log').open('w') as f:r=sp.run(['python3','/tmp/stock-mixed-normal-modules-batch56.py'],stdout=f,stderr=sp.STDOUT)
   assert r.returncode==0,('batch56_failed',r.returncode)
   report('batch56_terminal',receipt='/tmp/stock-mixed-current-main-normal-modules-batch56/receipt.json')
  finally:
   if stopped:os.kill(sched,signal.SIGCONT)
   print('primary scheduler resumed',flush=True)
  raise SystemExit(0)
 time.sleep(.5)
