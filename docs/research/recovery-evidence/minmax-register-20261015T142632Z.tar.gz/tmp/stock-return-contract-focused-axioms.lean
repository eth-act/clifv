import FV.Backend.Proof.StockReturnSourceWitness
import FV.Backend.Proof.StockTermContractWitness
#print axioms Backend.Stock.Proof.ReturnABI.ordinary
#print axioms Backend.Stock.Proof.LowerTermOkABI.legacy
#print axioms Backend.Stock.Proof.RunOkABI.prefix
#print axioms Backend.Stock.Proof.RunOkABI.legacy
#print axioms Backend.Stock.Proof.runOkABI_of_return_stop
#print axioms Backend.Stock.Proof.stock_lower_return_record_runOk
#print axioms Backend.Stock.Proof.ReturnSourceWitness.stock_return_run_contract_witness
#print axioms Backend.Stock.Proof.TermContractWitness.stock_trap_term_contract_witness
