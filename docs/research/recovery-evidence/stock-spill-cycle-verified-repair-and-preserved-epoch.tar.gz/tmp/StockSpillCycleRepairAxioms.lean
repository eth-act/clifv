import FV.Backend.Proof.PerEdgeSpillCycleFixture
import Lean
open Lean Elab Command
#print axioms Backend.Stock.Proof.IndexedSpillFixture.cycle_fixture
run_cmd do
  let env ← getEnv
  let mut count : Nat := 0
  for (name,_) in env.constants.toList do
    let some i := env.getModuleIdxFor? name | continue
    unless env.header.moduleNames[i]! == `FV.Backend.Proof.PerEdgeSpillCycleFixture do continue
    for ax in ← collectAxioms name do
      unless #[``propext,``Classical.choice,``Quot.sound].contains ax do
        throwError "disallowed axiom {ax} in {name}"
    count := count + 1
  unless count > 0 do throwError "empty fixture ownership partition"
  logInfo m!"SPILL_CYCLE_ALL_OWNED_STANDARD_ONLY {count}"
