import FV.Backend.Proof.PerEdgeSpillCycleFixture
#print axioms Backend.Stock.Proof.IndexedSpillFixture.cycle_fixture
