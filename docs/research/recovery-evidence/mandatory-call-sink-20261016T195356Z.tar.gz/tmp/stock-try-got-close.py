from pathlib import Path
import json,hashlib,re,datetime,tarfile,shutil
root=Path('/home/lee/clifv/.worktrees/driver-proof-resume');docs=root/'docs/research'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
now=datetime.datetime.now(datetime.timezone.utc);stamp=now.strftime('%Y%m%dT%H%M%SZ')
batch=json.loads(Path('/tmp/stock-try-got-batch.json').read_text());old=json.loads((docs/'stock-try-machine-scratch.json').read_text())
sets={m.group(1):sorted(x.strip() for x in m.group(2).split(',') if x.strip()) for m in re.finditer(r"'([^']+)' depends on axioms:\s*\[([^]]*)\]",Path('/tmp/stock-try-got-combined-axioms.log').read_text())}
for m in re.finditer(r"'([^']+)' does not depend on any axioms",Path('/tmp/stock-try-got-combined-axioms.log').read_text()):sets[m.group(1)]=[]
for n,a in old['normal_audit']['sets'].items():assert sorted(a)==sets[n],n
allowed={'propext','Classical.choice','Quot.sound'}
for n in batch['public_roots']+batch['models']:assert set(sets[n])<=allowed,n
constants=[json.loads(line.split('DELIVERY_CONSTANT ',1)[1]) for line in Path('/tmp/stock-try-got-all-constants.log').read_text().splitlines() if line.startswith('DELIVERY_CONSTANT ')]
assert constants
for n,a in constants:assert set(a)<=allowed,n
mods={}
for m in batch['modules']:
 p=Path('/tmp')/m;check=json.loads(p.with_suffix('.check.json').read_text());assert check['actual_exit']==0
 rec={}
 for key,ext in [('source','.lean'),('object','.olean'),('log','.log'),('check','.check.json')]:
  f=p.with_suffix(ext);rec[key]=str(f);rec[key+'_sha256']=sha(f)
 for k in ['source','object','log']:assert rec[k+'_sha256']==check[k+'_sha256']
 assert not re.search(r'\b(sorry|admit|axiom|trace_state|native_decide)\b',p.with_suffix('.lean').read_text())
 mods[m]=rec
prior={}
for name in ['source-execution-x','try-source','try-context','try-rule','try-rets','try-reservation','try-outgoing','try-values','try-emitted','try-machine']:
 d=json.loads((docs/f'stock-{name}-scratch.json').read_text())
 for m,rec in d['modules'].items():
  for k in ['source','object','log']:assert sha(rec[k])==rec[k+'_sha256'],(m,k)
  prior[m]=rec
freeze=json.loads(Path('/tmp/stock-coherent-build-inputs.json').read_text())
for group in ['source_sha256','validation_script_sha256']:
 for p,h in freeze[group].items():assert sha(root/p)==h,p
progress=json.loads(Path('/tmp/stock-pr246-gates-progress.json').read_text());progress.pop('completed_phases',None)
remaining=old['remaining_checklist']
for item in remaining:
 if 'Actual emitted direct/GOT/indirect TryCall outgoing' in item['requirement']:
  item['state']='Original outgoing/SigStackOk derived. Actual direct and GOT retained branches now execute exact ABI stores/reserved calls; GOT includes real fresh symbol load and target/source separation derived from build/traversal. Real seqRun normal returned worlds and actual operand results through final aliases proved. Complete9argGOT nonempty-stack machine witness passes. Indirect/exceptional machine execution and final-renamed/source-frame/block/whole composition remain open.'
 if 'Actual direct retained branch machine execution' in item['requirement']:
  item['state']='Proved and witnessed; GOT variant and complete9arg/nonempty-stack actual machine witness now also proved. Final-renamed branch/source-frame continuation remains open; not whole-driver simulation or completeness.'
remaining.append({'requirement':'Actual GOT retained branch machine execution including nonempty stack arguments','state':'Proved with original external/memory contracts, exact emitted stores/load/call, internally derived target freshness, returned world and actual operand results through final aliases. Complete9arg16byte stack original-condition compiler/prepare/checkedfallback/physical and real source17 witness passes. Broader sret/x8/width/handler matrix remains required.'})
receipt={'utc':now.isoformat(),'goal':'Original full #140 ACTIVE/INCOMPLETE; production LEGACY','scope':'Scratch-only additive Stock proofs, not coherent integration or merge-ready','delivery_target':'roughly eight substantive validated squash merges/day; remote backups and cleanup; drafts do not count','modules':mods,'public_roots':batch['public_roots'],'models':batch['models'],'counts':{'modules':len(mods),'public_roots':len(batch['public_roots']),'models':len(batch['models']),'combined_roots_models':len(sets),'previous_preserved':len(old['normal_audit']['sets']),'all_new_module_constants':len(constants)},'normal_audit':{'path':'/tmp/stock-try-got-combined-axioms.log','sha256':sha('/tmp/stock-try-got-combined-axioms.log'),'sets':sets},'all_constant_audit':{'path':'/tmp/stock-try-got-all-constants.log','sha256':sha('/tmp/stock-try-got-all-constants.log'),'all_standard_only':True,'count':len(constants)},'previous73_modules_hashes_preserved':list(prior),'canonical2246_source_and_script_freeze_preserved':True,'kernel_resources':'All new modules and both audits actual exit0 / object verified at8GiB through memcap; one heavy delivery worker retained','MCP':'No new calls; bundled provenance audit deferred until coherent integration','active_exact_PR246_validation':progress,'remaining_checklist':remaining}
(docs/'stock-try-got-scratch.json').write_text(json.dumps(receipt,indent=2)+'\n')
text=f'''Actual GOT TryCall normal machine execution — {now.isoformat()}

Four scratch modules, {len(batch['public_roots'])} public theorem roots and one public execution model pass kernel checks at8GiB. The {len(sets)}-root/model audit preserves all523prior exact axiom sets. All {len(constants)} constants in new modules, including private operational helpers, use only standard axioms. All73previous scratch source/object/log hashes and frozen2246canonical sources plus scripts are unchanged. Previous goal turn classified PROGRESS: actual direct branch machine execution, complete witness, audits, archive and verified remote backup.

The SAME actual GOT RHS emits exactly original mapped-source ABI argument stores, one freshly allocated GOT symbol load and its reserved-definition call. Whole lowering derives the original source/selection/layout, exact retained TryCall branch and per-site stack bound. Original build/traversal internally derives target freshness relative to every argument, with no caller disjointness certificate or new accepted-input condition. Under ORIGINAL external/memory/outgoing contracts and held original source arguments, real csem seqRun executes stores then load then TryCall, returning normal control/world and actual vdefUpd values through whole-driver final return aliases. Existing direct and older theorem variants remain unchanged; no source8argument restriction is added.

A COMPLETE nine-argument GOT original-condition compiler/prepare/forced checked fallback/checker/physical witness inhabits the original external/memory/callee contracts and executes the actual retained branch. It includes nonempty stack stores (16byte area), all nine mapped source arguments, symbol load and actual normal result update; real Clif.runWith returns17. This closes the prior nonempty-stack machine-execution witness gap for this GOT ABI case. Full sret/x8/zero-return/width/handler matrix remains required.

Open: true indirect/exception machine composition; actual final-renamed instruction and available source-frame/DFG/write noninterference/normal edge parameter continuation; exact payload endpoints; explicit/sret/x8. Shared exceptional csemU/ExtSem interfaces remain owned by @kevaundray #232/#233. Every remaining family/effect/source/block/whole-driver simulation AND completeness, coherent integration/public/private/compiler/MCP/full/crates/runtime/encoder/BOTH E2E identity-stage gates, actual production compiler/checker/linker/generated consumers and fresh complete comparison remain required. Production LEGACY. Main rechecked0ec59a028dd3a27911cb22554b3e292b20a5c45f. Same live delivery supervisor3247835/canonicalheld1233457 retained. Roughly eight substantive validated squash merges/day remains target; no merge/gate restart/new worktree/MCP this batch.

See stock-try-got-scratch.json for hashed evidence and full remaining checklist.
'''
(docs/'stock-try-got-scratch.md').write_text(text)
plan=root/'docs/plans/test-binary-alignment-recovery.md';plan.write_text(plan.read_text()+'\n\n'+text)
files=[]
for rec in mods.values():files.extend(Path(rec[k]) for k in ['source','object','log','check'])
for name in ['stock-try-got-combined-axioms','stock-try-got-all-constants']:
 for ext in ['.lean','.log','.olean','.check.json']:files.append(Path('/tmp')/(name+ext))
files.extend(Path(p) for p in ['/tmp/stock-try-got-batch.json','/tmp/stock-try-rule-inputs.json','/tmp/stock-try-reservation-check.py','/tmp/stock-try-got-close.py','/tmp/stock-try-got-status44.json','/tmp/stock-try-got-status52.json','/tmp/stock-try-got-status71.json','/tmp/stock-try-got-task140.json'])
files.extend([docs/'stock-try-got-scratch.json',docs/'stock-try-got-scratch.md',docs/'stock-delivery-main-drift.json',plan])
archive=Path('/home/lee/.clifv-recovery')/(stamp+'-try-got')/'checkpoint.tar.gz';archive.parent.mkdir(parents=True)
with tarfile.open(archive,'w:gz',compresslevel=1) as t:
 for p in files:t.add(p,arcname=str(p).lstrip('/'),recursive=False)
with tarfile.open(archive,'r:gz') as t:
 for p in files:assert t.extractfile(str(p).lstrip('/')).read()==p.read_bytes(),p
snapshot=Path('/tmp/stock-try-rule-inputs');size=sum(p.stat().st_size for p in snapshot.rglob('*') if p.is_file());shutil.rmtree(snapshot)
backup={'utc':now.isoformat(),'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(files),'all_members_byte_verified':True,'previous_remote_backup':json.loads((docs/'stock-try-machine-backup.json').read_text())['remote'],'cleanup':{'duplicate_dependency_snapshot_removed':True,'bytes_reclaimed':size,'unique_sources_objects_logs_checks_audits_preserved':True,'one_shared_warm_cache_retained':True,'other_projects_touched':False,'free_bytes':shutil.disk_usage(root).free}}
(docs/'stock-try-got-backup.json').write_text(json.dumps(backup,indent=2)+'\n');Path('/tmp/stock-try-got-archive-path').write_text(str(archive))
print(json.dumps({'counts':receipt['counts'],'archive':str(archive),'cleanup':backup['cleanup'],'gate':progress},indent=2))
