import StockTryGotCode
import StockTryDirectSem
import FV.E2E.RegLevelDriverSem
namespace Backend.Stock.Proof.TryGotSemDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open TryResultMapDraft TryResultWritesDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
/-- Real stack stores, GOT load and reserved-result TryCall execute in order
under ORIGINAL external/memory contracts. The fresh target preserves all source
argument registers; normal control/world/actual operand results follow. -/
theorem stock_try_got_stores_normal_execution
    {Rd F : BitVec 64 → Prop} {asm : FnCtx} {X : ExtSem} {MR : MemRelT} {sb : Nat} {syms : String → Option Nat}
    (stable : MRStable F MR) (memory : MemRefinesR Rd F sb syms (csem F asm X))
    {outB : Nat} (outgoing : OutArgsOk F outB MR)
    {env : Clif.Env} {exts : List Clif.ExtFunc} (external : XCallsOk env exts MR X)
    {ext : Clif.ExtFunc} (member : ext ∈ exts) (stackOk : SigStackOk ext.sig outB)
    {bytes : List Nat} {locs : List ArgLoc} {stack : Nat}
    (byteRun : sigParamBytes ext.sig = .ok bytes) (locations : sigArgLocs ext.sig = .ok (locs,stack))
    {ns : List Nat} {vals rvals : List Clif.Val} {ρ : Nat → CV}
    (typed : vals.map (·.ty) = Clif.AbiParam.tys ext.sig.params) (count : ns.length = vals.length)
    (held : ∀ (j : Nat) (v : Clif.Val) (n : Nat),vals[j]? = some v → ns[j]? = some n → VHolds v (ρ n))
    {sl : List (Clif.SlotId × Nat)} {cm cm' : Clif.Mem} {w : Arm.ArmState} (related : MR sl cm w)
    {g : List Clif.Val → Clif.Mem → Clif.Outcome} (found : env.extern ext.name = some g)
    (returned : g vals cm = .returned rvals cm')
    (results : rvals.length = ext.sig.returns.length) (base target : Nat) (info : TryInfo)
    (far : ext.colocated = false) (fresh : ∀ n ∈ ns,n ≠ target) :
    ∃ (outs : List CV) (atCall w' : Arm.ArmState),
      let L := regPairsOf ((locs.zip ns).zip bytes)
      let D := resultDefs base ext.sig.returns.length
      let loaded := upd ρ target (ofX (X.sym ext.name 0))
      let call := MInst.tryCall ⟨.reg (.vreg target .int),retPairs L,callDefs D⟩ {info with rets := ext.sig.returns.length}
      seqRun (csem F asm X) (((stackEnts ((locs.zip ns).zip bytes)).map argStore) ++ [.loadExtNameGot (.vreg target .int) ext.name,call]) ρ w =
        some (.stop (((stackEnts ((locs.zip ns).zip bytes)).map argStore).length + 1) call
          (tgtOp target :: (retOps L ++ callDefOps D)).toArray loaded atCall outs w' (.goto info.handlers.length)) ∧
      outs.length = max ext.sig.returns.length 2 ∧ PrefixHold rvals outs ∧ MR sl cm' w' ∧
      ∀ (j : Nat) (v : Clif.Val),rvals[j]? = some v →
        VHolds v (vdefUpd (tgtOp target :: (retOps L ++ callDefOps D)).toArray outs loaded (base+j)) := by
  obtain ⟨atCall,stores,relatedCall,arguments⟩ := argsAt_after_stores stable memory outgoing stackOk byteRun locations typed count held related
  have contract : CallsRefineP (fun _ _ _ _ => True) F env exts MR (csem F asm X) := (callsRefine_csem external).toP _
  obtain ⟨sym,load,tried⟩ := TryNormalCallValuesDraft.stock_try_normal_call_values contract
  have symbol : sym ext.name = X.sym ext.name 0 := by
    obtain ⟨loadedWorld,executed,_⟩ := load (.vreg target .int) ext.name atCall
    change some ([ofX (X.sym ext.name 0)],atCall,Ctl.next) = some ([ofX (sym ext.name)],loadedWorld,Ctl.next) at executed
    have same := congrArg Prod.fst (Option.some.inj executed)
    have word := (List.cons.inj same).1
    simpa only [lo64_ofX] using (congrArg lo64 word).symm
  let loaded := upd ρ target (ofX (X.sym ext.name 0))
  have unchanged : (regPairsOf ((locs.zip ns).zip bytes)).map (loaded ·.1) =
      (regPairsOf ((locs.zip ns).zip bytes)).map (ρ ·.1) := by
    apply List.map_congr_left
    intro q member
    have ne := fresh q.1 (map_zip_args (mem_args_of_regPairs (List.mem_map_of_mem member)))
    simp only [loaded,upd,if_neg ne]
  have targetValue : loaded target = ofX (X.sym ext.name 0) := by simp [loaded,upd]
  have loadRun : csem F asm X (.loadExtNameGot (.vreg target .int) ext.name) [] atCall =
      some ([ofX (X.sym ext.name 0)],atCall,.next) := rfl
  have loadedRun := seqRun_got (F := F) (ρ := ρ) loadRun
  obtain ⟨outs,w',run,length,values,world,normal⟩ := tried ext member g sl cm atCall (.reg (.vreg target .int))
    (retPairs (regPairsOf ((locs.zip ns).zip bytes))) info
    (loaded target :: (regPairsOf ((locs.zip ns).zip bytes)).map (loaded ·.1))
    ((regPairsOf ((locs.zip ns).zip bytes)).map (ρ ·.1)) vals rvals cm' base found
    (.inr ⟨.vreg target .int,rfl,far,by rw [targetValue,unchanged,symbol]⟩)
    (arguments atCall (SameWorldNF.refl F atCall)) relatedCall trivial returned results
  have defsLength : outs.length = (resultDefs base ext.sig.returns.length).length := by
    simpa only [resultDefs,List.length_map,List.length_range] using length
  have callRun := seqRun_tryCall_reg (ρ := loaded) run defsLength
  have prefixed := seqRun_append_fall_stop (csem F asm X) loadedRun callRun
  have executed := seqRun_append_fall_stop (csem F asm X) stores prefixed
  refine ⟨outs,atCall,w',?_,length,values,world,?_⟩
  · simpa only [List.singleton_append,List.cons_append,List.nil_append,List.length_cons,List.length_nil,Nat.zero_add,Nat.add_comm] using executed
  · intro j v atValue
    rw [vdefUpd_call_reg]
    exact normal loaded j v atValue

end Backend.Stock.Proof.TryGotSemDraft
