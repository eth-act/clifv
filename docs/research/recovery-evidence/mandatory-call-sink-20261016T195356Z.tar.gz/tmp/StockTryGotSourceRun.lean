import StockTryGotSem
import StockTryWholeOutgoing
import StockTryFinalReturnValues
namespace Backend.Stock.Proof.TryGotSourceRunDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open TrySourceContextDraft TryBranchSelectionDraft TryBranchAbiDraft TrySelectedCallsDraft
open TryWholeSourceReservationDraft TryRetsTotalDraft TryGotCodeDraft TryGotSemDraft TryWholeOutgoingDraft
open TryResultMapDraft TryFinalReturnValuesDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
/-- A conclusion about the actual retained source GOT branch and its normal machine
execution. It is constructed internally, never an accepted-program premise. -/
structure GotTryRun (f : Clif.Function) (result : Result) (label bi : Nat) (b : Clif.Block)
    (ext : Clif.ExtFunc) (isem : Sem) (MR : MemRelT) (fr : Clif.Frame)
    (ρ : Nat → CV) (w : Arm.ArmState) (rvals : List Clif.Val) (cm' : Clif.Mem) where
  source : TryBranchSource f result label bi b
  selected : TryBranchSelection source
  base : Nat
  target : Nat
  symbol : BitVec 64
  ns : List Nat
  bytes : List Nat
  locs : List ArgLoc
  stack : Nat
  info : TryInfo
  outs : List CV
  atCall : Arm.ArmState
  finalWorld : Arm.ArmState
  layout : result.initial.tryRegs[source.ti]! = (reservedReturns base ext.sig.returns.length,reservedPayloads base ext.sig.returns.length)
  code : source.branch.step.emitted = (((stackEnts ((locs.zip ns).zip bytes)).map argStore) ++
    [MInst.loadExtNameGot (.vreg target .int) ext.name,MInst.tryCall ⟨.reg (.vreg target .int),retPairs (regPairsOf ((locs.zip ns).zip bytes)),callDefs (resultDefs base ext.sig.returns.length)⟩
      {info with rets := ext.sig.returns.length}]).toArray
  run : seqRun isem source.branch.step.emitted.toList ρ w =
    some (.stop (((stackEnts ((locs.zip ns).zip bytes)).map argStore).length + 1)
      (.tryCall ⟨.reg (.vreg target .int),retPairs (regPairsOf ((locs.zip ns).zip bytes)),callDefs (resultDefs base ext.sig.returns.length)⟩
        {info with rets := ext.sig.returns.length})
      (tgtOp target :: (retOps (regPairsOf ((locs.zip ns).zip bytes)) ++ callDefOps (resultDefs base ext.sig.returns.length))).toArray
      (upd ρ target (ofX symbol)) atCall outs finalWorld (.goto info.handlers.length))
  returnedWorld : MR fr.slots cm' finalWorld
  normalValues : ∀ (j : Nat) (v : Clif.Val),rvals[j]? = some v →
    VHolds v (vdefUpd (tgtOp target :: (retOps (regPairsOf ((locs.zip ns).zip bytes)) ++ callDefOps (resultDefs base ext.sig.returns.length))).toArray
      outs (upd ρ target (ofX symbol)) (aliasNum result.final.alias (base+j)))
/-- Actual whole Stock lowering derives the GOT TryCall's exact branch code
and final reserved aliases, executes its real ABI stores, symbol load and call, and transfers
normal returned values/world. All source/static/layout premises are derived
from the original build/scope/input; memory and callee contracts are unchanged. -/
theorem stock_lower_got_try_normal_source_run {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f) (input : Prg.iselInB f = true)
    {label bi : Nat} {b : Clif.Block} (node : result.order.nodes[label]? = some (.original bi))
    (block : f.blocks[bi]? = some b) {fn : Nat} {args : List Nat} {et : Clif.ExnTable}
    (kind : b.term = .tryCall fn args et) {ext : Clif.ExtFunc} (external : f.extern? fn = some ext)
    (far : ext.colocated = false)
    {Rd F : BitVec 64 → Prop} {asm : FnCtx} {X : ExtSem} {MR : MemRelT} {sb : Nat} {syms : String → Option Nat}
    (stable : MRStable F MR) (memory : MemRefinesR Rd F sb syms (csem F asm X))
    (outgoing : OutArgsOk F result.code.outgoing MR)
    {env : Clif.Env} {exts : List Clif.ExtFunc}
    (calls : XCallsOk env exts MR X) (member : ext ∈ exts)
    {fr : Clif.Frame} {ρ : Nat → CV} {w : Arm.ArmState} {cm cm' : Clif.Mem} {vals rvals : List Clif.Val}
    (held : ValuesHeld (fun x => x ∈ args) result.ctx fr ρ) (read : fr.getMany args = .ok vals)
    (typed : vals.map (·.ty) = Clif.AbiParam.tys ext.sig.params) (related : MR fr.slots cm w)
    {g : List Clif.Val → Clif.Mem → Clif.Outcome} (found : env.extern ext.name = some g)
    (returned : g vals cm = .returned rvals cm')
    (results : rvals.length = ext.sig.returns.length) :
    Nonempty (GotTryRun f result label bi b ext (csem F asm X) MR fr ρ w rvals cm') := by
  have isTry : b.term.isTry = true := by rw [kind]; rfl
  obtain ⟨original,⟨originalSelected⟩⟩ := stock_lower_try_source_selection lowered scope node block isTry
  obtain ⟨items,table,_,_,_,_,_⟩ := stock_selected_try_got_rhs_calls originalSelected kind external far
  have sourceTableEq : sourceTable b.term = some et := by rw [kind]; rfl
  obtain ⟨ranges,source,selected,base,replay,replayAfter,build,allocation,slots,replayRun,frame⟩ :=
    stock_lower_original_try_reservation lowered scope input node block sourceTableEq table
  obtain ⟨actualItems,actualTable,_,_,_,_,protocol⟩ := stock_selected_try_got_rhs_calls selected kind external far
  obtain ⟨ns,bytes,locs,stack,target,mapping,byteRun,locations,targetIs,raw⟩ := stock_got_try_actual_code data_program
    source.mapped protocol base (exnTableOpnd_cc table) slots
  change selected.next.base.emitted = ((#[] ++ _).push _).push _ at raw
  change target = source.input.base.nextVreg at targetIs
  simp only [Array.empty_append] at raw
  obtain ⟨et',sig',items',info,call,tableKind,decoded,metadata,abiCount,last,code,finalLast⟩ :=
    stock_try_branch_explicit_abi isTry selected.code
  have sameTable : et' = et := Option.some.inj (tableKind.symm.trans sourceTableEq)
  subst et'
  have sameSig := Except.ok.inj (decoded.symm.trans table)
  cases sameSig
  rw [raw,Array.back?_push] at last
  have sameCall := Option.some.inj last
  cases sameCall
  have exactCode : source.branch.step.emitted = (((stackEnts ((locs.zip ns).zip bytes)).map argStore) ++
    [MInst.loadExtNameGot (.vreg target .int) ext.name,MInst.tryCall ⟨.reg (.vreg target .int),retPairs (regPairsOf ((locs.zip ns).zip bytes)),callDefs (resultDefs base ext.sig.returns.length)⟩
      {info with rets := ext.sig.returns.length}]).toArray := by
    rw [selected.stepCode,code,raw,Array.pop_push]
    apply Array.toList_inj.mp
    simp only [Array.toList_push,List.toList_toArray,List.append_assoc,List.cons_append,List.nil_append]
  have heldSource : ValuesHeld (fun x => x ∈ args) source.ctx fr ρ := by
    intro x member v lookup
    obtain ⟨n,mapped,value⟩ := held x member v lookup
    exact ⟨n,by rw [source.valueMap]; exact mapped,value⟩
  have allValues := requested_values_hold heldSource read mapping
  simp only [List.map_map,Function.comp_def,registerView] at allValues
  have counts : ns.length = vals.length := by simpa using allValues.1.symm
  have values : ∀ (j : Nat) (v : Clif.Val) (n : Nat),vals[j]? = some v → ns[j]? = some n → VHolds v (ρ n) := by
    intro j v n atValue atReg
    apply allValues.2 j v (ρ n) atValue
    simp only [List.getElem?_map,atReg,Option.map_some]
  have fresh : ∀ n ∈ ns,n ≠ target := by
    intro n member same
    have mappedMember : Reg.vreg n .int ∈ ns.map (fun k => Reg.vreg k .int) := List.mem_map_of_mem member
    obtain ⟨x,_,lookup⟩ := Backend.Proof.Flow.mapM_mem mapping _ mappedMember
    rw [source.valueMap] at lookup
    have below := (buildCtx_allocated build).1 x n lookup
    have initial := allocation.1
    rw [targetIs] at same
    omega
  have stackOk := stock_lower_direct_try_stack lowered scope node block kind external
  obtain ⟨outs,atCall,w',run,length,heldResults,world,normal⟩ := stock_try_got_stores_normal_execution
    stable memory outgoing calls member stackOk byteRun locations typed counts values related found returned results base target info far fresh
  have layout : result.initial.tryRegs[source.ti]! = (reservedReturns base ext.sig.returns.length,reservedPayloads base ext.sig.returns.length) := by
    rw [← allocation.2]
    exact source.tryRegs.symm.trans slots
  refine ⟨{
    source := source
    selected := selected
    base := base
    target := target
    symbol := X.sym ext.name 0
    ns := ns
    bytes := bytes
    locs := locs
    stack := stack
    info := info
    outs := outs
    atCall := atCall
    finalWorld := w'
    layout := layout
    code := exactCode
    run := ?_
    returnedWorld := world
    normalValues := ?_ }⟩
  · rw [exactCode,List.toList_toArray]
    exact run
  · intro j v atValue
    rw [vdefUpd_call_reg]
    exact stock_lower_try_normal_reserved_values lowered layout (upd ρ target (ofX (X.sym ext.name 0))) heldResults results length atValue
end Backend.Stock.Proof.TryGotSourceRunDraft
