import FV.Backend.Proof.StockMinMaxRegisterRecordValues
import FV.Backend.Proof.StockHighMulSourceValues
namespace Backend.Stock.Proof.ScalarSelect
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open MinMaxRegisterFixture Backend.Stock.Proof.ScalarCmp
/-- Successful original source execution and unchanged dominance derive both
restricted source operands internally. -/
theorem stock_lower_minmax_source_operands {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    {event : BlockScanEvent} {record : ScanRecord} (events : event ∈ result.blockScans.toList)
    {bi j : Nat} {b : Clif.Block} {stm : Clif.Stmt} (block : f.blocks[bi]? = some b)
    (statement : b.body[j]? = some stm) (current : record.inst = blockStart f bi + j)
    (unsigned maximum : Bool) {info : IInfo} {ty : Clif.Ty} {x y : Nat}
    (source : event.ctx.insts[record.inst]? = some info)
    (clif : info.clif = some (.binary (minmaxOperation unsigned maximum) ty x y))
    {env : Clif.Env} {cp : Clif.Program} {fr fr' : Clif.Frame} {cm cm' : Clif.Mem}
    (sourceStep : SourceInstResult env cp event.ctx record.inst (fr,cm) (fr',cm')) :
    ∃ u v,(restrict fr (availOf f (availIn f result.ctx) bi j)).getAs x ty = .ok u ∧
      (restrict fr (availOf f (availIn f result.ctx) bi j)).getAs y ty = .ok v := by
  obtain ⟨info',inst,vals,regs,rest,found,original,body,evaluated,written,updated⟩ := sourceStep
  have sameInfo := Option.some.inj (found.symm.trans source)
  subst info'
  have sameInst := Option.some.inj (original.symm.trans clif)
  subst inst
  have plain : Clif.evalInst fr cm (.binary (minmaxOperation unsigned maximum) ty x y) = .ok (vals,cm') := by
    cases unsigned <;> cases maximum <;> simpa [minmaxOperation,instOutcome] using evaluated
  obtain ⟨u,v,getX,getY,_⟩ := evalInst_binary_inv (by cases unsigned <;> cases maximum <;> rfl) plain
  have availableX : x ∈ availOf f (availIn f result.ctx) bi j := stock_lower_record_args_available
    run scope dominated events block statement current source clif x (by simp [Driver.instArgs])
  have availableY : y ∈ availOf f (availIn f result.ctx) bi j := stock_lower_record_args_available
    run scope dominated events block statement current source clif y (by simp [Driver.instArgs])
  exact ⟨u,v,(getAs_congr (fr := fr) (fr' := restrict fr (availOf f (availIn f result.ctx) bi j))
      (x := x) (ty := ty) (restrict_regs_of_mem availableX)).trans getX,
    (getAs_congr (fr := fr) (fr' := restrict fr (availOf f (availIn f result.ctx) bi j))
      (x := y) (ty := ty) (restrict_regs_of_mem availableY)).trans getY⟩
/-- Actual retained min/max register-case execution transfers the original guarded source
relation to the real original source-step frame, not merely a constructed result
frame. Original restricted DFG and demanded/available guards are retained. -/
theorem stock_lower_minmax_register_source_values {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    {event : BlockScanEvent} {record : ScanRecord}
    (events : event ∈ result.blockScans.toList) (records : record ∈ event.output.records)
    {bi j : Nat} {block : Clif.Block} {stmt : Clif.Stmt}
    (foundBlock : f.blocks[bi]? = some block) (foundStmt : block.body[j]? = some stmt)
    (current : record.inst = blockStart f bi + j)
    {info : IInfo} (unsigned maximum : Bool) {ty : Clif.Ty} {x y z a : Nat}
    (source : event.ctx.insts[record.inst]? = some info) (clif : info.clif = some (.binary (minmaxOperation unsigned maximum) ty x y))
    (wide : Bool) (sourceTy : ty = if wide then .i64 else .i32)
    (typeX : event.ctx.valueType? x = some (.int (if wide then 64 else 32)))
    (typeY : event.ctx.valueType? y = some (.int (if wide then 64 else 32)))
    (notConstantX : NonConstantSource event.ctx x) (notConstantY : NonConstantSource event.ctx y)
    (results : info.results = [z]) (statementResults : stmt.results = [z])
    (mapped : event.ctx.valueReg? z = some (.vreg a .int))
    {step : Step} (recorded : record.output.step = some step) (emitted : step.decision = .emitted)
    {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem} (refines : Refines F isem)
    {fr : Clif.Frame} {ρ : Nat → CV} {u v : BitVec ty.width}
    (dfg : DFGCons event.ctx (restrict fr (availOf f (availIn f result.ctx) bi j)))
    (getX : (restrict fr (availOf f (availIn f result.ctx) bi j)).getAs x ty = .ok u)
    (getY : (restrict fr (availOf f (availIn f result.ctx) bi j)).getAs y ty = .ok v)
    (held : ValuesHeld (fun value => Demanded record.output.state value ∧ value ∈ availOf f (availIn f result.ctx) bi j)
      event.ctx fr (fun key => ρ (aliasNum result.final.alias key)))
    {env : Clif.Env} {cp : Clif.Program} {fr' : Clif.Frame} {cm cm' : Clif.Mem}
    (sourceStep : SourceInstResult env cp event.ctx record.inst (fr,cm) (fr',cm')) :
    ∃ d,step.results = [[.vreg d .int]] ∧ record.input.base.nextVreg ≤ d ∧ d < record.output.state.base.nextVreg ∧
      cm' = cm ∧
      ∀ world,Runs F isem (record.output.emitted.toList.map
        (·.mapRegs (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1)))) ρ world (fun ρ' _ =>
          VHolds ⟨ty,Clif.Sem.binary (minmaxOperation unsigned maximum) u v⟩ (ρ' d) ∧ (∀ k,k < record.input.base.nextVreg ∨ record.output.state.base.nextVreg ≤ k → ρ' k = ρ k) ∧
          ValuesHeld (fun value => Demanded record.input value ∧ value ∈ availOf f (availIn f result.ctx) bi (j+1))
            event.ctx fr' (fun key => ρ' (aliasNum result.final.alias key))) := by
  have availableX := restrict_regs_isSome (by rw [getAs_ok getX]; rfl)
  have availableY := restrict_regs_isSome (by rw [getAs_ok getY]; rfl)
  have rawGetX : fr.getAs x ty = .ok u :=
    (getAs_congr (fr := restrict fr (availOf f (availIn f result.ctx) bi j)) (fr' := fr)
      (x := x) (ty := ty) (restrict_regs_of_mem availableX).symm).trans getX
  have rawGetY : fr.getAs y ty = .ok v :=
    (getAs_congr (fr := restrict fr (availOf f (availIn f result.ctx) bi j)) (fr' := fr)
      (x := y) (ty := ty) (restrict_regs_of_mem availableY).symm).trans getY
  have restored := sourceStep
  obtain ⟨info',inst,vals,regs,rest,found,original,body,evaluated,written,updated⟩ := sourceStep
  have sameInfo := Option.some.inj (found.symm.trans source)
  subst info'
  have sameInst := Option.some.inj (original.symm.trans clif)
  subst inst
  have eval' : instOutcome env cp fr cm (.binary (minmaxOperation unsigned maximum) ty x y) =
      .ok ([⟨ty,Clif.Sem.binary (minmaxOperation unsigned maximum) u v⟩],cm) := by
    cases unsigned <;> cases maximum <;> simp [minmaxOperation,instOutcome,Clif.evalInst,Clif.BinaryOp.isShift,rawGetX,rawGetY]
  rw [eval'] at evaluated
  cases evaluated
  obtain ⟨d,output,lower,upper,execution⟩ := stock_lower_minmax_register_available_values run scope dominated events records
    foundBlock foundStmt current unsigned maximum source clif wide sourceTy typeX typeY notConstantX notConstantY results statementResults mapped
    recorded emitted refines dfg getX getY held
  refine ⟨d,output,lower,upper,rfl,?_⟩
  intro world
  exact (execution world).imp (fun ρ' _ _ ⟨value,kept,post⟩ =>
    ⟨value,kept,source_single_result_values source clif results restored eval' post⟩)
/-- Original source execution supplies both getters internally; the earlier
getter-explicit source-transfer theorem remains available unchanged. -/
theorem stock_lower_minmax_register_source_by_instruction {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    {event : BlockScanEvent} {record : ScanRecord}
    (events : event ∈ result.blockScans.toList) (records : record ∈ event.output.records)
    {bi j : Nat} {block : Clif.Block} {stmt : Clif.Stmt}
    (foundBlock : f.blocks[bi]? = some block) (foundStmt : block.body[j]? = some stmt)
    (current : record.inst = blockStart f bi + j)
    {info : IInfo} (unsigned maximum : Bool) {ty : Clif.Ty} {x y z a : Nat}
    (source : event.ctx.insts[record.inst]? = some info) (clif : info.clif = some (.binary (minmaxOperation unsigned maximum) ty x y))
    (wide : Bool) (sourceTy : ty = if wide then .i64 else .i32)
    (typeX : event.ctx.valueType? x = some (.int (if wide then 64 else 32)))
    (typeY : event.ctx.valueType? y = some (.int (if wide then 64 else 32)))
    (notConstantX : NonConstantSource event.ctx x) (notConstantY : NonConstantSource event.ctx y)
    (results : info.results = [z]) (statementResults : stmt.results = [z])
    (mapped : event.ctx.valueReg? z = some (.vreg a .int))
    {step : Step} (recorded : record.output.step = some step) (emitted : step.decision = .emitted)
    {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem} (refines : Refines F isem)
    {fr : Clif.Frame} {ρ : Nat → CV}
    (dfg : DFGCons event.ctx (restrict fr (availOf f (availIn f result.ctx) bi j)))
    (held : ValuesHeld (fun value => Demanded record.output.state value ∧ value ∈ availOf f (availIn f result.ctx) bi j)
      event.ctx fr (fun key => ρ (aliasNum result.final.alias key)))
    {env : Clif.Env} {cp : Clif.Program} {fr' : Clif.Frame} {cm cm' : Clif.Mem}
    (sourceStep : SourceInstResult env cp event.ctx record.inst (fr,cm) (fr',cm')) :
    ∃ u : BitVec ty.width,∃ v : BitVec ty.width,∃ d,step.results = [[.vreg d .int]] ∧ record.input.base.nextVreg ≤ d ∧ d < record.output.state.base.nextVreg ∧
      cm' = cm ∧
      ∀ world,Runs F isem (record.output.emitted.toList.map
        (·.mapRegs (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1)))) ρ world (fun ρ' _ =>
          VHolds ⟨ty,Clif.Sem.binary (minmaxOperation unsigned maximum) u v⟩ (ρ' d) ∧ (∀ k,k < record.input.base.nextVreg ∨ record.output.state.base.nextVreg ≤ k → ρ' k = ρ k) ∧
          ValuesHeld (fun value => Demanded record.input value ∧ value ∈ availOf f (availIn f result.ctx) bi (j+1))
            event.ctx fr' (fun key => ρ' (aliasNum result.final.alias key))) := by
  obtain ⟨u,v,getX,getY⟩ := stock_lower_minmax_source_operands run scope dominated events
    foundBlock foundStmt current unsigned maximum source clif sourceStep
  obtain ⟨d,output,lower,upper,memory,execution⟩ := stock_lower_minmax_register_source_values run scope dominated events records
    foundBlock foundStmt current unsigned maximum source clif wide sourceTy typeX typeY notConstantX notConstantY results statementResults mapped
    recorded emitted refines dfg getX getY held sourceStep
  exact ⟨u,v,d,output,lower,upper,memory,execution⟩
end Backend.Stock.Proof.ScalarSelect
