import FV.Backend.Proof.StockCmpNonconstantSelection
import FV.Backend.Proof.StockMinMaxRegisterTraceValues
namespace Backend.Stock.Proof.ScalarSelect
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open Backend.Stock.Proof.ScalarCmp
/-- Actual successful emitter652 selection and select659 execution compute
the selected original value in the nonconstant source case. No caller-chosen emitter RHS is required,
and the real emitted-rule trace prefix is retained. -/
theorem stock_minmax_nonconstant_emitter_source_values {p : Program} (hp : Data p)
    {f : Clif.Function} {ctx : Ctx} (inv : MappedCtxInv f ctx) (cc : Clif.IntCC)
    {ty : Clif.Ty} (width : ty.width = 32 ∨ ty.width = 64)
    {fr : Clif.Frame} {x y : Nat} {u v : BitVec ty.width}
    (getX : fr.getAs x ty = .ok u) (getY : fr.getAs y ty = .ok v)
    (typeX : ctx.valueType? x = some (.int (szOf ty.width).bits))
    (typeY : ctx.valueType? y = some (.int (szOf ty.width).bits))
    (notConstantX : NonConstantSource ctx x) (notConstantY : NonConstantSource ctx y)
    {st middle next : State} {tr emitTrace trace : Array RuleId} {emitFuel conditionFuel : Nat} {condition out : V}
    (enoughEmit : 200 ≤ emitFuel) (enoughCondition : 279 ≤ conditionFuel)
    (emitter : ApplyInternal p (Stock.sem ctx) {} emitFuel 123 652 [.data 145 (ccIdx cc) [],.value x,.value y]
      (st,tr) condition (middle,emitTrace))
    (conditionCall : ApplyInternal p (Stock.sem ctx) {} conditionFuel 22 659 [.ty (.int ty.width),condition,.value x,.value y]
      (middle,emitTrace) out (next,trace))
    {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem} (refines : Refines F isem)
    {aliases : Array (Option Nat)} {ρ : Nat → CV} (bounded : aliases.size ≤ st.base.nextVreg)
    (extent : ∀ z r,ctx.valueReg? z = some r → z < st.demand.size)
    (held : ValuesHeld (Demanded next) ctx fr (fun key => ρ (aliasNum aliases key))) :
    ∃ nx ny d,ctx.valueReg? x = some (.vreg nx .int) ∧ ctx.valueReg? y = some (.vreg ny .int) ∧
      out = .regs [.vreg d .int] ∧ st.base.nextVreg ≤ d ∧ d < next.base.nextVreg ∧
      Frag st.base next.base [.aluRRR .subS (szOf ty.width) .xzr (.vreg nx .int) (.vreg ny .int),
        .csel (.vreg d .int) (.vreg nx .int) (.vreg ny .int) (condOf cc)] ∧
      ∀ world,Runs F isem ([MInst.aluRRR .subS (szOf ty.width) .xzr (.vreg nx .int) (.vreg ny .int),
        .csel (.vreg d .int) (.vreg nx .int) (.vreg ny .int) (condOf cc)].map
        (·.mapRegs (Backend.lowerFunction.resolve aliases (aliases.size+1)))) ρ world (fun ρ' _ =>
          VHolds ⟨ty,if Clif.Sem.intcc cc u v then u else v⟩ (ρ' d) ∧ ∀ k,k ≠ d → ρ' k = ρ k) := by
  obtain ⟨rhsTrace,rhs,traceEq⟩ := stock_cmp_nonconstant_emitter_selected hp ctx inv cc (szOf ty.width)
    enoughEmit typeX typeY notConstantX notConstantY emitter
  obtain ⟨n,fuelEq⟩ : ∃ n,emitFuel=n+100 := ⟨emitFuel-100,by omega⟩
  rw [fuelEq] at rhs
  exact stock_select_register_emitter_source_values_any_trace hp inv cc width getX getY enoughCondition
    rhs conditionCall refines bounded extent held
end Backend.Stock.Proof.ScalarSelect
