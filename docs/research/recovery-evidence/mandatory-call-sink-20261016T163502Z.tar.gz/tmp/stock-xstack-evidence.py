from pathlib import Path
import json,re,hashlib,datetime,tarfile,shutil,os
root=Path('/home/lee/clifv/.worktrees/driver-proof-resume');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();now=datetime.datetime.now(datetime.timezone.utc).isoformat()
mods=['StockSourceExecutionXStack','StockSourceExecutionStackShape','StockSourceExecutionXLift','StockSourceExecutionXStackWitness'];logs=['xstack','stackshape','xlift','xstack-witness'];records={}
for m,l in zip(mods,logs):
 p=Path('/tmp',m+'.lean');obj=p.with_suffix('.olean');log=Path('/tmp/stock-source-execution-'+l+'.log');assert p.exists() and obj.exists() and log.exists();assert 'error:' not in log.read_text();assert not re.search(r'\b(sorry|admit|trace_state)\b',p.read_text());assert not re.search(r'^\s*(?:private\s+)?axiom\s+',p.read_text(),re.M)
 records[m]={'source':str(p),'source_sha256':sha(p),'object':str(obj),'object_sha256':sha(obj),'log':str(log),'log_sha256':sha(log),'public_theorems':re.findall(r'^theorem\s+(\w+)',p.read_text(),re.M)}
audit=Path('/tmp/stock-source-execution-xstack-axioms.log');txt=audit.read_text();assert 'error:' not in txt
sets={m.group(1):sorted(a.strip() for a in m.group(2).split(',') if a.strip()) for m in re.finditer(r"'([^']+)' depends on axioms:\s*\[([^]]*)\]",txt)};sets.update({n:[] for n in re.findall(r"'([^']+)' does not depend on any axioms",txt)});assert len(sets)==12;assert all(set(a)<={'propext','Classical.choice','Quot.sound'} for a in sets.values())
frozen=json.loads(Path('/tmp/stock-coherent-build-inputs.json').read_text());assert {str(p.relative_to(root)):sha(p) for d in ['FV','FVTest'] for p in (root/d).rglob('*.lean')}==frozen['source_sha256']
for p,h in frozen['validation_script_sha256'].items():assert sha(root/p)==h,p
snapshot=json.loads(Path('/tmp/stock-unwind-proof-inputs.json').read_text())
for m,r in snapshot['objects'].items(): assert sha(Path('/tmp/stock-unwind-proof-inputs/FV/Clif',m+'.olean'))==r['sha256']
progress=json.loads(Path('/tmp/stock-pr246-gates-progress.json').read_text());pid=progress['pid'];assert 'stock-pr246-gates.py' in Path('/proc',str(pid),'cmdline').read_text();pids={'worker':pid,'current_phase':{k:progress.get(k) for k in ['state','index','total','module','utc']},'canonical_controller_held':Path('/proc/1233457/stat').read_text().split(') ',1)[1].split()[0]=='T'}
result={'utc':now,'state':'scratch_kernel_and_normal_public_audit_pass','modules':records,'public_theorem_count':sum(len(r['public_theorems']) for r in records.values()),'normal_audit':{'path':str(audit),'sha256':sha(audit),'roots_and_models':sets},'witnesses':['actual source TryCall program push with saved original table','nested ordinary program call above a TryCall caller','real raiseIn/unwindFrom skipping ordinary caller and catching lower saved table','tagged and default handlers with payload42 bound to fresh10','complete runWithX returns42 for both cases'],'isolated_inputs':snapshot,'canonical2246_source_and_validation_script_freeze_verified':True,'active_delivery_validation':pids,'remaining':['Specialize pending predicate to original reachable Stock source table without new input conditions','Combine normal source-location proof and catchIn theorem with liftStep/raiseIn to derive full actual stepX and prefix invariant','Add explicit normal-return pop and propagated-unwound/table-miss witnesses','Integrate scratch batch after canonical source freeze ends; fresh bundled MCP and complete all-constant/public/kernel/transitive audits','All original whole-driver value/world simulation AND completeness and production compiler/checker/linker/generated-proof cutover plus full gates and fresh complete Stock comparison'],'MCP':'Not yet run for this scratch batch; no per-root scratch MCP loops','production':'legacy','full_goal':'ACTIVE/incomplete','previous_verified_backup':{'branch':'agent/stock-driver-wip-backup-20261016T161413Z','commit':'a94fc7b29b23c7bcc59bd9f28b79bc629d58dae1','archive':'/home/lee/.clifv-recovery/20261016T161356Z-delivery-gates-handoff/checkpoint.tar.gz','sha256':'94b5f4f4f54bf0bac2e16818adfe866e33edad84783891ceebbeaae9464d5194'}}
assert result['public_theorem_count']==9
receipt=root/'docs/research/stock-source-execution-xstack-scratch.json';receipt.write_text(json.dumps(result,indent=2)+'\n')
(root/'docs/research/stock-source-execution-xstack-scratch.md').write_text('''# Saved-caller exception execution checkpoint

Four scratch modules and nine public roots pass normal kernel checks under8GiB. The12-root/model transitive audit uses only standard axioms. Actual `Clif.step` always retains, pushes or pops one caller; `liftStep` preserves aligned saved exception tables. Actual `raiseIn` and `unwindFrom` preserve the invariant when resuming a caught caller, even after discarding multiple frames. Ordinary entry establishes alignment internally.

Complete nested program-call witnesses throw at a leaf, skip a plain caller and catch in the lower TryCall caller. Both tagged and default handlers bind payload42 at fresh value10, enter the real handler and return42 in complete `runWithX` executions. The actual TryCall push exercises the new normal-step stack-shape and lifted invariant.

The source-specific pending-table/location specialization and generic `stepX`/prefix composition remain required. These generic helper premises are internal composition obligations, not new accepted-program conditions. No full Stock value/world simulation or completeness is claimed. Production remains legacy and original#140 remains active. The canonical2,246source/script freeze and live delivery worker were independently verified. No shared build-cache writes occurred; the temporary five-object input snapshot is archived and removed at batch completion.

[Hashed sources, objects, kernel logs, axiom sets, witnesses and remaining checklist](stock-source-execution-xstack-scratch.json).
''')
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');folder=Path('/home/lee/.clifv-recovery',stamp+'-source-xstack');folder.mkdir();archive=folder/'checkpoint.tar.gz'
files=[Path('/tmp/stock-xstack-evidence.py'),receipt,root/'docs/research/stock-source-execution-xstack-scratch.md',Path('/tmp/stock-unwind-proof-inputs.json'),audit,audit.with_suffix('.lean'),root/'docs/plans/test-binary-alignment-recovery.md']
for r in records.values():files.extend(Path(r[k]) for k in ['source','object','log'])
files.extend(Path('/tmp/stock-unwind-proof-inputs').rglob('*.olean'))
for extra in ['stock-pr246-allocation-review.json','stock-pr246-allocation-review-checkpoint.json']:
 p=root/'docs/research'/extra
 if p.exists():files.append(p)
with tarfile.open(archive,'w:gz',compresslevel=1) as tar:
 for p in files:tar.add(p,arcname=str(p).lstrip('/'),recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 for p in files:
  f=tar.extractfile(str(p).lstrip('/'));assert f and f.read()==p.read_bytes(),p
out={'utc':now,'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(files),'all_members_byte_verified':True,'snapshot_removed_after_archival':False}
# This uniquely owned, manifest-verified five-object input copy is expendable.
assert Path('/tmp/stock-unwind-proof-inputs').is_dir();assert len(list(Path('/tmp/stock-unwind-proof-inputs').rglob('*.olean')))==5
shutil.rmtree('/tmp/stock-unwind-proof-inputs');out['snapshot_removed_after_archival']=True
(root/'docs/research/stock-source-execution-xstack-backup.json').write_text(json.dumps(out,indent=2)+'\n');Path('/tmp/stock-xstack-archive-path.txt').write_text(str(archive));print(json.dumps(out))
