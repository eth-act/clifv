import StockTryBranchSelection
import FV.Backend.Proof.PerEdgeSpillEntryFixture
namespace Backend.Stock.Proof.TrySourceContextWitnessDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open TrySourceContextDraft TryBranchSelectionDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
attribute [local irreducible] Stock.lower Stock.runTerm Isle.Aarch64.program
private def function := SpillEntryFixture.function
private def entry (indirect : Bool) := (function indirect).blocks[0]!
private theorem block (indirect : Bool) : (function indirect).blocks[0]? = some (entry indirect) := by cases indirect <;> rfl
private theorem order (indirect : Bool) : blockOrder (function indirect) = .ok {
    nodes := #[.original 0,.original 1,.original 2],successors := #[#[2,1],#[],#[]]} := by cases indirect <;> cbv
private def original (indirect : Bool) : Ctx × Array (Nat × Nat) × State :=
  (Stock.buildCtx (function indirect)).toOption.getD (sinkCtx,#[],default)
private theorem build (indirect : Bool) : Stock.buildCtx (function indirect) = .ok (original indirect) := by cases indirect <;> rfl
private def frame (indirect : Bool) : Clif.Frame := {
  func := function indirect
  regs := if indirect then (Clif.Regs.empty.set 0 ⟨.i64,9⟩).set 1 ⟨.i64,4096⟩ else Clif.Regs.empty.set 0 ⟨.i64,9⟩
  slots := []
  body := []
  term := (entry indirect).term }
private theorem consistent (indirect : Bool) : DFGCons (original indirect).1 (frame indirect) := by
  cases indirect <;> constructor
  all_goals first
    | (intro x j info cl v definition lookup clif pure read
       rcases x with _ | (_ | x)
       all_goals first
         | (solve | change none = some v at read; cases read)
         | (solve |
            change some 0 = some j at definition
            cases definition
            have atSlot : (original false).1.insts[0]? = some ((original false).1.insts[0]!) := rfl
            rw [atSlot] at lookup
            cases lookup
            change some (.iconst .i64 9) = some cl at clif
            cases clif
            change some ⟨.i64,9⟩ = some v at read
            cases read
            exact ⟨[⟨.i64,9⟩],by intro cm; rfl,rfl⟩)
         | (solve |
            change some 0 = some j at definition
            cases definition
            have atSlot : (original true).1.insts[0]? = some ((original true).1.insts[0]!) := rfl
            rw [atSlot] at lookup
            cases lookup
            change some (.iconst .i64 9) = some cl at clif
            cases clif
            change some ⟨.i64,9⟩ = some v at read
            cases read
            exact ⟨[⟨.i64,9⟩],by intro cm; rfl,rfl⟩)
         | (solve |
            change some 1 = some j at definition
            cases definition
            have atSlot : (original true).1.insts[1]? = some ((original true).1.insts[1]!) := rfl
            rw [atSlot] at lookup
            cases lookup
            change some (.iconst .i64 4096) = some cl at clif
            cases clif
            change some ⟨.i64,4096⟩ = some v at read
            cases read
            exact ⟨[⟨.i64,4096⟩],by intro cm; rfl,rfl⟩))
    | (intro x t v typed read
       rcases x with _ | (_ | x)
       all_goals first
         | (solve | change none = some v at read; cases read)
         | (solve | change some (.int 64) = some t at typed; cases typed
                    change some ⟨.i64,9⟩ = some v at read; cases read; rfl)
         | (solve | change some (.int 64) = some t at typed; cases typed
                    change some ⟨.i64,4096⟩ = some v at read; cases read; rfl))
private theorem source_build {f : Clif.Function} {result : Result} (run : Stock.lower f = .ok result) :
    ∃ ranges,Stock.buildCtx f = .ok (result.ctx,ranges,result.initial) := by
  unfold Stock.lower at run
  dsimp only at run
  repeat' first
    | (solve | cases run)
    | simp only [bind,Except.bind,pure,Except.pure] at run
    | split at run
  cases run
  exact ⟨_,by assumption⟩
/-- Complete original direct/indirect TryCall pipelines inhabit source-index,
mapped context/DFG and real first-match branch/RHS selection. The actual source
frame has its live constant values and satisfies the transported DFG predicate. -/
theorem stock_complete_try_source_context_witness (indirect : Bool) :
    ∃ (out : SpillEntryFixture.Output indirect)
      (source : TryBranchSource (function indirect) out.result 0 0 (entry indirect))
      (selected : TryBranchSelection source),
      LowerScope (function indirect) ∧ Dominated (function indirect) ∧ ArityOk (function indirect) ∧
      Stock.lower (function indirect) = .ok out.result ∧
      prepareAt out.result.code out.result.edgeArgs = .ok out.prepared ∧
      out.rf = spillAllocAt out.prepared.code out.prepared.edges ∧
      checkAllocAt out.prepared.code out.prepared.edges out.rf = .ok () ∧
      lowerRFunc out.prepared.code out.rf = .ok out.af ∧
      source.ti = (if indirect then 2 else 1) ∧
      source.ctx.func = function indirect ∧
      source.ctx.insts[source.ti]? = some ⟨source.data,[],[],none⟩ ∧
      source.ctx.valueReg? = out.result.ctx.valueReg? ∧
      source.ctx.tryRegs = source.input.tryRegs[source.ti]! ∧
      DFGCons out.result.ctx (frame indirect) ∧ DFGCons source.ctx (frame indirect) ∧
      source.branch.step ∈ out.result.schedule.toList ∧
      source.branch.state = selected.next ∧ source.branch.step.before = {source.input with current := some source.ti,color := none,base.emitted := #[]} ∧
      source.branch.step.after = selected.next ∧ source.branch.step.rules = selected.trace ∧
      source.branch.step.emitted = source.branch.code := by
  obtain ⟨out⟩ := SpillEntryFixture.try_fixture indirect
  have sameOrder := Except.ok.inj ((stock_lower_order out.lowered).symm.trans (order indirect))
  have node : out.result.order.nodes[0]? = some (.original 0) := by rw [sameOrder]; rfl
  have kind : (entry indirect).term.isTry = true := by cases indirect <;> rfl
  obtain ⟨source,⟨selected⟩⟩ := stock_lower_try_source_selection out.lowered out.scope node (block indirect) kind
  obtain ⟨ranges,built⟩ := source_build out.lowered
  have context : out.result.ctx = (original indirect).1 := congrArg Prod.fst (Except.ok.inj (built.symm.trans (build indirect)))
  have originalDfg : DFGCons out.result.ctx (frame indirect) := by rw [context]; exact consistent indirect
  have branchDfg := (source.consistent (frame indirect)).mpr originalDfg
  have index : source.ti = (if indirect then 2 else 1) := by rw [source.index]; cases indirect <;> rfl
  exact ⟨out,source,selected,out.scope,out.dominated,out.arity,out.lowered,out.prepare,out.fallback,
    out.accepted,out.physical,index,source.mapped.func,source.slot,source.valueMap,source.tryRegs,
    originalDfg,branchDfg,source.scheduled,selected.state,selected.stepBefore,selected.stepAfter,
    selected.stepRules,selected.stepCode⟩
private def table : Clif.ExnTable := {
  sig := 0,normal := ⟨1,[.ret 0,.val 0]⟩,items := [.tag 7 ⟨2,[.exn 0,.exn 1,.val 0]⟩] }
/-- Both decoded TryCall layouts/signatures inhabit their new roots in the
same complete compiler pipeline and real selected branch context. -/
theorem stock_complete_try_source_data_witness (indirect : Bool) :
    ∃ (out : SpillEntryFixture.Output indirect)
      (source : TryBranchSource (function indirect) out.result 0 0 (entry indirect))
      (selected : TryBranchSelection source),
      Stock.lower (function indirect) = .ok out.result ∧
      prepareAt out.result.code out.result.edgeArgs = .ok out.prepared ∧
      checkAllocAt out.prepared.code out.prepared.edges out.rf = .ok () ∧
      lowerRFunc out.prepared.code out.rf = .ok out.af ∧ DFGCons source.ctx (frame indirect) ∧
      (if indirect then
        ∃ (sig : Clif.Signature) (items : List (Option Nat)),
          exnTableOpnd (function indirect) table = .ok (sig,items) ∧
          source.data = .data 152 28 [.data 151 14 [],.values [1],.op (.exnTable sig items)]
       else ∃ (sig : Clif.Signature) (items : List (Option Nat)) (ext : Clif.ExtFunc),
          exnTableOpnd (function indirect) table = .ok (sig,items) ∧
          (function indirect).extern? 0 = some ext ∧ ext.sig = sig ∧
          source.data = .data 152 27 [.data 151 13 [],.values [],.op (.funcRef 0),.op (.exnTable sig items)]) := by
  obtain ⟨out,source,selected,scope,dominated,arity,lowered,prepared,fallback,checked,physical,index,
    func,slot,mapping,regs,originalDfg,branchDfg,schedule,state,before,after,rules,code⟩ :=
    stock_complete_try_source_context_witness indirect
  refine ⟨out,source,selected,lowered,prepared,checked,physical,branchDfg,?_⟩
  cases indirect with
  | false => exact stock_try_source_direct_data source (show (entry false).term = .tryCall 0 [] table from rfl)
  | true => exact stock_try_source_indirect_data source (show (entry true).term = .tryCallIndirect 1 [] table from rfl)
end Backend.Stock.Proof.TrySourceContextWitnessDraft
