import StockTryBranchRecords
import FV.Backend.Proof.StockTermDataOrigin
import FV.Backend.Proof.StockNodeCoverage
namespace Backend.Stock.Proof.TrySourceContextDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64 TryBranchRecordsDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
attribute [local irreducible] Stock.runTerm lowerBlockCore branchArgs emitBranch collectOutgoing scanBlock
private theorem node_core {ctx : Ctx} {ranges : Array (Nat × Nat)} {order : Order}
    {f : Clif.Function} {params : List Nat} {label bi : Nat} {input output : DriverState}
    (node : order.nodes[label]! = .original bi) (isTry : f.blocks[bi]!.term.isTry = true)
    (run : lowerNode ctx ranges order f params label input = .ok output) :
    ∃ (data : Backend.V) (core : LoweredBlockCore),
      lowerBlockCore ctx order f f.blocks[bi]! bi ranges[bi]!.1 ranges[bi]!.2
        data order.successors[label]! input.state = .ok core ∧
      Coverage.blockData f f.blocks[bi]!.term = .ok data ∧
      output.schedule = (recordCore input core bi ranges[bi]!.2).schedule := by
  cases term : f.blocks[bi]!.term <;> simp only [term,Clif.Terminator.isTry] at isTry
  all_goals try contradiction
  all_goals
    unfold lowerNode at run
    simp only [node,term] at run
    repeat' first
      | (solve | cases run)
      | simp only [bind,Except.bind,pure,Except.pure] at run
      | split at run
    all_goals
      cases run
      refine ⟨_,_,by assumption,?_,rfl⟩
      simp only [Coverage.blockData,term]
      assumption
private theorem node_mono {ctx : Ctx} {ranges : Array (Nat × Nat)} {order : Order}
    {f : Clif.Function} {params : List Nat} {label : Nat} {input output : DriverState}
    {step : Step} (run : lowerNode ctx ranges order f params label input = .ok output)
    (member : step ∈ input.schedule.toList) : step ∈ output.schedule.toList := by
  unfold lowerNode at run
  dsimp only at run
  repeat' first
    | (solve | cases run)
    | simp only [bind,Except.bind,pure,Except.pure] at run
    | split at run
  all_goals
    cases run
    first | exact member | exact stock_recordCore_schedule_preserved member
private theorem nodes_mono {ctx : Ctx} {ranges : Array (Nat × Nat)} {order : Order}
    {f : Clif.Function} {params labels : List Nat} {input output : DriverState} {step : Step}
    (run : labels.foldlM (fun d k => lowerNode ctx ranges order f params k d) input = .ok output)
    (member : step ∈ input.schedule.toList) : step ∈ output.schedule.toList := by
  induction labels generalizing input with
  | nil => cases run; exact member
  | cons label rest ih =>
    rw [List.foldlM_cons] at run
    obtain ⟨middle,call,rest⟩ := Except.bind_ok run
    exact ih rest (node_mono call member)
private theorem origin {f : Clif.Function} {result : Result} (run : Stock.lower f = .ok result) :
    ∃ (ranges : Array (Nat × Nat)) (params : List Nat) (starting finishing : DriverState),
      Stock.buildCtx f = .ok (result.ctx,ranges,result.initial) ∧
      (Array.range result.order.nodes.size).reverse.toList.foldlM
        (fun d k => lowerNode result.ctx ranges result.order f params k d) starting = .ok finishing ∧
      result.schedule = finishing.schedule := by
  unfold Stock.lower at run
  dsimp only at run
  repeat' first
    | (solve | cases run)
    | simp only [bind,Except.bind,pure,Except.pure] at run
    | split at run
  cases run
  exact ⟨_,_,_,_,by assumption,by assumption,rfl⟩
/-- Source facts attached to the SAME actual scheduled TryCall branch.
The theorem derives this receipt; it is never a caller acceptance certificate. -/
structure TryBranchSource (f : Clif.Function) (result : Result) (label bi : Nat) (b : Clif.Block) where
  ctx : Ctx
  input : State
  data : Backend.V
  ti : Nat
  branch : BranchEmission
  index : ti = blockStart f bi + b.body.length
  prepared : Coverage.blockData f b.term = .ok data
  slot : ctx.insts[ti]? = some ⟨data,[],[],none⟩
  mapped : MappedCtxInv f ctx
  valueMap : ctx.valueReg? = result.ctx.valueReg?
  consistent : ∀ fr,DFGCons ctx fr ↔ DFGCons result.ctx fr
  tryRegs : ctx.tryRegs = input.tryRegs[ti]!
  emitted : emitBranch ctx f b.term bi ti result.order.successors[label]! input = .ok branch
  scheduled : branch.step ∈ result.schedule.toList

/-- Actual source construction and whole-driver traversal derive the exact
terminal index, placeholder replacement, mapped source context, DFG transport
and exception registers for a real scheduled TryCall branch. -/
theorem stock_lower_try_branch_source {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) {label bi : Nat} {b : Clif.Block}
    (node : result.order.nodes[label]? = some (.original bi)) (block : f.blocks[bi]? = some b)
    (isTry : b.term.isTry = true) : Nonempty (TryBranchSource f result label bi b) := by
  obtain ⟨ranges,params,starting,finishing,build,folded,schedule⟩ := origin run
  have bound := (Array.getElem?_eq_some_iff.mp node).1
  have member : label ∈ (Array.range result.order.nodes.size).reverse.toList := by simpa using bound
  obtain ⟨earlier,suffix,parts,_⟩ := List.eq_append_cons_of_mem member
  rw [parts,List.foldlM_append] at folded
  obtain ⟨before,_,rest⟩ := Except.bind_ok folded
  rw [List.foldlM_cons] at rest
  obtain ⟨after,call,last⟩ := Except.bind_ok rest
  have tag : result.order.nodes[label]! = .original bi := by simp only [getElem!_def,node]
  have original : f.blocks[bi]! = b := by simp only [getElem!_def,block]
  have kind : f.blocks[bi]!.term.isTry = true := by rw [original]; exact isTry
  obtain ⟨data,core,lowered,prepared,afterSchedule⟩ := node_core tag kind call
  rw [original] at lowered prepared
  obtain ⟨branch,selected,emitted⟩ := stock_lowerBlockCore_try_branch isTry lowered
  have retained : branch.step ∈ after.schedule.toList := by
    rw [afterSchedule]
    exact stock_recordCore_branch_retained selected
  have survived : branch.step ∈ result.schedule.toList := by rw [schedule]; exact nodes_mono last retained
  obtain ⟨oldCtx,oldState,oldBuild,spec,view⟩ := buildCtx_source build
  have range : ranges[bi]! = (blockStart f bi,blockStart f bi+b.body.length+1) := by
    simp only [getElem!_def,spec.ranges bi b block]
  have terminal : ranges[bi]!.2-1 = blockStart f bi+b.body.length := by rw [range]; simp
  let ti := blockStart f bi+b.body.length
  have placeholder : result.ctx.insts[ti]? = some ⟨.op .unit,[],[],none⟩ := by
    rw [view.insts]
    exact spec.facts.term bi b block
  have mapped := buildCtx_mappedInv scope build
  let ctx := {Driver.termCtx result.ctx ti data with tryRegs := before.state.tryRegs[ti]!}
  rw [terminal] at emitted
  have actualSlot : ctx.insts[ti]? = some ⟨data,[],[],none⟩ := termCtx_insts_self placeholder data
  refine ⟨{
    ctx := ctx
    input := before.state
    data := data
    ti := ti
    branch := branch
    index := rfl
    prepared := prepared
    slot := actualSlot
    mapped := (mapped.termCtx placeholder data).withTryRegs _
    valueMap := rfl
    consistent := ?_
    tryRegs := rfl
    emitted := emitted
    scheduled := survived }⟩
  intro fr
  exact mapped.dfgCons_termCtx_iff placeholder data fr
end Backend.Stock.Proof.TrySourceContextDraft
