import StockTrySourceContext
import FV.Backend.Proof.StockBranchSelection
namespace Backend.Stock.Proof.TryBranchSelectionDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open TrySourceContextDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
attribute [local irreducible] Stock.runTerm branchCode
private def branchInput (input : State) (ti : Nat) : State :=
  {input with current := some ti,color := none,base.emitted := #[]}
/-- First-match selection tied to the SAME actual source branch, its raw code
and schedule step, rather than a separately replayed ISLE protocol. -/
structure TryBranchSelection {f : Clif.Function} {result : Result} {label bi : Nat} {b : Clif.Block}
    (source : TryBranchSource f result label bi b) where
  out : Backend.V
  next : State
  trace : List RuleId
  named : Stock.runTerm source.ctx "lower_branch" [.inst source.ti,.labels result.order.successors[label]!.toList]
    (branchInput source.input source.ti) = .ok (some out,next,trace)
  selected : BranchSelection source.ctx source.ti result.order.successors[label]!.toList
    (branchInput source.input source.ti) out next trace
  code : branchCode f b.term result.order.successors[label]! next.base.emitted = .ok source.branch.code
  state : source.branch.state = next
  rules : source.branch.rules = trace
  stepBefore : source.branch.step.before = branchInput source.input source.ti
  stepAfter : source.branch.step.after = next
  stepRules : source.branch.step.rules = trace
  stepCode : source.branch.step.emitted = source.branch.code

/-- Actual emitBranch supplies its named match/RHS selection and exact emitted
call-to-TryCall replacement at the real Stock intermediate states. -/
theorem stock_try_branch_selection {f : Clif.Function} {result : Result} {label bi : Nat} {b : Clif.Block}
    (source : TryBranchSource f result label bi b) : Nonempty (TryBranchSelection source) := by
  have run := source.emitted
  unfold emitBranch at run
  change (do
    let (out,next,trace) ← Stock.runTerm source.ctx "lower_branch"
      [.inst source.ti,.labels result.order.successors[label]!.toList] (branchInput source.input source.ti)
    if out.isNone then throw _
    let code ← branchCode f b.term result.order.successors[label]! next.base.emitted
    pure (⟨next,code,⟨bi,source.ti,.emitted,branchInput source.input source.ti,next,[],trace,code⟩,trace⟩ : BranchEmission))
      = .ok source.branch at run
  cases named : Stock.runTerm source.ctx "lower_branch"
      [.inst source.ti,.labels result.order.successors[label]!.toList] (branchInput source.input source.ti) with
  | error err => simp only [named,bind,Except.bind] at run; cases run
  | ok q =>
    obtain ⟨out,next,trace⟩ := q
    simp only [named,bind,Except.bind] at run
    cases out with
    | none => simp only [Option.isNone_none,ite_true] at run; cases run
    | some out =>
      simp only [Option.isNone_some,Bool.false_eq_true,ite_false] at run
      cases code : branchCode f b.term result.order.successors[label]! next.base.emitted with
      | error err => simp only [code,bind,Except.bind] at run; cases run
      | ok instructions =>
        simp only [code,bind,Except.bind,pure,Except.pure] at run
        have equal := (Except.ok.inj run).symm
        obtain ⟨selection⟩ := stock_named_branch_selection named
        refine ⟨{
          out := out
          next := next
          trace := trace
          named := named
          selected := selection
          code := ?_
          state := ?_
          rules := ?_
          stepBefore := ?_
          stepAfter := ?_
          stepRules := ?_
          stepCode := ?_ }⟩
        all_goals rw [equal]
        exact code

/-- Original construction/traversal derive both the source receipt and the
actual first-match selection; neither is an accepted-program premise. -/
theorem stock_lower_try_source_selection {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) {label bi : Nat} {b : Clif.Block}
    (node : result.order.nodes[label]? = some (.original bi)) (block : f.blocks[bi]? = some b)
    (isTry : b.term.isTry = true) :
    ∃ source : TryBranchSource f result label bi b,Nonempty (TryBranchSelection source) := by
  obtain ⟨source⟩ := stock_lower_try_branch_source run scope node block isTry
  exact ⟨source,stock_try_branch_selection source⟩

/-- Real direct TryCall data and external signature are recovered from the
same source receipt's actual data preparation. -/
theorem stock_try_source_direct_data {f : Clif.Function} {result : Result} {label bi : Nat} {b : Clif.Block}
    (source : TryBranchSource f result label bi b) {fn : Nat} {args : List Nat} {et : Clif.ExnTable}
    (kind : b.term = .tryCall fn args et) :
    ∃ (sig : Clif.Signature) (items : List (Option Nat)) (ext : Clif.ExtFunc),
      exnTableOpnd f et = .ok (sig,items) ∧ f.extern? fn = some ext ∧ ext.sig = sig ∧
      source.data = .data 152 27 [.data 151 13 [],.values args,.op (.funcRef fn),.op (.exnTable sig items)] := by
  have prepared := source.prepared
  rw [kind] at prepared
  change tryCallData f (.tryCall fn args et) = .ok source.data at prepared
  obtain ⟨sig,items,ext,table,external,signature⟩ := tryCallData_spec prepared
  have data := tryCallData_eq (args := args) table external signature
  rw [prepared] at data
  exact ⟨sig,items,ext,table,external,signature,Except.ok.inj data⟩
/-- Real indirect TryCall data keeps the actual target value and declared
signature; no identity numbering or target-classification premise is added. -/
theorem stock_try_source_indirect_data {f : Clif.Function} {result : Result} {label bi : Nat} {b : Clif.Block}
    (source : TryBranchSource f result label bi b) {callee : Nat} {args : List Nat} {et : Clif.ExnTable}
    (kind : b.term = .tryCallIndirect callee args et) :
    ∃ (sig : Clif.Signature) (items : List (Option Nat)),exnTableOpnd f et = .ok (sig,items) ∧
      source.data = .data 152 28 [.data 151 14 [],.values (callee::args),.op (.exnTable sig items)] := by
  have prepared := source.prepared
  rw [kind] at prepared
  change tryCallData f (.tryCallIndirect callee args et) = .ok source.data at prepared
  obtain ⟨sig,items,table⟩ := tryCallIndData_spec prepared
  have data := tryCallIndData_eq (callee := callee) (args := args) table
  rw [prepared] at data
  exact ⟨sig,items,table,Except.ok.inj data⟩
end Backend.Stock.Proof.TryBranchSelectionDraft
