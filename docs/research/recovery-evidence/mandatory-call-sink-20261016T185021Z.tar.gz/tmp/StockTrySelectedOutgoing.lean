import StockTryRhsOutgoing
import StockTrySelectedCalls
namespace Backend.Stock.Proof.TrySelectedOutgoingDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open TrySourceContextDraft TryBranchSelectionDraft TrySelectedCallsDraft TryRhsOutgoingDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
/-- The actual selected direct OR GOT branch internally supplies the complete
signature stack bound, including original stackLayoutOk, at its real output. -/
theorem stock_selected_direct_try_stack {f : Clif.Function} {result : Result} {label bi : Nat} {b : Clif.Block}
    (scope : LowerScope f) (block : f.blocks[bi]? = some b)
    {source : TryBranchSource f result label bi b} (selected : TryBranchSelection source)
    {fn : Nat} {args : List Nat} {et : Clif.ExnTable} (kind : b.term = .tryCall fn args et)
    {ext : Clif.ExtFunc} (external : f.extern? fn = some ext) :
    SigStackOk ext.sig source.branch.state.base.outgoing := by
  refine ⟨?_,scope.stackLayout.2 b (List.mem_of_getElem? block) fn args et ext kind external⟩
  rw [selected.state]
  cases near : ext.colocated with
  | true =>
    obtain ⟨items,table,rule,env,matched,trace,calls⟩ := stock_selected_try_direct_rhs_calls selected kind external near
    exact stock_direct_try_rhs_outgoing calls
  | false =>
    obtain ⟨items,table,rule,env,matched,trace,calls⟩ := stock_selected_try_got_rhs_calls selected kind external near
    exact stock_got_try_rhs_outgoing calls
/-- An actual indirect source branch supplies its decoded signature and actual
outgoing bound. No extra indirect layout or count acceptance check is added. -/
theorem stock_selected_indirect_try_outgoing {f : Clif.Function} {result : Result} {label bi : Nat} {b : Clif.Block}
    {source : TryBranchSource f result label bi b} (selected : TryBranchSelection source)
    {callee : Nat} {args : List Nat} {et : Clif.ExnTable} (kind : b.term = .tryCallIndirect callee args et) :
    ∃ sig items,exnTableOpnd f et = .ok (sig,items) ∧ stackBytes sig ≤ source.branch.state.base.outgoing := by
  obtain ⟨sig,items,table,rule,env,matched,trace,calls⟩ := stock_selected_try_indirect_rhs_calls selected kind
  exact ⟨sig,items,table,by rw [selected.state]; exact stock_indirect_try_rhs_outgoing calls⟩
end Backend.Stock.Proof.TrySelectedOutgoingDraft
