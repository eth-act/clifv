import StockTryWholeOutgoing
import StockTryBranchAbiWitness
namespace Backend.Stock.Proof.TryOutgoingWitnessDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open TryProtocolWitnessDraft TrySourceContextDraft TryBranchSelectionDraft TrySourceOutgoingDraft TryWholeOutgoingDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private def function : Kind → Clif.Function
  | .near => TryNearFixtureDraft.function false
  | .got => SpillEntryFixture.function false
  | .indirect => SpillEntryFixture.function true
private def table : Clif.ExnTable := {
  sig := 0,normal := ⟨1,[.ret 0,.val 0]⟩,items := [.tag 7 ⟨2,[.exn 0,.exn 1,.val 0]⟩] }
/-- Complete near/GOT/indirect original-condition compiler pipelines inhabit
the actual helper→selected branch→reverse traversal→returned-area proofs. -/
theorem stock_complete_try_outgoing_witness (k : Kind) :
    ∃ (result : Result) (prepared : EdgeVCode) (rf : RFunc) (af : AFunc)
      (source : TryBranchSource (function k) result 0 0 (function k).blocks[0]!),
      LowerScope (function k) ∧ Dominated (function k) ∧ ArityOk (function k) ∧
      Stock.lower (function k) = .ok result ∧ prepareAt result.code result.edgeArgs = .ok prepared ∧
      rf = spillAllocAt prepared.code prepared.edges ∧ checkAllocAt prepared.code prepared.edges rf = .ok () ∧
      lowerRFunc prepared.code rf = .ok af ∧ source.branch.step ∈ result.schedule.toList ∧
      source.branch.state.base.outgoing ≤ result.code.outgoing ∧
      stackBytes (function k).sig ≤ result.code.outgoing := by
  obtain ⟨result,prepared,rf,af,oldSource,oldSelected,et,sig,items,info,call,scope,dominated,arity,
    lowered,prepare,fallback,accepted,physical,scheduled,kind,decoded,metadata,count,raw,last⟩ :=
    TryBranchAbiWitnessDraft.stock_complete_try_branch_explicit_abi_witness k
  have order : blockOrder (function k) = .ok {
    nodes := #[.original 0,.original 1,.original 2],successors := #[#[2,1],#[],#[]]} := by cases k <;> cbv
  have sameOrder := Except.ok.inj ((stock_lower_order lowered).symm.trans order)
  have node : result.order.nodes[0]? = some (.original 0) := by rw [sameOrder]; rfl
  have block : (function k).blocks[0]? = some (function k).blocks[0]! := by cases k <;> rfl
  have isTry : (function k).blocks[0]!.term.isTry = true := by cases k <;> rfl
  obtain ⟨source,bound⟩ := stock_lower_try_source_outgoing lowered scope node block isTry
  refine ⟨result,prepared,rf,af,source,scope,dominated,arity,lowered,prepare,fallback,accepted,physical,
    source.scheduled,bound,?_⟩
  cases k with
  | near =>
    let ext : Clif.ExtFunc := {name := "callee",sig := (function .near).sig,colocated := true}
    exact (stock_lower_direct_try_stack lowered scope node block
      (show (function .near).blocks[0]!.term = .tryCall 0 [] table from rfl)
      (show (function .near).extern? 0 = some ext from rfl)).1
  | got =>
    let ext : Clif.ExtFunc := {name := "callee",sig := (function .got).sig,colocated := false}
    exact (stock_lower_direct_try_stack lowered scope node block
      (show (function .got).blocks[0]!.term = .tryCall 0 [] table from rfl)
      (show (function .got).extern? 0 = some ext from rfl)).1
  | indirect =>
    obtain ⟨calleeSig,calleeItems,tableRun,area⟩ := stock_lower_indirect_try_outgoing lowered scope node block
      (show (function .indirect).blocks[0]!.term = .tryCallIndirect 1 [] table from rfl)
    have expected : exnTableOpnd (function .indirect) table = .ok ((function .indirect).sig,[some 7]) := rfl
    change exnTableOpnd (function .indirect) table = .ok (calleeSig,calleeItems) at tableRun
    rw [expected] at tableRun
    cases tableRun
    exact area
end Backend.Stock.Proof.TryOutgoingWitnessDraft
