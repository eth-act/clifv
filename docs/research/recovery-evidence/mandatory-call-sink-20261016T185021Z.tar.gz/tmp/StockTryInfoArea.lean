import StockTryHelperFrames
import FV.Backend.Proof.StockProjection
namespace Backend.Stock.Proof.TryInfoAreaDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
attribute [local irreducible] Stock.externCtor Isle.Aarch64.program Stock.runTerm
private theorem delegated {ctx : Ctx} {t : Term} {args : List V} {st next : State} {out : V}
    (ordinary : t.id ∉ revisedCtors) (run : Stock.externCtor ctx t args st = .ok (out,next)) :
    ∃ base,Backend.externCtor ctx t args st.base = .ok (out,base) ∧ next = {st with base} := by
  rw [stock_ctor_baseOnly _ _ _ _ ordinary] at run
  cases call : Backend.externCtor ctx t args st.base with
  | fail => rw [call] at run; cases run
  | unmodeled err => rw [call] at run; cases run
  | ok pair =>
    obtain ⟨value,base⟩ := pair
    rw [call] at run
    cases run
    exact ⟨base,rfl,rfl⟩
/-- Actual direct TryCall call-info construction decodes its real uses/defs,
preserves the call, and raises the outgoing area to its actual signature layout.
No caller call-shape or outgoing-area certificate is supplied. -/
theorem stock_try_direct_info_area {ctx : Ctx} {sig : Clif.Signature} {name : String}
    {uses defs tryValue value : V} {st next : State}
    (run : Stock.externCtor ctx T.gen_call_info
      [.op (.sig sig),.op (.extName name),uses,defs,tryValue,.bool false] st = .ok (value,next)) :
    ∃ (locs : List ArgLoc) (area : Nat) (us ds : List (Reg × Reg)),
      sigArgLocs sig = .ok (locs,area) ∧ uses = .op (.callArgs us) ∧ defs = .op (.callRets ds) ∧
      value = .op (.callInfo ⟨.sym name,us,ds⟩) ∧
      next = {st with base.outgoing := max st.base.outgoing area} := by
  obtain ⟨base,legacy,state⟩ := delegated (ctx := ctx) (st := st) (next := next) (out := value) (by decide) run
  have model : Backend.externCtor ctx T.gen_call_info
      [.op (.sig sig),.op (.extName name),uses,defs,tryValue,.bool false] st.base =
      (match (generalizing := false) uses,defs with
      | .op (.callArgs us),.op (.callRets ds) => match sigArgLocs sig with
        | .ok (_,area) => ExtResult.ok (.op (.callInfo ⟨.sym name,us,ds⟩),{st.base with outgoing := max st.base.outgoing area})
        | .error err => .unmodeled s!"gen_call_info: {err}"
      | _,_ => .unmodeled s!"constructor {T.gen_call_info.name} ({(6 : Nat)} args)") := by
    cases uses with
    | op u =>
      cases u <;> try rfl
      rename_i us
      cases defs with
      | op d => cases d <;> rfl
      | _ => rfl
    | _ => rfl
  rw [model] at legacy
  repeat' first | (solve | cases legacy) | split at legacy
  all_goals
    cases legacy
    exact ⟨_,_,_,_,by assumption,rfl,rfl,rfl,state⟩
/-- Actual indirect/GOT call-info construction likewise supplies the real target,
uses/defs and exact outgoing update internally, at its actual helper state. -/
theorem stock_try_indirect_info_area {ctx : Ctx} {sig : Clif.Signature}
    {target uses defs tryValue value : V} {st next : State}
    (run : Stock.externCtor ctx T.gen_call_ind_info
      [.op (.sig sig),target,uses,defs,tryValue] st = .ok (value,next)) :
    ∃ (locs : List ArgLoc) (area : Nat) (r : Reg) (us ds : List (Reg × Reg)),
      sigArgLocs sig = .ok (locs,area) ∧ target = .reg r ∧ uses = .op (.callArgs us) ∧ defs = .op (.callRets ds) ∧
      value = .op (.callInfo ⟨.reg r,us,ds⟩) ∧
      next = {st with base.outgoing := max st.base.outgoing area} := by
  obtain ⟨base,legacy,state⟩ := delegated (ctx := ctx) (st := st) (next := next) (out := value) (by decide) run
  have model : Backend.externCtor ctx T.gen_call_ind_info
      [.op (.sig sig),target,uses,defs,tryValue] st.base =
      (match (generalizing := false) target,uses,defs with
      | .reg r,.op (.callArgs us),.op (.callRets ds) => match sigArgLocs sig with
        | .ok (_,area) => ExtResult.ok (.op (.callInfo ⟨.reg r,us,ds⟩),{st.base with outgoing := max st.base.outgoing area})
        | .error err => .unmodeled s!"gen_call_ind_info: {err}"
      | _,_,_ => .unmodeled s!"constructor {T.gen_call_ind_info.name} ({(5 : Nat)} args)") := by
    cases target with
    | reg r =>
      cases uses with
      | op u =>
        cases u <;> try rfl
        rename_i us
        cases defs with
        | op d => cases d <;> rfl
        | _ => rfl
      | _ => rfl
    | _ => rfl
  rw [model] at legacy
  repeat' first | (solve | cases legacy) | split at legacy
  all_goals
    cases legacy
    exact ⟨_,_,_,_,_,by assumption,rfl,rfl,rfl,rfl,state⟩
end Backend.Stock.Proof.TryInfoAreaDraft
