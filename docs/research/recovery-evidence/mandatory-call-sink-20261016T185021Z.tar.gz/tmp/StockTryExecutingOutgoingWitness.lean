import StockTryWholeOutgoing
import StockSourceTryHandlerCoverage
import FV.Backend.Proof.PerEdgeSpillEntryFixture
namespace Backend.Stock.Proof.TryExecutingOutgoingWitnessDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open SourceExecutionXCoreDraft SourceExecutionXSourceDraft SourceExecutingTryDraft TryBranchRecordsDraft
open SourceExecutionGraphDraft SourceTryHandlerCoverageDraft TryWholeOutgoingDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
attribute [local irreducible] Stock.lower Stock.runTerm Isle.Aarch64.program
private def function := SpillEntryFixture.function
private def program (indirect : Bool) : Clif.Program := {funcs := [function indirect]}
private def memory : Clif.Mem := {Clif.Mem.empty with symbols := fun n => if n = "callee" then some 4096 else none}
private def exception : Clif.Exn := {catches := fun n => n == 7,payload := [⟨.i64,42⟩,⟨.i64,99⟩]}
private def environment (indirect handler : Bool) : Clif.XEnv := {
  extern := fun n => if n = "callee" then some (fun _ mem =>
    if handler then .unwound exception mem else .returned [⟨.i64,17⟩] mem) else none
  names := ["callee"]
  sigOf := fun n => if n = "callee" then some (function indirect).sig else none }
private def initial (indirect : Bool) : Clif.State := {
  frame := {
    func := function indirect
    regs := Clif.Regs.empty
    slots := []
    body := ((function indirect).blocks[0]!).body
    term := ((function indirect).blocks[0]!).term }
  callers := []
  mem := memory }
private def first (indirect : Bool) : Clif.State := {
  initial indirect with frame := {(initial indirect).frame with
    regs := Clif.Regs.empty.set 0 ⟨.i64,9⟩
    body := if indirect then [⟨[1],.iconst .i64 4096⟩] else []} }
private def current (indirect : Bool) : Clif.State :=
  if indirect then {first indirect with frame := {(first indirect).frame with
    regs := (first indirect).frame.regs.set 1 ⟨.i64,4096⟩,body := []}} else first indirect
private def afterTry (indirect handler : Bool) : Clif.XState := {
  s := {current indirect with frame := {(current indirect).frame with
    regs := if handler then ((current indirect).frame.regs.set 7 ⟨.i64,42⟩).set 8 ⟨.i64,99⟩
      else (current indirect).frame.regs.set 7 ⟨.i64,17⟩
    term := if handler then .jump ⟨2,[7,8,0]⟩ else .jump ⟨1,[7,0]⟩} }
  tries := [] }
private def afterJump (indirect handler : Bool) : Clif.XState :=
  match Clif.stepX (environment indirect handler) (program indirect) (afterTry indirect handler) with
  | .next xs => xs
  | _ => (current indirect).toX
private def source : Array (Array Nat) := #[#[2,1],#[],#[]]
private theorem computed (indirect : Bool) : stockSourceTable (function indirect) = .ok source := by cases indirect <;> cbv
private theorem entered (indirect : Bool) :
    Clif.initState (program indirect) (function indirect).name [] memory = .ok (initial indirect) := by cases indirect <;> rfl
private theorem setup (indirect handler : Bool) :
    XRunPrefix (environment indirect handler) (program indirect) (initial indirect).toX (current indirect).toX := by
  have firstStep : Clif.stepX (environment indirect handler) (program indirect) (initial indirect).toX =
      .next (first indirect).toX := by cases indirect <;> cases handler <;> rfl
  cases indirect with
  | false => exact .next firstStep (.refl _)
  | true =>
    refine .next firstStep (.next ?_ (.refl _))
    cases handler <;> rfl
private theorem actual (indirect handler : Bool) :
    Clif.stepX (environment indirect handler) (program indirect) (current indirect).toX =
      .next (afterTry indirect handler) := by cases indirect <;> cases handler <;> rfl
private theorem jumping (indirect handler : Bool) :
    Clif.stepX (environment indirect handler) (program indirect) (afterTry indirect handler) =
      .next (afterJump indirect handler) := by cases indirect <;> cases handler <;> rfl
private theorem complete (indirect handler : Bool) :
    Clif.runWithX (environment indirect handler) (program indirect) (function indirect).name [] memory
      (if indirect then 6 else 5) = .returned [⟨.i64,if handler then 42 else 17⟩] memory := by
  cases indirect <;> cases handler <;> rfl
private def table : Clif.ExnTable := {
  sig := 0,normal := ⟨1,[.ret 0,.val 0]⟩,items := [.tag 7 ⟨2,[.exn 0,.exn 1,.val 0]⟩] }
/-- Complete direct/indirect compiler pipelines exercise the new
execution-prefix outgoing bounds, and both normal/tagged-exception source runs
finish with live ordinary and payload arguments under original conditions. -/
theorem stock_complete_executing_try_outgoing_witness (indirect handler : Bool) :
    ∃ out : SpillEntryFixture.Output indirect,
      LowerScope (function indirect) ∧ Dominated (function indirect) ∧ ArityOk (function indirect) ∧
      Stock.lower (function indirect) = .ok out.result ∧
      prepareAt out.result.code out.result.edgeArgs = .ok out.prepared ∧
      out.rf = spillAllocAt out.prepared.code out.prepared.edges ∧
      checkAllocAt out.prepared.code out.prepared.edges out.rf = .ok () ∧
      lowerRFunc out.prepared.code out.rf = .ok out.af ∧
      XRunPrefix (environment indirect handler) (program indirect) (initial indirect).toX (current indirect).toX ∧
      stackBytes (function indirect).sig ≤ out.result.code.outgoing ∧
      Clif.runWithX (environment indirect handler) (program indirect) (function indirect).name [] memory
        (if indirect then 6 else 5) = .returned [⟨.i64,if handler then 42 else 17⟩] memory := by
  obtain ⟨out⟩ := SpillEntryFixture.try_fixture indirect
  refine ⟨out,out.scope,out.dominated,out.arity,out.lowered,out.prepare,out.fallback,out.accepted,out.physical,
    setup indirect handler,?_,complete indirect handler⟩
  cases indirect with
  | false =>
    let ext : Clif.ExtFunc := {name := "callee",sig := (function false).sig}
    exact (stock_lower_xexecuting_direct_try_stack out.lowered out.scope (entered false)
      (setup false handler) (show (current false).frame.func = function false from rfl)
      (show (current false).frame.body = [] from rfl)
      (show (current false).frame.term = .tryCall 0 [] table from rfl)
      (show (function false).extern? 0 = some ext from rfl)).1
  | true =>
    obtain ⟨sig,items,decoded,bound⟩ := stock_lower_xexecuting_indirect_try_outgoing out.lowered out.scope
      (entered true) (setup true handler) (show (current true).frame.func = function true from rfl)
      (show (current true).frame.body = [] from rfl)
      (show (current true).frame.term = .tryCallIndirect 1 [] table from rfl)
    have expected : exnTableOpnd (function true) table = .ok ((function true).sig,[some 7]) := rfl
    change exnTableOpnd (function true) table = .ok (sig,items) at decoded
    rw [expected] at decoded
    cases decoded
    exact bound
end Backend.Stock.Proof.TryExecutingOutgoingWitnessDraft
