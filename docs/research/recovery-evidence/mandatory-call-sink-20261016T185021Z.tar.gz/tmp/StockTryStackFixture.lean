import StockTryStackObservation
namespace Backend.Stock.Proof.TryStackFixtureDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill TryStackSourceDraft TryStackObservationDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
attribute [local irreducible] Stock.lower Stock.runTerm Stock.externCtor pipeline
structure Output where
  result : Result
  prepared : EdgeVCode
  rf : RFunc
  af : AFunc
  lowered : Stock.lower function = .ok result
  scope : LowerScope function
  dominated : Dominated function
  arity : ArityOk function
  prepare : prepareAt result.code result.edgeArgs = .ok prepared
  fallback : rf = spillAllocAt prepared.code prepared.edges
  accepted : checkAllocAt prepared.code prepared.edges rf = .ok ()
  physical : lowerRFunc prepared.code rf = .ok af
  outgoing : result.code.outgoing = 16
private theorem observed_exists {α : Type} (p : Except String α) (test : α → Bool)
    (h : p.toOption.map test = some true) : ∃ q,p = .ok q ∧ test q = true := by
  cases p with
  | error err => cases h
  | ok q => exact ⟨q,rfl,Option.some.inj h⟩
/-- Complete nine-argument source/Stock/prepare/checked-spill/physical pipeline
with a genuine16-byte outgoing stack requirement. -/
theorem stock_nine_argument_try_fixture : Nonempty Output := by
  obtain ⟨q,run,area⟩ := observed_exists pipeline (fun q => decide (q.1.code.outgoing = 16)) observed
  have outgoing : q.1.code.outgoing = 16 := of_decide_eq_true area
  delta pipeline at run
  obtain ⟨result,lowered,h⟩ := Except.bind_ok run
  obtain ⟨prepared,prepare,h⟩ := Except.bind_ok h
  obtain ⟨rf,selected,h⟩ := Except.bind_ok h
  obtain ⟨af,physical,h⟩ := Except.bind_ok h
  cases h
  have accepted := PerEdge.allocResultAt_checked selected
  have fallback : rf = spillAllocAt prepared.code prepared.edges := by
    unfold allocResultAt checkedSpillAt at selected
    simp only [bind,Except.bind] at selected
    split at selected <;> cases selected
    rfl
  exact ⟨⟨result,prepared,rf,af,lowered,original_conditions.1,original_conditions.2.1,original_conditions.2.2,
    prepare,fallback,accepted,physical,outgoing⟩⟩
end Backend.Stock.Proof.TryStackFixtureDraft
