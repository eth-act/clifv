import StockTryWholeOutgoing
import FV.Backend.Proof.PerEdgeSpillEntry
import FV.Backend.Proof.SpillCtlForms
import FV.Backend.Proof.SpillArity
import FV.Backend.Proof.StockCfgTotalWitness
import FV.Backend.Proof.PerEdgeAllocDriverSound
namespace Backend.Stock.Proof.TryStackSourceDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
def signature : Clif.Signature := {
  params := List.replicate 9 ⟨.i64,.none,.normal⟩,returns := [⟨.i64,.none,.normal⟩],callConv := some .systemV }
def table : Clif.ExnTable := {sig := 0,normal := ⟨1,[.ret 0]⟩,items := [.tag 7 ⟨2,[.exn 0,.exn 1]⟩]}
def function : Clif.Function := {
  name := "stock_try_nine_stack_arguments",sig := signature,sigDecls := [(0,signature)]
  externs := [(0,{name := "callee",sig := signature,colocated := false})]
  blocks := [{id := 0,params := (List.range 9).map fun n => (n,.i64),term := .tryCall 0 (List.range 9) table},
    {id := 1,params := [(20,.i64)],term := .ret [20]},
    {id := 2,params := [(21,.i64),(22,.i64)],term := .ret [21]}] }
private def original : Ctx × Array (Nat × Nat) × LState :=
  (Backend.buildCtx function).toOption.getD (sinkCtx,#[],default)
private theorem original_build : Backend.buildCtx function = .ok original := rfl
private theorem dominated : Dominated function := by
  constructor
  · decide +kernel
  · intro ctx ranges st build bi b found
    have bound : bi < 3 := by have h := lt_of_getElem? found; simpa [function] using h
    have choices : bi = 0 ∨ bi = 1 ∨ bi = 2 := by omega
    rcases choices with rfl | rfl | rfl
    all_goals
      simp [function] at found
      subst b
      constructor
      · intro j stm present y member
        simp at present
      · intro y member
        simp [abiTerm,Driver.termArgs,sretRet,sigRets,function,signature,table,
          Clif.ExnTable.vals,Clif.TryDest.vals] at member
        simp_all [availOf,function,defsBefore,defsFrom]
  · intro ctx ranges st build tl x incoming notLocal y member
    have context : ctx = original.1 := congrArg Prod.fst (Except.ok.inj (build.symm.trans original_build))
    have noDefs : original.1.valDef = Array.replicate 23 none := rfl
    rw [context] at member
    have noDef : original.1.defInst? x = none := by
      simp only [Ctx.defInst?,noDefs,Array.getElem?_replicate]
      split <;> rfl
    simp only [defArgs,noDef,List.not_mem_nil] at member
theorem original_conditions : LowerScope function ∧ Dominated function ∧ ArityOk function := by
  exact ⟨lowerScope_of (by decide +kernel),dominated,arityOk_of (by decide +kernel)⟩
end Backend.Stock.Proof.TryStackSourceDraft
