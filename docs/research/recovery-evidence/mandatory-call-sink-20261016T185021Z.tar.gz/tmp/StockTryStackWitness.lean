import StockTryStackFixture
import StockTrySelectedCalls
namespace Backend.Stock.Proof.TryStackWitnessDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open TryStackSourceDraft TryStackFixtureDraft TrySourceContextDraft TryBranchSelectionDraft TrySourceOutgoingDraft
open TryWholeOutgoingDraft TrySelectedCallsDraft TryRhsOutgoingDraft SourceExecutionXCoreDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
attribute [local irreducible] Stock.lower Stock.runTerm Isle.Aarch64.program
private def sourceProgram : Clif.Program := {funcs := [function]}
private def memory : Clif.Mem := {Clif.Mem.empty with symbols := fun n => if n = "callee" then some 4096 else none}
private def arguments : List Clif.Val := [⟨.i64,1⟩,⟨.i64,2⟩,⟨.i64,3⟩,⟨.i64,4⟩,⟨.i64,5⟩,⟨.i64,6⟩,⟨.i64,7⟩,⟨.i64,8⟩,⟨.i64,9⟩]
private def initial : Clif.State := {
  frame := {
    func := function
    regs := (Clif.Regs.empty.setMany (List.range 9) arguments).getD Clif.Regs.empty
    slots := []
    body := []
    term := .tryCall 0 (List.range 9) table }
  callers := []
  mem := memory }
private def exception : Clif.Exn := {catches := fun n => n == 7,payload := [⟨.i64,42⟩,⟨.i64,99⟩]}
private def environment (handler : Bool) : Clif.XEnv := {
  extern := fun n => if n = "callee" then some (fun _ mem =>
    if handler then .unwound exception mem else .returned [⟨.i64,17⟩] mem) else none
  names := ["callee"],sigOf := fun n => if n = "callee" then some signature else none }
private theorem entered : Clif.initState sourceProgram function.name arguments memory = .ok initial := rfl
private theorem completed (handler : Bool) :
    Clif.runWithX (environment handler) sourceProgram function.name arguments memory 4 =
      .returned [⟨.i64,if handler then 42 else 17⟩] memory := by cases handler <;> rfl
/-- A complete original-condition nine-argument GOT TryCall pipeline exercises
actual nonzero RHS, branch and final outgoing bounds AND the execution-prefix
variant. Normal and tagged exceptional source runs both complete, with all nine
actual argument values checked and a16-byte returned area. -/
theorem stock_complete_nine_argument_try_outgoing_witness (handler : Bool) :
    ∃ (out : Output) (source : TryBranchSource function out.result 0 0 function.blocks[0]!)
      (selected : TryBranchSelection source),
      LowerScope function ∧ Dominated function ∧ ArityOk function ∧
      Stock.lower function = .ok out.result ∧ prepareAt out.result.code out.result.edgeArgs = .ok out.prepared ∧
      out.rf = spillAllocAt out.prepared.code out.prepared.edges ∧
      checkAllocAt out.prepared.code out.prepared.edges out.rf = .ok () ∧ lowerRFunc out.prepared.code out.rf = .ok out.af ∧
      out.result.code.outgoing = 16 ∧ stackBytes signature = 16 ∧ SigStackOk signature out.result.code.outgoing ∧
      16 ≤ selected.next.base.outgoing ∧ source.branch.state.base.outgoing ≤ out.result.code.outgoing ∧
      source.branch.step ∈ out.result.schedule.toList ∧
      Clif.initState sourceProgram function.name arguments memory = .ok initial ∧
      initial.frame.getMany (List.range 9) = .ok arguments ∧
      XRunPrefix (environment handler) sourceProgram initial.toX initial.toX ∧
      Clif.runWithX (environment handler) sourceProgram function.name arguments memory 4 =
        .returned [⟨.i64,if handler then 42 else 17⟩] memory := by
  obtain ⟨out⟩ := stock_nine_argument_try_fixture
  have order : blockOrder function = .ok {
    nodes := #[.original 0,.original 1,.original 2],successors := #[#[2,1],#[],#[]]} := by cbv
  have sameOrder := Except.ok.inj ((stock_lower_order out.lowered).symm.trans order)
  have node : out.result.order.nodes[0]? = some (.original 0) := by rw [sameOrder]; rfl
  have block : function.blocks[0]? = some function.blocks[0]! := rfl
  have isTry : function.blocks[0]!.term.isTry = true := rfl
  obtain ⟨source,whole⟩ := stock_lower_try_source_outgoing out.lowered out.scope node block isTry
  obtain ⟨selected⟩ := stock_try_branch_selection source
  let ext : Clif.ExtFunc := {name := "callee",sig := signature,colocated := false}
  have external : function.extern? 0 = some ext := rfl
  have kind : function.blocks[0]!.term = .tryCall 0 (List.range 9) table := rfl
  obtain ⟨items,tableRun,rule,env,matched,trace,calls⟩ := stock_selected_try_got_rhs_calls selected kind external rfl
  have nonzero : stackBytes signature = 16 := rfl
  have localBound : 16 ≤ selected.next.base.outgoing := by
    rw [← nonzero]
    exact stock_got_try_rhs_outgoing calls
  have finalBound := stock_lower_xexecuting_direct_try_stack (env := environment handler) out.lowered out.scope entered
    (XRunPrefix.refl initial.toX) (show initial.frame.func = function from rfl)
    (show initial.frame.body = [] from rfl) (show initial.frame.term = .tryCall 0 (List.range 9) table from rfl) external
  exact ⟨out,source,selected,out.scope,out.dominated,out.arity,out.lowered,out.prepare,out.fallback,
    out.accepted,out.physical,out.outgoing,nonzero,finalBound,localBound,whole,source.scheduled,entered,rfl,
    XRunPrefix.refl initial.toX,completed handler⟩
end Backend.Stock.Proof.TryStackWitnessDraft
