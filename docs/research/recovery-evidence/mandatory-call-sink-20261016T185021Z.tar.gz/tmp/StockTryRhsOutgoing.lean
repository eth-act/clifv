import StockTryInfoArea
import StockOutgoingFlow
namespace Backend.Stock.Proof.TryRhsOutgoingDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open TryRhsCallsDraft TryHelperFramesDraft TryInfoAreaDraft OutgoingDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
/-- The SAME actual direct TryCall RHS raises the outgoing area to its source
signature's stack requirement; subsequent call construction/emission preserve it.
No stack-layout/area or separately replayed-helper certificate is required. -/
theorem stock_direct_try_rhs_outgoing {p : Program} {ctx : Ctx} {args : List Nat} {sig : Clif.Signature}
    {name : String} {items : List (Option Nat)} {labels : List Label} {st next : State}
    {tr trace : Array RuleId} {out : V} (calls : DirectTryCalls p ctx args sig name items labels st next tr trace out) :
    stackBytes sig ≤ next.base.outgoing := by
  obtain ⟨abi,afterAbi,tryValue,afterTry,requested,afterRequest,uses,afterArgs,defs,afterDefs,
    callInfo,afterInfo,machine,afterMachine,machineTrace,callFuel,emitFuel,
    abiCall,tryCall,requestCall,argsCall,retsCall,infoCall,callBound,emitBound,callRun,emitRun⟩ := calls
  obtain ⟨same,_⟩ := stock_try_abi_identity abiCall
  subst abi
  obtain ⟨locs,area,us,ds,locations,usesEq,defsEq,infoEq,frame⟩ := stock_try_direct_info_area infoCall
  have raised : area ≤ afterInfo.base.outgoing := by rw [frame]; exact Nat.le_max_right _ _
  have bound := Nat.le_trans raised (Nat.le_trans (stock_apply_outgoingLe callRun) (stock_apply_outgoingLe emitRun))
  simpa only [stackBytes,locations] using bound
/-- The actual GOT symbol load and indirect call construction lead to the same
signature-derived area bound at the SAME completed TryCall RHS state. -/
theorem stock_got_try_rhs_outgoing {p : Program} {ctx : Ctx} {args : List Nat} {sig : Clif.Signature}
    {name : String} {distance : V} {items : List (Option Nat)} {labels : List Label} {st next : State}
    {tr trace : Array RuleId} {out : V} (calls : GotTryCalls p ctx args sig name distance items labels st next tr trace out) :
    stackBytes sig ≤ next.base.outgoing := by
  obtain ⟨abi,afterAbi,tryValue,afterTry,requested,afterRequest,uses,afterArgs,defs,afterDefs,
    boxed,afterBox,target,afterTarget,targetTrace,callInfo,afterInfo,machine,afterMachine,machineTrace,
    loadFuel,callFuel,emitFuel,abiCall,tryCall,requestCall,argsCall,retsCall,boxCall,loadBound,loadRun,
    infoCall,callBound,emitBound,callRun,emitRun⟩ := calls
  obtain ⟨same,_⟩ := stock_try_abi_identity abiCall
  subst abi
  obtain ⟨locs,area,r,us,ds,locations,targetEq,usesEq,defsEq,infoEq,frame⟩ := stock_try_indirect_info_area infoCall
  have raised : area ≤ afterInfo.base.outgoing := by rw [frame]; exact Nat.le_max_right _ _
  have bound := Nat.le_trans raised (Nat.le_trans (stock_apply_outgoingLe callRun) (stock_apply_outgoingLe emitRun))
  simpa only [stackBytes,locations] using bound
/-- The real indirect source target and helper protocol derive its outgoing
stack requirement at actual returned RHS state without a caller bound. -/
theorem stock_indirect_try_rhs_outgoing {p : Program} {ctx : Ctx} {callee : Nat} {args : List Nat} {sig : Clif.Signature}
    {items : List (Option Nat)} {labels : List Label} {st next : State}
    {tr trace : Array RuleId} {out : V} (calls : IndirectTryCalls p ctx callee args sig items labels st next tr trace out) :
    stackBytes sig ≤ next.base.outgoing := by
  obtain ⟨abi,afterAbi,tryValue,afterTry,target,afterTarget,requested,afterRequest,uses,afterArgs,defs,afterDefs,
    callInfo,afterInfo,machine,afterMachine,machineTrace,callFuel,emitFuel,
    abiCall,tryCall,targetCall,requestCall,argsCall,retsCall,infoCall,callBound,emitBound,callRun,emitRun⟩ := calls
  obtain ⟨same,_⟩ := stock_try_abi_identity abiCall
  subst abi
  obtain ⟨locs,area,r,us,ds,locations,targetEq,usesEq,defsEq,infoEq,frame⟩ := stock_try_indirect_info_area infoCall
  have raised : area ≤ afterInfo.base.outgoing := by rw [frame]; exact Nat.le_max_right _ _
  have bound := Nat.le_trans raised (Nat.le_trans (stock_apply_outgoingLe callRun) (stock_apply_outgoingLe emitRun))
  simpa only [stackBytes,locations] using bound
end Backend.Stock.Proof.TryRhsOutgoingDraft
