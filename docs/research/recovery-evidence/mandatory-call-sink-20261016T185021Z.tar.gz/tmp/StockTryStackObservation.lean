import StockTryStackSource
namespace Backend.Stock.Proof.TryStackObservationDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill TryStackSourceDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 16000000
def pipeline : Except String (Result × EdgeVCode × RFunc × AFunc) := do
  let result ← Stock.lower function
  let prepared ← prepareAt result.code result.edgeArgs
  let rf ← allocResultAt prepared.code prepared.edges (.error "force nine-argument try checked fallback")
  let af ← lowerRFunc prepared.code rf
  pure (result,prepared,rf,af)
def Observed : Prop := pipeline.toOption.map (fun q => decide (q.1.code.outgoing = 16)) = some true
theorem observed : Observed := by
  unfold Observed pipeline
  decide +kernel
end Backend.Stock.Proof.TryStackObservationDraft
