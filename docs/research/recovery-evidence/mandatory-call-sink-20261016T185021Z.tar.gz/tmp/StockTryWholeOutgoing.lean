import StockTrySelectedOutgoing
import StockTrySourceOutgoing
import StockSourceExecutingTry
namespace Backend.Stock.Proof.TryWholeOutgoingDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open TrySourceContextDraft TryBranchSelectionDraft TrySelectedOutgoingDraft TrySourceOutgoingDraft SourceExecutingTryDraft SourceExecutionXCoreDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
/-- Every actual original direct/GOT TryCall node fits the final returned area.
Source, selection, helper-area and reverse-traversal facts are derived internally. -/
theorem stock_lower_direct_try_stack {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f)
    {label bi : Nat} {b : Clif.Block} (node : result.order.nodes[label]? = some (.original bi))
    (block : f.blocks[bi]? = some b) {fn : Nat} {args : List Nat} {et : Clif.ExnTable}
    (kind : b.term = .tryCall fn args et) {ext : Clif.ExtFunc} (external : f.extern? fn = some ext) :
    SigStackOk ext.sig result.code.outgoing := by
  have isTry : b.term.isTry = true := by rw [kind]; rfl
  obtain ⟨source,bound⟩ := stock_lower_try_source_outgoing lowered scope node block isTry
  obtain ⟨selected⟩ := stock_try_branch_selection source
  have localBound := stock_selected_direct_try_stack scope block selected kind external
  exact ⟨Nat.le_trans localBound.1 bound,localBound.2⟩
/-- The actual indirect source signature likewise fits the returned code area;
no global all-source-block stack predicate is imposed. -/
theorem stock_lower_indirect_try_outgoing {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f)
    {label bi : Nat} {b : Clif.Block} (node : result.order.nodes[label]? = some (.original bi))
    (block : f.blocks[bi]? = some b) {callee : Nat} {args : List Nat} {et : Clif.ExnTable}
    (kind : b.term = .tryCallIndirect callee args et) :
    ∃ sig items,exnTableOpnd f et = .ok (sig,items) ∧ stackBytes sig ≤ result.code.outgoing := by
  have isTry : b.term.isTry = true := by rw [kind]; rfl
  obtain ⟨source,bound⟩ := stock_lower_try_source_outgoing lowered scope node block isTry
  obtain ⟨selected⟩ := stock_try_branch_selection source
  obtain ⟨sig,items,table,localBound⟩ := stock_selected_indirect_try_outgoing selected kind
  exact ⟨sig,items,table,Nat.le_trans localBound bound⟩
/-- Every real exceptional execution prefix reaching a direct/GOT TryCall
internally supplies its compiled node and final outgoing bound. Neither source
reachability nor node/emission/stack certificates are caller conditions. -/
theorem stock_lower_xexecuting_direct_try_stack {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f)
    {env : Clif.XEnv} {p : Clif.Program} {name : String} {args : List Clif.Val} {mem : Clif.Mem}
    {initial : Clif.State} {current : Clif.XState} (entry : Clif.initState p name args mem = .ok initial)
    (execution : XRunPrefix env p initial.toX current) (function : current.s.frame.func = f)
    (empty : current.s.frame.body = []) {fn : Nat} {values : List Nat} {et : Clif.ExnTable}
    (kind : current.s.frame.term = .tryCall fn values et) {ext : Clif.ExtFunc} (external : f.extern? fn = some ext) :
    SigStackOk ext.sig result.code.outgoing := by
  have isTry : current.s.frame.term.isTry = true := by rw [kind]; rfl
  obtain ⟨label,bi,b,ctx,input,ti,branch,vblock,last,block,term,node,rest⟩ :=
    stock_lower_xexecuting_try_scheduled lowered scope entry execution function empty isTry
  exact stock_lower_direct_try_stack lowered scope node block (term.trans kind) external
/-- The same execution-to-original-source connection handles actual indirect
TryCalls, with their decoded signature and no caller reachability certificate. -/
theorem stock_lower_xexecuting_indirect_try_outgoing {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f)
    {env : Clif.XEnv} {p : Clif.Program} {name : String} {args : List Clif.Val} {mem : Clif.Mem}
    {initial : Clif.State} {current : Clif.XState} (entry : Clif.initState p name args mem = .ok initial)
    (execution : XRunPrefix env p initial.toX current) (function : current.s.frame.func = f)
    (empty : current.s.frame.body = []) {callee : Nat} {values : List Nat} {et : Clif.ExnTable}
    (kind : current.s.frame.term = .tryCallIndirect callee values et) :
    ∃ sig items,exnTableOpnd f et = .ok (sig,items) ∧ stackBytes sig ≤ result.code.outgoing := by
  have isTry : current.s.frame.term.isTry = true := by rw [kind]; rfl
  obtain ⟨label,bi,b,ctx,input,ti,branch,vblock,last,block,term,node,rest⟩ :=
    stock_lower_xexecuting_try_scheduled lowered scope entry execution function empty isTry
  exact stock_lower_indirect_try_outgoing lowered scope node block (term.trans kind)
end Backend.Stock.Proof.TryWholeOutgoingDraft
