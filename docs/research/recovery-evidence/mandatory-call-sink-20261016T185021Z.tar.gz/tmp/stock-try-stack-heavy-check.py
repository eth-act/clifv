from pathlib import Path
import os,signal,time,json,hashlib,datetime,subprocess as sp
root=Path('/home/lee/clifv/.worktrees/driver-proof-resume');worker=3247835;out=Path('/tmp/stock-try-stack-heavy-check.json');now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();held=False;result={'utc':now(),'worker':worker,'purpose':'One22GiB closed nine-argument GOT TryCall compiler observation, using established closed-fixture resource budget; same exact-PR supervisor resumes; one heavy kernel at a time'}
def proc(pid):
 try:
  fields=Path('/proc',str(pid),'stat').read_text().split(') ',1)[1].split()
  return {'state':fields[0],'exit_code':int(fields[49]),'cmdline':Path('/proc',str(pid),'cmdline').read_bytes().replace(b'\0',b' ').decode()}
 except FileNotFoundError:return None
try:
 w=proc(worker);assert w and 'stock-pr246-gates.py' in w['cmdline'] and w['state'] not in ['T','Z']
 os.kill(worker,signal.SIGSTOP);held=True
 while proc(worker)['state']!='T':time.sleep(.01)
 children=[int(p) for p in Path('/proc',str(worker),'task',str(worker),'children').read_text().split()]
 result.update(state='waiting_actual_current_kernel',children=children,current_phase={k:v for k,v in json.load(open('/tmp/stock-pr246-gates-progress.json')).items() if k!='completed_phases'});out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'state':result['state'],'children':children}),flush=True)
 while True:
  states={p:proc(p) for p in children}
  if all(s is None or s['state']=='Z' for s in states.values()):break
  assert proc(worker)['state']=='T'
  time.sleep(5)
 assert all(s is None or s['exit_code']==0 for s in states.values()),states
 active=sp.check_output(['ps','-C','lean','-o','args='],text=True)
 assert not any('stock-delivery-gates/FV/' in line for line in active.splitlines()),active
 frozen=json.load(open('/tmp/stock-coherent-build-inputs.json'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
 assert {str(p.relative_to(root)):sha(p) for d in ['FV','FVTest'] for p in (root/d).rglob('*.lean')}==frozen['source_sha256']
 for p,h in frozen['validation_script_sha256'].items():assert sha(root/p)==h
 result.update(state='running_isolated22G_observation',terminal_delivery_children=states);out.write_text(json.dumps(result,indent=2)+'\n');print(result['state'],flush=True)
 env=dict(os.environ,OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',LEAN_PATH='/tmp/stock-try-rule-inputs:/tmp',FV_MEMCAP='22G');log=Path('/tmp/StockTryStackObservation.log');source=Path('/tmp/StockTryStackObservation.lean');obj=source.with_suffix('.olean')
 with log.open('w') as f:r=sp.run([str(root/'scripts/memcap.sh'),'/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin/lean','--root=/tmp',str(source),'-o',str(obj)],cwd=root,env=env,stdout=f,stderr=sp.STDOUT)
 result.update(exit_code=r.returncode,log=str(log),log_sha256=sha(log),source_sha256=sha(source),object_present=obj.exists())
 assert r.returncode==0 and obj.exists(),result
 result.update(state='kernel_pass',object_sha256=sha(obj))
 Path('/tmp/StockTryStackObservation.check.json').write_text(json.dumps({'utc':now(),'actual_exit':r.returncode,'source_sha256':sha(source),'object_sha256':sha(obj),'log_sha256':sha(log)},indent=2)+'\n')
finally:
 if held:
  w=proc(worker);assert w and 'stock-pr246-gates.py' in w['cmdline'];os.kill(worker,signal.SIGCONT);result.update(same_worker_resumed=True)
 result['finished_utc']=now();out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
