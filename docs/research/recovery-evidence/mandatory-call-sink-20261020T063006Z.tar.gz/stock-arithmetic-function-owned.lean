import FV.Backend.Proof.StockArithmeticSourceWitness
import FV.Backend.Proof.StockArithmeticSourceExecutionWitness
import FV.Backend.Proof.StockArithmeticReturnWitness
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let mut coreCount : Nat := 0
  let mut witnessCount : Nat := 0
  for (name, _) in env.constants.toList do
    let some i := env.getModuleIdxFor? name | continue
    let owned := env.header.moduleNames[i]!.toString
    let core := #["FV.Backend.Proof.StockArithmeticSourceRefines", "FV.Backend.Proof.StockArithmeticSourceExecution", "FV.Backend.Proof.StockArithmeticSourceFrame", "FV.Backend.Proof.StockArithmeticTerminalDefined", "FV.Backend.Proof.StockArithmeticReturnRefines"]
    let witnesses := #["FV.Backend.Proof.StockArithmeticSourceWitness", "FV.Backend.Proof.StockArithmeticSourceExecutionWitness", "FV.Backend.Proof.StockArithmeticReturnWitness"]
    unless core.contains owned || witnesses.contains owned do continue
    let axioms ← collectAxioms name
    for ax in axioms do
      if #[``propext, ``Classical.choice, ``Quot.sound].contains ax then continue
      unless witnesses.contains owned &&
        ax.toString.startsWith "Backend.Stock.Proof.ScalarAddScanWitness." &&
        (ax.toString.splitOn "._native.native_decide.ax_").length == 2 do
          throwError "disallowed axiom {ax} in {name}"
    if core.contains owned then
      coreCount := coreCount + 1
    else witnessCount := witnessCount + 1
  unless coreCount > 0 do throwError "empty core partition"
  unless witnessCount > 0 do throwError "empty witness partition"
  logInfo m!"ARITHMETIC_CORE_STANDARD_ONLY {coreCount}; FIXED_WITNESS_CONSTANTS {witnessCount}"
