from pathlib import Path
import subprocess as sp,json,hashlib,datetime,re
view=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');root=Path('/tmp/stock-arithmetic-return-landing');root.mkdir(exist_ok=True)
head='d53bb5d9f1fc3385e814c81f3f9cbca54972f621';base='2fe5fa0febb4ec0460fad4785a5e1e81e7b440a9'
def run(*args):return sp.check_output(args,cwd=view,text=True,stderr=sp.STDOUT).strip()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
d=json.loads(Path('/tmp/stock-arithmetic-return-author-gates/progress.json').read_text());assert d['state']=='per_pr_gates_passed' and d['head']==head and d['base']==base
assert run('git','rev-parse','HEAD')==head
assert not run('git','diff','--name-only') and not run('git','diff','--cached','--name-only')
frozen=json.loads(Path('/tmp/stock-arithmetic-return-author-gates/inputs.json').read_text());current={str(p.relative_to(view)):sha(p) for folder in ['FV','FVTest','scripts/audit'] for p in (view/folder).rglob('*.lean')};assert frozen==current
for f in d['logs'].values():assert sha(f['path'])==f['sha256']
assert d['axiom_parity']['all_previous_axiom_sets_preserved']
run('git','fetch','origin','main');assert run('git','rev-parse','origin/main')==base,'main drift; reconcile first'
receipt=view/'docs/research/stock-arithmetic-return-author-gates.json';assert not receipt.exists();receipt.write_text(json.dumps(d,indent=2)+'\n')
p=view/'docs/plans/stock-driver-incremental-delivery.md';s=p.read_text();s+='\nSource/return author gates passed on `'+head+'`: all prior2428verified modules reused only after exact source/audit hash checks,8newmodules scheduled, completeFV/FVTest replay2439jobs,30audits,53standardcore/3fixedwitnessownedconstants. All1049previouspublicaxiomsets retained exactly,11newpublicroots audited. No runtime/consumer input or executable changed. Receipt: [source/return author gates](../research/stock-arithmetic-return-author-gates.json). Machine entry prelude, direct optimized-Stock consumers and full function production activation remain next.\n';p.write_text(s)
run('git','add','docs/research/stock-arithmetic-return-author-gates.json','docs/plans/stock-driver-incremental-delivery.md');run('git','diff','--cached','--check');run('git','commit','-m','Record exact arithmetic body author gate evidence')
final=run('git','rev-parse','HEAD');tree=run('git','rev-parse','HEAD^{tree}');run('git','push','origin','agent/stock-arithmetic-function-simulation')
body=root/'pr-body.md';body.write_text("""Connect successful original reference execution to ABI-correct returns in the actual Stock VCode for arbitrary single-block add/sub bodies. The source-step sequence, terminal source definedness, caller/frame transport, return step and exact body/return code placement are derived internally. The function-entry wrapper derives initial source facts from Clif.enterFunc; old theorem variants and input conditions remain available.

Complete witnesses cover real retained source records, original reference entry/return, nonempty arithmetic, dirty machine inputs and the actual VCode return. This is complete body/return simulation. The emitted machine argument prelude, direct optimized-Stock checker/consumer contracts and whole-function production activation remain next; broader families/effects and full original#140 simulation/completeness remain open. Production selection is unchanged.

Validation on `"""+head+"""` plus receipt-only `"""+final+"""`:

- Exact hashes preserve every previously verified source/audit file from merged#339. Scheduler checks8newmodules within16GiB, then fullFV/FVTest replay passes2439jobs.
- All30audit files PASS;1049previous public root axiom sets retained exactly,11newpublic roots audited.
- All53core-owned constants standard-only;3fixed witnesses use only existing marked native trace facts. Complete targeted675job build passes; one bundled MCP entered-return root standard3/no warnings and ownedLSPprocesses stopped.
- Import closure reaches no changed runtime consumer/executable; no runtime/compiler/checker/linker input changed, so additional runtime gates are outside this proof-only packet.

Exact terminal receipt: docs/research/stock-arithmetic-return-author-gates.json.
""")
assert run('git','ls-remote','origin','refs/heads/main').split()[0]==base
out=run('gh','pr','create','--repo','eth-act/clifv','--base','main','--head','agent/stock-arithmetic-function-simulation','--title','Connect original arithmetic execution to actual Stock VCode returns','--body-file',str(body));urls=re.findall(r'https://github.com/eth-act/clifv/pull/\d+',out);assert len(urls)==1,out
url=urls[0];(root/'progress.json').write_text(json.dumps({'state':'merging','pr':url,'head':final})+'\n')
assert run('git','ls-remote','origin','refs/heads/main').split()[0]==base
run('gh','pr','merge',url,'--repo','eth-act/clifv','--squash','--match-head-commit',final)
pr=json.loads(run('gh','pr','view',url,'--repo','eth-act/clifv','--json','number,state,mergeCommit,url'));assert pr['state']=='MERGED'
commit=pr['mergeCommit']['oid'];(root/'progress.json').write_text(json.dumps({'state':'merged_verifying','pr':pr,'head':final})+'\n')
run('git','fetch','origin','main');assert run('git','rev-parse',commit+'^{tree}')==tree
comment=root/'integrator.md';comment.write_text('@kevaundray Author squash landed #'+str(pr['number'])+' as **'+commit+'**. Exact tree equals validated '+head+' plus receipt '+final+'. Please include the actual commit in the immediate continuous main gate.\n\nComplete original arithmetic execution/body/return simulation in actual Stock VCode: source steps, terminal definedness, caller/frame transport, original return and actual segment placement derived internally; source entry derives initial source facts. Complete retained/reference/nonempty/dirty-machine/VCode-return witnesses pass. Per-PR fullFV/FVTest2439jobs with hash-verified reuse of unchanged#339modules,30audits/1049exactpriorrootsets+11newroots,53standardcoreconstants/3markedfixedwitnessconstants. No runtime/consumer input changed. Machine ABI argument prelude and additive direct semantic consumers/full function activation remain next; every original#140 broader family/effect/simulation/completeness obligation remains active.\n')
for issue in ['261','140']:run('gh','issue','comment',issue,'--repo','eth-act/clifv','--body-file',str(comment))
status=json.loads(run('gh','issue','view','44','--repo','eth-act/clifv','--json','body'))['body'];status+='\n\n'+comment.read_text()+'\nCurrent published branch agent/stock-arithmetic-function-simulation/'+final+'; stateactive. Next terminal evidence backup/cleanup, original source-step/whole-function integration. UTC '+datetime.datetime.now(datetime.timezone.utc).isoformat()+'\n';(root/'status.md').write_text(status);run('gh','issue','edit','44','--repo','eth-act/clifv','--body-file',str(root/'status.md'))
done={'state':'landed_and_integrator_notified','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pr':pr,'source':head,'receipt':final,'merge_commit':commit,'merge_tree_matches_validated_source_plus_receipt':True};(root/'progress.json').write_text(json.dumps(done,indent=2)+'\n');print(json.dumps(done))
