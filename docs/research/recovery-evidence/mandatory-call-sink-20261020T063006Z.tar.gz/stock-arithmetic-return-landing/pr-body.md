Connect successful original reference execution to ABI-correct returns in the actual Stock VCode for arbitrary single-block add/sub bodies. The source-step sequence, terminal source definedness, caller/frame transport, return step and exact body/return code placement are derived internally. The function-entry wrapper derives initial source facts from Clif.enterFunc; old theorem variants and input conditions remain available.

Complete witnesses cover real retained source records, original reference entry/return, nonempty arithmetic, dirty machine inputs and the actual VCode return. This is complete body/return simulation. The emitted machine argument prelude, direct optimized-Stock checker/consumer contracts and whole-function production activation remain next; broader families/effects and full original#140 simulation/completeness remain open. Production selection is unchanged.

Validation on `d53bb5d9f1fc3385e814c81f3f9cbca54972f621` plus receipt-only `c06d17de1c68d944a9c9f823e3685a0ebd861a94`:

- Exact hashes preserve every previously verified source/audit file from merged#339. Scheduler checks8newmodules within16GiB, then fullFV/FVTest replay passes2439jobs.
- All30audit files PASS;1049previous public root axiom sets retained exactly,11newpublic roots audited.
- All53core-owned constants standard-only;3fixed witnesses use only existing marked native trace facts. Complete targeted675job build passes; one bundled MCP entered-return root standard3/no warnings and ownedLSPprocesses stopped.
- Import closure reaches no changed runtime consumer/executable; no runtime/compiler/checker/linker input changed, so additional runtime gates are outside this proof-only packet.

Exact terminal receipt: docs/research/stock-arithmetic-return-author-gates.json.
