import StockTryNormalGraph
import StockTryNormalCfg
import StockTryNormalIndirectCopyWitness
import StockTryNormalEdgeValues
import StockTryNormalIndirectSourceValues
import StockTryIndirectValueAliasObservation
import StockTryIndirectAliasObservation
import FV.Backend.Proof.PerEdgeSpillEntryFixture
import FV.E2E.RegLevelDriverSem
namespace Backend.Stock.Proof.TryNormalIndirectControlWitnessDraft
open TryNormalIndirectSourceValuesDraft TryNormalValueColumnsDraft
open TryLiveNormalDraft
open TryNormalEntryValuesDraft TryNormalCopiesDraft TryNormalEdgeValuesDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open TryIndirectSourceRunDraft TryWholeSourceReservationDraft TryBranchAbiDraft
open TryResolvedRunsDraft TryLiveResolvedSourceDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
open TryNormalControlDraft TryNormalCfgDraft TryNormalGraphDraft
private def function := SpillEntryFixture.function true
private def signature := function.sig
private def model : ExtSem := ⟨fun _ _ w => some ([17],w),fun _ _ => 4096,0,fun _ w => Arm.read_pstate w⟩
private def environment : Clif.Env := {
  extern := fun _ => some (fun _ cm => .returned [⟨.i64,17⟩] cm),names := ["callee"],sigOf := fun _ => some signature }
private def symbols : String → Option Nat := fun n => if n = "callee" then some 4096 else none
private def memory : Clif.Mem := {Clif.Mem.empty with symbols}
private def relation : MemRelT := fun _ cm _ => cm.symbols = symbols
private def info : TryInfo := {continuation := 1,handlers := [.tag 7 2],clobberAll := false,rets := 1}
private def table : Clif.ExnTable := {
  sig := 0,normal := ⟨1,[.ret 0,.val 0]⟩,items := [.tag 7 ⟨2,[.exn 0,.exn 1,.val 0]⟩] }
private def fr : Clif.Frame := {
  func := function
  regs := (Clif.Regs.empty.set 0 ⟨.i64,9⟩).set 1 ⟨.i64,4096⟩
  slots := []
  body := []
  term := function.blocks[0]!.term }
private def resultRegs : Clif.Regs := fr.regs.set function.freshValue ⟨.i64,17⟩
private def normalCall : Clif.BlockCall := ⟨1,[function.freshValue,0]⟩
private def pendingFrame : Clif.Frame := {fr with regs := resultRegs,body := [],term := .jump normalCall}
private def enteredFrame : Clif.Frame := {pendingFrame with regs := ((resultRegs.set 2 ⟨.i64,17⟩).set 3 ⟨.i64,9⟩),body := [],term := .ret [2]}
private def rho (result : Result) : Nat → CV := fun n => if n = keyMap result 193 then ofX 4096 else 9
theorem stock_complete_indirect_normal_control_values_witness :
    ∃ out : SpillEntryFixture.Output true,
      LowerScope function ∧ Dominated function ∧ ArityOk function ∧ AbiSigsOk function ∧
      Stock.lower function = .ok out.result ∧ prepareAt out.result.code out.result.edgeArgs = .ok out.prepared ∧
      out.rf = spillAllocAt out.prepared.code out.prepared.edges ∧
      checkAllocAt out.prepared.code out.prepared.edges out.rf = .ok () ∧ lowerRFunc out.prepared.code out.rf = .ok out.af ∧
      XCallsIndOk environment [signature] relation model ∧
      IndCallsRefineP (fun _ _ _ _ => True) environment (indSigs function) relation
        (csem (fun _ => False) ⟨0,0⟩ model) ∧
      keyMap out.result 193 ≠ 193 ∧
      Clif.enterBlock pendingFrame normalCall = .ok enteredFrame ∧
      blockIdx? function table.normal.block = some 1 ∧ (1 : Nat) ≠ 0 ∧
      (∃ raw : IndirectTryRun function out.result 0 0 function.blocks[0]! signature
        (csem (fun _ => False) ⟨0,0⟩ model) relation fr (fun n => rho out.result (keyMap out.result n)) Arm.ArmState.default [⟨.i64,17⟩] memory,
        ∃ (k : Nat) (i : MInst) (ops : Array Operand) (atCall : Nat → CV) (world : Arm.ArmState)
          (outs : List CV) (finalWorld : Arm.ArmState) (args : Array Reg),
          raw.info.handlers.length = table.handlers.length ∧
          raw.info.continuation = 1 ∧
          succOf out.result.code 0 raw.info.handlers.length = some 1 ∧
          seqRun (csem (fun _ => False) ⟨0,0⟩ model)
            (raw.source.branch.step.emitted.toList.map (·.mapRegs (resolver out.result))) (rho out.result) Arm.ArmState.default =
            some (.stop k i ops atCall world outs finalWorld (.goto raw.info.handlers.length)) ∧
          NormalColumnValues out.result 0 table.handlers.length [⟨.i64,17⟩,⟨.i64,9⟩] (vdefUpd ops outs atCall) ∧
          (out.result.edgeArgs[0]?.bind fun row => row[table.handlers.length]?) = some args ∧
          edgeEnvAt out.result.code out.result.edgeArgs 0 1 raw.info.handlers.length (vdefUpd ops outs atCall) =
            some (parCopyEnv (vdefUpd ops outs atCall) (edgeParamNumbers out.result function.blocks[1]!) (columnNumbers args)) ∧
          ValuesHeld (fun x => x ∈ availOf function (availIn function out.result.ctx) 1 0) out.result.ctx enteredFrame
            (fun key => parCopyEnv (vdefUpd ops outs atCall) (edgeParamNumbers out.result function.blocks[1]!)
              (columnNumbers args) (aliasNum out.result.final.alias key))) ∧
      Clif.runWith environment {funcs := [function]} function.name [] memory 6 = .returned [⟨.i64,17⟩] memory := by
  obtain ⟨out,scope,dominated,arity,abi,lowered,prepare,fallback,accepted,physical,xind,contract,changed,entered,⟨raw,k,i,ops,atCall,world,outs,finalWorld,args,execute,column,stored,copies,agreement⟩,sourceRun⟩ := Backend.Stock.Proof.TryNormalIndirectCopyWitnessDraft.stock_complete_indirect_normal_copy_values_witness
  have control := stock_indirect_try_normal_control raw (et := table) (by rfl)
  have order : blockOrder function = .ok {nodes := #[.original 0,.original 1,.original 2],successors := #[#[2,1],#[],#[]]} := by cbv
  have sameOrder := Except.ok.inj ((stock_lower_order lowered).symm.trans order)
  have indexed := stock_lower_try_normal_original_target lowered scope
    (show out.result.order.nodes[0]? = some (.original 0) from by rw [sameOrder]; rfl)
    (show function.blocks[0]? = some function.blocks[0]! from rfl)
    (show IsTryWith function.blocks[0]!.term table from Or.inr ⟨1,[],rfl⟩)
    (show out.result.order.successors[0]![table.handlers.length]? = some 1 from by rw [sameOrder]; rfl)
    (show out.result.order.nodes[1]? = some (.original 1) from by rw [sameOrder]; rfl)
  have continuation : raw.info.continuation = 1 := by rw [control.2,sameOrder]; rfl
  have successor : succOf out.result.code 0 raw.info.handlers.length = some 1 := by
    rw [stock_lower_actual_successor lowered scope,control.1,sameOrder]
    rfl
  have actualCopies : edgeEnvAt out.result.code out.result.edgeArgs 0 1 raw.info.handlers.length (vdefUpd ops outs atCall) =
      some (parCopyEnv (vdefUpd ops outs atCall) (edgeParamNumbers out.result function.blocks[1]!) (columnNumbers args)) := by
    rw [control.1]
    exact copies
  exact ⟨out,scope,dominated,arity,abi,lowered,prepare,fallback,accepted,physical,xind,contract,changed,entered,indexed.1,indexed.2,⟨raw,k,i,ops,atCall,world,outs,finalWorld,args,control.1,continuation,successor,execute,column,stored,actualCopies,agreement⟩,sourceRun⟩
end Backend.Stock.Proof.TryNormalIndirectControlWitnessDraft
