import StockTryNormalGraph
import StockTryCriticalNormalWitness
import StockTryCriticalNormalVectors
import FV.Backend.Proof.StockCriticalSplitWitness
namespace Backend.Stock.Proof.TryNormalCriticalGraphWitnessDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open TryCriticalNormalVectorsDraft TryNormalNumbersDraft TrySourceContextDraft TryBranchSelectionDraft TryBranchAbiDraft
open TryRetsTotalDraft TryResultMapDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
open CriticalSplitFixture CriticalSplitWitness
open TryNormalGraphDraft TryNormalCfgDraft
private def entry (indirect : Bool) := (function indirect).blocks[0]!
private def table : Clif.ExnTable := {sig := 0,normal := ⟨1,[.ret 0]⟩,items := []}
private def environment (indirect : Bool) : Clif.Env := {
  extern := fun _ => some (fun _ cm => .returned [⟨.i64,17⟩] cm),names := ["callee"],sigOf := fun _ => some (function indirect).sig }
private def memory : Clif.Mem := {Clif.Mem.empty with symbols := fun name => if name = "callee" then some 4096 else none}
theorem stock_complete_try_normal_critical_graph_witness (indirect : Bool) :
    ∃ (result : Result) (p : EdgeVCode) (rf : RFunc) (af : AFunc)
      (source : TryBranchSource (function indirect) result 0 0 (entry indirect))
      (_selected : TryBranchSelection source) (base : Nat) (before : State) (value : V)
      (after edgeInput edgeNext : State) (args : Array Reg),
      Stock.lower (function indirect) = .ok result ∧ LowerScope (function indirect) ∧
      Dominated (function indirect) ∧ ArityOk (function indirect) ∧
      prepareAt result.code result.edgeArgs = .ok p ∧ rf = spillAllocAt p.code p.edges ∧
      checkAllocAt p.code p.edges rf = .ok () ∧ lowerRFunc p.code rf = .ok af ∧
      stockSourceTable (function indirect) = .ok #[#[1],#[],#[1]] ∧
      sourceIndegree #[#[1],#[],#[1]] (function indirect).blocks.length = .ok #[0,2,0] ∧
      CriticalSplitComplete (function indirect) #[#[1],#[],#[1]] #[0,2,0] result.order.nodes ∧
      Node.original 2 ∉ result.order.nodes.toList ∧ result.order.nodes[1]? = some (.edge 0 0 1) ∧
      blockIdx? (function indirect) table.normal.block = some 1 ∧ (1 : Nat) ≠ 0 ∧
      succOf result.code 0 table.handlers.length = some 1 ∧ succOf result.code 1 0 = some 2 ∧
      result.initial.tryRegs[source.ti]! = (reservedReturns base (function indirect).sig.returns.length,reservedPayloads base (function indirect).sig.returns.length) ∧
      Stock.externCtor source.ctx T.gen_try_call_rets [.op (.sig (function indirect).sig)] before = .ok (value,after) ∧
      value = .op (.callRets (callDefs (resultDefs base (function indirect).sig.returns.length))) ∧
      branchArgs result.ctx edgeInput 0 table.handlers.length = .ok (args,edgeNext) ∧
      args.map (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1)) =
        ((normalArgumentNumbers result base table).map (fun n => Reg.vreg n .int)).toArray ∧
      (result.edgeArgs[1]?.bind fun row => row[0]?) = some
        ((normalArgumentNumbers result base table).map (fun n => Reg.vreg n .int)).toArray ∧
      (normalArgumentNumbers result base table).length = 1 ∧
      Clif.runWith (environment indirect) {funcs := [function indirect]} (function indirect).name [] memory 6 = .returned [⟨.i64,17⟩] memory := by
  obtain ⟨result,p,rf,af,source,selected,base,before,value,after,edgeInput,edgeNext,args,lowered,scope,dominated,arity,prepared,fallback,accepted,physical,srcRun,degreeRun,complete,unreachable,edge,layout,helper,defs,call,numbers,stored,length,sourceRun⟩ := TryCriticalNormalWitnessDraft.stock_complete_try_critical_normal_vectors_witness indirect
  have block : (function indirect).blocks[0]? = some (entry indirect) := by cases indirect <;> rfl
  have kind : IsTryWith (entry indirect).term table := by
    cases indirect
    · exact .inl ⟨0,[],rfl⟩
    · exact .inr ⟨0,[],rfl⟩
  have indexed := stock_lower_try_normal_critical_target lowered scope block kind edge
  have order : blockOrder (function indirect) = .ok {
      nodes := #[.original 0,.edge 0 0 1,.original 1],successors := #[#[1],#[2],#[]]} := by cases indirect <;> cbv
  have sameOrder := Except.ok.inj ((stock_lower_order lowered).symm.trans order)
  have first : succOf result.code 0 table.handlers.length = some 1 := by
    rw [stock_lower_actual_successor lowered scope,sameOrder]; rfl
  have second : succOf result.code 1 0 = some 2 := by
    rw [stock_lower_actual_successor lowered scope,sameOrder]; rfl
  exact ⟨result,p,rf,af,source,selected,base,before,value,after,edgeInput,edgeNext,args,lowered,scope,dominated,arity,prepared,fallback,accepted,physical,srcRun,degreeRun,complete,unreachable,edge,indexed.1,indexed.2,first,second,layout,helper,defs,call,numbers,stored,length,sourceRun⟩
end Backend.Stock.Proof.TryNormalCriticalGraphWitnessDraft
