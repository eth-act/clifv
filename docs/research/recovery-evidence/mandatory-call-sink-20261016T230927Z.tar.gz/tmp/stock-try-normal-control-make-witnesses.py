from pathlib import Path
import re
for src,dst,form in [('StockTryNormalCopyWitness','StockTryNormalControlWitness','near'),('StockTryNormalGotCopyWitness','StockTryNormalGotControlWitness','got'),('StockTryNormalIndirectCopyWitness','StockTryNormalIndirectControlWitness','indirect')]:
 old=Path('/tmp',src+'.lean').read_text();ns=re.search(r'^namespace (\S+)',old,re.M).group(1);newns=ns.replace('CopyWitness','ControlWitness')
 head=old[:old.index('private def')];head='import StockTryNormalGraph\nimport StockTryNormalCfg\nimport '+src+'\n'+head;head=head.replace('namespace '+ns,'namespace '+newns);head+='open TryNormalControlDraft TryNormalCfgDraft TryNormalGraphDraft\n'
 defs=''.join(re.findall(r'^private def .*?(?=^private (?:def|theorem)|^/--|^theorem)',old,re.M|re.S))
 start=re.search(r'^theorem ',old,re.M).start();end=old.index(' := by',start);statement=old[start:end];oldroot=re.search(r'^theorem (\w+)',statement).group(1);newroot=oldroot.replace('copy_values','control_values');statement=statement.replace(oldroot,newroot,1)
 statement=statement.replace('          seqRun ','''          raw.info.handlers.length = table.handlers.length ∧
          raw.info.continuation = 1 ∧
          succOf out.result.code 0 raw.info.handlers.length = some 1 ∧
          seqRun ''',1)
 statement=statement.replace('edgeEnvAt out.result.code out.result.edgeArgs 0 1 table.handlers.length','edgeEnvAt out.result.code out.result.edgeArgs 0 1 raw.info.handlers.length')
 f='function' if form=='indirect' else 'f'
 statement=statement.replace('      Clif.enterBlock pendingFrame normalCall = .ok enteredFrame ∧',f'      Clif.enterBlock pendingFrame normalCall = .ok enteredFrame ∧\n      blockIdx? {f} table.normal.block = some 1 ∧ (1 : Nat) ≠ 0 ∧')

 fields='out,scope,dominated,arity,'
 if form=='indirect':fields+='abi,'
 fields+='lowered,prepare,fallback,accepted,physical,'
 fields+='xind,contract,changed,' if form=='indirect' else 'xcalls,contract,stable,memory,outgoing,'
 fields+='entered,⟨raw,k,i,ops,atCall,world,outs,finalWorld,args,execute,column,stored,copies,agreement⟩,sourceRun'
 body=f''' := by
  obtain ⟨{fields}⟩ := {ns}.{oldroot}
  have control := stock_{form}_try_normal_control raw (et := table) (by rfl)
  have order : blockOrder {'function' if form=='indirect' else 'f'} = .ok {{nodes := #[.original 0,.original 1,.original 2],successors := #[#[2,1],#[],#[]]}} := by cbv
  have sameOrder := Except.ok.inj ((stock_lower_order lowered).symm.trans order)
  have indexed := stock_lower_try_normal_original_target lowered scope
    (show out.result.order.nodes[0]? = some (.original 0) from by rw [sameOrder]; rfl)
    (show {f}.blocks[0]? = some {f}.blocks[0]! from rfl)
    (show IsTryWith {f}.blocks[0]!.term table from {'Or.inr ⟨1,[],rfl⟩' if form=='indirect' else 'Or.inl ⟨0,List.range 9,rfl⟩' if form=='got' else 'Or.inl ⟨0,[],rfl⟩'})
    (show out.result.order.successors[0]![table.handlers.length]? = some 1 from by rw [sameOrder]; rfl)
    (show out.result.order.nodes[1]? = some (.original 1) from by rw [sameOrder]; rfl)
  have continuation : raw.info.continuation = 1 := by rw [control.2,sameOrder]; rfl
  have successor : succOf out.result.code 0 raw.info.handlers.length = some 1 := by
    rw [stock_lower_actual_successor lowered scope,control.1,sameOrder]
    rfl
  have actualCopies : edgeEnvAt out.result.code out.result.edgeArgs 0 1 raw.info.handlers.length (vdefUpd ops outs atCall) =
      some (parCopyEnv (vdefUpd ops outs atCall) (edgeParamNumbers out.result {'function' if form=='indirect' else 'f'}.blocks[1]!) (columnNumbers args)) := by
    rw [control.1]
    exact copies
  exact ⟨'''
 exactfields=fields[:fields.index('entered,')]+ 'entered,indexed.1,indexed.2,⟨raw,k,i,ops,atCall,world,outs,finalWorld,args,control.1,continuation,successor,execute,column,stored,actualCopies,agreement⟩,sourceRun'
 body+=exactfields+'⟩\nend '+newns+'\n'
 Path('/tmp',dst+'.lean').write_text(head+defs+statement+body)
