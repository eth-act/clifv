import StockTryNormalCfg
import FV.Backend.Proof.StockGraphEdges
namespace Backend.Stock.Proof.TryNormalGraphDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Driver.Fix
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private theorem normal_destination {b : Clif.Block} {et : Clif.ExnTable} (kind : IsTryWith b.term et) :
    (destinations b.term)[et.handlers.length]? = some (et.normal.block,et.normal.args) := by
  rcases kind with ⟨fn,args,term⟩ | ⟨callee,args,term⟩ <;> rw [term] <;>
    simp [destinations,Clif.ExnTable.dests,List.getElem?_append]
private theorem normal_origin {f : Clif.Function} {result : Result} (lowered : Stock.lower f = .ok result)
    {label bi targetLabel : Nat} {b : Clif.Block} {et : Clif.ExnTable}
    (node : result.order.nodes[label]? = some (.original bi)) (block : f.blocks[bi]? = some b)
    (kind : IsTryWith b.term et)
    (successor : result.order.successors[label]![et.handlers.length]? = some targetLabel) :
    ∃ target,blockIdx? f et.normal.block = some target ∧
      (result.order.nodes[targetLabel]? = some (.original target) ∨
       result.order.nodes[targetLabel]? = some (.edge bi et.handlers.length target)) := by
  cases row : result.order.successors[label]? with
  | none => simp only [getElem!_def,row] at successor; cases successor
  | some ss =>
    have selected : ss[et.handlers.length]? = some targetLabel := by
      simpa only [getElem!_def,row,Option.getD_some] using successor
    obtain ⟨original,id,args,target,source,dest,found,targetNode⟩ :=
      stock_lower_indexed_successor_origin lowered node row selected
    cases Option.some.inj (source.symm.trans block)
    rw [normal_destination kind] at dest
    cases Option.some.inj dest
    exact ⟨target,found,targetNode⟩
/-- Actual normal control that targets an original node identifies the SAME
source destination and a nonentry block under original LowerScope. No target
mapping or no-entry certificate is supplied by the caller. -/
theorem stock_lower_try_normal_original_target {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f)
    {label bi targetLabel targetBi : Nat} {b : Clif.Block} {et : Clif.ExnTable}
    (node : result.order.nodes[label]? = some (.original bi)) (block : f.blocks[bi]? = some b)
    (kind : IsTryWith b.term et)
    (successor : result.order.successors[label]![et.handlers.length]? = some targetLabel)
    (target : result.order.nodes[targetLabel]? = some (.original targetBi)) :
    blockIdx? f et.normal.block = some targetBi ∧ targetBi ≠ 0 := by
  obtain ⟨index,found,actual⟩ := normal_origin lowered node block kind successor
  have same : index = targetBi := by
    rcases actual with original | critical
    · exact Node.original.inj (Option.some.inj (original.symm.trans target))
    · rw [target] at critical; cases critical
  subst index
  refine ⟨found,?_⟩
  have absent := scope.noEntryPred b (List.mem_of_getElem? block) et.normal.block (by
    rcases kind with ⟨fn,args,term⟩ | ⟨callee,args,term⟩ <;> rw [term] <;> simp [succIds,Clif.ExnTable.dests])
  intro zero
  subst targetBi
  exact absent found
/-- Every actual synthetic NORMAL node identifies the same original source
normal destination and nonentry property, independently of machine execution. -/
theorem stock_lower_try_normal_critical_target {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f)
    {label bi targetBi : Nat} {b : Clif.Block} {et : Clif.ExnTable}
    (block : f.blocks[bi]? = some b) (kind : IsTryWith b.term et)
    (target : result.order.nodes[label]? = some (.edge bi et.handlers.length targetBi)) :
    blockIdx? f et.normal.block = some targetBi ∧ targetBi ≠ 0 := by
  obtain ⟨original,id,args,source,dest,found⟩ := stock_lower_critical_source lowered target
  cases Option.some.inj (source.symm.trans block)
  rw [normal_destination kind] at dest
  cases Option.some.inj dest
  refine ⟨found,?_⟩
  have absent := scope.noEntryPred b (List.mem_of_getElem? block) et.normal.block (by
    rcases kind with ⟨fn,args,term⟩ | ⟨callee,args,term⟩ <;> rw [term] <;> simp [succIds,Clif.ExnTable.dests])
  intro zero
  subst targetBi
  exact absent found
end Backend.Stock.Proof.TryNormalGraphDraft
