from pathlib import Path
import re
s=Path('/tmp/StockTryCriticalNormalWitness.lean').read_text();ns='Backend.Stock.Proof.TryNormalCriticalGraphWitnessDraft'
a=re.search(r'^theorem ',s,re.M).start();b=s.index(' := by',a)
header=s[:s.index('private def')].replace('namespace Backend.Stock.Proof.TryCriticalNormalWitnessDraft','namespace '+ns)
header='import StockTryNormalGraph\nimport StockTryCriticalNormalWitness\n'+header+'open TryNormalGraphDraft TryNormalCfgDraft\n'
defs=''.join(re.findall(r'^private def .*?(?=^private (?:def|theorem)|^/--|^theorem)',s,re.M|re.S))
statement=s[a:b].replace('stock_complete_try_critical_normal_vectors_witness','stock_complete_try_normal_critical_graph_witness',1)
needle='      result.initial.tryRegs[source.ti]!'
statement=statement.replace(needle,'''      blockIdx? (function indirect) table.normal.block = some 1 ∧ (1 : Nat) ≠ 0 ∧
      succOf result.code 0 table.handlers.length = some 1 ∧ succOf result.code 1 0 = some 2 ∧
'''+needle,1)
fields='result,p,rf,af,source,selected,base,before,value,after,edgeInput,edgeNext,args,lowered,scope,dominated,arity,prepared,fallback,accepted,physical,srcRun,degreeRun,complete,unreachable,edge,layout,helper,defs,call,numbers,stored,length,sourceRun'
body=f''' := by
  obtain ⟨{fields}⟩ := TryCriticalNormalWitnessDraft.stock_complete_try_critical_normal_vectors_witness indirect
  have block : (function indirect).blocks[0]? = some (entry indirect) := by cases indirect <;> rfl
  have kind : IsTryWith (entry indirect).term table := by
    cases indirect
    · exact .inl ⟨0,[],rfl⟩
    · exact .inr ⟨0,[],rfl⟩
  have indexed := stock_lower_try_normal_critical_target lowered scope block kind edge
  have order : blockOrder (function indirect) = .ok {{
      nodes := #[.original 0,.edge 0 0 1,.original 1],successors := #[#[1],#[2],#[]]}} := by cases indirect <;> cbv
  have sameOrder := Except.ok.inj ((stock_lower_order lowered).symm.trans order)
  have first : succOf result.code 0 table.handlers.length = some 1 := by
    rw [stock_lower_actual_successor lowered scope,sameOrder]; rfl
  have second : succOf result.code 1 0 = some 2 := by
    rw [stock_lower_actual_successor lowered scope,sameOrder]; rfl
  exact ⟨'''+fields.replace('edge,layout','edge,indexed.1,indexed.2,first,second,layout')+'⟩\nend '+ns+'\n'
Path('/tmp/StockTryNormalCriticalGraphWitness.lean').write_text(header+defs+statement+body)
