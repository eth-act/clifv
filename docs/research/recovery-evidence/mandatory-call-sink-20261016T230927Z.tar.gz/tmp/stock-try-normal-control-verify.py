from pathlib import Path
import json,hashlib,re,tarfile
root=Path('/home/lee/clifv/.worktrees/driver-proof-resume');docs=root/'docs/research';prefix='stock-try-normal-control'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
r=json.loads((docs/(prefix+'-scratch.json')).read_text());old=json.loads((docs/'stock-try-normal-copy-scratch.json').read_text())
for n,a in old['normal_audit']['sets'].items():assert sorted(a)==sorted(r['normal_audit']['sets'][n]),n
assert len(r['normal_audit']['sets'])==698
for m,x in r['modules'].items():
 c=json.loads(Path(x['check']).read_text());assert c['actual_exit']==0
 for k in ['source','object','log','check']:assert sha(x[k])==x[k+'_sha256'],(m,k)
 for k in ['source','object','log']:assert c[k+'_sha256']==x[k+'_sha256']
for audit in ['combined-axioms','all-constants']:
 p=Path('/tmp')/(prefix+'-'+audit);c=json.loads(p.with_suffix('.check.json').read_text());assert c['actual_exit']==0
 for k,ext in [('source','.lean'),('object','.olean'),('log','.log')]:assert sha(p.with_suffix(ext))==c[k+'_sha256']
allowed={'propext','Classical.choice','Quot.sound'}
constants=[json.loads(line.split('DELIVERY_CONSTANT ',1)[1]) for line in Path(r['all_constant_audit']['path']).read_text().splitlines() if line.startswith('DELIVERY_CONSTANT ')]
assert len(constants)==269
for name,axioms in constants:assert set(axioms)<=allowed,name
for name in r['public_roots']+r['models']:assert set(r['normal_audit']['sets'][name])<=allowed,name
freeze=json.loads(Path('/tmp/stock-coherent-build-inputs.json').read_text())
for group in ['source_sha256','validation_script_sha256']:
 for p,h in freeze[group].items():assert sha(root/p)==h,p
prior={}
for name in ['source-execution-x','try-source','try-context','try-rule','try-rets','try-reservation','try-outgoing','try-values','try-emitted','try-machine','try-got','try-indirect','try-rename','try-resolved','try-gap','try-got-rename','try-normal-frame','try-metadata','source-index','try-normal-vector','try-critical-normal','source-erase','source-origin','try-live-frame','try-normal-values','try-normal-copy']:
 d=json.loads((docs/f'stock-{name}-scratch.json').read_text())
 for m,x in d['modules'].items():
  for k in ['source','object','log']:assert sha(x[k])==x[k+'_sha256'],(m,k)
  prior[m]=x
assert len(prior)==168
print('PASS:7modules/10public roots,698cumulative exact sets,269Std-only constants,168prior module hashes,canonical source/script freeze')
