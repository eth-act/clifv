import StockTryDirectSourceRun
import StockTryGotSourceRun
import StockTryIndirectSourceRun
import FV.Backend.Proof.StockCfgTotal
import FV.Backend.Proof.PrepareSound
namespace Backend.Stock.Proof.TryNormalControlDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Driver.Fix
open TrySourceContextDraft TryBranchSelectionDraft TryBranchAbiDraft
open TryDirectSourceRunDraft TryGotSourceRunDraft TryIndirectSourceRunDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private theorem decoded_handler_length {f : Clif.Function} {et : Clif.ExnTable}
    {sig : Clif.Signature} {items : List (Option Nat)} (table : exnTableOpnd f et = .ok (sig,items)) :
    items.length = et.handlers.length := by
  unfold exnTableOpnd at table
  dsimp only at table
  repeat' first
    | (solve | cases table)
    | simp only [bind,Except.bind,pure,Except.pure] at table
    | split at table
  cases table
  rename_i _ _ _ mappedItems mapped
  have count := (Prep.lmapM_ok mapped).1
  have good : ∀ item ∈ et.items, (match item with | .context _ => false | _ => true) = true := by
    intro item member
    obtain ⟨i,bound,equal⟩ := List.getElem_of_mem member
    have found : et.items[i]? = some item := by rw [List.getElem?_eq_getElem bound,equal]
    obtain ⟨out,success,_⟩ := (Prep.lmapM_ok mapped).2 i item found
    cases item <;> simp_all
  rw [handlers_length good]
  exact count
private theorem actual_handler_length {sig : Clif.Signature} {items : List (Option Nat)} {labels : List Label}
    {info : TryInfo} (run : tryInfoOf sig items labels = some info) :
    info.handlers.length = items.length := by
  unfold tryInfoOf at run
  split at run
  · cases run
  · rename_i length
    simp only [bne_iff_ne,ne_eq,Decidable.not_not] at length
    cases run
    simp only [List.length_map,List.length_zip]
    omega
private theorem selected_normal_index {f : Clif.Function} {result : Result} {label bi : Nat} {b : Clif.Block}
    {source : TryBranchSource f result label bi b} (selected : TryBranchSelection source)
    {et : Clif.ExnTable} (kind : sourceTable b.term = some et)
    {call : CallInfo} {info : TryInfo}
    (last : source.branch.step.emitted.back? = some (.tryCall call info)) :
    info.handlers.length = et.handlers.length ∧
      info.continuation = result.order.successors[label]!.toList.getLastD 0 := by
  have isTry : b.term.isTry = true := by
    cases term : b.term <;> simp only [sourceTable,term] at kind
    all_goals try contradiction
    all_goals rfl
  obtain ⟨actual,sig,items,original,callee,table,decoded,metadata,count,_,back⟩ := stock_selected_try_explicit_abi selected isTry
  cases Option.some.inj (table.symm.trans kind)
  have same := Option.some.inj (back.symm.trans last)
  have handlers := congrArg (fun inst => match inst with | .tryCall _ i => i.handlers.length | _ => 0) same
  have continuation := congrArg (fun inst => match inst with | .tryCall _ i => i.continuation | _ => 0) same
  change original.handlers.length = info.handlers.length at handlers
  change original.continuation = info.continuation at continuation
  refine ⟨handlers.symm.trans ((actual_handler_length metadata).trans (decoded_handler_length decoded)),?_⟩
  exact continuation.symm.trans (tryInfoOf_spec metadata).1
/-- The SAME actual near-call receipt has the source table's exact normal
control index and the actual computed normal continuation label. -/
theorem stock_near_try_normal_control {f : Clif.Function} {result : Result} {label bi : Nat} {b : Clif.Block}
    {ext : Clif.ExtFunc} {isem : Sem} {MR : MemRelT} {fr : Clif.Frame} {rho : Nat → CV}
    {w : Arm.ArmState} {rvals : List Clif.Val} {cm : Clif.Mem}
    (raw : DirectTryRun f result label bi b ext isem MR fr rho w rvals cm)
    {et : Clif.ExnTable} (kind : sourceTable b.term = some et) :
    raw.info.handlers.length = et.handlers.length ∧
      raw.info.continuation = result.order.successors[label]!.toList.getLastD 0 := by
  have last : raw.source.branch.step.emitted.back? = some (.tryCall
      ⟨.sym ext.name,retPairs (regPairsOf ((raw.locs.zip raw.ns).zip raw.bytes)),
        callDefs (TryResultMapDraft.resultDefs raw.base ext.sig.returns.length)⟩
      {raw.info with rets := ext.sig.returns.length}) := by
    rw [raw.code]
    simp
  exact selected_normal_index (info := {raw.info with rets := ext.sig.returns.length}) raw.selected kind last
/-- The SAME actual GOT-call receipt preserves its source normal control index,
including its real stack-store/symbol-load prefix. -/
theorem stock_got_try_normal_control {f : Clif.Function} {result : Result} {label bi : Nat} {b : Clif.Block}
    {ext : Clif.ExtFunc} {isem : Sem} {MR : MemRelT} {fr : Clif.Frame} {rho : Nat → CV}
    {w : Arm.ArmState} {rvals : List Clif.Val} {cm : Clif.Mem}
    (raw : GotTryRun f result label bi b ext isem MR fr rho w rvals cm)
    {et : Clif.ExnTable} (kind : sourceTable b.term = some et) :
    raw.info.handlers.length = et.handlers.length ∧
      raw.info.continuation = result.order.successors[label]!.toList.getLastD 0 := by
  have last : raw.source.branch.step.emitted.back? = some (.tryCall
      ⟨.reg (.vreg raw.target .int),retPairs (regPairsOf ((raw.locs.zip raw.ns).zip raw.bytes)),
        callDefs (TryResultMapDraft.resultDefs raw.base ext.sig.returns.length)⟩
      {raw.info with rets := ext.sig.returns.length}) := by
    rw [raw.code]
    simp
  exact selected_normal_index (info := {raw.info with rets := ext.sig.returns.length}) raw.selected kind last
/-- The SAME actual indirect-call receipt preserves the source normal control
index with its actual requested target and explicit result count. -/
theorem stock_indirect_try_normal_control {f : Clif.Function} {result : Result} {label bi : Nat} {b : Clif.Block}
    {sig : Clif.Signature} {isem : Sem} {MR : MemRelT} {fr : Clif.Frame} {rho : Nat → CV}
    {w : Arm.ArmState} {rvals : List Clif.Val} {cm : Clif.Mem}
    (raw : IndirectTryRun f result label bi b sig isem MR fr rho w rvals cm)
    {et : Clif.ExnTable} (kind : sourceTable b.term = some et) :
    raw.info.handlers.length = et.handlers.length ∧
      raw.info.continuation = result.order.successors[label]!.toList.getLastD 0 := by
  have last : raw.source.branch.step.emitted.back? = some (.tryCall
      ⟨.reg (.vreg raw.target .int),retPairs (regPairsOf ((raw.locs.zip raw.ns).zip raw.bytes)),
        callDefs (TryResultMapDraft.resultDefs raw.base sig.returns.length)⟩
      {raw.info with rets := sig.returns.length}) := by
    rw [raw.code]
    simp
  exact selected_normal_index (info := {raw.info with rets := sig.returns.length}) raw.selected kind last
end Backend.Stock.Proof.TryNormalControlDraft
