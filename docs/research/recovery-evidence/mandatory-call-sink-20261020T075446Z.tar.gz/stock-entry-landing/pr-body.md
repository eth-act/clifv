Stock body/return simulation needed an initial source-value relation, and the actual entry constructor exposed no source-row provenance. Derive original entry typing/maps/widths/final aliases/DFG consistency and a proof-selected virtual initialization, preserve values through ABI copies and stack loads, and derive exact ordered rows/code from actual assembleOriginalBlock. Unused parameters remain supported without an all-parameters-used condition or caller entry-value certificate. Old contracts/variants remain available.

Complete witnesses cover a real two-parameter/one-copy function and arbitrary-value actual csem ABI worlds; a real nine-parameter function loads its ninth parameter from fp+16 while omitting the first eight copies, with original ABI entry, arbitrary machine-memory execution and nonempty rows/exact actual constructor code.

This is the complete source/entry foundation. Typed ABI-row agreement and actual Stock-node entry at VCodeposition0, direct optimized-Stock semantic consumers and complete function activation remain next. Production class selection is unchanged; every original#140 simulation/completeness/effect/integration obligation remains active. checkAlloc_sound's universal initial virtual file is used internally; the weaker AllocChecked interface cannot silently replace it.

Validation on `37905e99c7519f1d91fdcf0d2e38c04e6123fca8` plus receipt-only `fe0547fbaa3417c158677fb781b14bb855ccae13`:

- Reconciled currentmain#3417a18184a additively, preserving published work. Exact previous source hashes/import closure justify reuse;17new/affected modules scheduled within16GiB/max3jobs, including new concurrency closure. CompleteFV/FVTest replay PASS2455jobs.
- All32audit files pass;1060prior public axiom sets preserved exactly,1129currentroots. All94newcore-owned constants standard-only;67fixedwitness constants restricted to marked ownnativefacts.
- Targeted complete witness builds and27public entry roots pass. One bundled MCP constructor/load check standard-only/no warnings; exact ownedLSP processes stopped.
- PR import closure reaches no runtime consumer/executable; no runtime/compiler/checker/linker source or input changed. Additional runtime gates are outside this proof-only per-PR scope.

Exact logs/hashes/scope/trust parity: docs/research/stock-entry-author-gates.json.
