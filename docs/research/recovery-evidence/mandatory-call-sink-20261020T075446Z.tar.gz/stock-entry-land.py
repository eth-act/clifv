from pathlib import Path
import subprocess as sp,json,hashlib,datetime,re
view=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');root=Path('/tmp/stock-entry-landing');root.mkdir(exist_ok=True)
head='37905e99c7519f1d91fdcf0d2e38c04e6123fca8';base='7a18184a86a4dab476d809d6318ad643182a8566'
def run(*args):return sp.check_output(args,cwd=view,text=True,stderr=sp.STDOUT).strip()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
d=json.loads(Path('/tmp/stock-entry-author-gates/progress.json').read_text());assert d['state']=='per_pr_gates_passed' and d['head']==head and d['base']==base
assert run('git','rev-parse','HEAD')==head and not run('git','diff','--name-only') and not run('git','diff','--cached','--name-only')
frozen=json.loads(Path('/tmp/stock-entry-author-gates/inputs.json').read_text());actual={str(p.relative_to(view)):sha(p) for folder in ['FV','FVTest','scripts/audit'] for p in (view/folder).rglob('*.lean')};assert frozen==actual
for f in d['logs'].values():assert sha(f['path'])==f['sha256']
assert d['axiom_parity']['all_previous_axiom_sets_preserved']
run('git','fetch','origin','main');assert run('git','rev-parse','origin/main')==base,'main changed: reconcile before landing'
receipt=view/'docs/research/stock-entry-author-gates.json';assert not receipt.exists();receipt.write_text(json.dumps(d,indent=2)+'\n')
p=view/'docs/plans/stock-driver-incremental-delivery.md';s=p.read_text();s+='\nEntry-foundation author gates passed on `'+head+'`: reconciled main#3417a18184a,17new/affected modules scheduled after strict prior-source/import closure checks, fullFV/FVTest2455jobs,all32auditfiles,94standardcore/67fixedwitnessownedconstants. All1060priorpublicaxiomsets retained exactly (1129currentroots including new concurrency proofs). No runtime/compiler/checker/linker input changed in this PR. [Terminal author receipt](../research/stock-entry-author-gates.json). Typed ABI agreement and actual Stock-node entry atVCode0/directsemanticconsumer integration remain next.\n';p.write_text(s)
run('git','add','docs/research/stock-entry-author-gates.json','docs/plans/stock-driver-incremental-delivery.md');run('git','diff','--cached','--check');run('git','commit','-m','Record reconciled Stock entry author gates')
final=run('git','rev-parse','HEAD');tree=run('git','rev-parse','HEAD^{tree}');run('git','push','origin','agent/stock-arithmetic-entry-simulation')
body=root/'pr-body.md';body.write_text('''Stock body/return simulation needed an initial source-value relation, and the actual entry constructor exposed no source-row provenance. Derive original entry typing/maps/widths/final aliases/DFG consistency and a proof-selected virtual initialization, preserve values through ABI copies and stack loads, and derive exact ordered rows/code from actual assembleOriginalBlock. Unused parameters remain supported without an all-parameters-used condition or caller entry-value certificate. Old contracts/variants remain available.

Complete witnesses cover a real two-parameter/one-copy function and arbitrary-value actual csem ABI worlds; a real nine-parameter function loads its ninth parameter from fp+16 while omitting the first eight copies, with original ABI entry, arbitrary machine-memory execution and nonempty rows/exact actual constructor code.

This is the complete source/entry foundation. Typed ABI-row agreement and actual Stock-node entry at VCodeposition0, direct optimized-Stock semantic consumers and complete function activation remain next. Production class selection is unchanged; every original#140 simulation/completeness/effect/integration obligation remains active. checkAlloc_sound's universal initial virtual file is used internally; the weaker AllocChecked interface cannot silently replace it.

Validation on `'''+head+'''` plus receipt-only `'''+final+'''`:

- Reconciled currentmain#3417a18184a additively, preserving published work. Exact previous source hashes/import closure justify reuse;17new/affected modules scheduled within16GiB/max3jobs, including new concurrency closure. CompleteFV/FVTest replay PASS2455jobs.
- All32audit files pass;1060prior public axiom sets preserved exactly,1129currentroots. All94newcore-owned constants standard-only;67fixedwitness constants restricted to marked ownnativefacts.
- Targeted complete witness builds and27public entry roots pass. One bundled MCP constructor/load check standard-only/no warnings; exact ownedLSP processes stopped.
- PR import closure reaches no runtime consumer/executable; no runtime/compiler/checker/linker source or input changed. Additional runtime gates are outside this proof-only per-PR scope.

Exact logs/hashes/scope/trust parity: docs/research/stock-entry-author-gates.json.
''')
assert run('git','ls-remote','origin','refs/heads/main').split()[0]==base
out=run('gh','pr','create','--repo','eth-act/clifv','--base','main','--head','agent/stock-arithmetic-entry-simulation','--title','Prove Stock entry values, stack loads and source-row construction','--body-file',str(body));urls=re.findall(r'https://github.com/eth-act/clifv/pull/\d+',out);assert len(urls)==1,out
url=urls[0];(root/'progress.json').write_text(json.dumps({'state':'merging','pr':url,'head':final})+'\n');assert run('git','ls-remote','origin','refs/heads/main').split()[0]==base
run('gh','pr','merge',url,'--repo','eth-act/clifv','--squash','--match-head-commit',final)
pr=json.loads(run('gh','pr','view',url,'--repo','eth-act/clifv','--json','number,state,mergeCommit,url'));assert pr['state']=='MERGED';commit=pr['mergeCommit']['oid'];(root/'progress.json').write_text(json.dumps({'state':'merged_verifying','pr':pr,'head':final})+'\n')
run('git','fetch','origin','main');assert run('git','rev-parse',commit+'^{tree}')==tree
comment=root/'integrator.md';comment.write_text('@kevaundray Author squash landed #'+str(pr['number'])+' as **'+commit+'**. Exact merge tree equals validated '+head+' plus receipt '+final+'. Please include the actual commit in the immediate continuous main gate.\n\nSource-selected entry values, ABI copies/stack loads and source-preserving actual entry constructor rows; complete two-parameter/one-copy and nine-parameter/stack-load ABI/arbitrary-world witnesses. Currentmain#341concurrency proofs reconciled without Stock overlap. Per-PR17affectedmodules+fullFV/FVTest2455jobs,all32audits,1060prioraxiomsets exact/1129currentroots,94standardcore-owned/67markedfixedwitnessconstants. No runtime/consumer input changed. Typed ABI agreement, actual node entry atVCode0 and direct semantic consumers/full function activation remain next; every original#140 obligation remains active. Seeded-entry/checkAlloc-vs-AllocChecked boundary remains#140/6284915808.\n')
for issue in ['261','140']:run('gh','issue','comment',issue,'--repo','eth-act/clifv','--body-file',str(comment))
status=json.loads(run('gh','issue','view','44','--repo','eth-act/clifv','--json','body'))['body'];status+='\n\n'+comment.read_text()+'\nCurrent published branch agent/stock-arithmetic-entry-simulation/'+final+'; stateactive. Next terminal evidence backup/cleanup, typed source/ABI agreement and actual driver-node entry/direct semantic integration. UTC '+datetime.datetime.now(datetime.timezone.utc).isoformat()+'\n';(root/'status.md').write_text(status);run('gh','issue','edit','44','--repo','eth-act/clifv','--body-file',str(root/'status.md'))
done={'state':'landed_and_integrator_notified','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pr':pr,'source':head,'receipt':final,'merge_commit':commit,'merge_tree_matches_validated_source_plus_receipt':True};(root/'progress.json').write_text(json.dumps(done,indent=2)+'\n');print(json.dumps(done))
