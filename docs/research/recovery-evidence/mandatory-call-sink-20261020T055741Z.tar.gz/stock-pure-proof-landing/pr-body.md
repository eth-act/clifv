Derive pure-body scan decisions from the original source and the actual complete Stock driver. Earlier body composition needed emitted/omitted coverage supplied separately; this packet proves the invariant through constructors, interpreter execution, original and critical-edge nodes, reverse traversal and every retained record. Actual sourceMetadata/buildCtx derive the pure slots' zero colors; unchanged LowerScope excludes remembered binding. Pure body records consequently derive emitted/omitted decisions without a per-record certificate.

Complete standard-only witnesses cover a nonempty pure source function, a real critical-edge CFG and an effectful sink that remains permitted. Old theorem variants, input conditions and runtime lowering/consumer definitions are retained. This is the complete prerequisite for broader body/function value simulation; shipped production coverage remains #336 until the next complete class is integrated. Direct optimized-Stock semantic consumers, effects/families and full original #140 simulation/completeness remain open.

Validation on `9cab610f1cc1bcff39aa70b049acee1c7d2710fb` plus receipt-only `18143396f2c0acaad67ba29b67392b01db08b69e`:

- Frozen FV/FVTest scheduler and affected-target build PASS (16 GiB/max3jobs/shared cache).
- All checked-in axiom audits and public/private/generated owned-constant scans PASS. All prior #336 theorem axiom sets retained exactly.
- Targeted complete witness builds; standard-only critical-edge/effectful sink/source-derived whole-driver witnesses; one bundled MCP whole-driver source check, standard3/no warnings.
- Dependency manifest: all changes are proofs/audits/docs; no runtime/compiler/checker/linker consumer or executable depends on the changed modules. Runtime inputs are byte-identical to current main#337, so additional runtime gates are outside this proof-only per-PR scope.

Exact terminal logs/hashes, scope and trust-set parity are checked into `docs/research/stock-pure-body-author-gates.json`. Last observed continuous main gate GREEN: #336/d18ba039. Reconciled #337/fcdaefe0 without overwriting saved/published work.
