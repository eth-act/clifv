from pathlib import Path
import os,subprocess as sp,json,datetime,hashlib,re,tomllib,traceback
view=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');root=Path('/tmp/stock-pure-proof-author-gates');root.mkdir(exist_ok=True)
head=sp.check_output(['git','rev-parse','HEAD'],cwd=view,text=True).strip();base=sp.check_output(['git','rev-parse','origin/main'],cwd=view,text=True).strip();logs={}
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
env=dict(os.environ,FV_MEMCAP='8G',FV_LAKE_CACHE='/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache',LEAN_NUM_THREADS='2',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2');env['PATH']='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:'+env['PATH']
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:8])
def inputs():
 return {str(p.relative_to(view)):sha(p) for folder in ['FV','FVTest','scripts/audit'] for p in (view/folder).rglob('*.lean')}
frozen=inputs();(root/'inputs.json').write_text(json.dumps({'head':head,'base':base,'sources':frozen},indent=2)+'\n')
def report(state,**kw):
 d=dict(state=state,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=os.getpid(),head=head,base=base,logs=logs,**kw);(root/'progress.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items() if k!='logs'}),flush=True)
def check_frozen():
 assert sp.check_output(['git','rev-parse','HEAD'],cwd=view,text=True).strip()==head
 assert inputs()==frozen,'tracked Lean/audit source changed during gates'
def run(name,args):
 check_frozen();log=root/(name+'.log');report('running',phase=name,log=str(log))
 command=args if args[:2]==['python3','/tmp/stock-execute-scheduler.py'] else ['scripts/memcap.sh',*args]
 with log.open('w') as f:r=sp.run(command,cwd=view,env=env,stdout=f,stderr=sp.STDOUT)
 assert r.returncode==0,(name,r.returncode,str(log));check_frozen();logs[name]={'path':str(log),'sha256':sha(log)};return log
try:
 changed=sp.check_output(['git','diff','--name-only',base,head],cwd=view,text=True).splitlines()
 assert all(p.startswith(('FV/Backend/Proof/','scripts/audit/','docs/')) for p in changed),changed
 changed_modules={p[:-5].replace('/','.') for p in changed if p.endswith('.lean') and p.startswith('FV/')}
 dependencies={};pat=re.compile(r'^(?:public\s+|private\s+|meta\s+)*import\s+(\S+)')
 for folder in ['FV','FVTest']:
  for p in (view/folder).rglob('*.lean'):
   dependencies[str(p.relative_to(view))[:-5].replace('/','.')]=set(m.group(1) for line in p.read_text().splitlines() if (m:=pat.match(line)))
 affected=set(changed_modules)
 while True:
  more={m for m,deps in dependencies.items() if deps & affected}-affected
  if not more:break
  affected|=more
 exes=[e['name'] for e in tomllib.loads((view/'lakefile.toml').read_text()).get('lean_exe',[]) if e.get('root',e['name']) in affected]
 runtime_affected=[m for m in affected if m in dependencies and not m.startswith('FV.Backend.Proof.')]
 assert not runtime_affected,'Proof packet reached runtime consumers; reassess gates: '+repr(runtime_affected)
 scope={'changed_files':changed,'affected_modules':sorted(affected),'affected_executables':exes,'runtime_source_unchanged_from_main':True,'runtime_gates':'no runtime/compiler/checker/linker/semantic definition or consumer input changed; proof-only scope under current per-PR policy'}
 (root/'scope.json').write_text(json.dumps(scope,indent=2)+'\n')
 run('all-modules',['python3','/tmp/stock-execute-scheduler.py','--budget','16G','--max-jobs','3','--max-cap','16G','--default-cap','8G','--others-by-usage','--out',str(root/'all-modules'),'FV','FVTest'])
 run('library-and-affected-tools',['lake','build','FV','FVTest',*exes])
 run('all-axiom-audits',['python3','scripts/axiom-audit.py','--log-dir',str(root/'axiom-audit')])
 files=['/tmp/stock-straight-line-body-owned.lean','/tmp/stock-pure-unsunk-owned.lean','/tmp/stock-pure-source-colors-owned.lean','/tmp/stock-pure-driver-core-owned.lean','/tmp/stock-pure-driver-witness-owned.lean','/tmp/stock-pure-record-coverage-owned.lean','/tmp/stock-scalar-native-owned-1.lean']
 for i,f in enumerate(files):run('owned-'+str(i),['lake','env','lean','--root=/tmp',f])
 def axioms(folder):
  result={}
  for p in Path(folder).glob('*.log'):
   flat=' '.join(p.read_text().split())
   for name,axs in re.findall(r"'(.+?)' depends on axioms: \[([^\]]*)\]",flat):result[name]=sorted(x.strip() for x in axs.split(',') if x.strip())
   for name in re.findall(r"'(.+?)' does not depend on any axioms",flat):result[name]=[]
  return result
 old=axioms('/tmp/stock-scalar-author-gates/axiom-audit');new=axioms(root/'axiom-audit');assert old
 missing=sorted(set(old)-set(new));changed_sets={n:{'before':a,'after':new.get(n)} for n,a in old.items() if n in new and new[n]!=a}
 parity={'previous_roots':len(old),'current_roots':len(new),'missing':missing,'changed_sets':changed_sets,'all_previous_axiom_sets_preserved':not missing and not changed_sets}
 (root/'axiom-set-parity.json').write_text(json.dumps(parity,indent=2)+'\n')
 assert parity['all_previous_axiom_sets_preserved'],'old theorem trust set drift: '+repr(parity)
 report('per_pr_gates_passed',scope=scope,axiom_parity=parity,remaining='Fetch current main/reconcile, record receipt, substantive prerequisite author squash; continue full function value simulation/activation and all original#140 obligations.')
except BaseException as e:report('failed',error=repr(e),traceback=traceback.format_exc());raise
