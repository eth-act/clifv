from pathlib import Path
import os,json,time,subprocess as sp,datetime,hashlib,re,traceback
view=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');root=Path('/tmp/stock-pure-proof-landing');root.mkdir(exist_ok=True);records={}
expected='9cab610f1cc1bcff39aa70b049acee1c7d2710fb';base='fcdaefe001c53ed87020aea1e2c35e2b01301efb';author_pid=3086906
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run(*args):return sp.check_output(args,cwd=view,text=True,stderr=sp.STDOUT).strip()
def report(state,**kw):
 d=dict(state=state,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=os.getpid(),records=records,**kw);(root/'progress.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items() if k!='records'}),flush=True)
try:
 report('waiting_for_exact_author_gates',author_pid=author_pid)
 while True:
  d=json.loads(Path('/tmp/stock-pure-proof-author-gates/progress.json').read_text());assert d['pid']==author_pid
  assert d['state']!='failed',d.get('error')
  if d['state']=='per_pr_gates_passed':break
  assert Path('/proc/'+str(author_pid)).exists(),'author missing without terminal result'
  time.sleep(2)
 report('checking_frozen_receipts')
 assert d['head']==expected and d['base']==base
 assert run('git','rev-parse','HEAD')==expected
 assert not run('git','diff','--name-only') and not run('git','diff','--cached','--name-only')
 frozen=json.loads(Path('/tmp/stock-pure-proof-author-gates/inputs.json').read_text())
 actual={str(p.relative_to(view)):sha(p) for folder in ['FV','FVTest','scripts/audit'] for p in (view/folder).rglob('*.lean')}
 assert frozen['sources']==actual
 for item in d['logs'].values():assert sha(item['path'])==item['sha256'],item['path']
 assert d['axiom_parity']['all_previous_axiom_sets_preserved']
 assert d['scope']['runtime_source_unchanged_from_main'] and not d['scope']['affected_executables']
 run('git','fetch','origin','main');assert run('git','rev-parse','origin/main')==base,'main changed: reconcile before landing'
 records['author']=d
 receipt=view/'docs/research/stock-pure-body-author-gates.json';assert not receipt.exists()
 receipt.write_text(json.dumps(dict(validated_head=expected,base_main=base,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),author=d,new_production_activation=False,full_140_complete=False),indent=2)+'\n')
 plan=view/'docs/plans/stock-driver-incremental-delivery.md';s=plan.read_text();s+='\nThe complete derived color-frame/decision-coverage prerequisite passed frozen\nauthor gates on `'+expected+'`, including the full FV/FVTest scheduler, all\nchecked-in trust audits, all owned constants and exact prior theorem axiom-set\nparity. The proof-only dependency manifest reaches no runtime consumer or\nexecutable; no new production class is claimed. The terminal\n[author receipt](../research/stock-pure-body-author-gates.json) records the scope.\nContinue arithmetic-family/value simulation and direct semantic consumer work\nimmediately after the prerequisite squash; all original #140 obligations remain.\n';plan.write_text(s)
 run('git','add',str(receipt.relative_to(view)),str(plan.relative_to(view)))
 run('git','diff','--cached','--check');run('git','commit','-m','Record pure-body driver prerequisite author gates')
 head=run('git','rev-parse','HEAD');tree=run('git','rev-parse','HEAD^{tree}');records['receipt_commit']=head
 run('git','push','origin','agent/stock-straight-line-production')
 report('receipt_pushed',head=head)
 body=root/'pr-body.md';body.write_text('''Derive pure-body scan decisions from the original source and the actual complete Stock driver. Earlier body composition needed emitted/omitted coverage supplied separately; this packet proves the invariant through constructors, interpreter execution, original and critical-edge nodes, reverse traversal and every retained record. Actual sourceMetadata/buildCtx derive the pure slots' zero colors; unchanged LowerScope excludes remembered binding. Pure body records consequently derive emitted/omitted decisions without a per-record certificate.

Complete standard-only witnesses cover a nonempty pure source function, a real critical-edge CFG and an effectful sink that remains permitted. Old theorem variants, input conditions and runtime lowering/consumer definitions are retained. This is the complete prerequisite for broader body/function value simulation; shipped production coverage remains #336 until the next complete class is integrated. Direct optimized-Stock semantic consumers, effects/families and full original #140 simulation/completeness remain open.

Validation on `'''+expected+'''` plus receipt-only `'''+head+'''`:

- Frozen FV/FVTest scheduler and affected-target build PASS (16 GiB/max3jobs/shared cache).
- All checked-in axiom audits and public/private/generated owned-constant scans PASS. All prior #336 theorem axiom sets retained exactly.
- Targeted complete witness builds; standard-only critical-edge/effectful sink/source-derived whole-driver witnesses; one bundled MCP whole-driver source check, standard3/no warnings.
- Dependency manifest: all changes are proofs/audits/docs; no runtime/compiler/checker/linker consumer or executable depends on the changed modules. Runtime inputs are byte-identical to current main#337, so additional runtime gates are outside this proof-only per-PR scope.

Exact terminal logs/hashes, scope and trust-set parity are checked into `docs/research/stock-pure-body-author-gates.json`. Last observed continuous main gate GREEN: #336/d18ba039. Reconciled #337/fcdaefe0 without overwriting saved/published work.
''')
 assert run('git','ls-remote','origin','refs/heads/main').split()[0]==base
 output=run('gh','pr','create','--repo','eth-act/clifv','--base','main','--head','agent/stock-straight-line-production','--title','Derive pure-body scan decisions through the complete Stock driver','--body-file',str(body))
 urls=re.findall(r'https://github.com/eth-act/clifv/pull/\d+',output);assert len(urls)==1,output
 url=urls[0];records['pr_url']=url
 assert run('git','ls-remote','origin','refs/heads/main').split()[0]==base,'main changed before squash'
 report('merging',pr=url);run('gh','pr','merge',url,'--repo','eth-act/clifv','--squash','--match-head-commit',head)
 pr=json.loads(run('gh','pr','view',url,'--repo','eth-act/clifv','--json','number,state,mergeCommit,url'));assert pr['state']=='MERGED';records['merged_pr']=pr
 commit=pr['mergeCommit']['oid'];run('git','fetch','origin','main');assert run('git','rev-parse',commit+'^{tree}')==tree,'merge tree differs from validated source plus receipt'
 comment=root/'integrator-comment.md';comment.write_text('@kevaundray Author squash landed #'+str(pr['number'])+' as **'+commit+'**. Exact merge tree equals validated '+expected+' plus receipt '+head+'. Please include the actual commit in the immediate continuous main gate.\n\nComplete derived pure-body/driver invariant and emitted-or-omitted decision prerequisite: actual source metadata/buildCtx, constructors/interpreter, original/critical-edge nodes, complete traversal and retained boundaries. Witnesses include nonempty pure source, real critical-edge CFG and permitted effectful sink. Frozen proof-only per-PR gates pass all FV/FVTest, all checked-in audits, all owned constants and exact previous theorem axiom-set parity. Dependency manifest reaches no runtime consumer/executable; no production behavior or accepted input changed. Shipped classes remain#336; broader function value simulation, direct optimized-Stock semantic consumers and every original#140 completeness/effect/integration obligation remain active.\n')
 for issue in ['261','140']:run('gh','issue','comment',issue,'--repo','eth-act/clifv','--body-file',str(comment))
 status=json.loads(run('gh','issue','view','44','--repo','eth-act/clifv','--json','body'))['body'];status+='\n\n'+comment.read_text()+'\nCurrent published source '+head+',branch agent/stock-straight-line-production; stateactive. Next backup terminal evidence/cleanup, then actual arithmetic-family/value simulation and broader production activation. UTC '+datetime.datetime.now(datetime.timezone.utc).isoformat()+'\n'
 (root/'status.md').write_text(status);run('gh','issue','edit','44','--repo','eth-act/clifv','--body-file',str(root/'status.md'))
 report('landed_and_integrator_notified',pr=url,merge_commit=commit,next='Back up terminal evidence/cleanup; continue value simulation/direct semantic integration and full original#140.')
except BaseException as e:report('failed',error=repr(e),output=getattr(e,'output',None),traceback=traceback.format_exc());raise
