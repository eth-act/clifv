import FV.Backend.Lowering.StockArithmeticNI
import FV.E2E.ProductionPipelineWith
import FVTest.E2E.LinkProof
open Backend E2E E2E.LinkCheck E2E.Elf E2E.BinCheck
private def get {α : Type} (r : Except String α) : IO α :=
  match r with | .ok a => pure a | .error e => throw (IO.userError e)
def main (args : List String) : IO Unit := do
  let dir : System.FilePath := args.headD ""
  let cleanup := args[1]?.getD "" == "Cleanup"
  let (b, exe) ← Front.readBundle dir []
  let A ← get (Front.assemble b)
  let I : LinkInput := {funcs := A.funcs, addrs := Front.linkAddrs b A, syms := [], raStar := 8, D := 0}
  let file ← IO.FS.readBinFile exe
  let some phs := phdrs (fileRd file) | throw (IO.userError "headers")
  unless I.funcs.length == 2 do throw (IO.userError "retained fixture function count")
  for fi in I.funcs do
    let fresh ← get (Stock.Arithmetic.lowerValidated fi.func)
    let retained ← get (Stock.ScalarAdd.lower fi.func)
    unless Stock.Arithmetic.eligible fi.func && !(fresh == retained) &&
        SemanticNI.check fi.func fresh && Proof.Driver.lowerCheck fi.func retained do
      throw (IO.userError "retained fixture must distinguish valid virtual lowerings")
    let actual ← get (I.pipeProductionWith Stock.Arithmetic.lowerValidated cleanup fi)
    let previous ← get (I.pipeProductionWith Stock.ScalarAdd.lower cleanup fi)
    unless actual.fb.words == previous.fb.words &&
        artB I (fileRd file) phs actual && artB I (fileRd file) phs previous do
      throw (IO.userError "actual retained file must validate under both routes with identical machine words")
    IO.println s!"RETAINED_SHARED_BYTES {fi.func.name} cleanup={cleanup} passed"
  IO.println "RETAINED_RAW_BYTE_PARITY 2"
