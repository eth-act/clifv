from pathlib import Path
import os, subprocess as sp, json, datetime, hashlib, traceback
view = Path('/home/lee/clifv/.worktrees/stock-driver-incremental')
canon = Path('/home/lee/clifv/.worktrees/driver-proof-resume')
root = Path('/tmp/stock-arithmetic-retained-route-gates')
root.mkdir(exist_ok=True)
state = root / 'progress.json'
logs = {}
head = sp.check_output(['git', 'rev-parse', 'HEAD'], cwd=view, text=True).strip()
assert head == '5a3b822e585e5a0ede99a59a5c7e567cf1009271', 'current-model candidate must be checked out only after verified old module boundary'
for retired_pid, retired_script in [(1235132, '/tmp/stock-arithmetic-arm-model-author-gates.py'), (1235140, '/tmp/stock-execute-scheduler.py')]:
    proc = Path('/proc') / str(retired_pid)
    if (proc / 'cmdline').exists():
        assert retired_script.encode() not in (proc / 'cmdline').read_bytes(), 'retire old metadata after verified healthy kernel drain before launching repaired epoch'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def inputs():
    return {str(p.relative_to(view)): sha(p) for d in ['FV', 'FVTest', 'rust/crates', 'examples/fv-demo/src', 'scripts/audit'] for p in (view / d).rglob('*') if p.is_file() and p.suffix in ['.lean', '.rs']}
frozen_sources = inputs()
(root / 'inputs.json').write_text(json.dumps({'head': head, 'sources': frozen_sources}, indent=2) + '\n')
env = dict(os.environ)
env.update(PATH='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:/home/lee/.cargo/bin:/home/lee/.local/share/clifv-test-tools/usr/bin:/home/lee/.rustup/toolchains/nightly-2026-09-26-x86_64-unknown-linux-gnu/lib/rustlib/x86_64-unknown-linux-gnu/bin:' + str(view / 'rust/target/release') + ':' + env['PATH'], FV_ROOT=str(view), FV_AR='/home/lee/.local/share/clifv-test-tools/usr/bin/llvm-ar', FV_OBJCOPY='/home/lee/.local/share/clifv-test-tools/usr/bin/llvm-objcopy', FV_LAKE_CACHE=str(canon / '.lake/artifact-cache'), FV_MEMCAP='8G', OMP_NUM_THREADS='2', OMP_THREAD_LIMIT='2', LEAN_NUM_THREADS='2', CARGO_BUILD_JOBS='2', CLIF_NATIVE_QEMU='/home/lee/.local/share/clifv-test-tools/usr/bin/qemu-aarch64-static', LLVM_MC='/home/lee/.local/share/clifv-test-tools/usr/bin/llvm-mc', PYTHONPATH=str(view / 'scripts'))
os.sched_setaffinity(0, sorted(os.sched_getaffinity(0))[:8])

def report(status, **kw):
    d = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'state': status, 'pid': os.getpid(), 'head': head, 'logs': logs, **kw}
    state.write_text(json.dumps(d, indent=2) + '\n')
    print(json.dumps({k: v for k, v in d.items() if k != 'logs'}), flush=True)

def frozen():
    assert sp.check_output(['git', 'rev-parse', 'HEAD'], cwd=view, text=True).strip() == head
    assert inputs() == frozen_sources, 'source changed during gates'

def run(name, args, cwd=view):
    frozen()
    p = root / (name + '.log')
    report('running', phase=name, log=str(p))
    with p.open('w') as f:
        command = args if args[:2] == ['python3', '/tmp/stock-execute-scheduler.py'] else [str(view / 'scripts/memcap.sh'), *args]
        r = sp.run(command, cwd=cwd, env=env, stdout=f, stderr=sp.STDOUT)
    assert r.returncode == 0, (name, r.returncode, str(p))
    frozen()
    logs[name] = {'path': str(p), 'sha256': sha(p)}
    return p
try:
 import re,shutil,ast
 oldroot=Path('/tmp/stock-arithmetic-runtime-import-final-gates')
 old=json.loads((oldroot/'progress.json').read_text());assert old['state']=='failed' and 'arithmetic-native-cli' in old['error'] and len(old['logs'])==30
 examplesroot=Path('/tmp/stock-arithmetic-independent-examples');examples=json.loads((examplesroot/'progress.json').read_text());assert examples['state']=='independent_verified_examples_passed' and examples['head']==old['head']
 before=json.loads((oldroot/'inputs.json').read_text())['sources']
 changed=sorted(p for p in before.keys()|frozen_sources.keys() if before.get(p)!=frozen_sources.get(p))
 assert changed==['FVTest/Backend/Lowering/StockArithmeticLinked.lean'],changed
 assert sp.check_output(['git','diff','--name-only',old['head'],head],cwd=view,text=True).splitlines()==changed
 for source in [old,examples]:
  for name,record in source['logs'].items():
   assert sha(Path(record['path']))==record['sha256'],name
   logs[name]={**record,'reused_from_head':source['head']}
 deps={str(p.relative_to(view))[:-5].replace('/','.'):set(re.findall(r'^(?:public\s+|meta\s+|private\s+)*import\s+(\S+)',p.read_text(),re.M)) for d in ['FV','FVTest'] for p in (view/d).rglob('*.lean')}
 affected={'FVTest.Backend.Lowering.StockArithmeticLinked'}
 assert not any(ds&affected for m,ds in deps.items() if m not in affected),'inspect unexpected fixture importers'
 unchanged=set(deps)-affected
 run('prior-success-module-keys-current',['lake','build','--no-build',*sorted(unchanged)])
 only=root/'affected-modules.txt';only.write_text('FVTest.Backend.Lowering.StockArithmeticLinked\n')
 run('all-modules',['python3','/tmp/stock-execute-scheduler.py','--budget','16G','--max-jobs','2','--max-cap','16G','--default-cap','8G','--only',str(only),'--out',str(root/'all-modules'),'FV','FVTest'])
 run('source-module-keys-current',['lake','build','--no-build','FV','FVTest'])
 run('library-and-affected-tools',['lake','build','FV','FVTest','lean-backend','lean-e2e-check','link-check','lean-link'])
 for p in ['identity-stage-parity.json']:
  shutil.copyfile(oldroot/p,root/p)
 required=set()
 for node in ast.walk(ast.parse(Path('/tmp/stock-arithmetic-runtime-import-final-gates.py').read_text())):
  if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id=='run' and node.args and isinstance(node.args[0],ast.Constant):required.add(node.args[0].value)
 manifest={'state':'unchanged_dependency_closures_and_normal_keys_verified','previous_head':old['head'],'current_head':head,'changed_source_paths':changed,'affected_modules':sorted(affected),'unchanged_normal_key_modules':sorted(unchanged),'all_configuration_files_unchanged':True,'fresh_normal_full_keys_passed':True,'required_gate_names':sorted(required),'original_progress':str(oldroot/'progress.json'),'example_progress':str(examplesroot/'progress.json'),'reused_logs_keep_original_head_and_hash':True,'reason':'Only the isolated linked-test fixture changed; no production executable or other proof/runtime/E2E/example input imports it. All old passed logs remain immutable; rerun the fixture, generated proofs and native CLI, plus current module/tool keys and trust/strict routing checks.'}
 (root/'reuse-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 run('all-axiom-audits',['python3','scripts/axiom-audit.py','--log-dir',str(root/'axiom-audit')])
 run('owned-constants',['lake','env','lean','--root=/tmp','/tmp/stock-arithmetic-activation-all-owned.lean'])
 runtime=run('arithmetic-dual-allocator-runtime',['lake','env','lean','--run','FVTest/Backend/Lowering/StockArithmeticRuntime.lean']);text=runtime.read_text();assert text.count('Stock arithmetic lean ')==6 and text.count('Stock arithmetic regalloc2 ')==6 and 'Stock arithmetic missing-binary negative control passed' in text
 (root/'arithmetic-strict-regalloc.json').write_text(json.dumps({'state':'strict_real_oracle_runtime_passed','head':head,'runtime_sha256':sha(view/'FVTest/Backend/Lowering/StockArithmeticRuntime.lean'),'log':str(runtime),'log_sha256':sha(runtime),'positive_case_grid':24,'missing_binary_negative_control':True},indent=2)+'\n')
 extra=Path('/tmp/StockArithmeticCommittedRoute.lean');assert sha(extra)=='d61c5d6f2702460bdb016a7a3907dcf76c8bda8f0181f36b6f2f191aa4de8f72'
 log=run('arithmetic-committed-route-extra',['lake','env','lean','--root=/tmp',str(extra)]);assert log.read_text().count('Stock arithmetic committed ')==24
 (root/'committed-route-extra-gate.json').write_text(json.dumps({'state':'passed','head':head,'source':str(extra),'sha256':sha(extra),'log':str(log),'log_sha256':sha(log),'pass_records':24},indent=2)+'\n')
 run('arithmetic-linked-generated-proofs',['python3','/tmp/stock-arithmetic-linked-check.py'])
 run('arithmetic-native-cli',['python3','/tmp/stock-arithmetic-cli-check.py'])
 def axioms(folder):
  out={}
  for p in Path(folder).glob('*.log'):
   flat=' '.join(p.read_text().split())
   for n,a in re.findall(r"'(.+?)' depends on axioms: \[([^\]]*)\]",flat):out[n]=sorted(x.strip() for x in a.split(',') if x.strip())
   for n in re.findall(r"'(.+?)' does not depend on any axioms",flat):out[n]=[]
  return out
 a=axioms('/tmp/stock-arithmetic-semantic-reconciled-author-gates/axiom-audit');b=axioms(root/'axiom-audit');assert len(a)>=1181
 missing=sorted(set(a)-set(b));drift={n:{'before':v,'after':b.get(n)} for n,v in a.items() if n in b and b[n]!=v};parity={'previous_roots':len(a),'current_roots':len(b),'missing':missing,'changed_sets':drift,'all_previous_axiom_sets_preserved':not missing and not drift};(root/'axiom-set-parity.json').write_text(json.dumps(parity,indent=2)+'\n');assert parity['all_previous_axiom_sets_preserved']
 for name,record in logs.items():assert sha(Path(record['path']))==record['sha256'] and 'Error: index out of bounds' not in Path(record['path']).read_text(),name
 report('per_pr_gates_passed',identity_stage_parity=json.loads((root/'identity-stage-parity.json').read_text()),reuse_manifest=str(root/'reuse-manifest.json'),remaining='Fresh main/readiness/source+receipt/PR/squash; full140 continues')
except BaseException as e:
 report('failed',error=repr(e),traceback=traceback.format_exc());raise
