import StockTryRetsFrame
namespace Backend.Stock.Proof.TryRetsShapeDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
/-- The actual helper's substitution of a payload sharing an ABI return register. -/
def payloadResult (ps rets : List Reg) (pair : Reg × Reg) : Reg :=
  match ps.idxOf? pair.1 with
  | none => pair.2
  | some i => rets[i]?.getD .xzr
private def step (ps rets : List Reg) (acc : Except String (State × List Reg))
    (pair : Reg × Reg) : Except String (State × List Reg) := do
  let (s, regs) ← acc
  if let some i := ps.idxOf? pair.1 then
    let some ret := rets[i]? | throw "try_call return register"
    pure (← s.setAlias pair.2 ret, regs ++ [ret])
  else pure (s, regs ++ [pair.2])
private theorem fold_error (ps rets : List Reg) (pairs : List (Reg × Reg)) (e : String) :
    pairs.foldl (step ps rets) (.error e) = .error e := by
  induction pairs with
  | nil => rfl
  | cons pair pairs ih => exact ih
private theorem fold_results (ps rets : List Reg) (pairs : List (Reg × Reg))
    (st : State) (acc : List Reg) {next : State} {out : List Reg}
    (run : pairs.foldl (step ps rets) (.ok (st,acc)) = .ok (next,out)) :
    out = acc ++ pairs.map (payloadResult ps rets) := by
  induction pairs generalizing st acc with
  | nil => cases run; simp
  | cons pair pairs ih =>
    rw [List.foldl_cons] at run
    cases call : step ps rets (.ok (st,acc)) pair with
    | error e => rw [call,fold_error] at run; cases run
    | ok result =>
      obtain ⟨middle,rs⟩ := result
      rw [call] at run
      have first : rs = acc ++ [payloadResult ps rets pair] := by
        unfold step at call
        simp only [bind,Except.bind] at call
        cases found : ps.idxOf? pair.1 with
        | none => simp only [found,pure,Except.pure] at call; cases call; simp only [payloadResult,found]
        | some i =>
          simp only [found] at call
          cases ret : rets[i]? with
          | none => simp only [ret] at call; cases call
          | some r =>
            simp only [ret] at call
            cases alias : st.setAlias pair.2 r with
            | error e => rw [alias] at call; cases call
            | ok s =>
              rw [alias] at call
              simp only [pure,Except.pure] at call
              cases call
              simp only [payloadResult,found,ret,Option.getD_some]
      rw [ih middle rs run,first,List.map_cons,List.append_assoc]
      rfl
/-- Successful real Stock return/payload construction has an exact normal-return
prefix and exact physical-register payload substitution. The substitution is
recovered from execution, not supplied as an extra compiler/input certificate. -/
theorem stock_try_rets_exact_shape {ctx : Ctx} {sig : Clif.Signature} {st next : State} {value : V}
    (run : Stock.externCtor ctx T.gen_try_call_rets [.op (.sig sig)] st = .ok (value,next)) :
    ∃ ps, retRegs sig.returns.length = some ps ∧
      value = .op (.callRets (ps.zip ctx.tryRegs.1 ++
        ((payloadRegs sig.callConv).zip
          (((payloadRegs sig.callConv).zip ctx.tryRegs.2).map (payloadResult ps ctx.tryRegs.1))).filter
          (fun (q : Reg × Reg) => !ps.contains q.1))) ∧
      {next with alias := #[]} = {st with alias := #[]} := by
  have frame := TryRetsFrameDraft.stock_try_rets_alias_only run
  change (match retRegs sig.returns.length with
    | none => ExtResult.unmodeled "try_call return count"
    | some ps =>
      match ((payloadRegs sig.callConv).zip ctx.tryRegs.2).foldl (step ps ctx.tryRegs.1) (Except.ok (st,([] : List Reg))) with
      | .error e => ExtResult.unmodeled e
      | .ok (s,regs) => ExtResult.ok (V.op (.callRets (ps.zip ctx.tryRegs.1 ++
          (((payloadRegs sig.callConv).zip regs).filter fun (q : Reg × Reg) => !ps.contains q.1))),s)) = .ok (value,next) at run
  cases returns : retRegs sig.returns.length with
  | none => simp only [returns] at run; cases run
  | some ps =>
    simp only [returns] at run
    cases folded : ((payloadRegs sig.callConv).zip ctx.tryRegs.2).foldl (step ps ctx.tryRegs.1) (Except.ok (st,([] : List Reg))) with
    | error err => rw [folded] at run; cases run
    | ok pair =>
      obtain ⟨after,regs⟩ := pair
      have same := fold_results ps ctx.tryRegs.1 _ st [] folded
      simp only [List.nil_append] at same
      rw [folded] at run
      cases run
      exact ⟨ps,rfl,by rw [same],frame⟩
end Backend.Stock.Proof.TryRetsShapeDraft
