import StockTryBranchAbi
import StockTryProtocolWitness
namespace Backend.Stock.Proof.TryBranchAbiWitnessDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open TryProtocolWitnessDraft TrySourceContextDraft TryBranchSelectionDraft TryBranchAbiDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private def function : Kind → Clif.Function
  | .near => TryNearFixtureDraft.function false
  | .got => SpillEntryFixture.function false
  | .indirect => SpillEntryFixture.function true
/-- COMPLETE original-condition direct, GOT and indirect compiler/prepare/
checked-fallback/physical pipelines exercise the explicit-return ABI theorem
on their actual selected branches and retained schedule entries. -/
theorem stock_complete_try_branch_explicit_abi_witness (k : Kind) :
    ∃ (result : Result) (prepared : EdgeVCode) (rf : RFunc) (af : AFunc)
      (source : TryBranchSource (function k) result 0 0 (function k).blocks[0]!)
      (selected : TryBranchSelection source) (et : Clif.ExnTable) (sig : Clif.Signature)
      (items : List (Option Nat)) (info : TryInfo) (call : CallInfo),
      LowerScope (function k) ∧ Dominated (function k) ∧ ArityOk (function k) ∧
      Stock.lower (function k) = .ok result ∧
      prepareAt result.code result.edgeArgs = .ok prepared ∧
      rf = spillAllocAt prepared.code prepared.edges ∧
      checkAllocAt prepared.code prepared.edges rf = .ok () ∧
      lowerRFunc prepared.code rf = .ok af ∧ source.branch.step ∈ result.schedule.toList ∧
      sourceTable (function k).blocks[0]!.term = some et ∧ exnTableOpnd (function k) et = .ok (sig,items) ∧
      tryInfoOf sig items result.order.successors[0]!.toList = some info ∧
      info.rets = (sigRets sig).length ∧
      selected.next.base.emitted.back? = some (.call call) ∧
      source.branch.step.emitted.back? = some (.tryCall call {info with rets := sig.returns.length}) := by
  obtain ⟨out,source,selected,scope,dominated,arity,lowered,prepare,fallback,accepted,physical,scheduled,protocol⟩ :=
    stock_complete_selected_try_protocol_witness k
  have kind : (function k).blocks[0]!.term.isTry = true := by cases k <;> rfl
  obtain ⟨et,sig,items,info,call,table,decoded,metadata,count,raw,last⟩ :=
    stock_selected_try_explicit_abi selected kind
  exact ⟨_,_,_,_,source,selected,et,sig,items,info,call,
    scope,dominated,arity,lowered,prepare,fallback,accepted,physical,scheduled,table,decoded,metadata,count,raw,last⟩
end Backend.Stock.Proof.TryBranchAbiWitnessDraft
