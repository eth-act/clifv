import StockTryRetsTotal
import StockTryRetsFootprint
import StockTryNearFixture
namespace Backend.Stock.Proof.TryRetsWitnessDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open TryRetsShapeDraft TryRetsTotalDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
attribute [local irreducible] Stock.lower Stock.runTerm Stock.externCtor
private theorem lower_build {f : Clif.Function} {result : Result} (run : Stock.lower f = .ok result) :
    ∃ ranges,Stock.buildCtx f = .ok (result.ctx,ranges,result.initial) := by
  unfold Stock.lower at run
  dsimp only at run
  repeat' first
    | (solve | cases run)
    | simp only [bind,Except.bind,pure,Except.pure] at run
    | split at run
  cases run
  exact ⟨_,by assumption⟩
private def function := TryNearFixtureDraft.function false
private def signature := function.sig
private def helperContext (result : Result) : Ctx := {result.ctx with tryRegs := result.initial.tryRegs[1]!}
private theorem reservation (out : TryNearFixtureDraft.Output) :
    (helperContext out.result).tryRegs = (reservedReturns 193 1,reservedPayloads 193 1) := by
  obtain ⟨ranges,build⟩ := lower_build out.lowered
  have observed : ((Stock.buildCtx function).toOption.map (fun q => q.2.2.tryRegs[1]!)) =
      some (reservedReturns 193 1,reservedPayloads 193 1) := by rfl
  change Stock.buildCtx function = .ok (out.result.ctx,ranges,out.result.initial) at build
  rw [build] at observed
  exact Option.some.inj observed
/-- A COMPLETE original-condition near TryCall compiler/prepare/checked-spill/
physical pipeline supplies the ACTUAL allocated slot. Both new exact-shape and
totality roots apply to that slot, rather than an unrelated synthetic context. -/
theorem stock_complete_try_rets_shape_total_witness :
    ∃ (out : TryNearFixtureDraft.Output) (value : V) (next : State) (ps : List Reg),
      LowerScope function ∧ Dominated function ∧ ArityOk function ∧
      Stock.lower function = .ok out.result ∧
      prepareAt out.result.code out.result.edgeArgs = .ok out.prepared ∧
      out.rf = spillAllocAt out.prepared.code out.prepared.edges ∧
      checkAllocAt out.prepared.code out.prepared.edges out.rf = .ok () ∧
      lowerRFunc out.prepared.code out.rf = .ok out.af ∧
      (helperContext out.result).tryRegs = (reservedReturns 193 1,reservedPayloads 193 1) ∧
      Stock.externCtor (helperContext out.result) T.gen_try_call_rets [.op (.sig signature)] out.result.initial = .ok (value,next) ∧
      retRegs signature.returns.length = some ps ∧
      value = .op (.callRets (ps.zip (helperContext out.result).tryRegs.1 ++
        ((payloadRegs signature.callConv).zip
          (((payloadRegs signature.callConv).zip (helperContext out.result).tryRegs.2).map
            (payloadResult ps (helperContext out.result).tryRegs.1))).filter
              (fun (q : Reg × Reg) => !ps.contains q.1))) ∧
      {next with alias := #[]} = {out.result.initial with alias := #[]} := by
  obtain ⟨out⟩ := TryNearFixtureDraft.stock_near_try_fixture
  have allocated := reservation out
  obtain ⟨value,next,run⟩ := stock_try_rets_reserved_total (ctx := helperContext out.result)
    (sig := signature) out.result.initial 193 (by decide +kernel) rfl allocated
  obtain ⟨ps,returns,shape,frame⟩ := stock_try_rets_exact_shape run
  exact ⟨out,value,next,ps,out.scope,out.dominated,out.arity,out.lowered,out.prepare,out.fallback,
    out.accepted,out.physical,allocated,run,returns,shape,frame⟩
/-- The same complete pipeline has a genuine shared return/payload and a
separate second payload definition. Both concrete outputs satisfy the generic
reservation footprint and the internally built source-mapping separation. -/
theorem stock_complete_try_rets_footprint_witness :
    ∃ (out : TryNearFixtureDraft.Output) (value : V) (next : State),
      Stock.lower function = .ok out.result ∧
      prepareAt out.result.code out.result.edgeArgs = .ok out.prepared ∧
      checkAllocAt out.prepared.code out.prepared.edges out.rf = .ok () ∧
      lowerRFunc out.prepared.code out.rf = .ok out.af ∧
      Stock.externCtor (helperContext out.result) T.gen_try_call_rets [.op (.sig signature)] out.result.initial = .ok (value,next) ∧
      value = .op (.callRets [(.x 0,.vreg 193 .int),(.x 1,.vreg 195 .int)]) ∧
      ∀ n ∈ [193,195], (.vreg n .int) ∈ (helperContext out.result).tryRegs.1 ++ (helperContext out.result).tryRegs.2 ∧
        n < out.result.initial.base.nextVreg ∧ ∀ x,out.result.ctx.valueReg? x ≠ some (.vreg n .int) := by
  obtain ⟨out,value,next,ps,scope,dominated,arity,lowered,prepare,fallback,accepted,physical,
    allocated,run,returns,shape,frame⟩ := stock_complete_try_rets_shape_total_witness
  have fixed : ps = [.x 0] := by
    change some [.x 0] = some ps at returns
    exact (Option.some.inj returns).symm
  have exactOutput : value = .op (.callRets [(.x 0,.vreg 193 .int),(.x 1,.vreg 195 .int)]) := by
    have payload : payloadRegs signature.callConv = [.x 0,.x 1] := rfl
    rw [fixed,allocated,payload] at shape
    simpa [signature,function,TryNearFixtureDraft.function,reservedReturns,reservedPayloads,
      payloadResult,payloadRegs,List.idxOf?,List.findIdx?,List.findIdx?.go] using shape
  obtain ⟨ranges,build⟩ := lower_build out.lowered
  refine ⟨out,value,next,out.lowered,out.prepare,out.accepted,out.physical,run,exactOutput,?_⟩
  intro n member
  have inOutput : (.vreg n .int) ∈ value.regsIn := by
    rw [exactOutput]
    simp only [List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl <;> decide +kernel
  have inReserved := TryRetsFootprintDraft.stock_try_rets_virtual_reserved run inOutput
  have separated := TryRetsFootprintDraft.stock_built_try_rets_source_separation build
    (show AllocationLe out.result.initial out.result.initial from ⟨Nat.le_refl _,rfl⟩) run inOutput
  exact ⟨inReserved,separated.2⟩
end Backend.Stock.Proof.TryRetsWitnessDraft
