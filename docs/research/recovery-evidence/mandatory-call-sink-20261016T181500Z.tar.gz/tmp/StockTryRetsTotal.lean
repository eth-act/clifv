import StockTryRetsShape
import FV.Backend.Proof.StockResults
namespace Backend.Stock.Proof.TryRetsTotalDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
/-- Exactly the disjoint vectors installed by Allocation.step.exception. -/
def reservedReturns (base count : Nat) : List Reg :=
  (List.range count).map fun j => .vreg (base+j) .int
def reservedPayloads (base count : Nat) : List Reg :=
  [.vreg (base+count) .int,.vreg (base+count+1) .int]
/-- Original supported try-call conventions and the real preallocation layout
make the Stock helper total, including zero returns. These are internal layout
facts, not a new accepted-input predicate. -/
theorem stock_try_rets_reserved_total {ctx : Ctx} {sig : Clif.Signature} (st : State) (base : Nat)
    (bound : sig.returns.length ≤ 8)
    (payload : payloadRegs sig.callConv = [.x 0,.x 1])
    (slots : ctx.tryRegs = (reservedReturns base sig.returns.length,reservedPayloads base sig.returns.length)) :
    ∃ (value : V) (next : State),
      Stock.externCtor ctx T.gen_try_call_rets [.op (.sig sig)] st = .ok (value,next) := by
  change ∃ value next, (match retRegs sig.returns.length with
    | none => ExtResult.unmodeled "try_call return count"
    | some ps =>
      match ((payloadRegs sig.callConv).zip ctx.tryRegs.2).foldl
        (fun (acc : Except String (State × List Reg)) (p,r) => do
          let (s,regs) ← acc
          if let some i := ps.idxOf? p then
            let some ret := ctx.tryRegs.1[i]? | throw "try_call return register"
            pure (← s.setAlias r ret,regs ++ [ret])
          else pure (s,regs ++ [r])) (Except.ok (st,([] : List Reg))) with
      | .error e => ExtResult.unmodeled e
      | .ok (s,regs) => ExtResult.ok (V.op (.callRets (ps.zip ctx.tryRegs.1 ++
          (((payloadRegs sig.callConv).zip regs).filter fun (q : Reg × Reg) => !ps.contains q.1))),s)) = .ok (value,next)
  rw [payload,slots]
  have casesCount : sig.returns.length = 0 ∨ sig.returns.length = 1 ∨ sig.returns.length = 2 ∨
      sig.returns.length = 3 ∨ sig.returns.length = 4 ∨ sig.returns.length = 5 ∨
      sig.returns.length = 6 ∨ sig.returns.length = 7 ∨ sig.returns.length = 8 := by omega
  rcases casesCount with n | n | n | n | n | n | n | n | n
  all_goals
    simp only [n,retRegs,reservedReturns,reservedPayloads]
    simp [List.range_succ, List.idxOf?, List.findIdx?, List.findIdx?.go, State.setAlias, bind, Except.bind, pure, Except.pure]
end Backend.Stock.Proof.TryRetsTotalDraft
