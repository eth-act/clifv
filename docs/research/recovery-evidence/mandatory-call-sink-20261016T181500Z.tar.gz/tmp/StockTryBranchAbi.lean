import StockTryBranchSelection
import FV.Backend.Proof.TryRegs
namespace Backend.Stock.Proof.TryBranchAbiDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open TrySourceContextDraft TryBranchSelectionDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
/-- The exception table actually carried by the original terminator. -/
def sourceTable : Clif.Terminator → Option Clif.ExnTable
  | .tryCall _ _ et | .tryCallIndirect _ _ et => some et
  | _ => none
/-- The actual call-to-TryCall replacement preserves the entire call and all
exception metadata while setting rets to EXPLICIT source returns. The old
tryInfoOf ABI-return count remains recorded separately, including implicit sret.
This describes the real compiler and does not identify the two counts. -/
theorem stock_try_branch_explicit_abi {f : Clif.Function} {term : Clif.Terminator}
    {labels : Array Nat} {before after : Array MInst}
    (kind : term.isTry = true) (run : branchCode f term labels before = .ok after) :
    ∃ (et : Clif.ExnTable) (sig : Clif.Signature) (items : List (Option Nat)) (info : TryInfo) (call : CallInfo),
      sourceTable term = some et ∧ exnTableOpnd f et = .ok (sig,items) ∧
      tryInfoOf sig items labels.toList = some info ∧ info.rets = (sigRets sig).length ∧
      before.back? = some (.call call) ∧
      after = before.pop.push (.tryCall call {info with rets := sig.returns.length}) ∧
      after.back? = some (.tryCall call {info with rets := sig.returns.length}) := by
  cases term <;> simp only [Clif.Terminator.isTry] at kind
  all_goals try contradiction
  all_goals
    unfold branchCode at run
    dsimp only at run
    repeat' first
      | (solve | cases run)
      | simp only [bind,Except.bind,pure,Except.pure] at run
      | split at run
    all_goals
      cases run
      rename_i _ sigItems tableRun _ info infoRun _ call atLast
      exact ⟨_,sigItems.1,sigItems.2,info,call,rfl,tableRun,infoRun,
        tryInfoOf_rets infoRun,atLast,rfl,by simp only [Array.back?_push]⟩
/-- The SAME actual selected source branch and retained schedule step carry
that explicit count. No caller-selected ABI/info or raw emitted-code certificate
is required beyond the internally derived actual source/selection receipts. -/
theorem stock_selected_try_explicit_abi {f : Clif.Function} {result : Result} {label bi : Nat} {b : Clif.Block}
    {source : TryBranchSource f result label bi b} (selected : TryBranchSelection source)
    (kind : b.term.isTry = true) :
    ∃ (et : Clif.ExnTable) (sig : Clif.Signature) (items : List (Option Nat)) (info : TryInfo) (call : CallInfo),
      sourceTable b.term = some et ∧ exnTableOpnd f et = .ok (sig,items) ∧
      tryInfoOf sig items result.order.successors[label]!.toList = some info ∧
      info.rets = (sigRets sig).length ∧
      selected.next.base.emitted.back? = some (.call call) ∧
      source.branch.step.emitted.back? = some (.tryCall call {info with rets := sig.returns.length}) := by
  obtain ⟨et,sig,items,info,call,table,decoded,metadata,count,raw,code,last⟩ :=
    stock_try_branch_explicit_abi kind selected.code
  exact ⟨et,sig,items,info,call,table,decoded,metadata,count,raw,by rw [selected.stepCode]; exact last⟩
end Backend.Stock.Proof.TryBranchAbiDraft
