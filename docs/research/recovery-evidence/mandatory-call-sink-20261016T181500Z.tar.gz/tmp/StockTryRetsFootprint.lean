import StockTryRetsFrame
import FV.Backend.Proof.StockCtorFlow
import FV.Backend.Proof.StockReservedScanFlow
namespace Backend.Stock.Proof.TryRetsFootprintDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Flow Isle Isle.Interp Isle.Aarch64
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
/-- Every virtual register in the real helper's output is an existing exception
reservation. In particular it is neither a new fresh allocation nor an arbitrary
source register; zero-return/payload-only output is included. -/
theorem stock_try_rets_virtual_reserved {ctx : Ctx} {sig : Clif.Signature} {st next : State} {value : V}
    (run : Stock.externCtor ctx T.gen_try_call_rets [.op (.sig sig)] st = .ok (value,next))
    {n : Nat} {c : RegClass} (member : (.vreg n c) ∈ value.regsIn) :
    (.vreg n c) ∈ ctx.tryRegs.1 ++ ctx.tryRegs.2 := by
  have origin := stock_ctor_output_reserved_origin run (.vreg n c) member
  rcases origin with generic | ret | pay
  · have base := (TryRetsFrameDraft.stock_try_rets_state_frame run).1
    simp only [RegOrigin,regsInL,valsInL,V.regsIn,V.valsIn,opRegs,opVals,
      List.append_nil,List.not_mem_nil,false_or,Reg.vreg.injEq,exists_and_left] at generic
    rcases generic with fresh | mapped | physical | invalid
    · obtain ⟨i,k,equal,low,high⟩ := fresh
      cases equal
      rw [base] at high
      omega
    · simp at mapped
    · exact False.elim (physical n c rfl)
    · cases invalid
  · exact List.mem_append_left _ ret
  · exact List.mem_append_right _ pay
/-- Real context construction separates every helper output virtual register
from every source mapping, at the current preallocated slot. This is a compiler
write-footprint fact; preservation of alias-resolved machine values still needs
the source-availability proof. -/
theorem stock_built_try_rets_source_separation {f : Clif.Function} {ctx : Ctx}
    {ranges : Array (Nat × Nat)} {initial st next : State} {ti : Nat} {sig : Clif.Signature} {value : V}
    (build : Stock.buildCtx f = .ok (ctx,ranges,initial)) (allocation : AllocationLe initial st)
    (run : Stock.externCtor {ctx with tryRegs := st.tryRegs[ti]!}
      T.gen_try_call_rets [.op (.sig sig)] st = .ok (value,next))
    {n : Nat} {c : RegClass} (member : (.vreg n c) ∈ value.regsIn) :
    c = .int ∧ n < initial.base.nextVreg ∧ ∀ x, ctx.valueReg? x ≠ some (.vreg n c) := by
  have reserved := stock_try_rets_virtual_reserved run member
  obtain ⟨m,shape,bound,separated⟩ := stock_reservation_slot_facts build allocation ti reserved
  cases shape
  exact ⟨rfl,bound,separated⟩
end Backend.Stock.Proof.TryRetsFootprintDraft
