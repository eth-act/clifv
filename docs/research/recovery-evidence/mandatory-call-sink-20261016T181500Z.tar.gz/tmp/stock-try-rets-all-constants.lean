import Lean
import StockTryRetsShape
import StockTryRetsTotal
import StockTryRetsFootprint
import StockTryRetsWitness
import StockTryBranchAbi
import StockTryBranchAbiWitness
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let targets : Array String := #["StockTryRetsShape", "StockTryRetsTotal", "StockTryRetsFootprint", "StockTryRetsWitness", "StockTryBranchAbi", "StockTryBranchAbiWitness" ]
  let mut count : Nat := 0
  for (name, info) in env.constants.toList do
    if false then continue
    let some index := env.getModuleIdxFor? name | continue
    let mod := env.header.moduleNames[index]!
    if !targets.contains mod.toString then continue
    let axioms ← collectAxioms name
    logInfo m!"DELIVERY_CONSTANT {Json.compress (toJson (name.toString, axioms.map Name.toString))}"
    count := count + 1
  logInfo m!"DELIVERY_AXIOM_COUNT {count}"
