import FV.Backend.ABIReadOnly
import FV.Backend.ArithmeticNIProduction
import FV.Backend.ArithmeticProduction
import FV.Backend.Lowering.StockArithmetic
import FV.Backend.Lowering.StockArithmeticNI
import FV.Backend.Proof.ArithmeticProduction
import FV.Backend.Proof.StockArithmeticCheck
import FV.Backend.SemanticNICheck
import FV.Backend.StockArithmeticCheck
import FV.E2E.ABIReadOnlyCheck
import FV.E2E.ABIReadOnlyMachine
import FV.E2E.ABIReadOnlyRealize
import FV.E2E.ABIReadOnlySem
import FV.E2E.ABIReadOnlyTransport
import FV.E2E.ArithmeticPipeline
import FV.E2E.ArithmeticPipelineWitness
import FV.E2E.CompiledSemantic
import FV.E2E.CompiledSemanticNI
import FV.E2E.LinkSemanticNI
import FV.E2E.SemanticBinary
import FV.E2E.SemanticBinaryGood
import FV.E2E.SemanticChecksWith
import FV.E2E.SemanticCompilerWitness
import FV.E2E.SemanticExecBytes
import FV.E2E.SemanticExecFrameSim
import FV.E2E.SemanticExecGoodReads
import FV.E2E.SemanticExecGoodRun
import FV.E2E.SemanticExecGot
import FV.E2E.SemanticExecProven
import FV.E2E.SemanticExecRunN
import FV.E2E.SemanticExecStatic
import FV.E2E.SemanticLinkGood
import FV.E2E.SemanticNIBoundary
import FV.E2E.SemanticPipelineCheck
import FV.E2E.SemanticPreparedPipeline
import FV.E2E.SemanticStackBound
import FV.E2E.StockArithmeticNI
import FV.E2E.StockArithmeticNIWitness
import FV.E2E.StockArithmeticStage
import FV.E2E.StockArithmeticStageWitness
import FV.E2E.StockArithmeticWorldX
import FV.Link.SemanticCompileWith
import FV.Link.SemanticExeSourceWith
import FV.Link.SemanticExeWith
import FVTest.E2E.SemanticLinkProofWith
import FV.Backend.Proof.StockContext
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let core := #["FV.Backend.Proof.StockContext", "FV.Backend.ABIReadOnly", "FV.Backend.ArithmeticNIProduction", "FV.Backend.ArithmeticProduction", "FV.Backend.Lowering.StockArithmetic", "FV.Backend.Lowering.StockArithmeticNI", "FV.Backend.Proof.ArithmeticProduction", "FV.Backend.Proof.StockArithmeticCheck", "FV.Backend.SemanticNICheck", "FV.Backend.StockArithmeticCheck", "FV.E2E.ABIReadOnlyCheck", "FV.E2E.ABIReadOnlyMachine", "FV.E2E.ABIReadOnlyRealize", "FV.E2E.ABIReadOnlySem", "FV.E2E.ABIReadOnlyTransport", "FV.E2E.ArithmeticPipeline", "FV.E2E.CompiledSemantic", "FV.E2E.CompiledSemanticNI", "FV.E2E.LinkSemanticNI", "FV.E2E.SemanticBinary", "FV.E2E.SemanticBinaryGood", "FV.E2E.SemanticChecksWith", "FV.E2E.SemanticExecBytes", "FV.E2E.SemanticExecFrameSim", "FV.E2E.SemanticExecGoodReads", "FV.E2E.SemanticExecGoodRun", "FV.E2E.SemanticExecGot", "FV.E2E.SemanticExecProven", "FV.E2E.SemanticExecRunN", "FV.E2E.SemanticExecStatic", "FV.E2E.SemanticLinkGood", "FV.E2E.SemanticNIBoundary", "FV.E2E.SemanticPipelineCheck", "FV.E2E.SemanticPreparedPipeline", "FV.E2E.SemanticStackBound", "FV.E2E.StockArithmeticNI", "FV.E2E.StockArithmeticStage", "FV.E2E.StockArithmeticWorldX", "FV.Link.SemanticCompileWith", "FV.Link.SemanticExeSourceWith", "FV.Link.SemanticExeWith", "FVTest.E2E.SemanticLinkProofWith"]
  let witnesses := #["FV.E2E.ArithmeticPipelineWitness", "FV.E2E.SemanticCompilerWitness", "FV.E2E.StockArithmeticNIWitness", "FV.E2E.StockArithmeticStageWitness"]
  let mut ncore : Nat := 0
  let mut nwitness : Nat := 0
  for (name,_) in env.constants.toList do
    let some i := env.getModuleIdxFor? name | continue
    let owned := env.header.moduleNames[i]!.toString
    unless core.contains owned || witnesses.contains owned do continue
    for ax in ← collectAxioms name do
      if #[``propext,``Classical.choice,``Quot.sound].contains ax then continue
      let permittedNative := #["E2E.StockArithmeticNIWitness.checks_true._native.native_decide.ax_1", "E2E.SemanticCompilerWitness.checks_true._native.native_decide.ax_1", "E2E.ArithmeticPipelineWitness.checks_true._native.native_decide.ax_1", "E2E.StockArithmeticStageWitness.checks_true._native.native_decide.ax_1"].contains ax.toString
      unless witnesses.contains owned && permittedNative do
        throwError "disallowed axiom {ax} in {name}"
    if core.contains owned then ncore := ncore+1 else nwitness := nwitness+1
  unless ncore > 0 do throwError "empty core partition"
  unless nwitness > 0 do throwError "empty witness partition"
  logInfo m!"ENTRY_CORE_STANDARD_ONLY {ncore}; FIXED_WITNESS_CONSTANTS {nwitness}"
