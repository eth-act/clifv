import StockCallSourceCoverage
import FV.Opt.Proof.SemSim
namespace Backend.Stock.Proof.SourceExecutionGraphDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000

/-- An actual source destination resolves to the same first block in the Stock
successor table and Clif.enterBlock, and preserves entry reachability. -/
theorem stock_source_destination_reachable {f : Clif.Function} {source : Array (Array Nat)}
    (computed : stockSourceTable f = .ok source) {bi : Nat} {b : Clif.Block}
    (block : f.blocks[bi]? = some b) (reached : Prep.Reach source bi)
    {id : Nat} {args : List Clif.TryArg} (destination : (id,args) ∈ destinations b.term) :
    ∃ (target : Nat) (next : Clif.Block),f.blocks[target]? = some next ∧ f.block? id = some next ∧
      target ∈ source[bi]!.toList ∧ Prep.Reach source target := by
  obtain ⟨size,calls⟩ := Prep.amapM_ok computed
  obtain ⟨row,rowRun,rowAt⟩ := calls bi b (by simpa only [List.getElem?_toArray] using block)
  obtain ⟨j,jBound,atDest⟩ := List.getElem_of_mem destination
  obtain ⟨count,items⟩ := Prep.amapM_ok rowRun
  obtain ⟨target,call,atTarget⟩ := items j (id,args)
    (by simpa only [List.getElem?_toArray,List.getElem?_eq_getElem jBound] using congrArg some atDest)
  cases selected : f.blocks.findIdx? (·.id == id) with
  | none => simp only [selected,throw,throwThe,MonadExceptOf.throw] at call; cases call
  | some ti =>
    simp only [selected,pure,Except.pure,Except.ok.injEq] at call
    subst target
    obtain ⟨bound,matchId,first⟩ := List.findIdx?_eq_some_iff_getElem.mp selected
    have next : f.blocks[ti]? = some f.blocks[ti] := List.getElem?_eq_getElem bound
    have lookup : f.block? id = some f.blocks[ti] := by
      rw [Clif.Function.block?,List.find?_eq_bind_findIdx?_getElem?,selected]
      exact next
    have edge : ti ∈ source[bi]!.toList := by
      simp only [getElem!_def,rowAt,Option.getD_some]
      exact Array.mem_toList_iff.mpr (Array.mem_of_getElem? atTarget)
    exact ⟨ti,f.blocks[ti],next,lookup,edge,.step reached edge⟩

/-- Location of a real frame in entry-reachable original source code. TryCall
may suspend at its pending jump, whose target is an actual original successor;
this is ghost proof information, never an accepted-input condition. -/
def FrameLocated (f : Clif.Function) (source : Array (Array Nat)) (fr : Clif.Frame) : Prop :=
  fr.func = f → ∃ (bi : Nat) (b : Clif.Block),f.blocks[bi]? = some b ∧ Prep.Reach source bi ∧
    fr.body <:+ b.body ∧ (fr.term = b.term ∨
      fr.body = [] ∧ ∃ (bc : Clif.BlockCall) (args : List Clif.TryArg),
        fr.term = .jump bc ∧ (bc.block,args) ∈ destinations b.term)

/-- A real successful activation starts at source entry, with no supplied
block-position or reachability certificate. -/
theorem stock_source_enterFunc_located {f g : Clif.Function} {source : Array (Array Nat)}
    {args : List Clif.Val} {mem mem' : Clif.Mem} {fr : Clif.Frame}
    (entered : Clif.enterFunc g args mem = .ok (fr,mem')) : FrameLocated f source fr := by
  obtain ⟨b,regs,entry,types,paramTypes,set,slots,frame⟩ := Opt.enterFunc_ok entered
  intro same
  have gf : g = f := by rw [frame] at same; exact same
  subst g
  refine ⟨0,b,?_,.entry,?_,.inl ?_⟩
  · simpa only [Clif.Function.entry?,List.head?_eq_getElem?] using entry
  · rw [frame]; exact List.suffix_refl _
  · rw [frame]

/-- Binding values changes no source location. -/
theorem stock_source_frame_located_regs {f : Clif.Function} {source : Array (Array Nat)}
    {fr : Clif.Frame} (located : FrameLocated f source fr) (regs : Clif.Regs) :
    FrameLocated f source {fr with regs} := by
  intro same
  obtain ⟨bi,b,block,reached,suffix,control⟩ := located same
  exact ⟨bi,b,block,reached,suffix,control⟩

/-- Consuming a real original statement preserves its source location. -/
theorem stock_source_frame_located_rest {f : Clif.Function} {source : Array (Array Nat)}
    {fr : Clif.Frame} (located : FrameLocated f source fr) {stm : Clif.Stmt} {rest : List Clif.Stmt}
    (body : fr.body = stm :: rest) (regs : Clif.Regs) : FrameLocated f source {fr with regs,body := rest} := by
  intro same
  obtain ⟨bi,b,block,reached,suffix,control⟩ := located same
  rcases control with normal | ⟨empty,pending⟩
  · exact ⟨bi,b,block,reached,(List.suffix_cons stm rest).trans (body ▸ suffix),.inl normal⟩
  · rw [body] at empty; cases empty

/-- Entering an actual successor from a located source frame preserves its
location. Static destination membership is taken from the actual current
terminator and transported through a pending TryCall jump internally. -/
theorem stock_source_enterBlock_located {f : Clif.Function} {source : Array (Array Nat)}
    (computed : stockSourceTable f = .ok source) {fr next : Clif.Frame} (located : FrameLocated f source fr)
    {bc : Clif.BlockCall} (destination : ∃ args,(bc.block,args) ∈ destinations fr.term)
    (entered : Clif.enterBlock fr bc = .ok next) : FrameLocated f source next := by
  obtain ⟨target,vals,regs,lookup,values,types,set,frame⟩ := Opt.enterBlock_ok entered
  intro same
  have original : fr.func = f := by rw [frame] at same; exact same
  obtain ⟨bi,b,block,reached,suffix,control⟩ := located original
  have dest : ∃ args,(bc.block,args) ∈ destinations b.term := by
    rcases control with normal | ⟨empty,pending,pargs,term,member⟩
    · rw [normal] at destination; exact destination
    · obtain ⟨args,member'⟩ := destination
      rw [term] at member'
      simp only [destinations,List.mem_singleton,Prod.mk.injEq] at member'
      exact ⟨pargs,by rw [member'.1]; exact member⟩
  obtain ⟨args,member⟩ := dest
  obtain ⟨ti,b',atNext,found,edge,reaches⟩ := stock_source_destination_reachable computed block reached member
  rw [original,found] at lookup
  cases lookup
  exact ⟨ti,target,atNext,reaches,by rw [frame]; exact List.suffix_refl _,.inl (by rw [frame])⟩
end Backend.Stock.Proof.SourceExecutionGraphDraft
