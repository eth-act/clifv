import StockSourceExecutionCalls
namespace Backend.Stock.Proof.SourceExecutionTryDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open SourceExecutionGraphDraft SourceExecutionCallsDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
private theorem ofRes_next {α : Type} {r : Clif.Res α} {k : α → Clif.StepResult} {next : Clif.State}
    (run : Clif.StepResult.ofRes r k = .next next) : ∃ a,r = .ok a ∧ k a = .next next := by
  cases r with
  | ok a => exact ⟨a,rfl,run⟩
  | trap c => cases run
  | stuck msg => cases run

/-- Pending jumps retain the original reachable source predecessor. This works
for both normal returns and exceptional handler continuations. -/
theorem stock_source_pending_jump_located {f : Clif.Function} {source : Array (Array Nat)}
    {fr : Clif.Frame} (located : FrameLocated f source fr) {bc : Clif.BlockCall}
    (destination : ∃ args,(bc.block,args) ∈ destinations fr.term) (regs : Clif.Regs) :
    FrameLocated f source {fr with regs,body := [],term := .jump bc} := by
  intro same
  obtain ⟨bi,b,block,reached,suffix,control⟩ := located same
  have dest : ∃ args,(bc.block,args) ∈ destinations b.term := by
    rcases control with normal | ⟨empty,pending,pargs,term,member⟩
    · rw [normal] at destination; exact destination
    · obtain ⟨args,member'⟩ := destination
      rw [term] at member'
      simp only [destinations,List.mem_singleton,Prod.mk.injEq] at member'
      exact ⟨pargs,by rw [member'.1]; exact member⟩
  obtain ⟨args,member⟩ := dest
  exact ⟨bi,b,block,reached,List.nil_suffix,.inr ⟨rfl,bc,args,rfl,member⟩⟩

/-- The successful executable normal continuation targets the actual table's
normal destination. No replacement return or arity assumption is introduced. -/
theorem stock_source_tryNormal_block {et : Clif.ExnTable} {base : Nat} {bc : Clif.BlockCall}
    (run : Clif.tryNormal et base = .ok bc) : bc.block = et.normal.block := by
  simp only [Clif.tryNormal,Opt.Res.bind_eq_ok,Opt.Res.pure_eq_ok] at run
  obtain ⟨args,mapped,equality⟩ := run
  cases equality
  rfl

/-- Actual direct TryCall normal-return preparation preserves original source
reachability across both real program calls and atomic external calls. -/
theorem stock_source_stepTryCall_located {f : Clif.Function} {source : Array (Array Nat)}
    {env : Clif.Env} {p : Clif.Program} {s next : Clif.State} {fn : Nat} {args : List Nat} {et : Clif.ExnTable}
    (located : StateLocated f source s) (term : s.frame.term = .tryCall fn args et)
    (run : Clif.stepTryCall env p s fn args et = .next next) : StateLocated f source next := by
  unfold Clif.stepTryCall at run
  obtain ⟨⟨n,base,bc⟩,request,run⟩ := ofRes_next run
  simp only [Opt.Res.bind_eq_ok,Opt.Res.ofOption_eq_ok,Opt.Res.pure_eq_ok,Prod.mk.injEq] at request
  obtain ⟨ext,external,sig,signature,u,checked,actualBc,normal,equality⟩ := request
  obtain ⟨rfl,rfl,rfl⟩ := equality
  have dest : ∃ xs,(actualBc.block,xs) ∈ destinations s.frame.term := by
    rw [term,stock_source_tryNormal_block normal]
    refine ⟨et.normal.args,?_⟩
    simp [destinations,Clif.ExnTable.dests]
  have pending := stock_source_pending_jump_located located.1 dest s.frame.regs
  exact stock_source_stepCall_located (s := {s with frame := {s.frame with body := [],term := .jump actualBc}}) pending located.2 run

/-- Actual indirect TryCall has the same derived normal continuation property. -/
theorem stock_source_stepTryCallIndirect_located {f : Clif.Function} {source : Array (Array Nat)}
    {env : Clif.Env} {p : Clif.Program} {s next : Clif.State} {callee : Nat} {args : List Nat} {et : Clif.ExnTable}
    (located : StateLocated f source s) (term : s.frame.term = .tryCallIndirect callee args et)
    (run : Clif.stepTryCallIndirect env p s callee args et = .next next) : StateLocated f source next := by
  unfold Clif.stepTryCallIndirect at run
  obtain ⟨⟨n,base,bc⟩,request,run⟩ := ofRes_next run
  simp only [Opt.Res.bind_eq_ok,Opt.Res.ofOption_eq_ok,Opt.Res.pure_eq_ok,Prod.mk.injEq] at request
  obtain ⟨sig,signature,actualBc,normal,equality⟩ := request
  obtain ⟨rfl,rfl,rfl⟩ := equality
  have dest : ∃ xs,(actualBc.block,xs) ∈ destinations s.frame.term := by
    rw [term,stock_source_tryNormal_block normal]
    refine ⟨et.normal.args,?_⟩
    simp [destinations,Clif.ExnTable.dests]
  have pending := stock_source_pending_jump_located located.1 dest s.frame.regs
  exact stock_source_stepCallIndirect_located (s := {s with frame := {s.frame with body := [],term := .jump actualBc}}) pending located.2 run
end Backend.Stock.Proof.SourceExecutionTryDraft
