import StockSourceExecutionCore
import FV.Backend.Proof.LowerDecide
namespace Backend.Stock.Proof.SourceExecutionProgramWitnessDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open SourceExecutionGraphDraft SourceExecutionCallsDraft SourceExecutionCoreDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
private def signature : Clif.Signature := {callConv := some .systemV}
private def callee : Clif.Function := {name := "source_location_helper",sig := signature,blocks := [{id := 0,term := .ret []}]}
private def caller (indirect : Bool) : Clif.Function := {
  name := "source_location_caller",sig := {signature with params := [⟨.i64,.none,.normal⟩]}
  externs := [(0,{name := callee.name,sig := signature})],sigDecls := [(0,signature)]
  blocks := [{id := 0,params := [(7,.i64)],body := [⟨[],if indirect then .callIndirect 0 7 [] else .call 0 []⟩],term := .ret []}] }
private def program (indirect : Bool) : Clif.Program := {funcs := [caller indirect,callee]}
private def memory : Clif.Mem := {Clif.Mem.empty with symbols := fun name => if name = callee.name then some 4096 else none}
private def before (indirect : Bool) : Clif.State := {
  frame := {func := caller indirect,regs := Clif.Regs.empty.set 7 ⟨.i64,4096⟩,slots := [],body := ((caller indirect).blocks[0]!).body,term := .ret []},callers := [],mem := memory }
private def during (indirect : Bool) : Clif.State := {
  frame := {func := callee,regs := Clif.Regs.empty,slots := [],body := [],term := .ret []}
  callers := [({(before indirect).frame with body := []},[])],mem := memory }
private def after (indirect : Bool) : Clif.State := {before indirect with frame := {(before indirect).frame with body := []}}
private theorem entry (indirect : Bool) : Clif.initState (program indirect) (caller indirect).name [⟨.i64,4096⟩] memory = .ok (before indirect) := by cases indirect <;> rfl
private theorem call (indirect : Bool) : Clif.step Clif.Env.empty (program indirect) (before indirect) = .next (during indirect) := by cases indirect <;> rfl
private theorem returned (indirect : Bool) : Clif.step Clif.Env.empty (program indirect) (during indirect) = .next (after indirect) := by cases indirect <;> rfl
private theorem computed (indirect : Bool) : stockSourceTable (caller indirect) = .ok #[#[]] := by cases indirect <;> cbv
private theorem scope (indirect : Bool) : LowerScope (caller indirect) := by cases indirect <;> apply lowerScope_of <;> decide +kernel

/-- Actual direct AND indirect program calls push a real caller, enter the real
callee, then return to that same original caller point. Both new call branches
and the nonempty-caller return branch are inhabited by real source execution. -/
theorem stock_actual_program_call_return_witness (indirect : Bool) :
    ∃ (f : Clif.Function) (p : Clif.Program) (before during after : Clif.State),LowerScope f ∧ stockSourceTable f = .ok #[#[]] ∧ before.frame.func = f ∧
      StateLocated f #[#[]] before ∧ Clif.step Clif.Env.empty p before = .next during ∧
      during.callers.length = 1 ∧ StateLocated f #[#[]] during ∧
      Clif.step Clif.Env.empty p during = .next after ∧ after.frame.func = f ∧
      after.callers = [] ∧ StateLocated f #[#[]] after := by
  have initial : StateLocated (caller indirect) #[#[]] (before indirect) := stock_source_initState_located (entry indirect)
  have invoked := stock_source_step_located (computed indirect) initial (call indirect)
  have resumed := stock_source_step_located (computed indirect) invoked (returned indirect)
  exact ⟨caller indirect,program indirect,before indirect,during indirect,after indirect,scope indirect,computed indirect,rfl,initial,call indirect,rfl,invoked,returned indirect,rfl,rfl,resumed⟩

private def tailer : Clif.Function := {name := "source_location_raw_tail",sig := signature,externs := [(0,{name := callee.name,sig := signature})],blocks := [{id := 0,term := .returnCall 0 []}]}
private def tailProgram : Clif.Program := {funcs := [tailer,callee]}
private def tailBefore : Clif.State := {frame := {func := tailer,regs := Clif.Regs.empty,slots := [],body := [],term := .returnCall 0 []},callers := [],mem := memory}
private def tailAfter : Clif.State := {frame := {func := callee,regs := Clif.Regs.empty,slots := [],body := [],term := .ret []},callers := [],mem := memory}
private theorem tailEntry : Clif.initState tailProgram tailer.name [] memory = .ok tailBefore := by rfl
private theorem tailActual : Clif.step Clif.Env.empty tailProgram tailBefore = .next tailAfter := by rfl
private theorem calleeComputed : stockSourceTable callee = .ok #[#[]] := by cbv

/-- The general Clif tail-call branch really enters the tracked callee at its
source entry, without pushing a caller. This is a raw semantics witness, not a
claim that Stock accepts the currently excluded return_call source family. -/
theorem stock_actual_raw_tail_location_witness :
    ∃ (f : Clif.Function) (p : Clif.Program) (before after : Clif.State),stockSourceTable f = .ok #[#[]] ∧ StateLocated f #[#[]] before ∧
      Clif.step Clif.Env.empty p before = .next after ∧ after.frame.func = f ∧ after.callers = [] ∧
      StateLocated f #[#[]] after := by
  have initial : StateLocated callee #[#[]] tailBefore := stock_source_initState_located tailEntry
  exact ⟨callee,tailProgram,tailBefore,tailAfter,calleeComputed,initial,tailActual,rfl,rfl,stock_source_step_located calleeComputed initial tailActual⟩
end Backend.Stock.Proof.SourceExecutionProgramWitnessDraft
