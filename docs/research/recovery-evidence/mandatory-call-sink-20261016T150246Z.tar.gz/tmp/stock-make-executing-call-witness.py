from pathlib import Path
s='''import StockSourceExecutionFixture
namespace Backend.Stock.Proof.SourceExecutingCallsWitnessDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open SourceExecutionGraphDraft SourceExecutionCallsDraft SourceExecutionCoreDraft SourceExecutingCallsDraft
open SourceExecutionFixtureDraft
open ExplicitCallWitnessDraft (sourceArgs values)
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
attribute [local irreducible] Stock.lower Stock.runTerm Isle.Aarch64.program
'''
for tag,ns,flag,root in [('direct','CallStaticFixture','false','CallEmissionWitnessDraft.stock_complete_direct_call_emission_witness'),('indirect','CallStaticFixture','true','IndirectCallEmissionWitnessDraft.stock_complete_indirect_call_emission_witness'),('got','GotCallFixture','false','GotCallWitnessDraft.stock_complete_got_call_emission_witness')]:
 fun=ns+'.function '+('implicit' if tag=='got' else flag+' implicit');inst=f'.callIndirect 0 80 (CallStaticFixture.arguments true implicit)' if tag=='indirect' else '.call 0 (CallStaticFixture.arguments false implicit)';sp='' if tag=='indirect' else 'SigStackOk (CallStaticFixture.signature false implicit) out.result.code.outgoing ∧\n      '
 s+=f'''
/-- Complete original {tag} ordinary/sret compiler pipelines and real source
runs inhabit the new executing-call coverage bridge. The actual reached source
call derives its Stock record and emission evidence through the new roots. -/
theorem stock_complete_{tag}_executing_call_witness (implicit : Bool) :
    ∃ (out : {ns}.Output) (bi j : Nat) (b : Clif.Block) (event : BlockScanEvent)
      (record : ScanRecord) (info : IInfo) (step : Step),
      LowerScope ({fun}) ∧ Dominated ({fun}) ∧ ArityOk ({fun}) ∧ AbiSigsOk ({fun}) ∧
      Stock.lower ({fun}) = .ok out.result ∧
      prepareAt out.result.code out.result.edgeArgs = .ok out.prepared ∧
      out.rf = spillAllocAt out.prepared.code out.prepared.edges ∧
      checkAllocAt out.prepared.code out.prepared.edges out.rf = .ok () ∧
      lowerRFunc out.prepared.code out.rf = .ok out.af ∧
      Clif.initState (program .{tag} implicit) (function .{tag} implicit).name (sourceArgs {flag} implicit) memory =
        .ok (initial .{tag} implicit) ∧
      RunPrefix (environment .{tag} implicit) (program .{tag} implicit) (initial .{tag} implicit) (current .{tag} implicit) ∧
      Clif.step (environment .{tag} implicit) (program .{tag} implicit) (current .{tag} implicit) = .next (afterCall .{tag} implicit) ∧
      StateLocated ({fun}) #[#[]] (afterCall .{tag} implicit) ∧
      {sp}({fun}).blocks[bi]? = some b ∧ b.body[j]? = some (CallStaticFixture.callStatement {flag} implicit) ∧
      event ∈ out.result.blockScans.toList ∧ event.block = bi ∧ record ∈ event.output.records ∧
      record.inst = blockStart ({fun}) bi + j ∧ event.ctx.insts[record.inst]? = some info ∧
      info.clif = some ({inst}) ∧ record.output.step = some step ∧ step.decision = .emitted := by
  obtain ⟨out,oldEvent,oldRecord,oldInfo,oldStep,scope,dom,arity,abi,run,prepared,fallback,checked,physical,
    facts,oldEvents,oldRecords,oldSlot,oldClif,oldRecorded,oldEmitted,rest⟩ := {root} implicit
  have computed : stockSourceTable (function .{tag} implicit) = .ok #[#[]] := by cases implicit <;> cbv
  have same : (current .{tag} implicit).frame.func = ({fun}) := by cases implicit <;> rfl
  have kind : (CallStaticFixture.callStatement {flag} implicit).inst = ({inst}) := rfl
  have call : (∃ fn xs,(CallStaticFixture.callStatement {flag} implicit).inst = .call fn xs) ∨
      (∃ sig callee xs,(CallStaticFixture.callStatement {flag} implicit).inst = .callIndirect sig callee xs) :=
    {'.inr ⟨0,80,_,kind⟩' if tag=='indirect' else '.inl ⟨0,_,kind⟩'}
  obtain ⟨bi,b,j,event,record,info,step,block,statement,events,eventBlock,records,index,slot,clif,recorded,emitted⟩ :=
    stock_lower_executing_source_call_emitted run scope (entered .{tag} implicit) (execution .{tag} implicit) same
      (head .{tag} implicit) call
  have located := stock_source_runPrefix_located computed (stock_source_initState_located (entered .{tag} implicit))
    (execution .{tag} implicit)
  have after := stock_source_step_located computed located (called .{tag} implicit)
'''
 if tag!='indirect':s+=f'''  let ext : Clif.ExtFunc := {{name := CallStaticFixture.calleeName,sig := CallStaticFixture.signature false implicit,colocated := {'false' if tag=='got' else 'true'}}}
  have external : ({fun}).extern? 0 = some ext := rfl
  have stack := stock_lower_executing_direct_call_stack run scope dom.1 abi (entered .{tag} implicit)
    (execution .{tag} implicit) same (head .{tag} implicit) kind external
'''
 s+=f'''  exact ⟨out,bi,j,b,event,record,info,step,scope,dom,arity,abi,run,prepared,fallback,checked,physical,
    entered .{tag} implicit,execution .{tag} implicit,called .{tag} implicit,after,{'' if tag=='indirect' else 'stack,'}
    block,statement,events,eventBlock,records,index,slot,clif,recorded,emitted⟩
'''
s+='end Backend.Stock.Proof.SourceExecutingCallsWitnessDraft\n';Path('/tmp/StockSourceExecutingCallsWitness.lean').write_text(s)
