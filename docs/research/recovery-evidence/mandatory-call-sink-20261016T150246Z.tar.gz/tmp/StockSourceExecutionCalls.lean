import StockSourceExecutionGraph
namespace Backend.Stock.Proof.SourceExecutionCallsDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64 SourceExecutionGraphDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000

def StateLocated (f : Clif.Function) (source : Array (Array Nat)) (s : Clif.State) : Prop :=
  FrameLocated f source s.frame ∧ ∀ c ∈ s.callers,FrameLocated f source c.1

private theorem ofRes_next {α : Type} {r : Clif.Res α} {k : α → Clif.StepResult} {next : Clif.State}
    (run : Clif.StepResult.ofRes r k = .next next) : ∃ a,r = .ok a ∧ k a = .next next := by
  cases r with
  | ok a => exact ⟨a,rfl,run⟩
  | trap c => cases run
  | stuck msg => cases run

/-- Real result binding preserves all running and suspended source locations. -/
theorem stock_source_continueWith_located {f : Clif.Function} {source : Array (Array Nat)}
    {s next : Clif.State} {rest : List Clif.Stmt} {results : List Nat} {vals : List Clif.Val} {mem : Clif.Mem}
    (resume : FrameLocated f source {s.frame with body := rest})
    (callers : ∀ c ∈ s.callers,FrameLocated f source c.1)
    (run : Clif.continueWith s rest results vals mem = .next next) : StateLocated f source next := by
  unfold Clif.continueWith at run
  cases bound : s.frame.regs.setMany results vals with
  | none => simp only [bound] at run; cases run
  | some regs =>
    simp only [bound,Clif.StepResult.next.injEq] at run
    subst next
    exact ⟨stock_source_frame_located_regs resume regs,callers⟩

/-- Returning to the real stored caller preserves its source location. -/
theorem stock_source_returnValues_located {f : Clif.Function} {source : Array (Array Nat)}
    {s next : Clif.State} {vals : List Clif.Val} {mem : Clif.Mem}
    (callers : ∀ c ∈ s.callers,FrameLocated f source c.1)
    (run : Clif.returnValues s vals mem = .next next) : StateLocated f source next := by
  unfold Clif.returnValues at run
  obtain ⟨u,types,run⟩ := ofRes_next run
  cases stored : s.callers with
  | nil => simp only [stored] at run; cases run
  | cons caller tail =>
    obtain ⟨fr,results⟩ := caller
    simp only [stored] at run
    cases bound : fr.regs.setMany results vals with
    | none => simp only [bound] at run; cases run
    | some regs =>
      simp only [bound,Clif.StepResult.next.injEq] at run
      subst next
      have head := callers (fr,results) (by rw [stored]; simp)
      refine ⟨stock_source_frame_located_regs head regs,?_⟩
      intro c member
      exact callers c (by rw [stored]; exact List.mem_cons_of_mem _ member)

/-- Both real program calls and atomic extern calls preserve the invariant.
The real retained caller point is supplied by the enclosing source-step proof. -/
theorem stock_source_stepCall_located {f : Clif.Function} {source : Array (Array Nat)}
    {env : Clif.Env} {p : Clif.Program} {s next : Clif.State}
    {rest : List Clif.Stmt} {results : List Nat} {fn : Nat} {args : List Nat}
    (resume : FrameLocated f source {s.frame with body := rest})
    (callers : ∀ c ∈ s.callers,FrameLocated f source c.1)
    (run : Clif.stepCall env p s rest results fn args = .next next) : StateLocated f source next := by
  unfold Clif.stepCall at run
  obtain ⟨⟨ext,vals⟩,request,run⟩ := ofRes_next run
  cases target : p.func? ext.name with
  | some callee =>
    simp only [target] at run
    split at run
    · obtain ⟨⟨fr,mem⟩,entered,run⟩ := ofRes_next run
      cases run
      refine ⟨stock_source_enterFunc_located entered,?_⟩
      intro c member
      rcases List.mem_cons.mp member with rfl | old
      · exact resume
      · exact callers c old
    · cases run
  | none =>
    simp only [target] at run
    cases found : env.extern ext.name with
    | none => simp only [found] at run; cases run
    | some g =>
      simp only [found] at run
      cases outcome : g vals s.mem with
      | trapped c => simp only [outcome] at run; cases run
      | stuck msg => simp only [outcome] at run; cases run
      | outOfFuel => simp only [outcome] at run; cases run
      | returned rvals mem =>
        simp only [outcome] at run
        split at run
        · exact stock_source_continueWith_located resume callers run
        · cases run

/-- Indirect program and external calls preserve the same original source
locations, without a stronger callee or target-acceptance condition. -/
theorem stock_source_stepCallIndirect_located {f : Clif.Function} {source : Array (Array Nat)}
    {env : Clif.Env} {p : Clif.Program} {s next : Clif.State}
    {rest : List Clif.Stmt} {results : List Nat} {sig callee : Nat} {args : List Nat}
    (resume : FrameLocated f source {s.frame with body := rest})
    (callers : ∀ c ∈ s.callers,FrameLocated f source c.1)
    (run : Clif.stepCallIndirect env p s rest results sig callee args = .next next) : StateLocated f source next := by
  unfold Clif.stepCallIndirect at run
  obtain ⟨⟨declared,addr,vals⟩,request,run⟩ := ofRes_next run
  cases target : p.funcs.find? (fun g => s.mem.symbols g.name == some addr) with
  | some g =>
    simp only [target] at run
    split at run
    · obtain ⟨⟨fr,mem⟩,entered,run⟩ := ofRes_next run
      cases run
      refine ⟨stock_source_enterFunc_located entered,?_⟩
      intro c member
      rcases List.mem_cons.mp member with rfl | old
      · exact resume
      · exact callers c old
    · cases run
  | none =>
    simp only [target] at run
    obtain ⟨⟨vals,mem⟩,returned,run⟩ := ofRes_next run
    exact stock_source_continueWith_located resume callers run

/-- Tail calls enter a real activation or resume a real suspended caller;
the departing activation contributes no new location premise. -/
theorem stock_source_stepReturnCall_located {f : Clif.Function} {source : Array (Array Nat)}
    {env : Clif.Env} {p : Clif.Program} {s next : Clif.State} {fn : Nat} {args : List Nat}
    (callers : ∀ c ∈ s.callers,FrameLocated f source c.1)
    (run : Clif.stepReturnCall env p s fn args = .next next) : StateLocated f source next := by
  unfold Clif.stepReturnCall at run
  obtain ⟨⟨ext,vals⟩,request,run⟩ := ofRes_next run
  cases target : p.func? ext.name with
  | some callee =>
    simp only [target] at run
    split at run
    · obtain ⟨⟨fr,mem⟩,entered,run⟩ := ofRes_next run
      cases run
      exact ⟨stock_source_enterFunc_located entered,callers⟩
    · cases run
  | none =>
    simp only [target] at run
    cases found : env.extern ext.name with
    | none => simp only [found] at run; cases run
    | some g =>
      simp only [found] at run
      cases outcome : g vals s.mem with
      | trapped c => simp only [outcome] at run; cases run
      | stuck msg => simp only [outcome] at run; cases run
      | outOfFuel => simp only [outcome] at run; cases run
      | returned rvals mem =>
        simp only [outcome] at run
        exact stock_source_returnValues_located callers run
end Backend.Stock.Proof.SourceExecutionCallsDraft
