import StockSourceExecutingCalls
import StockCallSourceCoverageWitness
import StockExplicitCallWitness
import StockIndirectSourceWitness
namespace Backend.Stock.Proof.SourceExecutionFixtureDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open SourceExecutionGraphDraft SourceExecutionCallsDraft SourceExecutionCoreDraft SourceExecutingCallsDraft
open CallStaticFixture (signature arguments callStatement calleeName count)
open ExplicitCallWitnessDraft (sourceArgs sourceEnv values)
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
attribute [local irreducible] Stock.lower Stock.runTerm Isle.Aarch64.program
inductive Kind where | direct | indirect | got
  deriving DecidableEq,Repr

def indirect : Kind → Bool | .indirect => true | _ => false
def function (k : Kind) (implicit : Bool) : Clif.Function :=
  match k with
  | .got => GotCallFixture.function implicit
  | _ => CallStaticFixture.function (indirect k) implicit
def program (k : Kind) (implicit : Bool) : Clif.Program := {funcs := [function k implicit]}
def memory : Clif.Mem := IndirectSourceWitnessDraft.memory
def environment (k : Kind) (implicit : Bool) : Clif.Env :=
  {sourceEnv (indirect k) implicit with names := [calleeName]}
def initial (k : Kind) (implicit : Bool) : Clif.State := {
  frame := {
    func := function k implicit
    regs := (Clif.Regs.empty.setMany ((arguments (indirect k) implicit))
      (sourceArgs (indirect k) implicit)).getD Clif.Regs.empty
    slots := []
    body := ((function k implicit).blocks[0]!).body
    term := ((function k implicit).blocks[0]!).term }
  callers := [],mem := memory }
def current (k : Kind) (implicit : Bool) : Clif.State :=
  if indirect k then {initial k implicit with frame := {(initial k implicit).frame with
    regs := (initial k implicit).frame.regs.set 80 ⟨.i64,4096⟩,
    body := [callStatement true implicit]}} else initial k implicit
def afterCall (k : Kind) (implicit : Bool) : Clif.State :=
  {current k implicit with frame := {(current k implicit).frame with
    regs := ((current k implicit).frame.regs.setMany (callStatement (indirect k) implicit).results
      (values implicit)).getD Clif.Regs.empty,body := []}}

theorem entered (k : Kind) (implicit : Bool) :
    Clif.initState (program k implicit) (function k implicit).name (sourceArgs (indirect k) implicit) memory =
      .ok (initial k implicit) := by cases k <;> cases implicit <;> rfl

theorem first (implicit : Bool) :
    Clif.step (environment .indirect implicit) (program .indirect implicit) (initial .indirect implicit) =
      .next (current .indirect implicit) := by cases implicit <;> rfl

theorem called (k : Kind) (implicit : Bool) :
    Clif.step (environment k implicit) (program k implicit) (current k implicit) = .next (afterCall k implicit) := by
  cases k <;> cases implicit <;> rfl

theorem returned (k : Kind) (implicit : Bool) :
    Clif.step (environment k implicit) (program k implicit) (afterCall k implicit) = .done (values implicit) memory := by
  cases k <;> cases implicit <;> rfl

theorem execution (k : Kind) (implicit : Bool) :
    RunPrefix (environment k implicit) (program k implicit) (initial k implicit) (current k implicit) := by
  cases k with
  | direct => exact .refl _
  | indirect => exact .next (first implicit) (.refl _)
  | got => exact .refl _

theorem head (k : Kind) (implicit : Bool) :
    (current k implicit).frame.body = [callStatement (indirect k) implicit] := by cases k <;> cases implicit <;> rfl
/-- These are real complete source runs, including the indirect target setup,
actual external call, result binding and return. -/
theorem completed_source_run (k : Kind) (implicit : Bool) :
    Clif.runWith (environment k implicit) (program k implicit) (function k implicit).name
      (sourceArgs (indirect k) implicit) memory (if indirect k then 4 else 3) =
      .returned (values implicit) memory := by cases k <;> cases implicit <;> rfl
end Backend.Stock.Proof.SourceExecutionFixtureDraft
