import StockSourceExecutionTry
import FV.Clif.Unwind
namespace Backend.Stock.Proof.SourceExecutionUnwindDraft
open Backend.Proof Backend.Proof.Driver
open SourceExecutionGraphDraft SourceExecutionCallsDraft SourceExecutionTryDraft
/-- The successful executable exception continuation targets its real handler. -/
theorem stock_source_tryHandler_block {d : Clif.TryDest} {base : Nat} {bc : Clif.BlockCall}
    (run : Clif.tryHandler d base = .ok bc) : bc.block = d.block := by
  simp only [Clif.tryHandler,Opt.Res.bind_eq_ok,Opt.Res.pure_eq_ok] at run
  obtain ⟨args,mapped,equality⟩ := run
  cases equality
  rfl



set_option maxRecDepth 20000
set_option maxHeartbeats 6000000

/-- Original exception table of a suspended source TryCall. It is proof state,
not a new input condition; normal calls record none and actual TryCalls record
their original table before replacing the active terminator by a pending jump. -/
def PendingTableLocated (f : Clif.Function) (source : Array (Array Nat))
    (fr : Clif.Frame) (et : Clif.ExnTable) : Prop :=
  fr.func = f → ∃ (bi : Nat) (b : Clif.Block),f.blocks[bi]? = some b ∧ Prep.Reach source bi ∧
    ((∃ fn args,b.term = .tryCall fn args et) ∨ (∃ callee args,b.term = .tryCallIndirect callee args et))

/-- The real TryCall terminator derives its original reachable pending table. -/
theorem stock_source_try_table_located {f : Clif.Function} {source : Array (Array Nat)}
    {fr : Clif.Frame} (located : FrameLocated f source fr) {et : Clif.ExnTable}
    (actual : (∃ fn args,fr.term = .tryCall fn args et) ∨
      (∃ callee args,fr.term = .tryCallIndirect callee args et)) : PendingTableLocated f source fr et := by
  intro same
  obtain ⟨bi,b,block,reached,suffix,control⟩ := located same
  rcases control with normal | ⟨empty,bc,args,term,member⟩
  · exact ⟨bi,b,block,reached,by rw [← normal]; exact actual⟩
  · rw [term] at actual
    rcases actual with ⟨fn,args,impossible⟩ | ⟨callee,args,impossible⟩
    all_goals cases impossible

private theorem catch_member {et : Clif.ExnTable} {e : Clif.Exn} {d : Clif.TryDest}
    (found : et.catch? e = some d) : d ∈ et.dests := by
  obtain ⟨item,member,selected⟩ := List.exists_of_findSome?_eq_some found
  apply List.mem_append_left
  apply List.mem_filterMap.mpr
  refine ⟨item,member,?_⟩
  cases item with
  | context v => cases selected
  | default target => cases selected; rfl
  | tag n target =>
    dsimp only at selected
    split at selected
    · cases selected; rfl
    · cases selected

/-- An actual caught exception preserves the original source predecessor and
chooses only an actual handler destination. No handler certificate is supplied. -/
theorem stock_source_catchIn_located {f : Clif.Function} {source : Array (Array Nat)}
    {fr next : Clif.Frame} {et : Clif.ExnTable} {e : Clif.Exn}
    (pending : PendingTableLocated f source fr et)
    (run : Clif.catchIn fr et e = some (.ok next)) : FrameLocated f source next := by
  unfold Clif.catchIn at run
  cases found : et.catch? e with
  | none => simp only [found,Option.map_none] at run; cases run
  | some d =>
    simp only [found,Option.map_some,Option.some.injEq,Opt.Res.bind_eq_ok,Opt.Res.ofOption_eq_ok,Opt.Res.pure_eq_ok] at run
    obtain ⟨bc,handler,regs,binds,equality⟩ := run
    cases equality
    intro same
    obtain ⟨bi,b,block,reached,kind⟩ := pending same
    have destination : (bc.block,d.args) ∈ destinations b.term := by
      rw [stock_source_tryHandler_block handler]
      rcases kind with ⟨fn,args,term⟩ | ⟨callee,args,term⟩
      all_goals rw [term]; exact List.mem_map.mpr ⟨d,catch_member found,rfl⟩
    exact ⟨bi,b,block,reached,List.nil_suffix,.inr ⟨rfl,bc,d.args,rfl,destination⟩⟩
end Backend.Stock.Proof.SourceExecutionUnwindDraft
