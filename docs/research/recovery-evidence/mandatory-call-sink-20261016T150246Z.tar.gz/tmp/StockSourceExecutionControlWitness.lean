import StockSourceExecutionCore
import StockSourceExecutionUnwind
import FV.Backend.Proof.LowerDecide
import FV.Backend.Proof.SpillArity
import FV.Backend.Proof.SpillCtlPipe
namespace Backend.Stock.Proof.SourceExecutionControlWitnessDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open SourceExecutionGraphDraft SourceExecutionCallsDraft SourceExecutionTryDraft SourceExecutionCoreDraft SourceExecutionUnwindDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
inductive Kind where | jump | brif | table | tryDirect | tryIndirect
  deriving DecidableEq,Repr
private def signature : Clif.Signature := {callConv := some .systemV}
private def table : Clif.ExnTable := {sig := 0,normal := ⟨1,[]⟩,items := [.tag 7 ⟨2,[]⟩,.default ⟨3,[]⟩]}
private def term : Kind → Clif.Terminator
  | .jump => .jump ⟨1,[]⟩
  | .brif => .brif 7 ⟨1,[]⟩ ⟨2,[]⟩
  | .table => .brTable 7 ⟨3,[]⟩ [⟨1,[]⟩,⟨2,[]⟩]
  | .tryDirect => .tryCall 0 [] table
  | .tryIndirect => .tryCallIndirect 7 [] table
private def paramTy : Kind → Clif.Ty | .table => .i32 | _ => .i64
private def function (k : Kind) : Clif.Function := {
  name := "stock_actual_source_control",sig := {signature with params := [⟨paramTy k,.none,.normal⟩]}
  externs := [(0,{name := "source_control_callee",sig := signature,colocated := true})]
  sigDecls := [(0,signature)]
  blocks := [{id := 0,params := [(7,paramTy k)],term := term k},
    {id := 1,term := .ret []},{id := 2,term := .ret []},{id := 3,term := .ret []}] }
private def source (k : Kind) : Array (Array Nat) :=
  #[match k with | .jump => #[1] | .brif => #[1,2] | .table => #[3,1,2] | _ => #[2,3,1],#[],#[],#[]]
private def argument (k : Kind) : Clif.Val := ⟨paramTy k,if k = .tryIndirect then 4096 else 1⟩
private def program (k : Kind) : Clif.Program := {funcs := [function k]}
private def memory : Clif.Mem := {Clif.Mem.empty with symbols := fun name => if name = "source_control_callee" then some 4096 else none}
private def environment : Clif.Env := {extern := fun _ => some (fun _ mem => .returned [] mem),names := ["source_control_callee"],sigOf := fun _ => some signature}
private def initial (k : Kind) : Clif.State := {
  frame := {func := function k,regs := Clif.Regs.empty.set 7 (argument k),slots := [],body := [],term := term k}
  callers := [],mem := memory }
private def one (k : Kind) : Clif.State :=
  {initial k with frame := {(initial k).frame with term := match k with | .tryDirect | .tryIndirect => .jump ⟨1,[]⟩ | _ => .ret []}}
private theorem computed (k : Kind) : stockSourceTable (function k) = .ok (source k) := by cases k <;> cbv
private theorem entered (k : Kind) : Clif.initState (program k) (function k).name [argument k] memory = .ok (initial k) := by cases k <;> rfl
private theorem actual (k : Kind) : Clif.step environment (program k) (initial k) = .next (one k) := by cases k <;> rfl
private theorem scope (k : Kind) : LowerScope (function k) := by cases k <;> apply lowerScope_of <;> decide +kernel
private def built (k : Kind) : Ctx × Array (Nat × Nat) × LState :=
  (Backend.buildCtx (function k)).toOption.getD (sinkCtx,#[],sinkState.base)
private theorem build (k : Kind) : Backend.buildCtx (function k) = .ok (built k) := by cases k <;> rfl
private theorem dominated (k : Kind) : Dominated (function k) := by
  constructor
  · cases k <;> decide +kernel
  · intro ctx ranges st build bi b found
    cases k <;> rcases bi with _ | (_ | (_ | (_ | bi)))
    all_goals simp [function] at found
    all_goals subst b
    all_goals constructor
    all_goals first
      | (intro j stm present; simp [function] at present)
      | (intro x member
         simp [abiTerm,Driver.termArgs,function,term,signature,sretRet,sigRets,table,Clif.ExnTable.vals,Clif.ExnTable.dests,Clif.ExnTable.handlers,Clif.TryDest.vals] at member
         all_goals subst x
         all_goals simp [availOf,function,defsBefore,defsFrom])
  · intro ctx ranges st original tl x incoming notLocal y member
    have bound := (inFix_fixOk (f := function k) (ctx := ctx) (gn := id)).cand tl x incoming
    have value : x = 7 := by simpa [valueDefs,function] using bound.2.2.2.1
    subst x
    have fixed : ctx = (built k).1 := congrArg Prod.fst (Except.ok.inj (original.symm.trans (build k)))
    rw [fixed] at member
    cases k <;> change y ∈ ([] : List Nat) at member <;> cases member
private theorem arity (k : Kind) : ArityOk (function k) := by cases k <;> apply arityOk_of <;> decide +kernel
private theorem abi (k : Kind) : AbiSigsOk (function k) := by
  constructor
  · constructor
    · cases k <;> decide +kernel
    · intro ext member
      simp only [function,List.mem_singleton] at member
      subst ext
      decide +kernel
  · intro sig member
    cases k <;> simp [indSigs,function,term,table,signature] at member
    all_goals subst sig; constructor <;> decide +kernel

/-- Original-condition functions execute every actual branch form and both
normal TryCall forms. The new whole-step proof establishes the reachable frame
invariant at the real successor state. -/
theorem stock_actual_control_execution_witness (k : Kind) :
    ∃ (f : Clif.Function) (ss : Array (Array Nat)) (env : Clif.Env) (p : Clif.Program) (before after : Clif.State),
      LowerScope f ∧ Dominated f ∧ ArityOk f ∧ AbiSigsOk f ∧ stockSourceTable f = .ok ss ∧
      before.frame.func = f ∧ StateLocated f ss before ∧ Clif.step env p before = .next after ∧
      after.frame.func = f ∧ StateLocated f ss after := by
  have before : StateLocated (function k) (source k) (initial k) := stock_source_initState_located (entered k)
  have after := stock_source_step_located (computed k) before (actual k)
  exact ⟨function k,source k,environment,program k,initial k,one k,scope k,dominated k,arity k,abi k,
    computed k,rfl,before,actual k,rfl,after⟩

private def exn (tagged : Bool) : Clif.Exn := {catches := fun n => tagged && n == 7,payload := []}
private def xenv (tagged : Bool) : Clif.XEnv := {
  extern := fun _ => some (fun _ mem => .unwound (exn tagged) mem),names := ["source_control_callee"],sigOf := fun _ => some signature}
private def tryKind (indirect : Bool) : Kind := if indirect then .tryIndirect else .tryDirect
private def caught (indirect tagged : Bool) : Clif.Frame :=
  {(initial (tryKind indirect)).frame with term := .jump ⟨if tagged then 2 else 3,[]⟩}
private theorem catching (indirect tagged : Bool) :
    Clif.catchIn (initial (tryKind indirect)).frame table (exn tagged) = some (.ok (caught indirect tagged)) := by
  cases indirect <;> cases tagged <;> rfl
private theorem raised (indirect tagged : Bool) :
    Clif.stepX (xenv tagged) (program (tryKind indirect)) ⟨initial (tryKind indirect),[]⟩ =
      .next ⟨{initial (tryKind indirect) with frame := caught indirect tagged},[]⟩ := by
  cases indirect <;> cases tagged <;> rfl
private theorem completed (indirect tagged : Bool) :
    Clif.runWithX (xenv tagged) (program (tryKind indirect)) (function (tryKind indirect)).name
      [argument (tryKind indirect)] memory 4 = .returned [] memory := by
  cases indirect <;> cases tagged <;> rfl

/-- Both actual direct/indirect TryCall forms catch tagged and default handlers
and complete real Clif.runWithX executions. The original table and caught frame
location are obtained by the new roots, with no supplied handler certificate. -/
theorem stock_actual_try_handler_execution_witness (indirect tagged : Bool) :
    ∃ (f : Clif.Function) (ss : Array (Array Nat)) (before : Clif.State) (et : Clif.ExnTable)
      (e : Clif.Exn) (after : Clif.Frame) (env : Clif.XEnv) (p : Clif.Program),
      LowerScope f ∧ Dominated f ∧ ArityOk f ∧ AbiSigsOk f ∧ stockSourceTable f = .ok ss ∧
      before.frame.func = f ∧ StateLocated f ss before ∧ PendingTableLocated f ss before.frame et ∧
      Clif.catchIn before.frame et e = some (.ok after) ∧ FrameLocated f ss after ∧
      Clif.stepX env p ⟨before,[]⟩ = .next ⟨{before with frame := after},[]⟩ ∧
      Clif.runWithX env p f.name [argument (tryKind indirect)] memory 4 = .returned [] memory := by
  let k := tryKind indirect
  have located : StateLocated (function k) (source k) (initial k) := stock_source_initState_located (entered k)
  have actualTry : (∃ fn args,(initial k).frame.term = .tryCall fn args table) ∨
      (∃ callee args,(initial k).frame.term = .tryCallIndirect callee args table) := by
    cases indirect with
    | false => exact .inl ⟨0,[],rfl⟩
    | true => exact .inr ⟨7,[],rfl⟩
  have pending := stock_source_try_table_located located.1 actualTry
  exact ⟨function k,source k,initial k,table,exn tagged,caught indirect tagged,xenv tagged,program k,
    scope k,dominated k,arity k,abi k,computed k,rfl,located,pending,catching indirect tagged,
    stock_source_catchIn_located pending (catching indirect tagged),raised indirect tagged,completed indirect tagged⟩
end Backend.Stock.Proof.SourceExecutionControlWitnessDraft
