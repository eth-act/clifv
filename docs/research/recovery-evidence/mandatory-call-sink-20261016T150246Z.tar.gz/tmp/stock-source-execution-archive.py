from pathlib import Path
import os,json,datetime,hashlib,tarfile,io,subprocess
os.nice(10);root=Path('/home/lee/clifv/.worktrees/driver-proof-resume');os.chdir(root)
r=json.loads(Path('docs/research/stock-source-execution-scratch.json').read_text());previous=json.loads(Path('docs/research/stock-source-call-emission-backup.json').read_text())
remote=subprocess.check_output(['git','ls-remote','origin','refs/heads/'+previous['branch']],text=True).split()[0];assert remote==previous['commit']
old=previous['archive'];assert hashlib.sha256(Path(old['archive']).read_bytes()).hexdigest()==old['sha256']
paths=subprocess.check_output(['git','ls-tree','-r','--name-only',previous['commit']],text=True).splitlines();paths=[p for p in paths if p.startswith('docs/research/recovery-evidence/mandatory-call-sink-') and p.endswith('.tar.gz')];assert len(paths)==1
proc=subprocess.Popen(['git','show',previous['commit']+':'+paths[0]],stdout=subprocess.PIPE);h=hashlib.sha256()
for chunk in iter(lambda:proc.stdout.read(1048576),b''):h.update(chunk)
assert proc.wait()==0 and h.hexdigest()==old['sha256']
chain={'previous_remote_branch':previous['branch'],'previous_remote_commit':previous['commit'],'previous_remote_archive_path':paths[0],'previous_archive_sha256':old['sha256'],'remote_and_local_chain_verified':True};Path('/tmp/stock-source-execution-recovery-chain.json').write_text(json.dumps(chain,indent=2)+'\n')
files=[Path(p) for k in ['new_scratch_sources','new_compiled_modules','new_compiled_logs'] for p in r[k]]
files += [Path(p) for p in ['docs/plans/test-binary-alignment-recovery.md','docs/research/stock-full-goal-current.md','docs/research/stock-source-execution-scratch.json','docs/research/stock-source-execution-scratch.md','docs/research/stock-source-call-emission-backup.json','docs/research/stock-source-call-emission-cleanup.json','docs/research/stock-cfg-preparation-delivery.json','docs/research/stock-per-successor-delivery.json','.lake/build/lib/lean/FV/Clif/Unwind.olean']]
files +=[Path('/tmp',p) for p in ['stock-source-execution-batch.json','stock-source-execution-axioms.lean','stock-source-execution-axioms.log','stock-source-execution-evidence.py','stock-source-execution-archive.py','stock-source-execution-unwind-dependency.log','stock-source-execution-recovery-chain.json','stock-make-executing-call-witness.py','stock-coherent-build-inputs.json','stock-coherent-serial-progress.json','stock-coherent-serial-build.py']]
files=sorted(set(p.resolve() for p in files));assert all(p.exists() for p in files)
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');dest=Path('/home/lee/.clifv-recovery')/(stamp+'-source-execution');dest.mkdir();archive=dest/'checkpoint.tar.gz';captured=[]
with tarfile.open(archive,'w:gz',compresslevel=1) as t:
 for p in files:
  data=p.read_bytes();name=str(p).lstrip('/');meta=tarfile.TarInfo(name);meta.size=len(data);meta.mode=0o644;meta.mtime=int(p.stat().st_mtime);t.addfile(meta,io.BytesIO(data));captured.append({'path':str(p),'member':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with tarfile.open(archive,'r:gz') as t:
 for row in captured:
  data=t.extractfile(row['member']).read();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'],row['path']
r={'utc':stamp,'archive':str(archive),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'members':len(captured),'every_member_verified':True,'recovery_chain':chain,'captured':captured};(dest/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');Path('/tmp/stock-source-execution-archive-result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='captured'}))
