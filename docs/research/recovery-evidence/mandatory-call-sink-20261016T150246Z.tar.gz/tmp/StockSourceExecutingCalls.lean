import StockSourceExecutionCore
namespace Backend.Stock.Proof.SourceExecutingCallsDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open SourceExecutionGraphDraft SourceExecutionCallsDraft SourceExecutionCoreDraft CallSourceCoverageDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000

/-- A real executing statement of the tracked function belongs to a reachable
original block at an actual source index. Frame equality identifies the current
function; no source-position certificate is supplied. -/
theorem stock_source_executing_statement {f : Clif.Function} {source : Array (Array Nat)}
    {fr : Clif.Frame} (located : FrameLocated f source fr) (function : fr.func = f)
    {stm : Clif.Stmt} {rest : List Clif.Stmt} (body : fr.body = stm :: rest) :
    ∃ (bi : Nat) (b : Clif.Block) (j : Nat),f.blocks[bi]? = some b ∧ Prep.Reach source bi ∧ b.body[j]? = some stm := by
  obtain ⟨bi,b,block,reached,⟨pre,parts⟩,control⟩ := located function
  refine ⟨bi,b,pre.length,block,reached,?_⟩
  rw [← parts,body]
  simp

/-- Every source call actually reached from real Clif.initState is an actual
emitted Stock record. Reachability, source position, lowered node, scan and
record/emission metadata are all derived internally from the real execution. -/
theorem stock_lower_executing_source_call_emitted {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f)
    {env : Clif.Env} {p : Clif.Program} {name : String} {args : List Clif.Val} {mem : Clif.Mem}
    {initial current : Clif.State} (entry : Clif.initState p name args mem = .ok initial)
    (execution : RunPrefix env p initial current) (function : current.frame.func = f)
    {stm : Clif.Stmt} {rest : List Clif.Stmt} (body : current.frame.body = stm :: rest)
    (call : (∃ fn xs,stm.inst = .call fn xs) ∨ (∃ sig callee xs,stm.inst = .callIndirect sig callee xs)) :
    ∃ (bi : Nat) (b : Clif.Block) (j : Nat) (event : BlockScanEvent) (record : ScanRecord) (info : IInfo) (step : Step),
      f.blocks[bi]? = some b ∧ b.body[j]? = some stm ∧
      event ∈ result.blockScans.toList ∧ event.block = bi ∧ record ∈ event.output.records ∧
      record.inst = blockStart f bi + j ∧ event.ctx.insts[record.inst]? = some info ∧
      info.clif = some stm.inst ∧ record.output.step = some step ∧ step.decision = .emitted := by
  obtain ⟨source,computed,size,bounds⟩ := stock_blockOrder_sourceTable (stock_lower_order lowered)
  have located := stock_source_runPrefix_located computed (stock_source_initState_located entry) execution
  obtain ⟨bi,b,j,block,reached,statement⟩ := stock_source_executing_statement located.1 function body
  obtain ⟨event,record,info,step,events,current,records,index,slot,clif,recorded,emitted⟩ :=
    stock_lower_reachable_source_call_emitted lowered scope computed reached block statement call
  exact ⟨bi,b,j,event,record,info,step,block,statement,events,current,records,index,slot,clif,recorded,emitted⟩

/-- Actual executed direct/GOT calls fit the actual returned outgoing area
under the original input conditions. The false all-source-block CallsStack
claim and caller-supplied reachability/emission certificates are unnecessary. -/
theorem stock_lower_executing_direct_call_stack {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f) (ssa : (valueDefs f).Nodup) (abi : AbiSigsOk f)
    {env : Clif.Env} {p : Clif.Program} {name : String} {args : List Clif.Val} {mem : Clif.Mem}
    {initial current : Clif.State} (entry : Clif.initState p name args mem = .ok initial)
    (execution : RunPrefix env p initial current) (function : current.frame.func = f)
    {stm : Clif.Stmt} {rest : List Clif.Stmt} (body : current.frame.body = stm :: rest)
    {fn : Nat} {xs : List Nat} (kind : stm.inst = .call fn xs)
    {ext : Clif.ExtFunc} (external : f.extern? fn = some ext) : SigStackOk ext.sig result.code.outgoing := by
  obtain ⟨bi,b,j,event,record,info,step,block,statement,events,current,records,index,slot,clif,recorded,emitted⟩ :=
    stock_lower_executing_source_call_emitted lowered scope entry execution function body (.inl ⟨fn,xs,kind⟩)
  exact CallOriginalOutgoingDraft.stock_lower_original_call_code_stack lowered scope ssa abi events records slot
    (by rw [clif,kind]) external
end Backend.Stock.Proof.SourceExecutingCallsDraft
