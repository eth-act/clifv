import StockSourceExecutionTry
namespace Backend.Stock.Proof.SourceExecutionCoreDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open SourceExecutionGraphDraft SourceExecutionCallsDraft SourceExecutionTryDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
private theorem ofRes_next {α : Type} {r : Clif.Res α} {k : α → Clif.StepResult} {next : Clif.State}
    (run : Clif.StepResult.ofRes r k = .next next) : ∃ a,r = .ok a ∧ k a = .next next := by
  cases r with
  | ok a => exact ⟨a,rfl,run⟩
  | trap c => cases run
  | stuck msg => cases run
private theorem branch {f : Clif.Function} {source : Array (Array Nat)}
    (computed : stockSourceTable f = .ok source) {s next : Clif.State} (located : StateLocated f source s)
    {bc : Clif.BlockCall} (destination : ∃ args,(bc.block,args) ∈ destinations s.frame.term)
    (run : Clif.StepResult.ofRes (Clif.enterBlock s.frame bc) (fun fr => .next {s with frame := fr}) = .next next) :
    StateLocated f source next := by
  obtain ⟨fr,entered,run⟩ := ofRes_next run
  cases run
  exact ⟨stock_source_enterBlock_located computed located.1 destination entered,located.2⟩

/-- Every real successful terminator step preserves original source location,
including normal TryCall continuations, tail calls and returns to callers. -/
theorem stock_source_stepTerm_located {f : Clif.Function} {source : Array (Array Nat)}
    (computed : stockSourceTable f = .ok source) {env : Clif.Env} {p : Clif.Program} {s next : Clif.State}
    (located : StateLocated f source s)
    (run : Clif.stepTerm env p s s.frame.term = .next next) : StateLocated f source next := by
  cases term : s.frame.term with
  | jump bc =>
    simp only [term,Clif.stepTerm] at run
    exact branch computed located ⟨bc.args.map .val,by simp [term,destinations]⟩ run
  | brif c t e =>
    simp only [term,Clif.stepTerm] at run
    obtain ⟨value,read,run⟩ := ofRes_next run
    apply branch computed located ?_ run
    split <;> simp [term,destinations]
  | brTable x d table =>
    simp only [term,Clif.stepTerm] at run
    obtain ⟨value,read,run⟩ := ofRes_next run
    apply branch computed located ?_ run
    cases selected : table[value.toNat]? with
    | none => simp [selected,term,destinations]
    | some bc =>
      refine ⟨bc.args.map .val,?_⟩
      simp only [selected,Option.getD_some,term,destinations,List.mem_map]
      exact ⟨bc,List.mem_cons_of_mem _ (List.mem_of_getElem? selected),rfl⟩
  | ret xs =>
    simp only [term,Clif.stepTerm] at run
    obtain ⟨vals,values,run⟩ := ofRes_next run
    exact stock_source_returnValues_located located.2 run
  | returnCall fn args =>
    simp only [term,Clif.stepTerm] at run
    exact stock_source_stepReturnCall_located located.2 run
  | trap code => simp only [term,Clif.stepTerm] at run; cases run
  | tryCall fn args et =>
    simp only [term,Clif.stepTerm] at run
    exact stock_source_stepTryCall_located located term run
  | tryCallIndirect callee args et =>
    simp only [term,Clif.stepTerm] at run
    exact stock_source_stepTryCallIndirect_located located term run

/-- EVERY real Clif.step next transition preserves reachable original source
locations for the active frame and all suspended callers. No instruction-family,
callee, arity, or checker certificate is added to source acceptance. -/
theorem stock_source_step_located {f : Clif.Function} {source : Array (Array Nat)}
    (computed : stockSourceTable f = .ok source) {env : Clif.Env} {p : Clif.Program} {s next : Clif.State}
    (located : StateLocated f source s) (run : Clif.step env p s = .next next) : StateLocated f source next := by
  classical
  cases body : s.frame.body with
  | nil =>
    rw [Clif.step_term env p s body] at run
    exact stock_source_stepTerm_located computed located run
  | cons stm rest =>
    have resume := stock_source_frame_located_rest located.1 body s.frame.regs
    by_cases direct : ∃ fn args,stm.inst = .call fn args
    · obtain ⟨fn,args,kind⟩ := direct
      unfold Clif.step at run
      simp only [body,kind] at run
      exact stock_source_stepCall_located resume located.2 run
    · by_cases indirect : ∃ sig callee args,stm.inst = .callIndirect sig callee args
      · obtain ⟨sig,callee,args,kind⟩ := indirect
        unfold Clif.step at run
        simp only [body,kind] at run
        exact stock_source_stepCallIndirect_located resume located.2 run
      · rw [Clif.step_inst env p s stm rest body
          (fun fn args h => direct ⟨fn,args,h⟩) (fun sig callee args h => indirect ⟨sig,callee,args,h⟩)] at run
        obtain ⟨⟨vals,mem⟩,evaluated,run⟩ := ofRes_next run
        exact stock_source_continueWith_located resume located.2 run

/-- Real function entry creates the whole active/caller location invariant. -/
theorem stock_source_initState_located {f : Clif.Function} {source : Array (Array Nat)}
    {p : Clif.Program} {name : String} {args : List Clif.Val} {mem : Clif.Mem} {s : Clif.State}
    (run : Clif.initState p name args mem = .ok s) : StateLocated f source s := by
  simp only [Clif.initState,Opt.Res.bind_eq_ok,Opt.Res.ofOption_eq_ok,Opt.Res.pure_eq_ok] at run
  obtain ⟨fn,found,pair,entered,equality⟩ := run
  obtain ⟨fr,mem'⟩ := pair
  cases equality
  exact ⟨stock_source_enterFunc_located entered,fun c member => by cases member⟩

/-- Finite prefixes of the actual unchanged Clif.step relation. This proof
relation records every next transition, including calls and normal TryCall. -/
inductive RunPrefix (env : Clif.Env) (p : Clif.Program) : Clif.State → Clif.State → Prop
  | refl (s : Clif.State) : RunPrefix env p s s
  | next {s s' s'' : Clif.State} : Clif.step env p s = .next s' → RunPrefix env p s' s'' → RunPrefix env p s s''

/-- Reachability is derived for every actual execution prefix from real entry. -/
theorem stock_source_runPrefix_located {f : Clif.Function} {source : Array (Array Nat)}
    (computed : stockSourceTable f = .ok source) {env : Clif.Env} {p : Clif.Program} {s next : Clif.State}
    (located : StateLocated f source s) (run : RunPrefix env p s next) : StateLocated f source next := by
  induction run with
  | refl => exact located
  | next step rest ih => exact ih (stock_source_step_located computed located step)
end Backend.Stock.Proof.SourceExecutionCoreDraft
