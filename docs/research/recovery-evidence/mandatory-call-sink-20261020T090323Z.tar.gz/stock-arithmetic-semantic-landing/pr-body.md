The existing production entry contract leaves related source-slot addresses free. Generalize Stock entry proofs to those source binding facts, retain all executable-enterFunc variants, and add direct actual-Stock preparation/allocation/emission/layout machine consumers. The complete ordinary arithmetic consumer refines every original source outcome without a legacy lowering verdict or caller-selected virtual file. The old CompiledProduction.lowerOk contract remains unchanged.

A real raw Stock function with an unused third parameter and an explicit source slot completes Lean allocation and emission/layout; its compact Stock code is rejected by the legacy lowering validator. The consumer witness supports arbitrary argument values and source-slot addresses under the original ABI activation preconditions. Production activation remains at #336; world/trace and cleanup adapters, runtime/checker/linker/generated-proof wiring and the complete original #140 obligations remain active.

Validation on `823ecbb19e6a1e7ec2708afbdfe7612e91fa5b76` plus receipt-only `4e4487e54a9e259ab70df6594777e95a605954e4`:

- Strict source/import-closure reuse, 21 affected modules and full FV/FVTest/checker-tool build (3052 jobs).
- All 34 audits pass; exact parity for 1144 prior axiom sets/1181 current roots and 18 prior public theorem headers. All 224 core-owned constants standard-only; 30 witness constants depend on one explicitly marked native compiler-data fact.
- Both E2E modes accept 1,159/0 rejected; all 1,150 original and 1,159 prior identities and ordered stages retained. Real verified fv-demo link checks pass.
- All 27 new public roots and complete normal witnesses pass. One bundled MCP check confirms standard compiler roots and the marked witness, no warnings; owned LSP stopped.

Receipt: `docs/research/stock-arithmetic-semantic-author-gates.json`.
