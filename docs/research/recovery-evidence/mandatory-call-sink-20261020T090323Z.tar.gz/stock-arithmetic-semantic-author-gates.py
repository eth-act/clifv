from pathlib import Path
import json,subprocess as sp,os,hashlib,datetime,re,traceback,tomllib
view=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');root=Path('/tmp/stock-arithmetic-semantic-author-gates');root.mkdir(exist_ok=True)
head=sp.check_output(['git','rev-parse','HEAD'],cwd=view,text=True).strip();base='f9e9aad1effc75000e7e1f42dfb79fde77e8dc3e';previous_base=base;logs={}
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(*args):return sp.check_output(['git',*args],cwd=view,text=True).strip()
env=dict(os.environ,FV_MEMCAP='8G',FV_LAKE_CACHE='/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache',LEAN_NUM_THREADS='2',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2');env['PATH']='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:'+env['PATH']
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:8])
def report(state,**kw):
 d=dict(state=state,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=os.getpid(),head=head,base=base,logs=logs,**kw);(root/'progress.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items() if k!='logs'}),flush=True)
def inputs():return {str(p.relative_to(view)):sha(p) for folder in ['FV','FVTest','scripts/audit'] for p in (view/folder).rglob('*.lean')}
frozen=inputs();(root/'inputs.json').write_text(json.dumps(frozen,indent=2)+'\n')
def check():assert git('rev-parse','HEAD')==head and inputs()==frozen,'frozen input/head changed'
def run(name,args,scheduler=False):
 check();log=root/(name+'.log');report('running',phase=name,log=str(log))
 with log.open('w') as f:r=sp.run(args if scheduler else ['scripts/memcap.sh',*args],cwd=view,env=env,stdout=f,stderr=sp.STDOUT)
 assert r.returncode==0,(name,r.returncode,str(log));check();logs[name]={'path':str(log),'sha256':sha(log)}
try:
 check();prior=json.loads(Path('/tmp/stock-entry-abi-author-gates/progress.json').read_text());assert prior['state']=='per_pr_gates_passed'
 landed=json.loads(Path('/tmp/stock-entry-abi-landing/progress.json').read_text());assert landed['state']=='landed_and_integrator_notified' and landed['merge_commit']==previous_base
 git('merge-base','--is-ancestor',previous_base,base);git('merge-base','--is-ancestor',base,head)
 old=json.loads(Path('/tmp/stock-entry-abi-author-gates/inputs.json').read_text())
 upstream=set(git('diff','--name-only',previous_base,base).splitlines());ours=set(git('diff','--name-only',base,head).splitlines())
 assert all(p.startswith(('FV/Backend/Proof/','FV/E2E/','scripts/audit/','docs/')) for p in ours),ours
 changed_prior={p for p,h in old.items() if frozen.get(p)!=h};added=set(frozen)-set(old)
 assert changed_prior<=upstream|ours,(changed_prior-upstream-ours)
 assert added <= upstream|ours,added-upstream-ours
 assert set(old)<=set(frozen),'previous source deleted; reassess reuse'
 for p in (changed_prior|added)&upstream:
  expected=hashlib.sha256(sp.check_output(['git','show',base+':'+p],cwd=view)).hexdigest();assert frozen[p]==expected,p
 deps={};pat=re.compile(r'^(?:public\s+|private\s+|meta\s+)*import\s+(\S+)')
 for folder in ['FV','FVTest']:
  for p in (view/folder).rglob('*.lean'):
   deps[str(p.relative_to(view))[:-5].replace('/','.')]=set(m.group(1) for line in p.read_text().splitlines() if (m:=pat.match(line)))
 def closure(seed):
  result=set(seed)
  while True:
   more={m for m,d in deps.items() if d&result}-result
   if not more:return result
   result|=more
 def mods(paths):return {p[:-5].replace('/','.') for p in paths if p.endswith('.lean') and p.startswith(('FV/','FVTest/'))}
 our_affected=closure(mods(ours));affected=closure(mods(changed_prior|added))
 exes=[e['name'] for e in tomllib.loads((view/'lakefile.toml').read_text()).get('lean_exe',[]) if e.get('root',e['name']) in our_affected]
 assert not exes,(exes,our_affected)
 manifest={'previous_verified_main':previous_base,'current_reconciled_main':base,'previous_source_modules':len(mods(old)),'unchanged_prior_source_and_audit_hashes_preserved':True,'changed_prior_paths_from_verified_upstream_tree':sorted(changed_prior),'new_upstream_modules':sorted(mods(upstream)),'new_entry_modules':sorted(mods(ours)),'affected_modules_to_schedule':sorted(affected),'prior_modules_reused':len(set(deps)-affected),'affected_executables':exes,'E2E_proof_changes':True,'compiler_runtime_input_changes':False,'reuse':'strict source/import closure validation; changed/new proof modules and all affected importers scheduled, then completeFV/FVTest replay'}
 (root/'reuse-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');only=root/'affected-modules.txt';only.write_text('\n'.join(sorted(affected))+'\n')
 run('affected-scheduler',['python3','/tmp/stock-execute-scheduler.py','--budget','16G','--max-jobs','2','--max-cap','16G','--default-cap','8G','--only',str(only),'--out',str(root/'affected-scheduler'),'FV','FVTest'],True)
 run('full-library-replay',['lake','build','FV','FVTest','lean-e2e-check','link-check'])
 run('all-axiom-audits',['python3','scripts/axiom-audit.py','--log-dir',str(root/'axiom-audit')])
 run('all-new-owned',['lake','env','lean','--root=/tmp','/tmp/stock-semantic-all-owned.lean'])
 parity_runtime={}
 def identities(path):
  fs=json.loads(Path(path).read_text())['functions'];answer={(f['file'],f['index'],f['function']):tuple(f['stages']) for f in fs};assert len(answer)==len(fs);return answer
 for label,flags,original in [('e2e',[],'legacy-dead-cleanup-final-e2e-identities.json'),('legacy-e2e',['--no-dead-cleanup'],'legacy-dead-cleanup-final-legacy-e2e-identities.json')]:
  actual=root/(label+'-identities.json');run(label,['lake','exe','lean-e2e-check',*flags,'--identity-report',str(actual)])
  initial=identities(Path('/tmp')/original);prior=identities(Path('/tmp/stock-scalar-author-gates')/(label+'-identities.json'));current=identities(actual)
  assert len(initial)==1150 and len(prior)==1159 and len(current)==1159
  for previous in [initial,prior]:assert previous.keys()<=current.keys() and all(previous[k]==current[k] for k in previous)
  parity_runtime[label]={'original':len(initial),'prior_shipped':len(prior),'current':len(current),'all_original_and_prior_identities_and_ordered_stages_preserved':True,'sha256':sha(actual)}
 (root/'identity-stage-parity.json').write_text(json.dumps(parity_runtime,indent=2)+'\n')
 bundles=sorted((view/'examples/fv-demo/target/fv/plain-leanlink-verified-leanld/bin-check').glob('*/bundle.json'));assert bundles,'verified fv-demo source bundles missing'
 for i,p in enumerate(bundles):run('link-check-'+str(i),['lake','exe','link-check',str(p.parent)])
 def axioms(folder):
  out={}
  for p in Path(folder).glob('*.log'):
   flat=' '.join(p.read_text().split())
   for n,a in re.findall(r"'(.+?)' depends on axioms: \[([^\]]*)\]",flat):out[n]=sorted(x.strip() for x in a.split(',') if x.strip())
   for n in re.findall(r"'(.+?)' does not depend on any axioms",flat):out[n]=[]
  return out
 before=axioms('/tmp/stock-entry-abi-author-gates/axiom-audit');after=axioms(root/'axiom-audit');assert before
 missing=sorted(set(before)-set(after));drift={n:{'before':v,'after':after.get(n)} for n,v in before.items() if n in after and after[n]!=v}
 parity={'previous_roots':len(before),'current_roots':len(after),'missing':missing,'changed_sets':drift,'all_previous_axiom_sets_preserved':not missing and not drift};(root/'axiom-set-parity.json').write_text(json.dumps(parity,indent=2)+'\n');assert parity['all_previous_axiom_sets_preserved'],parity
 report('per_pr_gates_passed',reuse_manifest=manifest,axiom_parity=parity,identity_stage_parity=parity_runtime,next='Fetch/reconcile current main, author squash and notify integrator. Continue runtime/checker/linker/generated-proof integration and next production activation; all original#140 obligations remain active.')
except BaseException as e:report('failed',error=repr(e),traceback=traceback.format_exc());raise
