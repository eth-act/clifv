from pathlib import Path
import subprocess as sp,json,hashlib,datetime,re
view=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');root=Path('/tmp/stock-arithmetic-semantic-landing');root.mkdir(exist_ok=True)
head='457405e49941c219d222b6104d4f0f81e6bcadcb';base='f9e9aad1effc75000e7e1f42dfb79fde77e8dc3e';branch='agent/stock-arithmetic-machine-consumers'
def run(*args):return sp.check_output(args,cwd=view,text=True,stderr=sp.STDOUT).strip()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
gates=Path('/tmp/stock-arithmetic-semantic-author-gates');d=json.loads((gates/'progress.json').read_text())
assert d['state']=='per_pr_gates_passed' and d['head']==head and d['base']==base
assert run('git','rev-parse','HEAD')==head and not run('git','diff','--name-only') and not run('git','diff','--cached','--name-only')
frozen=json.loads((gates/'inputs.json').read_text());actual={str(p.relative_to(view)):sha(p) for folder in ['FV','FVTest','scripts/audit'] for p in (view/folder).rglob('*.lean')};assert frozen==actual
for f in d['logs'].values():assert sha(f['path'])==f['sha256']
assert d['axiom_parity']['all_previous_axiom_sets_preserved']
assert all(x['all_original_and_prior_identities_and_ordered_stages_preserved'] for x in d['identity_stage_parity'].values())
assert 'ENTRY_CORE_STANDARD_ONLY 224; FIXED_WITNESS_CONSTANTS 30' in (gates/'all-new-owned.log').read_text()
run('git','fetch','origin','main');assert run('git','rev-parse','origin/main')==base,'main changed: reconcile before landing'
affected=len(d['reuse_manifest']['affected_modules_to_schedule']);parity=d['axiom_parity'];jobs=re.findall(r'Build completed successfully \((\d+) jobs\)',(gates/'full-library-replay.log').read_text())[-1]
receipt=view/'docs/research/stock-arithmetic-semantic-author-gates.json';assert not receipt.exists();receipt.write_text(json.dumps(d,indent=2)+'\n')
cp=view/'docs/research/stock-arithmetic-semantic-checkpoint.json';c=json.loads(cp.read_text());c['state']='complete direct semantic consumers, nonlegacy artifact witness and full current author gates passed';c['author_gates_receipt']='docs/research/stock-arithmetic-semantic-author-gates.json';cp.write_text(json.dumps(c,indent=2)+'\n')
p=view/'docs/plans/stock-driver-incremental-delivery.md';p.write_text(p.read_text()+f'\nDirect semantic-consumer author gates passed on `{head}`: {affected} affected modules scheduled with exact source/import-closure reuse, full FV/FVTest/checker tools ({jobs} jobs), all 34 audit files, 224 standard-only core constants and 30 witness constants with one explicitly marked fixed native fact. All {parity["previous_roots"]} prior public axiom sets are retained exactly ({parity["current_roots"]} current roots); 18 prior public theorem headers are unchanged. Both E2E modes retain all 1,150 original and 1,159 prior identities and ordered stages, with 1,159 accepted/0 rejected, and real verified fv-demo link checks pass. [Terminal author receipt](../research/stock-arithmetic-semantic-author-gates.json). Next world/trace and cleanup adapters plus actual runtime/checker/linker/generated-proof integration before new activation; all original #140 obligations remain active.\n')
run('git','add','docs/research/stock-arithmetic-semantic-author-gates.json','docs/research/stock-arithmetic-semantic-checkpoint.json','docs/plans/stock-driver-incremental-delivery.md');run('git','diff','--cached','--check');run('git','commit','-m','Record direct Stock semantic consumer author gates')
final=run('git','rev-parse','HEAD');tree=run('git','rev-parse','HEAD^{tree}');run('git','push','origin',branch)
body=root/'pr-body.md';body.write_text(f'''The existing production entry contract leaves related source-slot addresses free. Generalize Stock entry proofs to those source binding facts, retain all executable-enterFunc variants, and add direct actual-Stock preparation/allocation/emission/layout machine consumers. The complete ordinary arithmetic consumer refines every original source outcome without a legacy lowering verdict or caller-selected virtual file. The old CompiledProduction.lowerOk contract remains unchanged.

A real raw Stock function with an unused third parameter and an explicit source slot completes Lean allocation and emission/layout; its compact Stock code is rejected by the legacy lowering validator. The consumer witness supports arbitrary argument values and source-slot addresses under the original ABI activation preconditions. Production activation remains at #336; world/trace and cleanup adapters, runtime/checker/linker/generated-proof wiring and the complete original #140 obligations remain active.

Validation on `{head}` plus receipt-only `{final}`:

- Strict source/import-closure reuse, {affected} affected modules and full FV/FVTest/checker-tool build ({jobs} jobs).
- All 34 audits pass; exact parity for {parity['previous_roots']} prior axiom sets/{parity['current_roots']} current roots and 18 prior public theorem headers. All 224 core-owned constants standard-only; 30 witness constants depend on one explicitly marked native compiler-data fact.
- Both E2E modes accept 1,159/0 rejected; all 1,150 original and 1,159 prior identities and ordered stages retained. Real verified fv-demo link checks pass.
- All 27 new public roots and complete normal witnesses pass. One bundled MCP check confirms standard compiler roots and the marked witness, no warnings; owned LSP stopped.

Receipt: `docs/research/stock-arithmetic-semantic-author-gates.json`.
''')
assert run('git','ls-remote','origin','refs/heads/main').split()[0]==base
out=run('gh','pr','create','--repo','eth-act/clifv','--base','main','--head',branch,'--title','Prove direct Stock arithmetic machine and artifact consumers','--body-file',str(body));urls=re.findall(r'https://github.com/eth-act/clifv/pull/\d+',out);assert len(urls)==1,out
url=urls[0];(root/'progress.json').write_text(json.dumps({'state':'merging','pr':url,'head':final})+'\n');assert run('git','ls-remote','origin','refs/heads/main').split()[0]==base
run('gh','pr','merge',url,'--repo','eth-act/clifv','--squash','--match-head-commit',final)
pr=json.loads(run('gh','pr','view',url,'--repo','eth-act/clifv','--json','number,state,mergeCommit,url'));assert pr['state']=='MERGED';commit=pr['mergeCommit']['oid'];(root/'progress.json').write_text(json.dumps({'state':'merged_verifying','pr':pr,'head':final})+'\n')
run('git','fetch','origin','main');assert run('git','rev-parse',commit+'^{tree}')==tree
comment=root/'integrator.md';comment.write_text(f'@kevaundray Author squash landed #{pr["number"]} as **{commit}**. Exact tree equals validated {head} plus receipt {final}. Please include this actual commit in the immediate continuous main gate.\n\nDirect raw-Stock arithmetic preparation/allocation/emission/layout machine consumers and full ordinary source-outcome refinement. Original ClifEntry/caller-slot domain retained;18oldpublictheoremheaders unchanged; CompiledProduction.lowerOk untouched. Actual rawStock/Leanallocation/layout witness hasunusedarg+explicitSlot and compactlegacycheckerrejects; universal-value/caller-slot consumer witness passes. Per-PR {affected} affected modules, fullFV/FVTest/tools {jobs} jobs, all34audits, exact {parity["previous_roots"]} prior axiom sets/{parity["current_roots"]} current roots,224standardcore/30witnessconstants/oneexplicitfixednativefact. Both1159E2Emodes retain alloriginal1150/prior1159identities+orderedstages; realfv-demo linkchecks pass. Next world/trace/cleanup and actual runtime/checker/linker/generated-proof integration before new activation. Production classes remain #336; full original#140 active. Boundary #140/6287173690.\n')
for issue in ['261','140']:run('gh','issue','comment',issue,'--repo','eth-act/clifv','--body-file',str(comment))
status=json.loads(run('gh','issue','view','44','--repo','eth-act/clifv','--json','body'))['body'];status+='\n\n'+comment.read_text()+f'\nCurrent published branch {branch}/{final}; active. Next terminal evidence backup/cleanup, world/trace/cleanup and runtime/checker/linker/generated-proof integration. UTC '+datetime.datetime.now(datetime.timezone.utc).isoformat()+'\n';(root/'status.md').write_text(status);run('gh','issue','edit','44','--repo','eth-act/clifv','--body-file',str(root/'status.md'))
done={'state':'landed_and_integrator_notified','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pr':pr,'source':head,'receipt':final,'merge_commit':commit,'merge_tree_matches_validated_source_plus_receipt':True};(root/'progress.json').write_text(json.dumps(done,indent=2)+'\n');print(json.dumps(done))
