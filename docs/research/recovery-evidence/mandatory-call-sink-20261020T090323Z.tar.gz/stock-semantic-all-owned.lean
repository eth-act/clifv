import FV.E2E.StockArithmeticArtifactWitness
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let core := #["FV.Backend.Proof.StockSourceEntry", "FV.Backend.Proof.StockEntrySeed", "FV.Backend.Proof.StockEntryABI", "FV.Backend.Proof.StockEntryPrelude", "FV.Backend.Proof.StockArithmeticEntryRefines", "FV.Backend.Proof.StockArithmeticNoTrap", "FV.Backend.Proof.StockPreparedSemantics", "FV.E2E.StockArithmeticSemantics", "FV.E2E.StockArithmeticArtifact"]
  let witnesses := #["FV.E2E.StockArithmeticArtifactWitness"]
  let mut ncore : Nat := 0
  let mut nwitness : Nat := 0
  for (name,_) in env.constants.toList do
    let some i := env.getModuleIdxFor? name | continue
    let owned := env.header.moduleNames[i]!.toString
    unless core.contains owned || witnesses.contains owned do continue
    for ax in ← collectAxioms name do
      if #[``propext,``Classical.choice,``Quot.sound].contains ax then continue
      let permittedNative := ax.toString == "E2E.StockArithmeticArtifactWitness.checks_true._native.native_decide.ax_1"
      unless witnesses.contains owned && permittedNative do
        throwError "disallowed axiom {ax} in {name}"
    if core.contains owned then ncore := ncore+1 else nwitness := nwitness+1
  unless ncore > 0 do throwError "empty core partition"
  unless nwitness > 0 do throwError "empty witness partition"
  logInfo m!"ENTRY_CORE_STANDARD_ONLY {ncore}; FIXED_WITNESS_CONSTANTS {nwitness}"
