import StockSourceUnreservedFlow
import StockSourceRootAliasFrame
import FV.Backend.Proof.StockReservedScanFlow
import FV.Backend.Proof.StockBindingFlow

/-! Actual selected-context emission supplies source alias origins, even with
nonempty exception reservations. Ordered binding is the real emitter's binder. -/
namespace Backend.Stock.Proof.SourceBindingOrdinaryDraft
open SourceUnreservedFlowDraft SourceRootAliasFrameDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option maxRecDepth 4096
attribute [local irreducible] Isle.Aarch64.program

private theorem zip_right {α β : Type} (xs : List α) (ys : List β) {x : α} {y : β}
    (member : (x, y) ∈ xs.zip ys) : y ∈ ys := by
  induction xs generalizing ys with
  | nil => cases member
  | cons a xs ih =>
    cases ys with
    | nil => cases member
    | cons b ys =>
      simp only [List.zip_cons_cons, List.mem_cons] at member
      rcases member with same | member
      · cases same; exact List.mem_cons_self ..
      · exact List.mem_cons_of_mem _ (ih ys member)

private theorem bound_sourceOrigins {f : Clif.Function} {ctx : Ctx}
    {ranges : Array (Nat × Nat)} {initial : State}
    (build : Stock.buildCtx f = .ok (ctx, ranges, initial)) (scope : LowerScope f)
    {ti ii : Nat} (placeholder : ctx.insts[ti]? = some ⟨.op .unit, [], [], none⟩)
    (distinct : ii ≠ ti) (data : V)
    {info : IInfo} {inst : Clif.Inst}
    (source : ctx.insts[ii]? = some info) (original : info.clif = some inst)
    (nonempty : info.results ≠ []) {fuel : Nat} {before root bound : State}
    {rss : List (List Reg)} {trace finalTrace : Array RuleId} {copies : Array MInst}
    (allocation : AllocationLe initial before)
    (run : (applyTerm program
      (Stock.sem { Driver.termCtx ctx ti data with tryRegs := before.tryRegs[ti]! })
      {} fuel T.lower.ret T.lower.id [.inst ii]).run (before, trace) =
        .ok (some (.regsVec rss), root, finalTrace))
    (binding : bindResults { Driver.termCtx ctx ti data with tryRegs := before.tryRegs[ti]! }
      (info.results.zip rss) root = .ok (bound, copies)) :
    bound.base = root.base ∧ ∀ x key target, ctx.valueReg? x = some (.vreg key .int) →
      (bound.alias[key]?).join = some target →
      (before.alias[key]?).join = some target ∨
      (before.base.nextVreg ≤ target ∧ target < bound.base.nextVreg) ∨
        (∃ y, Prov ctx ii y ∧ ctx.valueReg? y = some (.vreg target .int)) := by
  have mapped := buildCtx_mappedInv scope build
  have outputFlow := stock_selected_root_source_flow mapped placeholder distinct data before.tryRegs[ti]! source
    original run rss rfl nonempty
  have origins := stock_bindResults_aliasOrigins
    (fun _ target => (before.base.nextVreg ≤ target ∧ target < root.base.nextVreg) ∨
      (∃ y, Prov ctx ii y ∧ ctx.valueReg? y = some (.vreg target .int)))
    mapped.valueReg (fun x rs member key target _ equal =>
      outputFlow rs (zip_right info.results rss member) target .int equal) binding
  refine ⟨origins.1, ?_⟩
  intro x key target map entry
  rcases origins.2 key target entry with old | output
  · left
    have unchanged := stock_source_root_alias_entry rfl run key
    exact unchanged.symm.trans old
  · right
    simpa only [origins.1] using output

private theorem lower_apply {ctx : Ctx} {ii : Nat} {before after : State}
    {rss : List (List Reg)} {trace : List RuleId}
    (run : Stock.runTerm ctx "lower" [.inst ii] before =
      .ok (some (.regsVec rss), after, trace)) :
    ∃ finalTrace, (applyTerm program (Stock.sem ctx) {} 1000000 T.lower.ret T.lower.id
      [.inst ii]).run (before, #[]) = .ok (some (.regsVec rss), after, finalTrace) := by
  unfold Stock.runTerm Interp.run at run
  rw [program_termByName_lower] at run
  dsimp only at run
  cases applied : (applyTerm program (Stock.sem ctx) {} 1000000 T.lower.ret T.lower.id
      [.inst ii]).run (before, #[]) with
  | error e => simp only [applied, bind, Except.bind] at run; cases run
  | ok result =>
    rcases result with ⟨out, next, fired⟩
    simp only [applied, bind, Except.bind, pure, Except.pure] at run
    cases run
    exact ⟨fired, rfl⟩

/-- The actual selected-context emitter and ordered binder supply each mapped
source alias target's origin. Existing source aliases survive root execution;
new targets are fresh or source-provenanced. -/
theorem stock_selected_emitInstruction_ordinaryOrigins {f : Clif.Function} {ctx : Ctx}
    {ranges : Array (Nat × Nat)} {initial : State}
    (build : Stock.buildCtx f = .ok (ctx, ranges, initial)) (scope : LowerScope f)
    {ti ii : Nat} (placeholder : ctx.insts[ti]? = some ⟨.op .unit, [], [], none⟩)
    (distinct : ii ≠ ti) (data : V)
    {info : IInfo} {inst : Clif.Inst}
    (source : ctx.insts[ii]? = some info) (original : info.clif = some inst)
    (nonempty : info.results ≠ []) {before : State} {emission : Emission}
    (allocation : AllocationLe initial before)
    (emitted : emitInstruction
      { Driver.termCtx ctx ti data with tryRegs := before.tryRegs[ti]! }
      ii before = .ok emission) :
    ∀ x key target, ctx.valueReg? x = some (.vreg key .int) →
      (emission.state.alias[key]?).join = some target →
      (before.alias[key]?).join = some target ∨
      (before.base.nextVreg ≤ target ∧ target < emission.state.base.nextVreg) ∨
        (∃ y, Prov ctx ii y ∧ ctx.valueReg? y = some (.vreg target .int)) := by
  let selected : Ctx := { Driver.termCtx ctx ti data with tryRegs := before.tryRegs[ti]! }
  have infoEq : selected.insts[ii]! = info := by
    change (Driver.termCtx ctx ti data).insts[ii]! = info
    have h : (Driver.termCtx ctx ti data).insts[ii]? = some info := by
      rw [termCtx_insts_ne distinct]; exact source
    simp only [getElem!_def, h]
  change emitInstruction selected ii before = .ok emission at emitted
  unfold emitInstruction at emitted
  rw [infoEq] at emitted
  cases root : Stock.runTerm selected "lower" [.inst ii] before with
  | error e => simp only [root, bind, Except.bind] at emitted; cases emitted
  | ok result =>
    rcases result with ⟨out, next, fired⟩
    simp only [root, bind, Except.bind] at emitted
    cases out with
    | none => cases emitted
    | some out =>
      cases out <;> try (cases emitted)
      rename_i rss
      dsimp only at emitted
      split at emitted
      · cases emitted
      · cases bound : bindResults selected (info.results.zip rss) next with
        | error e => simp only [bound] at emitted; cases emitted
        | ok result =>
          rcases result with ⟨after, copies⟩
          simp only [bound, pure, Except.pure] at emitted
          cases emitted
          obtain ⟨finalTrace, applied⟩ := lower_apply root
          exact (bound_sourceOrigins build scope placeholder distinct data source original nonempty
            allocation applied bound).2

/-- The mapped-source alternative of actual selected emission is available at
an actual source boundary. Reserved targets are excluded by the source-root closure. -/
theorem stock_selected_emitInstruction_ordinaryAvailable {f : Clif.Function} {ctx : Ctx}
    {ranges : Array (Nat × Nat)} {initial : State}
    (build : Stock.buildCtx f = .ok (ctx, ranges, initial)) (scope : LowerScope f)
    (dominated : Dominated f) {ti ii bi j n : Nat}
    (placeholder : ctx.insts[ti]? = some ⟨.op .unit, [], [], none⟩)
    (distinct : ii ≠ ti) (data : V)
    (available : n ∈ availOf f (availIn f ctx) bi j) (definition : ctx.defInst? n = some ii)
    {info : IInfo} {inst : Clif.Inst}
    (source : ctx.insts[ii]? = some info) (original : info.clif = some inst)
    (nonempty : info.results ≠ []) {before : State} {emission : Emission}
    (allocation : AllocationLe initial before)
    (emitted : emitInstruction
      { Driver.termCtx ctx ti data with tryRegs := before.tryRegs[ti]! }
      ii before = .ok emission) :
    ∀ x key target, ctx.valueReg? x = some (.vreg key .int) →
      (emission.state.alias[key]?).join = some target →
      (before.alias[key]?).join = some target ∨
      (before.base.nextVreg ≤ target ∧ target < emission.state.base.nextVreg) ∨
        (∃ y, y ∈ availOf f (availIn f ctx) bi j ∧ ctx.valueReg? y = some (.vreg target .int)) := by
  intro x key target map entry
  rcases stock_selected_emitInstruction_ordinaryOrigins build scope placeholder distinct data source
      original nonempty allocation emitted x key target map entry with old | fresh | mapped
  · exact .inl old
  · exact .inr (.inl fresh)
  · obtain ⟨y, reached, register⟩ := mapped
    exact .inr (.inr ⟨y,
      stock_available_provenance build dominated available definition reached, register⟩)


end Backend.Stock.Proof.SourceBindingOrdinaryDraft
