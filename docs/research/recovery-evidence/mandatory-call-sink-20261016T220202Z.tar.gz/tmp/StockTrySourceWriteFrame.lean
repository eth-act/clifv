import StockSourceReservedDisjoint
import StockTryResultDefsFixed
namespace Backend.Stock.Proof.TrySourceWriteFrameDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open SourceReservedDisjointDraft TryResultDefsFixedDraft TryFinalReturnValuesDraft
open TryRetsTotalDraft TryResultMapDraft TryBranchAbiDraft TrySourceContextDraft TryBranchSelectionDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private theorem lookup_of_layout {slots : Array (List Reg × List Reg)} {i base count : Nat}
    (layout : slots[i]! = (reservedReturns base count,reservedPayloads base count)) :
    slots[i]? = some (reservedReturns base count,reservedPayloads base count) := by
  cases found : slots[i]? with
  | none => simp only [getElem!_def,found] at layout; cases congrArg Prod.snd layout
  | some pair =>
    have same : pair = (reservedReturns base count,reservedPayloads base count) := by
      simpa only [getElem!_def,found] using layout
    rw [same]
private theorem key_reserved (base count j : Nat) (inside : j < max count 2) :
    (.vreg (resultKey base count j) .int) ∈ reservedReturns base count ++ reservedPayloads base count := by
  by_cases returned : j < count
  · apply List.mem_append_left
    exact List.mem_map.mpr ⟨j,List.mem_range.mpr returned,by simp [resultKey,returned]⟩
  · have choices : j = 0 ∨ j = 1 := by omega
    apply List.mem_append_right
    rcases choices with rfl | rfl <;> simp [resultKey,returned,reservedPayloads]
/-- Whole original TryCall selection supplies its SAME actual return helper,
exact defs and canonical reservation base. EVERY source value's final-resolved
register is separate from every actual result/payload definition, and arbitrary
returned writes preserve that source register. No caller disjointness/layout. -/
theorem stock_lower_try_actual_result_source_write_frame {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    (input : Prg.iselInB f = true) {label bi : Nat} {b : Clif.Block}
    (node : result.order.nodes[label]? = some (.original bi)) (block : f.blocks[bi]? = some b)
    {et : Clif.ExnTable} {sig : Clif.Signature} {items : List (Option Nat)}
    (kind : sourceTable b.term = some et) (table : exnTableOpnd f et = .ok (sig,items)) :
    ∃ (source : TryBranchSource f result label bi b) (_selected : TryBranchSelection source)
      (base : Nat) (before : State) (value : V) (after : State),
      result.initial.tryRegs[source.ti]! = (reservedReturns base sig.returns.length,reservedPayloads base sig.returns.length) ∧
      Stock.externCtor source.ctx T.gen_try_call_rets [.op (.sig sig)] before = .ok (value,after) ∧
      value = .op (.callRets (callDefs (resultDefs base sig.returns.length))) ∧
      (∀ j,j < max sig.returns.length 2 → aliasNum result.final.alias (resultKey base sig.returns.length j) = resultKey base sig.returns.length j) ∧
      (∀ x key,result.ctx.valueReg? x = some (.vreg key .int) → ∀ j,j < max sig.returns.length 2 →
        aliasNum result.final.alias key ≠ resultKey base sig.returns.length j) ∧
      (∀ (rho : Nat → CV) (outs : List CV) x key,result.ctx.valueReg? x = some (.vreg key .int) →
        writeV rho ((callDefOps (resultDefs base sig.returns.length)).zip outs) (aliasNum result.final.alias key) =
          rho (aliasNum result.final.alias key)) := by
  obtain ⟨source,selected,base,before,value,after,layout,helper,defs,values⟩ :=
    stock_lower_original_try_actual_result_values lowered scope input node block kind table
  have separate (x key : Nat) (mapped : result.ctx.valueReg? x = some (.vreg key .int))
      (j : Nat) (inside : j < max sig.returns.length 2) : aliasNum result.final.alias key ≠ resultKey base sig.returns.length j :=
    stock_lower_source_reserved_resolved_disjoint lowered scope dominated.ssa mapped (lookup_of_layout layout)
      (key_reserved base sig.returns.length j inside)
  refine ⟨source,selected,base,before,value,after,layout,helper,defs,
    stock_lower_try_result_keys_fixed lowered layout,separate,?_⟩
  intro rho outs x key mapped
  apply writeV_notMem_ctl
  intro member
  obtain ⟨pair,atPair,same⟩ := List.mem_map.mp member
  have operand := (List.of_mem_zip atPair).1
  obtain ⟨definition,atDef,equalOp⟩ := List.mem_map.mp operand
  obtain ⟨j,atIndex,equalDef⟩ := List.mem_map.mp atDef
  have inside := List.mem_range.mp atIndex
  subst definition
  rw [← equalOp] at same
  change resultKey base sig.returns.length j = aliasNum result.final.alias key at same
  exact separate x key mapped j inside same.symm
end Backend.Stock.Proof.TrySourceWriteFrameDraft
