from pathlib import Path
import json,hashlib,re,datetime,tarfile,shutil
root=Path('/home/lee/clifv/.worktrees/driver-proof-resume');docs=root/'docs/research';prefix='stock-source-origin'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
now=datetime.datetime.now(datetime.timezone.utc);stamp=now.strftime('%Y%m%dT%H%M%SZ')
batch=json.loads(Path('/tmp/'+prefix+'-batch.json').read_text());old=json.loads((docs/'stock-source-erase-scratch.json').read_text())
log=Path('/tmp/'+prefix+'-combined-axioms.log').read_text()
sets={m.group(1):sorted(x.strip() for x in m.group(2).split(',') if x.strip()) for m in re.finditer(r"'([^']+)' depends on axioms:\s*\[([^]]*)\]",log)}
for m in re.finditer(r"'([^']+)' does not depend on any axioms",log):sets[m.group(1)]=[]
for n,a in old['normal_audit']['sets'].items():assert sorted(a)==sets[n],n
assert len(sets)==len(old['normal_audit']['sets'])+len(batch['public_roots'])+len(batch['models'])
allowed={'propext','Classical.choice','Quot.sound'}
for n in batch['public_roots']+batch['models']:assert set(sets[n])<=allowed,n
constants=[json.loads(line.split('DELIVERY_CONSTANT ',1)[1]) for line in Path('/tmp/'+prefix+'-all-constants.log').read_text().splitlines() if line.startswith('DELIVERY_CONSTANT ')]
assert constants
for n,a in constants:assert set(a)<=allowed,n
mods={}
for m in batch['modules']:
 p=Path('/tmp')/m;check=json.loads(p.with_suffix('.check.json').read_text());assert check['actual_exit']==0
 rec={}
 for key,ext in [('source','.lean'),('object','.olean'),('log','.log'),('check','.check.json')]:
  f=p.with_suffix(ext);rec[key]=str(f);rec[key+'_sha256']=sha(f)
 for k in ['source','object','log']:assert rec[k+'_sha256']==check[k+'_sha256']
 assert not re.search(r'\b(sorry|admit|axiom|trace_state|native_decide)\b',p.with_suffix('.lean').read_text()),m
 mods[m]=rec
for audit in [prefix+'-combined-axioms',prefix+'-all-constants']:
 p=Path('/tmp')/audit;check=json.loads(p.with_suffix('.check.json').read_text());assert check['actual_exit']==0
 for k,ext in [('source','.lean'),('object','.olean'),('log','.log')]:assert sha(p.with_suffix(ext))==check[k+'_sha256']
prior={}
for name in ['source-execution-x','try-source','try-context','try-rule','try-rets','try-reservation','try-outgoing','try-values','try-emitted','try-machine','try-got','try-indirect','try-rename','try-resolved','try-gap','try-got-rename','try-normal-frame','try-metadata','source-index','try-normal-vector','try-critical-normal','source-erase']:
 d=json.loads((docs/f'stock-{name}-scratch.json').read_text())
 for m,rec in d['modules'].items():
  for k in ['source','object','log']:assert sha(rec[k])==rec[k+'_sha256'],(m,k)
  prior[m]=rec
freeze=json.loads(Path('/tmp/stock-coherent-build-inputs.json').read_text())
for group in ['source_sha256','validation_script_sha256']:
 for p,h in freeze[group].items():assert sha(root/p)==h,p
progress=json.loads(Path('/tmp/stock-pr246-gates-progress.json').read_text());progress.pop('completed_phases',None)
remaining=list(old['remaining_checklist']);remaining.append({'requirement':'Actual source aliases and TryCall result-write noninterference','state':'Kernel proved all-key statement-root alias frame; ordinary-only actual selected binder/emitter and retained-record/final-array origins with/without inherited entries and source availability. For ANY original mapped source and ANY finite final-alias chase, output is another mapped source or an unaliased fresh endpoint above initial allocation. Therefore final-resolved source registers avoid EVERY initial reserved return/payload, not only the active slot. The whole actual TryCall RHS helper internally provides canonical layout, exact resultDefs, fixed result keys, universal source-vs-result definition separation and actual writeV result-write framing for arbitrary outs. No caller source-path/reservation/disjointness/helper certificate. Complete near/GOT/indirect full pipelines, actual source0 mapping and full source17; complete source9 all-key root alias frame; complete direct-call9 pipeline with actual nonempty retained final alias and all four ordinary-only record classifications. Call-prefix machine framing, actual stopped-call/world/value composition, real normal parameter copies/source continuation, exception semantics and all remaining whole-driver/production obligations still OPEN.'})
counts={'modules':len(mods),'public_roots':len(batch['public_roots']),'models':len(batch['models']),'combined_roots_models':len(sets),'previous_preserved':len(old['normal_audit']['sets']),'all_new_module_constants':len(constants),'previous_modules_hashes_preserved':len(prior)}
receipt={'utc':now.isoformat(),'goal':'Original full #140 ACTIVE/INCOMPLETE; production LEGACY','scope':'Scratch-only additive Stock proofs, not coherent integration or merge-ready','delivery_target':'roughly eight substantive validated squash merges/day; coherent queue priority, backup and cleanup','modules':mods,'public_roots':batch['public_roots'],'models':batch['models'],'counts':counts,'normal_audit':{'path':'/tmp/'+prefix+'-combined-axioms.log','sha256':sha('/tmp/'+prefix+'-combined-axioms.log'),'sets':sets},'all_constant_audit':{'path':'/tmp/'+prefix+'-all-constants.log','sha256':sha('/tmp/'+prefix+'-all-constants.log'),'all_standard_only':True,'count':len(constants)},'previous_modules_hashes_preserved':list(prior),'canonical2246_source_and_script_freeze_preserved':True,'MCP':'Deferred until coherent integration; no new calls','active_exact_PR246_validation':progress,'remaining_checklist':remaining}
(docs/(prefix+'-scratch.json')).write_text(json.dumps(receipt,indent=2)+'\n')
text=f'''Actual source alias closure and reserved result-write framing — {now.isoformat()}

{len(mods)}scratch modules/{len(batch['public_roots'])}public roots/{len(batch['models'])}model pass actual8GiB kernel checks. The {len(sets)}-root/model cumulative audit preserves all635prior exact axiom sets. All{len(constants)}new-module constants, including private/generated binding/core/traversal/chase/witness helpers, use only standard axioms. All{len(prior)}prior source/object/log hashes and frozen2246canonical sources/49scripts unchanged. Previous turn PROGRESS: exact source-root reservation erasure/strong root/selected/availability origins, full source9 pipeline,635audit/305constants,054aad3 remote backup/2.8GBcleanup.

The actual source-root interpreter cannot change ANY alias entry, including reserved payload keys: apply the actual full-run erasure to the existing constructor alias frame with empty reservations. The real selected emitter and ordered binder now yield only inherited aliases, actual fresh allocation intervals or mapped source operands. Retained emitted scan records and their actual final-array alias entries inherit this stronger classification; source-availability and internally derived no-inherited variants preserve all original LowerScope/SSA/Dominated and record observations. Old public variants remain unchanged; no new accepted program certificate.

For ANY original mapped source, each final alias edge targets a mapped source or an actual fresh interval from a producing retained record. Whole-driver initial-frontier and final-array bounds make a fresh target unaliased and above ALL initial reserved return/payload registers. Induction over ANY finite actual chase stays in this source/fresh classification. The actual final size+1 resolver therefore avoids EVERY preallocated reserved return/payload, including other slots. No caller path, endpoint, source availability or disjointness hypothesis is needed. This removes the conservative reserved-output branch throughout source alias closure.

The whole actual TryCall source factory internally selects the SAME real RHS gen_try_call_rets at its actual intermediate state, canonical reservation layout/base and exact resultDefs. Every resultKey is in that actual return/payload reservation (including counts0/1 and the one-return base+2 hole); existing actual final-key fixedness composes with the new universal source separation. For ANY original source mapping and ANY returned outs, the actual result writeV preserves the source final-resolved register. The helper/layout/disjointness are conclusions derived from original lowering/scope/Dominated/input/source table facts, never caller certificates.

Complete near/GOT/true-indirect compiler→prepare→forced checkedfallback→checker→physical/source17 witnesses instantiate real source0→192, SAME actual RHS helper/defs and actual result-write frame for all two physical outputs. Complete same-source direct-call9 compiler/prepare/checker/physical pipeline retains an actual emitted source record and nonempty final alias; all four ordinary-only origin/availability variants pass. Complete source9 pipeline instantiates the all-key root alias frame with changed terminator/nonempty reservations. Cached source observations and full three-form pipelines reused; new one-block direct-call physical fixture checked once at8GiB.

These close final source/reserved register separation and the ACTUAL RESULT-WRITE frame. They DO NOT yet compose call-prefix machine effects, returned write frame with actual stopped-run/world/source-value agreement, real normal parameter copies or source continuation. Next compose those existing actual all-three final-renamed branch receipts, GOT fresh-target frame and inherited live .val values with this new universal result-write frame. Exact shared payload endpoints/exception machine semantics, zero-return/sret/x8/width/handler/Try-critical matrix, uncovered families/effects/sinking/source/block/whole-driver simulation AND completeness, original-input context/visitor/static/checker/fallback/physical totality, coherent integration/public/private/compiler/MCP/full/crates/runtime/encoder/BOTH E2E identity-stage parity, production compiler/checker/linker/generated consumers and fresh COMPLETE comparison remain mandatory. Production LEGACY. Shared S10/FP interfaces remain @kevaundray boundary.

Same live delivery3247835/exclusive cache lease and held canonical1233457 retained; exact246gate advanced965→968/1415 this turn. Main789152e includes248 FP machine/encoder change plus250/251/253/254 consumers/cache. Preserve receipts, reconcile CURRENTmain and rerun actual-head affected audits and ALL full gates before dependent squash246→247. Target8substantive validated merges/day. No merge/new worktree/MCP/heavy retry/gate restart. Hashed evidence/full checklist: {prefix}-scratch.json.
'''

(docs/(prefix+'-scratch.md')).write_text(text);plan=root/'docs/plans/test-binary-alignment-recovery.md';plan.write_text(plan.read_text()+'\n\n'+text)
files=[]
for rec in mods.values():files.extend(Path(rec[k]) for k in ['source','object','log','check'])
for name in [prefix+'-combined-axioms',prefix+'-all-constants']:
 for ext in ['.lean','.log','.olean','.check.json']:files.append(Path('/tmp')/(name+ext))
for p in ['/tmp/'+prefix+'-batch.json','/tmp/stock-try-rule-inputs.json','/tmp/stock-try-reservation-check.py','/tmp/'+prefix+'-close.py','/tmp/'+prefix+'-make-audit.py','/tmp/'+prefix+'-restore.py','/tmp/'+prefix+'-status44-start.md','/tmp/'+prefix+'-status52.json','/tmp/'+prefix+'-status71.json','/tmp/'+prefix+'-task140.json','/tmp/stock-source-origin-issues.json']:
 if Path(p).exists():files.append(Path(p))
files.extend([docs/(prefix+'-scratch.json'),docs/(prefix+'-scratch.md'),docs/'stock-delivery-main-drift.json',plan])
archive=Path('/home/lee/.clifv-recovery')/(stamp+'-source-origin')/'checkpoint.tar.gz';archive.parent.mkdir(parents=True)
with tarfile.open(archive,'w:gz',compresslevel=1) as t:
 for p in files:t.add(p,arcname=str(p).lstrip('/'),recursive=False)
with tarfile.open(archive,'r:gz') as t:
 for p in files:assert t.extractfile(str(p).lstrip('/')).read()==p.read_bytes(),p
snapshot=Path('/tmp/stock-try-rule-inputs');size=sum(p.stat().st_size for p in snapshot.rglob('*') if p.is_file());shutil.rmtree(snapshot)
backup={'utc':now.isoformat(),'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(files),'all_members_byte_verified':True,'previous_remote_backup':json.loads((docs/'stock-source-erase-backup.json').read_text())['remote'],'cleanup':{'duplicate_dependency_snapshot_removed':True,'bytes_reclaimed':size,'unique_sources_objects_logs_checks_audits_preserved':True,'one_shared_warm_cache_retained':True,'other_projects_touched':False,'free_bytes':shutil.disk_usage(root).free}}
(docs/(prefix+'-backup.json')).write_text(json.dumps(backup,indent=2)+'\n');Path('/tmp/'+prefix+'-archive-path').write_text(str(archive))
print(json.dumps({'counts':counts,'archive':str(archive),'cleanup':backup['cleanup'],'gate':progress},indent=2))
