import FV.Backend.Proof.StockCriticalSplit
import FV.Backend.Proof.PerEdgeSpillEntryFixture

namespace Backend.Stock.Proof.SourceOriginFixtureDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Backend.Proof.PerEdgeSpill
set_option maxRecDepth 20000
set_option maxHeartbeats 16000000
def function : Clif.Function := {
  name := "emitted_record_alias"
  sig := {returns := [⟨.i8,.none,.normal⟩],callConv := some .systemV}
  externs := [(0,{name := "callee",sig := {returns := [⟨.i8,.none,.normal⟩],callConv := some .systemV}})]
  blocks := [{id := 0,body := [⟨[0],.call 0 []⟩],term := .ret [0]}] }
private def pipeline  : Except String (Result × EdgeVCode × RFunc × AFunc) := do
  let result ← Stock.lower function
  let p ← prepareAt result.code result.edgeArgs
  let rf ← allocResultAt p.code p.edges (.error "force indexed split witness")
  let af ← lowerRFunc p.code rf
  pure (result,p,rf,af)
private theorem observed  : (pipeline).isOk = true := by decide +kernel
private theorem scope  : LowerScope function := by
  apply lowerScope_of <;> decide +kernel
private theorem arity  : ArityOk function := by
  apply arityOk_of <;> decide +kernel

structure Output  where
  result : Result
  prepared : EdgeVCode
  rf : RFunc
  af : AFunc
  lowered : Stock.lower function = .ok result
  scope : LowerScope function
  arity : ArityOk function
  prepare : prepareAt result.code result.edgeArgs = .ok prepared
  fallback : rf = spillAllocAt prepared.code prepared.edges
  accepted : checkAllocAt prepared.code prepared.edges rf = .ok ()
  physical : lowerRFunc prepared.code rf = .ok af

/-- Complete source-constant compiler, preparation, checked fallback and physical pipeline. -/
theorem stock_source_origin_fixture  : Nonempty (Output) := by
  have actual := observed
  cases run : pipeline with
  | error err => simp only [run,Except.isOk] at actual; cases actual
  | ok q =>
    unfold pipeline at run
    obtain ⟨result,lowered,h⟩ := Except.bind_ok run
    obtain ⟨p,prepare,h⟩ := Except.bind_ok h
    obtain ⟨rf,selected,h⟩ := Except.bind_ok h
    obtain ⟨af,physical,h⟩ := Except.bind_ok h
    cases h
    have accepted := PerEdge.allocResultAt_checked selected
    have fallback : rf = spillAllocAt p.code p.edges := by
      unfold allocResultAt checkedSpillAt at selected
      simp only [bind,Except.bind] at selected
      split at selected <;> cases selected
      rfl
    exact ⟨⟨result,p,rf,af,lowered,scope,arity,prepare,fallback,accepted,physical⟩⟩

end Backend.Stock.Proof.SourceOriginFixtureDraft
