import StockTrySourceWriteFrame
import StockTryEmittedWitness
namespace Backend.Stock.Proof.TrySourceWriteWitnessDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open TryEmittedWitnessDraft (Kind)
open TrySourceWriteFrameDraft TrySourceContextDraft TryBranchSelectionDraft TryBranchAbiDraft
open TryRetsTotalDraft TryResultMapDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private def function : Kind → Clif.Function
  | .near => TryNearFixtureDraft.function false
  | .got => SpillEntryFixture.function false
  | .indirect => SpillEntryFixture.function true
private def entry (k : Kind) := (function k).blocks[0]!
private def table : Clif.ExnTable := {
  sig := 0,normal := ⟨1,[.ret 0,.val 0]⟩,items := [.tag 7 ⟨2,[.exn 0,.exn 1,.val 0]⟩] }
private structure Fixture (k : Kind) where
  result : Result
  prepared : EdgeVCode
  rf : RFunc
  af : AFunc
  lowered : Stock.lower (function k) = .ok result
  scope : LowerScope (function k)
  dominated : Dominated (function k)
  arity : ArityOk (function k)
  prepare : prepareAt result.code result.edgeArgs = .ok prepared
  fallback : rf = spillAllocAt prepared.code prepared.edges
  accepted : checkAllocAt prepared.code prepared.edges rf = .ok ()
  physical : lowerRFunc prepared.code rf = .ok af
private theorem fixture (k : Kind) : Nonempty (Fixture k) := by
  cases k with
  | near =>
    obtain ⟨out⟩ := TryNearFixtureDraft.stock_near_try_fixture
    exact ⟨⟨out.result,out.prepared,out.rf,out.af,out.lowered,out.scope,out.dominated,out.arity,
      out.prepare,out.fallback,out.accepted,out.physical⟩⟩
  | got =>
    obtain ⟨out⟩ := SpillEntryFixture.try_fixture false
    exact ⟨⟨out.result,out.prepared,out.rf,out.af,out.lowered,out.scope,out.dominated,out.arity,
      out.prepare,out.fallback,out.accepted,out.physical⟩⟩
  | indirect =>
    obtain ⟨out⟩ := SpillEntryFixture.try_fixture true
    exact ⟨⟨out.result,out.prepared,out.rf,out.af,out.lowered,out.scope,out.dominated,out.arity,
      out.prepare,out.fallback,out.accepted,out.physical⟩⟩
private theorem order (k : Kind) : blockOrder (function k) = .ok {
    nodes := #[.original 0,.original 1,.original 2],successors := #[#[2,1],#[],#[]]} := by cases k <;> cbv

private def environment (k : Kind) : Clif.Env := {
  extern := fun _ => some (fun _ cm => .returned [⟨.i64,17⟩] cm),names := ["callee"],sigOf := fun _ => some (function k).sig }
private def memory : Clif.Mem := {Clif.Mem.empty with symbols := fun name => if name = "callee" then some 4096 else none}
private def built (k : Kind) : Ctx × Array (Nat × Nat) × State :=
  (Stock.buildCtx (function k)).toOption.getD (sinkCtx,#[],sinkState)
private theorem built_ok (k : Kind) : Stock.buildCtx (function k) = .ok (built k) := by cases k <;> rfl
private theorem built_context {f : Clif.Function} {result : Result} (run : Stock.lower f = .ok result) :
    ∃ ranges,Stock.buildCtx f = .ok (result.ctx,ranges,result.initial) := by
  unfold Stock.lower at run
  dsimp only at run
  repeat' first
    | (solve | cases run)
    | simp only [bind,Except.bind,pure,Except.pure] at run
    | split at run
  cases run
  rename_i _ built hbuild _ order horder _ driver hdriver
  exact ⟨_,hbuild⟩
/-- Complete near/GOT/indirect pipelines have a real live source0 mapping and
actual nonempty reserved result writes. All such writes preserve its resolved
register; the original full source execution still returns17. -/
theorem stock_complete_try_source_reserved_write_frame_witness (k : Kind) :
    ∃ (out : Fixture k) (source : TryBranchSource (function k) out.result 0 0 (entry k))
      (_selected : TryBranchSelection source) (base : Nat) (before : State) (value : V) (after : State),
      LowerScope (function k) ∧ Dominated (function k) ∧ ArityOk (function k) ∧
      Stock.lower (function k) = .ok out.result ∧ prepareAt out.result.code out.result.edgeArgs = .ok out.prepared ∧
      out.rf = spillAllocAt out.prepared.code out.prepared.edges ∧
      checkAllocAt out.prepared.code out.prepared.edges out.rf = .ok () ∧ lowerRFunc out.prepared.code out.rf = .ok out.af ∧
      out.result.ctx.valueReg? 0 = some (.vreg 192 .int) ∧
      out.result.initial.tryRegs[source.ti]! = (reservedReturns base (function k).sig.returns.length,reservedPayloads base (function k).sig.returns.length) ∧
      Stock.externCtor source.ctx T.gen_try_call_rets [.op (.sig (function k).sig)] before = .ok (value,after) ∧
      value = .op (.callRets (callDefs (resultDefs base (function k).sig.returns.length))) ∧
      (∀ j,j < 2 → aliasNum out.result.final.alias 192 ≠ resultKey base (function k).sig.returns.length j) ∧
      (∀ (rho : Nat → CV) (outs : List CV),
        writeV rho ((callDefOps (resultDefs base (function k).sig.returns.length)).zip outs) (aliasNum out.result.final.alias 192) =
          rho (aliasNum out.result.final.alias 192)) ∧
      Clif.runWith (environment k) {funcs := [function k]} (function k).name [] memory 6 = .returned [⟨.i64,17⟩] memory := by
  obtain ⟨out⟩ := fixture k
  have sameOrder := Except.ok.inj ((stock_lower_order out.lowered).symm.trans (order k))
  have node : out.result.order.nodes[0]? = some (.original 0) := by rw [sameOrder]; rfl
  have block : (function k).blocks[0]? = some (entry k) := by cases k <;> rfl
  have input : Prg.iselInB (function k) = true := by cases k <;> decide +kernel
  have kind : sourceTable (entry k).term = some table := by cases k <;> rfl
  have decoded : exnTableOpnd (function k) table = .ok ((function k).sig,[some 7]) := by cases k <;> rfl
  obtain ⟨ranges,build⟩ := built_context out.lowered
  have ctxEq := congrArg Prod.fst (Except.ok.inj (build.symm.trans (built_ok k)))
  change out.result.ctx = (built k).1 at ctxEq
  have live : out.result.ctx.valueReg? 0 = some (.vreg 192 .int) := by rw [ctxEq]; cases k <;> rfl
  obtain ⟨source,selected,base,before,value,after,layout,helper,defs,fixed,separate,frame⟩ :=
    stock_lower_try_actual_result_source_write_frame out.lowered out.scope out.dominated input node block kind decoded
  refine ⟨out,source,selected,base,before,value,after,out.scope,out.dominated,out.arity,out.lowered,
    out.prepare,out.fallback,out.accepted,out.physical,live,layout,helper,defs,?_,(fun rho outs => frame rho outs 0 192 live),?_⟩
  · intro j inside
    apply separate 0 192 live j
    cases k <;> exact inside
  · cases k <;> rfl
end Backend.Stock.Proof.TrySourceWriteWitnessDraft
