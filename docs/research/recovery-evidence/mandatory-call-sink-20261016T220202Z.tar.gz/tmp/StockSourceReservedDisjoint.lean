import StockSourceRecordedOrdinary
import FV.Backend.Proof.StockSourceAliasRecords
namespace Backend.Stock.Proof.SourceReservedDisjointDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open SourceRecordedOrdinaryDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
attribute [local irreducible] Isle.Aarch64.program
private theorem built_context {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) :
    ∃ ranges,Stock.buildCtx f = .ok (result.ctx,ranges,result.initial) := by
  unfold Stock.lower at run
  dsimp only at run
  repeat' first
    | (solve | cases run)
    | simp only [bind,Except.bind,pure,Except.pure] at run
    | split at run
  cases run
  rename_i _ built hbuild _ order horder _ driver hdriver
  exact ⟨_,hbuild⟩
private theorem ordinary_target {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (ssa : (valueDefs f).Nodup)
    {x key target : Nat} (mapped : result.ctx.valueReg? x = some (.vreg key .int))
    (entry : (result.final.alias[key]?).join = some target) :
    (result.initial.base.nextVreg ≤ target ∧ (result.final.alias[target]?).join = none) ∨
      ∃ y,result.ctx.valueReg? y = some (.vreg target .int) := by
  obtain ⟨event,record,step,info,inst,eventMem,recordMem,recorded,emitted,source,original,defines,installed⟩ :=
    stock_lower_source_alias_emitted_record run scope ssa mapped entry
  rcases stock_lower_emitted_record_finalOrdinaryOrigins_noInherited run scope
      (fun h => scope.nonempty (List.length_eq_zero_iff.mp h)) ssa eventMem recordMem recorded emitted
      source original defines mapped target entry with fresh | ⟨y,reached,register⟩
  · have initial := stock_lower_blockScanInitialFrontier run event eventMem record recordMem
    have bound := stock_lower_blockScanAliasBounds run event eventMem record recordMem
    have normal : (scanState record.input record.inst).base.nextVreg = record.input.base.nextVreg := by
      unfold scanState; dsimp only; split <;> rfl
    rw [normal] at bound
    exact .inl ⟨by omega,by rw [Array.getElem?_eq_none (by omega : result.final.alias.size ≤ target)]; rfl⟩
  · exact .inr ⟨y,register⟩
/-- Every finite actual source-alias chase stays on a mapped source or reaches
an unaliased fresh endpoint above every preallocated exception reservation. -/
theorem stock_lower_source_chase_ordinary {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (ssa : (valueDefs f).Nodup)
    (fuel : Nat) {x key : Nat} (mapped : result.ctx.valueReg? x = some (.vreg key .int)) :
    (result.initial.base.nextVreg ≤ chaseF (fun k => (result.final.alias[k]?).join) fuel key ∧
      (result.final.alias[chaseF (fun k => (result.final.alias[k]?).join) fuel key]?).join = none) ∨
      ∃ y,result.ctx.valueReg? y = some (.vreg (chaseF (fun k => (result.final.alias[k]?).join) fuel key) .int) := by
  induction fuel generalizing x key with
  | zero => exact .inr ⟨x,mapped⟩
  | succ fuel ih =>
    cases entry : (result.final.alias[key]?).join with
    | none => simpa only [chaseF,entry] using (Or.inr ⟨x,mapped⟩ :
        (result.initial.base.nextVreg ≤ key ∧ (result.final.alias[key]?).join = none) ∨
          ∃ y,result.ctx.valueReg? y = some (.vreg key .int))
    | some target =>
      simp only [chaseF,entry]
      rcases ordinary_target run scope ssa mapped entry with ⟨above,terminal⟩ | ⟨y,register⟩
      · rw [chaseF_none terminal]
        exact .inl ⟨above,terminal⟩
      · exact ih register
/-- Original source mappings remain disjoint from EVERY reserved return and
payload after actual final resolution. No caller path, alias-origin, available
value or disjointness certificate is introduced. -/
theorem stock_lower_source_reserved_resolved_disjoint {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (ssa : (valueDefs f).Nodup)
    {x key slot reserved : Nat} {rs : List Reg × List Reg}
    (mapped : result.ctx.valueReg? x = some (.vreg key .int))
    (lookup : result.initial.tryRegs[slot]? = some rs)
    (member : (.vreg reserved .int) ∈ rs.1 ++ rs.2) :
    aliasNum result.final.alias key ≠ reserved := by
  obtain ⟨ranges,build⟩ := built_context run
  have classified := stock_lower_source_chase_ordinary run scope ssa (result.final.alias.size+1) mapped
  change (result.initial.base.nextVreg ≤ aliasNum result.final.alias key ∧
      (result.final.alias[aliasNum result.final.alias key]?).join = none) ∨
      (∃ y,result.ctx.valueReg? y = some (.vreg (aliasNum result.final.alias key) .int)) at classified
  intro same
  rw [same] at classified
  rcases classified with ⟨above,terminal⟩ | ⟨y,register⟩
  · obtain ⟨n,equal,below⟩ := buildCtx_reservedBelow build slot rs lookup (.vreg reserved .int) member
    cases equal
    omega
  · exact buildCtx_valueReservedDisjoint build y (.vreg reserved .int) register slot rs lookup
      (.vreg reserved .int) member rfl
end Backend.Stock.Proof.SourceReservedDisjointDraft
