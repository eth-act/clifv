import StockSourceErasure
import FV.Backend.Proof.StockAliasWrites
namespace Backend.Stock.Proof.SourceRootAliasFrameDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open SourceErasureDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
/-- Actual ordinary-root interpretation cannot install ANY alias, including on
reserved payload keys: erasure is derived from the checked source-root closure. -/
theorem stock_source_root_alias_entry {ctx : Ctx} {cfg : Config}
    (overlap : cfg.checkOverlap = false) {fuel : Nat} {args : List V}
    {before after : State} {out : Option V} {trace finalTrace : Array RuleId}
    (run : (applyTerm program (Stock.sem ctx) cfg fuel T.lower.ret T.lower.id args).run
      (before,trace) = .ok (out,after,finalTrace)) (key : Nat) :
    (after.alias[key]?).join = (before.alias[key]?).join := by
  have same := stock_source_root_reservations_irrelevant ctx cfg overlap fuel args before trace
  have erasedRun := same.symm.trans run
  exact stock_apply_aliasEntry (ctx := {ctx with tryRegs := ([],[])})
    (by intro r member; cases member) erasedRun
end Backend.Stock.Proof.SourceRootAliasFrameDraft
