import StockSourceRecordedOrdinary
import StockSourceOriginFixture
import FV.Backend.Proof.StockRecordedFlow
namespace Backend.Stock.Proof.SourceRecordedOrdinaryWitnessDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open SourceRecordedOrdinaryDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private def info := infoOf SourceOriginFixtureDraft.function ⟨[0],.call 0 []⟩
private def env : Clif.Env := {extern := fun _ => some (fun _ m => .returned [⟨.i8,9⟩] m)}
/-- All successful stages and an actual nonempty final source alias inhabit
ordinary-only retained-record classification and its availability variants. -/
theorem stock_complete_recorded_ordinary_origins_witness :
    ∃ (out : SourceOriginFixtureDraft.Output) (event : BlockScanEvent) (record : ScanRecord) (step : Step) (target : Nat),
      LowerScope SourceOriginFixtureDraft.function ∧ Dominated SourceOriginFixtureDraft.function ∧ ArityOk SourceOriginFixtureDraft.function ∧
      Stock.lower SourceOriginFixtureDraft.function = .ok out.result ∧
      prepareAt out.result.code out.result.edgeArgs = .ok out.prepared ∧ out.rf = spillAllocAt out.prepared.code out.prepared.edges ∧
      checkAllocAt out.prepared.code out.prepared.edges out.rf = .ok () ∧ lowerRFunc out.prepared.code out.rf = .ok out.af ∧
      event ∈ out.result.blockScans.toList ∧ record ∈ event.output.records ∧ record.inst = 0 ∧
      record.output.step = some step ∧ step.decision = .emitted ∧ out.result.ctx.insts[record.inst]? = some info ∧
      out.result.ctx.valueReg? 0 = some (.vreg 192 .int) ∧ out.result.ctx.defInst? 0 = some record.inst ∧
      (out.result.final.alias[192]?).join = some target ∧
      ((record.input.alias[192]?).join = some target ∨
        (record.input.base.nextVreg ≤ target ∧ target < record.output.state.base.nextVreg) ∨
        ∃ y,Prov out.result.ctx record.inst y ∧ out.result.ctx.valueReg? y = some (.vreg target .int)) ∧
      ((record.input.base.nextVreg ≤ target ∧ target < record.output.state.base.nextVreg) ∨
        ∃ y,Prov out.result.ctx record.inst y ∧ out.result.ctx.valueReg? y = some (.vreg target .int)) ∧
      ((record.input.alias[192]?).join = some target ∨
        (record.input.base.nextVreg ≤ target ∧ target < record.output.state.base.nextVreg) ∨
        ∃ y,y ∈ availOf SourceOriginFixtureDraft.function (availIn SourceOriginFixtureDraft.function out.result.ctx) 0 1 ∧
          out.result.ctx.valueReg? y = some (.vreg target .int)) ∧
      ((record.input.base.nextVreg ≤ target ∧ target < record.output.state.base.nextVreg) ∨
        ∃ y,y ∈ availOf SourceOriginFixtureDraft.function (availIn SourceOriginFixtureDraft.function out.result.ctx) 0 1 ∧
          out.result.ctx.valueReg? y = some (.vreg target .int)) ∧
      Clif.runWith env {funcs := [SourceOriginFixtureDraft.function]} SourceOriginFixtureDraft.function.name [] Clif.Mem.empty 3 =
        .returned [⟨.i8,9⟩] Clif.Mem.empty := by
  obtain ⟨out⟩ := SourceOriginFixtureDraft.stock_source_origin_fixture
  obtain ⟨result,event,record,step,target,scope,dominated,nonempty,actual,eventMem,recordMem,which,recorded,emitted,
    source,mapped,definition,entry,old⟩ := stock_lower_emitted_record_finalAliasOrigins_witness
  have same : result = out.result := Except.ok.inj (actual.symm.trans out.lowered)
  subst result
  have available : (0 : Nat) ∈ availOf SourceOriginFixtureDraft.function (availIn SourceOriginFixtureDraft.function out.result.ctx) 0 1 := by
    change 0 ∈ ((availIn SourceOriginFixtureDraft.function out.result.ctx).getD 0 [] ++ [0]).filter (fun x => decide (x ∉ ([] : List Nat)))
    simp
  refine ⟨out,event,record,step,target,scope,dominated,out.arity,out.lowered,out.prepare,out.fallback,out.accepted,out.physical,
    eventMem,recordMem,which,recorded,emitted,source,mapped,definition,entry,?_,?_,?_,?_,?_⟩
  · exact stock_lower_emitted_record_finalOrdinaryOrigins actual scope nonempty dominated.ssa eventMem recordMem recorded emitted source rfl (by decide) mapped target entry
  · exact stock_lower_emitted_record_finalOrdinaryOrigins_noInherited actual scope nonempty dominated.ssa eventMem recordMem recorded emitted source rfl (by decide) mapped target entry
  · exact stock_lower_emitted_record_finalOrdinaryAvailable actual scope dominated nonempty eventMem recordMem recorded emitted source rfl (by decide) mapped available definition target entry
  · exact stock_lower_emitted_record_finalOrdinaryAvailable_noInherited actual scope dominated nonempty eventMem recordMem recorded emitted source rfl (by decide) mapped available definition target entry
  · rfl
end Backend.Stock.Proof.SourceRecordedOrdinaryWitnessDraft
