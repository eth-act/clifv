from pathlib import Path
import json,subprocess,os,datetime
root=Path('/home/lee/clifv/.worktrees/driver-proof-resume');data=json.loads(Path('/tmp/stock-jump-cfg-affected.json').read_text());affected=set(data['affected']);done=set();order=[]
def visit(m):
 if m in done:return
 done.add(m)
 for d in data['imports'][m]:
  if d in affected:visit(d)
 order.append(m)
for m in sorted(affected):visit(m)
env=dict(os.environ,OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',FV_MEMCAP='20G')
assert subprocess.check_output(['nproc'],env=env,text=True).strip()=='2'
logs={}
for i,m in enumerate(order):
 print(datetime.datetime.now(datetime.timezone.utc).isoformat(),i+1,len(order),m,flush=True)
 log=Path('/tmp/stock-jump-cfg-rebuild-'+m.rsplit('.',1)[1]+'.log')
 with log.open('w') as out:subprocess.run(['scripts/memcap.sh','/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin/lake','build',m],cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT,check=True)
 assert 'Build completed successfully' in log.read_text(),m
 logs[m]=str(log)
Path('/tmp/stock-jump-cfg-serial-rebuild-receipt.json').write_text(json.dumps({'success':True,'sequential_modules':order,'heavy_kernels_concurrent':1,'memcap_GiB':20,'effective_nproc':2,'logs':logs},indent=2)+'\n')
print('PASS',len(order),'serial affected modules',flush=True)
