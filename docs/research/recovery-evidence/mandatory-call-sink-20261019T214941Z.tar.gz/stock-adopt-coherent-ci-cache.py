from pathlib import Path
import os,subprocess as sp,json,tarfile,datetime,importlib.util
view=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');cache=Path('/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache');out=Path('/tmp/stock-coherent-ci-adoption');out.mkdir(exist_ok=True)
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  cmd=(p/'cmdline').read_bytes().decode().replace('\0',' ')
  if '/bin/lean '+str(view)+'/' in cmd:raise AssertionError('a local Lean build is still active: '+p.name)
 except OSError:pass
s=importlib.util.spec_from_file_location('s','/tmp/stock-execute-scheduler.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);_,mods,imports=m.load_modules(view);names=set();q=['FV.Backend.Proof.StockCmpWithFlags']
while q:
 n=q.pop()
 if n in names:continue
 names.add(n);q+=imports[n]
for n in names:assert sp.check_output(['git','show','5f4f9bf6:'+str(mods[n].relative_to(view))],cwd=view)==mods[n].read_bytes(),n
traces=[view/'.lake/build/lib/lean'/(n.replace('.','/')+'.trace') for n in sorted(names)]
backup=out/'previous-local-traces.tar.gz'
with tarfile.open(backup,'w:gz') as t:
 for p in traces:
  if p.is_file():t.add(p,arcname=str(p.relative_to(view)))
oldmap=[]
for p in traces:
 if p.is_file():
  d=json.loads(p.read_text());oldmap.append({'path':str(p.relative_to(view)),'depHash':d.get('depHash'),'outputs':d.get('outputs')})
(out/'previous-local-output-mappings.json').write_text(json.dumps(oldmap,indent=2)+'\n')
env=dict(os.environ,PATH='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:'+os.environ['PATH'],FV_MEMCAP='8G',FV_LAKE_CACHE=str(cache),RUST_MIN_STACK='67108864',LEAN_NUM_THREADS='2',OMP_NUM_THREADS='2')
with (out/'unstage.log').open('w') as log:r=sp.run(['scripts/memcap.sh','lake','cache','unstage','--force-overwrite','/tmp/stock-cmp-heavy-checked-stage'],cwd=view,env=env,stdout=log,stderr=sp.STDOUT)
assert r.returncode==0,r.returncode
# Existing checked traces take precedence over newly staged cache variants.
# Remove only these archived, expendable trace files, leaving sources and all
# cached output blobs intact. Lake must derive each input key and restore the
# coherent checked closure itself; no trace key is assigned by this script.
for p in traces:p.unlink(missing_ok=True)
with (out/'official-current-input-key-restore.log').open('w') as log:r=sp.run(['scripts/memcap.sh','lake','build','--no-build','FV.Backend.Proof.StockCmpWithFlags'],cwd=view,env=env,stdout=log,stderr=sp.STDOUT)
receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':sp.check_output(['git','rev-parse','HEAD'],cwd=view,text=True).strip(),'ci_run':39242870268,'same_source_modules':len(names),'returncode':r.returncode,'method':'official force-overwrite unstage; archived local traces removed; Lake derives and checks every current input key, no kernel build allowed','old_traces':str(backup),'log':str(out/'official-current-input-key-restore.log')}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));raise SystemExit(r.returncode)
