from pathlib import Path
import subprocess as sp,json,re
root=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');out=Path('/tmp/stock-d0-constant-audits');out.mkdir(exist_ok=True)
files=sp.check_output(['git','diff','--name-only','693b9b24','--','FV','FVTest'],cwd=root,text=True).splitlines();mains=[];base=[]
for file in files:
 if not file.endswith('.lean'):continue
 module=file[:-5].replace('/','.')
 (mains if re.search(r'^def main\b',(root/file).read_text(),re.M) else base).append(module)
body='''open Lean Elab Command
run_cmd do
  let env ← getEnv
  let targets : Array String := TARGETS
  let mut count : Nat := 0
  for (name, _) in env.constants.toList do
    let some index := env.getModuleIdxFor? name | continue
    if !targets.contains env.header.moduleNames[index]!.toString then continue
    let axioms ← collectAxioms name
    for ax in axioms do
      unless #[``propext, ``Classical.choice, ``Quot.sound].contains ax do
        throwError "disallowed axiom {ax} in {name}"
    logInfo m!"DELIVERY_CONSTANT {Json.compress (toJson (name.toString, axioms.map Name.toString))}"
    count := count + 1
  unless count > 0 do throwError "empty constant audit"
  logInfo m!"DELIVERY_AXIOM_COUNT {count}"
'''
manifest=[]
for label,modules in [('base',base)]+[(m.replace('.','-'),[m]) for m in mains]:
 p=out/(label+'.lean');p.write_text('import Lean\n'+''.join('import '+m+'\n' for m in modules)+body.replace('TARGETS','#['+','.join(json.dumps(m) for m in modules)+']'))
 manifest.append({'file':str(p),'modules':modules})
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print('Audit partitions',len(manifest),'modules',len(base)+len(mains),'isolated global main declarations',mains)
