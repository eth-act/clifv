from pathlib import Path
import re
base=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');src=(base/'FV/E2E/BinCheck.lean').read_text()
a=src.index('theorem img_bytes ');b=src.index('\nend E2E.BinCheck',a);image=src[a:b]
image=image.replace('theorem img_bytes {I : LinkInput}','theorem img_bytesWithResults {I : LinkInput} {R : Res}').replace('BinOk I D file','BinOkWithResults I R D file').replace('(hI : okB I = true)','(himg : imgB (tabOf R) = true)').replace('I.results','R').replace('RelocAt I','RelocAtWithResults I R')
old='''    have himg : imgB (tabOf R) = true := by
      have := okB_global hI ("imgCode: the image reads back", imgB (tabOf R))
        (by simp [globalChks])
      exact this
'''
assert old in image;image=image.replace(old,'')
s='''import FV.E2E.BinCheck
import StockActualCheckerProbe

/-! Actual emitted-artifact/ELF provenance. Reuses the existing ELF parser,
relocation, data, symbol and byte checks; the code table is the actual pipeline
result table, without a legacy reconstruction or diagnostic-history rewrite. -/
namespace E2E.BinCheck
open Backend E2E.LinkCheck Elf

/-- Actual total-pipeline output with the original source/oracle indices/base. -/
def artInWithLowering (I : LinkInput) (lower : Clif.Function → Except String VCode)
    (stage : VCode → VCode) (fi : FnInput) : Art :=
  getOk (pipeTWithLowering lower stage fi.func fi.k
    (BitVec.ofNat 64 (I.baseOf fi.func.name)) (raJ fi.ra fi.j))

def codeBWithLowering (I : LinkInput) (lower : Clif.Function → Except String VCode)
    (stage : VCode → VCode) (ex : Excerpt) (fs : List FnInput) : Bool :=
  match phdrs (exRd ex) with
  | some phs => fs.all fun fi => artB I (exRd ex) phs (artInWithLowering I lower stage fi)
  | none => false

def ArtsOkWithLowering (I : LinkInput) (lower : Clif.Function → Except String VCode)
    (stage : VCode → VCode) (file : ByteArray) (fs : List FnInput) : Prop :=
  ∀ fi ∈ fs, ArtOk I file (artInWithLowering I lower stage fi)

theorem artsOkWithLowering_append {I : LinkInput}
    {lower : Clif.Function → Except String VCode} {stage : VCode → VCode}
    {file : ByteArray} {l₁ l₂ : List FnInput}
    (h₁ : ArtsOkWithLowering I lower stage file l₁)
    (h₂ : ArtsOkWithLowering I lower stage file l₂) :
    ArtsOkWithLowering I lower stage file (l₁ ++ l₂) := by
  intro fi hfi
  rcases List.mem_append.1 hfi with h | h
  · exact h₁ fi h
  · exact h₂ fi h

theorem codeBWithLowering_sound {I : LinkInput}
    {lower : Clif.Function → Except String VCode} {stage : VCode → VCode}
    {ex : Excerpt} {fs : List FnInput}
    (h : codeBWithLowering I lower stage ex fs = true) {file : ByteArray}
    (hA : Agrees file ex) : ArtsOkWithLowering I lower stage file fs := by
  unfold codeBWithLowering at h
  split at h
  · rename_i phs hp
    exact fun fi hfi => artB_sound hA hp (List.all_eq_true.1 h fi hfi)
  · cases h

/-- Same binary obligations, for an explicit actual result table. -/
structure BinOkWithResults (I : LinkInput) (R : Res) (D : List Clif.DataObject)
    (file : ByteArray) : Prop where
  static : Static file
  code : ∀ e ∈ tabOf R, ArtOk I file e.2
  data : ∀ o ∈ D, DataOk I file o
  syms : SymsOk I file

theorem BinOk.toWithResults {I : LinkInput} {D : List Clif.DataObject} {file : ByteArray}
    (h : BinOk I D file) : BinOkWithResults I I.results D file :=
  ⟨h.static, h.code, h.data, h.syms⟩

theorem binOkWithResults_ofLowering {I : LinkInput}
    {lower : Clif.Function → Except String VCode} {stage : VCode → VCode}
    {D : List Clif.DataObject} {file : ByteArray} (hs : Static file)
    (hc : ArtsOkWithLowering I lower stage file I.funcs)
    (hd : ∀ o ∈ D, DataOk I file o) (hy : SymsOk I file) :
    BinOkWithResults I (I.resultsTWithLowering lower stage) D file := by
  refine ⟨hs, fun e he => ?_, hd, hy⟩
  simp only [tabOf, LinkInput.resultsTWithLowering, List.map_map, List.mem_map,
    Function.comp] at he
  obtain ⟨fi, hfi, rfl⟩ := he
  exact hc fi hfi

def RelocAtWithResults (I : LinkInput) (R : Res) (a : BitVec 64) : Prop :=
  ∃ e ∈ tabOf R, ∃ r ∈ e.2.fb.relocs, ∃ i < 4, a = wAt e.2 (r.offset + i)

'''+image+'''

theorem img_bytesWithLowering {I : LinkInput}
    {lower : Clif.Function → Except String VCode} {stage : VCode → VCode}
    {D : List Clif.DataObject} {file : ByteArray}
    (hB : BinOkWithResults I (I.resultsTWithLowering lower stage) D file)
    (hI : okRWith stage I (I.resultsTWithLowering lower stage) = true)
    {a : BitVec 64} (ha : ImgT (tabOf (I.resultsTWithLowering lower stage)) a) :
    Elf.ro file a ∧
      (loadMem file a = some (memT (tabOf (I.resultsTWithLowering lower stage)) a) ∨
        RelocAtWithResults I (I.resultsTWithLowering lower stage) a) := by
  have himg : imgB (tabOf (I.resultsTWithLowering lower stage)) = true :=
    okRWith_global stage hI
      ("imgCode: the image reads back", imgB (tabOf (I.resultsTWithLowering lower stage)))
      (by simp [globalChks])
  exact img_bytesWithResults hB himg ha

#print axioms artsOkWithLowering_append
#print axioms codeBWithLowering_sound
#print axioms BinOk.toWithResults
#print axioms binOkWithResults_ofLowering
#print axioms img_bytesWithResults
#print axioms img_bytesWithLowering
end E2E.BinCheck
'''
Path('/tmp/StockActualBinaryProbe.lean').write_text(s)
Path('/home/lee/clifv/.worktrees/driver-proof-resume/docs/research/stock-actual-binary-candidate.lean').write_text(s)
t=Path('/tmp/stock-actual-checker-check.py').read_text().replace("'/tmp/stock-actual-checker-check'","'/tmp/stock-actual-binary-check'").replace("'FV.E2E.PipelineCheck'","'FV.E2E.BinCheck'").replace('/tmp/StockActualCheckerProbe.olean','/tmp/StockActualBinaryProbe.olean').replace('/tmp/StockActualCheckerProbe.lean','/tmp/StockActualBinaryProbe.lean')
Path('/tmp/stock-actual-binary-check.py').write_text(t);print('Prepared actual binary provenance',len(s.splitlines()),'lines,six roots')
