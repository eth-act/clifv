import Lean
import StockPrologueInputProbe
import FV.Backend.Proof.LowerDecide
open Lean Meta Backend.Proof.Driver Backend.Stock.PrologueProbe
set_option maxRecDepth 100000
set_option maxHeartbeats 8000000
run_meta do
  for n in [``dominatedB, ``lowerScopeB, ``availIn, ``inFix, ``fixLoop, ``fixHas] do
    match ← getConstInfo n with
    | .defnInfo d => logInfo m!"{n}: definition"
    | .opaqueInfo _ => logInfo m!"{n}: opaque"
    | .axiomInfo _ => logInfo m!"{n}: axiom"
    | _ => logInfo m!"{n}: other"
#eval (dominatedB (source "" .systemVI64 []), lowerScopeB (source "" .systemVI64 []))
#reduce dominatedB (source "" .systemVI64 [])
