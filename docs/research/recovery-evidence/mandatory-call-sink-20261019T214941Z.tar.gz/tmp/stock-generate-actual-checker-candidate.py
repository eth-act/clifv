from pathlib import Path
import re
base=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');src=(base/'FV/E2E/PipelineCheck.lean').read_text()
start=src.index('def ResOkWith ');end=src.index('theorem okRWith_global',start);declarations=src[start:end]
declarations=declarations.replace('def ResOkWith (stage','def ResOkWithLowering (lower : Clif.Function → Except String VCode) (stage').replace('structure FactsWith (stage','structure FactsWithLowering (lower : Clif.Function → Except String VCode) (stage').replace('lowerFunction e.1','lower e.1').replace('lowerFunction g','lower g')
names=['factsRWith','indFactsRWith','okRWith_sound'];rename={n:n.replace('With','WithLowering') for n in names};parts=[]
for name in names:
 a=re.search(r'^theorem '+name+r'\b',src,re.M).start();tail=src[a:];stop=re.search(r'\n(?:theorem |end E2E)',tail);assert stop,name
 t=tail[:stop.start()].rstrip()
 t=t.replace('ResOkWith stage I R','ResOkWithLowering lower stage I R').replace('FactsWith stage I R','FactsWithLowering lower stage I R')
 for old,new in rename.items():t=re.sub(r'\b'+old+r'\b',new+' lower',t)
 t=t.replace('theorem '+rename[name]+' lower (stage','theorem '+rename[name]+' (lower : Clif.Function → Except String VCode) (stage')
 if name=='okRWith_sound':
  t=t.replace('(ofRes I R B F).Ok :=','(ofRes I R B F).OkProduction :=').replace('CompiledEither g','CompiledProduction g')
  t=t.replace('· exact ⟨.legacy ⟨hl, (fa hg).lowerOk, hpr, (fa hg).prepOk, (fa hg).check, ha, he, hla⟩, hb⟩','· exact ⟨.stock ⟨⟨(fa hg).lowerOk, hpr, (fa hg).prepOk, allocChecked_of_checkAlloc (fa hg).check, ha, he, hla⟩, (fa hg).check⟩, hb⟩')
  t=t.replace('· exact ⟨.cleanup ⟨hl, (fa hg).lowerOk, hpr, (fa hg).prepOk, (fa hg).check, ha, he, hla⟩, hb⟩','· exact ⟨.stockCleanup ⟨⟨(fa hg).lowerOk, hpr, (fa hg).prepOk, allocChecked_of_checkAlloc (fa hg).check, ha, he, hla⟩, (fa hg).check⟩, hb⟩')
 parts.append(t)
header='''import FV.E2E.PipelineCheck
import StockLinkProductionProbe
import StockPipelineProvenanceProbe

/-! Actual-result checker provenance. All existing checks and input/layout/base
conditions remain; the proof uses the actual callback output in either supported
preparation stage. Old checker definitions/theorem variants are unchanged. -/
namespace E2E.LinkCheck
open Backend Backend.Proof Backend.Proof.Driver

'''
s=header+declarations+'\n\n'.join(parts)+'''

/-- Actual source/index/oracle/base metadata and lowering output flow through the
same total allocation pipeline consumed by the compiler. -/
def LinkInput.resultsTWithLowering (I : LinkInput)
    (lower : Clif.Function → Except String VCode) (stage : VCode → VCode) : Res :=
  I.funcs.map fun fi =>
    (fi.func, pipeTWithLowering lower stage fi.func fi.k
      (BitVec.ofNat 64 (I.baseOf fi.func.name)) (raJ fi.ra fi.j))

theorem LinkInput.resultsTWithLowering_provenance (I : LinkInput)
    (lower : Clif.Function → Except String VCode) (stage : VCode → VCode) :
    ResOkWithLowering lower stage I (I.resultsTWithLowering lower stage) := by
  intro e he a ha
  unfold LinkInput.resultsTWithLowering at he
  obtain ⟨fi, hfi, rfl⟩ := List.mem_map.mp he
  obtain ⟨lowered, prep, rf, alloc, emit, layout, index, addr⟩ :=
    ActualCodeProbe.pipeTWithLowering_spec ha
  exact ⟨lowered, prep, alloc, emit, layout, addr⟩

theorem LinkInput.resultsTWithLowering_legacy (I : LinkInput) :
    I.resultsTWithLowering lowerFunction id = I.resultsT := by
  simp only [LinkInput.resultsTWithLowering, LinkInput.resultsT, pipeT,
    pipeTWithLowering, Stock.D0.defaultLower_eq_legacy]

theorem LinkInput.resultsTWithLowering_sound (I : LinkInput)
    (lower : Clif.Function → Except String VCode) (stage : VCode → VCode)
    (hstage : stage = id ∨ stage = DeadCleanup.prune)
    (hI : okRWith stage I (I.resultsTWithLowering lower stage) = true)
    {B : BaseEnv} {F : BitVec 64 → Prop}
    (hB : BaseOk (ofRes I (I.resultsTWithLowering lower stage) B F))
    (hF : ∀ a, (ofRes I (I.resultsTWithLowering lower stage) B F).Img a → F a) :
    (ofRes I (I.resultsTWithLowering lower stage) B F).OkProduction :=
  okRWithLowering_sound lower stage hstage
    (I.resultsTWithLowering_provenance lower stage) hI hB hF

/-- The same linked-machine statement, tied to the actual lowering callback and
preparation stage, for generated proof consumers. -/
def CrateStmtWithLowering (I : LinkInput) (lower : Clif.Function → Except String VCode)
    (stage : VCode → VCode) (n : String) : Prop :=
  ∀ (B : BaseEnv) (F : BitVec 64 → Prop),
    BaseOk (ofRes I (I.resultsTWithLowering lower stage) B F) →
    (∀ a, (ofRes I (I.resultsTWithLowering lower stage) B F).Img a → F a) →
    ProgStmt (ofRes I (I.resultsTWithLowering lower stage) B F) n

theorem crate_correct_withLowering (I : LinkInput)
    (lower : Clif.Function → Except String VCode) (stage : VCode → VCode)
    (hstage : stage = id ∨ stage = DeadCleanup.prune)
    (hI : okRWith stage I (I.resultsTWithLowering lower stage) = true) (n : String) :
    CrateStmtWithLowering I lower stage n :=
  fun _ _ hB hF f hf M _ _ _ _ _ hent hres hFeq hgfree himg hbe hargs hcs hsav hrel hpl htr =>
    backend_correct_program_production _
      (I.resultsTWithLowering_sound lower stage hstage hI hB hF)
      (Clif.Program.func?_some hf).1 M hent hres hFeq hgfree himg hbe hargs hcs hsav hrel hpl htr

#print axioms crate_correct_withLowering

'''+ '\n'.join('#print axioms '+rename[n] for n in names)+'\n'+ '\n'.join('#print axioms LinkInput.resultsTWithLowering_'+n for n in ['provenance','legacy','sound'])+'\nend E2E.LinkCheck\n'
Path('/tmp/StockActualCheckerProbe.lean').write_text(s)
Path('/home/lee/clifv/.worktrees/driver-proof-resume/docs/research/stock-actual-checker-candidate.lean').write_text(s)
t=Path('/tmp/stock-link-production-reserved-window.py').read_text().replace("'/tmp/stock-link-production-check'","'/tmp/stock-actual-checker-check'").replace("'FV.E2E.LinkArm'","'FV.E2E.PipelineCheck'").replace('/tmp/StockLinkProductionProbe.olean','/tmp/StockActualCheckerProbe.olean').replace('/tmp/StockLinkProductionProbe.lean','/tmp/StockActualCheckerProbe.lean')
Path('/tmp/stock-actual-checker-check.py').write_text(t);print('Prepared checker',len(s.splitlines()),'lines,seven roots')
