from pathlib import Path
import os,signal,re,json,subprocess as sp,datetime
scheduler=113274;out=Path('/tmp/stock-prologue-all-source-check');out.mkdir(exist_ok=True);view=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');paused=False
import fcntl
_probe_lock = open('/tmp/stock-reserved-probe.lock', 'a')
fcntl.flock(_probe_lock, fcntl.LOCK_EX)
assert 'stock-execute-scheduler.py' in Path(f'/proc/{scheduler}/cmdline').read_text()
def report(state,**kw):
 d={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':os.getpid(),'state':state,**kw};(out/'progress.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)
try:
 os.kill(scheduler,signal.SIGSTOP);paused=True;active={}
 for l in Path('/tmp/stock-d0-full-module-gate/all-modules/sched.log').read_text().splitlines():
  m=re.search(r' start (\S+) cap=(\d+)G',l)
  if m:active[m[1]]=int(m[2])
  m=re.search(r' done (\S+)',l)
  if m:active.pop(m[1],None)
 initial_caps=dict(active)
 # Dispatch is stopped; existing workers continue. Wait briefly for a small
 # backfill worker to finish, using its actual process handle rather than logs.
 import time
 deadline=time.monotonic()+10
 handles={}
 for raw in Path(f'/proc/{scheduler}/task/{scheduler}/children').read_text().split():
  child=int(raw)
  try:args=Path(f'/proc/{child}/cmdline').read_bytes().decode().split('\0')
  except FileNotFoundError:continue
  args=[a for a in args if a]
  if '/tmp/stock-delivery-time.py' in args:
   module=args[-1];assert module in active,(child,module)
   handles[child]=(module,active[module])
 def live_caps():
  caps={}
  for child,(module,cap) in handles.items():
   try:
    state=Path(f'/proc/{child}/stat').read_text().split(') ',1)[1].split()[0]
   except FileNotFoundError:continue
   if state!='Z':caps[module]=cap
  return caps
 active=live_caps()
 while sum(active.values())+2>16 and time.monotonic()<deadline:
  time.sleep(.2);active=live_caps()
 if sum(active.values())+2>16:
  report('not_started_slot_unavailable',active_caps=active,initial_caps=initial_caps);raise SystemExit(0)
 report('reserved_after_verified_worker_completion',active_caps=active,initial_caps=initial_caps,worker_handles=handles,combined_reserved_GiB=sum(active.values())+2)
 env=dict(os.environ,FV_MEMCAP='2G',FV_LAKE_CACHE='/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2');env['PATH']='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:'+env['PATH'];os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:2]);report('checking_dependency_keys',active_caps=active,combined_reserved_GiB=sum(active.values())+2)
 with (out/'dependency-keys.log').open('w') as f:r=sp.run(['scripts/memcap.sh','lake','build','--no-build','FV.Backend.Lowering.StockD0','FV.Clif.Run'],cwd=view,env=env,stdout=f,stderr=sp.STDOUT)
 if r.returncode:report('not_started_dependencies_not_current',returncode=r.returncode);raise SystemExit(0)
 env['LEAN_PATH']='/tmp:'+sp.check_output(['lake','env','printenv','LEAN_PATH'],cwd=view,env=env,text=True).strip()
 with (out/'kernel.log').open('w') as f:r=sp.run(['timeout','--signal=TERM','--kill-after=3s','30s','scripts/memcap.sh','lean','--root=/tmp','-o','/tmp/StockPrologueAllSourceProbe.olean','/tmp/StockPrologueAllSourceProbe.lean'],cwd=view,env=env,stdout=f,stderr=sp.STDOUT)
 report('candidate_kernel_passed' if r.returncode==0 else 'candidate_not_proved_in_bounded_probe',returncode=r.returncode)
finally:
 if paused:os.kill(scheduler,signal.SIGCONT)
 p=out/'progress.json'
 if p.exists():d=json.loads(p.read_text());d['scheduler_dispatch_resumed']=True;p.write_text(json.dumps(d,indent=2)+'\n')
