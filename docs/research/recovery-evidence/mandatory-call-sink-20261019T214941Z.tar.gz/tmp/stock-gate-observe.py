from pathlib import Path
import json,re,datetime
jobs={113213:'stock-d0-full-module-gate.py',113274:'stock-execute-scheduler.py',118996:'stock-d0-final-affected-gates.py',1062423:'stock-prologue-code-after-witness.py'}
handles={}
for pid,marker in jobs.items():
 try:
  cmd=Path(f'/proc/{pid}/cmdline').read_bytes().replace(b'\0',b' ').decode()
  state=next(l.split(':',1)[1].strip() for l in Path(f'/proc/{pid}/status').read_text().splitlines() if l.startswith('State:'))
  handles[str(pid)]={'matches':marker in cmd,'state':state,'live':marker in cmd and not state.startswith('Z')}
 except FileNotFoundError:handles[str(pid)]={'live':False}
s=Path('/tmp/stock-d0-full-module-gate/all-modules/sched.log').read_text();last={};active={}
for line in s.splitlines():
 m=re.search(r' start (\S+) cap=([\d.]+)G',line)
 if m:active[m[1]]=float(m[2])
 m=re.search(r' done (\S+) rc=(-?\d+)',line)
 if m:last[m[1]]=int(m[2]);active.pop(m[1],None)
d={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'passed':sum(v==0 for v in last.values()),'total':int(re.search(r'want (\d+) modules',s).group(1)),'active_caps_GiB':active,'latest_nonzero':{k:v for k,v in last.items() if v},'handles':handles}
for key,path in [('full','/tmp/stock-d0-full-module-gate/progress.json'),('affected','/tmp/stock-d0-final-affected-gates/progress.json')]:
 p=json.loads(Path(path).read_text());d[key]={'state':p.get('state'),'phase':p.get('phase')}
Path('/tmp/stock-gate-observation.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))
