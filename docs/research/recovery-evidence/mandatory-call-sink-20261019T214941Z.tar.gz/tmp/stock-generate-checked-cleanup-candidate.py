from pathlib import Path
import re
base=Path('/home/lee/clifv/.worktrees/stock-driver-incremental')
selected={
 'DeadCleanupPipeline':['backend_correct_cleanup_ex','backend_correct_of_rules_cleanup_ex'],
 'DeadCleanupFinal':['backend_correct_m4_cleanup_ex','hasTry_of_hasTryCallCleanupA','hasTls_of_vcodeCleanupA','outgoing_le_intBaseCleanupA','stackArgsAvoid_frameWCleanupA','backend_correct_final_cleanup_ex'],
 'DeadCleanupWorld':['iselSim_relW_cleanup','backend_correct_world_cleanup'],
 'DeadCleanupPair':['instCalls_pair_value','tryCalls_pair_value','tryIndCalls_pair_value','vcode_ni_value','backend_correct_world_ni_value'],
 'DeadCleanupWorldX':['backend_correct_worldX_cleanup','backend_correct_world_niX_cleanup']}
rename={n:n+'_validated' for names in selected.values() for n in names}
header='''import FV.E2E.DeadCleanupWorldX
import StockCheckedNoninterferenceConsumerProbe

/-! Actual-output consumer contracts for the existing dead-cleanup stage.
The source validator applies to actual raw output, preparation to its actual
pruned output. Legacy theorem variants and runtime histories remain unchanged.
Concrete successful Stock witnesses remain required before integration. -/
namespace E2E
open Backend Backend.Proof Backend.Proof.Driver Backend.DeadCleanup

structure CompiledCleanupValidatedA (f : Clif.Function) (k : Nat) (vc vcp : VCode)
    (rf : RFunc) (af : AFunc) (fa : FnAsm) (fb : FnBin) : Prop where
  lowerOk : lowerCheck f vc = true
  prepare : prepare (prune vc) = .ok vcp
  prepOk : prepCheck (prune vc) vcp = true
  check : AllocChecked vcp rf
  alloc : lowerRFunc vcp rf = .ok af
  emit : emitFunc k af = .ok fa
  layout : fa.layout = .ok fb

structure CompiledCleanupValidated (f : Clif.Function) (k : Nat) (vc vcp : VCode)
    (rf : RFunc) (af : AFunc) (fa : FnAsm) (fb : FnBin) : Prop
    extends CompiledCleanupValidatedA f k vc vcp rf af fa fb where
  checkAlloc : Backend.checkAlloc vcp rf = .ok ()

theorem CompiledCleanupA.toValidated {f : Clif.Function} {k : Nat} {vc vcp : VCode}
    {rf : RFunc} {af : AFunc} {fa : FnAsm} {fb : FnBin}
    (hc : CompiledCleanupA f k vc vcp rf af fa fb) :
    CompiledCleanupValidatedA f k vc vcp rf af fa fb :=
  ⟨hc.lowerOk, hc.prepare, hc.prepOk, hc.check, hc.alloc, hc.emit, hc.layout⟩

theorem CompiledCleanup.toValidated {f : Clif.Function} {k : Nat} {vc vcp : VCode}
    {rf : RFunc} {af : AFunc} {fa : FnAsm} {fb : FnBin}
    (hc : CompiledCleanup f k vc vcp rf af fa fb) :
    CompiledCleanupValidated f k vc vcp rf af fa fb :=
  ⟨hc.toA.toValidated, hc.check⟩

'''
variables='''section
variable {p : Clif.Program} {f : Clif.Function} {k : Nat} {vc vcp : VCode} {rf : RFunc}
  {af : AFunc} {fa : FnAsm} {fb : FnBin} {X : ExtSem} {syms : String → Option Nat}
  {slotOff : Nat} {env : Clif.Env} {F : BitVec 64 → Prop} {c : BitVec 64} {D : BitVec 64 → Prop}

'''
parts=[]
for file,names in selected.items():
 source=(base/'FV/E2E'/f'{file}.lean').read_text()
 for n in names:
  start=re.search(r'^theorem '+re.escape(n)+r'\b',source,re.M).start();tail=source[start:];end=re.search(r'\n(?:/--|theorem |end(?: E2E)?\s*\n)',tail);assert end,n
  t=tail[:end.start()].rstrip();strict='(hc : CompiledCleanup f ' in t
  t=t.replace('CompiledCleanupA f k vc vcp rf af fa fb','CompiledCleanupValidatedA f k vc vcp rf af fa fb').replace('CompiledCleanup f k vc vcp rf af fa fb','CompiledCleanupValidated f k vc vcp rf af fa fb')
  t=re.sub(r'\b(?:'+ '|'.join(map(re.escape,sorted(rename,key=len,reverse=True)))+r')\b',lambda m:rename[m[0]],t)
  if strict:t=t.replace('hc.toA','hc.toCompiledCleanupValidatedA').replace('hc.check ', 'hc.checkAlloc ')
  if n in ['tryCalls_pair_value','tryIndCalls_pair_value']:
   t=t.replace('(hc : CompiledCleanupValidated f k vc vcp rf af fa fb)','',1)
  for name in ['tryCalls_pair_value','tryIndCalls_pair_value']:
   t=t.replace(rename[name]+' hc ',rename[name]+' ')
  if n=='instCalls_pair_value':parts.append(variables)
  parts.append(t)
  if n=='tryIndCalls_pair_value':parts.append('end')
s=header+'\n\n'.join(parts)+'\n\n#print axioms CompiledCleanupA.toValidated\n#print axioms CompiledCleanup.toValidated\n'+'\n'.join('#print axioms '+rename[n] for names in selected.values() for n in names)+'\nend E2E\n'
Path('/tmp/StockCheckedCleanupConsumerProbe.lean').write_text(s)
Path('/home/lee/clifv/.worktrees/driver-proof-resume/docs/research/stock-checked-cleanup-consumer-candidate.lean').write_text(s)
t=Path('/tmp/stock-checked-consumer-check.py').read_text().replace("'/tmp/stock-checked-consumer-check'","'/tmp/stock-checked-cleanup-consumer-check'").replace("'FV.E2E.Main'","'FV.E2E.DeadCleanupWorldX'").replace('/tmp/StockCheckedConsumerProbe.olean','/tmp/StockCheckedCleanupConsumerProbe.olean').replace('/tmp/StockCheckedConsumerProbe.lean','/tmp/StockCheckedCleanupConsumerProbe.lean')
Path('/tmp/stock-checked-cleanup-consumer-check.py').write_text(t)
print('Prepared cleanup consumer:',len(s.splitlines()),'lines,19 roots; unvalidated')
