import Lean
import StockPrologueInputProbe
import FV.Backend.Proof.LowerDecide

namespace Backend.Stock.PrologueProbe
open Backend.Proof.Driver
set_option maxRecDepth 100000
set_option maxHeartbeats 8000000
set_option Elab.async false

/-- These source conditions are derived inside the fixed class, for arbitrary
names/run metadata, rather than supplied as new caller premises. -/
theorem systemV_i64_domain (name : String) (runs : List Clif.RunCommand) :
    dominatedB (source name .systemVI64 runs) = true ∧
      lowerScopeB (source name .systemVI64 runs) = true := by
  change dominatedB (source "" .systemVI64 []) = true ∧
    lowerScopeB (source "" .systemVI64 []) = true
  decide +kernel

#print axioms systemV_i64_domain
end Backend.Stock.PrologueProbe
