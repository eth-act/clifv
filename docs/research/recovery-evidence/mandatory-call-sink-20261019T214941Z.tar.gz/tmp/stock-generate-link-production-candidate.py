from pathlib import Path
import re,json
base=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');source=(base/'FV/E2E/LinkArm.lean').read_text()
start=source.index('structure Ok : Prop where');end=source.index('\n/-- **The machine side',start);record=source[start:end];fields=re.findall(r'^  (\w+) :',record,re.M);assert len(fields)==39
record=record.replace('structure Ok : Prop where','structure OkProduction : Prop where',1);assert record.count('CompiledEither')==1;record=record.replace('CompiledEither','CompiledProduction')
commands=list(re.finditer(r'^(?:theorem ([\w?.]+)|((?:structure|def|abbrev|namespace|end|variable|open|section))\b)',source,re.M));selected=[];ns=[]
for i,m in enumerate(commands):
 line=source[m.start():source.find('\n',m.start())]
 if m[2]=='namespace':ns.append(line.split()[1])
 elif m[2]=='section':ns.append(line.split()[1] if len(line.split())>1 else '')
 elif m[2]=='end':
  bits=line.split()
  if len(bits)>1:assert ns[-1]==bits[1],(ns,line)
  ns.pop()
 if m.start()<end or not m[1]:continue
 chunk=source[m.start():commands[i+1].start() if i+1<len(commands) else len(source)]
 if not re.search(r'\bL\.Ok\b',chunk):continue
 # Strip documentation belonging to the next declaration.
 chunk=re.split(r'\n/--|\n/-!',chunk,maxsplit=1)[0].rstrip()
 selected.append((m[1],tuple(ns),chunk))
assert len(selected)==38,len(selected)
rename={n:n+'_production' for n,_,_ in selected if n!='Ok.withCrun'}
assert not set(fields)&set(rename)
rename.update({n:n.replace('_pipeline','_production') for n in ['backend_correct_world_pipeline','backend_correct_world_ni_pipeline','backend_correct_worldX_pipeline','backend_correct_world_niX_pipeline','hasTls_of_vcode_pipeline','stackArgsAvoid_frameW_pipeline']})
header='''import FV.E2E.LinkArm
import StockProductionContractProbe

/-! Additive whole-program proofs for actual validated output.
Uses the existing LinkSys, hooks, CLIF runs, machine, depth/peak budgets and
binary artifacts. Only the proof contract's compilation field is generalized;
all38 non-compilation input/layout/environment conditions and old theorem variants are
preserved. Concrete compiler/checker/generated-proof integration is still needed. -/
namespace E2E
open Backend Backend.Proof Backend.Proof.Driver
open Clif Opt

namespace LinkSys
variable (L : LinkSys)

'''
s=header+record+'\n\n'
s+='''/-- Every retained legacy system is an instance with the same actual artifacts. -/
theorem Ok.toProduction {L : LinkSys} (h : L.Ok) : L.OkProduction where
'''
for f in fields:
 s+='  '+f+' := '+('fun g hg => .legacy (h.compiled g hg)' if f=='compiled' else 'h.'+f)+'\n'
s+='\nend LinkSys\n\n';roots=['LinkSys.Ok.toProduction']
for name,ns,chunk in selected:
 assert ns in [('E2E','LinkSys'),('E2E',)],(name,ns)
 chunk=re.sub(r'\b(?:'+'|'.join(map(re.escape,sorted(rename,key=len,reverse=True)))+r')\b',lambda m:rename[m[0]],chunk)
 chunk=re.sub(r'\.Ok\b','.OkProduction',chunk)
 if name=='Ok.withCrun':chunk=chunk.replace('theorem Ok.withCrun','theorem OkProduction.withCrun',1);new='OkProduction.withCrun'
 else:new=rename[name]
 if ns[-1]=='LinkSys':
  s+='namespace LinkSys\nvariable (L : LinkSys)\nvariable {κ : Nat → Clif.Function → Nat}\n\n'+chunk+'\nend LinkSys\n\n';roots.append('LinkSys.'+new)
 else:s+=chunk+'\n\n';roots.append(new)
s+='\n'.join('#print axioms '+n for n in roots)+'\nend E2E\n'
Path('/tmp/StockLinkProductionProbe.lean').write_text(s)
Path('/home/lee/clifv/.worktrees/driver-proof-resume/docs/research/stock-link-production-candidate.lean').write_text(s)
Path('/tmp/stock-link-production-source-map.json').write_text(json.dumps({'base':'567d1f09','source':'FV/E2E/LinkArm.lean','condition_field_count':39,'unchanged_condition_fields':[f for f in fields if f!='compiled'],'roots':roots,'only_record_field_changed':'compiled: CompiledEither -> CompiledProduction','runtime_model_copied':False},indent=2)+'\n')
t=Path('/tmp/stock-checked-consumer-check.py').read_text().replace("'/tmp/stock-checked-consumer-check'","'/tmp/stock-link-production-check'").replace("'FV.E2E.Main'","'FV.E2E.LinkArm'").replace('/tmp/StockCheckedConsumerProbe.olean','/tmp/StockLinkProductionProbe.olean').replace('/tmp/StockCheckedConsumerProbe.lean','/tmp/StockLinkProductionProbe.lean').replace('+2>16','+3>16').replace('+2)', '+3)').replace("FV_MEMCAP='2G'","FV_MEMCAP='3G'").replace("'20s'","'30s'")
Path('/tmp/stock-link-production-check.py').write_text(t)
print('Prepared',len(s.splitlines()),'lines;',len(roots),'roots; preserved',len(fields),'conditions')
