from pathlib import Path
import re
base=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');old=(base/'FV/E2E/CompiledEither.lean').read_text()
s='''import FV.E2E.CompiledEither
import StockCheckedCleanupConsumerProbe

/-! Additive production artifact contract: retained legacy variants plus actual
validated Stock output in either cleanup mode. The old CompiledEither and its
legacy-equality theorem are unchanged. This is a fixed proof interface, not a
runtime certificate or permission to discard source/edge obligations. -/
namespace E2E
open Backend Backend.Proof Backend.Proof.Driver

inductive CompiledProduction (f : Clif.Function) (k : Nat) (vc vcp : VCode)
    (rf : RFunc) (af : AFunc) (fa : FnAsm) (fb : FnBin) : Prop where
  | legacy : CompiledEither f k vc vcp rf af fa fb →
      CompiledProduction f k vc vcp rf af fa fb
  | stock : CompiledValidated f k vc vcp rf af fa fb →
      CompiledProduction f k vc vcp rf af fa fb
  | stockCleanup : CompiledCleanupValidated f k vc vcp rf af fa fb →
      CompiledProduction f k vc vcp rf af fa fb

namespace CompiledProduction
variable {f : Clif.Function} {k : Nat} {vc vcp : VCode} {rf : RFunc}
  {af : AFunc} {fa : FnAsm} {fb : FnBin}

'''
projections={'lowerOk':('lowerCheck f vc = true','lowerOk'),'check':('Backend.checkAlloc vcp rf = .ok ()','checkAlloc'),'alloc':('lowerRFunc vcp rf = .ok af','alloc'),'emit':('emitFunc k af = .ok fa','emit'),'layout':('fa.layout = .ok fb','layout')}
for name,(typ,field) in projections.items():
 s+=f'''theorem {name} (hc : CompiledProduction f k vc vcp rf af fa fb) : {typ} := by
  cases hc with
  | legacy h => exact h.{name}
  | stock h => exact h.{field}
  | stockCleanup h => exact h.{field}

'''
s+='end CompiledProduction\n\n'
roots=['backend_correct_world_pipeline','backend_correct_world_ni_pipeline','backend_correct_worldX_pipeline','backend_correct_world_niX_pipeline','hasTls_of_vcode_pipeline','stackArgsAvoid_frameW_pipeline']
for name in roots:
 start=re.search(r'^theorem '+name+r'\b',old,re.M).start();tail=old[start:];end=re.search(r'\n(?:theorem |end E2E)',tail);assert end,name
 t=tail[:end.start()];header=t[:t.index(':= by')];header=header.replace('CompiledEither f k vc vcp rf af fa fb','CompiledProduction f k vc vcp rf af fa fb').replace('theorem '+name,'theorem '+name.replace('_pipeline','_production'),1)
 if name.startswith('backend_correct_'):
  plain=name.replace('_pipeline','')+'_validated';clean={'backend_correct_world_pipeline':'backend_correct_world_cleanup_validated','backend_correct_world_ni_pipeline':'backend_correct_world_ni_value_validated','backend_correct_worldX_pipeline':'backend_correct_worldX_cleanup_validated','backend_correct_world_niX_pipeline':'backend_correct_world_niX_cleanup_validated'}[name]
  args='hsub h hcov hX hXI hsym hslot hcs hrel hargs htr fuel'
  s+=header+f''':= by
  cases hc with
  | legacy h => exact {name} {args}
  | stock h => exact {plain} {args}
  | stockCleanup h => exact {clean} {args}

'''
 elif name=='hasTls_of_vcode_pipeline':
  s+=header+''':= by
  cases hc with
  | legacy h => exact hasTls_of_vcode_pipeline h ht
  | stock h => exact hasTls_of_vcodeA_validated h.toCompiledValidatedA ht
  | stockCleanup h => exact hasTls_of_vcodeCleanupA_validated h.toCompiledCleanupValidatedA ht

'''
 else:
  s+=header+''':= by
  cases hc with
  | legacy h => exact stackArgsAvoid_frameW_pipeline h hres _hent hargs
  | stock h => exact stackArgsAvoid_frameWA_validated h.toCompiledValidatedA hres _hent hargs
  | stockCleanup h => exact stackArgsAvoid_frameWCleanupA_validated h.toCompiledCleanupValidatedA hres _hent hargs

'''
s+='\n'.join('#print axioms CompiledProduction.'+n for n in projections)+'\n'+'\n'.join('#print axioms '+n.replace('_pipeline','_production') for n in roots)+'\nend E2E\n'
Path('/tmp/StockProductionContractProbe.lean').write_text(s)
Path('/home/lee/clifv/.worktrees/driver-proof-resume/docs/research/stock-production-contract-candidate.lean').write_text(s)
t=Path('/tmp/stock-checked-consumer-check.py').read_text().replace("'/tmp/stock-checked-consumer-check'","'/tmp/stock-production-contract-check'").replace("'FV.E2E.Main'","'FV.E2E.CompiledEither'").replace('/tmp/StockCheckedConsumerProbe.olean','/tmp/StockProductionContractProbe.olean').replace('/tmp/StockCheckedConsumerProbe.lean','/tmp/StockProductionContractProbe.lean')
Path('/tmp/stock-production-contract-check.py').write_text(t);print('Prepared',len(s.splitlines()),'lines,11 roots')
