import StockPrologueInputProbe
import FV.Backend.Proof.DriverCheck

open Backend Stock Stock.D0
#eval do
  let f := Backend.Stock.PrologueProbe.source "stock_prologue_diagnostic" .systemVI64 []
  match Stock.lower f, lowerFunction f with
  | .ok r, .ok legacy =>
    IO.println s!"stock_lowerCheck={Backend.Proof.Driver.lowerCheck f (compact f.name r)} legacy_lowerCheck={Backend.Proof.Driver.lowerCheck f legacy} stock_name={r.code.name} compact_name={(compact f.name r).name} legacy_name={legacy.name}"
  | a, b => IO.println s!"stock_success={a.isOk} legacy_success={b.isOk}"
