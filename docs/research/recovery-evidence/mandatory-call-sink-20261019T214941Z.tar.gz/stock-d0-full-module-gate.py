from pathlib import Path
import importlib.util,json,subprocess as sp,os,datetime,traceback
prefix=Path('/tmp/stock-d0-affected-gates.py').read_text().split('\ntry:\n')[0].replace("Path('/tmp/stock-d0-affected-gates')","Path('/tmp/stock-d0-full-module-gate')")
exec(compile(prefix,'/tmp/stock-d0-affected-gates.py','exec'),globals())
spec=importlib.util.spec_from_file_location('s','/tmp/stock-execute-scheduler.py');sched=importlib.util.module_from_spec(spec);spec.loader.exec_module(sched)
_,mods,imports=sched.load_modules(view);wanted={n for n in mods if n=='FV' or n.startswith('FV.') or n=='FVTest' or n.startswith('FVTest.')}
heavy='FV.Backend.Proof.StockCmpWithFlags';excluded={heavy};q=[heavy];rdeps={n:[] for n in mods}
for n,deps in imports.items():
 for d in deps:rdeps[d].append(n)
while q:
 for n in rdeps[q.pop()]:
  if n not in excluded:excluded.add(n);q.append(n)
(root/'non-heavy-modules.txt').write_text('\n'.join(sorted(wanted-excluded))+'\n');(root/'pending-heavy-descendants.txt').write_text('\n'.join(sorted(wanted&excluded))+'\n')
command=['python3','/tmp/stock-execute-scheduler.py','--budget','16G','--max-jobs','3','--max-cap','16G','--default-cap','8G','--others-by-usage']
try:
 receipt=json.loads(Path('/tmp/stock-coherent-ci-adoption/receipt.json').read_text())
 assert receipt['returncode']==0 and receipt['ci_run']==39242870268,receipt
 run('validate-current-heavy-input-key',['lake','build','--no-build',heavy])
 run('all-modules',[*command,'--out',str(root/'all-modules'),'FV','FVTest'])
 run('library-replay',['lake','build','FV','FVTest'])
 run('e2e-axiom-audit',['python3','scripts/axiom-audit.py','--log-dir',str(root/'axiom-audit')])
 for i,entry in enumerate(json.loads(Path('/tmp/stock-d0-constant-audits/manifest.json').read_text())):
  run(f'all-constants-{i}',['lake','env','lean','--root=/tmp/stock-d0-constant-audits',entry['file']])
 report('full_current_module_and_trust_gates_passed',remaining='Require current runtime/encoder/E2E, verified crates and generated-proof gates; reconcile main and squash substantive production PR. Full original #140 remains after D0.')
except SystemExit:raise
except BaseException as e:report('failed',error=repr(e),traceback=traceback.format_exc());raise
