from pathlib import Path
import os,json,time,subprocess as sp,datetime,hashlib
pid=113213;out=Path('/tmp/stock-prologue-code-probe-check');view=Path('/home/lee/clifv/.worktrees/stock-driver-incremental')
assert 'stock-d0-full-module-gate.py' in Path(f'/proc/{pid}/cmdline').read_text()
def report(state,**kw):
 d={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':os.getpid(),'state':state,**kw};(out/'progress.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)
report('waiting_on_verified_full_gate',controller_pid=pid,max_combined_reserved_GiB=14)
while True:
 try:cmd=Path(f'/proc/{pid}/cmdline').read_text()
 except FileNotFoundError:break
 if 'stock-d0-full-module-gate.py' not in cmd:break
 time.sleep(10)
full=json.loads(Path('/tmp/stock-d0-full-module-gate/progress.json').read_text())
if full['state']!='full_current_module_and_trust_gates_passed':report('not_started_full_gate_failed',full_state=full['state']);raise SystemExit(0)
env=dict(os.environ,FV_MEMCAP='6G',FV_LAKE_CACHE='/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2');env['PATH']='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:'+env['PATH'];os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:2]);report('checking_current_dependency_keys')
with (out/'dependency-keys.log').open('w') as f:r=sp.run(['scripts/memcap.sh','lake','build','--no-build','FV.Backend.Lowering.StockD0','FV.Backend.Proof.DriverCheck'],cwd=view,env=env,stdout=f,stderr=sp.STDOUT)
if r.returncode:report('not_started_dependencies_not_current',returncode=r.returncode);raise SystemExit(0)
source=Path('/tmp/StockPrologueCodeProbe.lean');report('running_bounded_kernel_probe',head=sp.check_output(['git','rev-parse','HEAD'],cwd=view,text=True).strip(),source_sha256=hashlib.sha256(source.read_bytes()).hexdigest())
with (out/'kernel.log').open('w') as f:r=sp.run(['timeout','--signal=TERM','--kill-after=5s','60s','scripts/memcap.sh','lake','env','lean','--root=/tmp',str(source)],cwd=view,env=env,stdout=f,stderr=sp.STDOUT)
report('candidate_kernel_passed' if r.returncode==0 else 'candidate_not_proved_in_bounded_probe',returncode=r.returncode,limitation='Only one complete prologue configuration; other configurations, source witnesses, consumer variants, and production activation still required. This probe does not gate the earlier complete D0 class.')
