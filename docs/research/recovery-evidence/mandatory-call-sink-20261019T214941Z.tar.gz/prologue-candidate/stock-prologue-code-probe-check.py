from pathlib import Path
import os,signal,re,json,subprocess as sp,datetime,hashlib
scheduler=113274;out=Path('/tmp/stock-prologue-code-probe-check');out.mkdir(exist_ok=True);view=Path('/home/lee/clifv/.worktrees/stock-driver-incremental')
def report(state,**kw):
 d={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':os.getpid(),'state':state,**kw};(out/'progress.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)
assert 'stock-execute-scheduler.py' in Path(f'/proc/{scheduler}/cmdline').read_text()
paused=False
try:
 os.kill(scheduler,signal.SIGSTOP);paused=True;active={}
 for l in Path('/tmp/stock-d0-full-module-gate/all-modules/sched.log').read_text().splitlines():
  m=re.search(r' start (\S+) cap=(\d+)G',l)
  if m:active[m[1]]=int(m[2])
  m=re.search(r' done (\S+)',l)
  if m:active.pop(m[1],None)
 if sum(active.values())+6>16:
  report('not_started_slot_unavailable',active_caps=active);raise SystemExit(0)
 env=dict(os.environ,FV_MEMCAP='6G',FV_LAKE_CACHE='/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2');env['PATH']='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:'+env['PATH'];os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:2]);report('checking_current_dependency_keys',active_caps=active,combined_reserved_GiB=sum(active.values())+6)
 with (out/'dependency-keys.log').open('w') as f:r=sp.run(['scripts/memcap.sh','lake','build','--no-build','FV.Backend.Lowering.StockD0','FV.Backend.Proof.DriverCheck'],cwd=view,env=env,stdout=f,stderr=sp.STDOUT)
 if r.returncode:
  report('not_started_dependencies_not_current',returncode=r.returncode);raise SystemExit(0)
 source=Path('/tmp/StockPrologueCodeProbe.lean');report('running_bounded_kernel_probe',source_sha256=hashlib.sha256(source.read_bytes()).hexdigest())
 with (out/'kernel.log').open('w') as f:r=sp.run(['timeout','--signal=TERM','--kill-after=5s','60s','scripts/memcap.sh','lake','env','lean','--root=/tmp',str(source)],cwd=view,env=env,stdout=f,stderr=sp.STDOUT)
 report('candidate_kernel_passed' if r.returncode==0 else 'candidate_not_proved_in_bounded_probe',returncode=r.returncode)
finally:
 if paused:os.kill(scheduler,signal.SIGCONT)
 p=out/'progress.json'
 if p.exists():d=json.loads(p.read_text());d['scheduler_dispatch_resumed']=True;p.write_text(json.dumps(d,indent=2)+'\n')
