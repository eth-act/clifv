from pathlib import Path
import subprocess as sp, os, time, json, datetime, hashlib
pid=113213
out=Path('/tmp/stock-rule-history-bridge-check');out.mkdir(exist_ok=True)
def report(state,**kw):
 data={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':os.getpid(),'state':state,**kw};(out/'progress.json').write_text(json.dumps(data,indent=2)+'\n');print(json.dumps(data),flush=True)
report('waiting_on_verified_full_gate',controller_pid=pid)
while True:
 try:cmd=Path(f'/proc/{pid}/cmdline').read_text()
 except FileNotFoundError:break
 if 'stock-d0-full-module-gate.py' not in cmd:break
 time.sleep(10)
full=json.loads(Path('/tmp/stock-d0-full-module-gate/progress.json').read_text())
if full['state']!='full_current_module_and_trust_gates_passed':
 report('not_started_full_gate_failed',full_state=full['state']);raise SystemExit(1)
view=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');env=dict(os.environ,FV_MEMCAP='4G',FV_LAKE_CACHE='/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2');env['PATH']='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:'+env['PATH']
os.sched_setaffinity(0, sorted(os.sched_getaffinity(0))[:2])
source=Path('/tmp/StockRuleHistoryBridge.lean');report('running',sha256=hashlib.sha256(source.read_bytes()).hexdigest())
with (out/'kernel.log').open('w') as log:
 r=sp.run(['scripts/memcap.sh','lake','env','lean','--root=/tmp',str(source)],cwd=view,env=env,stdout=log,stderr=sp.STDOUT)
report('candidate_kernel_passed' if r.returncode==0 else 'candidate_failed',returncode=r.returncode,limitation='Only the general metadata-insensitivity bridge; full prologue class and production consumers remain unproved.')
raise SystemExit(r.returncode)
