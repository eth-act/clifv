Enable the first proved Stock production class: one-block i32/i64 functions that return their sole ordinary entry parameter, with default/System V/fast ABI and arbitrary symbols/run metadata. The default compiler and all four E2E pipeline variants use input dispatch with legacy fallback; every other source function retains legacy lowering.

The actual Stock output is compacted and proved equal to the complete legacy result for this class, including rule history. Fixed kernel proofs lift that fact to all-input compiler acceptance, errors, artifacts and arbitrary allocator effects without changing caller premises. Source witnesses cover arbitrary values and dirty upper bits. The edge guard rejects nonempty successor rows; later CFG classes must preserve their full payload. Stock errors retry legacy, whose work is deferred on Stock success.

The shared file/pipeline seams retain the complete lowered payload and old theorem variants. The existing proof emitter is shared with a real mixed Stock identity/legacy caller executable fixture. Generated proofs retain fallback, source index and allocator-answer index; the original nondefault-index fixture exposed and verifies these serialization fixes. Both cleanup modes use the default Lean ELF writer, actual executable compiler, checker and the same emitted bytes/proofs. Unoptimized Rust identity prologues remain on legacy until their different rule histories have an honest semantic bridge.

Validation (exact head and final gate lines to be filled after the live run):
- Current source: 567d1f0989e5d59d201a2731966660975166025c, base693b9b24. Full current FV/FVTest build/trust gate RUNNING; not a green claim.
- Both actual mixed linked runtime fixtures, generated kernel proofs and index/fallback provenance checks PASS on this source.
- Heavy unchanged dependency StockCmpWithFlags: exact-source CI39242870268 PASS; official coherent Lake cache restore validates371 up-to-date jobs without weakening the proof.
- New public roots, all changed public/private/generated constants, affected tools, runtime/encoder, both complete E2E identity/stage reports, default Lean-linked verified fv-demo/survey: current-head run pending. Earlier-head counts are not final evidence.
- Old163 theorem declaration headers and the two moved input-scope definitions preserved; final source audit pending.

This is the first production class, not completion of #140. Further integer/CFG/effect/call/exception classes, full source/block/whole-driver simulation and Stock-only completeness remain. Legacy fallback retires only after those obligations cover the original accepted domain.
