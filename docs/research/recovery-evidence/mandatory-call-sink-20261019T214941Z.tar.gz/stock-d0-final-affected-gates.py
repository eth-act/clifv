from pathlib import Path
import os,json,re,time,subprocess as sp,traceback
prefix=Path('/tmp/stock-d0-affected-gates.py').read_text().split('\ntry:\n')[0].replace("Path('/tmp/stock-d0-affected-gates')","Path('/tmp/stock-d0-final-affected-gates')")
exec(compile(prefix,'/tmp/stock-d0-affected-gates.py','exec'),globals())
buildpid=113213
assert 'stock-d0-full-module-gate.py' in Path(f'/proc/{buildpid}/cmdline').read_text()
def run_controller(name,path):
 frozen();p=root/(name+'.log');report('running',phase=name,log=str(p))
 with p.open('w') as log:r=sp.run(['python3',path],cwd=view,env=env,stdout=log,stderr=sp.STDOUT)
 assert r.returncode==0,(name,r.returncode,str(p));frozen();logs[name]={'path':str(p),'sha256':sha(p)}
try:
 report('waiting_on_verified_live_full_gate',controller_pid=buildpid)
 while True:
  try:cmd=Path(f'/proc/{buildpid}/cmdline').read_text()
  except FileNotFoundError:break
  if 'stock-d0-full-module-gate.py' not in cmd:break
  time.sleep(10)
 full=json.loads(Path('/tmp/stock-d0-full-module-gate/progress.json').read_text())
 assert full['state']=='full_current_module_and_trust_gates_passed',full['state']
 run('d0-runtime',['lake','env','lean','--run','FVTest/Backend/Lowering/StockD0Runtime.lean'])
 run('mixed-linked-program',['lake','env','lean','--run','FVTest/Backend/Lowering/StockD0Linked.lean','/tmp/stock-d0-linked-fixture'])
 run('d0-roots-audit',['python3','scripts/axiom-audit.py','scripts/audit/stock-d0.lean','--log-dir',str(root/'d0-roots-audit')])
 for i,entry in enumerate(json.loads(Path('/tmp/stock-d0-constant-audits/manifest.json').read_text())):
  run(f'all-constants-{i}', ['lake','env','lean','--root=/tmp/stock-d0-constant-audits',entry['file']])
 generated=Path('/tmp/stock-d0-linked-fixture');leanpath=sp.check_output(['lake','env','printenv','LEAN_PATH'],cwd=view,env=env,text=True).strip();saved=env.get('LEAN_PATH');env['LEAN_PATH']=str(generated)+':'+leanpath
 for name in ['StockD0MixedPlain','StockD0MixedCleanup']:
  p=generated/'Crates'/(name+'.lean');assert p.is_file();run('generated-'+name,['lean','--root='+str(generated),'-o',str(p.with_suffix('.olean')),str(p)])
 if saved is None:env.pop('LEAN_PATH',None)
 else:env['LEAN_PATH']=saved
 run('tools',['lake','build','lean-backend','lean-e2e-check','link-check','lean-link','clif-decode','lean-stock-lowering-compare'])
 run('runtime',['bash','scripts/lean-backend-filetests.sh'])
 run('encoder',['bash','scripts/lean-backend-encode-check.sh'])
 parity={}
 for label,flags,previous in [('e2e',[],'legacy-dead-cleanup-final-e2e-identities.json'),('legacy-e2e',['--no-dead-cleanup'],'legacy-dead-cleanup-final-legacy-e2e-identities.json')]:
  actual=root/(label+'-identities.json');run(label,['lake','exe','lean-e2e-check',*flags,'--identity-report',str(actual)])
  def ids(p):
   fs=json.loads(p.read_text())['functions'];result={(f['file'],f['index'],f['function']):tuple(f['stages']) for f in fs};assert len(result)==len(fs);return result
  a=ids(Path('/tmp')/previous);b=ids(actual);assert len(a)==1150 and a.keys()<=b.keys();assert all(a[k]==b[k] for k in a)
  parity[label]={'original':1150,'current':len(b),'all_original_identities_and_ordered_stages_preserved':True,'gained':len(b.keys()-a.keys())}
 (root/'identity-stage-parity.json').write_text(json.dumps(parity,indent=2)+'\n')
 run('stock-development-artifacts',['python3','-m','unittest','-v','test_stock_compiler_compare.StockDevelopmentIntegrationTests'])
 meta=json.loads(Path('/tmp/stock-cgclif-source.json').read_text());assert sha(Path(meta['output']))==meta['output_sha256'];assert sha(view/'scripts/patches/cg-clif-extnames.patch')==meta['patch_sha256']
 run('rust-tools',['cargo','build','--release','--locked','-p','cargo-fv','-p','clif-data-export','-p','lean-regalloc'],cwd=view/'rust')
 for example in ['fv-demo','survey']:run('verified-'+example,['bash','examples/compare.sh','examples/'+example,'--lean-link','--verified','--keep-temps'])
 report('final_affected_gates_passed',identity_stage_parity=parity)
 report('current_full_and_affected_gates_passed_pending_main_reconciliation',remaining='Inspect actual gate counts/source provenance; fetch main, open substantive non-draft PR and author squash under current policy. Full original #140 remains after first D0 production class.')
except BaseException as e:report('failed',error=repr(e),traceback=traceback.format_exc());raise
