from pathlib import Path
import subprocess as sp,os,json,hashlib,datetime
root=Path('/tmp/stock-main-693-cache-handoff');view=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');cache=Path('/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache');out=Path('/tmp/stock-main-693-cache-prefill');out.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
stages=sorted(root.rglob('outputs.jsonl'));assert len(stages)==9
keys=set();files=[]
for p in stages:
 rows=[json.loads(l) for l in p.read_text().splitlines()[1:] if l.strip()]
 keys.update(k for k,_ in rows);files.append({'path':str(p),'sha256':sha(p),'mappings':len(rows)})
existing={k:sha(p) for k in keys if (p:=cache/'outputs/fv'/(k+'.json')).exists()}
env=dict(os.environ,FV_MEMCAP='1G',FV_LAKE_CACHE=str(cache),OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2');env['PATH']='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:'+env['PATH'];os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:2])
for p in stages:
 log=out/(p.parent.name+'.log')
 with log.open('w') as f:r=sp.run(['scripts/memcap.sh','lake','cache','unstage',str(p.parent)],cwd=view,env=env,stdout=f,stderr=sp.STDOUT)
 assert r.returncode==0,(str(p),r.returncode)
changed=[k for k,h in existing.items() if sha(cache/'outputs/fv'/(k+'.json'))!=h]
missing=[k for k in keys if not (cache/'outputs/fv'/(k+'.json')).exists()]
receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'ci_run':39219555558,'ci_head':'693b9b24d8ff32a9421800b6d4bddc50c0c02bc5','head':sp.check_output(['git','rev-parse','HEAD'],cwd=view,text=True).strip(),'method':'Official lake cache unstage without force-overwrite; no source changes, trace removals, live build output mutations, or assigned input keys. Lake performs current input-key validation.','stages':files,'unique_input_keys':len(keys),'existing_before':len(existing),'missing_before':len(keys)-len(existing),'missing_after':missing,'observed_existing_mapping_changes':changed,'no_force_overwrite':True}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items() if k!='stages'}));assert not missing
