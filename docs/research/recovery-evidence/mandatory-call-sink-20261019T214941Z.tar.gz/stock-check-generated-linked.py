from pathlib import Path
import os,subprocess as sp,json
view=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');root=Path('/tmp/stock-d0-linked-fixture')
env=dict(os.environ,PATH='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:'+os.environ['PATH'],FV_MEMCAP='8G',FV_LAKE_CACHE='/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache',OMP_NUM_THREADS='2',LEAN_NUM_THREADS='2')
path=sp.check_output(['lake','env','printenv','LEAN_PATH'],cwd=view,env=env,text=True).strip();env['LEAN_PATH']=str(root)+':'+path
for name in ['StockD0MixedPlain','StockD0MixedCleanup']:
 p=root/'Crates'/(name+'.lean');log=Path('/tmp')/(name+'-kernel.log')
 with log.open('w') as f:r=sp.run(['scripts/memcap.sh','lean','--root='+str(root),'-o',str(p.with_suffix('.olean')),str(p)],cwd=view,env=env,stdout=f,stderr=sp.STDOUT)
 print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
