import Lean
import StockPrologueInputProbe
import FV.Backend.Proof.DriverCheck
namespace Backend.Stock.PrologueProbe
deriving instance DecidableEq for VBlock
deriving instance DecidableEq for VCode
deriving instance DecidableEq for Except
run_meta do
  for (name, _) in (← Lean.getEnv).constants.toList do
    if name.toString.endsWith "instDecidableEqVBlock" ||
        (name.toString.startsWith "Backend.Stock.PrologueProbe.instDecidableEq") then
      Lean.logInfo m!"{name}"
end Backend.Stock.PrologueProbe
