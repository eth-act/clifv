from pathlib import Path
import subprocess as sp,re,json,hashlib,datetime
root=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');base='693b9b24d8ff32a9421800b6d4bddc50c0c02bc5'
def git(*a): return sp.check_output(['git',*a],cwd=root,text=True)
def statements(text):
 result={}
 for m in re.finditer(r'^(?:private |protected )?theorem\s+([^\s({:]+)',text,re.M):
  end=text.find(':=',m.end())
  assert end>=0,m.group(0)
  key=m.group(1)
  assert key not in result,key
  result[key]=re.sub(r'\s+',' ',text[m.start():end]).strip()
 return result
files=git('diff','--name-only',base,'--','FV').splitlines();rows=[]
for name in files:
 old=sp.run(['git','show',base+':'+name],cwd=root,text=True,capture_output=True)
 if old.returncode: continue
 previous=statements(old.stdout);current=statements((root/name).read_text())
 missing=set(previous)-set(current);changed=[n for n in previous.keys()&current.keys() if previous[n]!=current[n]]
 assert not missing and not changed,(name,missing,changed)
 rows.append({'path':name,'original_theorem_statements_preserved':len(previous)})
# The two scope definitions moved verbatim; compare their definition terms separately.
old=git('show',base+':FV/Backend.lean');new=(root/'FV/Backend/InputScope.lean').read_text()
for name in ['abiSigs','verifiable']:
 pattern=rf'^def {name} .*?(?=\n\n)'
 a=re.search(pattern,old,re.M|re.S);b=re.search(pattern,new,re.M|re.S)
 assert a and b and a.group()==b.group(),name
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':base,'head':git('rev-parse','HEAD').strip(),'scope':'Exact source-level old theorem declaration preservation in changed existing FV modules; separate kernel compatibility proofs cover changed runtime definitions. Not an expression-hash equivalence claim.','rows':rows,'total_preserved':sum(x['original_theorem_statements_preserved'] for x in rows),'scope_definitions_verbatim':['Backend.abiSigs','Backend.verifiable']}
Path('/tmp/stock-d0-signature-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'total_preserved':result['total_preserved'],'modules':len(rows),'scope_definitions_verbatim':True}))
