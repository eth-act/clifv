import Crates.StockD0MixedPlain
import Crates.StockD0MixedCleanup
example : Crates.StockD0MixedPlain.input.fallback = true := by decide +kernel
example : Crates.StockD0MixedCleanup.input.fallback = true := by decide +kernel
example : Crates.StockD0MixedPlain.input.funcs[1]!.k = 1 := by decide +kernel
example : Crates.StockD0MixedPlain.input.funcs[1]!.j = 1 := by decide +kernel
example : Crates.StockD0MixedCleanup.input.funcs[1]!.k = 1 := by decide +kernel
example : Crates.StockD0MixedCleanup.input.funcs[1]!.j = 1 := by decide +kernel
