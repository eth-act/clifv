from pathlib import Path
import os,signal,re,json,subprocess as sp,datetime,hashlib
scheduler=113274;old=130369;root=Path('/tmp/stock-rule-history-bridge-check');view=Path('/home/lee/clifv/.worktrees/stock-driver-incremental')
assert 'stock-execute-scheduler.py' in Path(f'/proc/{scheduler}/cmdline').read_text()
assert 'stock-rule-history-bridge-check.py' in Path(f'/proc/{old}/cmdline').read_text()
previous=json.loads((root/'progress.json').read_text());assert previous['state']=='waiting_on_verified_full_gate'
(root/'previous-waiting-controller.json').write_text(json.dumps(previous,indent=2)+'\n')
os.kill(old,signal.SIGTERM)
def report(state,**kw):
 d={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':os.getpid(),'state':state,**kw};(root/'progress.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)
paused=False
try:
 os.kill(scheduler,signal.SIGSTOP);paused=True
 running={}
 for line in Path('/tmp/stock-d0-full-module-gate/all-modules/sched.log').read_text().splitlines():
  m=re.search(r' start (\S+) cap=(\d+)G',line)
  if m:running[m[1]]=int(m[2])
  m=re.search(r' done (\S+)',line)
  if m:running.pop(m[1],None)
 assert sum(running.values())+4<=16,running
 env=dict(os.environ,FV_MEMCAP='4G',FV_LAKE_CACHE='/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2');env['PATH']='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:'+env['PATH'];os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:2])
 source=Path('/tmp/StockRuleHistoryBridge.lean');report('running_reserved_slot',active_job_caps=running,combined_reserved_GiB=sum(running.values())+4,source_sha256=hashlib.sha256(source.read_bytes()).hexdigest())
 with (root/'kernel.log').open('w') as log:r=sp.run(['scripts/memcap.sh','lake','env','lean','--root=/tmp',str(source)],cwd=view,env=env,stdout=log,stderr=sp.STDOUT)
 report('candidate_kernel_passed' if r.returncode==0 else 'candidate_failed',returncode=r.returncode,limitation='General metadata bridge only; actual prologue relation and production consumer integration remain.')
finally:
 if paused:os.kill(scheduler,signal.SIGCONT)
 report_data=json.loads((root/'progress.json').read_text());report_data['scheduler_dispatch_resumed']=True;(root/'progress.json').write_text(json.dumps(report_data,indent=2)+'\n')
