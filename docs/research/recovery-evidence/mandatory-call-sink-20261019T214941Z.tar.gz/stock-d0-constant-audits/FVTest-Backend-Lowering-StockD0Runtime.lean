import Lean
import FVTest.Backend.Lowering.StockD0Runtime
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let targets : Array String := #["FVTest.Backend.Lowering.StockD0Runtime"]
  let mut count : Nat := 0
  for (name, _) in env.constants.toList do
    let some index := env.getModuleIdxFor? name | continue
    if !targets.contains env.header.moduleNames[index]!.toString then continue
    let axioms ← collectAxioms name
    for ax in axioms do
      unless #[``propext, ``Classical.choice, ``Quot.sound].contains ax do
        throwError "disallowed axiom {ax} in {name}"
    logInfo m!"DELIVERY_CONSTANT {Json.compress (toJson (name.toString, axioms.map Name.toString))}"
    count := count + 1
  unless count > 0 do throwError "empty constant audit"
  logInfo m!"DELIVERY_AXIOM_COUNT {count}"
