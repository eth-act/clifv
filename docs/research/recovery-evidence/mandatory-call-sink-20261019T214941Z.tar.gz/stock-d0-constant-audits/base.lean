import Lean
import FV.Backend
import FV.Backend.InputScope
import FV.Backend.Lowering.StockD0
import FV.Backend.Proof.LoweringPipeline
import FV.Backend.Proof.StockD0Code
import FV.Backend.Proof.StockD0Compiler
import FV.Backend.Proof.StockD0Dispatch
import FV.Backend.Proof.StockD0DispatchWitness
import FV.Backend.Proof.StockD0Edges
import FV.Backend.Proof.StockD0FallbackWitness
import FV.Backend.Proof.StockD0PipelineWitness
import FV.Backend.Proof.StockD0Source
import FV.Backend.Proof.StockD0Witness
import FV.E2E.DeadCleanupLinkCheck
import FV.E2E.DeadCleanupLinkScope
import FV.E2E.LinkCheck
import FV.E2E.LinkScope
import FV.E2E.LoweringPipeline
import FV.E2E.Statement
import FV.Link.DeadCleanupLayoutFacts
import FV.Link.DeadCleanupTotal
import FV.Link.LayoutFacts
import FV.Link.Total
import FVTest.E2E.LinkProof
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let targets : Array String := #["FV.Backend","FV.Backend.InputScope","FV.Backend.Lowering.StockD0","FV.Backend.Proof.LoweringPipeline","FV.Backend.Proof.StockD0Code","FV.Backend.Proof.StockD0Compiler","FV.Backend.Proof.StockD0Dispatch","FV.Backend.Proof.StockD0DispatchWitness","FV.Backend.Proof.StockD0Edges","FV.Backend.Proof.StockD0FallbackWitness","FV.Backend.Proof.StockD0PipelineWitness","FV.Backend.Proof.StockD0Source","FV.Backend.Proof.StockD0Witness","FV.E2E.DeadCleanupLinkCheck","FV.E2E.DeadCleanupLinkScope","FV.E2E.LinkCheck","FV.E2E.LinkScope","FV.E2E.LoweringPipeline","FV.E2E.Statement","FV.Link.DeadCleanupLayoutFacts","FV.Link.DeadCleanupTotal","FV.Link.LayoutFacts","FV.Link.Total","FVTest.E2E.LinkProof"]
  let mut count : Nat := 0
  for (name, _) in env.constants.toList do
    let some index := env.getModuleIdxFor? name | continue
    if !targets.contains env.header.moduleNames[index]!.toString then continue
    let axioms ← collectAxioms name
    for ax in axioms do
      unless #[``propext, ``Classical.choice, ``Quot.sound].contains ax do
        throwError "disallowed axiom {ax} in {name}"
    logInfo m!"DELIVERY_CONSTANT {Json.compress (toJson (name.toString, axioms.map Name.toString))}"
    count := count + 1
  unless count > 0 do throwError "empty constant audit"
  logInfo m!"DELIVERY_AXIOM_COUNT {count}"
