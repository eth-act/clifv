from pathlib import Path
import subprocess as sp,os,signal,time,json,re,hashlib,datetime
primary=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');root=Path('/home/lee/clifv/.worktrees/stock-mixed-production');sched=1763255
out=Path('/tmp/stock-mixed-current-main-normal-modules-batch4');out.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sp.check_output(['git','rev-parse','HEAD'],cwd=primary,text=True).strip()=='213fe68bfbda3ed5d237cb7df6651f47e5a189bc'
head=sp.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert head=='c1ce8e3d35eae33d21ed37a5abc6d9b3064e1dc2'
assert not sp.check_output(['git','diff','--name-only'],cwd=root,text=True).strip()
assert b'stock-execute-scheduler.py' in Path(f'/proc/{sched}/cmdline').read_bytes()
env=dict(os.environ,PATH='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:'+os.environ['PATH'],FV_MEMCAP='8G',FV_LAKE_CACHE='/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache',LEAN_NUM_THREADS='2',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2')
pat=re.compile(r'^(?:public\s+|private\s+|meta\s+)*import\s+(\S+)');deps={};ordered=[];seen=set()
def visit(m):
 if m in seen:return
 p=root/(m.replace('.','/')+'.lean')
 if not p.exists():return
 seen.add(m);ds=[x[1] for l in p.read_text().splitlines() if (x:=pat.match(l))];deps[m]=ds
 for d in ds:visit(d)
 ordered.append(m)
changed=sp.check_output(['git','diff','--name-only','213fe68bfbda3ed5d237cb7df6651f47e5a189bc..HEAD'],cwd=root,text=True).splitlines()
wanted={p[:-5].replace('/','.') for p in changed if p.endswith('.lean') and p.startswith(('FV/','FVTest/'))}
# Small unchanged data adapter: immediate imports must already be current.
# Build it once into the shared store, never launch its legacy dependency closure.
wanted.update({'FV.Backend.StockArithmeticCheck','FV.Backend.Unwind','FV.Backend.Proof.RelaxLayout'})
all_deps={}
for folder in ['FV','FVTest']:
 for file in (root/folder).rglob('*.lean'):
  module=str(file.relative_to(root))[:-5].replace('/','.')
  all_deps[module]={x[1] for line in file.read_text().splitlines() if (x:=pat.match(line))}
affected=set(wanted)
while True:
 more={m for m,ds in all_deps.items() if ds&affected}-affected
 if not more:break
 affected|=more
for m in sorted(wanted):visit(m)
ordered=[m for m in ordered if m in affected]
frozen={m:sha(root/(m.replace('.','/')+'.lean')) for m in ordered};records=[];stopped=False;skip_reason=None;leaf_cap_mib=8192;waiting=set()
try:
 os.kill(sched,signal.SIGSTOP);stopped=True
 deadline=time.monotonic()+60
 while True:
  kids=Path(f'/proc/{sched}/task/{sched}/children').read_text().split();live=[k for k in kids if Path(f'/proc/{k}/stat').exists() and Path(f'/proc/{k}/stat').read_text().split()[2]!='Z']
  if len(live)<=1:break
  
  if time.monotonic()>=deadline:
   skip_reason='two existing author kernels retained; no available slot';break
  time.sleep(.2)
 for k in live:
  caps=[v.decode().split('=',1)[1] for v in Path(f'/proc/{k}/environ').read_bytes().split(b'\0') if v.startswith(b'FV_MEMCAP=')];assert len(caps)==1
  cap=caps[0];amount=int(cap[:-1])*(1024 if cap[-1]=='G' else 1)
  leaf_cap_mib=min(leaf_cap_mib,16384-amount)
  if leaf_cap_mib<4096:skip_reason='existing author cap '+cap+' leaves less than 4G for a leaf'
 env['FV_MEMCAP']=str(leaf_cap_mib)+'M'
 started=time.monotonic();built=0
 for m in ([] if skip_reason else ordered):
  active=set()
  for event in Path('/tmp/stock-arithmetic-current-main-author-gates/all-modules/sched.log').read_text().splitlines():
   fields=event.split()
   if len(fields)>2 and fields[1]=='start':active.add(fields[2])
   elif len(fields)>2 and fields[1]=='done':active.discard(fields[2])
  if m in active:
   waiting.add(m);records.append({'module':m,'state':'waiting_for_active_author_build'});continue
  if time.monotonic()-started>120 or built>=8:break
  upstream=[d for d in deps[m] if d in waiting]
  if upstream:
   waiting.add(m);records.append({'module':m,'state':'waiting_for_transitive_imports','dependencies':upstream});continue
  log=out/(m+'.probe.log')
  with log.open('w') as f:r=sp.run([str(root/'scripts/memcap.sh'),'lake','build','--no-build',m],cwd=root,env=env,stdout=f,stderr=sp.STDOUT,timeout=25)
  if r.returncode==0:
   records.append({'module':m,'state':'source_key_current_or_restored','probe_log':str(log)});continue
  imports=[d for d in deps[m] if (root/(d.replace('.','/')+'.lean')).exists()];imports_log=out/(m+'.imports.log')
  with imports_log.open('w') as f:r=sp.run([str(root/'scripts/memcap.sh'),'lake','build','--no-build',*imports],cwd=root,env=env,stdout=f,stderr=sp.STDOUT,timeout=25) if imports else sp.CompletedProcess([],0)
  if r.returncode:
   waiting.add(m)
   records.append({'module':m,'state':'waiting_for_current_imports','log':str(imports_log)});continue
  log=out/(m+'.build.log')
  with log.open('w') as f:r=sp.run([str(root/'scripts/memcap.sh'),'lake','build',m],cwd=root,env=env,stdout=f,stderr=sp.STDOUT,)
  records.append({'module':m,'state':'built' if r.returncode==0 else 'failed','log':str(log),'returncode':r.returncode});built+=1
  assert r.returncode==0,('normal module failed',m,str(log))
 assert sp.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head
 assert all(sha(root/(m.replace('.','/')+'.lean'))==h for m,h in frozen.items())
finally:
 if stopped:os.kill(sched,signal.SIGCONT)
 result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'primary_head':'213fe68bfbda3ed5d237cb7df6651f47e5a189bc','source_sha256':frozen,'records':records,'skip_reason':skip_reason,'scheduler_resumed':stopped,'budget_GiB':16,'normal_leaf_cap_MiB':leaf_cap_mib,'max_active_builds':2,'cache':'own ignored .lake view, shared source-keyed artifactstore/hardlinks; no cachecopy','remaining':'Continue source-keyed normalmixedproof/consumer/tool/runtime gates; arithmeticcandidate must landfirst.'}
 (out/'receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'head':head,'counts':{s:sum(r['state']==s for r in records) for s in ['source_key_current_or_restored','built','waiting_for_current_imports','failed']},'scheduler_resumed':stopped,'skip_reason':skip_reason,'normal_leaf_cap_MiB':leaf_cap_mib,'receipt':str(out/'receipt.json')}),flush=True)
