from pathlib import Path
import os,signal,time,subprocess as sp,json,hashlib,datetime,re
root=Path('/home/lee/clifv/.worktrees/stock-mixed-production');sched=1763255;out=Path('/tmp/stock-mixed-current-normal-runtime-checked-oracle-pass');out.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
head=sp.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert head=='c1ce8e3d35eae33d21ed37a5abc6d9b3064e1dc2'
expected={'FV/E2E/StockArithmeticNIWitness.lean','FV/E2E/StockMixedWitness.lean','FVTest/Backend/Lowering/StockMixedRuntime.lean','FV/E2E/StockProductionFixtures.lean'}
actual=set(sp.check_output(['git','ls-files','-m','-o','--exclude-standard'],cwd=root,text=True).splitlines())-{'rust/target'};assert actual==expected,actual
frozen={p:sha(root/p) for p in expected};env=dict(os.environ,PATH='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:'+os.environ['PATH'],FV_LAKE_CACHE='/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache',LEAN_NUM_THREADS='2',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2');records=[];stopped=False
try:
 os.kill(sched,signal.SIGSTOP);stopped=True
 deadline=time.monotonic()+60
 while True:
  live=[]
  for k in Path(f'/proc/{sched}/task/{sched}/children').read_text().split():
   p=Path('/proc')/k
   if p.exists() and (p/'stat').read_text().split()[2]!='Z':live.append(k)
  if len(live)<=1:break
  if time.monotonic()>deadline:raise RuntimeError('author kernels retained; no slot')
  time.sleep(.2)
 cap=8192
 for k in live:
  c=next(e.decode().split('=',1)[1] for e in Path(f'/proc/{k}/environ').read_bytes().split(b'\0') if e.startswith(b'FV_MEMCAP='));amount=int(c[:-1])*(1024 if c[-1]=='G' else 1);cap=min(cap,16384-amount)
 assert cap>=2048,('insufficient reserved budget',cap)
 env['FV_MEMCAP']=str(cap)+'M'
 def run(label,args):
  p=out/(label+'.log')
  with p.open('w') as f:r=sp.run([str(root/'scripts/memcap.sh'),*args],cwd=root,env=env,stdout=f,stderr=sp.STDOUT)
  records.append({'label':label,'returncode':r.returncode,'log':str(p),'sha256':sha(p)});assert r.returncode==0,(label,str(p));return p
 pat=re.compile(r'^import (\S+)')
 for m in ['FV.E2E.StockProductionFixtures','FVTest.Backend.Lowering.StockMixedRuntime']:
  source=root/(m.replace('.','/')+'.lean');imports=[x[1] for l in source.read_text().splitlines() if (x:=pat.match(l))]
  run(m+'-imports',['lake','build','--no-build',*imports]);run(m,['lake','build',m])
 run('dual-allocator-runtime',['lake','env','lean','--run','FVTest/Backend/Lowering/StockMixedRuntime.lean'])
 missing=out/'oracle-that-does-not-exist';assert not missing.exists()
 source=(root/'FVTest/Backend/Lowering/StockMixedRuntime.lean').read_text()
 source=source.replace('def main : IO Unit := FVTest.StockMixedRuntime.check', 'def main : IO Unit := FVTest.StockMixedRuntime.checkConfiguration "missing-oracle" (FVTest.StockMixedRuntime.checkedRegalloc2 "'+str(missing)+'") .defaultI32')
 negative=out/'MissingOracle.lean';negative.write_text(source);log=out/'missing-oracle-negative-control.log'
 with log.open('w') as f:r=sp.run([str(root/'scripts/memcap.sh'),'lake','env','lean','--root='+str(out),'--run',str(negative)],cwd=root,env=env,stdout=f,stderr=sp.STDOUT)
 assert r.returncode!=0 and str(missing) in log.read_text() and ('no such file' in log.read_text().lower() or 'does not exist' in log.read_text().lower()),('negative control did not reject absent oracle',log)
 records.append({'label':'missing-oracle-negative-control','returncode':r.returncode,'expected_nonzero':True,'log':str(log),'sha256':sha(log)})

 assert all(sha(root/p)==h for p,h in frozen.items())
 # Only isle2lean changed between the completed release epoch and this current base;
 # lean-regalloc has no local workspace dependencies, and its source/manifests/lock are unchanged.
 unchanged=['rust/crates/lean-regalloc','rust/Cargo.toml','rust/Cargo.lock','rust/rust-toolchain.toml']
 assert not sp.check_output(['git','diff','087e91d1615c8c944e560c050c1eb7c60981d205..213fe68bfbda3ed5d237cb7df6651f47e5a189bc','--',*unchanged],cwd=root)
 state='passed'
finally:
 if stopped:os.kill(sched,signal.SIGCONT)
 result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head_before_fixture_extraction':head,'source_sha256':frozen,'records':records,'state':locals().get('state','incomplete_or_failed'),'leaf_cap_MiB':locals().get('cap'),'max_active_builds':2,'aggregate_MiB':16384,'scheduler_resumed':stopped,'regalloc2_binary_sha256':sha(root/'rust/target/release/lean-regalloc'),'remaining':'Normal module/kernel proof and complete class/current per-PR activation gates remain mandatory. Arithmetic lands first; full original140active.'};(out/'receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['records','source_sha256']}),flush=True)
