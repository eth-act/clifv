import FV.Backend.LinearScan
import FV.Backend.Lowering.StockD0
import FV.Backend.Proof.StockArithmeticBodyRefines
import FV.Backend.Proof.StockArithmeticEntryRefines
import FV.E2E.ABIReadOnlyMachine
import FV.Backend.Proof.IselCmpRun
import FV.Backend.Proof.StockArithmeticCheck

/-! Candidate next-class source bridge. Not part of the frozen activation run. -/
namespace Backend.Stock.Proof.MixedBody
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 8192
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm

/-- A syntactic family, with no execution or register-map certificate. -/
def Family (inst : Clif.Inst) : Prop :=
  (∃ subtract : Bool, ∃ ty x y,
    inst = .binary (if subtract then .isub else .iadd) ty x y) ∨
  (∃ ty c x y, inst = .select ty c x y)

private theorem select_result {f : Clif.Function} {ctx : Ctx} (inv : MappedCtxInv f ctx)
    {i : Nat} {info : IInfo} {ty : Clif.Ty} {c x y : Nat}
    (source : ctx.insts[i]? = some info)
    (clif : info.clif = some (.select ty c x y)) :
    ∃ z, info.results = [z] := by
  obtain ⟨tys,result,typed,arity⟩ := inv.resTys i info _ source clif
  have result' : tys = [ty] := by
    simpa [Clif.Inst.resultTypes] using result.symm
  rw [result'] at arity
  cases values : info.results with
  | nil => simp [values] at arity
  | cons z rest =>
    cases rest with
    | nil => exact ⟨z,rfl⟩
    | cons a tail => simp [values] at arity

private theorem scans_execute {exec : Nat → State → Except String Scan}
    {indices : List Nat} {input : State} {output : BlockScan}
    (cert : ScansSpec exec indices input output) :
    ∀ record ∈ output.records, exec record.inst record.input = .ok record.output := by
  induction cert with
  | nil input => simp
  | cons head rest ih =>
    intro record member
    rcases List.mem_cons.mp member with rfl | member
    · exact head
    · exact ih record member

/-- Derive actual emitted/omitted select and arithmetic record coverage from
original source syntax and successful lowering, retaining unused/dead operations. -/
theorem actual_mixed_families {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f)
    {b : Clif.Block} (blocks : f.blocks = [b])
    (family : ∀ stm ∈ b.body, Family stm.inst)
    {event : BlockScanEvent} (events : event ∈ result.blockScans.toList) :
    ∃ term body, SourceBodySplit f event b term body ∧
      ∀ record ∈ body.records, SelectAddSubOrOmittedRecord f event.ctx event.block record := by
  have quiet : ∀ stm ∈ b.body, colored stm.inst = false := by
    intro stm member
    rcases family stm member with ⟨subtract,ty,x,y,shape⟩ | ⟨ty,c,x,y,shape⟩
    · rw [shape]; cases subtract <;> rfl
    · rw [shape]; rfl
  obtain ⟨term,body,split,decisions⟩ := stock_lower_pure_body_decisions run scope blocks quiet events
  refine ⟨term,body,split,?_⟩
  intro record member
  obtain ⟨j,stm,statement,current⟩ := split.positions record member
  obtain ⟨step,recorded,decision⟩ := decisions record member
  rcases decision with omitted | emitted
  · exact Or.inl ⟨j,b,stm,split.block,statement,current,step,recorded,Or.inl omitted⟩
  · obtain ⟨info,source,clif,results⟩ :=
      ArithmeticBody.body_source_info run events split statement current
    have inv := (stock_lower_record_context run scope events).1
    obtain ⟨emission,emissionRun,scan⟩ := stock_emitted_scan
      (scans_execute split.scanned record member) recorded emitted
    have atInst : event.ctx.insts[record.inst]! = info := by
      simp only [Array.getElem!_eq_getD,Array.getD_eq_getD_getElem?,source,Option.getD_some]
    rcases family stm (List.mem_of_getElem? statement) with
      ⟨subtract,ty,x,y,shape⟩ | ⟨ty,c,x,y,shape⟩
    · have clif' : info.clif = some (.binary (if subtract then .isub else .iadd) ty x y) := by
        rw [clif,shape]
      obtain ⟨z,one⟩ := ArithmeticBody.arithmetic_result inv subtract source clif'
      obtain ⟨r,mapped⟩ := ArithmeticBody.emission_result_mapped emissionRun
        (by rw [atInst]; exact one)
      obtain ⟨a,rfl⟩ := inv.valueReg z r mapped
      exact Or.inr ⟨j,b,stm,split.block,statement,current,step,recorded,emitted,
        subtract,info,ty,x,y,z,a,source,clif',one,results.symm.trans one,mapped⟩
    · have clif' : info.clif = some (.select ty c x y) := by rw [clif,shape]
      obtain ⟨z,one⟩ := select_result inv source clif'
      obtain ⟨r,mapped⟩ := ArithmeticBody.emission_result_mapped emissionRun
        (by rw [atInst]; exact one)
      obtain ⟨a,rfl⟩ := inv.valueReg z r mapped
      exact Or.inl ⟨j,b,stm,split.block,statement,current,step,recorded,Or.inr
        ⟨emitted,info,ty,c,x,y,z,a,source,clif',one,results.symm.trans one,mapped⟩⟩

/-- Complete mixed ordinary-body simulation with record-family and map facts
derived internally, preserving the original source and related-world boundary. -/
theorem actual_mixed_body_refines {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    {b : Clif.Block} (blocks : f.blocks = [b])
    (family : ∀ stm ∈ b.body, Family stm.inst)
    {event : BlockScanEvent} (events : event ∈ result.blockScans.toList)
    {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem} (refines : Refines F isem)
    {MR : MemRelT} (stable : MRStable F MR) {env : Clif.Env} {cp : Clif.Program} :
    ∃ term body, SourceBodySplit f event b term body ∧
      ∀ s s', SourceSteps (IndexedSourceInst env cp f event.ctx event.block)
        ((List.range b.body.length).map (blockStart f event.block + ·)) s s' →
        ∀ ρ w, GuardedScanRel f result event.ctx event.block MR event.output.state s ρ w → ∃ ρ' w',
          seqRun isem (body.code.toList.map (·.mapRegs
            (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size + 1)))) ρ w =
            some (.fall ρ' w') ∧
          GuardedScanRel f result event.ctx event.block MR term.output.state s' ρ' w' := by
  obtain ⟨term,body,split,families⟩ := actual_mixed_families run scope blocks family events
  refine ⟨term,body,split,?_⟩
  intro s s' source ρ w held
  apply stock_lower_select_addsub_omitted_body_fall_refines run scope dominated events
    split.scanned split.retained families refines stable s s'
  · simpa only [sourceBodyIndices,List.reverse_reverse] using source
  · simpa only [split.state] using held


private theorem step_of_family {env : Clif.Env} {cp : Clif.Program}
    {s : Clif.State} {stm : Clif.Stmt} {rest : List Clif.Stmt}
    (remaining : s.frame.body = stm :: rest) (family : Family stm.inst) :
    Clif.step env cp s = Clif.StepResult.ofRes (Clif.evalInst s.frame s.mem stm.inst)
      (fun (vs,cm) => Clif.continueWith s rest stm.results vs cm) := by
  rcases family with ⟨subtract,ty,x,y,shape⟩ | ⟨ty,c,x,y,shape⟩
  all_goals unfold Clif.step; simp only [remaining,shape]

private theorem outcome_of_family {env : Clif.Env} {cp : Clif.Program}
    {fr : Clif.Frame} {cm : Clif.Mem} {inst : Clif.Inst} (family : Family inst) :
    instOutcome env cp fr cm inst = Clif.evalInst fr cm inst := by
  rcases family with ⟨subtract,ty,x,y,shape⟩ | ⟨ty,c,x,y,shape⟩
  all_goals rw [shape]; rfl

/-- The original executable source step supplies the mixed-family indexed step. -/
theorem actual_mixed_source_step {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) {event : BlockScanEvent}
    (events : event ∈ result.blockScans.toList) {b : Clif.Block} {term : ScanRecord} {body : BlockScan}
    (split : SourceBodySplit f event b term body) {record : ScanRecord} {j : Nat} {stm : Clif.Stmt}
    (statement : b.body[j]? = some stm) (current : record.inst = blockStart f event.block + j)
    (family : Family stm.inst)
    {env : Clif.Env} {cp : Clif.Program} {s t : Clif.State} {rest : List Clif.Stmt}
    (remaining : s.frame.body = stm :: rest) (next : Clif.step env cp s = .next t) :
    IndexedSourceInst env cp f event.ctx event.block record.inst
      (j,s.frame,s.mem) (j+1,t.frame,t.mem) := by
  obtain ⟨info,source,clif,results⟩ := ArithmeticBody.body_source_info run events split statement current
  have remaining' : s.frame.body = ⟨info.results,stm.inst⟩ :: rest := by
    rw [remaining,results]
  rw [step_of_family remaining family] at next
  cases evaluated : Clif.evalInst s.frame s.mem stm.inst with
  | trap code => simp only [evaluated,Clif.StepResult.ofRes] at next; cases next
  | stuck message => simp only [evaluated,Clif.StepResult.ofRes] at next; cases next
  | ok value =>
    obtain ⟨vals,mem⟩ := value
    simp only [evaluated,Clif.StepResult.ofRes] at next
    unfold Clif.continueWith at next
    cases written : s.frame.regs.setMany stm.results vals with
    | none => simp only [written] at next; cases next
    | some regs =>
      simp only [written] at next
      cases next
      refine ⟨current,rfl,info,stm.inst,vals,regs,rest,source,clif,remaining',?_,?_,rfl⟩
      · rw [outcome_of_family family]; exact evaluated
      · rw [results]; exact written

/-- Frame components untouched by the arithmetic source body. -/
def SourceFrameEq (s t : Clif.State) : Prop :=
  t.callers = s.callers ∧ t.frame.func = s.frame.func ∧
    t.frame.slots = s.frame.slots ∧ t.frame.term = s.frame.term

private theorem SourceFrameEq.trans {s t u : Clif.State}
    (first : SourceFrameEq s t) (second : SourceFrameEq t u) : SourceFrameEq s u :=
  ⟨second.1.trans first.1,second.2.1.trans first.2.1,
    second.2.2.1.trans first.2.2.1,second.2.2.2.trans first.2.2.2⟩

private theorem mixed_next_of_returned_frame {env : Clif.Env} {cp : Clif.Program}
    {fuel : Nat} {s : Clif.State} {stm : Clif.Stmt} {rest : List Clif.Stmt}
    (remaining : s.frame.body = stm :: rest) (family : Family stm.inst)
    {vals : List Clif.Val} {mem : Clif.Mem}
    (returned : Clif.runLoop env cp (fuel+1) s = .returned vals mem) :
    ∃ t, Clif.step env cp s = .next t ∧ t.frame.body = rest ∧
      Clif.runLoop env cp fuel t = .returned vals mem ∧ SourceFrameEq s t := by
  have step : Clif.step env cp s =
      Clif.StepResult.ofRes (Clif.evalInst s.frame s.mem stm.inst)
        (fun (vs,cm) => Clif.continueWith s rest stm.results vs cm) := by
    exact step_of_family remaining family
  rw [Clif.runLoop_succ,step] at returned
  cases evaluated : Clif.evalInst s.frame s.mem stm.inst with
  | trap code => simp only [evaluated,Clif.StepResult.ofRes] at returned; cases returned
  | stuck message => simp only [evaluated,Clif.StepResult.ofRes] at returned; cases returned
  | ok value =>
    obtain ⟨vs,cm⟩ := value
    simp only [evaluated,Clif.StepResult.ofRes] at returned
    unfold Clif.continueWith at returned
    cases written : s.frame.regs.setMany stm.results vs with
    | none => simp only [written] at returned; cases returned
    | some regs =>
      simp only [written] at returned
      refine ⟨{s with frame := {s.frame with regs,body := rest},mem := cm},?_,rfl,returned,rfl,rfl,rfl,rfl⟩
      rw [step,evaluated]
      simp only [Clif.StepResult.ofRes,Clif.continueWith,written]

/-- The actual reference run supplies every ordinary arithmetic source step,
including the residual fuel and the exact state at the terminator. -/
theorem actual_mixed_source_execution_frame {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) {event : BlockScanEvent}
    (events : event ∈ result.blockScans.toList) {b : Clif.Block} {term : ScanRecord} {body : BlockScan}
    (split : SourceBodySplit f event b term body)
    (family : ∀ stm ∈ b.body, Family stm.inst)
    {env : Clif.Env} {cp : Clif.Program} {fuel j : Nat} {s : Clif.State}
    (bound : j ≤ b.body.length) (remaining : s.frame.body = b.body.drop j)
    {vals : List Clif.Val} {mem : Clif.Mem}
    (returned : Clif.runLoop env cp fuel s = .returned vals mem) :
    ∃ t left, left + (b.body.length-j) = fuel ∧
      Clif.runLoop env cp left t = .returned vals mem ∧ t.frame.body = [] ∧
      SourceSteps (IndexedSourceInst env cp f event.ctx event.block)
        (List.range' (blockStart f event.block+j) (b.body.length-j))
        (j,s.frame,s.mem) (b.body.length,t.frame,t.mem) ∧ SourceFrameEq s t := by
  induction fuel generalizing j s with
  | zero => cases returned
  | succ fuel ih =>
    by_cases done : j = b.body.length
    · subst j
      refine ⟨s,fuel+1,by omega,returned,?_,?_,rfl,rfl,rfl,rfl⟩
      · simpa using remaining
      · simp only [Nat.sub_self,List.range'_zero]
        exact .nil _
    · have inside : j < b.body.length := by omega
      let stm := b.body[j]
      have statement : b.body[j]? = some stm := List.getElem?_eq_getElem inside
      have head : s.frame.body = stm :: b.body.drop (j+1) := by
        rw [remaining,List.drop_eq_getElem_cons inside]
      have instFamily := family stm (List.mem_of_getElem? statement)
      obtain ⟨next,stepped,rest,returned',frame⟩ := mixed_next_of_returned_frame head instFamily returned
      obtain ⟨t,left,total,ends,empty,tail,tailFrame⟩ := ih (by omega) rest returned'
      have current := actual_mixed_source_step run events split
        (record := ⟨blockStart f event.block+j,default,default⟩) statement rfl instFamily head stepped
      refine ⟨t,left,by omega,ends,empty,?_,SourceFrameEq.trans frame tailFrame⟩
      have length : b.body.length-j = (b.body.length-(j+1))+1 := by omega
      rw [length,List.range'_succ]
      simpa only [Nat.add_assoc,Nat.add_comm 1 j] using SourceSteps.cons current tail

private theorem return_done_of_runLoop {env : Clif.Env} {cp : Clif.Program}
    {s : Clif.State} {xs : List Nat} {fuel : Nat} {vals : List Clif.Val} {mem : Clif.Mem}
    (empty : s.frame.body = []) (callers : s.callers = []) (term : s.frame.term = .ret xs)
    (returned : Clif.runLoop env cp fuel s = .returned vals mem) :
    Clif.stepTerm env cp s (.ret xs) = .done vals mem := by
  cases fuel with
  | zero => cases returned
  | succ fuel =>
    rw [Clif.runLoop_succ,Clif.step_term env cp s empty,term] at returned
    cases step : Clif.stepTerm env cp s (.ret xs) with
    | next t => exact False.elim ((stepTerm_ret callers).1 t step)
    | done vs cm =>
      simp only [step,Clif.Outcome.returned.injEq] at returned
      obtain ⟨rfl,rfl⟩ := returned
      rfl
    | trapped c => simp only [step] at returned; cases returned
    | stuck message => simp only [step] at returned; cases returned

private theorem factor_seg {vb : VBlock} {pre code post : Array MInst}
    (parts : vb.insts = pre ++ code ++ post) : SegAt vb pre.size code.toList := by
  intro k hk
  have bound : k < code.size := by simpa using hk
  rw [parts,Array.append_assoc,Array.getElem?_append_right (by omega)]
  simp only [Nat.add_sub_cancel_left]
  rw [Array.getElem?_append_left bound]
  simp [bound]

/-- Actual source execution and the actual emitted arithmetic body/return reach
an ABI-correct return in Stock's returned VCode. Source steps, terminal definedness,
caller/frame transport and segment placement are all derived internally. -/
theorem actual_mixed_return_refines_at {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    (abi : sigAbiOk f.sig = true) {b : Clif.Block} (blocks : f.blocks = [b])
    (family : ∀ stm ∈ b.body, Family stm.inst)
    {xs : List Nat} (ret : b.term = .ret xs)
    {event : BlockScanEvent} (events : event ∈ result.blockScans.toList)
    {env : Clif.Env} {cp : Clif.Program} {fuel : Nat} {s : Clif.State}
    (func : s.frame.func = f) (callers : s.callers = [])
    (remaining : s.frame.body = b.body) (terminal : s.frame.term = b.term)
    (defined : SourceDefinedAt f result.ctx event.block 0 s.frame)
    {vals : List Clif.Val} {mem : Clif.Mem}
    (returned : Clif.runLoop env cp fuel s = .returned vals mem)
    {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem} (refines : Refines F isem)
    {MR : MemRelT} (stable : MRStable F MR)
    {label : Nat} {vb : VBlock} {pre post : Array MInst}
    (placed : result.code.blocks[label]? = some vb)
    (code : vb.insts = pre ++ event.output.code.map (·.mapRegs
      (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1))) ++ post) :
    ∀ ρ w, GuardedScanRel f result event.ctx event.block MR event.output.state
      (0,s.frame,s.mem) ρ w →
      RunOkABI f result.code isem MR s.frame.slots ⟨label,pre.size,ρ,w⟩ (.returned vals mem) := by
  obtain ⟨term,body,split,families⟩ := actual_mixed_families run scope blocks family events
  have start : s.frame.body = b.body.drop 0 := by simpa using remaining
  obtain ⟨t,left,total,ends,empty,steps,frame⟩ := actual_mixed_source_execution_frame
    run events split family (j := 0) (by omega) start returned
  have tDefined : SourceDefinedAt f result.ctx event.block b.body.length t.frame := by
    apply ArithmeticBody.arithmetic_steps_defined run scope dominated events split.block
      (env := env) (cp := cp) (s := (0,s.frame,s.mem)) (t := (b.body.length,t.frame,t.mem))
      (j := 0) (n := b.body.length) (by omega) rfl ?_ defined
    simpa only [Nat.add_zero,Nat.sub_zero] using steps
  have tFunc : t.frame.func = f := frame.2.1.trans func
  have tCallers : t.callers = [] := frame.1.trans callers
  have tTerm : t.frame.term = .ret xs := frame.2.2.2.trans (terminal.trans ret)
  have done := return_done_of_runLoop empty tCallers tTerm ends
  let resolve := Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1)
  have pieces : vb.insts = pre ++ body.code.map (·.mapRegs resolve) ++
      (term.output.emitted.map (·.mapRegs resolve) ++ post) := by
    simp only [code,split.code,Array.map_append,Array.append_assoc,resolve]
  have bodySeg : SegAt vb pre.size (body.code.toList.map (·.mapRegs resolve)) := by
    simpa only [Array.toList_map] using factor_seg pieces
  have termPieces : vb.insts = (pre ++ body.code.map (·.mapRegs resolve)) ++
      term.output.emitted.map (·.mapRegs resolve) ++ post := by
    simpa only [Array.append_assoc] using pieces
  have termSeg : SegAt vb (pre.size+body.code.size)
      (term.output.emitted.toList.map (·.mapRegs resolve)) := by
    simpa only [Array.size_append,Array.size_map,Array.toList_map] using factor_seg termPieces
  have termMember : term ∈ event.output.records := by rw [split.records]; exact List.mem_cons_self
  intro ρ w held
  obtain ⟨ρ',w',executed,postHeld⟩ := stock_lower_select_addsub_omitted_body_fall_refines
    run scope dominated events split.scanned split.retained families refines stable
    (0,s.frame,s.mem) (b.body.length,t.frame,t.mem)
    (by simpa only [sourceBodyIndices,List.reverse_reverse,Nat.add_zero,Nat.sub_zero,List.range'_eq_map_range] using steps)
    ρ w (by simpa only [split.state] using held)
  obtain ⟨heldFunc,dfg,memory,values⟩ := postHeld
  obtain ⟨step,rs,ps,extra,recorded,emitted,termCode,rest⟩ :=
    stock_lower_return_record_source_run_auto run scope dominated abi events split.block ret
      termMember split.termInst tFunc tCallers done tDefined values refines stable
  have nonempty : 0 < term.output.emitted.size := by rw [termCode]; exact Nat.zero_lt_succ 0
  have room : pre.size + (body.code.toList.map (·.mapRegs resolve)).length < vb.insts.size := by
    have sizes := congrArg Array.size pieces
    simp only [Array.size_append,Array.size_map] at sizes
    simp only [List.length_map,Array.length_toList]
    omega
  have path := seqRun_fall_star (vc := result.code) (sem := isem) placed bodySeg room executed
  have finished := stock_lower_return_record_runOk run scope dominated abi events split.block ret
    termMember split.termInst tFunc tCallers done tDefined values refines stable placed termSeg w' memory
  have combined := RunOkABI.prefix path (by simpa only [List.length_map,Array.length_toList] using finished)
  simpa only [frame.2.2.1] using combined

/-- Compatibility variant retaining existential body placement. -/
theorem actual_mixed_return_refines {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    (abi : sigAbiOk f.sig = true) {b : Clif.Block} (blocks : f.blocks = [b])
    (family : ∀ stm ∈ b.body, Family stm.inst)
    {xs : List Nat} (ret : b.term = .ret xs)
    {event : BlockScanEvent} (events : event ∈ result.blockScans.toList)
    {env : Clif.Env} {cp : Clif.Program} {fuel : Nat} {s : Clif.State}
    (func : s.frame.func = f) (callers : s.callers = [])
    (remaining : s.frame.body = b.body) (terminal : s.frame.term = b.term)
    (defined : SourceDefinedAt f result.ctx event.block 0 s.frame)
    {vals : List Clif.Val} {mem : Clif.Mem}
    (returned : Clif.runLoop env cp fuel s = .returned vals mem)
    {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem} (refines : Refines F isem)
    {MR : MemRelT} (stable : MRStable F MR) :
    ∃ label k, ∀ ρ w, GuardedScanRel f result event.ctx event.block MR event.output.state
      (0,s.frame,s.mem) ρ w →
      RunOkABI f result.code isem MR s.frame.slots ⟨label,k,ρ,w⟩ (.returned vals mem) := by
  obtain ⟨label,vb,pre,post,placed,code⟩ := stock_lower_block_scan_code run events
  exact ⟨label,pre.size,actual_mixed_return_refines_at run scope dominated abi blocks family ret
    events func callers remaining terminal defined returned refines stable placed code⟩

/-- Original function entry derives the frame, caller and source-definedness
premises of the actual arithmetic return simulation. -/
theorem actual_mixed_entered_return_refines {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    (abi : sigAbiOk f.sig = true) {b : Clif.Block} (blocks : f.blocks = [b])
    (family : ∀ stm ∈ b.body, Family stm.inst)
    {xs : List Nat} (ret : b.term = .ret xs)
    {event : BlockScanEvent} (events : event ∈ result.blockScans.toList)
    {args : List Clif.Val} {cm0 cm : Clif.Mem} {fr : Clif.Frame}
    (entered : Clif.enterFunc f args cm0 = .ok (fr,cm))
    {env : Clif.Env} {cp : Clif.Program} {fuel : Nat} {vals : List Clif.Val} {mem : Clif.Mem}
    (returned : Clif.runLoop env cp fuel ⟨fr,[],cm⟩ = .returned vals mem)
    {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem} (refines : Refines F isem)
    {MR : MemRelT} (stable : MRStable F MR) :
    ∃ label k, ∀ ρ w, GuardedScanRel f result event.ctx event.block MR event.output.state
      (0,fr,cm) ρ w →
      RunOkABI f result.code isem MR fr.slots ⟨label,k,ρ,w⟩ (.returned vals mem) := by
  obtain ⟨b',regs,entry,types,paramTypes,set,slots,frame⟩ := Opt.enterFunc_ok entered
  have same : b' = b := by
    have found : some b = some b' := by simpa only [Clif.Function.entry?,blocks,List.head?_cons] using entry
    exact Option.some.inj found.symm
  subst b'
  obtain ⟨term,body,split,families⟩ := actual_mixed_families run scope blocks family events
  have bound := (List.getElem?_eq_some_iff.mp split.block).1
  rw [blocks] at bound
  have zero : event.block = 0 := by simpa using bound
  have defined : SourceDefinedAt f result.ctx event.block 0 fr := by
    rw [zero]
    exact source_defined_enterFunc dominated result.ctx entered
  apply actual_mixed_return_refines run scope dominated abi blocks family ret events
    (s := ⟨fr,[],cm⟩) (by rw [frame]) rfl
    (by rw [frame]) (by rw [frame]) defined returned refines stable

private theorem return_inbounds {vc : VCode} {isem : Backend.Proof.Sem}
    {vs : VState CV Arm.ArmState} {us : List (Reg × Reg)} {vals : List CV} {w : Arm.ArmState}
    (ret : VRetFrom vc isem vs us vals w) {block : VBlock}
    (placed : vc.blocks[vs.b]? = some block) : vs.k < block.insts.size := by
  obtain ⟨b,k,ρ,w₁,vb,ops,outs,path,atBlock,instruction,_⟩ := ret
  cases path with
  | refl =>
    have same : block = vb := Option.some.inj (placed.symm.trans atBlock)
    subst vb
    exact (Array.getElem?_eq_some_iff.mp instruction).1
  | step first rest =>
    cases first with
    | step found instruction operands semantics length next =>
      have same : block = _ := Option.some.inj (placed.symm.trans found)
      subst same
      exact (Array.getElem?_eq_some_iff.mp instruction).1

/-- Complete original-entry-to-return simulation of arbitrary single-block
add/sub bodies in the actual Stock VCode. ABI materialization, omitted parameter
values, final aliases, source execution and machine PC placement are derived
internally. The allocation checker may choose the proof-selected initial file. -/
theorem actual_mixed_entry_return_refines_frame {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    (abi : sigAbiOk f.sig = true) {b : Clif.Block} (blocks : f.blocks = [b])
    (family : ∀ stm ∈ b.body, Family stm.inst)
    {xs : List Nat} (ret : b.term = .ret xs)
    {args : List Clif.Val} {cm : Clif.Mem} {fr : Clif.Frame}
    (entered : SourceEntry f args fr)
    {env : Clif.Env} {cp : Clif.Program} {fuel : Nat} {vals : List Clif.Val} {mem : Clif.Mem}
    (returned : Clif.runLoop env cp fuel ⟨fr,[],cm⟩ = .returned vals mem)
    {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem} (refines : Refines F isem)
    (driver : DriverSem isem) {sb : Nat} {syms : String → Option Nat}
    (memorySem : MemRefines F sb syms isem) {MR : MemRelT} (stable : MRStable F MR)
    {w : Arm.ArmState} (memory : MR fr.slots cm w)
    (arguments : ArgsAtEntry F f.sig args w) :
    ∃ ρ, RunOkABI f result.code isem MR fr.slots ⟨0,0,ρ,w⟩ (.returned vals mem) := by
  obtain ⟨event,vb,pre,body,ρ',w',events,zero,placed,pieces,execution,mem',values,same,
    after,bodyCode⟩ := stock_lower_entry_prelude_refines_frame run scope dominated entered driver
      memorySem stable memory arguments
  have code : vb.insts = pre ++ event.output.code.map (·.mapRegs
      (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1))) ++ after := by
    rw [pieces,bodyCode,Array.append_assoc]
  have entryFacts := entered
  obtain ⟨b',regs,entry,argTypes,paramTypes,set,frame⟩ := entryFacts
  have sameBlock : b' = b := by
    have found : some b = some b' := by
      simpa only [Clif.Function.entry?,blocks,List.head?_cons] using entry
    exact Option.some.inj found.symm
  subst b'
  have defined : SourceDefinedAt f result.ctx event.block 0 fr := by
    rw [zero]
    exact source_defined_entry_frame dominated result.ctx entered
  have held := stock_lower_entered_values_guarded_frame run scope dominated events entered values
    event.output.state w' mem'
  have finished := actual_mixed_return_refines_at run scope dominated abi blocks family ret events
    (s := ⟨fr,[],cm⟩) (by rw [frame]) rfl (by rw [frame]) (by rw [frame])
    defined returned refines stable placed code ρ' w' held
  have room : pre.size < vb.insts.size := by
    obtain ⟨us,outs,world,cm',reached,_⟩ := finished
    exact return_inbounds reached placed
  have segment : SegAt vb 0 pre.toList := by
    intro k bound
    have inside : k < pre.size := by simpa only [Array.length_toList] using bound
    rw [Nat.zero_add,pieces,Array.getElem?_append_left inside]
    simp [inside]
  have path := seqRun_fall_star (vc := result.code) (sem := isem) placed segment
    (by simpa only [Nat.zero_add,Array.length_toList] using room) execution
  refine ⟨entrySeed event.ctx fr,RunOkABI.prefix path ?_⟩
  simpa only [Nat.zero_add,Array.length_toList] using finished

/-- Executable-entry compatibility variant; retains the original statement. -/
theorem actual_mixed_entry_return_refines {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    (abi : sigAbiOk f.sig = true) {b : Clif.Block} (blocks : f.blocks = [b])
    (family : ∀ stm ∈ b.body, Family stm.inst)
    {xs : List Nat} (ret : b.term = .ret xs)
    {args : List Clif.Val} {cm0 cm : Clif.Mem} {fr : Clif.Frame}
    (entered : Clif.enterFunc f args cm0 = .ok (fr,cm))
    {env : Clif.Env} {cp : Clif.Program} {fuel : Nat} {vals : List Clif.Val} {mem : Clif.Mem}
    (returned : Clif.runLoop env cp fuel ⟨fr,[],cm⟩ = .returned vals mem)
    {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem} (refines : Refines F isem)
    (driver : DriverSem isem) {sb : Nat} {syms : String → Option Nat}
    (memorySem : MemRefines F sb syms isem) {MR : MemRelT} (stable : MRStable F MR)
    {w : Arm.ArmState} (memory : MR fr.slots cm w)
    (arguments : ArgsAtEntry F f.sig args w) :
    ∃ ρ, RunOkABI f result.code isem MR fr.slots ⟨0,0,ρ,w⟩ (.returned vals mem) := by
  exact actual_mixed_entry_return_refines_frame run scope dominated abi blocks family ret (SourceEntry.of_enterFunc entered) returned refines driver memorySem stable memory arguments


private theorem get_notrap (fr : Clif.Frame) (x : Nat) (c : Clif.TrapCode) :
    fr.get x ≠ .trap c := by
  cases found : fr.regs x <;> simp [Clif.Frame.get,Clif.Res.ofOption,found]

private theorem getAs_notrap (fr : Clif.Frame) (x : Nat) (ty : Clif.Ty) (c : Clif.TrapCode) :
    fr.getAs x ty ≠ .trap c := by
  cases found : fr.get x with
  | trap code => exact False.elim (get_notrap fr x code found)
  | stuck message => simp [Clif.Frame.getAs,found]
  | ok value => cases cast : value.as? ty <;> simp [Clif.Frame.getAs,found,Clif.Res.ofOption,cast]

private theorem getMany_notrap (fr : Clif.Frame) (xs : List Nat) (c : Clif.TrapCode) :
    fr.getMany xs ≠ .trap c := by
  induction xs generalizing c with
  | nil => simp [Clif.Frame.getMany]
  | cons x xs ih =>
    cases found : fr.get x with
    | trap code => exact False.elim (get_notrap fr x code found)
    | stuck message => simp [Clif.Frame.getMany,found]
    | ok value =>
      cases rest : fr.getMany xs with
      | trap code => exact False.elim ((ih code) rest)
      | stuck message => simp [Clif.Frame.getMany,found,rest]
      | ok values => simp [Clif.Frame.getMany,found,rest]

private theorem arithmetic_notrap (fr : Clif.Frame) (cm : Clif.Mem)
    (subtract : Bool) (ty : Clif.Ty) (x y : Nat) (c : Clif.TrapCode) :
    Clif.evalInst fr cm (.binary (if subtract then .isub else .iadd) ty x y) ≠ .trap c := by
  cases subtract <;>
    simp only [Bool.false_eq_true,ite_false,ite_true,Clif.evalInst,Clif.BinaryOp.isShift]
  all_goals
    cases left : fr.getAs x ty with
    | trap code => exact False.elim (getAs_notrap fr x ty code left)
    | stuck message => simp
    | ok a =>
      cases right : fr.getAs y ty with
      | trap code => exact False.elim (getAs_notrap fr y ty code right)
      | stuck message => simp
      | ok b => simp

private theorem family_notrap (fr : Clif.Frame) (cm : Clif.Mem)
    {inst : Clif.Inst} (family : Family inst) (c : Clif.TrapCode) :
    Clif.evalInst fr cm inst ≠ .trap c := by
  rcases family with ⟨subtract,ty,x,y,rfl⟩ | ⟨ty,condition,x,y,rfl⟩
  · exact arithmetic_notrap fr cm subtract ty x y c
  · simp only [Clif.evalInst]
    cases cond : fr.get condition with
    | trap code => exact False.elim (get_notrap fr condition code cond)
    | stuck message => simp
    | ok cv =>
      cases left : fr.getAs x ty with
      | trap code => exact False.elim (getAs_notrap fr x ty code left)
      | stuck message => simp
      | ok a =>
        cases right : fr.getAs y ty with
        | trap code => exact False.elim (getAs_notrap fr y ty code right)
        | stuck message => simp
        | ok b => simp

/-- Pure add/sub source bodies ending in return cannot produce a trap, even
when malformed operands instead make the executable semantics stuck. -/
theorem mixed_source_notrap {env : Clif.Env} {cp : Clif.Program} (fuel : Nat)
    (s : Clif.State) (callers : s.callers = [])
    (family : ∀ stm ∈ s.frame.body, Family stm.inst)
    {xs : List Nat} (ret : s.frame.term = .ret xs) (code : Clif.TrapCode) :
    Clif.runLoop env cp fuel s ≠ .trapped code := by
  induction fuel generalizing s with
  | zero => simp
  | succ fuel ih =>
    rw [Clif.runLoop_succ]
    cases remaining : s.frame.body with
    | nil =>
      rw [Clif.step_term env cp s remaining,ret,Clif.stepTerm]
      cases values : s.frame.getMany xs with
      | trap c => exact False.elim (getMany_notrap s.frame xs c values)
      | stuck message => simp
      | ok vals =>
        simp only [Clif.StepResult.ofRes]
        by_cases typed : vals.map (·.ty) = Clif.AbiParam.tys s.frame.func.sig.returns <;>
          simp [Clif.returnValues,Clif.checkTys,Clif.Res.check,callers,Clif.StepResult.ofRes,typed]
    | cons stm rest =>
      have instFamily := family stm (by simp [remaining])
      rw [Clif.step_inst env cp s stm rest remaining
        (by
          intro fn args h
          rcases instFamily with ⟨subtract,ty,x,y,shape⟩ | ⟨ty,c,x,y,shape⟩
          all_goals rw [shape] at h; cases h)
        (by
          intro sig callee args h
          rcases instFamily with ⟨subtract,ty,x,y,shape⟩ | ⟨ty,c,x,y,shape⟩
          all_goals rw [shape] at h; cases h)]
      cases evaluated : Clif.evalInst s.frame s.mem stm.inst with
      | trap c => exact False.elim (family_notrap s.frame s.mem instFamily c evaluated)
      | stuck message => simp
      | ok pair =>
        rcases pair with ⟨values,cm⟩
        simp only [Clif.StepResult.ofRes,Clif.continueWith]
        cases written : s.frame.regs.setMany stm.results values with
        | none => simp
        | some regs =>
          simp only
          apply ih {s with frame := {s.frame with regs,body := rest},mem := cm} callers ?_ ret
          intro other member
          apply family other
          rw [remaining]
          exact List.mem_cons_of_mem _ member


end Backend.Stock.Proof.MixedBody

namespace E2E.MixedFlagBoundary
open Backend Backend.Proof Backend.Proof.Driver Backend.DeadCleanup
set_option autoImplicit false
set_option Elab.async false

/-- Additional forms actually used by parameter-conditioned scalar select.
This classifier does not change the dead-code-removal whitelist. -/
def extra : MInst → Bool
  | .aluRRR .subS _ .xzr (.vreg _ .int) .xzr => true
  | .csel (.vreg _ .int) (.vreg _ .int) (.vreg _ .int) _ => true
  | _ => false

/-- Executable facts expose only concrete instruction shapes. -/
theorem extra_cases {i : MInst} (checked : extra i = true) :
    (∃ sz n, i = .aluRRR .subS sz .xzr (.vreg n .int) .xzr) ∨
    (∃ d n m c, i = .csel (.vreg d .int) (.vreg n .int) (.vreg m .int) c) := by
  cases i with
  | aluRRR op sz rd rn rm =>
    cases op <;> try cases checked
    cases rd <;> try cases checked
    cases rn <;> try cases checked
    case vreg n cls =>
      cases cls <;> try cases checked
      cases rm <;> try cases checked
      exact .inl ⟨sz,n,rfl⟩
  | csel rd rn rm c =>
    cases rd <;> try cases checked
    case vreg d cls =>
      cases cls <;> try cases checked
      cases rn <;> try cases checked
      case vreg n cls =>
        cases cls <;> try cases checked
        cases rm <;> try cases checked
        case vreg m cls =>
          cases cls <;> try cases checked
          exact .inr ⟨d,n,m,c,rfl⟩
  | _ => cases checked

private theorem no_mem {i : MInst} (checked : extra i = true) : i.isMemAcc = false := by
  rcases extra_cases checked with ⟨sz,n,rfl⟩ | ⟨d,n,m,c,rfl⟩ <;> rfl

private theorem spec_eq {i : MInst} (checked : extra i = true) (sb : Nat)
    (us : List CV) (w : Arm.ArmState) : mspec sb i us w = ispec i us w := by
  rcases extra_cases checked with ⟨sz,n,rfl⟩ | ⟨d,n,m,c,rfl⟩ <;> rfl

/-- Extra select forms may change NZCV, while preserving the full memory and
all non-flag world fields required by the source memory relation. -/
theorem step_frame {i : MInst} (checked : extra i = true) {sb : Nat}
    {us outs : List CV} {w t : Arm.ArmState} {ctl : Ctl}
    (run : mspec sb i us w = some (outs,t,ctl)) :
    SameWorldNF (fun _ => False) t w ∧ ctl = .next := by
  rw [spec_eq checked] at run
  rcases extra_cases checked with ⟨sz,n,rfl⟩ | ⟨d,n,m,c,rfl⟩
  · cases us with
    | nil => cases run
    | cons a rest =>
      cases rest with
      | cons b tail =>
        cases tail with
        | cons c rest => simp [ispec] at run
        | nil =>
          simp only [ispec,Option.some.injEq,Prod.mk.injEq] at run
          obtain ⟨rfl,rfl,rfl⟩ := run
          exact ⟨SameWorldNF.write_pstate _ _ _,rfl⟩
      | nil =>
        simp only [ispec,Option.some.injEq,Prod.mk.injEq] at run
        obtain ⟨rfl,rfl,rfl⟩ := run
        exact ⟨SameWorldNF.write_pstate _ _ _,rfl⟩
  · cases us with
    | nil => cases run
    | cons a rest =>
      cases rest with
      | nil => cases run
      | cons b tail =>
        cases tail with
        | cons c rest => cases run
        | nil =>
          simp only [ispec,Option.some.injEq,Prod.mk.injEq] at run
          obtain ⟨rfl,rfl,rfl⟩ := run
          exact ⟨SameWorld.nf (SameWorld.refl _ _),rfl⟩

/-- Equal virtual operands on related worlds produce equal values/control and
related successor worlds, including the newly computed flags. -/
theorem step_transport {i : MInst} (checked : extra i = true) {sb : Nat}
    {Z : BitVec 64 → Prop} {w w' : Arm.ArmState} (worlds : SameWorld Z w w')
    {us outs : List CV} {t : Arm.ArmState} {ctl : Ctl}
    (run : mspec sb i us w = some (outs,t,ctl)) :
    ∃ t', mspec sb i us w' = some (outs,t',ctl) ∧ SameWorld Z t t' :=
  mspec_lockstep (no_mem checked) worlds run

/-- Realize the flag-threaded specification through the existing shipped
value semantics, retaining identical outputs and flags on related worlds. -/
theorem step_realize {i : MInst} (checked : extra i = true)
    {F : BitVec 64 → Prop} {ctx : FnCtx} {X : ExtSem}
    {us outs : List CV} {w w' t : Arm.ArmState} {ctl : Ctl}
    (worlds : SameWorld F w' w)
    (run : mspec ctx.slotBase i us w = some (outs,t,ctl)) :
    ∃ t', valueSem F ctx X i us w' = some (outs,t',ctl) ∧ SameWorld F t' t := by
  obtain ⟨spec,executed,related⟩ := step_transport checked worlds.symm run
  rw [spec_eq checked] at executed
  obtain ⟨actual,realized,related'⟩ := refines_valueSem F ctx X i us w' outs spec executed
  exact ⟨actual,realized,related'.trans related.symm⟩

/-- A real compare step and dependent conditional select preserve the flag
thread; both outcomes are covered for arbitrary words and caller state. -/
theorem compare_select_witness (sz : OperandSize) (a x y : CV) (w : Arm.ArmState) :
    ∃ t,
      mspec 0 (.aluRRR .subS sz .xzr (.vreg 0 .int) .xzr) [a] w = some ([],t,.next) ∧
      mspec 0 (.csel (.vreg 3 .int) (.vreg 1 .int) (.vreg 2 .int) .ne) [x,y] t =
        some ([ofX (if Arm.ConditionHolds Cond.ne.bits t then lo64 x else lo64 y)],t,.next) := by
  exact ⟨_,rfl,rfl⟩


/-- Proof semantics classify the operation independently of register names;
the executable boundary above restricts actual accepted shapes. -/
def special : MInst → Bool
  | .aluRRR .subS .. | .csel .. => true
  | _ => false

noncomputable def sem (F : BitVec 64 → Prop) (ctx : FnCtx) (X : ExtSem) : Sem :=
  fun i us w => if special i then mspec ctx.slotBase i us w else ABIReadOnly.sem F ctx X i us w

/-- The original source specification is preserved, including flag updates. -/
theorem refines (F : BitVec 64 → Prop) (ctx : FnCtx) (X : ExtSem) :
    Refines F (sem F ctx X) := by
  intro i us w outs w' ctl executed
  by_cases hs : special i = true
  · exact ⟨w',by simp only [sem,hs,↓reduceIte]; exact mspec_of_ispec executed,SameWorld.refl F w'⟩
  · simpa only [sem,show special i = false from Bool.eq_false_iff.mpr hs,Bool.false_eq_true,↓reduceIte] using
      ABIReadOnly.refines F ctx X i us w outs w' executed

/-- Memory and symbol contracts retain the existing implementation. -/
theorem memory (F : BitVec 64 → Prop) (ctx : FnCtx) (X : ExtSem)
    {sb : Nat} {syms : String → Option Nat} (base : ctx.slotBase = sb)
    (symbols : ∀ n b, syms n = some b → X.sym n 0 = BitVec.ofNat 64 b) :
    MemRefines F sb syms (sem F ctx X) := by
  simpa only [MemRefines,sem,special,Bool.false_eq_true,↓reduceIte] using ABIReadOnly.memory F ctx X base symbols

/-- Alias resolution, retargeting and actual ABI argument reads retain their
original driver contracts. No chosen virtual file is added to source inputs. -/
theorem driver (F : BitVec 64 → Prop) (ctx : FnCtx) (X : ExtSem) :
    DriverSem (sem F ctx X) := by
  have hd := ABIReadOnly.driver F ctx X
  refine ⟨⟨?_,?_,?_⟩,?_⟩
  · intro l w; exact hd.jump l w
  · intro g gn hg i
    funext us w
    have old := congrFun (congrFun (hd.rename g gn hg i) us) w
    have spec := mspec_mapRegs hg ctx.slotBase i us w
    cases i with
    | aluRRR op sz rd rn rm =>
      cases op
      all_goals first
        | simpa only [sem,special,MInst.mapRegs,Bool.false_eq_true,↓reduceIte] using spec
        | simpa only [sem,special,MInst.mapRegs,Bool.false_eq_true,↓reduceIte] using old
    | csel rd rn rm c => simpa only [sem,special,MInst.mapRegs,Bool.false_eq_true,↓reduceIte] using spec
    | _ => simpa only [sem,special,MInst.mapRegs,Bool.false_eq_true,↓reduceIte] using old
  · intro i ls i' targets
    have old := hd.retarget i ls i' targets
    unfold MInst.setTargets at targets
    split at targets
    all_goals repeat' first | cases targets | split at targets
    all_goals
      funext us w
      simpa only [sem,special,Bool.false_eq_true,↓reduceIte] using congrFun (congrFun old us) w
  · intro ds w; exact hd.args ds w


/-- Specification worlds differ only in flags; even masked physical registers
are retained, so original ABI reads remain available while flags are threaded. -/
def FlagFrame (w t : Arm.ArmState) : Prop :=
  (∀ f, (∀ fl, f ≠ .FLAG fl) → Arm.r f t = Arm.r f w) ∧
  t.mem = w.mem ∧ t.program = w.program

private theorem FlagFrame.refl (w : Arm.ArmState) : FlagFrame w w :=
  ⟨fun _ _ => rfl,rfl,rfl⟩

private theorem FlagFrame.write_pstate (ps : Arm.PState) (w : Arm.ArmState) :
    FlagFrame w (Arm.write_pstate ps w) := by
  refine ⟨fun f nonflag => ?_,?_,?_⟩
  · simp only [Arm.write_pstate]
    rw [Arm.r_of_w_different (nonflag _),Arm.r_of_w_different (nonflag _),
      Arm.r_of_w_different (nonflag _),Arm.r_of_w_different (nonflag _)]
  · simp only [Arm.write_pstate,Arm.ArmState.mem_w_eq_mem]
  · simp only [Arm.write_pstate,Arm.w_program]

private theorem old_not_special {sig : Clif.Signature} {b k : Nat} {i : MInst}
    (checked : Backend.ABIReadOnly.instruction sig b k i = true) : special i = false := by
  cases i with
  | aluRRR op sz rd rn rm =>
    cases op <;> simp_all [special,Backend.ABIReadOnly.instruction,pureForm,pureAlu]
  | csel rd rn rm c => cases checked
  | _ => rfl

private theorem extra_special {i : MInst} (checked : extra i = true) : special i = true := by
  rcases extra_cases checked with ⟨sz,n,rfl⟩ | ⟨d,n,m,c,rfl⟩ <;> rfl

/-- Extra select forms may change NZCV, while preserving the full memory and
all non-flag world fields required by the source memory relation. -/
theorem step_flag_frame {i : MInst} (checked : extra i = true) {sb : Nat}
    {us outs : List CV} {w t : Arm.ArmState} {ctl : Ctl}
    (run : mspec sb i us w = some (outs,t,ctl)) :
    FlagFrame w t ∧ ctl = .next := by
  rw [spec_eq checked] at run
  rcases extra_cases checked with ⟨sz,n,rfl⟩ | ⟨d,n,m,c,rfl⟩
  · cases us with
    | nil => cases run
    | cons a rest =>
      cases rest with
      | cons b tail =>
        cases tail with
        | cons c rest => simp [ispec] at run
        | nil =>
          simp only [ispec,Option.some.injEq,Prod.mk.injEq] at run
          obtain ⟨rfl,rfl,rfl⟩ := run
          exact ⟨FlagFrame.write_pstate _ _,rfl⟩
      | nil =>
        simp only [ispec,Option.some.injEq,Prod.mk.injEq] at run
        obtain ⟨rfl,rfl,rfl⟩ := run
        exact ⟨FlagFrame.write_pstate _ _,rfl⟩
  · cases us with
    | nil => cases run
    | cons a rest =>
      cases rest with
      | nil => cases run
      | cons b tail =>
        cases tail with
        | cons c rest => cases run
        | nil =>
          simp only [ispec,Option.some.injEq,Prod.mk.injEq] at run
          obtain ⟨rfl,rfl,rfl⟩ := run
          exact ⟨FlagFrame.refl _,rfl⟩


/-- The executable combined boundary preserves every ABI register/memory byte,
threading the actual flag changes rather than assuming an unchanged world. -/
theorem checked_step_frame {sig : Clif.Signature} {b k : Nat} {i : MInst}
    (checked : (Backend.ABIReadOnly.instruction sig b k i || extra i) = true)
    {F : BitVec 64 → Prop} {ctx : FnCtx} {X : ExtSem}
    {us outs : List CV} {w t : Arm.ArmState} {ctl : Ctl}
    (run : sem F ctx X i us w = some (outs,t,ctl)) :
    FlagFrame w t ∧ (ctl = .next ∨ ctl = .ret) := by
  simp only [Bool.or_eq_true] at checked
  rcases checked with old | added
  · have ordinary := old_not_special old
    simp only [sem,ordinary,Bool.false_eq_true,↓reduceIte] at run
    have unchanged := ABIReadOnly.step_world old run
    subst t
    exact ⟨FlagFrame.refl _,ABIReadOnly.step_control old run⟩
  · simp only [sem,extra_special added,↓reduceIte] at run
    obtain ⟨frame,control⟩ := step_flag_frame added run
    exact ⟨frame,.inl control⟩


private theorem FlagFrame.trans {w t u : Arm.ArmState}
    (first : FlagFrame w t) (second : FlagFrame t u) : FlagFrame w u :=
  ⟨fun f h => (second.1 f h).trans (first.1 f h),
    second.2.1.trans first.2.1,second.2.2.trans first.2.2⟩

private theorem FlagFrame.regVal {w t : Arm.ArmState} (frame : FlagFrame w t) (r : Reg) :
    regVal t r = regVal w r := by
  cases r with
  | x n => exact congrArg (fun bits : BitVec 64 => bits.setWidth 128) (frame.1 (.GPR (rnum n)) (by intro fl eq; cases eq))
  | v n => exact frame.1 (.SFP (rnum n)) (by intro fl eq; cases eq)
  | _ => rfl

/-- Transfer checked flag-threaded steps with the same virtual operands,
using only the original ABI agreement and internally preserved physical reads. -/
theorem checked_step_transport {sig : Clif.Signature} {args : List Clif.Val}
    (types : args.map (·.ty) = sig.params.map (·.ty))
    {b k : Nat} {i : MInst}
    (checked : (Backend.ABIReadOnly.instruction sig b k i || extra i) = true)
    {F Z : BitVec 64 → Prop} {ctx : FnCtx} {X : ExtSem}
    {initial initial' w w' : Arm.ArmState}
    (current : FlagFrame initial w) (other : FlagFrame initial' w')
    (worlds : SameWorld Z w w')
    (registers : ∀ r v, (.reg r,v) ∈ (locsOf sig).zip args →
      regVal initial' r = regVal initial r)
    (stack : ∀ (off : Nat) (v : Clif.Val), (.stack off,v) ∈ (locsOf sig).zip args →
      ∀ j < v.ty.bytes,
      initial'.mem (Arm.r (.GPR 29#5) initial + BitVec.ofInt 64 (16+(off : Int)) + BitVec.ofNat 64 j) =
      initial.mem (Arm.r (.GPR 29#5) initial + BitVec.ofInt 64 (16+(off : Int)) + BitVec.ofNat 64 j))
    {us outs : List CV} {t : Arm.ArmState} {ctl : Ctl}
    (run : sem F ctx X i us w = some (outs,t,ctl)) :
    ∃ t', sem F ctx X i us w' = some (outs,t',ctl) ∧ SameWorld Z t t' := by
  simp only [Bool.or_eq_true] at checked
  rcases checked with old | added
  · have hs := old_not_special old
    simp only [sem,hs,Bool.false_eq_true,↓reduceIte] at run ⊢
    have fixed := ABIReadOnly.step_world old run
    subst t
    have regs : ∀ r v, (.reg r,v) ∈ (locsOf sig).zip args → regVal w' r = regVal w r := by
      intro r v member
      rw [other.regVal r,current.regVal r]
      exact registers r v member
    have bytes : ∀ (off : Nat) (v : Clif.Val), (.stack off,v) ∈ (locsOf sig).zip args →
        ∀ j < v.ty.bytes,
        w'.mem (Arm.r (.GPR 29#5) w + BitVec.ofInt 64 (16+(off : Int)) + BitVec.ofNat 64 j) =
        w.mem (Arm.r (.GPR 29#5) w + BitVec.ofInt 64 (16+(off : Int)) + BitVec.ofNat 64 j) := by
      intro off v member j bound
      rw [other.2.1,current.2.1,current.1 (.GPR 29#5) (by intro fl eq; cases eq)]
      exact stack off v member j bound
    exact ⟨w',ABIReadOnly.step_transport types old worlds regs bytes run,worlds⟩
  · have hs := extra_special added
    simp only [sem,hs,↓reduceIte] at run ⊢
    exact step_transport added worlds run

def instruction (sig : Clif.Signature) (b k : Nat) (i : MInst) : Bool :=
  Backend.ABIReadOnly.instruction sig b k i || extra i

def check (sig : Clif.Signature) (vc : VCode) : Bool :=
  vc.blocks.toList.zipIdx.all fun (block,b) =>
    block.insts.toList.zipIdx.all fun (i,k) => instruction sig b k i

private theorem checked_instruction {sig : Clif.Signature} {vc : VCode}
    (checked : check sig vc = true) {b k : Nat} {vb : VBlock} {i : MInst}
    (block : vc.blocks[b]? = some vb) (inst : vb.insts[k]? = some i) :
    (Backend.ABIReadOnly.instruction sig b k i || extra i) = true := by
  have bm : (vb,b) ∈ vc.blocks.toList.zipIdx :=
    List.mk_mem_zipIdx_iff_getElem?.mpr (by simpa using block)
  have im : (i,k) ∈ vb.insts.toList.zipIdx :=
    List.mk_mem_zipIdx_iff_getElem?.mpr (by simpa using inst)
  exact List.all_eq_true.mp (List.all_eq_true.mp checked (vb,b) bm) (i,k) im

/-- Both runs retain the same PC and complete virtual register file, with
related flags and original ABI reads framed throughout. -/
def Related (Z : BitVec 64 → Prop) (initial initial' : Arm.ArmState)
    (c d : VConf CV Arm.ArmState) : Prop :=
  ∃ w w', c.mapW (fun _ => w) = c ∧ d = c.mapW (fun _ => w') ∧
    FlagFrame initial w ∧ FlagFrame initial' w' ∧ SameWorld Z w w'

/-- Whole checked executions transfer one proof-internal virtual file; no
second file, final flags or execution callback is assumed. -/
theorem star_transport {sig : Clif.Signature} {args : List Clif.Val}
    (types : args.map (·.ty) = sig.params.map (·.ty))
    {vc : VCode} (checked : check sig vc = true)
    {F Z : BitVec 64 → Prop} {ctx : FnCtx} {X : ExtSem}
    {initial initial' : Arm.ArmState}
    (registers : ∀ r v, (.reg r,v) ∈ (locsOf sig).zip args →
      regVal initial' r = regVal initial r)
    (stack : ∀ (off : Nat) (v : Clif.Val), (.stack off,v) ∈ (locsOf sig).zip args →
      ∀ j < v.ty.bytes,
      initial'.mem (Arm.r (.GPR 29#5) initial + BitVec.ofInt 64 (16+(off : Int)) + BitVec.ofNat 64 j) =
      initial.mem (Arm.r (.GPR 29#5) initial + BitVec.ofInt 64 (16+(off : Int)) + BitVec.ofNat 64 j))
    {c c' d : VConf CV Arm.ArmState} (related : Related Z initial initial' c d)
    (path : Star (VStep vc (sem F ctx X)) c c') :
    ∃ d', Star (VStep vc (sem F ctx X)) d d' ∧ Related Z initial initial' c' d' := by
  induction path generalizing d with
  | refl => exact ⟨d,.refl _,related⟩
  | @step c next final first rest ih =>
    obtain ⟨w,w',fixed,rfl,current,other,worlds⟩ := related
    cases first with
    | @step b k ρ w0 vb i ops outs t ctl target hb hi hops run arity successor =>
      have eq : w0 = w := by
        have state := VConf.run.inj fixed
        exact (congrArg VState.w state).symm
      subst w0
      have supported := checked_instruction checked hb hi
      obtain ⟨t',executed,postWorlds⟩ := checked_step_transport types supported
        current other worlds registers stack run
      have post := (checked_step_frame supported run).1
      have post' := (checked_step_frame supported executed).1
      have mapped := VStep.step hb hi hops executed arity
        (vnext_map vc (fun _ => t') successor)
      have relation : Related Z initial initial' next (next.mapW (fun _ => t')) := by
        refine ⟨t,t',?_,rfl,current.trans post,other.trans post',postWorlds⟩
        cases successor <;> rfl
      obtain ⟨d',tail,final⟩ := ih relation
      exact ⟨d',.step mapped tail,final⟩


/-- Transfer the complete returned ABI values with one initial virtual file.
Final flags are related outputs, never a caller-provided or unchanged-world premise. -/
theorem return_transport {sig : Clif.Signature} {args : List Clif.Val}
    (types : args.map (·.ty) = sig.params.map (·.ty))
    {vc : VCode} (checked : check sig vc = true)
    {F Z : BitVec 64 → Prop} {ctx : FnCtx} {X : ExtSem}
    {initial initial' : Arm.ArmState} (worlds : SameWorld Z initial initial')
    (registers : ∀ r v, (.reg r,v) ∈ (locsOf sig).zip args →
      regVal initial' r = regVal initial r)
    (stack : ∀ (off : Nat) (v : Clif.Val), (.stack off,v) ∈ (locsOf sig).zip args →
      ∀ j < v.ty.bytes,
      initial'.mem (Arm.r (.GPR 29#5) initial + BitVec.ofInt 64 (16+(off : Int)) + BitVec.ofNat 64 j) =
      initial.mem (Arm.r (.GPR 29#5) initial + BitVec.ofInt 64 (16+(off : Int)) + BitVec.ofNat 64 j))
    {ρ : Nat → CV} {us : List (Reg × Reg)} {outs : List CV} {world : Arm.ArmState}
    (returned : VReturns vc (sem F ctx X) ρ initial us outs world) :
    ∃ world', VReturns vc (sem F ctx X) ρ initial' us outs world' ∧ SameWorld Z world world' := by
  obtain ⟨b,k,ρ1,w1,vb,ops,results,path,hb,hi,hops,values,run⟩ := returned
  have initialRelation : Related Z initial initial'
      (.run ⟨0,0,ρ,initial⟩) (.run ⟨0,0,ρ,initial'⟩) :=
    ⟨initial,initial',rfl,rfl,FlagFrame.refl _,FlagFrame.refl _,worlds⟩
  obtain ⟨d,path',w,w',fixed,equal,current,other,related⟩ :=
    star_transport types checked registers stack initialRelation path
  have same : w1 = w := by
    have state := VConf.run.inj fixed
    exact (congrArg VState.w state).symm
  subst w1
  obtain ⟨world',executed,finalWorlds⟩ := checked_step_transport types
    (checked_instruction checked hb hi) current other related registers stack run
  exact ⟨world',⟨b,k,ρ1,w',vb,ops,results,
    by simpa only [equal,VConf.mapW] using path',hb,hi,hops,values,executed⟩,finalWorlds⟩


private theorem FlagFrame.arguments {F : BitVec 64 → Prop} {sig : Clif.Signature}
    {args : List Clif.Val} {w t : Arm.ArmState} (frame : FlagFrame w t)
    (arguments : ArgsAtEntry F sig args w) : ArgsAtEntry F sig args t := by
  intro loc value member
  have given := arguments loc value member
  cases loc with
  | reg r =>
    change VHolds value (Backend.Proof.regVal t r)
    rw [frame.regVal r]
    exact given
  | stack off =>
    have fp := frame.1 (.GPR 29#5) (by intro fl eq; cases eq)
    change Avoids F value.ty.bytes _ ∧ _
    rw [fp]
    refine ⟨given.1,?_⟩
    have bytes := read_mem_bytes_congr (s := t) (t := w) value.ty.bytes
      (Arm.r (.GPR 29#5) w + BitVec.ofInt 64 (16+(off : Int)))
      (fun j hj => congrFun frame.2.1 _)
    rw [bytes]
    exact given.2

namespace Realize
/-- Realize each checked flag-threaded step at the existing machine boundary. -/
theorem step_realize {sig : Clif.Signature} {args : List Clif.Val}
    (types : args.map (·.ty) = sig.params.map (·.ty))
    {b k : Nat} {i : MInst}
    (checked : (Backend.ABIReadOnly.instruction sig b k i || extra i) = true)
    {F : BitVec 64 → Prop} {ctx : FnCtx} {X : ExtSem}
    {initial w t final : Arm.ArmState} (frame : FlagFrame initial w)
    (arguments : ArgsAtEntry F sig args initial) (worlds : SameWorld F t w)
    (entry : k = 0 → t = w) {us outs : List CV} {ctl : Ctl}
    (executed : sem F ctx X i us w = some (outs,final,ctl)) :
    ∃ actual, valueSem F ctx X i us t = some (outs,actual,ctl) ∧ SameWorld F actual final := by
  simp only [Bool.or_eq_true] at checked
  rcases checked with old | added
  · simp only [sem,old_not_special old,Bool.false_eq_true,↓reduceIte] at executed
    have unchanged := ABIReadOnly.step_world old executed
    subst final
    exact ABIReadOnly.step_realize types old (frame.arguments arguments) worlds entry executed
  · simp only [sem,extra_special added,↓reduceIte] at executed
    exact E2E.MixedFlagBoundary.step_realize added worlds executed

def Related (F : BitVec 64 → Prop) (initial : Arm.ArmState)
    (c d : VConf CV Arm.ArmState) : Prop :=
  ∃ w t, c.mapW (fun _ => w) = c ∧ d = c.mapW (fun _ => t) ∧
    FlagFrame initial w ∧ SameWorld F t w ∧
    ∀ vs, c = .run vs → vs.k = 0 → t = w

private theorem realize_step {sig : Clif.Signature} {args : List Clif.Val}
    (types : args.map (·.ty) = sig.params.map (·.ty))
    {vc : VCode} (checked : check sig vc = true)
    {F : BitVec 64 → Prop} {ctx : FnCtx} {X : ExtSem} {initial : Arm.ArmState}
    (arguments : ArgsAtEntry F sig args initial)
    {c c' d : VConf CV Arm.ArmState} (related : Related F initial c d)
    (step : VStep vc (sem F ctx X) c c') :
    ∃ d', VStep vc (valueSem F ctx X) d d' ∧ Related F initial c' d' := by
  obtain ⟨w,t,fixed,rfl,frame,worlds,entry⟩ := related
  cases step with
  | @step b k ρ w0 vb i ops outs w1 ctl target hb hi hops run arity successor =>
    have eq : w0 = w := by
      have state := VConf.run.inj fixed
      exact (congrArg VState.w state).symm
    subst w0
    have supported := checked_instruction checked hb hi
    obtain ⟨t',realized,related'⟩ := step_realize types supported frame arguments worlds (entry _ rfl) run
    have preserved := (checked_step_frame supported run).1
    refine ⟨c'.mapW (fun _ => t'),
      VStep.step hb hi hops realized arity (vnext_map vc (fun _ => t') successor),?_⟩
    have control := (checked_step_frame supported run).2
    cases successor with
    | next hk =>
      refine ⟨w1,t',rfl,rfl,frame.trans preserved,related',?_⟩
      intro vs eq zero
      cases eq
      change k+1=0 at zero
      omega
    | goto => rcases control with control | control <;> cases control
    | ret => exact ⟨w1,t',rfl,rfl,frame.trans preserved,related',fun vs eq => by cases eq⟩
    | halt => rcases control with control | control <;> cases control

theorem star_realize {sig : Clif.Signature} {args : List Clif.Val}
    (types : args.map (·.ty) = sig.params.map (·.ty))
    {vc : VCode} (checked : check sig vc = true)
    {F : BitVec 64 → Prop} {ctx : FnCtx} {X : ExtSem} {initial : Arm.ArmState}
    (arguments : ArgsAtEntry F sig args initial)
    {c c' d : VConf CV Arm.ArmState} (related : Related F initial c d)
    (path : Star (VStep vc (sem F ctx X)) c c') :
    ∃ d', Star (VStep vc (valueSem F ctx X)) d d' ∧ Related F initial c' d' := by
  induction path generalizing d with
  | refl => exact ⟨d,.refl _,related⟩
  | step first rest ih =>
    obtain ⟨d1,first',related'⟩ := realize_step types checked arguments related first
    obtain ⟨d',tail,final⟩ := ih related'
    exact ⟨d',.step first' tail,final⟩

/-- Complete realization preserves exact virtual definitions/ABI pins and the
actual final flags, without requiring the final source world to equal entry. -/
theorem return_realize {sig : Clif.Signature} {args : List Clif.Val}
    (types : args.map (·.ty) = sig.params.map (·.ty))
    {vc : VCode} (checked : check sig vc = true)
    {F : BitVec 64 → Prop} {ctx : FnCtx} {X : ExtSem} {initial : Arm.ArmState}
    (arguments : ArgsAtEntry F sig args initial)
    {ρ : Nat → CV} {us : List (Reg × Reg)} {outs : List CV} {world : Arm.ArmState}
    (returned : VReturns vc (sem F ctx X) ρ initial us outs world) :
    ∃ t, VReturns vc (valueSem F ctx X) ρ initial us outs t ∧ SameWorld F t world := by
  obtain ⟨b,k,ρ1,w1,vb,ops,results,path,hb,hi,hops,values,run⟩ := returned
  have start : Related F initial (.run ⟨0,0,ρ,initial⟩) (.run ⟨0,0,ρ,initial⟩) :=
    ⟨initial,initial,rfl,rfl,FlagFrame.refl _,SameWorld.refl _ _,fun _ _ _ => rfl⟩
  obtain ⟨d,path',w,t,fixed,equal,frame,worlds,entry⟩ := star_realize types checked arguments start path
  have same : w1 = w := by
    have state := VConf.run.inj fixed
    exact (congrArg VState.w state).symm
  subst w1
  obtain ⟨t',realized,related⟩ := step_realize types (checked_instruction checked hb hi)
    frame arguments worlds (entry _ rfl) run
  exact ⟨t',⟨b,k,ρ1,t,vb,ops,results,
    by simpa only [equal,VConf.mapW] using path',hb,hi,hops,values,realized⟩,related⟩
end Realize
/-- The existing checked preparation/allocation machine consumer realizes the
read-only run in either cleanup mode, including a wider non-interference world.
Initial virtual values stay proof-internal in the complete source consumer. -/
theorem machine_return {f : Clif.Function} {args : List Clif.Val}
    (types : args.map (·.ty) = f.sig.params.map (·.ty))
    {vc vcp : VCode} {rf : RFunc} {af : AFunc} {fa : FnAsm} {fb : FnBin} {k : Nat}
    {cleanup : Bool} (readOnly : check f.sig vc = true)
    (prep : prepCheck (Stock.Arithmetic.stage cleanup vc) vcp = true)
    (check : checkAlloc vcp rf = .ok ()) (alloc : lowerRFunc vcp rf = .ok af)
    (emit : emitFunc k af = .ok fa) (layout : fa.layout = .ok fb)
    {X : ExtSem} {K : Nat} {F Z : BitVec 64 → Prop}
    (frame : ∀ a, F a → Z a) (covered : FormsCovered ⟨fa.k,af.slotBase⟩ vcp)
    {w final reference : Arm.ArmState} (arguments : ArgsAtEntry F f.sig args w)
    (worlds : SameWorld Z final reference)
    {ρ : Nat → CV} {us : List (Reg × Reg)} {outs : List CV}
    (returned : VReturns vc (sem F ⟨fa.k,af.slotBase⟩ X) ρ w us outs final)
    (H : ArmHooks) (G : BitVec 64 → Prop) (base ra : BitVec 64) (s : Arm.ArmState)
    (entry : ActEntry vcp rf af fa fb K F G X H base ra s w) :
    ∃ n, ActRet ra Z G us outs reference s (runX (ArmStepX X H fa) n s) ∧
      PostTrace fa af base (ArmStepX X H fa) s n ∧
      ∀ i < n, actGoodX vcp rf af fa fb base s X H K G (GotV vcp)
        (runX (ArmStepX X H fa) i s) := by
  obtain ⟨t,valueRun,related⟩ := Realize.return_realize types readOnly arguments returned
  have finalWorld := (SameWorld.mono frame related).trans worlds
  have prepared := StockArithmeticStage_returns prep valueRun
  have machine := regLevelCorrect_worldX_value check alloc emit layout
    (X := X) (H := H) (K := K) (G := G) (gv := GotV vcp)
    covered entry.abi entry.stack entry.gfree (by rw [entry.hF]; exact entry.calls)
    (by rw [entry.hF]; exact entry.tries) (by rw [entry.hF]; exact entry.tls)
    (by rw [entry.hF]; exact entry.body) ρ
  rw [entry.hF] at machine
  obtain ⟨n,⟨h1,h2,h3,h4,h5,h6,h7⟩,h8⟩ :=
    machine.1 us outs t (vReturns_gotV_value prepared)
  refine ⟨n,⟨h1,h2,?_,?_,h5,h6⟩,h7,h8⟩
  · intro a outside
    rw [h3 a (fun hf => outside (frame a hf))]
    exact finalWorld.2.1 a outside
  · intro field unmasked fp sp
    rw [h4 field unmasked fp sp]
    exact finalWorld.1 field unmasked


end E2E.MixedFlagBoundary

namespace Backend.Stock.Mixed
open Backend.Proof Backend.Proof.Driver
structure Domain (f : Clif.Function) : Prop where
  scope : LowerScope f
  dominated : Dominated f
  abi : sigAbiOk f.sig = true
  shape : ∃ b xs, f.blocks = [b] ∧ b.term = .ret xs ∧
    ∀ stm ∈ b.body, Backend.Stock.Proof.MixedBody.Family stm.inst
  ordinary : (sigRets f.sig).any (·.purpose == .sret) = false
end Backend.Stock.Mixed


namespace E2E
open Backend Backend.Proof Backend.Proof.Driver Backend.Stock.Proof Backend.DeadCleanup
set_option autoImplicit false
set_option Elab.async false

/-- Complete source-to-machine non-interference for actual Stock arithmetic.
The runtime ABI-read check derives the read boundary; no legacy lowering verdict,
second chosen virtual file or extra source-value assumption is needed. -/
theorem backend_correct_world_niX_stock_mixed {p : Clif.Program} {f : Clif.Function} {k : Nat} {result : Stock.Result} {vcp : VCode}
    {rf : RFunc} {af : AFunc} {fa : FnAsm} {fb : FnBin}
    (domain : Stock.Mixed.Domain f) {cleanup : Bool}
    (readOnly : E2E.MixedFlagBoundary.check f.sig result.code = true)
    (hc : CompiledStockArithmeticStage f cleanup k result vcp rf af fa fb)
    {X : ExtSem} {syms : String → Option Nat} {slotOff : Nat} {env : Clif.Env} {K : Nat}
    {F : BitVec 64 → Prop} {c : BitVec 64}
    (hcov : FormsCovered ⟨fa.k, af.slotBase⟩ vcp)
    (hsym : ∀ n b, syms n = some b → X.sym n 0 = BitVec.ofNat 64 b)
    (hslot : af.slotBase = slotOff)
    {w₀ : Arm.ArmState} {args : List Clif.Val} {cs : Clif.State}
    (hcs : ClifEntry f args cs)
    (hrel : RelW ⟨F, syms, slotOff, (RAFrame.compute vcp rf).intBase⟩ f c cs.frame.slots cs.mem w₀)
    (hargs : ArgsAtEntry F f.sig args w₀)
    (fuel : Nat) :
    ∀ vals cm, Clif.runLoop env p fuel cs = .returned vals cm →
      ∃ (us : List (Reg × Reg)) (outs : List CV) (w : Arm.ArmState),
        us.map (·.2) = (List.range us.length).map Reg.x ∧ us.length = outs.length ∧
        PrefixHold vals outs ∧ MemRel F syms cm w ∧ result.code.RetsSite us ∧
        (∀ (H : ArmHooks) (G : BitVec 64 → Prop) (base ra : BitVec 64) (s : Arm.ArmState),
          ActEntry vcp rf af fa fb K F G X H base ra s w₀ →
          ∃ n, ActRet ra F G us outs w s (runX (ArmStepX X H fa) n s) ∧
            PostTrace fa af base (ArmStepX X H fa) s n ∧
            ∀ i < n, actGoodX vcp rf af fa fb base s X H K G (GotV vcp)
              (runX (ArmStepX X H fa) i s)) ∧
        (∀ (D : BitVec 64 → Prop) (w₀' : Arm.ArmState),
          RelW ⟨F, syms, slotOff, (RAFrame.compute vcp rf).intBase⟩ f c cs.frame.slots cs.mem w₀' →
          SameWorld (fun b => F b ∨ D b) w₀ w₀' →
          (∀ r v, (ArgLoc.reg r, v) ∈ (locsOf f.sig).zip args → regVal w₀' r = regVal w₀ r) →
          (∀ off v, (ArgLoc.stack off, v) ∈ (locsOf f.sig).zip args → ∀ k < v.ty.bytes,
            w₀'.mem (Arm.r (.GPR 29#5) w₀ + BitVec.ofInt 64 (16 + (off : Int)) + BitVec.ofNat 64 k) =
              w₀.mem (Arm.r (.GPR 29#5) w₀ + BitVec.ofInt 64 (16 + (off : Int)) + BitVec.ofNat 64 k)) →
          ∀ (H : ArmHooks) (G : BitVec 64 → Prop) (base ra : BitVec 64) (s : Arm.ArmState),
            ActEntry vcp rf af fa fb K F G X H base ra s w₀' →
            ∃ n, ActRet ra (fun a => F a ∨ D a) G us outs w s (runX (ArmStepX X H fa) n s) ∧
              PostTrace fa af base (ArmStepX X H fa) s n ∧
              ∀ i < n, actGoodX vcp rf af fa fb base s X H K G (GotV vcp)
                (runX (ArmStepX X H fa) i s)) := by
  intro vals cm returned
  obtain ⟨b,xs,blocks,ret,family⟩ := domain.shape
  have state : (⟨cs.frame,[],cs.mem⟩ : Clif.State) = cs := by
    have callers := hcs.callers
    cases cs
    cases callers
    rfl
  obtain ⟨ρ,source⟩ := MixedBody.actual_mixed_entry_return_refines_frame
    hc.lower domain.scope domain.dominated domain.abi blocks family ret hcs.stockSourceEntry
    (by rwa [state]) (MixedFlagBoundary.refines F ⟨fa.k,af.slotBase⟩ X)
    (MixedFlagBoundary.driver F ⟨fa.k,af.slotBase⟩ X)
    (MixedFlagBoundary.memory F ⟨fa.k,af.slotBase⟩ X hslot hsym)
    (mrStable_relW ⟨F,syms,slotOff,(RAFrame.compute vcp rf).intBase⟩ f c) hrel hargs
  obtain ⟨us,outs,w,cm0,reached,pins,arity,values,memory,freed⟩ := source
  have site : result.code.RetsSite us := by
    obtain ⟨b,k,ρ,w₁,vb,ops,outs',_,hvb,hk,_⟩ := reached
    exact ⟨b,vb,k,hvb,hk⟩
  have mem : MemRel F syms cm w := by
    rw [freed]
    exact memRel_leave (memRel_free memory.1.1 _)
  refine ⟨us,outs,w,pins.ordinary domain.ordinary,arity,values,mem,site,?_,?_⟩
  · intro H G base ra s he
    exact MixedFlagBoundary.machine_return (f := f) hcs.sig readOnly hc.prepOk hc.check hc.alloc hc.emit hc.layout
      (fun _ h => h) hcov hargs (SameWorld.refl F w) reached H G base ra s he
  · intro D w₀' hrel' hsw hreg hstk H G base ra s he
    have arguments := ABIReadOnly.arguments_transport hargs hsw hreg hstk
    obtain ⟨otherWorld,other,relatedWorlds⟩ :=
      MixedFlagBoundary.return_transport hcs.sig readOnly hsw hreg hstk reached
    exact MixedFlagBoundary.machine_return (f := f) hcs.sig readOnly hc.prepOk hc.check hc.alloc hc.emit hc.layout
      (fun _ h => Or.inl h) hcov arguments relatedWorlds.symm other H G base ra s he

end E2E
namespace E2E.StockMixedNIWitness
open Backend Backend.Proof Backend.Proof.Driver Backend.Stock.D0
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm

/-- Dependent add/select/sub, a consumed ninth stack argument, five unused
parameters, an explicit source slot and an omitted dead operation. -/
def function (config : Configuration) : Clif.Function :=
  let ty := valueType config
  {source "stock_mixed_ni" config [] with
    sig := {
      params := List.replicate 9 ⟨ty,.none,.normal⟩
      returns := [⟨ty,.none,.normal⟩]
      callConv := convention config}
    slots := [(7,⟨8,some 8⟩)]
    blocks := [{
      id := 0
      params := (List.range 9).map (fun i => (i,ty))
      body := [⟨[9],.binary .iadd ty 1 8⟩,⟨[10],.select ty 0 9 1⟩,
        ⟨[11],.binary .isub ty 10 2⟩,⟨[12],.binary .iadd ty 1 8⟩]
      term := .ret [11]}]}

private def checks (config : Configuration) (cleanup : Bool) : Bool :=
  lowerScopeB (function config) && dominatedB (function config) && sigAbiOk (function config).sig &&
  match Stock.lower (function config) with
  | .error _ => false
  | .ok result =>
    !lowerCheck (function config) result.code &&
    MixedFlagBoundary.check (function config).sig result.code &&
    match Backend.prepare (Stock.Arithmetic.stage cleanup result.code) with
    | .error _ => false
    | .ok vcp =>
      prepCheck (Stock.Arithmetic.stage cleanup result.code) vcp &&
      match leanAlloc vcp with
      | .error _ => false
      | .ok rf =>
        (checkAlloc vcp rf).isOk &&
        match lowerRFunc vcp rf with
        | .error _ => false
        | .ok af =>
          match emitFunc 0 af with
          | .error _ => false
          | .ok fa => formsCoveredB ⟨fa.k,af.slotBase⟩ vcp && fa.layout.isOk

private def grid : Bool := configurations.all fun config => checks config false && checks config true
-- witness: native_decide (twelve fixed actual pipeline configurations only)
theorem checks_true : grid = true := by native_decide
end E2E.StockMixedNIWitness

namespace E2E.StockMixedNIWitness
open Backend Backend.Proof Backend.Proof.Driver Backend.Stock.D0

private theorem family (config : Configuration) :
    ∀ stm ∈ (function config).blocks[0]!.body, Stock.Proof.MixedBody.Family stm.inst := by
  intro stm member
  let ty := valueType config
  change stm ∈ [⟨[9],.binary .iadd ty 1 8⟩,⟨[10],.select ty 0 9 1⟩,
    ⟨[11],.binary .isub ty 10 2⟩,⟨[12],.binary .iadd ty 1 8⟩] at member
  simp only [List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with rfl | rfl | rfl | rfl
  · exact .inl ⟨false,ty,1,8,rfl⟩
  · exact .inr ⟨ty,0,9,1,rfl⟩
  · exact .inl ⟨true,ty,10,2,rfl⟩
  · exact .inl ⟨false,ty,1,8,rfl⟩

/-- Actual checked/allocated/emitted artifacts inhabit the complete mixed
semantic domain in every ABI and cleanup mode, beyond the legacy checker. -/
theorem compiled_exists (config : Configuration) (cleanup : Bool) :
    Stock.Mixed.Domain (function config) ∧
    ∃ result vcp rf af fa fb,
      CompiledStockArithmeticStage (function config) cleanup 0 result vcp rf af fa fb ∧
      MixedFlagBoundary.check (function config).sig result.code = true ∧
      leanAlloc vcp = .ok rf ∧ FormsCovered ⟨fa.k,af.slotBase⟩ vcp ∧
      lowerCheck (function config) result.code = false := by
  have h : checks config cleanup = true := by
    have both := List.all_eq_true.mp checks_true config (by cases config <;> simp [configurations])
    simp only [Bool.and_eq_true] at both
    cases cleanup with
    | false => exact both.1
    | true => exact both.2
  simp only [checks,Bool.and_eq_true] at h
  obtain ⟨⟨⟨scope,dominated⟩,abi⟩,h⟩ := h
  have domain : Stock.Mixed.Domain (function config) :=
    ⟨lowerScope_of scope,dominated_of dominated,abi,
      ⟨(function config).blocks[0]!,[11],rfl,rfl,family config⟩,by rfl⟩
  refine ⟨domain,?_⟩
  cases lowered : Stock.lower (function config) with
  | error message => simp [lowered] at h
  | ok result =>
    simp only [lowered,Bool.and_eq_true,Bool.not_eq_true'] at h
    obtain ⟨⟨legacy,reads⟩,h⟩ := h
    cases prepared : Backend.prepare (Stock.Arithmetic.stage cleanup result.code) with
    | error message => simp [prepared] at h
    | ok vcp =>
      simp only [prepared,Bool.and_eq_true] at h
      obtain ⟨prepOk,h⟩ := h
      cases allocated : leanAlloc vcp with
      | error message => simp [allocated] at h
      | ok rf =>
        simp only [allocated,Bool.and_eq_true] at h
        obtain ⟨checked,h⟩ := h
        cases physical : lowerRFunc vcp rf with
        | error message => simp [physical] at h
        | ok af =>
          cases emitted : emitFunc 0 af with
          | error message => simp [physical,emitted] at h
          | ok fa =>
            simp only [physical,emitted,Bool.and_eq_true] at h
            obtain ⟨covered,layoutOk⟩ := h
            cases layout : fa.layout with
            | error message => rw [layout] at layoutOk; change false = true at layoutOk; cases layoutOk
            | ok fb =>
              have check : checkAlloc vcp rf = .ok () := by
                cases check : checkAlloc vcp rf with
                | error message => rw [check] at checked; change false = true at checked; cases checked
                | ok value => cases value; rfl
              exact ⟨result,vcp,rf,af,fa,fb,
                ⟨lowered,prepared,prepOk,check,physical,emitted,layout⟩,
                reads,allocated,(formsCoveredB_iff _ _).mp covered,legacy⟩

def arguments (config : Configuration) (input : Nat → BitVec (valueType config).width) : List Clif.Val :=
  (List.range 9).map fun i => ⟨valueType config,input i⟩

def frame (config : Configuration) (input : Nat → BitVec (valueType config).width) (slot : Nat) : Clif.Frame := {
  func := function config
  regs := (Clif.Regs.empty.setMany (List.range 9) (arguments config input)).getD Clif.Regs.empty
  slots := [(7,slot)]
  body := (function config).blocks[0]!.body
  term := .ret [11] }

/-- All entry values and the original explicit-slot address remain arbitrary. -/
theorem source_entry (config : Configuration) (input : Nat → BitVec (valueType config).width) (slot : Nat) :
    ClifEntry (function config) (arguments config input) ⟨frame config input slot,[],Clif.Mem.empty⟩ := by
  cases config <;> exact ⟨rfl,rfl,rfl,⟨_,rfl,rfl,rfl,rfl,rfl⟩,rfl⟩

/-- Full reference execution includes dependent selection, the consumed stack
argument and the dead statement, for arbitrary values in all six configurations. -/
theorem source_returns (config : Configuration) (input : Nat → BitVec (valueType config).width) (slot : Nat) :
    Clif.runLoop Clif.Env.empty {funcs := []} 5 ⟨frame config input slot,[],Clif.Mem.empty⟩ =
      .returned [⟨valueType config,Clif.Sem.select (input 0) (input 1 + input 8) (input 1) - input 2⟩]
        Clif.Mem.empty := by
  cases config <;> rfl
end E2E.StockMixedNIWitness


namespace Backend.Stock.Mixed
open Backend.Proof Backend.Proof.Driver
abbrev abiEligible := Arithmetic.abiEligible

def bodyEligible (stm : Clif.Stmt) : Bool :=
  match stm.inst with
  | .binary op ty _ _ => (op == .iadd || op == .isub) && (ty == .i32 || ty == .i64)
  | .select ty _ _ _ => ty == .i32 || ty == .i64
  | _ => false

def eligible (f : Clif.Function) : Bool :=
  match f.blocks with
  | [b] => b.body.all bodyEligible &&
      (match b.term with | .ret _ => true | _ => false) &&
      f.sig.params.all abiEligible && f.sig.returns.all abiEligible
  | _ => false

def sourceOk (f : Clif.Function) : Bool :=
  eligible f && lowerScopeB f && dominatedB f && sigAbiOk f.sig

private theorem normal_abi {params : List Clif.AbiParam} (all : params.all abiEligible = true) :
    ∀ p ∈ params, p.purpose = .normal := by
  intro p member
  have good := List.all_eq_true.mp all p member
  simp only [abiEligible,Arithmetic.abiEligible, Bool.and_eq_true] at good
  have purpose : (p.purpose == .normal) = true := good.1
  exact beq_iff_eq.mp purpose

/-- The runtime source classifier derives all semantic premises internally. -/
theorem sourceOk_sound {f : Clif.Function} (checked : sourceOk f = true) : Domain f := by
  simp only [sourceOk,Bool.and_eq_true] at checked
  obtain ⟨⟨⟨eligible,scope⟩,dominated⟩,abi⟩ := checked
  unfold Mixed.eligible at eligible
  split at eligible
  next b blocks =>
    simp only [Bool.and_eq_true] at eligible
    obtain ⟨⟨⟨body,terminal⟩,params⟩,returns⟩ := eligible
    have sourceShape : ∃ xs, b.term = .ret xs := by
      cases term : b.term <;> simp_all
    obtain ⟨xs,ret⟩ := sourceShape
    have families : ∀ stm ∈ b.body, Stock.Proof.MixedBody.Family stm.inst := by
      intro stm member
      have supported := List.all_eq_true.mp body stm member
      cases inst : stm.inst <;> simp only [bodyEligible,inst] at supported
      all_goals try contradiction
      next op ty x y =>
        simp only [Bool.and_eq_true] at supported
        have ops := supported.1
        simp only [Bool.or_eq_true,beq_iff_eq] at ops
        rcases ops with rfl | rfl
        · exact .inl ⟨false,ty,x,y,rfl⟩
        · exact .inl ⟨true,ty,x,y,rfl⟩
      next ty c x y => exact .inr ⟨ty,c,x,y,rfl⟩
    have noSret : f.sig.params.find? (·.purpose == .sret) = none := by
      apply List.find?_eq_none.mpr
      intro p member
      simp [(normal_abi params) p member]
    have ordinary : (sigRets f.sig).any (·.purpose == .sret) = false := by
      rw [sigRets,noSret]
      apply Bool.eq_false_iff.mpr
      intro any
      obtain ⟨p,member,sret⟩ := List.any_eq_true.mp any
      simpa [(normal_abi returns) p member] using sret
    exact ⟨lowerScope_of scope,dominated_of dominated,abi,⟨b,xs,blocks,ret,families⟩,ordinary⟩
  next => cases eligible


/-- Only the new actual-Stock branch; the production union retains its previous
legacy/arithmetic alternatives and transactional fallbacks. -/
def check (f : Clif.Function) (vc : VCode) : Bool :=
  sourceOk f && match Stock.lower f with
  | .error _ => false
  | .ok result => decide (result.code = vc) && result.edgeArgs.all (fun row => row.all (·.isEmpty))

theorem check_sound {f : Clif.Function} {vc : VCode} (checked : check f vc = true) :
    ∃ result, Domain f ∧ Stock.lower f = .ok result ∧ result.code = vc ∧
      result.edgeArgs.all (fun row => row.all (·.isEmpty)) = true := by
  simp only [check,Bool.and_eq_true] at checked
  obtain ⟨source,lowered⟩ := checked
  cases run : Stock.lower f with
  | error message => simp [run] at lowered
  | ok result =>
    simp only [run,Bool.and_eq_true,decide_eq_true_eq] at lowered
    exact ⟨result,sourceOk_sound source,rfl,lowered.1,lowered.2⟩
end Backend.Stock.Mixed

open Lean Elab Command
run_cmd do
  let env ← getEnv
  let mut core : Nat := 0
  let mut witness : Nat := 0
  for (name,_) in env.constants.toList do
    if (env.getModuleIdxFor? name).isSome then continue
    let isWitness := (name.toString.splitOn ".StockMixedNIWitness.").length > 1
    for ax in ← collectAxioms name do
      if #[``propext,``Classical.choice,``Quot.sound].contains ax then continue
      unless isWitness && ax.toString == "E2E.StockMixedNIWitness.checks_true._native.native_decide.ax_1" do
        throwError "disallowed axiom {ax} in {name}"
    if isWitness then witness := witness+1 else core := core+1
  unless core > 0 && witness > 0 do throwError "empty partition"
  logInfo m!"MIXED_MACHINE_CORE_STANDARD_ONLY {core}; FIXED_COMPILER_WITNESS {witness}"
#print axioms E2E.MixedFlagBoundary.Realize.return_realize
#print axioms E2E.MixedFlagBoundary.machine_return
#print axioms E2E.backend_correct_world_niX_stock_mixed
#print axioms E2E.StockMixedNIWitness.checks_true

#print axioms Backend.Stock.Mixed.sourceOk_sound
#print axioms Backend.Stock.Mixed.check_sound
