from pathlib import Path
import subprocess as sp,os,signal,time,json,sys
root=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');sched=3016520
out=Path('/tmp/stock-mixed-draft-check');out.mkdir(exist_ok=True)
env=dict(os.environ,PATH='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:'+os.environ['PATH'],FV_MEMCAP='4G',FV_LAKE_CACHE='/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache',LEAN_NUM_THREADS='2',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2')
head=sp.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert head=='087e91d1615c8c944e560c050c1eb7c60981d205'
assert b'stock-execute-scheduler.py' in Path(f'/proc/{sched}/cmdline').read_bytes()
stopped=False
try:
 os.kill(sched,signal.SIGSTOP);stopped=True
 for _ in range(100):
  if Path(f'/proc/{sched}/stat').read_text().split()[2]=='T':break
  time.sleep(.01)
 else:raise RuntimeError('launcher did not stop')
 deadline=time.monotonic()+10
 while True:
  kids=Path(f'/proc/{sched}/task/{sched}/children').read_text().split()
  live=[k for k in kids if Path(f'/proc/{k}/stat').exists() and Path(f'/proc/{k}/stat').read_text().split()[2]!='Z']
  if len(live)<=1:
   kids=live;break
  if time.monotonic()>=deadline:raise RuntimeError('no bounded scratch slot; existing kernels retained')
  time.sleep(.1)
 for k in kids:
  childenv=Path(f'/proc/{k}/environ').read_bytes().split(b'\0');cap=[v for v in childenv if v.startswith(b'FV_MEMCAP=')];assert len(cap)==1,cap
  value=cap[0].decode().split('=',1)[1]; amount=int(value[:-1])*(1024 if value[-1]=='G' else 1); assert 0<amount<=12288,cap
 with (out/(sys.argv[2]+'.log')).open('w') as f:
  p=sp.run([str(root/'scripts/memcap.sh'),'lake','env','lean','--root=/tmp',sys.argv[1]],cwd=root,env=env,stdout=f,stderr=sp.STDOUT,timeout=60)
 assert sp.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head
 print(json.dumps({'candidate_returncode':p.returncode,'head_unchanged':True,'existing_jobs':len(kids),'reserved_GiB':16,'log':str(out/(sys.argv[2]+'.log'))}))
finally:
 if stopped:os.kill(sched,signal.SIGCONT)
 print(json.dumps({'scheduler_resumed':True}),flush=True)
