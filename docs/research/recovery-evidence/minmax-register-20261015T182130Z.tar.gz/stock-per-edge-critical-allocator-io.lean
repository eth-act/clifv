import FV.Backend.RegallocPerEdgeDriver
import FV.Backend.Proof.StockPerEdgeCheckerWitness
namespace Backend.Stock.Proof.EdgeAllocatorInspect
private def reduce : Clif.Stmt := ⟨[17],.ireduce .i8 7⟩
private def function : Clif.Function := {
  name := "stock_critical_values_alias"
  sig := {params := [⟨.i64,.none,.normal⟩],returns := [⟨.i8,.none,.normal⟩],callConv := some .systemV}
  blocks := [{id := 0,params := [(7,.i64)],body := [reduce],term := .brif 7 ⟨1,[17]⟩ ⟨1,[17]⟩},
    {id := 1,params := [(31,.i8)],term := .ret [31]}] }

#eval show IO Unit from do
  let .ok result := Stock.lower function | throw (IO.userError "Stock lowering failed")
  let input : EdgeVCode := ⟨result.code,result.edgeArgs⟩
  let .ok prepared := prepareAt input.code input.edges | throw (IO.userError "prepareAt failed")
  let .ok request := vcodeJsonAt prepared.code prepared.edges | throw (IO.userError "request failed")
  IO.FS.writeFile "/tmp/stock-per-edge-critical-allocator-request.json" request
  let raw ← runLeanRegallocAt "/home/lee/clifv/.worktrees/driver-proof-resume/rust/target/release/lean-regalloc" aarch64Env #[prepared]
  let .ok raw := raw | throw (IO.userError "oracle transport failed")
  let .ok answer := raw[0]!.bind RAResult.oracle | throw (IO.userError "Rust checker rejected oracle")
  if !(checkAllocAt prepared.code prepared.edges answer).isOk then
    throw (IO.userError "Lean indexed checker rejected oracle")
  let .ok lowered := lowerRFunc prepared.code answer | throw (IO.userError "oracle lowering failed")
  if !emitReady lowered then
    throw (IO.userError "oracle was not the expected ready allocation")
  let oracle ← allocateRegalloc2At "/home/lee/clifv/.worktrees/driver-proof-resume/rust/target/release/lean-regalloc" aarch64Env #[input]
  let fallback ← allocateRegalloc2At "/tmp/clifv-intentionally-missing-regalloc" aarch64Env #[input]
  let spill := allocateSpillAt #[input]
  if !oracle.all (·.isOk) || !fallback.all (·.isOk) || !spill.all (·.isOk) then
    IO.println s!"oracle={oracle.map (·.isOk)} fallback={fallback.map (·.isOk)} spill={spill.map (·.isOk)}"
    throw (IO.userError "allocation failed")
  IO.println "PASS actual Rust oracle accepted by both checkers, ready zero-spill allocation; unavailable-oracle fallback and forced indexed spill"
end Backend.Stock.Proof.EdgeAllocatorInspect
