import FV.Backend.RegallocPerEdgeDriver
namespace Backend
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private def vc : VCode := {name := "kernel_spill",slotBytes := 0,outgoing := 0,rulesFired := #[],classes := Array.replicate 195 .int,blocks := #[
 {label := 0,insts := #[.args [(.vreg 192 .int,.x 0)],.condBr 2 1 (.notZero (.vreg 192 .int) .size64)]},
 {label := 1,insts := #[.rets [(.vreg 194 .int,.x 0)]],params := #[.vreg 194 .int]},
 {label := 2,insts := #[.rets [(.vreg 193 .int,.x 0)]],params := #[.vreg 193 .int]}]}
private def edges : Array (Array (Array Reg)) := #[#[#[.vreg 192 .int],#[.vreg 192 .int]],#[],#[]]
example : (prepareAt vc edges).isOk = true := by decide +kernel
example : (checkAllocAt vc edges (spillAllocAt vc edges)).isOk = true := by decide +kernel
example : (lowerRFunc vc (spillAllocAt vc edges)).isOk = true := by decide +kernel
#reduce (spillHomesAt vc edges).size
end Backend
