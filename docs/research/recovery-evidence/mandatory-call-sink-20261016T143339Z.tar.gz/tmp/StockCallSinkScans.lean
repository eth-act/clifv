import StockCallSinkControl
import FV.Backend.Proof.StockTerminalScans
namespace Backend.Stock.Proof.CallSinkScansDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Cov Coverage Isle Isle.Interp Isle.Aarch64
open CallSinkControlDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm
/-- Every actual original source call remains available to mandatory scanning. -/
def SourceCallsUnsunk (ctx : Ctx) (st : State) : Prop :=
  ∀ i,SourceCallSlot ctx i → st.sunk[i]! = false
theorem stock_buildCtx_source_calls_unsunk {f : Clif.Function} {ctx : Ctx}
    {ranges : Array (Nat × Nat)} {initial : State}
    (build : Stock.buildCtx f = .ok (ctx, ranges, initial)) : SourceCallsUnsunk ctx initial := by
  unfold Stock.buildCtx at build
  cases legacy : Backend.buildCtx f with
  | error e => simp only [legacy, bind, Except.bind] at build; cases build
  | ok result =>
    rcases result with ⟨original, ranges, before⟩
    simp only [legacy, bind, Except.bind] at build
    cases requestRun : allocationRequests f ranges with
    | error e => simp only [requestRun, bind, Except.bind] at build; cases build
    | ok requests =>
      simp only [requestRun, bind, Except.bind, pure, Except.pure] at build
      cases build
      intro i slot
      change (Array.replicate original.insts.size false)[i]! = false
      by_cases inside : i < original.insts.size <;>
        simp [getElem!_def,Array.getElem?_replicate,inside] <;> rfl

private theorem scanState_table (st : State) (i : Nat) :
    (scanState st i).opportunistic = st.opportunistic := by
  unfold scanState
  dsimp only
  split <;> rfl

private theorem commitValues_empty (ctx : Ctx) (values : List Nat) (st : State)
    (empty : NoOpportunity st) : commitOpportunisticValues ctx values st = .ok st := by
  unfold commitOpportunisticValues
  induction values with
  | nil => rfl
  | cons v values ih =>
    rw [List.foldlM_cons]
    simp only [empty v, pure, Except.pure, bind, Except.bind]
    exact ih

private theorem commit_empty {ctx : Ctx} {block i : Nat} {st next : State}
    (empty : NoOpportunity st) (run : commitOpportunistic ctx block i st = .ok (some next)) :
    next = st := by
  unfold commitOpportunistic at run
  dsimp only at run
  split at run
  · cases run
  · rw [commitValues_empty ctx _ st empty] at run
    simp only [bind, Except.bind, pure, Except.pure, Except.ok.injEq, Option.some.injEq] at run
    exact run.symm

private theorem scan_preserves {ctx : Ctx} {block i ti : Nat} {isBranch : Bool}
    (P : State → Prop)
    (normalize : ∀ st i,P st → P (scanState st i))
    (emitPreserves : ∀ before emission, P before →
      emitInstruction ctx i before = .ok emission → P emission.state)
    {input : State} {output : Scan} (empty : NoOpportunity input) (safe : P input)
    (run : scanInstruction ctx block i ti isBranch input = .ok output) :
    P output.state := by
  have normalizedEmpty : NoOpportunity (scanState input i) := by
    intro v
    rw [scanState_table]
    exact empty v
  have normalized : P (scanState input i) := normalize _ _ safe
  have emitted (h : (emitInstruction ctx i (scanState input i) >>= fun e =>
      pure (e.scan block i (scanState input i))) = .ok output) : P output.state := by
    cases hr : emitInstruction ctx i (scanState input i) with
    | error e => simp only [hr, bind, Except.bind] at h; cases h
    | ok emission =>
      simp only [hr, bind, Except.bind, pure, Except.pure] at h
      cases h
      exact emitPreserves _ _ normalized hr
  by_cases sunk : input.sunk[i]! = true
  · simp only [scanInstruction, sunk, ite_true] at run
    cases run; exact safe
  · simp only [scanInstruction, sunk, ite_false] at run
    by_cases skipped : (i == ti && isBranch) = true
    · simp only [skipped, ite_true] at run
      cases run; exact normalized
    · simp only [skipped, ite_false] at run
      cases mandatory : (if i == ti then true else ctx.insts[i]!.clif.any mustLower) <;>
        simp only [mandatory] at run
      all_goals
        by_cases omitted : (! (if i == ti then true else ctx.insts[i]!.clif.any mustLower) &&
          !ctx.insts[i]!.results.any (fun v => (scanState input i).demand[v]! != 0)) = true
        · simp only [mandatory] at omitted
          simp only [omitted, ite_true] at run
          cases run; exact normalized
        · simp only [mandatory] at omitted
          simp only [omitted, ite_false] at run
          by_cases committing : ((scanState input i).entryColor[i]! == 0 &&
              !(if i == ti then true else ctx.insts[i]!.clif.any mustLower)) = true
          · simp only [mandatory] at committing
            simp only [committing, ite_true] at run
            cases hc : commitOpportunistic ctx block i (scanState input i) with
            | error e => simp only [hc, bind, Except.bind] at run; cases run
            | ok result =>
              simp only [hc, bind, Except.bind] at run
              cases result with
              | none => exact emitted run
              | some next =>
                have eq := commit_empty normalizedEmpty hc
                cases run
                rw [eq]
                exact normalized
          · simp only [mandatory] at committing
            simp only [committing, ite_false] at run
            exact emitted run


private theorem emit_same {f : Clif.Function} {ctx : Ctx}
    (mapped : MappedCtxInv f ctx) (clean : Clean (sourceIdentityCtx ctx)) {i : Nat}
    (kind : (∃ info inst,ctx.insts[i]? = some info ∧ info.clif = some inst) ∨
      ∃ t data,retOrTrap t = true ∧ Backend.termData t = .ok data ∧ ctx.insts[i]? = some ⟨data,[],[],none⟩)
    {before : State} {emission : Emission}
    (run : emitInstruction ctx i before = .ok emission) : SourceCallsSame ctx before emission.state := by
  unfold emitInstruction at run
  cases root : Stock.runTerm ctx "lower" [.inst i] before with
  | error e => simp only [root,bind,Except.bind] at run; cases run
  | ok result =>
    obtain ⟨out,next,rules⟩ := result
    simp only [root,bind,Except.bind] at run
    cases out with
    | none => cases run
    | some out =>
      have preserved : SourceCallsSame ctx before next := by
        rcases kind with ⟨info,inst,source,clif⟩ | ⟨t,data,rt,prepared,source⟩
        · exact stock_statement_source_calls_same mapped clean source clif root
        · exact stock_retTrap_source_calls_same mapped clean rt prepared source root
      cases out <;> try (cases run)
      rename_i rss
      dsimp only at run
      split at run
      · cases run
      · cases binding : bindResults ctx (ctx.insts[i]!.results.zip rss) next with
        | error e => simp only [binding,bind,Except.bind] at run; cases run
        | ok pair =>
          obtain ⟨bound,copies⟩ := pair
          simp only [binding,pure,Except.pure] at run
          cases run
          intro call source
          rw [bindResults_noSink binding]
          exact preserved call source
private theorem normalize_same (ctx : Ctx) (baseline st : State) (i : Nat)
    (safe : SourceCallsSame ctx baseline st) : SourceCallsSame ctx baseline (scanState st i) := by
  intro j call
  unfold scanState
  dsimp only
  split <;> exact safe j call
private theorem scan_slot_same {f : Clif.Function} {ctx : Ctx}
    (mapped : MappedCtxInv f ctx) (clean : Clean (sourceIdentityCtx ctx))
    {block i ti : Nat} {branch : Bool} (slot : ScanSlot ctx i ti branch)
    {baseline input : State} {output : Scan} (empty : NoOpportunity input)
    (safe : SourceCallsSame ctx baseline input)
    (run : scanInstruction ctx block i ti branch input = .ok output) :
    SourceCallsSame ctx baseline output.state := by
  have emitter (kind : (∃ info inst,ctx.insts[i]? = some info ∧ info.clif = some inst) ∨
      ∃ t data,retOrTrap t = true ∧ Backend.termData t = .ok data ∧ ctx.insts[i]? = some ⟨data,[],[],none⟩) (before : State) (emission : Emission)
      (held : SourceCallsSame ctx baseline before) (emitted : emitInstruction ctx i before = .ok emission) :
      SourceCallsSame ctx baseline emission.state := by
    have frame := emit_same mapped clean kind emitted
    intro j call
    exact (frame j call).trans (held j call)
  rcases slot with ordinary | ⟨same,br⟩ | terminal
  · exact scan_preserves (SourceCallsSame ctx baseline) (normalize_same ctx baseline)
      (emitter (.inl ordinary)) empty safe run
  · subst i
    subst branch
    by_cases sunk : input.sunk[ti]! = true
    · simp only [scanInstruction,sunk,ite_true] at run
      cases run; exact safe
    · simp only [scanInstruction,sunk,ite_false,beq_self_eq_true,Bool.true_and,ite_true] at run
      cases run; exact normalize_same ctx baseline input ti safe
  · exact scan_preserves (SourceCallsSame ctx baseline) (normalize_same ctx baseline)
      (emitter (.inr terminal)) empty safe run
private theorem block_same {f : Clif.Function} {ctx : Ctx}
    (mapped : MappedCtxInv f ctx) (clean : Clean (sourceIdentityCtx ctx))
    {block ti : Nat} {branch : Bool} {indices : List Nat}
    (slots : ∀ i ∈ indices,ScanSlot ctx i ti branch)
    {baseline input : State} {output : BlockScan} (empty : NoOpportunity input)
    (safe : SourceCallsSame ctx baseline input)
    (run : scanBlock ctx block ti branch indices input = .ok output) :
    SourceCallsSame ctx baseline output.state ∧ ∀ record ∈ output.records,
      SourceCallsSame ctx baseline record.input ∧ SourceCallsSame ctx baseline record.output.state := by
  have memories := scanBlock_records_noOpportunity mapped clean slots empty run
  have cert := runScans_spec run
  clear run empty
  induction cert with
  | nil input => exact ⟨safe,by simp⟩
  | @cons i indices input scan tail head rest ih =>
    have first := scan_slot_same mapped clean (slots i (List.mem_cons_self))
      (memories _ (List.mem_cons_self)).1 safe head
    have later := ih (fun k hk => slots k (List.mem_cons_of_mem i hk)) first
      (fun r hr => memories r (List.mem_cons_of_mem _ hr))
    refine ⟨later.1,?_⟩
    intro record member
    rcases List.mem_cons.mp member with rfl | member
    · exact ⟨safe,first⟩
    · exact later.2 record member
/-- Complete actual backward scans frame every original call bit and supply
that same frame at BOTH endpoints of every actual retained record. -/
theorem stock_scanBlock_source_calls_same {f : Clif.Function} {ctx : Ctx}
    (mapped : MappedCtxInv f ctx) (clean : Clean (sourceIdentityCtx ctx))
    {block ti : Nat} {branch : Bool} {indices : List Nat}
    (slots : ∀ i ∈ indices,ScanSlot ctx i ti branch)
    {input : State} {output : BlockScan} (empty : NoOpportunity input)
    (run : scanBlock ctx block ti branch indices input = .ok output) :
    SourceCallsSame ctx input output.state ∧ ∀ record ∈ output.records,
      SourceCallsSame ctx input record.input ∧ SourceCallsSame ctx input record.output.state :=
  block_same mapped clean slots empty (fun _ _ => rfl) run
/-- Original call metadata plus an actual unsunk scan input forces the real
mandatory emission path. Terminator separation comes from the actual empty
placeholder, rather than an additional accepted-input condition. -/
theorem stock_scan_original_call_emitted {ctx : Ctx} {block i ti : Nat} {branch : Bool}
    (source : SourceCallSlot ctx i) (terminal : ctx.insts[ti]!.clif = none)
    {input : State} {output : Scan} (unsunk : input.sunk[i]! = false)
    (run : scanInstruction ctx block i ti branch input = .ok output) :
    ∃ step,output.step = some step ∧ step.decision = .emitted := by
  have actual : ctx.insts[i]!.clif.any mustLower = true ∧ ctx.insts[i]!.clif ≠ none := by
    rcases source with ⟨info,fn,args,slot,clif⟩ | ⟨info,ref,callee,args,slot,clif⟩
    all_goals simp [getElem!_def,slot,clif,mustLower]
  have ne : i ≠ ti := by intro eq; subst i; rw [terminal] at actual; cases actual.2 rfl
  simp only [scanInstruction,unsunk,Bool.false_eq_true,ite_false,show (i == ti) = false from beq_eq_false_iff_ne.mpr ne,
    Bool.false_and,actual.1,Bool.not_true,Bool.false_and,Bool.and_false,ite_false] at run
  cases emitted : emitInstruction ctx i (scanState input i) with
  | error e => simp only [emitted,bind,Except.bind] at run; cases run
  | ok emission =>
    simp only [emitted,bind,Except.bind,pure,Except.pure] at run
    cases run
    exact ⟨_,rfl,rfl⟩
/-- A complete actual backward scan carries source-call unsunkness to its
final state and every retained boundary; no replay premise is supplied. -/
theorem stock_scanBlock_source_calls_unsunk {f : Clif.Function} {ctx : Ctx}
    (mapped : MappedCtxInv f ctx) (clean : Clean (sourceIdentityCtx ctx))
    {block ti : Nat} {branch : Bool} {indices : List Nat}
    (slots : ∀ i ∈ indices,ScanSlot ctx i ti branch)
    {input : State} {output : BlockScan} (empty : NoOpportunity input)
    (safe : SourceCallsUnsunk ctx input)
    (run : scanBlock ctx block ti branch indices input = .ok output) :
    SourceCallsUnsunk ctx output.state ∧ ∀ record ∈ output.records,
      SourceCallsUnsunk ctx record.input ∧ SourceCallsUnsunk ctx record.output.state := by
  have all := stock_scanBlock_source_calls_same mapped clean slots empty run
  have extend {st : State} (frame : SourceCallsSame ctx input st) : SourceCallsUnsunk ctx st :=
    fun i call => (frame i call).trans (safe i call)
  exact ⟨extend all.1,fun record member =>
    ⟨extend (all.2 record member).1,extend (all.2 record member).2⟩⟩
end Backend.Stock.Proof.CallSinkScansDraft

