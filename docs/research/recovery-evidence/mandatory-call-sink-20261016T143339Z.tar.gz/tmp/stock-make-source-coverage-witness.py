from pathlib import Path
s='''import StockCallSourceCoverage
import StockCallEmissionWitness
import StockIndirectCallEmissionWitness
import StockGotCallWitness
namespace Backend.Stock.Proof.CallSourceCoverageWitnessDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open CallSourceCoverageDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
attribute [local irreducible] Stock.lower Stock.runTerm Isle.Aarch64.program
'''
for tag,ns,flag,root,far in [('direct','CallStaticFixture','false','CallEmissionWitnessDraft.stock_complete_direct_call_emission_witness',False),('indirect','CallStaticFixture','true','IndirectCallEmissionWitnessDraft.stock_complete_indirect_call_emission_witness',False),('got','GotCallFixture','false','GotCallWitnessDraft.stock_complete_got_call_emission_witness',True)]:
 fun=ns+'.function '+('implicit' if far else flag+' implicit');callidx='1' if tag=='indirect' else '0'
 inst=f'.callIndirect 0 80 (CallStaticFixture.arguments true implicit)' if tag=='indirect' else '.call 0 (CallStaticFixture.arguments false implicit)'
 stackpart='' if tag=='indirect' else 'SigStackOk (CallStaticFixture.signature false implicit) out.result.code.outgoing ∧\n      '
 s+=f'''
/-- The actual {tag} ordinary/sret source position, entry reachability and
complete checked/physical pipeline inhabit the new source-to-record coverage
contracts. All retained/emission evidence is obtained from the new roots. -/
theorem stock_complete_{tag}_reachable_call_witness (implicit : Bool) :
    ∃ (out : {ns}.Output) (event : BlockScanEvent) (record : ScanRecord) (info : IInfo) (step : Step),
      LowerScope ({fun}) ∧ Dominated ({fun}) ∧ ArityOk ({fun}) ∧ AbiSigsOk ({fun}) ∧
      Stock.lower ({fun}) = .ok out.result ∧
      prepareAt out.result.code out.result.edgeArgs = .ok out.prepared ∧
      out.rf = spillAllocAt out.prepared.code out.prepared.edges ∧
      checkAllocAt out.prepared.code out.prepared.edges out.rf = .ok () ∧
      lowerRFunc out.prepared.code out.rf = .ok out.af ∧
      stockSourceTable ({fun}) = .ok #[#[]] ∧ Prep.Reach #[#[]] 0 ∧
      {stackpart}event ∈ out.result.blockScans.toList ∧ event.block = 0 ∧ record ∈ event.output.records ∧
      record.inst = blockStart ({fun}) 0 + {callidx} ∧ event.ctx.insts[record.inst]? = some info ∧
      info.clif = some ({inst}) ∧ record.output.step = some step ∧ step.decision = .emitted := by
  obtain ⟨out,oldEvent,oldRecord,oldInfo,oldStep,scope,dom,arity,abi,run,prepared,fallback,checked,physical,
    facts,oldEvents,oldRecords,oldSlot,oldClif,oldRecorded,oldEmitted,rest⟩ := {root} implicit
  let f := {fun}
  let b := f.blocks[0]!
  have block : f.blocks[0]? = some b := by cases implicit <;> rfl
  have statement : b.body[{callidx}]? = some (CallStaticFixture.callStatement {flag} implicit) := by cases implicit <;> rfl
  have computed : stockSourceTable f = .ok #[#[]] := by cases implicit <;> rfl
  have kind : (CallStaticFixture.callStatement {flag} implicit).inst = ({inst}) := rfl
  have actualKind : (∃ fn args,(CallStaticFixture.callStatement {flag} implicit).inst = .call fn args) ∨
      (∃ ref callee args,(CallStaticFixture.callStatement {flag} implicit).inst = .callIndirect ref callee args) :=
    {'.inr ⟨0,80,_,kind⟩' if tag=='indirect' else '.inl ⟨0,_,kind⟩'}
  obtain ⟨event,record,info,step,events,current,records,index,slot,clif,recorded,emitted⟩ :=
    stock_lower_reachable_source_call_emitted run scope computed (.entry : Prep.Reach #[#[]] 0) block statement actualKind
'''
 if tag!='indirect':
  s+=f'''  let ext : Clif.ExtFunc := {{name := CallStaticFixture.calleeName,sig := CallStaticFixture.signature false implicit,colocated := {'false' if far else 'true'}}}
  have external : f.extern? 0 = some ext := rfl
  have stack := stock_lower_reachable_direct_call_stack run scope dom.1 abi computed
    (.entry : Prep.Reach #[#[]] 0) block statement kind external
'''
 s+=f'''  exact ⟨out,event,record,info,step,scope,dom,arity,abi,run,prepared,fallback,checked,physical,
    computed,.entry,{'' if tag=='indirect' else 'stack,'}events,current,records,index,slot,clif,recorded,emitted⟩
'''
s+='end Backend.Stock.Proof.CallSourceCoverageWitnessDraft\n';Path('/tmp/StockCallSourceCoverageWitness.lean').write_text(s)
