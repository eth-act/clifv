import StockCallSinkDriver
import FV.Backend.Proof.StockTermDataOrigin
import FV.Backend.Proof.StockConstantRecordValues
namespace Backend.Stock.Proof.CallMandatoryEmissionDraft
open Backend.Proof Backend.Proof.Driver Coverage Isle Isle.Interp Isle.Aarch64
open CallSinkControlDraft CallSinkScansDraft CallSinkDriverDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm scanBlock
private theorem scans_execute {exec : Nat → State → Except String Scan}
    {indices : List Nat} {input : State} {output : BlockScan}
    (cert : ScansSpec exec indices input output) :
    ∀ record ∈ output.records,exec record.inst record.input = .ok record.output := by
  induction cert with
  | nil input => simp
  | cons head rest ih =>
    intro record member
    rcases List.mem_cons.mp member with rfl | member
    · exact head
    · exact ih record member
private theorem record_execute {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) {event : BlockScanEvent}
    (events : event ∈ result.blockScans.toList) {record : ScanRecord}
    (records : record ∈ event.output.records) :
    scanInstruction event.ctx event.block record.inst event.termInst event.isBranch record.input = .ok record.output := by
  obtain ⟨ranges,params,earlier,suffix,starting,finishing,before,after,label,bi,data,core,
    build,ordered,initial,empty,parts,folded,final,prefixRun,nodeRun,suffixRun,node,coreRun,eventEq,stateEq⟩ :=
    stock_lower_blockScanOrigin run events
  rw [eventEq] at records ⊢
  have actual := (stock_lowerBlockCore_scanOrigin coreRun).2.2.2.2.2
  unfold scanBlock at actual
  exact scans_execute (runScans_spec actual) record records
/-- EVERY actual original direct or indirect source call record is emitted.
The successful whole driver derives its unsunk input, actual scan transition
and terminator separation internally, including zero-result calls. -/
theorem stock_lower_source_call_record_emitted {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f)
    {event : BlockScanEvent} (events : event ∈ result.blockScans.toList)
    {record : ScanRecord} (records : record ∈ event.output.records)
    (call : SourceCallSlot event.ctx record.inst) :
    ∃ step,record.output.step = some step ∧ step.decision = .emitted := by
  have context := stock_lower_record_context run scope events
  have original : SourceCallSlot result.ctx record.inst := by
    rcases call with ⟨info,fn,args,slot,clif⟩ | ⟨info,ref,callee,args,slot,clif⟩
    · exact .inl ⟨info,fn,args,context.2.2 _ _ _ slot clif,clif⟩
    · exact .inr ⟨info,ref,callee,args,context.2.2 _ _ _ slot clif,clif⟩
  have unsunk := ((stock_lower_records_source_calls_unsunk scope run events).2 record records).1 record.inst original
  obtain ⟨b,data,block,prepared,termSlot⟩ := stock_lower_blockScan_term_data run scope events
  have terminal : event.ctx.insts[event.termInst]!.clif = none := by
    simp only [getElem!_def,termSlot,Option.getD_some]
  exact stock_scan_original_call_emitted call terminal unsunk (record_execute run events records)
end Backend.Stock.Proof.CallMandatoryEmissionDraft
