import StockCallSinkDriver
import FV.Backend.Proof.SpillArity
import FV.Backend.Proof.SpillCtlPipe
import FV.Backend.Proof.LowerDecide
namespace Backend.Stock.Proof.UnreachableCallStackDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Cov Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm Stock.lower
private def arguments : List Nat := [100,101,102,103,104,105,106,107,108]
private def signature : Clif.Signature := {
  params := List.replicate 9 ⟨.i64,.none,.normal⟩,callConv := some .systemV }
private def external : Clif.ExtFunc := {name := "unreachable_nine_argument_callee",sig := signature,colocated := true}
private def statement : Clif.Stmt := ⟨[],.call 0 arguments⟩
private def dead : Clif.Block := {id := 1,params := arguments.map (fun x => (x,.i64)),body := [statement],term := .ret []}
private def function : Clif.Function := {
  name := "stock_unreachable_call_stack"
  sig := {callConv := some .systemV}
  externs := [(0,external)]
  blocks := [{id := 0,term := .ret []},dead] }
private theorem scope : LowerScope function := lowerScope_of (by decide +kernel)
private theorem arity : ArityOk function := arityOk_of (by decide +kernel)
private theorem abi : AbiSigsOk function := by
  constructor
  · constructor
    · decide +kernel
    · intro e member
      simp only [function,List.mem_singleton] at member
      subst e
      decide +kernel
  · intro sig member
    simp [indSigs,function,dead,statement] at member
private theorem dominated : Dominated function := by
  constructor
  · decide +kernel
  · intro ctx ranges st build bi b found
    rcases bi with _ | (_ | bi)
    · simp only [function,List.getElem?_cons_zero,Option.some.injEq] at found
      subst b
      constructor
      · intro j stm present; simp at present
      · intro x member; simp [abiTerm,Driver.termArgs,function,sretRet,sigRets] at member
    · simp only [function,List.getElem?_cons_succ,List.getElem?_cons_zero,Option.some.injEq] at found
      subst b
      constructor
      · intro j stm present x member
        cases j with
        | zero =>
          simp only [dead,List.getElem?_cons_zero,Option.some.injEq] at present
          subst stm
          simp only [statement,Driver.instArgs] at member
          simp [arguments] at member
          rcases member with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
          all_goals simp [availOf,function,dead,statement,defsBefore,defsFrom,arguments]
        | succ j => simp [dead] at present
      · intro x member; simp [abiTerm,Driver.termArgs,function,dead,sretRet,sigRets] at member
    · simp [function] at found
  · intro ctx ranges st build tl x incoming notLocal y member
    have bound := (inFix_fixOk (f := function) (ctx := ctx) (gn := id)).cand tl x incoming
    have size : function.blocks.length = 2 := rfl
    have which : tl = 1 := by omega
    subst tl
    have source := bound.2.2.2.1
    have notParam := bound.2.2.2.2.1
    exact False.elim (notParam (by simpa [valueDefs,parsOf,function,dead,statement,arguments] using source))
private def observed : Prop := (Stock.lower function).toOption.map (fun r =>
  r.code.outgoing == 0 && decide (r.order.nodes.toList = [.original 0])) = some true
private theorem actual : observed := by unfold observed; decide +kernel
/-- The ORIGINAL input conditions allow an unreachable nine-argument call.
The actual Stock driver emits only the entry block with outgoing area zero,
so the legacy all-source-block CallsStack contract is false at that area. -/
theorem stock_unreachable_call_stack_witness :
    ∃ (f : Clif.Function) (result : Result),
      LowerScope f ∧ Dominated f ∧ ArityOk f ∧ AbiSigsOk f ∧
      Stock.lower f = .ok result ∧ result.code.outgoing = 0 ∧
      result.order.nodes.toList = [.original 0] ∧ ¬ CallsStack f result.code.outgoing := by
  have observation := actual
  unfold observed at observation
  cases run : Stock.lower function with
  | error e => simp only [run,Except.toOption,Option.map_none] at observation; cases observation
  | ok result =>
    simp only [run,Except.toOption,Option.map_some,Option.some.injEq,Bool.and_eq_true,beq_iff_eq,decide_eq_true_eq] at observation
    have outgoing : result.code.outgoing = 0 := observation.1
    have order : result.order.nodes.toList = [.original 0] := observation.2
    refine ⟨function,result,scope,dominated,arity,abi,run,outgoing,order,?_⟩
    intro stack
    have bound := stack dead (by simp [function]) statement (by simp [dead]) 0 arguments external rfl (by rfl)
    rw [outgoing] at bound
    have required : stackBytes signature = 16 := by decide +kernel
    change stackBytes signature ≤ 0 ∧ _ at bound
    rw [required] at bound
    omega
end Backend.Stock.Proof.UnreachableCallStackDraft
