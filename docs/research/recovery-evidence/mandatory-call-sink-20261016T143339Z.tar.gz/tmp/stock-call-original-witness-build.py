from pathlib import Path
import os,re,json,time,subprocess as sp,datetime,traceback,hashlib
root=Path('/home/lee/clifv/.worktrees/driver-proof-resume');os.chdir(root);mods=['StockCallAreaBounds','StockCallActualStackWitness','StockGotActualStackWitness'];progress=Path('/tmp/stock-call-original-witness-progress.json');logs={};now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def report(state,**kw):
 d={'state':state,'pid':os.getpid(),'utc':now(),'completed':logs,**kw};progress.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items() if k!='completed'}),flush=True)
def deps(m):
 seen=set();required=set();missing=set()
 def visit(p):
  if str(p) in seen:return
  seen.add(str(p))
  for decl in re.findall(r'^import\s+([^\n]+)',p.read_text(),re.M):
   for m in decl.split():
    if m.startswith('FV.'):src=Path(m.replace('.','/')+'.lean');obj=Path('.lake/build/lib/lean',m.replace('.','/')+'.olean');required.add(m)
    elif m.startswith('Stock'):src=Path('/tmp',m+'.lean');obj=Path('/tmp',m+'.olean')
    else:continue
    if not obj.exists():missing.add(m)
    if src.exists():visit(src)
 visit(Path('/tmp',m+'.lean'));return required,sorted(missing)
env=dict(os.environ,OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',LEAN_PATH='/tmp',FV_MEMCAP='8G');lake='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin/lake'
try:
 for m in mods:
  previous=None
  while True:
   required,missing=deps(m);main=json.loads(Path('/tmp/stock-coherent-serial-progress.json').read_text());assert main['state']!='failed',main
   if main['state']=='running':assert Path('/proc',str(main['pid']),'cmdline').read_bytes().startswith(b'python3\0/tmp/stock-coherent-serial-build.py')
   busy=main.get('current') in required;key=(tuple(missing),main.get('index'),busy)
   if key!=previous:report('waiting_dependencies',module=m,missing=missing,canonical={k:v for k,v in main.items() if k in ['state','pid','index','current','total']},current_in_required_dependencies=busy);previous=key
   if not missing and not busy:break
   time.sleep(5)
  log=Path('/tmp/stock-call-area-build-'+m+'.log');report('running',module=m,log=str(log),memcap='8G')
  with log.open('w') as out:p=sp.run(['scripts/memcap.sh',lake,'env','lean','--root=/tmp','-o','/tmp/'+m+'.olean','/tmp/'+m+'.lean'],env=env,stdout=out,stderr=sp.STDOUT)
  assert p.returncode==0 and not re.search(r'error[:(]',log.read_text()),f'{m} rc={p.returncode} log={log}'
  logs[m]={'path':str(log),'sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
 report('complete',modules=len(mods),canonical_integration_MCP_fullgates='pending;original full #140 goal incomplete/production legacy')
except BaseException as e:report('failed',error=repr(e),traceback=traceback.format_exc());raise
