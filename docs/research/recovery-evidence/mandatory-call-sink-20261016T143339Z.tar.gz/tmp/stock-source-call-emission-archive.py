from pathlib import Path
import json,os,tarfile,io,hashlib,datetime,subprocess
os.nice(10);root=Path('/home/lee/clifv/.worktrees/driver-proof-resume');os.chdir(root)
r=json.loads(Path('docs/research/stock-source-call-emission-scratch.json').read_text());previous=json.loads(Path('docs/research/stock-call-protection-backup.json').read_text())
remote=subprocess.check_output(['git','ls-remote','origin','refs/heads/'+previous['branch']],text=True).split()[0];assert remote==previous['commit']
# The preceding complete archive remains local and remotely backed up. Store
# a verified chain pointer rather than nesting another copy of its 50MiB blob.
assert hashlib.sha256(Path(previous['archive']['archive']).read_bytes()).hexdigest()==previous['archive']['sha256']
rows=subprocess.check_output(['git','ls-tree','-r',previous['commit']],text=True).splitlines();archived=[x.split('\t',1)[1] for x in rows if x.endswith('.tar.gz') and 'recovery-evidence/mandatory-call-sink-' in x];assert len(archived)==1
proc=subprocess.Popen(['git','show',previous['commit']+':'+archived[0]],stdout=subprocess.PIPE);h=hashlib.sha256()
for chunk in iter(lambda:proc.stdout.read(1048576),b''):h.update(chunk)
assert proc.wait()==0 and h.hexdigest()==previous['archive']['sha256']
chain={'previous_remote_branch':previous['branch'],'previous_remote_commit':previous['commit'],'previous_remote_archive_path':archived[0],'previous_archive_sha256':h.hexdigest(),'remote_and_local_chain_verified':True}
Path('/tmp/stock-source-call-emission-recovery-chain.json').write_text(json.dumps(chain,indent=2)+'\n')
files=[Path(p) for k in ['new_scratch_sources','new_compiled_modules','new_compiled_logs'] for p in r[k]]
files += [Path(p) for p in ['docs/plans/test-binary-alignment-recovery.md','docs/research/stock-full-goal-current.md','docs/research/stock-source-call-emission-scratch.json','docs/research/stock-source-call-emission-scratch.md','docs/research/stock-call-protection-backup.json','docs/research/stock-cfg-preparation-delivery.json','docs/research/stock-cfg-preparation-delivery.md','docs/research/stock-per-successor-delivery.json','docs/research/cleanup-discipline-current.json']]
files += [Path('/tmp',p) for p in ['stock-source-call-emission-batch.json','stock-source-call-emission-axioms.lean','stock-source-call-emission-axioms.log','stock-source-call-emission-evidence.py','stock-source-call-emission-archive.py','stock-source-call-emission-recovery-chain.json','stock-make-source-coverage-witness.py','stock-call-source-witness-build.py','stock-call-source-witness-progress.json','stock-call-source-witness-controller.log','stock-call-source-coverage-build.py','stock-call-source-coverage-progress.json','stock-call-source-coverage-controller.log','stock-source-coverage-build-StockCallSourceCoverage.log','stock-call-source-coverage-witness.log','stock-call-original-witness-build.py','stock-call-original-witness-progress.json','stock-call-area-candidate-build.py','stock-call-area-candidate-progress.json','stock-coherent-build-inputs.json','stock-coherent-serial-progress.json','stock-coherent-serial-build.py','stock-create-cfg-delivery.py','stock-cfg-delivery-result.json','stock-cfg-preparation-pr-body.md']]
files=sorted(set(files));assert all(p.exists() for p in files)
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');dest=Path('/home/lee/.clifv-recovery')/(stamp+'-source-call-emission');dest.mkdir();archive=dest/'checkpoint.tar.gz';captured=[]
with tarfile.open(archive,'w:gz',compresslevel=1) as t:
 for p in files:
  p=p.resolve();data=p.read_bytes();name=str(p).lstrip('/');meta=tarfile.TarInfo(name);meta.size=len(data);meta.mode=0o644;meta.mtime=int(p.stat().st_mtime);t.addfile(meta,io.BytesIO(data));captured.append({'path':str(p),'member':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with tarfile.open(archive,'r:gz') as t:
 for row in captured:
  data=t.extractfile(row['member']).read();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'],row['path']
r={'utc':stamp,'archive':str(archive),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'members':len(captured),'every_member_verified':True,'recovery_chain':chain,'captured':captured};(dest/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');Path('/tmp/stock-source-call-emission-archive-result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='captured'}))
