import StockCallSinkControl
import FV.Backend.Proof.LowerDecide
import FV.Backend.Proof.SpillArity
import FV.Backend.Proof.SpillCtlPipe
namespace Backend.Stock.Proof.CallSinkControlWitnessDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Cov Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open CallSinkControlDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm
inductive Kind where
  | ret | trap | jump
  deriving DecidableEq,Repr
private def term : Kind → Clif.Terminator
  | .ret => .ret []
  | .trap => .trap (.user 9)
  | .jump => .jump ⟨1,[]⟩
private def signature : Clif.Signature := {callConv := some .systemV}
private def first (k : Kind) : Clif.Block := {
  id := 0,params := [(1,.i64),(3,.i64)],body := [⟨[],.call 0 []⟩,⟨[],.callIndirect 0 3 []⟩],term := term k }
private def function (k : Kind) : Clif.Function := {
  name := "stock_calls_control_frames"
  sig := {params := [⟨.i64,.none,.normal⟩,⟨.i64,.none,.normal⟩],callConv := some .systemV}
  externs := [(0,{name := "control_frame_callee",sig := signature,colocated := true})]
  sigDecls := [(0,signature)]
  blocks := if k = .jump then [first k,{id := 1,term := .ret []}] else [first k] }
private def built (k : Kind) : Ctx × Array (Nat × Nat) × State :=
  (Stock.buildCtx (function k)).toOption.getD (sinkCtx,#[],sinkState)
private def data (k : Kind) : V := (Backend.termData (term k)).toOption.getD (.op .unit)
private def context (k : Kind) : Ctx := Driver.termCtx (built k).1 2 (data k)
private def name : Kind → String | .jump => "lower_branch" | _ => "lower"
private def arguments : Kind → List V | .jump => [.inst 2,.labels [1]] | _ => [.inst 2]
private theorem build (k : Kind) : Stock.buildCtx (function k) = .ok (built k) := by cases k <;> rfl
private theorem scope (k : Kind) : LowerScope (function k) := by cases k <;> apply lowerScope_of <;> decide +kernel
private theorem arity (k : Kind) : ArityOk (function k) := by cases k <;> apply arityOk_of <;> decide +kernel
private theorem abi (k : Kind) : AbiSigsOk (function k) := by
  constructor
  · constructor
    · cases k <;> decide +kernel
    · intro e member
      simp only [function,List.mem_singleton] at member
      subst e
      decide +kernel
  · intro sig member
    cases k <;> simp [indSigs,function,first,signature,term] at member
    all_goals subst sig; constructor <;> decide +kernel
private theorem dominated (k : Kind) : Dominated (function k) := by
  constructor
  · cases k <;> decide +kernel
  · intro ctx ranges st build bi b found
    cases k <;> rcases bi with _ | (_ | bi)
    all_goals simp [function] at found
    all_goals subst b
    all_goals constructor
    all_goals first
      | (intro j stm present x member
         rcases j with _ | (_ | j)
         all_goals simp [first] at present
         all_goals subst stm
         all_goals simp [Driver.instArgs] at member
         all_goals subst x
         all_goals simp [availOf,function,first,defsBefore,defsFrom])
      | (intro x member
         simp [abiTerm,Driver.termArgs,function,first,term,signature,sretRet,sigRets] at member)
  · intro ctx ranges st build tl x incoming notLocal y member
    have bound := (inFix_fixOk (f := function k) (ctx := ctx) (gn := id)).cand tl x incoming
    cases k with
    | ret => have size : (function .ret).blocks.length = 1 := rfl; omega
    | trap => have size : (function .trap).blocks.length = 1 := rfl; omega
    | jump =>
      have size : (function .jump).blocks.length = 2 := rfl
      have index : tl = 1 := by omega
      subst tl
      simp [parsOf,function]
private theorem placeholder (k : Kind) : (built k).1.insts[2]? = some ⟨.op .unit,[],[],none⟩ := by cases k <;> rfl
private theorem prepared (k : Kind) : Backend.termData (term k) = .ok (data k) := by cases k <;> rfl
private theorem clean_built {f : Clif.Function} {ctx : Ctx} {ranges : Array (Nat × Nat)} {st : State}
    (build : Stock.buildCtx f = .ok (ctx,ranges,st)) : Clean (sourceIdentityCtx ctx) := by
  obtain ⟨original,before,legacy,spec,view⟩ := buildCtx_source build
  intro i info lookup
  change ctx.insts[i]? = some info at lookup
  rw [view.insts] at lookup
  exact Cov.clean_of_build legacy i info lookup
private def observed (k : Kind) : Prop :=
  (Stock.runTerm (context k) (name k) (arguments k) (built k).2.2).toOption.map
    (fun q => !q.2.1.sunk[0]! && !q.2.1.sunk[1]!) = some true
private theorem actual (k : Kind) : observed k := by cases k <;> unfold observed <;> decide +kernel
/-- Original-condition functions contain BOTH real source-call forms while
actual return, trap and jump roots run in their real prepared contexts. Both
nonempty call slots are preserved by the new root contracts. -/
theorem stock_control_both_source_calls_witness (k : Kind) :
    ∃ (f : Clif.Function) (ctx : Ctx) (before after : State) (name : String) (args : List V)
      (out : Option V) (trace : List RuleId),
      LowerScope f ∧ Dominated f ∧ ArityOk f ∧ AbiSigsOk f ∧
      MappedCtxInv f ctx ∧ Clean (sourceIdentityCtx ctx) ∧
      SourceCallSlot ctx 0 ∧ SourceCallSlot ctx 1 ∧
      Stock.runTerm ctx name args before = .ok (out,after,trace) ∧ SourceCallsSame ctx before after ∧
      before.sunk[0]! = false ∧ before.sunk[1]! = false ∧ after.sunk[0]! = false ∧ after.sunk[1]! = false := by
  have observation := actual k
  unfold observed at observation
  cases call : Stock.runTerm (context k) (name k) (arguments k) (built k).2.2 with
  | error e => simp only [call,Except.toOption,Option.map_none] at observation; cases observation
  | ok q =>
    obtain ⟨out,after,trace⟩ := q
    have mapped : MappedCtxInv (function k) (context k) :=
      (buildCtx_mappedInv (scope k) (build k)).termCtx (placeholder k) (data k)
    have clean : Clean (sourceIdentityCtx (context k)) := clean_termCtx (clean_built (build k)) (prepared k) 2
    have slot : (context k).insts[2]? = some ⟨data k,[],[],none⟩ := termCtx_insts_self (placeholder k) (data k)
    have frame : SourceCallsSame (context k) (built k).2.2 after := by
      cases k with
      | ret => exact stock_retTrap_source_calls_same mapped clean rfl (prepared .ret) slot call
      | trap => exact stock_retTrap_source_calls_same mapped clean rfl (prepared .trap) slot call
      | jump => exact stock_branch_source_calls_same mapped clean call
    have direct : SourceCallSlot (context k) 0 := by
      apply Or.inl
      refine ⟨(context k).insts[0]!,0,[],?_,?_⟩
      all_goals cases k <;> rfl
    have indirect : SourceCallSlot (context k) 1 := by
      apply Or.inr
      refine ⟨(context k).insts[1]!,0,3,[],?_,?_⟩
      all_goals cases k <;> rfl
    simp only [call,Except.toOption,Option.map_some,Option.some.injEq,Bool.and_eq_true,Bool.not_eq_true'] at observation
    refine ⟨function k,context k,(built k).2.2,after,name k,arguments k,out,trace,scope k,dominated k,arity k,abi k,
      mapped,clean,direct,indirect,call,frame,?_,?_,observation.1,observation.2⟩
    all_goals cases k <;> rfl
end Backend.Stock.Proof.CallSinkControlWitnessDraft
