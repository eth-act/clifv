import StockDirectCallAreaOrdinary
import StockDirectCallAreaSret
import StockGotCallAreaOrdinary
import StockGotCallAreaSret
namespace Backend.Stock.Proof.CallAreaBoundsDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64 CallAreaObservationDraft
/-- Exact outgoing field of the already-used ordinary/sret direct sources. -/
theorem stock_direct_call_area (implicit : Bool) {result : Result}
    (run : Stock.lower (CallStaticFixture.function false implicit) = .ok result) :
    result.code.outgoing = (if implicit then 0 else 16) := by
  cases implicit with
  | false =>
    have actual := stock_direct_call_area_false
    simpa only [run,Except.toOption,Option.map_some,Option.some.injEq,beq_iff_eq,Bool.false_eq_true,↓reduceIte] using actual
  | true =>
    have actual := stock_direct_call_area_true
    simpa only [run,Except.toOption,Option.map_some,Option.some.injEq,beq_iff_eq,Bool.false_eq_true,↓reduceIte] using actual
/-- Exact outgoing field of the SAME noncolocated/GOT ordinary/sret sources. -/
theorem stock_got_call_area (implicit : Bool) {result : Result}
    (run : Stock.lower (GotCallFixture.function implicit) = .ok result) :
    result.code.outgoing = (if implicit then 0 else 16) := by
  cases implicit with
  | false =>
    have actual := stock_got_call_area_false
    simpa only [run,Except.toOption,Option.map_some,Option.some.injEq,beq_iff_eq,Bool.false_eq_true,↓reduceIte] using actual
  | true =>
    have actual := stock_got_call_area_true
    simpa only [run,Except.toOption,Option.map_some,Option.some.injEq,beq_iff_eq,Bool.false_eq_true,↓reduceIte] using actual
end Backend.Stock.Proof.CallAreaBoundsDraft
