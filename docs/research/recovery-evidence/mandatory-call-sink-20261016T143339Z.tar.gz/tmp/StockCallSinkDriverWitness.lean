import StockCallMandatoryEmission
import StockCallOriginalOutgoing
import StockCallEmissionWitness
import StockGotCallWitness
namespace Backend.Stock.Proof.CallSinkDriverWitnessDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open CallSinkControlDraft CallSinkScansDraft CallSinkDriverDraft CallMandatoryEmissionDraft CallOriginalOutgoingDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm Stock.lower
private theorem retained_facts {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dom : Dominated f) (abi : AbiSigsOk f)
    {event : BlockScanEvent} (events : event ∈ result.blockScans.toList)
    {record : ScanRecord} (records : record ∈ event.output.records)
    {info : IInfo} {fn : Nat} {args : List Nat} {ext : Clif.ExtFunc}
    (slot : event.ctx.insts[record.inst]? = some info) (clif : info.clif = some (.call fn args))
    (external : f.extern? fn = some ext) :
    SourceCallsUnsunk result.ctx result.final ∧
    SourceCallsUnsunk result.ctx event.input ∧
    SourceCallsUnsunk result.ctx record.input ∧ SourceCallsUnsunk result.ctx record.output.state ∧
    SourceCallSlot result.ctx record.inst ∧ SigStackOk ext.sig result.code.outgoing ∧
    ∃ step,record.output.step = some step ∧ step.decision = .emitted := by
  have ctx := stock_lower_record_context run scope events
  have original : SourceCallSlot result.ctx record.inst :=
    .inl ⟨info,fn,args,ctx.2.2 _ _ _ slot clif,clif⟩
  have safe := stock_lower_records_source_calls_unsunk scope run events
  exact ⟨stock_lower_source_calls_unsunk scope run,safe.1,(safe.2 record records).1,(safe.2 record records).2,
    original,stock_lower_original_call_code_stack run scope dom.1 abi events records slot clif external,
    stock_lower_source_call_record_emitted run scope events records (.inl ⟨info,fn,args,slot,clif⟩)⟩

/-- Complete ordinary and sret direct pipelines inhabit whole-driver source-call
unsunkness at final and retained boundaries, mandatory emission and the stack
bound at the actual returned outgoing area. Existing complete stage observations
are reused, while every new conclusion is derived by the new general roots. -/
theorem stock_complete_direct_call_unsunk_driver_witness (implicit : Bool) :
    ∃ (out : CallStaticFixture.Output) (event : BlockScanEvent) (record : ScanRecord) (info : IInfo),
      LowerScope (CallStaticFixture.function false implicit) ∧ Dominated (CallStaticFixture.function false implicit) ∧
      ArityOk (CallStaticFixture.function false implicit) ∧ AbiSigsOk (CallStaticFixture.function false implicit) ∧
      Stock.lower (CallStaticFixture.function false implicit) = .ok out.result ∧
      prepareAt out.result.code out.result.edgeArgs = .ok out.prepared ∧
      out.rf = spillAllocAt out.prepared.code out.prepared.edges ∧
      checkAllocAt out.prepared.code out.prepared.edges out.rf = .ok () ∧
      lowerRFunc out.prepared.code out.rf = .ok out.af ∧
      event ∈ out.result.blockScans.toList ∧ record ∈ event.output.records ∧
      event.ctx.insts[record.inst]? = some info ∧
      info.clif = some (.call 0 (CallStaticFixture.arguments false implicit)) ∧
      SourceCallsUnsunk out.result.ctx out.result.final ∧
      SourceCallsUnsunk out.result.ctx event.input ∧
      SourceCallsUnsunk out.result.ctx record.input ∧ SourceCallsUnsunk out.result.ctx record.output.state ∧
      SourceCallSlot out.result.ctx record.inst ∧
      SigStackOk (CallStaticFixture.signature false implicit) out.result.code.outgoing ∧
      ∃ step,record.output.step = some step ∧ step.decision = .emitted := by
  obtain ⟨out,event,record,info,step,scope,dom,arity,abi,run,prepared,fallback,checked,physical,
    facts,events,records,slot,clif,recorded,emitted,rest⟩ := CallEmissionWitnessDraft.stock_complete_direct_call_emission_witness implicit
  let ext : Clif.ExtFunc := {name := CallStaticFixture.calleeName,sig := CallStaticFixture.signature false implicit,colocated := true}
  have external : (CallStaticFixture.function false implicit).extern? 0 = some ext := rfl
  exact ⟨out,event,record,info,scope,dom,arity,abi,run,prepared,fallback,checked,physical,
    events,records,slot,clif,retained_facts run scope dom abi events records slot clif external⟩

/-- Complete ordinary and sret got pipelines inhabit whole-driver source-call
unsunkness at final and retained boundaries, mandatory emission and the stack
bound at the actual returned outgoing area. Existing complete stage observations
are reused, while every new conclusion is derived by the new general roots. -/
theorem stock_complete_got_call_unsunk_driver_witness (implicit : Bool) :
    ∃ (out : GotCallFixture.Output) (event : BlockScanEvent) (record : ScanRecord) (info : IInfo),
      LowerScope (GotCallFixture.function implicit) ∧ Dominated (GotCallFixture.function implicit) ∧
      ArityOk (GotCallFixture.function implicit) ∧ AbiSigsOk (GotCallFixture.function implicit) ∧
      Stock.lower (GotCallFixture.function implicit) = .ok out.result ∧
      prepareAt out.result.code out.result.edgeArgs = .ok out.prepared ∧
      out.rf = spillAllocAt out.prepared.code out.prepared.edges ∧
      checkAllocAt out.prepared.code out.prepared.edges out.rf = .ok () ∧
      lowerRFunc out.prepared.code out.rf = .ok out.af ∧
      event ∈ out.result.blockScans.toList ∧ record ∈ event.output.records ∧
      event.ctx.insts[record.inst]? = some info ∧
      info.clif = some (.call 0 (CallStaticFixture.arguments false implicit)) ∧
      SourceCallsUnsunk out.result.ctx out.result.final ∧
      SourceCallsUnsunk out.result.ctx event.input ∧
      SourceCallsUnsunk out.result.ctx record.input ∧ SourceCallsUnsunk out.result.ctx record.output.state ∧
      SourceCallSlot out.result.ctx record.inst ∧
      SigStackOk (CallStaticFixture.signature false implicit) out.result.code.outgoing ∧
      ∃ step,record.output.step = some step ∧ step.decision = .emitted := by
  obtain ⟨out,event,record,info,step,scope,dom,arity,abi,run,prepared,fallback,checked,physical,
    facts,events,records,slot,clif,recorded,emitted,rest⟩ := GotCallWitnessDraft.stock_complete_got_call_emission_witness implicit
  let ext : Clif.ExtFunc := {name := CallStaticFixture.calleeName,sig := CallStaticFixture.signature false implicit,colocated := false}
  have external : (GotCallFixture.function implicit).extern? 0 = some ext := rfl
  exact ⟨out,event,record,info,scope,dom,arity,abi,run,prepared,fallback,checked,physical,
    events,records,slot,clif,retained_facts run scope dom abi events records slot clif external⟩
end Backend.Stock.Proof.CallSinkDriverWitnessDraft
