import StockCallStaticSource
import StockGotCallSource
namespace Backend.Stock.Proof.CallAreaObservationDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm Stock.lower
/-- The actual scheduler's outgoing field only. Allocation, preparation,
physical lowering and callee observations are reused from earlier witnesses. -/
theorem stock_direct_call_area_true :
    (Stock.lower (CallStaticFixture.function false true)).toOption.map (fun r => r.code.outgoing == 0) = some true := by
  decide +kernel
end Backend.Stock.Proof.CallAreaObservationDraft
