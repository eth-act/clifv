import StockCallMandatoryEmission
import StockCallOriginalOutgoing
import FV.Backend.Proof.StockBodyScanOrigin
import FV.Backend.Proof.StockNodeCoverage
namespace Backend.Stock.Proof.CallSourceCoverageDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open CallSinkControlDraft CallMandatoryEmissionDraft CallOriginalOutgoingDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
/-- Every statement of an actual original output block has its real retained
record and original instruction metadata. No record certificate is supplied. -/
theorem stock_lower_original_body_record {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) {label bi : Nat}
    (node : result.order.nodes[label]? = some (.original bi))
    {b : Clif.Block} (block : f.blocks[bi]? = some b) {j : Nat} {stm : Clif.Stmt}
    (statement : b.body[j]? = some stm) :
    ∃ (event : BlockScanEvent) (record : ScanRecord) (info : IInfo),
      event ∈ result.blockScans.toList ∧ event.block = bi ∧ record ∈ event.output.records ∧
      record.inst = blockStart f bi + j ∧ event.ctx.insts[record.inst]? = some info ∧ info.clif = some stm.inst := by
  obtain ⟨event,events,current⟩ := stock_lower_original_scan run node
  obtain ⟨b',term,body,split⟩ := stock_lower_body_scan_split run scope events
  have same : b' = b := by
    have found := split.block
    rw [current,block] at found
    exact (Option.some.inj found).symm
  subst b'
  have bound := (List.getElem?_eq_some_iff.mp statement).1
  have member : blockStart f event.block + j ∈ body.records.map (·.inst) := by
    rw [split.scanned.order]
    unfold sourceBodyIndices
    rw [List.mem_reverse]
    exact List.mem_map.mpr ⟨j,List.mem_range.mpr bound,rfl⟩
  obtain ⟨record,records,index⟩ := List.mem_map.mp member
  obtain ⟨ranges,params,earlier,suffix,starting,finishing,before,after,label',bi',data,core,
    build,ordered,initial,empty,parts,folded,final,prefixRun,nodeRun,suffixRun,node',coreRun,eventEq,stateEq⟩ :=
    stock_lower_blockScanOrigin run events
  obtain ⟨original,oldState,legacy,spec,view⟩ := buildCtx_source build
  have eventBlock : f.blocks[event.block]? = some b := by rw [current]; exact block
  obtain ⟨info,source,clif,results⟩ := spec.facts.stmt event.block b j stm eventBlock statement
  have actual : result.ctx.insts[record.inst]? = some info := by rw [index,view.insts]; exact source
  have different : record.inst ≠ event.termInst := by rw [index,split.termIndex]; omega
  have origin := stock_lowerBlockCore_scanOrigin coreRun
  have contexts : event.ctx.insts = (Driver.termCtx result.ctx event.termInst data).insts := by
    rw [eventEq,origin.2.1,origin.2.2.2.1]
  refine ⟨event,record,info,events,current,split.retained record records,?_,?_,clif⟩
  · simpa only [current] using index
  · rw [contexts,termCtx_insts_ne different]; exact actual

/-- Every entry-reachable source block has an actual original output node.
The actual source successor table is derived by successful lowering. -/
theorem stock_lower_reachable_original_node {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f)
    {source : Array (Array Nat)} (computed : stockSourceTable f = .ok source)
    {bi : Nat} (reached : Prep.Reach source bi) :
    ∃ label : Nat,result.order.nodes[label]? = some (Node.original bi) := by
  have ordered := stock_lower_order run
  obtain ⟨actual,actualComputed,projected⟩ := stock_blockOrder_originals ordered
  have same : actual = source := by rw [computed] at actualComputed; exact (Except.ok.inj actualComputed).symm
  subst actual
  obtain ⟨size,bounds⟩ := stock_sourceTable_bounds computed
  have nonempty : source.size ≠ 0 := by
    rw [size]
    exact fun h => scope.nonempty (List.length_eq_zero_iff.mp h)
  have retained := (Prep.rpo_spec bounds nonempty).2.2.2.2 bi reached
  rw [← projected] at retained
  unfold stockOriginals at retained
  obtain ⟨node,member,select⟩ := List.mem_filterMap.mp retained
  cases node with
  | edge pred k target => cases select
  | original index =>
    cases select
    exact Array.mem_iff_getElem?.mp (Array.mem_toList_iff.mp member)

/-- Every entry-reachable original direct or indirect call is actually emitted,
including zero-result calls. Node, scan, record and emission evidence is derived
from the real source position and successful whole driver. -/
theorem stock_lower_reachable_source_call_emitted {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f)
    {source : Array (Array Nat)} (computed : stockSourceTable f = .ok source)
    {bi : Nat} (reached : Prep.Reach source bi) {b : Clif.Block} (block : f.blocks[bi]? = some b)
    {j : Nat} {stm : Clif.Stmt} (statement : b.body[j]? = some stm)
    (call : (∃ fn args,stm.inst = .call fn args) ∨ (∃ ref callee args,stm.inst = .callIndirect ref callee args)) :
    ∃ (event : BlockScanEvent) (record : ScanRecord) (info : IInfo) (step : Step),
      event ∈ result.blockScans.toList ∧ event.block = bi ∧ record ∈ event.output.records ∧
      record.inst = blockStart f bi + j ∧ event.ctx.insts[record.inst]? = some info ∧
      info.clif = some stm.inst ∧ record.output.step = some step ∧ step.decision = .emitted := by
  obtain ⟨label,node⟩ := stock_lower_reachable_original_node run scope computed reached
  obtain ⟨event,record,info,events,current,records,index,slot,clif⟩ :=
    stock_lower_original_body_record run scope node block statement
  have actual : SourceCallSlot event.ctx record.inst := by
    rcases call with ⟨fn,args,kind⟩ | ⟨ref,callee,args,kind⟩
    · exact .inl ⟨info,fn,args,slot,by rw [clif,kind]⟩
    · exact .inr ⟨info,ref,callee,args,slot,by rw [clif,kind]⟩
  obtain ⟨step,recorded,emitted⟩ := stock_lower_source_call_record_emitted run scope events records actual
  exact ⟨event,record,info,step,events,current,records,index,slot,clif,recorded,emitted⟩

/-- Every executed-reachable direct/GOT source call fits the actual returned
outgoing area, without the false all-source-block CallsStack premise. -/
theorem stock_lower_reachable_direct_call_stack {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (ssa : (valueDefs f).Nodup) (abi : AbiSigsOk f)
    {source : Array (Array Nat)} (computed : stockSourceTable f = .ok source)
    {bi : Nat} (reached : Prep.Reach source bi) {b : Clif.Block} (block : f.blocks[bi]? = some b)
    {j : Nat} {stm : Clif.Stmt} (statement : b.body[j]? = some stm)
    {fn : Nat} {args : List Nat} (kind : stm.inst = .call fn args)
    {ext : Clif.ExtFunc} (external : f.extern? fn = some ext) : SigStackOk ext.sig result.code.outgoing := by
  obtain ⟨event,record,info,step,events,current,records,index,slot,clif,recorded,emitted⟩ :=
    stock_lower_reachable_source_call_emitted run scope computed reached block statement (.inl ⟨fn,args,kind⟩)
  exact stock_lower_original_call_code_stack run scope ssa abi events records slot (by rw [clif,kind]) external
end Backend.Stock.Proof.CallSourceCoverageDraft
