import StockCallMandatoryEmission
import StockCallOutgoing
import StockGotOutgoing
namespace Backend.Stock.Proof.CallOriginalOutgoingDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open CallSinkControlDraft CallMandatoryEmissionDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
/-- The ORIGINAL source conditions and actual successful whole lowering derive
that EVERY retained direct/GOT source call fits the actual returned outgoing
area. No emission, stack-area, or all-source-block CallsStack certificate is supplied. -/
theorem stock_lower_original_call_code_stack {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (ssa : (valueDefs f).Nodup) (abi : AbiSigsOk f)
    {event : BlockScanEvent} (events : event ∈ result.blockScans.toList)
    {record : ScanRecord} (records : record ∈ event.output.records)
    {info : IInfo} {fn : Nat} {args : List Nat} {ext : Clif.ExtFunc}
    (slot : event.ctx.insts[record.inst]? = some info) (clif : info.clif = some (.call fn args))
    (external : f.extern? fn = some ext) :
    SigStackOk ext.sig result.code.outgoing := by
  obtain ⟨step,recorded,emitted⟩ := stock_lower_source_call_record_emitted run scope events records
    (.inl ⟨info,fn,args,slot,clif⟩)
  cases colocated : ext.colocated with
  | true =>
    exact CallOutgoingDraft.stock_lower_direct_call_code_outgoing
      run scope ssa abi events records slot clif external colocated recorded emitted
  | false =>
    exact GotOutgoingDraft.stock_lower_got_call_code_outgoing
      run scope ssa abi events records slot clif external colocated recorded emitted
end Backend.Stock.Proof.CallOriginalOutgoingDraft
