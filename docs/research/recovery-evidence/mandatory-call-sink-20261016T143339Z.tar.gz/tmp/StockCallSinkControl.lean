import StockCallSinkRoots
import FV.Backend.Proof.StockTerminalRoots
namespace Backend.Stock.Proof.CallSinkControlDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Cov Isle Isle.Interp Isle.Aarch64
open CallSinkDraft CallSinkRootsDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
attribute [local irreducible] Isle.Aarch64.program
/-- An actual original direct or indirect call slot in the source context. -/
def SourceCallSlot (ctx : Ctx) (i : Nat) : Prop :=
  (∃ info fn args,ctx.insts[i]? = some info ∧ info.clif = some (.call fn args)) ∨
  (∃ info ref callee args,ctx.insts[i]? = some info ∧ info.clif = some (.callIndirect ref callee args))
/-- Exact call-bit framing, including calls that were already sunk on entry. -/
def SourceCallsSame (ctx : Ctx) (before after : State) : Prop :=
  ∀ i,SourceCallSlot ctx i → after.sunk[i]! = before.sunk[i]!
private theorem call_data {f : Clif.Function} {ctx : Ctx} (mapped : MappedCtxInv f ctx)
    {ti fn : Nat} {info : IInfo} {args : List Nat}
    (slot : ctx.insts[ti]? = some info) (clif : info.clif = some (.call fn args)) :
    info.data = .data 152 6 [.data 151 8 [],.values args,.op (.funcRef fn)] := by
  have data := mapped.data ti info _ slot clif
  simp only [instData] at data
  cases external : f.extern? fn with
  | none => simp only [external] at data; cases data
  | some ext =>
    simp only [external] at data
    split at data
    · unfold instDataV opcodeV mkVariant variantIdx variantNames Isle.Aarch64.program at data
      change Except.ok (V.data 152 6 [.data 151 8 [],.values args,.op (.funcRef fn)]) = .ok info.data at data
      exact (Except.ok.inj data).symm
    · cases data

private theorem indirect_data {f : Clif.Function} {ctx : Ctx} (mapped : MappedCtxInv f ctx)
    {ti ref callee : Nat} {info : IInfo} {args : List Nat}
    (slot : ctx.insts[ti]? = some info) (clif : info.clif = some (.callIndirect ref callee args)) :
    ∃ sig,f.sigDecls.lookup ref = some sig ∧
      info.data = .data 152 7 [.data 151 9 [],.values (callee :: args),.op (.sig sig)] := by
  have data := mapped.data ti info _ slot clif
  simp only [instData] at data
  cases declared : f.sigDecls.lookup ref with
  | none => simp only [declared] at data; cases data
  | some sig =>
    simp only [declared] at data
    unfold instDataV opcodeV mkVariant variantIdx variantNames Isle.Aarch64.program at data
    change Except.ok (V.data 152 7 [.data 151 9 [],.values (callee :: args),.op (.sig sig)]) = .ok info.data at data
    exact ⟨sig,rfl,(Except.ok.inj data).symm⟩


private theorem source_call_not_atomic {f : Clif.Function} {ctx : Ctx}
    (mapped : MappedCtxInv f ctx) {i : Nat} (call : SourceCallSlot ctx i) :
    ∀ info fields,ctx.insts[i]? = some info → (Backend.sem ctx).unData 152 info.data ≠ some (17,fields) := by
  rcases call with ⟨info,fn,args,slot,clif⟩ | ⟨info,ref,callee,args,slot,clif⟩
  · have data := call_data mapped slot clif
    intro actual fields found format
    have same := Option.some.inj (slot.symm.trans found)
    subst actual
    rw [data] at format
    simp [Backend.sem] at format
  · obtain ⟨sig,declared,data⟩ := indirect_data mapped slot clif
    intro actual fields found format
    have same := Option.some.inj (slot.symm.trans found)
    subst actual
    rw [data] at format
    simp [Backend.sem] at format
private theorem named_run_apply {ctx : Ctx} {name : String} {args : List V}
    {before after : State} {out : Option V} {trace : List RuleId}
    (run : Stock.runTerm ctx name args before = .ok (out, after, trace)) :
    ∃ (term : Term) (finalTrace : Array RuleId), program.termByName? name = some term ∧
      (applyTerm program (Stock.sem ctx) {} (Config.fuel ({} : Config)) term.ret term.id args).run
        (before, #[]) = .ok (out, after, finalTrace) := by
  unfold Stock.runTerm at run
  cases actual : Isle.Interp.run program (Stock.sem ctx) {} name args before with
  | error e => rw [actual] at run; cases run
  | ok result =>
    rw [actual] at run
    cases run
    unfold Isle.Interp.run at actual
    cases lookup : program.termByName? name with
    | none => simp only [lookup] at actual; cases actual
    | some term =>
      simp only [lookup] at actual
      cases lowered : (applyTerm program (Stock.sem ctx) {} (Config.fuel ({} : Config))
          term.ret term.id args).run (before, #[]) with
      | error e => simp only [lowered, bind, Except.bind] at actual; cases actual
      | ok result =>
        rcases result with ⟨out, after, trace⟩
        simp only [lowered, bind, Except.bind, pure, Except.pure] at actual
        cases actual
        exact ⟨term, trace, rfl, lowered⟩

private theorem stock_ruleFmt_match {ctx : Ctx} {r : Rule} {fT : Nat}
    (format : ruleFmt r = some fT) (lo : 2447 ≤ fT) (hi : fT < 2447 + 36)
    {fuel ti : Nat} {st next : State × Array RuleId} {env : Isle.Interp.Env V}
    (matched : (matchRule program (Stock.sem ctx) {} fuel r [.inst ti]).run st =
      .ok (some env, next)) :
    ∃ info fs, ctx.insts[ti]? = some info ∧ info.data = .data 152 (fT - 2447) fs := by
  have bound : fT - 2447 < 36 := by omega
  obtain ⟨term, lookup, kind⟩ := fmtKinds_program (fT - 2447) bound
  rw [show 2447 + (fT - 2447) = fT by omega] at lookup
  cases fuel with
  | zero => rw [matchRule.eq_1] at matched; cases matched
  | succ fuel =>
    obtain ⟨env0, args, _⟩ := matchRule_some_inv matched
    rw [stock_matchArgs] at args
    unfold ruleFmt at format
    split at format
    · rename_i q qs shape
      rw [shape] at args
      obtain ⟨env1, head, _⟩ := matchArgs_cons_inv args
      exact rootFmt_match_k data_program format lookup kind head
    · cases format

private theorem stock_lower_term_nomatch {ctx : Ctx} {ti : Nat} {t : Clif.Terminator}
    {data : V} (retTrap : retOrTrap t = true) (dataRun : Backend.termData t = .ok data)
    (slot : ctx.insts[ti]? = some ⟨data, [], [], none⟩) {r : Rule}
    (member : r ∈ program.rulesOf TId.lower) (notRoot : termRootRule r = false) :
    ∀ fuel st env next, (matchRule program (Stock.sem ctx) {} fuel r [.inst ti]).run st ≠
      .ok (some env, next) := by
  intro fuel st env next matched
  have checked := List.all_eq_true.mp lower_fmts r member
  simp only [lowerFmtOk, notRoot, Bool.false_or] at checked
  split at checked
  · rename_i fT format
    simp only [Bool.and_eq_true, decide_eq_true_eq, bne_iff_ne, ne_eq] at checked
    obtain ⟨⟨⟨lo, hi⟩, notRet⟩, notTrap⟩ := checked
    obtain ⟨info, fields, source, shape⟩ := stock_ruleFmt_match format lo hi matched
    rw [slot] at source
    cases source
    obtain ⟨fields', rfl⟩ := termData_fmt dataRun
    simp only [V.data.injEq] at shape
    cases t <;> simp [retOrTrap] at retTrap <;> simp [termFmt] at shape <;>
      first | omega | simp [Backend.termData, throw, throwThe, MonadExceptOf.throw] at dataRun
  · cases checked

private theorem protected_retTrap {f : Clif.Function} {ctx : Ctx}
    (mapped : MappedCtxInv f ctx) (clean : Clean (sourceIdentityCtx ctx))
    {ti : Nat} {t : Clif.Terminator} {data : V} (retTrap : retOrTrap t = true)
    (dataRun : Backend.termData t = .ok data) (slot : ctx.insts[ti]? = some ⟨data, [], [], none⟩)
    {before after : State} {out : Option V} {trace : List RuleId}
    (run : Stock.runTerm ctx "lower" [.inst ti] before = .ok (out, after, trace))
    {guardedIndex : Nat}
    (notAtomic : ∀ info fields,ctx.insts[guardedIndex]? = some info →
      (Backend.sem ctx).unData 152 info.data ≠ some (17,fields)) :
    after.sunk[guardedIndex]! = before.sunk[guardedIndex]! := by
  obtain ⟨term, finalTrace, lookup, lowered⟩ := named_run_apply run
  rw [program_termByName_lower] at lookup
  cases lookup
  let md := callSinkModel mapped clean guardedIndex notAtomic before.sunk[guardedIndex]!
  have cert := Coverage.OracleInvariant.soundAt mapped md {} callSinkTab rfl stock_callSink_table_checked
    (Config.fuel ({} : Config))
  have rules : ∀ r ∈ program.rulesOf T.lower.id,
      aRule program callSinkTab aext sourceSinkActor callSinkPre callSinkOracle [AW.c0] AW.top r = true ∨
        ∀ fuel st env next, (matchRule program (Stock.sem ctx) {} fuel r [.inst ti]).run st ≠
          .ok (some env, next) := by
    intro r member
    cases root : termRootRule r with
    | false => exact .inr (stock_lower_term_nomatch retTrap dataRun slot member root)
    | true =>
      have checked := List.all_eq_true.mp stock_callSink_roots_checked.2.1 r member
      simp only [termRootRule] at root
      simp only [root, Bool.not_true, Bool.false_or] at checked
      exact .inl checked
  exact (cert.root T.lower.ret T.lower.id T.lower _ _ [AW.c0] AW.top [.inst ti]
    before #[] out after finalTrace data_program.t686 term_686_kind rules
    ⟨γ_c0_inst ti, trivial⟩ rfl lowered).1

private theorem protected_branch {f : Clif.Function} {ctx : Ctx}
    (mapped : MappedCtxInv f ctx) (clean : Clean (sourceIdentityCtx ctx))
    {ti : Nat} {targets : List Label} {before after : State} {out : Option V}
    {trace : List RuleId}
    (run : Stock.runTerm ctx "lower_branch" [.inst ti, .labels targets] before =
      .ok (out, after, trace))
    {guardedIndex : Nat}
    (notAtomic : ∀ info fields,ctx.insts[guardedIndex]? = some info →
      (Backend.sem ctx).unData 152 info.data ≠ some (17,fields)) :
    after.sunk[guardedIndex]! = before.sunk[guardedIndex]! := by
  obtain ⟨term, finalTrace, lookup, lowered⟩ := named_run_apply run
  rw [program_termByName_lower_branch] at lookup
  cases lookup
  let md := callSinkModel mapped clean guardedIndex notAtomic before.sunk[guardedIndex]!
  have cert := Coverage.OracleInvariant.soundAt mapped md {} callSinkTab rfl stock_callSink_table_checked
    (Config.fuel ({} : Config))
  have input : Holds2 f (sourceIdentityCtx ctx) [AW.c0, AW.c0] [.inst ti, .labels targets] :=
    ⟨γ_c0_inst ti, γ_c0_labels targets, trivial⟩
  exact (cert.root T.lower_branch.ret T.lower_branch.id T.lower_branch _ _ [AW.c0, AW.c0]
    AW.top _ before #[] out after finalTrace data_program.t687 term_687_kind
    (fun r member => .inl (List.all_eq_true.mp stock_callSink_roots_checked.2.2 r member))
    input rfl lowered).1


/-- All actual source-call slots are framed by every successful statement
selector returning a value, with no caller load-classification certificate. -/
theorem stock_statement_source_calls_same {f : Clif.Function} {ctx : Ctx}
    (mapped : MappedCtxInv f ctx) (clean : Clean (sourceIdentityCtx ctx))
    {ii : Nat} {info : IInfo} {inst : Clif.Inst}
    (slot : ctx.insts[ii]? = some info) (clif : info.clif = some inst)
    {before after : State} {out : V} {trace : List RuleId}
    (run : Stock.runTerm ctx "lower" [.inst ii] before = .ok (some out,after,trace)) :
    SourceCallsSame ctx before after := by
  intro i call
  rcases call with ⟨info,fn,args,source,original⟩ | ⟨info,ref,callee,args,source,original⟩
  · exact stock_statement_preserves_direct_source_call mapped clean source original slot clif run
  · exact stock_statement_preserves_indirect_source_call mapped clean source original slot clif run
/-- Successful actual branch-root interpretation preserves EVERY original
source call bit; signatures and non-load formats are derived from the source. -/
theorem stock_branch_source_calls_same {f : Clif.Function} {ctx : Ctx}
    (mapped : MappedCtxInv f ctx) (clean : Clean (sourceIdentityCtx ctx))
    {ti : Nat} {targets : List Label} {before after : State} {out : Option V} {trace : List RuleId}
    (run : Stock.runTerm ctx "lower_branch" [.inst ti,.labels targets] before = .ok (out,after,trace)) :
    SourceCallsSame ctx before after := by
  intro i call
  exact protected_branch mapped clean run (source_call_not_atomic mapped call)
/-- Actual return/trap placeholders preserve every actual original source call
bit under the same original terminal-data hypotheses. -/
theorem stock_retTrap_source_calls_same {f : Clif.Function} {ctx : Ctx}
    (mapped : MappedCtxInv f ctx) (clean : Clean (sourceIdentityCtx ctx))
    {ti : Nat} {t : Clif.Terminator} {data : V} (retTrap : retOrTrap t = true)
    (dataRun : Backend.termData t = .ok data) (slot : ctx.insts[ti]? = some ⟨data,[],[],none⟩)
    {before after : State} {out : Option V} {trace : List RuleId}
    (run : Stock.runTerm ctx "lower" [.inst ti] before = .ok (out,after,trace)) :
    SourceCallsSame ctx before after := by
  intro i call
  exact protected_retTrap mapped clean retTrap dataRun slot run (source_call_not_atomic mapped call)
end Backend.Stock.Proof.CallSinkControlDraft
