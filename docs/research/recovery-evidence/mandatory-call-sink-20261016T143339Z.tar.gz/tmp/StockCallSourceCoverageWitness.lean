import StockCallSourceCoverage
import StockCallEmissionWitness
import StockIndirectCallEmissionWitness
import StockGotCallWitness
namespace Backend.Stock.Proof.CallSourceCoverageWitnessDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open CallSourceCoverageDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
attribute [local irreducible] Stock.lower Stock.runTerm Isle.Aarch64.program

/-- The actual direct ordinary/sret source position, entry reachability and
complete checked/physical pipeline inhabit the new source-to-record coverage
contracts. All retained/emission evidence is obtained from the new roots. -/
theorem stock_complete_direct_reachable_call_witness (implicit : Bool) :
    ∃ (out : CallStaticFixture.Output) (event : BlockScanEvent) (record : ScanRecord) (info : IInfo) (step : Step),
      LowerScope (CallStaticFixture.function false implicit) ∧ Dominated (CallStaticFixture.function false implicit) ∧ ArityOk (CallStaticFixture.function false implicit) ∧ AbiSigsOk (CallStaticFixture.function false implicit) ∧
      Stock.lower (CallStaticFixture.function false implicit) = .ok out.result ∧
      prepareAt out.result.code out.result.edgeArgs = .ok out.prepared ∧
      out.rf = spillAllocAt out.prepared.code out.prepared.edges ∧
      checkAllocAt out.prepared.code out.prepared.edges out.rf = .ok () ∧
      lowerRFunc out.prepared.code out.rf = .ok out.af ∧
      stockSourceTable (CallStaticFixture.function false implicit) = .ok #[#[]] ∧ Prep.Reach #[#[]] 0 ∧
      SigStackOk (CallStaticFixture.signature false implicit) out.result.code.outgoing ∧
      event ∈ out.result.blockScans.toList ∧ event.block = 0 ∧ record ∈ event.output.records ∧
      record.inst = blockStart (CallStaticFixture.function false implicit) 0 + 0 ∧ event.ctx.insts[record.inst]? = some info ∧
      info.clif = some (.call 0 (CallStaticFixture.arguments false implicit)) ∧ record.output.step = some step ∧ step.decision = .emitted := by
  obtain ⟨out,oldEvent,oldRecord,oldInfo,oldStep,scope,dom,arity,abi,run,prepared,fallback,checked,physical,
    facts,oldEvents,oldRecords,oldSlot,oldClif,oldRecorded,oldEmitted,rest⟩ := CallEmissionWitnessDraft.stock_complete_direct_call_emission_witness implicit
  let f := CallStaticFixture.function false implicit
  let b := f.blocks[0]!
  have block : f.blocks[0]? = some b := by cases implicit <;> rfl
  have statement : b.body[0]? = some (CallStaticFixture.callStatement false implicit) := by cases implicit <;> rfl
  have computed : stockSourceTable f = .ok #[#[]] := by cases implicit <;> cbv
  have kind : (CallStaticFixture.callStatement false implicit).inst = (.call 0 (CallStaticFixture.arguments false implicit)) := rfl
  have actualKind : (∃ fn args,(CallStaticFixture.callStatement false implicit).inst = .call fn args) ∨
      (∃ ref callee args,(CallStaticFixture.callStatement false implicit).inst = .callIndirect ref callee args) :=
    .inl ⟨0,_,kind⟩
  obtain ⟨event,record,info,step,events,current,records,index,slot,clif,recorded,emitted⟩ :=
    stock_lower_reachable_source_call_emitted run scope computed (.entry : Prep.Reach #[#[]] 0) block statement actualKind
  let ext : Clif.ExtFunc := {name := CallStaticFixture.calleeName,sig := CallStaticFixture.signature false implicit,colocated := true}
  have external : f.extern? 0 = some ext := rfl
  have stack := stock_lower_reachable_direct_call_stack run scope dom.1 abi computed
    (.entry : Prep.Reach #[#[]] 0) block statement kind external
  exact ⟨out,event,record,info,step,scope,dom,arity,abi,run,prepared,fallback,checked,physical,
    computed,.entry,stack,events,current,records,index,slot,clif,recorded,emitted⟩

/-- The actual indirect ordinary/sret source position, entry reachability and
complete checked/physical pipeline inhabit the new source-to-record coverage
contracts. All retained/emission evidence is obtained from the new roots. -/
theorem stock_complete_indirect_reachable_call_witness (implicit : Bool) :
    ∃ (out : CallStaticFixture.Output) (event : BlockScanEvent) (record : ScanRecord) (info : IInfo) (step : Step),
      LowerScope (CallStaticFixture.function true implicit) ∧ Dominated (CallStaticFixture.function true implicit) ∧ ArityOk (CallStaticFixture.function true implicit) ∧ AbiSigsOk (CallStaticFixture.function true implicit) ∧
      Stock.lower (CallStaticFixture.function true implicit) = .ok out.result ∧
      prepareAt out.result.code out.result.edgeArgs = .ok out.prepared ∧
      out.rf = spillAllocAt out.prepared.code out.prepared.edges ∧
      checkAllocAt out.prepared.code out.prepared.edges out.rf = .ok () ∧
      lowerRFunc out.prepared.code out.rf = .ok out.af ∧
      stockSourceTable (CallStaticFixture.function true implicit) = .ok #[#[]] ∧ Prep.Reach #[#[]] 0 ∧
      event ∈ out.result.blockScans.toList ∧ event.block = 0 ∧ record ∈ event.output.records ∧
      record.inst = blockStart (CallStaticFixture.function true implicit) 0 + 1 ∧ event.ctx.insts[record.inst]? = some info ∧
      info.clif = some (.callIndirect 0 80 (CallStaticFixture.arguments true implicit)) ∧ record.output.step = some step ∧ step.decision = .emitted := by
  obtain ⟨out,oldEvent,oldRecord,oldInfo,oldStep,scope,dom,arity,abi,run,prepared,fallback,checked,physical,
    facts,oldEvents,oldRecords,oldSlot,oldClif,oldRecorded,oldEmitted,rest⟩ := IndirectCallEmissionWitnessDraft.stock_complete_indirect_call_emission_witness implicit
  let f := CallStaticFixture.function true implicit
  let b := f.blocks[0]!
  have block : f.blocks[0]? = some b := by cases implicit <;> rfl
  have statement : b.body[1]? = some (CallStaticFixture.callStatement true implicit) := by cases implicit <;> rfl
  have computed : stockSourceTable f = .ok #[#[]] := by cases implicit <;> cbv
  have kind : (CallStaticFixture.callStatement true implicit).inst = (.callIndirect 0 80 (CallStaticFixture.arguments true implicit)) := rfl
  have actualKind : (∃ fn args,(CallStaticFixture.callStatement true implicit).inst = .call fn args) ∨
      (∃ ref callee args,(CallStaticFixture.callStatement true implicit).inst = .callIndirect ref callee args) :=
    .inr ⟨0,80,_,kind⟩
  obtain ⟨event,record,info,step,events,current,records,index,slot,clif,recorded,emitted⟩ :=
    stock_lower_reachable_source_call_emitted run scope computed (.entry : Prep.Reach #[#[]] 0) block statement actualKind
  exact ⟨out,event,record,info,step,scope,dom,arity,abi,run,prepared,fallback,checked,physical,
    computed,.entry,events,current,records,index,slot,clif,recorded,emitted⟩

/-- The actual got ordinary/sret source position, entry reachability and
complete checked/physical pipeline inhabit the new source-to-record coverage
contracts. All retained/emission evidence is obtained from the new roots. -/
theorem stock_complete_got_reachable_call_witness (implicit : Bool) :
    ∃ (out : GotCallFixture.Output) (event : BlockScanEvent) (record : ScanRecord) (info : IInfo) (step : Step),
      LowerScope (GotCallFixture.function implicit) ∧ Dominated (GotCallFixture.function implicit) ∧ ArityOk (GotCallFixture.function implicit) ∧ AbiSigsOk (GotCallFixture.function implicit) ∧
      Stock.lower (GotCallFixture.function implicit) = .ok out.result ∧
      prepareAt out.result.code out.result.edgeArgs = .ok out.prepared ∧
      out.rf = spillAllocAt out.prepared.code out.prepared.edges ∧
      checkAllocAt out.prepared.code out.prepared.edges out.rf = .ok () ∧
      lowerRFunc out.prepared.code out.rf = .ok out.af ∧
      stockSourceTable (GotCallFixture.function implicit) = .ok #[#[]] ∧ Prep.Reach #[#[]] 0 ∧
      SigStackOk (CallStaticFixture.signature false implicit) out.result.code.outgoing ∧
      event ∈ out.result.blockScans.toList ∧ event.block = 0 ∧ record ∈ event.output.records ∧
      record.inst = blockStart (GotCallFixture.function implicit) 0 + 0 ∧ event.ctx.insts[record.inst]? = some info ∧
      info.clif = some (.call 0 (CallStaticFixture.arguments false implicit)) ∧ record.output.step = some step ∧ step.decision = .emitted := by
  obtain ⟨out,oldEvent,oldRecord,oldInfo,oldStep,scope,dom,arity,abi,run,prepared,fallback,checked,physical,
    facts,oldEvents,oldRecords,oldSlot,oldClif,oldRecorded,oldEmitted,rest⟩ := GotCallWitnessDraft.stock_complete_got_call_emission_witness implicit
  let f := GotCallFixture.function implicit
  let b := f.blocks[0]!
  have block : f.blocks[0]? = some b := by cases implicit <;> rfl
  have statement : b.body[0]? = some (CallStaticFixture.callStatement false implicit) := by cases implicit <;> rfl
  have computed : stockSourceTable f = .ok #[#[]] := by cases implicit <;> cbv
  have kind : (CallStaticFixture.callStatement false implicit).inst = (.call 0 (CallStaticFixture.arguments false implicit)) := rfl
  have actualKind : (∃ fn args,(CallStaticFixture.callStatement false implicit).inst = .call fn args) ∨
      (∃ ref callee args,(CallStaticFixture.callStatement false implicit).inst = .callIndirect ref callee args) :=
    .inl ⟨0,_,kind⟩
  obtain ⟨event,record,info,step,events,current,records,index,slot,clif,recorded,emitted⟩ :=
    stock_lower_reachable_source_call_emitted run scope computed (.entry : Prep.Reach #[#[]] 0) block statement actualKind
  let ext : Clif.ExtFunc := {name := CallStaticFixture.calleeName,sig := CallStaticFixture.signature false implicit,colocated := false}
  have external : f.extern? 0 = some ext := rfl
  have stack := stock_lower_reachable_direct_call_stack run scope dom.1 abi computed
    (.entry : Prep.Reach #[#[]] 0) block statement kind external
  exact ⟨out,event,record,info,step,scope,dom,arity,abi,run,prepared,fallback,checked,physical,
    computed,.entry,stack,events,current,records,index,slot,clif,recorded,emitted⟩
end Backend.Stock.Proof.CallSourceCoverageWitnessDraft
