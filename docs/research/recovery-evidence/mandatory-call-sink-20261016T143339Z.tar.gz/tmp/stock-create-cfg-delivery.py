from pathlib import Path
import subprocess as sp,json,os,re,datetime
root=Path('/home/lee/clifv/.worktrees/driver-proof-resume');os.chdir(root)
def run(*a,env=None,input=None):return sp.check_output(a,env=env,input=input)
core=json.loads(Path('/tmp/stock-delivery-core-paths.json').read_text());first=json.loads(Path('/tmp/stock-delivery-first-paths.json').read_text())
base='44abfd79cbe4cda5ed868054b7f9e166152cf709';snapshot=first['snapshot'];branch='agent/stock-cfg-preparation-proof-pr';paths=sorted(set(first['paths'])-set(core['paths']))
assert len(paths)==83
assert sp.run(['git','show-ref','--verify','--quiet','refs/heads/'+branch]).returncode==1
head=run('git','rev-parse','HEAD');index=run('git','diff','--cached','--binary')
def tree(ref):
 result={}
 for rec in run('git','ls-tree','-r','-z',ref).split(b'\0'):
  if not rec:continue
  meta,name=rec.split(b'\t',1);mode,kind,blob=meta.decode().split();result[name.decode()]=(mode,blob)
 return result
old=tree(base);snap=tree(snapshot);proposed=dict(old);rows=[]
for p in paths:
 mode,blob=snap[p];assert run('git','hash-object',p).decode().strip()==blob,p
 proposed[p]=(mode,blob);rows.append(mode+' '+blob+'\t'+p+'\n')
# Validate each changed module's complete FV/FVTest source import closure in the proposed tree.
visited=set();missing=set();local_differences=set()
def visit(path):
 if path in visited:return
 visited.add(path)
 if path not in proposed:missing.add(path);return
 blob=proposed[path][1];source=run('git','cat-file','blob',blob).decode()
 if Path(path).exists() and run('git','hash-object',path).decode().strip()!=blob:local_differences.add(path)
 for line in re.findall(r'^import\s+([^\n]+)',source,re.M):
  for m in line.split():
   if m.startswith(('FV.','FVTest.')):visit(m.replace('.','/')+'.lean')
for p in paths:
 if p.endswith('.lean'):visit(p)
assert not missing,sorted(missing)
# Local differences are reported, not presented as exact local validation of this proposed tree.
receipt=Path('docs/research/stock-cfg-preparation-delivery.md')
receipt.write_text('''# Stock CFG and preparation proof delivery

This draft depends on [#246](https://github.com/eth-act/clifv/pull/246). It proves correspondence between the actual Stock output and its successor graph, derives raw and checked preparation success under the original source scope, transports indexed argument/parameter shapes, and connects actual spill-copy execution. The supporting source-order, entry, branch, return, TryCall, critical-edge and complete pipeline witnesses are included.

The principal roots are `stock_lower_cfg`, `stock_prepare_total`, `stock_prepare_copy_metadata` and `stock_spillArgMovesAt_runs`. Graph and copy metadata are derived from successful Stock lowering and the existing source conditions. Existing theorem variants and production defaults are preserved. Whole-driver source simulation and completeness, allocation/checker completeness, and compiler/checker/linker/generated-proof production cutover remain required by #140.

This is one dependency-closed proof unit: 83 existing Lean modules from remotely backed-up recovery snapshot b74ffb957ef0026dae0771206058705d999fdafd, stacked on #246 at44abfd79cbe4cda5ed868054b7f9e166152cf709. No worktree or build cache was created. All other unpublished work remains in the canonical recovery workspace and remote backups.

Historical backlog-tree full gates passed, but those results do not establish exact-current-PR gates after published-upstream changes. The canonical rebuild is running with source and validation scripts frozen. Exact proposed-tree validation, transitive trust review, required full local gates and CI remain pending. Keep draft until those gates pass; squash merge only.
''')
p=str(receipt);blob=run('git','hash-object','-w','--stdin',input=receipt.read_bytes()).decode().strip();rows.append('100644 '+blob+'\t'+p+'\n')
idx=Path('/tmp/stock-cfg-delivery-index-'+str(os.getpid()));env=dict(os.environ,GIT_INDEX_FILE=str(idx))
try:
 run('git','read-tree',base,env=env);run('git','update-index','--index-info',env=env,input=''.join(rows).encode());resultTree=run('git','write-tree',env=env).decode().strip()
 commit=run('git','commit-tree',resultTree,'-p',base,input=b'Stock: derive CFG correspondence, preparation totality and indexed copy metadata\n').decode().strip();run('git','update-ref','refs/heads/'+branch,commit,'0'*40)
 assert run('git','rev-parse','HEAD')==head and run('git','diff','--cached','--binary')==index
 assert set(run('git','diff','--name-only',base,commit).decode().splitlines())==set(paths+[p])
 r={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'branch':branch,'commit':commit,'tree':resultTree,'base':base,'base_pr':246,'snapshot':snapshot,'paths':paths,'new_lean_modules':83,'import_closure_modules':len(visited),'import_closure_verified':True,'proposed_dependency_paths_different_from_active_tree':sorted(local_differences),'active_head_and_index_unchanged':True,'new_worktree_or_cache':False,'exact_current_PR_fullgates':'pending; draft only','goal':'original full #140 active/incomplete; production legacy'}
 Path('docs/research/stock-cfg-preparation-delivery.json').write_text(json.dumps(r,indent=2)+'\n');Path('/tmp/stock-cfg-delivery-result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='paths'}))
finally:idx.unlink(missing_ok=True)
