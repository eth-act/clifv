import re,json,hashlib
from pathlib import Path
parse=lambda s:{m.group(1):sorted(x.strip() for x in m.group(2).split(',') if x.strip()) for m in re.finditer(r"'([^']+)' depends on axioms:\s*\[([^]]*)\]",s)}|{n:[] for n in re.findall(r"'([^']+)' does not depend on any axioms",s)}
old=parse(Path('/tmp/stock-prepared-shared-axioms.log').read_text());log=Path('/tmp/stock-final-record-axioms.log').read_text();new=parse(log)
assert len(old)==1969 and len(new)==1990,(len(old),len(new))
assert not re.search(r'(^|\n).*error:',log)
assert all(new.get(n)==v for n,v in old.items())
p=json.loads(Path('docs/research/stock-final-record-checkpoint.json').read_text());roots=p['pending_parent_batch_roots']+p['new_public_roots'];std={'Classical.choice','Quot.sound','propext'}
assert set(new)-set(old)==set(roots);assert all(set(new[n])<=std for n in roots)
mcps={}
for label in ['stock-emission-static','stock-bound-record','stock-final-record']:
 rs=json.loads(Path('docs/research/'+label+'-checkpoint.json').read_text())['new_public_roots']
 mpath=Path('docs/research/'+label+'-mcp.json');m=json.loads(mpath.read_text());assert m['success'] and not m['timed_out'];assert parse('\n'.join(d['message'] for d in m['diagnostics']))=={n:new[n] for n in rs};mcps[str(mpath)]={'sha256':hashlib.sha256(mpath.read_bytes()).hexdigest(),'roots':len(rs),'one_existing_bundled_run':True,'matches_normal':True}
scans={f:[(i,l) for i,l in enumerate(Path(f).read_text().splitlines(),1) if re.search(r'\b(sorry|admit|axiom|trace_state)\b',l)] for f in p['new_or_appended_source_paths']};assert not any(scans.values()),scans
r={'normal_audit':{'path':'/tmp/stock-final-record-axioms.log','sha256':hashlib.sha256(log.encode()).hexdigest(),'roots':len(new),'all1969_previous_sets_including_7_compiler_sets_preserved':True,'new_axioms':{n:new[n] for n in roots}},'mcp_audits':mcps,'source_scan_warnings':scans}
Path('/tmp/stock-final-record-audit-receipt.json').write_text(json.dumps(r,indent=2)+'\n')
print('PASS',len(new),'roots;',len(old),'prior sets unchanged;21 new standard-only; three existing bundled MCP receipts agree;source scans clear')
