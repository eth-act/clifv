from pathlib import Path
import json,subprocess,os,datetime
root=Path('/home/lee/clifv/.worktrees/driver-proof-resume')
data=json.loads(Path('/tmp/stock-static-affected.json').read_text());affected=set(data['affected']);done=set();order=[]
def visit(m):
 if m in done:return
 done.add(m)
 for d in data['imports'][m]:
  if d in affected:visit(d)
 order.append(m)
for m in sorted(affected):visit(m)
env=dict(os.environ,OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',FV_MEMCAP='20G')
assert subprocess.check_output(['nproc'],env=env,text=True).strip()=='2'
progress=Path('/tmp/stock-static-serial-progress.json');logs={}
if progress.exists():
 prior=json.loads(progress.read_text())
 if prior.get('state')=='failed':
  for m in prior['completed']:
   existing=Path('/tmp/stock-static-rebuild-'+m.rsplit('.',1)[1]+'.log')
   assert 'Build completed successfully' in existing.read_text(),m
   logs[m]=str(existing)
print('Resuming after',len(logs),'verified completed modules',flush=True)
for i,m in enumerate(order):
 if m in logs:continue
 env['FV_MEMCAP']='32G' if m=='FV.Backend.Proof.StockCmpWithFlags' else '20G'
 started=datetime.datetime.now(datetime.timezone.utc).isoformat()
 print(started,i+1,len(order),m,flush=True)
 progress.write_text(json.dumps({'state':'running','pid':os.getpid(),'started_utc':started,'current':m,'index':i+1,'total':len(order),'completed':list(logs),'logs':logs},indent=2)+'\n')
 log=Path('/tmp/stock-static-rebuild-'+m.rsplit('.',1)[1]+'.log')
 with log.open('w') as out:
  result=subprocess.run(['scripts/memcap.sh','/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin/lake','build',m],cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT)
 if result.returncode or 'Build completed successfully' not in log.read_text():
  progress.write_text(json.dumps({'state':'failed','pid':os.getpid(),'failed_module':m,'index':i+1,'total':len(order),'returncode':result.returncode,'log':str(log),'completed':list(logs)},indent=2)+'\n')
  raise SystemExit('Build failed: '+m+'; '+str(log))
 logs[m]=str(log)
report={'success':True,'sequential_modules':order,'heavy_kernels_concurrent':1,'default_memcap_GiB':20,'isolated_cap_overrides':{'FV.Backend.Proof.StockCmpWithFlags':32},'effective_nproc':2,'logs':logs}
Path('/tmp/stock-static-serial-rebuild-receipt.json').write_text(json.dumps(report,indent=2)+'\n')
progress.write_text(json.dumps({'state':'complete','completed_modules':len(order),'pid':os.getpid()},indent=2)+'\n')
print('PASS',len(order),'serial affected modules',flush=True)
