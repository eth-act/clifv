import FV.Backend.Proof.StockSourceCallWitness
import FV.Backend.Proof.StockEdgeValuesWitness
#print axioms Backend.Stock.Proof.source_defined_setMany
#print axioms Backend.Stock.Proof.source_defined_continueWith
#print axioms Backend.Stock.Proof.source_defined_returnValues
#print axioms Backend.Stock.Proof.SourceCallWitness.stock_source_call_result_witness
#print axioms Backend.Stock.Proof.stock_lower_entry_alias_apart
#print axioms Backend.Stock.Proof.stock_lower_parameter_resolves
#print axioms Backend.Stock.Proof.stock_lower_edge_values
#print axioms Backend.Stock.Proof.EdgeValuesWitness.stock_edge_values_alias_witness
