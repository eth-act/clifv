import FV.Backend.Proof.StockEdgeValues
namespace Backend.Stock.Proof.EdgeDebug
open Backend.Stock Backend.Stock.Proof Backend.Proof Backend.Proof.Driver Backend.Proof.Driver.Fix
def reduce : Clif.Stmt := ⟨[17],.ireduce .i8 7⟩
def function : Clif.Function := {
  name := "stock_edge_values_alias"
  sig := {params := [⟨.i64,.none,.normal⟩],returns := [⟨.i8,.none,.normal⟩],callConv := some .systemV}
  blocks := [{id := 0,params := [(7,.i64)],body := [reduce],term := .jump ⟨1,[17]⟩},
    {id := 1,params := [(31,.i8)],term := .ret [31]}] }
def original : Ctx × Array (Nat × Nat) × LState :=
  (Backend.buildCtx function).toOption.getD (sinkCtx,#[],default)
theorem original_build : Backend.buildCtx function = .ok original := rfl
def initial (word : BitVec 64) : Clif.Frame := {
  func := function,regs := Clif.Regs.empty.set 7 ⟨.i64,word⟩,slots := [],body := [reduce],term := .jump ⟨1,[17]⟩ }
def before (word : BitVec 64) : Clif.Frame := {
  initial word with regs := (initial word).regs.set 17 ⟨.i8,word.setWidth 8⟩,body := [] }
def after (word : BitVec 64) : Clif.Frame := {
  before word with regs := (before word).regs.set 31 ⟨.i8,word.setWidth 8⟩,term := .ret [31] }
def machine (word : BitVec 64) (key : Nat) : CV :=
  if key = 192 then BitVec.ofNat 128 (2^100 + word.toNat) else 0
def needed (result : Result) (x : Nat) : Prop :=
  (x = 7 ∨ x = 17 ∨ x = 31) ∧ Demanded result.final x ∧ x ∈ availOf function (availIn function result.ctx) 1 0
instance neededDecidable (result : Result) (x : Nat) : Decidable (needed result x) := by
  unfold needed Demanded
  infer_instance

#eval match Stock.lower function with
| .error e => "ERROR " ++ e
| .ok r => reprStr (r.ctx.valueReg? 7,r.ctx.valueReg? 17,r.ctx.valueReg? 31,
  (r.final.alias[192]?).join,(r.final.alias[193]?).join,(r.final.alias[194]?).join,
  aliasNum r.final.alias 192,aliasNum r.final.alias 193,aliasNum r.final.alias 194,
  r.final.demand[7]!,r.final.demand[17]!,r.final.demand[31]!,
  (availIn function r.ctx).getD 1 [],availOf function (availIn function r.ctx) 1 0,
  (r.code.blocks[0]!).branchArgs,(r.code.blocks[1]!).params)
#print neededDecidable
end Backend.Stock.Proof.EdgeDebug
