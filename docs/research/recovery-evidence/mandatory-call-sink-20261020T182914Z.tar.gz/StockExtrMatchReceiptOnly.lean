namespace Backend.Stock.Proof.LogicalExtr
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
attribute [local irreducible] Isle.Aarch64.program

private theorem matched_width {p : Program} (hp : Data p) {ctx : Ctx} (mirrored : Bool)
    {i w n : Nat} {info : IInfo} (source : ctx.insts[i]? = some info)
    (type : info.resTys.head? = some (.int w))
    {st : State} {tr : Array RuleId} {env : Isle.Interp.Env V} {middle : State × Array RuleId}
    (matched : (matchRule p (Stock.sem ctx) {} (n+20) (extrRule mirrored) [.inst i]).run (st,tr) =
      .ok (some env,middle)) : w = 32 ∨ w = 64 := by
  obtain ⟨q,shape⟩ : ∃ q,(extrRule mirrored).args = [.term 18 209
      [.term 14 120 [.bind 14 0 (.wildcard 14)],q]] := by
    cases mirrored <;> exact ⟨_,rfl⟩
  obtain ⟨initial,args,_⟩ := matchRule_some_inv matched
  rw [stock_matchArgs,shape] at args
  obtain ⟨e1,root,_⟩ := matchArgs_cons_inv args
  obtain ⟨fields,extracted,patterns⟩ := matchPat_extract_inv hp.t209 term_209_kind rfl root
  have expected := ext_inst_data_value ctx st.base source
  rw [type,Option.getD_some] at expected
  rw [Backend.Proof.sem_extract,expected] at extracted
  cases extracted
  obtain ⟨e2,typeMatch,_⟩ := matchArgs_cons_inv patterns
  obtain ⟨typeFields,typeExtract,_⟩ := matchPat_extract_inv hp.t120 term_120_kind rfl typeMatch
  rw [Backend.Proof.sem_extract,ext_ty_32_or_64] at typeExtract
  split at typeExtract
  · assumption
  · cases typeExtract

/-- Original source facts recovered from a lookthrough match, retained with
all four actual instruction/definition links. -/
structure SourceWord (ctx : Ctx) (value : Nat) (left : Bool) where
  inst : Nat
  word : Nat
  count : Nat
  literalInst : Nat
  info : IInfo
  literal : IInfo
  ty : Clif.Ty
  literalTy : Clif.Ty
  bits : BitVec literalTy.width
  defined : ctx.defInst? value = some inst
  found : ctx.insts[inst]? = some info
  original : info.clif = some (.binary (if left then .ishl else .ushr) ty word count)
  countDefined : ctx.defInst? count = some literalInst
  countFound : ctx.insts[literalInst]? = some literal
  countOriginal : literal.clif = some (.iconst literalTy bits)

def SourceWord.amount {ctx : Ctx} {value : Nat} {left : Bool} (word : SourceWord ctx value left) : Int :=
  u64 (imm64OfIconst word.literalTy word.bits)

private theorem original_word {ctx : Ctx} {value : Nat} {left : Bool}
    (source : WordSource ctx value left) : Nonempty (SourceWord ctx value left) := by
  obtain ⟨j,x,c,k,info,literal,ty,literalTy,bits,defined,found,original,cdef,cfound,coriginal⟩ := source
  exact ⟨⟨j,x,c,k,info,literal,ty,literalTy,bits,defined,found,original,cdef,cfound,coriginal⟩⟩

section Data
attribute [local semireducible] Isle.Aarch64.program
private theorem source_data {f : Clif.Function} {ctx : Ctx} (inv : MappedCtxInv f ctx)
    {i a b : Nat} {ty : Clif.Ty} {info : IInfo} (source : ctx.insts[i]? = some info)
    (clif : info.clif = some (.binary .bor ty a b)) :
    info.data = .data 152 2 [.data 151 98 [],.values [a,b]] ∧
      info.resTys.head? = some (.int ty.width) := by
  have accepted := inv.instE i info _ source clif
  have supported : eTy ty = true := by
    simpa [Compile.instE,Compile.binaryE,Compile.tyE,eTy] using accepted
  have raw := inv.data i info _ source clif
  obtain ⟨types,result,typed,_⟩ := inv.resTys i info _ source clif
  simp only [Clif.Inst.resultTypes] at result
  cases result
  refine ⟨?_,by rw [typed]; simp [ofClif_int_width (isInt_of_eTy supported)]⟩
  have expected : instData f (.binary .bor ty a b) = .ok (.data 152 2 [.data 151 98 [],.values [a,b]]) := by
    simp only [instData,binaryOpcode,supported,ite_true]
    rfl
  exact Except.ok.inj (raw.symm.trans expected)

private theorem source_word_data {f : Clif.Function} {ctx : Ctx} (inv : MappedCtxInv f ctx)
    {value : Nat} {left : Bool} (word : SourceWord ctx value left) :
    word.info.data = .data 152 2 [.data 151 (if left then 103 else 104) [],.values [word.word,word.count]] ∧
      word.literal.data = .data 152 35 [.data 151 57 [],.int (imm64OfIconst word.literalTy word.bits)] := by
  have accepted := inv.instE word.inst word.info _ word.found word.original
  have supported : eTy word.ty = true := by
    cases left <;> simpa [Compile.instE,Compile.binaryE,Compile.tyE,eTy] using accepted
  have raw := inv.data word.inst word.info _ word.found word.original
  have expected : instData f (.binary (if left then .ishl else .ushr) word.ty word.word word.count) =
      .ok (.data 152 2 [.data 151 (if left then 103 else 104) [],.values [word.word,word.count]]) := by
    cases left <;> simp only [instData,binaryOpcode,supported,ite_true] <;> rfl
  have literalAccepted := inv.instE word.literalInst word.literal _ word.countFound word.countOriginal
  have literalSupported : eTy word.literalTy = true := by
    simpa [Compile.instE,Compile.tyE,eTy] using literalAccepted
  have literalRaw := inv.data word.literalInst word.literal _ word.countFound word.countOriginal
  have literalExpected : instData f (.iconst word.literalTy word.bits) =
      .ok (.data 152 35 [.data 151 57 [],.int (imm64OfIconst word.literalTy word.bits)]) := by
    simp only [instData,literalSupported,ite_true]
    rfl
  exact ⟨Except.ok.inj (raw.symm.trans expected),Except.ok.inj (literalRaw.symm.trans literalExpected)⟩
end Data
end Backend.Stock.Proof.LogicalExtr
