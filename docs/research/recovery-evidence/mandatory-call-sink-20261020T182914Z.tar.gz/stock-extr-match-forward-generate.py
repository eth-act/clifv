from pathlib import Path
root=Path('/home/lee/clifv/.worktrees/stock-mixed-production')
s=(root/'FV/Backend/Proof/IselTermsALUAExtr.lean').read_text()
start=s.index('theorem match_1501 ');end=s.index('theorem rhs_1501')
# Keep the four success/failure match theorems, stopping before RHS helpers.
print(s[end-180:end])
parts=[]
for name,nextname in [('match_1501','match_1501_none'),('match_1501_none','match_1507'),('match_1507','match_1507_none')]:
 a=s.index('theorem '+name+' ');b=s.index('theorem '+nextname+' ',a);block=s[a:b];block=block[:block.rfind('set_option')] if 'set_option' in block else block;parts.append(block.rstrip())
a=s.index('theorem match_1507_none ');b=s.index('theorem ',a+8);block=s[a:b];block=block[:block.rfind('set_option')] if 'set_option' in block else block;parts.append(block.rstrip())
header='''import FV.Backend.Proof.StockLogicalForms
import FV.Backend.Proof.IselTermsALUAExtr
namespace Backend.Stock.Proof.LogicalExtr
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
attribute [local irreducible] Isle.Aarch64.program
private theorem sem_extract (ctx : Ctx) (t : Term) (v : V) (st : State) :
    (Stock.sem ctx).extract t v st = Backend.externExtract ctx t v st.base := rfl
private theorem sem_unData (ctx : Ctx) (t : Nat) (v : V) :
    (Stock.sem ctx).unData t v = (Backend.sem ctx).unData t v := rfl
private theorem sem_eq (ctx : Ctx) (a b : V) : (Stock.sem ctx).eq a b = (a == b) := rfl
private theorem sem_prim (ctx : Ctx) (name : String) :
    (Stock.sem ctx).prim 14 name = (CTy.ofName? name).map V.ty := rfl
private theorem sem_ctor (ctx : Ctx) (t : Term) (vs : List V) (st : State) :
    (Stock.sem ctx).ctor t vs st = Stock.externCtor ctx t vs st := rfl
private theorem pure_ctor (ctx : Ctx) (t : Term) (args : List V) (st : State) (v : V)
    (unrevised : t.id ∉ revisedCtors)
    (base : Backend.externCtor ctx t args st.base = .ok (v,st.base)) :
    Stock.externCtor ctx t args st = .ok (v,st) := by
  rw [stock_ctor_baseOnly ctx t args st unrevised,base]
  rfl
private theorem stock_u8_into_u64 (ctx : Ctx) (st : State) (a : Int) :
    Stock.externCtor ctx T.u8_into_u64 [.int a] st = .ok (.int a,st) :=
  pure_ctor ctx _ _ st _ (by decide) (ctor_u8_into_u64 ctx st.base a)
private theorem stock_wrapping_add (ctx : Ctx) (st : State) (a b : Int) :
    Stock.externCtor ctx T.u64_wrapping_add [.int a,.int b] st = .ok (.int (u64 (a+b)),st) :=
  pure_ctor ctx _ _ st _ (by decide) (ctor_u64_wrapping_add ctx st.base a b)
private theorem stock_eq (ctx : Ctx) (st : State) (a b : Int) :
    Stock.externCtor ctx T.u64_eq [.int a,.int b] st = .ok (.bool (a == b),st) :=
  pure_ctor ctx _ _ st _ (by decide) (ctor_u64_eq ctx st.base a b)
private theorem stock_gt (ctx : Ctx) (st : State) (a b : Int) :
    Stock.externCtor ctx T.u64_gt [.int a,.int b] st = .ok (.bool (decide (a>b)),st) :=
  pure_ctor ctx _ _ st _ (by decide) (ctor_u64_gt ctx st.base a b)
private theorem stock_bits (ctx : Ctx) (st : State) (w : Nat) :
    Stock.externCtor ctx T.ty_bits [.ty (.int w)] st = .ok (.int w,st) :=
  pure_ctor ctx _ _ st _ (by decide) (ctor_ty_bits ctx st.base w)
variable {p : Program} (hp : Data p) (ctx : Ctx) {cfg : Config}
variable (st : State) (tr : Array RuleId) (n : Nat)
'''
out=[]
for block in parts:
 block=block.replace('theorem match_','private theorem stock_match_').replace('(sem ctx)','(Stock.sem ctx)')
 for name in ['ext_inst_data_value','ext_def_inst_some','ext_ty_32_or_64']:
  block=block.replace(name+' ctx st ',name+' ctx st.base ')
 block=block.replace('  have he := sem_eq_beq_fa ctx\n','')
 for old,new in [('ctor_u8_into_u64','stock_u8_into_u64'),('ctor_u64_wrapping_add','stock_wrapping_add'),('ctor_u64_eq','stock_eq'),('ctor_u64_gt','stock_gt'),('ctor_ty_bits','stock_bits')]:block=block.replace(old,new)
 block=block.replace('isel_eval [','isel_eval [sem_extract,sem_unData,sem_eq,sem_prim,sem_ctor,')
 out.append(block)
Path('/tmp/StockExtrMatchForward.lean').write_text(header+'\n\n'.join(out)+'\nend Backend.Stock.Proof.LogicalExtr\n')
