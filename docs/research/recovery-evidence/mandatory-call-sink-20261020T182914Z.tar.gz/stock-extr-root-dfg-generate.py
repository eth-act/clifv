from pathlib import Path
header='''
namespace E2E.StockLogicalExtrWitness
open Backend Backend.Proof Backend.Proof.Driver Backend.Stock.D0 Backend.Stock.Proof
open Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm
private def rootBuilt (config : Configuration) (mirrored : Bool) : Ctx × Array (Nat × Nat) × Stock.State :=
  (Stock.buildCtx (function config mirrored)).toOption.getD (sinkCtx,#[],sinkState)
private def sourceFrame (config : Configuration) (mirrored : Bool) (a b : CV) : Clif.Frame :=
  let ty := valueType config
  {func := function config mirrored
   regs := fun x => if x = 1 then some ⟨ty,a.setWidth ty.width⟩
     else if x = 8 then some ⟨ty,b.setWidth ty.width⟩
     else if x = 9 then some (.ofInt ty (ty.width-1 : Nat))
     else if x = 10 then some (.ofInt ty 1)
     else if x = 11 then some ⟨ty,a.setWidth ty.width <<< (ty.width-1)⟩
     else if x = 12 then some ⟨ty,b.setWidth ty.width >>> 1⟩ else none
   slots := []
   body := []
   term := .ret [13] }
/-- The real looked-through shifts and literals are source-available while
being absent from the machine register file in the fused EXTR witness. -/
private theorem sourceDFG (config : Configuration) (mirrored : Bool) (a b : CV) :
    DFGCons (rootBuilt config mirrored).1 (sourceFrame config mirrored a b) := by
  constructor
  · intro x j info cl v defined found original pure lookup
'''
# Uniform case split, each source result uses its actual source instruction index.
body=''
indent='    '
for i,x in enumerate([1,8,9,10,11,12]):
 body+=indent+f'by_cases h{x} : x = {x}\n'+indent+'· subst x\n'
 if x in [1,8]:
  body+=indent+f'  have absent : (rootBuilt config mirrored).1.defInst? {x} = none := by\n'+indent+'    cases config <;> cases mirrored <;> rfl\n'+indent+'  rw [absent] at defined\n'+indent+'  cases defined\n'
 else:
  body+=indent+'  cases config <;> cases mirrored\n'+indent+'  all_goals\n'+indent+f'    change some {x-9} = some j at defined\n'+indent+'    cases defined\n'+indent+'    obtain ⟨bound,equal⟩ := Array.getElem?_eq_some_iff.mp found\n'+indent+'    subst info\n'+indent+'    cases original\n'+indent+'    cases lookup\n'+indent+'    exact ⟨[_],fun cm => rfl,rfl⟩\n'
 body+=indent+'· '
 # Nest remaining cases, avoiding offside ambiguity by one deeper indentation.
 if x!=12:body+='\n';indent+='  '
body+='simp [sourceFrame,h1,h8,h9,h10,h11,h12] at lookup\n'
body+='''  · intro x t v typed lookup
    by_cases present : x = 1 ∨ x = 8 ∨ x = 9 ∨ x = 10 ∨ x = 11 ∨ x = 12
    · rcases present with rfl | rfl | rfl | rfl | rfl | rfl
      all_goals
        cases config <;> cases mirrored
        all_goals first
        | (change some (.int 32) = some t at typed; cases typed; cases lookup; rfl)
        | (change some (.int 64) = some t at typed; cases typed; cases lookup; rfl)
    · simp only [not_or] at present
      simp [sourceFrame,present.1,present.2.1,present.2.2.1,present.2.2.2.1,
        present.2.2.2.2.1,present.2.2.2.2.2] at lookup
end E2E.StockLogicalExtrWitness
'''
code=header+body
# Match standard Lean record offside formatting.
code=code.replace('{func := function config mirrored','{\n   func := function config mirrored')
Path('/tmp/StockExtrRootDFGOnly.lean').write_text(code)
s=Path('/tmp/StockExtrCanonicalWitnessCached.lean').read_text().split('#print axioms Backend.Stock.Proof.LogicalExtr.match_receipt')[0]+'\n'+code+'\n'
# Public wrapper for checking a private witness root in this one prototype.
s+='''namespace E2E.StockLogicalExtrWitness
theorem sourceDFG_test (config : Backend.Stock.D0.Configuration) (mirrored : Bool) (a b : Backend.Proof.CV) :
    Backend.Proof.DFGCons (rootBuilt config mirrored).1 (sourceFrame config mirrored a b) := sourceDFG config mirrored a b
end E2E.StockLogicalExtrWitness
#print axioms E2E.StockLogicalExtrWitness.sourceDFG_test
'''
Path('/tmp/StockExtrRootDFG.lean').write_text(s)
