import FV.Backend.Proof.StockRotateSemantics
import FV.Backend.Proof.IselFamALUAExtr
import FV.Backend.Proof.StockLogicalForms
import FV.Backend.Proof.IselTermsALUAExtr

namespace Backend.Stock.Proof.LogicalExtr
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000

private theorem fresh_reg {aliases : Array (Option Nat)} {d : Nat} (bounded : aliases.size ≤ d) :
    Backend.lowerFunction.resolve aliases (aliases.size+1) (.vreg d .int) = .vreg d .int := by
  rw [resolve_vreg]
  have fresh : aliasNum aliases d = d := by
    apply chaseF_none
    rw [Array.getElem?_eq_none bounded]
    rfl
  change Reg.vreg (aliasNum aliases d) .int = _
  rw [fresh]

/-- A two-input EXTR uses original values through final aliases and writes
only its fresh destination. The concatenated inputs need not be equal. -/
theorem extr_resolved {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem}
    (refines : Refines F isem) {ty : Clif.Ty} (width : ty.width = 32 ∨ ty.width = 64)
    {aliases : Array (Option Nat)} {ρ : Nat → CV} {d x y X : Nat} {sh : ShiftOpAndAmt}
    (bounded : aliases.size ≤ d) (sum : X + sh.amt = ty.width) (count : sh.amt < ty.width)
    {u v : BitVec ty.width} (heldX : VHolds ⟨ty,u⟩ (ρ (aliasNum aliases x)))
    (heldY : VHolds ⟨ty,v⟩ (ρ (aliasNum aliases y))) :
    ∃ ρ', PRun F isem
      [(MInst.aluRRRShift .extr (szOf ty.width) (.vreg d .int) (.vreg x .int)
        (.vreg y .int) sh).mapRegs (Backend.lowerFunction.resolve aliases (aliases.size+1))] ρ ρ' ∧
      VHolds ⟨ty,(u <<< X) ||| (v >>> sh.amt)⟩ (ρ' d) ∧ ∀ n,n ≠ d → ρ' n = ρ n := by
  have bits : (szOf ty.width).bits = ty.width := by
    rcases width with h | h <;> simp [szOf,h,OperandSize.bits]
  have fits : sh.amt < (szOf ty.width).bits := by rwa [bits]
  let r := resX (szOf ty.width)
    (((opnd (szOf ty.width) (ρ (aliasNum aliases x)) ++
       opnd (szOf ty.width) (ρ (aliasNum aliases y))) >>> sh.amt).setWidth (szOf ty.width).bits)
  refine ⟨upd ρ d r,?_,?_,?_⟩
  · simp only [MInst.mapRegs]
    rw [fresh_reg bounded,resolve_vreg,resolve_vreg]
    exact prun_rrr refines (operands_aluRRRShift _ _ _ _ _ _)
      (fun _ => ispec_extr fits) (prun_nil _)
  · rw [upd_same]
    exact extr_holds width heldX heldY sum
  · intro n different
    simp only [upd,different,ite_false]

/-- Both source widths have actual executable instances for arbitrary, distinct
machine words and caller state, with the destination separate from the inputs. -/
theorem extr_resolved_witness (ty : Clif.Ty) (supported : ty = .i32 ∨ ty = .i64) (a b : CV) :
    let ρ : Nat → CV := fun n => if n = 0 then a else if n = 1 then b else 0
    ∃ ρ', PRun (fun _ => True) ispec
      [(MInst.aluRRRShift .extr (szOf ty.width) (.vreg 2 .int) (.vreg 0 .int)
        (.vreg 1 .int) ⟨.lsr,1⟩).mapRegs (Backend.lowerFunction.resolve #[] 1)] ρ ρ' ∧
      VHolds ⟨ty,(a.setWidth ty.width <<< (ty.width-1)) ||| (b.setWidth ty.width >>> 1)⟩ (ρ' 2) ∧
      ∀ n,n ≠ 2 → ρ' n = ρ n := by
  dsimp only
  have width : ty.width = 32 ∨ ty.width = 64 := by rcases supported with rfl | rfl <;> simp [Clif.Ty.width]
  have sum : ty.width-1+1 = ty.width := by rcases supported with rfl | rfl <;> decide
  have count : 1 < ty.width := by rcases supported with rfl | rfl <;> decide
  have self : Refines (fun _ => True) ispec := fun _ _ _ _ w' _ h => ⟨w',h,SameWorld.refl _ _⟩
  exact extr_resolved self width (aliases := #[]) (d := 2) (x := 0) (y := 1)
    (X := ty.width-1) (sh := ⟨.lsr,1⟩) (by decide) sum count (by rfl) (by rfl)

end Backend.Stock.Proof.LogicalExtr

namespace Backend.Stock.Proof.LogicalExtr
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
attribute [local irreducible] Isle.Aarch64.program

private theorem sem_ctor (ctx : Ctx) (t : Term) (vs : List V) (st : State) :
    (Stock.sem ctx).ctor t vs st = Stock.externCtor ctx t vs st := rfl
private theorem sem_mkData (ctx : Ctx) (t k : Nat) (vs : List V) :
    (Stock.sem ctx).mkData t k vs = .data t k vs := rfl
private theorem extr_shift_32 (ctx : Ctx) (st : State) (amount : Nat) :
    Stock.externCtor ctx T.a64_extr_imm [.ty (.int 32),.op (.immShift amount)] st =
      .ok (.op (.shiftOpAndAmt ⟨.lsl,amount⟩),st) := by
  rw [stock_ctor_baseOnly ctx T.a64_extr_imm _ st (by decide)]
  rfl
private theorem extr_shift_64 (ctx : Ctx) (st : State) (amount : Nat) :
    Stock.externCtor ctx T.a64_extr_imm [.ty (.int 64),.op (.immShift amount)] st =
      .ok (.op (.shiftOpAndAmt ⟨.lsr,amount⟩),st) := by
  rw [stock_ctor_baseOnly ctx T.a64_extr_imm _ st (by decide)]
  rfl
private theorem immediate_shift (ctx : Ctx) (st : State) {amount : Int} (fits : amount < 64) :
    Stock.externCtor ctx T.imm_shift_from_u8 [.int amount] st =
      .ok (.op (.immShift amount.toNat),st) := by
  rw [stock_ctor_baseOnly ctx T.imm_shift_from_u8 _ st (by decide),
    ctor_imm_shift_from_u8 ctx st.base fits]
private theorem output_run {p : Program} (hp : Data p) (ctx : Ctx) (st : State)
    (tr : Array RuleId) (n : Nat) (r : Reg) :
    (applyTerm p (Stock.sem ctx) {} (n+10) 25 172 [.reg r]).run (st,tr) =
      .ok (some (.regsVec [[r]]),st,tr.push rule_prelude_lower_105.id) := by
  have value : ∀ q,Stock.externCtor ctx T.value_reg [.reg r] q = .ok (.regs [r],q) := by
    intro q; rw [stock_ctor_baseOnly ctx T.value_reg _ q (by decide)]; rfl
  have output : ∀ q,Stock.externCtor ctx T.output [.regs [r]] q = .ok (.regsVec [[r]],q) := by
    intro q; rw [stock_ctor_baseOnly ctx T.output _ q (by decide)]; rfl
  cases hp
  isel_eval [*,rule_prelude_lower_105,sem_ctor]

def shiftFor (w amount : Nat) : ShiftOpAndAmt :=
  if w ≤ 32 then ⟨.lsl,amount⟩ else ⟨.lsr,amount⟩

/-- The real two-register EXTR helper preserves all Stock scheduling fields. -/
theorem helper_run {p : Program} (hp : Data p) (ctx : Ctx) {w : Nat}
    (width : w = 32 ∨ w = 64) (st : State) (tr : Array RuleId) (n : Nat)
    (rx ry : Reg) (amount : Nat) :
    (applyTerm p (Stock.sem ctx) {} (n+30) 27 515
      [.ty (.int w),.reg rx,.reg ry,.op (.immShift amount)]).run (st,tr) =
      .ok (some (.reg (st.base.fresh .int).1),
        {st with base := (st.base.fresh .int).2.emit (.aluRRRShift .extr (szOf w) (st.base.fresh .int).1 rx ry (shiftFor w amount))},
        ((tr.push (if w ≤ 32 then rule_inst_1592.id else rule_inst_1593.id)).push rule_inst_2656.id).push
          rule_inst_3487.id) := by
  have small : w ≤ 64 := by rcases width with rfl | rfl <;> decide
  have inner := fun q trace fuel sh => LogicalForms.stock_logical_shift_helper hp ctx (cfg := {})
    rfl small (k := 15) (op := .extr) rfl q trace fuel rx ry sh
  have ctor32 := fun q => extr_shift_32 ctx q amount
  have ctor64 := fun q => extr_shift_64 ctx q amount
  cases hp
  rcases width with rfl | rfl
  all_goals simp only [shiftFor,szOf,Nat.reduceLeDiff,ite_true,ite_false] at *
  all_goals isel_eval [*,rule_inst_3487,sem_mkData,sem_ctor]
  all_goals rfl

def extrRule (mirrored : Bool) : Rule := if mirrored then rule_lower_1507 else rule_lower_1501

def extrEnv (mirrored : Bool) (w x : Nat) (X : Int) (y : Nat) (Y : Int) : Isle.Interp.Env V :=
  if mirrored then env5 (.ty (.int w)) (.value y) (.int Y) (.value x) (.int X)
  else env5 (.ty (.int w)) (.value x) (.int X) (.value y) (.int Y)

/-- Both original fused-OR RHSs request only the underlying source words,
retain complete Stock scheduling state, and emit the actual EXTR instruction. -/
theorem rhs_forward {p : Program} (hp : Data p) (ctx : Ctx) (mirrored : Bool)
    {w x y : Nat} {X Y : Int} {rx ry : Reg}
    (mappedX : ctx.valueReg? x = some rx) (mappedY : ctx.valueReg? y = some ry)
    (width : w = 32 ∨ w = 64) (fits : Y < 64)
    (st : State) (safeX : DemandAllowed ctx st x) (safeY : DemandAllowed ctx st y)
    (tr : Array RuleId) (n : Nat) :
    ∃ trace,(evalExpr p (Stock.sem ctx) {} (n+60) (extrRule mirrored).rhs
      (extrEnv mirrored w x X y Y)).run (st,tr) =
      .ok (some (.regsVec [[(st.base.fresh .int).1]]),
        {(st.mark x).mark y with base := (st.base.fresh .int).2.emit (.aluRRRShift .extr (szOf w) (st.base.fresh .int).1 rx ry (shiftFor w Y.toNat))},trace) := by
  have requestX := stock_put_in_reg ctx st x rx mappedX safeX
  have requestY := stock_put_in_reg ctx (st.mark x) y ry mappedY safeY
  have shift := fun q => immediate_shift ctx q fits
  have helper := fun q trace fuel => helper_run hp ctx width q trace fuel rx ry Y.toNat
  have output := fun q trace fuel r => output_run hp ctx q trace fuel r
  cases hp
  cases mirrored with
  | false =>
    refine Exists.intro ?trace0 ?proof0
    case proof0 =>
      simp only [extrRule,extrEnv,Bool.false_eq_true,ite_true,ite_false]
      isel_eval [*,rule_lower_1501,sem_ctor]
      rfl
  | true =>
    refine Exists.intro ?trace1 ?proof1
    case proof1 =>
      simp only [extrRule,extrEnv,Bool.false_eq_true,ite_true,ite_false]
      isel_eval [*,rule_lower_1507,sem_ctor]
      rfl

/-- Successful actual RHS execution supplies both guarded source requests;
no caller-provided register map or scheduling certificate is needed. -/
theorem rhs_requests {p : Program} (hp : Data p) (ctx : Ctx) (mirrored : Bool)
    {w x y n : Nat} {X Y : Int} {st next : State} {tr trace : Array RuleId} {out : V}
    (run : (evalExpr p (Stock.sem ctx) {} (n+60) (extrRule mirrored).rhs
      (extrEnv mirrored w x X y Y)).run (st,tr) = .ok (some out,next,trace)) :
    DemandAllowed ctx st x ∧ DemandAllowed ctx st y ∧
      (∃ rx,ctx.valueReg? x = some rx) ∧ ∃ ry,ctx.valueReg? y = some ry := by
  cases hp
  cases mirrored
  all_goals
    isel_inv [*,extrRule,extrEnv,rule_lower_1501,rule_lower_1507,sem_ctor,stock_put_in_reg_iff] at run
    all_goals simp only [stock_put_in_reg_iff,ExtResult.ok.injEq,Prod.mk.injEq] at *
    all_goals isel_destruct <;> subst_vars
  all_goals
    exact ⟨‹DemandAllowed ctx st x›,‹DemandAllowed ctx (st.mark x) y›,
      ⟨_,‹ctx.valueReg? x = some _›⟩,⟨_,‹ctx.valueReg? y = some _›⟩⟩

/-- Actual success determines the complete output and marking/emission state.
Root match guards will supply the width and immediate facts. -/
theorem rhs_observed {p : Program} (hp : Data p) (ctx : Ctx) (mirrored : Bool)
    {w x y n : Nat} {X Y : Int} (width : w = 32 ∨ w = 64) (fits : Y < 64)
    {st next : State} {tr trace : Array RuleId} {out : V}
    (run : (evalExpr p (Stock.sem ctx) {} (n+60) (extrRule mirrored).rhs
      (extrEnv mirrored w x X y Y)).run (st,tr) = .ok (some out,next,trace)) :
    DemandAllowed ctx st x ∧ DemandAllowed ctx st y ∧
      ∃ rx ry,ctx.valueReg? x = some rx ∧ ctx.valueReg? y = some ry ∧
        out = .regsVec [[(st.base.fresh .int).1]] ∧
        next = {(st.mark x).mark y with base := (st.base.fresh .int).2.emit (.aluRRRShift .extr
          (szOf w) (st.base.fresh .int).1 rx ry (shiftFor w Y.toNat))} := by
  obtain ⟨safeX,safeY,⟨rx,mappedX⟩,ry,mappedY⟩ := rhs_requests hp ctx mirrored run
  obtain ⟨actualTrace,forward⟩ := rhs_forward hp ctx mirrored mappedX mappedY width fits st safeX safeY tr n
  rw [forward] at run
  simp only [Except.ok.injEq,Prod.mk.injEq,Option.some.injEq] at run
  obtain ⟨outEq,stateEq,_⟩ := run
  exact ⟨safeX,safeY,rx,ry,mappedX,mappedY,outEq.symm,stateEq.symm⟩

/-- Concrete mapped words inhabit both RHS routes and supported widths; the
source match/binding and complete-function witness remain separate obligations. -/
theorem rhs_witness (mirrored : Bool) (w : Nat) (width : w = 32 ∨ w = 64) :
    ∃ trace,(evalExpr program (Stock.sem sinkCtx) {} 60 (extrRule mirrored).rhs
      (extrEnv mirrored w 0 (w-1 : Nat) 1 1)).run (sinkState,#[]) =
      .ok (some (.regsVec [[(sinkState.base.fresh .int).1]]),
        {(sinkState.mark 0).mark 1 with base := (sinkState.base.fresh .int).2.emit (.aluRRRShift .extr (szOf w) (sinkState.base.fresh .int).1 (.vreg 192 .int)
            (.vreg 193 .int) (shiftFor w 1))},trace) := by
  have safe0 := stock_put_in_reg_witness.1
  have safe1 : DemandAllowed sinkCtx sinkState 1 := by
    intro i found
    change (none : Option Nat) = some i at found
    cases found
  exact rhs_forward data_program sinkCtx mirrored (w := w) (x := 0) (y := 1)
    (X := (w-1 : Nat)) (Y := 1) rfl rfl width (by decide) sinkState safe0 safe1 #[] 0

/-- Successful concrete runs inhabit the observation theorem for both mirrors
and source-compatible positive shifts summing to the supported width. -/
theorem rhs_observed_witness (mirrored : Bool) (w : Nat) (width : w = 32 ∨ w = 64) :
    DemandAllowed sinkCtx sinkState 0 ∧ DemandAllowed sinkCtx sinkState 1 ∧
      ∃ rx ry,sinkCtx.valueReg? 0 = some rx ∧ sinkCtx.valueReg? 1 = some ry ∧
        (.regsVec [[(sinkState.base.fresh .int).1]] : V) =
          .regsVec [[(sinkState.base.fresh .int).1]] ∧
        {(sinkState.mark 0).mark 1 with base := (sinkState.base.fresh .int).2.emit (.aluRRRShift .extr (szOf w) (sinkState.base.fresh .int).1 (.vreg 192 .int)
            (.vreg 193 .int) (shiftFor w 1))} =
        {(sinkState.mark 0).mark 1 with base := (sinkState.base.fresh .int).2.emit (.aluRRRShift .extr (szOf w) (sinkState.base.fresh .int).1 rx ry
            (shiftFor w (1 : Int).toNat))} := by
  obtain ⟨trace,run⟩ := rhs_witness mirrored w width
  exact rhs_observed data_program sinkCtx mirrored width (by decide) (n := 0) run

end Backend.Stock.Proof.LogicalExtr

namespace Backend.Stock.Proof.LogicalExtr
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
attribute [local irreducible] Isle.Aarch64.program

private def literalPattern (slot : Nat) : Pattern :=
  .term 15 1 [.term 18 209 [.wildcard 14,.term 152 2482
    [.term 151 2341 [],.term 134 144 [.term 4 1527 [.bind 1 slot (.wildcard 1)]]]]]
private def wordPattern (left : Bool) (wordSlot countSlot : Nat) : Pattern :=
  .term 15 1 [.term 18 209 [.wildcard 14,.term 152 2449
    [.term 151 (if left then 2387 else 2388) [],.term 147 1614
      [.bind 15 wordSlot (.wildcard 15),literalPattern countSlot]]]]

/-- Both original source definitions are retained, including the shift count's
own typed literal definition. These are not caller-supplied lookthrough facts. -/
def WordSource (ctx : Ctx) (value : Nat) (left : Bool) : Prop :=
  ∃ (j x count k : Nat) (info literal : IInfo) (ty literalTy : Clif.Ty) (bits : BitVec literalTy.width),
    ctx.defInst? value = some j ∧ ctx.insts[j]? = some info ∧
    info.clif = some (.binary (if left then .ishl else .ushr) ty x count) ∧
    ctx.defInst? count = some k ∧ ctx.insts[k]? = some literal ∧
    literal.clif = some (.iconst literalTy bits)

private theorem word_source {p : Program} (hp : Data p) {f : Clif.Function} {ctx : Ctx}
    (inv : MappedCtxInv f ctx) (left : Bool) {v wordSlot countSlot : Nat}
    {st : LState} {env env' : Isle.Interp.Env V}
    (matched : matchPat p (Backend.sem ctx) st (wordPattern left wordSlot countSlot)
      (.value v) env = .ok (some env')) : WordSource ctx v left := by
  have opTerm : termOf p (if left then 2387 else 2388) =
      .ok (if left then T.«Opcode.Ishl» else T.«Opcode.Ushr») := by
    cases left <;> first | exact hp.t2387 | exact hp.t2388
  have opKind : (if left then T.«Opcode.Ishl» else T.«Opcode.Ushr»).kind =
      .enumVariant (if left then 103 else 104) := by cases left <;> rfl
  obtain ⟨j,info,fs,env0,defined,found,data,rest⟩ :=
    defInst_match_inv hp ctx hp.t2449 term_2449_kind opTerm opKind matched
  obtain ⟨original,clif,raw⟩ := ctxInv_clif inv.identityView defined found
  rw [data] at raw
  have name : (variantNames 151)[if left then 103 else 104]? =
      some (if left then "Ishl" else "Ushr") := by
    cases left <;> first | exact variantNames_Ishl | exact variantNames_Ushr
  have opcode : binaryOpcode (if left then .ishl else .ushr) =
      some (if left then "Ishl" else "Ushr") := by cases left <;> rfl
  obtain ⟨ty,x,count,rfl,_,rfl⟩ := instData_binary_inv name opcode raw
  obtain ⟨env1,_,constant⟩ := values2_match_inv hp ctx rest
  obtain ⟨k,literal,fields,env2,countDefined,countFound,literalData,_⟩ :=
    defInst_match_inv hp ctx hp.t2482 term_2482_kind hp.t2341 term_2341_kind constant
  obtain ⟨sourceLiteral,literalClif,literalRaw⟩ := ctxInv_clif inv.identityView countDefined countFound
  rw [literalData] at literalRaw
  obtain ⟨literalTy,bits,rfl,rfl⟩ := instData_iconst_inv literalRaw
  exact ⟨j,x,count,k,info,literal,ty,literalTy,bits,defined,found,clif,countDefined,countFound,literalClif⟩

/-- Actual successful Stock matches follow both original operands through their
shift and literal definitions, including the mirrored OR route. -/
theorem matched_sources {p : Program} (hp : Data p) {f : Clif.Function} {ctx : Ctx}
    (inv : MappedCtxInv f ctx) (mirrored : Bool) {i a b n : Nat} {info : IInfo}
    (source : ctx.insts[i]? = some info)
    (data : info.data = .data 152 2 [.data 151 98 [],.values [a,b]])
    {st : State} {tr : Array RuleId} {env : Isle.Interp.Env V} {middle : State × Array RuleId}
    (matched : (matchRule p (Stock.sem ctx) {} (n+20) (extrRule mirrored) [.inst i]).run (st,tr) =
      .ok (some env,middle)) : WordSource ctx a (!mirrored) ∧ WordSource ctx b mirrored := by
  have shape : (extrRule mirrored).args = [.term 18 209
    [.term 14 120 [.bind 14 0 (.wildcard 14)],.term 152 2449
      [.term 151 2382 [],.term 147 1614 [wordPattern (!mirrored) 1 2,wordPattern mirrored 3 4]]]] := by
    cases mirrored <;> rfl
  obtain ⟨initial,args,_⟩ := matchRule_some_inv matched
  rw [stock_matchArgs,shape] at args
  obtain ⟨e1,root,_⟩ := matchArgs_cons_inv args
  obtain ⟨fields,extracted,patterns⟩ := matchPat_extract_inv hp.t209 term_209_kind rfl root
  rw [Backend.Proof.sem_extract,ext_inst_data_value ctx st.base source,data] at extracted
  cases extracted
  obtain ⟨e2,_,tail⟩ := matchArgs_cons_inv patterns
  obtain ⟨e3,binary,_⟩ := matchArgs_cons_inv tail
  obtain ⟨fs,decoded,matchedFields⟩ := matchPat_enum_inv hp.t2449 term_2449_kind binary
  have decode : (Backend.sem ctx).unData 152 (.data 152 2 [.data 151 98 [],.values [a,b]]) =
      some (2,[.data 151 98 [],.values [a,b]]) := rfl
  rw [decode] at decoded
  cases decoded
  obtain ⟨e4,_,values⟩ := matchArgs_cons_inv matchedFields
  obtain ⟨e5,first,second⟩ := values2_match_inv hp ctx values
  exact ⟨word_source hp inv (!mirrored) first,word_source hp inv mirrored second⟩
end Backend.Stock.Proof.LogicalExtr


namespace Backend.Stock.Proof.LogicalExtr
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
attribute [local irreducible] Isle.Aarch64.program
private theorem forward_sem_extract (ctx : Ctx) (t : Term) (v : V) (st : State) :
    (Stock.sem ctx).extract t v st = Backend.externExtract ctx t v st.base := rfl
private theorem forward_sem_unData (ctx : Ctx) (t : Nat) (v : V) :
    (Stock.sem ctx).unData t v = (Backend.sem ctx).unData t v := rfl
private theorem forward_sem_bool (ctx : Ctx) (b : Bool) : (Stock.sem ctx).bool b = .bool b := rfl
private theorem forward_sem_int (ctx : Ctx) (ty : TypeId) (i : Int) :
    (Stock.sem ctx).int ty i = .int (normInt ty i) := rfl
private theorem forward_sem_eq (ctx : Ctx) (a b : V) : (Stock.sem ctx).eq a b = (a == b) := rfl
private theorem forward_sem_prim (ctx : Ctx) (name : String) :
    (Stock.sem ctx).prim 14 name = (CTy.ofName? name).map V.ty := rfl
private theorem forward_sem_ctor (ctx : Ctx) (t : Term) (vs : List V) (st : State) :
    (Stock.sem ctx).ctor t vs st = Stock.externCtor ctx t vs st := rfl
private theorem pure_ctor (ctx : Ctx) (t : Term) (args : List V) (st : State) (v : V)
    (unrevised : t.id ∉ revisedCtors)
    (base : Backend.externCtor ctx t args st.base = .ok (v,st.base)) :
    Stock.externCtor ctx t args st = .ok (v,st) := by
  rw [stock_ctor_baseOnly ctx t args st unrevised,base]
private theorem stock_u8_into_u64 (ctx : Ctx) (st : State) (a : Int) :
    Stock.externCtor ctx T.u8_into_u64 [.int a] st = .ok (.int a,st) :=
  pure_ctor ctx _ _ st _ (by decide) (ctor_u8_into_u64 ctx st.base a)
private theorem stock_wrapping_add (ctx : Ctx) (st : State) (a b : Int) :
    Stock.externCtor ctx T.u64_wrapping_add [.int a,.int b] st = .ok (.int (u64 (a+b)),st) :=
  pure_ctor ctx _ _ st _ (by decide) (ctor_u64_wrapping_add ctx st.base a b)
private theorem stock_eq (ctx : Ctx) (st : State) (a b : Int) :
    Stock.externCtor ctx T.u64_eq [.int a,.int b] st = .ok (.bool (a == b),st) :=
  pure_ctor ctx _ _ st _ (by decide) (ctor_u64_eq ctx st.base a b)
private theorem stock_gt (ctx : Ctx) (st : State) (a b : Int) :
    Stock.externCtor ctx T.u64_gt [.int a,.int b] st = .ok (.bool (decide (a>b)),st) :=
  pure_ctor ctx _ _ st _ (by decide) (ctor_u64_gt ctx st.base a b)
private theorem stock_bits (ctx : Ctx) (st : State) (w : Nat) :
    Stock.externCtor ctx T.ty_bits [.ty (.int w)] st = .ok (.int w,st) :=
  pure_ctor ctx _ _ st _ (by decide) (ctor_ty_bits ctx st.base w)
variable {p : Program} (hp : Data p) (ctx : Ctx) {cfg : Config}
variable (st : State) (tr : Array RuleId) (n : Nat)
include hp in
private theorem stock_match_1501 {i a b x c1 y c2 w j1 j2 j3 j4 : Nat} {kx ky : Int}
    {info info1 info2 info3 info4 : IInfo} (hi : ctx.insts[i]? = some info)
    (hty : info.resTys.head? = some (.int w)) (hw : w = 32 ∨ w = 64)
    (hd : info.data = .data 152 2 [.data 151 98 [], .values [a, b]])
    (hj1 : ctx.defInst? a = some j1) (hij1 : ctx.insts[j1]? = some info1)
    (hd1 : info1.data = .data 152 2 [.data 151 103 [], .values [x, c1]])
    (hj2 : ctx.defInst? c1 = some j2) (hij2 : ctx.insts[j2]? = some info2)
    (hd2 : info2.data = .data 152 35 [.data 151 57 [], .int kx])
    (hj3 : ctx.defInst? b = some j3) (hij3 : ctx.insts[j3]? = some info3)
    (hd3 : info3.data = .data 152 2 [.data 151 104 [], .values [y, c2]])
    (hj4 : ctx.defInst? c2 = some j4) (hij4 : ctx.insts[j4]? = some info4)
    (hd4 : info4.data = .data 152 35 [.data 151 57 [], .int ky])
    (hok : ExtrOk w (u64 kx) (u64 ky)) :
    (matchRule p (Stock.sem ctx) cfg (n+20) rule_lower_1501 [.inst i]).run (st, tr) =
      .ok (some (env5 (.ty (.int w)) (.value x) (.int (u64 kx)) (.value y) (.int (u64 ky))), (st, tr)) := by
  obtain ⟨hx8, hy8, hsum, hx0, hy0⟩ := hok
  have hx0' : decide ((u64 kx : Int) > 0) = true := by simpa using hx0
  have hy0' : decide ((u64 ky : Int) > 0) = true := by simpa using hy0
  have h0 := ext_inst_data_value ctx st.base hi
  rw [hd, hty, Option.getD_some] at h0
  have h1 := ext_inst_data_value ctx st.base hij1
  rw [hd1] at h1
  have h2 := ext_inst_data_value ctx st.base hij2
  rw [hd2] at h2
  have h3 := ext_inst_data_value ctx st.base hij3
  rw [hd3] at h3
  have h4 := ext_inst_data_value ctx st.base hij4
  rw [hd4] at h4
  have g1 := ext_def_inst_some ctx st.base hj1
  have g2 := ext_def_inst_some ctx st.base hj2
  have g3 := ext_def_inst_some ctx st.base hj3
  have g4 := ext_def_inst_some ctx st.base hj4
  have h5 := ext_ty_32_or_64 ctx st.base w
  simp only [hw, ↓reduceIte] at h5
  cases hp
  isel_eval [*,forward_sem_bool,forward_sem_int,forward_sem_extract,forward_sem_unData,forward_sem_eq,forward_sem_prim,forward_sem_ctor, rule_lower_1501, ext_value_array_2, ext_u64_from_imm64, ext_u8_from_u64,
    stock_u8_into_u64, stock_wrapping_add, stock_eq, stock_gt, stock_bits,
    beq_bool_true_true, and_self]

set_option maxRecDepth 20000 in

include hp in
private theorem stock_match_1501_none {i a b x c1 y c2 w j1 j2 j3 j4 : Nat} {kx ky : Int}
    {info info1 info2 info3 info4 : IInfo} (hi : ctx.insts[i]? = some info)
    (hty : info.resTys.head? = some (.int w)) (hw : w = 32 ∨ w = 64)
    (hd : info.data = .data 152 2 [.data 151 98 [], .values [a, b]])
    (hj1 : ctx.defInst? a = some j1) (hij1 : ctx.insts[j1]? = some info1)
    (hd1 : info1.data = .data 152 2 [.data 151 103 [], .values [x, c1]])
    (hj2 : ctx.defInst? c1 = some j2) (hij2 : ctx.insts[j2]? = some info2)
    (hd2 : info2.data = .data 152 35 [.data 151 57 [], .int kx])
    (hj3 : ctx.defInst? b = some j3) (hij3 : ctx.insts[j3]? = some info3)
    (hd3 : info3.data = .data 152 2 [.data 151 104 [], .values [y, c2]])
    (hj4 : ctx.defInst? c2 = some j4) (hij4 : ctx.insts[j4]? = some info4)
    (hd4 : info4.data = .data 152 35 [.data 151 57 [], .int ky])
    (hno : ¬ ExtrOk w (u64 kx) (u64 ky)) :
    (matchRule p (Stock.sem ctx) cfg (n+20) rule_lower_1501 [.inst i]).run (st, tr) = .ok (none, (st, tr)) := by
  unfold ExtrOk at hno
  have h0 := ext_inst_data_value ctx st.base hi
  rw [hd, hty, Option.getD_some] at h0
  have h1 := ext_inst_data_value ctx st.base hij1
  rw [hd1] at h1
  have h2 := ext_inst_data_value ctx st.base hij2
  rw [hd2] at h2
  have h3 := ext_inst_data_value ctx st.base hij3
  rw [hd3] at h3
  have h4 := ext_inst_data_value ctx st.base hij4
  rw [hd4] at h4
  have g1 := ext_def_inst_some ctx st.base hj1
  have g2 := ext_def_inst_some ctx st.base hj2
  have g3 := ext_def_inst_some ctx st.base hj3
  have g4 := ext_def_inst_some ctx st.base hj4
  have h5 := ext_ty_32_or_64 ctx st.base w
  simp only [hw, ↓reduceIte] at h5
  cases hp
  by_cases c1 : 0 ≤ (u64 kx : Int) ∧ (u64 kx : Int) < 256
  · by_cases c2 : 0 ≤ (u64 ky : Int) ∧ (u64 ky : Int) < 256
    · by_cases c3 : ((w : Int) == ((u64 ((u64 kx : Int) + (u64 ky : Int)) : Nat) : Int)) = true
      · by_cases c4 : 0 < (u64 kx : Int)
        · have c5 : decide ((u64 ky : Int) > 0) = false := by
            simp only [decide_eq_false_iff_not]
            exact fun h => hno (by first | exact ⟨c1, c2, c3, c4, h⟩ | exact ⟨c2, c1, c3, c4, h⟩)
          have c4' : decide ((u64 kx : Int) > 0) = true := by simpa using c4
          isel_eval [*,forward_sem_bool,forward_sem_int,forward_sem_extract,forward_sem_unData,forward_sem_eq,forward_sem_prim,forward_sem_ctor, rule_lower_1501, ext_value_array_2, ext_u64_from_imm64, ext_u8_from_u64,
    stock_u8_into_u64, stock_wrapping_add, stock_eq, stock_gt, stock_bits,
    beq_bool_true_true, beq_bool_false_true, and_self]
        · have c4' : decide ((u64 kx : Int) > 0) = false := by simpa using c4
          isel_eval [*,forward_sem_bool,forward_sem_int,forward_sem_extract,forward_sem_unData,forward_sem_eq,forward_sem_prim,forward_sem_ctor, rule_lower_1501, ext_value_array_2, ext_u64_from_imm64, ext_u8_from_u64,
    stock_u8_into_u64, stock_wrapping_add, stock_eq, stock_gt, stock_bits,
    beq_bool_true_true, beq_bool_false_true, and_self]
      · have c3' : ((w : Int) == ((u64 ((u64 kx : Int) + (u64 ky : Int)) : Nat) : Int)) = false := by
          simpa using c3
        isel_eval [*,forward_sem_bool,forward_sem_int,forward_sem_extract,forward_sem_unData,forward_sem_eq,forward_sem_prim,forward_sem_ctor, rule_lower_1501, ext_value_array_2, ext_u64_from_imm64, ext_u8_from_u64,
    stock_u8_into_u64, stock_wrapping_add, stock_eq, stock_gt, stock_bits,
    beq_bool_true_true, beq_bool_false_true, and_self]
    · isel_eval [*,forward_sem_bool,forward_sem_int,forward_sem_extract,forward_sem_unData,forward_sem_eq,forward_sem_prim,forward_sem_ctor, rule_lower_1501, ext_value_array_2, ext_u64_from_imm64, ext_u8_from_u64,
    stock_u8_into_u64, stock_wrapping_add, stock_eq, stock_gt, stock_bits,
    beq_bool_true_true, beq_bool_false_true, and_self]
  · isel_eval [*,forward_sem_bool,forward_sem_int,forward_sem_extract,forward_sem_unData,forward_sem_eq,forward_sem_prim,forward_sem_ctor, rule_lower_1501, ext_value_array_2, ext_u64_from_imm64, ext_u8_from_u64,
    stock_u8_into_u64, stock_wrapping_add, stock_eq, stock_gt, stock_bits,
    beq_bool_true_true, beq_bool_false_true, and_self]

set_option maxRecDepth 20000 in

include hp in
private theorem stock_match_1507 {i a b x c1 y c2 w j1 j2 j3 j4 : Nat} {kx ky : Int}
    {info info1 info2 info3 info4 : IInfo} (hi : ctx.insts[i]? = some info)
    (hty : info.resTys.head? = some (.int w)) (hw : w = 32 ∨ w = 64)
    (hd : info.data = .data 152 2 [.data 151 98 [], .values [a, b]])
    (hj1 : ctx.defInst? a = some j1) (hij1 : ctx.insts[j1]? = some info1)
    (hd1 : info1.data = .data 152 2 [.data 151 104 [], .values [y, c1]])
    (hj2 : ctx.defInst? c1 = some j2) (hij2 : ctx.insts[j2]? = some info2)
    (hd2 : info2.data = .data 152 35 [.data 151 57 [], .int ky])
    (hj3 : ctx.defInst? b = some j3) (hij3 : ctx.insts[j3]? = some info3)
    (hd3 : info3.data = .data 152 2 [.data 151 103 [], .values [x, c2]])
    (hj4 : ctx.defInst? c2 = some j4) (hij4 : ctx.insts[j4]? = some info4)
    (hd4 : info4.data = .data 152 35 [.data 151 57 [], .int kx])
    (hok : ExtrOk w (u64 kx) (u64 ky)) :
    (matchRule p (Stock.sem ctx) cfg (n+20) rule_lower_1507 [.inst i]).run (st, tr) =
      .ok (some (env5 (.ty (.int w)) (.value y) (.int (u64 ky)) (.value x) (.int (u64 kx))), (st, tr)) := by
  obtain ⟨hx8, hy8, hsum, hx0, hy0⟩ := hok
  have hx0' : decide ((u64 kx : Int) > 0) = true := by simpa using hx0
  have hy0' : decide ((u64 ky : Int) > 0) = true := by simpa using hy0
  have h0 := ext_inst_data_value ctx st.base hi
  rw [hd, hty, Option.getD_some] at h0
  have h1 := ext_inst_data_value ctx st.base hij1
  rw [hd1] at h1
  have h2 := ext_inst_data_value ctx st.base hij2
  rw [hd2] at h2
  have h3 := ext_inst_data_value ctx st.base hij3
  rw [hd3] at h3
  have h4 := ext_inst_data_value ctx st.base hij4
  rw [hd4] at h4
  have g1 := ext_def_inst_some ctx st.base hj1
  have g2 := ext_def_inst_some ctx st.base hj2
  have g3 := ext_def_inst_some ctx st.base hj3
  have g4 := ext_def_inst_some ctx st.base hj4
  have h5 := ext_ty_32_or_64 ctx st.base w
  simp only [hw, ↓reduceIte] at h5
  cases hp
  isel_eval [*,forward_sem_bool,forward_sem_int,forward_sem_extract,forward_sem_unData,forward_sem_eq,forward_sem_prim,forward_sem_ctor, rule_lower_1507, ext_value_array_2, ext_u64_from_imm64, ext_u8_from_u64,
    stock_u8_into_u64, stock_wrapping_add, stock_eq, stock_gt, stock_bits,
    beq_bool_true_true, beq_bool_false_true, and_self]

set_option maxRecDepth 20000 in

include hp in
private theorem stock_match_1507_none {i a b x c1 y c2 w j1 j2 j3 j4 : Nat} {kx ky : Int}
    {info info1 info2 info3 info4 : IInfo} (hi : ctx.insts[i]? = some info)
    (hty : info.resTys.head? = some (.int w)) (hw : w = 32 ∨ w = 64)
    (hd : info.data = .data 152 2 [.data 151 98 [], .values [a, b]])
    (hj1 : ctx.defInst? a = some j1) (hij1 : ctx.insts[j1]? = some info1)
    (hd1 : info1.data = .data 152 2 [.data 151 104 [], .values [y, c1]])
    (hj2 : ctx.defInst? c1 = some j2) (hij2 : ctx.insts[j2]? = some info2)
    (hd2 : info2.data = .data 152 35 [.data 151 57 [], .int ky])
    (hj3 : ctx.defInst? b = some j3) (hij3 : ctx.insts[j3]? = some info3)
    (hd3 : info3.data = .data 152 2 [.data 151 103 [], .values [x, c2]])
    (hj4 : ctx.defInst? c2 = some j4) (hij4 : ctx.insts[j4]? = some info4)
    (hd4 : info4.data = .data 152 35 [.data 151 57 [], .int kx])
    (hno : ¬ ExtrOk w (u64 kx) (u64 ky)) :
    (matchRule p (Stock.sem ctx) cfg (n+20) rule_lower_1507 [.inst i]).run (st, tr) = .ok (none, (st, tr)) := by
  unfold ExtrOk at hno
  have h0 := ext_inst_data_value ctx st.base hi
  rw [hd, hty, Option.getD_some] at h0
  have h1 := ext_inst_data_value ctx st.base hij1
  rw [hd1] at h1
  have h2 := ext_inst_data_value ctx st.base hij2
  rw [hd2] at h2
  have h3 := ext_inst_data_value ctx st.base hij3
  rw [hd3] at h3
  have h4 := ext_inst_data_value ctx st.base hij4
  rw [hd4] at h4
  have g1 := ext_def_inst_some ctx st.base hj1
  have g2 := ext_def_inst_some ctx st.base hj2
  have g3 := ext_def_inst_some ctx st.base hj3
  have g4 := ext_def_inst_some ctx st.base hj4
  have h5 := ext_ty_32_or_64 ctx st.base w
  simp only [hw, ↓reduceIte] at h5
  cases hp
  by_cases c1 : 0 ≤ (u64 ky : Int) ∧ (u64 ky : Int) < 256
  · by_cases c2 : 0 ≤ (u64 kx : Int) ∧ (u64 kx : Int) < 256
    · by_cases c3 : ((w : Int) == ((u64 ((u64 kx : Int) + (u64 ky : Int)) : Nat) : Int)) = true
      · by_cases c4 : 0 < (u64 kx : Int)
        · have c5 : decide ((u64 ky : Int) > 0) = false := by
            simp only [decide_eq_false_iff_not]
            exact fun h => hno (by first | exact ⟨c1, c2, c3, c4, h⟩ | exact ⟨c2, c1, c3, c4, h⟩)
          have c4' : decide ((u64 kx : Int) > 0) = true := by simpa using c4
          isel_eval [*,forward_sem_bool,forward_sem_int,forward_sem_extract,forward_sem_unData,forward_sem_eq,forward_sem_prim,forward_sem_ctor, rule_lower_1507, ext_value_array_2, ext_u64_from_imm64, ext_u8_from_u64,
    stock_u8_into_u64, stock_wrapping_add, stock_eq, stock_gt, stock_bits,
    beq_bool_true_true, beq_bool_false_true, and_self]
        · have c4' : decide ((u64 kx : Int) > 0) = false := by simpa using c4
          isel_eval [*,forward_sem_bool,forward_sem_int,forward_sem_extract,forward_sem_unData,forward_sem_eq,forward_sem_prim,forward_sem_ctor, rule_lower_1507, ext_value_array_2, ext_u64_from_imm64, ext_u8_from_u64,
    stock_u8_into_u64, stock_wrapping_add, stock_eq, stock_gt, stock_bits,
    beq_bool_true_true, beq_bool_false_true, and_self]
      · have c3' : ((w : Int) == ((u64 ((u64 kx : Int) + (u64 ky : Int)) : Nat) : Int)) = false := by
          simpa using c3
        isel_eval [*,forward_sem_bool,forward_sem_int,forward_sem_extract,forward_sem_unData,forward_sem_eq,forward_sem_prim,forward_sem_ctor, rule_lower_1507, ext_value_array_2, ext_u64_from_imm64, ext_u8_from_u64,
    stock_u8_into_u64, stock_wrapping_add, stock_eq, stock_gt, stock_bits,
    beq_bool_true_true, beq_bool_false_true, and_self]
    · isel_eval [*,forward_sem_bool,forward_sem_int,forward_sem_extract,forward_sem_unData,forward_sem_eq,forward_sem_prim,forward_sem_ctor, rule_lower_1507, ext_value_array_2, ext_u64_from_imm64, ext_u8_from_u64,
    stock_u8_into_u64, stock_wrapping_add, stock_eq, stock_gt, stock_bits,
    beq_bool_true_true, beq_bool_false_true, and_self]
  · isel_eval [*,forward_sem_bool,forward_sem_int,forward_sem_extract,forward_sem_unData,forward_sem_eq,forward_sem_prim,forward_sem_ctor, rule_lower_1507, ext_value_array_2, ext_u64_from_imm64, ext_u8_from_u64,
    stock_u8_into_u64, stock_wrapping_add, stock_eq, stock_gt, stock_bits,
    beq_bool_true_true, beq_bool_false_true, and_self]

include hp in
private theorem match_observed_1501 {i a b x c1 y c2 w j1 j2 j3 j4 : Nat} {kx ky : Int}
    {info info1 info2 info3 info4 : IInfo} (hi : ctx.insts[i]? = some info)
    (hty : info.resTys.head? = some (.int w)) (hw : w = 32 ∨ w = 64)
    (hd : info.data = .data 152 2 [.data 151 98 [], .values [a, b]])
    (hj1 : ctx.defInst? a = some j1) (hij1 : ctx.insts[j1]? = some info1)
    (hd1 : info1.data = .data 152 2 [.data 151 103 [], .values [x, c1]])
    (hj2 : ctx.defInst? c1 = some j2) (hij2 : ctx.insts[j2]? = some info2)
    (hd2 : info2.data = .data 152 35 [.data 151 57 [], .int kx])
    (hj3 : ctx.defInst? b = some j3) (hij3 : ctx.insts[j3]? = some info3)
    (hd3 : info3.data = .data 152 2 [.data 151 104 [], .values [y, c2]])
    (hj4 : ctx.defInst? c2 = some j4) (hij4 : ctx.insts[j4]? = some info4)
    (hd4 : info4.data = .data 152 35 [.data 151 57 [], .int ky])
    {env : Isle.Interp.Env V} {middle : State × Array RuleId}
    (matched : (matchRule p (Stock.sem ctx) cfg (n+20) rule_lower_1501 [.inst i]).run (st,tr) =
      .ok (some env,middle)) :
    ExtrOk w (u64 kx) (u64 ky) ∧ env = env5 (.ty (.int w)) (.value x) (.int (u64 kx)) (.value y) (.int (u64 ky)) ∧ middle = (st,tr) := by
  classical
  by_cases guard : ExtrOk w (u64 kx) (u64 ky)
  · have forward := stock_match_1501 (cfg := cfg) hp ctx st tr n hi hty hw hd hj1 hij1 hd1 hj2 hij2 hd2 hj3 hij3 hd3 hj4 hij4 hd4 guard
    rw [forward] at matched
    have same := Except.ok.inj matched
    exact ⟨guard,(Option.some.inj (congrArg Prod.fst same)).symm,(congrArg Prod.snd same).symm⟩
  · have failed := stock_match_1501_none (cfg := cfg) hp ctx st tr n hi hty hw hd hj1 hij1 hd1 hj2 hij2 hd2 hj3 hij3 hd3 hj4 hij4 hd4 guard
    rw [failed] at matched
    cases matched

include hp in
private theorem match_observed_1507 {i a b x c1 y c2 w j1 j2 j3 j4 : Nat} {kx ky : Int}
    {info info1 info2 info3 info4 : IInfo} (hi : ctx.insts[i]? = some info)
    (hty : info.resTys.head? = some (.int w)) (hw : w = 32 ∨ w = 64)
    (hd : info.data = .data 152 2 [.data 151 98 [], .values [a, b]])
    (hj1 : ctx.defInst? a = some j1) (hij1 : ctx.insts[j1]? = some info1)
    (hd1 : info1.data = .data 152 2 [.data 151 104 [], .values [y, c1]])
    (hj2 : ctx.defInst? c1 = some j2) (hij2 : ctx.insts[j2]? = some info2)
    (hd2 : info2.data = .data 152 35 [.data 151 57 [], .int ky])
    (hj3 : ctx.defInst? b = some j3) (hij3 : ctx.insts[j3]? = some info3)
    (hd3 : info3.data = .data 152 2 [.data 151 103 [], .values [x, c2]])
    (hj4 : ctx.defInst? c2 = some j4) (hij4 : ctx.insts[j4]? = some info4)
    (hd4 : info4.data = .data 152 35 [.data 151 57 [], .int kx])
    {env : Isle.Interp.Env V} {middle : State × Array RuleId}
    (matched : (matchRule p (Stock.sem ctx) cfg (n+20) rule_lower_1507 [.inst i]).run (st,tr) =
      .ok (some env,middle)) :
    ExtrOk w (u64 kx) (u64 ky) ∧ env = env5 (.ty (.int w)) (.value y) (.int (u64 ky)) (.value x) (.int (u64 kx)) ∧ middle = (st,tr) := by
  classical
  by_cases guard : ExtrOk w (u64 kx) (u64 ky)
  · have forward := stock_match_1507 (cfg := cfg) hp ctx st tr n hi hty hw hd hj1 hij1 hd1 hj2 hij2 hd2 hj3 hij3 hd3 hj4 hij4 hd4 guard
    rw [forward] at matched
    have same := Except.ok.inj matched
    exact ⟨guard,(Option.some.inj (congrArg Prod.fst same)).symm,(congrArg Prod.snd same).symm⟩
  · have failed := stock_match_1507_none (cfg := cfg) hp ctx st tr n hi hty hw hd hj1 hij1 hd1 hj2 hij2 hd2 hj3 hij3 hd3 hj4 hij4 hd4 guard
    rw [failed] at matched
    cases matched

end Backend.Stock.Proof.LogicalExtr
namespace Backend.Stock.Proof.LogicalExtr
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
attribute [local irreducible] Isle.Aarch64.program

private theorem matched_width {p : Program} (hp : Data p) {ctx : Ctx} (mirrored : Bool)
    {i w n : Nat} {info : IInfo} (source : ctx.insts[i]? = some info)
    (type : info.resTys.head? = some (.int w))
    {st : State} {tr : Array RuleId} {env : Isle.Interp.Env V} {middle : State × Array RuleId}
    (matched : (matchRule p (Stock.sem ctx) {} (n+20) (extrRule mirrored) [.inst i]).run (st,tr) =
      .ok (some env,middle)) : w = 32 ∨ w = 64 := by
  obtain ⟨q,shape⟩ : ∃ q,(extrRule mirrored).args = [.term 18 209
      [.term 14 120 [.bind 14 0 (.wildcard 14)],q]] := by
    cases mirrored <;> exact ⟨_,rfl⟩
  obtain ⟨initial,args,_⟩ := matchRule_some_inv matched
  rw [stock_matchArgs,shape] at args
  obtain ⟨e1,root,_⟩ := matchArgs_cons_inv args
  obtain ⟨fields,extracted,patterns⟩ := matchPat_extract_inv hp.t209 term_209_kind rfl root
  have expected := ext_inst_data_value ctx st.base source
  rw [type,Option.getD_some] at expected
  rw [Backend.Proof.sem_extract,expected] at extracted
  cases extracted
  obtain ⟨e2,typeMatch,_⟩ := matchArgs_cons_inv patterns
  obtain ⟨typeFields,typeExtract,_⟩ := matchPat_extract_inv hp.t120 term_120_kind rfl typeMatch
  rw [Backend.Proof.sem_extract,ext_ty_32_or_64] at typeExtract
  split at typeExtract
  · assumption
  · cases typeExtract

/-- Original source facts recovered from a lookthrough match, retained with
all four actual instruction/definition links. -/
structure SourceWord (ctx : Ctx) (value : Nat) (left : Bool) where
  inst : Nat
  word : Nat
  count : Nat
  literalInst : Nat
  info : IInfo
  literal : IInfo
  ty : Clif.Ty
  literalTy : Clif.Ty
  bits : BitVec literalTy.width
  defined : ctx.defInst? value = some inst
  found : ctx.insts[inst]? = some info
  original : info.clif = some (.binary (if left then .ishl else .ushr) ty word count)
  countDefined : ctx.defInst? count = some literalInst
  countFound : ctx.insts[literalInst]? = some literal
  countOriginal : literal.clif = some (.iconst literalTy bits)

def SourceWord.amount {ctx : Ctx} {value : Nat} {left : Bool} (word : SourceWord ctx value left) : Int :=
  u64 (imm64OfIconst word.literalTy word.bits)

private theorem original_word {ctx : Ctx} {value : Nat} {left : Bool}
    (source : WordSource ctx value left) : Nonempty (SourceWord ctx value left) := by
  obtain ⟨j,x,c,k,info,literal,ty,literalTy,bits,defined,found,original,cdef,cfound,coriginal⟩ := source
  exact ⟨⟨j,x,c,k,info,literal,ty,literalTy,bits,defined,found,original,cdef,cfound,coriginal⟩⟩

section Data
attribute [local semireducible] Isle.Aarch64.program
private theorem source_data {f : Clif.Function} {ctx : Ctx} (inv : MappedCtxInv f ctx)
    {i a b : Nat} {ty : Clif.Ty} {info : IInfo} (source : ctx.insts[i]? = some info)
    (clif : info.clif = some (.binary .bor ty a b)) :
    info.data = .data 152 2 [.data 151 98 [],.values [a,b]] ∧
      info.resTys.head? = some (.int ty.width) := by
  have accepted := inv.instE i info _ source clif
  have supported : eTy ty = true := by
    simpa [Compile.instE,Compile.binaryE,Compile.tyE,eTy] using accepted
  have raw := inv.data i info _ source clif
  obtain ⟨types,result,typed,_⟩ := inv.resTys i info _ source clif
  simp only [Clif.Inst.resultTypes] at result
  cases result
  refine ⟨?_,by rw [typed]; simp [ofClif_int_width (isInt_of_eTy supported)]⟩
  have expected : instData f (.binary .bor ty a b) = .ok (.data 152 2 [.data 151 98 [],.values [a,b]]) := by
    simp only [instData,binaryOpcode,supported,ite_true]
    rfl
  exact Except.ok.inj (raw.symm.trans expected)

private theorem source_word_data {f : Clif.Function} {ctx : Ctx} (inv : MappedCtxInv f ctx)
    {value : Nat} {left : Bool} (word : SourceWord ctx value left) :
    word.info.data = .data 152 2 [.data 151 (if left then 103 else 104) [],.values [word.word,word.count]] ∧
      word.literal.data = .data 152 35 [.data 151 57 [],.int (imm64OfIconst word.literalTy word.bits)] := by
  have accepted := inv.instE word.inst word.info _ word.found word.original
  have supported : eTy word.ty = true := by
    cases left <;> simpa [Compile.instE,Compile.binaryE,Compile.tyE,eTy] using accepted
  have raw := inv.data word.inst word.info _ word.found word.original
  have expected : instData f (.binary (if left then .ishl else .ushr) word.ty word.word word.count) =
      .ok (.data 152 2 [.data 151 (if left then 103 else 104) [],.values [word.word,word.count]]) := by
    cases left <;> simp only [instData,binaryOpcode,supported,ite_true] <;> rfl
  have literalAccepted := inv.instE word.literalInst word.literal _ word.countFound word.countOriginal
  have literalSupported : eTy word.literalTy = true := by
    simpa [Compile.instE,Compile.tyE,eTy] using literalAccepted
  have literalRaw := inv.data word.literalInst word.literal _ word.countFound word.countOriginal
  have literalExpected : instData f (.iconst word.literalTy word.bits) =
      .ok (.data 152 35 [.data 151 57 [],.int (imm64OfIconst word.literalTy word.bits)]) := by
    simp only [instData,literalSupported,ite_true]
    rfl
  exact ⟨Except.ok.inj (raw.symm.trans expected),Except.ok.inj (literalRaw.symm.trans literalExpected)⟩
end Data
end Backend.Stock.Proof.LogicalExtr


namespace Backend.Stock.Proof.LogicalExtr
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
/-- A real successful source match derives its canonical environment, unchanged
complete state/trace and the original positive shift/sum guards internally.
Both original word/literal definition chains remain available to source DFG. -/
theorem match_receipt {p : Program} (hp : Data p) {f : Clif.Function} {ctx : Ctx}
    (inv : MappedCtxInv f ctx) (mirrored : Bool) {i a b n : Nat} {ty : Clif.Ty} {info : IInfo}
    (source : ctx.insts[i]? = some info) (clif : info.clif = some (.binary .bor ty a b))
    {st : State} {tr : Array RuleId} {env : Isle.Interp.Env V} {middle : State × Array RuleId}
    (matched : (matchRule p (Stock.sem ctx) {} (n+20) (extrRule mirrored) [.inst i]).run (st,tr) =
      .ok (some env,middle)) :
    ∃ (first : SourceWord ctx a (!mirrored)) (second : SourceWord ctx b mirrored),
      (ty.width = 32 ∨ ty.width = 64) ∧
      ExtrOk ty.width (if mirrored then second.amount else first.amount)
        (if mirrored then first.amount else second.amount) ∧
      env = extrEnv mirrored ty.width
        (if mirrored then second.word else first.word) (if mirrored then second.amount else first.amount)
        (if mirrored then first.word else second.word) (if mirrored then first.amount else second.amount) ∧
      middle = (st,tr) := by
  obtain ⟨data,type⟩ := source_data inv source clif
  have width := matched_width hp mirrored source type matched
  obtain ⟨leftSource,rightSource⟩ := matched_sources hp inv mirrored source data matched
  obtain ⟨first⟩ := original_word leftSource
  obtain ⟨second⟩ := original_word rightSource
  obtain ⟨shiftFirst,literalFirst⟩ := source_word_data inv first
  obtain ⟨shiftSecond,literalSecond⟩ := source_word_data inv second
  refine ⟨first,second,width,?_⟩
  cases mirrored with
  | false =>
    exact match_observed_1501 hp ctx st tr n source type width data
      first.defined first.found shiftFirst first.countDefined first.countFound literalFirst
      second.defined second.found shiftSecond second.countDefined second.countFound literalSecond matched
  | true =>
    exact match_observed_1507 hp ctx st tr n source type width data
      first.defined first.found shiftFirst first.countDefined first.countFound literalFirst
      second.defined second.found shiftSecond second.countDefined second.countFound literalSecond matched
end Backend.Stock.Proof.LogicalExtr

#print axioms Backend.Stock.Proof.LogicalExtr.match_receipt
