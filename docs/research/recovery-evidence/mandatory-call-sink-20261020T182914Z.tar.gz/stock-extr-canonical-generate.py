from pathlib import Path
import re
f=Path('/tmp/StockExtrMatchForward.lean').read_text()
for n in ['sem_extract','sem_unData','sem_eq','sem_prim','sem_ctor','sem_bool','sem_int']:
 f=re.sub(r'\b'+n+r'\b','forward_'+n,f)
observers=[]
for num in ['1501','1507']:
 a=f.index('private theorem stock_match_'+num+' ');b=f.index('    (hok :',a)
 header=f[a:b].replace('private theorem stock_match_'+num,'private theorem match_observed_'+num)
 env='env5 (.ty (.int w)) (.value x) (.int (u64 kx)) (.value y) (.int (u64 ky))' if num=='1501' else 'env5 (.ty (.int w)) (.value y) (.int (u64 ky)) (.value x) (.int (u64 kx))'
 args='hp ctx st tr n hi hty hw hd hj1 hij1 hd1 hj2 hij2 hd2 hj3 hij3 hd3 hj4 hij4 hd4'
 code='''include hp in
'''+header+f'''    {{env : Isle.Interp.Env V}} {{middle : State × Array RuleId}}
    (matched : (matchRule p (Stock.sem ctx) cfg (n+20) rule_lower_{num} [.inst i]).run (st,tr) =
      .ok (some env,middle)) :
    ExtrOk w (u64 kx) (u64 ky) ∧ env = {env} ∧ middle = (st,tr) := by
  classical
  by_cases guard : ExtrOk w (u64 kx) (u64 ky)
  · have forward := stock_match_{num} {args} guard
    rw [forward] at matched
    have same := Except.ok.inj matched
    exact ⟨guard,(Option.some.inj (congrArg Prod.fst same)).symm,(congrArg Prod.snd same).symm⟩
  · have failed := stock_match_{num}_none {args} guard
    rw [failed] at matched
    cases matched
'''
 observers.append(code)
f=f.replace('end Backend.Stock.Proof.LogicalExtr','\n'.join(observers)+'\nend Backend.Stock.Proof.LogicalExtr')
Path('/tmp/StockExtrMatchForwardObserved.lean').write_text(f)
pub='''
namespace Backend.Stock.Proof.LogicalExtr
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
/-- A real successful source match derives its canonical environment, unchanged
complete state/trace and the original positive shift/sum guards internally.
Both original word/literal definition chains remain available to source DFG. -/
theorem match_receipt {p : Program} (hp : Data p) {f : Clif.Function} {ctx : Ctx}
    (inv : MappedCtxInv f ctx) (mirrored : Bool) {i a b n : Nat} {ty : Clif.Ty} {info : IInfo}
    (source : ctx.insts[i]? = some info) (clif : info.clif = some (.binary .bor ty a b))
    {st : State} {tr : Array RuleId} {env : Isle.Interp.Env V} {middle : State × Array RuleId}
    (matched : (matchRule p (Stock.sem ctx) {} (n+20) (extrRule mirrored) [.inst i]).run (st,tr) =
      .ok (some env,middle)) :
    ∃ (first : SourceWord ctx a (!mirrored)) (second : SourceWord ctx b mirrored),
      ty.width = 32 ∨ ty.width = 64 ∧ False := by
  sorry
end Backend.Stock.Proof.LogicalExtr
'''
# Construct intended nested proposition explicitly, avoiding OR precedence ambiguities.
pub=pub.replace('      ty.width = 32 ∨ ty.width = 64 ∧ False := by\n  sorry', '''      (ty.width = 32 ∨ ty.width = 64) ∧
      ExtrOk ty.width (if mirrored then second.amount else first.amount)
        (if mirrored then first.amount else second.amount) ∧
      env = extrEnv mirrored ty.width
        (if mirrored then second.word else first.word) (if mirrored then second.amount else first.amount)
        (if mirrored then first.word else second.word) (if mirrored then first.amount else second.amount) ∧
      middle = (st,tr) := by
  obtain ⟨data,type⟩ := source_data inv source clif
  have width := matched_width hp mirrored source type matched
  obtain ⟨leftSource,rightSource⟩ := matched_sources hp inv mirrored source data matched
  obtain ⟨first⟩ := original_word leftSource
  obtain ⟨second⟩ := original_word rightSource
  obtain ⟨shiftFirst,literalFirst⟩ := source_word_data inv first
  obtain ⟨shiftSecond,literalSecond⟩ := source_word_data inv second
  refine ⟨first,second,width,?_⟩
  cases mirrored with
  | false =>
    exact match_observed_1501 hp ctx st tr n source type width data
      first.defined first.found shiftFirst first.countDefined first.countFound literalFirst
      second.defined second.found shiftSecond second.countDefined second.countFound literalSecond matched
  | true =>
    exact match_observed_1507 hp ctx st tr n source type width data
      first.defined first.found shiftFirst first.countDefined first.countFound literalFirst
      second.defined second.found shiftSecond second.countDefined second.countFound literalSecond matched''')
Path('/tmp/StockExtrMatchReceiptPublicOnly.lean').write_text(pub)
base=Path('/tmp/StockExtrMatch.lean').read_text().split('#print axioms Backend.Stock.Proof.LogicalExtr.matched_sources')[0]
forward='\n'.join(l for l in f.splitlines() if not l.startswith('import '))
source=base+'\n'+forward+'\n'+Path('/tmp/StockExtrMatchReceiptOnly.lean').read_text()+'\n'+pub
source+='\n#print axioms Backend.Stock.Proof.LogicalExtr.match_receipt\n'
Path('/tmp/StockExtrCanonicalMatch.lean').write_text(source)
