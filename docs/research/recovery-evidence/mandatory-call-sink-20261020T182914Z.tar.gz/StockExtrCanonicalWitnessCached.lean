import StockExtrCanonicalMatch
import FV.E2E.StockArithmeticStage
import FV.Backend.LinearScan
import FV.Backend.Lowering.StockD0
namespace E2E.StockLogicalExtrWitness
open Backend Backend.Proof Backend.Proof.Driver Backend.Stock.D0
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm

/-- Distinct shift operands, a consumed ninth ABI argument, unused parameters,
an explicit slot and a dead statement. Both original OR operand orders occur. -/
def function (config : Configuration) (mirrored : Bool) : Clif.Function :=
  let ty := valueType config
  {source "stock_logical_extr" config [] with
    sig := {
      params := List.replicate 9 ⟨ty,.none,.normal⟩
      returns := [⟨ty,.none,.normal⟩]
      callConv := convention config}
    slots := [(7,⟨8,some 8⟩)]
    blocks := [{
      id := 0
      params := (List.range 9).map (fun i => (i,ty))
      body := [⟨[9],.iconst ty (ty.width-1 : Nat)⟩,⟨[10],.iconst ty 1⟩,
        ⟨[11],.binary .ishl ty 1 9⟩,⟨[12],.binary .ushr ty 8 10⟩,
        ⟨[13],.binary .bor ty (if mirrored then 12 else 11) (if mirrored then 11 else 12)⟩,
        ⟨[14],.binary .bxor ty 0 2⟩]
      term := .ret [13]}]}
def selected (result : Stock.Result) (mirrored : Bool) : Bool :=
  result.schedule.any fun step => step.rules.contains
    (if mirrored then Isle.Aarch64.rule_lower_1507.id else Isle.Aarch64.rule_lower_1501.id)

private def checks (config : Configuration) (mirrored cleanup : Bool) : Bool :=
  lowerScopeB (function config mirrored) && dominatedB (function config mirrored) && sigAbiOk (function config mirrored).sig &&
  match Stock.lower (function config mirrored) with
  | .error _ => false
  | .ok result =>
    (!lowerCheck (function config mirrored) result.code && selected result mirrored) &&
    match Backend.prepare (Stock.Arithmetic.stage cleanup result.code) with
    | .error _ => false
    | .ok vcp =>
      prepCheck (Stock.Arithmetic.stage cleanup result.code) vcp &&
      match leanAlloc vcp with
      | .error _ => false
      | .ok rf =>
        (checkAlloc vcp rf).isOk &&
        match lowerRFunc vcp rf with
        | .error _ => false
        | .ok af =>
          match emitFunc 0 af with
          | .error _ => false
          | .ok fa => formsCoveredB ⟨fa.k,af.slotBase⟩ vcp && fa.layout.isOk


private def grid : Bool := configurations.all fun config =>
  [false,true].all fun mirrored => [false,true].all fun cleanup => checks config mirrored cleanup
-- witness: native_decide (24 fixed actual full-pipeline configurations only)
theorem checks_true : grid = true := by native_decide

/-- Real Stock EXTR programs pass both cleanup modes through checked Lean
allocation and emitted bytes in every existing integer ABI configuration. -/
theorem compiled_exists (config : Configuration) (mirrored cleanup : Bool) :
    LowerScope (function config mirrored) ∧ Dominated (function config mirrored) ∧
    sigAbiOk (function config mirrored).sig = true ∧
    ∃ result vcp rf af fa fb,
      CompiledStockArithmeticStage (function config mirrored) cleanup 0 result vcp rf af fa fb ∧
      selected result mirrored = true ∧ leanAlloc vcp = .ok rf ∧ FormsCovered ⟨fa.k,af.slotBase⟩ vcp ∧
      lowerCheck (function config mirrored) result.code = false := by
  have h : checks config mirrored cleanup = true := by
    have allConfig := List.all_eq_true.mp checks_true config (by cases config <;> simp [configurations])
    have allMirror := List.all_eq_true.mp allConfig mirrored (by cases mirrored <;> simp)
    exact List.all_eq_true.mp allMirror cleanup (by cases cleanup <;> simp)
  simp only [checks,Bool.and_eq_true] at h
  obtain ⟨⟨⟨scope,dominated⟩,abi⟩,h⟩ := h
  refine ⟨lowerScope_of scope,dominated_of dominated,abi,?_⟩
  cases lowered : Stock.lower (function config mirrored) with
  | error message => simp [lowered] at h
  | ok result =>
    simp only [lowered,Bool.and_eq_true,Bool.not_eq_true'] at h
    obtain ⟨⟨legacy,selectedRoot⟩,h⟩ := h
    cases prepared : Backend.prepare (Stock.Arithmetic.stage cleanup result.code) with
    | error message => simp [prepared] at h
    | ok vcp =>
      simp only [prepared,Bool.and_eq_true] at h
      obtain ⟨prepOk,h⟩ := h
      cases allocated : leanAlloc vcp with
      | error message => simp [allocated] at h
      | ok rf =>
        simp only [allocated,Bool.and_eq_true] at h
        obtain ⟨checked,h⟩ := h
        cases physical : lowerRFunc vcp rf with
        | error message => simp [physical] at h
        | ok af =>
          cases emitted : emitFunc 0 af with
          | error message => simp [physical,emitted] at h
          | ok fa =>
            simp only [physical,emitted,Bool.and_eq_true] at h
            obtain ⟨covered,layoutOk⟩ := h
            cases layout : fa.layout with
            | error message => rw [layout] at layoutOk; change false = true at layoutOk; cases layoutOk
            | ok fb =>
              have check : checkAlloc vcp rf = .ok () := by
                cases check : checkAlloc vcp rf with
                | error message => rw [check] at checked; change false = true at checked; cases checked
                | ok value => cases value; rfl
              exact ⟨result,vcp,rf,af,fa,fb,
                ⟨lowered,prepared,prepOk,check,physical,emitted,layout⟩,
                selectedRoot,allocated,(formsCoveredB_iff _ _).mp covered,legacy⟩

end E2E.StockLogicalExtrWitness
namespace E2E.StockLogicalExtrWitness
open Backend Backend.Proof Backend.Proof.Driver Backend.Stock.D0 Backend.Stock.Proof
open Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm

private def built (config : Configuration) (mirrored : Bool) : Ctx × Array (Nat × Nat) × Stock.State :=
  (Stock.buildCtx (function config mirrored)).toOption.getD (sinkCtx,#[],sinkState)
private theorem build (config : Configuration) (mirrored : Bool) :
    Stock.buildCtx (function config mirrored) = .ok (built config mirrored) := by
  cases config <;> cases mirrored <;> rfl
private def matchChecks (config : Configuration) (mirrored : Bool) : Bool :=
  let ctx := (built config mirrored).1
  let st := (built config mirrored).2.2
  lowerScopeB (function config mirrored) &&
  match ctx.insts[4]? with
  | none => false
  | some info =>
    decide (info.data = .data 152 2 [.data 151 98 [],
      .values [if mirrored then 12 else 11,if mirrored then 11 else 12]]) &&
    match (matchRule program (Stock.sem ctx) {} 20 (LogicalExtr.extrRule mirrored) [.inst 4]).run (st,#[]) with
    | .ok (some _,_) => true
    | _ => false
private def matchGrid : Bool := configurations.all fun config =>
  [false,true].all fun mirrored => matchChecks config mirrored
-- witness: native_decide (twelve fixed source contexts and actual rule matches only)
theorem match_checks_true : matchGrid = true := by native_decide

/-- Each ABI/width and mirrored root has an actual successful source match
inhabiting the original two-shift/two-literal definition theorem. -/
theorem source_matches (config : Configuration) (mirrored : Bool) :
    let ctx := (built config mirrored).1
    let st := (built config mirrored).2.2
    ∃ info env middle,
      ctx.insts[4]? = some info ∧
      info.data = .data 152 2 [.data 151 98 [],
        .values [if mirrored then 12 else 11,if mirrored then 11 else 12]] ∧
      (matchRule program (Stock.sem ctx) {} 20 (LogicalExtr.extrRule mirrored) [.inst 4]).run (st,#[]) =
        .ok (some env,middle) ∧
      LogicalExtr.WordSource ctx (if mirrored then 12 else 11) (!mirrored) ∧
      LogicalExtr.WordSource ctx (if mirrored then 11 else 12) mirrored := by
  dsimp only
  have h : matchChecks config mirrored = true := by
    have allConfig := List.all_eq_true.mp match_checks_true config (by cases config <;> simp [configurations])
    exact List.all_eq_true.mp allConfig mirrored (by cases mirrored <;> simp)
  simp only [matchChecks,Bool.and_eq_true] at h
  obtain ⟨scope,h⟩ := h
  have inv := buildCtx_mappedInv (lowerScope_of scope) (build config mirrored)
  cases found : (built config mirrored).1.insts[4]? with
  | none => simp [found] at h
  | some info =>
    simp only [found,Bool.and_eq_true,decide_eq_true_eq] at h
    obtain ⟨data,h⟩ := h
    cases run : (matchRule program (Stock.sem (built config mirrored).1) {} 20
        (LogicalExtr.extrRule mirrored) [.inst 4]).run ((built config mirrored).2.2,#[]) with
    | error message => simp [run] at h
    | ok result =>
      rcases result with ⟨value,middle⟩
      cases value with
      | none => simp [run] at h
      | some env =>
        obtain ⟨first,second⟩ := LogicalExtr.matched_sources data_program inv mirrored found data (n := 0) run
        exact ⟨info,env,middle,rfl,data,rfl,first,second⟩
end E2E.StockLogicalExtrWitness


namespace E2E.StockLogicalExtrWitness
open Backend Backend.Proof Backend.Proof.Driver Backend.Stock.D0 Backend.Stock.Proof
open Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm

private def canonicalBuilt (config : Configuration) (mirrored : Bool) : Ctx × Array (Nat × Nat) × Stock.State :=
  (Stock.buildCtx (function config mirrored)).toOption.getD (sinkCtx,#[],sinkState)
private theorem canonicalBuild (config : Configuration) (mirrored : Bool) :
    Stock.buildCtx (function config mirrored) = .ok (canonicalBuilt config mirrored) := by
  cases config <;> cases mirrored <;> rfl

/-- All twelve original source contexts inhabit the canonical environment and
shift-guard theorem, using their real successful matches and unchanged inputs. -/
theorem canonical_matches (config : Configuration) (mirrored : Bool) :
    let ctx := (canonicalBuilt config mirrored).1
    let st := (canonicalBuilt config mirrored).2.2
    let ty := valueType config
    ∃ (env : Isle.Interp.Env V) (middle : Stock.State × Array RuleId)
      (first : LogicalExtr.SourceWord ctx (if mirrored then 12 else 11) (!mirrored))
      (second : LogicalExtr.SourceWord ctx (if mirrored then 11 else 12) mirrored),
      (matchRule program (Stock.sem ctx) {} 20 (LogicalExtr.extrRule mirrored) [.inst 4]).run (st,#[]) =
        .ok (some env,middle) ∧
      (ty.width = 32 ∨ ty.width = 64) ∧
      ExtrOk ty.width (if mirrored then second.amount else first.amount)
        (if mirrored then first.amount else second.amount) ∧
      env = LogicalExtr.extrEnv mirrored ty.width
        (if mirrored then second.word else first.word) (if mirrored then second.amount else first.amount)
        (if mirrored then first.word else second.word) (if mirrored then first.amount else second.amount) ∧
      middle = (st,#[]) := by
  dsimp only
  obtain ⟨info,env,middle,found,data,run,_,_⟩ := source_matches config mirrored
  have expected : ((canonicalBuilt config mirrored).1.insts[4]?).bind IInfo.clif =
      some (.binary .bor (valueType config) (if mirrored then 12 else 11) (if mirrored then 11 else 12)) := by
    cases config <;> cases mirrored <;> rfl
  change (canonicalBuilt config mirrored).1.insts[4]? = some info at found
  rw [found] at expected
  have clif : info.clif = some (.binary .bor (valueType config)
      (if mirrored then 12 else 11) (if mirrored then 11 else 12)) := expected
  have scope : LowerScope (function config mirrored) := by
    apply lowerScope_of
    cases config <;> cases mirrored <;> decide +kernel
  have inv := buildCtx_mappedInv scope (canonicalBuild config mirrored)
  obtain ⟨first,second,width,guard,envEq,stateEq⟩ :=
    LogicalExtr.match_receipt data_program inv mirrored found clif (n := 0) run
  exact ⟨env,middle,first,second,run,width,guard,envEq,stateEq⟩
end E2E.StockLogicalExtrWitness

#print axioms Backend.Stock.Proof.LogicalExtr.match_receipt
#print axioms E2E.StockLogicalExtrWitness.canonical_matches
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let mut count : Nat := 0
  for (name,_) in env.constants.toList do
    let core := name.toString.contains "StockExtrCanonicalMatch" || name.toString.contains "LogicalExtr"
    let owned := (env.getModuleIdxFor? name).isNone
    if !core && !owned then continue
    for ax in ← collectAxioms name do
      unless #[``propext,``Classical.choice,``Quot.sound,
        ``E2E.StockLogicalExtrWitness.checks_true._native.native_decide.ax_1,
        ``E2E.StockLogicalExtrWitness.match_checks_true._native.native_decide.ax_1].contains ax do
        throwError "unexpected axiom {ax} in {name}"
    if core && !owned then
      for ax in ← collectAxioms name do
        unless #[``propext,``Classical.choice,``Quot.sound].contains ax do
          throwError "unexpected core axiom {ax} in {name}"
    count := count+1
  logInfo m!"STOCK_EXTR_CANONICAL_MATCH_FIXED_WITNESSES_AUDIT {count}"
