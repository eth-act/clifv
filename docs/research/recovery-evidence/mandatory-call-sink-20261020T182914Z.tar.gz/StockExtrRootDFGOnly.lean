
namespace E2E.StockLogicalExtrWitness
open Backend Backend.Proof Backend.Proof.Driver Backend.Stock.D0 Backend.Stock.Proof
open Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm
private def rootBuilt (config : Configuration) (mirrored : Bool) : Ctx × Array (Nat × Nat) × Stock.State :=
  (Stock.buildCtx (function config mirrored)).toOption.getD (sinkCtx,#[],sinkState)
private def sourceFrame (config : Configuration) (mirrored : Bool) (a b : CV) : Clif.Frame :=
  let ty := valueType config
  {
   func := function config mirrored
   regs := fun x => if x = 1 then some ⟨ty,a.setWidth ty.width⟩
     else if x = 8 then some ⟨ty,b.setWidth ty.width⟩
     else if x = 9 then some (.ofInt ty (ty.width-1 : Nat))
     else if x = 10 then some (.ofInt ty 1)
     else if x = 11 then some ⟨ty,a.setWidth ty.width <<< (ty.width-1)⟩
     else if x = 12 then some ⟨ty,b.setWidth ty.width >>> 1⟩ else none
   slots := []
   body := []
   term := .ret [13] }
/-- The real looked-through shifts and literals are source-available while
being absent from the machine register file in the fused EXTR witness. -/
private theorem sourceDFG (config : Configuration) (mirrored : Bool) (a b : CV) :
    DFGCons (rootBuilt config mirrored).1 (sourceFrame config mirrored a b) := by
  constructor
  · intro x j info cl v defined found original pure lookup
    by_cases h1 : x = 1
    · subst x
      have absent : (rootBuilt config mirrored).1.defInst? 1 = none := by
        cases config <;> cases mirrored <;> rfl
      rw [absent] at defined
      cases defined
    · 
      by_cases h8 : x = 8
      · subst x
        have absent : (rootBuilt config mirrored).1.defInst? 8 = none := by
          cases config <;> cases mirrored <;> rfl
        rw [absent] at defined
        cases defined
      · 
        by_cases h9 : x = 9
        · subst x
          cases config <;> cases mirrored
          all_goals
            change some 0 = some j at defined
            cases defined
            obtain ⟨bound,equal⟩ := Array.getElem?_eq_some_iff.mp found
            subst info
            cases original
            cases lookup
            exact ⟨[_],fun cm => rfl,rfl⟩
        · 
          by_cases h10 : x = 10
          · subst x
            cases config <;> cases mirrored
            all_goals
              change some 1 = some j at defined
              cases defined
              obtain ⟨bound,equal⟩ := Array.getElem?_eq_some_iff.mp found
              subst info
              cases original
              cases lookup
              exact ⟨[_],fun cm => rfl,rfl⟩
          · 
            by_cases h11 : x = 11
            · subst x
              cases config <;> cases mirrored
              all_goals
                change some 2 = some j at defined
                cases defined
                obtain ⟨bound,equal⟩ := Array.getElem?_eq_some_iff.mp found
                subst info
                cases original
                cases lookup
                exact ⟨[_],fun cm => rfl,rfl⟩
            · 
              by_cases h12 : x = 12
              · subst x
                cases config <;> cases mirrored
                all_goals
                  change some 3 = some j at defined
                  cases defined
                  obtain ⟨bound,equal⟩ := Array.getElem?_eq_some_iff.mp found
                  subst info
                  cases original
                  cases lookup
                  exact ⟨[_],fun cm => rfl,rfl⟩
              · simp [sourceFrame,h1,h8,h9,h10,h11,h12] at lookup
  · intro x t v typed lookup
    by_cases present : x = 1 ∨ x = 8 ∨ x = 9 ∨ x = 10 ∨ x = 11 ∨ x = 12
    · rcases present with rfl | rfl | rfl | rfl | rfl | rfl
      all_goals
        cases config <;> cases mirrored
        all_goals first
        | (change some (.int 32) = some t at typed; cases typed; cases lookup; rfl)
        | (change some (.int 64) = some t at typed; cases typed; cases lookup; rfl)
    · simp only [not_or] at present
      simp [sourceFrame,present.1,present.2.1,present.2.2.1,present.2.2.2.1,
        present.2.2.2.2.1,present.2.2.2.2.2] at lookup
end E2E.StockLogicalExtrWitness
