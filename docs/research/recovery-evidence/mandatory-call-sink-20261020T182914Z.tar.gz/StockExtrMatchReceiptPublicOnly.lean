
namespace Backend.Stock.Proof.LogicalExtr
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
/-- A real successful source match derives its canonical environment, unchanged
complete state/trace and the original positive shift/sum guards internally.
Both original word/literal definition chains remain available to source DFG. -/
theorem match_receipt {p : Program} (hp : Data p) {f : Clif.Function} {ctx : Ctx}
    (inv : MappedCtxInv f ctx) (mirrored : Bool) {i a b n : Nat} {ty : Clif.Ty} {info : IInfo}
    (source : ctx.insts[i]? = some info) (clif : info.clif = some (.binary .bor ty a b))
    {st : State} {tr : Array RuleId} {env : Isle.Interp.Env V} {middle : State × Array RuleId}
    (matched : (matchRule p (Stock.sem ctx) {} (n+20) (extrRule mirrored) [.inst i]).run (st,tr) =
      .ok (some env,middle)) :
    ∃ (first : SourceWord ctx a (!mirrored)) (second : SourceWord ctx b mirrored),
      (ty.width = 32 ∨ ty.width = 64) ∧
      ExtrOk ty.width (if mirrored then second.amount else first.amount)
        (if mirrored then first.amount else second.amount) ∧
      env = extrEnv mirrored ty.width
        (if mirrored then second.word else first.word) (if mirrored then second.amount else first.amount)
        (if mirrored then first.word else second.word) (if mirrored then first.amount else second.amount) ∧
      middle = (st,tr) := by
  obtain ⟨data,type⟩ := source_data inv source clif
  have width := matched_width hp mirrored source type matched
  obtain ⟨leftSource,rightSource⟩ := matched_sources hp inv mirrored source data matched
  obtain ⟨first⟩ := original_word leftSource
  obtain ⟨second⟩ := original_word rightSource
  obtain ⟨shiftFirst,literalFirst⟩ := source_word_data inv first
  obtain ⟨shiftSecond,literalSecond⟩ := source_word_data inv second
  refine ⟨first,second,width,?_⟩
  cases mirrored with
  | false =>
    exact match_observed_1501 hp ctx st tr n source type width data
      first.defined first.found shiftFirst first.countDefined first.countFound literalFirst
      second.defined second.found shiftSecond second.countDefined second.countFound literalSecond matched
  | true =>
    exact match_observed_1507 hp ctx st tr n source type width data
      first.defined first.found shiftFirst first.countDefined first.countFound literalFirst
      second.defined second.found shiftSecond second.countDefined second.countFound literalSecond matched
end Backend.Stock.Proof.LogicalExtr
