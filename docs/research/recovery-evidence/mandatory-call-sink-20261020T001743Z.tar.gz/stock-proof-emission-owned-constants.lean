import Lean
import FV.Link.ActualImageProof
import FV.E2E.ActualStackBound
import FV.E2E.ActualChunkCheck
import FVTest.E2E.ActualLinkProof
import FVTest.Backend.Lowering.StockActualLinked
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let targets : Array String := #["FV.Link.ActualImageProof","FV.E2E.ActualStackBound","FV.E2E.ActualChunkCheck","FVTest.E2E.ActualLinkProof","FVTest.Backend.Lowering.StockActualLinked"]
  let mut count : Nat := 0
  for (name, _) in env.constants.toList do
    let some i := env.getModuleIdxFor? name | continue
    unless targets.contains env.header.moduleNames[i]!.toString do continue
    let axioms ← collectAxioms name
    for ax in axioms do
      unless #[``propext, ``Classical.choice, ``Quot.sound].contains ax do
        throwError "disallowed axiom {ax} in {name}"
    count := count + 1
  unless count > 0 do throwError "empty consumer constant audit"
  logInfo m!"CONSUMER_CONSTANTS_STANDARD_ONLY {count}"
