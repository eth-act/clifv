from pathlib import Path
import subprocess as sp,json,re,hashlib,os,datetime
r=Path('/home/lee/clifv/.worktrees/driver-proof-resume');prefix='/tmp/select-retained-comparison';env=dict(os.environ);env['PATH']='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:/home/lee/.cargo/bin:'+env['PATH'];env['LEAN_NUM_THREADS']='2';env['FV_MEMCAP']='22G';p=r/'docs/research/stock-select-retained-comparison-checkpoint.json';d=json.loads(p.read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for kind,cmd in [('build',['scripts/memcap.sh','lake','build',*[x[:-5].replace('/','.') for x in d['sources']]]),('axioms',['scripts/memcap.sh','lake','env','lean','docs/research/stock-select-retained-comparison-all-axioms.lean'])]:
 print(datetime.datetime.now(datetime.timezone.utc).isoformat(),kind,flush=True)
 with Path(prefix+'-'+kind+'.log').open('w') as out:sp.run(cmd,cwd=r,env=env,stdout=out,stderr=sp.STDOUT,check=True)
def parse(path):return {n:sorted(set(x.strip() for x in a.split(',') if x.strip())) for n,a in re.findall(r"'([^']+)' depends on axioms: \[([^]]*)\]",Path(path).read_text())}
a=parse('/tmp/select-original-source-axioms.log');b=parse(prefix+'-axioms.log');assert len(a)==1553 and len(b)==1556;assert all(b.get(k)==v for k,v in a.items())
new={k:v for k,v in b.items() if k not in a};assert set(new)==set(d['roots']);assert all(set(v)<={'propext','Classical.choice','Quot.sound'} for v in new.values())
for path,digest in {**d['sources'],**d['preserved_prior_proof_sources']}.items():assert sha(r/path)==digest,path
d['normal_axioms']=new;d['normal_audit']={'log':prefix+'-axioms.log','sha256':sha(prefix+'-axioms.log'),'roots':1556,'all1553_prior_axiom_sets_exactly_preserved':True,'all7_compiler_trust_sets_exactly_preserved':True};d['build']={'log':prefix+'-build.log','sha256':sha(prefix+'-build.log'),'jobs':int(re.search(r'Build completed successfully \((\d+) jobs\)',Path(prefix+'-build.log').read_text())[1])};d['trust']='standard';d['kernel_matrix']={'log':'/tmp/select-retained-driver-matrix2.log','cases':32,'arbitrary_source_word_pairs':True};p.write_text(json.dumps(d,indent=2)+'\n')
s=Path('/tmp/minmax-register-integrated-full-gates.py').read_text().replace("prefix='/tmp/minmax-register-integrated-full'","prefix='/tmp/select-retained-comparison-full'").replace('stock-minmax-register-integrated-checkpoint.json','stock-select-retained-comparison-checkpoint.json');Path('/tmp/select-retained-comparison-full-gates.py').write_text(s)
sp.run(['python','/tmp/select-retained-comparison-full-gates.py'],cwd=r,env=env,check=True)
print('3-module3-root retained/source witness/kernel/audit/full gates PASS; other witness variants and full #140 still incomplete. No publication performed.',flush=True)
