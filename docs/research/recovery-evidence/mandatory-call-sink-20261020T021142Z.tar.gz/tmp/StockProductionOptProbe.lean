import FV.Link.OptExe
import FV.Link.ProductionExeSource

set_option autoImplicit false
namespace Link.ProductionCompiler.OptimizedProbe
open E2E E2E.LinkCheck E2E.BinCheck E2E.Elf E2E.ProductionBinary E2E.ProductionExecBytes E2E.LegalProgram Backend LinkSpec Opt.Legalize128

def attemptOpt (S : LinkSpec) (file0 : ByteArray) (cleanup : Bool) : Except String ByteArray :=
  Link.ProductionCompiler.attempt S.opt file0 cleanup

theorem prog_input (S : LinkSpec) {cleanup : Bool} : prog (input S cleanup) = (input S cleanup).toLinkInput.prog := by
  simp [prog,ProductionStackBound.CompilerInput.results,LinkInput.resultsProduction,
    progOf,LinkInput.prog,Function.comp_def]

/-- The optimised program and the input's program. -/
theorem optRel_prog (S : LinkSpec) {cleanup : Bool} : OptRel (prog (input S cleanup)) (prog (input S.opt cleanup)) := by
  rw [prog_input, prog_input]; exact S.optRel

theorem attemptOpt_spec {S : LinkSpec} {cleanup : Bool} {file0 file : ByteArray}
    (h : attemptOpt S file0 cleanup = .ok file) : Link.ProductionCompiler.attempt S.opt file0 cleanup = .ok file := h

/-- The linked system of the optimised input is `Ok`. -/
theorem linkOk_opt {S : LinkSpec} {cleanup : Bool} {file0 file : ByteArray} (h : attemptOpt S file0 cleanup = .ok file)
    (B : BaseEnv) (hB : BaseOk (sys (input S.opt cleanup) B)) :
    (ProductionStackBound.ofInput (input S.opt cleanup) B fun _ => True).OkProduction := by
  obtain ⟨hin, hl⟩ := Link.ProductionCompiler.attempt_spec (attemptOpt_spec h)
  exact ProductionStackBound.okB_sound hin (baseOk_F hB) fun _ _ => trivial

/-- Two entries of `f` with the same registers, slots and memory are the same state. -/
theorem clifEntry_eq {f : Clif.Function} {args args' : List Clif.Val} {cs cs0 : Clif.State}
    (h : ClifEntry f args cs) (h0 : ClifEntry f args' cs0) (hr : cs.frame.regs = cs0.frame.regs)
    (hs : cs.frame.slots = cs0.frame.slots) (hm : cs.mem = cs0.mem) : cs = cs0 := by
  obtain ⟨b, hb, h2, h3, -⟩ := h.entry
  obtain ⟨b0, hb0, h20, h30, -⟩ := h0.entry
  rw [hb] at hb0; cases hb0
  obtain ⟨⟨fu, re, sl, bo, te⟩, ca, me⟩ := cs
  obtain ⟨⟨fu0, re0, sl0, bo0, te0⟩, ca0, me0⟩ := cs0
  have hc := h.callers; have hc0 := h0.callers
  have hf := h.func; have hf0 := h0.func
  simp only at hr hs hm h2 h3 h20 h30 hc hc0 hf hf0
  subst hr hs hm hc hc0 hf hf0
  rw [h2, h3, h20, h30]

/-- The optimised program's run from `cs'` refines the input program's from the input
function's entry `cs` with the same registers, slots and memory. -/
theorem optRun {S : LinkSpec} {cleanup : Bool} {B : Clif.Env} (hE : Opt.EnvKeepsSymbols B) {n : String}
    {f f' : Clif.Function} (hf : (prog (input S cleanup)).func? n = some f)
    (hf' : (prog (input S.opt cleanup)).func? n = some f') {args : List Clif.Val} {cs cs' : Clif.State}
    (hcs : ClifEntry f args cs) (hcs' : ClifEntry f' args cs')
    (hregs : cs.frame.regs = cs'.frame.regs) (hsl : cs.frame.slots = cs'.frame.slots)
    (hmem : cs.mem = cs'.mem) (k : Nat) :
    ∃ m, (∀ v cm, Clif.runLoop B (prog (input S cleanup)) k cs = .returned v cm →
        Clif.runLoop B (prog (input S.opt cleanup)) m cs' = .returned v cm) ∧
      (∀ c, Clif.runLoop B (prog (input S cleanup)) k cs = .trapped c →
        Clif.runLoop B (prog (input S.opt cleanup)) m cs' = .trapped c) ∧
      (Opt.Final (Clif.runLoop B (prog (input S cleanup)) k cs) → ∀ d,
        Clif.DepthLe B (prog (input S cleanup)) d cs → Clif.DepthLe B (prog (input S.opt cleanup)) d cs') := by
  have hR := optRel_prog S (cleanup := cleanup)
  obtain ⟨cs0, hcs0, hr0, hs0, hm0, -, hSR⟩ := hR.entry hf hf' hcs'
  have : cs = cs0 := clifEntry_eq hcs hcs0 (hregs.trans hr0.symm) (hsl.trans hs0.symm)
    (hmem.trans hm0.symm)
  subst this
  exact hR.refines hE hSR k

/-- `ExecRefines` of an outcome of the optimised program's run (`Link.ProductionCompiler.attempt_correct` at its fuel). -/
theorem execOpt {S : LinkSpec} {cleanup : Bool} {file0 file : ByteArray} (h : attemptOpt S file0 cleanup = .ok file)
    (B : BaseEnv) (hB : BaseOk (sys (input S.opt cleanup) B)) (hH : HooksSim (input S.opt cleanup) B) {n : String}
    {f' : Clif.Function} (hf' : (prog (input S.opt cleanup)).func? n = some f')
    (hc : ¬ ProductionStackBound.CycleFrom (ProductionStackBound.Calls (input S.opt cleanup) (input S.opt cleanup).results) f')
    {r : Arm.ArmState} {args : List Clif.Val} {cs' : Clif.State} (hX : (imageOf file).Intact r)
    (ho : OutsideCall (input S.opt cleanup) (BinCheck.roByte (input S.opt cleanup) S.opt.data) f'
      (ProductionStackBound.stackFn (input S.opt cleanup) f') r args cs'.mem)
    (hr : ClifRun (input S.opt cleanup) B f' r args cs') {o : Clif.Outcome} {m : Nat}
    (hm : Clif.runLoop B.env (prog (input S.opt cleanup)) m cs' = o) (hof : o ≠ .outOfFuel)
    (htr : ∀ K, Clif.runLoop B.env (prog (input S.opt cleanup)) (K + 1) cs' = o →
      TrapsExplicit (Clif.linkEnvN (prog (input S.opt cleanup)) B.env K) (prog (input S.opt cleanup)).bare cs') :
    ExecRefines (art (input S.opt cleanup) f').fb (art (input S.opt cleanup) f').base (xreg 30 r)
      (step (input S.opt cleanup) B file) r (RelocAtWithResults (input S.opt cleanup) (input S.opt cleanup).results) o := by
  cases m with
  | zero => exact absurd hm.symm (by simpa using hof)
  | succ K =>
    have := Link.ProductionCompiler.attempt_correct (attemptOpt_spec h) B hB hH hf' hc K hX ho hr (htr K hm)
    rw [hm] at this
    exact this

/-- `ExecRefines` of an outcome of the optimised program's run of call depth at most `d`
(`Link.ProductionCompiler.attempt_correct_peak` at its fuel). -/
theorem execOptPeak {S : LinkSpec} {cleanup : Bool} {file0 file : ByteArray} (h : attemptOpt S file0 cleanup = .ok file)
    (B : BaseEnv) (hB : BaseOk (sys (input S.opt cleanup) B)) (hH : HooksSim (input S.opt cleanup) B) {n : String}
    {f' : Clif.Function} (hf' : (prog (input S.opt cleanup)).func? n = some f') (d : Nat)
    {r : Arm.ArmState} {args : List Clif.Val} {cs' : Clif.State} (hX : (imageOf file).Intact r)
    (ho : OutsideCall (input S.opt cleanup) (BinCheck.roByte (input S.opt cleanup) S.opt.data) f'
      (frameDrop (art (input S.opt cleanup) f').af + (input S.opt cleanup).D * d) r args cs'.mem)
    (hr : ClifRun (input S.opt cleanup) B f' r args cs') (hd : Clif.DepthLe B.env (prog (input S.opt cleanup)) d cs')
    {o : Clif.Outcome} {m : Nat}
    (hm : Clif.runLoop B.env (prog (input S.opt cleanup)) m cs' = o) (hof : o ≠ .outOfFuel)
    (htr : ∀ F, Clif.runLoop B.env (prog (input S.opt cleanup)) (F + 1) cs' = o →
      TrapsExplicit (Clif.linkEnvD (prog (input S.opt cleanup)) B.env F d) (prog (input S.opt cleanup)).bare cs') :
    ExecRefines (art (input S.opt cleanup) f').fb (art (input S.opt cleanup) f').base (xreg 30 r)
      (step (input S.opt cleanup) B file) r (RelocAtWithResults (input S.opt cleanup) (input S.opt cleanup).results) o := by
  cases m with
  | zero => exact absurd hm.symm (by simpa using hof)
  | succ F =>
    have := Link.ProductionCompiler.attempt_correct_peak (attemptOpt_spec h) B hB hH hf' F d hX ho hr hd (htr F hm)
    rw [hm] at this
    exact this

/-- **The optimising executable compiler is correct** (about the input's program, after the
`i128` legalisation, before the mid-end): for `attemptOpt S file0 cleanup = .ok file`, an outside call
of the compiled code of the optimised function `f'` (named `n`; no call cycle reachable from it)
refines the whole-program run of the input's program from the entry `cs` of its function `f`
named `n` with the call's registers, slots and memory: a return is the executable's return of
the same values with the same memory; a trap (the optimised runs' traps explicit) is the same
trap. -/
theorem attemptOpt_correct {S : LinkSpec} {cleanup : Bool} {file0 file : ByteArray}
    (h : attemptOpt S file0 cleanup = .ok file) (B : BaseEnv) (hB : BaseOk (sys (input S.opt cleanup) B))
    (hH : HooksSim (input S.opt cleanup) B) (hkeep : Opt.EnvKeepsSymbols B.env) {n : String}
    {f f' : Clif.Function} (hf : (prog (input S cleanup)).func? n = some f)
    (hf' : (prog (input S.opt cleanup)).func? n = some f')
    (hc : ¬ ProductionStackBound.CycleFrom (ProductionStackBound.Calls (input S.opt cleanup) (input S.opt cleanup).results) f')
    {r : Arm.ArmState} {args : List Clif.Val} {cs cs' : Clif.State}
    (hX : (imageOf file).Intact r)
    (ho : OutsideCall (input S.opt cleanup) (BinCheck.roByte (input S.opt cleanup) S.opt.data) f'
      (ProductionStackBound.stackFn (input S.opt cleanup) f') r args cs'.mem)
    (hr : ClifRun (input S.opt cleanup) B f' r args cs') (hcs : ClifEntry f args cs)
    (hregs : cs.frame.regs = cs'.frame.regs) (hsl : cs.frame.slots = cs'.frame.slots)
    (hmem : cs.mem = cs'.mem) (M : Nat) :
    (∀ vals cm, Clif.runLoop B.env (prog (input S cleanup)) M cs = .returned vals cm →
      ExecRefines (art (input S.opt cleanup) f').fb (art (input S.opt cleanup) f').base (xreg 30 r)
        (step (input S.opt cleanup) B file) r (RelocAtWithResults (input S.opt cleanup) (input S.opt cleanup).results) (.returned vals cm)) ∧
    ((∀ K, TrapsExplicit (Clif.linkEnvN (prog (input S.opt cleanup)) B.env K) (prog (input S.opt cleanup)).bare cs') →
      ∀ c, Clif.runLoop B.env (prog (input S cleanup)) M cs = .trapped c →
      ExecRefines (art (input S.opt cleanup) f').fb (art (input S.opt cleanup) f').base (xreg 30 r)
        (step (input S.opt cleanup) B file) r (RelocAtWithResults (input S.opt cleanup) (input S.opt cleanup).results) (.trapped c)) := by
  have hL := linkOk_opt h B hB
  have hcs' := hr.entry
  obtain ⟨m, h1, h2, -⟩ := optRun hkeep hf hf' hcs hcs' hregs hsl hmem M
  have hfP' : f' ∈ (prog (input S.opt cleanup)).funcs := (Clif.Program.func?_some hf').1
  refine ⟨fun vals cm hrun => ?_, fun htr c hrun => ?_⟩
  · exact execOpt h B hB hH hf' hc hX ho hr (h1 vals cm hrun) (fun h => by cases h)
      fun K hK => trapsExplicit_of_run hL hfP' hcs' ho.symbols hK
  · exact execOpt h B hB hH hf' hc hX ho hr (h2 c hrun) (fun h => by cases h) fun K _ => htr K

/-- **The optimising executable compiler is correct for recursive programs, with the stack of
the run's peak call depth**: `attemptOpt_correct` without the call-graph premise; the outside
caller provides `frameDrop + D * d` bytes of stack, where `d` bounds the call depth of the input
program's run from `cs` (the mid-end keeps the call depth of the runs it refines). -/
theorem attemptOpt_correct_peak {S : LinkSpec} {cleanup : Bool} {file0 file : ByteArray}
    (h : attemptOpt S file0 cleanup = .ok file) (B : BaseEnv) (hB : BaseOk (sys (input S.opt cleanup) B))
    (hH : HooksSim (input S.opt cleanup) B) (hkeep : Opt.EnvKeepsSymbols B.env) {n : String}
    {f f' : Clif.Function} (hf : (prog (input S cleanup)).func? n = some f)
    (hf' : (prog (input S.opt cleanup)).func? n = some f') (d : Nat)
    {r : Arm.ArmState} {args : List Clif.Val} {cs cs' : Clif.State}
    (hX : (imageOf file).Intact r)
    (ho : OutsideCall (input S.opt cleanup) (BinCheck.roByte (input S.opt cleanup) S.opt.data) f'
      (frameDrop (art (input S.opt cleanup) f').af + (input S.opt cleanup).D * d) r args cs'.mem)
    (hr : ClifRun (input S.opt cleanup) B f' r args cs') (hcs : ClifEntry f args cs)
    (hregs : cs.frame.regs = cs'.frame.regs) (hsl : cs.frame.slots = cs'.frame.slots)
    (hmem : cs.mem = cs'.mem) (hd : Clif.DepthLe B.env (prog (input S cleanup)) d cs) (M : Nat) :
    (∀ vals cm, Clif.runLoop B.env (prog (input S cleanup)) M cs = .returned vals cm →
      ExecRefines (art (input S.opt cleanup) f').fb (art (input S.opt cleanup) f').base (xreg 30 r)
        (step (input S.opt cleanup) B file) r (RelocAtWithResults (input S.opt cleanup) (input S.opt cleanup).results) (.returned vals cm)) ∧
    ((∀ F, TrapsExplicit (Clif.linkEnvD (prog (input S.opt cleanup)) B.env F d) (prog (input S.opt cleanup)).bare cs') →
      ∀ c, Clif.runLoop B.env (prog (input S cleanup)) M cs = .trapped c →
      ExecRefines (art (input S.opt cleanup) f').fb (art (input S.opt cleanup) f').base (xreg 30 r)
        (step (input S.opt cleanup) B file) r (RelocAtWithResults (input S.opt cleanup) (input S.opt cleanup).results) (.trapped c)) := by
  have hL := linkOk_opt h B hB
  have hcs' := hr.entry
  obtain ⟨m, h1, h2, h3⟩ := optRun hkeep hf hf' hcs hcs' hregs hsl hmem M
  have hfP' : f' ∈ (prog (input S.opt cleanup)).funcs := (Clif.Program.func?_some hf').1
  refine ⟨fun vals cm hrun => ?_, fun htr c hrun => ?_⟩
  · have hd' := h3 (by rw [hrun]; trivial) d hd
    exact execOptPeak h B hB hH hf' d hX ho hr hd' (h1 vals cm hrun) (fun h => by cases h)
      fun F hF => trapsExplicit_of_runD hL hfP' hcs' ho.symbols hd' hF
  · have hd' := h3 (by rw [hrun]; trivial) d hd
    exact execOptPeak h B hB hH hf' d hX ho hr hd' (h2 c hrun) (fun h => by cases h)
      fun F _ => htr F

/-- The source domain's context from the optimised input's linked system. -/
theorem srcCtx_opt {S : LinkSpec} {cleanup : Bool} {file0 file : ByteArray} (h : attemptOpt S file0 cleanup = .ok file)
    (hsrc : SrcScopeB (input S cleanup) = true) (B : BaseEnv) (hB : BaseOk (sys (input S.opt cleanup) B))
    (hlegal : (∃ f ∈ (input S cleanup).toLinkInput.srcProg.funcs, mentions128 f = true) →
      Opt.Legal.HelperOk B.env ∧ Opt.Legal.ExtLegal B.env ∧ Opt.Legal.EnvKeepsBounded B.env)
    (hsig : (∃ g ∈ (prog (input S cleanup)).funcs, ¬ Clif.IndFree g) → ∀ n, B.env.sigOf n = none) :
    ProgCtx (input S cleanup).toLinkInput.srcProg B.env (fun n => (input S cleanup).syms.lookup n) := by
  have hL := linkOk_opt h B hB
  have hR := optRel_prog S (cleanup := cleanup)
  have hpe' : (input S cleanup).toLinkInput.prog = prog (input S cleanup) := (prog_input S).symm
  exact srcCtx hsrc (by rw [hpe']; exact hR.nodup hL.names) (by rw [hpe']; exact hR.free hL.free)
    (by rw [hpe']; exact hR.declSig hL.declSig) (by rw [hpe']; exact hR.indScope hL.indScope)
    hlegal (by rw [hpe']; exact hsig)

/-- **The optimising executable compiler refines the original source program** (S2, S3): for
`attemptOpt S file0 cleanup = .ok file`, a source function `f` of an input in the source domain
(`SrcScopeB`), an outside call of the compiled code of the optimised legalisation `f'` of `f`
(named `n`, no call cycle reachable from it) with the ABI-split arguments `args'` of `args`
refines the whole-program run of the **original** program from `f`'s entry `cs` on `args`: a
return is the executable's return of the results split by `f`'s return groups with the same
memory; a trap (of a source run without load/store traps, the optimised runs' traps explicit) is
the same trap. -/
theorem attemptOpt_correct_source {S : LinkSpec} {cleanup : Bool} {file0 file : ByteArray}
    (h : attemptOpt S file0 cleanup = .ok file) (hsrc : SrcScopeB (input S cleanup) = true)
    (B : BaseEnv) (hB : BaseOk (sys (input S.opt cleanup) B)) (hH : HooksSim (input S.opt cleanup) B)
    (hkeep : Opt.EnvKeepsSymbols B.env)
    (hlegal : (∃ f ∈ (input S cleanup).toLinkInput.srcProg.funcs, mentions128 f = true) →
      Opt.Legal.HelperOk B.env ∧ Opt.Legal.ExtLegal B.env ∧ Opt.Legal.EnvKeepsBounded B.env)
    (hsig : (∃ g ∈ (prog (input S cleanup)).funcs, ¬ Clif.IndFree g) → ∀ n, B.env.sigOf n = none)
    {n : String} {f f' : Clif.Function} (hf : (input S cleanup).toLinkInput.srcProg.func? n = some f)
    (hf' : (prog (input S.opt cleanup)).func? n = some f')
    (hc : ¬ ProductionStackBound.CycleFrom (ProductionStackBound.Calls (input S.opt cleanup) (input S.opt cleanup).results) f')
    {r : Arm.ArmState} {args args' : List Clif.Val} {cs cs' : Clif.State}
    (hX : (imageOf file).Intact r)
    (ho : OutsideCall (input S.opt cleanup) (BinCheck.roByte (input S.opt cleanup) S.opt.data) f'
      (ProductionStackBound.stackFn (input S.opt cleanup) f') r args' cs'.mem)
    (hr : ClifRun (input S.opt cleanup) B f' r args' cs')
    (hcs : ClifEntry f args cs)
    (hexp : Opt.Legal.ExpRel ((Opt.Legal.groups f.sig.params).getD []) args args')
    (hsl : cs'.frame.slots = cs.frame.slots) (hmem : cs'.mem = cs.mem)
    (hbnd : ∀ s', Opt.Legal.SReach B.env (input S cleanup).toLinkInput.srcProg cs s' → Opt.Legal.MemBounded s'.mem)
    (M : Nat) :
    (∀ vals cm, Clif.runLoop B.env (input S cleanup).toLinkInput.srcProg M cs = .returned vals cm →
      ∃ vals', Opt.Legal.ExpRel ((Opt.Legal.groups f.sig.returns).getD []) vals vals' ∧
        ExecRefines (art (input S.opt cleanup) f').fb (art (input S.opt cleanup) f').base (xreg 30 r)
          (step (input S.opt cleanup) B file) r (RelocAtWithResults (input S.opt cleanup) (input S.opt cleanup).results) (.returned vals' cm)) ∧
    ((∀ K, TrapsExplicit (Clif.linkEnvN (prog (input S.opt cleanup)) B.env K) (prog (input S.opt cleanup)).bare cs') →
      Opt.Legal.NoMemTrap B.env (input S cleanup).toLinkInput.srcProg cs → ∀ c,
      Clif.runLoop B.env (input S cleanup).toLinkInput.srcProg M cs = .trapped c →
      ExecRefines (art (input S.opt cleanup) f').fb (art (input S.opt cleanup) f').base (xreg 30 r)
        (step (input S.opt cleanup) B file) r (RelocAtWithResults (input S.opt cleanup) (input S.opt cleanup).results) (.trapped c)) := by
  have hL := linkOk_opt h B hB
  have hpe := prog_eq_legal (input S cleanup)
  have hC := srcCtx_opt h hsrc B hB hlegal hsig
  have hfP := (Clif.Program.func?_some hf).1
  have hfL : (prog (input S cleanup)).func? n = some (legalize f) := by rw [hpe]; exact hC.func?_some hf
  -- the entries: the optimised function's `cs'`, the legalisation's `csL`, the source's `cs`
  have hcs' := hr.entry
  obtain ⟨csL, hcsL, hrL, hsL, hmL, -, -⟩ := (optRel_prog S).entry hfL hf' hcs'
  obtain ⟨b, hb, h2, h3, h4, h5⟩ := hcs.entry
  obtain ⟨b', hb', h2', h3', -, h5'⟩ := hcsL.entry
  have hE : EntryRel f args args' cs.frame csL.frame :=
    ⟨hcs.func, hcsL.func, ⟨b, hb, h2, h3, h4, h5⟩, ⟨b', hb', h2', h3', h5'⟩,
      by rw [hsL, hsl], hexp⟩
  have hst : (⟨cs.frame, [], cs.mem⟩ : Clif.State) = cs := by rw [← hcs.callers]
  have hstL : (⟨csL.frame, [], cs.mem⟩ : Clif.State) = csL := by
    rw [← hcsL.callers, ← hmem, ← hmL]
  have hLe : Clif.LInv (input S cleanup).toLinkInput.srcProg cs := by
    rw [← hst]; exact ⟨hE.lframe hfP, fun _ h => nomatch h⟩
  have hsym : SomeInd (legalProg (input S cleanup).toLinkInput.srcProg) →
      Opt.EnvKeepsSymbols B.env ∧ cs.mem.symbols = fun n => (input S cleanup).syms.lookup n := by
    intro _
    refine ⟨hkeep, ?_⟩
    rw [← hmem]; exact ho.symbols
  have hfP' : f' ∈ (prog (input S.opt cleanup)).funcs := (Clif.Program.func?_some hf').1
  -- legal run → optimised run
  have hopt : ∀ k, ∃ m, (∀ v cm, Clif.runLoop B.env (legalProg (input S cleanup).toLinkInput.srcProg) k csL =
        .returned v cm → Clif.runLoop B.env (prog (input S.opt cleanup)) m cs' = .returned v cm) ∧
      (∀ c, Clif.runLoop B.env (legalProg (input S cleanup).toLinkInput.srcProg) k csL = .trapped c →
        Clif.runLoop B.env (prog (input S.opt cleanup)) m cs' = .trapped c) := by
    intro k
    obtain ⟨m, h1, h2, -⟩ := optRun hkeep hfL hf' hcsL hcs' hrL hsL hmL k
    exact ⟨m, fun v cm hk => h1 v cm (by rw [hpe]; exact hk), fun c hk => h2 c (by rw [hpe]; exact hk)⟩
  refine ⟨fun vals cm hrun => ?_, fun htr hnmt c hrun => ?_⟩
  · have hG : GoodFrom B.env (input S cleanup).toLinkInput.srcProg (SomeInd (legalProg (input S cleanup).toLinkInput.srcProg))
        (fun n => (input S cleanup).syms.lookup n) ⟨cs.frame, [], cs.mem⟩ := by
      rw [hst]
      exact goodFrom_of hC.free hLe hbnd (memTrapFree_of_returned M cs vals cm hrun) hsym
    rw [← hst] at hrun
    obtain ⟨rv', hrel, k, hk⟩ := (legalProg_refines hC hfP hE hG M).1 vals cm hrun
    rw [hstL] at hk
    obtain ⟨m, h1, -⟩ := hopt k
    exact ⟨rv', hrel, execOpt h B hB hH hf' hc hX ho hr (h1 _ _ hk) (fun h => by cases h)
      fun K hK => trapsExplicit_of_run hL hfP' hcs' ho.symbols hK⟩
  · have hG : GoodFrom B.env (input S cleanup).toLinkInput.srcProg (SomeInd (legalProg (input S cleanup).toLinkInput.srcProg))
        (fun n => (input S cleanup).syms.lookup n) ⟨cs.frame, [], cs.mem⟩ := by
      rw [hst]
      exact goodFrom_of hC.free hLe hbnd hnmt hsym
    rw [← hst] at hrun
    obtain ⟨k, hk⟩ := (legalProg_refines hC hfP hE hG M).2 c hrun
    rw [hstL] at hk
    obtain ⟨m, -, h2⟩ := hopt k
    exact execOpt h B hB hH hf' hc hX ho hr (h2 _ hk) (fun h => by cases h) fun K _ => htr K

/-- **The optimising executable compiler refines the original source program, recursive
programs included** (S2, S3, L1d): `attemptOpt_correct_source` without the call-graph
premise; the outside caller provides `frameDrop + D * d` bytes of stack, where `d` bounds the
call depth of the **source** run (`Clif.DepthLe`): the legalisation and the mid-end keep the
call depth of the runs they refine. -/
theorem attemptOpt_correct_source_peak {S : LinkSpec} {cleanup : Bool} {file0 file : ByteArray}
    (h : attemptOpt S file0 cleanup = .ok file) (hsrc : SrcScopeB (input S cleanup) = true)
    (B : BaseEnv) (hB : BaseOk (sys (input S.opt cleanup) B)) (hH : HooksSim (input S.opt cleanup) B)
    (hkeep : Opt.EnvKeepsSymbols B.env)
    (hlegal : (∃ f ∈ (input S cleanup).toLinkInput.srcProg.funcs, mentions128 f = true) →
      Opt.Legal.HelperOk B.env ∧ Opt.Legal.ExtLegal B.env ∧ Opt.Legal.EnvKeepsBounded B.env)
    (hsig : (∃ g ∈ (prog (input S cleanup)).funcs, ¬ Clif.IndFree g) → ∀ n, B.env.sigOf n = none)
    {n : String} {f f' : Clif.Function} (hf : (input S cleanup).toLinkInput.srcProg.func? n = some f)
    (hf' : (prog (input S.opt cleanup)).func? n = some f') (d : Nat)
    {r : Arm.ArmState} {args args' : List Clif.Val} {cs cs' : Clif.State}
    (hX : (imageOf file).Intact r)
    (ho : OutsideCall (input S.opt cleanup) (BinCheck.roByte (input S.opt cleanup) S.opt.data) f'
      (frameDrop (art (input S.opt cleanup) f').af + (input S.opt cleanup).D * d) r args' cs'.mem)
    (hr : ClifRun (input S.opt cleanup) B f' r args' cs')
    (hcs : ClifEntry f args cs)
    (hexp : Opt.Legal.ExpRel ((Opt.Legal.groups f.sig.params).getD []) args args')
    (hsl : cs'.frame.slots = cs.frame.slots) (hmem : cs'.mem = cs.mem)
    (hbnd : ∀ s', Opt.Legal.SReach B.env (input S cleanup).toLinkInput.srcProg cs s' → Opt.Legal.MemBounded s'.mem)
    (hd : Clif.DepthLe B.env (input S cleanup).toLinkInput.srcProg d cs) (M : Nat) :
    (∀ vals cm, Clif.runLoop B.env (input S cleanup).toLinkInput.srcProg M cs = .returned vals cm →
      ∃ vals', Opt.Legal.ExpRel ((Opt.Legal.groups f.sig.returns).getD []) vals vals' ∧
        ExecRefines (art (input S.opt cleanup) f').fb (art (input S.opt cleanup) f').base (xreg 30 r)
          (step (input S.opt cleanup) B file) r (RelocAtWithResults (input S.opt cleanup) (input S.opt cleanup).results) (.returned vals' cm)) ∧
    ((∀ F, TrapsExplicit (Clif.linkEnvD (prog (input S.opt cleanup)) B.env F d)
        (prog (input S.opt cleanup)).bare cs') →
      Opt.Legal.NoMemTrap B.env (input S cleanup).toLinkInput.srcProg cs → ∀ c,
      Clif.runLoop B.env (input S cleanup).toLinkInput.srcProg M cs = .trapped c →
      ExecRefines (art (input S.opt cleanup) f').fb (art (input S.opt cleanup) f').base (xreg 30 r)
        (step (input S.opt cleanup) B file) r (RelocAtWithResults (input S.opt cleanup) (input S.opt cleanup).results) (.trapped c)) := by
  have hL := linkOk_opt h B hB
  have hpe := prog_eq_legal (input S cleanup)
  have hC := srcCtx_opt h hsrc B hB hlegal hsig
  have hfP := (Clif.Program.func?_some hf).1
  have hfL : (prog (input S cleanup)).func? n = some (legalize f) := by rw [hpe]; exact hC.func?_some hf
  have hcs' := hr.entry
  obtain ⟨csL, hcsL, hrL, hsL, hmL, -, -⟩ := (optRel_prog S).entry hfL hf' hcs'
  obtain ⟨b, hb, h2, h3, h4, h5⟩ := hcs.entry
  obtain ⟨b', hb', h2', h3', -, h5'⟩ := hcsL.entry
  have hE : EntryRel f args args' cs.frame csL.frame :=
    ⟨hcs.func, hcsL.func, ⟨b, hb, h2, h3, h4, h5⟩, ⟨b', hb', h2', h3', h5'⟩,
      by rw [hsL, hsl], hexp⟩
  have hst : (⟨cs.frame, [], cs.mem⟩ : Clif.State) = cs := by rw [← hcs.callers]
  have hstL : (⟨csL.frame, [], cs.mem⟩ : Clif.State) = csL := by
    rw [← hcsL.callers, ← hmem, ← hmL]
  have hLe : Clif.LInv (input S cleanup).toLinkInput.srcProg cs := by
    rw [← hst]; exact ⟨hE.lframe hfP, fun _ h => nomatch h⟩
  have hd' : Clif.DepthLe B.env (input S cleanup).toLinkInput.srcProg d ⟨cs.frame, [], cs.mem⟩ := by rw [hst]; exact hd
  have hsym : SomeInd (legalProg (input S cleanup).toLinkInput.srcProg) →
      Opt.EnvKeepsSymbols B.env ∧ cs.mem.symbols = fun n => (input S cleanup).syms.lookup n := by
    intro _
    refine ⟨hkeep, ?_⟩
    rw [← hmem]; exact ho.symbols
  have hfP' : f' ∈ (prog (input S.opt cleanup)).funcs := (Clif.Program.func?_some hf').1
  -- legal run (call depth `d`) → optimised run (call depth `d`)
  have hopt : ∀ k, Clif.DepthLe B.env (legalProg (input S cleanup).toLinkInput.srcProg) d csL → ∃ m,
      (∀ v cm, Clif.runLoop B.env (legalProg (input S cleanup).toLinkInput.srcProg) k csL = .returned v cm →
        Clif.runLoop B.env (prog (input S.opt cleanup)) m cs' = .returned v cm ∧
          Clif.DepthLe B.env (prog (input S.opt cleanup)) d cs') ∧
      (∀ c, Clif.runLoop B.env (legalProg (input S cleanup).toLinkInput.srcProg) k csL = .trapped c →
        Clif.runLoop B.env (prog (input S.opt cleanup)) m cs' = .trapped c ∧
          Clif.DepthLe B.env (prog (input S.opt cleanup)) d cs') := by
    intro k hdL
    obtain ⟨m, h1, h2, h3⟩ := optRun hkeep hfL hf' hcsL hcs' hrL hsL hmL k
    rw [← hpe] at hdL
    refine ⟨m, fun v cm hk => ?_, fun c hk => ?_⟩
    · rw [← hpe] at hk
      exact ⟨h1 v cm hk, h3 (by rw [hk]; trivial) d hdL⟩
    · rw [← hpe] at hk
      exact ⟨h2 c hk, h3 (by rw [hk]; trivial) d hdL⟩
  refine ⟨fun vals cm hrun => ?_, fun htr hnmt c hrun => ?_⟩
  · have hG : GoodFrom B.env (input S cleanup).toLinkInput.srcProg (SomeInd (legalProg (input S cleanup).toLinkInput.srcProg))
        (fun n => (input S cleanup).syms.lookup n) ⟨cs.frame, [], cs.mem⟩ := by
      rw [hst]
      exact goodFrom_of hC.free hLe hbnd (memTrapFree_of_returned M cs vals cm hrun) hsym
    rw [← hst] at hrun
    obtain ⟨rv', hrel, ⟨k, hk⟩, hdL⟩ := (legalProg_refines_depth hC hfP hE hG hd' M).1 vals cm hrun
    rw [hstL] at hk hdL
    obtain ⟨m, h1, -⟩ := hopt k hdL
    obtain ⟨hm, hdO⟩ := h1 _ _ hk
    exact ⟨rv', hrel, execOptPeak h B hB hH hf' d hX ho hr hdO hm (fun h => by cases h)
      fun F hF => trapsExplicit_of_runD hL hfP' hcs' ho.symbols hdO hF⟩
  · have hG : GoodFrom B.env (input S cleanup).toLinkInput.srcProg (SomeInd (legalProg (input S cleanup).toLinkInput.srcProg))
        (fun n => (input S cleanup).syms.lookup n) ⟨cs.frame, [], cs.mem⟩ := by
      rw [hst]
      exact goodFrom_of hC.free hLe hbnd hnmt hsym
    rw [← hst] at hrun
    obtain ⟨⟨k, hk⟩, hdL⟩ := (legalProg_refines_depth hC hfP hE hG hd' M).2 c hrun
    rw [hstL] at hk hdL
    obtain ⟨m, -, h2⟩ := hopt k hdL
    obtain ⟨hm, hdO⟩ := h2 _ hk
    exact execOptPeak h B hB hH hf' d hX ho hr hdO hm (fun h => by cases h) fun F _ => htr F

/-- `withSizes` and `opt` commute. -/
theorem withSizes_opt (S : LinkSpec) {cleanup : Bool} (z : List Nat) : (S.withSizes z).opt = S.opt.withSizes z := by
  obtain ⟨funcs, names, sizes, outside, data, symNames, R⟩ := S
  simp only [LinkSpec.withSizes, LinkSpec.opt, LinkSpec.mk.injEq, List.map_map, true_and,
    and_true]
  exact List.map_congr_left fun fi _ => fi.opt_pair.2.name.symm


end Link.ProductionCompiler.OptimizedProbe
