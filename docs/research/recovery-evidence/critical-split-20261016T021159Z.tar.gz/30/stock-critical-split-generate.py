from pathlib import Path
import json,hashlib,re,datetime,subprocess
name='stock-critical-split';base='stock-shared-entry';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
old=json.loads(Path('docs/research/'+base+'-checkpoint.json').read_text());assert all(sha(n)==h for n,h in old['sources'].items())
modules={'StockCriticalSplit':'Backend.Stock.Proof.','StockSourceIndegree':'Backend.Stock.Proof.','StockCriticalSplitFixture':'Backend.Stock.Proof.CriticalSplitFixture.','StockCriticalSplitWitness':'Backend.Stock.Proof.CriticalSplitWitness.'}
paths=['FV/Backend/Proof/'+m+'.lean' for m in modules]
roots=[ns+n for m,ns in modules.items() for n in re.findall(r'^theorem (\w+)',Path('FV/Backend/Proof/'+m+'.lean').read_text(),re.M)];assert len(roots)==5
p={k:old[k] for k in ['goal','status','full_goal_checklist','comparison_preservation']}
p.update(updated_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),baseline_checkpoint='docs/research/'+base+'-checkpoint.json',previous_goal_turn_classification='progress: actual shared-jump runBlock/edge invariant and complete cyclic witness;1919-root/full2478/remotec5cfcdcc verified',scope='Actual Stock critical-node insertion completeness, exact source indegree counts including duplicate/unreachable edges, complete direct/indirect one-successor forced TryCall split witnesses. Actual graph predecessor-count bound and prepared shared-source jump classification remain open; all universal checker/static/dataflow/full source/driver/production obligations retained.',sources=old['sources']|{n:sha(n) for n in paths},new_or_appended_source_paths=paths,new_public_roots=roots,next_steps=['Prove actual graph incoming-edge provenance/index uniqueness and bound original-target predecessor counts by exact source indegree; combine insertion completeness to exclude unsplit nonjump sources of shared targets','Transport source classification through actual indexed preparation/RPO; compose arbitrary full block/edge verification from canonical entry/body states; derive universal original-input Stock static/class/must-availability/EntryAvailAt and actual checker/fallback fixpoint/completeness','Complete all original source/DFG/world/block/whole-driver simulation/completeness, uncovered families/effects/traps/sinking and actual compiler/checker/linker/generated-proof production integration, complete production witnesses/final audits/gates/fresh comparison preserving original input/theorem/axiom/identity/stage/#179 parity'],new_root_witness_coverage={'stock_single_try_forced_split_witness':['stock_order_critical_split_complete','stock_lower_critical_split_complete','sourceIndegree_counts','single_try_fixture','complete direct/indirect original LowerScope/Dominated/ArityOk TryCall source with one successor and unreachable second source predecessor; exact source table, source indegree2, unreachable node absence and actual forced critical node/edges; raw preparation/global checked fallback/physical lowering retained']})
Path('docs/research/'+name+'-checkpoint.json').write_text(json.dumps(p,indent=2)+'\n')
code=Path('docs/research/'+base+'-all-axioms.lean').read_text()
imports='\n'.join('import FV.Backend.Proof.'+m for m in modules)
Path('docs/research/'+name+'-all-axioms.lean').write_text(imports+'\n'+code+'\n'+'\n'.join('#print axioms '+n for n in roots)+'\n')
Path('/tmp/'+name+'-mcp-code.lean').write_text(imports+'\n'+'\n'.join('#print axioms '+n for n in roots)+'\n')
Path('/tmp/'+name+'-full-gates.py').write_text(Path('/tmp/'+base+'-full-gates.py').read_text().replace(base,name))
audit=Path('/tmp/'+base+'-audit-check.py').read_text().replace('stock-preentry','OLD_BASE').replace(base,name).replace('OLD_BASE',base).replace('1919','1924').replace('1915','1919').replace('all4_sets','all5_sets').replace('4 new','5 new');Path('/tmp/'+name+'-audit-check.py').write_text(audit)
ref='c5cfcdcca484c8e07c9f363ad92ab86268b600e6';manifest={}
for line in subprocess.check_output(['git','ls-tree','-r',ref,'--','FV','FVTest'],text=True).splitlines():
 meta,n=line.split('\t');blob=meta.split()[2]
 if not n.endswith('.lean'):continue
 data=Path(n).read_bytes();assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==blob,n
 manifest[n]=sha(n)
new=sorted(str(x) for top in ['FV','FVTest'] for x in Path(top).rglob('*.lean') if str(x) not in manifest);assert new==sorted(paths),new
Path('/tmp/'+name+'-source-preservation.json').write_text(json.dumps({'baseline':ref,'existing_Lean_files':len(manifest),'all_existing_sources_byte_identical':True,'new_sources':new,'source_sha256':manifest},indent=2)+'\n')
print(len(manifest),'old files unchanged;',len(p['sources']),'recorded paths;',len(roots),'new roots')
