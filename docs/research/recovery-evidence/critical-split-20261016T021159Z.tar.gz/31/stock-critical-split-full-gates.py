from pathlib import Path
import subprocess as sp,os,json,re,hashlib,datetime
root=Path('/home/lee/clifv/.worktrees/driver-proof-resume');prefix='/tmp/stock-critical-split-full'
env=dict(os.environ);env['PATH']='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:/home/lee/.cargo/bin:'+env['PATH'];env['LEAN_NUM_THREADS']='2';env['FV_MEMCAP']='22G';env['CLIF_NATIVE_QEMU']='/home/lee/.local/share/clifv-test-tools/usr/bin/qemu-aarch64-static';env['LLVM_MC']='/home/lee/.local/share/clifv-test-tools/usr/bin/llvm-mc'
receipt=root/'docs/research/stock-critical-split-checkpoint.json';report=json.loads(receipt.read_text());div=json.loads((root/'docs/research/stock-div-audit.json').read_text());comparison=json.loads((root/'docs/research/stock-cmp-publication-gates.json').read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for name,digest in report['sources'].items():assert sha(root/name)==digest,name
checks=[('full',['scripts/memcap.sh','lake','build','FV','FVTest','lean-backend','lean-e2e-check','link-check'],root),('crates',['../scripts/memcap.sh','lake','build'],root/'crate-proofs'),('runtime',['scripts/memcap.sh','bash','scripts/lean-backend-filetests.sh'],root),('encoder',['scripts/memcap.sh','bash','scripts/lean-backend-encode-check.sh'],root),('e2e',['scripts/memcap.sh','lake','exe','lean-e2e-check','--identity-report',prefix+'-identities.json'],root),('legacy-e2e',['scripts/memcap.sh','lake','exe','lean-e2e-check','--no-dead-cleanup','--identity-report',prefix+'-legacy-identities.json'],root)]
for kind,command,cwd in checks:
 print(datetime.datetime.now(datetime.timezone.utc).isoformat(),kind,flush=True)
 with Path(prefix+'-'+kind+'.log').open('w') as log:sp.run(command,cwd=cwd,env=env,stdout=log,stderr=sp.STDOUT,check=True)
for name,digest in report['sources'].items():assert sha(root/name)==digest,name
for name,digest in comparison['source_sha256'].items():assert sha(root/name)==digest,name
for kind,key in [('identities','identity_sha256'),('legacy-identities','legacy_identity_sha256')]:assert sha(prefix+'-'+kind+'.json')==div['gates'][key],kind
family=lambda t:[x for x in t.splitlines() if re.match(r'^[\w-]+: lean pass ',x) or x.startswith(('runs: lean pass ','TOTAL files '))]
assert family(Path(prefix+'-runtime.log').read_text())==family(Path(div['logs']['runtime']['path']).read_text())
assert 'functions 1292: identical 1292, differ 0' in Path(prefix+'-encoder.log').read_text()
report['full_gates']={'full_build_jobs':int(re.search(r'Build completed successfully \((\d+) jobs\)',Path(prefix+'-full.log').read_text())[1]),'crate_proof_jobs':1171,'runtime_pass_fail_error':[4672,0,0],'known_nonrunnable':7,'runtime_family_counts_preserved':True,'encoder_identical_differ':[1292,0],'both_E2E_accepted_rejected':[1150,0],'both_E2E_identity_stage_reports_byte_identical_to_baseline':True,'all420_comparison_source_hashes_unchanged':True}
report['full_gate_logs']={kind:{'path':prefix+'-'+kind+'.log','sha256':sha(prefix+'-'+kind+'.log')} for kind,_,_ in checks};report['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
receipt.write_text(json.dumps(report,indent=2)+'\n');print('PASS',report['full_gates'],flush=True)
