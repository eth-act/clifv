from pathlib import Path
import subprocess as sp,time,os,signal,json,hashlib,datetime
priority=432059;sched=1763255;out=Path('/tmp/stock-mixed-after-source-sink');out.mkdir(exist_ok=True)
def report(state,**kw):
 j={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':os.getpid(),'state':state,'priority':priority,'scheduler':sched,**kw};(out/'progress.json').write_text(json.dumps(j,indent=2)+'\n');print(json.dumps(j),flush=True)
report('waiting_for_exact_source_sink_priority_controller')
while Path(f'/proc/{priority}/cmdline').exists():
 assert b'stock-source-sink-priority.py' in Path(f'/proc/{priority}/cmdline').read_bytes()
 time.sleep(1)
j=json.loads(Path('/tmp/stock-source-sink-priority/progress.json').read_text())
assert j['state']=='normal_build_passed',j
p=Path(j['log']);assert hashlib.sha256(p.read_bytes()).hexdigest()==j['log_sha256']
assert b'stock-execute-scheduler.py' in Path(f'/proc/{sched}/cmdline').read_bytes()
stopped=False
try:
 os.kill(sched,signal.SIGSTOP);stopped=True
 report('running_bounded_normal_mixed_batch44_after_verified_source_sink')
 with (out/'batch.log').open('w') as f:r=sp.run(['python3','/tmp/stock-mixed-normal-modules-batch44.py'],stdout=f,stderr=sp.STDOUT)
 assert r.returncode==0,('batch44_failed',r.returncode)
 report('batch44_terminal',receipt='/tmp/stock-mixed-current-main-normal-modules-batch44/receipt.json')
finally:
 if stopped:os.kill(sched,signal.SIGCONT)
 print('primary scheduler resumed',flush=True)
