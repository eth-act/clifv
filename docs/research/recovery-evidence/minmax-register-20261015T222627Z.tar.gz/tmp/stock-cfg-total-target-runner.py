from pathlib import Path
import subprocess,os,json,datetime
root=Path('/home/lee/clifv/.worktrees/driver-proof-resume')
env=dict(os.environ,LEAN_NUM_THREADS='2',FV_MEMCAP='20G')
with Path('/tmp/stock-cfg-total-witness.log').open('w') as log:
 r=subprocess.run(['scripts/memcap.sh','/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin/lake','build','FV.Backend.Proof.StockCfgTotalWitness'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
Path('/tmp/stock-cfg-total-target-exit.json').write_text(json.dumps({'exit_code':r.returncode,'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})+'\n')
