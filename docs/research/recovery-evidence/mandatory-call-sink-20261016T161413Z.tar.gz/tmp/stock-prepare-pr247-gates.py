from pathlib import Path
import json,ast
source=Path('/tmp/stock-pr246-gates.py').read_text();s=source.replace('stock-pr246','stock-pr247').replace("expected='44abfd79cbe4cda5ed868054b7f9e166152cf709';pr=246","expected='e5a9cd6ce7a339ffab9fc6b0a26d574296d3f8de';pr=247")
# Preserve the canonical queue hold across a successful PR246 -> PR247 handoff;
# no restart or intervening writer may invalidate the exact PR246 warm cache.
old="old=proc(controller);assert old and old['state'] not in ['T','t','Z'] and 'python3 /tmp/stock-coherent-serial-build.py' in old['cmdline'],old\n previous=json.loads(leasePath.read_text()) if leasePath.exists() else None\n assert not previous or previous['state']=='released',previous\n os.kill(controller,signal.SIGSTOP);held=True"
new="""old=proc(controller);assert old and old['state'] in ['T','t'] and 'python3 /tmp/stock-coherent-serial-build.py' in old['cmdline'],old
 previous=json.loads(leasePath.read_text());assert previous['state']=='held_for_review' and previous['pr']==246 and previous['worker_finished']
 oldWorker=proc(previous['worker_pid']);assert not oldWorker or oldWorker['state']=='Z'
 first=json.loads(Path('/tmp/stock-pr246-gates-receipt.json').read_text());assert first['success'] and not first['trust_review_required']
 completion=json.loads(Path('/tmp/stock-pr246-completion-audit.json').read_text());assert completion['success_pending_MCP_provenance_review']
 mcp=json.loads((canon/'docs/research/stock-pr246-mcp-audit.json').read_text());assert mcp['success'] and mcp['expected_and_actual_union_axioms_match']
 firstPR=json.loads(sp.check_output(['gh','pr','view','246','--json','state,mergeCommit'],text=True,cwd=view));assert firstPR['state']=='MERGED'
 held=True"""
assert old in s;s=s.replace(old,new)
old="affected=(set(f['affected'])&set(modules))|incompatible|{m for m in modules if not (canon/'.lake/build/lib/lean'/Path(m.replace('.','/')+'.olean')).exists()}\n needed=[m for m in order if m in affected and not (m in completed and m not in incompatible)]"
new="""# Exact PR246 gates finished under this SAME continuously held cache lease.
 # Rebuild only the PR247 source/import changes and missing artifacts; final
 # --rehash FV/FVTest/tools independently checks every cached dependency.
 p1=json.loads(Path('/tmp/stock-pr246-gates-inputs.json').read_text())
 changedFromP1={m for m,p in modules.items() if p1['sources'].get(str(p.relative_to(view)))!=sha(p)}
 refresh=set(changedFromP1)
 for m in order:
  if any(d in refresh for d in imports[m]):refresh.add(m)
 affected=refresh|{m for m in modules if not (canon/'.lake/build/lib/lean'/Path(m.replace('.','/')+'.olean')).exists()}
 needed=[m for m in order if m in affected]"""
assert old in s;s=s.replace(old,new)
s=s.replace("core=json.loads(Path('/tmp/stock-delivery-core-paths.json').read_text())", "core=json.loads(Path('/tmp/stock-delivery-pr247-paths.json').read_text())")
s=s.replace("assert lease['pr']==pr and lease['state']", "assert lease['pr']==pr and lease['state']")
# Save the preceding lease in the new durable owner record.
s=s.replace("'release_command':'python3 /tmp/stock-pr247-gates.py --release'", "'release_command':'python3 /tmp/stock-pr247-gates.py --release','previous_PR246_lease':previous")
ast.parse(s);Path('/tmp/stock-pr247-gates.py').write_text(s)
review=json.loads(Path('/home/lee/clifv/.worktrees/driver-proof-resume/docs/research/stock-pr247-source-review.json').read_text());Path('/tmp/stock-delivery-pr247-paths.json').write_text(json.dumps({'paths':sorted(review['source_sha256']),'base':review['base'],'head':review['head']},indent=2)+'\n')
completion=Path('/tmp/stock-pr246-completion-audit.py').read_text().replace('stock-pr246','stock-pr247').replace("expected='44abfd79cbe4cda5ed868054b7f9e166152cf709'", "expected='e5a9cd6ce7a339ffab9fc6b0a26d574296d3f8de'").replace("lease['pr']==246","lease['pr']==247").replace("'view','246'","'view','247'").replace("'pr':246","'pr':247").replace("Path('/tmp/stock-delivery-core-paths.json')","Path('/tmp/stock-delivery-pr247-paths.json')")
completion=completion.replace("pr['baseRefOid']=='032d576442e48aeb5de9062103c970d18b8d0739'", "pr['baseRefOid']==json.loads(sp.check_output(['gh','pr','view','246','--json','mergeCommit'],cwd=view,text=True))['mergeCommit']['oid']")
ast.parse(completion);Path('/tmp/stock-pr247-completion-audit.py').write_text(completion)
bundle=Path('/tmp/stock-pr246-mcp-bundle.py').read_text().replace('stock-pr246','stock-pr247').replace('pr246_bundle','pr247_bundle');ast.parse(bundle);Path('/tmp/stock-pr247-mcp-bundle.py').write_text(bundle)
print('Prepared PR247 gate/review/MCP scripts; NOT started. Handoff requires completed exact PR246 gates, completion review, successful MCP and actual squash merge. Cache stays exclusive; only source/import changes rebuilt before full --rehash gates.')
