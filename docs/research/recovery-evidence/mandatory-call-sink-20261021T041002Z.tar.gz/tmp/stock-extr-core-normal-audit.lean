import FV.Backend.Proof.StockLogicalExtrSourceTransfer
#print axioms Backend.Stock.Proof.LogicalExtr.selected_root_values
#print axioms Backend.Stock.Proof.LogicalExtr.record_values
#print axioms Backend.Stock.Proof.LogicalExtr.available_values
#print axioms Backend.Stock.Proof.LogicalExtr.source_operands
#print axioms Backend.Stock.Proof.LogicalExtr.available_source
#print axioms Backend.Stock.Proof.LogicalExtr.source_from_step
