from pathlib import Path
import os,signal,subprocess as sp,time,json,datetime,traceback
root=Path('/tmp/stock-logical-record-source-priority');root.mkdir(exist_ok=True)
view=Path('/home/lee/clifv/.worktrees/stock-mixed-production');sched=2201390
state=root/'progress.json'
def report(status,**fields):
 d={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':os.getpid(),'state':status,**fields};state.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)
def live_children():
 p=Path(f'/proc/{sched}/task/{sched}/children')
 children=p.read_text().split() if p.exists() else []
 return [int(p) for p in children if Path('/proc/'+p+'/stat').exists() and Path('/proc/'+p+'/stat').read_text().split()[2]!='Z']
env=dict(os.environ,FV_LAKE_CACHE='/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2')
env['PATH']='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:'+env['PATH']
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:8])
held=False
try:
 cmd=Path(f'/proc/{sched}/cmdline').read_bytes().decode().replace('\0',' ')
 assert '/tmp/stock-execute-scheduler.py' in cmd
 os.kill(sched,signal.SIGSTOP);held=True
 report('draining_existing_jobs',scheduler=sched)
 while live_children():time.sleep(3)
 report('normal_build',scheduler=sched,existing_jobs_drained=True)
 with (root/'build.log').open('w') as out:
  result=sp.run(['python3','/tmp/stock-execute-scheduler.py','--budget','16G','--max-jobs','2','--max-cap','16G','--default-cap','8G','--out',str(root/'modules'),'--only',str(root/'targets.txt'),'FV.Backend.Proof.StockLogicalExtrSourceTransfer'],cwd=view,env=env,stdout=out,stderr=sp.STDOUT)
 report('normal_build_passed' if result.returncode==0 else 'normal_build_failed',exit_status=result.returncode,log=str(root/'build.log'))
except BaseException as e:
 report('controller_error',error=repr(e),traceback=traceback.format_exc());raise
finally:
 if held:
  os.kill(sched,signal.SIGCONT)
  (root/'arithmetic-resumed.json').write_text(json.dumps({'scheduler':sched,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'resumed':True})+'\n')
