from pathlib import Path
import os,signal,subprocess as sp,time,json,datetime
root=Path('/tmp/stock-extr-core-normal-audit');root.mkdir(exist_ok=True);sched=2201390
held=False
try:
 assert '/tmp/stock-execute-scheduler.py' in Path(f'/proc/{sched}/cmdline').read_bytes().decode().replace('\0',' ')
 os.kill(sched,signal.SIGSTOP);held=True
 while True:
  ids=Path(f'/proc/{sched}/task/{sched}/children').read_text().split()
  live=[p for p in ids if Path('/proc/'+p+'/stat').exists() and Path('/proc/'+p+'/stat').read_text().split()[2]!='Z']
  if not live:break
  time.sleep(2)
 env=dict(os.environ,FV_MEMCAP='4G',FV_LAKE_CACHE='/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2');env['PATH']='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:'+env['PATH']
 with (root/'axioms.log').open('w') as out:
  r=sp.run(['scripts/memcap.sh','lake','env','lean','--root=/tmp','/tmp/stock-extr-core-normal-audit.lean'],cwd='/home/lee/clifv/.worktrees/stock-mixed-production',env=env,stdout=out,stderr=sp.STDOUT)
 (root/'result.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_status':r.returncode,'log':str(root/'axioms.log')})+'\n')
finally:
 if held:os.kill(sched,signal.SIGCONT)
