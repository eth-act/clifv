Existing E2E consumers require literal legacy-constructor output, preventing a Stock class with different diagnostic history from using the existing source-to-machine proof chain. Add contracts for the actual source/SSA-validated lowering output, concrete machine/world/non-interference composition in both cleanup modes, a common production contract, and exact callback-result provenance.

Retain all old contracts and theorem variants. No existing Lean module is modified. Successful actual Stock witnesses cover all six D0 configurations, arbitrary names/run metadata/allocator answers and both cleanup modes. Concrete legacy try-call and live TLS compilations exercise the positive helper premises in both modes. New theorem modules disable implicit-variable inference.

This is the consumer interface for the next production class, not another driver activation: #328's entry-return class remains the shipped selection. Actual whole-program checker/linker/binary/generated-proof consumers and the two-block Rust prologue activation follow under #140. The full original simulation/completeness/integration goal remains open.

Validation on frozen source `bd15409a`, reconciled with current main `6a1f7d51`; terminal receipt in `docs/research/stock-actual-output-consumer-progress.json`. Final changes after validation update documentation only.

- Full author scheduler: **2335/2335 modules**, 1 rebuilt/2334 reused; library and affected-tool replay **2899 jobs**.
- Public trust audit: 62/62 roots; the 54 compiler/universal Stock roots use only standard axioms. Fixed native witnesses are explicitly marked.
- One bundled MCP source/axiom check of `backend_correct_world_niX_production`: standard-three, no warnings.
- All **11/11** axiom-audit files pass; **124 owned constants** use standard axioms only.
- Both E2E modes: **1154 accepted/0 rejected**, all original **1150 identities and ordered stages preserved**.
- `link-check`: both saved default Lean-linked verified binary bundles pass in their matching cleanup mode. Both actual mixed Stock/legacy generated proofs (plain and cleanup) pass.
- Existing Lean source is unchanged; no lowering/encoding/regalloc/CLIF/runtime-driver/cargo inputs changed, so those runtime gates are not required for this proof-consumer packet under TO-PROVE§7.

Resource budget: aggregate16GiB/max3jobs, one warm cache, no new worktree. Current source is backed up remotely; canonical dirty source, branches and unique evidence are preserved. #140 coordination: https://github.com/eth-act/clifv/issues/140#issuecomment-6278959544 .
