from pathlib import Path
import os,subprocess as sp,json,datetime,hashlib,traceback
view=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');canon=Path('/home/lee/clifv/.worktrees/driver-proof-resume');root=Path('/tmp/stock-consumer-per-pr-gates');root.mkdir(exist_ok=True);state=root/'progress.json';logs={}
head=sp.check_output(['git','rev-parse','HEAD'],cwd=view,text=True).strip()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def inputs():
 return {str(p.relative_to(view)):sha(p) for d in ['FV','FVTest','examples/fv-demo/src','scripts/audit'] for p in (view/d).rglob('*') if p.is_file() and p.suffix in ['.lean','.rs']}
frozen_sources=inputs();(root/'inputs.json').write_text(json.dumps({'head':head,'sources':frozen_sources},indent=2)+'\n')
env=dict(os.environ);env.update(PATH='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:/home/lee/.cargo/bin:/home/lee/.local/share/clifv-test-tools/usr/bin:/home/lee/.rustup/toolchains/nightly-2026-09-26-x86_64-unknown-linux-gnu/lib/rustlib/x86_64-unknown-linux-gnu/bin:'+str(view/'rust/target/release')+':'+env['PATH'],FV_ROOT=str(view),FV_AR='/home/lee/.local/share/clifv-test-tools/usr/bin/llvm-ar',FV_OBJCOPY='/home/lee/.local/share/clifv-test-tools/usr/bin/llvm-objcopy',FV_LAKE_CACHE=str(canon/'.lake/artifact-cache'),FV_MEMCAP='8G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',CARGO_BUILD_JOBS='2',CLIF_NATIVE_QEMU='/home/lee/.local/share/clifv-test-tools/usr/bin/qemu-aarch64-static',LLVM_MC='/home/lee/.local/share/clifv-test-tools/usr/bin/llvm-mc',PYTHONPATH=str(view/'scripts'))
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:8])
def report(status,**kw):
 d={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':status,'pid':os.getpid(),'head':head,'logs':logs,**kw};state.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items() if k!='logs'}),flush=True)
def frozen():
 assert sp.check_output(['git','rev-parse','HEAD'],cwd=view,text=True).strip()==head
 assert inputs()==frozen_sources,'source changed during gates'
def run(name,args,cwd=view):
 frozen();p=root/(name+'.log');report('running',phase=name,log=str(p))
 with p.open('w') as f:
  command=args if args[:2]==['python3','/tmp/stock-execute-scheduler.py'] else [str(view/'scripts/memcap.sh'),*args]
  r=sp.run(command,cwd=cwd,env=env,stdout=f,stderr=sp.STDOUT)
 assert r.returncode==0,(name,r.returncode,str(p));frozen();logs[name]={'path':str(p),'sha256':sha(p)};return p
try:
 run('all-modules',['python3','/tmp/stock-execute-scheduler.py','--budget','16G','--max-jobs','3','--max-cap','16G','--default-cap','8G','--others-by-usage','--out',str(root/'all-modules'),'FV','FVTest'])
 run('library-and-affected-tools',['lake','build','FV','FVTest','lean-e2e-check','link-check'])
 run('all-axiom-audits',['python3','scripts/axiom-audit.py','--log-dir',str(root/'axiom-audit')])
 run('owned-constants',['lake','env','lean','--root=/tmp','/tmp/stock-consumer-owned-constants.lean'])
 parity={}
 def ids(path):
  fs=json.loads(path.read_text())['functions'];d={(f['file'],f['index'],f['function']):tuple(f['stages']) for f in fs};assert len(d)==len(fs);return d
 for label,flags,previous in [('e2e',[],'legacy-dead-cleanup-final-e2e-identities.json'),('legacy-e2e',['--no-dead-cleanup'],'legacy-dead-cleanup-final-legacy-e2e-identities.json')]:
  actual=root/(label+'-identities.json')
  run(label,['lake','exe','lean-e2e-check',*flags,'--identity-report',str(actual)])
  a=ids(Path('/tmp')/previous);b=ids(actual);assert len(a)==1150 and a.keys()<=b.keys();assert all(a[k]==b[k] for k in a)
  parity[label]={'original':len(a),'current':len(b),'all_original_identities_and_ordered_stages_preserved':True}
 (root/'identity-stage-parity.json').write_text(json.dumps(parity,indent=2)+'\n')
 bundles=sorted((view/'examples/fv-demo/target/fv/plain-leanlink-verified-leanld/tmp').glob('*/fv-link.json'))
 assert bundles,'verified fv-demo source bundle missing'
 for i,p in enumerate(bundles):
  run(f'link-check-{i}',['lake','exe','link-check',str(p.parent)])
 generated=Path('/tmp/stock-d0-linked-fixture')
 leanpath=sp.check_output(['lake','env','printenv','LEAN_PATH'],cwd=view,env=env,text=True).strip()
 env['LEAN_PATH']=str(generated)+':'+leanpath
 for name in ['StockD0MixedPlain','StockD0MixedCleanup']:
  p=generated/'Crates'/(name+'.lean');assert p.is_file()
  run('generated-'+name,['lean','--root='+str(generated),'-o',str(p.with_suffix('.olean')),str(p)])
 report('per_pr_gates_passed',identity_stage_parity=parity,remaining='Fetch current main, reconcile if needed, open non-draft implementation PR and author squash promptly. Full original #140 remains active.')
except BaseException as e:
 report('failed',error=repr(e),traceback=traceback.format_exc());raise
