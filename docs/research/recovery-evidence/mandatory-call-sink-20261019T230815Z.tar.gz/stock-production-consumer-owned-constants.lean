import Lean
import FV.E2E.LinkProduction
import FV.E2E.ActualPipelineCheck
import FV.E2E.ActualBinCheck
import FV.E2E.ActualCompilerModes
import FV.Link.ActualImage
import FV.Link.ActualCompilerImage
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let targets : Array String := #["FV.E2E.LinkProduction","FV.E2E.ActualPipelineCheck","FV.E2E.ActualBinCheck","FV.E2E.ActualCompilerModes","FV.Link.ActualImage","FV.Link.ActualCompilerImage"]
  let mut count : Nat := 0
  for (name, _) in env.constants.toList do
    let some i := env.getModuleIdxFor? name | continue
    unless targets.contains env.header.moduleNames[i]!.toString do continue
    let axioms ← collectAxioms name
    for ax in axioms do
      unless #[``propext, ``Classical.choice, ``Quot.sound].contains ax do
        throwError "disallowed axiom {ax} in {name}"
    count := count + 1
  unless count > 0 do throwError "empty consumer constant audit"
  logInfo m!"CONSUMER_CONSTANTS_STANDARD_ONLY {count}"
