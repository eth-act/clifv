import StockTryResolvedSource
import FV.Backend.Proof.PerEdgeSpillEntryFixture
namespace Backend.Stock.Proof.TryIndirectAliasObservationDraft
open Backend.Proof Backend.Proof.Driver TryResolvedRunsDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 16000000
/-- The actual indirect source callee has a nonidentity final alias, so its
final-renamed execution witness exercises a real changed target register. -/
theorem observed : (Stock.lower (SpillEntryFixture.function true)).toOption.any (fun r => keyMap r 193 != 193) = true := by
  decide +kernel
end Backend.Stock.Proof.TryIndirectAliasObservationDraft
