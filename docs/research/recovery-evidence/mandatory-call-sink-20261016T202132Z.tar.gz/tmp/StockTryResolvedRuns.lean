import StockTryStopRename
import StockTryResultDefsFixed
import StockTryDirectSourceRun
import StockTryIndirectSourceRun
namespace Backend.Stock.Proof.TryResolvedRunsDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open TryStopRenameDraft TryResultDefsFixedDraft TryRetsTotalDraft TryResultMapDraft
open TryDirectSourceRunDraft TryIndirectSourceRunDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
/-- Actual alias map used by Stock's returned instruction stream. -/
def resolver (result : Result) := Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1)
abbrev keyMap (result : Result) := aliasNum result.final.alias
/-- Execution of the final-renamed retained branch, with returned world and
normal values through its actual operand update and actual final source keys. -/
def ResolvedNormalBranch (result : Result) (step : Step) (isem : Sem) (MR : MemRelT)
    (fr : Clif.Frame) (rho : Nat → CV) (w : Arm.ArmState) (base normal : Nat)
    (rvals : List Clif.Val) (cm' : Clif.Mem) : Prop :=
  ∃ (k : Nat) (i : MInst) (ops : Array Operand) (atCall : Nat → CV) (world : Arm.ArmState)
    (outs : List CV) (finalWorld : Arm.ArmState),
    seqRun isem (step.emitted.toList.map (·.mapRegs (resolver result))) rho w =
      some (.stop k i ops atCall world outs finalWorld (.goto normal)) ∧ MR fr.slots cm' finalWorld ∧
      ∀ (j : Nat) (v : Clif.Val),rvals[j]? = some v →
        VHolds v (vdefUpd ops outs atCall (keyMap result (base+j)))
private theorem alias_ren (result : Result) : VRenaming (resolver result) (keyMap result) := by
  refine ⟨fun n c => resolve_vreg _ _ n c,?_⟩
  intro r notVirtual
  cases r with
  | vreg n c => exact False.elim (notVirtual n c rfl)
  | _ => rfl
private theorem last_index {V W : Type} {sem : ISem V W} {pre : List MInst} {i : MInst}
    (apart : ∀ m ∈ pre,m ≠ i) {rho : Nat → V} {w : W} {k : Nat} {ops : Array Operand}
    {atCall : Nat → V} {world : W} {outs : List V} {finalWorld : W} {ctl : Ctl}
    (run : seqRun sem (pre ++ [i]) rho w = some (.stop k i ops atCall world outs finalWorld ctl)) : k = pre.length := by
  induction pre generalizing rho w k with
  | nil =>
    rcases seqRun_cons_stop run with first | ⟨k',op,output,world',index,operands,execute,length,rest⟩
    · exact first.1
    · simp only [seqRun,Option.some.injEq] at rest
      cases rest
  | cons m pre ih =>
    rcases seqRun_cons_stop run with first | ⟨k',op,output,world',index,operands,execute,length,rest⟩
    · exact False.elim (apart m (List.mem_cons_self ..) first.2.1.symm)
    · have inner := ih (fun m member => apart m (List.mem_cons_of_mem _ member)) rest
      simp only [List.length_cons]
      omega
private theorem fixed_call {f : Clif.Function} {result : Result} (lowered : Stock.lower f = .ok result)
    {owner base count : Nat}
    (layout : result.initial.tryRegs[owner]! = (reservedReturns base count,reservedPayloads base count))
    (dest : CallDest) (L : List (Nat × Reg)) (info : TryInfo)
    (form : (∃ name,dest = .sym name) ∨ (∃ target,dest = .reg (.vreg target .int))) :
    ∀ d ∈ vdefs (.tryCall ⟨dest,retPairs L,callDefs (resultDefs base count)⟩ info),keyMap result d = d := by
  intro d defined
  have same (call : CallInfo) : vdefs (.tryCall call info) = vdefs (.call call) := by
    unfold vdefs
    rw [operands_tryCall_call]
  rw [same] at defined
  rcases form with ⟨name,rfl⟩ | ⟨target,rfl⟩
  · rw [vdefs_call_sym] at defined
    simp only [resultDefs,List.map_map,Function.comp_def,List.mem_map,List.mem_range] at defined
    obtain ⟨j,inside,rfl⟩ := defined
    exact stock_lower_try_result_keys_fixed lowered layout j inside
  · rw [vdefs_call_reg] at defined
    simp only [resultDefs,List.map_map,Function.comp_def,List.mem_map,List.mem_range] at defined
    obtain ⟨j,inside,rfl⟩ := defined
    exact stock_lower_try_result_keys_fixed lowered layout j inside
/-- Final-renamed direct branch execution from the actual raw whole-driver
receipt. All call definitions are fixed internally; no alias/use certificate. -/
theorem stock_direct_try_run_resolved {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) {isem : Sem} (driver : DriverSem isem)
    {label bi : Nat} {b : Clif.Block} {ext : Clif.ExtFunc} {MR : MemRelT} {fr : Clif.Frame}
    {rho : Nat → CV} {w : Arm.ArmState} {rvals : List Clif.Val} {cm' : Clif.Mem}
    (raw : DirectTryRun f result label bi b ext isem MR fr (fun n => rho (keyMap result n)) w rvals cm')
    (results : rvals.length = ext.sig.returns.length) :
    ResolvedNormalBranch result raw.source.branch.step isem MR fr rho w raw.base raw.info.handlers.length rvals cm' := by
  have execute := raw.run
  rw [raw.code,List.toList_toArray] at execute
  have noDefs : ∀ m ∈ (stackEnts ((raw.locs.zip raw.ns).zip raw.bytes)).map argStore,vdefs m = [] := by
    intro m member
    obtain ⟨e,_,rfl⟩ := List.mem_map.mp member
    exact vdefs_argStore e
  have fixed := fixed_call lowered raw.layout (.sym ext.name) (regPairsOf ((raw.locs.zip raw.ns).zip raw.bytes))
    {raw.info with rets := ext.sig.returns.length} (.inl ⟨ext.name,rfl⟩)
  obtain ⟨next,renamed,post⟩ := stock_no_def_prefix_stop_rename (alias_ren result)
    (driver.rename _ _ (alias_ren result)) noDefs fixed execute
  refine ⟨((stackEnts ((raw.locs.zip raw.ns).zip raw.bytes)).map argStore).length,
    (MInst.tryCall ⟨.sym ext.name,retPairs (regPairsOf ((raw.locs.zip raw.ns).zip raw.bytes)),callDefs (resultDefs raw.base ext.sig.returns.length)⟩ {raw.info with rets := ext.sig.returns.length}).mapRegs (resolver result),
    ((retOps (regPairsOf ((raw.locs.zip raw.ns).zip raw.bytes)) ++ callDefOps (resultDefs raw.base ext.sig.returns.length)).toArray.map (rnOp (keyMap result))),next,raw.atCall,raw.outs,raw.finalWorld,?_,raw.returnedWorld,?_⟩
  · rw [raw.code,List.toList_toArray]
    exact renamed
  · intro j v atValue
    have inside : j < ext.sig.returns.length := by have bound := (List.getElem?_eq_some_iff.mp atValue).1; omega
    have fixedKey : keyMap result (raw.base+j) = raw.base+j := by
      have atKey := stock_lower_try_result_keys_fixed lowered raw.layout j (Nat.lt_of_lt_of_le inside (Nat.le_max_left _ _))
      simpa only [keyMap,resultKey,if_pos inside] using atKey
    have value := raw.normalValues j v atValue
    dsimp only [keyMap] at fixedKey value ⊢
    rw [fixedKey] at value ⊢
    have sameUpdate := post _ fixedKey
    dsimp only [keyMap] at sameUpdate
    rw [← sameUpdate]
    exact value
/-- Final-renamed true-indirect branch execution from its same raw receipt.
The actual stop instruction identifies the last call internally. -/
theorem stock_indirect_try_run_resolved {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) {isem : Sem} (driver : DriverSem isem)
    {label bi : Nat} {b : Clif.Block} {sig : Clif.Signature} {MR : MemRelT} {fr : Clif.Frame}
    {rho : Nat → CV} {w : Arm.ArmState} {rvals : List Clif.Val} {cm' : Clif.Mem}
    (raw : IndirectTryRun f result label bi b sig isem MR fr (fun n => rho (keyMap result n)) w rvals cm')
    (results : rvals.length = sig.returns.length) :
    ResolvedNormalBranch result raw.source.branch.step isem MR fr rho w raw.base raw.info.handlers.length rvals cm' := by
  have execute := raw.run
  rw [raw.code,List.toList_toArray] at execute
  have apart : ∀ m ∈ (stackEnts ((raw.locs.zip raw.ns).zip raw.bytes)).map argStore,
      m ≠ .tryCall ⟨.reg (.vreg raw.target .int),retPairs (regPairsOf ((raw.locs.zip raw.ns).zip raw.bytes)),
        callDefs (resultDefs raw.base sig.returns.length)⟩ {raw.info with rets := sig.returns.length} := by
    intro m member
    obtain ⟨e,_,rfl⟩ := List.mem_map.mp member
    intro impossible
    cases impossible
  have index := last_index apart execute
  rw [index] at execute
  have noDefs : ∀ m ∈ (stackEnts ((raw.locs.zip raw.ns).zip raw.bytes)).map argStore,vdefs m = [] := by
    intro m member
    obtain ⟨e,_,rfl⟩ := List.mem_map.mp member
    exact vdefs_argStore e
  have fixed := fixed_call lowered raw.layout (.reg (.vreg raw.target .int)) (regPairsOf ((raw.locs.zip raw.ns).zip raw.bytes))
    {raw.info with rets := sig.returns.length} (.inr ⟨raw.target,rfl⟩)
  obtain ⟨next,renamed,post⟩ := stock_no_def_prefix_stop_rename (alias_ren result)
    (driver.rename _ _ (alias_ren result)) noDefs fixed execute
  refine ⟨((stackEnts ((raw.locs.zip raw.ns).zip raw.bytes)).map argStore).length,
    (MInst.tryCall ⟨.reg (.vreg raw.target .int),retPairs (regPairsOf ((raw.locs.zip raw.ns).zip raw.bytes)),callDefs (resultDefs raw.base sig.returns.length)⟩ {raw.info with rets := sig.returns.length}).mapRegs (resolver result),
    ((tgtOp raw.target :: (retOps (regPairsOf ((raw.locs.zip raw.ns).zip raw.bytes)) ++ callDefOps (resultDefs raw.base sig.returns.length))).toArray.map (rnOp (keyMap result))),next,raw.atCall,raw.outs,raw.finalWorld,?_,raw.returnedWorld,?_⟩
  · rw [raw.code,List.toList_toArray]
    exact renamed
  · intro j v atValue
    have inside : j < sig.returns.length := by have bound := (List.getElem?_eq_some_iff.mp atValue).1; omega
    have fixedKey : keyMap result (raw.base+j) = raw.base+j := by
      have atKey := stock_lower_try_result_keys_fixed lowered raw.layout j (Nat.lt_of_lt_of_le inside (Nat.le_max_left _ _))
      simpa only [keyMap,resultKey,if_pos inside] using atKey
    have value := raw.normalValues j v atValue
    dsimp only [keyMap] at fixedKey value ⊢
    rw [fixedKey] at value ⊢
    have sameUpdate := post _ fixedKey
    dsimp only [keyMap] at sameUpdate
    rw [← sameUpdate]
    exact value
end Backend.Stock.Proof.TryResolvedRunsDraft
