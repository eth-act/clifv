import os,subprocess as sp,pathlib,sys,json,hashlib,datetime
root=pathlib.Path('/home/lee/clifv/.worktrees/driver-proof-resume');env=dict(os.environ,OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',LEAN_PATH='/tmp/stock-try-rule-inputs:/tmp',FV_MEMCAP='8G')
for m in sys.argv[1:]:
 p=pathlib.Path('/tmp/'+m+'.lean');obj=p.with_suffix('.olean');obj.unlink(missing_ok=True)
 with p.with_suffix('.log').open('w') as f:r=sp.run([str(root/'scripts/memcap.sh'),'/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin/lean','--root=/tmp',str(p),'-o',str(obj)],cwd=root,env=env,stdout=f,stderr=sp.STDOUT)
 sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
 p.with_suffix('.check.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actual_exit':r.returncode,'source_sha256':sha(p),'object_sha256':sha(obj) if obj.exists() else None,'log_sha256':sha(p.with_suffix('.log'))},indent=2)+'\n')
 print(m,'ACTUAL_RC',r.returncode,flush=True);print(p.with_suffix('.log').read_text()[:8000] if r.returncode else 'object and actual exit0 captured',flush=True)
 if r.returncode:raise SystemExit(r.returncode)
 assert obj.exists()
