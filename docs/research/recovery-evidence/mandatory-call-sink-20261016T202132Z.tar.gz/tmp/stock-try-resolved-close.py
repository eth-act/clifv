from pathlib import Path
import json,hashlib,re,datetime,tarfile,shutil
root=Path('/home/lee/clifv/.worktrees/driver-proof-resume');docs=root/'docs/research'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
now=datetime.datetime.now(datetime.timezone.utc);stamp=now.strftime('%Y%m%dT%H%M%SZ')
batch=json.loads(Path('/tmp/stock-try-resolved-batch.json').read_text());old=json.loads((docs/'stock-try-rename-scratch.json').read_text())
sets={m.group(1):sorted(x.strip() for x in m.group(2).split(',') if x.strip()) for m in re.finditer(r"'([^']+)' depends on axioms:\s*\[([^]]*)\]",Path('/tmp/stock-try-resolved-combined-axioms.log').read_text())}
for m in re.finditer(r"'([^']+)' does not depend on any axioms",Path('/tmp/stock-try-resolved-combined-axioms.log').read_text()):sets[m.group(1)]=[]
for n,a in old['normal_audit']['sets'].items():assert sorted(a)==sets[n],n
allowed={'propext','Classical.choice','Quot.sound'}
for n in batch['public_roots']+batch['models']:assert set(sets[n])<=allowed,n
constants=[json.loads(line.split('DELIVERY_CONSTANT ',1)[1]) for line in Path('/tmp/stock-try-resolved-all-constants.log').read_text().splitlines() if line.startswith('DELIVERY_CONSTANT ')]
assert constants
for n,a in constants:assert set(a)<=allowed,n
mods={}
for m in batch['modules']:
 p=Path('/tmp')/m;check=json.loads(p.with_suffix('.check.json').read_text());assert check['actual_exit']==0
 rec={}
 for key,ext in [('source','.lean'),('object','.olean'),('log','.log'),('check','.check.json')]:
  f=p.with_suffix(ext);rec[key]=str(f);rec[key+'_sha256']=sha(f)
 for k in ['source','object','log']:assert rec[k+'_sha256']==check[k+'_sha256']
 assert not re.search(r'\b(sorry|admit|axiom|trace_state|native_decide)\b',p.with_suffix('.lean').read_text())
 mods[m]=rec
prior={}
for name in ['source-execution-x','try-source','try-context','try-rule','try-rets','try-reservation','try-outgoing','try-values','try-emitted','try-machine','try-got','try-indirect','try-rename']:
 d=json.loads((docs/f'stock-{name}-scratch.json').read_text())
 for m,rec in d['modules'].items():
  for k in ['source','object','log']:assert sha(rec[k])==rec[k+'_sha256'],(m,k)
  prior[m]=rec
freeze=json.loads(Path('/tmp/stock-coherent-build-inputs.json').read_text())
for group in ['source_sha256','validation_script_sha256']:
 for p,h in freeze[group].items():assert sha(root/p)==h,p
progress=json.loads(Path('/tmp/stock-pr246-gates-progress.json').read_text());progress.pop('completed_phases',None)
remaining=old['remaining_checklist']
for item in remaining:
 if 'Mapped/final-alias source frame' in item['requirement']:
  item['state']='All reserved result keys fixed. Actual final-renamed direct and indirect retained branch execution with original semantic contracts/held final-source args now proved, including returned world and actual renamed operand result values. Whole original-source wrappers construct raw receipts internally. GOT final-renamed fresh-target separation, available-source frame/write noninterference and block/whole composition remain open.'
remaining.append({'requirement':'Actual final-renamed direct/true-indirect retained branch execution and normal result/world transfer','state':'Proved and completely witnessed through original compiler/prepare/forced checkedfallback/checker/physical pipelines and source17 runs. Actual indirect source callee changes register under final alias map, verified by kernel observation. No-def argument prefix plus stopped-call renaming avoids new use-image acceptance certificates. GOT renaming/source frames and whole sim/completeness remain open.'})
receipt={'utc':now.isoformat(),'goal':'Original full #140 ACTIVE/INCOMPLETE; production LEGACY','scope':'Scratch-only additive Stock proofs, not coherent integration or merge-ready','delivery_target':'roughly eight substantive validated squash merges/day; remote backups and cleanup; drafts do not count','modules':mods,'public_roots':batch['public_roots'],'models':batch['models'],'counts':{'modules':len(mods),'public_roots':len(batch['public_roots']),'models':len(batch['models']),'combined_roots_models':len(sets),'previous_preserved':len(old['normal_audit']['sets']),'all_new_module_constants':len(constants)},'normal_audit':{'path':'/tmp/stock-try-resolved-combined-axioms.log','sha256':sha('/tmp/stock-try-resolved-combined-axioms.log'),'sets':sets},'all_constant_audit':{'path':'/tmp/stock-try-resolved-all-constants.log','sha256':sha('/tmp/stock-try-resolved-all-constants.log'),'all_standard_only':True,'count':len(constants)},'previous88_modules_hashes_preserved':list(prior),'canonical2246_source_and_script_freeze_preserved':True,'kernel_resources':'All new modules and both audits actual exit0 / object verified at8GiB through memcap; one heavy delivery worker retained','MCP':'No new calls; bundled provenance audit deferred until coherent integration','active_exact_PR246_validation':progress,'remaining_checklist':remaining}
(docs/'stock-try-resolved-scratch.json').write_text(json.dumps(receipt,indent=2)+'\n')
text=f'''Final-renamed direct and indirect TryCall execution — {now.isoformat()}

Six scratch modules, {len(batch['public_roots'])} public theorem roots and {len(batch['models'])} public models pass actual8GiB kernel checks. The {len(sets)}-root/model audit preserves all550prior exact axiom sets. All {len(constants)} constants in new modules, including private operational helpers, use only standard axioms. All88previous scratch source/object/log hashes and frozen2246canonical sources plus scripts are unchanged. Prior goal turn PROGRESS: internally derived unshared whole payload endpoints/fixed result keys, complete witnesses, audits/archive/verified remote backup.

A no-def argument-store prefix renames under full source register agreement, then the last stopped call renames its reads and output update using internally proved fixed result keys. No caller use-image/disjointness certificate is required for values read BEFORE the final write. Actual stopped instruction identity locates the last indirect call internally. Applying this to actual whole-lowering direct and true-indirect receipts proves final-renamed retained branch execution, normal control, returned world and values through actual renamed vdefUpd and actual final source keys. Whole original-source wrappers construct raw receipts internally from original source/build/input and published semantic contracts. Existing raw and old theorem variants remain unchanged.

Complete original-condition direct and true-indirect compiler/prepare/forced checkedfallback/checker/physical witnesses inhabit original contracts and actual final-renamed runs; real source programs return17. The indirect witness uses an actual nonidentity final callee alias, established by a projection-only kernel observation at8GiB, and places4096 at that actual renamed target. Thus it exercises a changed source-use register, not identity renaming. The broader positive-argument/sret/x8/zero-return/width/handler witness matrix remains open.

Next: GOT final-renamed execution needs internal source-use alias separation from its fresh symbol target (the load writes before the final call). Available original source-frame/DFG/reserved-write noninterference, normal edge parameter copies and source continuation, exact shared payload alias endpoints/exception machine execution remain. These final-renamed local branch theorems do not prove block/whole-driver simulation or completeness. ALL original uncovered family/effect/sinking obligations, original-input context/visitor/static/checker/fallback/physical totality, coherent scratch integration/public/private/compiler/MCP/full/crates/runtime/encoder/BOTH E2E identity-stage gates, production compiler/checker/linker/generated consumers and fresh COMPLETE comparison remain required. Production LEGACY. S10 shared exceptional interfaces stay with @kevaundray #232/#233.

Main rechecked0ec59a028dd3a27911cb22554b3e292b20a5c45f; exact old-head delivery gates remain live under same supervisor3247835, canonical1233457 deliberately held. Reconcile current main and rerun required actual-head gates before squash246/247. Roughly eight substantive validated squash merges/day target. No merge/new worktree/MCP/heavy retry/restarted validation this batch.

See stock-try-resolved-scratch.json for hashed evidence/full remaining checklist.
'''
(docs/'stock-try-resolved-scratch.md').write_text(text)
plan=root/'docs/plans/test-binary-alignment-recovery.md';plan.write_text(plan.read_text()+'\n\n'+text)
files=[]
for rec in mods.values():files.extend(Path(rec[k]) for k in ['source','object','log','check'])
for name in ['stock-try-resolved-combined-axioms','stock-try-resolved-all-constants']:
 for ext in ['.lean','.log','.olean','.check.json']:files.append(Path('/tmp')/(name+ext))
files.extend(Path(p) for p in ['/tmp/stock-try-resolved-batch.json','/tmp/stock-try-rule-inputs.json','/tmp/stock-try-reservation-check.py','/tmp/stock-try-resolved-close.py','/tmp/stock-try-resolved-status44.json','/tmp/stock-try-resolved-status52.json','/tmp/stock-try-resolved-status71.json','/tmp/stock-try-resolved-task140.json'])
files.extend([docs/'stock-try-resolved-scratch.json',docs/'stock-try-resolved-scratch.md',docs/'stock-delivery-main-drift.json',plan])
archive=Path('/home/lee/.clifv-recovery')/(stamp+'-try-resolved')/'checkpoint.tar.gz';archive.parent.mkdir(parents=True)
with tarfile.open(archive,'w:gz',compresslevel=1) as t:
 for p in files:t.add(p,arcname=str(p).lstrip('/'),recursive=False)
with tarfile.open(archive,'r:gz') as t:
 for p in files:assert t.extractfile(str(p).lstrip('/')).read()==p.read_bytes(),p
snapshot=Path('/tmp/stock-try-rule-inputs');size=sum(p.stat().st_size for p in snapshot.rglob('*') if p.is_file());shutil.rmtree(snapshot)
backup={'utc':now.isoformat(),'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(files),'all_members_byte_verified':True,'previous_remote_backup':json.loads((docs/'stock-try-rename-backup.json').read_text())['remote'],'cleanup':{'duplicate_dependency_snapshot_removed':True,'bytes_reclaimed':size,'unique_sources_objects_logs_checks_audits_preserved':True,'one_shared_warm_cache_retained':True,'other_projects_touched':False,'free_bytes':shutil.disk_usage(root).free}}
(docs/'stock-try-resolved-backup.json').write_text(json.dumps(backup,indent=2)+'\n');Path('/tmp/stock-try-resolved-archive-path').write_text(str(archive))
print(json.dumps({'counts':receipt['counts'],'archive':str(archive),'cleanup':backup['cleanup'],'gate':progress},indent=2))
