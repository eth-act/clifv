import FV.Backend.Proof.LowerRename
import FV.Backend.Proof.LowerSeq
import FV.Backend.Proof.IselCmpRun
namespace Backend.Stock.Proof.TryStopRenameDraft
open Backend.Proof Backend.Proof.Driver
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private theorem split_last_stop {V W : Type} {sem : ISem V W} {pre : List MInst} {i : MInst}
    {rho : Nat → V} {w : W} {ops : Array Operand} {atCall : Nat → V} {world : W}
    {outs : List V} {finalWorld : W} {ctl : Ctl}
    (run : seqRun sem (pre ++ [i]) rho w = some (.stop pre.length i ops atCall world outs finalWorld ctl)) :
    seqRun sem pre rho w = some (.fall atCall world) ∧
    seqRun sem [i] atCall world = some (.stop 0 i ops atCall world outs finalWorld ctl) := by
  induction pre generalizing rho w with
  | nil =>
    rcases seqRun_cons_stop run with first | ⟨k,op,output,world',impossible,rest⟩
    · obtain ⟨_,_,_,sameRho,sameWorld,rest⟩ := first
      subst atCall
      subst world
      exact ⟨rfl,run⟩
    · simp only [List.length_nil] at impossible
      omega
  | cons m pre ih =>
    rcases seqRun_cons_stop run with first | ⟨k,op,output,world',index,operands,execute,length,rest⟩
    · have zero := first.1
      simp only [List.length_cons] at zero
      omega
    · have same : k = pre.length := by simp only [List.length_cons] at index; omega
      subst k
      obtain ⟨prefixRun,single⟩ := ih rest
      refine ⟨?_,single⟩
      simp only [seqRun,operands,execute,length,ite_true,prefixRun,Option.map_some,SeqEnd.succ]
/-- Rename a final stopped instruction from FULL input register agreement.
The call's writes occur after all its reads, so no use-image exclusion is
needed for the final instruction. Only actual definition keys must be fixed. -/
theorem stock_single_stop_rename {V W : Type} {sem : ISem V W} {g : Reg → Reg} {gn : Nat → Nat}
    (ren : VRenaming g gn) (semantic : ∀ i,sem (i.mapRegs g) = sem i)
    {i : MInst} (fixed : ∀ d ∈ vdefs i,gn d = d)
    {raw rho : Nat → V} (agree : ∀ n,raw n = rho (gn n))
    {w finalWorld : W} {ops : Array Operand} {outs : List V} {ctl : Ctl}
    (run : seqRun sem [i] raw w = some (.stop 0 i ops raw w outs finalWorld ctl)) :
    seqRun sem [i.mapRegs g] rho w = some (.stop 0 (i.mapRegs g) (ops.map (rnOp gn)) rho w outs finalWorld ctl) ∧
      ∀ n,gn n = n → vdefUpd ops outs raw n = vdefUpd (ops.map (rnOp gn)) outs rho n := by
  rcases seqRun_cons_stop run with first | ⟨k,op,output,world',impossible,rest⟩
  · obtain ⟨_,_,operands,_,_,execute,length,control⟩ := first
    have full : Agree gn (fun _ => False) raw rho := fun n _ => agree n
    have uses : ∀ o ∈ ops.toList,o.isUse = true → (False ∨ ¬ False) := by intro _ _ _; exact .inr id
    have renamedUses := vuses_rename full uses
    have defs : ∀ o ∈ ops.toList,o.isDef = true → o.vreg ∈ vdefs i := by
      intro o member defined
      simp only [vdefs,operands]
      exact List.mem_map.mpr ⟨o,List.mem_filter.mpr ⟨member,defined⟩,rfl⟩
    have post := vdefUpd_rename (outs := outs) (D := fun n => n ∈ vdefs i) (fun d member => fixed d member)
      (fun n _ => agree n) defs
    refine ⟨?_,?_⟩
    · simp only [seqRun,operands_mapRegs ren,operands,Except.map,semantic,renamedUses,execute,
        defs_length_rn,length,ite_true]
    · intro n unchanged
      have decision : n ∈ vdefs i ∨ ¬ gn n ∈ vdefs i := by
        by_cases member : n ∈ vdefs i
        · exact .inl member
        · exact .inr (by rw [unchanged]; exact member)
      simpa only [unchanged] using post n decision
  · omega
/-- A no-def prefixRun (actual ABI argument stores) and the last stopped call
rename together without a caller use-image/disjointness certificate. -/
theorem stock_no_def_prefix_stop_rename {V W : Type} {sem : ISem V W} {g : Reg → Reg} {gn : Nat → Nat}
    (ren : VRenaming g gn) (semantic : ∀ i,sem (i.mapRegs g) = sem i)
    {pre : List MInst} (noDefs : ∀ m ∈ pre,vdefs m = []) {i : MInst}
    (fixed : ∀ d ∈ vdefs i,gn d = d) {rho : Nat → V} {w : W}
    {ops : Array Operand} {atCall : Nat → V} {world : W} {outs : List V} {finalWorld : W} {ctl : Ctl}
    (run : seqRun sem (pre ++ [i]) (fun n => rho (gn n)) w =
      some (.stop pre.length i ops atCall world outs finalWorld ctl)) :
    ∃ next,seqRun sem ((pre ++ [i]).map (·.mapRegs g)) rho w =
      some (.stop pre.length (i.mapRegs g) (ops.map (rnOp gn)) next world outs finalWorld ctl) ∧
      ∀ n,gn n = n → vdefUpd ops outs atCall n = vdefUpd (ops.map (rnOp gn)) outs next n := by
  obtain ⟨prefixRun,single⟩ := split_last_stop run
  have defs : ∀ m ∈ pre,∀ d ∈ vdefs m,False := by
    intro m member d defined
    rw [noDefs m member] at defined
    cases defined
  obtain ⟨next,renamed,agree⟩ := (seqRun_rename (D := fun _ => False) ren semantic
    (by intro d impossible; cases impossible) defs (by intro _ _ _ _; exact .inr id) (by intro n _; rfl)).1 prefixRun
  have full : ∀ n,atCall n = next (gn n) := fun n => agree n (.inr id)
  obtain ⟨last,post⟩ := stock_single_stop_rename ren semantic fixed full single
  refine ⟨next,?_,post⟩
  have combined := seqRun_append_fall_stop sem renamed last
  simpa only [List.map_append,List.map_cons,List.map_nil,List.length_map,Nat.zero_add] using combined
end Backend.Stock.Proof.TryStopRenameDraft
