import StockPreparedSegments
import StockTryCompleteEntry
namespace Backend.Stock.Proof.TryPreparedEntryDraft
open Backend.Proof Backend.Proof.Driver
open TryCompleteEntryDraft TryNormalCopiesDraft TryNormalEdgeValuesDraft
open PreparedSegmentsDraft Backend.Proof.PerEdgePrep
def PreparedNormalEntryExecution (f : Clif.Function) (result : Result) (prepared : EdgeVCode) (source : Step)
    (label targetLabel targetBi column : Nat) (fr' : Clif.Frame) (isem : Sem)
    (rho postCall : Nat → CV) (w finalWorld : Arm.ArmState) : Prop :=
  ∃ (target : Clif.Block) (args : Array Reg) (vb : VBlock) (prelude : Array MInst),
    f.blocks[targetBi]? = some target ∧
    (result.edgeArgs[label]?.bind fun row => row[column]?) = some args ∧
    result.code.blocks[label]? = some vb ∧
    vb.insts = prelude ++ source.emitted.map
      (·.mapRegs (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1))) ∧
    Star (VStepAt result.code result.edgeArgs isem) (.run ⟨label,prelude.size,rho,w⟩)
      (.run ⟨targetLabel,0,parCopyEnv postCall (edgeParamNumbers result target) (columnNumbers args),finalWorld⟩) ∧
    (∃ mapped,sigmaOf result.code prepared.code targetLabel = some mapped ∧
      Star (VStepAt prepared.code prepared.edges isem) (.run ⟨label,prelude.size,rho,w⟩)
        (.run ⟨mapped,0,parCopyEnv postCall (edgeParamNumbers result target) (columnNumbers args),finalWorld⟩)) ∧
    ValuesHeld (fun x => x ∈ availOf f (availIn f result.ctx) targetBi 0) result.ctx fr'
      (fun key => parCopyEnv postCall (edgeParamNumbers result target) (columnNumbers args) (aliasNum result.final.alias key))

/-- The same complete normal branch transition survives actual preparation,
including its exact parallel-copy environment, source values and returned world. -/
theorem stock_prepare_try_normal_entry {f : Clif.Function} {result : Result} {prepared : EdgeVCode}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f)
    (preparedRun : prepareAt result.code result.edgeArgs = .ok prepared)
    {source : Step} {targetLabel targetBi column : Nat} {fr' : Clif.Frame}
    {isem : Sem} (semantics : DriverSemG isem)
    {rho postCall : Nat → CV} {w finalWorld : Arm.ArmState}
    (original : NormalEntryExecution f result source 0 targetLabel targetBi column fr' isem rho postCall w finalWorld) :
    PreparedNormalEntryExecution f result prepared source 0 targetLabel targetBi column fr' isem rho postCall w finalWorld := by
  obtain ⟨target,args,vb,prelude,block,stored,placed,code,steps,values⟩ := original
  obtain ⟨mapped,_,mapping,_,transported,_⟩ := stock_prepare_reachable_segment lowered scope preparedRun semantics steps (.refl _)
  exact ⟨target,args,vb,prelude,block,stored,placed,code,steps,⟨mapped,mapping,transported⟩,values⟩
end Backend.Stock.Proof.TryPreparedEntryDraft
