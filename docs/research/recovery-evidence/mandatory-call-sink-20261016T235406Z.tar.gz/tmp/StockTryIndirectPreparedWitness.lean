import StockTryPreparedEntry
import StockTryIndirectEntryExecution
import StockTryNormalIndirectEntry
import StockTryNormalEdgeValues
import StockTryNormalIndirectSourceValues
import StockTryIndirectValueAliasObservation
import StockTryIndirectAliasObservation
import FV.Backend.Proof.PerEdgeSpillEntryFixture
import FV.E2E.RegLevelDriverSem
namespace Backend.Stock.Proof.TryIndirectPreparedWitnessDraft
open TryNormalIndirectSourceValuesDraft TryNormalValueColumnsDraft
open TryLiveNormalDraft
open TryNormalEntryValuesDraft TryNormalCopiesDraft TryNormalEdgeValuesDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open TryIndirectSourceRunDraft TryWholeSourceReservationDraft TryBranchAbiDraft
open TryResolvedRunsDraft TryLiveResolvedSourceDraft
open TryNormalEntryCaseDraft TryNormalIndirectEntryDraft
open TryCompleteEntryDraft TryIndirectEntryExecutionDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private def function := SpillEntryFixture.function true
private def signature := function.sig
private def model : ExtSem := ⟨fun _ _ w => some ([17],w),fun _ _ => 4096,0,fun _ w => Arm.read_pstate w⟩
private def environment : Clif.Env := {
  extern := fun _ => some (fun _ cm => .returned [⟨.i64,17⟩] cm),names := ["callee"],sigOf := fun _ => some signature }
private def symbols : String → Option Nat := fun n => if n = "callee" then some 4096 else none
private def memory : Clif.Mem := {Clif.Mem.empty with symbols}
private def relation : MemRelT := fun _ cm _ => cm.symbols = symbols
private def info : TryInfo := {continuation := 1,handlers := [.tag 7 2],clobberAll := false,rets := 1}
private theorem held : PrefixHold [⟨.i64,17⟩] ([17] : List CV) := by
  refine ⟨by decide,?_⟩
  intro j v x atValue atOut
  cases j with
  | zero => cases atValue; cases atOut; rfl
  | succ j => simp at atValue
private theorem xind : XCallsIndOk environment [signature] relation model := by
  intro sig member name g sl cm w u args vals rvals cm' found declared symbol count arguments related returned length typed
  have same := List.mem_singleton.mp member
  subst sig
  simp only [environment,Option.some.injEq] at found
  subst g
  cases returned
  exact ⟨[17],w,rfl,rfl,held,related⟩

private def table : Clif.ExnTable := {
  sig := 0,normal := ⟨1,[.ret 0,.val 0]⟩,items := [.tag 7 ⟨2,[.exn 0,.exn 1,.val 0]⟩] }
private def fr : Clif.Frame := {
  func := function
  regs := (Clif.Regs.empty.set 0 ⟨.i64,9⟩).set 1 ⟨.i64,4096⟩
  slots := []
  body := []
  term := function.blocks[0]!.term }
private def resultRegs : Clif.Regs := fr.regs.set function.freshValue ⟨.i64,17⟩
private def normalCall : Clif.BlockCall := ⟨1,[function.freshValue,0]⟩
private def pendingFrame : Clif.Frame := {fr with regs := resultRegs,body := [],term := .jump normalCall}
private def enteredFrame : Clif.Frame := {pendingFrame with regs := ((resultRegs.set 2 ⟨.i64,17⟩).set 3 ⟨.i64,9⟩),body := [],term := .ret [2]}
private def rho (result : Result) : Nat → CV := fun n => if n = keyMap result 193 then ofX 4096 else 9
private theorem abi : AbiSigsOk function := by
  constructor
  · constructor
    · decide +kernel
    · intro e member
      change e ∈ [(0,{name := "callee",sig := signature,colocated := false})] at member
      cases List.mem_singleton.mp member
      decide +kernel
  · intro sig member
    change sig ∈ [signature] at member
    cases List.mem_singleton.mp member
    exact ⟨by decide +kernel,by decide +kernel⟩
/-- Complete original-condition true-indirect compiler/prepare/checkedfallback/
physical pipeline, inhabited ORIGINAL indirect contract and actual final-renamed
normal machine branch, with actual source execution returning17. -/
private theorem source_defined (ctx : Ctx) : SourceDefinedAt function ctx 0 function.blocks[0]!.body.length fr := by
  have block : function.blocks[0]? = some function.blocks[0]! := rfl
  intro x available
  obtain ⟨present,_⟩ := (mem_av block).mp available
  rcases present with parameter | incoming | ⟨j,stm,earlier,statement,member⟩
  · change x ∈ ([] : List Nat) at parameter
    cases parameter
  · have impossible := (inFix_fixOk (f := function) (ctx := ctx) (gn := id)).cand 0 x incoming
    omega
  · have choices : ∀ stm ∈ function.blocks[0]!.body,∀ y ∈ stm.results,y = 0 ∨ y = 1 := by
      simp [function,SpillEntryFixture.function]
    rcases choices stm (List.mem_of_getElem? statement) x member with rfl | rfl
    · exact ⟨⟨.i64,9⟩,rfl⟩
    · exact ⟨⟨.i64,4096⟩,rfl⟩
theorem stock_prepared_complete_indirect_normal_entry_execution_witness :
    ∃ out : SpillEntryFixture.Output true,
      LowerScope function ∧ Dominated function ∧ ArityOk function ∧ AbiSigsOk function ∧
      Stock.lower function = .ok out.result ∧ prepareAt out.result.code out.result.edgeArgs = .ok out.prepared ∧
      out.rf = spillAllocAt out.prepared.code out.prepared.edges ∧
      checkAllocAt out.prepared.code out.prepared.edges out.rf = .ok () ∧ lowerRFunc out.prepared.code out.rf = .ok out.af ∧
      XCallsIndOk environment [signature] relation model ∧
      IndCallsRefineP (fun _ _ _ _ => True) environment (indSigs function) relation
        (csem (fun _ => False) ⟨0,0⟩ model) ∧
      keyMap out.result 193 ≠ 193 ∧
      SourceDefinedAt function out.result.ctx 0 function.blocks[0]!.body.length fr ∧
      SourceDefinedAt function out.result.ctx 1 0 enteredFrame ∧
      Clif.enterBlock pendingFrame normalCall = .ok enteredFrame ∧
      (∃ raw : IndirectTryRun function out.result 0 0 function.blocks[0]! signature
        (csem (fun _ => False) ⟨0,0⟩ model) relation fr (fun n => rho out.result (keyMap out.result n)) Arm.ArmState.default [⟨.i64,17⟩] memory,
        ∃ (k : Nat) (i : MInst) (ops : Array Operand) (atCall : Nat → CV) (world : Arm.ArmState)
          (outs : List CV) (finalWorld : Arm.ArmState),
          seqRun (csem (fun _ => False) ⟨0,0⟩ model)
            (raw.source.branch.step.emitted.toList.map (·.mapRegs (resolver out.result))) (rho out.result) Arm.ArmState.default =
            some (.stop k i ops atCall world outs finalWorld (.goto raw.info.handlers.length)) ∧
          NormalColumnValues out.result 0 table.handlers.length [⟨.i64,17⟩,⟨.i64,9⟩] (vdefUpd ops outs atCall) ∧
          raw.info.handlers.length = table.handlers.length ∧
          NormalEntryAgreement function out.result 0 1 1 raw.info.handlers.length normalCall enteredFrame (vdefUpd ops outs atCall) ∧
          TryPreparedEntryDraft.PreparedNormalEntryExecution function out.result out.prepared raw.source.branch.step 0 1 1 raw.info.handlers.length enteredFrame
            (csem (fun _ => False) ⟨0,0⟩ model) (rho out.result) (vdefUpd ops outs atCall) Arm.ArmState.default finalWorld) ∧
      Clif.runWith environment {funcs := [function]} function.name [] memory 6 = .returned [⟨.i64,17⟩] memory := by
  obtain ⟨out⟩ := SpillEntryFixture.try_fixture true
  have order : blockOrder function = .ok {nodes := #[.original 0,.original 1,.original 2],successors := #[#[2,1],#[],#[]]} := by cbv
  have sameOrder := Except.ok.inj ((stock_lower_order out.lowered).symm.trans order)
  have node : out.result.order.nodes[0]? = some (.original 0) := by rw [sameOrder]; rfl
  have block : function.blocks[0]? = some function.blocks[0]! := rfl
  have kind : function.blocks[0]!.term = .tryCallIndirect 1 [] table := rfl
  have tableRun : exnTableOpnd function table = .ok (signature,[some 7]) := rfl
  obtain ⟨ranges,source,selected,base,value,next,build,rest⟩ := stock_lower_original_try_reservation
    out.lowered out.scope (show Prg.iselInB function = true from by decide +kernel) node block
    (show sourceTable function.blocks[0]!.term = some table from rfl) tableRun
  have projection : ((Stock.buildCtx function).toOption.map (fun q => q.1.valueReg? 1)) = some (some (.vreg 193 .int)) := rfl
  change Stock.buildCtx function = .ok (out.result.ctx,ranges,out.result.initial) at build
  rw [build] at projection
  have mapping : out.result.ctx.valueReg? 1 = some (.vreg 193 .int) := Option.some.inj projection
  have heldArgs : ValuesHeld (fun x => x = 1 ∨ x ∈ ([] : List Nat)) out.result.ctx fr (fun n => rho out.result (keyMap out.result n)) := by
    intro x member v lookup
    rcases member with rfl | impossible
    · change some ⟨.i64,4096⟩ = some v at lookup
      cases lookup
      exact ⟨193,mapping,by simp only [rho,ite_true]; rfl⟩
    · cases impossible
  have contract : IndCallsRefineP (fun _ _ _ _ => True) environment (indSigs function) relation
      (csem (fun _ => False) ⟨0,0⟩ model) := (indCallsRefine_csem (syms := symbols) xind
        (by intro n b found; by_cases same : n = "callee" <;> simp [symbols,same] at found; cases found; rfl)
        (by intro sl cm w related; exact related)).toP _
  have projection0 : ((Stock.buildCtx function).toOption.map (fun q => q.1.valueReg? 0)) = some (some (.vreg 192 .int)) := rfl
  rw [build] at projection0
  have mapping0 : out.result.ctx.valueReg? 0 = some (.vreg 192 .int) := Option.some.inj projection0
  have distinct : keyMap out.result 192 ≠ keyMap out.result 193 := by
    have observed := TryIndirectValueAliasObservationDraft.observed
    rw [out.lowered] at observed
    exact bne_iff_ne.mp observed
  have liveHeld : ValuesHeld (fun x => x ∈ availOf function (availIn function out.result.ctx) 0 function.blocks[0]!.body.length)
      out.result.ctx fr (fun n => rho out.result (keyMap out.result n)) := by
    intro x available v lookup
    by_cases zero : x = 0
    · subst x
      change some ⟨.i64,9⟩ = some v at lookup
      cases lookup
      exact ⟨192,mapping0,by simp only [rho,if_neg distinct]; rfl⟩
    · by_cases one : x = 1
      · subst x
        exact heldArgs 1 (.inl rfl) v lookup
      · simp [fr,Clif.Regs.empty,Clif.Regs.set,zero,one] at lookup
  have successor : out.result.order.successors[0]![table.handlers.length]? = some 1 := by rw [sameOrder]; rfl
  have target : out.result.order.nodes[1]? = some (.original 1) := by rw [sameOrder]; rfl
  have sourceBind : fr.regs.setMany ((List.range 1).map (function.freshValue + ·)) [⟨.i64,17⟩] = some resultRegs := rfl
  have normalRead : ({fr with regs := resultRegs} : Clif.Frame).getMany normalCall.args = .ok [⟨.i64,17⟩,⟨.i64,9⟩] := rfl
  have sourceEntered : Clif.enterBlock pendingFrame normalCall = .ok enteredFrame := rfl
  have run := stock_lower_indirect_try_normal_entry_execution (ρ := rho out.result) (w := Arm.ArmState.default) (cm := memory) (cm' := memory)
    out.lowered out.scope out.dominated (show Prg.iselInB function = true from by decide +kernel) abi node block kind tableRun successor target (driverSem_csem _ _ _) contract
    heldArgs (show fr.getMany [] = .ok [] from rfl)
    (show ([] : List Clif.Val).map (·.ty) = Clif.AbiParam.tys signature.params from rfl)
    (show relation fr.slots memory Arm.ArmState.default from rfl)
    (show fr.get 1 = .ok ⟨.i64,BitVec.ofNat 64 4096⟩ from rfl)
    (show memory.symbols "callee" = some 4096 from rfl)
    (by intro s hs; cases Option.some.inj hs; rfl)
    (show environment.extern "callee" = some (fun _ cm => .returned [⟨.i64,17⟩] cm) from rfl)
    trivial rfl rfl liveHeld sourceBind (show Clif.tryNormal table function.freshValue = .ok normalCall from rfl) normalRead rfl sourceEntered
  obtain ⟨raw,k,i,ops,atCall,world,outs,finalWorld,execute,related,returns,postHeld,column,normalIndex,entryAgreement,defined,complete⟩ := run
  have changed : keyMap out.result 193 ≠ 193 := by
    have observed := TryIndirectAliasObservationDraft.observed
    rw [out.lowered] at observed
    exact bne_iff_ne.mp observed
  have transported := TryPreparedEntryDraft.stock_prepare_try_normal_entry out.lowered out.scope out.prepare
    (driverSem_csem (fun _ => False) ⟨0,0⟩ model).toDriverSemG complete
  exact ⟨out,out.scope,out.dominated,out.arity,abi,out.lowered,out.prepare,out.fallback,out.accepted,out.physical,xind,contract,changed,source_defined out.result.ctx,defined (source_defined out.result.ctx),sourceEntered,⟨raw,k,i,ops,atCall,world,outs,finalWorld,execute,column,normalIndex,entryAgreement,transported⟩,rfl⟩
end Backend.Stock.Proof.TryIndirectPreparedWitnessDraft
