import StockTryPreparedEntry
import StockTryNearEntryExecution
import StockTryNormalNearEntry
import StockTryNormalEdgeValues
import StockTryNormalSourceValues
import StockTryLiveValues
import StockTryLiveResolvedSource
import StockTryNearOutgoingObservation
import FV.Backend.Proof.MemRefines
import FV.E2E.RegLevelDriverSem
namespace Backend.Stock.Proof.TryNearPreparedWitnessDraft
open TryNormalSourceValuesDraft TryNormalValueColumnsDraft
open TryLiveValuesDraft TryLiveNormalDraft
open TryNormalEntryValuesDraft TryNormalCopiesDraft TryNormalEdgeValuesDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open TryDirectSourceRunDraft TryNearFixtureDraft
open TryResolvedRunsDraft TryLiveResolvedSourceDraft
open TryNormalEntryCaseDraft TryNormalNearEntryDraft
open TryCompleteEntryDraft TryNearEntryExecutionDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private def f := function false
private def ext : Clif.ExtFunc := {name := "callee",sig := f.sig,colocated := true}
private def table : Clif.ExnTable := {
  sig := 0,normal := ⟨1,[.ret 0,.val 0]⟩,items := [.tag 7 ⟨2,[.exn 0,.exn 1,.val 0]⟩] }
private def fr : Clif.Frame := {func := f,regs := Clif.Regs.empty.set 0 ⟨.i64,9⟩,slots := [],body := [],term := f.blocks[0]!.term}
private def model : ExtSem := ⟨fun _ _ w => some ([17],w),fun _ _ => 4096,0,fun _ w => Arm.read_pstate w⟩
private def environment : Clif.Env := {
  extern := fun _ => some (fun _ cm => .returned [⟨.i64,17⟩] cm),names := ["callee"],sigOf := fun _ => some f.sig }
private theorem held : PrefixHold [⟨.i64,17⟩] ([17] : List CV) := by
  refine ⟨by decide,?_⟩
  intro j v x atValue atOut
  cases j with
  | zero => cases atValue; cases atOut; rfl
  | succ j => simp at atValue
private theorem xcalls : XCallsOk environment [ext] (fun _ _ _ => True) model := by
  intro e member g sl cm w dest used args vals rvals cm' found target arguments memory returned length
  have same := List.mem_singleton.mp member
  subst e
  simp only [environment,Option.some.injEq] at found
  subst g
  cases returned
  exact ⟨[17],w,rfl,rfl,held,trivial⟩
/-- A COMPLETE original-condition compiler/prepare/checked-fallback/physical
pipeline inhabits the original memory/callee contracts and the new whole-source
final-renamed branch execution. The actual normal operand update returns17 through
final aliases; the source program also really runs to17. -/
private def resultRegs : Clif.Regs := fr.regs.set f.freshValue ⟨.i64,17⟩
private def normalCall : Clif.BlockCall := ⟨1,[f.freshValue,0]⟩
private def pendingFrame : Clif.Frame := {fr with regs := resultRegs,body := [],term := .jump normalCall}
private def enteredFrame : Clif.Frame := {pendingFrame with regs := ((resultRegs.set 2 ⟨.i64,17⟩).set 3 ⟨.i64,9⟩),body := [],term := .ret [2]}
private def built : Ctx × Array (Nat × Nat) × State := (Stock.buildCtx f).toOption.getD (sinkCtx,#[],sinkState)
private theorem built_ok : Stock.buildCtx f = .ok built := rfl
private theorem built_context {result : Result} (run : Stock.lower f = .ok result) :
    ∃ ranges,Stock.buildCtx f = .ok (result.ctx,ranges,result.initial) := by
  unfold Stock.lower at run
  dsimp only at run
  repeat' first
    | (solve | cases run)
    | simp only [bind,Except.bind,pure,Except.pure] at run
    | split at run
  cases run
  rename_i _ built hbuild _ order horder _ driver hdriver
  exact ⟨_,hbuild⟩
private theorem source_defined (ctx : Ctx) : SourceDefinedAt f ctx 0 f.blocks[0]!.body.length fr := by
  have block : f.blocks[0]? = some f.blocks[0]! := rfl
  intro x available
  obtain ⟨present,_⟩ := (mem_av block).mp available
  rcases present with parameter | incoming | ⟨j,stm,earlier,statement,member⟩
  · change x ∈ ([] : List Nat) at parameter
    cases parameter
  · have impossible := (inFix_fixOk (f := f) (ctx := ctx) (gn := id)).cand 0 x incoming
    omega
  · have choices : ∀ stm ∈ f.blocks[0]!.body,∀ y ∈ stm.results,y = 0 := by
      simp [f,TryNearFixtureDraft.function]
    have same := choices stm (List.mem_of_getElem? statement) x member
    subst x
    exact ⟨⟨.i64,9⟩,rfl⟩
theorem stock_prepared_complete_near_try_normal_entry_execution_witness :
    ∃ out : Output,
      LowerScope f ∧ Dominated f ∧ ArityOk f ∧ Stock.lower f = .ok out.result ∧
      prepareAt out.result.code out.result.edgeArgs = .ok out.prepared ∧
      out.rf = spillAllocAt out.prepared.code out.prepared.edges ∧
      checkAllocAt out.prepared.code out.prepared.edges out.rf = .ok () ∧ lowerRFunc out.prepared.code out.rf = .ok out.af ∧
      XCallsOk environment [ext] (fun _ _ _ => True) model ∧
      CallsRefineP (fun _ _ _ _ => True) (fun _ => False) environment [ext] (fun _ _ _ => True) (csem (fun _ => False) ⟨0,0⟩ model) ∧
      MRStable (fun _ => False) (fun _ _ _ => True) ∧
      MemRefinesR (fun _ => True) (fun _ => False) 0 (fun _ => none) (csem (fun _ => False) ⟨0,0⟩ model) ∧
      OutArgsOk (fun _ => False) out.result.code.outgoing (fun _ _ _ => True) ∧
      SourceDefinedAt f out.result.ctx 0 f.blocks[0]!.body.length fr ∧
      SourceDefinedAt f out.result.ctx 1 0 enteredFrame ∧
      Clif.enterBlock pendingFrame normalCall = .ok enteredFrame ∧
      (∃ raw : DirectTryRun f out.result 0 0 f.blocks[0]! ext (csem (fun _ => False) ⟨0,0⟩ model)
        (fun _ _ _ => True) fr (fun _ => 9) Arm.ArmState.default [⟨.i64,17⟩] Clif.Mem.empty,
        ∃ (k : Nat) (i : MInst) (ops : Array Operand) (atCall : Nat → CV) (world : Arm.ArmState)
          (outs : List CV) (finalWorld : Arm.ArmState),
          seqRun (csem (fun _ => False) ⟨0,0⟩ model)
            (raw.source.branch.step.emitted.toList.map (·.mapRegs (resolver out.result))) (fun _ => 9) Arm.ArmState.default =
            some (.stop k i ops atCall world outs finalWorld (.goto raw.info.handlers.length)) ∧
          NormalColumnValues out.result 0 table.handlers.length [⟨.i64,17⟩,⟨.i64,9⟩] (vdefUpd ops outs atCall) ∧
          raw.info.handlers.length = table.handlers.length ∧
          NormalEntryAgreement f out.result 0 1 1 raw.info.handlers.length normalCall enteredFrame (vdefUpd ops outs atCall) ∧
          TryPreparedEntryDraft.PreparedNormalEntryExecution f out.result out.prepared raw.source.branch.step 0 1 1 raw.info.handlers.length enteredFrame
            (csem (fun _ => False) ⟨0,0⟩ model) (fun _ => 9) (vdefUpd ops outs atCall) Arm.ArmState.default finalWorld) ∧
      Clif.runWith environment {funcs := [f]} f.name [] Clif.Mem.empty 6 = .returned [⟨.i64,17⟩] Clif.Mem.empty := by
  obtain ⟨out⟩ := stock_near_try_fixture
  have order : blockOrder f = .ok {nodes := #[.original 0,.original 1,.original 2],successors := #[#[2,1],#[],#[]]} := by cbv
  have sameOrder := Except.ok.inj ((stock_lower_order out.lowered).symm.trans order)
  have node : out.result.order.nodes[0]? = some (.original 0) := by rw [sameOrder]; rfl
  have block : f.blocks[0]? = some f.blocks[0]! := rfl
  have kind : f.blocks[0]!.term = .tryCall 0 [] table := rfl
  have external : f.extern? 0 = some ext := rfl
  have area : out.result.code.outgoing = 0 := by
    have observed := TryNearOutgoingObservationDraft.observed
    rw [out.lowered] at observed
    exact Option.some.inj observed
  have stable : MRStable (fun _ => False) (fun _ _ _ => True) := by intro _ _ _ _ _ _; trivial
  have memory : MemRefinesR (fun _ => True) (fun _ => False) 0 (fun _ => none) (csem (fun _ => False) ⟨0,0⟩ model) :=
    memRefinesR_of (memRefines_csem _ _ _ rfl (by intro n b found; cases found))
  have outgoing : OutArgsOk (fun _ => False) out.result.code.outgoing (fun _ _ _ => True) := by
    rw [area]
    intro sl cm w related
    exact ⟨by decide,by intro k bound bad; exact bad,by intro k n y inside; trivial⟩
  have contract : CallsRefineP (fun _ _ _ _ => True) (fun _ => False) environment [ext] (fun _ _ _ => True)
      (csem (fun _ => False) ⟨0,0⟩ model) := (callsRefine_csem xcalls).toP _
  have heldArgs : ValuesHeld (fun x => x ∈ ([] : List Nat)) out.result.ctx fr (fun _ => 9) := by
    intro x member; cases member
  obtain ⟨ranges,build⟩ := built_context out.lowered
  have ctxEq := congrArg Prod.fst (Except.ok.inj (build.symm.trans built_ok))
  change out.result.ctx = built.1 at ctxEq
  have mapping : out.result.ctx.valueReg? 0 = some (.vreg 192 .int) := by rw [ctxEq]; rfl
  have heldLive : ValuesHeld (fun _ => True) out.result.ctx fr (fun _ => 9) := by
    intro x member v lookup
    by_cases same : x = 0
    · subst x
      change some ⟨.i64,9⟩ = some v at lookup
      cases lookup
      exact ⟨192,mapping,rfl⟩
    · simp [fr,Clif.Regs.empty,Clif.Regs.set,same] at lookup
  have successor : out.result.order.successors[0]![table.handlers.length]? = some 1 := by rw [sameOrder]; rfl
  have target : out.result.order.nodes[1]? = some (.original 1) := by rw [sameOrder]; rfl
  have sourceBind : fr.regs.setMany ((List.range 1).map (f.freshValue + ·)) [⟨.i64,17⟩] = some resultRegs := rfl
  have normalRead : ({fr with regs := resultRegs} : Clif.Frame).getMany normalCall.args = .ok [⟨.i64,17⟩,⟨.i64,9⟩] := rfl
  have sourceEntered : Clif.enterBlock pendingFrame normalCall = .ok enteredFrame := rfl
  have run := stock_lower_direct_try_normal_entry_execution (ρ := fun _ => 9) (w := Arm.ArmState.default) (cm := Clif.Mem.empty) (cm' := Clif.Mem.empty) out.lowered out.scope out.dominated
    (show Prg.iselInB f = true from by decide +kernel) node block kind external rfl successor target (driverSem_csem _ _ _) stable memory outgoing
    contract (show ext ∈ [ext] from by simp) heldArgs (show fr.getMany [] = .ok [] from rfl)
    (show ([] : List Clif.Val).map (·.ty) = Clif.AbiParam.tys ext.sig.params from rfl)
    (show (fun _ _ _ => True) fr.slots Clif.Mem.empty Arm.ArmState.default from trivial)
    (show environment.extern ext.name = some (fun _ cm => .returned [⟨.i64,17⟩] cm) from rfl)
    trivial rfl rfl (fun x available v present => heldLive x trivial v present) sourceBind
    (show Clif.tryNormal table f.freshValue = .ok normalCall from rfl) normalRead rfl sourceEntered
  obtain ⟨raw,k,i,ops,atCall,world,outs,finalWorld,execute,related,returns,postHeld,column,normalIndex,entryAgreement,defined,complete⟩ := run
  have transported := TryPreparedEntryDraft.stock_prepare_try_normal_entry out.lowered out.scope out.prepare
    (driverSem_csem (fun _ => False) ⟨0,0⟩ model).toDriverSemG complete
  exact ⟨out,out.scope,out.dominated,out.arity,out.lowered,out.prepare,out.fallback,out.accepted,out.physical,xcalls,contract,stable,memory,outgoing,source_defined out.result.ctx,defined (source_defined out.result.ctx),sourceEntered,⟨raw,k,i,ops,atCall,world,outs,finalWorld,execute,column,normalIndex,entryAgreement,transported⟩,rfl⟩
end Backend.Stock.Proof.TryNearPreparedWitnessDraft
