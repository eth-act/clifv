from pathlib import Path
import json,hashlib,re,datetime,tarfile,shutil,subprocess
root=Path('/home/lee/clifv/.worktrees/driver-proof-resume');docs=root/'docs/research';prefix='stock-try-prepared'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
now=datetime.datetime.now(datetime.timezone.utc);stamp=now.strftime('%Y%m%dT%H%M%SZ')
batch=json.loads(Path('/tmp/'+prefix+'-batch.json').read_text());old=json.loads((docs/'stock-try-edge-step-scratch.json').read_text())
log=Path('/tmp/'+prefix+'-combined-axioms.log').read_text()
sets={m.group(1):sorted(x.strip() for x in m.group(2).split(',') if x.strip()) for m in re.finditer(r"'([^']+)' depends on axioms:\s*\[([^]]*)\]",log)}
for m in re.finditer(r"'([^']+)' does not depend on any axioms",log):sets[m.group(1)]=[]
for n,a in old['normal_audit']['sets'].items():assert sorted(a)==sets[n],n
assert len(sets)==len(old['normal_audit']['sets'])+len(batch['public_roots'])+len(batch['models'])
allowed={'propext','Classical.choice','Quot.sound'}
for n in batch['public_roots']+batch['models']:assert set(sets[n])<=allowed,n
constants=[json.loads(line.split('DELIVERY_CONSTANT ',1)[1]) for line in Path('/tmp/'+prefix+'-all-constants.log').read_text().splitlines() if line.startswith('DELIVERY_CONSTANT ')]
assert constants
for n,a in constants:assert set(a)<=allowed,n
mods={}
for m in batch['modules']:
 p=Path('/tmp')/m;check=json.loads(p.with_suffix('.check.json').read_text());assert check['actual_exit']==0
 rec={}
 for key,ext in [('source','.lean'),('object','.olean'),('log','.log'),('check','.check.json')]:
  f=p.with_suffix(ext);rec[key]=str(f);rec[key+'_sha256']=sha(f)
 for k in ['source','object','log']:assert rec[k+'_sha256']==check[k+'_sha256']
 assert not re.search(r'\b(sorry|admit|axiom|trace_state|native_decide)\b',p.with_suffix('.lean').read_text()),m
 mods[m]=rec
for audit in [prefix+'-combined-axioms',prefix+'-all-constants']:
 p=Path('/tmp')/audit;check=json.loads(p.with_suffix('.check.json').read_text());assert check['actual_exit']==0
 for k,ext in [('source','.lean'),('object','.olean'),('log','.log')]:assert sha(p.with_suffix(ext))==check[k+'_sha256']
prior={}
for name in ['source-execution-x','try-source','try-context','try-rule','try-rets','try-reservation','try-outgoing','try-values','try-emitted','try-machine','try-got','try-indirect','try-rename','try-resolved','try-gap','try-got-rename','try-normal-frame','try-metadata','source-index','try-normal-vector','try-critical-normal','source-erase','source-origin','try-live-frame','try-normal-values','try-normal-copy','try-normal-control','try-normal-entry','try-placement','try-edge-step']:
 d=json.loads((docs/f'stock-{name}-scratch.json').read_text())
 for m,rec in d['modules'].items():
  for k in ['source','object','log']:assert sha(rec[k])==rec[k+'_sha256'],(m,k)
  prior[m]=rec
assert len(prior)==206
freeze=json.loads(Path('/tmp/stock-coherent-build-inputs.json').read_text())
for group in ['source_sha256','validation_script_sha256']:
 for p,h in freeze[group].items():assert sha(root/p)==h,p
imports=json.loads(Path('/tmp/stock-try-rule-inputs.json').read_text())
for m,r in imports['modules'].items():
 assert sha(r['snapshot'])==r['object_sha256'],(m,'snapshot')
 assert sha(r['source'])==r['source_sha256'],(m,'source')
progress=json.loads(Path('/tmp/stock-pr246-gates-progress.json').read_text());progress.pop('completed_phases',None)
live=subprocess.check_output(['ps','-p','3247835','-o','pid,stat,etime,args'],text=True)
remaining=list(old['remaining_checklist'])
remaining.append({'requirement':'Actual prepared normal branch and reachable-segment transport','state':'PROGRESS: generic checked entry Star and reachable segment transport; original Stock wrappers derive checker from original lower/scope/prepare. Same exact register/world states and actual sigma map; nonentry liveness derived through actual runtime history, not program acceptance. Prepared normal-entry output retains original actual VCode transition and ALL source-value agreement. Complete ordinary near/GOT/indirect and critical indirect/local-area-GOT pipelines now include real prepared execution. Branch boundary AFTER ordinary body; initial/body/source/DFG/world/whole-driver simulation AND completeness and cutover remain OPEN. Near-critical and older whole-area GOT root-specific witnesses remain pending.'})
counts={'modules':len(mods),'public_roots':len(batch['public_roots']),'models':len(batch['models']),'combined_roots_models':len(sets),'previous_preserved':len(old['normal_audit']['sets']),'all_new_module_constants':len(constants),'previous_modules_hashes_preserved':len(prior)}
receipt={'utc':now.isoformat(),'goal':'Original full #140 ACTIVE/INCOMPLETE; production LEGACY','scope':'Scratch prepared normal branch and reachable-segment transport; full goal unchanged','delivery_target':'roughly 8 substantive validated squash merges/day; coherent grouping, remote backups and cleanup','modules':mods,'public_roots':batch['public_roots'],'models':batch['models'],'counts':counts,'normal_audit':{'path':'/tmp/'+prefix+'-combined-axioms.log','sha256':sha('/tmp/'+prefix+'-combined-axioms.log'),'sets':sets},'all_constant_audit':{'path':'/tmp/'+prefix+'-all-constants.log','sha256':sha('/tmp/'+prefix+'-all-constants.log'),'count':len(constants),'all_standard_only':True},'previous_modules_hashes_preserved':list(prior),'canonical2246_source_and_script_freeze_preserved':True,'import_generation':{'source_and_snapshot_hashes_checked':len(imports['modules']),'manifest_sha256':sha('/tmp/stock-try-rule-inputs.json'),'shared_cache_writes':False},'nonvacuity':{'ordinary3':'Complete original near/GOT/true-indirect compiler/prepare/forced fallback/checker/physical/source17/runtime/memory/callee/value/copy/defined-before-after witnesses plus actual prepared transitions and mapped target labels','critical2':'Complete original indirect/local-area-GOT pipelines; preserved unreachable predecessor/indegree2; actual raw call/identity first copy/synthetic jump/second copy into original target AND prepared execution with same final register/world state','near_critical':'PENDING one larger kernel after active heavy lane frees; prior 8GiB failures preserved','older_whole_result_area_GOT':'PENDING original root-specific contract/non-vacuity; local-area witness is additive, not substituted'},'fidelity':'Original source conditions and old variants unchanged; actual history is a runtime simulation invariant, never a new accepted-input filter. PreparedNormalEntryExecution is solely an output conclusion. Initial state is branch boundary after ordinary body, not function entry. No new semantic assumption or caller map/live/checker certificate. Private structural facts reproduce existing kernel-checked checker inversion additively; canonical source frozen.','MCP':'Deferred until coherent integration; no new calls','active_exact_PR246_validation':progress,'live_worker':live,'remaining_checklist':remaining}
(docs/(prefix+'-scratch.json')).write_text(json.dumps(receipt,indent=2)+'\n')
text=f'''Actual prepared normal TryCall execution and reachable-segment transport — {now.isoformat()}

{len(mods)} scratch modules / {len(batch['public_roots'])} public roots / {len(batch['models'])} semantic output model: actual 8GiB kernel PASS. Cumulative {len(sets)} root/model audit preserves ALL {len(old['normal_audit']['sets'])} prior exact axiom sets; ALL {len(constants)} new-module constants including private/generated/model/witness helpers use only standard axioms. ALL {len(prior)} prior scratch source/object/log hashes, 2246 canonical source/49-script freeze and 1049 imported source/snapshot hashes preserved; no shared-cache writes.

Checked preparation now transports complete actual entry-block Star segments at arbitrary PC, with exact register and world preservation and actual mapped endpoint labels. A general nonentry-segment theorem derives its live-block invariant and source/target maps from actual runtime history. Original Stock consumers derive the internal preparation checker from successful lowering, original LowerScope and actual prepareAt; no caller-supplied live/renaming/checker certificate or additional accepted-program condition. Runtime history is an ordinary simulation observation.

PreparedNormalEntryExecution retains the original complete raw normal branch transition, source target/column/placed suffix and ALL destination-available source values, and adds the actual prepared transition with SAME copied register file and returned world. COMPLETE original ordinary near/GOT/true-indirect and critical INDIRECT/local-area GOT witnesses now include actual prepared execution. Critical cases preserve real unreachable predecessor/indegree2 and both raw call/identity-first-copy and synthetic-jump/second-copy hops. Ordinary witnesses preserve source-defined-before/after, complete original callee/memory/ABI/compiler/prepare/forced checkedfallback/checker/physical/source17. Nine-argument GOT retains real stack stores/16byte area; indirect retains callee4096. Nonentry transport is also applied to a real completed normal transition as execution history, retaining its actual endpoint.

This transports NORMAL BRANCH execution from its actual boundary AFTER ordinary body; initial entry/ordinary-body/whole source-block/function/DFG/world/whole-driver simulation AND completeness remain OPEN. Next compose actual body/entry/source continuations and establish universal source/world invariants. Near-critical complete compiler/machine/value observation remains pending after saved 8GiB failures; one larger kernel AFTER live delivery heavy lane frees. Older critical GOT WHOLE-RESULT-AREA root-specific contract/non-vacuity remains pending; local-area witness is not substituted. Physical lowering is not an outgoing bound/projection proof; VM is not proof.

All zero-return/sret/x8/width/handler/Try-critical matrix, shared payload/exception semantics, uncovered rule families/effects/sinking, source/DFG/world/block/whole-driver simulation AND completeness, original-input context/static/visitor/checker/fallback/physical totality, coherent integration/public/private/compiler/MCP/full build/crates/runtime/encoder/BOTH E2E identity-stage parity, actual compiler/checker/linker/generated consumers and FRESH COMPLETE comparison remain mandatory. Original inputs/old variants/exact axiom sets/accepted identities/successful stages/at least #179 baseline preserved. Full #140 ACTIVE/INCOMPLETE; production LEGACY.

Same #246 supervisor3247835 confirmed LIVE at {progress.get('index')}/{progress.get('total')}; canonical1233457 deliberately held/exclusive one-cache lease. No restart. Preserve old-head receipts, reconcile current main/shared assumptions/changed-deleted roots, rerun affected kernel/trust and ALL full/crates/runtime/encoder/BOTH E2E actual integrated-head gates before dependent squash246→247. Roughly 8 substantive validated merges/day, coherent semantic batches/remote backups/cleanup. No merge/new tree/agent/MCP/heavy retry/other-project cleanup. Contributor52/71/task140 reread; Kev shared Arm/FP/ExtSem/csemU/Link/runtime/S10 boundaries preserved. Full evidence/checklist: stock-try-prepared-scratch.json.
'''
(docs/(prefix+'-scratch.md')).write_text(text)
plan=root/'docs/plans/test-binary-alignment-recovery.md';plan.write_text(plan.read_text()+'\n\n'+text)
current=docs/'stock-full-goal-current.md';previous=current.read_text();Path('/tmp/'+prefix+'-full-goal-before.md').write_text(previous)
current.write_text(f'Latest checkpoint {now.isoformat()}: [actual prepared normal transitions and reachable-segment transport](stock-try-prepared-scratch.md). {len(mods)} modules/{len(batch["public_roots"])} public roots/{len(batch["models"])} model; cumulative {len(sets)} preserves {len(old["normal_audit"]["sets"])} prior exact sets; {len(constants)} new-module constants standard-only. Complete ordinary3/critical2 pipelines now include actual prepared execution, exact world/register state and source-value agreement. Initial/body/source/DFG/world/whole-driver simulation AND completeness/cutover remain OPEN; branch boundary is not function entry. Near-critical and older whole-area GOT root-specific witnesses remain pending. Full #140 ACTIVE/INCOMPLETE; production LEGACY. Same #246 live gate {progress.get("index")}/{progress.get("total")}; no merge.\n\n'+previous)
files=[]
for rec in mods.values():files.extend(Path(rec[k]) for k in ['source','object','log','check'])
for name in [prefix+'-combined-axioms',prefix+'-all-constants']:
 for ext in ['.lean','.log','.olean','.check.json']:files.append(Path('/tmp')/(name+ext))
files.extend(p for p in Path('/tmp').glob(prefix+'*') if p.is_file())
files.extend(Path('/tmp')/('stock-merge-discipline-status'+str(n)+'.json') for n in [44,52,71,140])
files.extend([Path('/tmp/stock-try-rule-inputs.json'),Path('/tmp/stock-try-reservation-check.py'),Path('/tmp/stock-source-erase-restore.py'),docs/(prefix+'-scratch.json'),docs/(prefix+'-scratch.md'),docs/'stock-delivery-main-drift.json',plan,current])
files=list(dict.fromkeys(files));archive=Path('/home/lee/.clifv-recovery')/(stamp+'-try-prepared')/'checkpoint.tar.gz';archive.parent.mkdir(parents=True)
with tarfile.open(archive,'w:gz',compresslevel=1) as t:
 for p in files:t.add(p,arcname=str(p).lstrip('/'),recursive=False)
with tarfile.open(archive,'r:gz') as t:
 for p in files:assert t.extractfile(str(p).lstrip('/')).read()==p.read_bytes(),p
snapshot=Path('/tmp/stock-try-rule-inputs');size=sum(p.stat().st_size for p in snapshot.rglob('*') if p.is_file());shutil.rmtree(snapshot)
backup={'utc':now.isoformat(),'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(files),'all_members_byte_verified':True,'previous_remote_backup':json.loads((docs/'stock-try-edge-step-backup.json').read_text())['remote'],'cleanup':{'duplicate_dependency_snapshot_removed':True,'bytes_reclaimed':size,'all_unique_sources_objects_logs_checks_audits_preserved':True,'one_shared_warm_cache_retained':True,'other_projects_touched':False,'free_bytes':shutil.disk_usage(root).free}}
(docs/(prefix+'-backup.json')).write_text(json.dumps(backup,indent=2)+'\n');Path('/tmp/'+prefix+'-archive-path').write_text(str(archive))
print(json.dumps({'counts':counts,'archive':str(archive),'cleanup':backup['cleanup'],'gate':{k:progress.get(k) for k in ['state','index','total','module']}},indent=2))
