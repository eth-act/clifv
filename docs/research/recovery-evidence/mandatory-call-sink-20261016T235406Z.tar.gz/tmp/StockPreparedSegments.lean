import FV.Backend.Proof.StockPrepareComplete
namespace Backend.Stock.Proof.PreparedSegmentsDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.PerEdgePrep
private theorem checked_facts {vc vcp : VCode} {edges edges' : Array (Array (Array Reg))}
    (h : prepCheckAt vc edges ⟨vcp,edges'⟩ = true) :
    ∃ (ss ps ss' ps' : Array (Array Nat)) (L : Nat → Prop),
      vc.cfg = .ok (ss,ps) ∧ vcp.cfg = .ok (ss',ps') ∧ L 0 ∧ sigmaOf vc vcp 0 = some 0 ∧
      (∀ (b : Nat) (sb : Array Nat) (j target : Nat),L b → ss[b]? = some sb → sb[j]? = some target → L target) ∧
      (∀ b b',L b → sigmaOf vc vcp b = some b' → KeptAt vc vcp edges edges' ss ss' b b') := by
  dsimp only [prepCheckAt] at h
  split at h
  · rename_i ss ps ss' ps' hcfg hcfg'
    simp only [Bool.and_eq_true, decide_eq_true_eq] at h
    obtain ⟨⟨⟨h0, hl0⟩, hall⟩, -⟩ := h
    let L : Nat → Prop := fun b => b < vc.blocks.size ∧ liveOf ss b = true
    have hchk : ∀ b, L b → ∃ b', sigmaOf vc vcp b = some b' ∧ keptOkAt vc vcp edges edges' ss ss' b b' = true ∧
        (ss[b]?.getD #[]).all (fun s => decide (s < vc.blocks.size) && liveOf ss s) = true := by
      intro b ⟨hlt, hlb⟩
      have := all_range hall hlt
      rw [hlb] at this
      simp only [Bool.not_true, Bool.false_or] at this
      split at this
      · cases this
      · rename_i b' hσ
        simp only [Bool.and_eq_true] at this
        exact ⟨b', hσ, this.1, this.2⟩
    have hk : ∀ b b', L b → sigmaOf vc vcp b = some b' → KeptAt vc vcp edges edges' ss ss' b b' := by
      intro b b' hLb hσ
      obtain ⟨b'', hσ', hkept, -⟩ := hchk b hLb
      rw [hσ] at hσ'; cases hσ'
      exact keptOkAt_sound hkept
    have hL : ∀ (b : Nat) (sb : Array Nat) (j s : Nat), L b → ss[b]? = some sb → sb[j]? = some s → L s := by
      intro b sb j s hLb hsb hs
      obtain ⟨-, -, -, hall'⟩ := hchk b hLb
      rw [hsb, Option.getD_some] at hall'
      have := (Array.all_eq_true_iff_forall_mem.mp hall') s (Array.mem_of_getElem? hs)
      simpa only [Bool.and_eq_true, decide_eq_true_eq] using this
    have hL0 : L 0 := by
      refine ⟨?_, hl0⟩
      unfold sigmaOf at h0
      split at h0
      · rename_i vb hvb; exact (Array.getElem?_eq_some_iff.mp hvb).1
      · cases h0
    exact ⟨ss,ps,ss',ps',L,hcfg,hcfg',hL0,h0,hL,hk⟩
  · cases h


/-- Checked preparation transports an actual segment starting anywhere in the
entry block, preserving the exact endpoint registers and world. -/
theorem prep_entry_star {W : Type} {vc vcp : VCode} {edges edges' : Array (Array (Array Reg))}
    {sem : ISem CV W} (semantics : DriverSemG sem)
    (checked : prepCheckAt vc edges ⟨vcp,edges'⟩ = true)
    {k : Nat} {rho : Nat → CV} {w : W} {target : VState CV W}
    (steps : Star (VStepAt vc edges sem) (.run ⟨0,k,rho,w⟩) (.run target)) :
    ∃ mapped,sigmaOf vc vcp target.b = some mapped ∧
      Star (VStepAt vcp edges' sem) (.run ⟨0,k,rho,w⟩)
        (.run ⟨mapped,target.k,target.ρ,target.w⟩) := by
  obtain ⟨ss,ps,ss',ps',L,cfg,cfg',live0,entry,closed,kept⟩ := checked_facts checked
  obtain ⟨mapped,_,mapping,run⟩ := prep_star semantics cfg cfg' closed kept steps _ _ 0 rfl rfl live0 entry
  exact ⟨mapped,mapping,run⟩

/-- Runtime reachability supplies the internal live-block invariant. No live
label, renaming map or structural checker certificate is supplied by callers. -/
theorem prep_reachable_segment {W : Type} {vc vcp : VCode} {edges edges' : Array (Array (Array Reg))}
    {sem : ISem CV W} (semantics : DriverSemG sem)
    (checked : prepCheckAt vc edges ⟨vcp,edges'⟩ = true)
    {k : Nat} {rho : Nat → CV} {w : W} {source target : VState CV W}
    (history : Star (VStepAt vc edges sem) (.run ⟨0,k,rho,w⟩) (.run source))
    (steps : Star (VStepAt vc edges sem) (.run source) (.run target)) :
    ∃ start finish,sigmaOf vc vcp source.b = some start ∧
      sigmaOf vc vcp target.b = some finish ∧
      Star (VStepAt vcp edges' sem) (.run ⟨0,k,rho,w⟩)
        (.run ⟨start,source.k,source.ρ,source.w⟩) ∧
      Star (VStepAt vcp edges' sem) (.run ⟨start,source.k,source.ρ,source.w⟩)
        (.run ⟨finish,target.k,target.ρ,target.w⟩) := by
  obtain ⟨ss,ps,ss',ps',L,cfg,cfg',live0,entry,closed,kept⟩ := checked_facts checked
  obtain ⟨start,liveStart,startMap,before⟩ := prep_star semantics cfg cfg' closed kept history _ _ 0 rfl rfl live0 entry
  obtain ⟨finish,_,finishMap,after⟩ := prep_star semantics cfg cfg' closed kept steps _ _ start rfl rfl liveStart startMap
  exact ⟨start,finish,startMap,finishMap,before,after⟩

/-- Successful original Stock lowering and preparation derive the checker
internally; an actual entry-block segment retains its exact state. -/
theorem stock_prepare_entry_star {W : Type} {f : Clif.Function} {result : Result} {prepared : EdgeVCode}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f)
    (preparedRun : prepareAt result.code result.edgeArgs = .ok prepared)
    {sem : ISem CV W} (semantics : DriverSemG sem)
    {k : Nat} {rho : Nat → CV} {w : W} {target : VState CV W}
    (steps : Star (VStepAt result.code result.edgeArgs sem) (.run ⟨0,k,rho,w⟩) (.run target)) :
    ∃ mapped,sigmaOf result.code prepared.code target.b = some mapped ∧
      Star (VStepAt prepared.code prepared.edges sem) (.run ⟨0,k,rho,w⟩)
        (.run ⟨mapped,target.k,target.ρ,target.w⟩) :=
  prep_entry_star semantics (stock_prepCheckAt_complete lowered scope preparedRun) steps

/-- Nonentry segments compose with real runtime history without adding a
source acceptance condition or asking callers to prove an internal label map. -/
theorem stock_prepare_reachable_segment {W : Type} {f : Clif.Function} {result : Result} {prepared : EdgeVCode}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f)
    (preparedRun : prepareAt result.code result.edgeArgs = .ok prepared)
    {sem : ISem CV W} (semantics : DriverSemG sem)
    {k : Nat} {rho : Nat → CV} {w : W} {source target : VState CV W}
    (history : Star (VStepAt result.code result.edgeArgs sem) (.run ⟨0,k,rho,w⟩) (.run source))
    (steps : Star (VStepAt result.code result.edgeArgs sem) (.run source) (.run target)) :
    ∃ start finish,sigmaOf result.code prepared.code source.b = some start ∧
      sigmaOf result.code prepared.code target.b = some finish ∧
      Star (VStepAt prepared.code prepared.edges sem) (.run ⟨0,k,rho,w⟩)
        (.run ⟨start,source.k,source.ρ,source.w⟩) ∧
      Star (VStepAt prepared.code prepared.edges sem) (.run ⟨start,source.k,source.ρ,source.w⟩)
        (.run ⟨finish,target.k,target.ρ,target.w⟩) :=
  prep_reachable_segment semantics (stock_prepCheckAt_complete lowered scope preparedRun) history steps
end Backend.Stock.Proof.PreparedSegmentsDraft
