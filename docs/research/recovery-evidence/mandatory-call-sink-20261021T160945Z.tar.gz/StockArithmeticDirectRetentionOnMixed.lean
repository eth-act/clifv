import FV.Backend.Lowering.StockMixedNI
import FV.E2E.ProductionPipelineWith
import FVTest.E2E.LinkProof
open Backend E2E E2E.LinkCheck E2E.Elf E2E.BinCheck
private def get {α : Type} (r : Except String α) : IO α :=
  match r with | .ok a => pure a | .error e => throw (IO.userError e)
def main (args : List String) : IO Unit := do
  let dir : System.FilePath := args.headD ""
  let cleanup := args[1]?.getD "" == "Cleanup"
  let retainedNames := args.drop 2
  let (b, exe) ← Front.readBundle dir []
  let A ← get (Front.assemble b)
  let I : LinkInput := {funcs := A.funcs, addrs := Front.linkAddrs b A, syms := [], raStar := 8, D := 0}
  let file ← IO.FS.readBinFile exe
  let some phs := phdrs (fileRd file) | throw (IO.userError "headers")
  unless I.funcs.length == 2 do throw (IO.userError "retained fixture count")
  for fi in I.funcs do
    let raw ← get (Stock.Arithmetic.lowerValidated fi.func)
    let current ← get (Stock.Mixed.lowerValidated fi.func)
    let old ← get (Stock.ScalarAdd.lower fi.func)
    unless raw == current && !(raw == old) && SemanticNI.check fi.func raw && Proof.Driver.lowerCheck fi.func old do
      throw (IO.userError "previous raw arithmetic code/provenance was changed")
    let rawAttempt := I.pipeOfWithLowering Stock.Mixed.lowerValidated (productionStage cleanup) fi
    let byteMatches := match rawAttempt with | .error _ => false | .ok a => artB I (fileRd file) phs a
    unless retainedNames.contains fi.func.name == !byteMatches do
      throw (IO.userError "emitted retained names do not match the direct pre-retry candidate probe")
    let legacy ← get (I.pipeOfWithLowering Stock.ScalarAdd.lower (productionStage cleanup) fi)
    let restored ← get (I.pipeOfWithLowering (Stock.Mixed.lowerWithFallbacks retainedNames) (productionStage cleanup) fi)
    unless restored.vc == (if retainedNames.contains fi.func.name then old else raw) &&
        artB I (fileRd file) phs restored && artB I (fileRd file) phs legacy &&
        restored.fb.words == legacy.fb.words do
      throw (IO.userError "direct selected route must validate original ELF/words without transactional retry")
    IO.println s!"RETAINED_DIRECT_ROUTE {fi.func.name} rawMatch={byteMatches} retained={retainedNames.contains fi.func.name} cleanup={cleanup} passed"
  IO.println "RETAINED_DIRECT_ROUTING_PASS 2"
