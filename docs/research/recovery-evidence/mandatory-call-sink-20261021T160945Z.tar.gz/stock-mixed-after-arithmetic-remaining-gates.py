from pathlib import Path
import os, subprocess as sp, json, datetime, hashlib, traceback
view = Path('/home/lee/clifv/.worktrees/stock-driver-incremental')
canon = Path('/home/lee/clifv/.worktrees/driver-proof-resume')
root = Path('/tmp/stock-mixed-after-arithmetic-remaining-gates')
root.mkdir(exist_ok=True)
state = root / 'progress.json'
logs = {}
head = sp.check_output(['git', 'rev-parse', 'HEAD'], cwd=view, text=True).strip()
assert head == 'bb8d3ae75ca718d248cab68fedaf9083154ca072', 'current-model candidate must be checked out only after verified old module boundary'
for retired_pid, retired_script in [(1235132, '/tmp/stock-arithmetic-arm-model-author-gates.py'), (1235140, '/tmp/stock-execute-scheduler.py')]:
    proc = Path('/proc') / str(retired_pid)
    if (proc / 'cmdline').exists():
        assert retired_script.encode() not in (proc / 'cmdline').read_bytes(), 'retire old metadata after verified healthy kernel drain before launching repaired epoch'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def inputs():
    return {str(p.relative_to(view)): sha(p) for d in ['FV', 'FVTest', 'rust/crates', 'examples/fv-demo/src', 'scripts/audit'] for p in (view / d).rglob('*') if p.is_file() and p.suffix in ['.lean', '.rs']}
frozen_sources = inputs()
(root / 'inputs.json').write_text(json.dumps({'head': head, 'sources': frozen_sources}, indent=2) + '\n')
env = dict(os.environ)
env.update(PATH='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:/home/lee/.cargo/bin:/home/lee/.local/share/clifv-test-tools/usr/bin:/home/lee/.rustup/toolchains/nightly-2026-09-26-x86_64-unknown-linux-gnu/lib/rustlib/x86_64-unknown-linux-gnu/bin:' + str(view / 'rust/target/release') + ':' + env['PATH'], FV_ROOT=str(view), FV_AR='/home/lee/.local/share/clifv-test-tools/usr/bin/llvm-ar', FV_OBJCOPY='/home/lee/.local/share/clifv-test-tools/usr/bin/llvm-objcopy', FV_LAKE_CACHE=str(canon / '.lake/artifact-cache'), FV_MEMCAP='8G', OMP_NUM_THREADS='2', OMP_THREAD_LIMIT='2', LEAN_NUM_THREADS='2', CARGO_BUILD_JOBS='2', CLIF_NATIVE_QEMU='/home/lee/.local/share/clifv-test-tools/usr/bin/qemu-aarch64-static', LLVM_MC='/home/lee/.local/share/clifv-test-tools/usr/bin/llvm-mc', PYTHONPATH=str(view / 'scripts'))
os.sched_setaffinity(0, sorted(os.sched_getaffinity(0))[:8])

def report(status, **kw):
    d = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'state': status, 'pid': os.getpid(), 'head': head, 'logs': logs, **kw}
    state.write_text(json.dumps(d, indent=2) + '\n')
    print(json.dumps({k: v for k, v in d.items() if k != 'logs'}), flush=True)

def frozen():
    assert sp.check_output(['git', 'rev-parse', 'HEAD'], cwd=view, text=True).strip() == head
    assert inputs() == frozen_sources, 'source changed during gates'

def run(name, args, cwd=view):
    frozen()
    p = root / (name + '.log')
    report('running', phase=name, log=str(p))
    with p.open('w') as f:
        command = args if args[:2] == ['python3', '/tmp/stock-execute-scheduler.py'] else [str(view / 'scripts/memcap.sh'), *args]
        r = sp.run(command, cwd=cwd, env=env, stdout=f, stderr=sp.STDOUT)
    assert r.returncode == 0, (name, r.returncode, str(p))
    frozen()
    logs[name] = {'path': str(p), 'sha256': sha(p)}
    return p
try:
 prior_root=Path('/tmp/stock-arithmetic-retained-route-gates')
 partial=Path('/tmp/stock-mixed-after-arithmetic-complete-gates');previous=json.loads((partial/'progress.json').read_text())
 assert previous['state']=='failed' and 'owned-constants' in previous['error'] and len(previous['logs'])==8
 assert previous['head']==head
 assert json.loads((partial/'inputs.json').read_text())['sources']==frozen_sources
 for name,record in previous['logs'].items():
  assert sha(Path(record['path']))==record['sha256'],name
  logs[name]=record
 run('owned-constants',['lake','env','lean','--root=/tmp','/tmp/stock-mixed-current-all-owned.lean'])
 run('spill-cycle-all-owned',['lake','env','lean','--root=/tmp','/tmp/StockSpillCycleRepairAxioms.lean'])
 run('crate-proofs',['lake','build'],view/'crate-proofs')
 native=root/'native-artifacts';assert not native.exists()
 env['STOCK_MIXED_NATIVE_OUT']=str(native)
 run('mixed-real-runtime-linked-generated-cli',['python3','scripts/check-stock-mixed-integration.py','--output',str(root/'mixed-integration')])
 env.pop('STOCK_MIXED_NATIVE_OUT')
 run('mixed-native-byte-executions',['python3','scripts/check-stock-mixed-native.py',str(native)])
 native_receipt=json.loads((native/'native-receipt.json').read_text());assert native_receipt['state']=='passed' and native_receipt['actual_lean_encoded_objects']==24 and native_receipt['lean_byte_executions']==624 and native_receipt['failures']==0 and native_receipt['disagreements']==0
 run('runtime',['bash','scripts/lean-backend-filetests.sh'])
 run('encoder',['bash','scripts/lean-backend-encode-check.sh'])
 parity={}
 def ids(path):
  fs=json.loads(path.read_text())['functions'];d={(f['file'],f['index'],f['function']):tuple(f['stages']) for f in fs};assert len(d)==len(fs);return d
 for label,flags,previous in [('e2e',[],'legacy-dead-cleanup-final-e2e-identities.json'),('legacy-e2e',['--no-dead-cleanup'],'legacy-dead-cleanup-final-legacy-e2e-identities.json')]:
  actual=root/(label+'-identities.json')
  run(label,['lake','exe','lean-e2e-check',*flags,'--identity-report',str(actual)])
  a=ids(Path('/tmp')/previous);b=ids(actual);assert len(a)==1150 and a.keys()<=b.keys();assert all(a[k]==b[k] for k in a)
  prior=ids(Path('/tmp/stock-all-reconcile-gates')/(label+'-identities.json'));assert len(prior)==1159 and prior.keys()<=b.keys();assert all(prior[k]==b[k] for k in prior)
  parity[label]={'original':len(a),'prior_shipped':len(prior),'current':len(b),'all_original_and_prior_identities_and_ordered_stages_preserved':True}
 (root/'identity-stage-parity.json').write_text(json.dumps(parity,indent=2)+'\n')
 bundles=sorted((view/'examples/fv-demo/target/fv/plain-leanlink-verified-leanld/bin-check').glob('*/bundle.json'))
 assert bundles,'verified fv-demo source bundle missing'
 for i,p in enumerate(bundles):
  run(f'link-check-{i}',['lake','exe','link-check',str(p.parent)])
 generated=Path('/tmp/stock-d0-linked-fixture')
 leanpath=sp.check_output(['lake','env','printenv','LEAN_PATH'],cwd=view,env=env,text=True).strip()
 env['LEAN_PATH']=str(generated)+':'+leanpath
 for name in ['StockD0MixedPlain','StockD0MixedCleanup']:
  p=generated/'Crates'/(name+'.lean');assert p.is_file()
  run('generated-'+name,['lean','--root='+str(generated),'-o',str(p.with_suffix('.olean')),str(p)])
 env.pop('LEAN_PATH',None)
 run('actual-linked-generated-proofs',['python3','/tmp/stock-production-linked-proper-check.py'])
 run('production-runtime',['lake','env','lean','--run','FVTest/Backend/Lowering/StockProductionRuntime.lean'])
 run('all-configurations-runtime',['lake','env','lean','--run','FVTest/Backend/Lowering/StockProductionAllRuntime.lean'])
 run('all-configurations-linked-proofs',['python3','/tmp/stock-production-all-linked-check.py'])
 run('production-cli-original-bundles',['python3','/tmp/stock-production-cli-original-bundles-check-semantic.py'])
 run('production-cli-all-configurations',['python3','/tmp/stock-production-all-cli-check-semantic.py'])
 run('scalar-runtime',['lake','env','lean','--run','FVTest/Backend/Lowering/StockScalarRuntime.lean'])
 run('scalar-regalloc2-matched',['lake','env','lean','--root=/tmp','--run','/tmp/StockScalarRegalloc2Comparison.lean'])
 run('scalar-linked-proofs',['python3','/tmp/stock-scalar-linked-check.py'])
 run('scalar-real-cli',['python3','/tmp/stock-scalar-cli-check-semantic.py'])
 assert sha(view/'FVTest/Backend/Lowering/StockArithmeticRuntime.lean')=='b00043a15c8616e6b4b78bfa2d24634eeacb825bbd75d56db6aa1b1626641b1c'
 runtime_log=run('arithmetic-dual-allocator-runtime',['lake','env','lean','--run','FVTest/Backend/Lowering/StockArithmeticRuntime.lean'])
 runtime_text=runtime_log.read_text()
 assert runtime_text.count('Stock arithmetic lean ')==6 and runtime_text.count('Stock arithmetic regalloc2 ')==6
 assert 'Stock arithmetic missing-binary negative control passed' in runtime_text
 (root/'arithmetic-strict-regalloc.json').write_text(json.dumps({'state':'strict_real_oracle_runtime_passed','head':head,'runtime_sha256':sha(view/'FVTest/Backend/Lowering/StockArithmeticRuntime.lean'),'log':str(runtime_log),'log_sha256':sha(runtime_log),'positive_case_grid':24,'missing_binary_negative_control':True},indent=2)+'\n')
 extra_source=Path('/tmp/StockArithmeticCommittedRoute.lean')
 assert sha(extra_source)=='d61c5d6f2702460bdb016a7a3907dcf76c8bda8f0181f36b6f2f191aa4de8f72'
 extra_log=run('arithmetic-committed-route-extra',['lake','env','lean','--root=/tmp',str(extra_source)])
 assert extra_log.read_text().count('Stock arithmetic committed ')==24
 (root/'committed-route-extra-gate.json').write_text(json.dumps({'state':'passed','head':head,'source':str(extra_source),'sha256':sha(extra_source),'log':str(extra_log),'log_sha256':sha(extra_log),'pass_records':24},indent=2)+'\n')
 run('arithmetic-linked-generated-proofs',['python3','/tmp/stock-arithmetic-linked-check.py'])
 run('arithmetic-native-cli',['python3','/tmp/stock-arithmetic-cli-check-on-mixed.py'])
 for example in ['fv-demo','survey']:
  run('verified-'+example,['bash','examples/compare.sh','examples/'+example,'--lean-link','--verified','--keep-temps'])
 def axioms(folder):
  out={}
  for p in Path(folder).glob('*.log'):
   flat=' '.join(p.read_text().split())
   for n,a in re.findall(r"'(.+?)' depends on axioms: \[([^\]]*)\]",flat):out[n]=sorted(x.strip() for x in a.split(',') if x.strip())
   for n in re.findall(r"'(.+?)' does not depend on any axioms",flat):out[n]=[]
  return out
 before=axioms(prior_root/'axiom-audit');after=axioms(root/'axiom-audit');assert len(before)>=1241
 missing=sorted(set(before)-set(after));drift={n:{'before':v,'after':after.get(n)} for n,v in before.items() if n in after and after[n]!=v}
 parity_axioms={'previous_roots':len(before),'current_roots':len(after),'missing':missing,'changed_sets':drift,'all_previous_axiom_sets_preserved':not missing and not drift};(root/'axiom-set-parity.json').write_text(json.dumps(parity_axioms,indent=2)+'\n');assert parity_axioms['all_previous_axiom_sets_preserved'],parity_axioms
 for name,record in logs.items():assert sha(Path(record['path']))==record['sha256'] and 'Error: index out of bounds' not in Path(record['path']).read_text(),name
 report('per_pr_gates_passed',identity_stage_parity=parity,remaining='Fetch current main, reconcile if needed, open non-draft implementation PR and author squash promptly. Full original #140 remains active.')
except BaseException as e:
 report('failed',error=repr(e),traceback=traceback.format_exc());raise
