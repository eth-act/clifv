from pathlib import Path
import os, subprocess as sp, json, datetime, hashlib, traceback
view = Path('/home/lee/clifv/.worktrees/stock-driver-incremental')
canon = Path('/home/lee/clifv/.worktrees/driver-proof-resume')
root = Path('/tmp/stock-mixed-final-retention-gates')
root.mkdir(exist_ok=True)
state = root / 'progress.json'
logs = {}
head = sp.check_output(['git', 'rev-parse', 'HEAD'], cwd=view, text=True).strip()
assert head == 'd7f93237450be61d695bb36dfca53a2aae0d91d3', 'current-model candidate must be checked out only after verified old module boundary'
for retired_pid, retired_script in [(1235132, '/tmp/stock-arithmetic-arm-model-author-gates.py'), (1235140, '/tmp/stock-execute-scheduler.py')]:
    proc = Path('/proc') / str(retired_pid)
    if (proc / 'cmdline').exists():
        assert retired_script.encode() not in (proc / 'cmdline').read_bytes(), 'retire old metadata after verified healthy kernel drain before launching repaired epoch'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def inputs():
    return {str(p.relative_to(view)): sha(p) for d in ['FV', 'FVTest', 'rust/crates', 'examples/fv-demo/src', 'scripts/audit'] for p in (view / d).rglob('*') if p.is_file() and p.suffix in ['.lean', '.rs']}
frozen_sources = inputs()
(root / 'inputs.json').write_text(json.dumps({'head': head, 'sources': frozen_sources}, indent=2) + '\n')
env = dict(os.environ)
env.update(PATH='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:/home/lee/.cargo/bin:/home/lee/.local/share/clifv-test-tools/usr/bin:/home/lee/.rustup/toolchains/nightly-2026-09-26-x86_64-unknown-linux-gnu/lib/rustlib/x86_64-unknown-linux-gnu/bin:' + str(view / 'rust/target/release') + ':' + env['PATH'], FV_ROOT=str(view), FV_AR='/home/lee/.local/share/clifv-test-tools/usr/bin/llvm-ar', FV_OBJCOPY='/home/lee/.local/share/clifv-test-tools/usr/bin/llvm-objcopy', FV_LAKE_CACHE=str(canon / '.lake/artifact-cache'), FV_MEMCAP='8G', OMP_NUM_THREADS='2', OMP_THREAD_LIMIT='2', LEAN_NUM_THREADS='2', CARGO_BUILD_JOBS='2', CLIF_NATIVE_QEMU='/home/lee/.local/share/clifv-test-tools/usr/bin/qemu-aarch64-static', LLVM_MC='/home/lee/.local/share/clifv-test-tools/usr/bin/llvm-mc', PYTHONPATH=str(view / 'scripts'))
os.sched_setaffinity(0, sorted(os.sched_getaffinity(0))[:8])

def report(status, **kw):
    d = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'state': status, 'pid': os.getpid(), 'head': head, 'logs': logs, **kw}
    state.write_text(json.dumps(d, indent=2) + '\n')
    print(json.dumps({k: v for k, v in d.items() if k != 'logs'}), flush=True)

def frozen():
    assert sp.check_output(['git', 'rev-parse', 'HEAD'], cwd=view, text=True).strip() == head
    assert inputs() == frozen_sources, 'source changed during gates'

def run(name, args, cwd=view):
    frozen()
    p = root / (name + '.log')
    report('running', phase=name, log=str(p))
    with p.open('w') as f:
        command = args if args[:2] == ['python3', '/tmp/stock-execute-scheduler.py'] else [str(view / 'scripts/memcap.sh'), *args]
        r = sp.run(command, cwd=cwd, env=env, stdout=f, stderr=sp.STDOUT)
    assert r.returncode == 0, (name, r.returncode, str(p))
    frozen()
    logs[name] = {'path': str(p), 'sha256': sha(p)}
    return p
import re,shutil

try:
 prior_root=Path('/tmp/stock-arithmetic-retained-route-gates')
 partial=Path('/tmp/stock-mixed-unified-generated-gates');previous=json.loads((partial/'progress.json').read_text())
 assert previous['state']=='failed' and 'arithmetic-native-cli' in previous['error'] and len(previous['logs'])==36
 assert previous['head']==head and json.loads((partial/'inputs.json').read_text())['sources']==frozen_sources
 for name,record in previous['logs'].items():
  assert sha(Path(record['path']))==record['sha256'],name
  logs[name]=record
 shutil.copytree(partial/'axiom-audit',root/'axiom-audit',dirs_exist_ok=False)
 for file in ['identity-stage-parity.json','arithmetic-strict-regalloc.json','committed-route-extra-gate.json']:
  shutil.copyfile(partial/file,root/file)
 (root/'completed-gate-provenance.json').write_text(json.dumps({'head':head,'all_frozen_source_hashes_unchanged':True,'passed_original_logs':36,'original_failed_arithmetic_cli_not_reused':True,'fixed_external_test':'Actual pre-retry callback retained-name selection, direct no-retry artifact/ELF/words and unchanged previous arithmetic code; no production/proof source change','direct_probe':'/tmp/stock-mixed-unified-generated-gates/direct-retention-probe.log'},indent=2)+'\n')
 run('arithmetic-native-cli',['python3','/tmp/stock-arithmetic-cli-check-on-mixed.py'])
 for example in ['fv-demo','survey']:
  run('verified-'+example,['bash','examples/compare.sh','examples/'+example,'--lean-link','--verified','--keep-temps'])
 def axioms(folder):
  out={}
  for p in Path(folder).glob('*.log'):
   flat=' '.join(p.read_text().split())
   for n,a in re.findall(r"'(.+?)' depends on axioms: \[([^\]]*)\]",flat):out[n]=sorted(x.strip() for x in a.split(',') if x.strip())
   for n in re.findall(r"'(.+?)' does not depend on any axioms",flat):out[n]=[]
  return out
 before=axioms(prior_root/'axiom-audit');after=axioms(root/'axiom-audit');assert len(before)>=1241
 missing=sorted(set(before)-set(after));drift={n:{'before':v,'after':after.get(n)} for n,v in before.items() if n in after and after[n]!=v}
 parity_axioms={'previous_roots':len(before),'current_roots':len(after),'missing':missing,'changed_sets':drift,'all_previous_axiom_sets_preserved':not missing and not drift};(root/'axiom-set-parity.json').write_text(json.dumps(parity_axioms,indent=2)+'\n');assert parity_axioms['all_previous_axiom_sets_preserved'],parity_axioms
 for name,record in logs.items():assert sha(Path(record['path']))==record['sha256'] and 'Error: index out of bounds' not in Path(record['path']).read_text(),name
 report('per_pr_gates_passed',identity_stage_parity=parity,remaining='Fetch current main, reconcile if needed, open non-draft implementation PR and author squash promptly. Full original #140 remains active.')
except BaseException as e:
 report('failed',error=repr(e),traceback=traceback.format_exc());raise
