from pathlib import Path
import os,signal,time,json,datetime,subprocess as sp,hashlib
sched=3016520;root=Path('/tmp/stock-mixed-realize-drain-queue');root.mkdir(exist_ok=True);source=Path('/tmp/StockMixedFlagRealizeChecked.lean');digest=hashlib.sha256(source.read_bytes()).hexdigest();stopped=False
def report(state,**extra):
 d={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':state,'pid':os.getpid(),'scheduler':sched,'source':str(source),'sha256':digest,**extra};(root/'progress.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)
def live(p):
 try:return Path(f'/proc/{p}/stat').read_text().split()[2]!='Z'
 except FileNotFoundError:return False
try:
 assert b'stock-execute-scheduler.py' in Path(f'/proc/{sched}/cmdline').read_bytes()
 os.kill(sched,signal.SIGSTOP);stopped=True
 for _ in range(100):
  if Path(f'/proc/{sched}/stat').read_text().split()[2]=='T':break
  time.sleep(.01)
 else:raise RuntimeError('launcher not stopped')
 kids=Path(f'/proc/{sched}/task/{sched}/children').read_text().split();kids=[p for p in kids if live(p)];assert len(kids)<=1,kids
 for p in kids:
  caps=[v for v in Path(f'/proc/{p}/environ').read_bytes().split(b'\0') if v.startswith(b'FV_MEMCAP=')];assert len(caps)==1
  cap=caps[0].decode().split('=',1)[1];amount=int(cap[:-1])*(1024 if cap[-1]=='G' else 1);assert 12288<amount<=16384,caps
 deadline=time.monotonic()+600;last=0
 while any(live(p) for p in kids):
  if time.monotonic()>deadline:raise TimeoutError('existing heavy proof retained; scratch not started')
  if time.monotonic()-last>=30:report('waiting_existing_heavy_only',existing_wrappers=kids);last=time.monotonic()
  time.sleep(1)
 assert hashlib.sha256(source.read_bytes()).hexdigest()==digest
 report('checking_realization_after_heavy_terminal')
 with (root/'check.log').open('w') as f:
  r=sp.run(['python3','/tmp/stock-mixed-reserved-check.py',str(source),'flag-realize-owned'],stdout=f,stderr=sp.STDOUT)
 log=Path('/tmp/stock-mixed-draft-check/flag-realize-owned.log').read_text()
 assert r.returncode==0 and 'MIXED_FLAG_ALL_OWNED_STANDARD_ONLY' in log and ': error' not in log,(r.returncode,log[-1800:])
 report('realization_kernel_and_owned_audit_passed',log='/tmp/stock-mixed-draft-check/flag-realize-owned.log')
except BaseException as e:
 report('failed_or_not_started',error=repr(e));raise
finally:
 if stopped:os.kill(sched,signal.SIGCONT)
 print(json.dumps({'scheduler_resumed':True}),flush=True)
