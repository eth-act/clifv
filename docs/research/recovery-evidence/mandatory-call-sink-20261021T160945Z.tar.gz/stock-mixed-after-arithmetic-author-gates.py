from pathlib import Path
import os, subprocess as sp, json, datetime, hashlib, traceback
view = Path('/home/lee/clifv/.worktrees/stock-driver-incremental')
canon = Path('/home/lee/clifv/.worktrees/driver-proof-resume')
root = Path('/tmp/stock-mixed-after-arithmetic-author-gates')
root.mkdir(exist_ok=True)
state = root / 'progress.json'
logs = {}
head = sp.check_output(['git', 'rev-parse', 'HEAD'], cwd=view, text=True).strip()
assert head == 'd52355b8632ec1807589bad963c08c3f684056fe', 'current-model candidate must be checked out only after verified old module boundary'
for retired_pid, retired_script in [(1235132, '/tmp/stock-arithmetic-arm-model-author-gates.py'), (1235140, '/tmp/stock-execute-scheduler.py')]:
    proc = Path('/proc') / str(retired_pid)
    if (proc / 'cmdline').exists():
        assert retired_script.encode() not in (proc / 'cmdline').read_bytes(), 'retire old metadata after verified healthy kernel drain before launching repaired epoch'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def inputs():
    return {str(p.relative_to(view)): sha(p) for d in ['FV', 'FVTest', 'rust/crates', 'examples/fv-demo/src', 'scripts/audit'] for p in (view / d).rglob('*') if p.is_file() and p.suffix in ['.lean', '.rs']}
frozen_sources = inputs()
(root / 'inputs.json').write_text(json.dumps({'head': head, 'sources': frozen_sources}, indent=2) + '\n')
env = dict(os.environ)
env.update(PATH='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:/home/lee/.cargo/bin:/home/lee/.local/share/clifv-test-tools/usr/bin:/home/lee/.rustup/toolchains/nightly-2026-09-26-x86_64-unknown-linux-gnu/lib/rustlib/x86_64-unknown-linux-gnu/bin:' + str(view / 'rust/target/release') + ':' + env['PATH'], FV_ROOT=str(view), FV_AR='/home/lee/.local/share/clifv-test-tools/usr/bin/llvm-ar', FV_OBJCOPY='/home/lee/.local/share/clifv-test-tools/usr/bin/llvm-objcopy', FV_LAKE_CACHE=str(canon / '.lake/artifact-cache'), FV_MEMCAP='8G', OMP_NUM_THREADS='2', OMP_THREAD_LIMIT='2', LEAN_NUM_THREADS='2', CARGO_BUILD_JOBS='2', CLIF_NATIVE_QEMU='/home/lee/.local/share/clifv-test-tools/usr/bin/qemu-aarch64-static', LLVM_MC='/home/lee/.local/share/clifv-test-tools/usr/bin/llvm-mc', PYTHONPATH=str(view / 'scripts'))
os.sched_setaffinity(0, sorted(os.sched_getaffinity(0))[:8])

def report(status, **kw):
    d = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'state': status, 'pid': os.getpid(), 'head': head, 'logs': logs, **kw}
    state.write_text(json.dumps(d, indent=2) + '\n')
    print(json.dumps({k: v for k, v in d.items() if k != 'logs'}), flush=True)

def frozen():
    assert sp.check_output(['git', 'rev-parse', 'HEAD'], cwd=view, text=True).strip() == head
    assert inputs() == frozen_sources, 'source changed during gates'

def run(name, args, cwd=view):
    frozen()
    p = root / (name + '.log')
    report('running', phase=name, log=str(p))
    with p.open('w') as f:
        command = args if args[:2] == ['python3', '/tmp/stock-execute-scheduler.py'] else [str(view / 'scripts/memcap.sh'), *args]
        r = sp.run(command, cwd=cwd, env=env, stdout=f, stderr=sp.STDOUT)
    assert r.returncode == 0, (name, r.returncode, str(p))
    frozen()
    logs[name] = {'path': str(p), 'sha256': sha(p)}
    return p
try:
 import re
 prior=Path('/tmp/stock-arithmetic-retained-route-gates');p=json.loads((prior/'progress.json').read_text());assert p['state']=='per_pr_gates_passed'
 old=json.loads((prior/'inputs.json').read_text())['sources']
 deps={str(f.relative_to(view))[:-5].replace('/','.'):set(re.findall(r'^(?:public\s+|meta\s+|private\s+)*import\s+(\S+)',f.read_text(),re.M)) for d in ['FV','FVTest'] for f in (view/d).rglob('*.lean')}
 changed=sorted(n for n in old.keys()|frozen_sources.keys() if old.get(n)!=frozen_sources.get(n))
 affected={n[:-5].replace('/','.') for n in changed if n.endswith('.lean') and n.startswith(('FV/','FVTest/'))}
 while True:
  extra={m for m,ds in deps.items() if ds&affected}-affected
  if not extra:break
  affected|=extra
 unaffected=set(deps)-affected
 for m in unaffected:
  name=m.replace('.','/')+'.lean';assert old.get(name)==frozen_sources.get(name),name
 for name in ['lean-toolchain','lakefile.toml','lake-manifest.json','scripts/memcap.sh']:
  assert sp.check_output(['git','show','95b8710895e24a6bc40014e589b611b792f49b5b:'+name],cwd=view)==(view/name).read_bytes(),name
 run('unchanged-normal-keys-current',['lake','build','--no-build',*sorted(unaffected)])
 only=root/'affected-modules.txt';only.write_text('\n'.join(sorted(affected))+'\n')
 (root/'module-reuse-manifest.json').write_text(json.dumps({'base_main':'95b8710895e24a6bc40014e589b611b792f49b5b','current_head':head,'changed_sources':changed,'unaffected_count':len(unaffected),'affected_count':len(affected),'source_module_count':len(deps),'unchanged_current_normal_keys_verified':True,'unaffected_modules':sorted(unaffected),'affected_modules':sorted(affected)},indent=2)+'\n')
 run('affected-modules',['python3','/tmp/stock-execute-scheduler.py','--budget','16G','--max-jobs','2','--max-cap','16G','--default-cap','8G','--only',str(only),'--out',str(root/'affected-modules'),'FV','FVTest'])
 run('full-source-module-keys-current',['lake','build','--no-build','FV','FVTest'])
 run('library-and-affected-tools',['lake','build','FV','FVTest','lean-backend','lean-e2e-check','link-check','lean-link'])
 run('all-axiom-audits',['python3','scripts/axiom-audit.py','--log-dir',str(root/'axiom-audit')])
 report('normal_module_tools_and_checked_in_audits_passed_remaining_activation_gates_pending',remaining='All-owned/public MCP trust and exact prior AX/source-header parity, strict actual allocator/native and whole function witnesses, Mixed integration script including actual linked/generated/defaultCLI, all previous production class routes/retained fixtures, runtime/encoder/both-mode identity-stage parity, verified fv-demo/survey, fresh main/reconciliation and terminal receipt/PR/squash. Do not claim activation from this batch alone; full140 stays active.')
except BaseException as e:
 report('failed',error=repr(e),traceback=traceback.format_exc());raise
