from pathlib import Path
import ast,datetime,hashlib,json,os,re,subprocess,time,traceback
view=Path('/home/lee/clifv/.worktrees/stock-driver-incremental')
root=Path('/tmp/stock-mixed-unified-generated-gates');out=Path('/tmp/stock-mixed-terminal-review');out.mkdir(exist_ok=True)
expected='d7f93237450be61d695bb36dfca53a2aae0d91d3'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def report(state,**kw):
 d={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':state,'pid':os.getpid(),'source_head':expected,**kw};(out/'progress.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items() if k!='gate_logs'}),flush=True)
def git(*args):return subprocess.check_output(['git',*args],cwd=view,text=True).strip()
def axioms(folder):
 result={}
 for p in Path(folder).glob('*.log'):
  text=' '.join(p.read_text().split())
  for n,a in re.findall(r"'(.+?)' depends on axioms: \[([^\]]*)\]",text):result[n]=sorted(x.strip() for x in a.split(',') if x.strip())
  for n in re.findall(r"'(.+?)' does not depend on any axioms",text):result[n]=[]
 return result
try:
 pid=4081528;cmd=Path('/proc')/str(pid)/'cmdline'
 report('waiting_for_live_original_controller',controller_pid=pid)
 while cmd.exists() and b'/tmp/stock-mixed-unified-generated-gates.py' in cmd.read_bytes():time.sleep(2)
 state=json.loads((root/'progress.json').read_text());assert state['head']==expected
 # The running controller was found to lack its closing regex import. Preserve
 # its actual terminal state and independently perform that closing audit; no
 # failed compiler/test command may be accepted here.
 if state['state']!='per_pr_gates_passed':
  assert state['state']=='failed' and 'NameError' in state['error'] and "'re'" in state['error'],state.get('error')
 logs=state['logs'];required=set()
 for node in ast.walk(ast.parse(Path('/tmp/stock-mixed-after-arithmetic-complete-gates.py').read_text())):
  if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id=='run' and node.args and isinstance(node.args[0],ast.Constant):required.add(node.args[0].value)
 required.update(['e2e','legacy-e2e','generated-StockD0MixedPlain','generated-StockD0MixedCleanup','verified-fv-demo','verified-survey','source-module-keys-current-final','tool-keys-current-final'])
 assert required<=logs.keys(),sorted(required-logs.keys())
 assert any(k.startswith('link-check-') for k in logs)
 for name,rec in logs.items():
  assert sha(rec['path'])==rec['sha256'],name
  assert 'Error: index out of bounds' not in Path(rec['path']).read_text(),name
 assert git('rev-parse','HEAD')==expected and not git('diff','--name-only') and not git('diff','--cached','--name-only')
 frozen=json.loads((root/'inputs.json').read_text());actual={str(p.relative_to(view)):sha(p) for folder in ['FV','FVTest','rust/crates','examples/fv-demo/src','scripts/audit'] for p in (view/folder).rglob('*') if p.is_file() and p.suffix in ['.lean','.rs']};assert frozen['sources']==actual
 before=axioms('/tmp/stock-arithmetic-retained-route-gates/axiom-audit');after=axioms(root/'axiom-audit');assert len(before)==1241
 missing=sorted(before.keys()-after.keys());changed={n:{'before':v,'after':after[n]} for n,v in before.items() if n in after and after[n]!=v};assert not missing and not changed,(missing,changed)
 parity={'previous_roots':len(before),'current_roots':len(after),'missing':missing,'changed_sets':changed,'all_previous_axiom_sets_preserved':True};(out/'axiom-set-parity.json').write_text(json.dumps(parity,indent=2)+'\n')
 identity=json.loads((root/'identity-stage-parity.json').read_text());assert set(identity)=={'e2e','legacy-e2e'}
 for rec in identity.values():assert rec['original']==1150 and rec['prior_shipped']==1159 and rec['current']>=1159 and rec['all_original_and_prior_identities_and_ordered_stages_preserved']
 integ=json.loads((root/'mixed-integration/receipt.json').read_text());assert integ['state']=='passed' and integ['head']==expected and integ['runtime_cases']==24 and integ['strict_missing_oracle_negative_control']
 assert len(integ['generated_roots'])==12 and len(integ['cli_sources'])==4
 for name,rec in integ['records'].items():assert rec['returncode']==0 and sha(rec['log'])==rec['sha256'],name
 native=json.loads((root/'native-artifacts/native-receipt.json').read_text());assert native['state']=='passed' and native['actual_lean_encoded_objects']==24 and native['lean_byte_executions']==624 and native['failures']==0 and native['disagreements']==0
 strict=json.loads((root/'arithmetic-strict-regalloc.json').read_text());assert strict['head']==expected and strict['positive_case_grid']==24 and strict['missing_binary_negative_control'] and sha(strict['log'])==strict['log_sha256']
 extra=json.loads((root/'committed-route-extra-gate.json').read_text());assert extra['state']=='passed' and extra['head']==expected and extra['pass_records']==24 and sha(extra['log'])==extra['log_sha256']
 review=json.loads(Path('/tmp/stock-mixed-after-arithmetic-author-gates/current-mcp-review.json').read_text());assert review['state']=='passed' and not review['warnings'] and set(review['axioms'])=={'propext','Classical.choice','Quot.sound'}
 assert git('diff','--name-only',review['source_head'],expected)== 'scripts/check-stock-mixed-integration.py','proof/MCP inputs changed after review'
 source_preflight=json.loads((view/'docs/research/stock-mixed-on-landed-arithmetic.json').read_text());assert source_preflight['retained_old_header_count']==25
 for rec in source_preflight['retained_old_headers']:
  text=(view/rec['file']).read_text();pattern=r'(?m)^(?:private |protected |noncomputable )*theorem\s+'+re.escape(rec['name'])+r'\b';m=re.search(pattern,text);assert m
  header=text[m.start():text.index(':=',m.start())].strip();assert hashlib.sha256(header.encode()).hexdigest()==rec['header_sha256'],rec
 result={'state':'per_pr_gates_passed','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'validated_source_head':expected,'gate_logs':logs,'gate_records':len(logs),'original_controller_terminal_state':state['state'],'original_controller_error':state.get('error'),'closing_audit_independently_completed':True,'normal_source_files_verified':len(actual),'identity_stage_parity':identity,'axiom_set_parity':parity,'mixed_integration':integ,'native_execution':native,'retained_arithmetic_strict_runtime':strict,'retained_arithmetic_positive_routes':extra,'mcp_review':review,'old_theorem_headers_preserved':25,'full_original_140_complete':False}
 (out/'terminal-author-receipt.json').write_text(json.dumps(result,indent=2)+'\n');report('per_pr_gates_passed',validated_source_head=expected,gate_records=len(logs),receipt=str(out/'terminal-author-receipt.json'),remaining='Fetch/reconcile fresh main, terminal backup/source+receipt docs, substantive Mixed PR/author squash, notify integrator, then logical and full140 obligations.')
except BaseException as e:
 report('failed',error=repr(e),traceback=traceback.format_exc());raise
