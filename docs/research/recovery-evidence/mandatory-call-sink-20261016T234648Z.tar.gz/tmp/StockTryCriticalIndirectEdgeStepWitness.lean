import StockTryCriticalTransition
import StockTryCriticalIndirectValuesWitness
import StockTryNormalIndirectSourceValues
import StockTryNormalGraph
import StockTryCriticalNormalWitness
import FV.E2E.RegLevelDriverSem
namespace Backend.Stock.Proof.TryCriticalIndirectEdgeStepWitnessDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open TryNormalIndirectSourceValuesDraft TryNormalValueColumnsDraft TryNormalGraphDraft TryNormalCfgDraft
open TryNormalEdgeValuesDraft TryNormalCopiesDraft TryNormalControlDraft
open TryIndirectSourceRunDraft TryBranchAbiDraft TryResolvedRunsDraft TryWholeSourceReservationDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
open TryCriticalTransitionDraft TryLastPositionDraft
private def function := CriticalSplitFixture.function true
private def signature := function.sig
private def table : Clif.ExnTable := {sig := 0,normal := ⟨1,[.ret 0]⟩,items := []}
private def model : ExtSem := ⟨fun _ _ w => some ([17],w),fun _ _ => 4096,0,fun _ w => Arm.read_pstate w⟩
private def environment : Clif.Env := {
  extern := fun _ => some (fun _ cm => .returned [⟨.i64,17⟩] cm),names := ["callee"],sigOf := fun _ => some signature }
private def symbols : String → Option Nat := fun name => if name = "callee" then some 4096 else none
private def memory : Clif.Mem := {Clif.Mem.empty with symbols}
private def relation : MemRelT := fun _ cm _ => cm.symbols = symbols
private def fr : Clif.Frame := {
  func := function,regs := Clif.Regs.empty.set 0 ⟨.i64,4096⟩,slots := [],body := [],term := function.blocks[0]!.term }
private def resultRegs : Clif.Regs := fr.regs.set function.freshValue ⟨.i64,17⟩
private def normalCall : Clif.BlockCall := ⟨1,[function.freshValue]⟩
private def pending : Clif.Frame := {fr with regs := resultRegs,body := [],term := .jump normalCall}
private def entered : Clif.Frame := {pending with regs := resultRegs.set 2 ⟨.i64,17⟩,body := [],term := .ret [2]}
theorem stock_complete_critical_indirect_normal_values_edge_execution_witness :
    ∃ (result : Result) (p : EdgeVCode) (rf : RFunc) (af : AFunc),
      Stock.lower function = .ok result ∧ LowerScope function ∧ Dominated function ∧ ArityOk function ∧ AbiSigsOk function ∧
      prepareAt result.code result.edgeArgs = .ok p ∧ rf = spillAllocAt p.code p.edges ∧
      checkAllocAt p.code p.edges rf = .ok () ∧ lowerRFunc p.code rf = .ok af ∧
      stockSourceTable function = .ok #[#[1],#[],#[1]] ∧
      sourceIndegree #[#[1],#[],#[1]] function.blocks.length = .ok #[0,2,0] ∧
      Node.original 2 ∉ result.order.nodes.toList ∧ result.order.nodes[1]? = some (.edge 0 0 1) ∧
      XCallsIndOk environment [signature] relation model ∧
      IndCallsRefineP (fun _ _ _ _ => True) environment (indSigs function) relation (csem (fun _ => False) ⟨0,0⟩ model) ∧
      Clif.enterBlock pending normalCall = .ok entered ∧
      (∃ raw : IndirectTryRun function result 0 0 function.blocks[0]! signature
        (csem (fun _ => False) ⟨0,0⟩ model) relation fr (fun _ => 4096) Arm.ArmState.default [⟨.i64,17⟩] memory,
        ∃ (k : Nat) (i : MInst) (ops : Array Operand) (atCall : Nat → CV) (world : Arm.ArmState)
          (outs : List CV) (finalWorld : Arm.ArmState) (args : Array Reg),
          seqRun (csem (fun _ => False) ⟨0,0⟩ model)
            (raw.source.branch.step.emitted.toList.map (·.mapRegs (resolver result))) (fun _ => 4096) Arm.ArmState.default =
            some (.stop k i ops atCall world outs finalWorld (.goto raw.info.handlers.length)) ∧
          relation entered.slots memory finalWorld ∧ raw.info.handlers.length = 0 ∧
          succOf result.code 0 raw.info.handlers.length = some 1 ∧ succOf result.code 1 0 = some 2 ∧
          NormalColumnValues result 1 0 [⟨.i64,17⟩] (vdefUpd ops outs atCall) ∧
          (result.edgeArgs[1]?.bind fun row => row[0]?) = some args ∧
          edgeEnvAt result.code result.edgeArgs 1 2 0 (vdefUpd ops outs atCall) =
            some (parCopyEnv (vdefUpd ops outs atCall) (edgeParamNumbers result function.blocks[1]!) (columnNumbers args)) ∧
          ValuesHeld (fun x => x ∈ availOf function (availIn function result.ctx) 1 0) result.ctx entered
            (fun key => parCopyEnv (vdefUpd ops outs atCall) (edgeParamNumbers result function.blocks[1]!)
              (columnNumbers args) (aliasNum result.final.alias key)) ∧
          (∃ (vb : VBlock) (prelude : Array MInst),result.code.blocks[0]? = some vb ∧
            vb.insts = prelude ++ raw.source.branch.step.emitted.map
              (·.mapRegs (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1))) ∧
            Star (VStepAt result.code result.edgeArgs (csem (fun _ => False) ⟨0,0⟩ model))
              (.run ⟨0,prelude.size,(fun _ => 4096),Arm.ArmState.default⟩)
              (.run ⟨2,0,parCopyEnv (vdefUpd ops outs atCall) (edgeParamNumbers result function.blocks[1]!) (columnNumbers args),finalWorld⟩))) ∧
      Clif.runWith environment {funcs := [function]} function.name [] memory 6 = .returned [⟨.i64,17⟩] memory := by
  obtain ⟨result,p,rf,af,lowered,scope,dominated,arity,abi,prepared,fallback,accepted,physical,srcRun,degreeRun,unreachable,edge,xind,contract,sourceEntered,⟨raw,k,i,ops,atCall,world,outs,finalWorld,args,execute,related,normalZero,first,second,argumentValues,actual,copied1,copied2⟩,sourceRun⟩ := Backend.Stock.Proof.TryCriticalIndirectValuesWitnessDraft.stock_complete_critical_indirect_normal_values_witness
  have order : blockOrder function = .ok {nodes := #[.original 0,.edge 0 0 1,.original 1],successors := #[#[1],#[2],#[]]} := by cbv
  have sameOrder := Except.ok.inj ((stock_lower_order lowered).symm.trans order)
  have last := stock_indirect_try_normal_last raw execute
  have complete := stock_lower_try_critical_normal_execution lowered scope
    (driverSem_csem (fun _ => False) ⟨0,0⟩ model).toDriverSemG
    (show result.order.nodes[0]? = some (.original 0) from by rw [sameOrder]; rfl)
    (show function.blocks[0]? = some function.blocks[0]! from rfl)
    (show function.blocks[0]!.term.isTry = true from rfl) raw.source
    (show result.order.successors[0]![raw.info.handlers.length]? = some 1 from by rw [normalZero,sameOrder]; rfl)
    (show result.order.nodes[1]? = some (.edge 0 raw.info.handlers.length 1) from by rw [normalZero]; exact edge)
    (show result.order.successors[1]? = some #[2] from by rw [sameOrder]; rfl) execute last copied1
  exact ⟨result,p,rf,af,lowered,scope,dominated,arity,abi,prepared,fallback,accepted,physical,srcRun,degreeRun,unreachable,edge,xind,contract,sourceEntered,⟨raw,k,i,ops,atCall,world,outs,finalWorld,args,execute,related,normalZero,first,second,argumentValues,actual,copied1,copied2,complete⟩,sourceRun⟩
end Backend.Stock.Proof.TryCriticalIndirectEdgeStepWitnessDraft
