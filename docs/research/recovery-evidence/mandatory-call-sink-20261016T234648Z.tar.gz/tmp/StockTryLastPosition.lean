import StockTryPlacedExecution
import StockTryResolvedRuns
import StockTryGotSourceRun
import FV.E2E.RegLevelDriverSem
namespace Backend.Stock.Proof.TryLastPositionDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open TryDirectSourceRunDraft TryIndirectSourceRunDraft TryGotSourceRunDraft TryResolvedRunsDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private theorem last_goto {V W : Type} {sem : ISem V W} {pre : List MInst} {last : MInst}
    (noGoto : ∀ m ∈ pre,∀ uses w outs w' j,sem m uses w ≠ some (outs,w',.goto j))
    {rho atCall : Nat → V} {w world finalWorld : W} {k normal : Nat} {i : MInst} {ops : Array Operand} {outs : List V}
    (run : seqRun sem (pre ++ [last]) rho w = some (.stop k i ops atCall world outs finalWorld (.goto normal))) :
    k = pre.length := by
  induction pre generalizing rho w k with
  | nil =>
    rcases seqRun_cons_stop run with head | ⟨k',ops',outs',w',index,operands,execute,arity,rest⟩
    · exact head.1
    · simp only [seqRun,Option.some.injEq] at rest
      cases rest
  | cons first pre ih =>
    rcases seqRun_cons_stop run with head | ⟨k',ops',outs',w',index,operands,execute,arity,rest⟩
    · exact (noGoto first (List.mem_cons_self ..) _ _ _ _ normal head.2.2.2.2.2.1).elim
    · have inner := ih (fun m member => noGoto m (List.mem_cons_of_mem _ member)) rest
      simp only [List.length_cons]
      omega
private theorem straight_no_goto {F : BitVec 64 → Prop} {ctx : FnCtx} {i : MInst} {uses outs : List CV}
    {w w' : Arm.ArmState} {j : Nat} : straightSem F ctx i uses w ≠ some (outs,w',.goto j) := by
  intro run
  unfold straightSem at run
  repeat' first
    | (solve | cases run)
    | simp only [Option.map] at run
    | split at run
private theorem store_no_goto {F : BitVec 64 → Prop} {ctx : FnCtx} {X : ExtSem}
    (op : StoreOp) (n : Nat) (am : AMode) (fl : Clif.MemFlags)
    (uses outs : List CV) (w w' : Arm.ArmState) (j : Nat) :
    csem F ctx X (.store op (.vreg n .int) am fl) uses w ≠ some (outs,w',.goto j) := by
  intro run
  rw [csem_straight rfl] at run
  split at run
  · exact straight_no_goto run
  · cases uses with
    | nil => simp [mspec,ispec] at run
    | cons v uses =>
      simp only [mspec] at run
      repeat' first
        | (solve | cases run)
        | simp only [Option.map] at run
        | split at run
private theorem store_prefix_no_goto (F : BitVec 64 → Prop) (ctx : FnCtx) (X : ExtSem) (result : Result)
    (entries : List (Nat × Nat × Nat)) :
    ∀ m ∈ (entries.map argStore).map (·.mapRegs (resolver result)),∀ uses w outs w' j,
      csem F ctx X m uses w ≠ some (outs,w',.goto j) := by
  intro m member uses w outs w' j
  obtain ⟨raw,inside,rfl⟩ := List.mem_map.mp member
  obtain ⟨entry,_,rfl⟩ := List.mem_map.mp inside
  simp only [argStore,MInst.mapRegs,AMode.mapRegs,resolver,resolve_vreg]
  change csem F ctx X (.store (storeOpOfBytes entry.2.2) (.vreg (keyMap result entry.2.1) .int)
    (.spOffset entry.1) trustedFlags) uses w ≠ some (outs,w',.goto j)
  exact store_no_goto _ _ _ _ uses outs w w' j
/-- The actual production semantics can return normally from this SAME
near TryCall fragment only at its last instruction. Prefix stores/GOT loads
cannot produce goto; no caller last-index certificate is supplied. -/
theorem stock_near_try_normal_last {f : Clif.Function} {result : Result} {label bi : Nat} {b : Clif.Block}
    {ext : Clif.ExtFunc} {F : BitVec 64 → Prop} {asm : FnCtx} {X : ExtSem} {MR : MemRelT} {fr : Clif.Frame}
    {rawRho : Nat → CV} {rawWorld : Arm.ArmState} {rvals : List Clif.Val} {cm : Clif.Mem}
    (raw : DirectTryRun f result label bi b ext (csem F asm X) MR fr rawRho rawWorld rvals cm)
    {rho atCall : Nat → CV} {w world finalWorld : Arm.ArmState} {k normal : Nat}
    {i : MInst} {ops : Array Operand} {outs : List CV}
    (run : seqRun (csem F asm X) (raw.source.branch.step.emitted.toList.map (·.mapRegs (resolver result))) rho w =
      some (.stop k i ops atCall world outs finalWorld (.goto normal))) :
    k + 1 = raw.source.branch.step.emitted.size := by
  rw [raw.code,List.toList_toArray] at run
  simp only [List.map_append,List.map_cons,List.map_nil] at run
  have index := last_goto (store_prefix_no_goto F asm X result _) run
  simp only [List.length_map] at index
  rw [raw.code,List.size_toArray,List.length_append]
  simp only [List.length_map,List.length_cons,List.length_nil]
  omega
/-- The actual production semantics can return normally from this SAME
got TryCall fragment only at its last instruction. Prefix stores/GOT loads
cannot produce goto; no caller last-index certificate is supplied. -/
theorem stock_got_try_normal_last {f : Clif.Function} {result : Result} {label bi : Nat} {b : Clif.Block}
    {ext : Clif.ExtFunc} {F : BitVec 64 → Prop} {asm : FnCtx} {X : ExtSem} {MR : MemRelT} {fr : Clif.Frame}
    {rawRho : Nat → CV} {rawWorld : Arm.ArmState} {rvals : List Clif.Val} {cm : Clif.Mem}
    (raw : GotTryRun f result label bi b ext (csem F asm X) MR fr rawRho rawWorld rvals cm)
    {rho atCall : Nat → CV} {w world finalWorld : Arm.ArmState} {k normal : Nat}
    {i : MInst} {ops : Array Operand} {outs : List CV}
    (run : seqRun (csem F asm X) (raw.source.branch.step.emitted.toList.map (·.mapRegs (resolver result))) rho w =
      some (.stop k i ops atCall world outs finalWorld (.goto normal))) :
    k + 1 = raw.source.branch.step.emitted.size := by
  rw [raw.code,List.toList_toArray] at run
  simp only [List.map_append,List.map_cons,List.map_nil] at run
  let pre := ((stackEnts ((raw.locs.zip raw.ns).zip raw.bytes)).map argStore).map (·.mapRegs (resolver result)) ++ [(MInst.loadExtNameGot (.vreg raw.target .int) ext.name).mapRegs (resolver result)]
  have arranged : seqRun (csem F asm X) (pre ++ [(MInst.tryCall ⟨.reg (.vreg raw.target .int),retPairs (regPairsOf ((raw.locs.zip raw.ns).zip raw.bytes)),callDefs (TryResultMapDraft.resultDefs raw.base ext.sig.returns.length)⟩ {raw.info with rets := ext.sig.returns.length}).mapRegs (resolver result)]) rho w =
      some (.stop k i ops atCall world outs finalWorld (.goto normal)) := by
    simpa only [pre,List.append_assoc,List.singleton_append] using run
  have noGoto : ∀ m ∈ pre,∀ uses w outs w' j,csem F asm X m uses w ≠ some (outs,w',.goto j) := by
    intro m member uses w outs w' j
    rcases List.mem_append.mp member with stored | loaded
    · exact store_prefix_no_goto F asm X result _ m stored uses w outs w' j
    · have same := List.mem_singleton.mp loaded
      subst m
      simp only [MInst.mapRegs,csem]
      intro impossible
      cases impossible
  have index := last_goto noGoto arranged
  simp only [pre,List.length_append,List.length_map,List.length_singleton] at index
  rw [raw.code,List.size_toArray,List.length_append]
  simp only [List.length_map,List.length_cons,List.length_nil]
  omega
/-- The actual production semantics can return normally from this SAME
indirect TryCall fragment only at its last instruction. Prefix stores/GOT loads
cannot produce goto; no caller last-index certificate is supplied. -/
theorem stock_indirect_try_normal_last {f : Clif.Function} {result : Result} {label bi : Nat} {b : Clif.Block}
    {sig : Clif.Signature} {F : BitVec 64 → Prop} {asm : FnCtx} {X : ExtSem} {MR : MemRelT} {fr : Clif.Frame}
    {rawRho : Nat → CV} {rawWorld : Arm.ArmState} {rvals : List Clif.Val} {cm : Clif.Mem}
    (raw : IndirectTryRun f result label bi b sig (csem F asm X) MR fr rawRho rawWorld rvals cm)
    {rho atCall : Nat → CV} {w world finalWorld : Arm.ArmState} {k normal : Nat}
    {i : MInst} {ops : Array Operand} {outs : List CV}
    (run : seqRun (csem F asm X) (raw.source.branch.step.emitted.toList.map (·.mapRegs (resolver result))) rho w =
      some (.stop k i ops atCall world outs finalWorld (.goto normal))) :
    k + 1 = raw.source.branch.step.emitted.size := by
  rw [raw.code,List.toList_toArray] at run
  simp only [List.map_append,List.map_cons,List.map_nil] at run
  have index := last_goto (store_prefix_no_goto F asm X result _) run
  simp only [List.length_map] at index
  rw [raw.code,List.size_toArray,List.length_append]
  simp only [List.length_map,List.length_cons,List.length_nil]
  omega
end Backend.Stock.Proof.TryLastPositionDraft
