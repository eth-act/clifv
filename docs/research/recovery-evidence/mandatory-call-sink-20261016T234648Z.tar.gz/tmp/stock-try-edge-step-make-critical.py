from pathlib import Path
import re
for form in ['indirect','got']:
 src='StockTryCritical'+form.capitalize()+'ValuesWitness';dst='StockTryCritical'+form.capitalize()+'EdgeStepWitness';s=Path('/tmp',src+'.lean').read_text();oldns=re.search(r'^namespace (\S+)',s,re.M).group(1);ns='Backend.Stock.Proof.'+dst[len('Stock'):]+'Draft'
 head='import StockTryCriticalTransition\nimport '+src+'\n'+s[:s.index('private def')].replace('namespace '+oldns,'namespace '+ns)+'open TryCriticalTransitionDraft TryLastPositionDraft\n'
 defs=''.join(re.findall(r'^private def .*?(?=^private (?:def|theorem)|^/--|^theorem)',s,re.M|re.S))
 a=re.search(r'^theorem ',s,re.M).start();b=s.index(' := by',a);statement=s[a:b];oldroot=re.search(r'^theorem (\w+)',statement).group(1);statement=statement.replace(oldroot,oldroot.replace('_witness','_edge_execution_witness'),1)
 at=statement.index('      Clif.runWith');end=statement.rfind(') ∧',0,at);rho='(fun _ => 4096)' if form=='indirect' else '(fun _ => 0)'
 statement=statement[:end]+f''' ∧
          (∃ (vb : VBlock) (prelude : Array MInst),result.code.blocks[0]? = some vb ∧
            vb.insts = prelude ++ raw.source.branch.step.emitted.map
              (·.mapRegs (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1))) ∧
            Star (VStepAt result.code result.edgeArgs (csem (fun _ => False) ⟨0,0⟩ model))
              (.run ⟨0,prelude.size,{rho},Arm.ArmState.default⟩)
              (.run ⟨2,0,parCopyEnv (vdefUpd ops outs atCall) (edgeParamNumbers result function.blocks[1]!) (columnNumbers args),finalWorld⟩))) ∧'''+statement[end+3:]
 fields='result,p,rf,af,lowered,scope,dominated,arity,'+('abi,' if form=='indirect' else '')+'prepared,fallback,accepted,physical,srcRun,degreeRun,unreachable,edge,'
 fields+='xind,contract,' if form=='indirect' else 'xcalls,stable,memory,localArea,'
 fields+='sourceEntered,⟨raw,k,i,ops,atCall,world,outs,finalWorld,args,execute,'+('related,' if form=='indirect' else '')+'normalZero,first,second,argumentValues,actual,copied1,copied2⟩,sourceRun'
 body=f''' := by
  obtain ⟨{fields}⟩ := {oldns}.{oldroot}
  have order : blockOrder function = .ok {{nodes := #[.original 0,.edge 0 0 1,.original 1],successors := #[#[1],#[2],#[]]}} := by cbv
  have sameOrder := Except.ok.inj ((stock_lower_order lowered).symm.trans order)
  have last := stock_{form}_try_normal_last raw execute
  have complete := stock_lower_try_critical_normal_execution lowered scope
    (driverSem_csem (fun _ => False) ⟨0,0⟩ model).toDriverSemG
    (show result.order.nodes[0]? = some (.original 0) from by rw [sameOrder]; rfl)
    (show function.blocks[0]? = some function.blocks[0]! from rfl)
    (show function.blocks[0]!.term.isTry = true from rfl) raw.source
    (show result.order.successors[0]![raw.info.handlers.length]? = some 1 from by rw [normalZero,sameOrder]; rfl)
    (show result.order.nodes[1]? = some (.edge 0 raw.info.handlers.length 1) from by rw [normalZero]; exact edge)
    (show result.order.successors[1]? = some #[2] from by rw [sameOrder]; rfl) execute last copied1
  exact ⟨'''+fields.replace('copied2⟩','copied2,complete⟩')+'⟩\nend '+ns+'\n'
 Path('/tmp',dst+'.lean').write_text(head+defs+statement+body)
