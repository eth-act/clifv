import StockTryLastPosition
import StockTryNormalEntryCase
namespace Backend.Stock.Proof.TryCompleteEntryDraft
open Backend.Proof Backend.Proof.Driver
open TryPlacedExecutionDraft TrySourceContextDraft TryNormalEntryCaseDraft TryNormalCopiesDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
/-- A derived conclusion: a complete actual placed VCode branch (including
its call and actual normal successor copy) establishes source entry agreement.
It is not an accepted-program predicate or a caller execution certificate. -/
def NormalEntryExecution (f : Clif.Function) (result : Result) (source : Step)
    (label targetLabel targetBi column : Nat) (fr' : Clif.Frame) (isem : Sem)
    (rho postCall : Nat → CV) (w finalWorld : Arm.ArmState) : Prop :=
  ∃ (target : Clif.Block) (args : Array Reg) (vb : VBlock) (prelude : Array MInst),
    f.blocks[targetBi]? = some target ∧
    (result.edgeArgs[label]?.bind fun row => row[column]?) = some args ∧
    result.code.blocks[label]? = some vb ∧
    vb.insts = prelude ++ source.emitted.map
      (·.mapRegs (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1))) ∧
    Star (VStepAt result.code result.edgeArgs isem) (.run ⟨label,prelude.size,rho,w⟩)
      (.run ⟨targetLabel,0,parCopyEnv postCall (edgeParamNumbers result target) (columnNumbers args),finalWorld⟩) ∧
    ValuesHeld (fun x => x ∈ availOf f (availIn f result.ctx) targetBi 0) result.ctx fr'
      (fun key => parCopyEnv postCall (edgeParamNumbers result target) (columnNumbers args) (aliasNum result.final.alias key))
/-- Complete the SAME placed stopped run with its actual executable goto and
per-successor copies. Source entry/copy facts are derived by the normal-entry
factory; the end index is derived by each actual call-form wrapper. -/
theorem stock_lower_try_complete_normal_entry {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f)
    {label bi targetLabel targetBi : Nat} {b : Clif.Block}
    (node : result.order.nodes[label]? = some (.original bi)) (block : f.blocks[bi]? = some b)
    (isTry : b.term.isTry = true) (source : TryBranchSource f result label bi b)
    {isem : Sem} {rho atCall : Nat → CV} {w world finalWorld : Arm.ArmState}
    {k normal : Nat} {i : MInst} {ops : Array Operand} {outs : List CV}
    (run : seqRun isem (source.branch.step.emitted.toList.map (·.mapRegs
      (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1)))) rho w =
        some (.stop k i ops atCall world outs finalWorld (.goto normal)))
    (last : k + 1 = source.branch.step.emitted.size) {bc : Clif.BlockCall} {fr' : Clif.Frame}
    (entry : NormalEntryAgreement f result label targetLabel targetBi normal bc fr' (vdefUpd ops outs atCall)) :
    NormalEntryExecution f result source.branch.step label targetLabel targetBi normal fr' isem rho
      (vdefUpd ops outs atCall) w finalWorld := by
  obtain ⟨index,nonentry,successor,target,args,destination,found,func,body,term,stored,copies,agreement⟩ := entry
  obtain ⟨vb,prelude,placed,code,executedSteps,bound,atInst,operands,semantics,arity,control⟩ :=
    stock_lower_try_branch_stop_prefix lowered scope node block isTry source run
  have ending : prelude.size+k+1 = vb.insts.size := by
    rw [code,Array.size_append,Array.size_map]
    omega
  have step : VStepAt result.code result.edgeArgs isem (.run ⟨label,prelude.size+k,atCall,world⟩)
      (.run ⟨targetLabel,0,parCopyEnv (vdefUpd ops outs atCall) (edgeParamNumbers result target) (columnNumbers args),finalWorld⟩) :=
    VStepAt.step placed atInst operands semantics arity (VNextAt.goto ending successor copies)
  exact ⟨target,args,vb,prelude,destination,stored,placed,code,executedSteps.trans (.step step (.refl _)),agreement⟩
end Backend.Stock.Proof.TryCompleteEntryDraft
