from pathlib import Path
import re
for form,src,dst in [('direct','StockTryNormalNearEntry','StockTryNearEntryExecution'),('got','StockTryNormalGotEntry','StockTryGotEntryExecution'),('indirect','StockTryNormalIndirectEntry','StockTryIndirectEntryExecution')]:
 old=Path('/tmp',src+'.lean').read_text();a=re.search(r'^theorem ',old,re.M).start();b=old.index(' := by',a);sig=old[a:b];name=re.search(r'^theorem (\w+)',sig).group(1);newname=name.replace('_entry_source_values','_entry_execution');sig=sig.replace(name,newname,1)
 if form=='direct':sig=sig.replace('{isem : Sem}','{asm : FnCtx} {X : ExtSem}');sig=re.sub(r'\bisem\b','(csem F asm X)',sig)
 if form=='indirect':sig=sig.replace('{isem : Sem}','{F : BitVec 64 → Prop} {asm : FnCtx} {X : ExtSem}');sig=re.sub(r'\bisem\b','(csem F asm X)',sig)
 sig+=''' ∧
      NormalEntryExecution f result raw.source.branch.step label targetLabel targetBi raw.info.handlers.length fr'
        (csem F asm X) ρ (vdefUpd ops outs atCall) w finalWorld'''
 ns='Backend.Stock.Proof.Try'+('Near' if form=='direct' else form.capitalize())+'EntryExecutionDraft'
 head=f'import StockTryCompleteEntry\nimport {src}\nnamespace {ns}\n'
 head+='\n'.join(l for l in old[:a].splitlines() if l.startswith(('open ','set_option ')))+'\nopen TryLastPositionDraft TryCompleteEntryDraft\n'
 head+='open '+('TryNormalNearEntryDraft' if form=='direct' else 'TryNormalGotEntryDraft' if form=='got' else 'TryNormalIndirectEntryDraft')+'\n'
 if form=='direct':args='lowered scope dominated input node block kind external near successor target driver stable memory outgoing calls member held read typed related found pin returned results liveHeld bound normal normalRead func entered'
 elif form=='got':args='lowered scope dominated input node block kind external far successor target stable memory outgoing calls member held read typed related found returned results liveHeld bound normal normalRead func entered'
 else:args='lowered scope dominated input abi node block kind table successor target driver calls held read typed related calleeValue symbol signature found pin returned results liveHeld bound normal normalRead func entered'
 body=f''' := by
  obtain ⟨raw,k,i,ops,atCall,world,outs,finalWorld,execute,returnedWorld,returns,postHeld,column,index,entry,defined⟩ :=
    {name} {args}
  have last := stock_{'near' if form=='direct' else form}_try_normal_last raw execute
  have complete := stock_lower_try_complete_normal_entry lowered scope node block
    (show b.term.isTry = true from by rw [kind]; rfl) raw.source execute last entry
  exact ⟨raw,k,i,ops,atCall,world,outs,finalWorld,execute,returnedWorld,returns,postHeld,column,index,entry,defined,complete⟩
end {ns}
'''
 Path('/tmp',dst+'.lean').write_text(head+sig+body)
