import StockTryCompleteEntry
import StockTryNormalCfg
import FV.Backend.Proof.StockCriticalCode
import FV.Backend.Proof.StockOutgoingVectors
namespace Backend.Stock.Proof.TryCriticalTransitionDraft
open Backend.Proof Backend.Proof.Driver
open TrySourceContextDraft TryPlacedExecutionDraft TryNormalCfgDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
/-- Actual entry into a compiler-inserted synthetic edge has an empty incoming
column and no parameters, so its first copy is the identity. -/
theorem stock_lower_try_critical_first_copy {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) {label bi normal edgeLabel pred index targetBi : Nat}
    (node : result.order.nodes[label]? = some (.original bi))
    (successor : result.order.successors[label]![normal]? = some edgeLabel)
    (edge : result.order.nodes[edgeLabel]? = some (.edge pred index targetBi)) (rho : Nat → CV) :
    edgeEnvAt result.code result.edgeArgs label edgeLabel normal rho = some rho := by
  have empty := stock_lower_deferred_outgoing lowered node successor edge
  obtain ⟨input,next,args,targetLabel,call,row,target,placed⟩ := stock_lower_critical_code lowered edge
  change (result.edgeArgs[label]?.bind fun row => row[normal]?) = some #[] at empty
  simp [edgeEnvAt,placed,empty,Except.toOption]
  rfl
/-- The actual single jump installed for a synthetic node executes its real
selected copy vector into its actual original target. -/
theorem stock_lower_critical_jump_execution {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f) {isem : Sem} (driver : DriverSemG isem)
    {edgeLabel pred index targetBi targetLabel : Nat}
    (edge : result.order.nodes[edgeLabel]? = some (.edge pred index targetBi))
    (successor : result.order.successors[edgeLabel]? = some #[targetLabel])
    {rho nextRho : Nat → CV} {w : Arm.ArmState}
    (copies : edgeEnvAt result.code result.edgeArgs edgeLabel targetLabel 0 rho = some nextRho) :
    VStepAt result.code result.edgeArgs isem (.run ⟨edgeLabel,0,rho,w⟩) (.run ⟨targetLabel,0,nextRho,w⟩) := by
  obtain ⟨input,next,args,actual,call,row,target,placed⟩ := stock_lower_critical_code lowered edge
  have same : actual = targetLabel := by
    have arrays := Option.some.inj (row.symm.trans successor)
    have heads := congrArg (fun xs : Array Nat => xs[0]?) arrays
    exact Option.some.inj heads
  subst actual
  have selected : succOf result.code edgeLabel 0 = some targetLabel := by
    rw [stock_lower_actual_successor lowered scope,successor]
    rfl
  exact VStepAt.step (i := .jump targetLabel) (ops := #[]) (outs := []) placed (by rfl) (by rfl) (driver.jump targetLabel w) (by rfl)
    (VNextAt.goto (by rfl) selected copies)
/-- Complete the actual placed normal TryCall, the empty first copy, and its
real synthetic jump/copy. Every machine step executes the returned VCode; the
source/value theorem supplies the already-derived second-copy agreement. -/
theorem stock_lower_try_critical_normal_execution {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f) {isem : Sem} (driver : DriverSemG isem)
    {label bi edgeLabel targetLabel targetBi normal : Nat} {b : Clif.Block}
    (node : result.order.nodes[label]? = some (.original bi)) (block : f.blocks[bi]? = some b)
    (isTry : b.term.isTry = true) (source : TryBranchSource f result label bi b)
    (successor : result.order.successors[label]![normal]? = some edgeLabel)
    (edge : result.order.nodes[edgeLabel]? = some (.edge bi normal targetBi))
    (second : result.order.successors[edgeLabel]? = some #[targetLabel])
    {rho atCall nextRho : Nat → CV} {w world finalWorld : Arm.ArmState}
    {k : Nat} {i : MInst} {ops : Array Operand} {outs : List CV}
    (run : seqRun isem (source.branch.step.emitted.toList.map (·.mapRegs
      (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1)))) rho w =
        some (.stop k i ops atCall world outs finalWorld (.goto normal)))
    (last : k + 1 = source.branch.step.emitted.size)
    (copies : edgeEnvAt result.code result.edgeArgs edgeLabel targetLabel 0 (vdefUpd ops outs atCall) = some nextRho) :
    ∃ (vb : VBlock) (prelude : Array MInst),result.code.blocks[label]? = some vb ∧
      vb.insts = prelude ++ source.branch.step.emitted.map
        (·.mapRegs (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1))) ∧
      Star (VStepAt result.code result.edgeArgs isem) (.run ⟨label,prelude.size,rho,w⟩)
        (.run ⟨targetLabel,0,nextRho,finalWorld⟩) := by
  obtain ⟨vb,prelude,placed,code,executedSteps,bound,atInst,operands,semantics,arity,control⟩ :=
    stock_lower_try_branch_stop_prefix lowered scope node block isTry source run
  have ending : prelude.size+k+1 = vb.insts.size := by rw [code,Array.size_append,Array.size_map]; omega
  have selected : succOf result.code label normal = some edgeLabel := by
    rw [stock_lower_actual_successor lowered scope]
    cases row : result.order.successors[label]? with
    | none => simp only [getElem!_def,row] at successor; cases successor
    | some ss => simpa only [getElem!_def,row,Option.getD_some,Option.bind_some] using successor
  have firstCopy := stock_lower_try_critical_first_copy lowered node successor edge (vdefUpd ops outs atCall)
  have firstStep : VStepAt result.code result.edgeArgs isem (.run ⟨label,prelude.size+k,atCall,world⟩)
      (.run ⟨edgeLabel,0,vdefUpd ops outs atCall,finalWorld⟩) :=
    VStepAt.step placed atInst operands semantics arity (VNextAt.goto ending selected firstCopy)
  have secondStep := stock_lower_critical_jump_execution (w := finalWorld) lowered scope driver edge second copies
  exact ⟨vb,prelude,placed,code,executedSteps.trans (.step firstStep (.step secondStep (.refl _)))⟩
end Backend.Stock.Proof.TryCriticalTransitionDraft
