import StockTryCompleteEntry
import StockTryNormalIndirectEntry
namespace Backend.Stock.Proof.TryIndirectEntryExecutionDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open TryNormalSourceEntryDraft TryNormalEntryCaseDraft TryNormalControlDraft TryNormalValueColumnsDraft
open TryNormalSourceValuesDraft TryNormalIndirectSourceValuesDraft
open TryBranchAbiDraft TryResolvedRunsDraft TryDirectSourceRunDraft TryGotSourceRunDraft TryIndirectSourceRunDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
open TryLastPositionDraft TryCompleteEntryDraft
open TryNormalIndirectEntryDraft
theorem stock_lower_indirect_try_normal_entry_execution {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f) (input : Prg.iselInB f = true)
    (abi : Backend.Proof.Spill.AbiSigsOk f)
    {label bi : Nat} {b : Clif.Block} (node : result.order.nodes[label]? = some (.original bi))
    (block : f.blocks[bi]? = some b) {callee : Nat} {args : List Nat} {et : Clif.ExnTable}
    (kind : b.term = .tryCallIndirect callee args et) {sig : Clif.Signature} {items : List (Option Nat)}
    (table : exnTableOpnd f et = .ok (sig,items))
    {targetLabel targetBi : Nat}
    (successor : result.order.successors[label]![et.handlers.length]? = some targetLabel)
    (target : result.order.nodes[targetLabel]? = some (.original targetBi))
    {F : BitVec 64 → Prop} {asm : FnCtx} {X : ExtSem} {MR : MemRelT} (driver : DriverSem (csem F asm X))
    {Pc : String → Clif.Signature → List Clif.Val → Clif.Mem → Prop} {env : Clif.Env}
    (calls : IndCallsRefineP Pc env (indSigs f) MR (csem F asm X))
    {fr : Clif.Frame} {ρ : Nat → CV} {w : Arm.ArmState} {cm cm' : Clif.Mem} {vals rvals : List Clif.Val}
    (held : ValuesHeld (fun x => x = callee ∨ x ∈ args) result.ctx fr (fun key => ρ (keyMap result key))) (read : fr.getMany args = .ok vals)
    (typed : vals.map (·.ty) = Clif.AbiParam.tys sig.params) (related : MR fr.slots cm w)
    {name : String} {address : Nat}
    (calleeValue : fr.get callee = .ok ⟨.i64,BitVec.ofNat 64 address⟩)
    (symbol : cm.symbols name = some address)
    (signature : ∀ s,env.sigOf name = some s → sig.abiMatch s = true)
    {g : List Clif.Val → Clif.Mem → Clif.Outcome} (found : env.extern name = some g)
    (pin : Pc name sig vals cm) (returned : g vals cm = .returned rvals cm')
    (results : rvals.length = sig.returns.length)    (liveHeld : ValuesHeld (fun x => x ∈ availOf f (availIn f result.ctx) bi b.body.length) result.ctx fr
      (fun key => ρ (keyMap result key)))
    {regs : Clif.Regs} {bc : Clif.BlockCall} {normalValues : List Clif.Val}
    (bound : fr.regs.setMany ((List.range rvals.length).map (f.freshValue + ·)) rvals = some regs)
    (normal : Clif.tryNormal et f.freshValue = .ok bc)
    (normalRead : ({fr with regs} : Clif.Frame).getMany bc.args = .ok normalValues)
    {fr' : Clif.Frame} (func : fr.func = f)
    (entered : Clif.enterBlock {fr with regs,body := [],term := .jump bc} bc = .ok fr') :
    ∃ (raw : IndirectTryRun f result label bi b sig (csem F asm X) MR fr (fun key => ρ (keyMap result key)) w rvals cm')
      (k : Nat) (i : MInst) (ops : Array Operand) (atCall : Nat → CV) (world : Arm.ArmState)
      (outs : List CV) (finalWorld : Arm.ArmState),
      seqRun (csem F asm X) (raw.source.branch.step.emitted.toList.map (·.mapRegs (resolver result))) ρ w =
        some (.stop k i ops atCall world outs finalWorld (.goto raw.info.handlers.length)) ∧
      MR fr'.slots cm' finalWorld ∧
      (∀ (j : Nat) (v : Clif.Val),rvals[j]? = some v → VHolds v (vdefUpd ops outs atCall (keyMap result (raw.base+j)))) ∧
      ValuesHeld (fun x => x ∈ availOf f (availIn f result.ctx) bi b.body.length) result.ctx fr
        (fun key => vdefUpd ops outs atCall (keyMap result key)) ∧
      NormalColumnValues result label et.handlers.length normalValues (vdefUpd ops outs atCall) ∧
      raw.info.handlers.length = et.handlers.length ∧
      NormalEntryAgreement f result label targetLabel targetBi raw.info.handlers.length bc fr' (vdefUpd ops outs atCall) ∧
      (SourceDefinedAt f result.ctx bi b.body.length fr → SourceDefinedAt f result.ctx targetBi 0 fr') ∧
      NormalEntryExecution f result raw.source.branch.step label targetLabel targetBi raw.info.handlers.length fr'
        (csem F asm X) ρ (vdefUpd ops outs atCall) w finalWorld := by
  obtain ⟨raw,k,i,ops,atCall,world,outs,finalWorld,execute,returnedWorld,returns,postHeld,column,index,entry,defined⟩ :=
    stock_lower_indirect_try_normal_entry_source_values lowered scope dominated input abi node block kind table successor target driver calls held read typed related calleeValue symbol signature found pin returned results liveHeld bound normal normalRead func entered
  have last := stock_indirect_try_normal_last raw execute
  have complete := stock_lower_try_complete_normal_entry lowered scope node block
    (show b.term.isTry = true from by rw [kind]; rfl) raw.source execute last entry
  exact ⟨raw,k,i,ops,atCall,world,outs,finalWorld,execute,returnedWorld,returns,postHeld,column,index,entry,defined,complete⟩
end Backend.Stock.Proof.TryIndirectEntryExecutionDraft
