from pathlib import Path
import json,hashlib,re,datetime,tarfile,shutil,subprocess
root=Path('/home/lee/clifv/.worktrees/driver-proof-resume');docs=root/'docs/research';prefix='stock-try-edge-step'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
now=datetime.datetime.now(datetime.timezone.utc);stamp=now.strftime('%Y%m%dT%H%M%SZ')
batch=json.loads(Path('/tmp/'+prefix+'-batch.json').read_text());old=json.loads((docs/'stock-try-placement-scratch.json').read_text())
log=Path('/tmp/'+prefix+'-combined-axioms.log').read_text()
sets={m.group(1):sorted(x.strip() for x in m.group(2).split(',') if x.strip()) for m in re.finditer(r"'([^']+)' depends on axioms:\s*\[([^]]*)\]",log)}
for m in re.finditer(r"'([^']+)' does not depend on any axioms",log):sets[m.group(1)]=[]
for n,a in old['normal_audit']['sets'].items():assert sorted(a)==sets[n],n
assert len(sets)==len(old['normal_audit']['sets'])+len(batch['public_roots'])+len(batch['models'])
allowed={'propext','Classical.choice','Quot.sound'}
for n in batch['public_roots']+batch['models']:assert set(sets[n])<=allowed,n
constants=[json.loads(line.split('DELIVERY_CONSTANT ',1)[1]) for line in Path('/tmp/'+prefix+'-all-constants.log').read_text().splitlines() if line.startswith('DELIVERY_CONSTANT ')]
assert constants
for n,a in constants:assert set(a)<=allowed,n
mods={}
for m in batch['modules']:
 p=Path('/tmp')/m;check=json.loads(p.with_suffix('.check.json').read_text());assert check['actual_exit']==0
 rec={}
 for key,ext in [('source','.lean'),('object','.olean'),('log','.log'),('check','.check.json')]:
  f=p.with_suffix(ext);rec[key]=str(f);rec[key+'_sha256']=sha(f)
 for k in ['source','object','log']:assert rec[k+'_sha256']==check[k+'_sha256']
 assert not re.search(r'\b(sorry|admit|axiom|trace_state|native_decide)\b',p.with_suffix('.lean').read_text()),m
 mods[m]=rec
for audit in [prefix+'-combined-axioms',prefix+'-all-constants']:
 p=Path('/tmp')/audit;check=json.loads(p.with_suffix('.check.json').read_text());assert check['actual_exit']==0
 for k,ext in [('source','.lean'),('object','.olean'),('log','.log')]:assert sha(p.with_suffix(ext))==check[k+'_sha256']
prior={}
for name in ['source-execution-x','try-source','try-context','try-rule','try-rets','try-reservation','try-outgoing','try-values','try-emitted','try-machine','try-got','try-indirect','try-rename','try-resolved','try-gap','try-got-rename','try-normal-frame','try-metadata','source-index','try-normal-vector','try-critical-normal','source-erase','source-origin','try-live-frame','try-normal-values','try-normal-copy','try-normal-control','try-normal-entry','try-placement']:
 d=json.loads((docs/f'stock-{name}-scratch.json').read_text())
 for m,rec in d['modules'].items():
  for k in ['source','object','log']:assert sha(rec[k])==rec[k+'_sha256'],(m,k)
  prior[m]=rec
assert len(prior)==195
freeze=json.loads(Path('/tmp/stock-coherent-build-inputs.json').read_text())
for group in ['source_sha256','validation_script_sha256']:
 for p,h in freeze[group].items():assert sha(root/p)==h,p
imports=json.loads(Path('/tmp/stock-try-rule-inputs.json').read_text())
for m,r in imports['modules'].items():
 assert sha(r['snapshot'])==r['object_sha256'],(m,'snapshot')
 assert sha(r['source'])==r['source_sha256'],(m,'source')
progress=json.loads(Path('/tmp/stock-pr246-gates-progress.json').read_text());progress.pop('completed_phases',None)
subprocess.run(['ps','-p','3247835','-o','pid,stat,etime,args'],check=True)
remaining=list(old['remaining_checklist']);remaining.append({'requirement':'Complete actual normal TryCall VCode transition and successor copies','state':'Actual production-csem store/GOT-load prefixes cannot goto; SAME stopped near/GOT/indirect call is last without caller last-index certificate. Actual placed prefix plus call executes VNextAt.goto and exact per-successor copies. Whole original near/GOT/indirect original-contract consumers construct NormalEntryExecution, actual Star(VStepAt) to original successor0 with returned world/copy env/ALL available source values/source-definedness preservation; no caller map/end/copy acceptance predicate. Actual synthetic first copy identity and actual single jump/copies derive from successful compiler output, enabling complete critical indirect/local-area-GOT two-hop execution into source target. COMPLETE ordinary3+critical2 full pipelines/source17/value/copy/actual execution witnesses PASS. Initial state remains actual branch boundary, after ordinary body; prepared transport, whole source block/function/world/DFG/driver simulation AND completeness, cutover and final gates remain OPEN. Near-critical and older critical GOT whole-area root-specific non-vacuity remain PENDING; local-area witness is not substituted.'})
counts={'modules':len(mods),'public_roots':len(batch['public_roots']),'models':len(batch['models']),'combined_roots_models':len(sets),'previous_preserved':len(old['normal_audit']['sets']),'all_new_module_constants':len(constants),'previous_modules_hashes_preserved':len(prior)}
receipt={'utc':now.isoformat(),'goal':'Original full #140 ACTIVE/INCOMPLETE; production LEGACY','scope':'Scratch additive complete normal branch transitions; coherent integration/whole-driver/final gates still pending','delivery_target':'roughly8 substantive validated squash merges/day; grouping/remote backup/cleanup','modules':mods,'public_roots':batch['public_roots'],'models':batch['models'],'counts':counts,'normal_audit':{'path':'/tmp/'+prefix+'-combined-axioms.log','sha256':sha('/tmp/'+prefix+'-combined-axioms.log'),'sets':sets},'all_constant_audit':{'path':'/tmp/'+prefix+'-all-constants.log','sha256':sha('/tmp/'+prefix+'-all-constants.log'),'all_standard_only':True,'count':len(constants)},'previous_modules_hashes_preserved':list(prior),'canonical2246_source_and_script_freeze_preserved':True,'import_generation':{'source_and_snapshot_hashes_checked':len(imports['modules']),'manifest_sha256':sha('/tmp/stock-try-rule-inputs.json'),'shared_cache_writes':False,'canonical_import_repair':'stock-try-normal-copy-scratch.json'},'nonvacuity':{'ordinary_near_GOT_indirect':'COMPLETE original compiler/prepare/forced checkedfallback/checker/physical/source17/runtime/memory/callee/value/copy/defined-before-after plus actual complete placed VCode normal branch/call/copy transition to original target','critical_indirect':'COMPLETE same actual placed branch/call/identity-first-copy/synthetic jump/second-copy transition; real source callee4096/memory-symbol relation/value17/target agreement/unreachable predecessor/indegree2/all pipeline stages','critical_GOT_local_area':'COMPLETE same actual two-hop transition/source/value/pipeline under generic additive actual-callee-stack-area contract; old variants retained; no whole-area projection claim','critical_near':'PENDING complete compiler/machine/value observation; saved8GiB failures, larger kernel queued after delivery heavy lane frees','older_critical_GOT_whole_area':'PENDING root-specific old whole-result-area contract/non-vacuity; new local-area witness not substituted'},'semantics':'New end-position/whole-consumer variants use actual production csem. Older generic-isem theorem variants remain unchanged. No accepted-input restriction or new program predicate. NormalEntryExecution is an output, never an acceptance certificate. Calls begin at actual branch boundary after ordinary body, not function entry.','MCP':'Deferred until coherent integration; no new calls','active_exact_PR246_validation':progress,'remaining_checklist':remaining}
(docs/(prefix+'-scratch.json')).write_text(json.dumps(receipt,indent=2)+'\n')
text=f'''Complete actual normal TryCall VCode transitions and successor copies — {now.isoformat()}

{len(mods)}scratch modules/{len(batch['public_roots'])}public roots/{len(batch['models'])}semantic model actual8GiB kernelPASS. Cumulative{len(sets)}root/model audit preserves ALL720prior exact axiom sets. ALL{len(constants)}new-module constants incl private control/end-position/contract/witness helpers STANDARD-only. ALL195prior scratch source/object/log hashes,2246canonical source/49script freeze and1049imported source/snapshot hashes unchanged; no shared-cache writes.

The actual production csem cannot produce goto from argument stores or GOT loads. Successful normal stopped runs of the SAME near/GOT/indirect branch therefore stop at its LAST call, with no caller-supplied last-index certificate or new source input bound. Older generic-isem variants remain unchanged. Source programs are not restricted; these new variants prove execution for the actual production instruction semantics.

Actual placed VCode prefix plus actual executing call now takes real VNextAt.goto and the SAME actual per-successor copy. Whole original near/GOT/true-indirect original-contract consumers construct NormalEntryExecution: actual Star(VStepAt) from the placed branch boundary to original target at0, exact returned world/post-call/copy environment, ALL destination-available source values and source-definedness preservation. Actual source result binding/read/enterBlock and ordinary incoming agreement remain runtime simulation observations. No caller end-index/map/copy/disjointness/program acceptance certificate. The model is solely an output conclusion.

Actual incoming columns for compiler-inserted synthetic nodes are empty and their actual parameters are empty, so the first copy is identity. Their actual installed one-instruction jump executes the SAME actual outgoing copy into the actual original target. COMPLETE critical INDIRECT and generic local-area GOT witnesses now execute the returned VCode through the real call, first identity-copy edge, synthetic jump and actual second copy, ending at original source successor with its source-value agreement. Ordinary near/GOT/indirect COMPLETE witnesses likewise execute real call/copy transitions. All five retain original source/runtime/memory/callee/compiler/prepare/forced checkedfallback/checker/physical/source17; ordinary defined-before/after and critical unreachable predecessor/indegree2 preserved. Nine-argument GOT has real nonempty stack-store prefix/16byte area; indirect retains real callee4096.

This is complete NORMAL BRANCH transition execution from its actual branch boundary, after the ordinary body. It does not prove initial entry/body/whole-source-block/function/world/DFG/whole-driver simulation or completeness. Next lift these transitions through checked preparation and compose actual body/entry/source continuation and whole driver. Near-critical complete compiler/machine/value observation remains pending after archived8GiB failures, one larger kernel after delivery lane frees. Older critical GOT WHOLE-RESULT-AREA root-specific contract/non-vacuity remains pending; new local-area witness is not substituted. Physical lowering does not imply a whole outgoing bound/projection, and VM output is not proof.

All remaining zero-return/sret/x8/width/handler/Try-critical matrix, shared payload/exception semantics, uncovered families/effects/sinking, source/DFG/world/block/whole-driver simulation AND completeness, original-input context/static/visitor/checker/fallback/physical totality, coherent integration/public/private/compiler/MCP/full build/crates/runtime/encoder/BOTH E2E identity-stage parity, actual compiler/checker/linker/generated consumers and FRESH COMPLETE comparison remain mandatory. Original inputs/old variants/exact axioms/accepted identities/successful stages/#179baseline preserved. Full#140 ACTIVE/INCOMPLETE; production LEGACY.

Same246supervisor3247835confirmedLIVE at{progress.get('index')}/{progress.get('total')}, canonical1233457deliberatelyheld/exclusive one-cache lease. No restart. Preserve old-head receipts, reconcile currentmain/shared machine assumptions/changed-deleted roots, rerun affected kernel/trust plus ALL full/crates/runtime/encoder/BOTH E2E actual integrated-head gates before dependent squash246→247. Roughly8substantive validated merges/day; semantic grouping/remote backup/cleanup. No merge/new tree/agent/MCP/cold compiler projection/larger kernel/heavyretry/restart/other-project cleanup. Contributor52/71/task140 reread; shared Kev S10/FP/Link boundaries preserved. Exact evidence/full checklist: stock-try-edge-step-scratch.json.
'''
(docs/(prefix+'-scratch.md')).write_text(text);plan=root/'docs/plans/test-binary-alignment-recovery.md';plan.write_text(plan.read_text()+'\n\n'+text)
current=docs/'stock-full-goal-current.md';s=current.read_text();Path('/tmp/'+prefix+'-full-goal-before.md').write_text(s);lines=s.splitlines()
for i,line in enumerate(lines):
 if line.startswith('| Source, DFG, world, block and whole-driver simulation |'):
  lines[i]='| Source, DFG, world, block and whole-driver simulation | Complete actual production-csem NORMAL TryCall branch transitions from placed branch boundary through call and copies into original successor: near/GOT/indirect whole consumers, ordinary3+critical2 complete actual VCode/source/value/pipeline witnesses. Critical actual identity first edge and jump/second-copy both execute. Earlier source-definedness/reachability retained | Prepared transport and initial entry/ordinary body/source-block/source-world/DFG/function/whole-driver simulation AND completeness remain open; branch boundary is not function entry. Finish generic runX/unwind invariant and uncovered families/effects |'
 elif line.startswith('| Public-root/kernel/transitive axiom audit |'):
  lines[i]=f'| Public-root/kernel/transitive axiom audit | Latest scratch cumulative{len(sets)}roots/models preserve720prior exact sets;{len(constants)}new-module constants including private helpers Std-only,195prior module hashes/source freeze unchanged | Coherent canonical integration/current integrated public/private/model/compiler audit, ONE bundled MCP and final production audit. Scratch{len(sets)}does not establish integrated/cutover audit |'
current.write_text(f'Latest checkpoint {now.isoformat()}: [complete actual normal TryCall VCode transitions and copies](stock-try-edge-step-scratch.md). {len(mods)}modules/{len(batch["public_roots"])}roots/{len(batch["models"])}model; cumulative{len(sets)}preserves720prior exact sets;{len(constants)}new-module constants standard-only. Ordinary3/critical2 full pipeline/source/value witnesses include complete actual placed branch/call/copy transitions, with real synthetic jump where required. Prepared transport/body/entry/whole-source/world/driver simulation/completeness/cutover remain OPEN, as do near-critical and old whole-area-GOT specific witness gates. Full#140 ACTIVE/INCOMPLETE; production LEGACY. Same246livegate at{progress.get("index")}/{progress.get("total")}; no merge.\n\n'+'\n'.join(lines)+'\n')
files=[]
for rec in mods.values():files.extend(Path(rec[k]) for k in ['source','object','log','check'])
for name in [prefix+'-combined-axioms',prefix+'-all-constants']:
 for ext in ['.lean','.log','.olean','.check.json']:files.append(Path('/tmp')/(name+ext))
for p in Path('/tmp').glob(prefix+'*'):
 if p.is_file():files.append(p)
files.extend([Path('/tmp/stock-try-rule-inputs.json'),Path('/tmp/stock-try-reservation-check.py'),Path('/tmp/stock-source-erase-restore.py'),docs/(prefix+'-scratch.json'),docs/(prefix+'-scratch.md'),docs/'stock-delivery-main-drift.json',plan,current])
files=list(dict.fromkeys(files))
archive=Path('/home/lee/.clifv-recovery')/(stamp+'-try-edge-step')/'checkpoint.tar.gz';archive.parent.mkdir(parents=True)
with tarfile.open(archive,'w:gz',compresslevel=1) as t:
 for p in files:t.add(p,arcname=str(p).lstrip('/'),recursive=False)
with tarfile.open(archive,'r:gz') as t:
 for p in files:assert t.extractfile(str(p).lstrip('/')).read()==p.read_bytes(),p
snapshot=Path('/tmp/stock-try-rule-inputs');size=sum(p.stat().st_size for p in snapshot.rglob('*') if p.is_file());shutil.rmtree(snapshot)
backup={'utc':now.isoformat(),'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(files),'all_members_byte_verified':True,'previous_remote_backup':json.loads((docs/'stock-try-placement-backup.json').read_text())['remote'],'cleanup':{'duplicate_dependency_snapshot_removed':True,'bytes_reclaimed':size,'all_unique_sources_objects_logs_checks_audits_preserved':True,'one_shared_warm_cache_retained':True,'other_projects_touched':False,'free_bytes':shutil.disk_usage(root).free}}
(docs/(prefix+'-backup.json')).write_text(json.dumps(backup,indent=2)+'\n');Path('/tmp/'+prefix+'-archive-path').write_text(str(archive))
print(json.dumps({'counts':counts,'archive':str(archive),'cleanup':backup['cleanup'],'gate':progress},indent=2))
