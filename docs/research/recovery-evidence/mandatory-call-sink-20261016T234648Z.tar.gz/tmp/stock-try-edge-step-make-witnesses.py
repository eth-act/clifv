from pathlib import Path
import re
for src,dst,consumer,form in [('StockTryNormalNearEntryWitness','StockTryNearEdgeStepWitness','StockTryNearEntryExecution','direct'),('StockTryNormalGotEntryWitness','StockTryGotEdgeStepWitness','StockTryGotEntryExecution','got'),('StockTryNormalIndirectEntryWitness','StockTryIndirectEdgeStepWitness','StockTryIndirectEntryExecution','indirect')]:
 s=Path('/tmp',src+'.lean').read_text();oldns=re.search(r'^namespace (\S+)',s,re.M).group(1);ns='Backend.Stock.Proof.'+dst[len('Stock'):]+'Draft'
 s='import '+consumer+'\n'+s.replace('namespace '+oldns,'namespace '+ns,1).replace('end '+oldns,'end '+ns)
 at=s.index('set_option maxRecDepth');s=s[:at]+'open TryCompleteEntryDraft Try'+('Near' if form=='direct' else form.capitalize())+'EntryExecutionDraft\n'+s[at:]
 a=re.search(r'^theorem ',s,re.M).start();b=s.index(' := by',a);t=s[a:b].replace('_entry_values_witness','_entry_execution_witness')
 f='function' if form=='indirect' else 'f';rho='(rho out.result)' if form=='indirect' else '(fun _ => 9)' if form=='direct' else '(fun _ => 0)'
 needle="(vdefUpd ops outs atCall)) ∧\n      Clif.runWith"
 replacement=f'''(vdefUpd ops outs atCall) ∧
          NormalEntryExecution {f} out.result raw.source.branch.step 0 1 1 raw.info.handlers.length enteredFrame
            (csem (fun _ => False) ⟨0,0⟩ model) {rho} (vdefUpd ops outs atCall) Arm.ArmState.default finalWorld) ∧
      Clif.runWith'''
 assert needle in t;t=t.replace(needle,replacement,1);s=s[:a]+t+s[b:]
 s=s.replace(f'stock_lower_{form}_try_normal_entry_source_values',f'stock_lower_{form}_try_normal_entry_execution',1)
 s=s.replace('column,normalIndex,entryAgreement,defined⟩ := run','column,normalIndex,entryAgreement,defined,complete⟩ := run').replace('execute,column,normalIndex,entryAgreement⟩','execute,column,normalIndex,entryAgreement,complete⟩')
 Path('/tmp',dst+'.lean').write_text(s)
