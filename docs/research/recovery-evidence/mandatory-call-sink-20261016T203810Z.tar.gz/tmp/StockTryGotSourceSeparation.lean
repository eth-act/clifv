import FV.Backend.Proof.StockFreshAlias
import StockTryGotFrontier
import StockTrySourceAvailableGap
import StockTryGotSourceRun
namespace Backend.Stock.Proof.TryGotSourceSeparationDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Driver.Fix Isle Isle.Interp Isle.Aarch64
open TrySourceContextDraft TryBranchSelectionDraft TrySelectedCallsDraft TryBranchAbiDraft
open TryRetsTotalDraft TryGotFrontierDraft TrySourceAvailableGapDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private theorem view_avail {ctx original : Ctx}
    (view : DFGViewEq ctx original) (f : Clif.Function) :
    availIn f ctx = availIn f original := by
  have args : defArgs ctx = defArgs original := by
    funext x
    simp only [defArgs, Ctx.defInst?, view.valDef, view.insts]
  have users : fUsers ctx = fUsers original := by
    simp only [fUsers, usersN, args, view.valDef]
  have bytes : fInB0 f ctx id = fInB0 f original id := by
    unfold fInB0
    rw [view.valDef]
  have work : fWork0 f ctx id = fWork0 f original id := by
    simp only [fWork0, view.valDef, bytes, args]
  simp only [availIn, inFix_eq, users, bytes, work, view.valDef]

/-- Original dominance and actual whole traversal separate every mapped GOT
argument's final alias from the SAME fresh symbol target. The helper protocol,
allocation gap and argument availability are derived, never input certificates. -/
theorem stock_lower_got_try_source_alias_separation {f : Clif.Function} {result : Result}
    (lowered : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    (input : Prg.iselInB f = true)
    {label bi : Nat} {b : Clif.Block} (node : result.order.nodes[label]? = some (.original bi))
    (block : f.blocks[bi]? = some b) {fn : Nat} {args : List Nat} {et : Clif.ExnTable}
    (kind : b.term = .tryCall fn args et) {ext : Clif.ExtFunc} (external : f.extern? fn = some ext)
    (far : ext.colocated = false) :
    ∃ (ranges : Array (Nat × Nat)) (source : TryBranchSource f result label bi b)
      (selected : TryBranchSelection source) (base : Nat)
      (ns bytes : List Nat) (locs : List ArgLoc) (stack target : Nat),
      Stock.buildCtx f = .ok (result.ctx,ranges,result.initial) ∧
      AllocationLe result.initial source.input ∧
      source.ctx.tryRegs = (reservedReturns base ext.sig.returns.length,reservedPayloads base ext.sig.returns.length) ∧
      args.mapM source.ctx.valueReg? = some (ns.map fun n => Reg.vreg n .int) ∧
      sigParamBytes ext.sig = .ok bytes ∧ sigArgLocs ext.sig = .ok (locs,stack) ∧
      target = source.input.base.nextVreg ∧ source.branch.state.base.nextVreg = target+1 ∧
      aliasNum result.final.alias target = target ∧
      selected.next.base.emitted = ((#[ ] ++ ((stackEnts ((locs.zip ns).zip bytes)).map argStore).toArray).push
        (.loadExtNameGot (.vreg target .int) ext.name)).push
        (.call ⟨.reg (.vreg target .int),retPairs (regPairsOf ((locs.zip ns).zip bytes)),callDefs (TryResultMapDraft.resultDefs base ext.sig.returns.length)⟩) ∧
      (∀ x key,x ∈ availOf f (availIn f result.ctx) bi b.body.length →
        result.ctx.valueReg? x = some (.vreg key .int) → aliasNum result.final.alias key ≠ target) ∧
      ∀ n ∈ ns,aliasNum result.final.alias n ≠ target := by
  have isTry : b.term.isTry = true := by rw [kind]; rfl
  obtain ⟨original,⟨originalSelected⟩⟩ := stock_lower_try_source_selection lowered scope node block isTry
  obtain ⟨items,table,_,_,_,_,_⟩ := stock_selected_try_got_rhs_calls originalSelected kind external far
  have sourceTableEq : sourceTable b.term = some et := by rw [kind]; rfl
  obtain ⟨ranges,source,selected,base,replay,replayAfter,build,allocation,slots,replayRun,recordGap,gap⟩ :=
    stock_lower_try_source_available_gap lowered scope dominated input node block sourceTableEq table
  obtain ⟨actualItems,actualTable,_,_,_,_,protocol⟩ := stock_selected_try_got_rhs_calls selected kind external far
  obtain ⟨ns,bytes,locs,stack,target,mapping,byteRun,locations,targetIs,frontier,raw⟩ :=
    stock_got_try_actual_code_with_frontier data_program source.mapped protocol base (exnTableOpnd_cc table) slots
  change target = source.input.base.nextVreg at targetIs
  change selected.next.base.emitted = _ at raw
  have branchFrontier : source.branch.state.base.nextVreg = target+1 := by rw [selected.state]; exact frontier
  have availableGap : ∀ x key,x ∈ availOf f (availIn f result.ctx) bi b.body.length →
      result.ctx.valueReg? x = some (.vreg key .int) → aliasNum result.final.alias key ≠ target := by
    intro x key available mapped same
    rcases gap x key available mapped with before | after
    · rw [← targetIs] at before
      omega
    · rw [branchFrontier] at after
      omega
  refine ⟨ranges,source,selected,base,ns,bytes,locs,stack,target,build,allocation,slots,
    mapping,byteRun,locations,targetIs,branchFrontier,
    (stock_lower_freshAlias_terminal lowered (by rw [targetIs]; exact allocation.1)).2,raw,availableGap,?_⟩
  intro n member
  have mappedMember : Reg.vreg n .int ∈ ns.map (fun k => Reg.vreg k .int) := List.mem_map_of_mem member
  obtain ⟨x,argument,lookup⟩ := Backend.Proof.Flow.mapM_mem mapping _ mappedMember
  rw [source.valueMap] at lookup
  obtain ⟨oldCtx,st0,oldBuild,spec,view⟩ := buildCtx_source build
  have available := (dominated.uses oldCtx ranges st0 oldBuild bi b block).2 x
    (by simp only [kind,abiTerm,termArgs]; exact List.mem_append_left _ argument)
  apply availableGap x n ?_ lookup
  rw [view_avail view f]
  exact available
end Backend.Stock.Proof.TryGotSourceSeparationDraft
