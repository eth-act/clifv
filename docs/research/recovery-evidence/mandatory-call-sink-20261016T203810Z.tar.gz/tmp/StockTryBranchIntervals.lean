import FV.Backend.Proof.StockRecordIntervals
namespace Backend.Stock.Proof.TryBranchIntervalsDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm emitBranch scanBlock
private theorem intervals_nil (lo hi : Nat) : RecordIntervals lo hi [] :=
  ⟨by simp, .nil⟩
private theorem intervals_mono {lo hi a b : Nat} {records : List ScanRecord}
    (h : RecordIntervals a b records) (left : lo ≤ a) (right : b ≤ hi) : RecordIntervals lo hi records := by
  refine ⟨?_, h.ordered⟩
  intro r member
  have bound := h.bounds r member
  exact ⟨Nat.le_trans left bound.1, bound.2.1, Nat.le_trans bound.2.2 right⟩
private theorem intervals_append {lo mid hi : Nat} {first second : List ScanRecord}
    (left : lo ≤ mid) (right : mid ≤ hi)
    (a : RecordIntervals lo mid first) (b : RecordIntervals mid hi second) :
    RecordIntervals lo hi (first ++ second) := by
  refine ⟨?_, List.pairwise_append.mpr ⟨a.ordered, b.ordered, ?_⟩⟩
  · intro r member
    rcases List.mem_append.mp member with fromFirst | fromSecond
    · exact (intervals_mono a (Nat.le_refl lo) right).bounds r fromFirst
    · exact (intervals_mono b left (Nat.le_refl hi)).bounds r fromSecond
  · intro r member s other
    exact Nat.le_trans (a.bounds r member).2.2 (b.bounds s other).1

private theorem scan_intervals {ctx : Ctx} {block ti : Nat} {branch : Bool}
    {indices : List Nat} {input : State} {output : BlockScan}
    (run : scanBlock ctx block ti branch indices input = .ok output) :
    input.base.nextVreg ≤ output.state.base.nextVreg ∧
      RecordIntervals input.base.nextVreg output.state.base.nextVreg output.records := by
  unfold scanBlock at run
  have cert := runScans_spec run
  clear run
  induction cert with
  | nil st => exact ⟨Nat.le_refl _, intervals_nil _ _⟩
  | @cons i indices input scan tail head rest ih =>
    have own := (stock_scan_allocationLe head).1
    refine ⟨Nat.le_trans own ih.1, ⟨?_, ?_⟩⟩
    · intro r member
      rcases List.mem_cons.mp member with rfl | member
      · exact ⟨Nat.le_refl _, own, ih.1⟩
      · exact (intervals_mono ih.2 own (Nat.le_refl _)).bounds r member
    · exact List.Pairwise.cons
        (fun r member => (ih.2.bounds r member).1) ih.2.ordered

private def frame (st : State) := (st.base.nextVreg, st.tryRegs, st.alias)

private theorem forIn_frame {α β γ : Type} (field : α → γ)
    (step : β → α → Except String (ForInStep α))
    (keeps : ∀ x a b, step x a = .ok (.yield b) → field b = field a)
    (no_break : ∀ x a b, step x a ≠ .ok (.done b))
    (xs : List β) {a next : α} (h : forIn xs a step = .ok next) :
    field next = field a := by
  induction xs generalizing a with
  | nil => simp only [List.forIn_nil, pure, Except.pure] at h; cases h; rfl
  | cons x xs ih =>
    rw [List.forIn_cons] at h
    cases call : step x a with
    | error e => simp only [call, bind, Except.bind] at h; cases h
    | ok result =>
      cases result with
      | done b => exact False.elim (no_break x a b call)
      | yield b =>
        simp only [call, bind, Except.bind] at h
        exact (ih h).trans (keeps x a b call)

private def argStep (ctx : Ctx) (rets pays : List Reg) (index nh : Nat)
    (arg : Clif.TryArg) (acc : State × Array Reg) :
    Except String (ForInStep (State × Array Reg)) := do
  match arg with
  | .val v =>
    let some r := ctx.valueReg? v | throw s!"unknown value v{v}"
    pure (.yield (acc.1.mark v, acc.2.push r))
  | .ret i =>
    if index < nh then throw "try_call return on exception edge"
    let some r := rets[i]? | throw "try_call return index"
    pure (.yield (acc.1, acc.2.push r))
  | .exn i =>
    if index == nh then throw "try_call payload on normal edge"
    let some r := pays[i]? | throw "try_call payload index"
    pure (.yield (acc.1, acc.2.push r))

private theorem arg_frame (ctx : Ctx) (rets pays : List Reg) (index nh : Nat)
    (arg : Clif.TryArg) (a b : State × Array Reg)
    (h : argStep ctx rets pays index nh arg a = .ok (.yield b)) :
    frame b.1 = frame a.1 := by
  cases arg <;> unfold argStep at h
  all_goals repeat' first | (solve | cases h <;> rfl) | split at h

private theorem arg_no_break (ctx : Ctx) (rets pays : List Reg) (index nh : Nat)
    (arg : Clif.TryArg) (a b : State × Array Reg) :
    argStep ctx rets pays index nh arg a ≠ .ok (.done b) := by
  intro h
  cases arg <;> unfold argStep at h
  all_goals repeat' first | (solve | cases h) | split at h

private theorem branch_frame {ctx : Ctx} {st next : State} {block index : Nat}
    {args : Array Reg} (h : branchArgs ctx st block index = .ok (args, next)) :
    frame next = frame st := by
  unfold branchArgs at h
  dsimp only at h
  split at h
  · rename_i id values lookup
    split at h
    · rename_i target found
      split at h
      · cases h
      · let ti := (st.instBlock.findIdx? (· == block)).getD 0 + ctx.func.blocks[block]!.body.length
        let reservations := st.tryRegs[ti]!
        let nh := match ctx.func.blocks[block]!.term with
          | .tryCall _ _ et | .tryCallIndirect _ _ et => et.handlers.length
          | _ => 0
        change (do
          let result ← forIn values (st, #[]) (argStep ctx reservations.1 reservations.2 index nh)
          pure (result.2, result.1)) = .ok (args, next) at h
        cases loop : forIn values (st, #[]) (argStep ctx reservations.1 reservations.2 index nh) with
        | error e => simp only [loop, bind, Except.bind] at h; cases h
        | ok result =>
          simp only [loop, bind, Except.bind, pure, Except.pure] at h
          cases h
          exact forIn_frame (fun a : State × Array Reg => frame a.1) _
            (arg_frame ctx reservations.1 reservations.2 index nh)
            (arg_no_break ctx reservations.1 reservations.2 index nh) values loop
    · cases h
  · cases h

private theorem fold_fields_eq {α β γ : Type} (field : α → γ)
    (step : α → β → Except String α)
    (hs : ∀ a b next, step a b = .ok next → field next = field a)
    (xs : List β) {a next : α} (h : xs.foldlM step a = .ok next) :
    field next = field a := by
  induction xs generalizing a with
  | nil => cases h; rfl
  | cons x xs ih =>
    rw [List.foldlM_cons] at h
    cases he : step a x with
    | error e => simp only [he, bind, Except.bind] at h; cases h
    | ok middle =>
      simp only [he, bind, Except.bind] at h
      exact (ih h).trans (hs a x middle he)


private theorem outgoing_frame {ctx : Ctx} {order : Order} {bi : Nat} {targets : Array Nat}
    {st next : State} {outgoing : Array (Array Reg)}
    (h : collectOutgoing ctx order bi targets st = .ok (next, outgoing)) :
    frame next = frame st := by
  unfold collectOutgoing at h
  apply fold_fields_eq (fun a : State × Array (Array Reg) => frame a.1) _ ?_ _ h
  intro acc target result step
  unfold outgoingStep at step
  split at step
  · cases step; rfl
  · cases call : branchArgs ctx acc.1 bi target.2 with
    | error e => simp only [call, bind, Except.bind] at step; cases step
    | ok pair =>
      rcases pair with ⟨regs, state⟩
      simp only [call, bind, Except.bind, pure, Except.pure] at step
      cases step
      exact branch_frame call


private theorem named_alloc {ctx : Ctx} {term : String} {args : List V}
    {st next : State} {out : Option V} {trace : List RuleId}
    (h : Stock.runTerm ctx term args st = .ok (out, next, trace)) :
    AllocationLe st next := by
  unfold Stock.runTerm at h
  cases hr : Isle.Interp.run program (Stock.sem ctx) {} term args st with
  | error e => rw [hr] at h; cases h
  | ok result =>
    rw [hr] at h
    cases h
    unfold Isle.Interp.run at hr
    cases ht : program.termByName? term with
    | none => simp only [ht] at hr; cases hr
    | some t =>
      simp only [ht] at hr
      cases ha : (applyTerm program (Stock.sem ctx) {} (Config.fuel ({} : Config))
          t.ret t.id args).run (st, #[]) with
      | error e => simp only [ha, bind, Except.bind] at hr; cases hr
      | ok result =>
        rcases result with ⟨out, next, trace⟩
        simp only [ha, bind, Except.bind, pure, Except.pure] at hr
        cases hr
        exact stock_apply_allocationLe ha

private theorem branch_mono {ctx : Ctx} {f : Clif.Function} {t : Clif.Terminator}
    {bi ti : Nat} {targets : Array Nat} {input : State} {output : BranchEmission}
    (run : emitBranch ctx f t bi ti targets input = .ok output) :
    input.base.nextVreg ≤ output.state.base.nextVreg := by
  unfold emitBranch at run
  dsimp only at run
  let before := { input with current := some ti, color := none, base.emitted := #[] }
  change ((do
    let (out, next, fired) ← Stock.runTerm ctx "lower_branch" [.inst ti, .labels targets.toList] before
    if out.isNone then throw s!"no lowering rule for terminator {repr t}"
    let code ← branchCode f t targets next.base.emitted
    pure ⟨next, code, ⟨bi, ti, .emitted, before, next, [], fired, code⟩, fired⟩) : Except String BranchEmission) = .ok output at run
  cases root : Stock.runTerm ctx "lower_branch" [.inst ti, .labels targets.toList] before with
  | error e => simp only [root, bind, Except.bind] at run; cases run
  | ok result =>
    rcases result with ⟨out, next, fired⟩
    simp only [root, bind, Except.bind] at run
    split at run
    · cases run
    · cases code : branchCode f t targets next.base.emitted with
      | error e => simp only [code] at run; cases run
      | ok instructions =>
        simp only [code, pure, Except.pure] at run
        cases run
        exact (named_alloc root).1

theorem stock_core_branch_intervals {f : Clif.Function} {ctx : Ctx}
    {second : Clif.Block} {start stop : Nat}
    {order : Order} {data : V} {targets : Array Nat} {input : State} {output : LoweredBlockCore}
    (run : lowerBlockCore ctx order f second bi start stop data targets input = .ok output) :
    input.base.nextVreg ≤ output.state.base.nextVreg ∧
      RecordIntervals input.base.nextVreg output.state.base.nextVreg output.scan.output.records ∧
      ∀ branch,output.branch = some branch →
        RecordIntervals branch.state.base.nextVreg output.state.base.nextVreg output.scan.output.records ∧
        input.base.nextVreg ≤ branch.state.base.nextVreg ∧ branch.state.base.nextVreg ≤ output.state.base.nextVreg := by
  let ti := stop - 1
  let selected := { Driver.termCtx ctx ti data with tryRegs := input.tryRegs[ti]! }
  let branch : Bool := match second.term with | .ret .. | .trap .. | .returnCall .. => false | _ => true
  let branchCall : Except String (Option BranchEmission) :=
    if branch then some <$> emitBranch selected f second.term bi ti targets input else pure none
  have branchKeeps {br : Option BranchEmission} (call : branchCall = .ok br) :
      input.base.nextVreg ≤ ((br.map (·.state)).getD input).base.nextVreg := by
    unfold branchCall at call
    split at call
    · cases emitted : emitBranch selected f second.term bi ti targets input with
      | error e => simp only [emitted, Functor.map, Except.map] at call; cases call
      | ok e =>
        simp only [emitted, Functor.map, Except.map] at call
        cases call
        exact branch_mono emitted
    · cases call; exact Nat.le_refl _
  have normal : lowerBlockCore ctx order f second bi start stop data targets input = (do
      let br ← branchCall
      let (next, outgoing) ← collectOutgoing ctx order bi targets (br.map (·.state) |>.getD input)
      let before := { next with color := some next.endColor[bi]! }
      let indices := ((Array.range (stop - start)).map (start + ·)).reverse.toList
      let body ← scanBlock selected bi ti branch indices before
      pure ⟨body.state, body.code ++ (br.map (·.code) |>.getD #[]), outgoing,
        br, ⟨selected, bi, ti, branch, indices, before, body⟩⟩) := by
    unfold lowerBlockCore
    dsimp only [branchCall, branch, selected, ti, Driver.termCtx]
    split <;> simp_all only [branch, selected, ti] <;> rfl
  rw [normal] at run
  cases call : branchCall with
  | error e => simp only [call, bind, Except.bind] at run; cases run
  | ok br =>
    simp only [call, bind, Except.bind] at run
    cases edges : collectOutgoing ctx order bi targets (br.map (·.state) |>.getD input) with
    | error e => simp only [edges] at run; cases run
    | ok pair =>
      rcases pair with ⟨next, outgoing⟩
      simp only [edges] at run
      let before := { next with color := some next.endColor[bi]! }
      let indices := ((Array.range (stop - start)).map (start + ·)).reverse.toList
      have keeps : input.base.nextVreg ≤ before.base.nextVreg := by
        have frontier := congrArg Prod.fst (outgoing_frame edges)
        change next.base.nextVreg = ((br.map (·.state)).getD input).base.nextVreg at frontier
        change input.base.nextVreg ≤ next.base.nextVreg
        rw [frontier]
        exact branchKeeps call
      change (scanBlock selected bi ti branch indices before >>= fun body =>
        pure (⟨body.state, body.code ++ (br.map (·.code) |>.getD #[]), outgoing,
          br, ⟨selected, bi, ti, branch, indices, before, body⟩⟩ : LoweredBlockCore)) = .ok output at run
      cases scan : scanBlock selected bi ti branch indices before with
      | error e => simp only [scan, bind, Except.bind] at run; cases run
      | ok body =>
        simp only [scan, bind, Except.bind, pure, Except.pure] at run
        cases run
        have intervals := scan_intervals scan
        refine ⟨Nat.le_trans keeps intervals.1,intervals_mono intervals.2 keeps (Nat.le_refl _),?_⟩
        intro actual present
        cases br with
        | none => cases present
        | some actualBranch =>
          cases present
          have frontier := congrArg Prod.fst (outgoing_frame edges)
          change next.base.nextVreg = actual.state.base.nextVreg at frontier
          have lower : input.base.nextVreg ≤ actual.state.base.nextVreg := by simpa only [Option.map_some,Option.getD_some] using branchKeeps call
          have records : RecordIntervals actual.state.base.nextVreg body.state.base.nextVreg body.records := by
            simpa only [before,frontier] using intervals.2
          have upper : actual.state.base.nextVreg ≤ body.state.base.nextVreg := by
            simpa only [before,frontier] using intervals.1
          exact ⟨records,lower,upper⟩

theorem stock_node_record_suffix_intervals {f : Clif.Function} {ctx : Ctx}
    {ranges : Array (Nat × Nat)}
    {order : Order} {params : List Nat} {label : Nat} {input output : DriverState}
    (run : lowerNode ctx ranges order f params label input = .ok output) :
    ∃ extra : Array BlockScanEvent,output.blockScans = input.blockScans ++ extra ∧
      input.state.base.nextVreg ≤ output.state.base.nextVreg ∧
      RecordIntervals input.state.base.nextVreg output.state.base.nextVreg (retainedRecords extra) := by
  cases node : order.nodes[label]! with
  | edge pred k target =>
    unfold lowerNode at run
    simp only [node] at run
    cases args : branchArgs ctx input.state pred k with
    | error e => simp only [args, bind, Except.bind] at run; cases run
    | ok pair =>
      rcases pair with ⟨args, next⟩
      simp only [args, bind, Except.bind, pure, Except.pure] at run
      cases run
      have frontier := congrArg Prod.fst (branch_frame args)
      change next.base.nextVreg = input.state.base.nextVreg at frontier
      exact ⟨#[],by simp,by rw [frontier]; exact Nat.le_refl _,intervals_nil _ _⟩
  | original bi =>
    let b := f.blocks[bi]!
    let start := ranges[bi]!.1
    let stop := ranges[bi]!.2
    let fetchData : Except String V := match b.term with
      | .tryCall .. | .tryCallIndirect .. => tryCallData f b.term
      | _ => termData (abiTerm f b.term)
    let reject : Bool := (match b.term with | .ret .. => true | _ => false) &&
      (sretRet f).isEmpty && (sigRets f.sig != f.sig.returns)
    have normal : lowerNode ctx ranges order f params label input = (do
        let data ← fetchData
        if reject then throw "sret parameter is not an entry-block parameter"
        let lowered ← lowerBlockCore ctx order f b bi start stop data order.successors[label]! input.state
        let assembled ← assembleOriginalBlock ctx f b bi label order.successors[label]!
          lowered.outgoing params lowered.state.uses lowered.code
        pure { recordCore input lowered bi stop with
          blocks := input.blocks.set! label assembled,
          edgeArgs := input.edgeArgs.set! label lowered.outgoing }) := by
      unfold lowerNode
      simp only [node]
      dsimp only [fetchData, reject, b, start, stop]
      split <;> simp_all only [reject] <;> rfl
    rw [normal] at run
    cases dataRun : fetchData with
    | error e => simp only [dataRun, bind, Except.bind] at run; cases run
    | ok data =>
      simp only [dataRun, bind, Except.bind] at run
      split at run
      · cases run
      · cases core : lowerBlockCore ctx order f b bi start stop data order.successors[label]! input.state with
        | error e => simp only [core] at run; cases run
        | ok lowered =>
          simp only [core] at run
          cases assembled : assembleOriginalBlock ctx f b bi label order.successors[label]!
              lowered.outgoing params lowered.state.uses lowered.code with
          | error e => simp only [assembled] at run; cases run
          | ok block =>
            simp only [assembled, pure, Except.pure] at run
            cases run
            have intervals := stock_core_branch_intervals core
            refine ⟨#[lowered.scan],?_,intervals.1,?_⟩
            · simp only [recordCore,Array.push_eq_append]
            · simpa [retainedRecords,recordCore] using intervals.2.1

/-- Actual suffix diagnostics contain only records allocated within that suffix;
old diagnostic history is preserved exactly. -/
theorem stock_nodes_record_suffix_intervals {ctx : Ctx} {ranges : Array (Nat × Nat)}
    {order : Order} {f : Clif.Function} {params labels : List Nat} {input output : DriverState}
    (run : labels.foldlM (fun d label => lowerNode ctx ranges order f params label d) input = .ok output) :
    ∃ extra : Array BlockScanEvent,output.blockScans = input.blockScans ++ extra ∧
      input.state.base.nextVreg ≤ output.state.base.nextVreg ∧
      RecordIntervals input.state.base.nextVreg output.state.base.nextVreg (retainedRecords extra) := by
  induction labels generalizing input with
  | nil => cases run; exact ⟨#[],by simp,Nat.le_refl _,intervals_nil _ _⟩
  | cons label labels ih =>
    rw [List.foldlM_cons] at run
    obtain ⟨middle,first,rest⟩ := Except.bind_ok run
    obtain ⟨left,old,mono,bounds⟩ := stock_node_record_suffix_intervals first
    obtain ⟨right,tail,mono',bounds'⟩ := ih rest
    refine ⟨left ++ right,?_,Nat.le_trans mono mono',?_⟩
    · rw [tail,old,Array.append_assoc]
    · simp only [retainedRecords,Array.toList_append,List.flatMap_append]
      exact intervals_append mono mono' bounds bounds'
end Backend.Stock.Proof.TryBranchIntervalsDraft
