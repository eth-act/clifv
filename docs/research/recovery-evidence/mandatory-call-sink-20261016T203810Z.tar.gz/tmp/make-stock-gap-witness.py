from pathlib import Path
s=Path('/tmp/StockTryPayloadTerminalWitness.lean').read_text();a=s.index('private def function');b=s.index('/-- Complete near/GOT',a)
head='''import StockTrySourceAvailableGap
import StockTryEmittedWitness
import StockTryStackFixture
namespace Backend.Stock.Proof.TryGapWitnessDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open TryEmittedWitnessDraft (Kind)
open TrySourceContextDraft TryBranchSelectionDraft TryBranchAbiDraft TrySourceAvailableGapDraft TryRetsTotalDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
'''
body='''/-- Every branch/allocation/source gap is inhabited by actual near, GOT and
true-indirect whole compiler/prepare/checked fallback/physical pipelines.
The pre-existing fixtures retain their real body records and reservations. -/
theorem stock_complete_try_source_allocation_gap_witness (k : Kind) :
    ∃ (out : Fixture k) (ranges : Array (Nat × Nat))
      (source : TryBranchSource (function k) out.result 0 0 (entry k))
      (_selected : TryBranchSelection source) (base : Nat) (value : V) (next : State),
      LowerScope (function k) ∧ Dominated (function k) ∧ ArityOk (function k) ∧
      Stock.lower (function k) = .ok out.result ∧ prepareAt out.result.code out.result.edgeArgs = .ok out.prepared ∧
      out.rf = spillAllocAt out.prepared.code out.prepared.edges ∧
      checkAllocAt out.prepared.code out.prepared.edges out.rf = .ok () ∧ lowerRFunc out.prepared.code out.rf = .ok out.af ∧
      Stock.buildCtx (function k) = .ok (out.result.ctx,ranges,out.result.initial) ∧
      AllocationLe out.result.initial source.input ∧
      source.ctx.tryRegs = (reservedReturns base (function k).sig.returns.length,reservedPayloads base (function k).sig.returns.length) ∧
      Stock.externCtor source.ctx T.gen_try_call_rets [.op (.sig (function k).sig)] source.input = .ok (value,next) ∧
      (∀ event ∈ out.result.blockScans.toList,∀ record ∈ event.output.records,
        record.output.state.base.nextVreg ≤ source.input.base.nextVreg ∨
          source.branch.state.base.nextVreg ≤ record.input.base.nextVreg) ∧
      ∀ x key,x ∈ availOf (function k) (availIn (function k) out.result.ctx) 0 (entry k).body.length →
        out.result.ctx.valueReg? x = some (.vreg key .int) →
          aliasNum out.result.final.alias key < source.input.base.nextVreg ∨
            source.branch.state.base.nextVreg ≤ aliasNum out.result.final.alias key := by
  obtain ⟨out⟩ := fixture k
  have sameOrder := Except.ok.inj ((stock_lower_order out.lowered).symm.trans (order k))
  have node : out.result.order.nodes[0]? = some (.original 0) := by rw [sameOrder]; rfl
  have block : (function k).blocks[0]? = some (entry k) := by cases k <;> rfl
  have input : Prg.iselInB (function k) = true := by cases k <;> decide +kernel
  have kind : sourceTable (entry k).term = some table := by cases k <;> rfl
  have decoded : exnTableOpnd (function k) table = .ok ((function k).sig,[some 7]) := by cases k <;> rfl
  obtain ⟨ranges,source,selected,base,value,next,build,allocation,slots,helper,records,gap⟩ :=
    stock_lower_try_source_available_gap out.lowered out.scope out.dominated input node block kind decoded
  exact ⟨out,ranges,source,selected,base,value,next,out.scope,out.dominated,out.arity,out.lowered,out.prepare,
    out.fallback,out.accepted,out.physical,build,allocation,slots,helper,records,gap⟩
end Backend.Stock.Proof.TryGapWitnessDraft
'''
Path('/tmp/StockTryGapWitness.lean').write_text(head+s[a:b]+body)
