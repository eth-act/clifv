from pathlib import Path
import json,hashlib,re,datetime,tarfile,shutil
root=Path('/home/lee/clifv/.worktrees/driver-proof-resume');docs=root/'docs/research'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
now=datetime.datetime.now(datetime.timezone.utc);stamp=now.strftime('%Y%m%dT%H%M%SZ')
batch=json.loads(Path('/tmp/stock-try-gap-batch.json').read_text());old=json.loads((docs/'stock-try-resolved-scratch.json').read_text())
log=Path('/tmp/stock-try-gap-combined-axioms.log').read_text()
sets={m.group(1):sorted(x.strip() for x in m.group(2).split(',') if x.strip()) for m in re.finditer(r"'([^']+)' depends on axioms:\s*\[([^]]*)\]",log)}
for m in re.finditer(r"'([^']+)' does not depend on any axioms",log):sets[m.group(1)]=[]
for n,a in old['normal_audit']['sets'].items():assert sorted(a)==sets[n],n
assert len(sets)==len(old['normal_audit']['sets'])+len(batch['public_roots'])+len(batch['models'])
allowed={'propext','Classical.choice','Quot.sound'}
for n in batch['public_roots']+batch['models']:assert set(sets[n])<=allowed,n
constants=[json.loads(line.split('DELIVERY_CONSTANT ',1)[1]) for line in Path('/tmp/stock-try-gap-all-constants.log').read_text().splitlines() if line.startswith('DELIVERY_CONSTANT ')]
assert constants
for n,a in constants:assert set(a)<=allowed,n
mods={}
for m in batch['modules']:
 p=Path('/tmp')/m;check=json.loads(p.with_suffix('.check.json').read_text());assert check['actual_exit']==0
 rec={}
 for key,ext in [('source','.lean'),('object','.olean'),('log','.log'),('check','.check.json')]:
  f=p.with_suffix(ext);rec[key]=str(f);rec[key+'_sha256']=sha(f)
 for k in ['source','object','log']:assert rec[k+'_sha256']==check[k+'_sha256']
 assert not re.search(r'\b(sorry|admit|axiom|trace_state|native_decide)\b',p.with_suffix('.lean').read_text()),m
 mods[m]=rec
for audit in ['stock-try-gap-combined-axioms','stock-try-gap-all-constants']:
 p=Path('/tmp')/audit;check=json.loads(p.with_suffix('.check.json').read_text());assert check['actual_exit']==0
 for k,ext in [('source','.lean'),('object','.olean'),('log','.log')]:assert sha(p.with_suffix(ext))==check[k+'_sha256']
prior={}
for name in ['source-execution-x','try-source','try-context','try-rule','try-rets','try-reservation','try-outgoing','try-values','try-emitted','try-machine','try-got','try-indirect','try-rename','try-resolved']:
 d=json.loads((docs/f'stock-{name}-scratch.json').read_text())
 for m,rec in d['modules'].items():
  for k in ['source','object','log']:assert sha(rec[k])==rec[k+'_sha256'],(m,k)
  prior[m]=rec
freeze=json.loads(Path('/tmp/stock-coherent-build-inputs.json').read_text())
for group in ['source_sha256','validation_script_sha256']:
 for p,h in freeze[group].items():assert sha(root/p)==h,p
progress=json.loads(Path('/tmp/stock-pr246-gates-progress.json').read_text());progress.pop('completed_phases',None)
remaining=old['remaining_checklist']
remaining.append({'requirement':'GOT TryCall actual fresh-target/source final alias separation','state':'Proved internally from real original/critical-edge traversal intervals, every retained record gap, original Dominated source availability and fresh source producer provenance. Actual GOT helper allocates exactly target+1; target is final alias terminal. Every available mapped source and each actual mapped argument excludes target. Complete three-form gap and nine-argument/16-byte GOT pipelines witnessed. Final-renamed GOT machine execution/available-source frame/normal continuation remain open.'})
counts={'modules':len(mods),'public_roots':len(batch['public_roots']),'models':len(batch['models']),'combined_roots_models':len(sets),'previous_preserved':len(old['normal_audit']['sets']),'all_new_module_constants':len(constants),'previous_modules_hashes_preserved':len(prior)}
receipt={'utc':now.isoformat(),'goal':'Original full #140 ACTIVE/INCOMPLETE; production LEGACY','scope':'Scratch-only additive Stock proofs, not coherent integration or merge-ready','delivery_target':'roughly eight substantive validated squash merges/day; prioritize landing coherent backlog, remote backups and cleanup; drafts do not count','modules':mods,'public_roots':batch['public_roots'],'models':batch['models'],'counts':counts,'normal_audit':{'path':'/tmp/stock-try-gap-combined-axioms.log','sha256':sha('/tmp/stock-try-gap-combined-axioms.log'),'sets':sets},'all_constant_audit':{'path':'/tmp/stock-try-gap-all-constants.log','sha256':sha('/tmp/stock-try-gap-all-constants.log'),'all_standard_only':True,'count':len(constants)},'previous_modules_hashes_preserved':list(prior),'canonical2246_source_and_script_freeze_preserved':True,'kernel_resources':'All new modules and both audits actual exit0/object verified at8GiB through memcap; one heavy delivery worker retained','MCP':'No new calls; bundled audit deferred until coherent integration','active_exact_PR246_validation':progress,'remaining_checklist':remaining}
(docs/'stock-try-gap-scratch.json').write_text(json.dumps(receipt,indent=2)+'\n')
text=f'''GOT TryCall fresh-target/source alias separation — {now.isoformat()}

Seven scratch modules/nine public roots pass actual8GiB kernel checks. The {len(sets)}-root/model audit preserves all562prior exact axiom sets. All {len(constants)} constants of new modules, including private interval/DFG/fixture helpers, use only standard axioms. All{len(prior)}previous scratch source/object/log hashes and frozen2246canonical sources plus49validation scripts remain unchanged. Previous goal turn was a verified live delivery wait and cadence/status update, with no new proof; this batch makes concrete proof progress.

Actual emitBlockCore intervals place retained body records after branch fresh allocation. Original/critical-edge node and full suffix traversal retain interval bounds and diagnostic concatenation. Whole original TryCall construction derives a gap for EVERY actual retained record: it ends before the branch input frontier or starts after the branch output frontier. Available source final alias fresh-origin provenance then excludes this branch's entire allocation interval, with original Dominated availability transported through the unchanged DFG view. No new source-use, allocation, layout or alias certificate is an accepted-input condition.

The real GOT helper allocates EXACTLY one fresh target and returns nextVreg=target+1. Its original-source consumer derives the actual reserved layout, arguments, byte/ABI locations, exact stores/load/call, initial and final target frontiers, final target terminal and final-alias separation for EVERY original available mapped source and EVERY actual mapped argument. Complete near/GOT/true-indirect compiler→prepareAt→forced checkedfallback→checker→physical pipelines inhabit all interval/source gap roots; complete nine-argument GOT with16byte outgoing area inhabits exact target/code/separation. Original fixture body records, inputs and all earlier raw/final direct/indirect variants are retained.

Next: compose the GOT argument stores and fresh symbol load under final alias renaming, then the stopped call with fixed reserved defs. Prefix agreement excludes only the fresh target; last-call renaming must use actual argument separation without imposing a caller certificate or excluding legitimate aliases to reserved result registers. Final-renamed GOT execution is NOT yet proved here. Available source-frame/DFG/reserved-write noninterference, normal edge copies/source continuation, exact shared payload alias endpoints/exception machine execution remain. Every remaining original family/effect/source/block/whole-driver simulation AND completeness, original-input context/visitor/static/checker/fallback/physical totality, coherent scratch integration/MCP/public/private/compiler audits, full/crates/runtime/encoder/BOTH E2E identity-stage parity, production compiler/checker/linker/generated consumers and FRESH COMPLETE comparison remain mandatory. Production LEGACY, full#140 ACTIVE/INCOMPLETE. S10 shared exceptional interfaces stay with @kevaundray #232/#233.

Delivery246/247 remain drafts; same live exact-PR worker3247835/shared warm cache, canonical1233457 deliberately held. Preserve old-head receipts, reconcile current main and rerun affected kernel/trust and all full gates at actual updated heads before dependent squash merges. Target roughly8substantive validated merges/day with related semantic grouping and remote backups. No merge/new worktree/new MCP/heavy retry/gate restart this batch.

Hashed evidence and full remaining checklist: stock-try-gap-scratch.json.
'''
(docs/'stock-try-gap-scratch.md').write_text(text)
plan=root/'docs/plans/test-binary-alignment-recovery.md';plan.write_text(plan.read_text()+'\n\n'+text)
files=[]
for rec in mods.values():files.extend(Path(rec[k]) for k in ['source','object','log','check'])
for name in ['stock-try-gap-combined-axioms','stock-try-gap-all-constants']:
 for ext in ['.lean','.log','.olean','.check.json']:files.append(Path('/tmp')/(name+ext))
files.extend(Path(p) for p in ['/tmp/stock-try-gap-batch.json','/tmp/stock-try-rule-inputs.json','/tmp/stock-try-reservation-check.py','/tmp/stock-try-gap-close.py','/tmp/stock-try-gap-make-audit.py','/tmp/make-stock-gap-witness.py','/tmp/stock-try-gap-status44.json','/tmp/stock-try-gap-status52.json','/tmp/stock-try-gap-status71.json','/tmp/stock-try-gap-task140.json'])
files.extend([docs/'stock-try-gap-scratch.json',docs/'stock-try-gap-scratch.md',docs/'stock-delivery-main-drift.json',plan])
archive=Path('/home/lee/.clifv-recovery')/(stamp+'-try-gap')/'checkpoint.tar.gz';archive.parent.mkdir(parents=True)
with tarfile.open(archive,'w:gz',compresslevel=1) as t:
 for p in files:t.add(p,arcname=str(p).lstrip('/'),recursive=False)
with tarfile.open(archive,'r:gz') as t:
 for p in files:assert t.extractfile(str(p).lstrip('/')).read()==p.read_bytes(),p
snapshot=Path('/tmp/stock-try-rule-inputs');size=sum(p.stat().st_size for p in snapshot.rglob('*') if p.is_file());shutil.rmtree(snapshot)
backup={'utc':now.isoformat(),'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(files),'all_members_byte_verified':True,'previous_remote_backup':json.loads((docs/'stock-try-resolved-backup.json').read_text())['remote'],'cleanup':{'duplicate_dependency_snapshot_removed':True,'bytes_reclaimed':size,'unique_sources_objects_logs_checks_audits_preserved':True,'one_shared_warm_cache_retained':True,'other_projects_touched':False,'free_bytes':shutil.disk_usage(root).free}}
(docs/'stock-try-gap-backup.json').write_text(json.dumps(backup,indent=2)+'\n');Path('/tmp/stock-try-gap-archive-path').write_text(str(archive))
print(json.dumps({'counts':counts,'archive':str(archive),'cleanup':backup['cleanup'],'gate':progress},indent=2))
