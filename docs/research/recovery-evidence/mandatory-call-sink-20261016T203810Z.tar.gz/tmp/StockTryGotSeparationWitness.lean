import StockTryGotSourceSeparation
import StockTryStackFixture
namespace Backend.Stock.Proof.TryGotSeparationWitnessDraft
open Backend.Proof Backend.Proof.Driver Backend.Proof.Spill Isle Isle.Interp Isle.Aarch64
open TrySourceContextDraft TryBranchSelectionDraft TryBranchAbiDraft TryRetsTotalDraft TryStackFixtureDraft TryGotSourceSeparationDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private def f := TryStackSourceDraft.function
private def ext : Clif.ExtFunc := {name := "callee",sig := f.sig,colocated := false}
private def table := TryStackSourceDraft.table
/-- Complete nine-argument GOT compilation, actual sixteen-byte outgoing area
and nonempty real source requests inhabit the internally derived final-alias
separation and exact fresh-target allocation/code. -/
theorem stock_complete_nine_argument_got_alias_separation_witness :
    ∃ out : Output,
      LowerScope f ∧ Dominated f ∧ ArityOk f ∧ Stock.lower f = .ok out.result ∧
      prepareAt out.result.code out.result.edgeArgs = .ok out.prepared ∧
      out.rf = spillAllocAt out.prepared.code out.prepared.edges ∧
      checkAllocAt out.prepared.code out.prepared.edges out.rf = .ok () ∧ lowerRFunc out.prepared.code out.rf = .ok out.af ∧
      out.result.code.outgoing = 16 ∧
    ∃ (ranges : Array (Nat × Nat)) (source : TryBranchSource f out.result 0 0 f.blocks[0]!)
      (selected : TryBranchSelection source) (base : Nat)
      (ns bytes : List Nat) (locs : List ArgLoc) (stack target : Nat),
      Stock.buildCtx f = .ok (out.result.ctx,ranges,out.result.initial) ∧
      AllocationLe out.result.initial source.input ∧
      source.ctx.tryRegs = (reservedReturns base ext.sig.returns.length,reservedPayloads base ext.sig.returns.length) ∧
      (List.range 9).mapM source.ctx.valueReg? = some (ns.map fun n => Reg.vreg n .int) ∧
      sigParamBytes ext.sig = .ok bytes ∧ sigArgLocs ext.sig = .ok (locs,stack) ∧
      target = source.input.base.nextVreg ∧ source.branch.state.base.nextVreg = target+1 ∧
      aliasNum out.result.final.alias target = target ∧
      selected.next.base.emitted = ((#[ ] ++ ((stackEnts ((locs.zip ns).zip bytes)).map argStore).toArray).push
        (.loadExtNameGot (.vreg target .int) ext.name)).push
        (.call ⟨.reg (.vreg target .int),retPairs (regPairsOf ((locs.zip ns).zip bytes)),callDefs (TryResultMapDraft.resultDefs base ext.sig.returns.length)⟩) ∧
      (∀ x key,x ∈ availOf f (availIn f out.result.ctx) 0 f.blocks[0]!.body.length →
        out.result.ctx.valueReg? x = some (.vreg key .int) → aliasNum out.result.final.alias key ≠ target) ∧
      ∀ n ∈ ns,aliasNum out.result.final.alias n ≠ target := by
  obtain ⟨out⟩ := stock_nine_argument_try_fixture
  have order : blockOrder f = .ok {nodes := #[.original 0,.original 1,.original 2],successors := #[#[2,1],#[],#[]]} := by cbv
  have sameOrder := Except.ok.inj ((stock_lower_order out.lowered).symm.trans order)
  have node : out.result.order.nodes[0]? = some (.original 0) := by rw [sameOrder]; rfl
  have block : f.blocks[0]? = some f.blocks[0]! := rfl
  have kind : f.blocks[0]!.term = .tryCall 0 (List.range 9) table := rfl
  have external : f.extern? 0 = some ext := rfl
  exact ⟨out,out.scope,out.dominated,out.arity,out.lowered,out.prepare,out.fallback,out.accepted,out.physical,out.outgoing,
    stock_lower_got_try_source_alias_separation out.lowered out.scope out.dominated
      (show Prg.iselInB f = true from by decide +kernel) node block kind external rfl⟩
end Backend.Stock.Proof.TryGotSeparationWitnessDraft
