import StockTrySourceGap
import StockTrySourceRetsTotal
import StockTryBranchSelection
namespace Backend.Stock.Proof.TrySourceAvailableGapDraft
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
open TrySourceGapDraft TrySourceContextDraft TrySourceRetsTotalDraft TryRetsTotalDraft TryBranchSelectionDraft TryBranchAbiDraft
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private theorem entries_iff {a : Array (Option Nat)} {key target : Nat} :
    (key, target) ∈ finalAliasEntries a ↔ (a[key]?).join = some target := by
  constructor
  · intro member
    obtain ⟨n, _, mapped⟩ := List.mem_filterMap.mp member
    cases lookup : (a[n]?).join with
    | none => simp only [lookup, Option.map_none] at mapped; cases mapped
    | some value =>
      simp only [lookup, Option.map_some, Option.some.injEq, Prod.mk.injEq] at mapped
      rcases mapped with ⟨rfl, rfl⟩
      exact lookup
  · intro entry
    have inside : key < a.size := by
      apply Nat.lt_of_not_ge
      intro outside
      rw [Array.getElem?_eq_none outside] at entry
      cases entry
    exact List.mem_filterMap.mpr ⟨key, List.mem_range.mpr inside, by rw [entry]; rfl⟩

private theorem entries_faithful (a : Array (Option Nat)) :
    Faithful (finalAliasEntries a) (fun key => (a[key]?).join) := by
  constructor
  · intro key target entry; exact entries_iff.mpr entry
  · intro key absent target member
    have entry := entries_iff.mp member
    rw [absent] at entry
    cases entry

private theorem resolver_path {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    (key : Nat) :
    AliasPath (finalAliasEntries result.final.alias) key (aliasNum result.final.alias key) ∧
      (result.final.alias[aliasNum result.final.alias key]?).join = none := by
  obtain ⟨rank, decrease⟩ := stock_lower_alias_wellFounded run scope dominated
  have contains : ∀ p ∈ finalAliasEntries result.final.alias,
      p.1 ∈ List.range result.final.alias.size := by
    intro p member
    obtain ⟨key, inside, mapped⟩ := List.mem_filterMap.mp member
    cases lookup : (result.final.alias[key]?).join with
    | none => simp only [lookup, Option.map_none] at mapped; cases mapped
    | some target =>
      simp only [lookup, Option.map_some, Option.some.injEq] at mapped
      subst p
      exact inside
  have count := chainCount_le (finalAliasEntries result.final.alias) rank
    (List.range result.final.alias.size) key
  simp only [List.length_range] at count
  exact chaseF_end (entries_faithful result.final.alias) decrease contains
    (result.final.alias.size + 1) key (by omega)


private theorem source_alias_gap {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    {label bi : Nat} {b : Clif.Block} (source : TryBranchSource f result label bi b)
    (allocation : AllocationLe result.initial source.input)
    (gap : ∀ event ∈ result.blockScans.toList,∀ record ∈ event.output.records,
      record.output.state.base.nextVreg ≤ source.input.base.nextVreg ∨
        source.branch.state.base.nextVreg ≤ record.input.base.nextVreg)
    {x key : Nat} (available : x ∈ availOf f (availIn f result.ctx) bi b.body.length)
    (mapped : result.ctx.valueReg? x = some (.vreg key .int)) :
    aliasNum result.final.alias key < source.input.base.nextVreg ∨
      source.branch.state.base.nextVreg ≤ aliasNum result.final.alias key := by
  by_cases below : aliasNum result.final.alias key < result.initial.base.nextVreg
  · exact .inl (Nat.lt_of_lt_of_le below allocation.1)
  · have fresh := Nat.le_of_not_gt below
    obtain ⟨event,record,info,y,sourceKey,events,records,slot,defines,sourceMap,ownerAvailable,lower,upper⟩ :=
      stock_lower_source_path_fresh_origin run scope dominated available mapped
        (resolver_path run scope dominated key).1 fresh
    rcases gap event events record records with before | after
    · exact .inl (Nat.lt_of_lt_of_le upper before)
    · exact .inr (Nat.le_trans after lower)
/-- Whole original source/build/traversal derives reservation layout, actual
helper, real branch gap and exclusion of EVERY source-available final alias
from that branch's fresh allocation interval. None is a caller certificate. -/
theorem stock_lower_try_source_available_gap {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f) (input : Prg.iselInB f = true)
    {label bi : Nat} {b : Clif.Block} (node : result.order.nodes[label]? = some (.original bi))
    (block : f.blocks[bi]? = some b) {et : Clif.ExnTable} {sig : Clif.Signature} {items : List (Option Nat)}
    (kind : sourceTable b.term = some et) (table : exnTableOpnd f et = .ok (sig,items)) :
    ∃ (ranges : Array (Nat × Nat)) (source : TryBranchSource f result label bi b)
      (_selected : TryBranchSelection source) (base : Nat) (value : V) (next : State),
      Stock.buildCtx f = .ok (result.ctx,ranges,result.initial) ∧ AllocationLe result.initial source.input ∧
      source.ctx.tryRegs = (reservedReturns base sig.returns.length,reservedPayloads base sig.returns.length) ∧
      Stock.externCtor source.ctx T.gen_try_call_rets [.op (.sig sig)] source.input = .ok (value,next) ∧
      (∀ event ∈ result.blockScans.toList,∀ record ∈ event.output.records,
        record.output.state.base.nextVreg ≤ source.input.base.nextVreg ∨
          source.branch.state.base.nextVreg ≤ record.input.base.nextVreg) ∧
      ∀ (x key : Nat),x ∈ availOf f (availIn f result.ctx) bi b.body.length →
        result.ctx.valueReg? x = some (.vreg key .int) →
          aliasNum result.final.alias key < source.input.base.nextVreg ∨
            source.branch.state.base.nextVreg ≤ aliasNum result.final.alias key := by
  have isTry : b.term.isTry = true := by
    cases term : b.term <;> simp only [sourceTable,term] at kind
    all_goals first | contradiction | rfl
  obtain ⟨ranges,source,build,allocation,gap⟩ := stock_lower_try_source_record_gap run scope node block isTry
  obtain ⟨selected⟩ := stock_try_branch_selection source
  obtain ⟨base,value,next,layout,helper⟩ := stock_original_source_try_rets_total build input allocation block kind table
  have slots : source.ctx.tryRegs = (reservedReturns base sig.returns.length,reservedPayloads base sig.returns.length) := by
    rw [source.tryRegs,source.index]
    exact layout
  have actual : Stock.externCtor source.ctx T.gen_try_call_rets [.op (.sig sig)] source.input = .ok (value,next) := by
    calc Stock.externCtor source.ctx T.gen_try_call_rets [.op (.sig sig)] source.input =
        Stock.externCtor {result.ctx with tryRegs := source.ctx.tryRegs} T.gen_try_call_rets [.op (.sig sig)] source.input := rfl
      _ = .ok (value,next) := by rw [source.tryRegs,source.index]; exact helper
  exact ⟨ranges,source,selected,base,value,next,build,allocation,slots,actual,gap,
    fun x key available mapped => source_alias_gap run scope dominated source allocation gap available mapped⟩
end Backend.Stock.Proof.TrySourceAvailableGapDraft
