Production lowering currently uses the legacy driver. This enables actual Stock lowering for six structural one-block i32/i64 entry-parameter-return forms (default/System V/fast ABI), with arbitrary function names and run metadata. Other inputs retain legacy lowering. The selector depends only on input syntax; Stock failure or unsupported edge payload retries legacy on the same input.

Kernel proofs cover actual Stock success, its complete compacted output including history, source execution with arbitrary values/memory/oracles/dirty upper bits, and all-input compiler compatibility including allocator effects, errors, settings and artifact metadata. The compiler and four E2E routes use the dispatcher. Existing theorem variants remain; the audit preserves 163 old declaration headers and moves two input-scope definitions verbatim.

A shared proof emitter exercises a real mixed Stock identity/legacy caller executable in both cleanup modes, including default Lean ELF linking, CALL26 relocation and generated Lean proofs. It retains nondefault source/oracle indices and fallback settings. Rust's two-block identity prologues remain legacy until their distinct histories and new consumer route are integrated.

Validation on rebased `b5e9b15f0f42ffec3fd10a64b766d992f0f45b79` (main `820b6ae6`):

- Full FV/FVTest closure: 2,326/2,326 passed; 130 rebuilt, remaining outputs reused through the shared cache.
- Library replay, 10/10 axiom audits (including unwinding), all 35 D0 roots and four partitions of changed public/private/generated constants passed. Compiler roots use only the standard three axioms; fixed native witnesses retain the policy's explicit markings.
- Affected tools, runtime 114/22/4737 with zero failures/disagreements, encoding 1316 identical/zero different, both E2E modes 1154 accepted with every original 1150 identity and ordered stage preserved, both generated mixed-program proofs, and four Stock development tests passed.
- Verified default Lean-linked fv-demo: 21/21 tests and 2/2 binaries. Survey: 53/53 tests and 18/18 binaries. Pinned frontend and current Rust tools checked.


Advances #140. This is the first production class; it does not complete the original family/effect/source/block/whole-driver simulation, Stock-only completeness or final consumer replacement obligations. Coverage will grow through further proved complete classes while retaining legacy fallback and old theorem variants.
