import Lean
import FV.E2E.ValidatedLowering
import FV.E2E.ValidatedFinal
import FV.E2E.ValidatedWorld
import FV.E2E.ValidatedNoninterference
import FV.E2E.ValidatedCleanup
import FV.E2E.CompiledProduction
import FV.E2E.LoweringProvenance
import FV.Backend.Proof.StockD0ActualConsumerWitness
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let targets : Array String := #["FV.E2E.ValidatedLowering","FV.E2E.ValidatedFinal","FV.E2E.ValidatedWorld","FV.E2E.ValidatedNoninterference","FV.E2E.ValidatedCleanup","FV.E2E.CompiledProduction","FV.E2E.LoweringProvenance","FV.Backend.Proof.StockD0ActualConsumerWitness"]
  let mut count : Nat := 0
  for (name, _) in env.constants.toList do
    let some i := env.getModuleIdxFor? name | continue
    unless targets.contains env.header.moduleNames[i]!.toString do continue
    let axioms ← collectAxioms name
    for ax in axioms do
      unless #[``propext, ``Classical.choice, ``Quot.sound].contains ax do
        throwError "disallowed axiom {ax} in {name}"
    count := count + 1
  unless count > 0 do throwError "empty consumer constant audit"
  logInfo m!"CONSUMER_CONSTANTS_STANDARD_ONLY {count}"
