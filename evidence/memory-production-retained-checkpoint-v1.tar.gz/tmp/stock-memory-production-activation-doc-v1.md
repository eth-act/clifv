# Original-source Stock memory production activation

Implementation `3753d98a71709cf940ead8a4ac6ece697bf23fd3`, based on merged #637
(`d5cc12dd`). Publication and merge remain pending retained-route gates.

The default compiler, checker, verified linker and generated-proof consumers
select actual Stock output for an original one-block nontrapping i32 load and
return of that result. The address is an original parameter, the offset is zero,
and entry arguments occupy registers. Route12 preserves0–11 and the complete
previous ParameterCfg pipeline on the original input/settings, including retry
after allocation/layout failure. This is a new optional source class; original
accepted inputs and public theorem/world conditions are preserved.

`Memory.Domain` extends the old pure contract using memory validity supplied by
the original downstream world relation. Original source syntax and actual Stock
construction derive selected load1043, retained records, fresh result/final
aliases, restricted-DFG guarded source steps, complete bodies, ABI entry and
return. Initialized source bytes derive paired read equality. The shared entry
seed makes both executions use one virtual file; the existing value/preparation/
allocation/machine consumers then prove actual paired executions. The prior
ABI-read predicate is unchanged. The emitted-code check admits ABI copies,
loads and returns and derives concrete/value agreement and TLS exclusion.

Positive witnesses execute an actual PC0 load-return function with a nonzero
heap and distinct ABI-entry worlds. Universal correctness uses standard axioms.
Two explicitly annotated fixed witness roots share one native classifier fact;
this fact is not a premise or dependency of universal correctness.

| Current author evidence | Result |
| --- | --- |
| Normal FV/FVTest / tools | 4256 modules /5115 jobs |
| Trust / preserved contracts | 98 audit files;4025 per-file axiom sets; all3994 prior sets,84 prior memory roots and23 modified public headers exact |
| Memory roots / MCP | 101 standard-only roots;2 annotated fixed witness roots; one bundled top-NI review, standard axioms/no warnings |
| Memory integration | 22 commands;8 generated packages;both CLI checker/proof and verified-linker modes;both cleanup settings;exact forced prior-pipeline retry bytes |
| Native memory execution | 12288 candidate calls/8192 initialized unaligned loads;6144 independent Cranelift calls/4096 initialized loads;0 disagreement |
| Actual proof/byte binding | 10 proof/CLI ELF excerpt sets and6 native object function bodies equal final verified ELF bytes |
| Runtime / encoder | 5755/0/0,seven unchanged non-runnable cases /1398 identical,0 different |
| E2E identity/stage parity | both modes retain1159 accepted identities;original1150 and prior1159 ordered successful stages exact |
| Verified examples / actual crate package | both examples/all20 ELFs /93 modules |
| Actual captured comparison | 4543 original source/candidate/reference/full-relocation bindings;900→900 exact;0 gains/losses/changed function bytes |
| Retained routes | running;not yet counted passed |

Current receipts are under `/tmp/stock-memory-production-*`, with independent
native reference evidence under `/tmp/stock-memory-reference-native-v1` and
final fixture byte binding in `/tmp/stock-memory-fixture-byte-binding-v1.json`.
Sources are pushed and unique evidence is archived before cleanup. A first
retained run failed its HEAD-pinning guard when the implementation was committed;
it is preserved and excluded from successful evidence. The restarted queue holds
commit3753 and all source fixed. Earlier native-harness assembler/linker failures
are likewise preserved, superseded by the complete passing run.

No corpus agreement improvement or original #140 completion is claimed. Next
cover the captured two-block/nop load-return source, then broader addressing,
effects/atomics/calls/exceptions, remaining control/rule families and the original
whole-driver/Stock-only/downstream completeness obligations. Fallback preserves
acceptance; it does not prove completeness.
