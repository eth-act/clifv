from pathlib import Path
import concurrent.futures,datetime,json,subprocess,threading,queue,os
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');os.chdir(root);head='3753d98a71709cf940ead8a4ac6ece697bf23fd3'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
for kind in ['parameter','conditional-forward']:
 r=json.loads(Path(f'/tmp/stock-memory-retained-{kind}-gates-v2/receipt.json').read_text());assert r['state']=='passed'
items=queue.Queue()
for kind in ['conditional','forward','linear','scalar-entry','entry','cfg']:items.put(kind)
records=[];lock=threading.Lock();failed=threading.Event();progress=Path('/tmp/stock-memory-validation-queue-v3.json')
def save():progress.write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),head=head,max_parallel=2,cap_per_lane='8G',source_and_head_frozen=True,coverage='Six original real-oracle runtime suites and focused exact-default compatibility matrices; two latest full generated-proof cohorts already pass.',records=records),indent=2)+'\n')
def worker(lane):
 while not failed.is_set():
  try:kind=items.get_nowait()
  except queue.Empty:return
  out=Path(f'/tmp/stock-memory-retained-{kind}-gates-v2');action='resume' if out.exists() else 'run'
  with lock:
   record=dict(kind=kind,lane=lane,state='running',started=datetime.datetime.now(datetime.timezone.utc).isoformat());records.append(record);save();print('START',kind,lane,flush=True)
  with Path(f'/tmp/stock-memory-retained-{kind}-matrix-runner-v3.log').open('w') as log:
   r=subprocess.run(['taskset','-c','0,1' if lane==0 else '2,3','nice','-n','10','python3','scripts/stock-delivery-gates.py',action,f'/tmp/stock-memory-retained-{kind}-manifest-v2.json','--root',str(root),'--out',str(out)],stdout=log,stderr=subprocess.STDOUT)
  with lock:
   record.update(state='passed' if r.returncode==0 else 'failed',returncode=r.returncode,ended=datetime.datetime.now(datetime.timezone.utc).isoformat());save();print('END',kind,record['state'],flush=True)
  items.task_done()
  if r.returncode:failed.set()
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 fs=[pool.submit(worker,lane) for lane in [0,1]]
 for f in fs:f.result()
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head
if failed.is_set():raise SystemExit('Inspect failed matrix; other healthy active validation finished; queued jobs held.')
assert items.empty();print('ALL_RETAINED_CLASS_MATRICES_PASS',flush=True)
