import Crates.StockCfgParameterProduction100CleanupFallbackEntries
import Crates.StockCfgParameterProduction100CleanupFallbackGlobal
import Crates.StockCfgParameterProduction100CleanupStrictEntries
import Crates.StockCfgParameterProduction100CleanupStrictGlobal
import Crates.StockCfgParameterProduction100PlainFallbackEntries
import Crates.StockCfgParameterProduction100PlainFallbackGlobal
import Crates.StockCfgParameterProduction100PlainStrictEntries
import Crates.StockCfgParameterProduction100PlainStrictGlobal
import Crates.StockCfgParameterProduction2CleanupFallbackGlobal
import Crates.StockCfgParameterProduction2PlainFallbackGlobal
import Crates.StockCfgParameterProduction2RetainedCleanupFallbackGlobal
import Crates.StockCfgParameterProduction2RetainedPlainFallbackGlobal
import Crates.StockCfgParameterProduction33CleanupFallbackEntries
import Crates.StockCfgParameterProduction33CleanupFallbackGlobal
import Crates.StockCfgParameterProduction6MixedCleanupFallbackGlobal
import Crates.StockCfgParameterProduction6MixedPlainFallbackGlobal
import Crates.StockCfgParameterProduction7MixedCleanupFallbackGlobal
import Crates.StockCfgParameterProduction7MixedPlainFallbackGlobal
import Crates.CfgParameterProductionCLIcurrentPlain
import Crates.CfgParameterProductionCLIretainedPlain
import Crates.CfgParameterProductionCLIcurrentCleanup
import Crates.CfgParameterProductionCLIretainedCleanup
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let generated := fun (name : Name) =>
    let owner := (privateToUserName? name).getD name
    owner.toString.startsWith "Crates.StockCfgParameterProduction" || owner.toString.startsWith "Crates.CfgParameterProductionCLI"
  let mut count : Nat := 0
  for (name, _) in env.constants.toList do
    unless generated name do continue
    for ax in ← collectAxioms name do
      if #[``propext, ``Classical.choice, ``Quot.sound].contains ax then continue
      unless generated ax && (ax.toString.splitOn "._native.native_decide.ax_").length > 1 do
        throwError "unexpected generated-proof axiom {ax} in {name}"
    count := count + 1
  unless count > 0 do throwError "empty generated-proof audit"
  logInfo m!"STOCK_CFGPARAMETERPRODUCTION_GENERATED_AXIOMS_PASS {count}"
