import Crates.StockCfgConditionalForwardProduction100CleanupFallbackEntries
import Crates.StockCfgConditionalForwardProduction100CleanupFallbackGlobal
import Crates.StockCfgConditionalForwardProduction100CleanupStrictEntries
import Crates.StockCfgConditionalForwardProduction100CleanupStrictGlobal
import Crates.StockCfgConditionalForwardProduction100PlainFallbackEntries
import Crates.StockCfgConditionalForwardProduction100PlainFallbackGlobal
import Crates.StockCfgConditionalForwardProduction100PlainStrictEntries
import Crates.StockCfgConditionalForwardProduction100PlainStrictGlobal
import Crates.StockCfgConditionalForwardProduction2CleanupFallbackGlobal
import Crates.StockCfgConditionalForwardProduction2PlainFallbackGlobal
import Crates.StockCfgConditionalForwardProduction2RetainedCleanupFallbackGlobal
import Crates.StockCfgConditionalForwardProduction2RetainedPlainFallbackGlobal
import Crates.StockCfgConditionalForwardProduction33CleanupFallbackEntries
import Crates.StockCfgConditionalForwardProduction33CleanupFallbackGlobal
import Crates.StockCfgConditionalForwardProduction6MixedCleanupFallbackGlobal
import Crates.StockCfgConditionalForwardProduction6MixedPlainFallbackGlobal
import Crates.StockCfgConditionalForwardProduction7MixedCleanupFallbackGlobal
import Crates.StockCfgConditionalForwardProduction7MixedPlainFallbackGlobal
import Crates.CfgConditionalForwardProductionCLIcurrentPlain
import Crates.CfgConditionalForwardProductionCLIretainedPlain
import Crates.CfgConditionalForwardProductionCLIcurrentCleanup
import Crates.CfgConditionalForwardProductionCLIretainedCleanup
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let generated := fun (name : Name) =>
    let owner := (privateToUserName? name).getD name
    owner.toString.startsWith "Crates.StockCfgConditionalForwardProduction" || owner.toString.startsWith "Crates.CfgConditionalForwardProductionCLI"
  let mut count : Nat := 0
  for (name, _) in env.constants.toList do
    unless generated name do continue
    for ax in ← collectAxioms name do
      if #[``propext, ``Classical.choice, ``Quot.sound].contains ax then continue
      unless generated ax && (ax.toString.splitOn "._native.native_decide.ax_").length > 1 do
        throwError "unexpected generated-proof axiom {ax} in {name}"
    count := count + 1
  unless count > 0 do throwError "empty generated-proof audit"
  logInfo m!"STOCK_CFGCONDITIONALFORWARDPRODUCTION_GENERATED_AXIOMS_PASS {count}"
