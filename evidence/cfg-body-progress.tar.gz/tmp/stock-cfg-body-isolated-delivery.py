import os,pathlib,subprocess,json,hashlib,time,datetime
root=pathlib.Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');os.chdir(root)
draft=pathlib.Path('/tmp/stock-cfg-isolated-packet');meta=json.loads((draft/'metadata.json').read_text())
receipt=pathlib.Path('/tmp/stock-cfg-body-isolated-delivery.json');state={'state':'waiting for safe old-module drain','source_head_before':'cba3a9e098e509a3dfa2923ac61faca1e9e32ef6','gates':[]}
def save():
 state['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();tmp=receipt.with_suffix('.tmp');tmp.write_text(json.dumps(state,indent=2)+'\n');tmp.replace(receipt)
def git(*a):return subprocess.check_output(['git',*a],text=True).strip()
save()
while True:
 p=pathlib.Path('/tmp/stock-cfg-body-dispatch-drain.json')
 if p.exists() and json.loads(p.read_text()).get('state','').startswith('current module terminal;'):break
 time.sleep(3)
assert not pathlib.Path('/proc/398491').exists(),'Original healthy compiler must terminate first'
assert not pathlib.Path('/proc/381728').exists(),'Old dispatcher must terminate first'
assert git('rev-parse','HEAD')==state['source_head_before']
assert not git('status','--porcelain'),'Preserve unexpected unpublished work; do not overwrite'
for name,expected in meta['files'].items():assert hashlib.sha256((draft/name).read_bytes()).hexdigest()==expected,name
state['state']='applying additive proof isolation and source-successor packet';save()
for name in meta['files']:(root/'FV/Backend/Proof'/name).write_bytes((draft/name).read_bytes())
for name,rev in [('StockQuietSourceRecords.lean','ab1abdfc'),('StockLocalSourceTrap.lean','a9922080')]:
 expected=subprocess.check_output(['git','show',rev+':FV/Backend/Proof/'+name]);assert (root/'FV/Backend/Proof'/name).read_bytes()==expected
roots=['Backend.Stock.Proof.stock_lower_scan_dfg_iff','Backend.Stock.Proof.stock_lower_scan_dfg_transfer','Backend.Stock.Proof.source_enterBlock_dfg','Backend.Stock.Proof.stock_lower_source_enterBlock_dfg','Backend.Stock.Proof.SourceSuccessorWitness.actual_source_successor_dfg_witness']
(root/'scripts/audit/stock-cfg-source-edge.lean').write_text('import FV.Backend.Proof.StockSourceEdgeDFGWitness\n\n'+'\n'.join('#print axioms '+r+(' -- witness: native_decide' if 'Witness.' in r else '') for r in roots)+'\n')
state['applied_sha256']={n:hashlib.sha256((root/'FV/Backend/Proof'/n).read_bytes()).hexdigest() for n in meta['files']};state['old_proof_modules_byte_exact']=True;state['state']='running final current full-normal keys';save()
profile=pathlib.Path('/tmp/stock-cfg-isolation-peaks.tsv');profile.write_text('FV.Backend.Proof.StockQuietBlockWitness\t8000\t25\n')
env=os.environ.copy();env.update(json.load(open('/tmp/stock-mixed-div-env.json')));env.update(FV_ROOT=str(root))
commands=[('full-normal',['python3','scripts/lake-serial-build.py','--budget','16G','--max-jobs','2','--max-cap','16G','--profile','scripts/lake-module-peaks.tsv','--profile','.lake/lake-module-peaks.tsv','--profile',str(profile),'--out','/tmp/stock-cfg-body-full-normal-v2','FV','FVTest']),('all-axioms',['scripts/memcap.sh','taskset','-c','0','python3','scripts/axiom-audit.py','--log-dir','/tmp/stock-cfg-body-all-axioms-v2']),('retained-axioms',['scripts/memcap.sh','taskset','-c','0','python3','scripts/axiom-audit.py','--log-dir','/tmp/stock-cfg-body-retained-audit-v2','/tmp/stock-cfg-body-retained-axioms.lean'])]
for name,cmd in commands:
 e=env.copy();e.update(FV_MEMCAP='6G',FV_MEMCAP_UNIT='clifv-stock-cfg-isolated-'+name,FV_MEMCAP_STATS='/tmp/stock-cfg-body-'+name+'-v2.mem')
 output=pathlib.Path('/tmp/stock-cfg-body-'+name+'-v2.log')
 state['active_gate']=name;save()
 with output.open('w') as out:r=subprocess.run(cmd,env=e,stdout=out,stderr=subprocess.STDOUT)
 state['gates'].append({'name':name,'command':cmd,'returncode':r.returncode,'log':str(output),'sha256':hashlib.sha256(output.read_bytes()).hexdigest()});save()
 if r.returncode:state['state']='failed '+name;save();raise SystemExit(r.returncode)
import re
flat=' '.join(pathlib.Path('/tmp/stock-cfg-body-retained-audit-v2/stock-cfg-body-retained-axioms.log').read_text().split());current={r:sorted(a.strip() for a in ax.split(',')) for r,ax in re.findall(r"'(.+?)' depends on axioms: \[([^\]]*)\]",flat)}
for r in re.findall(r"'(.+?)' does not depend on any axioms",flat):current[r]=[]
prior=json.load(open('/tmp/stock-cfg-body-baseline-all-axioms.json'))['axiom_sets'];missing=sorted(set(prior)-set(current));changed={r:{'before':a,'after':current[r]} for r,a in prior.items() if r in current and current[r]!=a}
state['exact_prior_axiom_sets']={'expected':len(prior),'reported':len(current),'missing':missing,'changed':changed};state['state']='passed' if not missing and not changed else 'failed exact prior axiom parity';save();print(state['state'],flush=True)
