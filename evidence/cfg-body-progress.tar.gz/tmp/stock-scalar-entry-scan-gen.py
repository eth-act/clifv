from pathlib import Path
import re
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025/FV/Backend/Proof')
specs=[('StockSelectScanRefines','select'),('StockAddSubScanRefines','addsub'),('StockLogicalScanRefines','logical'),('StockBnotScanRefines','bnot'),('StockMulScanRefines','mul'),('StockShiftScanRefines','shift'),('StockCastCmpScanRefines','extend_of_memory_formats'),('StockCastScanRefines','reduce'),('StockBitScanRefines','unary_bit'),('StockBitScanRefines','rotate'),('StockPopcountScanRefines','popcount'),('StockMinMaxScanRefines','minmax'),('StockCmpScanRefines','cmp'),('StockHighMulScanRefines','highmul'),('StockBmaskScanRefines','bmask')]
out='''import FV.Backend.Proof.StockInheritedMixedDivision
import FV.Backend.Proof.StockMaskBlockRefines

/-! Carry existing original entry values through the already proved scalar
records. Every outside-interval frame comes from its existing execution proof;
no extra source acceptance or emitted-code certificate is assumed. -/
namespace Backend.Stock.Proof.Inherited
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm emitBranch scanBlock

'''
s=(root/'StockSelectScanRefines.lean').read_text();a=s.index('private theorem select_operands');b=s.index('\n/--',a);out+=s[a:b].replace('res_bind_eq_ok','Backend.Proof.Driver.res_bind_eq_ok')+'\n\n'
out+=Path('/tmp/stock-scalar-entry-single-frame.lean').read_text()
for file,kind in specs:
 s=(root/(file+'.lean')).read_text();name='stock_lower_'+kind+'_scan_fall_refines'
 if kind=='extend_of_memory_formats':name='stock_lower_extend_scan_fall_refines_of_memory_formats'
 a=s.index('theorem '+name+' ');end=a+re.search(r'\n  · simpa only \[advance,position\] using post(?:\.2\.2)?\n',s[a:]).end()-1
 old=s[a:end]
 old=old.replace('theorem '+name+' ','private theorem '+kind+'_carry ',1)
 old=old.replace('{bi j : Nat}','{j : Nat}')
 old=re.sub(r'\bbi\b','event.block',old)
 old=old.replace('    {F : BitVec 64 → Prop}', '''    {term : ScanRecord} {body : BlockScan}
    (split : SourceBodySplit f event b term body)
    {needed : Nat → Prop}
    (available : ∀ x,needed x → x ∈ availOf f (availIn f result.ctx) event.block 0)
    {F : BitVec 64 → Prop}''',1)
 old=old.replace('(GuardedScanRel f result event.ctx event.block MR) record := by','(CarryRel f result event.ctx event.block MR needed) record := by',1)
 old=old.replace(':= held\n',':= held.1\n',1)
 # Source wrappers now expose the original frame before the guarded relation forgets it.
 for src in ['MulComplete.record_source','ShiftComplete.record_source','BitBody.unary_source','BitBody.rotate_source','CastComplete.reduce_source','CastComplete.extend_source_of_memory_formats']:
  if src in old:
   old=old.replace(src,src+'_framed')
   if 'extend_source_of_memory_formats' in src:
    old=old.replace("⟨ρ',w',executed,world,post⟩","⟨ρ',w',executed,world,post,kept⟩")
   else:old=old.replace("⟨ρ',execution,unchanged,post⟩","⟨ρ',execution,unchanged,post,kept⟩")
 if kind=='select':old=old.replace('  have postDFG', '  have kept := post.2.1\n  have postDFG',1)
 if kind in ['addsub','logical','bnot']:
  original={'addsub':'ScalarAddSub.stock_lower_addsub_source_by_instruction','logical':'LogicalComplete.record_source_from_step','bnot':'BnotComplete.source_from_step'}[kind]
  framed={'addsub':'frame_12','logical':'frame_19','bnot':'frame_21'}[kind]
  old=old.replace(original,framed).replace('kept,post⟩','kept,post,keptInterval⟩')
  old=old.replace('sourceStep available kept held.2','sourceStep available keptInterval held.2')
 old=old.replace('  have postDFG', '''  have carried := record_frame_carry run scope dominated events split records statement current
    sourceStep available kept held.2
  have postDFG''',1)
 old=old.replace("  refine ⟨ρ',w',executed,func',?_,?_,?_⟩","  refine ⟨ρ',w',executed,?_,carried⟩\n  refine ⟨func',?_,?_,?_⟩",1)
 if kind in ['addsub','logical','bnot']:old=old.replace('sourceStep available kept held.2','sourceStep available keptInterval held.2')
 out+=old+'\n\n'
out+='end Backend.Stock.Proof.Inherited\n'
(root/'StockInheritedScalar.lean').write_text(out)
