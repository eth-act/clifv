import os,json,subprocess
from pathlib import Path
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:2]);os.nice(10)
e=os.environ.copy();e.update(json.load(open('/tmp/stock-mixed-div-env.json')));e.update(FV_ROOT=os.getcwd(),FV_MEMCAP='8G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2')
commands=[['lake','env','lean','--root=/tmp','-c','/tmp/StockCfgLinkDiagnose.c','/tmp/StockCfgLinkDiagnose.lean'],['/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin/cc','-c','-o','/tmp/StockCfgLinkDiagnose.o','/tmp/StockCfgLinkDiagnose.c','-I','/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/include','-fPIC','-fvisibility=hidden','-O3','-DNDEBUG','-DLEAN_EXPORTING'],['/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin/cc','-o','/tmp/StockCfgLinkDiagnose','@/tmp/StockCfgLinkDiagnose.rsp'],['/tmp/StockCfgLinkDiagnose']]
for i,args in enumerate(commands):
 p=Path('/tmp/stock-cfg-production-native-diagnostic-'+str(i)+'.log')
 with p.open('w') as f:r=subprocess.run(['scripts/memcap.sh',*args],env=e,stdout=f,stderr=subprocess.STDOUT)
 print(i,r.returncode,flush=True)
 if r.returncode:print(p.read_text()[-1800:]);raise SystemExit(r.returncode)
