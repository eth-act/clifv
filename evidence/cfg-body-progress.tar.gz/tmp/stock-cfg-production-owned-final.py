import os,json,subprocess,time,datetime,re
from pathlib import Path
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');os.chdir(root)
env=os.environ.copy();env.update(json.load(open('/tmp/stock-mixed-div-env.json')));env.update(FV_ROOT=str(root),FV_MEMCAP='8G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',CARGO_BUILD_JOBS='2')
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:2]);os.nice(10)
original=Path('/proc/669216/stat').read_text().split()[21] if Path('/proc/669216/stat').exists() else None
while original is not None and Path('/proc/669216/stat').exists() and Path('/proc/669216/stat').read_text().split()[21]==original:time.sleep(10)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();records={}
def run(label,args):
 path=Path('/tmp/stock-cfg-production-'+label+'-v2.log');print(datetime.datetime.now(datetime.timezone.utc).isoformat(),label,flush=True)
 with path.open('w') as out:r=subprocess.run(args,env=env,stdout=out,stderr=subprocess.STDOUT)
 records[label]={'returncode':r.returncode,'log':str(path)}
 Path('/tmp/stock-cfg-production-owned-final.json').write_text(json.dumps({'head':head,'records':records},indent=2)+'\n')
 if r.returncode:raise SystemExit(r.returncode)
prior=json.load(open('/tmp/stock-cfg-production-proof-final.json'));assert prior['head']==head and all(v['returncode']==0 for v in prior['records'].values())
assert Path('/tmp/stock-cfg-production-exact-axioms-v2.json').exists()
run('owned',['scripts/memcap.sh','lake','env','lean','/tmp/stock-cfg-production-owned.lean'])
print('OWNED_CURRENT_MODULES_PASS',flush=True)
