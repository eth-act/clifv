import os,json,subprocess,time,hashlib,datetime,re
from pathlib import Path
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');os.chdir(root)
e=os.environ.copy();e.update(json.load(open('/tmp/stock-mixed-div-env.json')));e.update(FV_ROOT=str(root),FV_MEMCAP='8G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2')
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:2]);os.nice(10)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();out=Path('/tmp/stock-cfg-production-trust-v4');out.mkdir(exist_ok=False);records={}
while True:
 p=Path('/tmp/stock-cfg-production-linkfix-v4/receipt.json')
 if p.exists():
  d=json.loads(p.read_text());assert d['head']==head
  if 'normal' in d['records']:assert d['records']['normal']['returncode']==0;break
 time.sleep(5)
def run(label,args):
 log=out/(label+'.log');print(datetime.datetime.now(datetime.timezone.utc).isoformat(),label,flush=True)
 with log.open('w') as f:r=subprocess.run(['scripts/memcap.sh',*args],env=e,stdout=f,stderr=subprocess.STDOUT)
 records[label]={'returncode':r.returncode,'log':str(log),'sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
 (out/'receipt.json').write_text(json.dumps({'head':head,'state':'running' if not r.returncode else 'failed','records':records},indent=2)+'\n')
 if r.returncode:raise SystemExit(r.returncode)
run('all-axioms',['python3','scripts/axiom-audit.py','--log-dir',str(out/'all-axioms')])
for path in sorted(Path('/tmp/stock-cfg-production-owned-v3').glob('*.lean')):run(path.stem,['lake','env','lean',str(path)])
def collect(path):
 result={}
 for p in Path(path).glob('*.log'):
  flat=' '.join(p.read_text().split())
  for name,axes in re.findall(r"'(.+?)' depends on axioms: \[([^\]]*)\]",flat):
   ax=sorted(x.strip() for x in axes.split(',') if x.strip());assert name not in result or result[name]==ax;result[name]=ax
  for name in re.findall(r"'(.+?)' does not depend on any axioms",flat):assert name not in result or not result[name];result[name]=[]
 return result
old=collect('/tmp/stock-cfg-div-carry-all-axioms-v1');new=collect(out/'all-axioms');assert len(old)==3425
missing=sorted(set(old)-set(new));changed={k:[old[k],new[k]] for k in old.keys()&new.keys() if old[k]!=new[k]}
(out/'exact-parity.json').write_text(json.dumps({'head':head,'old_roots':len(old),'current_roots':len(new),'missing':missing,'changed':changed,'axiom_sets':new},indent=2)+'\n');assert not missing and not changed
assert head==subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
(out/'receipt.json').write_text(json.dumps({'head':head,'state':'passed','records':records},indent=2)+'\n');print('CURRENT_TRUST_AND_EXACT_OLD_AXIOMS_PASS',flush=True)
