import os,json,subprocess,time,datetime,hashlib
from pathlib import Path
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');os.chdir(root)
env=os.environ.copy();env.update(json.load(open('/tmp/stock-mixed-div-env.json')));env.update(FV_ROOT=str(root),FV_MEMCAP='8G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',CARGO_BUILD_JOBS='2',FV_CG_CLIF='/home/lee/clifv/.worktrees/driver-proof-resume/target/cg_clif/unwind/librustc_codegen_cranelift.so')
env['PATH']=str(root/'rust/target/release')+':'+env['PATH']
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:2]);os.nice(10)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head=='2de0e7620897bcfd6e364073ce6b71bbdd67172b'
out=Path('/tmp/stock-cfg-production-author-v2');out.mkdir(exist_ok=False);records={}
def run(label,args,extra=None):
 assert head==subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
 path=out/(label+'.log');print(datetime.datetime.now(datetime.timezone.utc).isoformat(),label,flush=True)
 started=time.monotonic();e=env.copy();e.update(extra or {})
 with path.open('w') as f:r=subprocess.run(['scripts/memcap.sh',*args],env=e,stdout=f,stderr=subprocess.STDOUT)
 records[label]={'returncode':r.returncode,'log':str(path),'seconds':time.monotonic()-started,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
 (out/'receipt.json').write_text(json.dumps({'head':head,'state':'running' if not r.returncode else 'failed','records':records},indent=2)+'\n')
 if r.returncode:raise SystemExit(r.returncode)
run('tools',['lake','build','clif-decode'])
for name in ['fv-demo','survey']:
 run('verified-'+name,['bash','examples/compare.sh','examples/'+name,'--lean-link','--verified','--keep-temps'])
run('real-crate-parity',['python3','/tmp/stock-cfg-production-real-crate-parity.py','--json',str(out/'real-crate-report.json'),'--diffs',str(out/'real-crate-diffs'),*[str(root/'examples'/name/'target/fv/plain-leanlink-verified-leanld/tmp') for name in ['fv-demo','survey']]])
run('crate-proofs',['python3','/tmp/stock-cfg-production-crate-validation.py','--out',str(out/'crate-proofs')])
(out/'receipt.json').write_text(json.dumps({'head':head,'state':'passed','records':records},indent=2)+'\n')
print('VERIFIED_EXAMPLES_REAL_CRATE_PARITY_PACKAGE_PASS',flush=True)
