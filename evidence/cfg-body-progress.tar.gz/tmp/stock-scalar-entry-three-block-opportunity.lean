import FV.Clif.Parse
import FV.Backend.Lowering.StockTwoBlock
import FV.Backend.Lowering.StockTwoBlockEntry
open Backend.Stock
private def withoutForwarding (f : Clif.Function) : Bool :=
  match f.blocks with
  | [entry,target] =>
    match entry.term,target.term with
    | .jump bc,.ret _ =>
      bc.block == target.id && entry.id != target.id &&
      entry.body.all Scalar.maskMixedBodyEligible && target.body.all Scalar.maskMixedBodyEligible &&
      f.sig.params.all Scalar.narrowAbiEligible && f.sig.returns.all Scalar.narrowAbiEligible
    | _,_ => false
  | _ => false
private def opportunity (f : Clif.Function) : Bool :=
  match f.blocks with
  | [entry,body,target] =>
    match entry.term,body.term,target.term with
    | .jump first,.jump last,.ret xs =>
      first.block == body.id && last.block == target.id && entry.body.isEmpty && target.body.isEmpty &&
      xs.all (fun x => (target.params.map (·.1)).contains x) &&
      f.blocks.all (fun b => b.body.all Scalar.maskMixedBodyEligible) &&
      f.sig.params.all Scalar.narrowAbiEligible && f.sig.returns.all Scalar.narrowAbiEligible
    | _,_,_ => false
  | _ => false
#eval do
  let paths ← IO.FS.readFile "/tmp/stock-scalar-entry-source-class-paths.txt"
  let mut counts := Array.replicate 5 (0 : Nat)
  let mut names : Array String := #[]
  for path in paths.splitOn "\n" do
    if path.isEmpty then continue
    let text ← IO.FS.readFile path
    for parsed in (Clif.parseFile text).funcs do
      match parsed.func with
      | .error _ => pure ()
      | .ok f =>
        let mask := f.blocks.all (fun b => b.body.all Scalar.maskMixedBodyEligible)
        let flags := #[f.blocks.length == 3,mask && f.blocks.length == 3,
          opportunity f, opportunity f && Backend.Proof.Driver.lowerScopeB f,
          opportunity f && Backend.Proof.Driver.dominatedB f]
        for i in List.range flags.size do
          if flags[i]! then counts := counts.set! i (counts[i]!+1)
        if opportunity f then names := names.push path
  IO.println <| Lean.Json.compress <| Lean.toJson (counts.toList,names.toList)
