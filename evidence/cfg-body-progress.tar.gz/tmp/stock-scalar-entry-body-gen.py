from pathlib import Path
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025/FV/Backend/Proof');p=root/'StockInheritedScalar.lean';s=p.read_text();assert s.endswith('end Backend.Stock.Proof.Inherited\n');s=s.removesuffix('end Backend.Stock.Proof.Inherited\n')
# A constant's existing resolved fresh-write proof supplies the same carry frame.
t=(root/'StockConstantScanRefines.lean').read_text();a=t.index('theorem stock_lower_constant_scan_fall_refines ');b=t.index(' := by',a);header=t[a:b].replace('theorem stock_lower_constant_scan_fall_refines','private theorem constant_carry').replace('{bi j : Nat}','{j : Nat}').replace(' bi',' event.block')
header=header.replace('    {F : BitVec 64 → Prop}', '''    {term : ScanRecord} {body : BlockScan}
    (split : SourceBodySplit f event b term body)
    {needed : Nat → Prop}
    (available : ∀ x,needed x → x ∈ availOf f (availIn f result.ctx) event.block 0)
    {F : BitVec 64 → Prop}''',1).replace('(GuardedScanRel f result event.ctx event.block MR)','(CarryRel f result event.ctx event.block MR needed)')
s+=header+''' := by
  have normal := stock_lower_constant_scan_fall_refines run scope dominated events records block statement current
    source clif results statementResults mapped recorded emitted refines driver stable (env := env) (cp := cp)
  intro s s' sourceStep ρ w held
  obtain ⟨ρ',w',executed,post⟩ := normal s s' sourceStep ρ w held.1
  have defs := constant_record_fresh_defs run scope events records source clif results mapped recorded emitted
  exact ⟨ρ',w',executed,post,record_fresh_carry run scope dominated events split records statement current
    sourceStep.2.2 available defs executed held.2⟩

'''
# Dispatch on the original syntax family, independently of root IDs.
s+='''private theorem scalar_emitted_carry {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    {event : BlockScanEvent} {record : ScanRecord}
    (events : event ∈ result.blockScans.toList) (records : record ∈ event.output.records)
    {b : Clif.Block} {j : Nat} {stm : Clif.Stmt}
    (block : f.blocks[event.block]? = some b) (statement : b.body[j]? = some stm)
    (current : record.inst = blockStart f event.block+j)
    {step : Step} (recorded : record.output.step = some step) (emitted : step.decision = .emitted)
    {info : IInfo} {z a : Nat} (source : event.ctx.insts[record.inst]? = some info)
    (clif : info.clif = some stm.inst) (results : info.results = [z]) (statementResults : stm.results = [z])
    (mapped : event.ctx.valueReg? z = some (.vreg a .int))
    (family : HighMulBody.Family stm.inst)
    (formats : ∀ block ∈ f.blocks,∀ stm ∈ block.body,CastComplete.MemoryFormat stm.inst)
    {term : ScanRecord} {body : BlockScan} (split : SourceBodySplit f event b term body)
    {needed : Nat → Prop}
    (available : ∀ x,needed x → x ∈ availOf f (availIn f result.ctx) event.block 0)
    {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem} (refines : Refines F isem)
    (driver : DriverSem isem) {MR : MemRelT} (stable : MRStable F MR)
    {env : Clif.Env} {cp : Clif.Program} :
    ScanFallRefines (IndexedSourceInst env cp f event.ctx event.block) isem result.final.alias
      (CarryRel f result event.ctx event.block MR needed) record := by
'''
cases=[('addsub','subtract,ty,x,y,shape','subtract'),('select','ty,c,x,y,shape',''),('logical','kind,ty,x,y,shape','kind'),('constant','ty,imm,shape',''),('bnot','ty,x,shape',''),('mul','ty,x,y,shape',''),('shift','kind,ty,x,y,shape','kind'),('extend','op,ty,x,shape',''),('reduce','ty,x,shape',''),('unary_bit','op,ty,x,unary,shape','unary'),('rotate','left,ty,x,y,shape','left'),('popcount','ty,x,shape',''),('minmax','unsigned,maximum,ty,x,y,shape','unsigned maximum'),('cmp','cc,ty,x,y,shape','cc'),('highmul','signed,ty,x,y,shape','signed')]
pattern='⟨'+cases[0][1]+'⟩ | ⟨'+cases[1][1]+'⟩ | ⟨'+cases[2][1]+'⟩'
for i in range(3,len(cases)):
 sep=' | ' if i in [8,10] else ') | '
 if i in [8,10]:pattern+=' | ⟨'+cases[i][1]+'⟩'
 else:pattern='('+pattern+') | ⟨'+cases[i][1]+'⟩'
s+='  rcases family with '+pattern+'\n'
for kind,binders,arg in cases:
 if kind=='extend':
  s+='''  · cases op with
    | uextend =>
      exact extend_of_memory_formats_carry run scope dominated events records block statement current formats false
        source (clif.trans (congrArg some shape)) results statementResults mapped recorded emitted split available refines stable
    | sextend =>
      exact extend_of_memory_formats_carry run scope dominated events records block statement current formats true
        source (clif.trans (congrArg some shape)) results statementResults mapped recorded emitted split available refines stable
'''
 else:
  s+='  · exact '+kind+'_carry run scope dominated events records block statement current '+(arg+' ' if arg else '')+'source\n      (clif.trans (congrArg some shape)) results statementResults mapped recorded emitted split available '+('refines driver stable' if kind=='constant' else 'stable' if kind=='reduce' else 'refines stable')+'\n'
s+='\nend Backend.Stock.Proof.Inherited\n';Path('/tmp/stock-scalar-entry-body-partial.lean').write_text(s)
# Install after the previous targeted build has finished, to preserve its source identity.
