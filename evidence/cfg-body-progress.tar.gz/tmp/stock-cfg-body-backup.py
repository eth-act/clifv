import pathlib,subprocess,json,hashlib,tarfile,datetime
root=pathlib.Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025')
def git(*args,input=None):return subprocess.check_output(['git',*args],cwd=root,input=input).decode().strip()
head=git('rev-parse','HEAD');source_branch=git('branch','--show-current');assert not git('status','--porcelain')
assert git('ls-remote','origin','refs/heads/'+source_branch).split()[0]==head
files=[]
for prefix in ['stock-cfg-body','stock-cfg-jump-code','stock-cfg-jump-data-check','stock-cfg-scan-context','stock-cfg-source-edge-dfg','stock-cfg-source-successor','stock-cfg-original-origin','stock-cfg-jump-body','stock-cfg-jump-seq','stock-cfg-successor-demand','stock-cfg-successor','stock-cfg-jump-demand','stock-cfg-jump-edge-parameters','stock-cfg-branch-mapping','stock-cfg-inherited','stock-cfg-div-carry']:
 for p in pathlib.Path('/tmp').glob(prefix+'*'):
  if p.is_file() and p.suffix in {'.json','.lean','.log','.mem','.md','.py','.patch','.time'}:files.append(p)
  elif p.is_dir():files.extend(x for x in p.rglob('*') if x.is_file())
files.extend([pathlib.Path('/tmp/stock-cfg-next.md'),pathlib.Path('/tmp/stock-cfg-isolation-prepare.py')]);files=sorted(set(files))
archive=pathlib.Path('/tmp/stock-cfg-body-progress.tar.gz');source_files=git('diff','--name-only','70220733ea37c3f4cba6ed8a4f95c119db8f12c8','HEAD').splitlines()
with tarfile.open(archive,'w:gz',compresslevel=3) as tf:
 for p in files:tf.add(p,arcname=str(p).lstrip('/'),recursive=False)
 for name in source_files:tf.add(root/name,arcname='repo/'+name,recursive=False)
blob=git('hash-object','-w',str(archive));evidence=git('mktree',input=f'100644 blob {blob}\tcfg-body-progress.tar.gz\n'.encode());tree=git('mktree',input=f'040000 tree {evidence}\tevidence\n'.encode());saved=json.load(open('/tmp/stock-cfg-body-progress-backup.json'));branch=saved['branch'];parent=git('rev-parse','refs/heads/'+branch);commit=git('commit-tree',tree,'-p',parent,'-m','Preserve625 landing cleanup and next control proof progress');git('update-ref','refs/heads/'+branch,commit,parent);subprocess.run(['git','push','origin',branch],cwd=root,check=True);assert git('ls-remote','origin','refs/heads/'+branch).split()[0]==commit
receipt={'source_head':head,'source_branch':source_branch,'evidence_commit':commit,'branch':branch,'archive_git_path':'evidence/cfg-body-progress.tar.gz','files':len(files)+len(source_files),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'state':'625/626/627/628/629 landed with exact validated/main trees; inherited carry landed; division carry landed with current full author gates and bundled MCP passed; production CFG/full140 still pending','original625_source_validation':'c7e249b1','original625_publication':'81b016f2','625_merge':'70220733ea37c3f4cba6ed8a4f95c119db8f12c8','next_control_metadata':'tmp/stock-cfg-body-next-control.json','next_control_sources':source_files,'full_140_complete':False}
pathlib.Path('/tmp/stock-cfg-body-progress-backup.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
