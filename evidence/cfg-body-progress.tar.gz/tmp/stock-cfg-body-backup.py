import pathlib,subprocess,json,hashlib,tarfile,datetime
root=pathlib.Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025')
files=[]
for prefix in ['stock-cfg-body','stock-cfg-scan-context','stock-cfg-source-edge-dfg','stock-cfg-source-successor']:
 for p in pathlib.Path('/tmp').glob(prefix+'*'):
  if p.is_file() and p.suffix in {'.json','.lean','.log','.mem','.md','.py'}:files.append(p)
for folder in ['stock-cfg-body-full-normal-v1','stock-cfg-body-all-axioms','stock-cfg-body-retained-audit']:
 p=pathlib.Path('/tmp')/folder
 if p.exists():files.extend(x for x in p.rglob('*') if x.is_file())
files=sorted(set(files));archive=pathlib.Path('/tmp/stock-cfg-body-progress.tar.gz')
with tarfile.open(archive,'w:gz',compresslevel=3) as tf:
 for p in files:tf.add(p,arcname=str(p).lstrip('/'),recursive=False)
def git(*args,input=None):return subprocess.check_output(['git',*args],cwd=root,input=input).decode().strip()
head=git('rev-parse','HEAD');blob=git('hash-object','-w',str(archive));evidence=git('mktree',input=f'100644 blob {blob}\tcfg-body-progress.tar.gz\n'.encode());tree=git('mktree',input=f'040000 tree {evidence}\tevidence\n'.encode());now=datetime.datetime.now(datetime.timezone.utc);branch='agent/stock-cfg-body-progress-'+now.strftime('%Y%m%dT%H%M%SZ');commit=git('commit-tree',tree,'-p',head,'-m','Preserve CFG body and source successor progress; validation still running');git('update-ref','refs/heads/'+branch,commit);subprocess.run(['git','push','origin',branch],cwd=root,check=True);remote=git('ls-remote','origin','refs/heads/'+branch).split()[0];assert remote==commit
receipt={'source_head':head,'evidence_commit':commit,'branch':branch,'archive_git_path':'evidence/cfg-body-progress.tar.gz','files':len(files),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'state':'progress only; full-normal and author gates still pending','source_successor_candidate':'compiled with actual entry/two-source-step/successor-binding witness; not yet integrated'}
pathlib.Path('/tmp/stock-cfg-body-progress-backup.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
