import FV.E2E.StockEntryCfgFixtures
import FV.Backend.Lowering.StockTwoBlockEntry
open Backend.Stock
#eval IO.println <| repr <| (E2E.StockEntryCfgNIWitness.scalarFunctions .systemVI32).filterMap fun (f,_) =>
  if TwoBlock.Entry.eligible f then none else some (f.name,f.blocks[0]!.body,f.blocks[1]!.params,f.sig.returns)
