import FV.Backend.Proof.StockMaskBlockWitness

namespace Backend.Stock.Proof
open Backend.Proof Backend.Proof.Driver
set_option autoImplicit false
set_option Elab.async false

/-- Actual scan contexts preserve source consistency across original blocks.
The overwritten terminator placeholder has no source definition. -/
theorem stock_lower_scan_dfg_iff {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f)
    {event : BlockScanEvent} (events : event ∈ result.blockScans.toList) (fr : Clif.Frame) :
    DFGCons event.ctx fr ↔ DFGCons result.ctx fr := by
  obtain ⟨b,term,body,split⟩ := stock_lower_body_scan_split run scope events
  obtain ⟨ranges, params, earlier, suffix, starting, finishing, before, after,
    label, bi, data, core, build, ordered, initial, empty, parts, folded,
    final, prefixRun, nodeRun, suffixRun, node, coreRun, eventEq, stateEq⟩ :=
    stock_lower_blockScanOrigin run events
  have atBlock : event.block = bi := by
    rw [eventEq]
    exact (stock_lowerBlockCore_scanOrigin coreRun).2.2.1
  have block : f.blocks[bi]? = some b := by rw [← atBlock]; exact split.block
  obtain ⟨original,st0,oldBuild,spec,view⟩ := buildCtx_source build
  have range := spec.ranges bi b block
  have rangeValue : ranges[bi]! = (blockStart f bi,blockStart f bi+b.body.length+1) := by
    simp only [getElem!_def,range]
  have placeholder : result.ctx.insts[ranges[bi]!.2-1]? = some ⟨.op .unit,[],[],none⟩ := by
    rw [rangeValue]
    have terminal : blockStart f bi+b.body.length+1-1 = blockStart f bi+b.body.length := by omega
    rw [terminal,view.insts]
    exact spec.facts.term bi b block
  rw [eventEq,(stock_lowerBlockCore_scanOrigin coreRun).2.1]
  change DFGCons (Driver.termCtx result.ctx (ranges[bi]!.2-1) data) fr ↔ DFGCons result.ctx fr
  exact (buildCtx_mappedInv scope build).dfgCons_termCtx_iff placeholder data fr

/-- A source frame can move between the actual predecessor and successor scan
contexts without an additional DFG certificate from the input program. -/
theorem stock_lower_scan_dfg_transfer {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f)
    {first second : BlockScanEvent} (source : first ∈ result.blockScans.toList)
    (target : second ∈ result.blockScans.toList) {fr : Clif.Frame}
    (consistent : DFGCons first.ctx fr) : DFGCons second.ctx fr :=
  (stock_lower_scan_dfg_iff run scope target fr).mpr
    ((stock_lower_scan_dfg_iff run scope source fr).mp consistent)

end Backend.Stock.Proof
