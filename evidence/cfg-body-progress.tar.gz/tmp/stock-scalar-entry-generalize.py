from pathlib import Path
import re
r=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025')
family='''(∃ ty imm,stm.inst = .iconst ty imm) ∨
      (∃ op ty x y,stm.inst = .div op ty x y) ∨ stm.inst = .nop'''
family2='''(∃ ty imm,stm.inst = .iconst ty imm) ∨
      (∃ op ty x y,stm.inst = .div op ty x y) ∨ stm.inst = .nop'''
local='''  have localFamily : ∀ stm ∈ b.body,LocalBody.LocalInst stm.inst := by
    intro stm member
    rcases family stm member with (scalar | ⟨op,ty,x,y,shape⟩) | ⟨ty,x,shape⟩ | shape
    · exact LocalBody.LocalInst.of_pure (HighMulBody.family_pure scalar)
    · rw [shape]; exact True.intro
    · rw [shape]; exact True.intro
    · rw [shape]; exact True.intro
'''
def add(file,oldname,newname,changes,imp=None,localStop=None):
 p=r/('FV/Backend/Proof/'+file+'.lean');s=p.read_text();a=s.index('theorem '+oldname+' ');m=re.search(r'\n(?:theorem |private theorem |end )',s[a+1:]);b=a+1+m.start();doc=s.rfind('\n/--',a,b)
 if doc>a:b=doc
 t=s[a:b].rstrip().replace('theorem '+oldname+' ','theorem '+newname+' ',1)
 t=t.replace(family,'MaskBody.Family stm.inst')
 if localStop:
  a1=t.index('  have localFamily :');b1=t.index(localStop,a1);t=t[:a1]+local+t[b1:]
 for x,y in changes:t=t.replace(x,y)
 end=s.rindex('\nend ');s=s[:end]+'\n\n/-- Broader scalar-entry variant; original interfaces remain available. -/\n'+t+'\n'+s[end:]
 if imp:s='import '+imp+'\n'+s
 p.write_text(s)
add('StockInheritedJumpDefined','division_jump_carry_returns_defined','scalar_jump_carry_returns_defined', [('constant_division_body_carry_refines_local','scalar_body_carry_refines')], 'FV.Backend.Proof.StockInheritedScalar', '  exact local_jump_carry_returns_defined')
add('StockInheritedJumpTrap','division_jump_carry_traps_or_continues_defined','scalar_jump_carry_traps_or_continues_defined',[('constant_division_body_carry_refines_local','scalar_body_carry_refines')],localStop='  have bodies :=')
add('StockTwoBlockReturn','entry_division_return_frame','entry_scalar_return_frame',[('Inherited.division_jump_carry_returns_defined','Inherited.scalar_jump_carry_returns_defined')])
add('StockTwoBlockTrap','entry_division_trap_frame','entry_scalar_trap_frame',[('Inherited.division_jump_carry_traps_or_continues_defined','Inherited.scalar_jump_carry_traps_or_continues_defined')])
add('StockTwoBlockDomain','domain_of_two_block_entry','domain_of_two_block_scalar_entry',[('TwoBlock.entry_division_return_frame','TwoBlock.entry_scalar_return_frame'),('TwoBlock.entry_division_trap_frame','TwoBlock.entry_scalar_trap_frame')])
p=r/'FV/Backend/Lowering/StockTwoBlockEntry.lean';s=p.read_text();a=s.index('/-- CFG source class');s=s[:a]+'''/-- Broader scalar entry selector; the original dividing-entry selector remains. -/
def scalarEntryEligible (stm : Clif.Stmt) : Bool := Scalar.maskMixedBodyEligible stm

'''+s[a:];s=s.replace('entry.body.all entryEligible','entry.body.all scalarEntryEligible');p.write_text(s)
p=r/'FV/Backend/Proof/StockTwoBlockEntryCheck.lean';s=p.read_text();s=s.replace('have entryFamily := fun stm member => entry_family (List.all_eq_true.mp entryBody stm member)','have entryFamily := fun stm member => Scalar.maskMixedBodyEligible_sound\n          (show Scalar.maskMixedBodyEligible stm = true from List.all_eq_true.mp entryBody stm member)');s=s.replace('            simp only [entryEligible,Bool.and_eq_true] at checked\n            exact Scalar.maskMixedBodyEligible_sound checked.1','            exact Scalar.maskMixedBodyEligible_sound checked');s=s.replace('Scalar.domain_of_two_block_entry scope','Scalar.domain_of_two_block_scalar_entry scope');p.write_text(s)
