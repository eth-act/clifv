import FV.Backend.Lowering.StockProduction
import FV.Backend.Lowering.StockPrologue
import FV.Backend.Lowering.StockPrologueAll
import FV.Backend.Lowering.StockScalarAdd
import FV.Backend.Lowering.StockScalarProduction
import FV.Backend.MixedNIProduction
import FV.Backend.Production
import FV.Backend.ProductionWith
import FV.Backend.Proof.IselOutBoundWitness
import FV.Backend.Proof.IselPrgCoverTermT
import FV.Backend.Proof.IselPrgCtorSoundT
import FV.Backend.Proof.IselPrgDriverT
import FV.Backend.Proof.IselPrgHandT
import FV.Backend.Proof.IselPrgTabF64
import FV.Backend.Proof.LowerSimMemTrap
import FV.Backend.Proof.LowerSimUAbi
import FV.Backend.Proof.LowerTotalT
import FV.Backend.Proof.LoweringPipeline
import FV.Backend.Proof.PrepareMemTrap
import FV.Backend.Proof.SretStableX
import FV.Backend.Proof.StockActualAddSubBodyRefines
import FV.Backend.Proof.StockAddSubScanRefines
import FV.Backend.Proof.StockArithmeticBodyRefines
import FV.Backend.Proof.StockArithmeticBodyWitness
import FV.Backend.Proof.StockArithmeticEntryWitness
import FV.Backend.Proof.StockArithmeticReturnWitness
import FV.Backend.Proof.StockArithmeticSourceExecutionWitness
import FV.Backend.Proof.StockArithmeticSourceRefines
import FV.Backend.Proof.StockArithmeticSourceWitness
import FV.Backend.Proof.StockBmaskRhs
import FV.Backend.Proof.StockBmaskSemanticsWitness
import FV.Backend.Proof.StockBmaskSourceWitness
import FV.Backend.Proof.StockBnotDispatch
import FV.Backend.Proof.StockConstantCompleteWitness
import FV.Backend.Proof.StockD0ActualConsumerWitness
import FV.Backend.Proof.StockD0Compiler
import FV.Backend.Proof.StockD0FallbackWitness
import FV.Backend.Proof.StockD0PipelineWitness
import FV.Backend.Proof.StockD0Source
import FV.Backend.Proof.StockDiagnosticChecker
import FV.Backend.Proof.StockEntryLoadsWitness
import FV.Backend.Proof.StockEntrySeedWitness
import FV.Backend.Proof.StockLogicalCheckWitness
import FV.Backend.Proof.StockLogicalDispatch
import FV.Backend.Proof.StockLogicalExtrMatch
import FV.Backend.Proof.StockLogicalExtrMatchReceipt
import FV.Backend.Proof.StockLogicalExtrMatchedValues
import FV.Backend.Proof.StockLogicalExtrRhs
import FV.Backend.Proof.StockLogicalExtrSemantics
import FV.Backend.Proof.StockLogicalExtrValuesWitness
import FV.Backend.Proof.StockLogicalNotRecordWitness
import FV.Backend.Proof.StockLogicalNotrapWitness
import FV.Backend.Proof.StockLogicalReturnWitness
import FV.Backend.Proof.StockLogicalSourceTransfer
import FV.Backend.Proof.StockLogicalSourceWitness
import FV.Backend.Proof.StockMaskBlockWitness
import FV.Backend.Proof.StockMulDispatch
import FV.Backend.Proof.StockNoLoadBranchWitness
import FV.Backend.Proof.StockNoLoadDriver
import FV.Backend.Proof.StockNoLoadDriverWitness
import FV.Backend.Proof.StockNoLoadScan
import FV.Backend.Proof.StockNoLoadSink
import FV.Backend.Proof.StockNoLoadSinkWitness
import FV.Backend.Proof.StockNoLoadSource
import FV.Backend.Proof.StockPopcountNonzeroWitness
import FV.Backend.Proof.StockPopcountZeroWitness
import FV.Backend.Proof.StockPrologueAllChecker
import FV.Backend.Proof.StockPrologueAllClass
import FV.Backend.Proof.StockPrologueAllCode
import FV.Backend.Proof.StockPrologueAllDomain
import FV.Backend.Proof.StockPrologueAllSource
import FV.Backend.Proof.StockPrologueAllWitness
import FV.Backend.Proof.StockPrologueClass
import FV.Backend.Proof.StockPrologueCode
import FV.Backend.Proof.StockPrologueCodeCore
import FV.Backend.Proof.StockPrologueDomain
import FV.Backend.Proof.StockPrologueInput
import FV.Backend.Proof.StockPrologueSelect
import FV.Backend.Proof.StockPrologueSource
import FV.Backend.Proof.StockPureDriverUnsunk
import FV.Backend.Proof.StockPureDriverWitness
import FV.Backend.Proof.StockPureRecordCoverage
import FV.Backend.Proof.StockPureSourceColors
import FV.Backend.Proof.StockPureUnsunk
import FV.Backend.Proof.StockQuietBlockWitness
import FV.Backend.Proof.StockReturnedDefinitionWitness
import FV.Backend.Proof.StockRuleFrame
import FV.Backend.Proof.StockScalarAddChecked
import FV.Backend.Proof.StockScalarAddClass
import FV.Backend.Proof.StockScalarAddCode
import FV.Backend.Proof.StockScalarAddDomain
import FV.Backend.Proof.StockScalarAddScanWitness
import FV.Backend.Proof.StockScalarAddSource
import FV.Backend.Proof.StockScalarAddWitness
import FV.Backend.Proof.StockScalarCheck
import FV.Backend.Proof.StockScalarDivBodyRecords
import FV.Backend.Proof.StockScalarDivBodyRefines
import FV.Backend.Proof.StockScalarDivSourceWitness
import FV.Backend.Proof.StockScalarGeneralDivDomain
import FV.Backend.Proof.StockScalarMixedDivDomain
import FV.Backend.Proof.StockSinkRuleRhs
import FV.Backend.Proof.StockSinkRuleRhsWitness
import FV.Backend.Proof.StockSinkRuleSyntax
import FV.Backend.Proof.StockTermIndex
import FV.Backend.Proof.StockZeroResultScan
import FV.Clif.LinkClifXN
import FV.Clif.MemTrapWitness
import FV.Concurrency
import FV.E2E.ABIReadMaskSteps
import FV.E2E.ABIReadScalar
import FV.E2E.ActualBinCheck
import FV.E2E.ActualBinary
import FV.E2E.ActualChunkCheck
import FV.E2E.ActualCompilerModes
import FV.E2E.ActualPipelineCheck
import FV.E2E.ActualProgramWitness
import FV.E2E.ActualPrologueWitness
import FV.E2E.ActualStackBound
import FV.E2E.CompiledProduction
import FV.E2E.DeadCleanupExecMemFault
import FV.E2E.DeadCleanupExecMemTrap
import FV.E2E.DeadCleanupExecProven
import FV.E2E.DeadCleanupFinal
import FV.E2E.DeadCleanupLegalDirect
import FV.E2E.DeadCleanupOptProven
import FV.E2E.DeadCleanupTrapCallTryWitness
import FV.E2E.DeadCleanupTrapCallWitness
import FV.E2E.DeadCleanupUnwindWitness
import FV.E2E.EhFrameFinal
import FV.E2E.ExecProven
import FV.E2E.Final
import FV.E2E.LeanAlloc
import FV.E2E.LegalDirect
import FV.E2E.LegalOptX
import FV.E2E.LegalProgXWitness
import FV.E2E.LegalUnwindWitness
import FV.E2E.LegalWideCleanup
import FV.E2E.LegalWideWitness
import FV.E2E.LinkArmUProgGoodWitness
import FV.E2E.LinkArmUProgNIWitness
import FV.E2E.LinkArmUProgWitness
import FV.E2E.LinkMemTrap
import FV.E2E.LinkProduction
import FV.E2E.LinkScopeInput
import FV.E2E.LinkScopeInputCleanupT
import FV.E2E.LinkScopeInputT
import FV.E2E.LinkTrapCallWitness
import FV.E2E.LinkUnwind
import FV.E2E.LoweringPipeline
import FV.E2E.LoweringProvenance
import FV.E2E.MemTrapStatement
import FV.E2E.NonVacuityLegalProgram
import FV.E2E.NonVacuityLegalSource
import FV.E2E.OptProven
import FV.E2E.OptUnwindWitness
import FV.E2E.PreparedPipeline
import FV.E2E.ProductionAllBoundaryWitness
import FV.E2E.ProductionBinary
import FV.E2E.ProductionBinaryGood
import FV.E2E.ProductionBoundaryWitness
import FV.E2E.ProductionCheck
import FV.E2E.ProductionChecksWith
import FV.E2E.ProductionExecBytes
import FV.E2E.ProductionExecFrameSim
import FV.E2E.ProductionExecGoodReads
import FV.E2E.ProductionExecGoodRun
import FV.E2E.ProductionExecGot
import FV.E2E.ProductionExecProven
import FV.E2E.ProductionExecRunN
import FV.E2E.ProductionExecStatic
import FV.E2E.ProductionLinkGood
import FV.E2E.ProductionPipeline
import FV.E2E.ProductionPipelineWith
import FV.E2E.ProductionStackBound
import FV.E2E.RegLevelCorrectU
import FV.E2E.RegLevelMemTrap
import FV.E2E.RegLevelUnwind
import FV.E2E.RetypeLegal
import FV.E2E.RetypeLegalWitness
import FV.E2E.ScalarAddBoundaryWitness
import FV.E2E.SemanticCompilerWitness
import FV.E2E.SemanticFallbackWitness
import FV.E2E.SemanticLogicalCompilerWitness
import FV.E2E.SemanticMixedCompilerWitness
import FV.E2E.SemanticNIBoundary
import FV.E2E.SemanticRoutesWitness
import FV.E2E.SretReturnCleanup
import FV.E2E.SretReturnLegalCleanupWitness
import FV.E2E.SretReturnLegalWitness
import FV.E2E.SretReturnOptWitness
import FV.E2E.SretReturnUnwind
import FV.E2E.SretReturnUnwindWitness
import FV.E2E.SretReturnWitness
import FV.E2E.SretReturnWitnessT
import FV.E2E.StockArithmeticArtifactWitness
import FV.E2E.StockBitWitness
import FV.E2E.StockCastWitness
import FV.E2E.StockCmpWitness
import FV.E2E.StockDivSourceWitness
import FV.E2E.StockDivWitness
import FV.E2E.StockGeneralDivWitness
import FV.E2E.StockHighMulWitness
import FV.E2E.StockLogicalExtrCanonicalWitness
import FV.E2E.StockLogicalExtrMatchWitness
import FV.E2E.StockLogicalExtrRootWitness
import FV.E2E.StockLogicalExtrWitness
import FV.E2E.StockLogicalWitness
import FV.E2E.StockLogicalWorldX
import FV.E2E.StockMaskWitness
import FV.E2E.StockMinMaxWitness
import FV.E2E.StockMixedDivWitness
import FV.E2E.StockMixedWitness
import FV.E2E.StockMulWitness
import FV.E2E.StockNarrowWitness
import FV.E2E.StockNotWitness
import FV.E2E.StockPopcountWitness
import FV.E2E.StockReturnedDivWitness
import FV.E2E.StockScalarWitness
import FV.E2E.StockScalarWorldX
import FV.E2E.StockShiftWitness
import FV.E2E.TotalInput
import FV.E2E.TypedRulesProg
import FV.E2E.ValidatedWitness
import FV.E2E.VerifiableT
import FV.E2E.WorldMemTrap
import FV.E2E.WorldTrapCall
import FV.E2E.WorldUnwindNIWitness
import FV.E2E.WorldUnwindWitness
import FV.Front.ExeContract
import FV.Front.RawExeBaselineNB
import FV.Front.RawExeContract
import FV.Front.RawExeMemFault
import FV.Front.RawExeMemTrap
import FV.Front.RawExeNB
import FV.Front.RawExeTrap
import FV.Front.RawExeTrapContract
import FV.Front.RawExeTrapNB
import FV.Front.RawExeTrapT
import FV.Front.RawExeTrapTNB
import FV.Front.RawExeUnwindRen
import FV.Front.RawExeUnwindSrc
import FV.Front.RawExeUnwindSrcNBWitness
import FV.Front.RawExeUnwindSrcWitness
import FV.Front.RenameRunXWitness
import FV.Link.ActualCompilerImage
import FV.Link.ActualImage
import FV.Link.ActualImageProof
import FV.Link.DeadCleanupCompileT
import FV.Link.DeadCleanupCompileT3
import FV.Link.DeadCleanupExe
import FV.Link.DeadCleanupExeAbiWitness
import FV.Link.DeadCleanupExeLd
import FV.Link.DeadCleanupExeMemFault
import FV.Link.DeadCleanupExeMemFaultWitness
import FV.Link.DeadCleanupExeMemTrap
import FV.Link.DeadCleanupExeMemTrapWitness
import FV.Link.DeadCleanupExeSourceContract
import FV.Link.DeadCleanupExeT
import FV.Link.DeadCleanupExeTotal
import FV.Link.DeadCleanupExeTrapContract
import FV.Link.DeadCleanupExeTrapNBWitness
import FV.Link.DeadCleanupExeTrapPeakNBWitness
import FV.Link.DeadCleanupExeTrapTNBWitness
import FV.Link.DeadCleanupExeTrapTWitness
import FV.Link.DeadCleanupExeTrapWitness
import FV.Link.DeadCleanupOptExeSourceNB
import FV.Link.EhCheckWitness
import FV.Link.Exe
import FV.Link.ExeInputReach
import FV.Link.ExeInputReachCleanupIn
import FV.Link.ExeLd
import FV.Link.ExeLdInWitness
import FV.Link.ExeSource
import FV.Link.ExeT
import FV.Link.ExeTls
import FV.Link.ExeTotal
import FV.Link.ExeULdInWitness
import FV.Link.ExeUnwindExecGoodWitness
import FV.Link.ExeUnwindExecWitness
import FV.Link.ExeUnwindWitness
import FV.Link.Ld.LayoutProof
import FV.Link.Ld.LayoutTotal
import FV.Link.Ld.RelocTotal
import FV.Link.NonVacuityExeSource
import FV.Link.OptExeSourceNB
import FV.Link.OptExeUnwindWitness
import FV.Link.ProductionCompatibility
import FV.Link.ProductionCompile
import FV.Link.ProductionCompileWith
import FV.Link.ProductionExe
import FV.Link.ProductionExeSource
import FV.Link.ProductionExeSourceWith
import FV.Link.ProductionExeWith
import FV.Link.ProductionImage
import FV.Link.ProductionImageProof
import FV.Link.ProductionImageWith
import FV.Link.ProductionImageWithProof
import FV.Link.ReachCheckWitness
import FV.Link.TailExeLd
import FV.Link.UnwCheckInWitness
import FV.Link.UnwCondInWitness
import FV.Link.UnwFnsCompleteWitness
import FV.Link.UnwOutIn
import FV.Link.UnwSavedInWitness
import FV.Link.UnwTryInWitness
import FV.Opt.Proof.LegalPre
import FV.Opt.Proof.RuleAll
import FVTest.Backend.FloatProgT
import FVTest.Concurrency.Litmus
import FVTest.Concurrency.LitmusFull
import FVTest.E2E.FloatCleanupTotalT
import FVTest.E2E.FloatScopeT3
import FVTest.E2E.FloatTotalT
import FVTest.E2E.FloatVerifiedW
import FVTest.Link.FloatCompileExeT
import FVTest.Link.FloatCompileExeT3
import FVTest.Link.FloatExeT

#print axioms Backend.Stock.Proof.PureHelper.projects
#print axioms Backend.Stock.Proof.PureHelper.preserves
#print axioms Backend.Stock.Proof.PureHelper.replays
#print axioms Backend.Stock.Proof.ScalarMask.stock_mask_child
#print axioms Backend.Stock.Proof.ScalarMask.stock_mask_child_witness
#print axioms Backend.Stock.Proof.ScalarMask.stock_mask_child_replay
#print axioms Backend.Stock.Proof.ScalarMask.stock_mask_child_replay_witness
#print axioms Backend.Stock.Proof.ScalarMask.stock_csetm_helper
#print axioms Backend.Stock.Proof.ScalarMask.stock_csetm_helper_observed
#print axioms Backend.Stock.Proof.ScalarMask.stock_csetm_helper_witness
#print axioms Backend.Stock.Proof.ScalarMask.stock_bmask_wide
#print axioms Backend.Stock.Proof.ScalarMask.stock_bmask_wide_observed
#print axioms Backend.Stock.Proof.ScalarMask.stock_bmask_wide_witness
#print axioms Backend.Stock.Proof.ScalarMask.stock_bmask_narrow
#print axioms Backend.Stock.Proof.ScalarMask.stock_bmask_narrow_observed
#print axioms Backend.Stock.Proof.ScalarMask.stock_bmask_narrow_witness
#print axioms Backend.Stock.Proof.ScalarMask.stock_bmask_run
#print axioms Backend.Stock.Proof.ScalarMask.stock_bmask_rhs
#print axioms Backend.Stock.Proof.ScalarMask.stock_bmask_rhs_observed
#print axioms Backend.Stock.Proof.ScalarMask.stock_bmask_rhs_witness
#print axioms Backend.Stock.Proof.ScalarMask.stock_bmask_source_data
#print axioms Backend.Stock.Proof.ScalarMask.stock_bmask_match
#print axioms Backend.Stock.Proof.ScalarMask.stock_bmask_match_observed
#print axioms Backend.Stock.Proof.ScalarMask.stock_selected_bmask_rule
#print axioms Backend.Stock.Proof.ScalarMask.stock_bmask_selected
#print axioms Backend.Stock.Proof.ScalarMask.stock_bmask_original_selection_witness
#print axioms Backend.Stock.Proof.ScalarMask.stock_bmask_defs
#print axioms Backend.Stock.Proof.ScalarMask.stock_bmask_resolved
#print axioms Backend.Stock.Proof.ScalarMask.stock_bmask_resolved_witness
#print axioms Backend.Stock.Proof.ScalarMask.stock_lower_bmask_record
#print axioms Backend.Stock.Proof.ScalarMask.stock_lower_bmask_record_witness
#print axioms Backend.Stock.Proof.ScalarMask.stock_lower_bmask_available_values
#print axioms Backend.Stock.Proof.ScalarMask.stock_lower_bmask_available_source
#print axioms Backend.Stock.Proof.ScalarMask.stock_lower_bmask_source_values_witness
#print axioms Backend.Stock.Proof.QuietSourceColors.sourceMetadata_quiet_single_block
#print axioms Backend.Stock.Proof.QuietSourceColors.buildCtx_quiet_single_block
#print axioms Backend.Stock.Proof.QuietSourceColors.stock_lower_quiet_single_block_unsunk
#print axioms Backend.Stock.Proof.QuietSourceColors.actual_quiet_source_record
#print axioms Backend.Stock.Proof.QuietSourceColors.highmul_source_record_fall_refines
#print axioms Backend.Stock.Proof.QuietSourceColors.sourceMetadata_zero_of_separate
#print axioms Backend.Stock.Proof.QuietSourceColors.buildCtx_quiet_block
#print axioms Backend.Stock.Proof.QuietSourceColors.stock_lower_quiet_block_unsunk
#print axioms Backend.Stock.Proof.QuietSourceColors.actual_quiet_source_record_at_block
#print axioms Backend.Stock.Proof.QuietBlockWitness.actual_block_record_witness -- witness: native_decide
#print axioms E2E.ABIReadOnly.refines
#print axioms E2E.ABIReadOnly.memory
#print axioms E2E.ABIReadOnly.driver
#print axioms E2E.ABIReadOnly.instruction_cases
#print axioms E2E.ABIReadOnly.registerRead_argument
#print axioms E2E.ABIReadOnly.stackRead_argument
#print axioms E2E.ABIReadOnly.checked_instruction
#print axioms E2E.ABIReadOnly.step_world
#print axioms E2E.ABIReadOnly.step_transport
#print axioms E2E.ABIReadOnly.star_transport
#print axioms E2E.ABIReadOnly.return_transport
#print axioms E2E.ABIReadOnly.step_control
#print axioms E2E.ABIReadOnly.step_realize
#print axioms E2E.ABIReadOnly.star_realize
#print axioms E2E.ABIReadOnly.return_realize
#print axioms E2E.ABIReadOnly.machine_return
#print axioms E2E.ABIReadOnly.arguments_transport
#print axioms E2E.backend_correct_world_niX_stock_arithmetic
#print axioms E2E.CompiledSemanticNI.toSemantic
#print axioms E2E.CompiledSemanticNI.of_checks
#print axioms E2E.backend_correct_world_niX_semantic
#print axioms E2E.CompiledSemanticNI.entryRegs
#print axioms E2E.CompiledSemanticNI.noTls
#print axioms E2E.hasTls_of_vcode_semantic
#print axioms E2E.stackArgsAvoid_frameW_semantic
#print axioms E2E.backend_correct_world_semantic
#print axioms E2E.backend_correct_world_ni_semantic
#print axioms E2E.backend_correct_program_semantic
#print axioms E2E.LinkCheck.semanticPreparedResults_sound
#print axioms E2E.SemanticStackBound.okB_sound
#print axioms E2E.SemanticBinary.binary_correct
#print axioms Link.SemanticCompilerWith.attempt_correct
#print axioms Link.SemanticCompilerWith.attempt_correct_source
#print axioms Link.SemanticCompilerWith.attempt_correct_source_peak
#print axioms E2E.StockArithmeticNIWitness.source_entry
#print axioms E2E.StockArithmeticNIWitness.source_returns
#print axioms E2E.StockArithmeticNIWitness.checks_true -- witness: native_decide
#print axioms E2E.StockArithmeticNIWitness.compiled_exists -- witness: native_decide
#print axioms E2E.SemanticCompilerWitness.checks_true -- witness: native_decide
#print axioms E2E.SemanticCompilerWitness.compiler_success -- witness: native_decide
#print axioms Backend.Stock.Proof.BitBody.family_pure
#print axioms Backend.Stock.Proof.BitBody.family_quiet
#print axioms Backend.Stock.Proof.BitBody.family_single
#print axioms Backend.Stock.Proof.BitBody.family_formats
#print axioms Backend.Stock.Proof.BitBody.bit_inst_notrap
#print axioms Backend.Stock.Proof.BitBody.bit_source_notrap
#print axioms Backend.Stock.Proof.BitBody.unary_source
#print axioms Backend.Stock.Proof.BitBody.rotate_source
#print axioms Backend.Stock.Proof.stock_lower_unary_bit_scan_fall_refines
#print axioms Backend.Stock.Proof.stock_lower_rotate_scan_fall_refines
#print axioms Backend.Stock.Proof.stock_lower_mixed_bit_record_fall_refines
#print axioms Backend.Stock.Proof.stock_lower_mixed_bit_body_fall_refines
#print axioms Backend.Stock.Proof.BitBody.emitted_record_family
#print axioms Backend.Stock.Proof.BitBody.actual_bit_families
#print axioms Backend.Stock.Proof.BitBody.actual_bit_body_refines
#print axioms Backend.Stock.Proof.BitBody.actual_bit_entry_return_refines_frame
#print axioms Backend.Stock.Scalar.domain_of_bit
#print axioms E2E.BitRead.step_frame
#print axioms E2E.BitRead.no_mem
#print axioms E2E.BitRead.spec_eq
#print axioms E2E.StockBitNIWitness.checks_true -- witness: native_decide
#print axioms E2E.StockBitNIWitness.compiled_exists -- witness: native_decide
#print axioms E2E.StockBitNIWitness.source_entry
#print axioms E2E.StockBitNIWitness.source_returns
#print axioms E2E.StockBitNIWitness.source_checks_true -- witness: native_decide
#print axioms E2E.StockBitNIWitness.classifier_accepts -- witness: native_decide
#print axioms E2E.StockBitNIWitness.selected_roots_present -- witness: native_decide
#print axioms E2E.StockBitNIWitness.compiled_semantic_exists -- witness: native_decide
#print axioms E2E.StockBitNIWitness.source_family
#print axioms Backend.Stock.Proof.CastComplete.stock_lower_cast_selected_rule_of_formats
#print axioms Backend.Stock.Proof.CastComplete.extend_source_of_formats
#print axioms Backend.Stock.Proof.stock_lower_extend_scan_fall_refines_of_formats
#print axioms Backend.Stock.Proof.stock_lower_mixed_cast_record_fall_refines_of_formats
#print axioms Backend.Stock.Scalar.bitBodyEligible_sound
#print axioms Backend.Stock.Scalar.sourceOk_sound
#print axioms Backend.Stock.Scalar.check_sound
#print axioms E2E.StockCastNIWitness.source_family
#print axioms Backend.Stock.Proof.CastComplete.opcode_inventory
#print axioms Backend.Stock.Proof.CastComplete.stock_lower_cast_selected_rule
#print axioms Backend.Stock.Proof.CastComplete.stock_reduce_selected_rule
#print axioms Backend.Stock.Proof.CastBody.family_pure
#print axioms Backend.Stock.Proof.CastBody.family_quiet
#print axioms Backend.Stock.Proof.CastBody.family_single
#print axioms Backend.Stock.Proof.CastBody.family_formats
#print axioms Backend.Stock.Proof.CastComplete.extend_source
#print axioms Backend.Stock.Proof.CastComplete.reduce_source
#print axioms Backend.Stock.Proof.stock_lower_extend_scan_fall_refines
#print axioms Backend.Stock.Proof.stock_lower_reduce_scan_fall_refines
#print axioms Backend.Stock.Proof.stock_lower_mixed_cast_record_fall_refines
#print axioms Backend.Stock.Proof.stock_lower_mixed_cast_body_fall_refines
#print axioms Backend.Stock.Proof.CastBody.emitted_record_family
#print axioms Backend.Stock.Proof.CastBody.actual_cast_families
#print axioms Backend.Stock.Proof.CastBody.actual_cast_body_refines
#print axioms Backend.Stock.Proof.CastBody.cast_inst_notrap
#print axioms Backend.Stock.Proof.CastBody.cast_source_notrap
#print axioms Backend.Stock.Proof.CastBody.actual_cast_entry_return_refines_frame
#print axioms Backend.Stock.Scalar.domain_of_cast
#print axioms Backend.Stock.Proof.stock_lower_source_statement_family
#print axioms E2E.CastRead.step_frame
#print axioms E2E.CastRead.no_mem
#print axioms E2E.CastRead.spec_eq
#print axioms E2E.StockCastNIWitness.checks_true -- witness: native_decide
#print axioms E2E.StockCastNIWitness.compiled_exists -- witness: native_decide
#print axioms E2E.StockCastNIWitness.source_entry
#print axioms E2E.StockCastNIWitness.source_returns
#print axioms E2E.StockCastNIWitness.source_checks_true -- witness: native_decide
#print axioms E2E.StockCastNIWitness.classifier_accepts -- witness: native_decide
#print axioms E2E.StockCastNIWitness.selected_roots_present -- witness: native_decide
#print axioms E2E.StockCastNIWitness.compiled_semantic_exists -- witness: native_decide
#print axioms Backend.Stock.Proof.stock_lower_mixed_shift_record_fall_refines
#print axioms Backend.Stock.Proof.ShiftBody.emitted_record_family
#print axioms Backend.Stock.Scalar.castBodyEligible_sound
#print axioms E2E.StockShiftNIWitness.source_family
#print axioms Backend.Stock.Proof.CmpBody.family_pure
#print axioms Backend.Stock.Proof.CmpBody.family_quiet
#print axioms Backend.Stock.Proof.CmpBody.family_single
#print axioms Backend.Stock.Proof.CmpBody.family_formats
#print axioms Backend.Stock.Proof.CmpBody.cmp_inst_notrap
#print axioms Backend.Stock.Proof.CmpBody.cmp_source_notrap
#print axioms Backend.Stock.Proof.stock_lower_cmp_scan_fall_refines
#print axioms Backend.Stock.Proof.stock_lower_mixed_cmp_record_fall_refines
#print axioms Backend.Stock.Proof.stock_lower_mixed_cmp_body_fall_refines
#print axioms Backend.Stock.Proof.CmpBody.emitted_record_family
#print axioms Backend.Stock.Proof.CmpBody.actual_cmp_families
#print axioms Backend.Stock.Proof.CmpBody.actual_cmp_body_refines
#print axioms Backend.Stock.Proof.CmpBody.actual_cmp_entry_return_refines_frame
#print axioms Backend.Stock.Scalar.domain_of_cmp
#print axioms E2E.BooleanRead.no_mem
#print axioms E2E.BooleanRead.spec_eq
#print axioms E2E.BooleanRead.step_frame
#print axioms E2E.StockCmpNIWitness.checks_true -- witness: native_decide
#print axioms E2E.StockCmpNIWitness.compiled_exists -- witness: native_decide
#print axioms E2E.StockCmpNIWitness.source_entry
#print axioms E2E.StockCmpNIWitness.source_returns
#print axioms E2E.StockCmpNIWitness.source_checks_true -- witness: native_decide
#print axioms E2E.StockCmpNIWitness.classifier_accepts -- witness: native_decide
#print axioms E2E.StockCmpNIWitness.selected_roots_present -- witness: native_decide
#print axioms E2E.StockCmpNIWitness.compiled_semantic_exists -- witness: native_decide
#print axioms E2E.StockCmpNIWitness.source_family
#print axioms Backend.Stock.Scalar.cmpBodyEligible_sound
#print axioms Backend.Stock.Proof.ScalarCmp.stock_lower_cmp_actual_source_values
#print axioms Backend.Stock.Proof.ScalarCmp.stock_lower_cmp_nonconstant_source_operands
#print axioms Backend.Stock.Proof.stock_lower_available_getAs_type
#print axioms Backend.Stock.Proof.ScalarCmp.stock_cmp_cset_suffix_normalized
#print axioms Backend.Stock.Proof.ScalarCmp.stock_cmp_cset_suffix_extend
#print axioms Backend.Stock.Proof.ScalarCmp.stock_cast_cmp_match
#print axioms Backend.Stock.Proof.ScalarCmp.stock_cast_cmp_match_observed
#print axioms Backend.Stock.Proof.ScalarCmp.stock_cast_cmp_source_operands
#print axioms Backend.Stock.Proof.ScalarCmp.stock_cast_cmp_source_data
#print axioms Backend.Stock.Proof.ScalarCmp.stock_cast_cmp_selected_definition
#print axioms Backend.Stock.Proof.ScalarCmp.stock_cast_cmp_rhs_source_values
#print axioms Backend.Stock.Proof.ScalarCmp.stock_cast_cmp_rhs_growth
#print axioms Backend.Stock.Proof.ScalarCmp.stock_lower_cast_cmp_source_values
#print axioms Backend.Stock.Proof.CastComplete.stock_lower_cast_selected_rule_of_memory_formats
#print axioms Backend.Stock.Proof.CastComplete.extend_source_of_memory_formats
#print axioms Backend.Stock.Proof.stock_lower_extend_scan_fall_refines_of_memory_formats
#print axioms Backend.Stock.Proof.stock_lower_mixed_minmax_record_fall_refines_of_memory_formats
#print axioms Backend.Stock.Proof.stock_lower_source_result_definition
#print axioms Backend.Stock.Proof.stock_lower_return_demand_unsunk
#print axioms Backend.Stock.Proof.stock_mandatory_unsunk_emitted
#print axioms Backend.Stock.Proof.stock_lower_single_div_return_emitted
#print axioms Backend.Stock.Proof.LocalBody.actual_local_source_step
#print axioms Backend.Stock.Proof.LocalBody.actual_local_source_execution_frame
#print axioms Backend.Stock.Proof.PureBody.actual_local_return_refines_at
#print axioms Backend.Stock.Proof.PureBody.actual_local_entry_return_refines_frame
#print axioms Backend.Stock.Proof.PureBody.actual_pure_return_refines_at
#print axioms Backend.Stock.Proof.PureBody.actual_pure_entry_return_refines_frame
#print axioms Backend.Stock.Proof.ScalarDiv.stock_lower_div_source_by_instruction
#print axioms Backend.Stock.Proof.ScalarDiv.stock_lower_div_source_trap
#print axioms Backend.Stock.Proof.stock_lower_div_scan_fall_refines
#print axioms Backend.Stock.Proof.DivBody.actual_single_div_record
#print axioms Backend.Stock.Proof.DivBody.actual_single_div_body_refines
#print axioms Backend.Stock.Proof.DivBody.single_div_source_trap
#print axioms Backend.Stock.Proof.DivBody.trapRun_at
#print axioms Backend.Stock.Proof.DivBody.actual_single_div_entry_return_refines_frame
#print axioms Backend.Stock.Proof.DivBody.actual_single_div_entry_trap_refines_frame
#print axioms Backend.Stock.Scalar.domain_of_single_div
#print axioms Backend.Stock.Scalar.singleDivEligible_sound
#print axioms E2E.DivBoundary.checked_step_frame
#print axioms E2E.DivBoundary.checked_step_transport
#print axioms E2E.DivBoundary.return_transport
#print axioms E2E.DivBoundary.machine_return
#print axioms E2E.DivBoundary.zero_guard_halts
#print axioms E2E.DivBoundary.nonzero_guard_continues
#print axioms E2E.backend_correct_world_niX_stock_div
#print axioms E2E.CompiledSemanticNI.noTlsDiv
#print axioms E2E.StockDivNIWitness.checks_true -- witness: native_decide
#print axioms E2E.StockDivNIWitness.compiled_exists -- witness: native_decide
#print axioms E2E.StockDivNIWitness.source_entry
#print axioms E2E.StockDivNIWitness.source_runs
#print axioms E2E.StockDivNIWitness.zero_traps
#print axioms E2E.StockDivNIWitness.signed_minimum_overflow
#print axioms E2E.StockDivNIWitness.signed_minimum_remainder
#print axioms Link.LinkSpec.reachOkMap_eq
#print axioms Link.LinkSpec.reachOkMap_empty
#print axioms Link.LinkSpec.reachOkMap_duplicates -- witness: native_decide
#print axioms Link.DeadCleanup.placedPar_eq
#print axioms Backend.Stock.Scalar.divisionBodyEligible_sound
#print axioms Backend.Stock.Scalar.generalDivBodyEligible_sound
#print axioms Backend.Stock.Scalar.domain_of_scalar_div
#print axioms E2E.StockGeneralDivNIWitness.outcomeAgrees_sound
#print axioms E2E.StockGeneralDivNIWitness.checks_true -- witness: native_decide
#print axioms E2E.StockGeneralDivNIWitness.source_cases -- witness: native_decide
#print axioms E2E.StockGeneralDivNIWitness.compiled_exists -- witness: native_decide
#print axioms E2E.StockGeneralDivNIWitness.source_entry
#print axioms Backend.Stock.Proof.HighMulBody.family_pure
#print axioms Backend.Stock.Proof.HighMulBody.family_quiet
#print axioms Backend.Stock.Proof.HighMulBody.family_single
#print axioms Backend.Stock.Proof.HighMulBody.family_formats
#print axioms Backend.Stock.Proof.HighMulBody.highmul_inst_notrap
#print axioms Backend.Stock.Proof.HighMulBody.highmul_source_notrap
#print axioms Backend.Stock.Proof.stock_lower_highmul_scan_fall_refines
#print axioms Backend.Stock.Proof.stock_lower_mixed_highmul_record_fall_refines
#print axioms Backend.Stock.Proof.stock_lower_mixed_highmul_body_fall_refines
#print axioms Backend.Stock.Proof.HighMulBody.emitted_record_family
#print axioms Backend.Stock.Proof.HighMulBody.actual_highmul_families
#print axioms Backend.Stock.Proof.HighMulBody.actual_highmul_body_refines
#print axioms Backend.Stock.Proof.HighMulBody.actual_highmul_entry_return_refines_frame
#print axioms Backend.Stock.Scalar.domain_of_highmul
#print axioms E2E.HighMulRead.no_mem
#print axioms E2E.HighMulRead.spec_eq
#print axioms E2E.HighMulRead.step_frame
#print axioms E2E.StockHighMulNIWitness.checks_true -- witness: native_decide
#print axioms E2E.StockHighMulNIWitness.compiled_exists -- witness: native_decide
#print axioms E2E.StockHighMulNIWitness.source_entry
#print axioms E2E.StockHighMulNIWitness.source_returns
#print axioms E2E.StockHighMulNIWitness.source_checks_true -- witness: native_decide
#print axioms E2E.StockHighMulNIWitness.classifier_accepts -- witness: native_decide
#print axioms E2E.StockHighMulNIWitness.selected_roots_present -- witness: native_decide
#print axioms E2E.StockHighMulNIWitness.compiled_semantic_exists -- witness: native_decide
#print axioms E2E.StockHighMulNIWitness.source_family
#print axioms Backend.Stock.Scalar.highmulBodyEligible_sound
#print axioms Backend.Stock.Proof.ScalarHighMul.stock_lower_highmul_source_by_instruction
#print axioms E2E.backend_correct_worldX_stock_logical
#print axioms E2E.backend_correct_world_niX_stock_logical
#print axioms E2E.StockLogicalNIWitness.checks_true -- witness: native_decide
#print axioms E2E.StockLogicalNIWitness.source_checks_true -- witness: native_decide
#print axioms E2E.StockLogicalNIWitness.compiled_exists -- witness: native_decide
#print axioms E2E.StockLogicalNIWitness.source_entry
#print axioms E2E.StockLogicalNIWitness.source_returns
#print axioms E2E.StockLogicalNIWitness.classifier_accepts -- witness: native_decide
#print axioms E2E.StockLogicalNIWitness.compiled_semantic_exists -- witness: native_decide
#print axioms E2E.SemanticLogicalCompilerWitness.checks_true -- witness: native_decide
#print axioms E2E.SemanticLogicalCompilerWitness.compiler_success -- witness: native_decide
#print axioms E2E.SemanticRoutesWitness.checks_true -- witness: native_decide
#print axioms Link.SemanticCompilerWith.compileWithRoutes_accepts_tail
#print axioms Link.SemanticCompilerWith.compileWithRoutes_accepts_legacy
#print axioms Link.SemanticCompilerWith.compileWithRoutes_spec
#print axioms Backend.Stock.Proof.LogicalSelected.logical_register_source_dominated
#print axioms Backend.Stock.Logical.classifier_accepts
#print axioms Backend.Stock.Proof.MinMaxBody.family_pure
#print axioms Backend.Stock.Proof.MinMaxBody.family_quiet
#print axioms Backend.Stock.Proof.MinMaxBody.family_single
#print axioms Backend.Stock.Proof.MinMaxBody.family_formats
#print axioms Backend.Stock.Proof.MinMaxBody.minmax_inst_notrap
#print axioms Backend.Stock.Proof.MinMaxBody.minmax_source_notrap
#print axioms Backend.Stock.Proof.stock_lower_minmax_scan_fall_refines
#print axioms Backend.Stock.Proof.stock_lower_mixed_minmax_record_fall_refines
#print axioms Backend.Stock.Proof.stock_lower_mixed_minmax_body_fall_refines
#print axioms Backend.Stock.Proof.MinMaxBody.emitted_record_family
#print axioms Backend.Stock.Proof.MinMaxBody.actual_minmax_families
#print axioms Backend.Stock.Proof.MinMaxBody.actual_minmax_body_refines
#print axioms Backend.Stock.Proof.MinMaxBody.actual_minmax_entry_return_refines_frame
#print axioms Backend.Stock.Scalar.domain_of_minmax
#print axioms E2E.ComparisonRead.no_mem
#print axioms E2E.ComparisonRead.spec_eq
#print axioms E2E.ComparisonRead.step_frame
#print axioms E2E.StockMinMaxNIWitness.checks_true -- witness: native_decide
#print axioms E2E.StockMinMaxNIWitness.compiled_exists -- witness: native_decide
#print axioms E2E.StockMinMaxNIWitness.source_entry
#print axioms E2E.StockMinMaxNIWitness.source_returns
#print axioms E2E.StockMinMaxNIWitness.source_checks_true -- witness: native_decide
#print axioms E2E.StockMinMaxNIWitness.classifier_accepts -- witness: native_decide
#print axioms E2E.StockMinMaxNIWitness.selected_roots_present -- witness: native_decide
#print axioms E2E.StockMinMaxNIWitness.compiled_semantic_exists -- witness: native_decide
#print axioms E2E.StockMinMaxNIWitness.source_family
#print axioms Backend.Stock.Scalar.minmaxBodyEligible_sound
#print axioms Backend.Stock.Proof.ScalarSelect.stock_lower_minmax_actual_source_values
#print axioms Backend.Stock.Proof.ScalarSelect.stock_lower_minmax_source_operands
#print axioms Backend.Stock.Proof.trapRun_seq_prefix
#print axioms Backend.Stock.Proof.ScansSpec.local_trap_refines
#print axioms Backend.Stock.Proof.LocalBody.actual_local_source_trap
#print axioms Backend.Stock.Proof.LocalBody.actual_local_source_trap_execution
#print axioms Backend.Stock.Proof.LocalBody.actual_local_entry_trap_refines_frame
#print axioms Backend.Stock.Proof.stock_lower_last_div_return_emitted
#print axioms Backend.Stock.Proof.DivBody.actual_last_div_record
#print axioms Backend.Stock.Proof.ScansSpec.record_inst_mem
#print axioms Backend.Stock.Proof.ScansSpec.record_unique
#print axioms Backend.Stock.Proof.MixedDivRecord.fall_refines
#print axioms Backend.Stock.Proof.MixedDivRecord.trap_refines
#print axioms Backend.Stock.Proof.DivBody.actual_mixed_div_families
#print axioms Backend.Stock.Proof.DivBody.actual_mixed_div_body_refines
#print axioms Backend.Stock.Proof.DivBody.actual_mixed_div_entry_return_refines_frame
#print axioms Backend.Stock.Proof.DivBody.actual_mixed_div_entry_trap_refines_frame
#print axioms Backend.Stock.Scalar.domain_of_mixed_div
#print axioms Backend.Stock.Scalar.mixedDivEligible_sound
#print axioms E2E.StockMixedDivNIWitness.checks_true -- witness: native_decide
#print axioms E2E.StockMixedDivNIWitness.source_cases -- witness: native_decide
#print axioms E2E.StockMixedDivNIWitness.compiled_exists -- witness: native_decide
#print axioms E2E.StockMixedDivNIWitness.source_entry
#print axioms E2E.StockMixedDivNIWitness.outcomeAgrees_sound
#print axioms Backend.Stock.Proof.MixedBody.actual_mixed_families
#print axioms Backend.Stock.Proof.MixedBody.actual_mixed_entry_return_refines_frame
#print axioms Backend.Stock.Proof.MixedBody.mixed_source_notrap
#print axioms Backend.Stock.Mixed.sourceOk_sound
#print axioms Backend.Stock.Mixed.check_sound
#print axioms E2E.MixedFlagBoundary.Realize.return_realize
#print axioms E2E.MixedFlagBoundary.machine_return
#print axioms E2E.backend_correct_world_niX_stock_mixed
#print axioms E2E.backend_correct_worldX_stock_mixed
#print axioms Link.SemanticCompilerWith.compileWithFallback_spec
#print axioms Link.SemanticCompilerWith.accepts_previous
#print axioms E2E.StockMixedNIWitness.source_entry
#print axioms E2E.StockMixedNIWitness.source_returns
#print axioms E2E.StockMixedNIWitness.checks_true -- witness: native_decide
#print axioms E2E.StockMixedNIWitness.source_checks_true -- witness: native_decide
#print axioms E2E.StockMixedNIWitness.compiled_semantic_exists -- witness: native_decide
#print axioms E2E.SemanticMixedCompilerWitness.checks_true -- witness: native_decide
#print axioms E2E.SemanticFallbackWitness.checks_true -- witness: native_decide
#print axioms Backend.Stock.Proof.MulComplete.selected_rule
#print axioms Backend.Stock.Proof.MulComplete.record_source
#print axioms Backend.Stock.Proof.stock_lower_mul_scan_fall_refines
#print axioms Backend.Stock.Proof.stock_lower_mixed_mul_body_fall_refines
#print axioms Backend.Stock.Proof.MulBody.family_pure
#print axioms Backend.Stock.Proof.MulBody.family_quiet
#print axioms Backend.Stock.Proof.MulBody.family_single
#print axioms Backend.Stock.Proof.MulBody.actual_mul_families
#print axioms Backend.Stock.Proof.MulBody.actual_mul_body_refines
#print axioms Backend.Stock.Proof.MulBody.actual_mul_entry_return_refines_frame
#print axioms Backend.Stock.Proof.MulBody.mul_inst_notrap
#print axioms Backend.Stock.Proof.MulBody.mul_source_notrap
#print axioms Backend.Stock.Scalar.domain_of_mul
#print axioms Backend.Stock.Scalar.mulBodyEligible_sound
#print axioms Backend.Stock.Proof.stock_lower_mixed_bnot_record_fall_refines
#print axioms Backend.Stock.Proof.BnotBody.family_quiet
#print axioms Backend.Stock.Proof.BnotBody.family_single
#print axioms Backend.Stock.Proof.BnotBody.emitted_record_family
#print axioms Backend.Stock.Proof.BnotBody.bnot_inst_notrap
#print axioms Backend.Stock.Proof.PureBody.frame_getAs_notrap
#print axioms E2E.StockNotNIWitness.source_family
#print axioms E2E.StockMulNIWitness.checks_true -- witness: native_decide
#print axioms E2E.StockMulNIWitness.source_checks_true -- witness: native_decide
#print axioms E2E.StockMulNIWitness.compiled_exists -- witness: native_decide
#print axioms E2E.StockMulNIWitness.classifier_accepts -- witness: native_decide
#print axioms E2E.StockMulNIWitness.compiled_semantic_exists -- witness: native_decide
#print axioms E2E.StockMulNIWitness.selected_roots_present -- witness: native_decide
#print axioms E2E.StockMulNIWitness.source_entry
#print axioms E2E.StockMulNIWitness.source_returns
#print axioms Isle.Interp.RuleFrame.CtorFreeAt.mono
#print axioms Isle.Interp.RuleFrame.ctorFreeAt_inductive
#print axioms Backend.Stock.Proof.SinkRules.stock_term_ids_checked' does not depend on any axioms 'Backend.Stock.Proof.SinkRules.term_guard
#print axioms Backend.Stock.Proof.SinkRules.table_checked
#print axioms Backend.Stock.Proof.SinkRules.rule_cases
#print axioms Backend.Stock.Proof.SinkRules.sink_expr_other
#print axioms Backend.Stock.Proof.SinkRules.sink_let_other
#print axioms Backend.Stock.Proof.SinkRules.no_load_frames
#print axioms Backend.Stock.Proof.SinkRules.no_load_apply
#print axioms Backend.Stock.Proof.SinkRules.no_load_lower
#print axioms Backend.Stock.Proof.SinkRules.RhsWitness.explicit_sink_other_witness
#print axioms Backend.Stock.Proof.SinkRules.Witness.unused_division_witness -- witness: native_decide
#print axioms Isle.Interp.RuleFrame.CtorFreeAt.mono' depends on axioms: [propext] 'Isle.Interp.RuleFrame.ctorFreeAt_inductive' depends on axioms: [propext, Quot.sound] 'Backend.Stock.Proof.SinkRules.stock_term_ids_checked
#print axioms Backend.Stock.Proof.BnotComplete.selected_rule_ids
#print axioms Backend.Stock.Proof.BnotComplete.record_selected_rule_ids
#print axioms Backend.Stock.Proof.BnotComplete.source_operands
#print axioms Backend.Stock.Proof.BnotComplete.available_source
#print axioms Backend.Stock.Proof.BnotComplete.source_from_step
#print axioms Backend.Stock.Proof.stock_lower_bnot_scan_fall_refines
#print axioms Backend.Stock.Proof.stock_lower_mixed_bnot_body_fall_refines
#print axioms Backend.Stock.Proof.BnotBody.family_pure
#print axioms Backend.Stock.Proof.BnotBody.actual_bnot_families
#print axioms Backend.Stock.Proof.BnotBody.actual_bnot_body_refines
#print axioms Backend.Stock.Proof.BnotBody.actual_bnot_entry_return_refines_frame
#print axioms Backend.Stock.Proof.BnotBody.bnot_source_notrap
#print axioms Backend.Stock.Scalar.domain_of_bnot
#print axioms Backend.Stock.Scalar.extendedBodyEligible_sound
#print axioms Backend.Stock.Scalar.bodyEligible_sound
#print axioms E2E.StockNotNIWitness.checks_true -- witness: native_decide
#print axioms E2E.StockNotNIWitness.source_checks_true -- witness: native_decide
#print axioms E2E.StockNotNIWitness.compiled_exists -- witness: native_decide
#print axioms E2E.StockNotNIWitness.classifier_accepts -- witness: native_decide
#print axioms E2E.StockNotNIWitness.compiled_semantic_exists -- witness: native_decide
#print axioms E2E.StockNotNIWitness.source_entry
#print axioms E2E.StockNotNIWitness.source_returns
#print axioms Backend.Stock.Proof.PopcountBody.emitted_record_family
#print axioms Backend.Stock.Proof.PopcountBody.actual_popcount_families
#print axioms Backend.Stock.Proof.PopcountBody.actual_popcount_body_refines
#print axioms Backend.Stock.Proof.PopcountBody.family_pure
#print axioms Backend.Stock.Proof.PopcountBody.family_quiet
#print axioms Backend.Stock.Proof.PopcountBody.family_single
#print axioms Backend.Stock.Proof.PopcountBody.family_formats
#print axioms Backend.Stock.Proof.PopcountBody.popcount_inst_notrap
#print axioms Backend.Stock.Proof.PopcountBody.popcount_source_notrap
#print axioms Backend.Stock.Proof.PopcountBody.actual_popcount_entry_return_refines_frame
#print axioms Backend.Stock.Proof.stock_lower_popcount_scan_fall_refines
#print axioms Backend.Stock.Proof.stock_lower_mixed_popcount_record_fall_refines
#print axioms Backend.Stock.Proof.stock_lower_mixed_popcount_body_fall_refines
#print axioms Backend.Stock.Scalar.domain_of_popcount
#print axioms E2E.PopcountRead.step_frame
#print axioms E2E.PopcountRead.no_mem
#print axioms E2E.PopcountRead.spec_eq
#print axioms E2E.StockPopcountNIWitness.checks_true -- witness: native_decide
#print axioms E2E.StockPopcountNIWitness.compiled_exists -- witness: native_decide
#print axioms E2E.StockPopcountNIWitness.source_entry
#print axioms E2E.StockPopcountNIWitness.source_returns
#print axioms E2E.StockPopcountNIWitness.source_checks_true -- witness: native_decide
#print axioms E2E.StockPopcountNIWitness.classifier_accepts -- witness: native_decide
#print axioms E2E.StockPopcountNIWitness.selected_roots_present -- witness: native_decide
#print axioms E2E.StockPopcountNIWitness.compiled_semantic_exists -- witness: native_decide
#print axioms E2E.StockPopcountNIWitness.source_family
#print axioms Backend.Stock.Scalar.popcountBodyEligible_sound
#print axioms Backend.Stock.Proof.ScalarPopcount.stock_lower_popcount_source_by_instruction
#print axioms Backend.Stock.Proof.ScalarPopcount.ZeroWitness.stock_lower_popcount_source_witness
#print axioms Backend.Stock.Proof.ScalarPopcount.NonzeroWitness.stock_lower_popcount_source_witness
#print axioms Backend.Stock.Proof.DivBody.actual_returned_div_record
#print axioms Backend.Stock.Proof.DivBody.actual_returned_div_families
#print axioms Backend.Stock.Proof.DivBody.actual_returned_div_body_refines
#print axioms Backend.Stock.Proof.DivBody.actual_returned_div_entry_return_refines_frame
#print axioms Backend.Stock.Proof.DivBody.actual_returned_div_entry_trap_refines_frame
#print axioms Backend.Stock.Scalar.domain_of_returned_div
#print axioms Backend.Stock.Scalar.returnedDivAt_sound
#print axioms Backend.Stock.Scalar.returnedDivBodyEligible_sound
#print axioms Backend.Stock.Scalar.returnedDivEligible_sound
#print axioms E2E.StockReturnedDivNIWitness.outcomeAgrees_sound
#print axioms E2E.StockReturnedDivNIWitness.checks_true -- witness: native_decide
#print axioms E2E.StockReturnedDivNIWitness.source_cases -- witness: native_decide
#print axioms E2E.StockReturnedDivNIWitness.compiled_exists -- witness: native_decide
#print axioms E2E.StockReturnedDivNIWitness.source_entry
#print axioms Backend.Stock.Proof.SinkRules.no_load_branch
#print axioms Backend.Stock.Proof.SinkRules.inst_data_no_load
#print axioms Backend.Stock.Proof.SinkRules.build_ctx_no_load
#print axioms Backend.Stock.Proof.SinkRules.scoped_build_ctx_no_load
#print axioms Backend.Stock.Proof.SinkRules.term_ctx_no_load
#print axioms Backend.Stock.Proof.SinkRules.term_data_no_load
#print axioms Backend.Stock.Proof.SinkRules.try_call_data_no_load
#print axioms Backend.Stock.Proof.SinkRules.scalar_div_formats
#print axioms Backend.Stock.Proof.SinkRules.build_ctx_sunk_false
#print axioms Backend.Stock.Proof.SinkRules.scan_no_load_unsunk
#print axioms Backend.Stock.Proof.SinkRules.scan_block_no_load_unsunk
#print axioms Backend.Stock.Proof.SinkRules.scans_no_load_unsunk
#print axioms Backend.Stock.Proof.SinkRules.stock_blockCore_no_load_sunk_eq
#print axioms Backend.Stock.Proof.SinkRules.stock_node_no_load_sunk_eq
#print axioms Backend.Stock.Proof.SinkRules.stock_traversal_no_load_sunk_eq
#print axioms Backend.Stock.Proof.SinkRules.stock_lower_no_load_sunk_eq
#print axioms Backend.Stock.Proof.SinkRules.stock_lower_no_load_unsunk
#print axioms Backend.Stock.Proof.SinkRules.stock_lower_scalar_div_unsunk
#print axioms Backend.Stock.Proof.DivBody.actual_division_record
#print axioms Backend.Stock.Proof.DivBody.actual_scalar_div_families
#print axioms Backend.Stock.Proof.DivBody.actual_scalar_div_body_refines
#print axioms Backend.Stock.Proof.DivBody.actual_scalar_div_entry_return_refines_frame
#print axioms Backend.Stock.Proof.DivBody.actual_scalar_div_entry_trap_refines_frame
#print axioms Backend.Stock.Proof.SinkRules.DriverWitness.two_division_driver_witness -- witness: native_decide
#print axioms Backend.Stock.Proof.SinkRules.BranchWitness.critical_edge_driver_witness -- witness: native_decide
#print axioms Backend.Stock.Proof.SinkRules.DriverWitness.two_division_domain -- witness: native_decide
#print axioms Backend.Stock.Proof.SinkRules.DriverWitness.two_division_source_entry
#print axioms Backend.Stock.Proof.SinkRules.DriverWitness.two_division_source_return
#print axioms Backend.Stock.Proof.SinkRules.DriverWitness.two_division_source_zero
#print axioms Backend.Stock.Proof.SinkRules.DriverWitness.two_division_source_overflow
#print axioms Backend.Stock.Proof.SinkRules.DriverWitness.two_division_records -- witness: native_decide
#print axioms Backend.Stock.Proof.SinkRules.BranchWitness.try_call_format_witness
#print axioms Backend.Stock.Proof.PureBody.actual_source_records
#print axioms Backend.Stock.Proof.PureBody.actual_pure_source_step
#print axioms Backend.Stock.Proof.PureBody.actual_pure_source_execution_frame
#print axioms Backend.Stock.Proof.PureBody.pure_source_notrap
#print axioms Backend.Stock.Logical.bodyEligible_sound
#print axioms Backend.Stock.Proof.LogicalBody.logical_inst_notrap
#print axioms Backend.Stock.Proof.ConstantBody.family_pure
#print axioms Backend.Stock.Proof.ConstantBody.actual_constant_families
#print axioms Backend.Stock.Proof.ConstantBody.actual_constant_body_refines
#print axioms Backend.Stock.Proof.ConstantBody.actual_constant_entry_return_refines_frame
#print axioms Backend.Stock.Proof.ConstantBody.constant_source_notrap
#print axioms Backend.Stock.Scalar.domain_of_constant
#print axioms E2E.backend_correct_worldX_stock_scalar
#print axioms E2E.backend_correct_world_niX_stock_scalar
#print axioms E2E.StockScalarNIWitness.checks_true -- witness: native_decide
#print axioms E2E.StockScalarNIWitness.source_checks_true -- witness: native_decide
#print axioms E2E.StockScalarNIWitness.compiled_exists -- witness: native_decide
#print axioms E2E.StockScalarNIWitness.classifier_accepts -- witness: native_decide
#print axioms E2E.StockScalarNIWitness.compiled_semantic_exists -- witness: native_decide
#print axioms E2E.StockScalarNIWitness.source_entry
#print axioms E2E.StockScalarNIWitness.source_returns
#print axioms E2E.ABIReadBoundary.checked_step_frame
#print axioms E2E.ABIReadBoundary.checked_step_transport
#print axioms E2E.ABIReadBoundary.star_transport
#print axioms E2E.ABIReadBoundary.return_transport
#print axioms E2E.ABIReadBoundary.Realize.step_realize
#print axioms E2E.ABIReadBoundary.Realize.star_realize
#print axioms E2E.ABIReadBoundary.Realize.return_realize
#print axioms E2E.ABIReadBoundary.machine_return
#print axioms E2E.MixedFlagBoundary.FlagFrame.refl' does not depend on any axioms 'E2E.MixedFlagBoundary.FlagFrame.write_pstate
#print axioms E2E.MixedFlagBoundary.FlagFrame.trans' does not depend on any axioms 'E2E.MixedFlagBoundary.FlagFrame.regVal
#print axioms E2E.MixedFlagBoundary.FlagFrame.arguments
#print axioms E2E.ScalarBoundary.refines
#print axioms E2E.ScalarBoundary.memory
#print axioms E2E.ScalarBoundary.driver
#print axioms E2E.ScalarBoundary.checked_step_frame
#print axioms E2E.ScalarBoundary.checked_step_transport
#print axioms E2E.ScalarBoundary.Realize.step_realize
#print axioms E2E.ScalarBoundary.return_transport
#print axioms E2E.ScalarBoundary.machine_return
#print axioms E2E.ScalarBoundary.checked_instruction
#print axioms E2E.CompiledSemanticNI.noTlsScalar
#print axioms Backend.Stock.Proof.PureBody.actual_source_records' depends on axioms: [propext, Classical.choice, Quot.sound] 'Backend.Stock.Proof.PureBody.actual_pure_source_step' depends on axioms: [propext, Classical.choice, Quot.sound] 'Backend.Stock.Proof.PureBody.actual_pure_source_execution_frame' depends on axioms: [propext, Classical.choice, Quot.sound] 'Backend.Stock.Proof.PureBody.actual_pure_return_refines_at' depends on axioms: [propext, Classical.choice, Quot.sound] 'Backend.Stock.Proof.PureBody.actual_pure_entry_return_refines_frame' depends on axioms: [propext, Classical.choice, Quot.sound] 'Backend.Stock.Proof.PureBody.pure_source_notrap' depends on axioms: [propext, Quot.sound] 'Backend.Stock.Logical.bodyEligible_sound' depends on axioms: [propext] 'Backend.Stock.Proof.LogicalBody.logical_inst_notrap' depends on axioms: [propext, Quot.sound] 'Backend.Stock.Proof.ConstantBody.family_pure' depends on axioms: [propext] 'Backend.Stock.Proof.ConstantBody.actual_constant_families' depends on axioms: [propext, Classical.choice, Quot.sound] 'Backend.Stock.Proof.ConstantBody.actual_constant_body_refines' depends on axioms: [propext, Classical.choice, Quot.sound] 'Backend.Stock.Proof.ConstantBody.actual_constant_entry_return_refines_frame' depends on axioms: [propext, Classical.choice, Quot.sound] 'Backend.Stock.Proof.ConstantBody.constant_source_notrap' depends on axioms: [propext, Quot.sound] 'Backend.Stock.Scalar.domain_of_constant' depends on axioms: [propext, Classical.choice, Quot.sound] 'Backend.Stock.Scalar.bodyEligible_sound' depends on axioms: [propext] 'Backend.Stock.Scalar.sourceOk_sound' depends on axioms: [propext, Classical.choice, Quot.sound] 'Backend.Stock.Scalar.check_sound' depends on axioms: [propext, Classical.choice, Quot.sound] 'E2E.backend_correct_worldX_stock_scalar' depends on axioms: [propext, Classical.choice, Quot.sound] 'E2E.backend_correct_world_niX_stock_scalar' depends on axioms: [propext, Classical.choice, Quot.sound] 'E2E.StockScalarNIWitness.checks_true' depends on axioms: [propext, Classical.choice, Quot.sound, E2E.StockScalarNIWitness.checks_true._native.native_decide.ax_1] 'E2E.StockScalarNIWitness.source_checks_true' depends on axioms: [propext, Classical.choice, Quot.sound, E2E.StockScalarNIWitness.source_checks_true._native.native_decide.ax_1_1] 'E2E.StockScalarNIWitness.compiled_exists' depends on axioms: [propext, Classical.choice, Quot.sound, E2E.StockScalarNIWitness.checks_true._native.native_decide.ax_1] 'E2E.StockScalarNIWitness.classifier_accepts' depends on axioms: [propext, Classical.choice, Quot.sound, E2E.StockScalarNIWitness.source_checks_true._native.native_decide.ax_1_1] 'E2E.StockScalarNIWitness.compiled_semantic_exists' depends on axioms: [propext, Classical.choice, Quot.sound, E2E.StockScalarNIWitness.checks_true._native.native_decide.ax_1] 'E2E.StockScalarNIWitness.source_entry' depends on axioms: [propext] 'E2E.StockScalarNIWitness.source_returns' depends on axioms: [propext, Quot.sound] 'E2E.ABIReadBoundary.checked_step_frame' depends on axioms: [propext, Classical.choice, Quot.sound] 'E2E.ABIReadBoundary.checked_step_transport' depends on axioms: [propext, Classical.choice, Quot.sound] 'E2E.ABIReadBoundary.star_transport' depends on axioms: [propext, Classical.choice, Quot.sound] 'E2E.ABIReadBoundary.return_transport' depends on axioms: [propext, Classical.choice, Quot.sound] 'E2E.ABIReadBoundary.Realize.step_realize' depends on axioms: [propext, Classical.choice, Quot.sound] 'E2E.ABIReadBoundary.Realize.star_realize' depends on axioms: [propext, Classical.choice, Quot.sound] 'E2E.ABIReadBoundary.Realize.return_realize' depends on axioms: [propext, Classical.choice, Quot.sound] 'E2E.ABIReadBoundary.machine_return' depends on axioms: [propext, Classical.choice, Quot.sound] 'E2E.MixedFlagBoundary.FlagFrame.refl
#print axioms E2E.MixedFlagBoundary.FlagFrame.write_pstate' depends on axioms: [propext] 'E2E.MixedFlagBoundary.FlagFrame.trans
#print axioms Backend.Stock.Proof.ShiftComplete.opcode_inventory
#print axioms Backend.Stock.Proof.ShiftComplete.selected_rule_ids
#print axioms Backend.Stock.Proof.ShiftComplete.base_source
#print axioms Backend.Stock.Proof.ShiftBitfield.stock_bitfield_pure_helper
#print axioms Backend.Stock.Proof.ShiftBitfield.stock_bitfield_projects
#print axioms Backend.Stock.Proof.ShiftBitfield.stock_bitfield_move_observed
#print axioms Backend.Stock.Proof.ShiftBitfield.stock_bitfield_match_sources
#print axioms Backend.Stock.Proof.ShiftBitfield.stock_bitfield_match_receipts
#print axioms Backend.Stock.Proof.ShiftBitfield.stock_bitfield_helper_run
#print axioms Backend.Stock.Proof.ShiftBitfield.stock_bitfield_rhs_run
#print axioms Backend.Stock.Proof.ShiftBitfield.stock_bitfield_rhs_observed
#print axioms Backend.Stock.Proof.ShiftBitfield.stock_bitfield_resolved
#print axioms Backend.Stock.Proof.ShiftBitfield.stock_bitfield_selected_values
#print axioms Backend.Stock.Proof.ShiftBitfield.stock_lower_bitfield_record_values
#print axioms Backend.Stock.Proof.ShiftBitfield.stock_lower_bitfield_available_values
#print axioms Backend.Stock.Proof.ShiftComplete.fused_source
#print axioms Backend.Stock.Proof.ShiftComplete.record_source
#print axioms Backend.Stock.Proof.stock_lower_shift_scan_fall_refines
#print axioms Backend.Stock.Proof.stock_lower_mixed_mul_record_fall_refines
#print axioms Backend.Stock.Proof.stock_lower_mixed_shift_body_fall_refines
#print axioms Backend.Stock.Proof.ShiftBody.family_pure
#print axioms Backend.Stock.Proof.ShiftBody.family_quiet
#print axioms Backend.Stock.Proof.ShiftBody.family_single
#print axioms Backend.Stock.Proof.ShiftBody.actual_shift_families
#print axioms Backend.Stock.Proof.ShiftBody.actual_shift_body_refines
#print axioms Backend.Stock.Proof.ShiftBody.actual_shift_entry_return_refines_frame
#print axioms Backend.Stock.Proof.ShiftBody.shift_inst_notrap
#print axioms Backend.Stock.Proof.ShiftBody.shift_source_notrap
#print axioms Backend.Stock.Scalar.domain_of_shift
#print axioms E2E.ShiftRead.step_frame
#print axioms E2E.ShiftRead.no_mem
#print axioms E2E.ShiftRead.spec_eq
#print axioms Backend.Stock.Scalar.shiftBodyEligible_sound
#print axioms E2E.StockMulNIWitness.source_family
#print axioms E2E.StockShiftNIWitness.checks_true -- witness: native_decide
#print axioms E2E.StockShiftNIWitness.compiled_exists -- witness: native_decide
#print axioms E2E.StockShiftNIWitness.source_entry
#print axioms E2E.StockShiftNIWitness.source_returns
#print axioms E2E.StockShiftNIWitness.source_checks_true -- witness: native_decide
#print axioms E2E.StockShiftNIWitness.classifier_accepts -- witness: native_decide
#print axioms E2E.StockShiftNIWitness.selected_roots_present -- witness: native_decide
#print axioms E2E.StockShiftNIWitness.compiled_semantic_exists -- witness: native_decide
#print axioms Backend.Stock.Proof.scan_zero_results
#print axioms Backend.Stock.Proof.scan_zero_results_witness
#print axioms Backend.Stock.Proof.stock_lower_bmask_scan_fall_refines
#print axioms Backend.Stock.Proof.MaskBody.family_formats
#print axioms Backend.Stock.Proof.MaskBody.actual_nop_record
#print axioms Backend.Stock.Proof.MaskBody.actual_families
#print axioms Backend.Stock.Proof.MaskBody.Record.fall_refines
#print axioms Backend.Stock.Proof.MaskBody.Record.trap_refines
#print axioms Backend.Stock.Proof.MaskBody.actual_body_refines
#print axioms Backend.Stock.Proof.MaskBody.actual_entry_return_refines_frame
#print axioms Backend.Stock.Proof.MaskBody.actual_entry_trap_refines_frame
#print axioms Backend.Stock.Scalar.domain_of_mask
#print axioms Backend.Stock.Scalar.maskMixedBodyEligible_sound
#print axioms Backend.Stock.Scalar.domain_of_maskEligible
#print axioms E2E.MaskRead.no_mem
#print axioms E2E.MaskRead.spec_eq
#print axioms E2E.MaskRead.step_frame
#print axioms E2E.MaskRead.step_frame_witness
#print axioms E2E.StockMaskNIWitness.checks_true -- witness: native_decide
#print axioms E2E.StockMaskNIWitness.compiled_cases -- witness: native_decide
#print axioms E2E.ExtendedComparisonRead.cases_of_check
#print axioms E2E.ExtendedComparisonRead.no_mem
#print axioms E2E.ExtendedComparisonRead.spec_eq
#print axioms E2E.ExtendedComparisonRead.step_frame
#print axioms E2E.StockNarrowNIWitness.bswap8_original_scope
#print axioms E2E.StockNarrowNIWitness.checks_true -- witness: native_decide
#print axioms E2E.StockNarrowNIWitness.compiled_of_checks
#print axioms E2E.StockNarrowNIWitness.compiled_exists -- witness: native_decide
#print axioms E2E.StockNarrowNIWitness.compiled_mixed_exists -- witness: native_decide
#print axioms E2E.StockNarrowNIWitness.source_outcomes -- witness: native_decide
#print axioms E2E.StockNarrowNIWitness.source_return -- witness: native_decide
#print axioms E2E.StockNarrowNIWitness.division_zero -- witness: native_decide
#print axioms E2E.StockNarrowNIWitness.division_overflow -- witness: native_decide
#print axioms E2E.StockNarrowNIWitness.source_entry
#print axioms E2E.StockNarrowNIWitness.mixed_source_entry
#print axioms Backend.Stock.Scalar.narrowBodyEligible_sound
#print axioms Backend.Stock.Scalar.domain_of_narrowEligible
