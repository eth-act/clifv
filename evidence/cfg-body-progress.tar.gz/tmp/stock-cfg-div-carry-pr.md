The inherited-value invariant did not yet compose through division records. This reuses the existing complete division source execution and outside-interval frame for all old signed/unsigned/narrow/remainder cases, retains original zero/overflow traps, and composes complete constant/division/nop bodies under carry, including arbitrary-position, multiple and unused divisions.

Three genuine entry/normal7÷3=2/zero-trap/whole-body witnesses reuse previous kernel compiler/source fixtures. All four general roots and three witnesses are standard-only; no new finite fact or native axiom is introduced.

Author gates on e91b7103: full FV/FVTest4004/4004;85repository audits/3576reports/3425roots;all3418prior axiom sets exact;3991old Lean sources byte-exact. Bundled Lean MCP checks pass without source warnings. Publication10bf8c30 changes documentation only. No compiler/scope/allocator/checker/linker/consumer definitions or runtime gate inputs change.

Production CFG and full140remain pending. Next actual return-block/core composition and substantive two-block CFG production activation through actual ABI/return/prepared/physical consumers; continue successive classes and every original effect/whole-driver/completeness obligation afterward. See docs/research/stock-division-carry-checkpoint.md.
