import os,json,subprocess,datetime,hashlib
from pathlib import Path
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');os.chdir(root)
env=os.environ.copy();env.update(json.load(open('/tmp/stock-mixed-div-env.json')));env.update(FV_ROOT=str(root),FV_MEMCAP='8G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',CARGO_BUILD_JOBS='2')
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:2]);os.nice(10)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();records={}
def run(label,args):
 path=Path('/tmp/stock-cfg-production-'+label+'-v2.log');print(datetime.datetime.now(datetime.timezone.utc).isoformat(),label,flush=True)
 with path.open('w') as out:r=subprocess.run(['scripts/memcap.sh',*args],env=env,stdout=out,stderr=subprocess.STDOUT)
 records[label]={'returncode':r.returncode,'log':str(path)}
 Path('/tmp/stock-cfg-production-recovery-v2.json').write_text(json.dumps({'head':head,'records':records},indent=2)+'\n')
 if r.returncode:raise SystemExit(r.returncode)
run('native-execution',['python3','scripts/check-stock-mixed-native.py','/tmp/stock-cfg-production-integration-v1/native-objects','--class','cfg'])
run('linked-build',['lake','build','stock-general-div-linked'])
assert head==subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
run('integration',['python3','scripts/check-stock-mixed-integration.py','--output','/tmp/stock-cfg-production-integration-v2','--class','cfg','--fixture-mode','native'])
