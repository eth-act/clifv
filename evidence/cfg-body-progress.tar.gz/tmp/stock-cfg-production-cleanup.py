from pathlib import Path
import os,json,tarfile,hashlib,subprocess,shutil,datetime
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:1]);os.nice(19)
root=Path('/home/lee/clifv/.worktrees/driver-proof-resume');build=root/'.lake/build';out=Path('/tmp/stock-cfg-production-retired-original-build');out.mkdir(exist_ok=False)
status=subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=root)
files=sorted(p for p in build.rglob('*') if p.is_file());assert not any(p.suffix=='.lean' for p in files)
metadata=[p for p in files if p.suffix in {'.json','.trace','.hash','.rsp','.log','.md','.txt','.time'}]
archive=out/'metadata.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=3) as tf:
 for p in metadata:tf.add(p,arcname=str(p.relative_to(build)),recursive=False)
with tarfile.open(archive,'r:gz') as tf:assert len(tf.getmembers())==len(metadata)
(out/'inventory.json').write_text(json.dumps([{'path':str(p.relative_to(build)),'bytes':p.stat().st_size,'links':p.stat().st_nlink} for p in files],indent=2)+'\n')
r={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_root':str(root),'removed_cache':str(build),'metadata_files_preserved':len(metadata),'inventory_files':len(files),'metadata_archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'source_status_sha256_before':hashlib.sha256(status).hexdigest(),'no_Lean_source_files_in_removed_cache':True,'single_warm_artifact_cache_preserved':str(root/'.lake/artifact-cache')}
shutil.rmtree(build)
assert status==subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=root)
r['state']='obsolete_outputs_removed_source_status_unchanged';r['free_space_after']=subprocess.check_output(['df','-h',str(root)],text=True);(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='free_space_after'}))
