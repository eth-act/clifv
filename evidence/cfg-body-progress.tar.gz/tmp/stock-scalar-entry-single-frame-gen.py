from pathlib import Path
import re
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025/FV/Backend/Proof')
leaf=[('StockAluRecordValues','stock_lower_alu_available_values'),('StockAddSubRecordValues','stock_lower_addsub_fused_available_values'),('StockMulFusedRecordValues','stock_lower_mul_fused_available_values'),('StockLogicalRecordValues','stock_lower_logical_available_values'),('StockLogicalNotRecord','stock_lower_logical_not_available_values'),('StockLogicalExtrRecord','available_values'),('StockLogicalNotXorRecord','stock_lower_not_xor_available_values'),('StockBnotRecordValues','stock_lower_bnot_available_values')]
rest=[('StockAluOperandCoverage','stock_lower_alu_available_values_auto_operands'),('StockAluSelectedValues','stock_lower_alu_selected_values'),('StockAddSubAllValues','stock_lower_addsub_available_values'),('StockAddSubAllSourceValues','stock_lower_addsub_available_source'),('StockAddSubAllSourceValues','stock_lower_addsub_source_by_instruction'),('StockLogicalSourceTransfer','available_source'),('StockLogicalSourceTransfer','source_from_step'),('StockLogicalSourceTransfer','not_available_source'),('StockLogicalSourceTransfer','not_source_from_step'),('StockLogicalExtrSourceTransfer','available_source'),('StockLogicalExtrSourceTransfer','source_from_step'),('StockLogicalCompleteValues','record_source_from_step'),('StockBnotSourceTransfer','available_source'),('StockBnotSourceTransfer','source_from_step')]
specs=leaf+rest;data=[];names={}
for i,(file,name) in enumerate(specs):
 s=(root/(file+'.lean')).read_text();ns=re.search(r'^namespace (\S+)',s,re.M)[1];a=s.index('theorem '+name+' ');b=a+1+re.search(r'\n(?:theorem |private theorem |end |attribute )',s[a+1:]).start();doc=s.rfind('\n/--',a,b)
 if doc>a:b=doc
 text=s[a:b].rstrip();h,proof=text.split(' := by',1);key=ns+'.'+name;names[key]='frame_'+str(i);opens=[]
 for line in s[:a].splitlines():
  if line.startswith('open '):opens+=line[5:].split()
 data.append((key,ns,name,h,proof,opens))
out='''private theorem scan_frontier (st : State) (i : Nat) :
    (scanState st i).base.nextVreg = st.base.nextVreg := by
  unfold scanState
  dsimp only
  split <;> rfl

'''
frame="(∀ key,key < record.input.base.nextVreg ∨ record.output.state.base.nextVreg ≤ key → ρ' key = ρ key)"
for i,(key,ns,name,h,proof,opens) in enumerate(data):
 newname=names[key];h=h.replace('theorem '+name+' ','private theorem '+newname+' ',1)+' ∧\n      '+frame
 # Qualify old leaf calls first; replace only known calls in this declaration's namespace.
 referenced=[]
 for old,new in sorted(names.items(),key=lambda p:-len(p[0])):
  if old==key:continue
  short=old.removeprefix('Backend.Stock.Proof.');tail=old.rsplit('.',1)[1]
  variants=[short,old]
  if old.rsplit('.',1)[0]==ns:variants.append(tail)
  for variant in variants:
   pat=r'(?<![\w.])'+re.escape(variant)+r'(?![\w.])'
   if re.search(pat,proof):proof=re.sub(pat,new,proof);referenced.append(new)
 if i<len(leaf):
  if i==0:proof=proof.replace("exact ⟨ρ', actualExecution, value, kept, transferred⟩","exact ⟨ρ', actualExecution, value, kept, transferred,fun key outside => kept key (by omega)⟩")
  else:
   assert "refine ⟨ρ',execution,value,kept,?_⟩" in proof,(key,proof[-500:])
   proof=proof.replace("refine ⟨ρ',execution,value,kept,?_⟩","refine ⟨ρ',execution,value,kept,?_,fun key outside => kept key (by omega)⟩",1)
 else:
  # Destruct the additional last conjunct only at calls to framed declarations.
  pat=r'(obtain ⟨)([^⟩]+)(⟩ :=\s*(?:'+ '|'.join(re.escape(n) for n in referenced)+r')\b)'
  if referenced:proof=re.sub(pat,lambda m:m[1]+m[2]+',interval'+m[3],proof)
  # A local family dispatcher has the same additional last conjunct.
  if 'have values : ∃' in proof:
   proof=proof.replace("(fun k => ρ' (aliasNum result.final.alias k)) := by","(fun k => ρ' (aliasNum result.final.alias k)) ∧\n      "+frame+" := by")
   proof=proof.replace('kept,installed⟩ := values','kept,installed,interval⟩ := values')
  proof=re.sub(r'(exact ⟨[^\n]+,(?:post|installed)۰?)(⟩)',r'\1,interval\2',proof)
 # The framed DAG uses old syntax/typing helpers via exactly their original namespace.
 out+='open '+ns+' '+' '.join(dict.fromkeys(opens))+' in\n'+h+' := by'+proof+'\n\n'
Path('/tmp/stock-scalar-entry-single-frame.lean').write_text(out)
Path('/tmp/stock-scalar-entry-single-frame-map.json').write_text(__import__('json').dumps(names,indent=2))
print('framed nodes',len(specs),'lines',len(out.splitlines()))
