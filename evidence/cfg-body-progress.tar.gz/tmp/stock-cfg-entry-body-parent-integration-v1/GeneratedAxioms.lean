import Crates.StockCfgProduction2CleanupFallbackGlobal
import Crates.StockCfgProduction2PlainFallbackGlobal
import Crates.StockCfgProduction2RetainedCleanupFallbackGlobal
import Crates.StockCfgProduction2RetainedPlainFallbackGlobal
import Crates.StockCfgProduction33CleanupFallbackEntries
import Crates.StockCfgProduction33CleanupFallbackGlobal
import Crates.StockCfgProduction6CleanupFallbackGlobal
import Crates.StockCfgProduction6CleanupStrictGlobal
import Crates.StockCfgProduction6MixedCleanupFallbackGlobal
import Crates.StockCfgProduction6MixedPlainFallbackGlobal
import Crates.StockCfgProduction6PlainFallbackGlobal
import Crates.StockCfgProduction6PlainStrictGlobal
import Crates.StockCfgProduction7MixedCleanupFallbackGlobal
import Crates.StockCfgProduction7MixedPlainFallbackGlobal
import Crates.CfgProductionCLIcurrentPlain
import Crates.CfgProductionCLIretainedPlain
import Crates.CfgProductionCLIcurrentCleanup
import Crates.CfgProductionCLIretainedCleanup
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let generated := fun (name : Name) =>
    let owner := (privateToUserName? name).getD name
    owner.toString.startsWith "Crates.StockCfgProduction" || owner.toString.startsWith "Crates.CfgProductionCLI"
  let mut count : Nat := 0
  for (name, _) in env.constants.toList do
    unless generated name do continue
    for ax in ← collectAxioms name do
      if #[``propext, ``Classical.choice, ``Quot.sound].contains ax then continue
      unless generated ax && (ax.toString.splitOn "._native.native_decide.ax_").length > 1 do
        throwError "unexpected generated-proof axiom {ax} in {name}"
    count := count + 1
  unless count > 0 do throwError "empty generated-proof audit"
  logInfo m!"STOCK_CFGPRODUCTION_GENERATED_AXIOMS_PASS {count}"
