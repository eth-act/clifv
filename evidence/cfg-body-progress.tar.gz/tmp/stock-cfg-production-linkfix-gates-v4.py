import os,json,subprocess,datetime,time,hashlib
from pathlib import Path
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');os.chdir(root)
e=os.environ.copy();e.update(json.load(open('/tmp/stock-mixed-div-env.json')));e.update(FV_ROOT=str(root),FV_MEMCAP='8G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',CARGO_BUILD_JOBS='2',FV_CG_CLIF='/home/lee/clifv/.worktrees/driver-proof-resume/target/cg_clif/unwind/librustc_codegen_cranelift.so');e['PATH']=str(root/'rust/target/release')+':'+e['PATH']
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:2]);os.nice(10)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();out=Path('/tmp/stock-cfg-production-linkfix-v4');out.mkdir(exist_ok=False);records={}
def run(label,args):
 assert head==subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
 log=out/(label+'.log');print(datetime.datetime.now(datetime.timezone.utc).isoformat(),label,flush=True)
 with log.open('w') as f:r=subprocess.run(['scripts/memcap.sh',*args],env=e,stdout=f,stderr=subprocess.STDOUT)
 records[label]={'returncode':r.returncode,'log':str(log),'sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
 (out/'receipt.json').write_text(json.dumps({'head':head,'state':'running' if not r.returncode else 'failed','records':records},indent=2)+'\n')
 if r.returncode:raise SystemExit(r.returncode)
run('normal',['python3','scripts/lake-serial-build.py','--budget','8G','--max-jobs','1','--min-cap','6G','--default-cap','6G','--max-cap','8G','--out',str(out/'normal'),'FV','FVTest'])
run('tools',['lake','build','lean-link','stock-general-div-linked'])
run('integration',['python3','scripts/check-stock-mixed-integration.py','--output','/tmp/stock-cfg-production-integration-v4','--class','cfg','--fixture-mode','native'])
for name in ['fv-demo','survey']:
 run('verified-'+name,['bash','examples/compare.sh','examples/'+name,'--lean-link','--verified','--keep-temps'])
run('real-crate-parity',['python3','/tmp/stock-cfg-production-real-crate-parity.py','--json',str(out/'real-crate-report.json'),'--diffs',str(out/'real-crate-diffs'),*[str(root/'examples'/name/'target/fv/plain-leanlink-verified-leanld/tmp') for name in ['fv-demo','survey']]])
run('crate-proofs',['python3','/tmp/stock-cfg-production-crate-validation.py','--out',str(out/'crate-proofs')])
(out/'receipt.json').write_text(json.dumps({'head':head,'state':'passed','records':records},indent=2)+'\n')
print('CURRENT_LINKFIX_GATES_PASS',flush=True)
