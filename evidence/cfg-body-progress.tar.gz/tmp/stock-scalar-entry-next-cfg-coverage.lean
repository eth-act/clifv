import FV.Backend.Proof.StockInheritedScalar
import FV.Backend.Proof.StockGuardedSuccessor
namespace Backend.Stock.Proof.Control
open Backend.Proof Backend.Proof.Driver Backend.Proof.Driver.Fix
set_option autoImplicit false
set_option Elab.async false

private theorem inherited_predecessor {f : Clif.Function} {ctx : Ctx}
    {bi tl : Nat} {b target : Clif.Block} {bc : Clif.BlockCall}
    (source : f.blocks[bi]? = some b) (destination : f.blocks[tl]? = some target)
    (edge : bc.block ∈ succIds b.term) (index : blockIdx? f bc.block = some tl)
    {x : Nat} (available : x ∈ availOf f (availIn f ctx) tl 0)
    (notParameter : x ∉ target.params.map (·.1)) :
    x ∈ (availIn f ctx).getD tl [] ∧ x ∉ defsOf f tl ∧
      x ∈ availOf f (availIn f ctx) bi b.body.length := by
  obtain ⟨present,later⟩ := (mem_av destination).mp available
  have incoming : x ∈ (availIn f ctx).getD tl [] := by
    rcases present with parameter | incoming | ⟨j,stm,earlier,_,_⟩
    · exact False.elim (notParameter parameter)
    · exact incoming
    · omega
  have noDef : x ∉ defsOf f tl := by
    intro defined
    obtain ⟨original,j,stm,found,statement,result⟩ := mem_defsOf.mp defined
    cases Option.some.inj (found.symm.trans destination)
    exact later ⟨j,stm,Nat.zero_le _,statement,result⟩
  have successor : tl ∈ succIdx f bi := by
    simp only [succIdx,source]
    exact List.mem_filterMap.mpr ⟨bc.block,edge,index⟩
  have fixed := inFix_fixOk (f := f) (ctx := ctx) (gn := id)
  refine ⟨incoming,noDef,(mem_av source).mpr ⟨?_,?_⟩⟩
  · rcases fixed.out tl x incoming bi successor with parameter | defined | inherited
    · exact .inl (by rwa [parsOf_of source] at parameter)
    · obtain ⟨original,j,stm,found,statement,result⟩ := mem_defsOf.mp defined
      cases Option.some.inj (found.symm.trans source)
      exact .inr (.inr ⟨j,stm,lt_of_getElem? statement,statement,result⟩)
    · exact .inr (.inl inherited)
  · rintro ⟨j,stm,later,statement,_⟩
    have bound := lt_of_getElem? statement
    omega

/-- A direct edge needs only values available at the current block's entry
and this block's explicitly forwarded definitions. This removes the two-block
assumption from the old coverage argument. -/
theorem successor_entry_coverage {f : Clif.Function} {ctx : Ctx}
    {bi tl : Nat} {b target : Clif.Block} {bc : Clif.BlockCall}
    (source : f.blocks[bi]? = some b) (destination : f.blocks[tl]? = some target)
    (edge : bc.block ∈ succIds b.term) (index : blockIdx? f bc.block = some tl)
    (forwarded : ∀ stm ∈ b.body,∀ x ∈ stm.results,x ∈ bc.args)
    {x : Nat} (available : x ∈ availOf f (availIn f ctx) tl 0)
    (notParameter : x ∉ target.params.map (·.1)) :
    x ∈ availOf f (availIn f ctx) bi 0 ∨ x ∈ bc.args := by
  have current := (inherited_predecessor source destination edge index available notParameter).2.2
  by_cases own : x ∈ b.body.flatMap (·.results)
  · obtain ⟨stm,member,result⟩ := List.mem_flatMap.mp own
    exact .inr (forwarded stm member x result)
  · left
    obtain ⟨present,_⟩ := (mem_av source).mp current
    apply (mem_av source).mpr
    refine ⟨?_,?_⟩
    · rcases present with parameter | inherited | ⟨j,stm,earlier,statement,result⟩
      · exact .inl parameter
      · exact .inr (.inl inherited)
      · exact False.elim (own (List.mem_flatMap.mpr ⟨stm,List.mem_of_getElem? statement,result⟩))
    · rintro ⟨j,stm,_,statement,result⟩
      exact own (List.mem_flatMap.mpr ⟨stm,List.mem_of_getElem? statement,result⟩)

end Backend.Stock.Proof.Control
