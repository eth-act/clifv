private theorem scan_frontier (st : State) (i : Nat) :
    (scanState st i).base.nextVreg = st.base.nextVreg := by
  unfold scanState
  dsimp only
  split <;> rfl

open Backend.Stock.Proof Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64 in
private theorem frame_0 {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    {event : BlockScanEvent} {record : ScanRecord}
    (events : event ∈ result.blockScans.toList) (records : record ∈ event.output.records)
    {bi j : Nat} {b : Clif.Block} {stm : Clif.Stmt}
    (block : f.blocks[bi]? = some b) (statement : b.body[j]? = some stm)
    (current : record.inst = blockStart f bi + j)
    {info : IInfo} {z a x y n : Nat} {ty : Clif.Ty} (subtract : Bool) (width : ty.width ≤ 64)
    (source : event.ctx.insts[record.inst]? = some info)
    (clif : info.clif = some (.binary (if subtract then .isub else .iadd) ty x y))
    (results : info.results = [z]) (statementResults : stm.results = [z])
    (mapped : event.ctx.valueReg? z = some (.vreg a .int))
    {step : Step} (recorded : record.output.step = some step) (emitted : step.decision = .emitted)
    {next : State} {out : V} {evalTrace : Array RuleId} {trace : List RuleId}
    (evalRun : (evalExpr program (Stock.sem event.ctx) {} (n + 40)
      (if subtract then rule_lower_801 else rule_lower_86).rhs
      (env3 (.ty (.int ty.width)) (.value x) (.value y))).run
        (scanState record.input record.inst, #[]) = .ok (some out, next, evalTrace))
    (rootRun : Stock.runTerm event.ctx "lower" [.inst record.inst] (scanState record.input record.inst) =
      .ok (some out, next, trace))
    {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem} (refines : Refines F isem)
    {fr : Clif.Frame} {ρ : Nat → CV}
    (operands : ValuesHeld (fun v => v = x ∨ v = y) event.ctx fr (fun k => ρ (aliasNum result.final.alias k)))
    (held : ValuesHeld (fun v => Demanded record.output.state v ∧
      v ∈ availOf f (availIn f result.ctx) bi j) event.ctx fr (fun k => ρ (aliasNum result.final.alias k)))
    {u v : BitVec ty.width} (sourceX : fr.getAs x ty = .ok u) (sourceY : fr.getAs y ty = .ok v) :
    ∃ ρ', PRun F isem (record.output.emitted.toList.map (·.mapRegs
        (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size + 1)))) ρ ρ' ∧
      VHolds ⟨ty, Clif.Sem.binary (if subtract then .isub else .iadd) u v⟩ (ρ' record.input.base.nextVreg) ∧
      (∀ key, key ≠ record.input.base.nextVreg → ρ' key = ρ key) ∧
      ValuesHeld (fun y => Demanded record.input y ∧
        y ∈ availOf f (availIn f result.ctx) bi (j + 1)) event.ctx
          (withValue fr z ⟨ty, Clif.Sem.binary (if subtract then .isub else .iadd) u v⟩)
          (fun k => ρ' (aliasNum result.final.alias k)) ∧
      (∀ key,key < record.input.base.nextVreg ∨ record.output.state.base.nextVreg ≤ key → ρ' key = ρ key) := by
  obtain ⟨nx, ny, mx, my, outputs, code, upper, demands⟩ :=
    stock_lower_alu_record_shape run scope events records subtract width source results mapped recorded emitted evalRun rootRun
  have bound : result.final.alias.size ≤ record.input.base.nextVreg := by
    simpa only [scan_frontier] using stock_lower_blockScanAliasBounds run event events record records
  have operation : ((if subtract then ALUOp.sub else .add), (if subtract then Clif.BinaryOp.isub else .iadd)) =
      (.add, .iadd) ∨ ((if subtract then ALUOp.sub else .add), (if subtract then Clif.BinaryOp.isub else .iadd)) =
      (.sub, .isub) ∨ ((if subtract then ALUOp.sub else .add), (if subtract then Clif.BinaryOp.isub else .iadd)) =
      (.and, .band) ∨ ((if subtract then ALUOp.sub else .add), (if subtract then Clif.BinaryOp.isub else .iadd)) =
      (.orr, .bor) ∨ ((if subtract then ALUOp.sub else .add), (if subtract then Clif.BinaryOp.isub else .iadd)) =
      (.eor, .bxor) := by cases subtract <;> simp
  obtain ⟨ρ', executed, value, kept⟩ := stock_alu_rrr_resolved refines operation width bound mx my operands sourceX sourceY
  have actualCode : record.output.emitted.toList.map (·.mapRegs
      (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size + 1))) =
      [(MInst.aluRRR (if subtract then .sub else .add) (szOf ty.width)
        (.vreg record.input.base.nextVreg .int) (.vreg nx .int) (.vreg ny .int)).mapRegs
          (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size + 1))] := by rw [code]; rfl
  have actualExecution : PRun F isem (record.output.emitted.toList.map (·.mapRegs
      (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size + 1)))) ρ ρ' := by
    rw [actualCode]; exact executed
  have terminal : aliasNum result.final.alias record.input.base.nextVreg = record.input.base.nextVreg := by
    apply chaseF_none
    rw [Array.getElem?_eq_none bound]
    rfl
  have defs : ∀ m ∈ record.output.emitted.toList.map (·.mapRegs
      (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size + 1))), ∀ key ∈ vdefs m,
        record.input.base.nextVreg ≤ key ∧ key < record.output.state.base.nextVreg := by
    rw [actualCode]
    intro m member key defined
    have equal := List.mem_singleton.mp member
    subst m
    simp only [MInst.mapRegs, resolve_vreg] at defined
    change key ∈ [aliasNum result.final.alias record.input.base.nextVreg] at defined
    rw [terminal] at defined
    have equal := List.mem_singleton.mp defined
    subst key
    rw [upper]
    omega
  obtain ⟨w', execution, _⟩ := actualExecution Arm.ArmState.default
  have transferred := stock_lower_fresh_record_values_auto_demand run scope dominated events records
    block statement current source clif results statementResults mapped recorded emitted outputs
    (Nat.le_refl _) held defs execution value
  exact ⟨ρ', actualExecution, value, kept, transferred,fun key outside => kept key (by omega)⟩

open Backend.Stock.Proof.ScalarAddSub Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64 in
private theorem frame_1 {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    {event : BlockScanEvent} {record : ScanRecord}
    (events : event ∈ result.blockScans.toList) (records : record ∈ event.output.records)
    {bi j : Nat} {b : Clif.Block} {stm : Clif.Stmt}
    (block : f.blocks[bi]? = some b) (statement : b.body[j]? = some stm)
    (current : record.inst = blockStart f bi + j)
    (form : Form) (subtract left : Bool) (side : subtract = true → left = false) {info : IInfo} {x y z a : Nat} {ty : Clif.Ty}
    (source : event.ctx.insts[record.inst]? = some info)
    (clif : info.clif = some (.binary (if subtract then .isub else .iadd) ty x y))
    (results : info.results = [z]) (statementResults : stm.results = [z])
    (mapped : event.ctx.valueReg? z = some (.vreg a .int))
    {step : Step} (recorded : record.output.step = some step) (emitted : step.decision = .emitted)
    (selectedId : step.rules.getLast? = some (form.rule subtract left).id)
    {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem} (refines : Refines F isem)
    {fr : Clif.Frame} {ρ : Nat → CV}
    (dfg : DFGCons event.ctx (restrict fr (availOf f (availIn f result.ctx) bi j)))
    (held : ValuesHeld (fun v => Demanded record.output.state v ∧
      v ∈ availOf f (availIn f result.ctx) bi j) event.ctx fr (fun k => ρ (aliasNum result.final.alias k)))
    {u v : BitVec ty.width}
    (getX : (restrict fr (availOf f (availIn f result.ctx) bi j)).getAs x ty = .ok u)
    (getY : (restrict fr (availOf f (availIn f result.ctx) bi j)).getAs y ty = .ok v) :
    ∃ ρ', PRun F isem (record.output.emitted.toList.map (·.mapRegs
        (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size + 1)))) ρ ρ' ∧
      VHolds ⟨ty,Clif.Sem.binary (if subtract then .isub else .iadd) u v⟩ (ρ' record.input.base.nextVreg) ∧
      (∀ n, n ≠ record.input.base.nextVreg → ρ' n = ρ n) ∧
      ValuesHeld (fun y => Demanded record.input y ∧
        y ∈ availOf f (availIn f result.ctx) bi (j + 1)) event.ctx
          (withValue fr z ⟨ty,Clif.Sem.binary (if subtract then .isub else .iadd) u v⟩)
          (fun k => ρ' (aliasNum result.final.alias k)) ∧
      (∀ key,key < record.input.base.nextVreg ∨ record.output.state.base.nextVreg ≤ key → ρ' key = ρ key) := by
  have restrictedHeld : ValuesHeld (Demanded record.output.state) event.ctx
      (restrict fr (availOf f (availIn f result.ctx) bi j)) (fun k => ρ (aliasNum result.final.alias k)) := by
    intro x needed val lookup
    have available := restrict_regs_isSome (by rw [lookup]; rfl)
    rw [restrict_regs_of_mem available] at lookup
    exact held x ⟨needed,available⟩ val lookup
  obtain ⟨mi,ρ',outputs,code,upper,execution,value,kept⟩ := stock_lower_addsub_fused_record_values
    run scope events records form subtract left side source clif results mapped recorded emitted selectedId
    refines dfg restrictedHeld getX getY
  have resolved := (stock_lower_record_fresh_result run scope dominated.ssa events records
    source clif results mapped recorded emitted outputs (Nat.le_refl _)).2
  have maps := (stock_lower_record_context run scope events).2.1
  refine ⟨ρ',execution,value,kept,?_,fun key outside => kept key (by omega)⟩
  intro y required val lookup
  by_cases equal : y = z
  · subst y
    simp only [withValue,eq_self,ite_true] at lookup
    cases lookup
    exact ⟨a,mapped,by change VHolds _ (ρ' (aliasNum result.final.alias a)); rw [resolved]; exact value⟩
  · simp only [withValue,ite_eq_right equal] at lookup
    have before := available_before_of_after_not_result block statement required.2
      (by simpa only [statementResults,List.mem_singleton] using equal)
    have demand : Demanded record.output.state y := by
      intro zero
      have count := stock_lower_record_demand_mono run events records recorded emitted y
      change record.output.state.demand[y]! = 0 at zero
      rw [zero] at count
      exact required.1 (Nat.eq_zero_of_le_zero count)
    obtain ⟨key,map,old⟩ := held y ⟨demand,before⟩ val lookup
    have outside := stock_lower_available_alias_outside_record run scope dominated events records
      block statement current before (by rw [← maps]; exact map)
    have different : aliasNum result.final.alias key ≠ record.input.base.nextVreg := by
      rw [upper] at outside
      omega
    exact ⟨key,map,by change VHolds val (ρ' (aliasNum result.final.alias key)); rw [kept _ different]; exact old⟩

open Backend.Stock.Proof.ScalarMul.Fused Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64 in
private theorem frame_2 {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    {event : BlockScanEvent} {record : ScanRecord}
    (events : event ∈ result.blockScans.toList) (records : record ∈ event.output.records)
    {bi j : Nat} {b : Clif.Block} {stm : Clif.Stmt}
    (block : f.blocks[bi]? = some b) (statement : b.body[j]? = some stm)
    (current : record.inst = blockStart f bi + j)
    (fusion : Fusion) {info : IInfo} {x y z a : Nat} {ty : Clif.Ty}
    (source : event.ctx.insts[record.inst]? = some info)
    (clif : info.clif = some (.binary fusion.cop ty (if fusion.left then y else x) (if fusion.left then x else y)))
    (results : info.results = [z]) (statementResults : stm.results = [z])
    (mapped : event.ctx.valueReg? z = some (.vreg a .int))
    {step : Step} (recorded : record.output.step = some step) (emitted : step.decision = .emitted)
    (selectedId : step.rules.getLast? = some fusion.rule.id)
    {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem} (refines : Refines F isem)
    {fr : Clif.Frame} {ρ : Nat → CV}
    (dfg : DFGCons event.ctx (restrict fr (availOf f (availIn f result.ctx) bi j)))
    (held : ValuesHeld (fun v => Demanded record.output.state v ∧
      v ∈ availOf f (availIn f result.ctx) bi j) event.ctx fr (fun k => ρ (aliasNum result.final.alias k)))
    {u v : BitVec ty.width}
    (getX : (restrict fr (availOf f (availIn f result.ctx) bi j)).getAs x ty = .ok u)
    (getY : (restrict fr (availOf f (availIn f result.ctx) bi j)).getAs y ty = .ok v) :
    ∃ ρ', PRun F isem (record.output.emitted.toList.map (·.mapRegs
        (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size + 1)))) ρ ρ' ∧
      VHolds ⟨ty,Clif.Sem.binary fusion.cop (if fusion.left then v else u) (if fusion.left then u else v)⟩ (ρ' record.input.base.nextVreg) ∧
      (∀ n, n ≠ record.input.base.nextVreg → ρ' n = ρ n) ∧
      ValuesHeld (fun y => Demanded record.input y ∧
        y ∈ availOf f (availIn f result.ctx) bi (j + 1)) event.ctx
          (withValue fr z ⟨ty,Clif.Sem.binary fusion.cop (if fusion.left then v else u) (if fusion.left then u else v)⟩)
          (fun k => ρ' (aliasNum result.final.alias k)) ∧
      (∀ key,key < record.input.base.nextVreg ∨ record.output.state.base.nextVreg ≤ key → ρ' key = ρ key) := by
  have restrictedHeld : ValuesHeld (Demanded record.output.state) event.ctx
      (restrict fr (availOf f (availIn f result.ctx) bi j)) (fun k => ρ (aliasNum result.final.alias k)) := by
    intro x needed val lookup
    have available := restrict_regs_isSome (by rw [lookup]; rfl)
    rw [restrict_regs_of_mem available] at lookup
    exact held x ⟨needed,available⟩ val lookup
  obtain ⟨mi,ρ',outputs,code,upper,execution,value,kept⟩ := stock_lower_mul_fused_record_values
    run scope events records fusion source clif results mapped recorded emitted selectedId
    refines dfg restrictedHeld getX getY
  have resolved := (stock_lower_record_fresh_result run scope dominated.ssa events records
    source clif results mapped recorded emitted outputs (Nat.le_refl _)).2
  have maps := (stock_lower_record_context run scope events).2.1
  refine ⟨ρ',execution,value,kept,?_,fun key outside => kept key (by omega)⟩
  intro y required val lookup
  by_cases equal : y = z
  · subst y
    simp only [withValue,eq_self,ite_true] at lookup
    cases lookup
    exact ⟨a,mapped,by change VHolds _ (ρ' (aliasNum result.final.alias a)); rw [resolved]; exact value⟩
  · simp only [withValue,ite_eq_right equal] at lookup
    have before := available_before_of_after_not_result block statement required.2
      (by simpa only [statementResults,List.mem_singleton] using equal)
    have demand : Demanded record.output.state y := by
      intro zero
      have count := stock_lower_record_demand_mono run events records recorded emitted y
      change record.output.state.demand[y]! = 0 at zero
      rw [zero] at count
      exact required.1 (Nat.eq_zero_of_le_zero count)
    obtain ⟨key,map,old⟩ := held y ⟨demand,before⟩ val lookup
    have outside := stock_lower_available_alias_outside_record run scope dominated events records
      block statement current before (by rw [← maps]; exact map)
    have different : aliasNum result.final.alias key ≠ record.input.base.nextVreg := by
      rw [upper] at outside
      omega
    exact ⟨key,map,by change VHolds val (ρ' (aliasNum result.final.alias key)); rw [kept _ different]; exact old⟩

open Backend.Stock.Proof.LogicalSelected Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64 in
private theorem frame_3 {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    {event : BlockScanEvent} {record : ScanRecord}
    (events : event ∈ result.blockScans.toList) (records : record ∈ event.output.records)
    {bi j : Nat} {b : Clif.Block} {stm : Clif.Stmt}
    (block : f.blocks[bi]? = some b) (statement : b.body[j]? = some stm)
    (current : record.inst = blockStart f bi + j)
    (kind : Kind) {info : IInfo} {x y z a : Nat} {ty : Clif.Ty}
    (source : event.ctx.insts[record.inst]? = some info)
    (clif : info.clif = some (.binary kind.cop ty x y))
    (results : info.results = [z]) (statementResults : stm.results = [z])
    (mapped : event.ctx.valueReg? z = some (.vreg a .int))
    {step : Step} (recorded : record.output.step = some step) (emitted : step.decision = .emitted)
    (selectedId : step.rules.getLast? = some kind.rule.id)
    {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem} (refines : Refines F isem)
    {fr : Clif.Frame} {ρ : Nat → CV}
    (dfg : DFGCons event.ctx (restrict fr (availOf f (availIn f result.ctx) bi j)))
    (held : ValuesHeld (fun v => Demanded record.output.state v ∧
      v ∈ availOf f (availIn f result.ctx) bi j) event.ctx fr (fun k => ρ (aliasNum result.final.alias k)))
    {u v : BitVec ty.width}
    (sourceX : (restrict fr (availOf f (availIn f result.ctx) bi j)).getAs x ty = .ok u)
    (sourceY : (restrict fr (availOf f (availIn f result.ctx) bi j)).getAs y ty = .ok v) :
    ∃ ρ', PRun F isem (record.output.emitted.toList.map (·.mapRegs
        (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size + 1)))) ρ ρ' ∧
      VHolds ⟨ty,Clif.Sem.binary kind.cop u v⟩ (ρ' record.input.base.nextVreg) ∧
      (∀ n, n ≠ record.input.base.nextVreg → ρ' n = ρ n) ∧
      ValuesHeld (fun y => Demanded record.input y ∧
        y ∈ availOf f (availIn f result.ctx) bi (j + 1)) event.ctx
          (withValue fr z ⟨ty,Clif.Sem.binary kind.cop u v⟩)
          (fun k => ρ' (aliasNum result.final.alias k)) ∧
      (∀ key,key < record.input.base.nextVreg ∨ record.output.state.base.nextVreg ≤ key → ρ' key = ρ key) := by
  have restrictedHeld : ValuesHeld (Demanded record.output.state) event.ctx
      (restrict fr (availOf f (availIn f result.ctx) bi j)) (fun k => ρ (aliasNum result.final.alias k)) := by
    intro x needed val lookup
    have available := restrict_regs_isSome (by rw [lookup]; rfl)
    rw [restrict_regs_of_mem available] at lookup
    exact held x ⟨needed,available⟩ val lookup
  obtain ⟨mi,ρ',outputs,code,upper,execution,value,kept⟩ := stock_lower_logical_record_values
    run scope events records kind source clif results mapped recorded emitted selectedId
    refines dfg restrictedHeld sourceX sourceY
  have resolved := (stock_lower_record_fresh_result run scope dominated.ssa events records
    source clif results mapped recorded emitted outputs (Nat.le_refl _)).2
  have maps := (stock_lower_record_context run scope events).2.1
  refine ⟨ρ',execution,value,kept,?_,fun key outside => kept key (by omega)⟩
  intro y required val lookup
  by_cases equal : y = z
  · subst y
    simp only [withValue,eq_self,ite_true] at lookup
    cases lookup
    exact ⟨a,mapped,by change VHolds _ (ρ' (aliasNum result.final.alias a)); rw [resolved]; exact value⟩
  · simp only [withValue,ite_eq_right equal] at lookup
    have before := available_before_of_after_not_result block statement required.2
      (by simpa only [statementResults,List.mem_singleton] using equal)
    have demand : Demanded record.output.state y := by
      intro zero
      have count := stock_lower_record_demand_mono run events records recorded emitted y
      change record.output.state.demand[y]! = 0 at zero
      rw [zero] at count
      exact required.1 (Nat.eq_zero_of_le_zero count)
    obtain ⟨key,map,old⟩ := held y ⟨demand,before⟩ val lookup
    have outside := stock_lower_available_alias_outside_record run scope dominated events records
      block statement current before (by rw [← maps]; exact map)
    have different : aliasNum result.final.alias key ≠ record.input.base.nextVreg := by
      rw [upper] at outside
      omega
    exact ⟨key,map,by change VHolds val (ρ' (aliasNum result.final.alias key)); rw [kept _ different]; exact old⟩

open Backend.Stock.Proof.LogicalNot Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64 Backend.Stock.Proof.LogicalSelected in
private theorem frame_4 {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    {event : BlockScanEvent} {record : ScanRecord}
    (events : event ∈ result.blockScans.toList) (records : record ∈ event.output.records)
    {bi j : Nat} {b : Clif.Block} {stm : Clif.Stmt}
    (block : f.blocks[bi]? = some b) (statement : b.body[j]? = some stm)
    (current : record.inst = blockStart f bi + j)
    (kind : Kind) (left : Bool) {info : IInfo} {x y z a : Nat} {ty : Clif.Ty}
    (source : event.ctx.insts[record.inst]? = some info)
    (clif : info.clif = some (.binary kind.cop ty (if left then y else x) (if left then x else y)))
    (results : info.results = [z]) (statementResults : stm.results = [z])
    (mapped : event.ctx.valueReg? z = some (.vreg a .int))
    {step : Step} (recorded : record.output.step = some step) (emitted : step.decision = .emitted)
    (selectedId : step.rules.getLast? = some (notRule kind left).id)
    {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem} (refines : Refines F isem)
    {fr : Clif.Frame} {ρ : Nat → CV}
    (dfg : DFGCons event.ctx (restrict fr (availOf f (availIn f result.ctx) bi j)))
    (held : ValuesHeld (fun v => Demanded record.output.state v ∧
      v ∈ availOf f (availIn f result.ctx) bi j) event.ctx fr (fun k => ρ (aliasNum result.final.alias k)))
    {u v : BitVec ty.width}
    (getX : (restrict fr (availOf f (availIn f result.ctx) bi j)).getAs x ty = .ok u)
    (getY : (restrict fr (availOf f (availIn f result.ctx) bi j)).getAs y ty = .ok v) :
    ∃ ρ', PRun F isem (record.output.emitted.toList.map (·.mapRegs
        (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size + 1)))) ρ ρ' ∧
      VHolds ⟨ty,Clif.Sem.binary kind.cop (if left then v else u) (if left then u else v)⟩ (ρ' record.input.base.nextVreg) ∧
      (∀ n, n ≠ record.input.base.nextVreg → ρ' n = ρ n) ∧
      ValuesHeld (fun y => Demanded record.input y ∧
        y ∈ availOf f (availIn f result.ctx) bi (j + 1)) event.ctx
          (withValue fr z ⟨ty,Clif.Sem.binary kind.cop (if left then v else u) (if left then u else v)⟩)
          (fun k => ρ' (aliasNum result.final.alias k)) ∧
      (∀ key,key < record.input.base.nextVreg ∨ record.output.state.base.nextVreg ≤ key → ρ' key = ρ key) := by
  have restrictedHeld : ValuesHeld (Demanded record.output.state) event.ctx
      (restrict fr (availOf f (availIn f result.ctx) bi j)) (fun k => ρ (aliasNum result.final.alias k)) := by
    intro x needed val lookup
    have available := restrict_regs_isSome (by rw [lookup]; rfl)
    rw [restrict_regs_of_mem available] at lookup
    exact held x ⟨needed,available⟩ val lookup
  obtain ⟨mi,ρ',outputs,code,upper,execution,value,kept⟩ := stock_lower_logical_not_record_values
    run scope events records kind left source clif results mapped recorded emitted selectedId
    refines dfg restrictedHeld getX getY
  have resolved := (stock_lower_record_fresh_result run scope dominated.ssa events records
    source clif results mapped recorded emitted outputs (Nat.le_refl _)).2
  have maps := (stock_lower_record_context run scope events).2.1
  refine ⟨ρ',execution,value,kept,?_,fun key outside => kept key (by omega)⟩
  intro y required val lookup
  by_cases equal : y = z
  · subst y
    simp only [withValue,eq_self,ite_true] at lookup
    cases lookup
    exact ⟨a,mapped,by change VHolds _ (ρ' (aliasNum result.final.alias a)); rw [resolved]; exact value⟩
  · simp only [withValue,ite_eq_right equal] at lookup
    have before := available_before_of_after_not_result block statement required.2
      (by simpa only [statementResults,List.mem_singleton] using equal)
    have demand : Demanded record.output.state y := by
      intro zero
      have count := stock_lower_record_demand_mono run events records recorded emitted y
      change record.output.state.demand[y]! = 0 at zero
      rw [zero] at count
      exact required.1 (Nat.eq_zero_of_le_zero count)
    obtain ⟨key,map,old⟩ := held y ⟨demand,before⟩ val lookup
    have outside := stock_lower_available_alias_outside_record run scope dominated events records
      block statement current before (by rw [← maps]; exact map)
    have different : aliasNum result.final.alias key ≠ record.input.base.nextVreg := by
      rw [upper] at outside
      omega
    exact ⟨key,map,by change VHolds val (ρ' (aliasNum result.final.alias key)); rw [kept _ different]; exact old⟩

open Backend.Stock.Proof.LogicalExtr Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64 in
private theorem frame_5 {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f) (mirrored : Bool)
    {event : BlockScanEvent} {record : ScanRecord}
    (events : event ∈ result.blockScans.toList) (records : record ∈ event.output.records)
    {bi j : Nat} {b : Clif.Block} {stm : Clif.Stmt}
    (block : f.blocks[bi]? = some b) (statement : b.body[j]? = some stm)
    (current : record.inst = blockStart f bi + j)
    {info : IInfo} {x y z a : Nat} {ty : Clif.Ty}
    (source : event.ctx.insts[record.inst]? = some info)
    (clif : info.clif = some (.binary .bor ty x y))
    (results : info.results = [z]) (statementResults : stm.results = [z])
    (mapped : event.ctx.valueReg? z = some (.vreg a .int))
    {step : Step} (recorded : record.output.step = some step) (emitted : step.decision = .emitted)
    (selectedId : step.rules.getLast? = some (extrRule mirrored).id)
    {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem} (refines : Refines F isem)
    {fr : Clif.Frame} {ρ : Nat → CV}
    (dfg : DFGCons event.ctx (restrict fr (availOf f (availIn f result.ctx) bi j)))
    (held : ValuesHeld (fun v => Demanded record.output.state v ∧
      v ∈ availOf f (availIn f result.ctx) bi j) event.ctx fr (fun k => ρ (aliasNum result.final.alias k)))
    {u v : BitVec ty.width}
    (getX : (restrict fr (availOf f (availIn f result.ctx) bi j)).getAs x ty = .ok u)
    (getY : (restrict fr (availOf f (availIn f result.ctx) bi j)).getAs y ty = .ok v) :
    ∃ ρ', PRun F isem (record.output.emitted.toList.map (·.mapRegs
        (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size + 1)))) ρ ρ' ∧
      VHolds ⟨ty,Clif.Sem.binary .bor u v⟩ (ρ' record.input.base.nextVreg) ∧
      (∀ n, n ≠ record.input.base.nextVreg → ρ' n = ρ n) ∧
      ValuesHeld (fun y => Demanded record.input y ∧
        y ∈ availOf f (availIn f result.ctx) bi (j + 1)) event.ctx
          (withValue fr z ⟨ty,Clif.Sem.binary .bor u v⟩)
          (fun k => ρ' (aliasNum result.final.alias k)) ∧
      (∀ key,key < record.input.base.nextVreg ∨ record.output.state.base.nextVreg ≤ key → ρ' key = ρ key) := by
  have restrictedHeld : ValuesHeld (Demanded record.output.state) event.ctx
      (restrict fr (availOf f (availIn f result.ctx) bi j)) (fun k => ρ (aliasNum result.final.alias k)) := by
    intro x needed val lookup
    have available := restrict_regs_isSome (by rw [lookup]; rfl)
    rw [restrict_regs_of_mem available] at lookup
    exact held x ⟨needed,available⟩ val lookup
  obtain ⟨mi,ρ',outputs,code,upper,execution,value,kept⟩ := record_values
    run scope mirrored events records source clif results mapped recorded emitted selectedId
    refines dfg restrictedHeld getX getY
  have resolved := (stock_lower_record_fresh_result run scope dominated.ssa events records
    source clif results mapped recorded emitted outputs (Nat.le_refl _)).2
  have maps := (stock_lower_record_context run scope events).2.1
  refine ⟨ρ',execution,value,kept,?_,fun key outside => kept key (by omega)⟩
  intro y required val lookup
  by_cases equal : y = z
  · subst y
    simp only [withValue,eq_self,ite_true] at lookup
    cases lookup
    exact ⟨a,mapped,by change VHolds _ (ρ' (aliasNum result.final.alias a)); rw [resolved]; exact value⟩
  · simp only [withValue,ite_eq_right equal] at lookup
    have before := available_before_of_after_not_result block statement required.2
      (by simpa only [statementResults,List.mem_singleton] using equal)
    have demand : Demanded record.output.state y := by
      intro zero
      have count := stock_lower_record_demand_mono run events records recorded emitted y
      change record.output.state.demand[y]! = 0 at zero
      rw [zero] at count
      exact required.1 (Nat.eq_zero_of_le_zero count)
    obtain ⟨key,map,old⟩ := held y ⟨demand,before⟩ val lookup
    have outside := stock_lower_available_alias_outside_record run scope dominated events records
      block statement current before (by rw [← maps]; exact map)
    have different : aliasNum result.final.alias key ≠ record.input.base.nextVreg := by
      rw [upper] at outside
      omega
    exact ⟨key,map,by change VHolds val (ρ' (aliasNum result.final.alias key)); rw [kept _ different]; exact old⟩

open Backend.Stock.Proof.LogicalNot Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64 in
private theorem frame_6 {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    {event : BlockScanEvent} {record : ScanRecord}
    (events : event ∈ result.blockScans.toList) (records : record ∈ event.output.records)
    {bi j : Nat} {b : Clif.Block} {stm : Clif.Stmt}
    (block : f.blocks[bi]? = some b) (statement : b.body[j]? = some stm)
    (current : record.inst = blockStart f bi + j)
    {info : IInfo} {y z a : Nat} {ty : Clif.Ty}
    (source : event.ctx.insts[record.inst]? = some info)
    (clif : info.clif = some (.unary .bnot ty y))
    (results : info.results = [z]) (statementResults : stm.results = [z])
    (mapped : event.ctx.valueReg? z = some (.vreg a .int))
    {step : Step} (recorded : record.output.step = some step) (emitted : step.decision = .emitted)
    (selectedId : step.rules.getLast? = some rule_lower_1406.id)
    {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem} (refines : Refines F isem)
    {fr : Clif.Frame} {ρ : Nat → CV}
    (dfg : DFGCons event.ctx (restrict fr (availOf f (availIn f result.ctx) bi j)))
    (held : ValuesHeld (fun v => Demanded record.output.state v ∧
      v ∈ availOf f (availIn f result.ctx) bi j) event.ctx fr (fun k => ρ (aliasNum result.final.alias k)))
    {u : BitVec ty.width}
    (get : (restrict fr (availOf f (availIn f result.ctx) bi j)).getAs y ty = .ok u) :
    ∃ ρ', PRun F isem (record.output.emitted.toList.map (·.mapRegs
        (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size + 1)))) ρ ρ' ∧
      VHolds ⟨ty,Clif.Sem.unary .bnot u⟩ (ρ' record.input.base.nextVreg) ∧
      (∀ n, n ≠ record.input.base.nextVreg → ρ' n = ρ n) ∧
      ValuesHeld (fun y => Demanded record.input y ∧
        y ∈ availOf f (availIn f result.ctx) bi (j + 1)) event.ctx
          (withValue fr z ⟨ty,Clif.Sem.unary .bnot u⟩)
          (fun k => ρ' (aliasNum result.final.alias k)) ∧
      (∀ key,key < record.input.base.nextVreg ∨ record.output.state.base.nextVreg ≤ key → ρ' key = ρ key) := by
  have restrictedHeld : ValuesHeld (Demanded record.output.state) event.ctx
      (restrict fr (availOf f (availIn f result.ctx) bi j)) (fun k => ρ (aliasNum result.final.alias k)) := by
    intro x needed val lookup
    have available := restrict_regs_isSome (by rw [lookup]; rfl)
    rw [restrict_regs_of_mem available] at lookup
    exact held x ⟨needed,available⟩ val lookup
  obtain ⟨mi,ρ',outputs,code,upper,execution,value,kept⟩ := stock_lower_not_xor_record_values
    run scope events records source clif results mapped recorded emitted selectedId
    refines dfg restrictedHeld get
  have resolved := (stock_lower_record_fresh_result run scope dominated.ssa events records
    source clif results mapped recorded emitted outputs (Nat.le_refl _)).2
  have maps := (stock_lower_record_context run scope events).2.1
  refine ⟨ρ',execution,value,kept,?_,fun key outside => kept key (by omega)⟩
  intro y required val lookup
  by_cases equal : y = z
  · subst y
    simp only [withValue,eq_self,ite_true] at lookup
    cases lookup
    exact ⟨a,mapped,by change VHolds _ (ρ' (aliasNum result.final.alias a)); rw [resolved]; exact value⟩
  · simp only [withValue,ite_eq_right equal] at lookup
    have before := available_before_of_after_not_result block statement required.2
      (by simpa only [statementResults,List.mem_singleton] using equal)
    have demand : Demanded record.output.state y := by
      intro zero
      have count := stock_lower_record_demand_mono run events records recorded emitted y
      change record.output.state.demand[y]! = 0 at zero
      rw [zero] at count
      exact required.1 (Nat.eq_zero_of_le_zero count)
    obtain ⟨key,map,old⟩ := held y ⟨demand,before⟩ val lookup
    have outside := stock_lower_available_alias_outside_record run scope dominated events records
      block statement current before (by rw [← maps]; exact map)
    have different : aliasNum result.final.alias key ≠ record.input.base.nextVreg := by
      rw [upper] at outside
      omega
    exact ⟨key,map,by change VHolds val (ρ' (aliasNum result.final.alias key)); rw [kept _ different]; exact old⟩

open Backend.Stock.Proof.Bnot Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64 in
private theorem frame_7 {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    {event : BlockScanEvent} {record : ScanRecord}
    (events : event ∈ result.blockScans.toList) (records : record ∈ event.output.records)
    {bi j : Nat} {b : Clif.Block} {stm : Clif.Stmt}
    (block : f.blocks[bi]? = some b) (statement : b.body[j]? = some stm)
    (current : record.inst = blockStart f bi + j)
    (shifted : Bool) {info : IInfo} {y z a : Nat} {ty : Clif.Ty}
    (source : event.ctx.insts[record.inst]? = some info)
    (clif : info.clif = some (.unary .bnot ty y))
    (results : info.results = [z]) (statementResults : stm.results = [z])
    (mapped : event.ctx.valueReg? z = some (.vreg a .int))
    {step : Step} (recorded : record.output.step = some step) (emitted : step.decision = .emitted)
    (selectedId : step.rules.getLast? = some (rule shifted).id)
    {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem} (refines : Refines F isem)
    {fr : Clif.Frame} {ρ : Nat → CV}
    (dfg : DFGCons event.ctx (restrict fr (availOf f (availIn f result.ctx) bi j)))
    (held : ValuesHeld (fun v => Demanded record.output.state v ∧
      v ∈ availOf f (availIn f result.ctx) bi j) event.ctx fr (fun k => ρ (aliasNum result.final.alias k)))
    {u : BitVec ty.width}
    (get : (restrict fr (availOf f (availIn f result.ctx) bi j)).getAs y ty = .ok u) :
    ∃ ρ', PRun F isem (record.output.emitted.toList.map (·.mapRegs
        (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size + 1)))) ρ ρ' ∧
      VHolds ⟨ty,Clif.Sem.unary .bnot u⟩ (ρ' record.input.base.nextVreg) ∧
      (∀ n, n ≠ record.input.base.nextVreg → ρ' n = ρ n) ∧
      ValuesHeld (fun y => Demanded record.input y ∧
        y ∈ availOf f (availIn f result.ctx) bi (j + 1)) event.ctx
          (withValue fr z ⟨ty,Clif.Sem.unary .bnot u⟩)
          (fun k => ρ' (aliasNum result.final.alias k)) ∧
      (∀ key,key < record.input.base.nextVreg ∨ record.output.state.base.nextVreg ≤ key → ρ' key = ρ key) := by
  have restrictedHeld : ValuesHeld (Demanded record.output.state) event.ctx
      (restrict fr (availOf f (availIn f result.ctx) bi j)) (fun k => ρ (aliasNum result.final.alias k)) := by
    intro x needed val lookup
    have available := restrict_regs_isSome (by rw [lookup]; rfl)
    rw [restrict_regs_of_mem available] at lookup
    exact held x ⟨needed,available⟩ val lookup
  obtain ⟨mi,ρ',outputs,code,upper,execution,value,kept⟩ := stock_lower_bnot_record_values
    run scope events records shifted source clif results mapped recorded emitted selectedId
    refines dfg restrictedHeld get
  have resolved := (stock_lower_record_fresh_result run scope dominated.ssa events records
    source clif results mapped recorded emitted outputs (Nat.le_refl _)).2
  have maps := (stock_lower_record_context run scope events).2.1
  refine ⟨ρ',execution,value,kept,?_,fun key outside => kept key (by omega)⟩
  intro y required val lookup
  by_cases equal : y = z
  · subst y
    simp only [withValue,eq_self,ite_true] at lookup
    cases lookup
    exact ⟨a,mapped,by change VHolds _ (ρ' (aliasNum result.final.alias a)); rw [resolved]; exact value⟩
  · simp only [withValue,ite_eq_right equal] at lookup
    have before := available_before_of_after_not_result block statement required.2
      (by simpa only [statementResults,List.mem_singleton] using equal)
    have demand : Demanded record.output.state y := by
      intro zero
      have count := stock_lower_record_demand_mono run events records recorded emitted y
      change record.output.state.demand[y]! = 0 at zero
      rw [zero] at count
      exact required.1 (Nat.eq_zero_of_le_zero count)
    obtain ⟨key,map,old⟩ := held y ⟨demand,before⟩ val lookup
    have outside := stock_lower_available_alias_outside_record run scope dominated events records
      block statement current before (by rw [← maps]; exact map)
    have different : aliasNum result.final.alias key ≠ record.input.base.nextVreg := by
      rw [upper] at outside
      omega
    exact ⟨key,map,by change VHolds val (ρ' (aliasNum result.final.alias key)); rw [kept _ different]; exact old⟩

open Backend.Stock.Proof Backend.Proof Backend.Proof.Driver Backend.Proof.Driver.Fix Isle Isle.Interp Isle.Aarch64 in
private theorem frame_8 {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    {event : BlockScanEvent} {record : ScanRecord}
    (events : event ∈ result.blockScans.toList) (records : record ∈ event.output.records)
    {bi j : Nat} {b : Clif.Block} {stm : Clif.Stmt}
    (block : f.blocks[bi]? = some b) (statement : b.body[j]? = some stm)
    (current : record.inst = blockStart f bi + j)
    {info : IInfo} {z a x y n : Nat} {ty : Clif.Ty} (subtract : Bool) (width : ty.width ≤ 64)
    (source : event.ctx.insts[record.inst]? = some info)
    (clif : info.clif = some (.binary (if subtract then .isub else .iadd) ty x y))
    (results : info.results = [z]) (statementResults : stm.results = [z])
    (mapped : event.ctx.valueReg? z = some (.vreg a .int))
    {step : Step} (recorded : record.output.step = some step) (emitted : step.decision = .emitted)
    {next : State} {out : V} {evalTrace : Array RuleId} {trace : List RuleId}
    (evalRun : (evalExpr program (Stock.sem event.ctx) {} (n + 40)
      (if subtract then rule_lower_801 else rule_lower_86).rhs
      (env3 (.ty (.int ty.width)) (.value x) (.value y))).run
        (scanState record.input record.inst, #[]) = .ok (some out, next, evalTrace))
    (rootRun : Stock.runTerm event.ctx "lower" [.inst record.inst] (scanState record.input record.inst) =
      .ok (some out, next, trace))
    {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem} (refines : Refines F isem)
    {fr : Clif.Frame} {ρ : Nat → CV}
    (held : ValuesHeld (fun v => Demanded record.output.state v ∧
      v ∈ availOf f (availIn f result.ctx) bi j) event.ctx fr (fun k => ρ (aliasNum result.final.alias k)))
    {u v : BitVec ty.width} (sourceX : fr.getAs x ty = .ok u) (sourceY : fr.getAs y ty = .ok v) :
    ∃ ρ', PRun F isem (record.output.emitted.toList.map (·.mapRegs
        (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size + 1)))) ρ ρ' ∧
      VHolds ⟨ty, Clif.Sem.binary (if subtract then .isub else .iadd) u v⟩ (ρ' record.input.base.nextVreg) ∧
      (∀ key, key ≠ record.input.base.nextVreg → ρ' key = ρ key) ∧
      ValuesHeld (fun y => Demanded record.input y ∧
        y ∈ availOf f (availIn f result.ctx) bi (j + 1)) event.ctx
          (withValue fr z ⟨ty, Clif.Sem.binary (if subtract then .isub else .iadd) u v⟩)
          (fun k => ρ' (aliasNum result.final.alias k)) ∧
      (∀ key,key < record.input.base.nextVreg ∨ record.output.state.base.nextVreg ≤ key → ρ' key = ρ key) := by
  have coverage := stock_lower_alu_operand_coverage run scope dominated events records
    block statement current subtract width source clif results mapped recorded emitted evalRun rootRun
  have operands := held.mono coverage
  exact frame_0 run scope dominated events records block statement current
    subtract width source clif results statementResults mapped recorded emitted evalRun rootRun
    refines operands held sourceX sourceY

open Backend.Stock.Proof Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64 in
private theorem frame_9 {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    {event : BlockScanEvent} {record : ScanRecord}
    (events : event ∈ result.blockScans.toList) (records : record ∈ event.output.records)
    {bi j : Nat} {b : Clif.Block} {stm : Clif.Stmt}
    (block : f.blocks[bi]? = some b) (statement : b.body[j]? = some stm)
    (current : record.inst = blockStart f bi + j)
    {info : IInfo} {z a x y : Nat} {ty : Clif.Ty} (subtract : Bool)
    (source : event.ctx.insts[record.inst]? = some info)
    (clif : info.clif = some (.binary (if subtract then .isub else .iadd) ty x y))
    (results : info.results = [z]) (statementResults : stm.results = [z])
    (mapped : event.ctx.valueReg? z = some (.vreg a .int))
    {step : Step} (recorded : record.output.step = some step) (emitted : step.decision = .emitted)
    (selectedId : step.rules.getLast? = some (if subtract then rule_lower_801 else rule_lower_86).id)
    {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem} (refines : Refines F isem)
    {fr : Clif.Frame} {ρ : Nat → CV}
    (held : ValuesHeld (fun v => Demanded record.output.state v ∧
      v ∈ availOf f (availIn f result.ctx) bi j) event.ctx fr (fun k => ρ (aliasNum result.final.alias k)))
    {u v : BitVec ty.width} (sourceX : fr.getAs x ty = .ok u) (sourceY : fr.getAs y ty = .ok v) :
    ∃ ρ', PRun F isem (record.output.emitted.toList.map (·.mapRegs
        (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size + 1)))) ρ ρ' ∧
      VHolds ⟨ty, Clif.Sem.binary (if subtract then .isub else .iadd) u v⟩ (ρ' record.input.base.nextVreg) ∧
      (∀ key, key ≠ record.input.base.nextVreg → ρ' key = ρ key) ∧
      ValuesHeld (fun y => Demanded record.input y ∧
        y ∈ availOf f (availIn f result.ctx) bi (j + 1)) event.ctx
          (withValue fr z ⟨ty, Clif.Sem.binary (if subtract then .isub else .iadd) u v⟩)
          (fun k => ρ' (aliasNum result.final.alias k)) ∧
      (∀ key,key < record.input.base.nextVreg ∨ record.output.state.base.nextVreg ≤ key → ρ' key = ρ key) := by
  obtain ⟨width, out, next, trace, rhsTrace, rootRun, evalRun⟩ := stock_lower_alu_selected_receipts
    run scope events records subtract source clif recorded emitted selectedId
  exact frame_8 run scope dominated events records block statement current
    subtract width source clif results statementResults mapped recorded emitted (n := 999959) evalRun rootRun
    refines held sourceX sourceY

open Backend.Stock.Proof.ScalarAddSub Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64 in
private theorem frame_10 {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    {event : BlockScanEvent} {record : ScanRecord}
    (events : event ∈ result.blockScans.toList) (records : record ∈ event.output.records)
    {bi j : Nat} {b : Clif.Block} {stm : Clif.Stmt}
    (block : f.blocks[bi]? = some b) (statement : b.body[j]? = some stm)
    (current : record.inst = blockStart f bi + j)
    (subtract : Bool) {info : IInfo} {x y z a : Nat} {ty : Clif.Ty}
    (source : event.ctx.insts[record.inst]? = some info)
    (clif : info.clif = some (.binary (if subtract then .isub else .iadd) ty x y))
    (results : info.results = [z]) (statementResults : stm.results = [z])
    (mapped : event.ctx.valueReg? z = some (.vreg a .int))
    {step : Step} (recorded : record.output.step = some step) (emitted : step.decision = .emitted)
    {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem} (refines : Refines F isem)
    {fr : Clif.Frame} {ρ : Nat → CV}
    (dfg : DFGCons event.ctx (restrict fr (availOf f (availIn f result.ctx) bi j)))
    (held : ValuesHeld (fun v => Demanded record.output.state v ∧
      v ∈ availOf f (availIn f result.ctx) bi j) event.ctx fr (fun k => ρ (aliasNum result.final.alias k)))
    {u v : BitVec ty.width}
    (getX : (restrict fr (availOf f (availIn f result.ctx) bi j)).getAs x ty = .ok u)
    (getY : (restrict fr (availOf f (availIn f result.ctx) bi j)).getAs y ty = .ok v) :
    ∃ ρ', PRun F isem (record.output.emitted.toList.map (·.mapRegs
        (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size + 1)))) ρ ρ' ∧
      VHolds ⟨ty,Clif.Sem.binary (if subtract then .isub else .iadd) u v⟩ (ρ' record.input.base.nextVreg) ∧
      (∀ n, n ≠ record.input.base.nextVreg → ρ' n = ρ n) ∧
      ValuesHeld (fun y => Demanded record.input y ∧
        y ∈ availOf f (availIn f result.ctx) bi (j + 1)) event.ctx
          (withValue fr z ⟨ty,Clif.Sem.binary (if subtract then .isub else .iadd) u v⟩)
          (fun k => ρ' (aliasNum result.final.alias k)) ∧
      (∀ key,key < record.input.base.nextVreg ∨ record.output.state.base.nextVreg ≤ key → ρ' key = ρ key) := by
  obtain ⟨receipt⟩ := stock_lower_record_selection run events records recorded emitted
  have inv := (stock_lower_record_context run scope events).1
  have member := stock_addsub_selected_rule_ids inv subtract source clif receipt.selected
  have availableX := restrict_regs_isSome (by rw [getAs_ok getX]; rfl)
  have availableY := restrict_regs_isSome (by rw [getAs_ok getY]; rfl)
  have originalX : fr.getAs x ty = .ok u :=
    (getAs_congr (fr := fr) (fr' := restrict fr (availOf f (availIn f result.ctx) bi j))
      (x := x) (ty := ty) (restrict_regs_of_mem availableX)).symm.trans getX
  have originalY : fr.getAs y ty = .ok v :=
    (getAs_congr (fr := fr) (fr' := restrict fr (availOf f (availIn f result.ctx) bi j))
      (x := y) (ty := ty) (restrict_regs_of_mem availableY)).symm.trans getY
  cases subtract
  · simp only [Bool.false_eq_true,ite_false,ite_true,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with id595 | id597 | id596 | id598 | id590 | id589 | id592 | id591 | id594 | id593 | id588
    · have last : step.rules.getLast? = some 595 := by
        rw [receipt.rules,receipt.selected.last_rule,id595]
      exact frame_1 run scope dominated events records block statement current
        .shifted false false (by simp) source clif results statementResults mapped recorded emitted last refines dfg held getX getY
    · have last : step.rules.getLast? = some 597 := by
        rw [receipt.rules,receipt.selected.last_rule,id597]
      exact frame_2 run scope dominated events records
        block statement current .addRight source clif results statementResults mapped recorded emitted last refines dfg held getX getY
    · have last : step.rules.getLast? = some 596 := by
        rw [receipt.rules,receipt.selected.last_rule,id596]
      exact frame_1 run scope dominated events records block statement current
        .shifted false true (by simp) source clif results statementResults mapped recorded emitted last refines dfg held getX getY
    · have last : step.rules.getLast? = some 598 := by
        rw [receipt.rules,receipt.selected.last_rule,id598]
      exact frame_2 run scope dominated events records
        block statement current .addLeft (x := y) (y := x) source clif results statementResults mapped recorded emitted last refines dfg held getY getX
    · have last : step.rules.getLast? = some 590 := by
        rw [receipt.rules,receipt.selected.last_rule,id590]
      exact frame_1 run scope dominated events records block statement current
        .immediate false true (by simp) source clif results statementResults mapped recorded emitted last refines dfg held getX getY
    · have last : step.rules.getLast? = some 589 := by
        rw [receipt.rules,receipt.selected.last_rule,id589]
      exact frame_1 run scope dominated events records block statement current
        .immediate false false (by simp) source clif results statementResults mapped recorded emitted last refines dfg held getX getY
    · have last : step.rules.getLast? = some 592 := by
        rw [receipt.rules,receipt.selected.last_rule,id592]
      exact frame_1 run scope dominated events records block statement current
        .negative false true (by simp) source clif results statementResults mapped recorded emitted last refines dfg held getX getY
    · have last : step.rules.getLast? = some 591 := by
        rw [receipt.rules,receipt.selected.last_rule,id591]
      exact frame_1 run scope dominated events records block statement current
        .negative false false (by simp) source clif results statementResults mapped recorded emitted last refines dfg held getX getY
    · have last : step.rules.getLast? = some 594 := by
        rw [receipt.rules,receipt.selected.last_rule,id594]
      exact frame_1 run scope dominated events records block statement current
        .extended false true (by simp) source clif results statementResults mapped recorded emitted last refines dfg held getX getY
    · have last : step.rules.getLast? = some 593 := by
        rw [receipt.rules,receipt.selected.last_rule,id593]
      exact frame_1 run scope dominated events records block statement current
        .extended false false (by simp) source clif results statementResults mapped recorded emitted last refines dfg held getX getY
    · have last : step.rules.getLast? = some 588 := by
        rw [receipt.rules,receipt.selected.last_rule,id588]
      exact frame_9 run scope dominated events records block statement current false
        source clif results statementResults mapped recorded emitted last refines held originalX originalY
  · simp only [Bool.false_eq_true,ite_false,ite_true,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with id747 | id748 | id599 | id746 | id749 | id745
    · have last : step.rules.getLast? = some 747 := by
        rw [receipt.rules,receipt.selected.last_rule,id747]
      exact frame_1 run scope dominated events records block statement current
        .negative true false (by simp) source clif results statementResults mapped recorded emitted last refines dfg held getX getY
    · have last : step.rules.getLast? = some 748 := by
        rw [receipt.rules,receipt.selected.last_rule,id748]
      exact frame_1 run scope dominated events records block statement current
        .extended true false (by simp) source clif results statementResults mapped recorded emitted last refines dfg held getX getY
    · have last : step.rules.getLast? = some 599 := by
        rw [receipt.rules,receipt.selected.last_rule,id599]
      exact frame_2 run scope dominated events records
        block statement current .subRight source clif results statementResults mapped recorded emitted last refines dfg held getX getY
    · have last : step.rules.getLast? = some 746 := by
        rw [receipt.rules,receipt.selected.last_rule,id746]
      exact frame_1 run scope dominated events records block statement current
        .immediate true false (by simp) source clif results statementResults mapped recorded emitted last refines dfg held getX getY
    · have last : step.rules.getLast? = some 749 := by
        rw [receipt.rules,receipt.selected.last_rule,id749]
      exact frame_1 run scope dominated events records block statement current
        .shifted true false (by simp) source clif results statementResults mapped recorded emitted last refines dfg held getX getY
    · have last : step.rules.getLast? = some 745 := by
        rw [receipt.rules,receipt.selected.last_rule,id745]
      exact frame_9 run scope dominated events records block statement current true
        source clif results statementResults mapped recorded emitted last refines held originalX originalY

open Backend.Stock.Proof.ScalarAddSub Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64 in
private theorem frame_11 {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    {event : BlockScanEvent} {record : ScanRecord}
    (events : event ∈ result.blockScans.toList) (records : record ∈ event.output.records)
    {bi j : Nat} {b : Clif.Block} {stm : Clif.Stmt}
    (block : f.blocks[bi]? = some b) (statement : b.body[j]? = some stm)
    (current : record.inst = blockStart f bi + j)
    (subtract : Bool) {info : IInfo} {x y z a : Nat} {ty : Clif.Ty}
    (source : event.ctx.insts[record.inst]? = some info)
    (clif : info.clif = some (.binary (if subtract then .isub else .iadd) ty x y))
    (results : info.results = [z]) (statementResults : stm.results = [z])
    (mapped : event.ctx.valueReg? z = some (.vreg a .int))
    {step : Step} (recorded : record.output.step = some step) (emitted : step.decision = .emitted)
    {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem} (refines : Refines F isem)
    {fr : Clif.Frame} {ρ : Nat → CV}
    (dfg : DFGCons event.ctx (restrict fr (availOf f (availIn f result.ctx) bi j)))
    (held : ValuesHeld (fun v => Demanded record.output.state v ∧
      v ∈ availOf f (availIn f result.ctx) bi j) event.ctx fr (fun k => ρ (aliasNum result.final.alias k)))
    {u v : BitVec ty.width}
    (getX : (restrict fr (availOf f (availIn f result.ctx) bi j)).getAs x ty = .ok u)
    (getY : (restrict fr (availOf f (availIn f result.ctx) bi j)).getAs y ty = .ok v)
    {env : Clif.Env} {cp : Clif.Program} {fr' : Clif.Frame} {cm cm' : Clif.Mem}
    (sourceStep : SourceInstResult env cp event.ctx record.inst (fr,cm) (fr',cm')) :
    ∃ ρ', PRun F isem (record.output.emitted.toList.map (·.mapRegs
        (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size + 1)))) ρ ρ' ∧
      VHolds ⟨ty,Clif.Sem.binary (if subtract then .isub else .iadd) u v⟩ (ρ' record.input.base.nextVreg) ∧
      cm' = cm ∧
      (∀ n, n ≠ record.input.base.nextVreg → ρ' n = ρ n) ∧
      ValuesHeld (fun y => Demanded record.input y ∧
        y ∈ availOf f (availIn f result.ctx) bi (j + 1)) event.ctx
          fr'
          (fun k => ρ' (aliasNum result.final.alias k)) ∧
      (∀ key,key < record.input.base.nextVreg ∨ record.output.state.base.nextVreg ≤ key → ρ' key = ρ key) := by
  have sourceProof := sourceStep
  obtain ⟨info',inst,vals,regs,rest,found,original,body,evaluated,written,updated⟩ := sourceProof
  have sameInfo := Option.some.inj (found.symm.trans source)
  subst info'
  have sameInst := Option.some.inj (original.symm.trans clif)
  subst inst
  have availableX := restrict_regs_isSome (by rw [getAs_ok getX]; rfl)
  have availableY := restrict_regs_isSome (by rw [getAs_ok getY]; rfl)
  have originalX : fr.getAs x ty = .ok u :=
    (getAs_congr (fr := fr) (fr' := restrict fr (availOf f (availIn f result.ctx) bi j))
      (x := x) (ty := ty) (restrict_regs_of_mem availableX)).symm.trans getX
  have originalY : fr.getAs y ty = .ok v :=
    (getAs_congr (fr := fr) (fr' := restrict fr (availOf f (availIn f result.ctx) bi j))
      (x := y) (ty := ty) (restrict_regs_of_mem availableY)).symm.trans getY
  have computed : instOutcome env cp fr cm (.binary (if subtract then .isub else .iadd) ty x y) =
      .ok ([⟨ty,Clif.Sem.binary (if subtract then .isub else .iadd) u v⟩],cm) := by
    cases subtract <;> simp [instOutcome,Clif.evalInst,Clif.BinaryOp.isShift,originalX,originalY]
  have equal := Prod.mk.inj (Clif.Res.ok.inj (evaluated.symm.trans computed))
  have memEq : cm' = cm := equal.2
  have evaluatedValue : instOutcome env cp fr cm (.binary (if subtract then .isub else .iadd) ty x y) =
      .ok ([⟨ty,Clif.Sem.binary (if subtract then .isub else .iadd) u v⟩],cm') := by rw [memEq]; exact computed
  obtain ⟨ρ',execution,value,kept,installed,interval⟩ := frame_10
    run scope dominated events records block statement current subtract source clif results statementResults
    mapped recorded emitted refines dfg held getX getY
  have post := source_single_result_values source clif results sourceStep evaluatedValue installed
  exact ⟨ρ',execution,value,memEq,kept,post,interval⟩

open Backend.Stock.Proof.ScalarAddSub Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64 in
private theorem frame_12 {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    {event : BlockScanEvent} {record : ScanRecord}
    (events : event ∈ result.blockScans.toList) (records : record ∈ event.output.records)
    {bi j : Nat} {b : Clif.Block} {stm : Clif.Stmt}
    (block : f.blocks[bi]? = some b) (statement : b.body[j]? = some stm)
    (current : record.inst = blockStart f bi + j)
    (subtract : Bool) {info : IInfo} {x y z a : Nat} {ty : Clif.Ty}
    (source : event.ctx.insts[record.inst]? = some info)
    (clif : info.clif = some (.binary (if subtract then .isub else .iadd) ty x y))
    (results : info.results = [z]) (statementResults : stm.results = [z])
    (mapped : event.ctx.valueReg? z = some (.vreg a .int))
    {step : Step} (recorded : record.output.step = some step) (emitted : step.decision = .emitted)
    {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem} (refines : Refines F isem)
    {fr : Clif.Frame} {ρ : Nat → CV}
    (dfg : DFGCons event.ctx (restrict fr (availOf f (availIn f result.ctx) bi j)))
    (held : ValuesHeld (fun v => Demanded record.output.state v ∧
      v ∈ availOf f (availIn f result.ctx) bi j) event.ctx fr (fun k => ρ (aliasNum result.final.alias k)))
    {env : Clif.Env} {cp : Clif.Program} {fr' : Clif.Frame} {cm cm' : Clif.Mem}
    (sourceStep : SourceInstResult env cp event.ctx record.inst (fr,cm) (fr',cm')) :
    ∃ (u v : BitVec ty.width) (ρ' : Nat → CV),
      (restrict fr (availOf f (availIn f result.ctx) bi j)).getAs x ty = .ok u ∧
      (restrict fr (availOf f (availIn f result.ctx) bi j)).getAs y ty = .ok v ∧ PRun F isem (record.output.emitted.toList.map (·.mapRegs
        (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size + 1)))) ρ ρ' ∧
      VHolds ⟨ty,Clif.Sem.binary (if subtract then .isub else .iadd) u v⟩ (ρ' record.input.base.nextVreg) ∧
      cm' = cm ∧
      (∀ n, n ≠ record.input.base.nextVreg → ρ' n = ρ n) ∧
      ValuesHeld (fun y => Demanded record.input y ∧
        y ∈ availOf f (availIn f result.ctx) bi (j + 1)) event.ctx
          fr'
          (fun k => ρ' (aliasNum result.final.alias k)) ∧
      (∀ key,key < record.input.base.nextVreg ∨ record.output.state.base.nextVreg ≤ key → ρ' key = ρ key) := by
  obtain ⟨u,v,getX,getY⟩ := stock_lower_addsub_source_operands run scope dominated events block statement current subtract source clif sourceStep
  obtain ⟨ρ',execution,value,memEq,kept,post,interval⟩ := frame_11
    run scope dominated events records block statement current subtract source clif results statementResults
    mapped recorded emitted refines dfg held getX getY sourceStep
  exact ⟨u,v,ρ',getX,getY,execution,value,memEq,kept,post,interval⟩

open Backend.Stock.Proof.LogicalComplete Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64 LogicalSelected in
private theorem frame_13 {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    {event : BlockScanEvent} {record : ScanRecord}
    (events : event ∈ result.blockScans.toList) (records : record ∈ event.output.records)
    {bi j : Nat} {b : Clif.Block} {stm : Clif.Stmt}
    (block : f.blocks[bi]? = some b) (statement : b.body[j]? = some stm)
    (current : record.inst = blockStart f bi + j)
    (kind : Kind) {info : IInfo} {x y z a : Nat} {ty : Clif.Ty}
    (source : event.ctx.insts[record.inst]? = some info)
    (clif : info.clif = some (.binary kind.cop ty x y))
    (results : info.results = [z]) (statementResults : stm.results = [z])
    (mapped : event.ctx.valueReg? z = some (.vreg a .int))
    {step : Step} (recorded : record.output.step = some step) (emitted : step.decision = .emitted)
    (selectedId : step.rules.getLast? = some kind.rule.id)
    {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem} (refines : Refines F isem)
    {fr : Clif.Frame} {ρ : Nat → CV}
    (dfg : DFGCons event.ctx (restrict fr (availOf f (availIn f result.ctx) bi j)))
    (held : ValuesHeld (fun v => Demanded record.output.state v ∧
      v ∈ availOf f (availIn f result.ctx) bi j) event.ctx fr (fun k => ρ (aliasNum result.final.alias k)))
    {u v : BitVec ty.width}
    (getX : (restrict fr (availOf f (availIn f result.ctx) bi j)).getAs x ty = .ok u)
    (getY : (restrict fr (availOf f (availIn f result.ctx) bi j)).getAs y ty = .ok v)
    {env : Clif.Env} {cp : Clif.Program} {fr' : Clif.Frame} {cm cm' : Clif.Mem}
    (sourceStep : SourceInstResult env cp event.ctx record.inst (fr,cm) (fr',cm')) :
    ∃ ρ', PRun F isem (record.output.emitted.toList.map (·.mapRegs
        (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size + 1)))) ρ ρ' ∧
      VHolds ⟨ty,Clif.Sem.binary kind.cop u v⟩ (ρ' record.input.base.nextVreg) ∧
      cm' = cm ∧
      (∀ n, n ≠ record.input.base.nextVreg → ρ' n = ρ n) ∧
      ValuesHeld (fun y => Demanded record.input y ∧
        y ∈ availOf f (availIn f result.ctx) bi (j + 1)) event.ctx
          fr'
          (fun k => ρ' (aliasNum result.final.alias k)) ∧
      (∀ key,key < record.input.base.nextVreg ∨ record.output.state.base.nextVreg ≤ key → ρ' key = ρ key) := by
  have sourceProof := sourceStep
  obtain ⟨info',inst,vals,regs,rest,found,original,body,evaluated,written,updated⟩ := sourceProof
  have sameInfo := Option.some.inj (found.symm.trans source)
  subst info'
  have sameInst := Option.some.inj (original.symm.trans clif)
  subst inst
  have availableX := restrict_regs_isSome (by rw [getAs_ok getX]; rfl)
  have availableY := restrict_regs_isSome (by rw [getAs_ok getY]; rfl)
  have originalX : fr.getAs x ty = .ok u :=
    (getAs_congr (fr := fr) (fr' := restrict fr (availOf f (availIn f result.ctx) bi j))
      (x := x) (ty := ty) (restrict_regs_of_mem availableX)).symm.trans getX
  have originalY : fr.getAs y ty = .ok v :=
    (getAs_congr (fr := fr) (fr' := restrict fr (availOf f (availIn f result.ctx) bi j))
      (x := y) (ty := ty) (restrict_regs_of_mem availableY)).symm.trans getY
  have computed : instOutcome env cp fr cm (.binary kind.cop ty x y) =
      .ok ([⟨ty,Clif.Sem.binary kind.cop u v⟩],cm) := by
    cases kind <;> simp [Kind.cop,instOutcome,Clif.evalInst,Clif.BinaryOp.isShift,originalX,originalY]
  have equal := Prod.mk.inj (Clif.Res.ok.inj (evaluated.symm.trans computed))
  have memEq : cm' = cm := equal.2
  have evaluatedValue : instOutcome env cp fr cm (.binary kind.cop ty x y) =
      .ok ([⟨ty,Clif.Sem.binary kind.cop u v⟩],cm') := by rw [memEq]; exact computed
  obtain ⟨ρ',execution,value,kept,installed,interval⟩ := frame_3
    run scope dominated events records block statement current kind source clif results statementResults
    mapped recorded emitted selectedId refines dfg held getX getY
  have post := source_single_result_values source clif results sourceStep evaluatedValue installed
  exact ⟨ρ',execution,value,memEq,kept,post,interval⟩

open Backend.Stock.Proof.LogicalComplete Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64 LogicalSelected in
private theorem frame_14 {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    {event : BlockScanEvent} {record : ScanRecord}
    (events : event ∈ result.blockScans.toList) (records : record ∈ event.output.records)
    {bi j : Nat} {b : Clif.Block} {stm : Clif.Stmt}
    (block : f.blocks[bi]? = some b) (statement : b.body[j]? = some stm)
    (current : record.inst = blockStart f bi + j)
    (kind : Kind) {info : IInfo} {x y z a : Nat} {ty : Clif.Ty}
    (source : event.ctx.insts[record.inst]? = some info)
    (clif : info.clif = some (.binary kind.cop ty x y))
    (results : info.results = [z]) (statementResults : stm.results = [z])
    (mapped : event.ctx.valueReg? z = some (.vreg a .int))
    {step : Step} (recorded : record.output.step = some step) (emitted : step.decision = .emitted)
    (selectedId : step.rules.getLast? = some kind.rule.id)
    {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem} (refines : Refines F isem)
    {fr : Clif.Frame} {ρ : Nat → CV}
    (dfg : DFGCons event.ctx (restrict fr (availOf f (availIn f result.ctx) bi j)))
    (held : ValuesHeld (fun v => Demanded record.output.state v ∧
      v ∈ availOf f (availIn f result.ctx) bi j) event.ctx fr (fun k => ρ (aliasNum result.final.alias k)))
    {env : Clif.Env} {cp : Clif.Program} {fr' : Clif.Frame} {cm cm' : Clif.Mem}
    (sourceStep : SourceInstResult env cp event.ctx record.inst (fr,cm) (fr',cm')) :
    ∃ (u v : BitVec ty.width) (ρ' : Nat → CV),
      (restrict fr (availOf f (availIn f result.ctx) bi j)).getAs x ty = .ok u ∧
      (restrict fr (availOf f (availIn f result.ctx) bi j)).getAs y ty = .ok v ∧ PRun F isem (record.output.emitted.toList.map (·.mapRegs
        (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size + 1)))) ρ ρ' ∧
      VHolds ⟨ty,Clif.Sem.binary kind.cop u v⟩ (ρ' record.input.base.nextVreg) ∧
      cm' = cm ∧
      (∀ n, n ≠ record.input.base.nextVreg → ρ' n = ρ n) ∧
      ValuesHeld (fun y => Demanded record.input y ∧
        y ∈ availOf f (availIn f result.ctx) bi (j + 1)) event.ctx
          fr'
          (fun k => ρ' (aliasNum result.final.alias k)) ∧
      (∀ key,key < record.input.base.nextVreg ∨ record.output.state.base.nextVreg ≤ key → ρ' key = ρ key) := by
  obtain ⟨u,v,getX,getY⟩ := source_operands run scope dominated events block statement current kind source clif sourceStep
  obtain ⟨ρ',execution,value,memEq,kept,post,interval⟩ := frame_13
    run scope dominated events records block statement current kind source clif results statementResults
    mapped recorded emitted selectedId refines dfg held getX getY sourceStep
  exact ⟨u,v,ρ',getX,getY,execution,value,memEq,kept,post,interval⟩

open Backend.Stock.Proof.LogicalComplete Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64 LogicalSelected in
private theorem frame_15 {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    {event : BlockScanEvent} {record : ScanRecord}
    (events : event ∈ result.blockScans.toList) (records : record ∈ event.output.records)
    {bi j : Nat} {b : Clif.Block} {stm : Clif.Stmt}
    (block : f.blocks[bi]? = some b) (statement : b.body[j]? = some stm)
    (current : record.inst = blockStart f bi + j)
    (kind : Kind) (left : Bool) {info : IInfo} {x y z a : Nat} {ty : Clif.Ty}
    (source : event.ctx.insts[record.inst]? = some info)
    (clif : info.clif = some (.binary kind.cop ty x y))
    (results : info.results = [z]) (statementResults : stm.results = [z])
    (mapped : event.ctx.valueReg? z = some (.vreg a .int))
    {step : Step} (recorded : record.output.step = some step) (emitted : step.decision = .emitted)
    (selectedId : step.rules.getLast? = some (LogicalNot.notRule kind left).id)
    {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem} (refines : Refines F isem)
    {fr : Clif.Frame} {ρ : Nat → CV}
    (dfg : DFGCons event.ctx (restrict fr (availOf f (availIn f result.ctx) bi j)))
    (held : ValuesHeld (fun v => Demanded record.output.state v ∧
      v ∈ availOf f (availIn f result.ctx) bi j) event.ctx fr (fun k => ρ (aliasNum result.final.alias k)))
    {u v : BitVec ty.width}
    (getX : (restrict fr (availOf f (availIn f result.ctx) bi j)).getAs x ty = .ok u)
    (getY : (restrict fr (availOf f (availIn f result.ctx) bi j)).getAs y ty = .ok v)
    {env : Clif.Env} {cp : Clif.Program} {fr' : Clif.Frame} {cm cm' : Clif.Mem}
    (sourceStep : SourceInstResult env cp event.ctx record.inst (fr,cm) (fr',cm')) :
    ∃ ρ', PRun F isem (record.output.emitted.toList.map (·.mapRegs
        (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size + 1)))) ρ ρ' ∧
      VHolds ⟨ty,Clif.Sem.binary kind.cop u v⟩ (ρ' record.input.base.nextVreg) ∧
      cm' = cm ∧
      (∀ n, n ≠ record.input.base.nextVreg → ρ' n = ρ n) ∧
      ValuesHeld (fun y => Demanded record.input y ∧
        y ∈ availOf f (availIn f result.ctx) bi (j + 1)) event.ctx
          fr'
          (fun k => ρ' (aliasNum result.final.alias k)) ∧
      (∀ key,key < record.input.base.nextVreg ∨ record.output.state.base.nextVreg ≤ key → ρ' key = ρ key) := by
  have sourceProof := sourceStep
  obtain ⟨info',inst,vals,regs,rest,found,original,body,evaluated,written,updated⟩ := sourceProof
  have sameInfo := Option.some.inj (found.symm.trans source)
  subst info'
  have sameInst := Option.some.inj (original.symm.trans clif)
  subst inst
  have availableX := restrict_regs_isSome (by rw [getAs_ok getX]; rfl)
  have availableY := restrict_regs_isSome (by rw [getAs_ok getY]; rfl)
  have originalX : fr.getAs x ty = .ok u :=
    (getAs_congr (fr := fr) (fr' := restrict fr (availOf f (availIn f result.ctx) bi j))
      (x := x) (ty := ty) (restrict_regs_of_mem availableX)).symm.trans getX
  have originalY : fr.getAs y ty = .ok v :=
    (getAs_congr (fr := fr) (fr' := restrict fr (availOf f (availIn f result.ctx) bi j))
      (x := y) (ty := ty) (restrict_regs_of_mem availableY)).symm.trans getY
  have computed : instOutcome env cp fr cm (.binary kind.cop ty x y) =
      .ok ([⟨ty,Clif.Sem.binary kind.cop u v⟩],cm) := by
    cases kind <;> simp [Kind.cop,instOutcome,Clif.evalInst,Clif.BinaryOp.isShift,originalX,originalY]
  have equal := Prod.mk.inj (Clif.Res.ok.inj (evaluated.symm.trans computed))
  have memEq : cm' = cm := equal.2
  have evaluatedValue : instOutcome env cp fr cm (.binary kind.cop ty x y) =
      .ok ([⟨ty,Clif.Sem.binary kind.cop u v⟩],cm') := by rw [memEq]; exact computed
  obtain ⟨ρ',execution,value,kept,installed⟩ := not_values_same_order
    run scope dominated events records block statement current kind left source clif results statementResults
    mapped recorded emitted selectedId refines dfg held getX getY
  have post := source_single_result_values source clif results sourceStep evaluatedValue installed
  exact ⟨ρ',execution,value,memEq,kept,post,interval⟩

open Backend.Stock.Proof.LogicalComplete Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64 LogicalSelected in
private theorem frame_16 {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    {event : BlockScanEvent} {record : ScanRecord}
    (events : event ∈ result.blockScans.toList) (records : record ∈ event.output.records)
    {bi j : Nat} {b : Clif.Block} {stm : Clif.Stmt}
    (block : f.blocks[bi]? = some b) (statement : b.body[j]? = some stm)
    (current : record.inst = blockStart f bi + j)
    (kind : Kind) (left : Bool) {info : IInfo} {x y z a : Nat} {ty : Clif.Ty}
    (source : event.ctx.insts[record.inst]? = some info)
    (clif : info.clif = some (.binary kind.cop ty x y))
    (results : info.results = [z]) (statementResults : stm.results = [z])
    (mapped : event.ctx.valueReg? z = some (.vreg a .int))
    {step : Step} (recorded : record.output.step = some step) (emitted : step.decision = .emitted)
    (selectedId : step.rules.getLast? = some (LogicalNot.notRule kind left).id)
    {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem} (refines : Refines F isem)
    {fr : Clif.Frame} {ρ : Nat → CV}
    (dfg : DFGCons event.ctx (restrict fr (availOf f (availIn f result.ctx) bi j)))
    (held : ValuesHeld (fun v => Demanded record.output.state v ∧
      v ∈ availOf f (availIn f result.ctx) bi j) event.ctx fr (fun k => ρ (aliasNum result.final.alias k)))
    {env : Clif.Env} {cp : Clif.Program} {fr' : Clif.Frame} {cm cm' : Clif.Mem}
    (sourceStep : SourceInstResult env cp event.ctx record.inst (fr,cm) (fr',cm')) :
    ∃ (u v : BitVec ty.width) (ρ' : Nat → CV),
      (restrict fr (availOf f (availIn f result.ctx) bi j)).getAs x ty = .ok u ∧
      (restrict fr (availOf f (availIn f result.ctx) bi j)).getAs y ty = .ok v ∧ PRun F isem (record.output.emitted.toList.map (·.mapRegs
        (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size + 1)))) ρ ρ' ∧
      VHolds ⟨ty,Clif.Sem.binary kind.cop u v⟩ (ρ' record.input.base.nextVreg) ∧
      cm' = cm ∧
      (∀ n, n ≠ record.input.base.nextVreg → ρ' n = ρ n) ∧
      ValuesHeld (fun y => Demanded record.input y ∧
        y ∈ availOf f (availIn f result.ctx) bi (j + 1)) event.ctx
          fr'
          (fun k => ρ' (aliasNum result.final.alias k)) ∧
      (∀ key,key < record.input.base.nextVreg ∨ record.output.state.base.nextVreg ≤ key → ρ' key = ρ key) := by
  obtain ⟨u,v,getX,getY⟩ := source_operands run scope dominated events block statement current kind source clif sourceStep
  obtain ⟨ρ',execution,value,memEq,kept,post,interval⟩ := frame_15
    run scope dominated events records block statement current kind left source clif results statementResults
    mapped recorded emitted selectedId refines dfg held getX getY sourceStep
  exact ⟨u,v,ρ',getX,getY,execution,value,memEq,kept,post,interval⟩

open Backend.Stock.Proof.LogicalExtr Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64 in
private theorem frame_17 {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f) (mirrored : Bool)
    {event : BlockScanEvent} {record : ScanRecord}
    (events : event ∈ result.blockScans.toList) (records : record ∈ event.output.records)
    {bi j : Nat} {b : Clif.Block} {stm : Clif.Stmt}
    (block : f.blocks[bi]? = some b) (statement : b.body[j]? = some stm)
    (current : record.inst = blockStart f bi + j)
    {info : IInfo} {x y z a : Nat} {ty : Clif.Ty}
    (source : event.ctx.insts[record.inst]? = some info)
    (clif : info.clif = some (.binary .bor ty x y))
    (results : info.results = [z]) (statementResults : stm.results = [z])
    (mapped : event.ctx.valueReg? z = some (.vreg a .int))
    {step : Step} (recorded : record.output.step = some step) (emitted : step.decision = .emitted)
    (selectedId : step.rules.getLast? = some (extrRule mirrored).id)
    {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem} (refines : Refines F isem)
    {fr : Clif.Frame} {ρ : Nat → CV}
    (dfg : DFGCons event.ctx (restrict fr (availOf f (availIn f result.ctx) bi j)))
    (held : ValuesHeld (fun v => Demanded record.output.state v ∧
      v ∈ availOf f (availIn f result.ctx) bi j) event.ctx fr (fun k => ρ (aliasNum result.final.alias k)))
    {u v : BitVec ty.width}
    (getX : (restrict fr (availOf f (availIn f result.ctx) bi j)).getAs x ty = .ok u)
    (getY : (restrict fr (availOf f (availIn f result.ctx) bi j)).getAs y ty = .ok v)
    {env : Clif.Env} {cp : Clif.Program} {fr' : Clif.Frame} {cm cm' : Clif.Mem}
    (sourceStep : SourceInstResult env cp event.ctx record.inst (fr,cm) (fr',cm')) :
    ∃ ρ', PRun F isem (record.output.emitted.toList.map (·.mapRegs
        (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size + 1)))) ρ ρ' ∧
      VHolds ⟨ty,Clif.Sem.binary .bor u v⟩ (ρ' record.input.base.nextVreg) ∧
      cm' = cm ∧
      (∀ n, n ≠ record.input.base.nextVreg → ρ' n = ρ n) ∧
      ValuesHeld (fun y => Demanded record.input y ∧
        y ∈ availOf f (availIn f result.ctx) bi (j + 1)) event.ctx
          fr'
          (fun k => ρ' (aliasNum result.final.alias k)) ∧
      (∀ key,key < record.input.base.nextVreg ∨ record.output.state.base.nextVreg ≤ key → ρ' key = ρ key) := by
  have sourceProof := sourceStep
  obtain ⟨info',inst,vals,regs,rest,found,original,body,evaluated,written,updated⟩ := sourceProof
  have sameInfo := Option.some.inj (found.symm.trans source)
  subst info'
  have sameInst := Option.some.inj (original.symm.trans clif)
  subst inst
  have availableX := restrict_regs_isSome (by rw [getAs_ok getX]; rfl)
  have availableY := restrict_regs_isSome (by rw [getAs_ok getY]; rfl)
  have originalX : fr.getAs x ty = .ok u :=
    (getAs_congr (fr := fr) (fr' := restrict fr (availOf f (availIn f result.ctx) bi j))
      (x := x) (ty := ty) (restrict_regs_of_mem availableX)).symm.trans getX
  have originalY : fr.getAs y ty = .ok v :=
    (getAs_congr (fr := fr) (fr' := restrict fr (availOf f (availIn f result.ctx) bi j))
      (x := y) (ty := ty) (restrict_regs_of_mem availableY)).symm.trans getY
  have computed : instOutcome env cp fr cm (.binary .bor ty x y) =
      .ok ([⟨ty,Clif.Sem.binary .bor u v⟩],cm) := by
    simp [instOutcome,Clif.evalInst,Clif.BinaryOp.isShift,originalX,originalY]
  have equal := Prod.mk.inj (Clif.Res.ok.inj (evaluated.symm.trans computed))
  have memEq : cm' = cm := equal.2
  have evaluatedValue : instOutcome env cp fr cm (.binary .bor ty x y) =
      .ok ([⟨ty,Clif.Sem.binary .bor u v⟩],cm') := by rw [memEq]; exact computed
  obtain ⟨ρ',execution,value,kept,installed,interval⟩ := frame_5
    run scope dominated mirrored events records block statement current source clif results statementResults
    mapped recorded emitted selectedId refines dfg held getX getY
  have post := source_single_result_values source clif results sourceStep evaluatedValue installed
  exact ⟨ρ',execution,value,memEq,kept,post,interval⟩

open Backend.Stock.Proof.LogicalExtr Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64 in
private theorem frame_18 {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f) (mirrored : Bool)
    {event : BlockScanEvent} {record : ScanRecord}
    (events : event ∈ result.blockScans.toList) (records : record ∈ event.output.records)
    {bi j : Nat} {b : Clif.Block} {stm : Clif.Stmt}
    (block : f.blocks[bi]? = some b) (statement : b.body[j]? = some stm)
    (current : record.inst = blockStart f bi + j)
    {info : IInfo} {x y z a : Nat} {ty : Clif.Ty}
    (source : event.ctx.insts[record.inst]? = some info)
    (clif : info.clif = some (.binary .bor ty x y))
    (results : info.results = [z]) (statementResults : stm.results = [z])
    (mapped : event.ctx.valueReg? z = some (.vreg a .int))
    {step : Step} (recorded : record.output.step = some step) (emitted : step.decision = .emitted)
    (selectedId : step.rules.getLast? = some (extrRule mirrored).id)
    {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem} (refines : Refines F isem)
    {fr : Clif.Frame} {ρ : Nat → CV}
    (dfg : DFGCons event.ctx (restrict fr (availOf f (availIn f result.ctx) bi j)))
    (held : ValuesHeld (fun v => Demanded record.output.state v ∧
      v ∈ availOf f (availIn f result.ctx) bi j) event.ctx fr (fun k => ρ (aliasNum result.final.alias k)))
    {env : Clif.Env} {cp : Clif.Program} {fr' : Clif.Frame} {cm cm' : Clif.Mem}
    (sourceStep : SourceInstResult env cp event.ctx record.inst (fr,cm) (fr',cm')) :
    ∃ (u v : BitVec ty.width) (ρ' : Nat → CV),
      (restrict fr (availOf f (availIn f result.ctx) bi j)).getAs x ty = .ok u ∧
      (restrict fr (availOf f (availIn f result.ctx) bi j)).getAs y ty = .ok v ∧ PRun F isem (record.output.emitted.toList.map (·.mapRegs
        (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size + 1)))) ρ ρ' ∧
      VHolds ⟨ty,Clif.Sem.binary .bor u v⟩ (ρ' record.input.base.nextVreg) ∧
      cm' = cm ∧
      (∀ n, n ≠ record.input.base.nextVreg → ρ' n = ρ n) ∧
      ValuesHeld (fun y => Demanded record.input y ∧
        y ∈ availOf f (availIn f result.ctx) bi (j + 1)) event.ctx
          fr'
          (fun k => ρ' (aliasNum result.final.alias k)) ∧
      (∀ key,key < record.input.base.nextVreg ∨ record.output.state.base.nextVreg ≤ key → ρ' key = ρ key) := by
  obtain ⟨u,v,getX,getY⟩ := source_operands run scope dominated mirrored events block statement current source clif sourceStep
  obtain ⟨ρ',execution,value,memEq,kept,post,interval⟩ := frame_17
    run scope dominated mirrored events records block statement current source clif results statementResults
    mapped recorded emitted selectedId refines dfg held getX getY sourceStep
  exact ⟨u,v,ρ',getX,getY,execution,value,memEq,kept,post,interval⟩

open Backend.Stock.Proof.LogicalComplete Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64 LogicalSelected in
private theorem frame_19 {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    {event : BlockScanEvent} {record : ScanRecord}
    (events : event ∈ result.blockScans.toList) (records : record ∈ event.output.records)
    {bi j : Nat} {b : Clif.Block} {stm : Clif.Stmt}
    (block : f.blocks[bi]? = some b) (statement : b.body[j]? = some stm)
    (current : record.inst = blockStart f bi + j)
    (kind : Kind) {info : IInfo} {x y z a : Nat} {ty : Clif.Ty}
    (source : event.ctx.insts[record.inst]? = some info)
    (clif : info.clif = some (.binary kind.cop ty x y))
    (results : info.results = [z]) (statementResults : stm.results = [z])
    (mapped : event.ctx.valueReg? z = some (.vreg a .int))
    {step : Step} (recorded : record.output.step = some step) (emitted : step.decision = .emitted)
    {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem} (refines : Refines F isem)
    {fr : Clif.Frame} {ρ : Nat → CV}
    (dfg : DFGCons event.ctx (restrict fr (availOf f (availIn f result.ctx) bi j)))
    (held : ValuesHeld (fun v => Demanded record.output.state v ∧
      v ∈ availOf f (availIn f result.ctx) bi j) event.ctx fr (fun k => ρ (aliasNum result.final.alias k)))
    {env : Clif.Env} {cp : Clif.Program} {fr' : Clif.Frame} {cm cm' : Clif.Mem}
    (sourceStep : SourceInstResult env cp event.ctx record.inst (fr,cm) (fr',cm')) :
    ∃ (u v : BitVec ty.width) (ρ' : Nat → CV),
      (restrict fr (availOf f (availIn f result.ctx) bi j)).getAs x ty = .ok u ∧
      (restrict fr (availOf f (availIn f result.ctx) bi j)).getAs y ty = .ok v ∧ PRun F isem (record.output.emitted.toList.map (·.mapRegs
        (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size + 1)))) ρ ρ' ∧
      VHolds ⟨ty,Clif.Sem.binary kind.cop u v⟩ (ρ' record.input.base.nextVreg) ∧
      cm' = cm ∧
      (∀ n, n ≠ record.input.base.nextVreg → ρ' n = ρ n) ∧
      ValuesHeld (fun y => Demanded record.input y ∧
        y ∈ availOf f (availIn f result.ctx) bi (j + 1)) event.ctx
          fr'
          (fun k => ρ' (aliasNum result.final.alias k)) ∧
      (∀ key,key < record.input.base.nextVreg ∨ record.output.state.base.nextVreg ≤ key → ρ' key = ρ key) := by
  have inventory := record_selected_rule_ids run scope events records kind source clif recorded emitted
  obtain ⟨id,last,member⟩ : ∃ id, step.rules.getLast? = some id ∧ id ∈ candidateIds kind := by
    simpa only [Option.any_eq_true,List.contains_iff_mem] using inventory
  cases kind with
  | band =>
    simp only [candidateIds,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · exact frame_16 run scope dominated events records block statement current .band true
        source clif results statementResults mapped recorded emitted last refines dfg held sourceStep
    · exact frame_16 run scope dominated events records block statement current .band false
        source clif results statementResults mapped recorded emitted last refines dfg held sourceStep
    · exact frame_14 run scope dominated events records block statement current .band
        source clif results statementResults mapped recorded emitted last refines dfg held sourceStep
  | bor =>
    simp only [candidateIds,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl | rfl | rfl
    · exact frame_18 run scope dominated false events records block statement current
        source clif results statementResults mapped recorded emitted last refines dfg held sourceStep
    · exact frame_18 run scope dominated true events records block statement current
        source clif results statementResults mapped recorded emitted last refines dfg held sourceStep
    · exact frame_16 run scope dominated events records block statement current .bor true
        source clif results statementResults mapped recorded emitted last refines dfg held sourceStep
    · exact frame_16 run scope dominated events records block statement current .bor false
        source clif results statementResults mapped recorded emitted last refines dfg held sourceStep
    · exact frame_14 run scope dominated events records block statement current .bor
        source clif results statementResults mapped recorded emitted last refines dfg held sourceStep
  | bxor =>
    simp only [candidateIds,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · exact frame_16 run scope dominated events records block statement current .bxor true
        source clif results statementResults mapped recorded emitted last refines dfg held sourceStep
    · exact frame_16 run scope dominated events records block statement current .bxor false
        source clif results statementResults mapped recorded emitted last refines dfg held sourceStep
    · exact frame_14 run scope dominated events records block statement current .bxor
        source clif results statementResults mapped recorded emitted last refines dfg held sourceStep

open Backend.Stock.Proof.BnotComplete Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64 in
private theorem frame_20 {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    {event : BlockScanEvent} {record : ScanRecord}
    (events : event ∈ result.blockScans.toList) (records : record ∈ event.output.records)
    {bi j : Nat} {b : Clif.Block} {stm : Clif.Stmt}
    (block : f.blocks[bi]? = some b) (statement : b.body[j]? = some stm)
    (current : record.inst = blockStart f bi + j)
    {info : IInfo} {x z a : Nat} {ty : Clif.Ty}
    (source : event.ctx.insts[record.inst]? = some info)
    (clif : info.clif = some (.unary .bnot ty x))
    (results : info.results = [z]) (statementResults : stm.results = [z])
    (mapped : event.ctx.valueReg? z = some (.vreg a .int))
    {step : Step} (recorded : record.output.step = some step) (emitted : step.decision = .emitted)
    {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem} (refines : Refines F isem)
    {fr : Clif.Frame} {ρ : Nat → CV}
    (dfg : DFGCons event.ctx (restrict fr (availOf f (availIn f result.ctx) bi j)))
    (held : ValuesHeld (fun v => Demanded record.output.state v ∧
      v ∈ availOf f (availIn f result.ctx) bi j) event.ctx fr (fun k => ρ (aliasNum result.final.alias k)))
    {u : BitVec ty.width}
    (getX : (restrict fr (availOf f (availIn f result.ctx) bi j)).getAs x ty = .ok u)
    {env : Clif.Env} {cp : Clif.Program} {fr' : Clif.Frame} {cm cm' : Clif.Mem}
    (sourceStep : SourceInstResult env cp event.ctx record.inst (fr,cm) (fr',cm')) :
    ∃ ρ', PRun F isem (record.output.emitted.toList.map (·.mapRegs
        (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size + 1)))) ρ ρ' ∧
      VHolds ⟨ty,Clif.Sem.unary .bnot u⟩ (ρ' record.input.base.nextVreg) ∧
      cm' = cm ∧
      (∀ n, n ≠ record.input.base.nextVreg → ρ' n = ρ n) ∧
      ValuesHeld (fun y => Demanded record.input y ∧
        y ∈ availOf f (availIn f result.ctx) bi (j + 1)) event.ctx
          fr'
          (fun k => ρ' (aliasNum result.final.alias k)) ∧
      (∀ key,key < record.input.base.nextVreg ∨ record.output.state.base.nextVreg ≤ key → ρ' key = ρ key) := by
  have sourceProof := sourceStep
  obtain ⟨info',inst,vals,regs,rest,found,original,body,evaluated,written,updated⟩ := sourceProof
  have sameInfo := Option.some.inj (found.symm.trans source)
  subst info'
  have sameInst := Option.some.inj (original.symm.trans clif)
  subst inst
  have availableX := restrict_regs_isSome (by rw [getAs_ok getX]; rfl)
  have originalX : fr.getAs x ty = .ok u :=
    (getAs_congr (fr := fr) (fr' := restrict fr (availOf f (availIn f result.ctx) bi j))
      (x := x) (ty := ty) (restrict_regs_of_mem availableX)).symm.trans getX
  have computed : instOutcome env cp fr cm (.unary .bnot ty x) =
      .ok ([⟨ty,Clif.Sem.unary .bnot u⟩],cm) := by
    simp [instOutcome,Clif.evalInst,originalX]
  have equal := Prod.mk.inj (Clif.Res.ok.inj (evaluated.symm.trans computed))
  have memEq : cm' = cm := equal.2
  have evaluatedValue : instOutcome env cp fr cm (.unary .bnot ty x) =
      .ok ([⟨ty,Clif.Sem.unary .bnot u⟩],cm') := by rw [memEq]; exact computed
  have inventory := record_selected_rule_ids run scope events records source clif recorded emitted
  obtain ⟨id,last,member⟩ : ∃ id, step.rules.getLast? = some id ∧ id ∈ candidateIds := by
    simpa only [Option.any_eq_true,List.contains_iff_mem] using inventory
  have values : ∃ ρ', PRun F isem (record.output.emitted.toList.map (·.mapRegs
      (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1)))) ρ ρ' ∧
      VHolds ⟨ty,Clif.Sem.unary .bnot u⟩ (ρ' record.input.base.nextVreg) ∧
      (∀ n, n ≠ record.input.base.nextVreg → ρ' n = ρ n) ∧
      ValuesHeld (fun y => Demanded record.input y ∧ y ∈ availOf f (availIn f result.ctx) bi (j+1))
        event.ctx (withValue fr z ⟨ty,Clif.Sem.unary .bnot u⟩)
        (fun k => ρ' (aliasNum result.final.alias k)) ∧
      (∀ key,key < record.input.base.nextVreg ∨ record.output.state.base.nextVreg ≤ key → ρ' key = ρ key) := by
    simp only [candidateIds,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · exact frame_6 run scope dominated events records block statement current
        source clif results statementResults mapped recorded emitted last refines dfg held getX
    · exact frame_7 run scope dominated events records block statement current
        true source clif results statementResults mapped recorded emitted last refines dfg held getX
    · exact frame_7 run scope dominated events records block statement current
        false source clif results statementResults mapped recorded emitted last refines dfg held getX
  obtain ⟨ρ',execution,value,kept,installed,interval⟩ := values
  have post := source_single_result_values source clif results sourceStep evaluatedValue installed
  exact ⟨ρ',execution,value,memEq,kept,post,interval⟩

open Backend.Stock.Proof.BnotComplete Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64 in
private theorem frame_21 {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    {event : BlockScanEvent} {record : ScanRecord}
    (events : event ∈ result.blockScans.toList) (records : record ∈ event.output.records)
    {bi j : Nat} {b : Clif.Block} {stm : Clif.Stmt}
    (block : f.blocks[bi]? = some b) (statement : b.body[j]? = some stm)
    (current : record.inst = blockStart f bi + j)
    {info : IInfo} {x z a : Nat} {ty : Clif.Ty}
    (source : event.ctx.insts[record.inst]? = some info)
    (clif : info.clif = some (.unary .bnot ty x))
    (results : info.results = [z]) (statementResults : stm.results = [z])
    (mapped : event.ctx.valueReg? z = some (.vreg a .int))
    {step : Step} (recorded : record.output.step = some step) (emitted : step.decision = .emitted)
    {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem} (refines : Refines F isem)
    {fr : Clif.Frame} {ρ : Nat → CV}
    (dfg : DFGCons event.ctx (restrict fr (availOf f (availIn f result.ctx) bi j)))
    (held : ValuesHeld (fun v => Demanded record.output.state v ∧
      v ∈ availOf f (availIn f result.ctx) bi j) event.ctx fr (fun k => ρ (aliasNum result.final.alias k)))
    {env : Clif.Env} {cp : Clif.Program} {fr' : Clif.Frame} {cm cm' : Clif.Mem}
    (sourceStep : SourceInstResult env cp event.ctx record.inst (fr,cm) (fr',cm')) :
    ∃ (u : BitVec ty.width) (ρ' : Nat → CV),
      (restrict fr (availOf f (availIn f result.ctx) bi j)).getAs x ty = .ok u ∧ PRun F isem (record.output.emitted.toList.map (·.mapRegs
        (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size + 1)))) ρ ρ' ∧
      VHolds ⟨ty,Clif.Sem.unary .bnot u⟩ (ρ' record.input.base.nextVreg) ∧
      cm' = cm ∧
      (∀ n, n ≠ record.input.base.nextVreg → ρ' n = ρ n) ∧
      ValuesHeld (fun y => Demanded record.input y ∧
        y ∈ availOf f (availIn f result.ctx) bi (j + 1)) event.ctx
          fr'
          (fun k => ρ' (aliasNum result.final.alias k)) ∧
      (∀ key,key < record.input.base.nextVreg ∨ record.output.state.base.nextVreg ≤ key → ρ' key = ρ key) := by
  obtain ⟨u,getX⟩ := source_operands run scope dominated events block statement current source clif sourceStep
  obtain ⟨ρ',execution,value,memEq,kept,post,interval⟩ := frame_20
    run scope dominated events records block statement current source clif results statementResults
    mapped recorded emitted refines dfg held getX sourceStep
  exact ⟨u,ρ',getX,execution,value,memEq,kept,post,interval⟩

