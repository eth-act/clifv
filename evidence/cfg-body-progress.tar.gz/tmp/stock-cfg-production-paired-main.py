import os,json,subprocess,hashlib,shlex,concurrent.futures,sys,datetime
from pathlib import Path
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');base=Path('/home/lee/clifv/.worktrees/stock-cfg-main-parity-20261025');os.chdir(root);sys.path.insert(0,str(root/'scripts'))
from byte_compare import ELF
out=Path('/tmp/stock-cfg-production-paired-main');out.mkdir(exist_ok=False)
e=os.environ.copy();e.update(json.load(open('/tmp/stock-mixed-div-env.json')));e.update(FV_ROOT=str(base),FV_MEMCAP='8G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2');e.pop('FV_RA_OUT',None)
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:2]);os.nice(10)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();basehead=subprocess.check_output(['git','rev-parse','HEAD'],cwd=base,text=True).strip();assert basehead=='efe8b677f62193e45fd7ecb741f36694c36cf276'
backend=base/'.lake/build/bin/lean-backend';units=[];jobs=[];hashes={}
for crate in ['fv-demo','survey']:
 for p in sorted((root/'examples'/crate/'target/fv/plain-leanlink-verified-leanld/tmp').glob('*/fv-link.json')):
  directory=p.parent;rsp=directory/'lean-inputs.rsp'
  if not rsp.exists():continue
  data=json.load(p.open());metadata={str(Path(f['ra']).with_name(Path(f['ra']).name.replace('.ra.json','.o'))):f for f in data['functions'] if f.get('ra')}
  output=out/directory.name;output.mkdir();objects=shlex.split(rsp.read_text());replacements={}
  for obj in objects:
   if Path(obj).name=='gap.o':continue
   f=metadata[obj];target=output/Path(obj).name;source=Path(f['dump']);assert source.is_file();jobs.append((source,target));replacements[obj]=str(target)
   hashes[str(source)]=sha(source);hashes[obj]=sha(obj)
  for path in [p,rsp,directory/'cgclif.o',directory/'lean.o',directory/'redefine-lean.txt',directory/'gap.o']:hashes[str(path)]=sha(path)
  (output/'inputs.rsp').write_text('\n'.join('"'+replacements.get(obj,obj)+'"' for obj in objects)+'\n');units.append((directory,output,crate))
assert len(jobs)==4543 and len(units)==30,(len(jobs),len(units))
provenance={'head':head,'baseline':basehead,'baseline_backend_sha256':sha(backend),'candidate_backend_sha256':sha(root/'.lake/build/bin/lean-backend'),'captured_inputs':hashes,'jobs':len(jobs),'units':len(units),'flags':['--dead-cleanup','--personality','rust_eh_personality'],'source_pipeline_sha256':sha(root/'rust/crates/cargo-fv/src/pipeline.rs'),'state':'running'}
(out/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
def compile_one(job):
 source,target=job
 with target.with_suffix('.log').open('w') as log:r=subprocess.run([str(backend),str(source),str(target),'--dead-cleanup','--personality','rust_eh_personality'],env=e,stdout=log,stderr=subprocess.STDOUT)
 assert r.returncode==0,(source,r.returncode,target.with_suffix('.log'))
 return str(target)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 for i,_ in enumerate(pool.map(compile_one,jobs),1):
  if i%250==0:print('baseline functions',i,flush=True)
rows=[]
rel=lambda elf,s:[(r['offset'],r['type'],r['addend']) for r in elf.function_relocations(s,{})]
for directory,output,crate in units:
 subprocess.run([e['CLIF_NATIVE_LLD'],'-flavor','gnu','-r','-o',str(output/'lean.o'),'@'+str(output/'inputs.rsp')],env=e,check=True)
 subprocess.run([e['FV_OBJCOPY'],'--redefine-syms='+str(directory/'redefine-lean.txt'),str(output/'lean.o')],env=e,check=True)
 old=ELF(output/'lean.o');new=ELF(directory/'lean.o');stock=ELF(directory/'cgclif.o')
 for name,syms in sorted(new.functions.items()):
  if len(syms)!=1 or not syms[0]['size']:continue
  ns,nb=new.function(name);bs,bb=old.function(name);ss,sb=stock.function(name)
  rows.append({'crate':crate,'cgu':directory.name,'fn':name,'baseline_equal':bb==sb and rel(old,bs)==rel(stock,ss),'candidate_equal':nb==sb and rel(new,ns)==rel(stock,ss),'baseline_bytes':sha(output/'lean.o') if False else hashlib.sha256(bb).hexdigest(),'candidate_bytes':hashlib.sha256(nb).hexdigest()})
current={(r['cgu'],r['fn']):r for r in json.load(open('/tmp/stock-cfg-production-linkfix-v4/real-crate-report.json'))};assert len(current)==4543==len(rows)
assert {(r['cgu'],r['fn']) for r in rows}==set(current)
assert all(r['candidate_equal']==current[(r['cgu'],r['fn'])]['equal'] for r in rows)
assert all(sha(p)==digest for p,digest in hashes.items()),'captured input changed'
gained=[r for r in rows if r['candidate_equal'] and not r['baseline_equal']];lost=[r for r in rows if r['baseline_equal'] and not r['candidate_equal']]
summary={'head':head,'baseline':basehead,'state':'passed' if not lost else 'failed','symbol_comparisons':len(rows),'baseline_exact':sum(r['baseline_equal'] for r in rows),'candidate_exact':sum(r['candidate_equal'] for r in rows),'gained':gained,'lost':lost,'same_captured_inputs_and_settings':True,'limits':'Paired byte/relocation symbol comparisons, not unique function coverage or goal completion.'}
(out/'rows.json').write_text(json.dumps(rows,indent=2)+'\n');(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');provenance.update(state=summary['state'],rows_sha256=sha(out/'rows.json'),summary_sha256=sha(out/'summary.json'));(out/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
print(json.dumps({k:v if k not in ['gained','lost'] else len(v) for k,v in summary.items()}),flush=True)
assert not lost and gained,(len(lost),len(gained))
