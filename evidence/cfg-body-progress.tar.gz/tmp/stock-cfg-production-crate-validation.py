#!/usr/bin/env python3
"""Build the actual crate-proofs package serially inside its maintained 8G gate."""
from pathlib import Path
import argparse
import datetime
import hashlib
import importlib.util
import json
import os
import re
import subprocess
import time

ROOT = Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025')
PACKAGE = ROOT / 'crate-proofs'


def ordered(roots, deps):
    result, visiting, finished = [], set(), set()
    def visit(name):
        if name in finished:
            return
        assert name not in visiting, ('import cycle', name)
        visiting.add(name)
        for dep in deps[name]:
            visit(dep)
        visiting.remove(name)
        finished.add(name)
        result.append(name)
    for name in sorted(roots):
        visit(name)
    return result


def plan():
    spec = importlib.util.spec_from_file_location('serial_plan', ROOT / 'scripts/lake-serial-build.py')
    serial = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(serial)
    _, modules, deps = serial.load_modules(ROOT)
    config = (PACKAGE / 'lakefile.lean').read_text()
    section = config.split('def checkRoots', 1)[1].split('target fvcheck', 1)[0]
    roots = re.findall(r'`(FV\.[A-Za-z0-9_.]+)', section)
    assert len(roots) == 8 and all(name in modules for name in roots)
    native = ordered(roots, deps)
    crates = {'.'.join(p.relative_to(PACKAGE).with_suffix('').parts): p
              for p in (PACKAGE / 'Crates').rglob('*.lean')}
    assert crates
    own_deps = {}
    for name, path in crates.items():
        imports = []
        for line in path.read_text().splitlines():
            if re.match(r'^(?:(?:public|meta|private)\s+)*import\s+', line):
                imports.extend(n for n in re.findall(r'\bCrates\.[A-Za-z0-9_.]+', line.split('--')[0])
                               if n in crates)
        own_deps[name] = imports
    return {'checker_roots': roots, 'native_order': native,
            'crate_order': ordered(crates, own_deps),
            'crate_source_hashes': {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
                                    for p in crates.values()},
            'lakefile_sha256': hashlib.sha256((PACKAGE / 'lakefile.lean').read_bytes()).hexdigest()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan-only', action='store_true')
    parser.add_argument('--out', type=Path)
    args = parser.parse_args()
    build_plan = plan()
    if args.plan_only:
        print(json.dumps({'state': 'planned_not_executed', 'checker_roots': build_plan['checker_roots'],
                          'native_modules': len(build_plan['native_order']),
                          'crate_modules': len(build_plan['crate_order'])}))
        return
    assert args.out is not None
    assert os.environ.get('FV_MEMCAP') == '8G', 'run through the maintained 8G gate'
    assert os.environ.get('OMP_NUM_THREADS') == os.environ.get('OMP_THREAD_LIMIT') == '2'
    assert subprocess.check_output(['nproc'], text=True).strip() == '2'
    cpu = min(os.sched_getaffinity(0))
    os.sched_setaffinity(0, {cpu})
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    assert subprocess.run(['git', 'diff', '--quiet', 'HEAD', '--'], cwd=ROOT).returncode == 0
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / 'plan.json').write_text(json.dumps(build_plan, indent=2) + '\n')
    steps = []
    def run(label, targets, check=True):
        log = args.out / f'{len(steps):04d}-{label}.log'
        argv = ['lake', 'build', *targets]
        started = time.monotonic()
        with log.open('w') as stream:
            result = subprocess.run(argv, cwd=PACKAGE, stdout=stream, stderr=subprocess.STDOUT)
        steps.append({'label': label, 'argv': argv, 'cwd': str(PACKAGE), 'exit': result.returncode,
                      'seconds': time.monotonic() - started, 'log': str(log),
                      'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest(),
                      'required_build': check})
        (args.out / 'steps.json').write_text(json.dumps(steps, indent=2) + '\n')
        print(json.dumps({'step': label, 'exit': result.returncode}), flush=True)
        if check and result.returncode:
            raise SystemExit(result.returncode)
        return result.returncode
    # This is a diagnostic cache check, not a validation pass. Keep its original result.
    if run('checker-cache-check', ['--no-build', 'fvcheck'], check=False):
        # Lake's o.export facet compiles one module object; imports are already normally built.
        for name in build_plan['native_order']:
            run('native-' + name, [name + ':o.export'])
    run('checker-library', ['fvcheck'])
    # Dependencies precede their consumers, so these calls start at most one new Lean module.
    for name in build_plan['crate_order']:
        run(name, [name])
    run('actual-package-default-build', [])
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == head
    assert subprocess.run(['git', 'diff', '--quiet', 'HEAD', '--'], cwd=ROOT).returncode == 0
    assert all(Path(s['log']).is_file() and hashlib.sha256(Path(s['log']).read_bytes()).hexdigest()
               == s['log_sha256'] for s in steps)
    receipt = {'state': 'passed', 'source_head': head,
               'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
               'package': str(PACKAGE), 'required_outer_memcap': '8G', 'cpu_affinity': [cpu],
               'crate_modules': len(build_plan['crate_order']), 'steps': steps,
               'actual_default_package_build_passed': True, 'full_140_complete': False}
    (args.out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print('CRATE_PROOFS_PASSED', flush=True)


if __name__ == '__main__':
    main()
