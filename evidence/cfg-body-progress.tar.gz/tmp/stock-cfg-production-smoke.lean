import FV.Backend.TwoBlockNIProduction
import FV.Backend.LinearScan
import FV.E2E.StockCfgFixtures
import FV.Clif.Print
open Backend
private def get {α : Type} (r : Except String α) : IO α :=
  match r with | .ok a => pure a | .error e => throw (IO.userError e)
def main : IO Unit := do
  let fixtures := E2E.StockCfgNIWitness.functions .systemVI64
  for (f,_) in fixtures do
    let result ← get (Stock.lower f)
    let selected ← get (Stock.TwoBlock.lowerValidated f)
    let valid := Stock.TwoBlock.sourceOk f && ABIReadCfg.check f.sig result.code &&
      SemanticNI.check f result.code && decide (selected = result.code)
    IO.println s!"CFG_SMOKE {f.name}: eligible={Stock.TwoBlock.eligible f} source={Stock.TwoBlock.sourceOk f} read={ABIReadCfg.check f.sig result.code} semantic={SemanticNI.check f result.code} exact={decide (selected = result.code)}"
    unless valid do throw (IO.userError "CFG smoke fell back or failed validation")
  let parsed := Clif.parseFile (String.join (fixtures.map fun (f,_) => f.print ++ "\n"))
  let out ← compileFileTwoBlockNIWhen true (fun vcs => pure (allocateLean vcs)) parsed [] true
  unless out.funcs.length == 12 && out.unsupported.isEmpty && out.unverified.isEmpty && out.unvalidated.isEmpty do
    throw (IO.userError s!"CFG pipeline failed: unsupported={out.unsupported}, unverified={out.unverified}, unvalidated={out.unvalidated}")
  let bytes ← get out.object
  IO.FS.writeBinFile "/tmp/stock-cfg-production-smoke.o" bytes
  IO.FS.writeFile "/tmp/stock-cfg-production-smoke.json" out.tableJson
  IO.println s!"CFG_SMOKE complete: 12 verified functions, {bytes.size} object bytes"
