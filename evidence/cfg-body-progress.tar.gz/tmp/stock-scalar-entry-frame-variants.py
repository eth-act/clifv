from pathlib import Path
import re
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025/FV/Backend/Proof')
frame="(∀ k,k < record.input.base.nextVreg ∨ record.output.state.base.nextVreg ≤ k → ρ' k = ρ k)"
def change(file,name,adapt=None,world=False):
 p=root/(file+'.lean');s=p.read_text();a=s.index('theorem '+name+' ');matches=list(re.finditer(r'\n(?:theorem |private theorem |end )',s[a+1:]));b=a+1+matches[0].start() if matches else len(s)
 doc=s.rfind('\n/--',a,b)
 if doc>a:b=doc
 old=s[a:b].rstrip();header,body=old.split(' := by',1)
 end=header.index('(sourceStep :');binders=header[:end];args=[];i=binders.index(' ')+1
 while i<len(binders):
  if binders[i] not in '({':i+=1;continue
  start=i;op=binders[i];stack=[op];i+=1
  while stack:
   c=binders[i]
   if c in '([{':stack.append(c)
   elif c in ')]}':stack.pop()
   i+=1
  if op=='(':
   text=binders[start+1:i-1];names=text.split(':',1)[0].strip().split();args+=names
 args+=['sourceStep']
 newhead=header.replace('theorem '+name+' ','theorem '+name+'_framed ',1)+' ∧\n      '+frame
 if adapt:body=adapt(body)
 else:body=body.replace('post⟩','post,kept⟩').replace('computed installed⟩','computed installed,kept⟩')
 wrapper=header+' := by\n  obtain ⟨ρ\',execution,unchanged,post,_⟩ := '+name+'_framed '+' '.join(args)+"\n  exact ⟨ρ',execution,unchanged,post⟩\n"
 s=s[:a]+newhead+' := by'+body+'\n\n/-- Retained original interface. -/\n'+wrapper+s[b:];p.write_text(s)
 print(file,name,args)
change('StockBitFamily','unary_source')
change('StockBitFamily','rotate_source')
change('StockShiftSourceTransfer','base_source')
change('StockShiftCompleteSourceTransfer','fused_source')
change('StockShiftCompleteSourceTransfer','record_source',lambda s:s.replace('fused_source ','fused_source_framed ').replace('base_source ','base_source_framed '))
change('StockCastCompleteSourceTransfer','extend_source_of_formats')
change('StockCastCompleteSourceTransfer','reduce_source',lambda s:s.replace('exact ⟨ρ,execution,memory,post⟩','exact ⟨ρ,execution,memory,post,fun _ _ => rfl⟩'))
