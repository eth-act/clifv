from pathlib import Path
import os,json,subprocess,time,datetime,hashlib,re
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');os.chdir(root)
e=os.environ.copy();e.update(json.load(open('/tmp/stock-mixed-div-env.json')));e.update(FV_ROOT=str(root),FV_MEMCAP='8G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2')
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:2]);os.nice(10)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();out=Path('/tmp/stock-cfg-entry-body-trust-v1');out.mkdir(exist_ok=False);records={}
p=Path('/tmp/stock-cfg-entry-body-normal-v1.json')
workers=subprocess.check_output(['pgrep','-f','^python3 /tmp/stock-cfg-entry-body-normal-worker-v1.py$'],text=True).split() if not p.exists() else []
assert p.exists() or len(workers)==1,'normal worker not live and terminal receipt absent'
while not p.exists():time.sleep(10)
normal=json.load(p.open());assert normal['head']==normal['current_head']==head and normal['returncode']==0,normal
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run(label,args):
 assert head==subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
 log=out/(label+'.log');print(datetime.datetime.now(datetime.timezone.utc).isoformat(),label,flush=True)
 with log.open('w') as f:r=subprocess.run(['scripts/memcap.sh',*args],env=e,stdout=f,stderr=subprocess.STDOUT)
 records[label]={'returncode':r.returncode,'log':str(log),'sha256':sha(log)}
 (out/'receipt.json').write_text(json.dumps({'head':head,'state':'running' if not r.returncode else 'failed','records':records},indent=2)+'\n')
 if r.returncode:raise SystemExit(r.returncode)
run('all-axioms',['python3','scripts/axiom-audit.py','--log-dir',str(out/'all-axioms')])
for path in sorted(Path('/tmp/stock-cfg-entry-body-owned-v1').glob('Owned*.lean')):run(path.stem,['lake','env','lean',str(path)])
old=json.load(open('/tmp/stock-cfg-production-trust-v5/exact-parity.json'))['axiom_sets'];new={}
for p in (out/'all-axioms').glob('*.log'):
 flat=' '.join(p.read_text().split())
 for name,axes in re.findall(r"'(.+?)' depends on axioms: \[([^\]]*)\]",flat):
  axes=sorted(x.strip() for x in axes.split(',') if x.strip());assert name not in new or new[name]==axes;new[name]=axes
 for name in re.findall(r"'(.+?)' does not depend on any axioms",flat):assert name not in new or not new[name];new[name]=[]
assert len(old)==3486
missing=sorted(set(old)-set(new));changed={k:[old[k],new[k]] for k in old.keys()&new.keys() if old[k]!=new[k]}
(out/'exact-parity.json').write_text(json.dumps({'head':head,'old_roots':len(old),'current_roots':len(new),'missing':missing,'changed':changed,'axiom_sets':new},indent=2)+'\n');assert not missing and not changed,(missing,changed)
(out/'receipt.json').write_text(json.dumps({'head':head,'state':'passed','records':records},indent=2)+'\n');print('ENTRY_TRUST_AND_EXACT_OLD_AXIOMS_PASS',flush=True)
