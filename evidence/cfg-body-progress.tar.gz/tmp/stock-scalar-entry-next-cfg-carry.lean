import FV.Backend.Proof.StockInheritedScalar
import FV.Backend.Proof.StockGuardedSuccessor
namespace Backend.Stock.Proof.Control
open Backend.Proof Backend.Proof.Driver
set_option autoImplicit false
set_option Elab.async false

theorem direct_successor_carries {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    {first second : BlockScanEvent} (firstEvent : first ∈ result.blockScans.toList)
    (secondEvent : second ∈ result.blockScans.toList)
    {label bi index targetLabel tl : Nat} {b targetBlock : Clif.Block} {bc : Clif.BlockCall}
    (tag : result.order.nodes[label]? = some (.original bi)) (source : f.blocks[bi]? = some b)
    (selected : (dests b.term)[index]? = some bc)
    (successor : result.order.successors[label]![index]? = some targetLabel)
    (targetTag : result.order.nodes[targetLabel]? = some (.original tl))
    (targetIndex : blockIdx? f bc.block = some tl)
    (target : f.block? bc.block = some targetBlock)
    (firstBlock : first.block = bi) (secondBlock : second.block = tl)
    {fr fr' : Clif.Frame} {cm : Clif.Mem} {MR : MemRelT}
    {st : State} {ρ : Nat → CV} {w : Arm.ArmState}
    (before : GuardedScanRel f result first.ctx first.block MR st (b.body.length,fr,cm) ρ w)
    (defined : SourceDefinedAt f result.ctx bi b.body.length fr)
    (entered : Clif.enterBlock fr bc = .ok fr')
    (held : ValuesHeld (fun x => x ∈ bc.args ∨
      (x ∈ availOf f (availIn f result.ctx) tl 0 ∧ x ∉ targetBlock.params.map (·.1)))
      result.ctx fr (fun key => ρ (aliasNum result.final.alias key)))
    {needed : Nat → Prop}
    (available : ∀ x,needed x → x ∈ availOf f (availIn f result.ctx) tl 0) :
    ∃ ρ',edgeEnvAt result.code result.edgeArgs label targetLabel index ρ = some ρ' ∧
      SourceDefinedAt f result.ctx tl 0 fr' ∧
      Inherited.CarryRel f result second.ctx second.block MR needed second.output.state (0,fr',cm) ρ' w := by
  obtain ⟨ρ',copied,nextDefined,guarded⟩ := stock_lower_direct_guarded_successor run scope dominated
    firstEvent secondEvent tag source selected successor targetTag targetIndex target firstBlock secondBlock
    before defined entered held
  obtain ⟨ρ2,copied2,values⟩ := stock_lower_direct_per_edge_values run scope dominated tag source
    selected successor targetTag targetIndex before.1 target entered
    (needed := fun x => x ∈ availOf f (availIn f result.ctx) tl 0) (fun _ h => h) held
  have same : ρ2 = ρ' := Option.some.inj (copied2.symm.trans copied)
  subst ρ2
  refine ⟨ρ',copied,nextDefined,guarded,?_⟩
  intro x member value read
  obtain ⟨key,mapped,realized⟩ := values x (available x member) value read
  refine ⟨key,?_,realized⟩
  rw [(stock_lower_record_context run scope secondEvent).2.1 x]
  exact mapped

end Backend.Stock.Proof.Control
