# Dividing entry blocks in Stock production

Candidate158ffc0d extends the landed two-block class to constants, nop and
signed/unsigned division/remainder in the entry body, followed by the existing
scalar/division/mask successor. New definitions are forwarded; inherited entry
values remain available regardless of local demand.

Shared source/body/jump composition preserves source definedness and the
original continuation/fuel. A first entry trap ends before the jump; a later
trap follows the completed body, actual successor copies and successor run.
The instruction-zero ABI theorem covers both cases. Old quiet-entry and
whole-function division-carry variants retain their exact interfaces.

The new input-only class checker derives the existing Scalar.Domain under the
original source/scope/dominance/ABI conditions. Existing CfgBoundary and the
CompiledSemanticNI.cfg constructor handle paired physical execution; no new
machine model or output certificate is introduced. Route6 is appended; old
artifact indices0–5 remain fixed. Every candidate failure retries the previous
complete CFG pipeline with original source, allocator and settings. Existing
optimizer/tail and exception selection remains, including checked mixed programs
with a new-class function and retained try calls.

Formal witnesses execute entered7/3, inherited7 and copied2 to return9, and an
entry zero-divisor trap. Compilation is checked in the kernel; the only new
fixed native fact is original-input dominance, confined to labelled witnesses.
The generic source domain uses only the standard three axioms. Two bundled MCP
reviews are clear; all12 new source audit roots and8 carry roots pass.

Native cohort:16 functions, four widths, nine ABI arguments, source slot,
nonempty copies, signed overflow, entry zero and later zero/overflow. The later
signed overflow differs from the entry zero trap so attribution is observable.
Both allocators and cleanup modes pass34 integration checks and3840 Lean byte
executions against480 Cranelift references, zero disagreements. Actual CLI,
verified linking, generated-proof compilation and generated axioms pass. The
prior CFG cohort retains its34 integration checks. Runtime/encoder and both
original/parent identity-stage cohorts pass; verified examples pass.

Pending terminal gates: full current module keys, all90 audit files and exact
parent3486 axiom sets, declaration-owner audit, actual crate package and fresh
same-input current-main byte/relocation comparison. Do not claim release until
all required gates are terminal and verified.

This advances #140; it does not establish Stock-only compilation success or
complete arbitrary CFG/effect/call/whole-driver simulation. Retained fallback
is acceptance preservation, not a completeness theorem. Broader scalar entry
bodies, conditional/table/critical edges, loops, memory/effects/calls and all
original-domain completeness/consumer obligations remain active.
