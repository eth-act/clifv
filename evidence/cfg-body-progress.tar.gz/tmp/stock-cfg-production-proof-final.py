import os,json,subprocess,time,datetime,re
from pathlib import Path
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');os.chdir(root)
env=os.environ.copy();env.update(json.load(open('/tmp/stock-mixed-div-env.json')));env.update(FV_ROOT=str(root),FV_MEMCAP='8G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',CARGO_BUILD_JOBS='2')
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:2]);os.nice(10)
original=Path('/proc/637571/stat').read_text().split()[21] if Path('/proc/637571/stat').exists() else None
while original is not None and Path('/proc/637571/stat').exists() and Path('/proc/637571/stat').read_text().split()[21]==original:time.sleep(10)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();records={}
def run(label,args):
 path=Path('/tmp/stock-cfg-production-'+label+'-v2.log');print(datetime.datetime.now(datetime.timezone.utc).isoformat(),label,flush=True)
 with path.open('w') as out:r=subprocess.run(args,env=env,stdout=out,stderr=subprocess.STDOUT)
 records[label]={'returncode':r.returncode,'log':str(path)}
 Path('/tmp/stock-cfg-production-proof-final.json').write_text(json.dumps({'head':head,'records':records},indent=2)+'\n')
 if r.returncode:raise SystemExit(r.returncode)
run('normal',['python3','scripts/lake-serial-build.py','--budget','8G','--max-jobs','1','--min-cap','6G','--default-cap','6G','--max-cap','8G','--out','/tmp/stock-cfg-production-normal-v2','FV','FVTest'])
run('all-axioms',['scripts/memcap.sh','python3','scripts/axiom-audit.py','--log-dir','/tmp/stock-cfg-production-all-axioms-v2'])
def collect(path):
 result={}
 for p in Path(path).glob('*.log'):
  flat=' '.join(p.read_text().split())
  for name,axes in re.findall(r"'(.+?)' depends on axioms: \[([^\]]*)\]",flat):
   ax=sorted(x.strip() for x in axes.split(',') if x.strip())
   assert name not in result or result[name]==ax,(name,p)
   result[name]=ax
  for name in re.findall(r"'(.+?)' does not depend on any axioms",flat):
   assert name not in result or not result[name]
   result[name]=[]
 return result
old=collect('/tmp/stock-cfg-div-carry-all-axioms-v1');new=collect('/tmp/stock-cfg-production-all-axioms-v2')
assert len(old)==3425,len(old)
missing=sorted(set(old)-set(new));changed={k:[old[k],new[k]] for k in old.keys()&new.keys() if old[k]!=new[k]}
result={'head':head,'old_roots':len(old),'current_roots':len(new),'missing':missing,'changed':changed,'current_axiom_sets':new}
Path('/tmp/stock-cfg-production-exact-axioms-v2.json').write_text(json.dumps(result,indent=2)+'\n')
assert not missing and not changed,(missing,changed)
assert head==subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
print('CURRENT_NORMAL_AND_AXIOM_PARITY_PASS',len(new),flush=True)
