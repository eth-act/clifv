import os,signal,pathlib,json,time,datetime
scheduler=381728
proc=pathlib.Path(f'/proc/{scheduler}')
assert 'scripts/lake-serial-build.py' in (proc/'cmdline').read_bytes().decode().replace('\0',' ')
identity=(proc/'stat').read_text().split()[21]
children=[int(x) for x in (proc/f'task/{scheduler}/children').read_text().split()]
workers=[]
for pid in children:
 p=pathlib.Path(f'/proc/{pid}');cmd=(p/'cmdline').read_bytes().decode().replace('\0',' ')
 if 'lake-time.py' in cmd and 'FV.E2E.StockGeneralDivChecks' in cmd:workers.append((pid,(p/'stat').read_text().split()[21],cmd))
assert len(workers)==1,workers
receipt=pathlib.Path('/tmp/stock-cfg-body-dispatch-drain.json')
state={'scheduler_pid':scheduler,'scheduler_starttime':identity,'workers':workers,'state':'waiting for actual current module terminal state; dispatcher held'}
def save():state['utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();receipt.write_text(json.dumps(state,indent=2)+'\n')
def alive(pid,ident):
 p=pathlib.Path(f'/proc/{pid}/stat')
 try:s=p.read_text().split();return s[21]==ident and s[2]!='Z'
 except FileNotFoundError:return False
save()
while any(alive(pid,ident) for pid,ident,_ in workers):time.sleep(3)
state['worker_terminal']=True;save()
if alive(scheduler,identity):
 os.kill(scheduler,signal.SIGTERM)
 os.kill(scheduler,signal.SIGCONT)
 while alive(scheduler,identity):time.sleep(1)
state['state']='current module terminal; obsolete dispatcher terminated without interrupting a healthy compiler';save();print(state['state'],flush=True)
