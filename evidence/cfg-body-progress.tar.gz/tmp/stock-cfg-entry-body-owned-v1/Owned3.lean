import Lean
import FV.Backend.Lowering.StockTwoBlockEntry
import FV.Backend.Lowering.StockTwoBlockEntryNI
import FV.Backend.Proof.StockEntryDivisionFixture
import FV.Backend.Proof.StockEntryDivisionWitness
import FV.Backend.Proof.StockInheritedDivisionWitness
import FV.Backend.Proof.StockInheritedJumpDefined
import FV.Backend.Proof.StockInheritedJumpTrap
import FV.Backend.Proof.StockInheritedMixedDivision
import FV.Backend.Proof.StockTwoBlockDomain
import FV.Backend.Proof.StockTwoBlockEntryCheck
import FV.Backend.Proof.StockTwoBlockReturn
import FV.Backend.Proof.StockTwoBlockTrap
import FV.Backend.SemanticNICheck
import FV.Backend.TwoBlockEntryNIProduction
import FV.E2E.CompiledSemanticNI
import FV.E2E.StockEntryCfgFixtures
import FVTest.Backend.Lowering.StockTwoBlockProductionRuntime
import FVTest.Backend.Main
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let core := #["FV.Backend.Lowering.StockTwoBlockEntry", "FV.Backend.Lowering.StockTwoBlockEntryNI", "FV.Backend.Proof.StockInheritedJumpDefined", "FV.Backend.Proof.StockInheritedJumpTrap", "FV.Backend.Proof.StockInheritedMixedDivision", "FV.Backend.Proof.StockTwoBlockDomain", "FV.Backend.Proof.StockTwoBlockEntryCheck", "FV.Backend.Proof.StockTwoBlockReturn", "FV.Backend.Proof.StockTwoBlockTrap", "FV.Backend.SemanticNICheck", "FV.Backend.TwoBlockEntryNIProduction", "FV.E2E.CompiledSemanticNI", "FV.E2E.StockEntryCfgFixtures", "FVTest.Backend.Lowering.StockGeneralDivProductionLinked", "FVTest.Backend.Lowering.StockGeneralDivProductionRuntime", "FVTest.Backend.Lowering.StockTwoBlockProductionRuntime", "FVTest.Backend.Main", "FVTest.E2E.LinkCheckMain", "FVTest.Link.LeanLinkMain"]
  let witnesses := #["FV.Backend.Proof.StockEntryDivisionFixture", "FV.Backend.Proof.StockEntryDivisionWitness", "FV.Backend.Proof.StockInheritedDivisionWitness"]
  let fixedFacts := #["_private.FV.Backend.Proof.StockEntryDivisionFixture.0.Backend.Stock.Proof.EntryDivisionWitness.dominated._native.native_decide.ax_1"]
  let mut ncore : Nat := 0
  let mut nwitness : Nat := 0
  for (name,_) in env.constants.toList do
    let some i := env.getModuleIdxFor? name | continue
    let owner := env.header.moduleNames[i]!.toString
    unless core.contains owner || witnesses.contains owner do continue
    for ax in ← collectAxioms name do
      if #[``propext,``Classical.choice,``Quot.sound].contains ax then continue
      unless witnesses.contains owner && fixedFacts.contains ax.toString do
        throwError "disallowed axiom {ax.toString} in {name} owned by {owner}"
    if core.contains owner then ncore := ncore+1 else nwitness := nwitness+1
  unless ncore > 0 && nwitness > 0 do throwError "empty ownership partition"
  logInfo m!"ENTRY_CFG_OWNED_STANDARD_CORE {ncore}; FIXED_WITNESSES {nwitness}"
