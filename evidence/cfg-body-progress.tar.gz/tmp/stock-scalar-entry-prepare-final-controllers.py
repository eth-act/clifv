from pathlib import Path
import json,subprocess,re
r=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025')
# A fresh final check follows the healthy full build already running; retain its
# expensive unchanged module results, and bind the final gate to the fixture fix.
s=Path('/tmp/stock-scalar-entry-normal-worker-v1.py').read_text().replace('stock-scalar-entry-normal-v1','stock-scalar-entry-normal-v2').replace('import os,json,subprocess,datetime','import os,json,subprocess,datetime,time')
s=s.replace("with open('/tmp/stock-scalar-entry-normal-v2.log'", "while not Path('/tmp/stock-scalar-entry-normal-v1.json').exists():time.sleep(10)\nassert json.load(open('/tmp/stock-scalar-entry-normal-v1.json'))['returncode']==0\nwith open('/tmp/stock-scalar-entry-normal-v2.log'")
Path('/tmp/stock-scalar-entry-normal-worker-v2.py').write_text(s)
# Audit every changed declaration, including private implementation roots.
old=json.load(open('/tmp/stock-cfg-entry-body-owned-v1/modules.json'));mods=[]
for f in subprocess.check_output(['git','diff','--name-only','b94d6cd4','HEAD'],cwd=r,text=True).splitlines():
 if f.endswith('.lean') and f.startswith(('FV/','FVTest/')):mods.append(f[:-5].replace('/','.'))
neww=['FV.Backend.Proof.StockEntryScalarFixture','FV.Backend.Proof.StockEntryScalarWitness'];w=sorted(set(old['witnesses']+neww));core=sorted(set(old['core']+[m for m in mods if m not in w]));fixed=old['fixed_facts']+['_private.FV.Backend.Proof.StockEntryScalarFixture.0.Backend.Stock.Proof.EntryScalarWitness.dominated._native.native_decide.ax_1']
out=Path('/tmp/stock-scalar-entry-owned-v1');out.mkdir(exist_ok=True)
for p in Path('/tmp/stock-cfg-entry-body-owned-v1').glob('Owned*.lean'):
 s=p.read_text();imports=set(re.findall(r'^import (\S+)',s,re.M));extra=sorted((set(core+w)-set(old['executable_partitions']))-imports);s=''.join('import '+m+'\n' for m in extra)+s
 for key,value in [('core',core),('witnesses',w),('fixedFacts',fixed)]:s=re.sub(r'  let '+key+r' := #\[[^\n]*\]', '  let '+key+' := #'+json.dumps(value),s)
 (out/p.name).write_text(s)
(out/'modules.json').write_text(json.dumps({'core':core,'witnesses':w,'fixed_facts':fixed,'executable_partitions':old['executable_partitions']},indent=2)+'\n')
s=Path('/tmp/stock-cfg-entry-body-trust-worker-v1.py').read_text().replace('stock-cfg-entry-body','stock-scalar-entry').replace('stock-scalar-entry-normal-v1','stock-scalar-entry-normal-v2').replace('stock-scalar-entry-normal-worker-v1','stock-scalar-entry-normal-worker-v2')
a=s.index("old=json.load(open(");b=s.index('missing=sorted(',a)
s=s[:a]+'''def parse_axes(directory):
 result={}
 for path in Path(directory).glob('*.log'):
  source=path.read_text()
  for m in re.finditer(r"^'(.+)' depends on axioms: \\[([^\\]]*)\\]",source,re.M):
   name=m[1];axes=sorted(x.strip() for x in m[2].split(',') if x.strip());assert name not in result or result[name]==axes;result[name]=axes
  for m in re.finditer(r"^'(.+)' does not depend on any axioms",source,re.M):
   name=m[1];assert name not in result or not result[name];result[name]=[]
 return result
old=parse_axes('/tmp/stock-cfg-entry-body-trust-v1/all-axioms');new=parse_axes(out/'all-axioms');assert len(old)==3499
'''+s[b:]
Path('/tmp/stock-scalar-entry-trust-worker-v1.py').write_text(s)
# Fresh paired comparison against the actual current parent, using one temporary
# view owned by this batch and the same shared warm cache; remove it on completion.
s=Path('/tmp/stock-cfg-entry-body-post-native-worker-v1.py').read_text().replace('stock-cfg-entry-body','stock-scalar-entry').replace('stock-scalar-entry-native-v1','stock-scalar-entry-native-v2').replace('stock-cfg-entry-main-parity-20261026','stock-scalar-entry-main-parity-20261026').replace('ce83af2cb49585a64a4e4134001945c729f486da','b94d6cd42c4341e5c775ba4d89ef37a89656fcc0')
Path('/tmp/stock-scalar-entry-post-native-worker-v1.py').write_text(s)
s=Path('/tmp/stock-cfg-entry-body-paired-main-v1.py').read_text().replace('stock-cfg-entry-body','stock-scalar-entry').replace('stock-cfg-entry-main-parity-20261026','stock-scalar-entry-main-parity-20261026').replace('ce83af2cb49585a64a4e4134001945c729f486da','b94d6cd42c4341e5c775ba4d89ef37a89656fcc0');Path('/tmp/stock-scalar-entry-paired-main-v1.py').write_text(s)
print('ownership',len(core),len(w),'plus five executable partitions; final controllers prepared')
