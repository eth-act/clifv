import os,json,subprocess,time,datetime,hashlib
from pathlib import Path
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');os.chdir(root)
env=os.environ.copy();env.update(json.load(open('/tmp/stock-mixed-div-env.json')));env.update(FV_ROOT=str(root),FV_MEMCAP='8G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',CARGO_BUILD_JOBS='2',FV_CG_CLIF='/home/lee/clifv/.worktrees/driver-proof-resume/target/cg_clif/unwind/librustc_codegen_cranelift.so')
env['PATH']=str(root/'rust/target/release')+':'+env['PATH']
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:2]);os.nice(10)
p=Path('/proc/668369/stat');identity=p.read_text().split()[21] if p.exists() else None
while identity is not None and p.exists() and p.read_text().split()[21]==identity:time.sleep(10)
integration=json.load(open('/tmp/stock-cfg-production-integration-v3/receipt.json'));assert integration['state']=='passed',integration.get('error')
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head==integration['head']
out=Path('/tmp/stock-cfg-production-author-v1');out.mkdir(exist_ok=False);records={}
def run(label,args,extra=None):
 assert head==subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
 path=out/(label+'.log');print(datetime.datetime.now(datetime.timezone.utc).isoformat(),label,flush=True)
 started=time.monotonic();e=env.copy();e.update(extra or {})
 with path.open('w') as f:r=subprocess.run(['scripts/memcap.sh',*args],env=e,stdout=f,stderr=subprocess.STDOUT)
 records[label]={'returncode':r.returncode,'log':str(path),'seconds':time.monotonic()-started,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
 (out/'receipt.json').write_text(json.dumps({'head':head,'state':'running' if not r.returncode else 'failed','records':records},indent=2)+'\n')
 if r.returncode:raise SystemExit(r.returncode)
run('tools',['lake','build','lean-e2e-check','lean-backend-encode-test','lean-stock-lowering-compare'])
run('runtime',['bash','scripts/lean-backend-filetests.sh'])
run('encoder',['bash','scripts/lean-backend-encode-check.sh'])
for label,flags in [('e2e',[]),('legacy-e2e',['--no-dead-cleanup'])]:
 run(label,['.lake/build/bin/lean-e2e-check',*flags,'--identity-report',str(out/(label+'-identities.json'))])
parity={}
for label in ['e2e','legacy-e2e']:
 paths={'original':Path('/tmp/legacy-dead-cleanup-final-'+label+'-identities.json'),'prior':Path('/tmp/stock-mask-full-current/'+label+'-identities.json'),'current':out/(label+'-identities.json')}
 def entries(p):
  d=json.load(p.open());result={(v['file'],v['function'],v['index']):v['stages'] for v in d['functions']};assert len(result)==len(d['functions']);return result
 maps={k:entries(p) for k,p in paths.items()}
 assert len(maps['original'])==1150
 for name in ['original','prior']:assert all(maps['current'].get(k)==v for k,v in maps[name].items()),(label,name)
 parity[label]={'counts':{k:len(v) for k,v in maps.items()},'original_and_prior_ordered_stages_exact':True}
(out/'identity-stage-parity.json').write_text(json.dumps(parity,indent=2)+'\n')
for name in ['fv-demo','survey']:
 run('verified-'+name,['bash','examples/compare.sh','examples/'+name,'--lean-link','--verified','--keep-temps'])
(out/'receipt.json').write_text(json.dumps({'head':head,'state':'passed','records':records},indent=2)+'\n')
print('AUTHOR_NATIVE_RUNTIME_ENCODER_E2E_EXAMPLES_PASS',flush=True)
