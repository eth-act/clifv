import Crates.StockCfgEntryProduction16CleanupFallbackGlobal
import Crates.StockCfgEntryProduction16CleanupStrictGlobal
import Crates.StockCfgEntryProduction16PlainFallbackGlobal
import Crates.StockCfgEntryProduction16PlainStrictGlobal
import Crates.StockCfgEntryProduction2CleanupFallbackGlobal
import Crates.StockCfgEntryProduction2PlainFallbackGlobal
import Crates.StockCfgEntryProduction2RetainedCleanupFallbackGlobal
import Crates.StockCfgEntryProduction2RetainedPlainFallbackGlobal
import Crates.StockCfgEntryProduction33CleanupFallbackEntries
import Crates.StockCfgEntryProduction33CleanupFallbackGlobal
import Crates.StockCfgEntryProduction6MixedCleanupFallbackGlobal
import Crates.StockCfgEntryProduction6MixedPlainFallbackGlobal
import Crates.StockCfgEntryProduction7MixedCleanupFallbackGlobal
import Crates.StockCfgEntryProduction7MixedPlainFallbackGlobal
import Crates.CfgEntryProductionCLIcurrentPlain
import Crates.CfgEntryProductionCLIretainedPlain
import Crates.CfgEntryProductionCLIcurrentCleanup
import Crates.CfgEntryProductionCLIretainedCleanup
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let generated := fun (name : Name) =>
    let owner := (privateToUserName? name).getD name
    owner.toString.startsWith "Crates.StockCfgEntryProduction" || owner.toString.startsWith "Crates.CfgEntryProductionCLI"
  let mut count : Nat := 0
  for (name, _) in env.constants.toList do
    unless generated name do continue
    for ax in ← collectAxioms name do
      if #[``propext, ``Classical.choice, ``Quot.sound].contains ax then continue
      unless generated ax && (ax.toString.splitOn "._native.native_decide.ax_").length > 1 do
        throwError "unexpected generated-proof axiom {ax} in {name}"
    count := count + 1
  unless count > 0 do throwError "empty generated-proof audit"
  logInfo m!"STOCK_CFGENTRYPRODUCTION_GENERATED_AXIOMS_PASS {count}"
