import Crates.StockCfgScalarEntryProduction2CleanupFallbackGlobal
import Crates.StockCfgScalarEntryProduction2PlainFallbackGlobal
import Crates.StockCfgScalarEntryProduction2RetainedCleanupFallbackGlobal
import Crates.StockCfgScalarEntryProduction2RetainedPlainFallbackGlobal
import Crates.StockCfgScalarEntryProduction33CleanupFallbackEntries
import Crates.StockCfgScalarEntryProduction33CleanupFallbackGlobal
import Crates.StockCfgScalarEntryProduction6MixedCleanupFallbackGlobal
import Crates.StockCfgScalarEntryProduction6MixedPlainFallbackGlobal
import Crates.StockCfgScalarEntryProduction7MixedCleanupFallbackGlobal
import Crates.StockCfgScalarEntryProduction7MixedPlainFallbackGlobal
import Crates.StockCfgScalarEntryProduction96CleanupFallbackEntries
import Crates.StockCfgScalarEntryProduction96CleanupFallbackGlobal
import Crates.StockCfgScalarEntryProduction96CleanupStrictEntries
import Crates.StockCfgScalarEntryProduction96CleanupStrictGlobal
import Crates.StockCfgScalarEntryProduction96PlainFallbackEntries
import Crates.StockCfgScalarEntryProduction96PlainFallbackGlobal
import Crates.StockCfgScalarEntryProduction96PlainStrictEntries
import Crates.StockCfgScalarEntryProduction96PlainStrictGlobal
import Crates.CfgScalarEntryProductionCLIcurrentPlain
import Crates.CfgScalarEntryProductionCLIretainedPlain
import Crates.CfgScalarEntryProductionCLIcurrentCleanup
import Crates.CfgScalarEntryProductionCLIretainedCleanup
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let generated := fun (name : Name) =>
    let owner := (privateToUserName? name).getD name
    owner.toString.startsWith "Crates.StockCfgScalarEntryProduction" || owner.toString.startsWith "Crates.CfgScalarEntryProductionCLI"
  let mut count : Nat := 0
  for (name, _) in env.constants.toList do
    unless generated name do continue
    for ax in ← collectAxioms name do
      if #[``propext, ``Classical.choice, ``Quot.sound].contains ax then continue
      unless generated ax && (ax.toString.splitOn "._native.native_decide.ax_").length > 1 do
        throwError "unexpected generated-proof axiom {ax} in {name}"
    count := count + 1
  unless count > 0 do throwError "empty generated-proof audit"
  logInfo m!"STOCK_CFGSCALARENTRYPRODUCTION_GENERATED_AXIOMS_PASS {count}"
