import FV.Backend.Lowering.StockTwoBlockEntryNI
import FV.E2E.SemanticChecksWith
import FV.E2E.SemanticStackBound
import Crates.StockCfgScalarEntryProduction96PlainStrictEntries.Input

/-! Slice 2 of `Crates.StockCfgScalarEntryProduction96PlainStrictEntries`'s checks (generated; see there). -/

namespace Crates.StockCfgScalarEntryProduction96PlainStrictEntries

open E2E E2E.LinkCheck E2E.BinCheck

/-- The checks of the functions of slice 2 (`staticChks`, the validators, and `linkChks`). -/
theorem slice2_ok : SemanticChecksWith.fnsBProduction actualLower input false slice2 = true := by native_decide

/-- The executable's bytes of the code of slice 2 (and of the GOT slots it loads). -/
def ex2 : Elf.Excerpt := []

/-- The binary check of the functions of slice 2 (`ArtOk`: their code in the executable). -/
theorem slice2_bin : SemanticChecksWith.codeBProduction actualLower input false (exHdr ++ ex2) slice2 = true := by native_decide

end Crates.StockCfgScalarEntryProduction96PlainStrictEntries
