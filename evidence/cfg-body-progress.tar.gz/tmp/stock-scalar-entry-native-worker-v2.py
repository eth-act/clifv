from pathlib import Path
import os,json,subprocess,datetime,hashlib
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');os.chdir(root)
e=os.environ.copy();e.update(json.load(open('/tmp/stock-mixed-div-env.json')));e.update(FV_ROOT=str(root),FV_MEMCAP='8G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',CARGO_BUILD_JOBS='2',FV_CG_CLIF='/home/lee/clifv/.worktrees/driver-proof-resume/target/cg_clif/unwind/librustc_codegen_cranelift.so');e['PATH']=str(root/'rust/target/release')+':'+e['PATH']
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:2]);os.nice(10)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();out=Path('/tmp/stock-scalar-entry-native-v2');out.mkdir(exist_ok=False);records={}
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run(label,args):
 assert head==subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
 log=out/(label+'.log');print(datetime.datetime.now(datetime.timezone.utc).isoformat(),label,flush=True)
 with log.open('w') as f:r=subprocess.run(['scripts/memcap.sh',*args],env=e,stdout=f,stderr=subprocess.STDOUT)
 records[label]={'returncode':r.returncode,'log':str(log),'sha256':sha(log)}
 (out/'receipt.json').write_text(json.dumps({'head':head,'state':'running' if not r.returncode else 'failed','records':records},indent=2)+'\n')
 if r.returncode:raise SystemExit(r.returncode)
tools=['lean-backend','lean-link','link-check','stock-general-div-runtime','stock-general-div-linked','lean-e2e-check','lean-backend-encode-test','clif-decode','lean-ld']
run('tools',['lake','build',*tools])
(out/'tools.json').write_text(json.dumps({'head':head,'binary_sha256':{t:sha(root/'.lake/build/bin'/t) for t in tools}},indent=2)+'\n')
run('integration',['python3','scripts/check-stock-mixed-integration.py','--output','/tmp/stock-scalar-entry-integration-v2','--class','cfgscalarentry','--fixture-mode','native'])
run('native-execution',['python3','scripts/check-stock-mixed-native.py','/tmp/stock-scalar-entry-integration-v2/native-objects','--class','cfgscalarentry'])
run('parent-entry-integration',['python3','scripts/check-stock-mixed-integration.py','--output','/tmp/stock-scalar-entry-parent-entry-integration-v2','--class','cfgentry','--fixture-mode','native'])
run('parent-cfg-integration',['python3','scripts/check-stock-mixed-integration.py','--output','/tmp/stock-scalar-entry-parent-integration-v2','--class','cfg','--fixture-mode','native'])
run('runtime',['bash','scripts/lean-backend-filetests.sh'])
run('encoder',['bash','scripts/lean-backend-encode-check.sh'])
for label,flags in [('e2e',[]),('legacy-e2e',['--no-dead-cleanup'])]:
 run(label,['.lake/build/bin/lean-e2e-check',*flags,'--identity-report',str(out/(label+'-identities.json'))])
parity={}
for label in ['e2e','legacy-e2e']:
 paths={'original':Path('/tmp/legacy-dead-cleanup-final-'+label+'-identities.json'),'parent':Path('/tmp/stock-cfg-entry-body-native-v1/'+label+'-identities.json'),'current':out/(label+'-identities.json')}
 maps={k:{(v['file'],v['function'],v['index']):v['stages'] for v in json.load(p.open())['functions']} for k,p in paths.items()}
 assert len(maps['original'])==1150 and len(maps['parent'])==1159
 for name in ['original','parent']:assert all(maps['current'].get(k)==v for k,v in maps[name].items()),(label,name)
 parity[label]={'counts':{k:len(v) for k,v in maps.items()},'original_and_parent_ordered_stages_exact':True}
(out/'identity-stage-parity.json').write_text(json.dumps(parity,indent=2)+'\n')
for name in ['fv-demo','survey']:run('verified-'+name,['bash','examples/compare.sh','examples/'+name,'--lean-link','--verified','--keep-temps'])
(out/'receipt.json').write_text(json.dumps({'head':head,'state':'passed','records':records},indent=2)+'\n');print('NATIVE_AND_CONSUMER_GATES_PASS',flush=True)
