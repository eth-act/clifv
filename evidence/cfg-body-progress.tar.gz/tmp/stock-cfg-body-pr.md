Stock body proofs previously required a single-block function, and trap extraction required a return-only continuation. This packet derives actual scalar/division/bmask/nop records and body execution across arbitrary original blocks, keeps a later block's trap in its source continuation, and preserves source DFG consistency through actual successor binding under the original scope/dominance conditions.

The additions use isolated modules: every existing FV/FVTest Lean source and import key is preserved. Actual two-block witnesses cover ABI entry, successful return, a later division trap, two source statements and nonempty successor binding. Production CFG activation remains the next step; this is a reusable dependency for branch/value/world and per-edge consumer composition.

Validation on source `c7e249b1` and documentation publication `81b016f2`:

- Full FV/FVTest: 3,984/3,984 keys; eight new modules rebuilt. Publication replay: zero rebuilds.
- All 79 repository audit files pass: 3,540 reports / 3,389 distinct roots.
- All 626 preserved prior axiom sets match exactly; all 3,967 existing Lean sources are byte-exact against main.
- Fourteen general roots use only standard axioms; actual witnesses and bundled MCP reviews pass. Fixed native facts are confined to witnesses.
- No compiler/runtime/consumer implementation or input predicate changes; their existing keys are unchanged.

[Checkpoint and remaining work](https://github.com/eth-act/clifv/blob/81b016f2e10647bf2e467a81b27fe89b7d615c37/docs/research/stock-cfg-body-checkpoint.md). Terminal evidence: `9d04bac5740492dcd6ddaaa209a1e97b80d0d508`, Git path `evidence/cfg-body-progress.tar.gz`, SHA256 `8a776c5846c4c883eaac10b6f0865f5520daa8f04bddf9fd79e8ab802ed0b2ae`. Original intermediate/failed receipts remain preserved and are distinguished from the final passing gates.

Continues #140; full driver/register agreement and Stock-only/downstream completeness remain open.
