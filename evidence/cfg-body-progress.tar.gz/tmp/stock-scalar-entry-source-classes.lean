import FV.Clif.Parse
import FV.Backend.Lowering.StockTwoBlock
import FV.Backend.Lowering.StockTwoBlockEntry
open Backend.Stock
private def withoutForwarding (f : Clif.Function) : Bool :=
  match f.blocks with
  | [entry,target] =>
    match entry.term,target.term with
    | .jump bc,.ret _ =>
      bc.block == target.id && entry.id != target.id &&
      entry.body.all Scalar.maskMixedBodyEligible && target.body.all Scalar.maskMixedBodyEligible &&
      f.sig.params.all Scalar.narrowAbiEligible && f.sig.returns.all Scalar.narrowAbiEligible
    | _,_ => false
  | _ => false
#eval do
  let paths ← IO.FS.readFile "/tmp/stock-scalar-entry-source-class-paths.txt"
  let mut counts := Array.replicate 9 (0 : Nat)
  let mut relaxed : Array String := #[]
  let mut selected : Array String := #[]
  for path in paths.splitOn "\n" do
    if path.isEmpty then continue
    let text ← IO.FS.readFile path
    let pf := Clif.parseFile text
    for parsed in pf.funcs do
      match parsed.func with
      | .error _ => counts := counts.set! 8 (counts[8]!+1)
      | .ok f =>
        let broad := TwoBlock.Entry.eligible f
        let narrow := broad && f.blocks[0]!.body.all TwoBlock.Entry.entryEligible
        let flags := #[true,Scalar.maskEligible f,TwoBlock.eligible f,narrow,broad,withoutForwarding f,
          f.blocks.all (fun b => b.body.all Scalar.maskMixedBodyEligible),
          f.blocks.all (fun b => match b.term with | .jump _ | .ret _ => true | _ => false)]
        for i in List.range flags.size do
          if flags[i]! then counts := counts.set! i (counts[i]!+1)
        if broad && !narrow then selected := selected.push f.name
        if withoutForwarding f && !broad then relaxed := relaxed.push f.name
  IO.println <| Lean.Json.compress <| Lean.toJson (counts.toList,selected.toList,relaxed.toList)
