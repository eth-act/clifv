import FV.Backend.Proof.StockQuietBlockWitness
import FV.Backend.Proof.StockCoverageBlock
#eval Backend.Stock.Proof.Coverage.blockData Backend.Stock.Proof.QuietBlockWitness.function
  Backend.Stock.Proof.QuietBlockWitness.function.blocks[0]!.term
