# Scalar entry bodies in Stock CFG production

Implementation `b0a84c6bdb1f61fc848e7324598c7d267d90aecc`, with fixture/script
corrections through `b0f103011d30fed0eeadf030bac17db500f85261`, extends the
landed dividing-entry class to the complete existing scalar/division/mask
source family. Entry arithmetic, selects, logical operations, NOT, multiplication,
shifts, casts, bit operations, counts, min/max, comparisons, high multiplication,
bmask and nop compose with a scalar return successor. Arbitrary interleavings
retain first-entry traps, inherited values, original source continuation/fuel,
nonempty successor copies, original ABI entry and source slots.

The same input-only class checker derives the existing Scalar.Domain. Existing
compiler/checker/linker/generated-proof adapters and route6 are reused;
indices0–5, original quiet/dividing selectors, old theorem variants, complete
transactional fallback and optimizer/tail/exception routing remain. No allocator,
shared LowerSim, CLIF semantics or machine-model change is introduced.

The source work retains outside-interval frames that existing numerical/root
execution proofs already established. Some wrappers previously discarded those
frames; stronger variants now expose them and keep the old interface as a
wrapper. For one-result roots, actual root allocation supplies the interval
bound. The carry module reuses existing root/operand/binding/value proofs; it
does not introduce a new accepted-program code or value certificate.

Non-vacuity: an actual kernel-checked function executes an entry add feeding a
division, forwards both results, and adds an inherited entry value in its
successor. Instruction-zero7+3, followed by10/3 and inherited7, returns10;
denominator0 traps before the jump. Kernel compilation passed within8GiB,
7.9GiB anonymous peak, following the bounded6GiB retry. The only new fixed
native fact is labelled original-input dominance, confined to witnesses.
Old source-wrapper witnesses continue through the stronger variants.
Two MCP reviews pass: the general domain uses only the standard three axioms;
the complete trap witness adds only that labelled input-dominance fact.
All31 old public theorem headers are exact.

Native/consumer cohort:96 functions, preserving the separate original16-function
dividing-entry and12-function CFG cohorts. The new cohort includes those16 source
shapes and20 representative scalar shapes at each of four widths, nine ABI
arguments, source slot and nonempty successor copies. Mixed-sign high bits,
zero/overflow, first/later traps and real cast-of-comparison remain observable.
Across six ABI configurations, both allocators and both cleanup modes:

-70 actual integration checks and18 generated global/per-entry proof roots pass.
-24 actual encoded objects:23040 Lean byte executions against2880 Cranelift
 reference executions, zero failures/disagreements.
-Both retained cohorts pass their34 actual integration checks each.
-Runtime114 corpus+22extra+5755runnable cases, zero disagreements/failures.
-Encoder1398identical, zero differences.
-BothE2E modes1159accepted, original1150 and parent1159 identities and ordered
 successful stages exactly retained.
-Verified fv-demo21matching tests/two verified executable files.

Pending: verified survey terminal receipt; current4051 normal terminal check;
all91 audits/all3499 old axiom sets and six ownership partitions; actual crate
package; fresh same-input parent byte/relocation comparison. No complete author
or release claim until all required terminal receipts are checked.

Source and progress evidence are backed remotely on
`agent/stock-cfg-body-progress-20261025T025359Z`,
`evidence/cfg-body-progress.tar.gz`; progress snapshot098da531679c07a98a8452a98e323025059c1016
predates terminal remaining gates. Controllers and raw evidence are saved under
`/tmp/stock-scalar-entry-*`. Final publication must include a terminal snapshot
and exact source/binary provenance; documentation-only publication changes do
not relabel earlier source records.

The old multiplying-entry negative control now belongs to the broader class.
Its exact original input remains as positive raw-Stock selection coverage;
a fresh three-block control checks complete previous-route fallback.96-function
programs also produce per-entry proof artifacts, so all four additional Entries
roots are required. Initial harness failures remain saved; no check was dropped.

This advances #140 without closing it. This class still has two blocks and
forwards entry results through the successor argument vector. Arbitrary CFG,
conditional/table/critical edges and loops, effects/memory/calls/exceptions,
original-domain whole-driver simulation and Stock-only/downstream completeness
remain open. Fallback preserves acceptance; it is not a completeness proof.
