from pathlib import Path
import os,json,subprocess,datetime
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');os.chdir(root)
e=os.environ.copy();e.update(json.load(open('/tmp/stock-mixed-div-env.json')));e.update(FV_ROOT=str(root),FV_MEMCAP='8G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',CARGO_BUILD_JOBS='2')
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:2]);os.nice(10)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
with open('/tmp/stock-scalar-entry-normal-v1.log','w') as f:r=subprocess.run(['python3','scripts/lake-serial-build.py','--budget','8G','--max-jobs','1','--min-cap','6G','--default-cap','6G','--max-cap','8G','--out','/tmp/stock-scalar-entry-normal-v1','FV','FVTest'],env=e,stdout=f,stderr=subprocess.STDOUT)
Path('/tmp/stock-scalar-entry-normal-v1.json').write_text(json.dumps({'head':head,'returncode':r.returncode,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'current_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()},indent=2)+'\n');print('normal terminal',r.returncode,flush=True)
