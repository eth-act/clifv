import os,pathlib,json,time,re,subprocess,datetime,hashlib
root=pathlib.Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025')
os.chdir(root)
env=os.environ.copy();env.update(json.load(open('/tmp/stock-mixed-div-env.json')));env.update(FV_ROOT=str(root),FV_MEMCAP='6G')
sched=pathlib.Path('/proc/381728/stat');identity=sched.read_text().split()[21] if sched.exists() else None
state={'source_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'scheduler_pid':381728,'scheduler_starttime':identity,'state':'waiting for actual full-normal scheduler','gates':[]}
receipt=pathlib.Path('/tmp/stock-cfg-body-terminal-gates.json')
def save():
 state['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();tmp=receipt.with_suffix('.tmp');tmp.write_text(json.dumps(state,indent=2)+'\n');tmp.replace(receipt)
save()
while sched.exists() and sched.read_text().split()[21]==identity:time.sleep(5)
log=pathlib.Path('/tmp/stock-cfg-body-full-normal-v1.log').read_text()
if not re.search(r'END 3980/3980 ok,.*',log):
 state['state']='stopped: full-normal success not established';save();raise SystemExit(1)
state['state']='running post-normal trust gates';save()
commands=[('all-axioms',['python3','scripts/axiom-audit.py','--log-dir','/tmp/stock-cfg-body-all-axioms']),('retained-axioms',['python3','scripts/axiom-audit.py','--log-dir','/tmp/stock-cfg-body-retained-audit','/tmp/stock-cfg-body-retained-axioms.lean'])]
for name,cmd in commands:
 e=env.copy();e.update(FV_MEMCAP_UNIT='clifv-stock-cfg-body-'+name,FV_MEMCAP_STATS='/tmp/stock-cfg-body-'+name+'.mem')
 output=pathlib.Path('/tmp/stock-cfg-body-'+name+'.log')
 with output.open('w') as out:r=subprocess.run(['scripts/memcap.sh','taskset','-c','0']+cmd,env=e,stdout=out,stderr=subprocess.STDOUT)
 state['gates'].append({'name':name,'command':cmd,'returncode':r.returncode,'log':str(output),'sha256':hashlib.sha256(output.read_bytes()).hexdigest()});save()
 if r.returncode:state['state']='failed '+name;save();raise SystemExit(r.returncode)
flat=' '.join(pathlib.Path('/tmp/stock-cfg-body-retained-audit/stock-cfg-body-retained-axioms.log').read_text().split());current={r:sorted(a.strip() for a in ax.split(',')) for r,ax in re.findall(r"'(.+?)' depends on axioms: \[([^\]]*)\]",flat)}
for r in re.findall(r"'(.+?)' does not depend on any axioms",flat):current[r]=[]
prior=json.load(open('/tmp/stock-cfg-body-baseline-all-axioms.json'))['axiom_sets'];missing=sorted(set(prior)-set(current));changed={r:{'before':a,'after':current[r]} for r,a in prior.items() if r in current and current[r]!=a}
state['exact_prior_axiom_sets']={'expected':len(prior),'reported':len(current),'missing':missing,'changed':changed}
state['state']='passed' if not missing and not changed else 'failed exact prior axiom parity';save();print(state['state'],flush=True)
raise SystemExit(0 if state['state']=='passed' else 1)
