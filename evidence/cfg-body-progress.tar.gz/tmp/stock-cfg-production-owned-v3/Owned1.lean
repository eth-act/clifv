import Lean
import FV.Backend.ABIReadCfg
import FV.Backend.Lowering.StockTwoBlock
import FV.Backend.Lowering.StockTwoBlockNI
import FV.Backend.Proof.PerEdgeLegacyCompatible
import FV.Backend.Proof.PerEdgeSeq
import FV.Backend.Proof.StockCfgEntryAtWitness
import FV.Backend.Proof.StockCfgReturnAtWitness
import FV.Backend.Proof.StockCfgReturnBlock
import FV.Backend.Proof.StockCfgReturnBlockAt
import FV.Backend.Proof.StockCfgReturnEdge
import FV.Backend.Proof.StockCfgReturnEdgeAt
import FV.Backend.Proof.StockCfgReturnRefines
import FV.Backend.Proof.StockCfgReturnRefinesAt
import FV.Backend.Proof.StockCfgReturnTrapAt
import FV.Backend.Proof.StockCfgReturnTrapEdgeAt
import FV.Backend.Proof.StockCfgReturnWitness
import FV.Backend.Proof.StockComputedCfg
import FV.Backend.Proof.StockGuardedSuccessor
import FV.Backend.Proof.StockInheritedJumpDefined
import FV.Backend.Proof.StockInheritedJumpTrap
import FV.Backend.Proof.StockJumpEntryPrelude
import FV.Backend.Proof.StockPerEdgeReturnContract
import FV.Backend.Proof.StockTwoBlockCheck
import FV.Backend.Proof.StockTwoBlockCompatibility
import FV.Backend.Proof.StockTwoBlockDomain
import FV.Backend.Proof.StockTwoBlockReturn
import FV.Backend.Proof.StockTwoBlockShape
import FV.Backend.Proof.StockTwoBlockTrap
import FV.Backend.Proof.StockTwoBlockTrapWitness
import FV.Backend.SemanticNICheck
import FV.Backend.TwoBlockNIProduction
import FV.E2E.ABIReadCfg
import FV.E2E.ABIReadCfgBoundary
import FV.E2E.CompiledSemanticNI
import FV.E2E.SemanticNIBoundary
import FV.E2E.StockCfgFixtures
import FV.E2E.StockCfgNI
import FV.E2E.StockCfgReadFixture
import FV.E2E.StockCfgWitness
import FVTest.Backend.Lowering.StockTwoBlockProductionRuntime
import FVTest.Backend.Lowering.StockGeneralDivProductionLinked
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let core := #["FV.Backend.ABIReadCfg", "FV.Backend.Lowering.StockTwoBlock", "FV.Backend.Lowering.StockTwoBlockNI", "FV.Backend.Proof.PerEdgeLegacyCompatible", "FV.Backend.Proof.PerEdgeSeq", "FV.Backend.Proof.StockCfgReturnBlock", "FV.Backend.Proof.StockCfgReturnBlockAt", "FV.Backend.Proof.StockCfgReturnEdge", "FV.Backend.Proof.StockCfgReturnEdgeAt", "FV.Backend.Proof.StockCfgReturnRefines", "FV.Backend.Proof.StockCfgReturnRefinesAt", "FV.Backend.Proof.StockCfgReturnTrapAt", "FV.Backend.Proof.StockCfgReturnTrapEdgeAt", "FV.Backend.Proof.StockComputedCfg", "FV.Backend.Proof.StockGuardedSuccessor", "FV.Backend.Proof.StockInheritedJumpDefined", "FV.Backend.Proof.StockInheritedJumpTrap", "FV.Backend.Proof.StockJumpEntryPrelude", "FV.Backend.Proof.StockPerEdgeReturnContract", "FV.Backend.Proof.StockTwoBlockCheck", "FV.Backend.Proof.StockTwoBlockCompatibility", "FV.Backend.Proof.StockTwoBlockDomain", "FV.Backend.Proof.StockTwoBlockReturn", "FV.Backend.Proof.StockTwoBlockShape", "FV.Backend.Proof.StockTwoBlockTrap", "FV.Backend.SemanticNICheck", "FV.Backend.TwoBlockNIProduction", "FV.E2E.ABIReadCfg", "FV.E2E.ABIReadCfgBoundary", "FV.E2E.CompiledSemanticNI", "FV.E2E.SemanticNIBoundary", "FV.E2E.StockCfgFixtures", "FV.E2E.StockCfgNI", "FVTest.Backend.Lowering.StockGeneralDivProductionLinked", "FVTest.Backend.Lowering.StockGeneralDivProductionRuntime", "FVTest.Backend.Lowering.StockTwoBlockProductionRuntime", "FVTest.Backend.Main", "FVTest.E2E.LinkCheckMain", "FVTest.Link.LeanLinkMain"]
  let witnesses := #["FV.Backend.Proof.StockCfgEntryAtWitness", "FV.Backend.Proof.StockCfgReturnAtWitness", "FV.Backend.Proof.StockCfgReturnWitness", "FV.Backend.Proof.StockTwoBlockTrapWitness", "FV.E2E.StockCfgReadFixture", "FV.E2E.StockCfgWitness"]
  let fixedFacts := #["_private.FV.Backend.Proof.StockCfgEntryAtWitness.0.Backend.Stock.Proof.CfgEntryAtWitness.input_checks._native.native_decide.ax_1", "_private.FV.Backend.Proof.StockInheritedFixture.0.Backend.Stock.Proof.InheritedWitness.dominated._native.native_decide.ax_1", "_private.FV.Backend.Proof.StockTwoBlockTrapWitness.0.Backend.Stock.Proof.TwoBlockTrapWitness.dominated._native.native_decide.ax_1"]
  let mut ncore : Nat := 0
  let mut nwitness : Nat := 0
  for (name,_) in env.constants.toList do
    let some i := env.getModuleIdxFor? name | continue
    let owner := env.header.moduleNames[i]!.toString
    unless core.contains owner || witnesses.contains owner do continue
    for ax in ← collectAxioms name do
      if #[``propext,``Classical.choice,``Quot.sound].contains ax then continue
      unless witnesses.contains owner && fixedFacts.contains ax.toString do
        throwError "disallowed axiom {ax} in {name} owned by {owner}"
    if core.contains owner then ncore := ncore+1 else nwitness := nwitness+1
  unless ncore > 0 && nwitness > 0 do throwError "empty ownership partition"
  logInfo m!"STOCK_CFG_OWNED_STANDARD_CORE {ncore}; FIXED_WITNESSES {nwitness}"
