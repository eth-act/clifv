The default compiler now selects actual Stock lowering for a proved two-block class: a constant/nop entry jumps with successor arguments to a scalar/division/mask return block. In the same-input comparison against current main, exact Cranelift byte/relocation matches improve **887 → 900 of 4,543**, with **13 gains and zero losses**.

The source proof composes the same canonical ABI prelude, body, actual successor guards/copies, and return or division trap. An additive CFG ABI-read model handles goto and requires world equality only at true function entry. The checked contract connects through paired physical return execution, compiler/checker selection, verified linking and emitted-proof reconstruction. Failed candidates retry the previous complete pipeline with the original input/settings; retained route indices keep their meanings.

Real verified examples exposed a CLI routing mismatch: its global try-call guard skipped a passing CFG provider and retried a differently sized legacy region. Mixed programs containing the new CFG class now use the existing checked semantic provider alongside retained try-call functions. Optimizer/tail routes, other exception selection and transactional fallbacks remain.

Validation on implementation `5f35e773` (publication changes documentation only; all validated source/binary hashes preserved):

- FV/FVTest **4041/4041**; **89 axiom audits**, 3486 distinct roots, all **3425 previous axiom sets exact**; six declaration-owner partitions and bundled MCP reviews clear. Old theorem headers preserved.
- **34 integration checks**, including both allocators/cleanup modes, mixed try calls, retained routes, actual CLI/verified linking and generated proofs/axioms.
- **2880 native Lean byte executions**, zero disagreements; corpus114, extra22 and runtests5755 pass; encoder **1398 identical, zero differences**.
- Both E2E modes accept1159 functions, preserving all original1150 and prior1159 identities and ordered stages exactly.
- Verified fv-demo **21 matching tests/two verified executables**; survey **53 matching tests/18 verified executables**; actual crate-proofs package build passes.
- Paired main comparison recompiles every captured decoded input with identical settings, object order, gap words and symbol renaming. All4543 identities match;13 gains/zero losses. Temporary baseline worktree removed after preserving evidence.

Detailed receipt and remaining scope: `docs/research/stock-two-block-source.md`. This increment advances #140; broader CFGs, effects/calls and original-domain whole-driver simulation and Stock-only completeness remain open.

Recovery evidence: [50560608](https://github.com/eth-act/clifv/tree/50560608e5412bafa2865e469dca93379d4b4741/evidence), including terminal receipts, input/source/binary hashes and failed attempts.
