The default compiler currently uses the previous Scalar provider for direct control flow. This change enables actual Stock lowering for a proved two-block class: a quiet constant/nop entry jumps with successor arguments to a scalar/division/mask return block. Unsupported inputs and failed candidate pipelines retry the prior complete provider with the original source and settings.

The proof composes the same canonical ABI entry, source body, actual successor guards and per-edge copies, and original ABI return or division trap. A new CFG ABI-read model handles goto and restricts argument-read equality to the actual function entry. The resulting checked contract connects through paired physical execution, the compiler, checker, verified linker and emitted-proof consumers. Retained artifact route indices keep their meanings.

Validation already complete on 2de0e762:

- 32 integration checks: both allocators/cleanup modes, strict/fallback, mixed and retained classes, CLI, verified linking and generated proofs/axioms.
- 24 objects, 2,880 native Lean byte executions agree with Cranelift. Exported inputs are byte-identical across the successful native and final integration runs.
- Runtime 5,755 passes, zero failures/disagreements; encoder 1,398 identical functions, zero differences.
- Both E2E modes accept 1,159 functions; all original 1,150 and prior 1,159 identities and ordered stages preserved exactly.
- Remaining author gates pending: full normal input keys, complete axioms/owned constants and exact previous axiom sets; verified examples, actual crate package build and real-crate byte comparison. Do not publish as ready until these are resolved.

This is an incremental production expansion toward #140. Conditional/table control, critical edges/loops, remaining families and effects/calls, and whole-driver simulation/completeness remain open. It does not claim complete register alignment.
