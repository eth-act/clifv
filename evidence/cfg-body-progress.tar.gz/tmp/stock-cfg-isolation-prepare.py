from pathlib import Path
import subprocess,json,hashlib
root=Path.cwd();draft=Path('/tmp/stock-cfg-isolated-packet');p='FV/Backend/Proof/StockQuietSourceRecords.lean';current=(root/p).read_text();old=subprocess.check_output(['git','show','ab1abdfc:'+p],text=True)
a=current.index('namespace Backend.Stock.Proof.QuietSourceColors\nopen Backend.Proof Backend.Proof.Driver\nset_option autoImplicit false\nset_option Elab.async false\n\nprivate abbrev BlockColorState')
b=current.index('end Backend.Stock.Proof.QuietSourceColors',a)+len('end Backend.Stock.Proof.QuietSourceColors\n')
block=current[a:b];start=block.index('private abbrev BlockColorState');stop=block.rindex('end Backend.Stock.Proof.QuietSourceColors');blockBody=block[start:stop]
c=current.index('/-- Actual original block position derives omission/emission and result binding');d=current.index('/-- One original quiet statement derives its actual omission/emission and',c);record=current[c:d]
rest=(current[:a]+current[b:c]+current[d:]).replace('import FV.Backend.Proof.StockBlockRanges\n','');assert [x for x in rest.splitlines(True) if x.strip()]==[x for x in old.splitlines(True) if x.strip()]
h=current.index('private abbrev ColorState');i=current.index('/-- Only the selected source position must be quiet.',h);bodyHelpers=current[h:i]
h=current.index('private theorem records_execute');i=current.index('/-- Actual original block position',h);recordHelper=current[h:i]
new='import FV.Backend.Proof.StockQuietSourceRecords\nimport FV.Backend.Proof.StockBlockRanges\n\nnamespace Backend.Stock.Proof.QuietSourceColors\nopen Backend.Proof Backend.Proof.Driver\nset_option autoImplicit false\nset_option Elab.async false\n\n'+bodyHelpers+blockBody+recordHelper+record+'end Backend.Stock.Proof.QuietSourceColors\n'
(draft/'StockQuietSourceRecords.lean').write_text(old);(draft/'StockQuietBlockSourceRecords.lean').write_text(new)
p=root/'FV/Backend/Proof/StockQuietBlockWitness.lean';s=p.read_text();assert s.startswith('import FV.Backend.Proof.StockQuietSourceRecords\n');(draft/p.name).write_text(s.replace('import FV.Backend.Proof.StockQuietSourceRecords\n','import FV.Backend.Proof.StockQuietBlockSourceRecords\n',1))
p=root/'FV/Backend/Proof/StockMaskBlockRecords.lean';(draft/p.name).write_text('import FV.Backend.Proof.StockQuietBlockSourceRecords\n'+p.read_text())
meta=json.loads((draft/'metadata.json').read_text());meta.update(old_quiet_source_records_exact=True,quiet_generic_public_proof_bodies_exact=True,quiet_helpers='Unchanged private body-step/color and scan-execution helpers copied into the additive module; no old module imports the new CFG interface.',files={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in draft.glob('*.lean')});(draft/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n');print('Prepared old-module restoration and additive CFG isolation:',len(meta['files']),'files; NOT APPLIED')
