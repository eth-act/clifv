from pathlib import Path
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025/FV/Backend/Proof')
p=root/'StockCastCmpSourceValues.lean';s=p.read_text();a=s.index('theorem stock_lower_cast_cmp_source_values ');b=s.index('\nend Backend.Stock.Proof.ScalarCmp',a);old=s[a:b];h,proof=old.split(' := by',1)
frame="(∀ key,key < record.input.base.nextVreg ∨ record.output.state.base.nextVreg ≤ key → ρ' key = ρ key)"
nh=h.replace('theorem stock_lower_cast_cmp_source_values ','theorem stock_lower_cast_cmp_source_values_framed ',1).replace('step.results = [[.vreg d .int]] ∧','step.results = [[.vreg d .int]] ∧\n        '+frame+' ∧',1)
a2=proof.index('  refine ⟨outputRegs,?_⟩');rest=proof[a2+len('  refine ⟨outputRegs,?_⟩\n'):];proof=proof[:a2]+'''  refine ⟨outputRegs,?_,?_⟩
  · intro key outside
    exact kept key (by simpa only [scan_frontier,recordBase] using outside)
  · '''+rest.splitlines()[0].lstrip()+'\n'+'\n'.join('  '+line for line in rest.splitlines()[1:])+'\n'
wrapper=h+''' := by
  obtain ⟨memory,execution⟩ := stock_lower_cast_cmp_source_values_framed run scope dominated
    events records foundBlock foundStmt current source clif results statementResults mapped recorded emitted
    selectedId refines dfg held sourceStep
  refine ⟨memory,?_⟩
  intro world
  obtain ⟨d,ρ',w',executed,same,output,_,post⟩ := execution world
  exact ⟨d,ρ',w',executed,same,output,post⟩
'''
s=s[:a]+nh+' := by'+proof+'\n/-- Retained original interface. -/\n'+wrapper+s[b:];p.write_text(s)
p=root/'StockCastCmpCompleteSourceTransfer.lean';s=p.read_text();a=s.index('theorem extend_source_of_memory_formats ');b=s.index('\nend Backend.Stock.Proof.CastComplete',a);old=s[a:b];h,proof=old.split(' := by',1)
nh=h.replace('theorem extend_source_of_memory_formats ','theorem extend_source_of_memory_formats_framed ',1)+' ∧\n      '+frame
proof=proof.replace("exact ⟨ρ',w',executed,SameWorld.nf same,post⟩","exact ⟨ρ',w',executed,SameWorld.nf same,post,kept⟩")
proof=proof.replace('ScalarCmp.stock_lower_cast_cmp_source_values ','ScalarCmp.stock_lower_cast_cmp_source_values_framed ').replace("⟨d,ρ',w',executed,same,_,post⟩","⟨d,ρ',w',executed,same,_,kept,post⟩").replace("exact ⟨ρ',w',executed,same,post⟩","exact ⟨ρ',w',executed,same,post,kept⟩")
wrapper=h+''' := by
  obtain ⟨memory,execution⟩ := extend_source_of_memory_formats_framed run scope dominated
    events records block statement current family sg source clif results statementResults mapped recorded emitted
    refines dfg held sourceStep
  refine ⟨memory,?_⟩
  intro world
  obtain ⟨ρ',w',executed,same,post,_⟩ := execution world
  exact ⟨ρ',w',executed,same,post⟩
'''
s=s[:a]+nh+' := by'+proof+'\n/-- Retained original interface. -/\n'+wrapper+s[b:];p.write_text(s)
