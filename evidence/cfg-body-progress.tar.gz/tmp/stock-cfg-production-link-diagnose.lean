import FVTest.Link.LeanLinkMain
open Backend E2E E2E.LinkCheck Link
#eval do
  for name in ["leanlink-905d7d67908f", "leanlink-e91ae561a38d"] do
    let dir : System.FilePath := "/home/lee/clifv/.worktrees/stock-cfg-source-20261025/examples/fv-demo/target/fv/plain-leanlink-verified-leanld/tmp/" ++ name ++ "/input"
    let pair : Front.Bundle × String ← Front.readBundle dir []
    let b0 : Front.Bundle := pair.1
    let exe : String := pair.2
    let S : LinkSpec ← match Front.buildSpec {b0 with sizes := b0.markers.map fun (p : String × Nat) => (p.1,0)} with
      | .ok s => pure s
      | .error e => throw (IO.userError e)
    let tailOn := S.funcs.any (fun (fi : FnInput) => Opt.TailLoop.eligB fi.func)
    let tries := S.funcs.filter fun (fi : FnInput) => fi.func.blocks.any (fun b => b.term.isTry)
    let cfgs := S.funcs.filter (fun (fi : FnInput) => Stock.TwoBlock.eligible fi.func)
    IO.println s!"INPUT {name}: funcs={S.funcs.length}, tail={tailOn}, tries={tries.length}, cfg={cfgs.length}"
    let SC0 := if tailOn then S.tail else S
    let file ← IO.FS.readBinFile exe
    for (label,lower) in [("cfg",Stock.TwoBlock.lowerValidated),("scalar",Stock.Scalar.lowerValidated)] do
      let SP := SC0.placedProductionWith lower true
      let result := SemanticCompilerWith.attempt lower SP file true
      match result with
      | .ok _ => IO.println s!"{label}: PASS place={SP.placeOkB} region={SP.size}"
      | .error e => IO.println s!"{label}: FAIL place={SP.placeOkB} region={SP.size}: {e}"
