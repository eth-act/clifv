from pathlib import Path
import json,subprocess,hashlib,sys
root=Path.cwd();base='61934c30ad6b466b9dc7727aa9a837e6c31b3637';head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();changes=[s.split('\t',1) for s in subprocess.check_output(['git','diff','--name-status',base,head],text=True).splitlines()]
assert all(status=='A' or path.startswith('docs/') for status,path in changes),changes
assert not subprocess.check_output(['git','diff','--name-only'],text=True).strip()
newmods=['FV.Backend.Proof.StockDemandedUnsunk','FV.Backend.Proof.StockDemandedScan','FV.Backend.Proof.StockReturnedDefinitionRetention','FV.Backend.Proof.StockReturnedDefinitionWitness'];oldlean=subprocess.check_output(['git','ls-tree','-r','--name-only',base,'FV','FVTest'],text=True).splitlines();forbidden=[]
for path in oldlean:
 if not path.endswith('.lean'):continue
 for line in Path(path).read_text().splitlines():
  if line.startswith('import ') and any(m in line.split()[1:] for m in newmods):forbidden.append((path,line))
assert not forbidden,forbidden
mcp=json.load(open('/tmp/stock-returned-definition-mcp-review-input.json'));assert hashlib.sha256(Path(mcp['file']).read_bytes()).hexdigest()==mcp['source_sha256'];raw=json.load(open(mcp['raw_review']));assert raw['structuredContent']['axioms']==['propext','Classical.choice','Quot.sound'] and raw['structuredContent']['warnings']==[]
r={'state':'passed','base':base,'head':head,'changes':changes,'existing_source_files_unchanged':True,'new_modules_imported_by_existing_consumers':forbidden,'normal_gate_scope':'new modules and actual683import closure; old compiler/checker/linker/generated consumers and old theorem declarations/import closures byte-identical to521','historical_runtime_evidence':'521 actual1239 runtime/native/encoder/identity-stage/consumer/example evidence remains historical; no new runtime pass claimed','mcp_original_dirty_review_input':mcp,'mcp_source_exact':True};Path(sys.argv[1]).write_text(json.dumps(r,indent=2)+'\n');print('EXISTING_SOURCE_AND_CONSUMER_IMPORTS_EXACT; MCP_SOURCE_EXACT')
