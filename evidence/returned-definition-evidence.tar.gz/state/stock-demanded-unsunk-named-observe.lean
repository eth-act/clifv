import FV.Backend.Proof.StockPolicy
namespace Backend.Stock.Proof
open Isle Isle.Interp Isle.Aarch64
private def ctx : Ctx := {sinkCtx with insts := #[{sinkCtx.insts[0]! with results := [0]},{sinkCtx.insts[0]! with results := [1]}]}
private def st : State := {sinkState with entryColor := #[1,2],color := some 3,demand := #[1,0],sunk := #[false,false]}
#eval match Stock.runTerm ctx "sink_inst" [.inst 1] st with
  | .ok (_,next,trace) => next.sunk == #[false,true] && next.demand == #[1,0] && trace.isEmpty
  | .error _ => false
#eval match scanBlock ctx 0 1 true [1] st with
  | .ok output => output.records.length == 1 && output.state.sunk == #[false,false]
  | .error _ => false
end Backend.Stock.Proof
