from pathlib import Path
import json,subprocess,os,time,signal,datetime,hashlib
root=Path('/home/lee/clifv/.worktrees/stock-mixed-div-20261022');os.chdir(root);r=json.load(open('/tmp/stock-demanded-unsunk-build-drain.json'));env=os.environ.copy();env.update(json.load(open('/tmp/stock-mixed-div-env.json')));env['FV_MEMCAP']='8G'
try:
 for child in r['children']:
  while Path(f'/proc/{child}/stat').exists():
   if Path(f'/proc/{child}/stat').read_text().split(') ')[1].split()[0]=='Z':break
   time.sleep(3)
 src=root/'FV/Backend/Proof/StockDemandedUnsunk.lean';source=hashlib.sha256(src.read_bytes()).hexdigest()
 with open('/tmp/stock-demanded-unsunk-solo-build.log','w') as f:p=subprocess.run(['scripts/memcap.sh','lake','build','FV.Backend.Proof.StockDemandedUnsunk'],env=env,stdout=f,stderr=subprocess.STDOUT)
 assert hashlib.sha256(src.read_bytes()).hexdigest()==source
 Path('/tmp/stock-demanded-unsunk-solo-build.json').write_text(json.dumps({'exit':p.returncode,'source_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_sha256':source,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'new uncommitted demanded-unsunk leaf and its normal imports only'},indent=2)+'\n');print('exit',p.returncode,flush=True)
finally:
 if Path('/proc/1085232/cmdline').exists():os.kill(1085232,signal.SIGCONT)
 r['resumed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();Path('/tmp/stock-demanded-unsunk-build-drain.json').write_text(json.dumps(r,indent=2)+'\n')
