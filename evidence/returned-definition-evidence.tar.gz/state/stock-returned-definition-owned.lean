import Lean
import FV.Backend.Proof.StockDemandedUnsunk
import FV.Backend.Proof.StockDemandedScan
import FV.Backend.Proof.StockReturnedDefinitionRetention
import FV.Backend.Proof.StockReturnedDefinitionWitness
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let core := #["FV.Backend.Proof.StockDemandedUnsunk", "FV.Backend.Proof.StockDemandedScan", "FV.Backend.Proof.StockReturnedDefinitionRetention"]
  let witnesses := #["FV.Backend.Proof.StockReturnedDefinitionWitness"]
  let fixedFacts := #["Backend.Stock.Proof.ReturnedDefinitionWitness.checks_true._native.native_decide.ax_1"]
  let mut ncore : Nat := 0
  let mut nwitness : Nat := 0
  for (name,_) in env.constants.toList do
    let some i := env.getModuleIdxFor? name | continue
    let owner := env.header.moduleNames[i]!.toString
    unless core.contains owner || witnesses.contains owner do continue
    for ax in ← collectAxioms name do
      if #[``propext,``Classical.choice,``Quot.sound].contains ax then continue
      unless witnesses.contains owner && fixedFacts.contains ax.toString do
        throwError "disallowed axiom {ax} in {name} owned by {owner}"
    if core.contains owner then ncore := ncore+1 else nwitness := nwitness+1
  unless ncore > 0 do throwError "empty core partition"
  unless nwitness > 0 do throwError "empty witness partition"
  logInfo m!"STOCK_RETURNED_DEFINITION_OWNED_STANDARD_CORE {ncore}; FIXED_WITNESSES {nwitness}"
