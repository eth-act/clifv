
private def skipCtx : Ctx :=
  {sinkCtx with insts := #[{sinkCtx.insts[0]! with results := [0]},{sinkCtx.insts[0]! with results := [1]}]}
private def skipState : State :=
  {sinkState with entryColor := #[1,2],color := some 3,demand := #[1,0],sunk := #[false,false]}
private def skipped : Scan := ⟨scanState skipState 1,none,#[]⟩
private def scanned : BlockScan := ⟨skipped.state,[⟨1,skipState,skipped⟩],#[]⟩

/-- A real branch slot produces a nonempty scan while a demanded colored
neighbor remains protected. The helper sink witnesses cover changed sunk bits. -/
theorem stock_scan_demanded_unsunk_witness :
    scanInstruction skipCtx 0 1 1 true skipState = .ok skipped ∧
    skipState.entryColor[0]! ≠ 0 ∧ skipState.demand[0]! ≠ 0 ∧
    DemandedUnsunkLe skipCtx skipState skipped.state := by
  have run : scanInstruction skipCtx 0 1 1 true skipState = .ok skipped := rfl
  exact ⟨run,by decide,by decide,stock_scan_demanded_unsunk run⟩

/-- A complete nonempty scan inhabits the block invariant. -/
theorem stock_scanBlock_demanded_unsunk_witness :
    scanBlock skipCtx 0 1 true [1] skipState = .ok scanned ∧
    scanned.records.length = 1 ∧ DemandedUnsunkLe skipCtx skipState scanned.state := by
  have run : scanBlock skipCtx 0 1 true [1] skipState = .ok scanned := rfl
  exact ⟨run,rfl,stock_scanBlock_demanded_unsunk run⟩

/-- Actual retained input/output boundaries inhabit the complete scan relation. -/
theorem stock_scans_demanded_unsunk_witness :
    ScansSpec (fun i => scanInstruction skipCtx 0 i 1 true) [1] skipState scanned ∧
    scanned.records.length = 1 ∧ DemandedUnsunkLe skipCtx skipState scanned.state ∧
    ∀ r ∈ scanned.records,DemandedUnsunkLe skipCtx skipState r.input ∧
      DemandedUnsunkLe skipCtx skipState r.output.state := by
  have run : scanBlock skipCtx 0 1 true [1] skipState = .ok scanned := rfl
  have cert := runScans_spec run
  obtain ⟨last,records⟩ := stock_scans_demanded_unsunk cert
  exact ⟨cert,rfl,last,records⟩
