from pathlib import Path
import os,json,subprocess,hashlib,datetime,tarfile,io
root=Path.cwd();head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();outdir=Path('/tmp/stock-returned-definition-current-author');receipt=json.load(open(outdir/'receipt.json'));assert receipt['state']=='passed' and receipt['head']==head
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();records=[]
for gate in json.load(open('/tmp/stock-returned-definition-current-manifest.json'))['gates']:
 p=outdir/(gate['id']+'.json');r=json.load(open(p));assert r['state']=='passed' and r['source_head']==head and r['returncode']==0;assert sha(r['log'])==r['log_sha256']
 for f,h in r['outputs'].items():assert sha(f)==h
 records.append({'gate':gate['id'],'record':str(p),'sha256':sha(p)})
terminal={'state':'passed','validated_code_head':head,'base':'61934c30ad6b466b9dc7727aa9a837e6c31b3637','gates':records,'normal_keys':682,'audit_roots':20,'standard_core_constants':134,'fixed_witness_constants':16,'exact_native_facts':1,'new_generic_modules':3,'new_complete_witness_modules':1,'mcp':'One actual source-matched bundled review,Std3/no warnings; original dirty06input metadata retained','existing_sources_and_consumer_imports':'Exact current-main source parity; no existing consumer imports these new leaf modules','runtime_evidence':'Unchanged by this additive proof packet; actual521historical provenance retained, no new runtime pass claimed','full_140_complete':False,'next':'Activate the shared source return-and-trap domain for returned division at arbitrary positions; retain full original140other effects/control/calls/whole-driver and completeness obligations.'};Path('/tmp/stock-returned-definition-terminal-validation.json').write_text(json.dumps(terminal,indent=2)+'\n')
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');dest=Path('/tmp/stock-returned-definition-backup-'+stamp);dest.mkdir();files={}
for pattern in ['stock-returned-definition-*','stock-demanded-*']:
 for p in Path('/tmp').glob(pattern):
  if p==dest:continue
  if p.is_file():files['state/'+p.name]=p
  elif p.is_dir():
   for f in p.rglob('*'):
    if f.is_file():files['details/'+p.name+'/'+str(f.relative_to(p))]=f
for name in ['stock-mixed-div-merged.json','stock-mixed-div-cleanup.json','stock-completed-review-worker-cleanup.json','stock-div-current-status.md','stock-retention-kev-boundary.md','stock-mixed-div-landed-comment.md']:
 p=Path('/tmp')/name
 if p.is_file():files['state/'+name]=p
manifest={'validated_code_head':head,'full_140_complete':False,'files':{}};archive=dest/'returned-definition-evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=1) as tar:
 for name,p in sorted(files.items()):
  b=p.read_bytes();manifest['files'][name]={'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)};i=tarfile.TarInfo(name);i.size=len(b);tar.addfile(i,io.BytesIO(b))
 b=json.dumps(manifest,indent=2).encode();i=tarfile.TarInfo('manifest.json');i.size=len(b);tar.addfile(i,io.BytesIO(b))
assert archive.stat().st_size<90*1024**2
E=os.environ.copy();E['GIT_INDEX_FILE']=str(dest/'index');subprocess.run(['git','read-tree',head],env=E,check=True);blob=subprocess.check_output(['git','hash-object','-w',str(archive)],text=True).strip();subprocess.run(['git','update-index','--add','--cacheinfo','100644',blob,'evidence/returned-definition-evidence.tar.gz'],env=E,check=True);tree=subprocess.check_output(['git','write-tree'],env=E,text=True).strip();commit=subprocess.check_output(['git','commit-tree',tree,'-p',head],input=b'Back up complete arbitrary-position returned division retention evidence\n').decode().strip();branch='agent/stock-returned-retention-evidence-'+stamp;subprocess.run(['git','update-ref','refs/heads/'+branch,commit],check=True);subprocess.run(['git','push','origin',commit+':refs/heads/'+branch],check=True);assert subprocess.check_output(['git','ls-remote','origin','refs/heads/'+branch],text=True).split()[0]==commit
r={'state':'remote_verified','validated_code_head':head,'backup_commit':commit,'branch':branch,'files':len(files),'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive),'archive':str(archive)};Path('/tmp/stock-returned-definition-backup.json').write_text(json.dumps(r,indent=2)+'\n');(dest/'index').unlink();print(json.dumps(r))
