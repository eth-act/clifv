from pathlib import Path
import json,subprocess,os,time,datetime,hashlib
root=Path('/home/lee/clifv/.worktrees/stock-mixed-div-20261022');os.chdir(root);r=json.load(open('/tmp/stock-demanded-active-priority.json'));env=os.environ.copy();env.update(json.load(open('/tmp/stock-mixed-div-env.json')));env['FV_MEMCAP']='8G';env['FV_MEMCAP_STATS']='/tmp/stock-demanded-scan-solo.mem'
for child in r['children']:
 while Path(f'/proc/{child}/stat').exists():
  if Path(f'/proc/{child}/stat').read_text().split(') ')[1].split()[0]=='Z':break
  time.sleep(3)
paths=['FV/Backend/Proof/StockDemandedUnsunk.lean','FV/Backend/Proof/StockDemandedScan.lean'];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();sources={p:sha(p) for p in paths}
with open('/tmp/stock-demanded-scan-solo.log','w') as f:p=subprocess.run(['scripts/memcap.sh','lake','build','FV.Backend.Proof.StockDemandedScan'],env=env,stdout=f,stderr=subprocess.STDOUT)
assert sources=={p:sha(p) for p in paths}
Path('/tmp/stock-demanded-scan-solo.json').write_text(json.dumps({'exit':p.returncode,'source_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'dirty':True,'source_sha256':sources,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'two new leaf modules and normal import closure,8GiBsolo; optional513dispatch remains waiting_resources'},indent=2)+'\n');print('exit',p.returncode,flush=True)
