import FV.Backend.MemoryNIProduction
import FV.Opt.Legalize128Pass
import FV.Clif.Parse

set_option autoImplicit false

def main (args : List String) : IO UInt32 := do
  let files ← IO.FS.readFile (args[0]?.getD "")
  for path in files.splitOn "\n" do
    unless path.isEmpty do
      let text ← IO.FS.readFile path
      let pf := (Opt.Legalize128.parsedFile128 (Clif.parseFile text)).file
      if pf.funcs.length != 1 then throw (IO.userError s!"expected one function: {path}")
      for parsed in pf.funcs do
        match parsed.func with
        | .error error => throw (IO.userError s!"{path}: {repr error}")
        | .ok f =>
          let eligible := Backend.Stock.Memory.eligible f
          let sourceOk := Backend.Stock.Memory.sourceOk f
          let selected := if eligible then
            match Backend.Stock.lower f with
            | .ok result => Backend.Stock.Memory.check f result.code
            | .error _ => false
            else false
          IO.println (Lean.Json.compress (Lean.Json.mkObj [
            ("path", Lean.toJson path), ("function", Lean.toJson f.name),
            ("eligible", Lean.toJson eligible), ("source_ok", Lean.toJson sourceOk),
            ("checked_stock_memory", Lean.toJson selected)]))
  pure 0
