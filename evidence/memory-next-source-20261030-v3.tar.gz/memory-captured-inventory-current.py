from pathlib import Path
import json,hashlib,subprocess,os
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025')
e=Path('/home/lee/clifv/.git/agent-evidence/stock-memory-20261029')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
provenance=e/'historical/stock-memory-production-paired-actual-v1/provenance.json'
p=json.loads(provenance.read_text()); sources=p['original_sources']; assert len(sources)==4543
out=e/'memory-captured-inventory-current';out.mkdir(exist_ok=False)
paths=[]
for original,digest in sorted(sources.items()):
 path=e/'historical-root'/original.lstrip('/')
 assert sha(path)==digest,(str(path),'saved original source hash mismatch')
 paths.append(path)
listing=out/'sources.txt';listing.write_text(''.join(str(path)+'\n' for path in paths))
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert head==json.loads((e/'author-source-v1.json').read_text())['head']
env=dict(os.environ);env.update(json.loads((e/'author-env-v1.json').read_text()));env['FV_MEMCAP']='8G'
probe=e/'memory-captured-inventory-current.lean';log=out/'rows.jsonl'
with log.open('w') as output, (out/'compiler-stderr.log').open('w') as errors:
 subprocess.run([str(root/'scripts/memcap.sh'),'lake','env','lean','--run',str(probe),str(listing)],cwd=root,env=env,stdout=output,stderr=errors,check=True)
rows=[json.loads(line) for line in log.read_text().splitlines()];assert len(rows)==4543
assert {r['path'] for r in rows}=={str(p) for p in paths}
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head
result=dict(state='passed',head=head,original_sources=len(rows),eligible=sum(r['eligible'] for r in rows),source_ok=sum(r['source_ok'] for r in rows),checked_stock_memory=sum(r['checked_stock_memory'] for r in rows),rows_sha256=sha(log),probe_sha256=sha(probe),original_provenance_sha256=sha(provenance),sources={str(path):sha(path) for path in paths},limits='Actual original captured source with the CLI i128 legalization, source selector and actual Stock/checker result. This is coverage, not output-byte agreement or full-driver completeness.')
(out/'receipt.json').write_text(json.dumps(result,indent=2)+'\n')
print('CAPTURED_MEMORY_INVENTORY_PASS',len(rows),result['eligible'],result['checked_stock_memory'])
