import FV.Backend.Proof.StockRootOpcodeMatch
import FV.Backend.Proof.IselCtlRuleIds
import FV.Backend.Proof.StockMemoryIntegerAddress

namespace Backend.Stock.Memory.ExtendedRoots
open Backend.Proof Backend.Proof.Driver Backend.Stock.Proof
open Backend.Stock.Proof.MemoryHelpers Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
attribute [local irreducible] Isle.Aarch64.program

inductive Kind where
  | unsigned8 | signed8 | unsigned16 | signed16 | unsigned32 | signed32

def Kind.width : Kind → IntegerRoots.Width
  | .unsigned8 | .signed8 => .w8
  | .unsigned16 | .signed16 => .w16
  | .unsigned32 | .signed32 => .w32

def Kind.helper : Kind → IntegerLoad
  | .unsigned8 => .unsigned8 | .signed8 => .signed8
  | .unsigned16 => .unsigned16 | .signed16 => .signed16
  | .unsigned32 => .unsigned32 | .signed32 => .signed32

def Kind.loadOp : Kind → LoadOp
  | .unsigned8 => .uload8 | .signed8 => .sload8
  | .unsigned16 => .uload16 | .signed16 => .sload16
  | .unsigned32 => .uload32 | .signed32 => .sload32

def Kind.sourceOp : Kind → Clif.LoadOp
  | .unsigned8 => .uload8 | .signed8 => .sload8
  | .unsigned16 => .uload16 | .signed16 => .sload16
  | .unsigned32 => .uload32 | .signed32 => .sload32

def Kind.sourceTag : Kind → Nat
  | .unsigned8 => 31 | .signed8 => 32
  | .unsigned16 => 34 | .signed16 => 35
  | .unsigned32 => 37 | .signed32 => 38

def Kind.root : Kind → Rule
  | .unsigned8 => rule_lower_2647 | .signed8 => rule_lower_2650
  | .unsigned16 => rule_lower_2653 | .signed16 => rule_lower_2656
  | .unsigned32 => rule_lower_2659 | .signed32 => rule_lower_2662

private theorem sem_ctor (ctx : Ctx) (t : Term) (vs : List V) (st : State) :
    (Stock.sem ctx).ctor t vs st = Stock.externCtor ctx t vs st := rfl
private theorem sem_i32 (ctx : Ctx) :
    (Stock.sem ctx).prim 14 "I32" = some (.ty (.int 32)) := rfl

private theorem output_run {p : Program} (hp : Data p) (ctx : Ctx) {cfg : Config}
    (hc : cfg.checkOverlap = false) (st : State) (tr : Array RuleId) (n : Nat) (r : Reg) :
    (applyTerm p (Stock.sem ctx) cfg (n+10) 25 172 [.reg r]).run (st,tr) =
      .ok (some (.regsVec [[r]]),st,tr.push rule_prelude_lower_105.id) := by
  have value : ∀ q,Stock.externCtor ctx T.value_reg [.reg r] q = .ok (.regs [r],q) := by
    intro q; rw [stock_ctor_baseOnly ctx T.value_reg _ q (by decide)]; rfl
  have output : ∀ q,Stock.externCtor ctx T.output [.regs [r]] q = .ok (.regsVec [[r]],q) := by
    intro q; rw [stock_ctor_baseOnly ctx T.output _ q (by decide)]; rfl
  cases hp
  isel_eval [*,rule_prelude_lower_105,sem_ctor]

private theorem sem_i8 (ctx : Ctx) :
    (Stock.sem ctx).prim 14 "I8" = some (.ty (.int 8)) := rfl
private theorem sem_i16 (ctx : Ctx) :
    (Stock.sem ctx).prim 14 "I16" = some (.ty (.int 16)) := rfl
private theorem sem_i64 (ctx : Ctx) :
    (Stock.sem ctx).prim 14 "I64" = some (.ty (.int 64)) := rfl

/-- Every extending integer load root records the pointer demand and emits its exact signed or unsigned load. -/
theorem stock_parameter_extending_load_rhs {p : Program} (hp : Data p) (kind : Kind)
    (ctx : Ctx) {cfg : Config} (hc : cfg.checkOverlap = false) {x nreg : Nat}
    (parameter : ctx.defInst? x = none) (mapped : ctx.valueReg? x = some (.vreg nreg .int))
    (flags : Clif.MemFlags) (st : State) (tr : Array RuleId) (n : Nat) :
    ∃ trace,(evalExpr p (Stock.sem ctx) cfg (n+120) kind.root.rhs
      (env3 (.value x) (.op (.memFlags flags)) (.int 0))).run (st,tr) =
        .ok (some (.regsVec [[(st.base.fresh .int).1]]),
          {(st.mark x) with base := (st.base.fresh .int).2.emit (.load kind.loadOp (st.base.fresh .int).1 (.unsignedOffset (.vreg nreg .int) 0) flags)},trace) := by
  have address := fun q trace fuel =>
    IntegerRoots.stock_parameter_load_address_width hp kind.width ctx hc parameter mapped q trace fuel
  have load := fun q trace fuel => integer_load_forward kind.helper hp ctx hc q trace fuel
    (.data 89 VIdx.AMode.UnsignedOffset [.reg (.vreg nreg .int),.op (.uimm12Scaled 0)])
    (.op (.memFlags flags))
    (.load kind.loadOp (q.base.fresh .int).1 (.unsignedOffset (.vreg nreg .int) 0) flags)
    (by cases kind <;> rfl)
  have output := fun q trace fuel r => output_run hp ctx hc q trace fuel r
  have offset (q : State) : Stock.externCtor ctx T.offset32_to_i32 [.int 0] q =
      .ok (.int 0,q) := by
    rw [stock_ctor_baseOnly ctx T.offset32_to_i32 _ q (by decide)]
    rfl
  refine ⟨(((tr.push rule_inst_4064.id).push rule_inst_4038.id).push
    kind.helper.ruleId).push rule_prelude_lower_105.id,?_⟩
  cases kind <;> simp only [Kind.width,IntegerRoots.Width.bits,Kind.helper,Kind.loadOp,Kind.root,
    IntegerLoad.term,IntegerLoad.tag,IntegerLoad.ruleId] at * <;> cases hp <;>
    isel_eval [*,rule_lower_2647,rule_lower_2650,rule_lower_2653,rule_lower_2656,rule_lower_2659,rule_lower_2662,
      sem_ctor,sem_i8,sem_i16,sem_i32,sem_i64,offset] <;> rfl

end Backend.Stock.Memory.ExtendedRoots


namespace Backend.Stock.Memory.ExtendedRoots
open Backend.Proof Backend.Proof.Driver Backend.Stock.Proof Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
attribute [local irreducible] Isle.Aarch64.program

private theorem sem_extract (ctx : Ctx) (t : Term) (v : V) (st : State) :
    (Stock.sem ctx).extract t v st = Backend.externExtract ctx t v st.base := rfl
private theorem sem_unData (ctx : Ctx) (ty t k : Nat) (fs : List V) :
    (Stock.sem ctx).unData ty (.data t k fs) = if t = ty then some (k,fs) else none :=
  Backend.Proof.sem_unData ctx ty t k fs
private theorem match_sem_i32 (ctx : Ctx) :
    (Stock.sem ctx).prim 14 "I32" = some (.ty (.int 32)) := rfl
private theorem sem_eq (ctx : Ctx) (a b : V) : (Stock.sem ctx).eq a b = (a == b) := rfl

/-- The actual memory root matches the original load data, retaining the entire
Stock state and binding the source pointer and flags in its typed environment. -/
theorem stock_match_extending_load {p : Program} (hp : Data p) (kind : Kind) (ctx : Ctx) {cfg : Config}
    {i x : Nat} {info : IInfo} {flags : Clif.MemFlags}
    (source : ctx.insts[i]? = some info)
    (data : info.data = .data 152 16 [.data 151 kind.sourceTag [],.value x,.op (.memFlags flags),.int 0])
    (little : flags.endianness ≠ some .big) (st : State) (tr : Array RuleId) (n : Nat) :
    (matchRule p (Stock.sem ctx) cfg (n+2) kind.root [.inst i]).run (st,tr) =
      .ok (some (env3 (.value x) (.op (.memFlags flags)) (.int 0)),st,tr) := by
  have extraction := ext_inst_data_value ctx st.base source
  rw [data] at extraction
  have endian := (ext_little_or_native_endian_iff ctx st.base flags [.op (.memFlags flags)]).mpr ⟨little,rfl⟩
  cases kind <;> simp only [Kind.sourceTag,Kind.root] at * <;> cases hp <;>
    isel_eval [*,rule_lower_2647,rule_lower_2650,rule_lower_2653,rule_lower_2656,rule_lower_2659,rule_lower_2662,
      sem_extract,sem_unData,match_sem_i32,sem_eq]

end Backend.Stock.Memory.ExtendedRoots


namespace Backend.Stock.Memory.ExtendedRoots
open Backend.Proof Backend.Proof.Driver Backend.Stock.Proof Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000

private def flags : Clif.MemFlags := {trapCode := none}
private def fixture (kind : Kind) : Clif.Function := {
  name := "stock_extending_load_root"
  sig := {
    params := [⟨.i64,.none,.normal⟩]
    returns := [⟨.i64,.none,.normal⟩]
    callConv := some .systemV }
  blocks := [{
    id := 0
    params := [(0,.i64)]
    body := [⟨[2],.load kind.sourceOp .i64 flags 0 0⟩]
    term := .ret [2] }] }

private def built (kind : Kind) : Ctx × Array (Nat × Nat) × State :=
  (Stock.buildCtx (fixture kind)).toOption.getD (sinkCtx,#[],sinkState)

private theorem build_ok (kind : Kind) : Stock.buildCtx (fixture kind) = .ok (built kind) := by
  cases kind <;> rfl
private theorem parameter (kind : Kind) : (built kind).1.defInst? 0 = none := by
  cases kind <;> rfl
private theorem mapped (kind : Kind) :
    (built kind).1.valueReg? 0 = some (.vreg 192 .int) := by
  cases kind <;> rfl

private def rootWitnessOk (kind : Kind) : Bool :=
  match Stock.runTerm (built kind).1 "lower" [.inst 0] (built kind).2.2 with
  | .ok (some _,_,trace) => decide (trace.getLast? = some kind.root.id)
  | _ => false

private theorem roots_succeed (kind : Kind) : rootWitnessOk kind = true := by
  cases kind <;> decide +kernel

/-- Actual first-match Stock selection chooses each signed and unsigned extending load root
in a real source context with a parameter mapped to register192. -/
theorem extending_load_root_witness (kind : Kind) :
    ∃ (f : Clif.Function) (ctx : Ctx) (ranges : Array (Nat × Nat))
      (st next : State) (out : V) (trace : List RuleId),
      Stock.buildCtx f = .ok (ctx,ranges,st) ∧
      ctx.valueReg? 0 = some (.vreg 192 .int) ∧
      Stock.runTerm ctx "lower" [.inst 0] st = .ok (some out,next,trace) ∧
      trace.getLast? = some kind.root.id := by
  have checked := roots_succeed kind
  unfold rootWitnessOk at checked
  cases actual : Stock.runTerm (built kind).1 "lower" [.inst 0] (built kind).2.2 with
  | error error => rw [actual] at checked; cases checked
  | ok result =>
    obtain ⟨out,next,trace⟩ := result
    rw [actual] at checked
    cases out with
    | none => cases checked
    | some out =>
      exact ⟨fixture kind,(built kind).1,(built kind).2.1,(built kind).2.2,
        next,out,trace,build_ok kind,mapped kind,actual,of_decide_eq_true checked⟩

/-- Every root's forward contract has a concrete source-built context. -/
theorem extending_load_rhs_witness (kind : Kind) :
    ∃ (ctx : Ctx) (st : State) (trace : Array RuleId),
      ctx.defInst? 0 = none ∧ ctx.valueReg? 0 = some (.vreg 192 .int) ∧
      (evalExpr program (Stock.sem ctx) {} 120 kind.root.rhs
        (env3 (.value 0) (.op (.memFlags flags)) (.int 0))).run (st,#[]) =
        .ok (some (.regsVec [[(st.base.fresh .int).1]]),
          {(st.mark 0) with base := (st.base.fresh .int).2.emit (.load kind.loadOp (st.base.fresh .int).1 (.unsignedOffset (.vreg 192 .int) 0) flags)},trace) := by
  obtain ⟨trace,run⟩ := stock_parameter_extending_load_rhs data_program kind (built kind).1
    (cfg := {}) rfl (parameter kind) (mapped kind) flags (built kind).2.2 #[] 0
  exact ⟨(built kind).1,(built kind).2.2,trace,parameter kind,mapped kind,run⟩

end Backend.Stock.Memory.ExtendedRoots

#print axioms Backend.Stock.Memory.ExtendedRoots.stock_parameter_extending_load_rhs

#print axioms Backend.Stock.Memory.ExtendedRoots.stock_match_extending_load

#print axioms Backend.Stock.Memory.ExtendedRoots.extending_load_root_witness

#print axioms Backend.Stock.Memory.ExtendedRoots.extending_load_rhs_witness


namespace Backend.Stock.Memory.ExtendedRoots
open Backend.Proof Backend.Proof.Driver Backend.Stock.Proof Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm

private theorem opcode_inventory (kind : Kind) :
    sourceOpcodeIds kind.sourceTag = [kind.root.id] := by
  cases kind <;> decide +kernel

section SourceData
attribute [local semireducible] Isle.Aarch64.program

/-- Original source metadata supplies the load opcode and little-endian condition.
The result type remains arbitrary; the source invariant supplies its validity. -/
theorem extending_load_source_data (kind : Kind) {ty : Clif.Ty}
    {f : Clif.Function} {ctx : Ctx} (inv : MappedCtxInv f ctx)
    {i x : Nat} {info : IInfo} {flags : Clif.MemFlags}
    (source : ctx.insts[i]? = some info)
    (clif : info.clif = some (.load kind.sourceOp ty flags x 0)) :
    flags.endianness ≠ some .big ∧
      info.data = .data 152 16
        [.data 151 kind.sourceTag [],.value x,.op (.memFlags flags),.int 0] := by
  have data := inv.data i info _ source clif
  have little : flags.endianness ≠ some .big := by
    intro big
    cases kind <;> simp [Kind.sourceOp,instData,big] at data
  refine ⟨little,?_⟩
  cases kind <;> simp only [Kind.sourceOp,Kind.sourceTag,instData] at data ⊢
  all_goals
    split at data
    · cases data
    · rw [show (flags.endianness == some .big) = false from by simpa using little] at data
      exact (Except.ok.inj data).symm

end SourceData

/-- The unique original source opcode determines the retained root internally.
No global exclusion of load instructions is required. -/
theorem stock_selected_extending_load_rule (kind : Kind) {ty : Clif.Ty}
    {f : Clif.Function} {ctx : Ctx} (inv : MappedCtxInv f ctx)
    {i x : Nat} {info : IInfo} {flags : Clif.MemFlags}
    (source : ctx.insts[i]? = some info)
    (clif : info.clif = some (.load kind.sourceOp ty flags x 0))
    {st next : State} {out : V} {trace : List RuleId}
    (selected : LowerSelection ctx i st out next trace) : selected.rule = kind.root := by
  obtain ⟨little,data⟩ := extending_load_source_data kind inv source clif
  have member := stock_selected_source_opcode_ids inv source clif data selected
  rw [opcode_inventory] at member
  have idEq : selected.rule.id = kind.root.id := List.mem_singleton.mp member
  have candidate : kind.root ∈ program.rulesOf T.lower.id := by
    cases kind <;> rw [show T.lower.id = 686 from rfl,data_program.r686]
    all_goals decide +kernel
  exact eq_of_mem_of_id lower_ids_nodup selected.rule_mem candidate idEq

end Backend.Stock.Memory.ExtendedRoots

#print axioms Backend.Stock.Memory.ExtendedRoots.extending_load_source_data

#print axioms Backend.Stock.Memory.ExtendedRoots.stock_selected_extending_load_rule
