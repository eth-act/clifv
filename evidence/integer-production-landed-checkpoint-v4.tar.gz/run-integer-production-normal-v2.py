from pathlib import Path
import os,json,subprocess,datetime,hashlib
b=Path('/home/lee/clifv');r=b/'.worktrees/stock-cfg-source-20261025';e=b/'.git/agent-evidence/stock-memory-20261029';state=e/'integer-production-normal-state-v2.json';records=[]
os.sched_setaffinity(0,{8,9,10,11})
source=json.loads((e/'integer-production-source-v2.json').read_text())
env=dict(os.environ);env.update(json.loads((e/'author-env-v1.json').read_text()));env.update(FV_ROOT=str(r),FV_MEMCAP='16G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',CARGO_BUILD_JOBS='1')
for k in ['FV_PIPELINE_T','BLESS']:env.pop(k,None)
def save(status,**x):state.write_text(json.dumps(dict(status=status,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),records=records,head=source['head'],**x),indent=2)+'\n')
def frozen():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==source['head']
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=r,text=True).strip()
 assert all(hashlib.sha256((r/n).read_bytes()).hexdigest()==h for n,h in source['files'].items())
def run(label,args):
 frozen();save('running',phase=label)
 with (e/('integer-production-normal-'+label+'-v2.log')).open('w') as log:done=subprocess.run(['nice','-n','10',str(r/'scripts/memcap.sh'),*args],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 records.append(dict(label=label,returncode=done.returncode));assert done.returncode==0,(label,done.returncode)
try:
 frozen()
 run('libraries',['python3','scripts/lake-serial-build.py','--budget','16G','--max-jobs','2','--max-cap','16G','--default-cap','8G','--profile',str(r/'scripts/lake-module-peaks.tsv'),'--profile',str(r/'.lake/lake-module-peaks.tsv'),'--profile',str(e/'production-cold-overrides-v6.tsv'),'--out',str(e/'integer-production-full-modules-v2'),'FV','FVTest','Corpus'])
 tools=json.loads((e/'author-normal-manifest-v1.json').read_text())['gates'][1]['argv']
 run('tools',tools)
 run('all-axioms',['python3','scripts/axiom-audit.py','--log-dir',str(e/'integer-production-all-axioms-v2')])
 frozen();save('passed',scope='Full FV/FVTest/Corpus, author tools, and complete compiler axiom audit. Required runtime and identity gates still follow.')
except BaseException as error:save('failed',error=repr(error));raise
