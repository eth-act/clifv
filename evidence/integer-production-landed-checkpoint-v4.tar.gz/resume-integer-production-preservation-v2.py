from pathlib import Path
import os, subprocess, json, datetime, time, re, hashlib, sys, importlib.util
import psutil

b=Path('/home/lee/clifv');r=b/'.worktrees/stock-cfg-source-20261025'
e=b/'.git/agent-evidence/stock-memory-20261029'
state=e/'integer-production-preservation-state-v2.json';records=[]
env=dict(os.environ);env.update(json.loads((e/'author-env-v1.json').read_text()))
env.update(FV_ROOT=str(r),FV_MEMCAP='4G',OMP_NUM_THREADS='1',OMP_THREAD_LIMIT='1',
           LEAN_NUM_THREADS='1',CARGO_BUILD_JOBS='1')
env.pop('FV_PIPELINE_T',None);env.pop('BLESS',None)

def save(status,**extra):
    state.write_text(json.dumps(dict(status=status,records=records,
        utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),**extra),indent=2)+'\n')

def axioms(path):
    return {n:set(x.strip() for x in a.split(',')) for n,a in
        re.findall(r"'([^']+)' depends on axioms: \[([^]]*)\]",path.read_text(),re.S)}

try:
    assert json.loads((e/'integer-production-original-captures-receipt-v2.json').read_text())['status']=='passed'
    for label,script,baseline,count in [
        ('cfg-source','stock-memory-cfg-source.lean','captured-pc0-audit-v8.log',30),
        ('cfg-production','stock-memory-cfg-production.lean','captured-consumer-audit-v2.log',18)]:
        save('running',phase=label)
        log=e/('integer-production-preservation-'+label+'-v2.log')
        with log.open('w') as stream:
            done=subprocess.run(['nice','-n','10',str(r/'scripts/memcap.sh'),
                'lake','env','lean','-j1','scripts/audit/'+script],cwd=r,env=env,
                stdout=stream,stderr=subprocess.STDOUT)
        records.append(dict(label=label,returncode=done.returncode))
        assert done.returncode==0,(label,done.returncode)
        current=axioms(log)
        assert len(current)==count and current==axioms(e/baseline),(label,'axiom drift')
    sys.path.insert(0,str(r/'scripts'))
    spec=importlib.util.spec_from_file_location('comparison',r/'scripts/stock-compiler-compare.py')
    compare=importlib.util.module_from_spec(spec);spec.loader.exec_module(compare)
    reference=json.loads((e/'captured-object-reference-v1/receipt.json').read_text())
    variants={}
    for manifest in (e/'captured-object-reference-v1').glob('*/first/manifest.json'):
        for variant in json.loads(manifest.read_text())['variants']:
            for name in variant['functions']:
                variants[name.removeprefix('%')]=variant
    out=e/'integer-production-original-rejections-v2';out.mkdir(exist_ok=False)
    for i,row in enumerate(reference['rows']):
        source=Path(row['original_path'])
        assert compare.digest(source.read_bytes())==row['original_sha256']
        request=compare.request_for(variants[row['function']],source.read_bytes())
        requested=out/f'{i}.request.json';requested.write_text(json.dumps(request,indent=2)+'\n')
        receipt=out/f'{i}.receipt.json';obj=out/f'{i}.o';allocation=out/f'{i}.allocator.json'
        save('running',phase='original-rejection-'+str(i))
        with (out/f'{i}.log').open('w') as log:
            done=subprocess.run(['nice','-n','10',str(r/'scripts/memcap.sh'),
                str(r/'.lake/build/bin/lean-backend'),str(source),str(obj),
                '--regalloc','regalloc2','--stock-config',str(requested),
                '--config-receipt',str(receipt),*([] if row['cleanup'] else ['--no-dead-cleanup'])],
                cwd=r,env=dict(env,LEAN_REGALLOC_KEEP=str(allocation)),
                stdout=log,stderr=subprocess.STDOUT)
        old=json.loads((e/f'configured-original-captures-v1/{i}-native-baseline.receipt.json').read_text())
        actual=json.loads(receipt.read_text())
        assert done.returncode==3 and actual==old and actual['request']==request
        assert not actual['configuration_accepted'] and not obj.exists() and not allocation.exists()
        records.append(dict(label='original-rejection-'+str(i),returncode=done.returncode,receipt_exact=True))
    packet=json.loads((e/'integer-production-source-v2.json').read_text())
    assert all(hashlib.sha256((r/n).read_bytes()).hexdigest()==h for n,h in packet['files'].items())
    save('passed',captured_axiom_sets_exact=48,original_settings_rejections_exact=8,
         production_source_unchanged=True,full_goal_complete=False)
except BaseException as error:
    save('failed',error=repr(error));raise
