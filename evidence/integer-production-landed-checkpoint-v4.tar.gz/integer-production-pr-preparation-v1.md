Default and configured compilation now use the proved Stock provider for singleton loads of i8, i16, and i64. Each class loads through a source parameter and returns the result. The existing i32 provider and global routes 0–13 remain intact. The new provider appends route 14 and retains complete legacy fallback.

The change connects the actual scan, body, return, paired execution, machine NI, runtime checker, compiler, linker, and generated proofs. Concrete witnesses start at the ABI entry in two distinct initialized worlds. Original source conditions, theorem variants, settings, allocation callbacks, and cleanup behavior remain intact.

Validation is pending. Replace this paragraph with the authoritative gate results before opening the PR. Required receipts: integer-production-gates-state-v1.json, integer-production-official-state-v1.json, integer-production-original-captures-receipt-v1.json, and integer-production-preservation-state-v1.json. The extending-load drafts remain outside this PR.

Continues #140. The full driver goal remains incomplete.
