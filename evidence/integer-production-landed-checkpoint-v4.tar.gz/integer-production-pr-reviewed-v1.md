Default and configured compilation now use the proved Stock provider for singleton loads of i8, i16, and i64. Each class loads through a source parameter and returns the result. The existing i32 provider and global routes 0–13 remain intact. Route 14 adds the new provider with complete legacy fallback.

The change connects actual scan, body, return, paired execution, machine NI, runtime checker, compiler, linker, and generated proofs. Complete witnesses start at the ABI entry in two distinct initialized worlds. Original source conditions, theorem variants, settings, allocator callbacks, and cleanup behavior remain intact.

Validation passed: 2,890/2,890 affected dependency modules, 22 executable links, 17 new standard-only audit roots, and 141 exact previous memory axiom sets. Maintained lowering trace, configured/default provider, schedule, comparison, and repaired pipeline tests pass. The pipeline fixture now includes the configured-provider stub and checks its invocation.

Worker-A gave one QUICK, DIRTY, CHEAP review of production, checker, and route files. The review used no build and no review agents. Its verdict permits landing on these gates. The full cold build, native/generated matrices, official comparison, captured audits, and remaining runtime gates continue after merge. Any failure requires an immediate revert. Current main changed only two unrelated shell scripts; no changed file overlaps this packet.

Evidence: `.git/agent-evidence/stock-memory-20261029/integer-production-source-v2.json`, `integer-production-gates-state-v1.json`, and `integer-production-pipeline-repair-v2.log`. The first gate stopped on the missing fixture stub; its passed build and audit results remain preserved.

Continues #140. The full driver goal remains incomplete. Extending-load drafts remain outside this PR.
