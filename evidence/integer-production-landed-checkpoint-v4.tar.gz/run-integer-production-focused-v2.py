from pathlib import Path
import os, subprocess, json, datetime, time, hashlib
import psutil

b=Path('/home/lee/clifv');r=b/'.worktrees/stock-cfg-source-20261025'
e=b/'.git/agent-evidence/stock-memory-20261029'
state=e/'integer-production-focused-state-v2.json';records=[]
source=json.loads((e/'integer-production-source-v2.json').read_text())
env=dict(os.environ);env.update(json.loads((e/'author-env-v1.json').read_text()))
env.update(FV_ROOT=str(r),FV_MEMCAP='12G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',
           LEAN_NUM_THREADS='2',CARGO_BUILD_JOBS='1')
for key in ['FV_PIPELINE_T','BLESS']:
    env.pop(key,None)
os.sched_setaffinity(0,{8,9,10,11})
paused=None

def save(status,**extra):
    state.write_text(json.dumps(dict(status=status,records=records,head=source['head'],
        utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),**extra),indent=2)+'\n')

def live(process):
    try:
        return process.is_running() and process.status()!=psutil.STATUS_ZOMBIE
    except psutil.NoSuchProcess:
        return False

def frozen():
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==source['head']
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=r,text=True).strip()
    assert all(hashlib.sha256((r/n).read_bytes()).hexdigest()==h for n,h in source['files'].items())

def run(label,args):
    frozen();save('running',phase=label,normal_scheduler_paused=paused.pid if paused else None)
    with (e/('integer-production-focused-'+label+'-v2.log')).open('w') as log:
        done=subprocess.run(['nice','-n','10',str(r/'scripts/memcap.sh'),*map(str,args)],
            cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
    records.append(dict(label=label,returncode=done.returncode))
    assert done.returncode==0,(label,done.returncode)

try:
    frozen()
    normal=psutil.Process(3167178)
    assert 'integer-production-normal-v2' in ' '.join(normal.cmdline())
    while live(normal):
        candidates=[]
        for child in normal.children(recursive=True):
            try:
                if child.name().startswith('python') and any(arg.endswith('/lake-serial-build.py') or arg=='scripts/lake-serial-build.py' for arg in child.cmdline()):
                    candidates.append(child)
            except psutil.NoSuchProcess:
                pass
        if candidates:
            assert len(candidates)==1
            paused=candidates[0]
            paused.suspend()
            save('waiting',phase='finish-current-normal-modules',normal_scheduler_paused=paused.pid,
                 reason='Finish every active module without interruption. Pause only future scheduling. Reserve4GiB for the paused normal tree and12GiB for focused checks.')
            while any(live(child) for child in paused.children(recursive=True)):
                time.sleep(5)
            rss=sum(p.memory_info().rss for p in [normal,*normal.children(recursive=True)] if live(p))
            assert rss < 4*1024**3,('Paused normal tree exceeds reserved4GiB',rss)
            break
        save('waiting',phase='normal-tool-phase',dependency_pid=normal.pid)
        time.sleep(5)
    run('exporter-tests',['python3','-m','unittest','discover','-s','scripts','-p','test_stock_exporter.py','-v'])
    for kind in ['parameter','conditional-forward','conditional','forward','linear','scalar-entry','entry','cfg']:
        run('retained-'+kind,[r/'.lake/build/bin/stock-memory-retained',kind])
    for ty in ['i8','i16','i32','i64']:
        run('consumers-'+ty,['python3','scripts/check-stock-memory-integration.py',
            '--output',e/('integer-production-consumers-'+ty+'-v2'),'--load-type',ty])
    run('consumers-cfg32',['python3','scripts/check-stock-memory-integration.py',
        '--output',e/'integer-production-consumers-cfg32-v2','--memory-cfg'])
    for label,file in [('official','resume-integer-production-official-v2.py'),
                       ('captures','resume-integer-production-captures-v2.py'),
                       ('preservation','resume-integer-production-preservation-v2.py')]:
        run(label,['python3',e/file])
    frozen()
    save('passed',normal_scheduler_paused=paused.pid if paused else None,
         scope='Native/generated matrices, retained regressions, complete official comparison, original captures, exact captured audits and original settings rejections. Full runtime/E2E/example/crate gates remain.',full_goal_complete=False)
except BaseException as error:
    save('failed',error=repr(error),post_merge_action='Revert activation immediately under the peer-review condition.')
    raise
finally:
    if paused is not None and live(paused):
        paused.resume()
        (e/'integer-production-normal-resumed-v2.json').write_text(json.dumps(dict(
            scheduler_pid=paused.pid,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
            reason='Focused resource handoff ended; the existing normal scheduler resumes without a restart.'),indent=2)+'\n')
