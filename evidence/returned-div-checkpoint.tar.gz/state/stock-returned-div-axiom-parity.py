from pathlib import Path
import json,re,subprocess
plan=json.load(open('/tmp/stock-returned-div-scope.json'));currentdir=Path('/tmp/stock-returned-div-affected-audits');oldirs=[Path('/tmp/stock-highmul-reconciled-audits'),Path('/tmp/stock-div-current-affected-audits'),Path('/tmp/stock-mixed-div-affected-audits'),Path('/tmp/stock-returned-definition-current-author/audits')]
def roots(paths):
 result={}
 for p in paths:
  s=' '.join(p.read_text().split())
  for name,axes in re.findall(r"'(.+?)' depends on axioms: \[([^]]*)\]",s):result[name]=sorted(set(a.strip() for a in axes.split(',') if a.strip()))
  for name in re.findall(r"'(.+?)' does not depend on any axioms",s):result[name]=[]
 return result
required={};allold={}
for d in oldirs:
 allold.update(roots(sorted(d.glob('*.log'))));required.update(roots([d/(Path(p).stem+'.log') for p in plan['affected_audits'] if (d/(Path(p).stem+'.log')).exists()]))
current=roots(sorted(currentdir.glob('*.log')));missing=sorted(set(required)-set(current));changed=[n for n in required if n in current and required[n]!=current[n]]
r={'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'base':plan['base'],'prior_sources':[str(p) for p in oldirs],'current_roots':len(current),'prior_roots_required':len(required),'missing':missing,'changed':changed,'unrerun_unaffected_historical_roots':len(set(allold)-set(required)),'exact_required_axiom_sets_preserved':not missing and not changed};Path('/tmp/stock-returned-div-axiom-parity.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));assert not missing and not changed
