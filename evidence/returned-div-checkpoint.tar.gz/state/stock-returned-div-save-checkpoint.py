from pathlib import Path
import json,subprocess,os,tarfile,io,hashlib,datetime
root=Path.cwd();head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');out=Path('/tmp/stock-returned-div-checkpoint-'+stamp);out.mkdir()
changed=set(subprocess.check_output(['git','diff','--name-only','HEAD'],text=True).splitlines())|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines());sources={p:root/p for p in changed if (p.startswith('FV/') or p.startswith('FVTest/') or p.startswith('scripts/')) and (root/p).is_file()};files={'source/'+p:f for p,f in sources.items()}
for pattern in ['stock-returned-div-*.json','stock-returned-div-*.log','stock-returned-div-*.mem','stock-returned-div-*.lean','stock-returned-div-*.py','stock-returned-div-*.txt','stock-returned-definition-merged.json','stock-returned-definition-release.json','stock-returned-definition-latest-main-inputs.json','stock-returned-definition-landed.md','stock-returned-definition-review-serial-cleanup.json','stock-div-current-status.md']:
 for p in Path('/tmp').glob(pattern):
  if p.is_file():files['state/'+p.name]=p
for p in Path('/tmp/stock-returned-div-witness-normal').rglob('*'):
 if p.is_file():files['partial-normal/'+str(p.relative_to('/tmp/stock-returned-div-witness-normal'))]=p
manifest={'utc':stamp,'source_base':head,'scope':'Partial implementation backup: generic returned-division body/domain980keys and classifier/source-validator1014keys pass;96pipeline/source witness grid running, new37function runtime/link/native adapters unvalidated, Lake registration staged only. Not merge-ready or full140complete.','files':{}}
archive=out/'returned-div-checkpoint.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=1) as t:
 for name,p in sorted(files.items()):
  b=p.read_bytes();manifest['files'][name]={'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)};i=tarfile.TarInfo(name);i.size=len(b);t.addfile(i,io.BytesIO(b))
 b=json.dumps(manifest,indent=2).encode();i=tarfile.TarInfo('manifest.json');i.size=len(b);t.addfile(i,io.BytesIO(b))
E=os.environ.copy();E['GIT_INDEX_FILE']=str(out/'index');subprocess.run(['git','read-tree',head],env=E,check=True)
for p,dest in [(f,p) for p,f in sources.items()]+[(archive,'evidence/returned-div-checkpoint.tar.gz')]:
 blob=subprocess.check_output(['git','hash-object','-w',str(p)],text=True).strip();subprocess.run(['git','update-index','--add','--cacheinfo','100644',blob,dest],env=E,check=True)
tree=subprocess.check_output(['git','write-tree'],env=E,text=True).strip();commit=subprocess.check_output(['git','commit-tree',tree,'-p',head],input=b'Back up generalized returned division implementation and partial validation\n').decode().strip();branch='agent/stock-returned-div-checkpoint-'+stamp;subprocess.run(['git','update-ref','refs/heads/'+branch,commit],check=True);subprocess.run(['git','push','origin',commit+':refs/heads/'+branch],check=True);assert subprocess.check_output(['git','ls-remote','origin','refs/heads/'+branch],text=True).split()[0]==commit
r={'state':'remote_verified','source_base':head,'backup_commit':commit,'branch':branch,'source_files':len(sources),'files':len(files),'archive_bytes':archive.stat().st_size,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'scope':manifest['scope']};Path('/tmp/stock-returned-div-checkpoint-backup.json').write_text(json.dumps(r,indent=2)+'\n');(out/'index').unlink();print(json.dumps(r))
