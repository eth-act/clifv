from pathlib import Path
import json,subprocess,os,time,datetime
root=Path('/home/lee/clifv/.worktrees/stock-mixed-div-20261022');os.chdir(root);head='b1990ec02ff083882720dcc436d638c0db5f2b04';env=os.environ.copy();env.update(json.load(open('/tmp/stock-mixed-div-env.json')));env['FV_MEMCAP']='16G';dest=Path('/tmp/stock-returned-div-final-components.json');state={'head':head,'state':'waiting_component_gates','steps':[]}
def save():state['utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();dest.write_text(json.dumps(state,indent=2)+'\n')
def run(name,args,cap='16G'):
 assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head
 e=env.copy();e['FV_MEMCAP']=cap;state.update(state='running',current=name);save();log=Path('/tmp/stock-returned-div-'+name+'-runner.log');print('START',name,flush=True)
 with log.open('w') as f:r=subprocess.run(args,env=e,stdout=f,stderr=subprocess.STDOUT)
 state['steps'].append({'id':name,'exit':r.returncode,'log':str(log)});save()
 if r.returncode:raise RuntimeError((name,r.returncode,str(log)))
 print('PASS',name,flush=True)
def gates(name):run(name,['python3','scripts/stock-delivery-gates.py','run','/tmp/stock-returned-div-'+name+'-manifest.json','--root',str(root),'--out','/tmp/stock-returned-div-'+name+'-author'],'8G')
try:
 save()
 while True:
  p=Path('/tmp/stock-returned-div-after-fixtures.json');r=json.loads(p.read_text());assert r['head']==head
  if r['state']=='failed':raise RuntimeError('earlier component gate failed; inspect its record')
  if r['state']=='component_gates_passed':break
  time.sleep(3)
 run('prepare-owned',['python3','/tmp/stock-returned-div-prepare-owned.py'])
 roots=Path('/tmp/stock-returned-div-owned-roots.txt').read_text().splitlines()
 run('owned-normal',['python3','scripts/lake-serial-build.py','--budget','16G','--max-jobs','1','--default-cap','6G','--max-cap','16G','--out','/tmp/stock-returned-div-owned-normal',*roots])
 gates('owned');gates('integration');gates('retained-integration');gates('full')
 run('retained-flat',['python3','/tmp/stock-div-release-retained-flat-multiply.py','/tmp/stock-returned-div-retained-flat'],'8G')
 gates('examples');state.update(state='passed',next='exactoldAX/header/identity-stage parity, terminalvalidation+archive, currentmainreconciliationandrequiredgates, squash525, cleanupthencontinuefull140');save()
except BaseException as e:state.update(state='failed',error=repr(e));save();raise
