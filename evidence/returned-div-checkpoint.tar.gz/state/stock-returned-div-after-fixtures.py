from pathlib import Path
import json,subprocess,os,time,datetime,hashlib
root=Path('/home/lee/clifv/.worktrees/stock-mixed-div-20261022');os.chdir(root);head='b1990ec02ff083882720dcc436d638c0db5f2b04';env=os.environ.copy();env.update(json.load(open('/tmp/stock-mixed-div-env.json')));env['FV_MEMCAP']='16G';state={'head':head,'state':'waiting_native_fixture_build','steps':[]};dest=Path('/tmp/stock-returned-div-after-fixtures.json')
def save():
 state['utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();dest.write_text(json.dumps(state,indent=2)+'\n')
def run(name,argv,cap='16G'):
 assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head
 state['state']='running';state['current']=name;save();e=env.copy();e['FV_MEMCAP']=cap;log=Path('/tmp/stock-returned-div-'+name+'-runner.log');print('START',name,flush=True)
 with log.open('w') as f:r=subprocess.run(argv,env=e,stdout=f,stderr=subprocess.STDOUT)
 state['steps'].append({'id':name,'exit':r.returncode,'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()});save()
 if r.returncode:raise RuntimeError((name,r.returncode,str(log)))
 print('PASS',name,flush=True)
def gates(name):run(name,['python3','scripts/stock-delivery-gates.py','run','/tmp/stock-returned-div-'+name+'-manifest.json','--root',str(root),'--out','/tmp/stock-returned-div-'+name+'-author'],'8G')
try:
 save()
 while True:
  r=json.load(open('/tmp/stock-returned-div-native-fixture-build.json'));assert r['head']==head
  if any(x['exit'] for x in r['records']):raise RuntimeError('native fixture build failed')
  if len(r['records'])==2:break
  time.sleep(3)
 assert subprocess.check_output(['git','rev-parse','b1ef0c67:rust'],text=True)==subprocess.check_output(['git','rev-parse',head+':rust'],text=True),'Rust oracle source changed; rebuild before comparing'
 gates('native')
 tools=['lean-backend','lean-link','link-check','lean-e2e-check','stock-mixed-div-runtime','stock-mixed-div-linked','clif-decode','lean-ld']
 run('current-tools',['scripts/memcap.sh','lake','build',*tools])
 plan=json.load(open('/tmp/stock-returned-div-scope.json'))
 run('affected-normal',['python3','scripts/lake-serial-build.py','--budget','16G','--max-jobs','1','--default-cap','6G','--max-cap','16G','--only','/tmp/stock-returned-div-affected.txt','--out','/tmp/stock-returned-div-affected-normal',*plan['affected']])
 # Include explicit audit imports (some fixed witnesses are not reverse-dependent roots).
 imports=sorted({line.split()[1] for p in plan['affected_audits'] for line in Path(p).read_text().splitlines() if line.startswith('import ')})
 run('audit-imports',['python3','scripts/lake-serial-build.py','--budget','16G','--max-jobs','1','--default-cap','6G','--max-cap','16G','--out','/tmp/stock-returned-div-audit-imports',*imports])
 run('affected-audits',['scripts/memcap.sh','python3','scripts/axiom-audit.py','--log-dir','/tmp/stock-returned-div-affected-audits',*plan['affected_audits']],'8G')
 state['state']='component_gates_passed';state['next']='ownership/exact oldAXparity, current+retained integration, runtime/encoder/bothidentity-stage reports, old artifacts/examples; final evidence/current-main reconciliation beforemerge';save()
except BaseException as e:
 state.update(state='failed',error=repr(e));save();raise
