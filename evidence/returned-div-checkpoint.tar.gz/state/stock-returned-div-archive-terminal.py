from pathlib import Path
import os,json,subprocess,hashlib,datetime,tarfile,io
root=Path.cwd();head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();validation=json.load(open('/tmp/stock-returned-div-terminal-validation.json'));assert validation['state']=='passed' and validation['validated_code_head']==head
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');out=Path('/tmp/stock-returned-div-terminal-backup-'+stamp);out.mkdir();files={}
for directory in Path('/tmp').glob('stock-returned-div-*-author'):
 if directory.is_dir():
  for p in directory.rglob('*'):
   if p.is_file():files['author/'+directory.name+'/'+str(p.relative_to(directory))]=p
for pattern in ['stock-returned-div-*.json','stock-returned-div-*.py','stock-returned-div-*.log','stock-returned-div-*.md','stock-returned-div-*.txt']:
 for p in Path('/tmp').glob(pattern):
  if p.is_file():files['state/'+p.name]=p
for name in ['stock-returned-div-owned','stock-returned-div-affected-normal','stock-returned-div-owned-normal','stock-returned-div-affected-audits','stock-returned-div-affected-audits-failed-missing-imports','stock-returned-div-retained-flat','stock-returned-div-direct-main-normal','stock-returned-div-new-audits']:
 directory=Path('/tmp')/name
 for p in directory.rglob('*'):
  if p.is_file():files['details/'+name+'/'+str(p.relative_to(directory))]=p
# Preserve unique verified example sources/artifacts and exact comparison logs before cleanup.
import re
for example in ['fv-demo','survey']:
 report=root/'examples'/example/'target/fv-report.json'
 if report.is_file():files['examples/'+example+'/fv-report.json']=report
 for directory in (root/'examples'/example/'target/fv').glob('*/tmp'):
  for p in directory.rglob('*'):
   if p.is_file():files['examples/'+example+'/tmp/'+str(p.relative_to(directory))]=p
for log in Path('/tmp/stock-returned-div-examples-author').glob('verified-*.log'):
 text=log.read_text()
 for folder in re.findall(r'logs: (/tmp/fv-compare\.[A-Za-z0-9]+)',text):
  for p in Path(folder).iterdir():
   if p.is_file():files['examples/comparison/'+Path(folder).name+'/'+p.name]=p
 for label,path in re.findall(r'cargo fv: (binary|lean-link) (\S+):',text):
  p=Path(path)
  if p.is_file():files['examples/executables/'+str(p.relative_to(root))]=p
manifest={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'validated_code_head':head,'full_140_complete':False,'files':{},'scope':'Current author gate receipts/logs/objects/generated proofs; failed attempts kept; current mixed scalar-prefix division class; full140 remains incomplete; historical complete evidence remains in earlier independent archive.'}
archive=out/'stock-returned-div-terminal-evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=1) as tar:
 for name,p in sorted(files.items()):
  b=p.read_bytes();manifest['files'][name]={'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)};info=tarfile.TarInfo(name);info.size=len(b);info.mtime=0;tar.addfile(info,io.BytesIO(b))
 b=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode();info=tarfile.TarInfo('manifest.json');info.size=len(b);info.mtime=0;tar.addfile(info,io.BytesIO(b))
digest=hashlib.sha256(archive.read_bytes()).hexdigest();(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');assert archive.stat().st_size<90*1024**2,archive.stat().st_size
idx=out/'index';E=os.environ.copy();E['GIT_INDEX_FILE']=str(idx);subprocess.run(['git','read-tree',head],env=E,check=True)
for path,name in [(archive,'evidence/stock-returned-div-terminal-evidence.tar.gz'),(out/'manifest.json','evidence/manifest.json')]:
 blob=subprocess.check_output(['git','hash-object','-w',str(path)],text=True).strip();subprocess.run(['git','update-index','--add','--cacheinfo','100644',blob,name],env=E,check=True)
tree=subprocess.check_output(['git','write-tree'],env=E,text=True).strip();commit=subprocess.check_output(['git','commit-tree',tree,'-p',head],input=b'Back up complete Stock mixed division author evidence\n').decode().strip();branch='agent/stock-returned-div-evidence-'+stamp;subprocess.run(['git','update-ref','refs/heads/'+branch,commit],check=True);subprocess.run(['git','push','origin',commit+':refs/heads/'+branch],check=True);remote=subprocess.check_output(['git','ls-remote','origin','refs/heads/'+branch],text=True).split()[0];assert remote==commit
receipt={'state':'remote_verified','validated_code_head':head,'backup_commit':commit,'backup_branch':branch,'archive_sha256':digest,'archive_bytes':archive.stat().st_size,'files':len(files),'archive':str(archive),'manifest':str(out/'manifest.json')};Path('/tmp/stock-returned-div-terminal-backup.json').write_text(json.dumps(receipt,indent=2)+'\n');idx.unlink();print(json.dumps(receipt),flush=True)
