from pathlib import Path
import json,subprocess,re,hashlib,datetime
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head=='b1990ec02ff083882720dcc436d638c0db5f2b04';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for p in ['after-fixtures','final-components']:
 r=json.load(open('/tmp/stock-returned-div-'+p+'.json'));assert r['head']==head and r['state'] in ['component_gates_passed','passed'],(p,r)
subprocess.run(['python3','/tmp/stock-returned-div-header-parity.py'],check=True);subprocess.run(['python3','/tmp/stock-returned-div-axiom-parity.py'],check=True)
records=[]
for kind in ['native','owned','integration','retained-integration','full','examples']:
 m=json.load(open('/tmp/stock-returned-div-'+kind+'-manifest.json'));assert m['candidate']==head
 out=Path('/tmp/stock-returned-div-'+kind+'-author');receipt=json.load(open(out/'receipt.json'));assert receipt['head']==head and receipt['state']=='passed'
 for gate in m['gates']:
  p=out/(gate['id']+'.json');r=json.load(open(p));assert r['state']=='passed' and r['returncode']==0 and r['source_head']==head;assert sha(r['log'])==r['log_sha256']
  for file,digest in r['outputs'].items():assert sha(file)==digest,file
  records.append({'group':kind,'id':gate['id'],'record':str(p),'sha256':sha(p),'log_sha256':r['log_sha256']})
identities={}
for mode in ['e2e','legacy-e2e']:
 def indexed(p):
  d=json.load(open(p));v={(r['file'],r['function'],r['index']):r['stages'] for r in d['functions']};assert len(v)==len(d['functions']);return v
 now=indexed('/tmp/stock-returned-div-full-author/'+mode+'-identities.json');counts={}
 for label,path in [('original','/tmp/legacy-dead-cleanup-final-'+mode+'-identities.json'),('prior512','/tmp/stock-div-reconciled-current-full-author/'+mode+'-identities.json'),('prior521','/tmp/stock-mixed-div-full-solo-author/'+mode+'-identities.json')]:
  old=indexed(path);assert all(now.get(k)==v for k,v in old.items()),(mode,label);counts[label]=len(old)
 identities[mode]={**counts,'current':len(now),'all_original_and_prior_identities_and_ordered_stages_exact':True}
native=json.load(open('/tmp/stock-returned-div-native-author/native/native-receipt.json'));assert native['state']=='passed' and native['failures']==native['disagreements']==0;assert native['actual_lean_encoded_objects']==24 and native['reference_cases_compared']==8304
owned=json.load(open('/tmp/stock-returned-div-owned-author/owned-0.json'));s=Path(owned['log']).read_text();counts=re.search(r'STOCK_RETURNED_DIV_OWNED_STANDARD_CORE (\d+); FIXED_WITNESSES (\d+)',s);assert counts
part=json.load(open('/tmp/stock-returned-div-owned/partitions.json'));ax=json.load(open('/tmp/stock-returned-div-axiom-parity.json'));headers=json.load(open('/tmp/stock-returned-div-header-parity.json'));assert ax['exact_required_axiom_sets_preserved'] and headers['unchanged'];flat=json.load(open('/tmp/stock-returned-div-retained-flat/receipt.json'));assert flat['state']=='passed' and flat['source_head']==head
mcp=json.load(open('/tmp/stock-returned-div-domain-mcp-input.json'));assert sha(mcp['source_file'])==mcp['source_sha256'];review=json.load(open(mcp['raw_review']));assert review['structuredContent']['axioms']==['propext','Classical.choice','Quot.sound'] and review['structuredContent']['warnings']==[]
r={'state':'passed','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'validated_code_head':head,'base':'f52b714ae48e0c5df9f996dd3dbeaa8bdbc61370','records':records,'affected_normal_targets':107,'affected_import_closure':1772,'affected_audits':16,'current_audit_roots':ax['current_roots'],'prior_exact_axiom_sets':ax['prior_roots_required'],'old_headers_exact':headers['old_public_headers'],'owned_core_constants':int(counts[1]),'fixed_witness_constants':int(counts[2]),'ownership_gates':len(part['executable_owners'])+1,'exact_native_facts':len(part['exact_native_facts']),'identities':identities,'native':{k:v for k,v in native.items() if k!='records'},'all14_prior_native_case_grids_exact':json.load(open('/tmp/stock-returned-div-native-grid-parity.json')),'full_140_complete':False,'next':'Continue undemanded/sunkdivision and other effects, original widths/ABIs/control/memory/calls/exceptions, source/block/whole-driver simulation and Stock-only/downstream completeness.'};Path('/tmp/stock-returned-div-terminal-validation.json').write_text(json.dumps(r,indent=2)+'\n');print('PASS',head,'gates',len(records),'ownership',r['ownership_gates'],'constants',counts[1],counts[2])
