from pathlib import Path
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025')
base=Path('/tmp/stock-conditional-cfg-ranked-shape-draft.lean').read_text();old=(root/'FV/Backend/Proof/StockConditionalCompatibility.lean').read_text()
imports=old[:old.index('namespace Backend.Stock.ConditionalCfg')];base=imports+base
s=old[old.index('namespace Backend.Stock.ConditionalCfg'):]
s=s.replace('(shape : Shape f)','(shape : RankedShape f)').replace('theorem Shape.legacy_compatible','theorem RankedShape.legacy_compatible')
a=s.index('private theorem selected_empty');b=s.index('private theorem assembled_arguments')
helper=s[a:b];helper=helper.replace('(source : f.blocks[bi]? = some b) (selected : (destinations b.term)[index]? = some (id,args)) :','(source : f.blocks[bi]? = some b) (selected : (destinations b.term)[index]? = some (id,args)) (entry : bi = 0) :')
start=helper.index('  by_cases entry :');end=helper.index('  · obtain ⟨params,xs,ret⟩')
body=helper[start:end].replace('  by_cases entry : bi = 0\n  · subst bi\n','  subst bi\n');body='\n'.join(line[2:] if line.startswith('    ') else line for line in body.splitlines())+'\n'
helper=helper[:start]+body
s=s[:a]+helper+'\n'+s[b:]
orig=s.index('        obtain ⟨rfl,rfl,bc,selectedBc,empty⟩ := selected_empty shape source destination')
edge=s.index('      | edge pred k ti =>',orig)
oldbody=s[orig:edge].replace('selected_empty shape source destination','selected_empty shape source destination isEntry')
oldbody='\n'.join('  '+line for line in oldbody.splitlines())+'\n'
fwd=(root/'FV/Backend/Proof/StockForwardCompatibility.lean').read_text();jump=fwd[fwd.index('        · have only : index = 0'):fwd.index('\nend Backend.Stock.Proof.ForwardSource')]
jump=jump.replace('rcases terms b (List.mem_of_getElem? source)','rcases shape.tails bi b source isEntry')
new='''        by_cases isEntry : bi = 0
        ·
'''+oldbody+'''        · rcases shape.tails bi b source isEntry with ⟨bc,jump⟩ | ⟨xs,ret⟩
'''+''.join('  '+line+'\n' for line in jump.splitlines())
s=s[:orig]+new+s[edge:]
needle='''        obtain ⟨rfl,rfl,bc,selectedBc,empty⟩ := selected_empty shape source destination'''
replacement='''        have isEntry : pred = 0 := by
          apply Classical.byContradiction
          intro nonentry
          rcases shape.tails pred b source nonentry with ⟨bc,jump⟩ | ⟨xs,ret⟩
          · exact CriticalOwners.jump_no_edge (stock_lower_order run) source jump k ti
              (Array.mem_toList_iff.mpr (Array.mem_of_getElem? tag))
          · simp only [ret,destinations,List.getElem?_nil] at destination; cases destination
        obtain ⟨rfl,rfl,bc,selectedBc,empty⟩ := selected_empty shape source destination isEntry'''
assert needle in s;n=s.rfind(needle);s=s[:n]+replacement+s[n+len(needle):]
Path('/tmp/stock-conditional-cfg-ranked-compat-draft.lean').write_text(base+'\n'+s)
