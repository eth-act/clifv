import FV.Backend.Proof.StockConditionalEmptyFixture
import FV.Backend.Proof.LowerDecide
namespace Backend.Stock.Proof.ConditionalValues.RankedTailDraft
open Backend.Proof Backend.Proof.Driver
set_option Elab.async false
set_option maxRecDepth 20000
set_option maxHeartbeats 16000000
def function : Clif.Function := {
  name := "conditional_ranked_tail"
  sig := {params := [⟨.i64,.none,.normal⟩],returns := [⟨.i64,.none,.normal⟩],callConv := some .systemV}
  blocks := [{id := 0,params := [(7,.i64)],term := .brif 7 ⟨1,[]⟩ ⟨2,[]⟩},
    {id := 1,body := [⟨[31],.iconst .i64 1⟩],term := .jump ⟨3,[]⟩},
    {id := 2,body := [⟨[47],.iconst .i64 2⟩],term := .ret [47]},
    {id := 3,term := .ret [31]}] }
def initial (n : BitVec 64) : Clif.Frame := {
  func := function,regs := Clif.Regs.empty.set 7 ⟨.i64,n⟩,slots := [],
  body := [],term := .brif 7 ⟨1,[]⟩ ⟨2,[]⟩ }
private theorem scope : LowerScope function := lowerScope_of rfl
private def original : Ctx × Array (Nat × Nat) × LState :=
  (Backend.buildCtx function).toOption.getD (sinkCtx,#[],default)
private theorem original_build : Backend.buildCtx function = .ok original := rfl
private theorem inherited_available : (31 : Nat) ∈ (availIn function original.1).getD 3 [] := by
  have size : original.1.valDef.size = 48 := rfl
  have fixed : FixOk function original.1 id (fun tl x => tl = 3 ∧ x = 31) := by
    constructor
    · rintro tl x ⟨rfl,rfl⟩
      simp [size,function,valueDefs,parsOf]
    · rintro tl x ⟨rfl,rfl⟩ p successor
      rcases p with _ | (_ | (_ | (_ | p)))
      · exact False.elim ((by decide +kernel : (3 : Nat) ∉ succIdx function 0) successor)
      · exact .inr (.inl (by decide +kernel))
      · simp [succIdx,function,succIds,dests] at successor
      · simp [succIdx,function,succIds,dests] at successor
      · simp [succIdx,function,succIds,dests] at successor
    · rintro tl x ⟨rfl,rfl⟩ y member
      change y ∈ ([] : List Nat) at member
      cases member
  exact inFix_greatest fixed ⟨rfl,rfl⟩
private theorem dominated : Dominated function := by
  constructor
  · change ([7,31,47] : List Nat).Nodup; decide +kernel
  · intro ctx ranges st build bi b found
    have bound : bi < 4 := by have h := lt_of_getElem? found; simpa [function] using h
    have cases : bi = 0 ∨ bi = 1 ∨ bi = 2 ∨ bi = 3 := by omega
    rcases cases with rfl | rfl | rfl | rfl
    all_goals
      simp [function] at found
      subst b
      constructor
      · intro j stm present
        cases j <;> simp [function] at present
        all_goals subst stm; intro x member; cases member
      · intro x member
        simp [abiTerm,Driver.termArgs,sretRet,sigRets,function] at member <;>
          subst x <;> simp [availOf,function,defsBefore,defsFrom]
        all_goals
          have context : ctx = original.1 := congrArg Prod.fst (Except.ok.inj (build.symm.trans original_build))
          rw [context]
          rw [← Array.getD_eq_getD_getElem?]
          with_unfolding_all exact inherited_available
  · intro ctx ranges st build tl x available notLocal y member
    have fixed := (inFix_fixOk (f := function) (ctx := ctx) (gn := id)).cand tl x available
    have values : x = 7 ∨ x = 31 ∨ x = 47 := by simpa [valueDefs,function] using fixed.2.2.2.1
    have context : ctx = original.1 := congrArg Prod.fst (Except.ok.inj (build.symm.trans original_build))
    rw [context] at member
    rcases values with rfl | rfl | rfl
    all_goals change y ∈ ([] : List Nat) at member; cases member


end Backend.Stock.Proof.ConditionalValues.RankedTailDraft
