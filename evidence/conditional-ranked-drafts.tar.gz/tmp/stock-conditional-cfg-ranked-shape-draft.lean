import FV.Backend.Proof.StockForwardTrap
import FV.Backend.Proof.StockConditionalClass
import FV.Backend.Proof.StockConditionalLeaf
namespace Backend.Stock.Proof.ForwardSource
open Backend.Proof Backend.Proof.Driver
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 20000
/-- Only the continuations are jump/return blocks; the entry can branch. -/
def NonentryJumpReturnBlocks (f : Clif.Function) : Prop :=
  ∀ bi b,f.blocks[bi]? = some b → bi ≠ 0 →
    (∃ bc,b.term = .jump bc) ∨ (∃ xs,b.term = .ret xs)
/-- Compose arbitrary many ranked scalar jump blocks and a return from their
actual retained scans. The induction follows the real node labels; neither a
fixed block count nor a source result-forwarding restriction is required. -/
theorem nonentry_returns_of_termsAt {f : Clif.Function} {result : Result} {rank : Nat → Nat}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    (abi : sigAbiOk f.sig = true) (ranked : Ranked f rank) (terms : NonentryJumpReturnBlocks f)
    (family : ∀ b ∈ f.blocks,∀ stm ∈ b.body,MaskBody.Family stm.inst)
    {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem} (refines : Refines F isem)
    (driver : DriverSem isem) {MR : MemRelT} (stable : MRStable F MR)
    (env : Clif.Env) (cp : Clif.Program) {label bi : Nat} {b : Clif.Block}
    (tag : result.order.nodes[label]? = some (.original bi))
    (block : f.blocks[bi]? = some b) (nonentry : bi ≠ 0) :
    ∃ event,event ∈ result.blockScans.toList ∧ event.block = bi ∧
      ReturnsAt f result label bi b event isem MR env cp := by
  have nonempty : f.blocks.length ≠ 0 := fun h => scope.nonempty (List.length_eq_zero_iff.mp h)
  obtain ⟨source,computed,size,bounded⟩ := stock_blockOrder_sourceTable (stock_lower_order run)
  have composed : ∀ n label bi b,result.order.nodes.size-label = n →
      result.order.nodes[label]? = some (.original bi) → f.blocks[bi]? = some b → bi ≠ 0 →
      ∃ event,event ∈ result.blockScans.toList ∧ event.block = bi ∧
        ReturnsAt f result label bi b event isem MR env cp := by
    intro n
    induction n using Nat.strongRecOn with
    | ind n ih =>
      intro label bi b count tag block nonentry
      rcases terms bi b block nonentry with ⟨bc,jump⟩ | ⟨xs,ret⟩
      · obtain ⟨spec⟩ := Control.stock_lower_jump_body_spec run scope dominated family tag block jump refines driver stable env cp
        obtain ⟨tl,targetLabel,targetIndex,targetNonentry,successors,targetTag⟩ :=
          CriticalOwners.jump_successor run scope tag block jump
        have sameTarget : spec.target = targetLabel := by
          have row : result.order.successors[label]! = #[targetLabel] := by
            simp only [getElem!_def,successors,Option.getD_some]
          have targets := spec.targets
          rw [row] at targets
          exact (List.cons.inj targets).1.symm
        have sourceRow := jump_source_row computed block jump targetIndex
        have edge : tl ∈ source[bi]!.toList := by rw [sourceRow]; simp
        have later := successor_labels (stock_lower_order run) nonempty ranked computed tag targetTag edge
        have targetBound := (Array.getElem?_eq_some_iff.mp targetTag).1
        have smaller : result.order.nodes.size-targetLabel < n := by omega
        obtain ⟨targetBlock,targetFound,targetSource⟩ := block?_of_idx targetIndex
        obtain ⟨next,nextEvent,nextBlock,nextReturns⟩ := ih _ smaller targetLabel tl targetBlock rfl targetTag targetSource targetNonentry
        have demand := successor_demand run scope ranked computed
          (by simpa only [spec.atBlock] using tag)
          (by simpa only [nextBlock] using targetTag)
          (by simpa only [spec.atBlock,nextBlock] using edge) spec.events nextEvent spec.split
        refine ⟨spec.core.scan,spec.events,spec.atBlock,?_⟩
        intro fuel s vals cm ρ w func callers remaining atTerm defined returned held
        have continuation : ∀ (fuel : Nat) (s : Clif.State) (ρ : Nat → CV) (w : Arm.ArmState),
            s.frame.func = f → s.callers = [] → s.frame.body = targetBlock.body → s.frame.term = targetBlock.term →
            SourceDefinedAt f result.ctx tl 0 s.frame → Clif.runLoop env cp fuel s = .returned vals cm →
            GuardedScanRel f result next.ctx next.block MR next.output.state (0,s.frame,s.mem) ρ w →
            RunOkABIAt f result.code result.edgeArgs isem MR s.frame.slots ⟨spec.target,0,ρ,w⟩ (.returned vals cm) := by
          intro fuel s ρ w func callers remaining atTerm defined returned held
          simpa only [sameTarget] using nextReturns fuel s vals cm ρ w func callers remaining atTerm defined returned held
        have finished := Control.jump_body_returns_at run scope dominated family refines driver stable spec tag jump
          (by simpa only [sameTarget] using targetTag) targetIndex targetFound nextEvent nextBlock demand continuation
          callers remaining atTerm (by simpa only [spec.atBlock] using defined) returned held
        simpa only [jump_nonentry_prelude spec nonentry] using finished
      · obtain ⟨spec⟩ := CfgReturn.stock_lower_return_block_spec run scope dominated abi family tag block ret refines driver stable env cp
        refine ⟨spec.core.scan,spec.events,spec.atBlock,?_⟩
        intro fuel s vals cm ρ w func callers remaining atTerm defined returned held
        have finished := CfgReturnAt.return_block_returns_at run scope dominated abi family ret refines driver stable spec
          func callers remaining atTerm (by simpa only [spec.atBlock] using defined) returned held
        simpa only [spec.noPrelude nonentry] using finished
  exact composed _ label bi b rfl tag block nonentry

theorem nonentry_traps_of_termsAt {f : Clif.Function} {result : Result} {rank : Nat → Nat}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    (abi : sigAbiOk f.sig = true) (ranked : Ranked f rank) (terms : NonentryJumpReturnBlocks f)
    (family : ∀ b ∈ f.blocks,∀ stm ∈ b.body,MaskBody.Family stm.inst)
    {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem} (refines : Refines F isem)
    (driver : DriverSem isem) {MR : MemRelT} (stable : MRStable F MR)
    (env : Clif.Env) (cp : Clif.Program) {label bi : Nat} {b : Clif.Block}
    (tag : result.order.nodes[label]? = some (.original bi))
    (block : f.blocks[bi]? = some b) (nonentry : bi ≠ 0) :
    ∃ event,event ∈ result.blockScans.toList ∧ event.block = bi ∧
      TrapsAt f result label bi b event isem MR env cp := by
  have nonempty : f.blocks.length ≠ 0 := fun h => scope.nonempty (List.length_eq_zero_iff.mp h)
  obtain ⟨source,computed,size,bounded⟩ := stock_blockOrder_sourceTable (stock_lower_order run)
  have composed : ∀ n label bi b,result.order.nodes.size-label = n →
      result.order.nodes[label]? = some (.original bi) → f.blocks[bi]? = some b → bi ≠ 0 →
      ∃ event,event ∈ result.blockScans.toList ∧ event.block = bi ∧
        TrapsAt f result label bi b event isem MR env cp := by
    intro n
    induction n using Nat.strongRecOn with
    | ind n ih =>
      intro label bi b count tag block nonentry
      rcases terms bi b block nonentry with ⟨bc,jump⟩ | ⟨xs,ret⟩
      · obtain ⟨spec⟩ := Control.stock_lower_jump_body_spec run scope dominated family tag block jump refines driver stable env cp
        obtain ⟨tl,targetLabel,targetIndex,targetNonentry,successors,targetTag⟩ :=
          CriticalOwners.jump_successor run scope tag block jump
        have sameTarget : spec.target = targetLabel := by
          have row : result.order.successors[label]! = #[targetLabel] := by
            simp only [getElem!_def,successors,Option.getD_some]
          have targets := spec.targets
          rw [row] at targets
          exact (List.cons.inj targets).1.symm
        have sourceRow := jump_source_row computed block jump targetIndex
        have edge : tl ∈ source[bi]!.toList := by rw [sourceRow]; simp
        have later := successor_labels (stock_lower_order run) nonempty ranked computed tag targetTag edge
        have targetBound := (Array.getElem?_eq_some_iff.mp targetTag).1
        have smaller : result.order.nodes.size-targetLabel < n := by omega
        obtain ⟨targetBlock,targetFound,targetSource⟩ := block?_of_idx targetIndex
        obtain ⟨next,nextEvent,nextBlock,nextTraps⟩ := ih _ smaller targetLabel tl targetBlock rfl targetTag targetSource targetNonentry
        have demand := successor_demand run scope ranked computed
          (by simpa only [spec.atBlock] using tag)
          (by simpa only [nextBlock] using targetTag)
          (by simpa only [spec.atBlock,nextBlock] using edge) spec.events nextEvent spec.split
        refine ⟨spec.core.scan,spec.events,spec.atBlock,?_⟩
        intro fuel s code ρ w func callers remaining atTerm defined returned held
        have continuation : ∀ (fuel : Nat) (s : Clif.State) (ρ : Nat → CV) (w : Arm.ArmState),
            s.frame.func = f → s.callers = [] → s.frame.body = targetBlock.body → s.frame.term = targetBlock.term →
            SourceDefinedAt f result.ctx tl 0 s.frame → Clif.runLoop env cp fuel s = .trapped code →
            GuardedScanRel f result next.ctx next.block MR next.output.state (0,s.frame,s.mem) ρ w →
            RunOkABIAt f result.code result.edgeArgs isem MR s.frame.slots ⟨spec.target,0,ρ,w⟩ (.trapped code) := by
          intro fuel s ρ w func callers remaining atTerm defined returned held
          simpa only [sameTarget] using nextTraps fuel s code ρ w func callers remaining atTerm defined returned held
        have finished := Control.jump_body_traps_at run scope dominated family refines driver stable spec tag jump
          (by simpa only [sameTarget] using targetTag) targetIndex targetFound nextEvent nextBlock demand continuation
          callers remaining atTerm (by simpa only [spec.atBlock] using defined) returned held
        simpa only [jump_nonentry_prelude spec nonentry] using finished
      · obtain ⟨spec⟩ := CfgReturn.stock_lower_return_block_spec run scope dominated abi family tag block ret refines driver stable env cp
        refine ⟨spec.core.scan,spec.events,spec.atBlock,?_⟩
        intro fuel s code ρ w func callers remaining atTerm defined returned held
        have finished := CfgReturnAt.return_block_traps_at run scope dominated family ret refines driver stable spec
          callers remaining atTerm returned held
        simpa only [spec.noPrelude nonentry] using finished
  exact composed _ label bi b rfl tag block nonentry


end Backend.Stock.Proof.ForwardSource

namespace Backend.Stock.Proof.ConditionalValues
open Backend.Proof Backend.Proof.Driver Backend.Stock.Proof.ForwardSource

/-- A conditional successor can continue through arbitrarily many ranked jump/return blocks. -/
theorem SuccessorReturn.of_ranked_tail {f : Clif.Function} {result : Result} {rank : Nat → Nat}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    (abi : sigAbiOk f.sig = true) (ranked : Ranked f rank) (terms : NonentryJumpReturnBlocks f)
    (family : ∀ b ∈ f.blocks,∀ stm ∈ b.body,MaskBody.Family stm.inst)
    {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem} (refines : Refines F isem)
    (driver : DriverSem isem) {MR : MemRelT} (stable : MRStable F MR)
    {env : Clif.Env} {cp : Clif.Program} {vals : List Clif.Val} {cm : Clif.Mem}
    {label : Nat} {bc : Clif.BlockCall} {tl targetLabel : Nat} {b : Clif.Block}
    (lookup : blockIdx? f bc.block = some tl) (found : f.block? bc.block = some b)
    (source : f.blocks[tl]? = some b)
    (tag : result.order.nodes[targetLabel]? = some (.original tl))
    (nonentry : tl ≠ 0) (forward : label < targetLabel) :
    Nonempty (SuccessorReturn f result label bc isem MR env cp vals cm) := by
  obtain ⟨event,member,atBlock,returns⟩ := nonentry_returns_of_termsAt run scope dominated abi ranked terms family
    refines driver stable env cp tag source nonentry
  refine ⟨{
    index := tl
    targetLabel := targetLabel
    block := b
    event := event
    lookup := lookup
    found := found
    tag := tag
    member := member
    atBlock := atBlock
    forward := forward
    returns := ?_ }⟩
  intro fuel s ρ w func callers remaining atTerm defined terminal held
  exact returns fuel s vals cm ρ w func callers remaining atTerm defined terminal held

/-- A conditional successor can continue through arbitrarily many ranked jump/return blocks. -/
theorem SuccessorTrap.of_ranked_tail {f : Clif.Function} {result : Result} {rank : Nat → Nat}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    (abi : sigAbiOk f.sig = true) (ranked : Ranked f rank) (terms : NonentryJumpReturnBlocks f)
    (family : ∀ b ∈ f.blocks,∀ stm ∈ b.body,MaskBody.Family stm.inst)
    {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem} (refines : Refines F isem)
    (driver : DriverSem isem) {MR : MemRelT} (stable : MRStable F MR)
    {env : Clif.Env} {cp : Clif.Program} {trapCode : Clif.TrapCode}
    {label : Nat} {bc : Clif.BlockCall} {tl targetLabel : Nat} {b : Clif.Block}
    (lookup : blockIdx? f bc.block = some tl) (found : f.block? bc.block = some b)
    (source : f.blocks[tl]? = some b)
    (tag : result.order.nodes[targetLabel]? = some (.original tl))
    (nonentry : tl ≠ 0) (forward : label < targetLabel) :
    Nonempty (SuccessorTrap f result label bc isem MR env cp trapCode) := by
  obtain ⟨event,member,atBlock,traps⟩ := nonentry_traps_of_termsAt run scope dominated abi ranked terms family
    refines driver stable env cp tag source nonentry
  refine ⟨{
    index := tl
    targetLabel := targetLabel
    block := b
    event := event
    lookup := lookup
    found := found
    tag := tag
    member := member
    atBlock := atBlock
    forward := forward
    traps := ?_ }⟩
  intro fuel s ρ w func callers remaining atTerm defined terminal held
  exact traps fuel s trapCode ρ w func callers remaining atTerm defined terminal held

end Backend.Stock.Proof.ConditionalValues

#print axioms Backend.Stock.Proof.ForwardSource.nonentry_returns_of_termsAt

#print axioms Backend.Stock.Proof.ForwardSource.nonentry_traps_of_termsAt

#print axioms Backend.Stock.Proof.ConditionalValues.SuccessorReturn.of_ranked_tail

#print axioms Backend.Stock.Proof.ConditionalValues.SuccessorTrap.of_ranked_tail


namespace Backend.Stock.ConditionalCfg
open Backend.Proof Backend.Proof.Driver Backend.Stock.Proof Backend.Stock.Proof.ConditionalValues
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 20000
/-- Original conditional entry with arbitrary ranked scalar jump/return tails. -/
structure RankedShape (f : Clif.Function) where
  entry : Clif.Block
  condition : Nat
  yes : Clif.BlockCall
  no : Clif.BlockCall
  source : f.blocks[0]? = some entry
  term : entry.term = .brif condition yes no
  parameter : ∃ ty,(condition,ty) ∈ entry.params ∧ (ty = .i32 ∨ ty = .i64)
  targets : ∀ bc,bc = yes ∨ bc = no → bc.args = [] ∧
    ∃ tl,blockIdx? f bc.block = some tl ∧ 0 < tl
  tails : ForwardSource.NonentryJumpReturnBlocks f
  ranked : ForwardSource.Ranked f id
  family : ∀ b ∈ f.blocks,∀ stm ∈ b.body,MaskBody.Family stm.inst

/-- Original entry-parameter membership and SSA derive the real built context's
parameter status and width. No selected rule or DFG certificate is supplied. -/
theorem RankedShape.condition_metadata {f : Clif.Function} (shape : RankedShape f) (dominated : Dominated f)
    {ctx : Ctx} {ranges : Array (Nat × Nat)} {initial : State}
    (build : Stock.buildCtx f = .ok (ctx,ranges,initial)) :
    ctx.defInst? shape.condition = none ∧
      (ctx.valueType? shape.condition = some (.int 32) ∨ ctx.valueType? shape.condition = some (.int 64)) := by
  obtain ⟨original,st,oldBuild,spec,view⟩ := buildCtx_source build
  obtain ⟨ty,parameter,wide⟩ := shape.parameter
  have parameterId : shape.condition ∈ shape.entry.params.map (·.1) :=
    List.mem_map.mpr ⟨(shape.condition,ty),parameter,rfl⟩
  have noDefinition := defInst_par spec.facts dominated.ssa shape.source parameterId
  have originalType := (spec.facts.types dominated.ssa).2 shape.entry (List.mem_of_getElem? shape.source)
    (shape.condition,ty) parameter
  refine ⟨?_,?_⟩
  · simpa only [Ctx.defInst?,view.valDef] using noDefinition
  · have typed : ctx.valueType? shape.condition = some (CTy.ofClif ty) := by
      simpa only [Ctx.valueType?,view.valTy] using originalType
    rcases wide with rfl | rfl
    · exact Or.inl typed
    · exact Or.inr typed

private theorem selected_tail {f : Clif.Function} {result : Result}
    (shape : RankedShape f) (run : Stock.lower f = .ok result) (scope : LowerScope f)
    {index : Nat} {bc : Clif.BlockCall} (selected : (dests shape.entry.term)[index]? = some bc) :
    ∃ tl targetLabel b,blockIdx? f bc.block = some tl ∧ f.block? bc.block = some b ∧
      f.blocks[tl]? = some b ∧ result.order.nodes[targetLabel]? = some (.original tl) ∧
      tl ≠ 0 ∧ 0 < targetLabel := by
  have entryTag := stock_blockOrder_entry (stock_lower_order run) scope.nonempty
  obtain ⟨tl,middle,lookup,nonentry,successor,node⟩ :=
    stock_lower_selected_successor run scope entryTag shape.source selected
  have target : ∃ (targetLabel : Nat),result.order.nodes[targetLabel]? = some (.original tl) := by
    rcases node with original | synthetic
    · exact ⟨middle,original⟩
    · obtain ⟨input,next,args,targetLabel,call,successors,tag,placed⟩ := stock_lower_critical_code run synthetic
      exact ⟨targetLabel,tag⟩
  obtain ⟨targetLabel,targetTag⟩ := target
  obtain ⟨b,found,source⟩ := block?_of_idx lookup
  have different : targetLabel ≠ 0 := by
    intro equal
    subst targetLabel
    exact nonentry (Node.original.inj (Option.some.inj (targetTag.symm.trans entryTag)))
  exact ⟨tl,targetLabel,b,lookup,found,source,targetTag,nonentry,Nat.pos_of_ne_zero different⟩


end Backend.Stock.ConditionalCfg
