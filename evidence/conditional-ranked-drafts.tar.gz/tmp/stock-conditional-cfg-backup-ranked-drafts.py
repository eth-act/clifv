from pathlib import Path
import os,json,subprocess,hashlib,tarfile,datetime
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');os.chdir(root);os.nice(19);os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
def git(*a,env=None):return subprocess.check_output(['git',*a],env=env,text=True).strip()
head=git('rev-parse','HEAD');assert not git('status','--porcelain')
files=[p for p in Path('/tmp').glob('stock-conditional-cfg-*ranked*') if p.is_file() and p.suffix in {'.lean','.log','.py','.json'}]
manifest={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':head,'production_pr':635,'production_source_unchanged':True,'state':'scratch ranked conditional source/domain draft; universal domain, legacy compatibility and complete original compiled/source/input/domain witnesses compile standard-only; not production integrated or full gated','files':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}}
p=Path('/tmp/stock-conditional-cfg-ranked-drafts-manifest.json');p.write_text(json.dumps(manifest,indent=2)+'\n');files.append(p)
archive=Path('/tmp/stock-conditional-cfg-ranked-drafts.tar.gz')
with tarfile.open(archive,'w:gz',compresslevel=1) as tf:
 for p in sorted(set(files)):tf.add(p,arcname=str(p).lstrip('/'),recursive=False)
assert archive.stat().st_size<8*1024*1024
branch='agent/stock-cfg-body-progress-20261025T025359Z';parent=git('rev-parse',branch);index=Path('/tmp/stock-conditional-cfg-ranked-backup.index');index.unlink(missing_ok=True);e=os.environ.copy();e['GIT_INDEX_FILE']=str(index);git('read-tree',parent,env=e)
for p,key in [(archive,'evidence/conditional-ranked-drafts.tar.gz'),(Path('/tmp/stock-conditional-cfg-ranked-drafts-manifest.json'),'evidence/conditional-ranked-drafts-manifest.json')]:
 blob=git('hash-object','-w',str(p));git('update-index','--add','--cacheinfo',f'100644,{blob},{key}',env=e)
tree=git('write-tree',env=e);commit=git('commit-tree',tree,'-p',parent,'-m','Preserve ranked conditional source/domain continuation drafts and complete standard-only witnesses');git('update-ref','refs/heads/'+branch,commit,parent);subprocess.run(['git','push','origin',branch],check=True);assert git('ls-remote','origin','refs/heads/'+branch).split()[0]==commit
r={'utc':manifest['utc'],'base':head,'evidence_commit':commit,'branch':branch,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'files':len(set(files)),'prior_evidence_tree_preserved':True};Path('/tmp/stock-conditional-cfg-ranked-drafts-backup.json').write_text(json.dumps(r,indent=2)+'\n');index.unlink(missing_ok=True);print(json.dumps(r))
