from pathlib import Path
import hashlib,json,datetime
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');out=Path('/tmp/stock-conditional-cfg-ranked-port');out.mkdir(exist_ok=True);files={}
def add(name,text):
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
 source=root/name;files[name]={'before_sha256':hashlib.sha256(source.read_bytes()).hexdigest() if source.exists() else None,'content':text,'after_sha256':hashlib.sha256(text.encode()).hexdigest()}
def module(imports,namespace,body,opens='Backend.Proof Backend.Proof.Driver Backend.Stock.Proof Backend.Stock.Proof.ConditionalValues'):
 return ''.join('import '+n+'\n' for n in imports)+'\nnamespace '+namespace+'\nopen '+opens+'\nset_option autoImplicit false\nset_option Elab.async false\nset_option maxRecDepth 20000\n\n'+body.strip()+'\n\nend '+namespace+'\n'
def strip_prints(s):return '\n'.join(line for line in s.splitlines() if not line.startswith('#print axioms'))
core=Path('/tmp/stock-conditional-cfg-ranked-tail-draft.lean').read_text()
for kind in ['Return','Trap']:
 name='FV/Backend/Proof/StockForward'+kind+'.lean';old=(root/name).read_text();stem='returns' if kind=='Return' else 'traps';oldname='nonentry_'+stem;newname=oldname+'_of_termsAt'
 start=old.index('theorem '+oldname+' ');end=old.rindex('end Backend.Stock.Proof.ForwardSource');oldtheorem=old[start:end].strip();header=oldtheorem[:oldtheorem.index(':= by')]
 genStart=core.index('theorem '+newname+' ');genEnd=core.index('\nend Backend.Stock.Proof.ForwardSource',genStart) if kind=='Trap' else core.index('\ntheorem nonentry_traps_of_termsAt',genStart);generic=core[genStart:genEnd].strip()
 wrapper=header+'''\n:= by
  exact '''+newname+''' run scope dominated abi ranked
    (fun bi b found _ => terms b (List.mem_of_getElem? found)) family
    refines driver stable env cp tag block nonentry
'''
 text=old[:start]+generic+'\n\n/-- The original all-block variant is preserved. -/\n'+wrapper+'\n'+old[end:]
 if kind=='Return':
  at=text.index('/-- Instruction-zero return simulation')
  text=text[:at]+'''/-- Restrict only continuations; the entry may be conditional. -/
def NonentryJumpReturnBlocks (f : Clif.Function) : Prop :=
  ∀ bi b,f.blocks[bi]? = some b → bi ≠ 0 →
    (∃ bc,b.term = .jump bc) ∨ (∃ xs,b.term = .ret xs)

'''+text[at:]
 assert header in text
 add(name,text)
shape=Path('/tmp/stock-conditional-cfg-ranked-shape-draft.lean').read_text();a=shape.index('/-- Original conditional entry');b=shape.index('private theorem selected_tail',a)
add('FV/Backend/Proof/StockConditionalRankedShape.lean',module(['FV.Backend.Proof.StockConditionalClass','FV.Backend.Proof.StockForwardReturn'],'Backend.Stock.ConditionalCfg',shape[a:b]))
a=core.index('/-- A conditional successor');b=core.index('\nend Backend.Stock.Proof.ConditionalValues',a)
add('FV/Backend/Proof/StockConditionalRankedSuccessor.lean',module(['FV.Backend.Proof.StockConditionalRankedShape','FV.Backend.Proof.StockConditionalLeaf','FV.Backend.Proof.StockForwardTrap'],'Backend.Stock.Proof.ConditionalValues',core[a:b],opens='Backend.Proof Backend.Proof.Driver Backend.Stock.Proof.ForwardSource'))
compat=Path('/tmp/stock-conditional-cfg-ranked-compat-draft.lean').read_text();a=compat.rindex('namespace Backend.Stock.ConditionalCfg');body=compat[a:];oldimports=(root/'FV/Backend/Proof/StockConditionalCompatibility.lean').read_text().split('namespace Backend.Stock.ConditionalCfg')[0];oldimports=oldimports.replace('StockConditionalClass','StockConditionalRankedShape')
add('FV/Backend/Proof/StockConditionalRankedCompatibility.lean',oldimports+body)
domain=Path('/tmp/stock-conditional-cfg-ranked-domain-draft.lean').read_text();a=domain.rindex('namespace Backend.Stock.ConditionalCfg');body=domain[a:];tail=shape[shape.index('private theorem selected_tail'):shape.rindex('end Backend.Stock.ConditionalCfg')]
body=body.replace('private theorem source_entry_parts',tail+'\nprivate theorem source_entry_parts',1)
imports=['FV.Backend.Proof.StockConditionalRankedCompatibility','FV.Backend.Proof.StockConditionalRankedSuccessor','FV.Backend.Proof.StockConditionalEntryPrelude','FV.Backend.Proof.StockScalarContract']
add('FV/Backend/Proof/StockConditionalRankedDomain.lean',''.join('import '+n+'\n' for n in imports)+'\n'+strip_prints(body))
selector=Path('/tmp/stock-conditional-cfg-ranked-selector-addition.lean').read_text();a=selector.index('def rankedEligible');b=selector.index('private theorem ranked_target_sound');defs=selector[a:b];a=selector.index('def rankedSourceOk');b=selector.index('theorem ranked_sourceOk_sound',a);defs+=selector[a:b]
add('FV/Backend/Lowering/StockConditionalRankedCfg.lean',module(['FV.Backend.Lowering.StockConditionalCfg','FV.Backend.Lowering.StockForwardCfg'],'Backend.Stock.ConditionalCfg',defs,opens='Backend.Proof.Driver'))
a=selector.index('private theorem ranked_target_sound');b=selector.index('end Backend.Stock.ConditionalCfg',a);proof=selector[a:b];a=selector.index('private theorem ranked_abi');b=selector.index('def rankedSourceOk',a);proof+=selector[a:b];a=selector.index('theorem ranked_sourceOk_sound');b=selector.index('end Backend.Stock.ConditionalCfg',a);proof+=selector[a:b]
add('FV/Backend/Proof/StockConditionalRankedCheck.lean',module(['FV.Backend.Lowering.StockConditionalRankedCfg','FV.Backend.Proof.StockConditionalRankedDomain','FV.Backend.Proof.StockScalarCheck'],'Backend.Stock.ConditionalCfg',strip_prints(proof)))
# A separate appended adapter preserves the complete previous conditional pipeline.
old=(root/'FV/Backend/Lowering/StockConditionalCfgNI.lean').read_text();new=old.replace('StockForwardCfgNI','StockConditionalCfgNI').replace('import FV.Backend.Lowering.StockConditionalCfg\n','import FV.Backend.Lowering.StockConditionalRankedCfg\n').replace('namespace Backend.Stock.ConditionalCfg','namespace Backend.Stock.ConditionalForwardCfg').replace('end Backend.Stock.ConditionalCfg','end Backend.Stock.ConditionalForwardCfg').replace('ForwardCfg.','ConditionalCfg.').replace('if !eligible f then','if !eligible f then').replace('if check f result.code','if ConditionalCfg.rankedCheck f result.code').replace('indices0–8','indices0–9')
new=new.replace('/-- The compatible conditional CFG','/-- The compatible conditional CFG with forward tails').replace('def lowerValidated (f', 'def eligible (f : Clif.Function) : Bool :=\n  ConditionalCfg.rankedEligible f && !ConditionalCfg.eligible f\n\ndef lowerValidated (f',1)
add('FV/Backend/Lowering/StockConditionalForwardCfgNI.lean',new)
old=(root/'FV/Backend/ConditionalCfgNIProduction.lean').read_text();new=old.replace('import FV.Backend.ForwardCfgNIProduction','import FV.Backend.ConditionalCfgNIProduction').replace('StockConditionalCfgNI','StockConditionalForwardCfgNI').replace('lowerCheckedConditionalCfgNI','lowerCheckedConditionalForwardCfgNI').replace('lowerForAllocationConditionalCfgNI','lowerForAllocationConditionalForwardCfgNI').replace('compileFileConditionalCfgNIWhen','compileFileConditionalForwardCfgNIWhen').replace('Stock.ConditionalCfg.','Stock.ConditionalForwardCfg.').replace('lowerCheckedForwardCfgNI','lowerCheckedConditionalCfgNI').replace('compileFileForwardCfgNIWhen','compileFileConditionalCfgNIWhen')
add('FV/Backend/ConditionalForwardCfgNIProduction.lean',new)
for name,old,new in [('FV/Backend/SemanticNICheck.lean','(Stock.ConditionalCfg.check f vc && ABIReadCfg.check f.sig vc))','(Stock.ConditionalCfg.check f vc && ABIReadCfg.check f.sig vc) ||\n      (Stock.ConditionalCfg.rankedCheck f vc && ABIReadCfg.check f.sig vc))'),('FVTest/Backend/Main.lean','compileFileConditionalCfgNIWhen','compileFileConditionalForwardCfgNIWhen')]:
 text=(root/name).read_text();assert old in text;text=text.replace(old,new)
 if name.endswith('SemanticNICheck.lean'):text='import FV.Backend.Lowering.StockConditionalRankedCfg\n'+text
 else:text=text.replace('import FV.Backend.ConditionalCfgNIProduction','import FV.Backend.ConditionalForwardCfgNIProduction')
 if 'LeanLinkMain' in name:text=text.replace('Stock.ConditionalCfg.eligible f','(Stock.ConditionalCfg.eligible f || Stock.ConditionalForwardCfg.eligible f)')
 add(name,text)
name='FVTest/Link/LeanLinkMain.lean';text=(root/name).read_text();text=text.replace('import FV.Backend.Lowering.StockConditionalCfgNI','import FV.Backend.Lowering.StockConditionalForwardCfgNI').replace('Backend.Stock.ConditionalCfg.eligible fi.func','(Backend.Stock.ConditionalForwardCfg.eligible fi.func || Backend.Stock.ConditionalCfg.eligible fi.func)').replace('let routes := [Backend.Stock.ConditionalCfg.lowerValidated,','let routes := [Backend.Stock.ConditionalForwardCfg.lowerValidated,Backend.Stock.ConditionalCfg.lowerValidated,');add(name,text)
name='FV/E2E/CompiledSemanticNI.lean';text=(root/name).read_text();text='import FV.Backend.Proof.StockConditionalRankedCheck\n'+text
oldline=next(line for line in text.splitlines() if line.startswith('  rcases lower with legacy | '));prefix='  rcases lower with legacy | ';newpat=prefix+'('+oldline[len(prefix):]+' | ⟨semantic,reads⟩)';text=text.replace(oldline,newpat)
newcase='  · obtain ⟨result,domain,run,equal⟩ := Stock.ConditionalCfg.ranked_check_sound semantic\n    exact .cfg domain equal reads\n      ⟨run,by rwa [equal],by rwa [equal],check,alloc,emit,layout⟩\n\n'
text=text.replace('end CompiledSemanticNI',newcase+'end CompiledSemanticNI',1);add(name,text)
name='FVTest/E2E/LinkCheckMain.lean';text=(root/name).read_text();text=text.replace('StockConditionalCfgNI','StockConditionalForwardCfgNI').replace('Stock.ConditionalCfg.lowerRoutes','Stock.ConditionalForwardCfg.lowerRoutes').replace('Stock.ConditionalCfg.lowerWithRoutes','Stock.ConditionalForwardCfg.lowerWithRoutes').replace('Stock.ConditionalCfg.eligible f','(Stock.ConditionalForwardCfg.eligible f || Stock.ConditionalCfg.eligible f)');add(name,text)
# Remaining of_checks split, artifact route10 consumers, fixtures and formal audit are explicit pending tasks.
manifest={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':'31a1befea3ed925a3fc1378a0d889fe726f087a8','state':'staged source draft only; verified single-module proofs retained separately; no tracked source mutation; no production/full-gate claim','files':files,'pending':['compile staged source and preserve all old header/axiom sets','generated checker/linker route10 ownership validation','complete returning/first-trap witnesses in proper modules','runtime/native/linked test cohort','proper-module root/native inventory and one bundled review','all per-PR gates and actual-source paired outputs']}
Path('/tmp/stock-conditional-cfg-ranked-port-source.json').write_text(json.dumps(manifest,indent=2)+'\n');print('Prepared',len(files),'source files outside the frozen checkout; source payload and before/after hashes saved.')
