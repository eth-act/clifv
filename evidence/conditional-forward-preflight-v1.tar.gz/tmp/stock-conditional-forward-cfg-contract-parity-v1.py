from pathlib import Path
import subprocess,re,json,hashlib
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');parent='91c809f798aa21e6625a09e2138b24921bb4d27f';out=Path('/tmp/stock-conditional-forward-cfg-contract-parity-v1.json')
old=json.load(open('/tmp/stock-conditional-forward-cfg-parent-trust/exact-parity.json'))['axiom_sets'];assert len(old)==3698
new={}
for p in Path('/tmp/stock-conditional-forward-cfg-normal-gates-v1/all-axioms').glob('*.log'):
 for m in re.finditer(r"^'(.+)' depends on axioms: \[([^\]]*)\]",p.read_text(),re.M):
  axes=sorted(x.strip() for x in m[2].split(',') if x.strip());assert m[1] not in new or new[m[1]]==axes;new[m[1]]=axes
 for m in re.finditer(r"^'(.+)' does not depend on any axioms",p.read_text(),re.M):new[m[1]]=[]
missing=sorted(set(old)-set(new));changed={k:[old[k],new[k]] for k in old.keys()&new.keys() if old[k]!=new[k]}
headers={};untouched=0
for file in subprocess.check_output(['git','ls-tree','-r','--name-only',parent,'FV/Backend/Proof'],cwd=root,text=True).splitlines():
 if not file.endswith('.lean'):continue
 before=subprocess.check_output(['git','show',parent+':'+file],cwd=root,text=True);after=(root/file).read_text()
 if before==after:untouched+=1;continue
 for m in re.finditer(r'(?m)^(?:protected )?(?:theorem|lemma) ([A-Za-z0-9_]+)\b',before):
  name=m[1];header=before[m.start():before.index(':=',m.end())]
  found=re.search(r'(?m)^(?:protected )?(?:theorem|lemma) '+re.escape(name)+r'\b',after);assert found,(file,name)
  actual=after[found.start():after.index(':=',found.end())];assert header==actual,(file,name);headers[file+':'+name]=hashlib.sha256(header.encode()).hexdigest()
file='FV/E2E/CompiledSemanticNI.lean';before=subprocess.check_output(['git','show',parent+':'+file],cwd=root,text=True);after=(root/file).read_text();pattern=r'(?m)^theorem of_checks\b'
a=re.search(pattern,before);b=re.search(pattern,after);oldheader=before[a.start():before.index(':=',a.end())];newheader=after[b.start():after.index(':=',b.end())];assert oldheader==newheader;headers[file+':of_checks']=hashlib.sha256(oldheader.encode()).hexdigest()
d=dict(state='passed' if not missing and not changed else 'failed',old_roots=len(old),current_roots=len(new),missing=missing,changed=changed,old_public_headers=headers,unchanged_old_backend_proof_files=untouched,axiom_sets=new)
out.write_text(json.dumps(d,indent=2)+'\n');assert d['state']=='passed';print('EXACT_OLD_AX_HEADER_PARITY_PASS',len(old),len(new),len(headers),untouched)
