from pathlib import Path
p=Path('FVTest/Backend/Lowering/StockGeneralDivProductionLinked.lean');s=p.read_text();s='import FV.Backend.Lowering.StockConditionalForwardCfgNI\n'+s
s=s.replace('(conditional : Bool := false) : IO Unit := do','(conditional : Bool := false) (conditionalForward : Bool := false) : IO Unit := do')
s=s.replace('|| forward || conditional\n','|| forward || conditional || conditionalForward\n')
# Previous providers are deliberately the entire current conditional implementation.
s=s.replace('if conditional then Stock.ForwardCfg.lowerValidated','if conditionalForward then Stock.ConditionalCfg.lowerValidated else if conditional then Stock.ForwardCfg.lowerValidated')
s=s.replace('if conditional then "Backend.Stock.ForwardCfg.lowerValidated"','if conditionalForward then "Backend.Stock.ConditionalCfg.lowerValidated" else if conditional then "Backend.Stock.ForwardCfg.lowerValidated"')
s=s.replace('else if conditional then Stock.ConditionalCfg.lowerValidated','else if conditionalForward then Stock.ConditionalForwardCfg.lowerValidated else if conditional then Stock.ConditionalCfg.lowerValidated')
s=s.replace('else if conditional then "Backend.Stock.ConditionalCfg.lowerValidated"','else if conditionalForward then "Backend.Stock.ConditionalForwardCfg.lowerValidated" else if conditional then "Backend.Stock.ConditionalCfg.lowerValidated"')
s=s.replace('if conditional then FVTest.StockTwoBlockProductionRuntime.conditionalFunctions','if conditionalForward then FVTest.StockTwoBlockProductionRuntime.conditionalForwardFunctions else if conditional then FVTest.StockTwoBlockProductionRuntime.conditionalFunctions')
s=s.replace('if conditional then 100','if conditionalForward then 100 else if conditional then 100')
s=s.replace('if conditional && mixed','if (conditional || conditionalForward) && mixed')
s=s.replace('if conditional then Stock.ConditionalCfg.eligible','if conditionalForward then Stock.ConditionalForwardCfg.eligible else if conditional then Stock.ConditionalCfg.eligible')
s=s.replace('if conditional then Stock.ConditionalCfg.check','if conditionalForward then Stock.ConditionalCfg.rankedCheck else if conditional then Stock.ConditionalCfg.check')
s=s.replace('if conditional then empty else !empty','if conditionalForward then !empty else if conditional then empty else !empty')
s=s.replace('if conditional then "CfgConditionalProduction"','if conditionalForward then "CfgConditionalForwardProduction" else if conditional then "CfgConditionalProduction"')
s=s.replace('if conditional then "FV.Backend.Lowering.StockConditionalCfgNI"','if conditionalForward then "FV.Backend.Lowering.StockConditionalForwardCfgNI" else if conditional then "FV.Backend.Lowering.StockConditionalCfgNI"')
a=s.index('def checkCfgConditional (');b=s.index('end FVTest.StockGeneralDivProductionLinkedFixture',a);method=s[a:b].replace('def checkCfgConditional (','def checkCfgConditionalForward (')
lines=[]
for line in method.splitlines():
 if 'checkCase out ' in line:
  before,after=line.rsplit(' true',1);assert not after;line=before+' false true'
 lines.append(line)
s=s[:b]+'\n'.join(lines)+'\n'+s[b:]
s=s.replace('  if args.head? == some "--cfgconditional" then','  if args.head? == some "--cfgconditionalforward" then\n    FVTest.StockGeneralDivProductionLinkedFixture.checkCfgConditionalForward (System.FilePath.mk (args[1]?.getD "/tmp/stock-cfgconditionalforward-linked-fixture"))\n  else if args.head? == some "--cfgconditional" then')
p.write_text(s)
# Add the new class to existing maintained integration/native commands.
for name in ['scripts/check-stock-mixed-integration.py','scripts/check-stock-mixed-native.py']:
 p=Path(name);s=p.read_text()
 s=s.replace('"cfgconditional"]','"cfgconditional", "cfgconditionalforward"]')
 s=s.replace('"cfgconditional")','"cfgconditional", "cfgconditionalforward")')
 s=s.replace('"cfgconditional": "CfgConditionalProduction"','"cfgconditional": "CfgConditionalProduction", "cfgconditionalforward": "CfgConditionalForwardProduction"')
 s=s.replace('"cfgconditional": "stock-general-div"','"cfgconditional": "stock-general-div", "cfgconditionalforward": "stock-general-div"')
 s=s.replace("'CfgConditionalProduction')","'CfgConditionalProduction', 'CfgConditionalForwardProduction')")
 s=s.replace('"CfgConditionalProduction")','"CfgConditionalProduction", "CfgConditionalForwardProduction")')
 s=s.replace('(?:Scalar|ConditionalCfg|ForwardCfg','(?:Scalar|ConditionalForwardCfg|ConditionalCfg|ForwardCfg')
 # Existing native naming/count dispatches use one explicit map or conditional.
 s=s.replace('"cfgconditional": 100','"cfgconditional": 100, "cfgconditionalforward": 100')
 s=s.replace('"cfgconditional": "stock_cfgconditional"','"cfgconditional": "stock_cfgconditional", "cfgconditionalforward": "stock_cfgconditionalforward"')
 p.write_text(s)
