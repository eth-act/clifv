from pathlib import Path
import json,sys
out=Path(sys.argv[1]);result={}
for label in ['e2e','legacy-e2e']:
 paths={'original':Path('/tmp/legacy-dead-cleanup-final-'+label+'-identities.json'),'parent':Path('/tmp/stock-forward-cfg-native-v1/'+label+'-identities.json'),'current':out/(label+'-identities.json')}
 maps={k:{(v['file'],v['function'],v['index']):v['stages'] for v in json.load(p.open())['functions']} for k,p in paths.items()}
 assert len(maps['original'])==1150 and len(maps['parent'])==1159
 for name in ['original','parent']:assert all(maps['current'].get(k)==v for k,v in maps[name].items()),(label,name)
 result[label]={'counts':{k:len(v) for k,v in maps.items()},'original_and_parent_ordered_stages_exact':True}
(out/'identity-stage-parity-report.json').write_text(json.dumps(result,indent=2)+'\n');print('IDENTITY_STAGE_PARITY_PASS')
