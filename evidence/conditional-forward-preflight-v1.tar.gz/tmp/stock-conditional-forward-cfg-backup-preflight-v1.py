from pathlib import Path
import os,subprocess,hashlib,json,tarfile,datetime
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');os.chdir(root);os.nice(19);os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
def git(*args,env=None):return subprocess.check_output(['git',*args],env=env,text=True).strip()
head=git('rev-parse','HEAD');assert not git('status','--porcelain')
files=[]
for name in ['core-gates-v1','core-gates-v2','core-gates-v3','focused-axioms-v1','runtime-preflight-v1']:
 p=Path('/tmp/stock-conditional-forward-cfg-'+name)
 files += [x for x in p.rglob('*') if x.is_file() and x.suffix not in {'.olean','.ilean','.c','.a','.so','.o.export','.bc'}]
for p in Path('/tmp').glob('stock-conditional-forward-cfg-*'):
 if p.is_file() and p.suffix in {'.json','.py','.log','.lean','.md'} and 'normal-v1.log' not in p.name:files.append(p)
files.append(Path('/tmp/stock-conditional-cfg-merged.json'))
files=[p for p in sorted(set(files)) if p.is_file()]
manifest=dict(head=head,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),state='preflight only; frozen source full author gates pending',files={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files})
mp=Path('/tmp/stock-conditional-forward-cfg-preflight-manifest-v1.json');mp.write_text(json.dumps(manifest,indent=2)+'\n');files.append(mp)
a=Path('/tmp/stock-conditional-forward-cfg-preflight-v1.tar.gz')
with tarfile.open(a,'w:gz',compresslevel=1) as tf:
 for p in files:tf.add(p,arcname=str(p).lstrip('/'),recursive=False)
assert a.stat().st_size<32*1024*1024,a.stat().st_size
branch='agent/stock-cfg-body-progress-20261025T025359Z';parent=git('rev-parse',branch);idx=Path('/tmp/stock-conditional-forward-cfg-preflight-v1.index');idx.unlink(missing_ok=True);e=os.environ.copy();e['GIT_INDEX_FILE']=str(idx);git('read-tree',parent,env=e)
for p,key in [(a,'evidence/conditional-forward-preflight-v1.tar.gz'),(mp,'evidence/conditional-forward-preflight-manifest-v1.json')]:
 blob=git('hash-object','-w',str(p));git('update-index','--add','--cacheinfo',f'100644,{blob},{key}',env=e)
tree=git('write-tree',env=e);commit=git('commit-tree',tree,'-p',parent,'-m','Back up ranked conditional driver preflight evidence and validation recovery');git('update-ref','refs/heads/'+branch,commit,parent);subprocess.run(['git','push','origin',branch],check=True);assert git('ls-remote','origin','refs/heads/'+branch).split()[0]==commit
receipt=dict(head=head,evidence_commit=commit,archive_sha256=hashlib.sha256(a.read_bytes()).hexdigest(),bytes=a.stat().st_size,files=len(files),prior_tree_preserved=True);Path('/tmp/stock-conditional-forward-cfg-preflight-backup-v1.json').write_text(json.dumps(receipt,indent=2)+'\n');idx.unlink();print(json.dumps(receipt))
