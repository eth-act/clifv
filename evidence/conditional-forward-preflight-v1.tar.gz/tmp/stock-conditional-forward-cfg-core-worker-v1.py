from pathlib import Path
import os,json,subprocess
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');os.chdir(root);os.nice(10);os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:2])
e=json.load(open('/tmp/stock-mixed-div-env.json'));e.update(FV_ROOT=str(root),FV_MEMCAP='16G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',CARGO_BUILD_JOBS='2')
manifest={'packet':'conditional-forward-core-and-consumers','base':'91c809f798aa21e6625a09e2138b24921bb4d27f','candidate':'91c809f798aa21e6625a09e2138b24921bb4d27f','env':e,'tools':['lake','lean','python3'],'inputs':[str(root/'scripts/lake-serial-build.py')],'gates':[{'id':'core-consumers','argv':['python3','scripts/lake-serial-build.py','--min-cap','4G','--default-cap','4G','--out','{out}/modules','FV.Backend.Proof.StockConditionalRankedCheck','FV.Backend.ConditionalForwardCfgNIProduction','FV.E2E.CompiledSemanticNI','FVTest.Backend.Main','FVTest.Link.LeanLinkMain','FVTest.E2E.LinkCheckMain'],'requires':[r'END (\d+)/\1 ok'],'outputs':['{out}/modules/*.log'],'complete_inputs':False}]}
p=Path('/tmp/stock-conditional-forward-cfg-core-manifest-v1.json');p.write_text(json.dumps(manifest,indent=2)+'\n')
with open('/tmp/stock-conditional-forward-cfg-core-v1.log','w') as f:r=subprocess.run(['python3','scripts/stock-delivery-gates.py','run',str(p),'--root',str(root),'--out','/tmp/stock-conditional-forward-cfg-core-gates-v1'],stdout=f,stderr=subprocess.STDOUT)
print('Maintained core/consumer worker terminal',r.returncode)
