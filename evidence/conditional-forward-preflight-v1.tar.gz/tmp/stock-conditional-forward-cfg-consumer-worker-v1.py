from pathlib import Path
import os,json,subprocess,time,concurrent.futures,datetime
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');os.chdir(root);os.nice(10);os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:2])
prefix='/tmp/stock-conditional-forward-cfg-';head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();normal=Path(prefix+'normal-gates-v1');records={}
def stable():
 assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head
 assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
while not (normal/'receipt.json').exists():
 for name in ['normal','tools','trust']:
  p=normal/(name+'.json')
  if p.exists():assert json.load(p.open()).get('state')!='failed',(name,str(p))
 time.sleep(10)
assert json.load((normal/'receipt.json').open())['state']=='passed'
def run(label):
 stable();manifest=prefix+label+'-manifest-v1.json';out=prefix+label+'-gates-v1';log=prefix+label+'-runner-v1.log'
 with open(log,'w') as f:r=subprocess.run(['python3','scripts/stock-delivery-gates.py','run',manifest,'--root',str(root),'--out',out],stdout=f,stderr=subprocess.STDOUT)
 assert r.returncode==0,(label,r.returncode,log)
 d=json.load(open(out+'/receipt.json'));assert d['state']=='passed' and d['head']==head
 return label,dict(state='passed',receipt=out+'/receipt.json',utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
def record(future):
 label,r=future.result();records[label]=r;Path(prefix+'consumer-batch-v1.json').write_text(json.dumps(dict(head=head,state='running',records=records),indent=2)+'\n');print('PASS',label,flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 for f in concurrent.futures.as_completed([pool.submit(run,x) for x in ['full','current']]):record(f)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 for f in concurrent.futures.as_completed([pool.submit(run,x) for x in ['conditional','forward','linear','scalar-entry','entry','cfg']]):record(f)
stable();Path(prefix+'consumer-batch-v1.json').write_text(json.dumps(dict(head=head,state='passed',records=records),indent=2)+'\n');print('CONSUMER_BATCH_PASS',flush=True)
