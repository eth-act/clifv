import FV.Backend.Lowering.StockParameterCfg
import FV.Backend.Lowering.StockParameterCfgNI
import FV.Backend.ParameterCfgNIProduction
import FV.Backend.Proof.StockParameterCheck
import FV.Backend.Proof.StockParameterCheckedWitness
import FV.Backend.Proof.StockParameterCompatibility
import FV.Backend.Proof.StockParameterConditionalDomain
import FV.Backend.Proof.StockParameterDomain
import FV.Backend.Proof.StockParameterEntry
import FV.Backend.Proof.StockParameterFixture
import FV.Backend.Proof.StockParameterInput
import FV.Backend.Proof.StockParameterJumpDomain
import FV.Backend.Proof.StockParameterKernel
import FV.Backend.Proof.StockParameterMetadata
import FV.Backend.Proof.StockParameterPrelude
import FV.Backend.Proof.StockParameterReturn
import FV.Backend.Proof.StockParameterReturnEntry
import FV.Backend.Proof.StockParameterReturnPrelude
import FV.Backend.Proof.StockParameterSelection
import FV.Backend.Proof.StockParameterShape
import FV.Backend.Proof.StockParameterSuccessor
import FV.Backend.Proof.StockParameterTerms
import FV.Backend.Proof.StockParameterTrap
import FV.Backend.Proof.StockParameterWitness
import FV.Backend.SemanticNICheck
import FV.E2E.CompiledSemanticNI
import FV.E2E.StockParameterCfgFixtures
import FVTest.Backend.Lowering.StockGeneralDivProductionLinked
import FVTest.Backend.Lowering.StockGeneralDivProductionRuntime
import FVTest.Backend.Lowering.StockTwoBlockProductionRuntime
import FVTest.Backend.Main
import FVTest.E2E.LinkCheckMain
import FVTest.Link.LeanLinkMain
import Lean
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let core := #["FV.Backend.Lowering.StockParameterCfg", "FV.Backend.Lowering.StockParameterCfgNI", "FV.Backend.ParameterCfgNIProduction", "FV.Backend.Proof.StockParameterCheck", "FV.Backend.Proof.StockParameterCompatibility", "FV.Backend.Proof.StockParameterConditionalDomain", "FV.Backend.Proof.StockParameterDomain", "FV.Backend.Proof.StockParameterEntry", "FV.Backend.Proof.StockParameterFixture", "FV.Backend.Proof.StockParameterInput", "FV.Backend.Proof.StockParameterJumpDomain", "FV.Backend.Proof.StockParameterKernel", "FV.Backend.Proof.StockParameterMetadata", "FV.Backend.Proof.StockParameterPrelude", "FV.Backend.Proof.StockParameterReturn", "FV.Backend.Proof.StockParameterReturnEntry", "FV.Backend.Proof.StockParameterReturnPrelude", "FV.Backend.Proof.StockParameterSelection", "FV.Backend.Proof.StockParameterShape", "FV.Backend.Proof.StockParameterSuccessor", "FV.Backend.Proof.StockParameterTerms", "FV.Backend.Proof.StockParameterTrap", "FV.Backend.Proof.StockParameterWitness", "FV.Backend.SemanticNICheck", "FV.E2E.CompiledSemanticNI", "FV.E2E.StockParameterCfgFixtures", "FVTest.Backend.Lowering.StockGeneralDivProductionLinked", "FVTest.Backend.Lowering.StockGeneralDivProductionRuntime", "FVTest.Backend.Lowering.StockTwoBlockProductionRuntime", "FVTest.Backend.Main", "FVTest.E2E.LinkCheckMain", "FVTest.Link.LeanLinkMain"]
  let witnesses := #["FV.Backend.Proof.StockParameterCheckedWitness"]
  let fixedFacts := #["_private.FV.Backend.Proof.StockParameterCheckedWitness.0.Backend.Stock.Proof.ParameterCfg.Fixture.original_input_checks._native.native_decide.ax_1"]
  let mut ncore : Nat := 0
  let mut nwitness : Nat := 0
  for (name,_) in env.constants.toList do
    let some i := env.getModuleIdxFor? name | continue
    let owner := env.header.moduleNames[i]!.toString
    unless core.contains owner || witnesses.contains owner do continue
    for ax in ← collectAxioms name do
      if #[``propext,``Classical.choice,``Quot.sound].contains ax then continue
      unless witnesses.contains owner && fixedFacts.contains ax.toString do
        throwError "disallowed axiom {ax.toString} in {name} owned by {owner}"
    if core.contains owner then ncore := ncore+1 else nwitness := nwitness+1
  unless ncore > 0 && nwitness > 0 do throwError "empty ownership partition"
  logInfo m!"PARAMETER_CFG_OWNED_STANDARD_CORE {ncore}; FIXED_WITNESSES {nwitness}"
