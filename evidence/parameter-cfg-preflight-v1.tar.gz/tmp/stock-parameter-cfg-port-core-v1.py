from pathlib import Path
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');port=Path('/tmp/stock-conditional-forward-cfg-next-nonentry-port');target=root/'FV/Backend/Proof';ns='Backend.Stock.Proof.ParameterCfg';old='Backend.Stock.Proof.ConditionalValues.NextNonentry'
def prepare(source,imports,cut=None):
 s=(port/source).read_text();s=s[s.index('namespace '):]
 if cut:s=s[:s.index(cut)]+'\nend '+old+'\n'
 s=s.replace(old,ns).replace('Backend.Stock.ConditionalCfg.parameter_condition_metadata_ssa_draft','parameter_condition_metadata_ssa').replace('parameter_condition_metadata_ssa_draft','parameter_condition_metadata_ssa').replace('parameter_condition_metadata_draft','parameter_condition_metadata')
 # Prototype files relied on their parent ConditionalValues namespace.
 s=s.replace('open Backend.Proof Backend.Proof.Driver','open Backend.Proof Backend.Proof.Driver Backend.Stock.Proof.ConditionalValues')
 return ''.join('import '+m+'\n' for m in imports)+'\n'+s
files={}
s=(port/'NextParameterMetadata.lean').read_text();s=s[s.index('namespace Backend.Stock.ConditionalCfg'):s.index('private def metadataSource')];s=s.replace('namespace Backend.Stock.ConditionalCfg','namespace '+ns).replace('parameter_condition_metadata_ssa_draft','parameter_condition_metadata_ssa').replace('parameter_condition_metadata_draft','parameter_condition_metadata');files['StockParameterMetadata.lean']='import FV.Backend.Proof.StockDFG\nimport FV.Backend.Proof.LowerCertBase\n\n'+s+'\nend '+ns+'\n'
files['StockParameterTerms.lean']=prepare('NextParameterTerms.lean',['FV.Backend.Proof.StockParameterMetadata','FV.Backend.Proof.StockForwardReturn'], 'theorem nonentry_terms')
compat=(port/'NextParameterCompatibility.lean').read_text();defs=compat[compat.index('def ParameterTerms'):compat.index('private theorem selected_empty')];terms=files['StockParameterTerms.lean'];terms=terms.replace('\nend '+ns+'\n','\n'+defs+'\nend '+ns+'\n');files['StockParameterTerms.lean']=terms
files['StockParameterPrelude.lean']=prepare('NextNonentryPrelude.lean',['FV.Backend.Proof.StockConditionalBodyRefines'], 'def function')
files['StockParameterSelection.lean']=prepare('NextRankedSelection.lean',['FV.Backend.Proof.StockParameterTerms','FV.Backend.Proof.StockConditionalRankedDomain'], 'theorem ranked')
files['StockParameterReturn.lean']=prepare('NextParameterReturn.lean',['FV.Backend.Proof.StockParameterSelection','FV.Backend.Proof.StockParameterPrelude'])
files['StockParameterTrap.lean']=prepare('NextParameterTrap.lean',['FV.Backend.Proof.StockParameterReturn'])
s=prepare('NextParameterCompatibility.lean',['FV.Backend.Proof.StockParameterTrap']);begin=s.index('def ParameterTerms');end=s.index('private theorem selected_empty');s=s[:begin]+s[end:];files['StockParameterCompatibility.lean']=s
files['StockParameterEntry.lean']=prepare('NextParameterEntry.lean',['FV.Backend.Proof.StockParameterTrap','FV.Backend.Proof.StockJumpEntryPrelude'])
files['StockParameterReturnPrelude.lean']=prepare('NextReturnPrelude.lean',['FV.Backend.Proof.StockOriginalEntryPrelude','FV.Backend.Proof.StockCfgReturnBlock','FV.Backend.Proof.StockReturnScanShape'])
files['StockParameterReturnEntry.lean']=prepare('NextReturnEntry.lean',['FV.Backend.Proof.StockParameterReturnPrelude','FV.Backend.Proof.StockCfgReturnTrapAt','FV.Backend.Proof.StockJumpEntryPrelude'])
files['StockParameterSuccessor.lean']=prepare('NextParameterSuccessor.lean',['FV.Backend.Proof.StockParameterTrap'])
files['StockParameterJumpDomain.lean']=prepare('NextParameterJumpDomain.lean',['FV.Backend.Proof.StockParameterEntry','FV.Backend.Proof.StockParameterCompatibility','FV.Backend.Proof.StockScalarContract'], 'theorem all_parameter_terms')
files['StockParameterConditionalDomain.lean']=prepare('NextParameterConditionalDomain.lean',['FV.Backend.Proof.StockParameterSuccessor','FV.Backend.Proof.StockParameterReturnPrelude','FV.Backend.Proof.StockParameterCompatibility','FV.Backend.Proof.StockScalarContract'])
files['StockParameterDomain.lean']=prepare('NextParameterDomain.lean',['FV.Backend.Proof.StockParameterJumpDomain','FV.Backend.Proof.StockParameterConditionalDomain','FV.Backend.Proof.StockParameterReturnEntry'])
for name,s in files.items():
 assert 'NextNonentry' not in s and '_draft' not in s and 'import Next' not in s,name
 p=target/name;assert not p.exists(),p;p.write_text(s)
print('Ported',len(files),'proper proof modules; no fixture imports or previous source overwritten')
