from pathlib import Path
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025')
def read(n):return (root/n).read_text()
def write(n,s):(root/n).write_text(s)
fixture='''import FV.E2E.StockConditionalForwardCfgFixtures
import FV.Backend.Proof.DriverCtx

namespace E2E.StockParameterCfgNIWitness
open Backend.Stock.D0
set_option autoImplicit false

/-- Move the former entry condition into a genuine later block. Fresh entry
parameters pass through actual nonempty jump copies; original values and tails
remain intact, including inherited values, joins and first/later traps. -/
def functions (config : Configuration) : List (Clif.Function × Clif.Ty) :=
  (StockConditionalForwardCfgNIWitness.functions config).zipIdx.map fun ((f,ty),i) =>
    let entry := f.blocks[0]!
    let freshBlock := ((f.blocks.map (·.id)).foldl max 0)+1
    let freshValue := ((Backend.Proof.Driver.valueDefs f).foldl max 0)+1
    let params := entry.params.zipIdx.map fun ((_,t),j) => (freshValue+j,t)
    let first : Clif.Block := {id := entry.id,params,term := .jump ⟨freshBlock,params.map (·.1)⟩}
    ({f with name := s!"stock_cfgparameter_{i}"
      blocks := first :: {entry with id := freshBlock} :: f.blocks.drop 1},ty)

end E2E.StockParameterCfgNIWitness
'''
# DriverCtx import not needed: existing fixture imports the definitions closure.
fixture=fixture.replace('import FV.Backend.Proof.DriverCtx\n','')
write('FV/E2E/StockParameterCfgFixtures.lean',fixture)
name='FVTest/Backend/Lowering/StockTwoBlockProductionRuntime.lean';s=read(name);s='import FV.E2E.StockParameterCfgFixtures\nimport FV.Backend.ParameterCfgNIProduction\n'+s
s=s.replace('private def functionsFor','def parameterFunctions (config : Stock.D0.Configuration) : List (Clif.Function × Clif.Ty) :=\n  E2E.StockParameterCfgNIWitness.functions config\n\nprivate def functionsFor',1)
s=s.replace('(conditionalForward : Bool := false)', '(conditionalForward : Bool := false) (parameter : Bool := false)')
# Thread the new optional argument through helpers only, retaining all older call signatures.
s=s.replace('config conditional conditionalForward','config conditional conditionalForward parameter').replace('.systemVI32 conditional conditionalForward)', '.systemVI32 conditional conditionalForward parameter)')
replacements={
 'if conditionalForward then conditionalForwardFunctions':'if parameter then parameterFunctions config else if conditionalForward then conditionalForwardFunctions',
 'if conditionalForward then 100':'if parameter then 100 else if conditionalForward then 100',
 'if conditionalForward then Stock.ConditionalForwardCfg.lowerValidated':'if parameter then Stock.ParameterCfg.lowerValidated else if conditionalForward then Stock.ConditionalForwardCfg.lowerValidated',
 'if conditionalForward then Stock.ConditionalCfg.lowerValidated':'if parameter then Stock.ConditionalForwardCfg.lowerValidated else if conditionalForward then Stock.ConditionalCfg.lowerValidated',
 'if conditionalForward then Stock.ConditionalForwardCfg.eligible':'if parameter then Stock.ParameterCfg.eligible else if conditionalForward then Stock.ConditionalForwardCfg.eligible',
 'if conditionalForward then Stock.ConditionalCfg.rankedSourceOk':'if parameter then Stock.ParameterCfg.sourceOk else if conditionalForward then Stock.ConditionalCfg.rankedSourceOk',
 'if conditionalForward then Stock.ConditionalCfg.rankedCheck':'if parameter then Stock.ParameterCfg.check else if conditionalForward then Stock.ConditionalCfg.rankedCheck',
 'if conditionalForward then @compileFileConditionalForwardCfgNIWhen':'if parameter then @compileFileParameterCfgNIWhen IO _ else if conditionalForward then @compileFileConditionalForwardCfgNIWhen',
 'if conditionalForward then @compileFileConditionalCfgNIWhen':'if parameter then @compileFileConditionalForwardCfgNIWhen IO _ else if conditionalForward then @compileFileConditionalCfgNIWhen',
 'if conditionalForward then copies == sourceCopies':'if parameter then copies == sourceCopies else if conditionalForward then copies == sourceCopies',
 'if conditional || conditionalForward then':'if parameter || conditional || conditionalForward then',
 'if conditionalForward then "cfgconditionalforward"':'if parameter then "cfgparameter" else if conditionalForward then "cfgconditionalforward"',
}
for a,b in replacements.items():s=s.replace(a,b)
# The previous-class mixed retry must exercise all prior class code, using the same existing regression.
s=s.replace('    if conditionalForward then\n      let retainedLeaf := (conditionalFunctions config)[0]!.1\n      let added := (conditionalForwardFunctions config)[0]!.1\n      require (Stock.ConditionalCfg.eligible retainedLeaf && !eligible retainedLeaf && eligible added)',
'''    if parameter || conditionalForward then
      let retainedLeaf := (if parameter then conditionalForwardFunctions config else conditionalFunctions config)[0]!.1
      let added := (if parameter then parameterFunctions config else conditionalForwardFunctions config)[0]!.1
      require ((if parameter then Stock.ConditionalForwardCfg.eligible retainedLeaf else Stock.ConditionalCfg.eligible retainedLeaf) && !eligible retainedLeaf && eligible added)''')
s=s.replace('end FVTest.StockTwoBlockProductionRuntime','''def checkParameter (checkedRegalloc2 : String → Array VCode → IO (Array (Except String AFunc))) : IO Unit :=
  checkClass false false false false checkedRegalloc2 false false true

end FVTest.StockTwoBlockProductionRuntime''')
write(name,s)
name='FVTest/Backend/Lowering/StockGeneralDivProductionRuntime.lean';s=read(name)
s=s.replace('  if args == ["--cfgconditionalforward"] then','  if args == ["--cfgparameter"] then\n    FVTest.StockTwoBlockProductionRuntime.checkParameter FVTest.StockGeneralDivProductionRuntime.checkedRegalloc2\n  else if args == ["--cfgconditionalforward"] then');write(name,s)
name='FVTest/Backend/Lowering/StockGeneralDivProductionLinked.lean';s=read(name);s='import FV.Backend.Lowering.StockParameterCfgNI\n'+s
s=s.replace('(conditionalForward : Bool := false)', '(conditionalForward : Bool := false) (parameter : Bool := false)')
s=s.replace('|| forward || conditional || conditionalForward\n','|| forward || conditional || conditionalForward || parameter\n')
for a,b in {
 'if conditionalForward then Stock.ConditionalCfg.lowerValidated':'if parameter then Stock.ConditionalForwardCfg.lowerValidated else if conditionalForward then Stock.ConditionalCfg.lowerValidated',
 'if conditionalForward then "Backend.Stock.ConditionalCfg.lowerValidated"':'if parameter then "Backend.Stock.ConditionalForwardCfg.lowerValidated" else if conditionalForward then "Backend.Stock.ConditionalCfg.lowerValidated"',
 'else if conditionalForward then Stock.ConditionalForwardCfg.lowerValidated':'else if parameter then Stock.ParameterCfg.lowerValidated else if conditionalForward then Stock.ConditionalForwardCfg.lowerValidated',
 'else if conditionalForward then "Backend.Stock.ConditionalForwardCfg.lowerValidated"':'else if parameter then "Backend.Stock.ParameterCfg.lowerValidated" else if conditionalForward then "Backend.Stock.ConditionalForwardCfg.lowerValidated"',
 'if conditionalForward then FVTest.StockTwoBlockProductionRuntime.conditionalForwardFunctions':'if parameter then FVTest.StockTwoBlockProductionRuntime.parameterFunctions (configFor i) else if conditionalForward then FVTest.StockTwoBlockProductionRuntime.conditionalForwardFunctions',
 'if conditionalForward then 100':'if parameter then 100 else if conditionalForward then 100',
 'if (conditional || conditionalForward) && mixed':'if (parameter || conditional || conditionalForward) && mixed',
 'if conditionalForward then Stock.ConditionalForwardCfg.eligible':'if parameter then Stock.ParameterCfg.eligible else if conditionalForward then Stock.ConditionalForwardCfg.eligible',
 'if conditionalForward then Stock.ConditionalCfg.rankedCheck':'if parameter then Stock.ParameterCfg.check else if conditionalForward then Stock.ConditionalCfg.rankedCheck',
 'if conditionalForward then !empty':'if parameter then !empty else if conditionalForward then !empty',
 'if conditionalForward then "CfgConditionalForwardProduction"':'if parameter then "CfgParameterProduction" else if conditionalForward then "CfgConditionalForwardProduction"',
 'if conditionalForward then "FV.Backend.Lowering.StockConditionalForwardCfgNI"':'if parameter then "FV.Backend.Lowering.StockParameterCfgNI" else if conditionalForward then "FV.Backend.Lowering.StockConditionalForwardCfgNI"',
}.items():s=s.replace(a,b)
a=s.index('def checkCfgConditionalForward (');b=s.index('end FVTest.StockGeneralDivProductionLinkedFixture',a);method=s[a:b].replace('def checkCfgConditionalForward (','def checkCfgParameter (')
lines=[]
for l in method.splitlines():
 if 'checkCase out ' in l:
  before,after=l.rsplit(' true',1);assert not after;l=before+' false true'
 lines.append(l)
s=s[:b]+'\n'.join(lines)+'\n'+s[b:]
s=s.replace('  if args.head? == some "--cfgconditionalforward" then','  if args.head? == some "--cfgparameter" then\n    FVTest.StockGeneralDivProductionLinkedFixture.checkCfgParameter (System.FilePath.mk (args[1]?.getD "/tmp/stock-cfgparameter-linked-fixture"))\n  else if args.head? == some "--cfgconditionalforward" then');write(name,s)
for name in ['scripts/check-stock-mixed-integration.py','scripts/check-stock-mixed-native.py']:
 s=read(name).replace('"cfgconditionalforward"]','"cfgconditionalforward", "cfgparameter"]').replace('"cfgconditionalforward")','"cfgconditionalforward", "cfgparameter")')
 s=s.replace('"cfgconditionalforward": "CfgConditionalForwardProduction"','"cfgconditionalforward": "CfgConditionalForwardProduction", "cfgparameter": "CfgParameterProduction"').replace('"cfgconditionalforward": "stock-general-div"','"cfgconditionalforward": "stock-general-div", "cfgparameter": "stock-general-div"')
 s=s.replace("'CfgConditionalForwardProduction')","'CfgConditionalForwardProduction', 'CfgParameterProduction')").replace('"CfgConditionalForwardProduction")','"CfgConditionalForwardProduction", "CfgParameterProduction")')
 s=s.replace('(?:Scalar|ConditionalForwardCfg|','(?:Scalar|ParameterCfg|ConditionalForwardCfg|')
 write(name,s)
