from pathlib import Path
import json,subprocess
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');prefix='/tmp/stock-parameter-cfg-';oldprefix='/tmp/stock-conditional-forward-cfg-';base='07989b8fd7a1de9efb296f4c5933da2087232ec7'
# Run only after the implementation checkpoint is frozen.
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
for kind in ['normal','full','current','conditional','forward','linear','scalar-entry','entry','cfg','post']:
 old=Path(oldprefix+kind+'-manifest-v1.json');m=json.load(old.open());m['packet']='parameter-cfg-production';m['base']=base;m['candidate']=head
 # Preserve historical scripts and data; change ONLY this packet's output names.
 for g in m['gates']:
  for key in ['argv','outputs','inputs']:
   if key in g:g[key]=[x.replace(oldprefix,prefix) if x.startswith(oldprefix) and not x.endswith('.py') else x for x in g[key]]
 if kind=='current':
  for g in m['gates']:g['argv']=[x.replace('cfgconditionalforward','cfgparameter') for x in g['argv']]
 if kind=='full':
  # Kept original/prior identity data and exact ordered-stage test.
  m['gates'][4]['inputs']=[x.replace(prefix,oldprefix) if x.startswith(prefix) and x.endswith('.py') else x for x in m['gates'][4]['inputs']]
 if kind=='post':
  # Contract check targets actual #636 roots and unchanged public headers.
  g=m['gates'][0];g['argv']=['python3',prefix+'contract-parity-v1.py'];g['inputs']=[prefix+'contract-parity-v1.py',oldprefix+'contract-parity-v1.json',prefix+'normal-gates-v1/all-axioms/*.log'];g['outputs']=[prefix+'contract-parity-v1.json']
  m['gates']=[g]+m['gates'][1:-1]
  m['gates'].append(dict(id='owned-parameter',argv=['lake','env','lean',prefix+'owned-v1.lean'],inputs=[prefix+'owned-v1.lean'],complete_inputs=False))
  m['gates'].append(dict(id='paired-actual',argv=['python3',prefix+'paired-actual-v1.py'],inputs=[prefix+'paired-actual-v1.py',prefix+'baseline/provenance.json',oldprefix+'paired-actual-v1/provenance.json',oldprefix+'paired-actual-v1/rows.json'],outputs=[prefix+'paired-actual-v1/summary.json',prefix+'paired-actual-v1/provenance.json'],complete_inputs=False))
 Path(prefix+kind+'-manifest-v1.json').write_text(json.dumps(m,indent=2)+'\n')
# Retain the immediately previous current class in addition to all six older cohorts.
m=json.load(open(prefix+'current-manifest-v1.json'));m['gates']=[m['gates'][0]];g=m['gates'][0];g['id']='integration-conditional-forward';g['argv']=[x.replace(prefix+'current-integration-v1',prefix+'conditional-forward-integration-v1').replace('cfgparameter','cfgconditionalforward') for x in g['argv']];g['outputs']=[x.replace(prefix+'current-integration-v1',prefix+'conditional-forward-integration-v1') for x in g['outputs']];Path(prefix+'conditional-forward-manifest-v1.json').write_text(json.dumps(m,indent=2)+'\n')
# Exact prior audit inventory. This is the actual current parent's successful inventory.
p=Path(oldprefix+'contract-parity-v1.py');s=p.read_text().replace("parent='91c809f798aa21e6625a09e2138b24921bb4d27f'","parent='"+base+"'")
s=s.replace("out=Path('/tmp/stock-conditional-forward-cfg-contract-parity-v1.json')","out=Path('/tmp/stock-parameter-cfg-contract-parity-v1.json')").replace("'/tmp/stock-conditional-forward-cfg-parent-trust/exact-parity.json'","'/tmp/stock-conditional-forward-cfg-contract-parity-v1.json'").replace('len(old)==3698','len(old)==3716').replace("'/tmp/stock-conditional-forward-cfg-normal-gates-v1/all-axioms'","'/tmp/stock-parameter-cfg-normal-gates-v1/all-axioms'")
Path(prefix+'contract-parity-v1.py').write_text(s)
# Actual rebuilt current outputs paired to the previous actual candidate artifacts.
s=Path(oldprefix+'paired-actual-v1.py').read_text().replace("prefix='/tmp/stock-conditional-forward-cfg-'","prefix='/tmp/stock-parameter-cfg-'").replace("base='91c809f798aa21e6625a09e2138b24921bb4d27f'","base='"+base+"'").replace("Path('/tmp/stock-conditional-cfg-paired-main-v5')","Path('/tmp/stock-conditional-forward-cfg-paired-actual-v1')")
s=s.replace("prior['captured_inputs']","prior['files']").replace("['lean.o','inputs.rsp']:keep(parent/cgu/'candidate'/file", "['lean.o','lean-inputs.rsp']:keep(parent/cgu/'candidate'/file").replace("parent/cgu/'captured/cgclif.o'","parent/cgu/'candidate/cgclif.o'")
Path(prefix+'paired-actual-v1.py').write_text(s)
print('Prepared source-bound author manifests for',head)
