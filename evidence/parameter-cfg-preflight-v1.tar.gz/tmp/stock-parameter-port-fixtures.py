from pathlib import Path
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025/FV/Backend/Proof');scratch=Path('/tmp/stock-conditional-forward-cfg-next-nonentry-port')
ns='Backend.Stock.Proof.ParameterCfg.Fixture';old='Backend.Stock.Proof.ConditionalValues.NextNonentry'
settings='''open Backend.Proof Backend.Proof.Driver Backend.Stock.Proof.ForwardSource Backend.Stock.Proof.ConditionalValues
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 20000
set_option maxHeartbeats 16000000
'''
def read(n):return (scratch/(n+'.lean')).read_text()
def clean(s):return '\n'.join(l for l in s.replace(old,ns).splitlines() if not l.startswith('#print axioms'))+'\n'
def save(n,s): (root/(n+'.lean')).write_text(clean(s))
r=read('NextNonentryPrelude');t=read('NextTrapSource')
rdef=r[r.index('def function :'):r.index('private def original :')]
rinit=r[r.index('def initial (word'):r.index('theorem source_cases')]
tdef=t[t.index('def function :'):t.index('private def snapshot :')]
save('StockParameterFixture','import FV.Backend.Proof.StockParameterCheck\nimport FV.Backend.Proof.RefinesCSem\nimport FV.E2E.RegLevelDriverSem\n\nnamespace '+ns+'\n'+settings+rdef+rinit+'\nnamespace Trap\n'+tdef+'end Trap\nend '+ns+'\n')
snapshot='''private def snapshot : Bool :=
  match Stock.lower function with
  | .error _ => false
  | .ok result => decide (result.order.nodes[1]? = some (.original 1)) && ABIReadCfg.check function.sig result.code
/-- Actual Stock compilation and its finite ABI read boundary are kernel checked. -/
theorem snapshot_success : snapshot = true := by decide +kernel

theorem lowered : ∃ result,Stock.lower function = .ok result ∧
    result.order.nodes[1]? = some (.original 1) ∧ ABIReadCfg.check function.sig result.code = true := by
  have checked := snapshot_success
  unfold snapshot at checked
  cases run : Stock.lower function with
  | error message => simp only [run] at checked; cases checked
  | ok result =>
    simp only [run,Bool.and_eq_true,decide_eq_true_eq] at checked
    exact ⟨result,rfl,checked⟩
'''
save('StockParameterKernel','import FV.Backend.Proof.StockParameterFixture\nimport FV.Backend.ABIReadCfg\n\nnamespace '+ns+'\n'+settings+snapshot+'\nnamespace Trap\n'+snapshot+'end Trap\nend '+ns+'\n')
rin=r[r.index('private def original :'):r.index('def initial (word')]+r[r.index('theorem source_cases'):r.index('#print axioms')]
tin=read('NextTrapInput');tin=tin[tin.index('private def original :'):tin.index('theorem ranked :')]
tcases=t[t.index('theorem source_cases'):t.index('theorem lowered :')]
# Source selector derives control/ranking/family facts without opaque dominatedB evaluation.
facts='''
theorem selector_witness : Stock.ParameterCfg.sourceEligible function = true ∧
    Stock.ParameterCfg.hasNonentryConditional function = true ∧
    Stock.ConditionalCfg.rankedEligible function = false := ⟨rfl,rfl,rfl⟩
theorem ranked : Ranked function id := (Stock.ParameterCfg.source_eligible_facts selector_witness.1).2.1
theorem all_parameter_terms : ParameterTerms function := (Stock.ParameterCfg.source_eligible_facts selector_witness.1).1
theorem nonentry_terms : NonentryParameterTerms function := parameter_terms_nonentry all_parameter_terms
theorem original_domain_witness : Scalar.Domain function :=
  Stock.ParameterCfg.domain_of_source_eligible selector_witness.1 scope dominated rfl
'''
# trap input scope/family are after the manual ranked/nonentry drafts; use only original source/scope proof here.
tin += '\ntheorem scope : LowerScope function := lowerScope_of rfl\n'
save('StockParameterInput','import FV.Backend.Proof.StockParameterKernel\n\nnamespace '+ns+'\n'+settings+rin+facts+'\nnamespace Trap\n'+tcases+tin+facts+'end Trap\nend '+ns+'\n')
# Port retained body and exact compiled continuation witnesses, adapting the strengthened lowered triple.
w=read('NextNonentryWitness');w=w[w.index('theorem nonentry_condition_metadata'):w.index('#print axioms')]
w=w.replace('Backend.Stock.ConditionalCfg.parameter_condition_metadata_ssa_draft','parameter_condition_metadata_ssa')
w=w.replace('⟨result,run,tag⟩ := lowered','⟨result,run,tag,_⟩ := lowered')
rw=read('NextParameterReturnWitness');rw=rw[rw.index('theorem actual_return_continuation_witness'):rw.index('#print axioms')].replace('⟨result,run,tag⟩ := lowered','⟨result,run,tag,_⟩ := lowered')
tw=read('NextTrapWitness');tw=tw[tw.index('theorem actual_trap_continuation_witness'):tw.index('#print axioms')].replace('⟨result,run,tag⟩ := lowered','⟨result,run,tag,_⟩ := lowered')
rank=read('NextRankedSelection');rank=rank[rank.index('theorem selected_ranked_target_witness'):rank.index('#print axioms')].replace('⟨result,run,tag⟩ := lowered','⟨result,run,tag,_⟩ := lowered')
m=read('NextParameterMachineWitness');m=m[m.index('theorem parameter_cfg_machine_return_witness'):m.index('#print axioms')].replace('⟨result,run,_⟩ := lowered','⟨result,run,_,_⟩ := lowered')
save('StockParameterWitness','import FV.Backend.Proof.StockParameterInput\n\nnamespace '+ns+'\n'+settings+w+rank+rw+'\nnamespace Trap\n'+tw+'end Trap\n'+m+'end '+ns+'\n')
