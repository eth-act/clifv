from pathlib import Path
import os,json,subprocess,time,datetime,hashlib,collections
root=Path('/home/lee/clifv/.worktrees/stock-mixed-div-20261022');head='0aecff7cbeb8e0dc295855bf27d77c4ffdfffdfa'
env=os.environ.copy();env.update(json.load(open('/tmp/stock-mixed-div-env.json')));env.update(FV_MEMCAP='4G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2')
state=json.load(open('/tmp/stock-mask-parallel-controller-v1.json'));assert state['state']=='all_queued_gates_passed_review_still_required'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head
for label,args in [('parity',['python3','/tmp/stock-mask-post-gates.py']),('readiness',['python3','/tmp/stock-mask-readiness.py'])]:
 with Path('/tmp/stock-mask-final-'+label+'.log').open('w') as f:r=subprocess.run(args,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 assert r.returncode==0,(label,r.returncode)
with Path('/tmp/stock-mask-final-crate-reuse.log').open('w')as stream:
 r=subprocess.run(['python3','/tmp/stock-mask-reuse-crate-parity.py'],cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT)
assert r.returncode==0,('fresh-current-source-crate-comparison',r.returncode)
print('ALL_CURRENT_AUTHOR_CONSUMER_PARITY_AND_FRESH_CRATE_GATES_PASSED')
