import FV.Backend.Proof.StockBranchHelperTargets
import FV.Backend.Proof.StockBranchRootTargets
import FV.Backend.Proof.StockNamedBranchTargets
import FV.Backend.Proof.StockOrdinaryCfg
import FV.Backend.Proof.StockCfgTotal
import FV.Backend.Proof.StockBranchTargetsWitness
import FV.Backend.Proof.StockCfgTotalWitness
#print axioms Backend.Stock.Proof.BranchHelperTargets.stock_test_bit_emitted_targets
#print axioms Backend.Stock.Proof.BranchHelperTargets.stock_table_impl_targets
#print axioms Backend.Stock.Proof.BranchRootTargets.stock_selected_test_bit_targets
#print axioms Backend.Stock.Proof.BranchRootTargets.stock_selected_table_targets
#print axioms Backend.Stock.Proof.NamedBranchTargets.stock_named_brif_targets
#print axioms Backend.Stock.Proof.NamedBranchTargets.stock_named_table_targets
#print axioms Backend.Stock.Proof.OrdinaryCfg.stock_lower_ordinary_targets
#print axioms Backend.Stock.Proof.OrdinaryCfg.stock_lower_ordinary_cfg
#print axioms Backend.Stock.Proof.stock_lower_cfg
#print axioms Backend.Stock.Proof.stock_prepare_total
#print axioms Backend.Stock.Proof.BranchTargetsWitness.stock_branch_named_targets_witness
#print axioms Backend.Stock.Proof.BranchTargetsWitness.stock_test_bit_helper_targets_witness
#print axioms Backend.Stock.Proof.BranchTargetsWitness.stock_table_helper_targets_witness
#print axioms Backend.Stock.Proof.CfgTotalWitness.stock_branch_cfg_prepare_witness
#print axioms Backend.Stock.Proof.CfgTotalWitness.stock_critical_cfg_prepare_witness
#print axioms Backend.Stock.Proof.CfgTotalWitness.stock_return_cfg_prepare_witness
#print axioms Backend.Stock.Proof.CfgTotalWitness.stock_trap_cfg_prepare_witness
#print axioms Backend.Stock.Proof.CfgTotalWitness.stock_try_cfg_prepare_witness
