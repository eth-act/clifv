Enable Stock lowering for single-block `bmask` and `nop` functions mixed with the existing scalar and division families. Input/output widths vary independently across i8/i16/i32/i64. The proofs connect actual helper selection and retained result binding to guarded source return/trap execution and CSETM ABI frames through the ordinary compiler, checker, linker and generated-proof routes. Existing conditions, theorem variants and legacy fallback remain.

Validation on implementation `0aecff7c`:

- All 24 readiness requirements passed: 3,976/3,976 normal modules, 11 affected tools, 656 axiom reports, 70 ownership partitions, and exact prior axiom/header/identity/stage parity.
- 3,888 emitted-byte executions agree with 972 Cranelift references across 12 objects; all 12 ordinary CLI objects match the raw Stock API exactly. Both allocators and cleanup settings, missing-oracle control, and all new/retained linked and generated-proof consumers pass.
- Runtime: 5,755 pass, zero failures; encoder: 1,398 identical, zero differences; both E2E modes: 1,159 accepted, zero rejected. Crate proofs, 15,200 fault vectors and verified fv-demo/survey pass. Original unsupported/non-runnable cases remain explicit.

Publication `4c24e381` adds evidence/plan/ledger and removes one EOF blank. Fresh normal keys, all affected tools, public audits and ordinary CLI pass; the compiled proof leaf and all 11 executables are byte-identical. Original receipts retain their source heads. [Activation evidence and remote backup](https://github.com/eth-act/clifv/blob/4c24e381dde0ed3a249c8c9a9129f3adc7ffa1e4/docs/research/stock-mask-production-activation.md).

Fresh paired real-crate agreement remains 887/4,543 symbol comparisons, with zero gains/losses. Refs #140; CFG, memory/effects, calls/unwind, whole-driver simulation and Stock-only/downstream completeness remain open.
