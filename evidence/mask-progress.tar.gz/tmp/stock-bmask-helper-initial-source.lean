import FV.Backend.Proof.StockCmpZeroHelpers
import FV.Backend.Proof.IselAtomic

namespace Backend.Stock.Proof.ScalarMask
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
attribute [local irreducible] Isle.Aarch64.program

private theorem sem_ctor (ctx : Ctx) (t : Term) (vs : List V) (st : State) :
    (Stock.sem ctx).ctor t vs st = Stock.externCtor ctx t vs st := rfl

private theorem sem_mkData (ctx : Ctx) (ty k : Nat) (vs : List V) :
    (Stock.sem ctx).mkData ty k vs = .data ty k vs := rfl

private theorem sem_unData (ctx : Ctx) (ty t k : Nat) (vs : List V) :
    (Stock.sem ctx).unData ty (.data t k vs) = if t = ty then some (k,vs) else none :=
  Backend.Proof.sem_unData ctx ty t k vs

/-- The actual CSETM consumer allocates its result while retaining the complete
Stock scheduling state. Its instruction is emitted by the enclosing flags helper. -/
theorem stock_csetm_helper {p : Program} (hp : Data p) (ctx : Ctx) {cfg : Config}
    (hc : cfg.checkOverlap = false) (condition : V) (st : State)
    (trace : Array RuleId) (n : Nat) :
    (applyTerm p (Stock.sem ctx) cfg (n+30) 49 428 [condition]).run (st,trace) =
      .ok (some (.data 49 3 [
        .data 58 34 [.reg (st.base.fresh .int).1,condition],
        .reg (st.base.fresh .int).1]),
        {st with base := (st.base.fresh .int).2},trace.push rule_inst_3082.id) := by
  cases hp
  isel_eval [*,rule_inst_3082,sem_ctor,sem_mkData,sem_unData,
    Stock.externCtor,Backend.externCtor]

/-- A real condition and real fresh register inhabit the helper contract. -/
theorem stock_csetm_helper_witness (condition : Cond) :
    ∃ out next trace,
      (applyTerm program (Stock.sem sinkCtx) {} 1000 49 428 [V.ofCond condition]).run
        (sinkState,#[]) = .ok (some out,next,trace) := by
  exact ⟨_,_,_,stock_csetm_helper data_program sinkCtx (cfg := {}) rfl
    (V.ofCond condition) sinkState #[] 970⟩

end Backend.Stock.Proof.ScalarMask
