from pathlib import Path
import re,json,hashlib,sys
old=Path('/tmp/stock-narrow-axioms-current/narrow-audits/stock-narrow-public-audit.log')
new=Path('/tmp/stock-mask-axioms-current/narrow-audits/stock-narrow-public-audit.log')
allowed={'propext','Classical.choice','Quot.sound','E2E.StockNarrowNIWitness.checks_true._native.native_decide.ax_1'}
def parse(path):
 facts={}
 for m in re.finditer(r"'([^']+)' (does not depend on any axioms|depends on axioms: \[([^\]]*)\])",path.read_text()):
  axioms={a.strip() for a in (m[3]or'').split(',')if a.strip()}
  assert axioms<=allowed,(path,m[1],axioms-allowed)
  assert m[1] not in facts or facts[m[1]]==axioms
  facts[m[1]]=axioms
 return facts
before=parse(old);assert len(before)==23,len(before)
if '--baseline-only' in sys.argv:
 print('NARROW23_BASELINE_PARSED');raise SystemExit(0)
after=parse(new)
assert before.keys()<=after.keys()
assert all(v==after[k]for k,v in before.items())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r={'state':'passed','prior_roots':len(before),'all_prior_axiom_sets_exact':True,'old_log':str(old),'old_sha256':sha(old),'new_log':str(new),'new_sha256':sha(new),'roots':{k:sorted(v)for k,v in before.items()}}
Path('/tmp/stock-mask-narrow-axiom-parity.json').write_text(json.dumps(r,indent=2)+'\n');print('NARROW23_EXACT_AXIOM_SETS_PASSED')
