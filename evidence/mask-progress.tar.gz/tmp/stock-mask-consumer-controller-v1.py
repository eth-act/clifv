from pathlib import Path
import os,json,subprocess,time,datetime,re
root=Path('/home/lee/clifv/.worktrees/stock-mixed-div-20261022')
e=os.environ.copy();e.update(json.load(open('/tmp/stock-mixed-div-env.json')));e.update(FV_MEMCAP='8G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2')
e.update(STOCK_MASK_NATIVE_OUT='/tmp/stock-mask-native-v1',LEAN_NUM_THREADS='2',CARGO_BUILD_JOBS='2')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert head=='0aecff7cbeb8e0dc295855bf27d77c4ffdfffdfa'
status=Path('/tmp/stock-mask-consumer-controller-v1.json');events=[]
def note(**kw):
 events.append(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),**kw));status.write_text(json.dumps({'head':head,'pid':os.getpid(),'events':events,'full_140_complete':False},indent=2)+'\n')
def frozen():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head
 subprocess.run(['git','diff','--exit-code','HEAD','--','FV','FVTest','scripts'],cwd=root,check=True,stdout=subprocess.DEVNULL)
def start_id(pid):
 try:return Path(f'/proc/{pid}/stat').read_text().split(') ',1)[1].split()[19]
 except FileNotFoundError:return None
waiters={pid:start_id(pid) for pid in (205175,)}
note(action='waiting_specific_normal_builds',process_start_ids=waiters)
while any(v is not None and start_id(pid)==v for pid,v in waiters.items()):time.sleep(10)
frozen()
text=Path('/tmp/stock-mask-full-normal-v2.log').read_text();matches=re.findall(r'END (\d+)/(\d+) ok',text)
assert matches and matches[-1]==('3976','3976'),text[-3000:]
note(action='normal_passed',modules=3976)
assert subprocess.check_output(['nproc'],env=e,text=True).strip()=='2'
def run(name,argv):
 frozen();log=Path('/tmp/stock-mask-consumer-'+name+'.log');note(action='start',name=name,argv=argv,log=str(log))
 with log.open('w') as f:r=subprocess.run(argv,cwd=root,env=e,stdout=f,stderr=subprocess.STDOUT)
 note(action='done',name=name,returncode=r.returncode);frozen()
 if r.returncode:raise SystemExit(r.returncode)
names=['lean-backend','lean-backend-armrun','lean-backend-encode-test','lean-e2e-check','link-check','lean-link','arm-fault-cosim','stock-general-div-runtime','stock-general-div-linked','stock-returned-div-runtime','stock-returned-div-linked']
for name in names:run('build-'+name,['scripts/memcap.sh','taskset','-c','0','lake','build',name])
run('mask-runtime',['scripts/memcap.sh','.lake/build/bin/stock-general-div-runtime','--mask'])
run('mask-native',['scripts/memcap.sh','python3','scripts/check-stock-mixed-native.py','/tmp/stock-mask-native-v1','--class','mask'])
run('mask-ordinary-cli',['scripts/memcap.sh','python3','scripts/check-stock-api-backend-cli.py','/tmp/stock-mask-native-v1','--output','/tmp/stock-mask-ordinary-cli-v1'])
for category in ['integration','retained-integration','wide-integration','axioms','owned','full','examples']:
 run(category,['taskset','-c','0-7','python3','scripts/stock-delivery-gates.py','run','/tmp/stock-mask-'+category+'-manifest.json','--out','/tmp/stock-mask-'+category+'-current'])
note(action='all_queued_gates_passed_review_still_required',full_140_complete=False)
