from pathlib import Path
import os,json,subprocess,time,datetime,signal,threading,concurrent.futures
root=Path('/home/lee/clifv/.worktrees/stock-mixed-div-20261022')
head='0aecff7cbeb8e0dc295855bf27d77c4ffdfffdfa'
env=os.environ.copy();env.update(json.load(open('/tmp/stock-mixed-div-env.json')));env.update(FV_MEMCAP='8G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',CARGO_BUILD_JOBS='2',STOCK_MASK_NATIVE_OUT='/tmp/stock-mask-native-v1')
status=Path('/tmp/stock-mask-parallel-controller-v1.json');lock=threading.Lock()
old=json.load(open('/tmp/stock-mask-consumer-controller-v1.json'));events=list(old['events']);state='active'
def note(**kw):
 with lock:
  events.append(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),**kw))
  data={'head':head,'pid':os.getpid(),'state':state,'events':events,'inherited_actual_events_from':'/tmp/stock-mask-consumer-controller-v1.json','full_140_complete':False}
  temporary=status.with_suffix('.tmp');temporary.write_text(json.dumps(data,indent=2)+'\n');temporary.replace(status)
def proc(pid):
 try:
  fields=Path(f'/proc/{pid}/stat').read_text().split(') ',1)[1].split();return fields[0],fields[19]
 except FileNotFoundError:return None,None
def live(pid,start):
 current,identity=proc(pid);return identity==start and current not in (None,'Z','X')
def frozen():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head
 subprocess.run(['git','diff','--exit-code','HEAD','--','FV','FVTest','scripts'],cwd=root,check=True,stdout=subprocess.DEVNULL)
def terminate_coordinator(pid,start):
 if proc(pid)[1]==start:
  os.kill(pid,signal.SIGTERM);os.kill(pid,signal.SIGCONT)
frozen();assert subprocess.check_output(['nproc'],env=env,text=True).strip()=='2'
coordinators={213557:'258636968',215097:'258648682'};stopped=[]
try:
 # Stop waiting coordinators only. Their active category runner and proof child continue untouched.
 for pid,start in coordinators.items():
  assert live(pid,start),(pid,proc(pid));os.kill(pid,signal.SIGSTOP);stopped.append((pid,start))
 old=json.load(open('/tmp/stock-mask-consumer-controller-v1.json'));current=old['events'][-1]
 assert current['action']=='start' and current['name'] in ['integration','retained-integration','wide-integration'],current
 category=current['name'];children=Path('/proc/213557/task/213557/children').read_text().split();assert len(children)<=1,children
 child=int(children[0])if children else None;child_start=proc(child)[1]if child else None
 if child:
  argv=Path(f'/proc/{child}/cmdline').read_bytes().split(b'\0');assert ('/tmp/stock-mask-'+category+'-manifest.json').encode()in argv,argv
 note(action='coordinator_transition_only',old_coordinators=coordinators,preserved_category=category,preserved_runner_pid=child,preserved_runner_start=child_start,aggregate_build_budget='16G; two8G lanes; OMP2; CPUs0-15')
 terminate_coordinator(215097,coordinators[215097]);stopped=[x for x in stopped if x[0]!=215097]
except BaseException:
 for pid,start in stopped:
  if proc(pid)[1]==start:os.kill(pid,signal.SIGCONT)
 raise

def run_category(name,cpus):
 frozen();argv=['taskset','-c',cpus,'python3','scripts/stock-delivery-gates.py','run','/tmp/stock-mask-'+name+'-manifest.json','--out','/tmp/stock-mask-'+name+'-current'];log=Path('/tmp/stock-mask-parallel-'+name+'.log')
 note(action='start',name=name,argv=argv,log=str(log))
 with log.open('w')as stream:r=subprocess.run(argv,cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT)
 note(action='done',name=name,returncode=r.returncode);frozen();assert r.returncode==0,(name,r.returncode,log)

def consumer_lane():
 try:
  while child is not None and live(child,child_start):time.sleep(5)
  frozen()
  argv=['python3','scripts/stock-delivery-gates.py','report','/tmp/stock-mask-'+category+'-manifest.json','--out','/tmp/stock-mask-'+category+'-current']
  result=subprocess.run(argv,cwd=root,env=env,capture_output=True,text=True)
  Path('/tmp/stock-mask-preserved-'+category+'-report.json').write_text(result.stdout)
  assert result.returncode==0,(result.stdout,result.stderr)
  report=json.loads(result.stdout);assert report['state']=='passed' and report['head']==head and all(g['current_pass']for g in report['gates'])
  note(action='done',name=category,returncode=0,preserved_original_runner=True,report=str('/tmp/stock-mask-preserved-'+category+'-report.json'))
 finally:terminate_coordinator(213557,coordinators[213557])
 categories=['integration','retained-integration','wide-integration']
 for name in categories[categories.index(category)+1:]+['retention']:run_category(name,'0-7')

def author_lane():
 for name in ['axioms','owned','full','examples']:run_category(name,'8-15')

errors=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:
 jobs={pool.submit(fn):name for fn,name in [(consumer_lane,'consumer'),(author_lane,'author')]}
 for future in concurrent.futures.as_completed(jobs):
  try:future.result()
  except BaseException as error:
   errors.append((jobs[future],repr(error)));note(action='lane_failed_healthy_other_lane_preserved',lane=jobs[future],error=repr(error))
if errors:
 state='failed';note(action='terminal',errors=errors);raise SystemExit(1)
state='all_queued_gates_passed_review_still_required';note(action=state)
with Path('/tmp/stock-mask-parallel-final.log').open('w')as stream:
 result=subprocess.run(['python3','/tmp/stock-mask-parallel-final.py'],cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT)
note(action='post_validation_terminal',returncode=result.returncode);raise SystemExit(result.returncode)
