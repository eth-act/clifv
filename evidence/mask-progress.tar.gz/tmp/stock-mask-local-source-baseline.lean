import FV.Backend.Proof.StockLocalTrapRefines
#print axioms Backend.Stock.Proof.LocalBody.actual_local_source_step
#print axioms Backend.Stock.Proof.LocalBody.actual_local_source_execution_frame
#print axioms Backend.Stock.Proof.LocalBody.LocalInst.of_pure
#print axioms Backend.Stock.Proof.LocalBody.local_outcome
#print axioms Backend.Stock.Proof.LocalBody.actual_local_source_trap
#print axioms Backend.Stock.Proof.LocalBody.actual_local_source_trap_execution
#print axioms Backend.Stock.Proof.LocalBody.actual_local_entry_trap_refines_frame
