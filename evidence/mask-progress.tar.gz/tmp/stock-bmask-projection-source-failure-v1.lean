import FV.Backend.Proof.StockPureHelperTransport
import FV.Backend.Proof.StockBmaskHelper

namespace Backend.Stock.Proof.ScalarMask
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
attribute [local irreducible] Isle.Aarch64.program

/-- The pure children of `lower_bmask`. The outer recursive helper and
`with_flags_reg` need their own input-sensitive proofs. -/
def pureChildIds : List Nat :=
  [175,201,235,305,356,360,391,428,502,1791,1802,1822,1823,1852,1966,1972,2028,2029]

section Certificate
attribute [local semireducible] Isle.Aarch64.program
private theorem children_checked :
    pureChildIds.all (PureHelper.checkTerm program pureChildIds) = true := by
  decide +kernel
end Certificate

/-- Project an actual successful pure child call and retain every scheduling
field. This includes operand-size, CMP, CSETM and logical-immediate helpers. -/
theorem stock_mask_child {p : Program} (hp : Data p) (ctx : Ctx) {cfg : Config}
    (hc : cfg.checkOverlap = false) {fuel ty t : Nat} (member : t ∈ pureChildIds)
    (args : List V) {st next : State} {before trace : Array RuleId} {out : V}
    (run : ApplyInternal p (Stock.sem ctx) cfg fuel ty t args
      (st,before) out (next,trace)) :
    ApplyInternal p (Backend.sem ctx) cfg fuel ty t args
      (st.base,before) out (next.base,trace) ∧ next = {st with base := next.base} := by
  cases hp
  have projected := PureHelper.projects children_checked ctx hc (fuel+1) ty t member args st before
  unfold ApplyInternal at run ⊢
  rw [run] at projected
  exact ⟨projected.symm,PureHelper.preserves children_checked ctx hc member args run⟩

/-- The pure-child transport is inhabited by an actual CSETM execution, with a
genuine condition and allocation, rather than an assumed successful call. -/
theorem stock_mask_child_witness :
    ∃ out next trace,
      ApplyInternal program (Stock.sem sinkCtx) {} 999 49 428 [.data 96 1 []]
        (sinkState,#[]) out (next,trace) ∧
      ApplyInternal program (Backend.sem sinkCtx) {} 999 49 428 [.data 96 1 []]
        (sinkState.base,#[]) out (next.base,trace) ∧
      next = {sinkState with base := next.base} := by
  obtain ⟨out,next,trace,run,_⟩ := stock_csetm_helper_witness
  have actual : ApplyInternal program (Stock.sem sinkCtx) {} 999 49 428 [.data 96 1 []]
      (sinkState,#[]) out (next,trace) := run
  exact ⟨out,next,trace,actual,
    stock_mask_child data_program sinkCtx rfl (by decide) _ actual⟩

end Backend.Stock.Proof.ScalarMask
