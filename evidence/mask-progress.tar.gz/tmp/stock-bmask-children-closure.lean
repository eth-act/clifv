import FV.Backend.Proof.StockBmaskHelper
import FV.Backend.Proof.IselScopedProjection
open Backend Isle Isle.Interp Isle.Aarch64
private def calls (r : Rule) : List Nat := r.iflets.flatMap (fun il => exprCalls il.rhs) ++ exprCalls r.rhs
private def collect : Nat → List Nat → List Nat → List Nat
  | 0,seen,_ => seen
  | _+1,seen,[] => seen
  | n+1,seen,t::todo => if seen.contains t then collect n seen todo
      else collect n (t::seen) ((program.rulesOf t).flatMap calls ++ todo)
#eval (255, (collect 10000 [] [255]).mergeSort (· ≤ ·))
#eval (305, (collect 10000 [] [305]).mergeSort (· ≤ ·))
#eval (428, (collect 10000 [] [428]).mergeSort (· ≤ ·))
#eval (502, (collect 10000 [] [502]).mergeSort (· ≤ ·))
