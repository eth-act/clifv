from pathlib import Path
import json,subprocess,hashlib,os,time,datetime
root=Path('/home/lee/clifv/.worktrees/stock-mixed-div-20261022');out=Path('/tmp/stock-mask-real-crate-parity');path=out/'provenance.json'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def proc_start(pid):
 try:
  d=Path(f'/proc/{pid}/stat').read_text().split(') ',1)[1].split();return d[19]if d[0]not in ('Z','X')else None
 except FileNotFoundError:return None
r=json.load(path.open())
while r['state']=='running' and proc_start(r['pid'])==r['process_start']:
 time.sleep(5);r=json.load(path.open())
assert r['state']=='passed',r.get('state')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert head==r['source_head']=='0aecff7cbeb8e0dc295855bf27d77c4ffdfffdfa'
assert r['paired_cgu_objects']==30 and r['default_allocator']=='lean'
assert r['tool_sha256']==sha(root/'scripts/stock-crate-parity.py')
assert r['wrapper_sha256']==sha('/tmp/stock-general-div-real-crate-parity.py')
e=json.load(open('/tmp/stock-mixed-div-env.json'));assert r['llvm_mc_sha256']==sha(e['LLVM_MC'])
assert r['lean_backend_sha256']==sha(root/'.lake/build/bin/lean-backend')
assert all(sha(p)==digest for p,digest in r['inputs'].items())
assert r['report_sha256']==sha(out/'report.json')and r['summary_sha256']==sha(out/'summary.json')
summary=json.load((out/'summary.json').open());rows=json.load((out/'report.json').open());assert summary['source_head']==head and summary['total_symbol_comparisons']==len(rows)and summary['equal_symbol_comparisons']==sum(bool(row['equal'])for row in rows)
receipt={'state':'passed','source_head':head,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'current_source_earlier_parallel_check_reused_with_all_input_and_output_hashes_exact':True,'producer_provenance_sha256':sha(path),'summary':summary,'full_140_complete':False}
(out/'reuse.json').write_text(json.dumps(receipt,indent=2)+'\n');print('CURRENT_SOURCE_FRESH_CRATE_INPUTS_TOOLS_BINARY_AND_REPORT_EXACT',summary['equal_symbol_comparisons'],len(rows))
