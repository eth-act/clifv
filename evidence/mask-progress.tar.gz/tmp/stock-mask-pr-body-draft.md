Enable the proved Stock driver for single-block functions containing `bmask` and `nop`, interleaved with the previously supported scalar and division operations. Input and output widths vary independently across i8/i16/i32/i64. The ordinary compiler, checker, linker and generated-proof paths share the existing route and retain legacy fallback.

The proofs derive actual retained records, result binding and guarded original-source execution from the original input conditions. CSETM preserves ABI reads and flags; omitted nop and unused bmask are handled by the actual scan. Existing theorem variants, input conditions and prior production classes remain.

Validation is still running on pushed 0aecff7c. Replace this paragraph with terminal source-bound author-gate evidence before opening the PR. Targeted normal closures and the 56-report audit passed; one bundled MCP review passed for the 22 new production roots. All 65 prior theorem headers in modified modules are retained. Full normal, native bytes/ordinary CLI, current and retained consumers, exact old axioms, runtime/encoder/identities/stages and verified examples must finish before landing.

This extends production coverage for #140. General CFG, memory/effects, calls/unwind and whole-driver completeness remain open; fallback and finite fixtures do not establish completion.
