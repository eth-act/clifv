import Lean
import FV.Backend.Proof.StockBmaskScanRefines
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let mut count : Nat := 0
  for (name,_) in env.constants.toList do
    let some i := env.getModuleIdxFor? name | continue
    unless env.header.moduleNames[i]!.toString == "FV.Backend.Proof.StockBmaskScanRefines" do continue
    for ax in ← collectAxioms name do
      if #[``propext,``Classical.choice,``Quot.sound].contains ax then continue
      throwError "disallowed owned axiom {ax} in {name}"
    count := count+1
  unless count > 0 do throwError "empty owned partition"
  logInfo m!"STOCK_MASK_OWNED_PASS {count}"
