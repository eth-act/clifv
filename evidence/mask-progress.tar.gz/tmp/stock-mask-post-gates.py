from pathlib import Path
import json,subprocess,hashlib,re,datetime,os,sys
root=Path('/home/lee/clifv/.worktrees/stock-mixed-div-20261022');head='0aecff7cbeb8e0dc295855bf27d77c4ffdfffdfa'
env=os.environ.copy();env.update(json.load(open('/tmp/stock-mixed-div-env.json')));env.update(FV_MEMCAP='4G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head
jobs=[('old-production-axioms',['python3','/tmp/stock-general-div-axiom-parity.py','/tmp/stock-mask-axioms-current/audits','/tmp/stock-mask-old-axiom-parity.json']),('old-sink-axioms',['python3','/tmp/stock-div-source-axiom-parity.py','/tmp/stock-mask-axioms-current/audits/stock-no-load-sink.log','/tmp/stock-mask-old-sink-axiom-parity.json']),('headers-native-grids',['python3','/tmp/stock-mask-compatibility.py'])]
for name,args in jobs:
 with Path('/tmp/stock-mask-post-'+name+'.log').open('w') as f:r=subprocess.run(args,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 assert r.returncode==0,(name,r.returncode)
if '--axioms-only' in sys.argv:
 print('NARROW_OLD_AXIOM_HEADER_AND_NATIVE_GRID_PARITY_PASSED');raise SystemExit(0)
# Preserve the original identities, the prior returned-division cohort and the
# immediately preceding general-division delivery, including ordered stages.
result={}
for mode in ['e2e','legacy-e2e']:
 paths={'original':Path('/tmp/legacy-dead-cleanup-final-'+mode+'-identities.json'),'prior':Path('/tmp/stock-returned-div-full-author/'+mode+'-identities.json'),'parent':Path('/tmp/stock-narrow-full-current/'+mode+'-identities.json'),'current':Path('/tmp/stock-mask-full-current/'+mode+'-identities.json')}
 data={k:json.loads(p.read_text()) for k,p in paths.items()}
 def records(d):
  pairs={(v['file'],v['function'],v['index']):v['stages'] for v in d['functions']};assert len(pairs)==len(d['functions']);return pairs
 maps={k:records(d) for k,d in data.items()};assert len(maps['original'])==1150 and len(maps['prior'])==1159 and len(maps['parent'])==1159
 for label in ['original','prior','parent']:
  assert all(maps['current'].get(k)==v for k,v in maps[label].items()),(mode,label)
 result[mode]={'counts':{k:len(v) for k,v in maps.items()},'all_original_prior_and_parent_identities_and_ordered_stages_preserved':True,'files':{k:{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for k,p in paths.items()}}
Path('/tmp/stock-mask-identity-stage-parity.json').write_text(json.dumps(result,indent=2)+'\n')
print('NARROW_OLD_AXIOM_HEADER_NATIVE_GRID_AND_IDENTITY_STAGE_PARITY_PASSED')
