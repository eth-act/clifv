Stock preparation needs a proof that its emitted terminators and indexed edges describe the same graph. This PR derives that correspondence from successful Stock lowering under the original source scope, then proves raw and checked preparation success without a caller-supplied graph certificate.

It also carries argument/parameter shape through preparation and connects actual spill-copy execution, with complete source, CFG, branch/return/TryCall and pipeline witnesses. It preserves existing theorem variants and production defaults. Whole-driver source simulation/completeness and production integration remain open in #140.

Depends on #246; review against that branch. This is a substantive, dependency-closed backlog unit: 83 Lean proof/witness modules, with the full 784-module proposed-tree import closure checked. Created from the remote recovery snapshot without changing the active checkout or index and without creating a worktree/cache.

Validation: historical backlog-tree full gates passed, but do not establish this exact PR after upstream changes. Current canonical rebuild, exact proposed-tree local gates, trust review and CI are pending. Keep draft until required gates pass; squash merge only. Evidence: `docs/research/stock-cfg-preparation-delivery.md`.
