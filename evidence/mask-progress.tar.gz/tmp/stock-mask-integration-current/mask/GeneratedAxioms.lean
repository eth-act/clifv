import Crates.StockMaskProduction2CleanupFallbackGlobal
import Crates.StockMaskProduction2PlainFallbackGlobal
import Crates.StockMaskProduction2RetainedCleanupFallbackGlobal
import Crates.StockMaskProduction2RetainedPlainFallbackGlobal
import Crates.StockMaskProduction36CleanupFallbackEntries
import Crates.StockMaskProduction36CleanupFallbackGlobal
import Crates.StockMaskProduction36CleanupStrictEntries
import Crates.StockMaskProduction36CleanupStrictGlobal
import Crates.StockMaskProduction36PlainFallbackEntries
import Crates.StockMaskProduction36PlainFallbackGlobal
import Crates.StockMaskProduction36PlainStrictEntries
import Crates.StockMaskProduction36PlainStrictGlobal
import Crates.MaskProductionCLIcurrentPlain
import Crates.MaskProductionCLIretainedPlain
import Crates.MaskProductionCLIcurrentCleanup
import Crates.MaskProductionCLIretainedCleanup
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let generated := fun (name : Name) =>
    let owner := (privateToUserName? name).getD name
    owner.toString.startsWith "Crates.StockMaskProduction" || owner.toString.startsWith "Crates.MaskProductionCLI"
  let mut count : Nat := 0
  for (name, _) in env.constants.toList do
    unless generated name do continue
    for ax in ← collectAxioms name do
      if #[``propext, ``Classical.choice, ``Quot.sound].contains ax then continue
      unless generated ax && (ax.toString.splitOn "._native.native_decide.ax_").length > 1 do
        throwError "unexpected generated-proof axiom {ax} in {name}"
    count := count + 1
  unless count > 0 do throwError "empty generated-proof audit"
  logInfo m!"STOCK_MASKPRODUCTION_GENERATED_AXIOMS_PASS {count}"
