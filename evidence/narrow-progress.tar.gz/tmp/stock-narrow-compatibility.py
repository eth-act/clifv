from pathlib import Path
import subprocess,re,json,importlib.util,hashlib
base='439ca61b415274d16b549fe494eff96c9cdc8615'
root=Path('/home/lee/clifv/.worktrees/stock-mixed-div-20261022')
headers=lambda s:dict(re.findall(r'^theorem\s+(\w+)\s*([\s\S]*?):= by',s,re.M))
counts={}
for p in ['FV/Backend/Proof/StockScalarCheck.lean','FV/E2E/ABIReadScalar.lean','FV/E2E/SemanticNIBoundary.lean']:
 old=headers(subprocess.check_output(['git','show',base+':'+p],cwd=root,text=True));new=headers((root/p).read_text())
 assert old and old.keys()<=new.keys(),p
 for name,header in old.items():assert new[name]==header,(p,name)
 counts[p]=len(old)
def module(path,name):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
prior=Path('/tmp/stock-narrow-native-baseline.py');prior.write_bytes(subprocess.check_output(['git','show',base+':scripts/check-stock-mixed-native.py'],cwd=root))
a=module(prior,'prior');b=module(root/'scripts/check-stock-mixed-native.py','current')
profiles=['mixed','logical','scalar','not','mul','shift','cast','bit','popcount','minmax','cmp','highmul','div','mixeddiv','returneddiv','generaldiv']
case_counts={}
for width in (32,64):
 for profile in profiles:
  before=a.run_commands(width,profile);after=b.run_commands(width,profile);assert before==after,(width,profile)
  case_counts[f'{width}:{profile}']=len(after)
r={'state':'passed','base':base,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'old_public_headers_exact':counts,'old_native_profile_width_pairs_exact':len(case_counts),'case_counts':case_counts,'limits':'Header/vector parity only; exact old axiom sets, native/consumer and identity/stage gates separately required.'}
Path('/tmp/stock-narrow-compatibility.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r))
