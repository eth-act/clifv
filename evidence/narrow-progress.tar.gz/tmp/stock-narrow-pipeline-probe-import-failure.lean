import FV.E2E.StockNarrowFixtures
import FV.Backend.ScalarNIProduction
import FV.Backend.LinearScan

open Backend Backend.Proof Backend.Proof.Driver E2E.StockNarrowNIWitness
set_option autoImplicit false

def pipeline (f : Clif.Function) : Except String Unit := do
  unless Stock.Scalar.productionEligible f do throw "production classifier rejected"
  unless Stock.Scalar.sourceOk f do
    throw s!"source rejected: scope={lowerScopeB f} dominated={dominatedB f} abi={sigAbiOk f.sig}"
  let raw ← Stock.Scalar.lowerValidated f
  unless Stock.Scalar.check f raw && SemanticNI.check f raw do throw "paired source/ABI checks rejected"
  for cleanup in [false,true] do
    let vc ← prepare (Stock.Arithmetic.stage cleanup raw)
    unless prepCheck (Stock.Arithmetic.stage cleanup raw) vc do throw "prepare check rejected"
    let rf ← leanAlloc vc
    unless (checkAlloc vc rf).isOk do throw "allocation check rejected"
    let af ← lowerRFunc vc rf
    let fa ← emitFunc 0 af
    unless formsCoveredB ⟨fa.k,af.slotBase⟩ vc && fa.layout.isOk do throw "forms/layout rejected"

def main : IO Unit := do
  let mut failures := 0
  let mut passed := 0
  for ty in widths do
    for c in cases ty do
      let f := function .defaultI32 c
      match pipeline f with
      | .ok _ =>
        passed := passed+1
        IO.println s!"PASS {ty.width} {c.name}"
      | .error message =>
        failures := failures+1
        IO.println s!"FAIL {ty.width} {c.name}: {message}"
  IO.println s!"PIPELINE_DIAGNOSTIC passed={passed} failed={failures}"
