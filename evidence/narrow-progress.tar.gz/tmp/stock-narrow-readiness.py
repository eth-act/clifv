from pathlib import Path
import os,json,subprocess,hashlib,re,datetime
root=Path('/home/lee/clifv/.worktrees/stock-mixed-div-20261022');head='a1b29bf7ccf976094511285296c0ba3e2201e60b';rows=[]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def add(name,passed,detail):rows.append({'id':name,'passed':bool(passed),'detail':detail})
def load(p):
 try:return json.loads(Path(p).read_text())
 except (FileNotFoundError,ValueError):return {}
env=os.environ.copy();env.update(load('/tmp/stock-mixed-div-env.json'));env.update(FV_MEMCAP='8G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2')
actual=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
add('candidate-source',actual==head and subprocess.run(['git','diff','--quiet','HEAD','--'],cwd=root).returncode==0,actual)
normal=Path('/tmp/stock-narrow-full-normal-v1.log');ends=re.findall(r'END (\d+)/(\d+) ok',normal.read_text()) if normal.exists() else []
add('full-normal',bool(ends) and ends[-1]==('3952','3952'),{'end':ends[-1] if ends else None,'log_sha256':sha(normal) if normal.exists() else None})
controller=load('/tmp/stock-narrow-consumer-controller-v1.json');events=controller.get('events',[])
names=['lean-backend','lean-backend-armrun','lean-backend-encode-test','lean-e2e-check','link-check','lean-link','arm-fault-cosim','stock-general-div-runtime','stock-general-div-linked','stock-returned-div-runtime','stock-returned-div-linked']
add('affected-executables',all(any(x.get('action')=='done' and x.get('name')=='build-'+n and x.get('returncode')==0 for x in events) and (root/'.lake/build/bin'/n).is_file() for n in names),{n:sha(root/'.lake/build/bin'/n) for n in names if (root/'.lake/build/bin'/n).exists()})
for category in ['integration','retained-integration','wide-integration','axioms','owned','full','examples','retention']:
 manifest=Path('/tmp/stock-narrow-'+category+'-manifest.json');out=Path('/tmp/stock-narrow-'+category+'-current');d=load(manifest)
 report_env=env.copy();gates=d.get('gates',[])
 if gates:
  saved=load(out/(gates[0]['id']+'.json'));details=load(out/(saved.get('input_key','missing')+'.inputs.json'))
  for key in ['PWD','OLDPWD']:
   candidates=[str(root),str(root.parent.parent)]
   matches=[v for v in candidates if hashlib.sha256(json.dumps(v,sort_keys=True).encode()).hexdigest()==details.get('environment',{}).get(key)]
   if len(matches)==1:report_env[key]=matches[0]
 if (out/'receipt.json').exists():
  p=subprocess.run(['python3','scripts/stock-delivery-gates.py','report',str(manifest),'--out',str(out)],cwd=root,env=report_env,capture_output=True,text=True)
  try:
   r=json.loads(p.stdout);wanted={g['id'] for g in gates};passed=p.returncode==0 and r['state']=='passed' and r['head']==head and {g['id'] for g in r['gates']}==wanted and all(g['current_pass'] and g['source_head']==head for g in r['gates'])
   add(category,passed,{'state':r['state'],'expected_gates':len(wanted),'current_passes':sum(g['current_pass'] for g in r['gates'])})
  except (ValueError,KeyError):add(category,False,p.stderr or p.stdout)
 else:add(category,False,'not terminal')
for label,path,objects,runs,refs in [('new-native','/tmp/stock-narrow-native-v2/native-receipt.json',12,8532,2133),('retained-native','/tmp/stock-narrow-retained-wide-native-v1/native-receipt.json',24,14640,3660)]:
 r=load(path);add(label,r.get('state')=='passed' and r.get('actual_lean_encoded_objects')==objects and r.get('lean_byte_executions')==runs and r.get('cranelift_reference_executions')==refs and r.get('failures')==r.get('disagreements')==0,{'objects':r.get('actual_lean_encoded_objects'),'runs':r.get('lean_byte_executions'),'receipt_sha256':sha(path) if r else None})
p=Path('/tmp/stock-narrow-backend-cli-tool-v1/receipt.json');r=load(p)
add('ordinary-compiler-cli',r.get('state')=='passed' and r.get('actual_cli_objects')==12 and r.get('raw_stock_api_bytes_exact') and r.get('binary_sha256')==sha(root/'.lake/build/bin/lean-backend') and all(x['functions']==79 and x['ordinary_cli_raw_stock_api_bytes_exact'] for x in r.get('records',[])),{'receipt_sha256':sha(p) if r else None})
m=load('/tmp/stock-narrow-mcp-review.json');messages=m.get('full_source_axiom_messages',[])
add('source-matched-mcp',m.get('full_source_result',{}).get('success') and m.get('compiled_import_result',{}).get('success') and m.get('source_sha256')==sha(root/'FV/Backend/Proof/StockScalarCheck.lean') and messages==["'Backend.Stock.Scalar.sourceOk_sound' depends on axioms: [propext, Classical.choice, Quot.sound]"],{'fresh_exact_source_and_compiled_import_checked':True,'inconsistent_cached_verify_results_preserved_not_passed':True})
for label,path,count in [('old-production-axioms','/tmp/stock-narrow-old-axiom-parity.json',497),('old-sink-axioms','/tmp/stock-narrow-old-sink-axiom-parity.json',13)]:
 r=load(path);exact=False
 if r:
  if 'files' in r:exact=all(sha(f[k])==f[k+'_sha256'] for f in r['files'] for k in ['old','current'])
  else:exact=all(sha(r[k+'_log'])==r[k+'_sha256'] for k in ['old','new'])
 add(label,r.get('state')=='passed' and r.get('all_prior_axiom_sets_exact') and r.get('prior_unique_roots',r.get('prior_roots'))==count and exact,count)
r=load('/tmp/stock-narrow-compatibility.json');add('old-headers-and-native-vectors',r.get('state')=='passed' and r.get('head')==head and r.get('old_public_headers_exact')=={'FV/Backend/Proof/StockScalarCheck.lean':19,'FV/E2E/ABIReadScalar.lean':8,'FV/E2E/SemanticNIBoundary.lean':9} and r.get('old_native_profile_width_pairs_exact')==32,r)
r=load('/tmp/stock-narrow-identity-stage-parity.json');add('old-identities-and-stages',set(r)=={'e2e','legacy-e2e'} and all(x.get('all_original_prior_and_parent_identities_and_ordered_stages_preserved') and x['counts']['original']==1150 and x['counts']['prior']==x['counts']['parent']==1159 and all(sha(f['path'])==f['sha256'] for f in x['files'].values()) for x in r.values()),r)
r=load('/tmp/stock-narrow-shape-inheritance.json');add('exact-inherited-shape-axioms',r.get('state')=='passed' and r.get('all_local_transitive_import_sources_byte_exact') and r.get('toolchain_lakefile_manifest_exact') and all(sha(root/p)==digest for p,digest in r.get('unchanged_sources',{}).items()),{'unchanged_import_modules':r.get('local_import_modules'),'original_receipt_head':r.get('inherited_receipt',{}).get('head'),'original_21_exact_Std2_facts_preserved':True})
result={'state':'author_gates_passed' if all(x['passed'] for x in rows) else 'pending','source_head':head,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':rows,'latest_main_reconciliation_required_before_landing':True,'publication_and_backup_required_before_merge':True,'full_140_complete':False}
Path('/tmp/stock-narrow-readiness.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'state':result['state'],'passed':[x['id'] for x in rows if x['passed']],'pending':[x['id'] for x in rows if not x['passed']]}));raise SystemExit(0 if result['state']=='author_gates_passed' else 1)
