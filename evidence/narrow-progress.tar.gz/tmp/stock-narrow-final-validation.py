from pathlib import Path
import os,json,subprocess,time,datetime,hashlib,collections
root=Path('/home/lee/clifv/.worktrees/stock-mixed-div-20261022');head='a1b29bf7ccf976094511285296c0ba3e2201e60b'
env=os.environ.copy();env.update(json.load(open('/tmp/stock-mixed-div-env.json')));env.update(FV_MEMCAP='4G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2')
def proc_start(pid):
 try:return Path(f'/proc/{pid}/stat').read_text().split(') ',1)[1].split()[19]
 except FileNotFoundError:return None
pid=5554;start=proc_start(pid)
while start is not None and proc_start(pid)==start:time.sleep(10)
state=json.load(open('/tmp/stock-narrow-consumer-controller-v1.json'));assert state['events'][-1]['action']=='all_queued_gates_passed_review_still_required',state['events'][-1]
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head
for label,args in [('parity',['python3','/tmp/stock-narrow-post-gates.py']),('readiness',['python3','/tmp/stock-narrow-readiness.py'])]:
 with Path('/tmp/stock-narrow-final-'+label+'.log').open('w') as f:r=subprocess.run(args,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 assert r.returncode==0,(label,r.returncode)
out=Path('/tmp/stock-narrow-real-crate-parity');out.mkdir(exist_ok=False)
roots=[root/'examples'/name/'target/fv/plain-leanlink-verified-leanld/tmp' for name in ['fv-demo','survey']]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
inputs={};owners={}
for name,directory in zip(['fv-demo','survey'],roots):
 for stock in sorted(directory.rglob('cgclif.o')):
  lean=stock.with_name('lean.o')
  if not lean.exists():continue
  cgu=stock.parent.name;assert cgu not in owners;owners[cgu]=name
  for p in [stock,lean]:inputs[str(p)]=sha(p)
assert len(owners)==30,len(owners)
provenance={'source_head':head,'default_allocator':'lean','tool_sha256':sha(root/'scripts/stock-crate-parity.py'),'wrapper_sha256':sha('/tmp/stock-general-div-real-crate-parity.py'),'llvm_mc_sha256':sha(env['LLVM_MC']),'paired_cgu_objects':len(owners),'inputs':inputs,'state':'running'}
(out/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
with (out/'stdout.log').open('w') as f:r=subprocess.run(['scripts/memcap.sh','taskset','-c','8-11','python3','/tmp/stock-general-div-real-crate-parity.py','--json',str(out/'report.json'),'--diffs',str(out/'diffs'),*[str(p) for p in roots]],cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
assert r.returncode==0,r.returncode
assert all(sha(p)==digest for p,digest in inputs.items()),'objects changed during comparison'
rows=json.load((out/'report.json').open());assert isinstance(rows,list) and rows
by_crate={name:{'symbol_comparisons':0,'equal':0,'differ':0} for name in ['fv-demo','survey']}
causes=collections.Counter()
for row in rows:
 name=owners[row['cgu']];by_crate[name]['symbol_comparisons']+=1;by_crate[name]['equal' if row['equal'] else 'differ']+=1;causes.update(row.get('causes',{}))
summary={'source_head':head,'default_allocator':'lean','scope':'Exact byte/relocation symbol comparisons; heuristic causes, not unique function coverage or goal-completion percentage','total_symbol_comparisons':len(rows),'equal_symbol_comparisons':sum(bool(row['equal']) for row in rows),'by_crate':by_crate,'heuristic_instruction_causes':dict(causes)}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');provenance.update(state='passed',report_sha256=sha(out/'report.json'),summary_sha256=sha(out/'summary.json'));(out/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='heuristic_instruction_causes'}),flush=True)
