import Crates.StockReturnedDivProduction2CleanupFallbackGlobal
import Crates.StockReturnedDivProduction2PlainFallbackGlobal
import Crates.StockReturnedDivProduction2RetainedCleanupFallbackGlobal
import Crates.StockReturnedDivProduction2RetainedPlainFallbackGlobal
import Crates.StockReturnedDivProduction33CleanupFallbackEntries
import Crates.StockReturnedDivProduction33CleanupFallbackGlobal
import Crates.StockReturnedDivProduction6CleanupFallbackGlobal
import Crates.StockReturnedDivProduction6CleanupStrictGlobal
import Crates.StockReturnedDivProduction6MixedCleanupFallbackGlobal
import Crates.StockReturnedDivProduction6MixedPlainFallbackGlobal
import Crates.StockReturnedDivProduction6PlainFallbackGlobal
import Crates.StockReturnedDivProduction6PlainStrictGlobal
import Crates.ReturnedDivProductionCLIcurrentPlain
import Crates.ReturnedDivProductionCLIretainedPlain
import Crates.ReturnedDivProductionCLIcurrentCleanup
import Crates.ReturnedDivProductionCLIretainedCleanup
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let generated := fun (name : Name) =>
    let owner := (privateToUserName? name).getD name
    owner.toString.startsWith "Crates.StockReturnedDivProduction" || owner.toString.startsWith "Crates.ReturnedDivProductionCLI"
  let mut count : Nat := 0
  for (name, _) in env.constants.toList do
    unless generated name do continue
    for ax in ← collectAxioms name do
      if #[``propext, ``Classical.choice, ``Quot.sound].contains ax then continue
      unless generated ax && (ax.toString.splitOn "._native.native_decide.ax_").length > 1 do
        throwError "unexpected generated-proof axiom {ax} in {name}"
    count := count + 1
  unless count > 0 do throwError "empty generated-proof audit"
  logInfo m!"STOCK_RETURNEDDIVPRODUCTION_GENERATED_AXIOMS_PASS {count}"
