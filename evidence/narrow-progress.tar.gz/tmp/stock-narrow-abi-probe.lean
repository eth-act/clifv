import FV.E2E.StockNarrowFixtures
import FV.Backend.ScalarNIProduction
open Backend E2E.StockNarrowNIWitness

def main : IO Unit := do
  for ty in widths do
    for c in cases ty do
      let f := function .defaultI32 c
      if let .ok result := Stock.lower f then
        let raw := result.code
        unless ABIReadScalar.check f.sig raw || ABIReadDiv.check f.sig raw do
          for (b,bi) in raw.blocks.toList.zipIdx do
            for (i,pc) in b.insts.toList.zipIdx do
              unless ABIReadScalar.instruction f.sig bi pc i do
                IO.println s!"{ty.width} {c.name}: {repr i}"
