import FV.E2E.StockNarrowWitness
#print axioms E2E.StockNarrowNIWitness.bswap8_original_scope
#print axioms E2E.StockNarrowNIWitness.checks_true
#print axioms E2E.StockNarrowNIWitness.compiled_of_checks
#print axioms E2E.StockNarrowNIWitness.compiled_exists
#print axioms E2E.StockNarrowNIWitness.compiled_mixed_exists
#print axioms E2E.StockNarrowNIWitness.source_outcomes
#print axioms E2E.StockNarrowNIWitness.source_return
#print axioms E2E.StockNarrowNIWitness.division_zero
#print axioms E2E.StockNarrowNIWitness.division_overflow
#print axioms E2E.StockNarrowNIWitness.source_entry
#print axioms E2E.StockNarrowNIWitness.mixed_source_entry
