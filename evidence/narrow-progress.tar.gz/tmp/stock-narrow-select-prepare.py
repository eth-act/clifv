from pathlib import Path
import re,json,hashlib,datetime
r=Path('/home/lee/clifv/.worktrees/driver-proof-resume');research=r/'docs/research';prior=json.loads((research/'stock-minmax-narrow-integrated-checkpoint.json').read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
modules=['StockSelectZeroObserved','StockSelectZeroSourceValues','StockSelectZeroSourceWitness','StockSelectRootCalls','StockSelectOriginalSourceMatch','StockOriginalSelectFixture','StockSelectOriginalRootWitness'];roots=[];sources={};scans={};ns={}
exec(Path('/home/cody/.cache/uv/archive-v0/txMZz4UJwvitBV53gFJ1J/lib/python3.12/site-packages/lean_lsp_mcp/verify.py').read_text().replace('from orjson import loads as _json_loads','from json import loads as _json_loads'),ns)
for m in modules:
 p=r/('FV/Backend/Proof/'+m+'.lean');s=p.read_text();sources[str(p.relative_to(r))]=sha(p);assert not re.search(r'\b(sorry|admit|axiom|native_decide|bv_decide|unsafe|trace_state)\b',s),m
 scans[m]=ns['scan_warnings'](p);assert not scans[m],scans[m]
 namespace=re.search(r'^namespace (\S+)',s,re.M)[1];roots.extend(namespace+'.'+name for name in re.findall(r'^theorem\s+(\w+)',s,re.M))
assert len(sources)==7 and len(roots)==9,(len(sources),len(roots))
imports=''.join('import FV.Backend.Proof.'+m+'\n' for m in modules);prints=''.join('#print axioms '+x+'\n' for x in roots)
(research/'stock-original-select-progress-axioms.lean').write_text(imports+prints)
(research/'stock-narrow-select-all-axioms.lean').write_text(imports+(research/'stock-minmax-narrow-integrated-all-axioms.lean').read_text()+'\n'+prints)
prior['sources'].update(sources);prior['roots'].extend(roots);prior['source_scan_warnings'].update(scans);prior['scope']+=' Original select root2267 source/selection/real calls and complete original-driver root witness; actual Zero/NotZero659 consumer source values and witnesses. Original650 truth/full select source transfer still pending.'
prior['select_added_roots']=roots;prior['select_added_sources']=sources;prior['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();prior['remaining'].insert(0,'Compose original650/651 truth for every condition width, icmp/uextend look-through, actual select retained result binding/availability and original source-step semantics with complete all-form witnesses. Current original-driver witness establishes root/calls/binding, not select source-step execution.')
(research/'stock-narrow-select-checkpoint.json').write_text(json.dumps(prior,indent=2)+'\n');print('Prepared22 modules,25 new roots;1504-root combined audit,463 prior source hashes.')
