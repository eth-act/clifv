from pathlib import Path
import os,json,subprocess,hashlib,datetime
root=Path('/home/lee/clifv/.worktrees/stock-mixed-div-20261022');old='a1b29bf7ccf976094511285296c0ba3e2201e60b';head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();expected={'docs/plans/stock-driver-incremental-delivery.md','docs/research/stock-driver-obligations.json','docs/research/stock-narrow-production-activation.md','scripts/audit/stock-narrow-production.lean','scripts/check-stock-api-backend-cli.py'}
changed=set(subprocess.check_output(['git','diff','--name-only',old,head],cwd=root,text=True).splitlines());assert changed==expected,changed
baseline=json.load(open('/tmp/stock-narrow-readiness-a1.json'));assert baseline['state']=='author_gates_passed' and baseline['source_head']==old and len(baseline['checks'])==20 and all(x['passed'] for x in baseline['checks'])
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
binaries=next(x['detail'] for x in baseline['checks'] if x['id']=='affected-executables');assert all(sha(root/'.lake/build/bin'/n)==v for n,v in binaries.items())
assert (root/'scripts/audit/stock-narrow-production.lean').read_bytes()==Path('/tmp/stock-narrow-public-audit.lean').read_bytes()
assert (root/'scripts/check-stock-api-backend-cli.py').read_bytes()==Path('/tmp/stock-narrow-backend-cli-tool.py').read_bytes()
env=os.environ.copy();env.update(json.load(open('/tmp/stock-mixed-div-env.json')));env.update(FV_MEMCAP='8G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2')
records=[]
def run(label,args):
 log=Path('/tmp/stock-narrow-publication-'+label+'.log')
 with log.open('w') as f:r=subprocess.run(args,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 records.append({'id':label,'passed':r.returncode==0,'argv':args,'log':str(log),'sha256':sha(log)});assert r.returncode==0,(label,r.returncode)
run('normal',['taskset','-c','0-7','python3','scripts/lake-serial-build.py','--budget','8G','--max-jobs','1','--max-cap','8G','--out','/tmp/stock-narrow-publication-normal','FV','FVTest'])
assert 'END 3952/3952 ok, 0 built' in Path(records[-1]['log']).read_text()
run('new-audit',['scripts/memcap.sh','taskset','-c','0-3','python3','scripts/axiom-audit.py','--log-dir','/tmp/stock-narrow-publication-audit','scripts/audit/stock-narrow-production.lean'])
run('ordinary-cli',['scripts/memcap.sh','taskset','-c','0-3','python3','scripts/check-stock-api-backend-cli.py','/tmp/stock-narrow-native-v2','--output','/tmp/stock-narrow-publication-cli'])
assert all(sha(root/'.lake/build/bin'/n)==v for n,v in binaries.items())
result={'state':'passed','publication_head':head,'validated_implementation':old,'changed_paths':sorted(changed),'all_existing_production_compiler_proof_consumer_sources_exact':True,'all_11_native_executable_hashes_exact':True,'published_audit_and_cli_utility_match_tested_sources':True,'records':records,'original_readiness_sha256':sha('/tmp/stock-narrow-readiness-a1.json'),'full_140_complete':False}
Path('/tmp/stock-narrow-publication-equivalence.json').write_text(json.dumps(result,indent=2)+'\n')
checks=[{'id':'original-20-author-gates','passed':True,'detail':{'source_head':old,'readiness_sha256':result['original_readiness_sha256']}},{'id':'publication-production-source-equivalence','passed':True,'detail':str(Path('/tmp/stock-narrow-publication-equivalence.json'))},*records]
Path('/tmp/stock-narrow-readiness.json').write_text(json.dumps({'state':'author_gates_passed','source_head':head,'validated_implementation':old,'checks':checks,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'original_receipt_heads_preserved':True,'full_140_complete':False},indent=2)+'\n')
print('PUBLICATION_REPLAY_SOURCE_BINARIES_AUDIT_AND_ORDINARY_CLI_PASSED',head,flush=True)
