from pathlib import Path
import os,json,subprocess,hashlib,datetime
root=Path('/home/lee/clifv/.worktrees/stock-mixed-div-20261022');source=Path('/tmp/stock-narrow-native-v2');out=Path('/tmp/stock-narrow-actual-backend-cli-v1');out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert head=='a1b29bf7ccf976094511285296c0ba3e2201e60b'
records=[];binary=root/'.lake/build/bin/lean-backend';binary_hash=sha(binary)
def receipt(state,**kw):
 (out/'receipt.json').write_text(json.dumps({'state':state,'head':head,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'binary_sha256':binary_hash,'script_sha256':sha(__file__),'records':records,**kw},indent=2)+'\n')
try:
 for original in sorted(source.glob('*.o')):
  stem=original.stem;allocator=stem.split('-',1)[0];cleanup=stem.endswith('-cleanup');clif=original.with_suffix('.clif');obj=out/(stem+'.o');table=out/(stem+'.json');log=out/(stem+'.log')
  args=[str(binary),str(clif),str(obj),'--traps',str(table),'--regalloc',allocator]
  if not cleanup:args.append('--no-dead-cleanup')
  receipt('running',phase=stem)
  with log.open('w') as f:r=subprocess.run(args,cwd=root,stdout=f,stderr=subprocess.STDOUT)
  assert r.returncode==0,(stem,r.returncode,log)
  text=log.read_text();assert 'unsupported:' not in text and 'compiled, unverified' not in text,(stem,log)
  expected=json.loads(original.with_suffix('.json').read_text());observed=json.loads(table.read_text());assert len(observed['functions'])==79 and observed==expected,(stem,'table differs')
  assert obj.read_bytes()==original.read_bytes(),(stem,'actual default CLI object differs from checked raw-Stock API object')
  assert sha(binary)==binary_hash and subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head
  records.append({'stem':stem,'argv':args,'actual_default_cli':True,'raw_stock_api_object_byte_exact':True,'functions':79,'source_sha256':sha(clif),'object_sha256':sha(obj),'table_sha256':sha(table),'log_sha256':sha(log)})
  print('DEFAULT_BACKEND_RAW_STOCK_BYTES_EXACT',stem,flush=True)
 assert len(records)==12
 receipt('passed',actual_cli_objects=12,functions_per_object=79,raw_stock_api_bytes_exact=True,limits='Original no-opt/no-TryCall unit eligibility; mixed-TryCall and optimized production adapters remain required for full140.')
except BaseException as error:
 receipt('failed',error=repr(error));raise
