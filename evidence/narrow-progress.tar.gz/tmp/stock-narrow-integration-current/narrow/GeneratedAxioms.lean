import Crates.StockNarrowProduction2CleanupFallbackGlobal
import Crates.StockNarrowProduction2PlainFallbackGlobal
import Crates.StockNarrowProduction2RetainedCleanupFallbackGlobal
import Crates.StockNarrowProduction2RetainedPlainFallbackGlobal
import Crates.StockNarrowProduction79CleanupFallbackEntries
import Crates.StockNarrowProduction79CleanupFallbackGlobal
import Crates.StockNarrowProduction79CleanupStrictEntries
import Crates.StockNarrowProduction79CleanupStrictGlobal
import Crates.StockNarrowProduction79PlainFallbackEntries
import Crates.StockNarrowProduction79PlainFallbackGlobal
import Crates.StockNarrowProduction79PlainStrictEntries
import Crates.StockNarrowProduction79PlainStrictGlobal
import Crates.NarrowProductionCLIcurrentPlain
import Crates.NarrowProductionCLIretainedPlain
import Crates.NarrowProductionCLIcurrentCleanup
import Crates.NarrowProductionCLIretainedCleanup
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let generated := fun (name : Name) =>
    let owner := (privateToUserName? name).getD name
    owner.toString.startsWith "Crates.StockNarrowProduction" || owner.toString.startsWith "Crates.NarrowProductionCLI"
  let mut count : Nat := 0
  for (name, _) in env.constants.toList do
    unless generated name do continue
    for ax in ← collectAxioms name do
      if #[``propext, ``Classical.choice, ``Quot.sound].contains ax then continue
      unless generated ax && (ax.toString.splitOn "._native.native_decide.ax_").length > 1 do
        throwError "unexpected generated-proof axiom {ax} in {name}"
    count := count + 1
  unless count > 0 do throwError "empty generated-proof audit"
  logInfo m!"STOCK_NARROWPRODUCTION_GENERATED_AXIOMS_PASS {count}"
