import FV.Backend.Proof.StockScalarCheck
#print axioms Backend.Stock.Scalar.narrowBodyEligible_sound
#print axioms Backend.Stock.Scalar.domain_of_narrowEligible
#print axioms Backend.Stock.Scalar.sourceOk_sound
#print axioms Backend.Stock.Scalar.check_sound
