from pathlib import Path
import os,subprocess,json,hashlib,tarfile,datetime
root=Path('/home/lee/clifv/.worktrees/stock-mixed-div-20261022');paths=set()
for p in Path('/tmp').glob('stock-narrow-*'):
 if '-evidence-' in p.name:continue
 if p.is_file():paths.add(p)
 elif p.is_dir():paths.update(x for x in p.rglob('*') if x.is_file())
paths.update({Path('/tmp/stock-div-current-status.md'),Path('/tmp/stock-general-div-resume-20261023.md')})
paths={p for p in paths if p.suffix not in {'.gz','.tar','.ltar','.olean','.ilean','.pyc'} and '__pycache__' not in str(p)}
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');out=Path('/tmp/stock-narrow-progress-evidence-'+stamp);out.mkdir();snapshot=out/'snapshot';snapshot.mkdir();files={}
for p in sorted(paths):
 q=snapshot/str(p).lstrip('/');q.parent.mkdir(parents=True,exist_ok=True);data=p.read_bytes();q.write_bytes(data);files[str(p)]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();ready_path=Path('/tmp/stock-narrow-readiness.json');ready=json.loads(ready_path.read_text()) if ready_path.exists() else {};author_gates_passed=ready.get('state')=='author_gates_passed' and ready.get('source_head')==head and all(x['passed'] for x in ready.get('checks',[]));manifest={'state':'author_gate_snapshot_before_merge' if author_gates_passed else 'progress_snapshot_not_full_activation_validation','source_head':head,'utc':stamp,'component_pass_provenance':'Consult original source heads and input keys in individual archived receipts; snapshot source_head does not relabel earlier component passes.','consumer_full_gates_pending':not author_gates_passed,'author_gate_readiness':{'path':str(ready_path),'sha256':hashlib.sha256(ready_path.read_bytes()).hexdigest() if ready_path.exists() else None,'source_head':ready.get('source_head'),'state':ready.get('state')},'full_140_complete':False,'files':files};mp=out/'manifest.json';mp.write_text(json.dumps(manifest,indent=2)+'\n');archive=out/'progress.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=1) as t:
 for p in sorted(files):t.add(snapshot/p.lstrip('/'),arcname=p.lstrip('/'),recursive=False)
 t.add(mp,arcname='manifest.json')
assert archive.stat().st_size<80*1024*1024
with tarfile.open(archive) as t:
 for p,r in files.items():assert hashlib.sha256(t.extractfile(p.lstrip('/')).read()).hexdigest()==r['sha256']
def git(*args,**kw):return subprocess.check_output(['git',*args],cwd=root,**kw).decode().strip()
env=dict(os.environ,GIT_INDEX_FILE=str(out/'index'));git('read-tree',head,env=env);blob=git('hash-object','-w',str(archive));git('update-index','--add','--cacheinfo','100644',blob,'evidence/narrow-progress.tar.gz',env=env);tree=git('write-tree',env=env);commit=git('commit-tree',tree,'-p',head,input=b'Back up narrow scalar implementation and validation progress\n');branch='agent/stock-narrow-progress-'+stamp;git('update-ref','refs/heads/'+branch,commit);git('push','origin',commit+':refs/heads/'+branch);assert git('ls-remote','origin','refs/heads/'+branch).split()[0]==commit
r={'state':'remote_verified_progress_not_full_activation','source_head':head,'commit':commit,'branch':branch,'archive':str(archive),'bytes':archive.stat().st_size,'files':len(files),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()};Path('/tmp/stock-narrow-progress-backup.json').write_text(json.dumps(r,indent=2)+'\n');(out/'index').unlink()
import shutil
shutil.rmtree(snapshot);print(json.dumps(r))
