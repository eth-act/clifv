from pathlib import Path
import os, subprocess, json, datetime, re, tomllib, hashlib

b = Path('/home/lee/clifv')
r = b / '.worktrees/stock-cfg-source-20261025'
e = b / '.git/agent-evidence/stock-memory-20261029'
state = e / 'integer-production-gates-state-v1.json'
packet = json.loads((e / 'integer-production-source-v1.json').read_text())
records = []
env = dict(os.environ)
env.update(json.loads((e / 'author-env-v1.json').read_text()))
env.update(FV_ROOT=str(r), FV_MEMCAP='16G', OMP_NUM_THREADS='2',
           OMP_THREAD_LIMIT='2', LEAN_NUM_THREADS='2', CARGO_BUILD_JOBS='1')
for key in ['FV_PIPELINE_T', 'BLESS']:
    env.pop(key, None)

def save(status, **extra):
    state.write_text(json.dumps(dict(status=status, records=records,
        utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), **extra), indent=2)+'\n')

def run(label, args):
    save('running', phase=label)
    with (e / ('integer-production-'+label+'-v1.log')).open('w') as log:
        result = subprocess.run(['nice', '-n', '10', str(r/'scripts/memcap.sh'), *args],
            cwd=r, env=env, stdout=log, stderr=subprocess.STDOUT)
    records.append(dict(label=label, returncode=result.returncode))
    if result.returncode:
        raise RuntimeError((label, result.returncode))

def hashes():
    return {n:hashlib.sha256((r/n).read_bytes()).hexdigest() for n in packet['files']}

def axioms(path):
    return {n:set(x.strip() for x in a.split(',')) for n,a in
        re.findall(r"'([^']+)' depends on axioms: \[([^]]*)\]", path.read_text(), re.S)}

try:
    assert hashes() == packet['files'], 'Packet changed since the LSP checkpoint'
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r).decode().strip() == packet['base']
    deps = {}
    for folder in ['FV','FVTest','Corpus']:
        for p in (r/folder).rglob('*.lean'):
            deps[str(p.relative_to(r))[:-5].replace('/','.')] = set(re.findall(r'^import\s+(\S+)',p.read_text(),re.M))
    affected = {p[:-5].replace('/','.') for p in packet['files']
                if p.endswith('.lean') and not p.startswith('scripts/')}
    while True:
        more = affected | {m for m,imports in deps.items() if imports & affected}
        if more == affected:
            break
        affected = more
    roots = sorted(affected)
    config = tomllib.loads((r/'lakefile.toml').read_text())
    exes = [x['name'] for x in config['lean_exe'] if x.get('root',x['name']) in affected]
    (e/'integer-production-closure-v1.json').write_text(json.dumps(dict(roots=roots,executables=exes),indent=2)+'\n')
    run('reverse-build',['python3','scripts/lake-serial-build.py','--budget','16G',
        '--max-jobs','2','--max-cap','16G','--default-cap','8G',
        '--profile',str(r/'scripts/lake-module-peaks.tsv'),
        '--profile',str(r/'.lake/lake-module-peaks.tsv'),
        '--profile',str(e/'production-cold-overrides-v6.tsv'),
        '--out',str(e/'integer-production-modules-v1'),*roots])
    run('executables',['lake','build',*exes])
    run('audit',['lake','env','lean','scripts/audit/stock-memory-integer-production.lean'])
    current = axioms(e/'integer-production-audit-v1.log')
    assert len(current)==17 and all(a <= {'propext','Classical.choice','Quot.sound'} for a in current.values())
    for label,script,baseline,count in [
        ('old-memory','stock-memory-source.lean','author-normal-gates-v1/all-axioms/stock-memory-source.log',105),
        ('old-helpers','stock-memory-integer-forward.lean','integer-memory-integrated-audit-v1.log',12),
        ('old-roots','stock-memory-integer-roots.lean','integer-load-roots-audit-v2.log',5),
        ('old-records','stock-memory-integer-records.lean','integer-records-audit-v1.log',19)]:
        run(label,['lake','env','lean','scripts/audit/'+script])
        actual = axioms(e/('integer-production-'+label+'-v1.log'))
        assert len(actual)==count and actual==axioms(e/baseline), (label,'axiom drift')
    for test in ['test_lowering_trace.py','test_stock_configured_provider.py',
                 'test_stock_lowering_schedule.py','test_stock_compiler_compare.py',
                 'test_stock_pipeline.py','test_stock_exporter.py']:
        run(test,['python3','-m','unittest','discover','-s','scripts','-p',test,'-v'])
    for kind in ['parameter','conditional-forward','conditional','forward','linear','scalar-entry','entry','cfg']:
        run('retained-'+kind,[str(r/'.lake/build/bin/stock-memory-retained'),kind])
    for ty in ['i8','i16','i32','i64']:
        run('consumers-'+ty,['python3','scripts/check-stock-memory-integration.py',
            '--output',str(e/('integer-production-consumers-'+ty+'-v1')),'--load-type',ty])
    run('consumers-cfg32',['python3','scripts/check-stock-memory-integration.py',
        '--output',str(e/'integer-production-consumers-cfg32-v1'),'--memory-cfg'])
    assert hashes()==packet['files'], 'Packet changed during validation'
    save('passed',reverse_roots=len(roots),executables=exes,new_audit_roots=17,
         exact_old_axiom_sets=141,official_comparison='Pending separate original-input comparison')
except BaseException as error:
    save('failed',error=repr(error))
    raise
