from pathlib import Path
import subprocess,json,time,datetime,tarfile,hashlib,re,runpy,psutil
b=Path('/home/lee/clifv');e=b/'.git/agent-evidence/stock-memory-20261029';state=e/'integer-store-load-store-production-official-state-v1.json'
def save(status,**x):state.write_text(json.dumps(dict(status=status,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),full_goal_complete=False,**x),indent=2)+'\n')
def cmd(*a):return subprocess.check_output(a,cwd=b,text=True).strip()
try:
 save('waiting',phase='publication-after-local-gates')
 while True:
  pub=json.loads((e/'integer-store-load-store-production-publication-v1.json').read_text());assert pub['status']!='failed',pub
  if pub['status']=='passed':break
  process=psutil.Process(3072892)
  assert process.is_running() and process.status()!=psutil.STATUS_ZOMBIE and 'integer-store-load-store-publication-v1' in ' '.join(process.cmdline())
  time.sleep(10)
 required={'Quick checks','Build and compare','Check lost matches','Publish PR result'}
 while True:
  pr=json.loads(cmd('gh','pr','view',str(pub['pr']),'--repo','eth-act/clifv','--json','state,headRefOid,statusCheckRollup'))
  assert pr['state']=='OPEN' and pr['headRefOid']==pub['commit'],pr
  checks=pr['statusCheckRollup'];selected=[x for x in checks if x.get('name') in required]
  assert not any(x.get('status')=='COMPLETED' and x.get('conclusion') not in ['SUCCESS','SKIPPED','NEUTRAL'] for x in selected),selected
  if required<={x.get('name') for x in selected} and all(x.get('status')=='COMPLETED' for x in selected):break
  save('waiting',phase='four-current-CI-checks',pr=pub['pr'],head=pub['commit']);time.sleep(20)
 build=next(x for x in selected if x.get('name')=='Build and compare');assert build['conclusion']=='SUCCESS',build
 run=re.search(r'/actions/runs/([0-9]+)',build['detailsUrl']);assert run,build
 run_id=run[1];meta=json.loads(cmd('gh','api','repos/eth-act/clifv/actions/runs/'+run_id))
 attempt=meta['run_attempt'];assert meta['head_sha']==pub['commit'],meta['head_sha']
 save('running',phase='adopt-exact-current-CI-artifact',pr=pub['pr'],run_id=run_id,attempt=attempt)
 for name,directory in [('stock-comparison-summary-'+str(attempt),'stock-load-store-ci-summary-v1'),('stock-comparison-artifacts-'+str(attempt),'stock-load-store-ci-artifacts-v1')]:
  out=e/directory;out.mkdir(exist_ok=False);subprocess.run(['gh','run','download',run_id,'--repo','eth-act/clifv','--name',name,'--dir',str(out)],cwd=b,check=True)
 archives=list((e/'stock-load-store-ci-artifacts-v1').glob('*.tar.gz'));assert len(archives)==1,archives
 with tarfile.open(archives[0],'r:gz') as archive:
  matches=[m for m in archive.getmembers() if m.isfile() and (m.name=='results.json' or m.name.endswith('/results.json'))];assert len(matches)==1,matches
  data=archive.extractfile(matches[0]).read()
 report=e/'stock-load-store-ci-artifacts-v1/results.json';report.write_bytes(data)
 (e/'integer-store-load-store-ci-report-extraction-v1.json').write_text(json.dumps(dict(run_id=run_id,attempt=attempt,archive_sha256=hashlib.sha256(archives[0].read_bytes()).hexdigest(),member=matches[0].name,report_sha256=hashlib.sha256(data).hexdigest(),report_bytes=len(data)),indent=2)+'\n')
 runpy.run_path(str(e/'verify-integer-store-load-store-ci-official-v1.py'),run_name='__main__')
except BaseException as error:save('failed',error=repr(error));raise
