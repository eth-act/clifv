import FV.Clif.Run
set_option autoImplicit false
namespace MixedSourceOutcomeCheck
private def outcomeAgrees (ty : Clif.Ty) (wanted : Except Clif.TrapCode (BitVec ty.width))
    (actual : Clif.Outcome) : Bool :=
  match wanted,actual with
  | .error code,.trapped observed => code == observed
  | .ok bits,.returned vals _ => decide (vals = [⟨ty,bits⟩])
  | _,_ => false

private theorem outcomeAgrees_sound {ty : Clif.Ty}
    {wanted : Except Clif.TrapCode (BitVec ty.width)} {actual : Clif.Outcome}
    (checked : outcomeAgrees ty wanted actual = true) :
    match wanted with
    | .error code => actual = .trapped code
    | .ok bits => ∃ mem,actual = .returned [⟨ty,bits⟩] mem := by
  cases wanted with
  | error code =>
    cases actual with
    | trapped observed =>
      change (code == observed) = true at checked
      have equal : code = observed := beq_iff_eq.mp checked
      cases equal
      rfl
    | returned vals mem => change false = true at checked; cases checked
    | stuck message => change false = true at checked; cases checked
    | outOfFuel => change false = true at checked; cases checked
  | ok bits =>
    cases actual with
    | returned vals mem =>
      change decide (vals = [Clif.Val.mk ty bits]) = true at checked
      have equal : vals = [Clif.Val.mk ty bits] := of_decide_eq_true checked
      subst vals
      exact ⟨mem,rfl⟩
    | trapped code => change false = true at checked; cases checked
    | stuck message => change false = true at checked; cases checked
    | outOfFuel => change false = true at checked; cases checked


end MixedSourceOutcomeCheck
