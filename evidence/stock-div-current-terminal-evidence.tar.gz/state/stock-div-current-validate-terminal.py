from pathlib import Path
import json,subprocess,hashlib,re,datetime
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head=='b1ef0c67f455eecb643883a414904016bab65d8f'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
groups=['current-normal','current-native','current-integration','current-highmul-integration','current-retention','current-owned-retry','current-owned-keys-retry','current-example-tools','current-examples'];records=[]
for kind in groups+['current-full']:
 manifest=json.load(open('/tmp/stock-div-'+kind+'-manifest.json'));assert manifest['candidate']==head
 gates=manifest['gates'][:4] if kind=='current-full' else manifest['gates']
 out=Path('/tmp/stock-div-reconciled-'+kind+'-author')
 for g in gates:
  p=out/(g['id']+'.json');a=json.load(open(p));assert a['state']=='passed' and a['returncode']==0,(kind,g['id'],a['state']);assert a['source_head']==head
  assert sha(a['log'])==a['log_sha256'],a['log']
  for file,digest in a.get('outputs',{}).items():assert sha(file)==digest,file
  records.append({'group':kind,'gate':g['id'],'source_head':a['source_head'],'record':str(p),'record_sha256':sha(p),'log_sha256':a['log_sha256'],'outputs':len(a.get('outputs',{}))})
# Re-evaluate identity/stage preservation from the actual current reports.
identities={}
for mode in ['e2e','legacy-e2e']:
 current=Path('/tmp/stock-div-reconciled-current-full-author')/(mode+'-identities.json');d=json.load(open(current));now={(r['file'],r['function'],r['index']):r['stages'] for r in d['functions']};counts={}
 for name,path in [('original',Path('/tmp/legacy-dead-cleanup-final-'+mode+'-identities.json')),('prior',Path('/tmp/stock-highmul-final-full-author')/(mode+'-identities.json'))]:
  b=json.load(open(path));before={(r['file'],r['function'],r['index']):r['stages'] for r in b['functions']};assert all(now.get(k)==v for k,v in before.items()),(mode,name);counts[name]=len(before)
 identities[mode]={**counts,'current':len(now),'all_previous_identities_and_ordered_stages_preserved':True}
part=json.load(open('/tmp/stock-div-current-owned/partitions.json'));assert(len(part['core']),len(part['witnesses']),len(part['executable_owners']),len(part['exact_native_facts']))==(265,33,26,39)
owned=json.load(open('/tmp/stock-div-reconciled-current-owned-retry-author/owned-0.json'));s=Path(owned['log']).read_text();match=re.search(r'STOCK_DIV_OWNED_STANDARD_CORE (\d+); FIXED_WITNESSES (\d+)',s);assert match,s[-2000:]
native=json.load(open('/tmp/stock-div-reconciled-current-native-author/native/native-receipt.json'));assert native['state']=='passed' and native['failures']==0 and native['disagreements']==0
for path in ['/tmp/stock-div-current-main-header-parity.json','/tmp/stock-div-current-axiom-parity.json']:assert Path(path).exists()
headers=json.load(open('/tmp/stock-div-current-main-header-parity.json'));axioms=json.load(open('/tmp/stock-div-current-axiom-parity.json'));assert headers['unchanged'] and axioms['exact_required_axiom_sets_preserved']
failed=json.load(open('/tmp/stock-div-reconciled-current-full-author/verified-fv-demo.json'));assert failed['state']=='failed' and failed['returncode']!=0
assert 'clif-decode missing' in Path(failed['log']).read_text()
a={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':'passed','validated_code_head':head,'base':'5c1351a088eee97b38925a5266f5a6f4cbd19797','gate_records':records,'primary_gates':sum(x['group']!='current-owned-retry' for x in records),'ownership_gates':27,'library_key_scope':519,'current_scope':'134 reverse-dependent modules plus required changed imports;1607-module import closure. Current per-PR gates, not a fresh global library/crate sweep.','affected_audits':15,'current_audited_roots':axioms['current_roots'],'prior_affected_exact_axiom_sets':axioms['prior_roots_in_affected_audits'],'old_public_headers_exact':headers['old_public_headers'],'owned_core_constants':int(match[1]),'fixed_witness_constants':int(match[2]),'exact_allowed_native_facts':39,'identities':identities,'native':{k:v for k,v in native.items() if k!='records'},'preserved_failed_attempts':[failed['log'],'/tmp/stock-div-current-final-pr-build/FV.Backend.Proof.StockEdgeCode.log','/tmp/stock-div-current-final-pr-build/FV.Backend.Proof.StockPrepareInputs.log'],'example_prerequisite_failure':'First demo attempt lacked clif-decode. Both helpers rebuilt under source-bound gates; both verified examples then passed in current-examples. Original failed attempt retained.','historical_full_evidence':'Original complete normal/crate/full-audit/runtime/native/consumer gates remain at45aea1cd and15dc52fb/92ff5c0b, backedf3e6f6bc; never relabelled current.','full_140_complete':False,'next':'Land this complete trapping class, then stable outcome import boundary/mixed final division class/remaining full140 obligations. No stop after first class.'}
Path('/tmp/stock-div-current-terminal-validation.json').write_text(json.dumps(a,indent=2)+'\n');print('Actual required current author gates pass',a['primary_gates'],a['ownership_gates'],'core/witness constants',match[1],match[2]);print('Actual code',head,'full140 complete',a['full_140_complete'])
