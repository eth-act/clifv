from pathlib import Path
import re,json,subprocess
scope=json.load(open('/tmp/stock-div-current-pr-scope.json'));old_dir=Path('/tmp/stock-highmul-reconciled-audits');new_dir=Path('/tmp/stock-div-current-affected-audits')
def roots(files):
 result={}
 for p in files:
  s=p.read_text();
  for n,ax in re.findall(r"'(.+?)' depends on axioms: \[([^]]*)\]",s):result[n]=sorted(set(re.findall(r'[^\s,]+',ax)))
  for n in re.findall(r"'(.+?)' does not depend on any axioms",s):result[n]=[]
 return result
baseline=roots(old_dir.glob('*.log'));assert len(baseline)==1732
required_files=[old_dir/(Path(p).stem+'.log') for p in scope['affected_audits'] if (old_dir/(Path(p).stem+'.log')).exists()];required=roots(required_files);current=roots(new_dir.glob('*.log'));missing=sorted(set(required)-set(current));changed=[n for n in required if n in current and required[n]!=current[n]];assert not missing and not changed,(missing,changed)
a={'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'historical_baseline_roots':len(baseline),'current_affected_audit_files':len(scope['affected_audits']),'current_roots':len(current),'prior_roots_in_affected_audits':len(required),'exact_required_axiom_sets_preserved':True,'unrerun_unaffected_historical_roots':len(baseline)-len(required),'scope':'Fresh affected audit comparison only. Historical full1732-root evidence retains its original source; unrelated current-main interfaces are not attributed to this PR.'};Path('/tmp/stock-div-current-axiom-parity.json').write_text(json.dumps(a,indent=2)+'\n');print(a)
