from pathlib import Path
import os,json,subprocess,hashlib,datetime,tarfile,io
root=Path.cwd();head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();validation=json.load(open('/tmp/stock-div-current-terminal-validation.json'));assert validation['state']=='passed' and validation['validated_code_head']==head
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');out=Path('/tmp/stock-div-current-terminal-backup-'+stamp);out.mkdir();files={}
for directory in Path('/tmp').glob('stock-div-reconciled-current-*-author'):
 if directory.is_dir():
  for p in directory.rglob('*'):
   if p.is_file():files['author/'+directory.name+'/'+str(p.relative_to(directory))]=p
for pattern in ['stock-div-current-*.json','stock-div-current-*.py','stock-div-current-*.md','stock-div-current-*.txt','stock-div-current-*.log','stock-div-current-*.time','stock-div-release-mcp-review*.json','stock-div-release-mcp-review*.log','stock-div-next-*.json','stock-div-next-*.py','stock-div-next-*.lean','stock-div-next-*.log','stock-div-next-*.md']:
 for p in Path('/tmp').glob(pattern):
  if p.is_file():files['state/'+p.name]=p
for name in ['stock-div-current-owned','stock-div-current-owned-refresh','stock-div-current-owned-stale-refresh','stock-div-current-pr-build','stock-div-current-final-pr-build','stock-div-current-remaining-build','stock-div-next-staged','stock-div-next-lower-outcomes','stock-div-outcome-interface-check','stock-div-mixed-import-check']:
 directory=Path('/tmp')/name
 for p in directory.rglob('*'):
  if p.is_file():files['details/'+name+'/'+str(p.relative_to(directory))]=p
files['state/StockDivPacketReview.lean']=root/'.lake/StockDivPacketReview.lean'
manifest={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'validated_code_head':head,'full_140_complete':False,'files':{},'scope':'Current author gate receipts/logs/objects/generated proofs; failed attempts kept; next-class staged source explicitly unactivated; historical complete evidence remains in earlier independent archive.'}
archive=out/'stock-div-current-terminal-evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
 for name,p in sorted(files.items()):
  b=p.read_bytes();manifest['files'][name]={'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)};info=tarfile.TarInfo(name);info.size=len(b);info.mtime=0;tar.addfile(info,io.BytesIO(b))
 b=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode();info=tarfile.TarInfo('manifest.json');info.size=len(b);info.mtime=0;tar.addfile(info,io.BytesIO(b))
digest=hashlib.sha256(archive.read_bytes()).hexdigest();(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');assert archive.stat().st_size<90*1024**2,archive.stat().st_size
idx=out/'index';E=os.environ.copy();E['GIT_INDEX_FILE']=str(idx);subprocess.run(['git','read-tree',head],env=E,check=True)
for path,name in [(archive,'evidence/stock-div-current-terminal-evidence.tar.gz'),(out/'manifest.json','evidence/manifest.json')]:
 blob=subprocess.check_output(['git','hash-object','-w',str(path)],text=True).strip();subprocess.run(['git','update-index','--add','--cacheinfo','100644',blob,name],env=E,check=True)
tree=subprocess.check_output(['git','write-tree'],env=E,text=True).strip();commit=subprocess.check_output(['git','commit-tree',tree,'-p',head],input=b'Back up complete current Stock division author evidence and next-class saved work\n').decode().strip();branch='agent/stock-div-current-evidence-'+stamp;subprocess.run(['git','update-ref','refs/heads/'+branch,commit],check=True);subprocess.run(['git','push','origin',commit+':refs/heads/'+branch],check=True);remote=subprocess.check_output(['git','ls-remote','origin','refs/heads/'+branch],text=True).split()[0];assert remote==commit
receipt={'state':'remote_verified','validated_code_head':head,'backup_commit':commit,'backup_branch':branch,'archive_sha256':digest,'archive_bytes':archive.stat().st_size,'files':len(files),'archive':str(archive),'manifest':str(out/'manifest.json')};Path('/tmp/stock-div-current-terminal-backup.json').write_text(json.dumps(receipt,indent=2)+'\n');idx.unlink();print(json.dumps(receipt),flush=True)
