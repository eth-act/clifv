from pathlib import Path
import subprocess,json,os,datetime
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');e=Path('/home/lee/clifv/.git/agent-evidence/stock-memory-20261029');os.chdir(root)
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head==json.loads((e/'author-source-v1.json').read_text())['head']
state=e/'author-normal-state-v1.json'
def save(status,**extra):state.write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),head=head,status=status,**extra),indent=2)+'\n')
out=e/'author-normal-gates-v1';save('running')
with (e/'author-normal-runner-v1.log').open('w') as log:
 r=subprocess.run(['python3','scripts/stock-delivery-gates.py','resume' if out.exists() else 'run',str(e/'author-normal-manifest-v1.json'),'--root',str(root),'--out',str(out)],stdout=log,stderr=subprocess.STDOUT)
save('passed' if r.returncode==0 else 'failed',returncode=r.returncode,scope='normal/libraries/tools/full axiom audit; runtime/link/consumer gates follow separately')
raise SystemExit(r.returncode)
