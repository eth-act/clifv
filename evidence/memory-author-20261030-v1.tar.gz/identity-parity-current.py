from pathlib import Path
import json,sys,hashlib
out=Path(sys.argv[1]);base=Path('/home/lee/clifv/.git/agent-evidence/stock-memory-20261029/historical/stock-memory-production-full-gates-v1');reports=[]
for name in ['e2e-identities.json','legacy-e2e-identities.json']:
 def indexed(path):
  data=json.loads(path.read_text());assert data['schema']==1
  rows={(r['file'],r['index'],r['function']):r['stages'] for r in data['functions']};assert len(rows)==len(data['functions']);return rows
 prior=indexed(base/name);now=indexed(out/name);assert len(prior)==1159
 missing=sorted(set(prior)-set(now));changed={str(k):[stages,now[k]] for k,stages in prior.items() if k in now and stages!=now[k]}
 assert not missing and not changed,(name,missing,changed)
 reports.append(dict(mode=name,prior=len(prior),current=len(now),retained=len(prior),new=len(set(now)-set(prior)),old_stages_exact=True,baseline_sha256=hashlib.sha256((base/name).read_bytes()).hexdigest()))
(out/'identity-stage-parity.json').write_text(json.dumps(dict(state='passed',reports=reports),indent=2)+'\n');print('IDENTITY_STAGE_PARITY_PASS')
