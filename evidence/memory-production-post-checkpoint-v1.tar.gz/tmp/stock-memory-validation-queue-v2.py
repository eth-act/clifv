from pathlib import Path
import concurrent.futures,datetime,json,os,queue,subprocess,threading
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');os.chdir(root)
head='3753d98a71709cf940ead8a4ac6ece697bf23fd3'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
items=queue.Queue();jobs={}
for kind,oldkind in [('parameter','current'),('conditional-forward','conditional-forward'),('conditional','conditional'),('forward','forward'),('linear','linear'),('scalar-entry','scalar-entry'),('entry','entry'),('cfg','cfg')]:
 oldout=f'/tmp/stock-parameter-cfg-{oldkind}-integration-v1';newout=f'/tmp/stock-memory-retained-{kind}-integration-v2'
 m=json.loads(Path(f'/tmp/stock-parameter-cfg-{oldkind}-manifest-v1.json').read_text().replace(oldout,newout));m.update(packet='stock-memory-retained-'+kind,base='d5cc12ddeec71cc4ed77378812e9aca4fdfcba04',candidate=head);m['env']['FV_MEMCAP']='8G'
 for gate in m['gates']:
  if gate['argv'][:1]==['taskset']:gate['argv']=gate['argv'][3:]
 path=Path(f'/tmp/stock-memory-retained-{kind}-manifest-v2.json');path.write_text(json.dumps(m,indent=2)+'\n');jobs[kind]=(path,f'/tmp/stock-memory-retained-{kind}-gates-v2','run')
jobs['post']=(Path('/tmp/stock-memory-production-post-manifest-v4.json'),'/tmp/stock-memory-production-post-gates-v1','resume')
for kind in ['post','parameter','conditional-forward','conditional','forward','linear','scalar-entry','entry','cfg']:items.put(kind)
lock=threading.Lock();failed=threading.Event();records=[];progress=Path('/tmp/stock-memory-validation-queue-v2.json')
def save():progress.write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),head=head,max_parallel=2,cap_per_lane='8G',source_and_head_frozen=True,records=records),indent=2)+'\n')
def worker(lane):
 while not failed.is_set():
  try:kind=items.get_nowait()
  except queue.Empty:return
  path,out,action=jobs[kind]
  with lock:
   rec=dict(kind=kind,lane=lane,state='running',started=datetime.datetime.now(datetime.timezone.utc).isoformat());records.append(rec);save();print('START',kind,'lane',lane,flush=True)
  with Path(f'/tmp/stock-memory-{kind}-queue-runner-v2.log').open('w') as log:
   result=subprocess.run(['taskset','-c','0,1' if lane==0 else '2,3','nice','-n','10','python3','scripts/stock-delivery-gates.py',action,str(path),'--root',str(root),'--out',out],stdout=log,stderr=subprocess.STDOUT)
  with lock:
   rec.update(state='passed' if result.returncode==0 else 'failed',returncode=result.returncode,ended=datetime.datetime.now(datetime.timezone.utc).isoformat());save();print('END',kind,rec['state'],flush=True)
  items.task_done()
  if result.returncode:failed.set()
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 fs=[pool.submit(worker,n) for n in [0,1]]
 for f in fs:f.result()
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head
if failed.is_set():raise SystemExit('Inspect failed gate; healthy active work completed, no new cohorts started.')
assert items.empty();print('MEMORY_VALIDATION_QUEUE_PASS',flush=True)
