from pathlib import Path
import json,os,subprocess,tarfile,hashlib,datetime
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');os.chdir(root)
def git(*args,env=None):return subprocess.check_output(['git',*args],env=env,text=True).strip()
branch='agent/stock-cfg-body-progress-20261025T025359Z';parent=git('rev-parse','refs/heads/'+branch)
files=set()
for p in Path('/tmp').glob('stock-memory-*'):
 if p.is_file() and p.suffix in {'.json','.log','.py','.lean','.md'}:files.add(p)
 elif p.is_dir():files.update(f for f in p.rglob('*') if f.is_file() and f.suffix in {'.json','.log','.lean','.md','.mem','.time'})
files.update([Path('/tmp/stock-general-cfg-status.md'),root/'FV/Backend/Proof/StockMemoryReturnBody.lean',root/'FV/Backend/Proof/StockMemoryReturnSpec.lean',root/'FV/E2E/StockMemoryPairedReturn.lean',root/'FV/E2E/StockMemoryPairedReturnAt.lean']);files=sorted(files)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
m=Path('/tmp/stock-memory-body-pair-checkpoint-manifest-v1.json');a=Path('/tmp/stock-memory-body-pair-checkpoint-v1.tar.gz')
manifest=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),head=git('rev-parse','HEAD'),state='Published8d9939ea shared source/body and complete paired-body checkpoint;4237normal/5014tooljobs/81standard-onlyroots;77prior AXsets/modifiedheaders exact. Full98audit belongs to preceding381e72-root checkpoint. All memory progress/evidence and local paired ABI return consumer/block composition drafts included; drafts excluded from validation claim. Full ABI-entry/functionNI/production/broaderfunctions/full140 remain open.',files={str(p):sha(p) for p in files});m.write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(a,'w:gz',compresslevel=1) as tar:
 for p in files+[m]:tar.add(p,arcname=str(p).lstrip('/'),recursive=False)
idx=Path('/tmp/stock-memory-body-pair-backup-v1.index');idx.unlink(missing_ok=True);e=os.environ.copy();e['GIT_INDEX_FILE']=str(idx);git('read-tree',parent,env=e)
for p,k in [(m,'evidence/memory-ordinary-checkpoint-manifest-v1.json'),(a,'evidence/memory-ordinary-checkpoint-v1.tar.gz')]:
 blob=git('hash-object','-w',str(p));git('update-index','--add','--cacheinfo',f'100644,{blob},{k}',env=e)
tree=git('write-tree',env=e);commit=git('commit-tree',tree,'-p',parent,'-m','Preserve complete paired-body validation and paired ABI-return drafts');git('update-ref','refs/heads/'+branch,commit,parent);subprocess.run(['git','push','origin',branch],check=True);assert git('ls-remote','origin','refs/heads/'+branch).split()[0]==commit
blob=subprocess.check_output(['git','show',commit+':evidence/memory-ordinary-checkpoint-v1.tar.gz']);assert hashlib.sha256(blob).hexdigest()==sha(a)
with tarfile.open(a) as tar:
 for p in files:assert hashlib.sha256(tar.extractfile(str(p).lstrip('/')).read()).hexdigest()==manifest['files'][str(p)]
receipt=dict(head=manifest['head'],evidence_commit=commit,archive_sha256=sha(a),bytes=a.stat().st_size,verified_files=len(files),remote_bytes_verified=True);Path('/tmp/stock-memory-body-pair-checkpoint-receipt-v1.json').write_text(json.dumps(receipt,indent=2)+'\n');idx.unlink();print(json.dumps(receipt))
