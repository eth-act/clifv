import FV.Backend.Proof.StockRootOpcodeMatch
open Backend.Stock.Proof Isle Isle.Interp Isle.Aarch64
#eval sourceOpcodeIds 29
#eval (termOf program 135).map (·.name)
#eval (termOf program 136).map (·.name)
