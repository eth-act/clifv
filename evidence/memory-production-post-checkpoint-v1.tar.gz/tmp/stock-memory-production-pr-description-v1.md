Stock lowering of an original parameter-pointer i32 load/return was rejected by the legacy and ABI-read-only consumers. This activates a proved memory route across the default compiler, checker, verified linker and generated proofs, retaining routes 0–11 and complete previous-pipeline retry.

Original source and actual Stock construction derive the retained load, final result binding, body, shared ABI-entry virtual file and ABI return. The original initialized-memory relation supplies paired read agreement; the value-semantics and checked machine consumers cover both cleanup settings. The old ABI-read model, theorem variants, input/world conditions and required axiom sets remain intact.

The first class is a single nontrapping i32 parameter-pointer load at offset zero followed by returning its result, with register-only entry arguments. Captured two-block/nop functions, broader effects/control/calls and full #140 completeness remain open.

Validation on 3753d98a:

- 4,256 FV/FVTest modules; 5,115 tool jobs; 98 audits. All 3,994 prior per-file axiom sets, 84 previous memory roots and 23 modified public theorem headers are exact. Universal correctness uses only standard axioms; two explicitly marked fixed witness roots share one native classifier fact. One bundled MCP review passes.
- Eight actual memory proof packages, both CLI checker/verified-linker modes and cleanup settings; exact forced previous-pipeline retry bytes. 12,288 candidate native calls and 6,144 independent Cranelift calls show zero disagreement. Final proof excerpts and native object functions bind to actual verified ELF bytes.
- Runtime 5,755/0/0 with seven unchanged non-runnable cases; 1,398 identical encodings; both E2E modes retain all 1,159 identities and original successful stages; both verified examples pass.
- Actual crate-proof package: 93 modules. All 4,543 captured original source/candidate/reference/full-relocation bindings pass; byte agreement 900→900, zero gains/losses/changed function bytes.
- Retained-route regression cohorts are still running; this description is preparatory, not a merge-ready claim.
