import FV.Backend.Proof.StockMemorySelected
import FV.Backend.Proof.StockRootOpcodeMatch

namespace Backend.Stock.Memory
open Backend.Proof Backend.Proof.Driver Backend.Stock.Proof Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm
private theorem inventory : sourceOpcodeIds 29 = [1041,1042,1043,1044,1045,1046,1047,1048,1049,1050,1051] := by decide +kernel
