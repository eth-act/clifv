from pathlib import Path
import json,os,subprocess,datetime
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');os.chdir(root)
records=[];progress=Path('/tmp/stock-memory-retained-queue-v1.json')
items=[('parameter','current'),('conditional-forward','conditional-forward'),('conditional','conditional'),('forward','forward'),('linear','linear'),('scalar-entry','scalar-entry'),('entry','entry'),('cfg','cfg')]
for kind,oldkind in items:
 original=Path(f'/tmp/stock-parameter-cfg-{oldkind}-manifest-v1.json')
 oldout=f'/tmp/stock-parameter-cfg-{oldkind}-integration-v1';newout=f'/tmp/stock-memory-retained-{kind}-integration-v1'
 m=json.loads(original.read_text().replace(oldout,newout));m['packet']='stock-memory-retained-'+kind;m['base']='d5cc12ddeec71cc4ed77378812e9aca4fdfcba04';m['candidate']='791f3484+frozen-memory-activation';m['env']['FV_MEMCAP']='8G'
 path=Path(f'/tmp/stock-memory-retained-{kind}-manifest-v1.json');path.write_text(json.dumps(m,indent=2)+'\n')
 rec=dict(kind=kind,state='running',utc=datetime.datetime.now(datetime.timezone.utc).isoformat());records.append(rec);progress.write_text(json.dumps(dict(state='running',lanes=1,cap='8G',records=records),indent=2)+'\n');print('START',kind,flush=True)
 with Path(f'/tmp/stock-memory-retained-{kind}-runner-v1.log').open('w') as log:
  r=subprocess.run(['nice','-n','10','python3','scripts/stock-delivery-gates.py','run',str(path),'--root',str(root),'--out',f'/tmp/stock-memory-retained-{kind}-gates-v1'],stdout=log,stderr=subprocess.STDOUT)
 rec.update(state='passed' if r.returncode==0 else 'failed',returncode=r.returncode,ended=datetime.datetime.now(datetime.timezone.utc).isoformat());progress.write_text(json.dumps(dict(state='running' if r.returncode==0 else 'failed',lanes=1,cap='8G',records=records),indent=2)+'\n');print('END',kind,rec['state'],flush=True)
 if r.returncode:raise SystemExit(r.returncode)
progress.write_text(json.dumps(dict(state='passed',lanes=1,cap='8G',records=records),indent=2)+'\n')
