from pathlib import Path
import json,os,subprocess,tarfile,hashlib,datetime
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');os.chdir(root)
def git(*args,env=None):return subprocess.check_output(['git',*args],env=env,text=True).strip()
branch='agent/stock-cfg-body-progress-20261025T025359Z';parent=git('rev-parse','refs/heads/'+branch)
files=set()
for p in [p for prefix in ['stock-memory-paired','stock-memory-read'] for p in Path('/tmp').glob(prefix+'*')]:
 if p.is_file() and p.suffix in {'.json','.log','.py','.lean','.md'}:files.add(p)
 elif p.is_dir():files.update(f for f in p.rglob('*') if f.is_file() and f.suffix in {'.json','.log','.lean','.md','.mem','.time'})
files.update([Path('/tmp/stock-general-cfg-status.md'),Path('/tmp/stock-memory-single-cleanup-v1.json'),root/'FV/E2E/StockMemoryPairedSource.lean']);files=sorted(files)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
m=Path('/tmp/stock-memory-paired-checkpoint-manifest-v1.json');a=Path('/tmp/stock-memory-paired-checkpoint-v1.tar.gz')
manifest=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),head=git('rev-parse','HEAD'),state='Published381e paired initialized-source read/actual-record checkpoint;4233normal/5014tooljobs/98audits/72standard-onlymemoryroots; all3971prior per-file AXsets and65prior memory AXsets exact. Next paired-source local draft/source/generator/failures included, excluded from validation claims. Complete functionNI/production activation/broader functions/full140 remain open.',files={str(p):sha(p) for p in files});m.write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(a,'w:gz',compresslevel=1) as tar:
 for p in files+[m]:tar.add(p,arcname=str(p).lstrip('/'),recursive=False)
idx=Path('/tmp/stock-memory-paired-backup-v1.index');idx.unlink(missing_ok=True);e=os.environ.copy();e['GIT_INDEX_FILE']=str(idx);git('read-tree',parent,env=e)
for p,k in [(m,'evidence/memory-ordinary-checkpoint-manifest-v1.json'),(a,'evidence/memory-ordinary-checkpoint-v1.tar.gz')]:
 blob=git('hash-object','-w',str(p));git('update-index','--add','--cacheinfo',f'100644,{blob},{k}',env=e)
tree=git('write-tree',env=e);commit=git('commit-tree',tree,'-p',parent,'-m','Preserve initialized-memory paired record validation and next source draft');git('update-ref','refs/heads/'+branch,commit,parent);subprocess.run(['git','push','origin',branch],check=True);assert git('ls-remote','origin','refs/heads/'+branch).split()[0]==commit
blob=subprocess.check_output(['git','show',commit+':evidence/memory-ordinary-checkpoint-v1.tar.gz']);assert hashlib.sha256(blob).hexdigest()==sha(a)
with tarfile.open(a) as tar:
 for p in files:assert hashlib.sha256(tar.extractfile(str(p).lstrip('/')).read()).hexdigest()==manifest['files'][str(p)]
receipt=dict(head=manifest['head'],evidence_commit=commit,archive_sha256=sha(a),bytes=a.stat().st_size,verified_files=len(files),remote_bytes_verified=True);Path('/tmp/stock-memory-paired-checkpoint-receipt-v1.json').write_text(json.dumps(receipt,indent=2)+'\n');idx.unlink();print(json.dumps(receipt))
