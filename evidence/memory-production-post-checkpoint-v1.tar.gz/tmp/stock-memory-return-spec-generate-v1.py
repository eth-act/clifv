from pathlib import Path
p=Path('FV/Backend/Proof/StockMemoryReturnBody.lean');old=p.read_text()
privateStart=old.index('private theorem parameter_definition');privateEnd=old.index('\n/-- Original singleton',privateStart);private=old[privateStart:privateEnd]
start=old.index('theorem stock_single_load_return_body');semantic=old.index('    {F : BitVec 64 → Prop}',start);head=old[start:semantic]
a=old.index(' := by',semantic);initial=old[a+len(' := by\n'):old.index('  have normal :=',a)]
r1=old.index('  have bodyRecords :',a);r2=old.index('  refine ⟨term,body,split',r1);records=old[r1:r2]
preamble='''import FV.Backend.Proof.StockMemoryDispatch
import FV.Backend.Proof.StockReturnedSourceRetention

namespace Backend.Stock.Memory
open Backend.Proof Backend.Proof.Driver Backend.Stock.Proof Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000

'''
structure='''/-- Proof-internal retained load-body data, derived from original source syntax.
Consumers receive this from the whole driver; it is never an accepted-input certificate. -/
structure SingleLoadReturnSpec (f : Clif.Function) (result : Result) (event : BlockScanEvent)
    (b : Clif.Block) (x z : Nat) (flags : Clif.MemFlags) where
  term : ScanRecord
  record : ScanRecord
  body : BlockScan
  step : Step
  info : IInfo
  resultReg : Nat
  pointerReg : Nat
  split : SourceBodySplit f event b term body
  bodyRecords : body.records = [record]
  current : record.inst = blockStart f event.block+0
  records : record ∈ event.output.records
  recorded : record.output.step = some step
  emitted : step.decision = .emitted
  source : event.ctx.insts[record.inst]? = some info
  clif : info.clif = some (.load .load .i32 flags x 0)
  results : info.results = [z]
  mapped : event.ctx.valueReg? z = some (.vreg resultReg .int)
  parameter : event.ctx.defInst? x = none
  pointer : event.ctx.valueReg? x = some (.vreg pointerReg .int)

'''
new=preamble+private.replace('private theorem parameter_definition','/-- Original source parameters have no DFG instruction in each actual scan context. -/\ntheorem stock_lower_source_parameter_definition')+'\n'+structure
new+=head.replace('theorem stock_single_load_return_body','/-- Original singleton load/return syntax derives all retained-body data. -/\ntheorem stock_single_load_return_spec')+'    : Nonempty (SingleLoadReturnSpec f result event b x z flags) := by\n'
new+=initial.replace('parameter_definition run','stock_lower_source_parameter_definition run')+records+'''  exact ⟨⟨term,record,body,step,info,a,nreg,split,bodyRecords,current,records,recorded,emitted,
    source,clif,results,mapped,noDefinition,pointer⟩⟩

end Backend.Stock.Memory
'''
Path('FV/Backend/Proof/StockMemoryReturnSpec.lean').write_text(new)
# Preserve the old private/public signatures while sharing source derivation.
privateHeader=private[:private.index(' := by')]
privateWrapper=privateHeader+' :=\n  stock_lower_source_parameter_definition run dominated events block parameter\n'
header=old[start:a+len(' := by')]
body='''
  obtain ⟨spec⟩ := stock_single_load_return_spec run scope dominated events block singleton ret parameterBlock parameter
  have statement : b.body[0]? = some ⟨[z],.load .load .i32 flags x 0⟩ := by simp [singleton]
  have normal := stock_lower_load_scan_fall_refines_auto run scope dominated events spec.records block statement spec.current
    spec.source spec.clif spec.results rfl spec.mapped spec.parameter spec.pointer spec.recorded spec.emitted
    stable memorySem memoryOk (env := env) (cp := cp)
  refine ⟨spec.term,spec.body,spec.split,?_⟩
  have each : ∀ r ∈ spec.body.records,ScanFallRefines (IndexedSourceInst env cp f event.ctx event.block)
      isem result.final.alias (GuardedScanRel f result event.ctx event.block MR) r := by
    intro r present
    have same : r = spec.record := by simpa only [spec.bodyRecords,List.mem_singleton] using present
    subst r
    exact normal
  intro s s' steps ρ w held
  apply spec.split.scanned.fall_refines each s s'
  · simpa only [sourceBodyIndices,List.reverse_reverse] using steps
  · simpa only [spec.split.state] using held

end Backend.Stock.Memory
'''
updated=old[:privateStart].replace('import FV.Backend.Proof.StockReturnedSourceRetention','import FV.Backend.Proof.StockMemoryReturnSpec')+privateWrapper+'\n'+old[privateEnd:start]+header+body
p.write_text(updated)
