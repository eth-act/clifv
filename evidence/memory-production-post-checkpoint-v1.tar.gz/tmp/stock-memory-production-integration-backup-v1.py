from pathlib import Path
import os,subprocess,json,tarfile,hashlib,datetime
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');os.chdir(root)
def git(*args,env=None):return subprocess.check_output(['git',*args],env=env,text=True).strip()
branch='agent/stock-cfg-body-progress-20261025T025359Z';parent=git('rev-parse','refs/heads/'+branch)
files={root/p for p in git('diff','--name-only').splitlines()}
files.update(root/p for p in git('ls-files','--others','--exclude-standard').splitlines())
for p in Path('/tmp').glob('stock-memory-*'):
 if p.is_file() and p.suffix in {'.json','.py','.md','.lean','.log'}:files.add(p)
 elif p.is_dir():
  receipt=p/'receipt.json'
  if receipt.exists() and json.loads(receipt.read_text()).get('state') in ('passed','failed'):
   files.update(x for x in p.rglob('*') if x.is_file() and x.suffix in {'.json','.log','.lean','.md','.mem','.time','.clif','.s','.o','.elf','.rsp'})
files.update([Path('/tmp/stock-general-cfg-status.md'),Path('/tmp/stock-memory-paired-return-parity-v1.json'),Path('/tmp/stock-memory-body-pair-cleanup-v1.json'),Path('/tmp/stock-memory-production-normal-manifest-v1.json')])
for p in [Path('/tmp/stock-memory-paired-return-normal-gates-v1')]:
 files.update(x for x in p.rglob('*') if x.is_file())
files=sorted(files)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
manifest=Path('/tmp/stock-memory-production-integration-checkpoint-v1.json');archive=Path('/tmp/stock-memory-production-integration-checkpoint-v1.tar.gz')
m=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),head=git('rev-parse','HEAD'),state='Frozen local first memory production activation;5115tooljobs,22 memory integration commands/8generated roots/both CLI and cleanup modes/12288native calls/8192initialized loads pass. Independent6144Cranelift calls/4096initialized loads/0disagreement. Full normal/trust/corpus/retained/paired author gates remain ongoing and excluded from completion claim; preserve earlier harness failure evidence.23oldpublicheaders exact. Original140 remains open.',files={str(p):sha(p) for p in files});manifest.write_text(json.dumps(m,indent=2)+'\n')
with tarfile.open(archive,'w:gz',compresslevel=1) as tar:
 for p in files+[manifest]:tar.add(p,arcname=str(p).lstrip('/'),recursive=False)
index=Path('/tmp/stock-memory-production-integration-backup-v1.index');index.unlink(missing_ok=True);env=os.environ.copy();env['GIT_INDEX_FILE']=str(index);git('read-tree',parent,env=env)
for p,key in [(manifest,'evidence/memory-production-integration-checkpoint-v1.json'),(archive,'evidence/memory-production-integration-checkpoint-v1.tar.gz')]:
 blob=git('hash-object','-w',str(p));git('update-index','--add','--cacheinfo',f'100644,{blob},{key}',env=env)
commit=git('commit-tree',git('write-tree',env=env),'-p',parent,'-m','Preserve actual memory native, generated-proof and Cranelift-reference evidence');git('update-ref','refs/heads/'+branch,commit,parent);subprocess.run(['git','push','origin',branch],check=True);assert git('ls-remote','origin','refs/heads/'+branch).split()[0]==commit
blob=subprocess.check_output(['git','show',commit+':evidence/memory-production-integration-checkpoint-v1.tar.gz']);assert hashlib.sha256(blob).hexdigest()==sha(archive)
with tarfile.open(archive) as tar:
 for p in files:assert hashlib.sha256(tar.extractfile(str(p).lstrip('/')).read()).hexdigest()==m['files'][str(p)]
receipt=dict(head=m['head'],evidence_commit=commit,archive_sha256=sha(archive),bytes=archive.stat().st_size,verified_files=len(files),remote_verified=True);Path('/tmp/stock-memory-production-integration-backup-receipt-v1.json').write_text(json.dumps(receipt,indent=2)+'\n');index.unlink();print(json.dumps(receipt))
