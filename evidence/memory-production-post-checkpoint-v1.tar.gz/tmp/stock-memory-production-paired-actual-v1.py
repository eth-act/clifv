from pathlib import Path
import os,json,subprocess,hashlib,sys,shutil,datetime
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');os.chdir(root);sys.path.insert(0,str(root/'scripts'))
from byte_compare import ELF
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
prefix='/tmp/stock-memory-production-';out=Path(prefix+'paired-actual-v1');out.mkdir(exist_ok=False)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();base='d5cc12ddeec71cc4ed77378812e9aca4fdfcba04'
full=json.load(open(prefix+'full-current-receipt-v1.json'));assert full['state']=='passed' and full['head']==head
parent=Path('/tmp/stock-parameter-cfg-paired-actual-v1');prior=json.load(open(parent/'provenance.json'));baseline=json.load(open('/tmp/stock-memory-source-baseline/provenance.json'))
assert prior['state']=='passed' and baseline['baseline_main']==base and baseline['validated_implementation']==prior['head']
assert baseline['landed_tree_exact']
assert subprocess.check_output(['git','rev-parse',base+'^{tree}'],text=True)==subprocess.check_output(['git','rev-parse',baseline['publication']+'^{tree}'],text=True)
for name in ['FV','FVTest','scripts']:
 assert subprocess.check_output(['git','rev-parse',base+':'+name],text=True)==subprocess.check_output(['git','rev-parse',prior['head']+':'+name],text=True)
assert sha('/tmp/stock-memory-source-baseline/lean-backend')==baseline['binary_sha256']==prior['candidate_binary_sha256']
assert sha(root/'rust/crates/cargo-fv/src/pipeline.rs')==prior['source_pipeline_sha256']
assert prior['flags']==['--dead-cleanup','--personality','rust_eh_personality']
assert all(sha(p)==h for p,h in prior['original_sources'].items()),'Actual rebuilt sources differ: fresh paired baseline required'
assert all(sha(p)==h for p,h in prior['files'].items()),'Parent capture mutated'
report=json.load(open(prefix+'post-gates-v1/real-crate-report.json'));lookup={(r['cgu'],r['fn']):r for r in report};assert len(lookup)==4543
oldrows=json.load(open(parent/'rows.json'));assert sha(parent/'rows.json')==prior['rows_sha256']
groups={}
for r in oldrows:groups.setdefault((r['crate'],r['cgu']),[]).append(r)
rows=[];files={};units=[]
def keep(source,dest):
 dest.parent.mkdir(exist_ok=True,parents=True);shutil.copy2(source,dest);assert sha(source)==sha(dest);files[str(dest)]=sha(dest)
def reloc(elf,symbol):return [(r['offset'],r['type'],r['addend']) for r in elf.function_relocations(symbol,{})]
def fullreloc(elf,symbol):return elf.function_relocations(symbol,{})
for (crate,cgu),items in sorted(groups.items()):
 actual=root/'examples'/crate/'target/fv/plain-leanlink-verified-leanld/tmp'/cgu;target=out/cgu
 for file in ['lean.o','cgclif.o','fv-link.json','lean-inputs.rsp','redefine-lean.txt']:keep(actual/file,target/'candidate'/file)
 for file in ['lean.o','lean-inputs.rsp']:keep(parent/cgu/'candidate'/file,target/'baseline'/file)
 new=ELF(target/'candidate/lean.o');old=ELF(target/'baseline/lean.o');reference=ELF(target/'candidate/cgclif.o');oldref=ELF(parent/cgu/'candidate/cgclif.o')
 for r in items:
  name=r['fn'];ns,nb=new.function(name);bs,bb=old.function(name);ss,sb=reference.function(name);ps,pb=oldref.function(name)
  assert hashlib.sha256(bb).hexdigest()==r['candidate_bytes'],(cgu,name,'old output')
  assert sb==pb and fullreloc(reference,ss)==fullreloc(oldref,ps),(cgu,name,'same reference incl target names')
  equal=nb==sb and reloc(new,ns)==reloc(reference,ss)
  assert equal==lookup[(cgu,name)]['equal'],(cgu,name,'actual native report')
  rows.append(dict(crate=crate,cgu=cgu,fn=name,baseline_equal=bb==sb and reloc(old,bs)==reloc(reference,ss),candidate_equal=equal,baseline_bytes=hashlib.sha256(bb).hexdigest(),candidate_bytes=hashlib.sha256(nb).hexdigest()))
 units.append(dict(crate=crate,cgu=cgu,functions=len(items)))
assert len(rows)==4543 and len(units)==30
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head
lost=[r for r in rows if r['baseline_equal'] and not r['candidate_equal']];gained=[r for r in rows if r['candidate_equal'] and not r['baseline_equal']]
summary=dict(head=head,baseline=base,state='passed' if not lost else 'failed',symbol_comparisons=len(rows),baseline_exact=sum(r['baseline_equal'] for r in rows),candidate_exact=sum(r['candidate_equal'] for r in rows),gained=gained,lost=lost,changed_function_bytes=sum(r['baseline_bytes']!=r['candidate_bytes'] for r in rows),same_captured_inputs_and_settings=True,actual_rebuilt_candidate_and_reference=True,reference_full_relocation_targets_exact=True,limits='Bounded paired actual-output measurement, not original140 completeness. Candidate comes from current verified example gates; parent artifacts reused only after source/settings/executable/provenance hash checks.')
(out/'rows.json').write_text(json.dumps(rows,indent=2)+'\n');(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
p=dict(head=head,baseline=base,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),state=summary['state'],parent_original_provenance_sha256=sha(parent/'provenance.json'),parent_original_provenance=str(parent/'provenance.json'),parent_implementation=prior['head'],parent_binary_sha256=baseline['binary_sha256'],candidate_binary_sha256=sha(root/'.lake/build/bin/lean-backend'),source_pipeline_sha256=prior['source_pipeline_sha256'],flags=prior['flags'],original_sources=prior['original_sources'],files=files,units=units,full_gate_receipt_sha256=sha(prefix+'full-current-receipt-v1.json'),rows_sha256=sha(out/'rows.json'),summary_sha256=sha(out/'summary.json'))
(out/'provenance.json').write_text(json.dumps(p,indent=2)+'\n');print(json.dumps({k:len(v) if k in ['gained','lost'] else v for k,v in summary.items()}));assert not lost
