Extend the proved Stock memory provider to the captured NOP/jump/NOP/load/return class. The pointer comes from the original entry parameter. The compiler, checker, linker, generated proofs and trace use the same complete CFG provider. Previous routes and legacy fallback remain available.

The source and machine proofs cover jumps, inherited values, the initialized load, return and trap absence. Concrete paired witnesses use distinct worlds. Original source conditions, old theorem interfaces and axiom sets remain preserved.

Validation before reconciliation:2874/2874 reverse modules,22 executable links, exact105 old memory axiom sets and exact30/18 captured audit sets. Native/generated consumers pass in both cleanup modes. All4543 original source hashes remain exact. All eight actual captured function objects match preserved Cranelift bytes and relocations. This does not establish an original-settings contract or an official-suite gain.

The candidate now uses landed#775/main4d4985b9. Reconciliation changed only the nine landed#777 proof files; captured source remains exact. Current-base reverse/executable/audit/native gates and original-object checks run under exit watchers. Merge follows their results and the existing single QUICK, DIRTY, CHEAP peer review. No review agents.

Part of#140. This is one complete production class. Broader memory effects, configured-provider integration and the remaining original driver obligations continue separately.
