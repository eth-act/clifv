from pathlib import Path
import os,subprocess,json,datetime,time,re,tomllib,hashlib,shutil
b=Path('/home/lee/clifv');r=b/'.worktrees/stock-memory-delivery-20261030';e=b/'.git/agent-evidence/stock-memory-20261029'
state=e/'production-reverse-gates-state-v6.json';records=[]
def save(status,**extra):state.write_text(json.dumps(dict(status=status,records=records,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),**extra),indent=2)+'\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=r)
env=dict(os.environ);env.update(json.loads((e/'author-env-v1.json').read_text()));env.update(FV_ROOT=str(r),FV_MEMCAP='16G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',CARGO_BUILD_JOBS='2')
for key in ['FV_PIPELINE_T','BLESS']:env.pop(key,None)
def run(label,args):
 save('running',phase=label)
 with (e/('production-'+label+'-v6.log')).open('w') as log:result=subprocess.run(['nice','-n','10',str(r/'scripts/memcap.sh'),*args],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 records.append(dict(id=label,returncode=result.returncode))
 if result.returncode:raise RuntimeError(str((label,result.returncode)))
def inputs():
 names=git('ls-files','--cached','--others','--exclude-standard','-z').decode().split('\0')
 return {n:hashlib.sha256((r/n).read_bytes()).hexdigest() for n in names if n and (r/n).is_file()}
try:
 main=git('rev-parse','origin/main').decode().strip()
 assert main=='0391afea1cfb529aa415e7979f438dfe8fcc6c5a'
 assert git('rev-parse','HEAD').decode().strip()==main
 assert git('branch','--show-current').decode().strip()=='agent/stock-memory-activation-20261030'
 packet=json.loads((e/'memory-activation-packet.json').read_text());owned=set(packet['files'])
 expected_tree=git('write-tree').decode().strip()
 (e/'production-candidate-v6.json').write_text(json.dumps(dict(base=main,expected_tree=expected_tree,preserved_head='b6cdec54ace309896038fdecbb7c47a2d991e2fe',changes='Existing packet plus one explicit stack-bound import; adopted nine landed proof files'),indent=2)+'\n')
 deps={}
 for folder in ['FV','FVTest','Corpus']:
  for f in (r/folder).rglob('*.lean'):deps[str(f.relative_to(r))[:-5].replace('/','.')]=set(re.findall(r'^import\s+(\S+)',f.read_text(),re.M))
 affected={p[:-5].replace('/','.') for p in owned if p.endswith('.lean') and not p.startswith('scripts/')}
 while True:
  new=affected|{m for m,imports in deps.items() if imports&affected}
  if new==affected:break
  affected=new
 roots=sorted(affected);config=tomllib.loads((r/'lakefile.toml').read_text());exes=[x['name'] for x in config['lean_exe'] if x.get('root',x['name']) in affected]
 (e/'production-current-main-closure-v6.json').write_text(json.dumps(dict(main=main,roots=roots,executables=exes),indent=2)+'\n');original=inputs();(e/'production-current-source-v6.json').write_text(json.dumps(original,indent=2)+'\n')
 run('reverse-closure',['python3','scripts/lake-serial-build.py','--budget','16G','--max-jobs','2','--max-cap','16G','--default-cap','8G','--profile',str(r/'scripts/lake-module-peaks.tsv'),'--profile',str(r/'.lake/lake-module-peaks.tsv'),'--profile',str(e/'production-cold-overrides-v6.tsv'),'--out',str(e/'production-reverse-modules-v6'),*roots])
 run('executables',['lake','build',*exes])
 run('memory-audit',['lake','env','lean','scripts/audit/stock-memory-source.lean'])
 def axioms(text):return {n:set(x.strip() for x in a.split(',')) for n,a in re.findall(r"'([^']+)' depends on axioms: \[([^]]*)\]",text,re.S)}
 old=axioms((e/'author-normal-gates-v1/all-axioms/stock-memory-source.log').read_text());current=axioms((e/'production-memory-audit-v6.log').read_text());assert len(old)==105 and current==old,'Memory axiom sets changed'
 for test in ['test_lowering_trace.py','test_stock_lowering_schedule.py','test_stock_compiler_compare.py','test_stock_pipeline.py','test_stock_exporter.py']:run(test,['python3','-m','unittest','discover','-s','scripts','-p',test,'-v'])
 for kind in ['parameter','conditional-forward','conditional','forward','linear','scalar-entry','entry','cfg']:run('retained-'+kind,[str(r/'.lake/build/bin/stock-memory-retained'),kind])
 run('memory-consumers',['python3','scripts/check-stock-memory-integration.py','--output',str(e/'production-memory-consumers-v6')])
 assert inputs()==original,'Production validation source changed'
 save('passed',main=main,reverse_roots=len(roots),executables=exes,audit_roots=105,axiom_sets_exact=True,official_comparison='Reuse validated delivery-runtime-final-v1:1187/4455, no lost identities')
except BaseException as error:save('failed',error=repr(error));raise
