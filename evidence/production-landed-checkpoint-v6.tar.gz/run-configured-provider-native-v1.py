from pathlib import Path
import os,subprocess,json,datetime,time,re,tomllib,hashlib,sys,importlib.util,psutil
b=Path('/home/lee/clifv');r=b/'.worktrees/stock-memory-delivery-20261030';e=b/'.git/agent-evidence/stock-memory-20261029';state=e/'configured-provider-native-state-v1.json';records=[]
env=dict(os.environ);env.update(json.loads((e/'author-env-v1.json').read_text()));env.update(FV_ROOT=str(r),FV_MEMCAP='16G',FV_COMPARE_MEMCAP='1',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',CARGO_BUILD_JOBS='1',LEAN_BIN_DIR='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin',PYTHONDONTWRITEBYTECODE='1')
for key in ['FV_PIPELINE_T','BLESS']:env.pop(key,None)
def save(status,**extra):state.write_text(json.dumps(dict(status=status,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),records=records,**extra),indent=2)+'\n')
def run(label,args,accepted=(0,)):
 save('running',phase=label)
 with (e/('configured-provider-native-'+label+'-v1.log')).open('w') as log:done=subprocess.run(['nice','-n','10',str(r/'scripts/memcap.sh'),*args],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 records.append(dict(label=label,returncode=done.returncode));assert done.returncode in accepted,(label,done.returncode)
def git(*args):return subprocess.check_output(['git',*args],cwd=r).decode().strip()
def fingerprint():
 names=git('ls-files','--cached','--others','--exclude-standard','-z').split('\0')
 return {n:hashlib.sha256((r/n).read_bytes()).hexdigest() for n in names if n and (r/n).is_file()}
save('waiting',dependencies=[2859871,2860156,2860372],landing_receipt='captured-landing-v5.json')
try:
 while any(psutil.pid_exists(pid) for pid in [2859871,2860156,2860372]):time.sleep(3)
 for name in ['captured-current-consumers-state-v5.json','captured-real-inputs-state-v5.json','captured-current-object-comparison-state-v3.json']:assert json.loads((e/name).read_text())['status']=='passed',name
 while not (e/'captured-landing-v5.json').exists():time.sleep(3)
 assert json.loads((e/'captured-landing-v5.json').read_text())['state']=='MERGED'
 expected=json.loads((e/'configured-provider-focus-receipt-v1.json').read_text())['source_sha256']
 for current,draft in [('FVTest/Backend/Main.lean','BackendMainConfiguredProvider.next.lean'),('FVTest/Backend/StockConfig.lean','StockConfigAllocateWith.next.lean'),('scripts/test_stock_configured_provider.py','test_stock_configured_provider.next.py'),('scripts/testdata/stock-config-aarch64.json','stock-config-aarch64.next.json')]:assert hashlib.sha256((r/current).read_bytes()).hexdigest()==expected[draft],current
 before=fingerprint();(e/'configured-provider-native-source-v1.json').write_text(json.dumps(before,indent=2)+'\n')
 deps={}
 for folder in ['FV','FVTest','Corpus']:
  for f in (r/folder).rglob('*.lean'):deps[str(f.relative_to(r))[:-5].replace('/','.')]=set(re.findall(r'^import\s+(\S+)',f.read_text(),re.M))
 affected={'FVTest.Backend.Main','FVTest.Backend.StockConfig'}
 while True:
  more=affected|{m for m,imports in deps.items() if imports&affected}
  if more==affected:break
  affected=more
 config=tomllib.loads((r/'lakefile.toml').read_text());exes=[x['name'] for x in config['lean_exe'] if x.get('root',x['name']) in affected]
 (e/'configured-provider-native-closure-v1.json').write_text(json.dumps(dict(roots=sorted(affected),executables=exes),indent=2)+'\n')
 run('reverse-build',['python3','scripts/lake-serial-build.py','--budget','16G','--max-jobs','2','--max-cap','16G','--default-cap','8G','--profile',str(r/'scripts/lake-module-peaks.tsv'),'--profile',str(r/'.lake/lake-module-peaks.tsv'),'--out',str(e/'configured-provider-native-modules-v1'),*sorted(affected)])
 run('executables',['lake','build',*exes,'lean-backend-lowering-trace'])
 run('configured-tests',['python3','-m','unittest','discover','-s','scripts','-p','test_stock_configured_provider.py','-v'])
 sys.path.insert(0,str(r/'scripts'))
 spec=importlib.util.spec_from_file_location('compare',r/'scripts/stock-compiler-compare.py');compare=importlib.util.module_from_spec(spec);spec.loader.exec_module(compare)
 out=e/'configured-original-native-v1';out.mkdir(exist_ok=False);reference=json.loads((e/'captured-object-reference-v1/receipt.json').read_text());variants={}
 for manifest in (e/'captured-object-reference-v1').glob('*/first/manifest.json'):
  for variant in json.loads(manifest.read_text())['variants']:
   for name in variant['functions']:variants[name.removeprefix('%')]=variant
 for i,row in enumerate(reference['rows']):
  source=Path(row['original_path']);assert compare.digest(source.read_bytes())==row['original_sha256'];request=compare.request_for(variants[row['function']],source.read_bytes());request_path=out/f'{i}.request.json';request_path.write_text(json.dumps(request,indent=2)+'\n');receipt=out/f'{i}.receipt.json';obj=out/f'{i}.o';allocation=out/f'{i}.allocator.json'
  done=subprocess.run([str(r/'scripts/memcap.sh'),str(r/'.lake/build/bin/lean-backend'),str(source),str(obj),'--regalloc','regalloc2','--stock-config',str(request_path),'--config-receipt',str(receipt),*([] if row['cleanup'] else ['--no-dead-cleanup'])],cwd=r,env=dict(env,LEAN_REGALLOC_KEEP=str(allocation)),capture_output=True,text=True)
  (out/f'{i}.log').write_text(done.stdout+done.stderr);actual=json.loads(receipt.read_text());old=json.loads((e/f'configured-original-captures-v1/{i}-native-baseline.receipt.json').read_text());assert actual==old and actual['request']==request and not actual['configuration_accepted'];assert done.returncode==3 and not obj.exists() and not allocation.exists()
 run('official-comparison',['bash','scripts/stock-compiler-comparison.sh','--out',str(e/'configured-official-vectors-v1'),'--jobs','1'],accepted=(0,10))
 spec=importlib.util.spec_from_file_location('ci',r/'scripts/stock-comparison-ci.py');ci=importlib.util.module_from_spec(spec);spec.loader.exec_module(ci)
 report=json.loads((e/'configured-official-vectors-v1/results.json').read_text());old=json.loads((e/'delivery-official-vectors-v1/results.json').read_text());totals=ci.validate_report(report);previous=set(ci.matched_entries(old));current=set(ci.matched_entries(report));assert not(previous-current),('Lost identities',sorted(previous-current));assert report['inventory']==old['inventory'];assert before==fingerprint(),'Source changed during configured validation'
 save('passed',totals=totals,gained=sorted(current-previous),lost=[],original_settings_rejections_exact=8,source_unchanged=True,reverse_roots=len(affected),executables=exes)
except BaseException as error:save('failed',error=repr(error));raise
