Activate the proved Stock provider for initialized, nontrapping load.i32 at offset zero followed by return. The compiler, checker, linker and generated proofs select the same provider. All previous classes retain their routes and fallback.

The change preserves original source conditions, theorem variants and axiom sets. It also adds maintained native memory compatibility tests and the pinned Lean REPL dependency.

Validation on current main0391afea, candidate bda33e07:
- Changed reverse closure:2846/2846 modules passed.
- All22 affected executables linked.
- All105 memory audit roots retain their exact previous axiom sets.
- Maintained trace, schedule, comparison, pipeline and exporter tests passed.
- Remaining native/runtime consumers continue under the existing exit watcher.

One QUICK, DIRTY, CHEAP peer review approved merging after the reverse closure, executable links and exact axiom audit. No review agents. Any remaining runtime failure requires immediate revert, repair and relanding.

The preserved reconciled official comparison retains1187/4455 exact outputs with no lost identities. This singleton class accepts none of the4543 preserved captured inputs. The separate complete captured CFG class follows this PR. Full original#140 remains open.

The previous published headb6cdec54 remains backed up remotely on agent/stock-memory-activation-before-main-20261031. This candidate includes main#777 and one explicit stack-bound import repair. Failed validation attempts remain preserved.

Part of#140.
