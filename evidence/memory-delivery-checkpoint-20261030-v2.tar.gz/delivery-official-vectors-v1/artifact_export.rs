//! Capture artifacts in the actual stock `compile` subtest, before its text assertions.
//! No JIT, no compiler-setting overrides, and no test expectation updates.
use anyhow::{Result, anyhow, bail};
use cranelift_codegen::{CompiledCode, FinalizedRelocTarget, ir::Function, isa::TargetIsa};
use cranelift_reader::{TestCommand, TestFile};
use serde_json::json;
use std::{borrow::Cow, collections::HashMap, path::Path};

/// Export every independent function and retain the stock subtest's assertion result.
pub fn export_compile(
    test: &TestFile,
    command: &TestCommand,
    isa: &dyn TargetIsa,
    directory: &Path,
    input: &str,
) -> Result<()> {
    if std::env::var_os("BLESS").is_some() {
        bail!("BLESS is forbidden during artifact export");
    }
    std::fs::create_dir_all(directory)?;
    // As runone does, verify the entire file before running a verifier-requiring subtest.
    for (func, _) in &test.functions {
        cranelift_codegen::verify_function(func, isa)
            .map_err(|e| anyhow!("stock verifier: {e}"))?;
    }
    let update = crate::runone::FileUpdate::new(Path::new(input));
    let mut assertions = Vec::new();
    for (index, (func, details)) in test.functions.iter().enumerate() {
        // A subtest per function (TestCompile keeps no state between functions); artifacts are
        // named by the function's position in the file, because a compile test may repeat a name.
        let subtest = crate::test_compile::exporting_subtest(command, directory, index)?;
        let context = crate::subtest::Context {
            preamble_comments: &test.preamble_comments,
            details,
            flags: isa.flags(),
            isa: Some(isa),
            file_path: input,
            file_update: &update,
        };
        let result = subtest.run(Cow::Borrowed(func), &context);
        assertions.push(json!({"index":index, "name":func.name.to_string(), "passed":result.is_ok(), "error":result.err().map(|e|format!("{e:#}"))}));
    }
    std::fs::write(
        directory.join("assertions.json"),
        serde_json::to_vec_pretty(&assertions)?,
    )?;
    Ok(())
}

/// Artifact file stem: the function's position in the test file. Names are not unique in a
/// compile test, positions are; a number cannot escape the artifact directory.
fn stem(index: usize) -> String {
    index.to_string()
}

pub(crate) fn write_input(directory: &Path, index: usize, func: &Function) -> Result<()> {
    let original = func.to_string();
    std::fs::write(directory.join(format!("{}.clif", stem(index))), &original)?;
    let signatures: HashMap<_, _> = original
        .lines()
        .filter_map(|line| {
            let (name, signature) = line.trim().split_once(" = ")?;
            name.starts_with("sig").then_some((name, signature))
        })
        .collect();
    let adapted = original
        .lines()
        .map(|line| {
            if line.trim_start().starts_with("fn") {
                if let Some((prefix, reference)) = line.rsplit_once(' ') {
                    if let Some(signature) = signatures.get(reference) {
                        return format!("{prefix} {signature}");
                    }
                }
            }
            line.to_string()
        })
        .collect::<Vec<_>>()
        .join("\n")
        + "\n";
    if adapted != original {
        let mut parsed = cranelift_reader::parse_functions(&adapted).map_err(|e| anyhow!("{e}"))?;
        let original_func = cranelift_reader::parse_functions(&original)
            .map_err(|e| anyhow!("{e}"))?
            .remove(0);
        if parsed.len() != 1 || parsed[0].dfg.ext_funcs.len() != original_func.dfg.ext_funcs.len() {
            bail!("signature adaptation changed declarations");
        }
        for (id, expected) in &original_func.dfg.ext_funcs {
            let actual = parsed[0].dfg.ext_funcs[id].signature;
            if parsed[0].dfg.signatures[actual] != original_func.dfg.signatures[expected.signature]
            {
                bail!("signature adaptation changed signature");
            }
            parsed[0].dfg.ext_funcs[id].signature = expected.signature;
        }
        parsed[0].dfg.signatures = original_func.dfg.signatures.clone();
        if parsed[0].to_string() != original {
            bail!("signature adaptation changed IR");
        }
    }
    std::fs::write(
        directory.join(format!("{}.lean.clif", stem(index))),
        adapted,
    )?;
    Ok(())
}

pub(crate) fn write_rejection(
    directory: &Path,
    index: usize,
    func: &Function,
    error: Option<String>,
) -> Result<()> {
    std::fs::write(
        directory.join(format!("{}.rejection.json", stem(index))),
        serde_json::to_vec_pretty(
            &json!({"index":index,"name":func.name.to_string(),"rejected":error.is_some(),"error":error}),
        )?,
    )?;
    Ok(())
}

pub(crate) fn write_code(
    directory: &Path,
    index: usize,
    func: &Function,
    code: &CompiledCode,
    isa: &dyn TargetIsa,
) -> Result<()> {
    std::fs::write(
        directory.join(format!("{}.bin", stem(index))),
        code.code_buffer(),
    )?;
    let relocs: Vec<_> = code.buffer.relocs().iter().map(|r| {
        let (name, addend) = match &r.target {
            FinalizedRelocTarget::ExternalName(name) => (name.display(Some(&func.params)).to_string(), r.addend),
            FinalizedRelocTarget::Func(offset) => (func.name.to_string(), r.addend + i64::from(*offset)),
        };
        json!({"offset":r.offset,"kind":format!("{:?}",r.kind),"target":name.trim_start_matches('%'),"addend":addend})
    }).collect();
    let traps: Vec<_> = code
        .buffer
        .traps()
        .iter()
        .map(|t| json!({"offset":t.offset,"code":t.code.to_string()}))
        .collect();
    let unwind = code.create_unwind_info(isa)?;
    let mut exceptions = wasmtime_unwinder::ExceptionTableBuilder::default();
    exceptions
        .add_func(0, code.buffer.call_sites())
        .map_err(|e| anyhow!("{e:?}"))?;
    let metadata = json!({"index":index,"name":func.name.to_string(),"alignment":code.buffer.alignment.max(isa.function_alignment().minimum).max(isa.symbol_alignment() as u32),
        "relocations":relocs,"traps":traps,"unwind":format!("{unwind:?}"),
        "exception_call_sites":format!("{:?}",code.buffer.call_sites().collect::<Vec<_>>()),
        "exception_table_bytes":exceptions.to_vec(),"stack_maps":format!("{:?}",code.buffer.user_stack_maps()),
        "jit_allocation_performed":false,"boundary":"stock-compile-subtest"});
    std::fs::write(
        directory.join(format!("{}.json", stem(index))),
        serde_json::to_vec_pretty(&metadata)?,
    )?;
    Ok(())
}
