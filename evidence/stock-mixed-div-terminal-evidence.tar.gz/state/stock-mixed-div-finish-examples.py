from pathlib import Path
import json,os,subprocess,time,datetime
root=Path('/home/lee/clifv/.worktrees/stock-mixed-div-20261022');os.chdir(root)
env=os.environ.copy();env.update(json.load(open('/tmp/stock-mixed-div-env.json')));env.update(FV_MEMCAP='8G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',CARGO_BUILD_JOBS='2')
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head=='1239f8bcda9fac6ba6e421ab6cfb210ac3ce6677'
state={'head':head,'state':'running','steps':[]};dest=Path('/tmp/stock-mixed-div-finish-gates.json')
def save():
 state['utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();dest.write_text(json.dumps(state,indent=2)+'\n')
def run(name,argv):
 assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head
 log=Path('/tmp/stock-mixed-div-'+name+'-runner.log');print('START',name,flush=True)
 with log.open('w') as f:p=subprocess.run(argv,env=env,stdout=f,stderr=subprocess.STDOUT)
 state['steps'].append({'id':name,'returncode':p.returncode,'log':str(log)});save()
 if p.returncode:raise RuntimeError((name,p.returncode,str(log)))
 print('PASS',name,flush=True)
def gates(name,manifest=None):
 run(name,['python3','scripts/stock-delivery-gates.py','run',manifest or '/tmp/stock-mixed-div-'+name+'-manifest.json','--root',str(root),'--out','/tmp/stock-mixed-div-'+name+'-author'])
import signal
state=json.load(open('/tmp/stock-mixed-div-finish-gates-failed-example-prerequisite.json'));state.update(state='running',previous_failure=state.pop('error'));save()
controller=1085232
try:
 gates('examples-retry1')
 state['state']='passed';save()
except BaseException as e:
 state.update(state='failed',error=repr(e));save();raise
finally:
 if Path(f'/proc/{controller}/cmdline').exists():
  os.kill(controller,signal.SIGCONT)
  p=Path('/tmp/stock-mixed-div-example-drain.json');r=json.loads(p.read_text());r['resumed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();p.write_text(json.dumps(r,indent=2)+'\n')
