A returned division/remainder after a scalar computation now enters the proved default Stock route. This extends #512 to any previously proved scalar prefix followed by returned `sdiv`/`udiv`/`srem`/`urem`, including original zero/overflow traps and constant divisors.

The source checker derives the universal return-and-trap domain from actual retained records, result bindings and guarded original-source execution. Original operands, unused/stack arguments, slots, old theorem variants and shipped selectors remain. Shared fixture input data avoids importing another executable's entrypoint. This PR is directly based on main `ef499aca` and independent of performance #513.

Current author evidence at `1239f8bc`:

- All 106 affected normal targets and 1,599 imported modules pass; ownership/audit imports also pass normal keys for 1,629 modules. All 96 pipeline configurations and 96 source observations pass on unchanged proof inputs.
- All 15 affected trust audits / 483 roots pass; all 456 previous required axiom sets and 13 old public headers are exact. One bundled domain review reports standard axioms and no warnings. Core ownership: 6,224 standard-only constants / 1,126 fixed-witness constants with the exact declared facts; executable audits continue.
- Actual 24 native objects / 6,192 Lean-byte executions / 1,548 Cranelift references, zero failures/disagreements. Both real allocators and missing-oracle/whole-attempt fallback controls pass. Original 21 functions and 13 native grids retained, eight mixed functions added; safe division roots 790/791 observed.
- All 32 actual mixed CLI/checker/link/generated-proof checks pass, including 12 generated roots and 54 linked artifact hashes. The outer reporter initially expected the wrong receipt folder after exit0; original failed report is retained and every actual source/tool/output/log hash was separately validated without rerunning the successful cohort.

Before merge: finish executable ownership, retained division consumers, runtime/encoder/both E2E identity-and-stage reports, original retained artifacts and verified examples. These are running serially within the shared 16 GiB/two-build budget. GitHub's comparison run cancelled at its 30-minute limit and is not counted as a pass; follow the plan's author-gate and continuous-main discipline.

Source and partial evidence are remotely backed at `385dc1fc` (1,786 files, SHA256 `bd71724d66b05d591534ca7c1a192bb77dbf9f2d5fb4b4243421d0e988ffc4e1`). Final source-bound evidence will replace pending results before squash merge. Earlier failed attempts and actual source heads remain preserved.

Full #140 remains active: arbitrary-position/undemanded/sunk division, original widths/ABIs/effects/control/calls, source/block/whole-driver simulation and Stock-only/downstream completeness. Legacy fallback does not establish Stock completeness.
