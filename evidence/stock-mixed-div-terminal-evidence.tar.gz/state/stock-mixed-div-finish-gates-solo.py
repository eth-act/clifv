from pathlib import Path
import json,os,subprocess,time,datetime
root=Path('/home/lee/clifv/.worktrees/stock-mixed-div-20261022');os.chdir(root)
env=os.environ.copy();env.update(json.load(open('/tmp/stock-mixed-div-env.json')));env.update(FV_MEMCAP='8G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',CARGO_BUILD_JOBS='2')
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head=='1239f8bcda9fac6ba6e421ab6cfb210ac3ce6677'
state={'head':head,'state':'running','steps':[]};dest=Path('/tmp/stock-mixed-div-finish-gates.json')
def save():
 state['utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();dest.write_text(json.dumps(state,indent=2)+'\n')
def run(name,argv):
 assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head
 log=Path('/tmp/stock-mixed-div-'+name+'-runner.log');print('START',name,flush=True)
 with log.open('w') as f:p=subprocess.run(argv,env=env,stdout=f,stderr=subprocess.STDOUT)
 state['steps'].append({'id':name,'returncode':p.returncode,'log':str(log)});save()
 if p.returncode:raise RuntimeError((name,p.returncode,str(log)))
 print('PASS',name,flush=True)
def gates(name,manifest=None):
 run(name,['python3','scripts/stock-delivery-gates.py','run',manifest or '/tmp/stock-mixed-div-'+name+'-manifest.json','--root',str(root),'--out','/tmp/stock-mixed-div-'+name+'-author'])
import signal
state=json.load(open('/tmp/stock-mixed-div-finish-gates-failed-e2e-cap.json'));state.update(state='running',previous_failure=state.pop('error'));save()
drain=json.load(open('/tmp/stock-mixed-div-full-drain.json'));controller=drain['controller_pid']
try:
 for child in drain['children']:
  while Path(f'/proc/{child}/stat').exists():
   stat=Path(f'/proc/{child}/stat').read_text().split(') ')[1].split()[0]
   if stat=='Z':break
   time.sleep(3)
 gates('full-solo')
 p=json.load(open('/tmp/stock-mixed-div-scope.json'))
 run('retained-flat',['python3','/tmp/stock-div-release-retained-flat-multiply.py','/tmp/stock-mixed-div-retained-flat'])
 old=json.load(open('/tmp/stock-div-current-examples-manifest.json'));old.update(packet='mixed-div-verified-examples',base=p['base'],candidate=head,env={k:v for k,v in env.items() if k in json.load(open('/tmp/stock-mixed-div-env.json')) or k in ['FV_MEMCAP','OMP_NUM_THREADS','OMP_THREAD_LIMIT','LEAN_NUM_THREADS','CARGO_BUILD_JOBS']})
 Path('/tmp/stock-mixed-div-examples-manifest.json').write_text(json.dumps(old,indent=2)+'\n');gates('examples')
 state['state']='passed';save()
except BaseException as e:
 state.update(state='failed',error=repr(e));save();raise
finally:
 if Path(f'/proc/{controller}/cmdline').exists():
  os.kill(controller,signal.SIGCONT)
  drain['resumed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();Path('/tmp/stock-mixed-div-full-drain.json').write_text(json.dumps(drain,indent=2)+'\n')
