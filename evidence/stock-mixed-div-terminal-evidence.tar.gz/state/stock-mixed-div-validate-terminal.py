from pathlib import Path
import json,subprocess,hashlib,re,datetime
root=Path.cwd();head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head=='1239f8bcda9fac6ba6e421ab6cfb210ac3ce6677'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
finish=json.load(open('/tmp/stock-mixed-div-finish-gates.json'));assert finish['head']==head and finish['state']=='passed'
assert json.load(open('/tmp/stock-mixed-div-affected-normal-check.json'))['exit']==0
subprocess.run(['python3','/tmp/stock-mixed-div-header-parity.py'],check=True)
subprocess.run(['python3','/tmp/stock-mixed-div-axiom-parity.py'],check=True)
subprocess.run(['python3','/tmp/stock-mixed-div-validate-completed-consumers.py'],check=True)
records=[]
for group in ['native','owned','retained-integration','full-solo','examples-retry1']:
 m=json.load(open('/tmp/stock-mixed-div-'+group+'-manifest.json'));assert m['candidate']==head
 out=Path('/tmp/stock-mixed-div-'+group+'-author');receipt=json.load(open(out/'receipt.json'));assert receipt['state']=='passed' and receipt['head']==head
 for g in m['gates']:
  f=out/(g['id']+'.json');r=json.load(open(f));assert r['state']=='passed' and r['returncode']==0 and r['source_head']==head
  assert sha(r['log'])==r['log_sha256']
  for p,d in r.get('outputs',{}).items():assert sha(p)==d,p
  records.append({'group':group,'gate':g['id'],'record':str(f),'record_sha256':sha(f),'log_sha256':r['log_sha256']})
f=Path('/tmp/stock-mixed-div-full-author/runtime-corpus.json');r=json.load(open(f));assert r['state']=='passed' and r['returncode']==0 and r['source_head']==head and sha(r['log'])==r['log_sha256'];records.append({'group':'full-original-runtime','gate':'runtime-corpus','record':str(f),'record_sha256':sha(f),'log_sha256':r['log_sha256']})
identities={}
for mode in ['e2e','legacy-e2e']:
 def indexed(path):
  d=json.load(open(path));m={(r['file'],r['function'],r['index']):r['stages'] for r in d['functions']};assert len(m)==len(d['functions']);return m
 now=indexed('/tmp/stock-mixed-div-full-solo-author/'+mode+'-identities.json');counts={}
 for label,path in [('original','/tmp/legacy-dead-cleanup-final-'+mode+'-identities.json'),('prior_highmul','/tmp/stock-highmul-final-full-author/'+mode+'-identities.json'),('prior_div','/tmp/stock-div-reconciled-current-full-author/'+mode+'-identities.json')]:
  before=indexed(path);assert all(now.get(k)==v for k,v in before.items()),(mode,label);counts[label]=len(before)
 identities[mode]={**counts,'current':len(now),'all_original_and_prior_identities_and_ordered_stages_preserved':True}
native=json.load(open('/tmp/stock-mixed-div-native-author/native/native-receipt.json'));assert native['state']=='passed' and native['failures']==native['disagreements']==0
flat=json.load(open('/tmp/stock-mixed-div-retained-flat/receipt.json'));assert flat['state']=='passed' and flat['source_head']==head
owned=json.load(open('/tmp/stock-mixed-div-owned-author/owned-0.json'));s=Path(owned['log']).read_text();counts=re.search(r'STOCK_MIXED_DIV_OWNED_STANDARD_CORE (\d+); FIXED_WITNESSES (\d+)',s);assert counts
ax=json.load(open('/tmp/stock-mixed-div-axiom-parity.json'));headers=json.load(open('/tmp/stock-mixed-div-header-parity.json'));assert ax['exact_required_axiom_sets_preserved'] and headers['unchanged']
part=json.load(open('/tmp/stock-mixed-div-owned/partitions.json'))
r={'state':'passed','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'validated_code_head':head,'base':'ef499acae962dbd60cd00e46c43f04c449265944','records':records,'ownership_gates':len(part['executable_owners'])+1,'owned_core_constants':int(counts[1]),'fixed_witness_constants':int(counts[2]),'exact_native_facts':len(part['exact_native_facts']),'affected_normal_targets':106,'affected_import_closure':1599,'ownership_and_audit_normal_closure':1629,'audited_roots':ax['current_roots'],'prior_exact_axiom_sets':ax['prior_roots_required'],'old_headers_exact':headers['old_public_headers'],'identities':identities,'native':{k:v for k,v in native.items() if k!='records'},'mixed_consumer_validation':json.load(open('/tmp/stock-mixed-div-consumer-evidence-validation.json')),'failed_attempts_preserved':['initial source fuel250','witness elaboration','initial duplicate executable entrypoint','outer mixed consumer wrong receipt path','audit-only missing imports','3GiB encoder/E2E scope OOMs','missing shared pinned example backend link'],'historical_evidence':'Earlier full library/crates gates retain original source heads; not relabelled current','full_140_complete':False,'next':'Continue arbitrary-position/undemanded/sunk division, remaining original widths/ABIs, control/effects/calls, source/block/whole-driver simulation and Stock-only/downstream completeness.'}
Path('/tmp/stock-mixed-div-terminal-validation.json').write_text(json.dumps(r,indent=2)+'\n');print('PASSED',head,'records',len(records),'ownership',r['ownership_gates'],'core',counts[1],'witness',counts[2],flush=True)
