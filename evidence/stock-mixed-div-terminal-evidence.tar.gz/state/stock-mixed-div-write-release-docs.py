from pathlib import Path
import json,datetime,subprocess
r=json.load(open('/tmp/stock-mixed-div-terminal-validation.json'));b=json.load(open('/tmp/stock-mixed-div-terminal-backup.json'));assert r['state']=='passed' and b['state']=='remote_verified' and r['validated_code_head']==b['validated_code_head']==subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
text=f'''# Stock scalar-prefix division production activation

Previously proved scalar computations followed by a returned signed/unsigned
i32/i64 division or remainder now use the proved default Stock compiler,
checker, linker and generated-proof consumers. Original zero/overflow/remainder
outcomes, arbitrary arguments, unused/stack arguments and slots are preserved.
Generic source bridges retain all original widths. Old pure and singleton
selectors, theorem variants, input conditions and required axioms remain.

Seven generic modules derive actual record retention/result binding, quiet
source positions alongside colored division, successful source execution and
real traps, scan/body/entry composition and the universal Scalar.Domain.
The fixed source checker derives this domain internally. No successful Stock
run is promoted into a lowering-completeness theorem.

Validated implementation `{r['validated_code_head']}` is directly based on
main `{r['base']}`. It is independent of import-refactoring PR #513.
The release documentation changes only documentation; records keep their actual
source heads. Full original #140 remains unfinished.

Current author evidence:

- All106 affected normal targets /1599 imported modules pass. The additional
  ownership/audit import closure of1629 modules also has current normal keys.
- Fifteen checked-in audits cover{r['audited_roots']}roots. All{r['prior_exact_axiom_sets']}
  previous required axiom sets and{r['old_headers_exact']}old public headers are exact.
  One bundled domain review reports standard axioms and no warnings.
- All{r['ownership_gates']}ownership partitions pass: {r['owned_core_constants']}
  standard-only core constants, {r['fixed_witness_constants']}fixed-witness constants,
  exactly{r['exact_native_facts']}declared native facts. Generic compiler roots use
  standard axioms only.
- Complete96 pipeline configurations and96 executable source observations cover
  six ABIs, two widths and both cleanup modes. Actual safe signed-divisor root
  IDs790/791 are observed. Both real allocators, forced whole-attempt fallback
  and missing-oracle negative controls pass.
- Native24objects /6192 Lean-byte executions /1548 Cranelift reference executions,
  zero failures/disagreements. Original21functions and13 native grids retained,
  eight mixed functions added.
- Current mixed and retained singleton-division consumer cohorts each pass32
  checks. The mixed cohort includes12generated roots and54linked-artifact hashes.
  Original flat-multiply source and executable bytes remain intact and pass
  current proof reconstruction.
- Runtime, encoder, both E2E identity/stage reports and both verified default-linked
  examples pass. The reports preserve every original1150 and prior1159 function
  identity and ordered successful stage, in both cleanup modes.

Remote complete evidence: `{b['backup_commit']}`, branch `{b['backup_branch']}`.
Archive SHA256 `{b['archive_sha256']}`,
{b['archive_bytes']}bytes /{b['files']}files. Contains actual receipts, logs,
source/tool/artifact hashes, native objects, generated proofs and failed attempts.
Earlier global/crate proof runs retain their actual historical source heads;
these scoped author gates do not relabel them as a fresh full-main sweep.

The initial long source witness exhausted its inherited250fuel; only the new
witness now uses body.length+1. Witness unfolding/match and executable-entrypoint
repairs retain failed logs. The successful mixed consumer subprocess first hit
an outer wrong-receipt-folder report failure; all32actual results and every
input/output hash were separately validated without rerunning that cohort.
Audit-only missing compiled witness imports were restored through normal Lake
keys. Initial3GiB encoder/E2E attempts exceeded their scope caps; failures remain
recorded, final executable gates run at8GiB after healthy independent proofs
finish. No healthy kernel job was killed. GitHub comparison cancelled at its
30minute cap and is not counted as a pass.

Next: arbitrary-position/undemanded/sunk division and other colored effects,
remaining original widths/ABIs/control/memory/calls/exceptions, source/block/
whole-driver simulation and universal Stock-only/downstream completeness.
Fallback does not establish Stock completeness. Continue through all #140.
'''
Path('docs/research/stock-mixed-div-production-activation.md').write_text(text)
p=Path('docs/plans/stock-driver-incremental-delivery.md');s=p.read_text();a=s.index('Continue immediately with mixed scalar prefixes');z=s.index('\nA concrete build boundary',a)
s=s[:a]+'''The complete mixed scalar-prefix/final-returned division class now passes author
gates on1239f8bc, directly based on mainef499aca and independent of performance513.
[Terminal evidence](../research/stock-mixed-div-production-activation.md) records
actual source heads, full return-and-trap domain,96complete pipeline/source
witnesses,6192native comparisons, both32checkconsumer cohorts, exact previous
axiom/header/identity/stage parity and retained artifacts. Safe signed-divisor
root IDs790/791 are observed. All prior theorem variants and inputs remain.
Full140 continues immediately with arbitrary-position/undemanded/sunk division
and every original remaining obligation; no stop at this class.
'''+s[z:]
p.write_text(s)
p=Path('docs/research/stock-driver-obligations.json');x=json.loads(p.read_text());x['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
for value in ['singleton returned i32/i64 division/remainder with original traps (512,6a80a595)','scalar prefixes followed by returned i32/i64 division/remainder, source return+trap Domain and default consumers (521)']:
 if value not in x['production']['landed']:x['production']['landed'].append(value)
x['production']['pending']='Independent exact-body outcome/value import boundary513; arbitrary-position/undemanded/sunk division and other colored effects; complete original widths/ABIs/control/memory/calls/exceptions; source/block/whole-driver simulation and Stock-only/downstream completeness.'
x['production']['mixed_div_current_evidence']={'source_head':r['validated_code_head'],'receipt':'docs/research/stock-mixed-div-production-activation.md','backup':b['backup_commit'],'full_goal_complete':False}
p.write_text(json.dumps(x,indent=2)+'\n')
