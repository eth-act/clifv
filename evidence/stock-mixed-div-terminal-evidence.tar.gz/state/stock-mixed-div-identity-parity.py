from pathlib import Path
import json
result={}
for mode in ['e2e','legacy-e2e']:
 paths={'original':Path('/tmp/legacy-dead-cleanup-final-'+mode+'-identities.json'),'prior':Path('/tmp/stock-highmul-final-full-author/'+mode+'-identities.json'),'current':Path('/tmp/stock-mixed-div-full-solo-author/'+mode+'-identities.json')}
 data={k:json.loads(p.read_text()) for k,p in paths.items()}
 def records(d):
  r={(v['file'],v['function'],v['index']):v['stages'] for v in d['functions']};assert len(r)==len(d['functions']);return r
 maps={k:records(d) for k,d in data.items()};assert len(maps['original'])==1150 and len(maps['prior'])==1159
 for label in ['original','prior']:
  assert all(maps['current'].get(k)==v for k,v in maps[label].items()),(mode,label)
 result[mode]={'original':len(maps['original']),'prior':len(maps['prior']),'current':len(maps['current']),'all_original_and_prior_identities_and_ordered_stages_preserved':True,'paths':{k:str(v) for k,v in paths.items()}}
Path('/tmp/stock-mixed-div-identity-stage-parity.json').write_text(json.dumps(result,indent=2));print(result)
