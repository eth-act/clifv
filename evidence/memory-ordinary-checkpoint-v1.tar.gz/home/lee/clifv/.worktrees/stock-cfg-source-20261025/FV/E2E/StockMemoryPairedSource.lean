import FV.Backend.Proof.StockMemoryAutoScan
import FV.Backend.Proof.StockMemoryPairedRecord
import FV.E2E.PairDriverU

namespace E2E.StockMemory
open Backend Backend.Stock Backend.Proof Backend.Proof.Driver Backend.Stock.Proof Backend.Stock.Memory Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000

/-- Pair the real source step with one exact post-register file under guarded
reads. Existing source transfer supplies both original-frame postconditions;
semantic inclusion transfers the guarded executions without re-proving the
single-world DFG, demand, frame or result-binding arguments. -/
theorem stock_lower_load_paired_source_step {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    {event : BlockScanEvent} {record : ScanRecord}
    (events : event ∈ result.blockScans.toList) (records : record ∈ event.output.records)
    {bi j : Nat} {b : Clif.Block} {stm : Clif.Stmt}
    (block : f.blocks[bi]? = some b) (statement : b.body[j]? = some stm)
    (current : record.inst = blockStart f bi+j)
    {info : IInfo} {z a x nreg : Nat} {flags : Clif.MemFlags}
    (source : event.ctx.insts[record.inst]? = some info)
    (clif : info.clif = some (.load .load .i32 flags x 0)) (results : info.results = [z])
    (statementResults : stm.results = [z]) (mapped : event.ctx.valueReg? z = some (.vreg a .int))
    (parameter : event.ctx.defInst? x = none) (pointer : event.ctx.valueReg? x = some (.vreg nreg .int))
    {step : Step} (recorded : record.output.step = some step) (emitted : step.decision = .emitted)
    {F Rd : BitVec 64 → Prop} {sb : Nat} {syms : String → Option Nat} {isem isemG : Backend.Proof.Sem}
    {MR : MemRelT} (stable : MRStable F MR) (memorySem : MemRefines F sb syms isem)
    (memoryOk : MemRelOk F sb syms f MR)
    (guardedMemory : MemRefinesR Rd F sb syms isemG)
    (subGuarded : ∀ i us w r,isemG i us w = some r → isem i us w = some r)
    {fr fr' : Clif.Frame} {ρ : Nat → CV} {cm cm' : Clif.Mem} {w w' : Arm.ArmState}
    (memory : MR fr.slots cm w) (otherMemory : MR fr.slots cm w') (reads : InitIn Rd cm)
    (dfg : DFGCons event.ctx (restrict fr (availOf f (availIn f result.ctx) bi j)))
    (held : ValuesHeld (fun y => Demanded record.output.state y ∧
      y ∈ availOf f (availIn f result.ctx) bi j) event.ctx fr (fun k => ρ (aliasNum result.final.alias k)))
    {env : Clif.Env} {cp : Clif.Program}
    (sourceStep : SourceInstResult env cp event.ctx record.inst (fr,cm) (fr',cm')) :
    ∃ (v : Clif.Val) (ρ' : Nat → CV) (t t' : Arm.ArmState),
      Clif.evalInst fr cm (.load .load .i32 flags x 0) = .ok ([v],cm') ∧
      seqRun isemG (record.output.emitted.toList.map (·.mapRegs
        (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1)))) ρ w = some (.fall ρ' t) ∧
      seqRun isemG (record.output.emitted.toList.map (·.mapRegs
        (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1)))) ρ w' = some (.fall ρ' t') ∧
      SameWorld F t w ∧ SameWorld F t' w' ∧ MR fr'.slots cm' t ∧ MR fr'.slots cm' t' ∧
      VHolds v (ρ' record.input.base.nextVreg) ∧
      ValuesHeld (fun y => Demanded record.input y ∧
        y ∈ availOf f (availIn f result.ctx) bi (j+1)) event.ctx fr'
        (fun k => ρ' (aliasNum result.final.alias k)) := by
  obtain ⟨v,baseRegs,baseWorld,evaluated,baseRun,baseSame,baseMemory,value,post⟩ :=
    stock_lower_load_source_step_auto run scope dominated events records block statement current
      source clif results statementResults mapped parameter pointer recorded emitted
      stable memorySem memoryOk memory dfg held sourceStep
  obtain ⟨otherValue,otherRegs,otherWorld,otherEval,otherRun,otherSame,otherMemory',otherValueHeld,otherPost⟩ :=
    stock_lower_load_source_step_auto run scope dominated events records block statement current
      source clif results statementResults mapped parameter pointer recorded emitted
      stable memorySem memoryOk otherMemory dfg held sourceStep
  have selectedId := stock_lower_load_i32_selected_id run scope events records source clif recorded emitted
  have needed := stock_lower_load_operand_coverage run scope dominated events records block statement current
    source clif results mapped parameter pointer recorded emitted selectedId
  have restrictedGet : (restrict fr (availOf f (availIn f result.ctx) bi j)).get x = fr.get x := by
    simp only [Clif.Frame.get,restrict_regs_of_mem needed.2]
  have restrictedEval : Clif.evalInst (restrict fr (availOf f (availIn f result.ctx) bi j)) cm
      (.load .load .i32 flags x 0) = .ok ([v],cm') := by
    simpa only [Clif.evalInst,restrictedGet] using evaluated
  have restrictedHeld : ValueHeld event.ctx (restrict fr (availOf f (availIn f result.ctx) bi j))
      (fun k => ρ (aliasNum result.final.alias k)) x := by
    intro val lookup
    rw [restrict_regs_of_mem needed.2] at lookup
    exact held x needed val lookup
  obtain ⟨pairedRegs,t,t',first,second,same,otherSame'⟩ := stock_lower_load_paired_record
    run scope dominated events records source clif results mapped parameter pointer recorded emitted
    guardedMemory memoryOk memory otherMemory reads dfg restrictedHeld restrictedEval
  have firstBase := seqRun_sub subGuarded _ _ _ _ first
  have secondBase := seqRun_sub subGuarded _ _ _ _ second
  obtain ⟨fileEq,worldEq⟩ := SeqEnd.fall.inj (Option.some.inj (baseRun.symm.trans firstBase))
  obtain ⟨otherFileEq,otherWorldEq⟩ := SeqEnd.fall.inj (Option.some.inj (otherRun.symm.trans secondBase))
  refine ⟨v,pairedRegs,t,t',evaluated,first,second,same,otherSame',?_,?_,?_,?_⟩
  · rw [← worldEq]; exact baseMemory
  · rw [← otherWorldEq]; exact otherMemory'
  · rw [← fileEq]; exact value
  · rw [← fileEq]; exact post

end E2E.StockMemory
