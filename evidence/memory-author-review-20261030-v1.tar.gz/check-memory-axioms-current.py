from pathlib import Path
import re,json,subprocess
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');e=Path('/home/lee/clifv/.git/agent-evidence/stock-memory-20261029')
def ax(p):
 text=p.read_text();r={n:sorted(x.strip() for x in a.split(',') if x.strip()) for n,a in re.findall(r"'([^']+)' depends on axioms: \[([^\]]*)\]",text)};r.update({n:[] for n in re.findall(r"'([^']+)' does not depend on any axioms",text)});return r
old=ax(e/'historical-root/tmp/stock-memory-production-normal-gates-v1/all-axioms/stock-memory-source.log');new=ax(e/'author-normal-gates-v1/all-axioms/stock-memory-source.log');assert len(old)==103
assert all(new.get(n)==a for n,a in old.items()),{n:[a,new.get(n)] for n,a in old.items() if new.get(n)!=a}
std={'propext','Classical.choice','Quot.sound'};native={n:a for n,a in new.items() if not set(a)<=std};assert set(native)=={'E2E.StockMemoryEffectKernel.source_checked','E2E.StockMemoryActivationWitness.default_memory_route_witness'}
r=dict(state='passed',head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),old_roots=len(old),current_roots=len(new),all_old_memory_axiom_sets_exact=True,standard_only=len(new)-len(native),fixed_native_witnesses=native)
(e/'memory-axiom-parity-current.json').write_text(json.dumps(r,indent=2)+'\n');print('MEMORY_AXIOM_PARITY_PASS',len(old),len(new))
