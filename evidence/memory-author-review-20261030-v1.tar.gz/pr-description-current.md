An original parameter-pointer load/return can be lowered by Stock but could not pass the existing pure/ABI-read consumers. This adds a proved memory route to the default compiler, semantic checker, verified linker and generated proofs, with the previous complete pipeline retained as fallback.

The source class is one original block containing a nontrapping i32 load at offset zero followed by returning that result; entry arguments occupy registers. Original source and actual Stock construction derive the retained load, fresh result/final alias, guarded source execution, canonical shared ABI-entry virtual file and complete return. The existing source/world memory relation supplies initialized-read agreement. No input certificate or new global heap premise is introduced.

The route appends index12, keeps indices0–11, and retries the full earlier pipeline after allocation/layout failures. A general compatibility theorem preserves exactly the earlier monadic pipeline on programs outside the optional selector. The current CraneliftInput allocator path, frame-aware consumers, typed dispatch and placement shortcuts are reused.

This batch carries Kev's exact published #756 fix (original e1d0be7e, with author preserved), which marks three private StockBlockScan witness definitions noncomputable and prevents the #750 linker startup panic. The dependency was coordinated in #140.

Validation is still running on frozen6e4ae6f6. Do not publish this preparatory description as a merge-ready claim. Earlier targeted port0a5c7eb5 on c533c22a passed1711modules and105memory audit roots:103standard-only,2existing annotated fixed witnesses. Current full author receipts, identity/stage parity, native and verified-byte bindings will replace this paragraph before publication.

Full #140 remains open. Captured two-block/nop loads, broader addressing/effects/atomics/calls/control and original-domain whole-driver/Stock-only/downstream completeness follow this delivery. No corpus agreement gain is claimed for the first source class.
