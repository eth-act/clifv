from pathlib import Path
import subprocess,json,re,hashlib,datetime
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');e=Path('/home/lee/clifv/.git/agent-evidence/stock-memory-20261029')
prior=json.loads((e/'historical/stock-memory-production-header-parity-v1.json').read_text())
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True)
def header(source,name):
 matches=list(re.finditer(r'(?m)^(?:(?:noncomputable|protected) )?(?:theorem|lemma|def|abbrev) '+re.escape(name)+r'(?=\s|\{|\()',source));assert len(matches)==1,(name,len(matches))
 start=matches[0].start();i=start;depth=0;quote=False;comment=0
 while i<len(source):
  two=source[i:i+2];c=source[i]
  if comment:
   if two=='/-':comment+=1;i+=2;continue
   if two=='-/':comment-=1;i+=2;continue
   i+=1;continue
  if quote:
   if c=='\\':i+=2;continue
   if c=='"':quote=False
   i+=1;continue
  if two=='/-':comment=1;i+=2;continue
  if two=='--':i=source.find('\n',i);assert i>=0;continue
  if c=='"':quote=True;i+=1;continue
  if c in '([{⟨':depth+=1
  if c in ')]}⟩':depth-=1
  if depth==0 and two==':=':return source[start:i].strip()
  i+=1
 raise AssertionError(('no declaration body',name))
results={}
for key in prior['headers']:
 path,name=key.rsplit(':',1);old=header(git('show',prior['base']+':'+path),name);now=header((root/path).read_text(),name);assert old==now,(key,old,now);results[key]=hashlib.sha256(now.encode()).hexdigest()
# The initial memory packet's theorem variants remain byte-for-byte except for
# the value-semantics adapter repair (whose existing public headers are checked).
changed=[]
for path in git('diff','--name-only','3753d98a','HEAD','--','FV/Backend/Proof/StockMemory*.lean','FV/E2E/StockMemory*.lean').splitlines():
 old=subprocess.run(['git','show','3753d98a:'+path],cwd=root,text=True,capture_output=True)
 if old.returncode:continue
 current=(root/path).read_text()
 for name in re.findall(r'(?m)^(?:theorem|lemma)\s+(\S+)',old.stdout):
  a=header(old.stdout,name);b=header(current,name);assert a==b,(path,name,a,b);changed.append(path+':'+name)
r=dict(state='passed',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),head=git('rev-parse','HEAD').strip(),old_shared_headers_exact=len(results),shared_headers=results,modified_preserved_memory_headers_exact=changed,scope='Exact declaration headers including all binder defaults; bodies and axiom sets are verified separately by kernel builds/audits.')
(e/'public-header-parity-current.json').write_text(json.dumps(r,indent=2)+'\n');print('PUBLIC_HEADER_PARITY_PASS',len(results),len(changed))
