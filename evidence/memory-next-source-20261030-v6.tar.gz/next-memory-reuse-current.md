Next-batch source note (not validation):
- Reuse existing Backend.Stock.Proof.MaskBody.actual_nop_record_at_block in StockMaskBlockRecords. The older saved StockMemoryNopRecords draft duplicates it and is superseded; preserve archive but do not install duplicate.
- StockMemoryRetainedReturnSpec draft derives arbitrary-index returned load and classifies every real body record as that load or an actual omitted NOP. It reuses returned-definition demand and unique source positions, with inherited parameter pointer support. Must build and witness after current frozen gates release lanes.
- StockMemoryOmittedPairedScan draft composes existing one-world omission in both initialized worlds. Must build/witness before using.
- These are internal derivations, not external accepted-input premises. Next compose guarded/paired body, entry jump/inherited values, return and actual captured PC0 witness, then provider/checker/production/full gates. Old theorem variants remain.
- Current memory author HEAD remains6e4; no tracked edits or current production class expansion while gates run.

Prepared StockMemoryNopReturnBody and StockMemoryNopPairedBody compose those actual records through the existing ScansSpec fall_refines. Both are UNVALIDATED drafts and must receive actual captured non-vacuity/PC0 witnesses and compiled axiom checks after the frozen batch. No production coverage claim.

CFG boundary found on revision6e4:
- `Control.jump_body_returns_at` requires `MaskBody.Family` in every original block.
- `Inherited.scalar_jump_carry_returns_defined` also requires `CastComplete.MemoryFormat` in every block.
- `CastComplete.MemoryFormat` excludes both LoadNoOffset and Load. A captured memory successor cannot satisfy it.
- Do not try to satisfy this premise with an extra source assumption.
- `Inherited.jump_continuation_defined` is public and supports an independently proved body.
- `Inherited.local_jump_carry_returns_defined` is private. Its body uses the local source execution and the public jump continuation.
- Add an internal ordinary-body composition variant that reuses that continuation. Derive the entry NOP execution from actual omitted records.
- `OrdinaryBody.actual_ordinary_return_refines_at` already supports memory bodies, but yields RunOkABI. The CFG uses RunOkABIAt with per-successor arguments.
- Add the corresponding per-successor variant while retaining the old public theorem.

Prepared StockMemoryCfgReturnRefinesAt.lean from the existing ordinary return composition. It uses the existing per-successor fall, return-record, and prefix theorems. It retains source memory effects and old public variants. Compile it and add the captured return witness before use. The draft remains unvalidated and outside frozen6e4.

Prepared StockMemoryCfgJumpDefined.lean. It reuses the existing local jump body without imposing MemoryFormat on the memory successor. The existing public jump continuation proves its jump, inherited source values, and source definedness. The draft remains unvalidated. The captured entry must derive its bodyRefines premise from actual omitted NOP records. No accepted input condition changes.

Prepared StockMemoryCfgJumpReturnAt.lean. It retains the actual successor demand, copy, definedness, placement, and continuation proof. It replaces the global scalar family with an internal proved entry body. All old public theorem variants remain unchanged. The draft still needs Lean validation and a captured non-vacuity witness.

Prepared StockMemoryNopBody.lean. It derives the entry body directly from actual omitted NOP records. It needs only local NOP syntax, original scope/dominance, and successful Stock execution. It does not exclude memory in the successor. Its guarded body result supplies the internal local jump proof after the empty carry relation is discharged. The draft remains unvalidated.

Prepared StockMemoryNopPairedPrelude.lean. It derives the entry NOP body in both worlds from the paired omission proof and actual scans. Both worlds retain their original memory relation and one shared virtual register file. This draft also remains unvalidated and excluded from frozen6e4.
