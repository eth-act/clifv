from pathlib import Path
import os,json,subprocess,time,signal,hashlib,datetime,shutil
root=Path('/home/lee/clifv/.worktrees/stock-mixed-div-20261022');pid=3509078;proc=Path('/proc')/str(pid);birth=(proc/'stat').read_text().split()[21]
e=os.environ.copy();e.update(json.load(open('/tmp/stock-mixed-div-env.json')));e['FV_MEMCAP']='1G';cache=Path(e['FV_LAKE_CACHE']);events=[]
report=Path('/tmp/stock-general-div-ci604-extra-worker.json');base=Path('/sys/fs/cgroup/user.slice/user-30034.slice/user@30034.service/clifv.slice')
def note(**x):
 x['utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();events.append(x);report.write_text(json.dumps(events,indent=2)+'\n');print(json.dumps(x),flush=True)
def live():
 try:s=(proc/'stat').read_text().split();return s[21]==birth and s[2]!='Z'
 except FileNotFoundError:return False
def reservation():
 n=0
 for cg in base.glob(f'fvb-{pid}-*.scope'):
  try:
   if (cg/'cgroup.procs').read_text().strip():n+=int((cg/'memory.max').read_text())
  except FileNotFoundError:pass
 return n
held=False
def interrupted(sig,frame):raise SystemExit(128+sig)
signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGINT,interrupted)
try:
 while live():
  if reservation()<=15*1024**3:
   assert (proc/'cwd').resolve()==root
   assert b'scripts/lake-serial-build.py' in (proc/'cmdline').read_bytes()
   os.kill(pid,signal.SIGSTOP);held=True;time.sleep(.1)
   if reservation()<=15*1024**3:break
   os.kill(pid,signal.SIGCONT);held=False
  note(action='waiting_for_1GiB_maintenance_headroom',scheduler=pid,reserved_bytes=reservation());time.sleep(30)
 else:note(action='deferred_scheduler_finished_no_import');raise SystemExit(0)
 note(action='maintenance_started_dispatch_held_compilers_untouched',reserved_bytes=reservation())
 evidence=Path('/tmp/stock-general-div-ci-map-evidence');evidence.mkdir(exist_ok=True)
 for shard in [6,7,4,3,0,5,9,8]:
  stage=f'stage-w1-{shard}';dest=Path('/tmp/stock-general-div-ci604-extra-'+stage);dest.mkdir(exist_ok=True)
  log=Path('/tmp/stock-general-div-ci604-extra-'+stage+'.log');e['FV_MEMCAP_STATS']=str(log)+'.mem'
  with log.open('w') as f:
   subprocess.run(['scripts/memcap.sh','gh','run','download','39972864764','--name',stage,'--dir',str(dest)],cwd=root,env=e,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=180)
   maps=list(dest.rglob('outputs.jsonl'));assert maps
   for mapping in maps:
    entries=[json.loads(x) for x in mapping.read_text().splitlines()][1:];assert all((mapping.parent/a[1]).is_file() for a in entries)
    subprocess.run(['scripts/memcap.sh','lake','cache','unstage',str(mapping.parent)],cwd=root,env=e,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=60)
    rows=[]
    for key,name in entries:
     a=mapping.parent/name;b=cache/'artifacts'/name
     h=hashlib.sha256(a.read_bytes()).hexdigest();assert b.is_file() and hashlib.sha256(b.read_bytes()).hexdigest()==h
     rows.append({'key':key,'artifact':name,'sha256':h})
    shutil.copy2(mapping,evidence/f'ci604-extra-w1-{shard}-outputs.jsonl')
    (evidence/f'ci604-extra-w1-{shard}-hashes.json').write_text(json.dumps(rows,indent=2)+'\n')
  size=sum(x.stat().st_size for x in dest.rglob('*') if x.is_file());shutil.rmtree(dest)
  note(action='stage_imported_verified_staging_removed',ci_run=39972864764,stage=stage,mappings=len(rows),staging_bytes_removed=size,force=False,normal_current_keys_still_required=True)
finally:
 if held and live():os.kill(pid,signal.SIGCONT);note(action='scheduler_dispatch_resumed')
