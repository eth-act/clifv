from pathlib import Path
import os,signal,json,subprocess,datetime,time,hashlib,shutil
root=Path('/home/lee/clifv/.worktrees/stock-mixed-div-20261022');oldpid=1681039;birth='250455554';proc=Path('/proc',str(oldpid));paused=False;stopped=False;dest=Path('/tmp/stock-general-div-v4-idle-handoff');dest.mkdir(exist_ok=True);events=[]
def note(**v):
 v['utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();events.append(v);(dest/'events.json').write_text(json.dumps(events,indent=2)+'\n');print(json.dumps(v),flush=True)
def handler(sig,frame):raise SystemExit(128+sig)
signal.signal(signal.SIGTERM,handler);signal.signal(signal.SIGINT,handler)
try:
 assert (proc/'stat').read_text().split()[21]==birth
 assert b'/tmp/stock-general-div-required-tools-normal-v4' in (proc/'cmdline').read_bytes()
 h=json.loads(Path('/tmp/stock-general-div-main151-v6-handoff.json').read_text());assert h['state']=='waiting_for_existing_normal';os.kill(h['launcher_pid'],0)
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()=='cd57ac630b3846a7b7832140b7e5f195452857fc'
 os.kill(oldpid,signal.SIGSTOP);paused=True
 note(action='dispatch_paused_for_idle_boundary',old_pid=oldpid,new_waiting_launcher=h['launcher_pid'],reason='V4 already failed and source changed; preserve healthy workers and warm cache')
 seen=set()
 while True:
  subprocess.run(['python3','/tmp/stock-general-div-observe.py'],stdout=subprocess.DEVNULL,check=True);o=json.loads(Path('/tmp/stock-general-div-latest-observation.json').read_text());workers=o['workers']
  for w in workers:seen.add('FV.Backend.Proof.'+w['module'].removesuffix('.lean'))
  if not workers:break
  note(action='waiting_for_existing_compilers_only',workers=[{'pid':w['pid'],'module':w['module'],'cpu_seconds':w['cpu_seconds'],'oom_events':w['oom_events']} for w in workers]);time.sleep(20)
 # Files are now terminal and dispatch cannot truncate them for another attempt.
 evidence={}
 for module in seen:
  for suffix in ('.log','.mem','.time'):
   source=Path('/tmp/stock-general-div-required-tools-normal-v4')/(module+suffix)
   if source.exists():
    target=dest/source.name;shutil.copyfile(source,target);evidence[str(target)]=hashlib.sha256(target.read_bytes()).hexdigest()
 log=Path('/tmp/stock-general-div-main151-controller-required-tools-normal-v4.log');shutil.copyfile(log,dest/'old-controller-final-before-stop.log')
 note(action='idle_boundary_verified',live_compilers=0,terminal_artifacts_sha256=evidence,old_controller_sha256=hashlib.sha256(log.read_bytes()).hexdigest())
 assert (proc/'stat').read_text().split()[21]==birth
 os.kill(oldpid,signal.SIGTERM);os.kill(oldpid,signal.SIGCONT);paused=False;stopped=True
 note(action='failed_old_scheduler_terminated_after_workers_finished',signal='SIGTERM',healthy_compilers_stopped=0,new_validation='existing V6 launcher starts after old PID is reaped',cache_preserved=True,full_140_complete=False)
finally:
 if paused and not stopped and proc.exists() and (proc/'stat').read_text().split()[21]==birth:
  os.kill(oldpid,signal.SIGCONT);note(action='dispatch_resumed_after_interruption')
