from pathlib import Path
import os,json,time,subprocess,datetime
CURRENT_HEAD='cd57ac630b3846a7b7832140b7e5f195452857fc'
os.sched_setaffinity(0,set(range(16)))
root=Path('/home/lee/clifv/.worktrees/stock-mixed-div-20261022');e=os.environ.copy();e.update(json.load(open('/tmp/stock-mixed-div-env.json')));e['FV_MEMCAP']='8G';events=[]
def note(**row):
 row['utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();events.append(row);Path('/tmp/stock-general-div-main151-v6-trust-controller.json').write_text(json.dumps(events,indent=2)+'\n');print(json.dumps(row),flush=True)
def run(name,args):
 log=Path('/tmp/stock-general-div-main151-v6-controller-'+name+'.log');note(action='start',name=name,argv=args,log=str(log))
 with log.open('w') as f:p=subprocess.run(args,cwd=root,env=e,stdout=f,stderr=subprocess.STDOUT)
 note(action='done',name=name,exit=p.returncode)
 if p.returncode:raise SystemExit(p.returncode)
note(action='waiting_for_current_full_normal_v4')
while True:
 p=Path('/tmp/stock-general-div-normal-provenance-v6.json')
 if p.exists():
  r=json.load(p.open())
  if r['state']=='failed':note(action='current_full_normal_failed');raise SystemExit(1)
  if r['state']=='passed':
   assert r['source_head']==CURRENT_HEAD and r['source_unchanged']
   break
 time.sleep(20)
roots=Path('/tmp/stock-general-div-owned/normal-roots.txt').read_text().splitlines()
run('owned-normal',['python3','scripts/lake-serial-build.py','--budget','8G','--max-jobs','1','--max-cap','8G','--out','/tmp/stock-general-div-main151-v6-owned-normal',*roots])
for category in ['axioms','owned']:
 run(category,['python3','scripts/stock-delivery-gates.py','resume','/tmp/stock-general-div-main151-v6-'+category+'-manifest.json','--out','/tmp/stock-general-div-main151-v6-'+category+'-current'])
run('old-production-axiom-parity',['python3','/tmp/stock-general-div-axiom-parity.py','/tmp/stock-general-div-main151-v6-axioms-current/audits','/tmp/stock-general-div-main151-v6-old-axiom-parity.json'])
run('old-sink-axiom-parity',['python3','/tmp/stock-div-source-axiom-parity.py','/tmp/stock-general-div-main151-v6-axioms-current/audits/stock-no-load-sink.log','/tmp/stock-general-div-main151-v6-old-sink-axiom-parity.json'])
run('old-headers-native-cases',['python3','/tmp/stock-general-div-compatibility-main151-v6.py'])
run('shape-axioms',['scripts/memcap.sh','lake','env','lean','--root=/tmp','/tmp/stock-general-div-shape-axioms-v6.lean'])
shape_log=Path('/tmp/stock-general-div-main151-v6-controller-shape-axioms.log')
import re,hashlib
flat=shape_log.read_text().replace('\n',' ')
deps=re.findall(r"'(.+?)' depends on axioms: \[([^\]]*)\]",flat)
clean=re.findall(r"'(.+?)' does not depend on any axioms",flat)
expected={'Backend.Proof.CovT.shpStmtOkT_rule_lower_2267_f8_c7', 'Backend.Proof.CovT.shpStmtOkT_rule_lower_2267_rest', 'Backend.Proof.CovT.shpStmtOkT_rule_lower_2203', 'Backend.Proof.CovT.shpStmtOkT_rule_lower_2267_f8_n', 'Backend.Proof.CovT.shpStmtOkT_rule_lower_2280', 'Backend.Proof.CovT.shpStmtOkT_rule_lower_2267_f8_c5', 'Backend.Proof.CovT.shpStmtOkT_rule_lower_2108', 'Backend.Proof.CovT.shpStmtOkT_rule_lower_2267_f8_c4', 'Backend.Proof.CovT.shpStmtOkT_rule_lower_2267_f8_s', 'Backend.Proof.CovT.shpStmtOkT_rule_lower_2242', 'Backend.Proof.CovT.shpStmtOkT_rule_lower_2267_f8_c1', 'Backend.Proof.CovT.shpStmtOkT_rule_lower_2237', 'Backend.Proof.CovT.shpStmtOkT_rule_lower_2267', 'Backend.Proof.CovT.shpStmtOkT_rule_lower_2267_f8_c2', 'Backend.Proof.CovT.shpStmtOkT_rule_lower_2176', 'Backend.Proof.CovT.shpStmtOkT_rule_lower_2267_f8_c0', 'Backend.Proof.CovT.shpStmtOkT_rule_lower_2146', 'Backend.Proof.CovT.shpStmtOkT_rule_lower_2267_f8_c3', 'Backend.Proof.CovT.shpStmtOkT_rule_lower_2113', 'Backend.Proof.CovT.shpStmtOkT_rule_lower_2267_f8_c6', 'Backend.Proof.CovT.shpStmtOkT_rule_lower_2262'}
actual={name for name,_ in deps}|set(clean)
assert actual==expected,(actual,expected)
assert all(set(x.strip() for x in axioms.split(',') if x.strip())=={'propext','Quot.sound'} for _,axioms in deps)
Path('/tmp/stock-general-div-main151-v6-shape-axioms.json').write_text(json.dumps({'state':'passed','head':CURRENT_HEAD,'roots':len(expected),'all_axioms_standard_only':True,'exact_two_standard_axioms':True,'log':str(shape_log),'log_sha256':hashlib.sha256(shape_log.read_bytes()).hexdigest(),'source_sha256':hashlib.sha256((root/'FV/Backend/Proof/IselShpTTabS30.lean').read_bytes()).hexdigest()},indent=2)+'\n')
note(action='trust_and_compatibility_finished',full_140_complete=False)
