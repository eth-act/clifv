from pathlib import Path
import os,json,subprocess,time,datetime
root=Path('/home/lee/clifv/.worktrees/stock-mixed-div-20261022');e=os.environ.copy();e.update(json.load(open('/tmp/stock-mixed-div-env.json')));events=[]
items=[]
for pid,part in [(3509078,'stock-general-div-required-tools-normal-v2'),(3508990,'stock-general-div-consumer-controller-v2.py')]:
 p=Path('/proc')/str(pid)
 if p.exists():
  assert part in (p/'cmdline').read_bytes().replace(b'\0',b' ').decode();items.append((pid,(p/'stat').read_text().split()[21]))
def note(**r):
 r['utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();events.append(r);Path('/tmp/stock-general-div-harness-fix-controller.json').write_text(json.dumps(events,indent=2)+'\n');print(json.dumps(r),flush=True)
note(action='waiting_for_existing_full_normal_without_restart',pids=[x[0] for x in items],new_source='93257a5d711e21bae720fe44f2dd1c7494045e90',only_change='integration harness')
while True:
 live=[]
 for pid,birth in items:
  p=Path('/proc')/str(pid)
  try:s=(p/'stat').read_text().split()
  except FileNotFoundError:continue
  if s[21]==birth and s[2]!='Z':live.append(pid)
 if not live:break
 note(action='verified_wait',live_pids=live);time.sleep(45)
for name in ['consumer-controller','normal-provenance-v2']:
 p=Path('/tmp/stock-general-div-'+name+'.json')
 if p.exists():Path('/tmp/stock-general-div-'+name+'-before-harness-fix-replay.json').write_bytes(p.read_bytes())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()=='93257a5d711e21bae720fe44f2dd1c7494045e90'
note(action='start_fresh_current_source_normal_and_consumer_replay',prior_kernel_work_preserved=True)
with open('/tmp/stock-general-div-trust-controller-v3-runner.log','w') as trustlog,open('/tmp/stock-general-div-consumer-controller-v3-runner.log','w') as consumerlog:
 trust=subprocess.Popen(['python3','/tmp/stock-general-div-trust-controller-v3.py'],cwd=root,env=e,stdout=trustlog,stderr=subprocess.STDOUT)
 consumer=subprocess.Popen(['python3','/tmp/stock-general-div-consumer-controller-v3.py'],cwd=root,env=e,stdout=consumerlog,stderr=subprocess.STDOUT)
 note(action='current_controllers_live',trust_pid=trust.pid,consumer_pid=consumer.pid)
 rc=consumer.wait();note(action='consumer_done',exit=rc)
 if rc:raise SystemExit(rc)
 rc=trust.wait();note(action='trust_done',exit=rc);raise SystemExit(rc)
