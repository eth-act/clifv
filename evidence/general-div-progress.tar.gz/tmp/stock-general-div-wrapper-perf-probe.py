from pathlib import Path
import os,signal,subprocess,json,time,datetime
root=Path('/home/lee/clifv/.worktrees/stock-mixed-div-20261022');src=root/'FV/Backend/Proof/DefGenWrap.lean';text=src.read_text();text=text.replace('set_option maxRecDepth 100000','set_option maxRecDepth 100000\nattribute [local irreducible] Isle.Aarch64.program',1);probe=Path('/tmp/StockGeneralDefGenWrapPerfProbe.lean');probe.write_text(text)
items=[(1608854,'/tmp/stock-general-div-retained-normal'),(1667067,'/tmp/stock-general-div-linked-normal'),(1739839,'FV/Backend/Proof/DefGenWrap.lean')];stopped=[];e=os.environ.copy();e.update(json.load(open('/tmp/stock-mixed-div-env.json')));e['FV_MEMCAP']='3G';e['FV_MEMCAP_STATS']='/tmp/stock-general-div-wrapper-perf-probe.mem'
def sig(sig,frame):raise SystemExit(128+sig)
signal.signal(signal.SIGTERM,sig);signal.signal(signal.SIGINT,sig)
start=time.monotonic()
try:
 for pid,part in items:
  p=Path('/proc')/str(pid);assert p.exists(),pid;cmd=(p/'cmdline').read_bytes().replace(b'\0',b' ').decode();assert part in cmd,(pid,cmd);assert (p/'cwd').resolve()==root;birth=(p/'stat').read_text().split()[21];os.kill(pid,signal.SIGSTOP);stopped.append((pid,birth))
 with open('/tmp/stock-general-div-wrapper-perf-probe.log','w') as f:r=subprocess.run(['scripts/memcap.sh','timeout','55','lake','env','lean',str(probe)],cwd=root,env=e,stdout=f,stderr=subprocess.STDOUT)
 result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':r.returncode,'seconds':time.monotonic()-start,'repository_source_unchanged':src.read_text()==text.replace('\nattribute [local irreducible] Isle.Aarch64.program','',1),'original_build_preserved_and_resumed':True,'probe':str(probe),'cap':'3G','log':'/tmp/stock-general-div-wrapper-perf-probe.log'};Path('/tmp/stock-general-div-wrapper-perf-probe.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
finally:
 for pid,birth in reversed(stopped):
  p=Path('/proc')/str(pid)
  if p.exists() and (p/'stat').read_text().split()[21]==birth:os.kill(pid,signal.SIGCONT)
