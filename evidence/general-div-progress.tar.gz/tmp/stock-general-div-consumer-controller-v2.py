from pathlib import Path
import os,json,subprocess,time,tomllib,datetime
root=Path('/home/lee/clifv/.worktrees/stock-mixed-div-20261022');e=os.environ.copy();e.update(json.load(open('/tmp/stock-mixed-div-env.json')));e['FV_MEMCAP']='8G';events=[]
def note(**row):
 row['utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();events.append(row);Path('/tmp/stock-general-div-consumer-controller.json').write_text(json.dumps(events,indent=2)+'\n');print(json.dumps(row),flush=True)
def run(name,args):
 log=Path('/tmp/stock-general-div-controller-'+name+'.log');note(action='start',name=name,argv=args,log=str(log))
 with log.open('w') as f:r=subprocess.run(args,cwd=root,env=e,stdout=f,stderr=subprocess.STDOUT)
 note(action='done',name=name,exit=r.returncode)
 if r.returncode:raise SystemExit(r.returncode)
linked=Path('/tmp/stock-general-div-linked-normal.log');note(action='waiting_for_linked_normal')
while True:
 s=linked.read_text() if linked.exists() else ''
 if 'END ' in s:
  last=[x for x in s.splitlines() if 'END ' in x][-1]
  if 'END 1456/1456 ok' not in last:note(action='linked_normal_failed',line=last);raise SystemExit(1)
  break
 time.sleep(20)
config=tomllib.loads((root/'lakefile.toml').read_text());names=['lean-backend','lean-backend-armrun','lean-backend-encode-test','lean-e2e-check','link-check','lean-link','arm-fault-cosim','stock-general-div-linked','stock-returned-div-runtime','stock-returned-div-linked'];targets={x['name']:x['root'] for x in config['lean_exe']};assert all(n in targets for n in names)
run('required-tools-normal-v2',['python3','scripts/lake-serial-build.py','--budget','16G','--max-jobs','2','--max-cap','16G','--heavy','16G','--out','/tmp/stock-general-div-required-tools-normal-v2','FV','FVTest',*[targets[n] for n in names]])
cpu=str(min(os.sched_getaffinity(0)))
for name in names:
 e['FV_MEMCAP_STATS']='/tmp/stock-general-div-controller-build-'+name+'.mem'
 run('build-'+name,['scripts/memcap.sh','taskset','-c',cpu,'lake','build',name])
e.pop('FV_MEMCAP_STATS',None)
for category in ['integration','retained-integration','full','examples']:
 run(category,['python3','scripts/stock-delivery-gates.py','run','/tmp/stock-general-div-'+category+'-manifest.json','--out','/tmp/stock-general-div-'+category+'-current'])
note(action='consumer_runtime_example_gates_finished',full_140_complete=False)
