from pathlib import Path
import os,json,subprocess,time,datetime
root=Path('/home/lee/clifv/.worktrees/stock-mixed-div-20261022')
e=os.environ.copy();e.update(json.load(open('/tmp/stock-mixed-div-env.json')))
events=[]
def note(**r):
 r['utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();events.append(r);Path('/tmp/stock-general-div-full-assist-controller.json').write_text(json.dumps(events,indent=2)+'\n');print(json.dumps(r),flush=True)
note(action='waiting_for_trust_slot',purpose='Reuse freed 8GiB slot to assist full normal keys; shared dedup, no extra cache or worktree')
while True:
 try:t=json.load(open('/tmp/stock-general-div-trust-controller.json'));c=json.load(open('/tmp/stock-general-div-consumer-controller.json'))
 except (OSError,json.JSONDecodeError):time.sleep(20);continue
 if any(x['action']=='done' and x.get('exit',0) for x in t+c):note(action='upstream_failed');raise SystemExit(1)
 if any(x['action']=='done' and x.get('name')=='required-tools-normal' for x in c):note(action='full_normal_already_finished');raise SystemExit(0)
 if any(x['action']=='trust_and_compatibility_finished' for x in t):break
 time.sleep(20)
args=['python3','scripts/lake-serial-build.py','--budget','8G','--max-jobs','1','--max-cap','8G','--out','/tmp/stock-general-div-full-assist-normal','FV','FVTest']
note(action='start',argv=args)
with open('/tmp/stock-general-div-full-assist-normal.log','w') as f:r=subprocess.run(args,cwd=root,env=e,stdout=f,stderr=subprocess.STDOUT)
note(action='done',exit=r.returncode)
raise SystemExit(r.returncode)
