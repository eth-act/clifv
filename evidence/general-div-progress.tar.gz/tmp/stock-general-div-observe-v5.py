from pathlib import Path
import os,json,datetime,subprocess
root=Path('/home/lee/clifv/.worktrees/stock-mixed-div-20261022');workers=[];controllers=[]
for d in Path('/proc').glob('[0-9]*'):
 try:
  argv=(d/'cmdline').read_bytes().split(b'\0');cmd=b' '.join(argv)
  if not argv or not argv[0]:continue
  isworker=argv[0].rsplit(b'/',1)[-1]==b'lean' and b'--server' not in argv and any(x.endswith(b'.lean') and not x.startswith(b'file:') for x in argv)
  iscontroller=(b'/tmp/stock-general-div-' in cmd or b'/tmp/stock-general-div-' in cmd.replace(b'=',b' ')) and (b'controller' in cmd or b'scripts/lake-serial-build.py' in cmd or b'handoff.py' in cmd)
  if not (isworker or iscontroller):continue
  cwd=(d/'cwd').resolve()
  if isworker and not str(cwd).startswith('/home/lee/clifv'):continue
  s=(d/'stat').read_text().rsplit(')',1)[1].split();r={'pid':int(d.name),'state':s[0],'cpu_seconds':round((int(s[11])+int(s[12]))/os.sysconf('SC_CLK_TCK'),1),'rss_bytes':int(s[21])*os.sysconf('SC_PAGE_SIZE')}
  if isworker:
   r['affinity_cpus']=len(os.sched_getaffinity(int(d.name)))
   budget=Path('/tmp/stock-general-div-cpu-budget.json')
   r['within_shared_cpu_pool']=os.sched_getaffinity(int(d.name))<=set(json.load(budget.open())['shared_cpu_pool']) if budget.exists() else None
   r['module']=next(x.decode().rsplit('/',1)[-1] for x in argv if x.endswith(b'.lean') and not x.startswith(b'file:'))
   cg=Path('/sys/fs/cgroup'+(d/'cgroup').read_text().strip().split('::')[-1]);r['memory_cap']=(cg/'memory.max').read_text().strip() if (cg/'memory.max').exists() else None;r['charged_bytes']=int((cg/'memory.current').read_text()) if (cg/'memory.current').exists() else None;r['charged_peak_bytes']=int((cg/'memory.peak').read_text()) if (cg/'memory.peak').exists() else None;r['oom_events']=dict(line.split() for line in (cg/'memory.events').read_text().splitlines()) if (cg/'memory.events').exists() else {};workers.append(r)
  else:r['command']=cmd.decode().strip()[:180];controllers.append(r)
 except (FileNotFoundError,PermissionError,ProcessLookupError):pass
r={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'classification':'verified_wait' if workers or controllers else 'inspect_terminal_state','head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'workers':workers,'controllers':controllers,'full_140_complete':False};Path('/tmp/stock-general-div-latest-observation.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'utc':r['utc'],'head':r['head'],'workers':workers,'controllers':[(x['pid'],x['state']) for x in controllers]}))
p=Path('/tmp/stock-general-div-main151-v5-controller-required-tools-normal-v5.log')
if p.exists():print('v5 normal: '+' | '.join(p.read_text(errors='replace').splitlines()[-3:]))
