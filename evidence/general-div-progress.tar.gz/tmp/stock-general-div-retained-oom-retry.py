from pathlib import Path
import os,signal,subprocess,time,json,datetime
root=Path('/home/lee/clifv/.worktrees/stock-mixed-div-20261022')
items=[(1928210,'/tmp/stock-general-div-required-tools-normal'),(2139549,'FV/Opt/Proof/RuleShifts3P1.lean')];stopped=[]
e=os.environ.copy();e.update(json.load(open('/tmp/stock-mixed-div-env.json')));e['FV_MEMCAP']='10G';e['FV_MEMCAP_STATS']='/tmp/stock-general-div-retained-oom-retry.mem'
def handler(sig,frame):raise SystemExit(128+sig)
signal.signal(signal.SIGTERM,handler);signal.signal(signal.SIGINT,handler)
p=Path('/proc/2139549');cg=Path('/sys/fs/cgroup')/(p/'cgroup').read_text().split('0::',1)[1].strip().lstrip('/')
assert int((cg/'memory.current').read_text())<6*1024**3
start=time.monotonic()
try:
 for pid,part in items:
  q=Path('/proc')/str(pid);assert part in (q/'cmdline').read_bytes().replace(b'\0',b' ').decode();assert (q/'cwd').resolve()==root
  birth=(q/'stat').read_text().split()[21];os.kill(pid,signal.SIGSTOP);stopped.append((pid,birth))
 usage=int((cg/'memory.current').read_text());assert usage<6*1024**3
 with open('/tmp/stock-general-div-retained-oom-retry.log','w') as f:r=subprocess.run(['scripts/memcap.sh','lake','build','FV.Backend.Proof.StockLogicalRecordWitness'],cwd=root,env=e,stdout=f,stderr=subprocess.STDOUT,timeout=180)
finally:
 for pid,birth in reversed(stopped):
  q=Path('/proc')/str(pid)
  if q.exists() and (q/'stat').read_text().split()[21]==birth:os.kill(pid,signal.SIGCONT)
report={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'module':'FV.Backend.Proof.StockLogicalRecordWitness','prior_failure':'8GiB OOM, unchanged source','retry_cap_bytes':10*1024**3,'paused_optimizer_bytes':usage,'aggregate_reserved_bytes':usage+10*1024**3,'all_workers_resumed':True,'exit':r.returncode,'seconds':time.monotonic()-start};Path('/tmp/stock-general-div-retained-oom-retry.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report));raise SystemExit(r.returncode)
