# General scalar division production activation — pending author gates

This is a prepared receipt, not a completed activation or merge claim. It must
be finalized from current maintained-runner reports and normal provenance before
being added to the repository.

Candidate `93257a5d711e21bae720fe44f2dd1c7494045e90`, PR #611, extends the shared
Stock production selector to scalar bodies containing arbitrary numbers and
positions of signed/unsigned i32/i64 divisions and remainders. Division results
may be unused, consumed by later scalar operations, or occur in multiple-division
bodies. Old classifiers and public theorem variants remain. The source checker
derives the existing return/trap Domain through the general source-driver proof
landed in #604; the integration does not introduce a successful-lowering premise
as a Stock completeness theorem.

The complete witness grid has 288 configurations: six ABI/width combinations,
four operations, two divisor forms, three layouts and two cleanup modes. It keeps
all nine original arguments and slots. Runtime coverage retains 37 previous
functions and adds 24; both real allocators, retries/history and missing-oracle
controls remain. Linked/generated-proof fixtures exercise all three current
layouts and retained old-route controls in both cleanup modes, with exactly 32
qualified root artifacts.

## Completed evidence with original provenance

On implementation head d811c44a (before the Python-only harness correction):

- New witness normal closure: 1,184 jobs, including the complete 288-case grid.
- Linked normal closure: 1,456/1,456; owned closure: 1,811/1,811.
- Nineteen audit files, 577 public roots; 33 ownership partitions with 6,972
  standard-only core constants, 1,354 witness constants and 47 exact native facts.
- All 497 old production axiom sets and 13 old sink axiom sets exact; all 17 old
  public headers and 30 native ABI/width grids exact.
- Native execution: 24 Lean-encoded objects, 14,640 Lean-byte executions versus
  3,660 Cranelift references, zero failures and disagreements.
- Actual integration runtime and linked-fixture phases passed. The next harness
  check failed because it expected old unqualified names. The Python-only fix
  checks the exact 32 qualified roots and all three layouts; all 15 earlier class
  expected-root sets are unchanged. Failed output is retained.

One source-bound MCP review reports the standard three axioms and no warnings
for sourceOk_sound. Its original source head and module hash remain recorded;
the Python harness change does not alter that source/import closure.

## Current-source gates still required

Candidate93257 source-bound full FV/FVTest and ten required tool roots; current
native/trust/ownership and exact old parity reports; current and retained actual
CLI/checker/linker/generated-proof cohorts; runtime and encoder corpora; both E2E
reports preserving all original1,150 and prior1,159 identities and ordered stages;
original flat-multiply artifact retention; verified demo/survey; fresh-main
reconciliation; final verified remote evidence archive; exact squash-tree check.
Do not replace these requirements with narrow fixture successes.

The full normal batch is rebuilding cold unchanged optimizer and driver proofs.
All failures and retries keep their actual caps, logs and source provenance.
Comparison CI40028971816 cancelled near its30-minute limit during build531/773;
there is no comparison pass. Local normal kernels continue independently.

## Preservation and remaining original scope

One shared warm cache and the four necessary saved/active views remain. Imported
CI cache artifacts are only candidates until current input-key checks accept
them. Eight additional main604 wave1 shards were imported with3,804mapped hashes
verified;593,880,786bytes temporary staging were removed. Progress evidence is
remote at3320cd08373062d65372df0a2d5fb4c22ce221eb, explicitly not a release archive.
The saved cleanup-receipt correction must be applied after source-bound gates:
age/link count did not prove cache-key obsolescence, and the contribution of the
earlier cache purge to cold rebuilding is unmeasured.

Full original #140 remains open: all original widths/ABIs, control/successor
arguments/critical edges/block parameters/loops, memory/addressing/loads/stores/
atomics/traps/deferred effects, calls/exceptions/sret/TryCall/unwind, source/scan/
block/node/traversal/whole-driver simulation, Stock-only selection/lowering and
all downstream completeness, and production integration. Legacy fallback and
conditional Stock success do not close those obligations. After this activation,
continue implementation through the full goal without stopping at this class.
