from pathlib import Path
import subprocess,os,json,datetime
root=Path('/home/lee/clifv/.worktrees/stock-mixed-div-20261022')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()=='22aef3dfa02980e4dfcac6276ad9ec863e546a91'
os.sched_setaffinity(0,set(range(16)))
e=os.environ.copy();e.update(json.load(open('/tmp/stock-mixed-div-env.json')))
assert e['OMP_NUM_THREADS']=='2' and e['OMP_THREAD_LIMIT']=='2'
assert subprocess.check_output(['nproc'],env=e,text=True).strip()=='2'
children=[];processes=[]
for name in ['consumer-controller-v4','trust-controller-v4','final-retention-controller-v4']:
 log=Path('/tmp/stock-general-div-main151-'+name+'-runner.log')
 with log.open('w') as f:p=subprocess.Popen(['python3','/tmp/stock-general-div-'+name+'.py'],cwd=root,env=e,stdout=f,stderr=subprocess.STDOUT)
 processes.append(p)
 children.append({'name':name,'pid':p.pid,'birth':Path('/proc',str(p.pid),'stat').read_text().split()[21],'log':str(log)})
r={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':'22aef3dfa02980e4dfcac6276ad9ec863e546a91','base':'1510186e56b81e8cbb36027746414a411c8e1f37','resource_budget':'16GiB/max2compiler/shared16CPUs/onecache','effective_nproc':2,'children':children}
Path('/tmp/stock-general-div-main151-controllers.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))

for p in processes:
 rc=p.wait();print(json.dumps({"terminal_pid":p.pid,"exit":rc}),flush=True)
