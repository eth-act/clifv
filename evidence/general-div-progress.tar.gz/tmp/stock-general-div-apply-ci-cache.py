from pathlib import Path
import os,subprocess,signal,json,time,hashlib,datetime
root=Path('/home/lee/clifv/.worktrees/stock-mixed-div-20261022');dest=Path('/tmp/stock-general-div-ci-restore');e=os.environ.copy();e.update(json.load(open('/tmp/stock-mixed-div-env.json')));e['FV_MEMCAP']='1G'
controllers=[(1608854,'/tmp/stock-general-div-retained-normal'),(1667067,'/tmp/stock-general-div-linked-normal')];stopped=[];rows=[]
def handler(sig,frame):raise SystemExit(128+sig)
signal.signal(signal.SIGTERM,handler);signal.signal(signal.SIGINT,handler)
try:
 # Hold scheduler dispatch briefly; their existing capped compilers continue.
 # This reserves <=1GiB for cache copying without launching a third compiler.
 for pid,purpose in controllers:
  proc=Path('/proc')/str(pid)
  if not proc.exists():continue
  cmd=(proc/'cmdline').read_bytes().replace(b'\0',b' ').decode();assert 'scripts/lake-serial-build.py' in cmd and purpose in cmd;assert (proc/'cwd').resolve()==root
  born=(proc/'stat').read_text().split()[21];os.kill(pid,signal.SIGSTOP);stopped.append((pid,born))
 for p in sorted(dest.rglob('outputs.jsonl')):
  entries=[json.loads(x) for x in p.read_text().splitlines()][1:];assert all((p.parent/a[1]).is_file() for a in entries)
  log=Path('/tmp/stock-general-div-ci-unstage-'+p.parent.name+'.log');e['FV_MEMCAP_STATS']=str(log)+'.mem';start=time.monotonic()
  with log.open('w') as f:ret=subprocess.run(['scripts/memcap.sh','lake','cache','unstage',str(p.parent)],cwd=root,env=e,stdout=f,stderr=subprocess.STDOUT,timeout=60)
  row={'stage':p.parent.name,'mappings':len(entries),'outputs_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'exit':ret.returncode,'seconds':time.monotonic()-start,'log':str(log)};rows.append(row);print(json.dumps(row),flush=True)
  assert ret.returncode==0,log.read_text()
finally:
 for pid,born in stopped:
  proc=Path('/proc')/str(pid)
  if proc.exists() and (proc/'stat').read_text().split()[21]==born:os.kill(pid,signal.SIGCONT)
 report={'state':'cache_candidates_imported_no_gate_pass_claim','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'ci_run':39957075490,'ci_head':'de150774c6ae30063a303750daed347dac01c915','source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'one_existing_cache':e['FV_LAKE_CACHE'],'force_overwrite':False,'rows':rows,'scheduler_dispatch_resumed':True,'normal_current_key_checks_still_required':True};Path('/tmp/stock-general-div-ci-restore.json').write_text(json.dumps(report,indent=2)+'\n')
