from pathlib import Path
import os,signal,time,json,datetime
parent=Path('/proc/2297776');assert b'stock-general-div-retained-oom-retry.py' in (parent/'cmdline').read_bytes();birth=(parent/'stat').read_text().split()[21]
children=(parent/'task/2297776/children').read_text().split();assert len(children)==1,children
child=Path('/proc')/children[0];cbirth=(child/'stat').read_text().split()[21]
os.kill(2297776,signal.SIGSTOP)
print('Paused retry wrapper deadline while its healthy compiler continues; optimizer remains paused and aggregate reserved memory stays below16GiB',flush=True)
while child.exists():
 try:s=(child/'stat').read_text().split()
 except FileNotFoundError:break
 if s[21]!=cbirth or s[2]=='Z':break
 time.sleep(1)
if parent.exists() and (parent/'stat').read_text().split()[21]==birth:os.kill(2297776,signal.SIGCONT)
Path('/tmp/stock-general-div-retry-timeout-guard.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':'healthy_retry_finished_deadline_wrapper_resumed','compiler_preserved':True,'wrapper':2297776,'waited_child':children[0]},indent=2)+'\n');print('Healthy retry ended; wrapper resumed to collect actual result and restore optimizer',flush=True)
