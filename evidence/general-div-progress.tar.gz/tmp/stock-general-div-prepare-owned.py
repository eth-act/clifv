from pathlib import Path
import json,re
old=json.load(open('/tmp/stock-returned-div-owned/partitions.json'));source=json.load(open('/tmp/stock-div-source-author/partitions.json'))
sink=Path('/tmp/stock-div-sink-author/Owned.lean').read_text()
def prior_array(name):
 return json.loads('['+re.search(r'  let '+name+r' := #\[(.*)\]',sink)[1]+']')
core=list(dict.fromkeys(old['core']+source['core']+prior_array('core')+['FV.E2E.StockGeneralDivFixtures']))
witness=list(dict.fromkeys(old['witnesses']+source['witness']+prior_array('witnesses')+['FV.E2E.StockGeneralDivChecks','FV.E2E.StockGeneralDivWitness']))
owners=list(dict.fromkeys(old['executable_owners']+['FVTest.Backend.Lowering.StockGeneralDivProductionRuntime','FVTest.Backend.Lowering.StockGeneralDivProductionLinked']))
facts=sorted(set(old['exact_native_facts']+source['exact_native_facts']+prior_array('fixedFacts')+['E2E.StockGeneralDivNIWitness.checks_true._native.native_decide.ax_1']))
out=Path('/tmp/stock-general-div-owned');out.mkdir(exist_ok=True)
part={'core':core,'witnesses':witness,'executable_owners':owners,'exact_native_facts':facts};(out/'partitions.json').write_text(json.dumps(part,indent=2)+'\n')
s=Path('/tmp/stock-returned-div-owned/Owned0.lean').read_text();s=s[s.index('open Lean Elab Command'):]
for name,values in [('core',core),('witnesses',witness),('fixedFacts',facts)]:s=re.sub(r'  let '+name+r' := #\[.*\]',lambda _: '  let '+name+' := #['+', '.join(json.dumps(x) for x in values)+']',s)
s=s.replace('STOCK_RETURNED_DIV_OWNED','STOCK_GENERAL_DIV_OWNED');(out/'Owned0.lean').write_text('import Lean\n'+''.join('import '+n+'\n' for n in core+witness)+s)
for i,owner in enumerate(owners,1):
 template=Path('/tmp/stock-not-owned/Owned1.lean').read_text().replace('FVTest.Backend.Main',owner).replace('STOCK_NOT_OWNED','STOCK_GENERAL_DIV_OWNED')
 (out/f'Owned{i}.lean').write_text('import Lean\n'+template)
m=json.load(open('/tmp/stock-general-div-full-manifest.json'));m.update(packet='general-div-owned',inputs=[str(out/'partitions.json')]);m['gates']=[{'id':'owned-'+str(i),'argv':['lake','env','lean',str(out/f'Owned{i}.lean')],'requires':['STOCK_GENERAL_DIV_OWNED'],'inputs':[str(out/f'Owned{i}.lean')],'complete_inputs':False} for i in range(len(owners)+1)];Path('/tmp/stock-general-div-owned-manifest.json').write_text(json.dumps(m,indent=2)+'\n');(out/'normal-roots.txt').write_text('\n'.join(core+witness+owners)+'\n');print('PREPARED_OWNERSHIP',len(core),len(witness),len(owners),len(facts))
