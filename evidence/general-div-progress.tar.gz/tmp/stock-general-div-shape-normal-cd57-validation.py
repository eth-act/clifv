from pathlib import Path
import os,signal,json,subprocess,datetime,time,hashlib,re
os.sched_setaffinity(0,set(range(16)))
root=Path('/home/lee/clifv/.worktrees/stock-mixed-div-20261022');head='cd57ac630b3846a7b7832140b7e5f195452857fc';pid=1681039;proc=Path('/proc')/str(pid);assert 'scripts/lake-serial-build.py' in (proc/'cmdline').read_bytes().decode();birth=(proc/'stat').read_text().split()[21];paused=False;out=Path('/tmp/stock-general-div-shape-normal-cd57');out.mkdir(exist_ok=False);rows=[]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=root/'FV/Backend/Proof/IselShpTTabS30.lean';sourcehash=sha(source)
def handler(sig,frame):raise SystemExit(128+sig)
signal.signal(signal.SIGTERM,handler);signal.signal(signal.SIGINT,handler)
try:
 os.kill(pid,signal.SIGSTOP);paused=True
 while True:
  subprocess.run(['python3','/tmp/stock-general-div-observe.py'],stdout=subprocess.DEVNULL,check=True);o=json.loads(Path('/tmp/stock-general-div-latest-observation.json').read_text())
  if len(o['workers'])<=1 and sum(int(w['memory_cap']) for w in o['workers'])<=10*1024**3:break
  print(json.dumps({'state':'waiting_for_actual_slot','workers':[(w['pid'],w['module']) for w in o['workers']]}),flush=True);time.sleep(10)
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head and subprocess.run(['git','diff','--quiet','HEAD','--'],cwd=root).returncode==0
 e=os.environ.copy();e.update(json.loads(Path('/tmp/stock-mixed-div-env.json').read_text()));e.update(FV_MEMCAP='6G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2');assert subprocess.check_output(['nproc'],env=e,text=True).strip()=='2'
 commands=[('normal',['python3','scripts/lake-serial-build.py','--budget','6G','--max-jobs','1','--max-cap','6G','--out',str(out/'normal'),'FV.Backend.Proof.IselShpTTabS30']),('axioms',['scripts/memcap.sh','taskset','-c','14','lake','env','lean','--root=/tmp','/tmp/stock-general-div-shape-axioms-v5.lean'])]
 for name,args in commands:
  log=out/(name+'.log');e['FV_MEMCAP_STATS']=str(out/(name+'.mem'));start=time.monotonic()
  with log.open('w') as f:p=subprocess.run(args,cwd=root,env=e,stdout=f,stderr=subprocess.STDOUT)
  row={'name':name,'argv':args,'exit':p.returncode,'seconds':time.monotonic()-start,'log':str(log),'log_sha256':sha(log)};rows.append(row);print(json.dumps(row),flush=True)
  if p.returncode:break
 if len(rows)==2 and all(x['exit']==0 for x in rows):
  flat=(out/'axioms.log').read_text().replace('\n',' ');deps=re.findall(r"'(.+?)' depends on axioms: \[([^\]]*)\]",flat);clean=re.findall(r"'(.+?)' does not depend on any axioms",flat);expected={'Backend.Proof.CovT.'+x for x in re.findall(r'^theorem\s+(\w+)\s*:',source.read_text(),re.M)}
  assert len(expected)==21 and ({name for name,_ in deps}|set(clean))==expected
  assert all({x.strip() for x in axioms.split(',') if x.strip()}=={'propext','Quot.sound'} for _,axioms in deps)
  assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head and sha(source)==sourcehash
  (out/'axiom-sets.json').write_text(json.dumps({'roots':{**{name:sorted(x.strip() for x in axioms.split(',') if x.strip()) for name,axioms in deps},**{name:[] for name in clean}}},indent=2)+'\n')
finally:
 if paused and proc.exists() and (proc/'stat').read_text().split()[21]==birth:os.kill(pid,signal.SIGCONT)
 receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'source_sha256':sourcehash,'state':'affected_normal_and_shape_axioms_passed' if len(rows)==2 and all(x['exit']==0 for x in rows) and (out/'axiom-sets.json').exists() else 'affected_validation_failed_or_incomplete','commands':rows,'scheduler_dispatch_resumed':True,'existing_compiler_not_stopped':True,'whole_normal_or_activation_passed':False,'full_140_complete':False};(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
