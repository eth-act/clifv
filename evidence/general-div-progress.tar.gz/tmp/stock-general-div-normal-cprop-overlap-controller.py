from pathlib import Path
import os,signal,subprocess,json,datetime,time,hashlib,tomllib
root=Path('/home/lee/clifv/.worktrees/stock-mixed-div-20261022');oldpid=3509078;old=Path('/proc')/str(oldpid);oldbirth=(old/'stat').read_text().split()[21];healthypid=1513484;healthy=Path('/proc')/str(healthypid);healthybirth=(healthy/'stat').read_text().split()[21]
e=os.environ.copy();e.update(json.load(open('/tmp/stock-mixed-div-env.json')));pool=json.load(open('/tmp/stock-general-div-cpu-budget.json'))['shared_cpu_pool'];os.sched_setaffinity(0,set(pool));events=[];held=False;new=None;newheld=False
base=Path('/sys/fs/cgroup/user.slice/user-30034.slice/user@30034.service/clifv.slice');report=Path('/tmp/stock-general-div-normal-cprop-overlap-controller.json');head='93257a5d711e21bae720fe44f2dd1c7494045e90'
def live(p,b):
 try:s=(p/'stat').read_text().split();return s[21]==b and s[2]!='Z'
 except FileNotFoundError:return False
def note(**x):
 x['utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();events.append(x);report.write_text(json.dumps(events,indent=2)+'\n');print(json.dumps(x),flush=True)
def scopes(pid):
 rows=[]
 for cg in base.glob(f'fvb-{pid}-*.scope'):
  try:
   if (cg/'cgroup.procs').read_text().strip():rows.append((cg.name,int((cg/'memory.max').read_text())))
  except FileNotFoundError:pass
 return rows
def interrupted(sig,frame):raise SystemExit(128+sig)
signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGINT,interrupted)
try:
 assert live(old,oldbirth) and live(healthy,healthybirth)
 assert b'/tmp/stock-general-div-required-tools-normal-v2' in (old/'cmdline').read_bytes()
 os.kill(oldpid,signal.SIGSTOP);held=True
 assert sum(n for _,n in scopes(oldpid))<=5*1024**3
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head
 cfg=tomllib.loads((root/'lakefile.toml').read_text());roots={x['name']:x['root'] for x in cfg['lean_exe']};names=['lean-backend','lean-backend-armrun','lean-backend-encode-test','lean-e2e-check','link-check','lean-link','arm-fault-cosim','stock-general-div-linked','stock-returned-div-runtime','stock-returned-div-linked']
 argv=['python3','scripts/lake-serial-build.py','--budget','11G','--max-jobs','1','--max-cap','11G','--heavy','11G','--out','/tmp/stock-general-div-required-tools-normal-cprop-overlap','FV','FVTest',*[roots[n] for n in names]];log=Path('/tmp/stock-general-div-controller-required-tools-normal-cprop-overlap.log')
 note(action='start',original_dispatcher_held=oldpid,healthy_worker_untouched=healthypid,new_budget='11GiB/max1',aggregate='16GiB/max2/shared16CPUs',source_head=head,canonical_full_normal_still_required=True)
 with log.open('w') as f:
  new=subprocess.Popen(argv,cwd=root,env=e,stdout=f,stderr=subprocess.STDOUT);note(action='new_scheduler_live',pid=new.pid,log=str(log))
  while new.poll() is None and live(healthy,healthybirth):time.sleep(5)
  if new.poll() is None:
   os.kill(new.pid,signal.SIGSTOP);newheld=True;note(action='original_healthy_worker_terminal_drain_overlap')
   while new.poll() is None and scopes(new.pid):
    note(action='verified_wait_overlap_scopes',scopes=scopes(new.pid));time.sleep(10)
   if new.poll() is None:os.kill(new.pid,signal.SIGTERM);os.kill(new.pid,signal.SIGCONT);newheld=False
  rc=new.wait();note(action='done',exit=rc,intentional_partial_handoff=rc<0,log_sha256=hashlib.sha256(log.read_bytes()).hexdigest(),source_head_now=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),canonical_full_normal_still_required=True)
finally:
 if new is not None and new.poll() is None:
  new.terminate()
  if newheld:os.kill(new.pid,signal.SIGCONT)
  new.wait()
 if held and live(old,oldbirth):os.kill(oldpid,signal.SIGCONT);note(action='original_dispatch_resumed')
