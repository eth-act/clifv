# Arbitrary scalar/division source contract

Implementation `c7426b42` is reconciled onto `ba7d87fe` (#579). Earlier author checks on `eb24f241` retain their actual source provenance; fresh current-main author gates must pass before delivery. Full #140 is unfinished and production eligibility is not yet extended by this packet.

The source/DFG context construction and existing source-format classification derive the no-load interpreter invariant internally. Ordinary and exception-call terminator data retain it. The actual driver then preserves the complete sunk array through binding, opportunistic aliases, scans, outgoing arguments, blocks, critical-edge nodes and the complete traversal. The initial unsunk array is derived from construction, with no result-demand premise.

Every actual division in an arbitrary scalar/division body is emitted and has a mapped result. Existing scalar and division handlers compose the complete guarded original-source fall/return and trap contracts and the reusable Scalar.Domain, allowing any count/order of divisions and returning other original values. No source normalization, operand restriction, supplied execution certificate or new accepted-input condition is added. Old variants and all existing compiler/checker/linker/generated-proof consumers are unchanged.

Complete witnesses: two divisions retaining all nine arguments and the explicit stack slot, first result consumed and second unused, both emitted with the return; arbitrary original source entry/slot and actual return, zero-divisor and signed-overflow outcomes; a conditional/jump/join CFG with a real critical edge and every retained boundary protected. These are concrete fixtures; generic core results use only standard axioms.

Earlier source audit: 35 public roots plus all13 prior sink roots; all476 owned core constants standard-only;59 witness constants with exactly three identified fixed native facts. One source-matched Lean MCP domain review reports standard axioms and no warnings. The exact implementation hashes, old theorem bodies/headers and consumer import boundary survive reconciliation. Current-main normal/trust/ownership evidence and final inventory replace this paragraph only after actual completion; no historical pass is relabelled.

Progress evidence remote0caba06c9875f9366704fb984b0e703e2bfde7d8,187files/SHA06ac65137d270fb8530506202654138481f5d4fc82720042c6cc5d5ebe09532f. Prepared production edits are separately backed atd75cd95958b194a9452a9a7055f69a20f036ddfc and are explicitly unvalidated. Final terminal backup must include fresh gates, old axiom parity, reconciliation and cleanup records before merge.

#579 fixes the attributable #546 audit-printing failure; concurrent #580 parser hardening is retained. Main's #571 runtime checker/list-state implementation changed three files in the actual import graph, requiring fresh unchanged proof imports. The new source/domain core does not import the production selector, keeping the next activation out of this proof cache boundary.

Resource cleanup: the dormant optional #513 view was removed after source5aae55c3 and complete ignored evidence23649789587eb72cab1ab863e777845c0f5d04ad were remotely verified. All71494 regular file hashes and10 Rust metadata hardlinks verified. Four necessary views and one physical warm cache remain, about700GiB free. Rebuilds use at most two workers and aggregate16GiB (15GiB during bounded cleanup); new leaves stay below3GiB.

Next: extend the shared internal production selector for unused/consumed/multiple divisions and run complete affected production gates. Continue all original memory/effects/control/call/width/ABI/source/block/whole-driver simulation and Stock-only/downstream completeness obligations. Fallback is not completeness.
