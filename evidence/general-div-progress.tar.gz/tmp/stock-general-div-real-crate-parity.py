#!/usr/bin/env python3
"""Run the repository's existing real-crate comparator with this host's pinned LLVM tool.
Arguments are unchanged: --json OUT --diffs DIR <retained cargo-fv tmp dirs>.
This reports byte/relocation equality and heuristic causes; it does not prove a driver cutover.
"""
from pathlib import Path
import importlib.util,json,os,sys
root=Path('/home/lee/clifv/.worktrees/stock-mixed-div-20261022')
sys.path.insert(0,str(root/'scripts'))
spec=importlib.util.spec_from_file_location('stock_crate_parity',root/'scripts/stock-crate-parity.py')
report=importlib.util.module_from_spec(spec);spec.loader.exec_module(report)
report.MC=json.loads(Path('/tmp/stock-mixed-div-env.json').read_text())['LLVM_MC']
assert Path(report.MC).is_file() and os.access(report.MC,os.X_OK),report.MC
if __name__=='__main__':report.main()
