from pathlib import Path
import re,json,sys,hashlib
old=Path('/tmp/stock-returned-div-affected-audits');new=Path(sys.argv[1]);out=Path(sys.argv[2]);facts=json.load(open('/tmp/stock-general-div-owned/partitions.json'))['exact_native_facts'];std={'propext','Classical.choice','Quot.sound'}
def canon(a):
 a=a.strip()
 if a in std or a in facts:return a
 display=a.removesuffix('✝');possible=[f for f in facts if f==display or f.endswith('.'+display)]
 assert len(possible)==1,('not a unique known fixed-fact display identity',a,possible)
 return possible[0]
def parse(p):
 r={}
 for m in re.finditer(r"'([^']+)' (does not depend on any axioms|depends on axioms: \[([^\]]*)\])",p.read_text()):
  v={canon(a) for a in (m[3] or '').split(',') if a.strip()}
  assert m[1] not in r or r[m[1]]==v,(p,m[1]);r[m[1]]=v
 assert r,('empty axiom log',p);return r
before={};after={};files=[]
for p in sorted(old.glob('*.log')):
 q=new/p.name;assert q.is_file(),q;a=parse(p);b=parse(q)
 for n,v in a.items():assert n in b and b[n]==v,(n,v,b.get(n))
 before.update(a);after.update(b);files.append({'old':str(p),'old_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'current':str(q),'current_sha256':hashlib.sha256(q.read_bytes()).hexdigest(),'prior_roots':len(a)})
r={'state':'passed','prior_unique_roots':len(before),'files':files,'all_prior_axiom_sets_exact':True,'display_normalization':'Only unique explicit fixed fact identities from the exact ownership whitelist; no allowed-set expansion','full_140_complete':False};out.write_text(json.dumps(r,indent=2)+'\n');print('ALL_PRIOR_PRODUCTION_AXIOM_SETS_EXACT',len(before),len(files))
