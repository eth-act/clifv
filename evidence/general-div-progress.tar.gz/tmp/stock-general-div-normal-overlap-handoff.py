from pathlib import Path
import os,signal,time,json,datetime
worker=666509;gate=560557;wp=Path('/proc')/str(worker);gp=Path('/proc')/str(gate);wb=(wp/'stat').read_text().split()[21];gb=(gp/'stat').read_text().split()[21];events=[];held=False
base=Path('/sys/fs/cgroup/user.slice/user-30034.slice/user@30034.service/clifv.slice')
def live(p,b):
 try:s=(p/'stat').read_text().split();return s[21]==b and s[2]!='Z'
 except FileNotFoundError:return False
def note(**x):
 x['utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();events.append(x);Path('/tmp/stock-general-div-normal-overlap-handoff.json').write_text(json.dumps(events,indent=2)+'\n');print(json.dumps(x),flush=True)
def interrupted(sig,frame):raise SystemExit(128+sig)
signal.signal(signal.SIGINT,interrupted);signal.signal(signal.SIGTERM,interrupted)
try:
 while live(gp,gb) and live(wp,wb):time.sleep(10)
 if not live(wp,wb):note(action='normal_already_terminal_parent_finally_handles_release');raise SystemExit(0)
 assert b'/tmp/stock-general-div-required-tools-normal-overlap' in (wp/'cmdline').read_bytes()
 os.kill(worker,signal.SIGSTOP);held=True;note(action='integration_child_terminal_hold_new_dispatch_drain_healthy_worker',scheduler=worker)
 while live(wp,wb):
  active=[]
  for cg in base.glob(f'fvb-{worker}-*.scope'):
   try:
    if (cg/'cgroup.procs').read_text().strip():active.append(cg.name)
   except FileNotFoundError:pass
  if not active:break
  note(action='verified_wait_healthy_scopes',scopes=active);time.sleep(30)
 if live(wp,wb):
  os.kill(worker,signal.SIGTERM);os.kill(worker,signal.SIGCONT);held=False
  note(action='intentional_partial_normal_handoff_no_live_compiler_terminated',scheduler=worker,existing_v2_v3_whole_normal_still_required=True)
finally:
 if held and live(wp,wb):os.kill(worker,signal.SIGCONT);note(action='dispatcher_resumed_after_guard_interruption')
