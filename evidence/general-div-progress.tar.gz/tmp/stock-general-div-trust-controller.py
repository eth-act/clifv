from pathlib import Path
import os,json,time,subprocess,datetime
root=Path('/home/lee/clifv/.worktrees/stock-mixed-div-20261022');e=os.environ.copy();e.update(json.load(open('/tmp/stock-mixed-div-env.json')));e['FV_MEMCAP']='8G';events=[]
def note(**row):
 row['utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();events.append(row);Path('/tmp/stock-general-div-trust-controller.json').write_text(json.dumps(events,indent=2)+'\n');print(json.dumps(row),flush=True)
def run(name,args):
 log=Path('/tmp/stock-general-div-controller-'+name+'.log');note(action='start',name=name,argv=args,log=str(log))
 with log.open('w') as f:p=subprocess.run(args,cwd=root,env=e,stdout=f,stderr=subprocess.STDOUT)
 note(action='done',name=name,exit=p.returncode)
 if p.returncode:raise SystemExit(p.returncode)
note(action='waiting_for_retained_oom_retry_and_linked_normal',original_retained_result='1800/1805; one 8GiB OOM, four blocked; first attempt preserved')
while True:
 try:retry=json.load(open('/tmp/stock-general-div-retained-oom-retry.json'))
 except (OSError,json.JSONDecodeError):time.sleep(10);continue
 if retry['exit']!=0:note(action='retry_failed',result=retry);raise SystemExit(1)
 assert retry['source_head']=='d811c44a4abc8ec0331307f1540d3b570ea84338'
 assert retry['all_workers_resumed'] and retry['aggregate_reserved_bytes']<=16*1024**3
 linked=Path('/tmp/stock-general-div-linked-normal.log').read_text()
 assert 'END 1456/1456 ok' in linked
 note(action='retry_passed_replay_full_owned_normal_next',retry=retry)
 break
roots=Path('/tmp/stock-general-div-owned/normal-roots.txt').read_text().splitlines()
run('owned-normal',['python3','scripts/lake-serial-build.py','--budget','8G','--max-jobs','1','--max-cap','8G','--out','/tmp/stock-general-div-owned-normal',*roots])
for category in ['axioms','owned']:
 run(category,['python3','scripts/stock-delivery-gates.py','run','/tmp/stock-general-div-'+category+'-manifest.json','--out','/tmp/stock-general-div-'+category+'-current'])
run('old-production-axiom-parity',['python3','/tmp/stock-general-div-axiom-parity.py','/tmp/stock-general-div-axioms-current/audits','/tmp/stock-general-div-old-axiom-parity.json'])
run('old-sink-axiom-parity',['python3','/tmp/stock-div-source-axiom-parity.py','/tmp/stock-general-div-axioms-current/audits/stock-no-load-sink.log','/tmp/stock-general-div-old-sink-axiom-parity.json'])
run('old-headers-native-cases',['python3','/tmp/stock-general-div-compatibility.py'])
note(action='trust_and_compatibility_finished',full_140_complete=False)
