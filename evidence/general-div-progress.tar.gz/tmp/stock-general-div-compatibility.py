from pathlib import Path
import subprocess,re,json,hashlib,importlib.util
base='b631528b8c976c83bb7b181504407d99a2147f2e'
p='FV/Backend/Proof/StockScalarCheck.lean';old=subprocess.check_output(['git','show',base+':'+p],text=True);new=Path(p).read_text()
headers=lambda s:dict(re.findall(r'^theorem\s+(\w+)\s*([\s\S]*?):= by',s,re.M))
a=headers(old);b=headers(new);assert set(a)<=set(b)
for name,header in a.items():assert header==b[name],name
# All other existing Lean sources must be identical except the intended
# executable eligibility expansion. New files are additive.
changes=[x.split('\t',1) for x in subprocess.check_output(['git','diff','--name-status',base,'HEAD'],text=True).splitlines()]
allowed={'FV/Backend/Proof/StockScalarCheck.lean','FV/Backend/Lowering/StockScalar.lean'}
assert all(status=='A' or path in allowed for status,path in changes if path.endswith('.lean'))
oldpath=Path('/tmp/stock-general-div-native-prior.py');oldpath.write_text(subprocess.check_output(['git','show',base+':scripts/check-stock-mixed-native.py'],text=True))
def module(path,name):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
before=module(oldpath,'stock_general_div_prior');after=module(Path('scripts/check-stock-mixed-native.py'),'stock_general_div_current')
profiles=['mixed','logical','scalar','not','mul','shift','cast','bit','popcount','minmax','cmp','highmul','div','mixeddiv','returneddiv'];counts={}
for width in (32,64):
 for profile in profiles:
  previous=before.run_commands(width,profile);current=after.run_commands(width,profile);assert previous==current,(width,profile);counts[f'{width}:{profile}']=len(current)
 for layout in ['unused','consumed','multiple']:assert any('general_'+layout in str(x) for x in after.run_commands(width,'generaldiv'))
r={'state':'passed','base':base,'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'all_prior_public_headers_exact':len(a),'prior_native_profile_width_pairs_exact':len(counts),'prior_case_counts':counts,'old_lean_source_boundary_exact_except_two_intended_shared_files':True,'new_native_execution_claimed':False,'script_sha256':hashlib.sha256(Path('scripts/check-stock-mixed-native.py').read_bytes()).hexdigest()};Path('/tmp/stock-general-div-compatibility.json').write_text(json.dumps(r,indent=2)+'\n');print('PRIOR_PUBLIC_HEADERS_AND_30_NATIVE_PROFILE_WIDTH_PAIRS_EXACT',len(a))
