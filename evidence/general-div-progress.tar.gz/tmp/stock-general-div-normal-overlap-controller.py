from pathlib import Path
import os,signal,subprocess,json,datetime,time,hashlib,tomllib
root=Path('/home/lee/clifv/.worktrees/stock-mixed-div-20261022');prepid=560532;pre=Path('/proc')/str(prepid);birth=(pre/'stat').read_text().split()[21]
e=os.environ.copy();e.update(json.load(open('/tmp/stock-mixed-div-env.json')));events=[];held=False
head='93257a5d711e21bae720fe44f2dd1c7494045e90';report=Path('/tmp/stock-general-div-normal-overlap-controller.json')
def note(**x):
 x['utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();events.append(x);report.write_text(json.dumps(events,indent=2)+'\n');print(json.dumps(x),flush=True)
def live():
 try:s=(pre/'stat').read_text().split();return s[21]==birth and s[2]!='Z'
 except FileNotFoundError:return False
def interrupted(sig,frame):raise SystemExit(128+sig)
signal.signal(signal.SIGINT,interrupted);signal.signal(signal.SIGTERM,interrupted)
def snapshot():
 names=subprocess.check_output(['git','ls-files','-z'],cwd=root).decode().split('\0');return {n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in names if n and (root/n).is_file()}
try:
 assert live() and b'/tmp/stock-general-div-integration-4G-preflight-controller.py' in (pre/'cmdline').read_bytes()
 assert not Path('/proc/528769').exists()
 assert (Path('/proc/3509078/stat').read_text().split()[2])=='T'
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head
 os.kill(prepid,signal.SIGSTOP);held=True
 note(action='preflight_waiting_controller_held_child_proofs_continue',pid=prepid,normal_budget='11GiB',preflight_proof_cap='4GiB',preflight_controller_cap='1GiB',aggregate='16GiB/max2workers')
 names=['lean-backend','lean-backend-armrun','lean-backend-encode-test','lean-e2e-check','link-check','lean-link','arm-fault-cosim','stock-general-div-linked','stock-returned-div-runtime','stock-returned-div-linked'];cfg=tomllib.loads((root/'lakefile.toml').read_text());targets={x['name']:x['root'] for x in cfg['lean_exe']}
 argv=['python3','scripts/lake-serial-build.py','--budget','11G','--max-jobs','1','--max-cap','11G','--heavy','11G','--out','/tmp/stock-general-div-required-tools-normal-overlap','FV','FVTest',*[targets[n] for n in names]]
 tracked=snapshot();log=Path('/tmp/stock-general-div-controller-required-tools-normal-overlap.log');provenance={'state':'running','source_head':head,'tracked_files':tracked,'argv':argv,'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'log':str(log)};pr=Path('/tmp/stock-general-div-normal-provenance-overlap.json');pr.write_text(json.dumps(provenance,indent=2)+'\n')
 cpu=str(min(os.sched_getaffinity(0)))
 with log.open('w') as f:
  p=subprocess.Popen(['taskset','-c',cpu,*argv],cwd=root,env=e,stdout=f,stderr=subprocess.STDOUT);note(action='normal_scheduler_live',pid=p.pid,log=str(log));rc=p.wait()
 same=snapshot()==tracked and subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head
 provenance.update(state='passed' if rc==0 and same else 'failed',exit=rc,source_unchanged=same,finished=datetime.datetime.now(datetime.timezone.utc).isoformat(),log_sha256=hashlib.sha256(log.read_bytes()).hexdigest());pr.write_text(json.dumps(provenance,indent=2)+'\n');note(action='normal_done',exit=rc,source_unchanged=same,existing_v2_v3_replays_still_required=True)
finally:
 if held and live():os.kill(prepid,signal.SIGCONT);note(action='preflight_waiting_controller_resumed')
