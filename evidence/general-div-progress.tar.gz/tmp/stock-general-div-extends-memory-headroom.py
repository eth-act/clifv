from pathlib import Path
import os,signal,json,subprocess,time,datetime
pid=3509078;p=Path('/proc')/str(pid);assert b'stock-general-div-required-tools-normal-v2' in (p/'cmdline').read_bytes();birth=(p/'stat').read_text().split()[21]
os.kill(pid,signal.SIGSTOP)
base=Path('/sys/fs/cgroup/user.slice/user-30034.slice/user@30034.service/clifv.slice');live=[q for q in base.glob('fvb-3509078-*.scope') if (q/'cgroup.procs').read_text().strip()]
try:
 assert len(live)==1,[(q.name,(q/'cgroup.procs').read_text()) for q in live]
 cg=live[0];assert cg.name.endswith('-FV.Opt.Proof.RuleExtends2.scope')
 before=int((cg/'memory.max').read_text());current=int((cg/'memory.current').read_text());subprocess.run(['systemctl','--user','set-property','--runtime',cg.name,'MemoryMax=16G'],check=True)
 assert int((cg/'memory.max').read_text())==16*1024**3
 record={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':'sole_build_raised_to_existing_aggregate_16GiB_limit','unit':cg.name,'old_cap_bytes':before,'new_cap_bytes':16*1024**3,'memory_at_change':current,'dispatcher_held':pid};Path('/tmp/stock-general-div-extends-memory-headroom.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
 while cg.exists():
  try:procs=(cg/'cgroup.procs').read_text().split()
  except FileNotFoundError:break
  if not procs:break
  time.sleep(5)
finally:
 if p.exists() and (p/'stat').read_text().split()[21]==birth:os.kill(pid,signal.SIGCONT)
print('Owned scope ended; normal dispatch resumed',flush=True)
