from pathlib import Path
import os,json,subprocess,hashlib,re,datetime,shutil
root=Path('/home/lee/clifv/.worktrees/stock-mixed-div-20261022');head='cd57ac630b3846a7b7832140b7e5f195452857fc';rows=[]
e=os.environ.copy();e.update(json.load(open('/tmp/stock-mixed-div-env.json')))
def add(name,passed,detail):rows.append({'id':name,'passed':bool(passed),'detail':detail})
actual=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
add('candidate-source',actual==head and subprocess.run(['git','diff','--quiet','HEAD','--'],cwd=root).returncode==0,actual)
for category in ['native','axioms','owned','integration','retained-integration','full','examples','retention']:
 stem=category+'-bounded' if category=='native' else category
 manifest=Path('/tmp/stock-general-div-main151-v6-'+stem+'-manifest.json');out=Path('/tmp/stock-general-div-main151-v6-'+category+'-current')
 report_env=e.copy();restored=[]
 first_id=json.load(manifest.open())['gates'][0]['id'];saved=out/(first_id+'.json')
 if saved.exists():
  record=json.load(saved.open());details=out/(record['input_key']+'.inputs.json')
  if details.exists():
   hashes=json.load(details.open())['environment']
   for name in ['PWD','OLDPWD']:
    choices=[str(root),str(root.parent.parent)]
    matches=[v for v in choices if hashlib.sha256(json.dumps(v,sort_keys=True).encode()).hexdigest()==hashes.get(name)]
    if len(matches)==1:report_env[name]=matches[0];restored.append(name)
 p=subprocess.run(['python3','scripts/stock-delivery-gates.py','report',str(manifest),'--out',str(out)],cwd=root,env=report_env,capture_output=True,text=True)
 try:
  r=json.loads(p.stdout);expected={g['id'] for g in json.load(manifest.open())['gates']}
  passed=p.returncode==0 and r['state']=='passed' and r['head']==head and {g['id'] for g in r['gates']}==expected and all(g['current_pass'] and g['source_head']==head for g in r['gates'])
  add(category,passed,{'state':r['state'],'expected_gates':len(expected),'current_passes':sum(g['current_pass'] for g in r['gates']),'original_directory_environment_verified':restored})
 except (ValueError,KeyError):add(category,False,p.stderr.strip() or p.stdout.strip())
m=json.load(open('/tmp/stock-general-div-mcp-source.json'));mcp=json.load(open(m['result']));a=mcp.get('structuredContent',{})
add('source-matched-mcp',hashlib.sha256((root/m['source']).read_bytes()).hexdigest()==m['source_sha256'] and set(a.get('axioms',[]))=={'propext','Classical.choice','Quot.sound'} and a.get('warnings')==[] and not mcp.get('isError'),{'original_source_head':m['head'],'source_hash_exact':True})
r=json.load(open('/tmp/stock-general-div-main151-v6-native-current/native/native-receipt.json'))
add('native-actual-execution',r['state']=='passed' and r['actual_lean_encoded_objects']==24 and r['lean_byte_executions']==14640 and r['cranelift_reference_executions']==3660 and r['failures']==0 and r['disagreements']==0,{'objects':24,'lean_executions':14640,'references':3660})
p=Path('/tmp/stock-general-div-normal-provenance-v6.json')
if p.exists():
 r=json.load(p.open());log=Path(r['log']);files=r['tracked_files'];same=all((root/n).is_file() and hashlib.sha256((root/n).read_bytes()).hexdigest()==v for n,v in files.items())
 end=re.findall(r'END (\d+)/(\d+) ok[^\n]*',log.read_text()) if log.exists() else []
 add('full-normal',r.get('state')=='passed' and r.get('exit')==0 and r.get('source_unchanged') and r['source_head']==head and same and bool(end) and end[-1][0]==end[-1][1] and hashlib.sha256(log.read_bytes()).hexdigest()==r.get('log_sha256'),{'state':r['state'],'normal_end':end[-1] if end else None,'source_files_exact':same})
else:add('full-normal',False,'queued after live scopes drain')
for label,name,count in [('old-production-axioms','old-axiom-parity',497),('old-sink-axioms','old-sink-axiom-parity',13)]:
 r=json.load(open('/tmp/stock-general-div-main151-v6-'+name+'.json'))
 if 'files' in r:
  exact=all(hashlib.sha256(Path(f[k]).read_bytes()).hexdigest()==f[k+'_sha256'] for f in r['files'] for k in ['old','current'])
 else:exact=all(hashlib.sha256(Path(r[k+'_log']).read_bytes()).hexdigest()==r[k+'_sha256'] for k in ['old','new'])
 add(label,r['state']=='passed' and r['all_prior_axiom_sets_exact'] and r.get('prior_unique_roots',r.get('prior_roots'))==count and exact,count)
r=json.load(open('/tmp/stock-general-div-main151-v6-compatibility.json'));add('old-headers-and-native-cases',r['state']=='passed' and r['head']==head and r['all_prior_public_headers_exact']==17 and r['prior_native_profile_width_pairs_exact']==30,{'headers':17,'profile_width_pairs':30})
p=Path('/tmp/stock-general-div-main151-v6-identity-stage-parity.json')
if p.exists():
 r=json.load(p.open());add('old-identities-and-stages',set(r)=={'e2e','legacy-e2e'} and all(x['original']==1150 and x['prior']==1159 and x['all_original_and_prior_identities_and_ordered_stages_preserved'] for x in r.values()),r)
else:add('old-identities-and-stages',False,'both-mode current corpus comparison pending')
shape=json.load(open('/tmp/stock-general-div-main151-v6-shape-axioms.json'))
add('typed-shape-axioms',shape['state']=='passed' and shape['head']==head and shape['roots']==21 and shape['all_axioms_standard_only'] and shape['exact_two_standard_axioms'] and hashlib.sha256(Path(shape['log']).read_bytes()).hexdigest()==shape['log_sha256'] and hashlib.sha256((root/'FV/Backend/Proof/IselShpTTabS30.lean').read_bytes()).hexdigest()==shape['source_sha256'],shape)
result={'state':'author_gates_passed' if all(r['passed'] for r in rows) else 'pending','source_head':head,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':rows,'latest_main_reconciliation_required_before_landing':True,'full_140_complete':False}
Path('/tmp/stock-general-div-main151-v6-readiness.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'state':result['state'],'passed':[r['id'] for r in rows if r['passed']],'pending':[r['id'] for r in rows if not r['passed']]}))
raise SystemExit(0 if result['state']=='author_gates_passed' else 1)
