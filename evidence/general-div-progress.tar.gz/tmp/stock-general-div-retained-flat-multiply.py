from pathlib import Path
import os,json,subprocess,hashlib,sys
root=Path.cwd();out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=False);records={};sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run(name,args,env=None):
 p=out/(name+'.log')
 with p.open('w') as log:r=subprocess.run(['scripts/memcap.sh',*args],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 records[name]={'returncode':r.returncode,'log':str(p),'sha256':sha(p)};assert r.returncode==0,(name,r.returncode,p);assert 'Error: index out of bounds' not in p.read_text();return p
lp=subprocess.check_output(['scripts/memcap.sh','lake','env','printenv','LEAN_PATH'],cwd=root,text=True).strip()
try:
 for mode in ['Plain','Cleanup']:
  label='StockNotProduction6Mixed'+mode+'FallbackGlobal';old=Path('/tmp/stock-not-integration-author/not/linked');source=old/'Crates'/(label+'.lean');exe=old/(label+'.elf');assert source.exists() and exe.exists();original={'proof_source_sha256':sha(source),'executable_sha256':sha(exe)}
  # Reuse only the original data declarations, byte-for-byte apart from their namespace.
  prefix=source.read_text().split('/-- Fixed production callback and the original preparation-mode flag. -/')[0];assert 'def input : LinkInput where' in prefix
  prefix=prefix.replace('namespace Crates.'+label,'namespace RetainedOriginalInput')
  dest=out/'Crates'/('RetainedFlatMultiply'+mode+'.lean');dest.parent.mkdir(exist_ok=True)
  code='import FVTest.E2E.SemanticLinkProofWith\nimport FV.E2E.SemanticPipelineCheck\n'+prefix+'\nend RetainedOriginalInput\n'
  code+='''
open Backend E2E E2E.LinkCheck E2E.BinCheck E2E.Elf
private def require (b : Bool) (message : String) : IO Unit :=
  unless b do throw (IO.userError message)
def main : IO Unit := do
  let input := RetainedOriginalInput.input
  let fi := input.funcs[4]!
  require (fi.func.name == "actual_stock_not_4" && fi.func.blocks.length == 1 &&
    Stock.Scalar.activationEligible fi.func && Stock.Scalar.sourceOk fi.func)
    "original single-block multiply source was changed or failed current activation"
  let lower := Stock.Scalar.lowerWithRoutes [("actual_stock_not_4",1)]
  let cleanup := CLEANUP
  let results := input.resultsProductionWith lower cleanup
  require (okRSemanticNI (productionStage cleanup) input results)
    "retained original program/checker failed"
  let file ← IO.FS.readBinFile "EXE"
  let ex : Excerpt := [(0,file)]
  let index := _root_.symIndex file
  let cert := input.addrs.filterMap fun p => (index.get? (symName p.1,p.2)).map (p.1, ·)
  require (hdrB ex && symsB input ex cert &&
    SemanticChecksWith.codeBProduction lower input cleanup ex input.funcs)
    "original executable/header/code-table bytes rejected"
  let bg : BinGen := ⟨ex,[ex,ex],[],ex,cert,[]⟩
  let ci : SemanticStackBound.CompilerInput := {toLinkInput := input,cleanup,lower}
  let stack := SemanticStackBound.stackB ci
  require stack.isSome "original stack bound lost"
  let names := input.funcs.map (·.func.name)
  let lowerName := "Backend.Stock.Scalar.lowerWithRoutes [(" ++ (Lean.toJson "actual_stock_not_4").compress ++ ",1)]"
  for (path,text) in FVTest.E2E.SemanticLinkProofWith.leanFilesSemanticWith
      lowerName input names names
      "DEST" "MOD" "EXE" cleanup true stack [] bg
      (lowerImport := "FV.Backend.Lowering.StockScalarNI") do
    if let some parent := (System.FilePath.mk path).parent then IO.FS.createDirAll parent
    IO.FS.writeFile path text
  IO.println "ORIGINAL_FLAT_MULTIPLY_SOURCE_PROGRAM_BYTES_STACK_AND_CURRENT_PROOF_EMISSION_PASS"
'''.replace('CLEANUP','true' if mode=='Cleanup' else 'false').replace('EXE',str(exe)).replace('DEST',str(dest)).replace('MOD',dest.stem)
  # Lean's lowerName string contains escaped quotes, not literal backslashes in the emitted expression.
  code=code.replace('\\\\\\"','\\"')
  module=out/('Export'+mode+'.lean');module.write_text(code)
  run('current-original-checks-and-proof-emission-'+mode,['lake','env','lean','--root='+str(out),'--run',str(module)])
  env=dict(os.environ,LEAN_PATH=str(out)+':'+lp)
  run('current-generated-proof-'+mode,['lean','--root='+str(out),'-o',str(dest.with_suffix('.olean')),str(dest)],env)
  assert sha(source)==original['proof_source_sha256'] and sha(exe)==original['executable_sha256'],'original artifact mutated'
  records['original-'+mode]={**original,'files_untouched':True,'single_block_imul_preserved':True,'current_proof_sha256':sha(dest)}
 (out/'receipt.json').write_text(json.dumps({'state':'passed','records':records,'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'route':'explicit retained old Logical path for only the newly promoted flat multiply; all original data and ELF bytes unchanged'},indent=2));print('RETAINED_ORIGINAL_FLAT_MULTIPLY_BYTES_AND_CURRENT_PROOFS_PASS 2')
except BaseException as error:
 (out/'receipt.json').write_text(json.dumps({'state':'failed','error':repr(error),'records':records},indent=2));raise
