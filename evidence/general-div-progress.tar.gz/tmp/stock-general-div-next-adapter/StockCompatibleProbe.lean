import FV.Backend
import FV.Clif.Parse
import FV.Backend.Lowering.StockScalarNI

/-! Diagnostic only: original sources, real Stock artifacts, existing validators.
No theorem or production coverage is inferred from these measurements. -/
open Backend

def main (files : List String) : IO UInt32 := do
  let mut parsed := 0
  let mut stock := 0
  let mut emptyEdges := 0
  let mut scalar := 0
  let mut compatible := 0
  let mut additional := 0
  for file in files do
    let pf := Clif.parseFile (← IO.FS.readFile file)
    for entry in pf.funcs do
      match entry.func with
      | .error _ => pure ()
      | .ok f =>
        parsed := parsed + 1
        let retained := Stock.Scalar.eligible f || Stock.Logical.eligible f ||
          Stock.Mixed.eligible f || Stock.Arithmetic.eligible f || Stock.ScalarAdd.eligible f
        if retained then scalar := scalar + 1
        match Stock.lower f with
        | .error _ => pure ()
        | .ok result =>
          stock := stock + 1
          if result.edgeArgs.all (fun row => row.all (·.isEmpty)) then
            emptyEdges := emptyEdges + 1
            let vc := Stock.D0.compact f.name result
            if Backend.lowerCheckFor f vc then
              compatible := compatible + 1
              if !retained then
                additional := additional + 1
                IO.println s!"ADDITIONAL {file} {f.name} blocks={f.blocks.length} typed={!Compile.functionE f}"
  IO.println s!"SUMMARY parsed={parsed} stock={stock} emptyEdges={emptyEdges} retained={scalar} compatible={compatible} additional={additional}"
  return 0
