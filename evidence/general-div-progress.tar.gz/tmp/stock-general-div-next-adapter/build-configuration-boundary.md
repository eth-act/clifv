# Build configuration observation, not an established cold-build cause

On93257a5d, every production class adds runtime/linked executables in lakefile.toml.
scripts/ci-build-plan.py treats any lakefile.toml change as a global change and
plans every module. scripts/lake-serial-build.py source_keys also salts every
cross-worktree in-flight deduplication key with all lakefile.toml bytes.

These are observed planning/deduplication effects. They do NOT prove that Lake's
own artifact cache rejects every unchanged module, nor establish how much of the
current cold build comes from executable additions versus cache availability or
the earlier purge. Do not claim a measured causal explanation or weaken keys.

A future shared runtime/linked fixture dispatcher could avoid repeated lakefile
changes while retaining all class-specific checks and exact native fact ownership.
Before implementing it, measure unchanged-module Lake trace/cache reuse across an
executable-only configuration delta, and keep original source/module/binary/input
provenance. Coordinate infrastructure changes through261. This is a tentative
follow-up, not a reservation or reason to delay current611validation/landing.
