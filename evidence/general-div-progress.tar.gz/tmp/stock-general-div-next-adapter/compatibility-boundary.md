# Next adapter diagnostic boundary

Read-only inspection on93257a5d: Backend.lowerChecked still uses the proved D0
dispatcher, and E2E.VerifiableT.lowerChecked_spec preserves the public equality
with lowerFunction's output. This equality is used to derive typed lowering
soundness. A generic change to lowerChecked cannot be justified merely because
lowerCheckFor returns true on an arbitrary compact Stock artifact: the retained
public theorem also requires the output equality. Preserve that variant.

The active Scalar production integration supplies source-derived Domain through
shared artifact consumers. For the next extension, first measure the prepared
StockCompatibleProbe on original sources after the current activation lands.
Report real compact artifact validator acceptance, edge arguments, current route
eligibility and unchanged original identities. A positive validator result is a
diagnostic, not a completeness or source-domain proof, and must not silently
replace old lowerChecked_spec or original input conditions.

If a new compatible route is useful, compose it through existing semantic-artifact
consumers with an explicit soundness bridge; retain the legacy equality theorem
on its existing entrypoint. Nonempty successor arguments still need actual edge
transport, and blocks/loops/effects require the corresponding source/whole-driver
simulation. Do not claim those from empty-edge fixture or successful Stock output.

This note is outside the frozen checkout. No new route, proof, measured coverage,
reservation, worktree or build is claimed. Current #611 validation/landing takes
priority; original #140 remains the full objective.
