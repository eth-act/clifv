from pathlib import Path
import os,json,subprocess,hashlib,datetime,time
root=Path('/home/lee/clifv/.worktrees/stock-mixed-div-20261022');out=Path('/tmp/stock-general-div-next-adapter');probe=out/'StockCompatibleProbe.lean'
e=os.environ.copy();e.update(json.load(open('/tmp/stock-mixed-div-env.json')));e['FV_MEMCAP']='8G';e['FV_MEMCAP_STATS']=str(out/'probe.mem')
assert not Path('/proc/528769').exists(),'old normal compiler still live'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()=='93257a5d711e21bae720fe44f2dd1c7494045e90'
files=sorted((root/'corpus/clif').rglob('*.clif'))+sorted((root/'third_party/wasmtime/cranelift/filetests/filetests/runtests').glob('*.clif'))
assert files and subprocess.check_output(['nproc'],env=e,text=True).strip()=='2'
manifest={'state':'running_diagnostic_not_coverage_or_completeness','head':'93257a5d711e21bae720fe44f2dd1c7494045e90','started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cap':'8GiB','probe_sha256':hashlib.sha256(probe.read_bytes()).hexdigest(),'files':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},'original_inputs_unchanged':True,'production_changed':False,'full_140_complete':False}
(out/'probe-inputs.json').write_text(json.dumps(manifest,indent=2)+'\n');cpu=str(min(os.sched_getaffinity(0)));start=time.monotonic()
with (out/'probe.log').open('w') as f:
 r=subprocess.run(['scripts/memcap.sh','taskset','-c',cpu,'lake','env','lean','--run',str(probe),*[str(p) for p in files]],cwd=root,env=e,stdout=f,stderr=subprocess.STDOUT)
same=all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in manifest['files'].items())
manifest.update(state='completed_diagnostic_not_coverage_or_completeness' if r.returncode==0 and same else 'failed_diagnostic',exit=r.returncode,seconds=time.monotonic()-start,inputs_unchanged=same,finished=datetime.datetime.now(datetime.timezone.utc).isoformat(),log_sha256=hashlib.sha256((out/'probe.log').read_bytes()).hexdigest())
(out/'probe-inputs.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({k:v for k,v in manifest.items() if k!='files'}));raise SystemExit(r.returncode)
