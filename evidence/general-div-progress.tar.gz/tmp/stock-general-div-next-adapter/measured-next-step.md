# Measured next adapter candidates

Diagnostic on93257a5d over445unchanged corpus/runtest files parsed1681functions.
Stock.lower succeeded for1060;976had empty per-successor argument lists;364were
in the current retained syntax classes. Dense compact output passed the existing
lowerCheckFor on251functions, including182outside those classes. All182have one
block;177are in functionE and5use the typed validator. No new control-flow,
production or completeness coverage follows. Runtime28.01s, cap8GiB,
cgrouppeak362012672bytes/noOOM. Files/hash/log provenance is in probe-inputs.json.

Examples include i8/i16 arithmetic/div/rem/casts/rotations/shifts, alias forwarding
and bmask; not all examples belong to already-proved scalar source families.
The least speculative next implementation is to establish original narrow-ABI
source/producer composition for already-proved families, retain the old32/64
selectors and theorem variants, and route complete supported narrow classes
through the existing shared consumers. Actual checks do not supply the needed
source-domain or legacy-output-equality proofs. Alias/bmask/typed-move cases need
their own actual source-rule reasoning where not already proved.

After611lands, inspect saved and current original8/16source wrappers and ABI
bridges before writing another proof chain. Identify the exact guard/producer
boundary blocking narrow widths, then implement the reusable bridge with full
witnesses, old axiom/header/native-grid parity, real compiler/checker/linker/
generated-proof consumers and complete author gates. Continue all original140
control/effects/whole-driver/completeness obligations; this is not a replacement
or narrowed final goal. No task reservation or production change is made here.
