# Measured next adapter candidates

Diagnostic on93257a5d over445unchanged corpus/runtest files parsed1681functions.
Stock.lower succeeded for1060;976had empty per-successor argument lists;364were
in the current retained syntax classes. Dense compact output passed the existing
lowerCheckFor on251functions, including182outside those classes. All182have one
block;177are in functionE and5use the typed validator. No new control-flow,
production or completeness coverage follows. Runtime28.01s, cap8GiB,
cgrouppeak362012672bytes/noOOM. Files/hash/log provenance is in probe-inputs.json.

Examples include i8/i16 arithmetic/div/rem/casts/rotations/shifts, alias forwarding
and bmask; not all examples belong to already-proved scalar source families.
The least speculative next implementation is to establish original narrow-ABI
source/producer composition for already-proved families, retain the old32/64
selectors and theorem variants, and route complete supported narrow classes
through the existing shared consumers. Actual checks do not supply the needed
source-domain or legacy-output-equality proofs. Alias/bmask/typed-move cases need
their own actual source-rule reasoning where not already proved.

After611lands, inspect saved and current original8/16source wrappers and ABI
bridges before writing another proof chain. Identify the exact guard/producer
boundary blocking narrow widths, then implement the reusable bridge with full
witnesses, old axiom/header/native-grid parity, real compiler/checker/linker/
generated-proof consumers and complete author gates. Continue all original140
control/effects/whole-driver/completeness obligations; this is not a replacement
or narrowed final goal. No task reservation or production change is made here.

## Concrete reuse boundary from current sources

StockEntryABI.entered_source_abi_row_frame already proves actual source values,
ABI locations and widths1/2/4/8bytes. SourceOk_sound uses abiEligible only to
extract normal argument/return purposes and exclude sret; the source-domain
composition is supplied by the existing domain_of_scalar_div and family soundness.
ABIReadScalar already recognizes six integer extension forms including8/16-bit.
The current production ABI classifier (StockArithmetic.abiEligible, aliased by
Scalar) and family Bool classifiers restrict selected types to32/64. These
observations suggest an additive original-width classifier/soundness wrapper
reusing the existing source/entry/return/producer chain. Preserve all old Boolean
selectors, theorem headers and required axioms; do not alter original source
instructions merely to make a predicate pass. Actual narrow artifacts still
need paired source validation and downstream complete witnesses. No implemented
or validated narrow production activation is claimed here.
