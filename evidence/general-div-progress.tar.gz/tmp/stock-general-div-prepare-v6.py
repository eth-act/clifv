from pathlib import Path
import json,re,ast,hashlib,subprocess,datetime
r=Path('/home/lee/clifv/.worktrees/stock-mixed-div-20261022');tmp=Path('/tmp');head='cd57ac630b3846a7b7832140b7e5f195452857fc';oldhead='22aef3dfa02980e4dfcac6276ad9ec863e546a91'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==head
assert subprocess.run(['git','diff','--quiet','HEAD','--'],cwd=r).returncode==0
prefix='stock-general-div-main151-';newprefix='stock-general-div-main151-v6-'
def transform(s):return s.replace(prefix,newprefix).replace(oldhead,head).replace('normal-provenance-v4','normal-provenance-v6').replace('required-tools-normal-v4','required-tools-normal-v6').replace('controller-v4','controller-v6')
created=[]
def write(p,s):
 assert not p.exists(),p
 if p.suffix=='.py':ast.parse(s)
 p.write_text(s);created.append(str(p))
for category in ('native-bounded','integration','retained-integration','full','examples','axioms','owned','retention'):
 src=tmp/(prefix+category+'-manifest.json');m=json.loads(src.read_text());n=json.loads(transform(src.read_text()));n['candidate']=head
 assert len(m['gates'])==len(n['gates'])
 assert n['base']=='1510186e56b81e8cbb36027746414a411c8e1f37'
 write(tmp/(newprefix+category+'-manifest.json'),json.dumps(n,indent=2)+'\n')
# Supplement unchanged old scalar headers/native grids with exact proof-only boundaries.
s=(tmp/'stock-general-div-compatibility-main151.py').read_text()
needle="assert all(status=='A' or path in allowed for status,path in changes if path.endswith('.lean'))"
extra="""shape_path='FV/Backend/Proof/IselShpTTabS30.lean'
shape_old=subprocess.check_output(['git','show',base+':'+shape_path],text=True)
shape_headers=lambda s:dict(re.findall(r'^theorem\\s+(shpStmtOkT_rule_lower_\\d+)\\s*([\\s\\S]*?):= by',s,re.M))
shape_before=shape_headers(shape_old);shape_after=shape_headers(Path(shape_path).read_text())
assert len(shape_before)==10 and shape_before==shape_after
assert hashlib.sha256(Path(shape_path).read_bytes()).hexdigest()=='bbcb9bab3963d9cb7f192d35c467501318f67837cd6655f0e8726cb23c957ad4'
generator_path='FVTest/Backend/IselShpTGen.lean'
assert hashlib.sha256(Path(generator_path).read_bytes()).hexdigest()=='297c0f60cd11b75f7f82f833c06c84820439d5a877e330cf5c03d4c6576737c7'
allowed.update({shape_path,generator_path})
assert all(status=='A' or path in allowed for status,path in changes if path.endswith('.lean'))"""
assert s.count(needle)==1;s=s.replace(needle,extra).replace("'old_lean_source_boundary_exact_except_two_intended_shared_files':True","'old_lean_source_boundary_exact_except_declared_semantic_and_hash_verified_proof_files':True,'old_typed_shape_headers_exact':10")
s=transform(s).replace('stock-general-div-compatibility-main151.py','stock-general-div-compatibility-main151-v6.py')
write(tmp/'stock-general-div-compatibility-main151-v6.py',s)
s=transform((tmp/'stock-general-div-identity-stage-parity-main151.py').read_text());write(tmp/'stock-general-div-identity-stage-parity-main151-v6.py',s)
# Run all generated public shape facts through a strict additional Std3 audit.
roots=re.findall(r'^theorem\s+(\w+)\s*:',(r/'FV/Backend/Proof/IselShpTTabS30.lean').read_text(),re.M);assert len(roots)==21
write(tmp/'stock-general-div-shape-axioms-v6.lean','import FV.Backend.Proof.IselShpTTabS30\n'+''.join('#print axioms Backend.Proof.CovT.'+x+'\n' for x in roots))
s=transform((tmp/'stock-general-div-consumer-controller-v4.py').read_text())
s=re.sub(r"linked=Path\('/tmp/stock-general-div-linked-normal.log'\).*?(?=config=tomllib)","",s,flags=re.S)
assert "linked_normal" not in s
s=s.replace("'stock-general-div-linked','stock-returned-div-runtime'","'stock-general-div-runtime','stock-general-div-linked','stock-returned-div-runtime'")
s=s.replace("assert same,'tracked source changed during normal validation'","if not same:\n   note(action='done',name=name,exit=1,actual_command_exit=r.returncode,reason='source_changed');raise SystemExit(1)")
write(tmp/'stock-general-div-consumer-controller-v6.py',s)
s=transform((tmp/'stock-general-div-trust-controller-v4.py').read_text()).replace('stock-general-div-compatibility-main151.py','stock-general-div-compatibility-main151-v6.py')
shape="""run('shape-axioms',['scripts/memcap.sh','lake','env','lean','--root=/tmp','/tmp/stock-general-div-shape-axioms-v6.lean'])
shape_log=Path('/tmp/stock-general-div-main151-v6-controller-shape-axioms.log')
import re,hashlib
flat=shape_log.read_text().replace('\\n',' ')
deps=re.findall(r"'(.+?)' depends on axioms: \\[([^\\]]*)\\]",flat)
clean=re.findall(r"'(.+?)' does not depend on any axioms",flat)
expected="""+repr({'Backend.Proof.CovT.'+x for x in roots})+"""
actual={name for name,_ in deps}|set(clean)
assert actual==expected,(actual,expected)
assert all(set(x.strip() for x in axioms.split(',') if x.strip())=={'propext','Quot.sound'} for _,axioms in deps)
Path('/tmp/stock-general-div-main151-v6-shape-axioms.json').write_text(json.dumps({'state':'passed','head':CURRENT_HEAD,'roots':len(expected),'all_axioms_standard_only':True,'exact_two_standard_axioms':True,'log':str(shape_log),'log_sha256':hashlib.sha256(shape_log.read_bytes()).hexdigest(),'source_sha256':hashlib.sha256((root/'FV/Backend/Proof/IselShpTTabS30.lean').read_bytes()).hexdigest()},indent=2)+'\\n')
"""
s=s.replace("note(action='trust_and_compatibility_finished',full_140_complete=False)",shape+"note(action='trust_and_compatibility_finished',full_140_complete=False)")
write(tmp/'stock-general-div-trust-controller-v6.py',s)
s=transform((tmp/'stock-general-div-final-retention-controller-v4.py').read_text()).replace('stock-general-div-identity-stage-parity-main151.py','stock-general-div-identity-stage-parity-main151-v6.py');write(tmp/'stock-general-div-final-retention-controller-v6.py',s)
s=transform((tmp/'stock-general-div-readiness-v4.py').read_text())
needle="result={'state':'author_gates_passed'"
extra="""shape=json.load(open('/tmp/stock-general-div-main151-v6-shape-axioms.json'))
add('typed-shape-axioms',shape['state']=='passed' and shape['head']==head and shape['roots']==21 and shape['all_axioms_standard_only'] and shape['exact_two_standard_axioms'] and hashlib.sha256(Path(shape['log']).read_bytes()).hexdigest()==shape['log_sha256'] and hashlib.sha256((root/'FV/Backend/Proof/IselShpTTabS30.lean').read_bytes()).hexdigest()==shape['source_sha256'],shape)
"""
assert needle in s;s=s.replace(needle,extra+needle);write(tmp/'stock-general-div-readiness-v6.py',s)
# Waiting launcher: never overlaps a fresh build with the existing healthy normal.
launch=transform((tmp/'stock-general-div-main151-launch.py').read_text())
wait="""from pathlib import Path
import os,time,signal,json,subprocess,datetime
oldpid=1681039
oldbirth='"""+'250455554'+"""'
print('Waiting for existing normal1681039 to finish; no worker stopped',flush=True)
Path('/tmp/stock-general-div-main151-v6-handoff.json').write_text(json.dumps({'state':'waiting_for_existing_normal','old_pid':oldpid,'old_birth':oldbirth,'candidate':'"""+head+"""','utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})+'\\n')
while Path('/proc',str(oldpid)).exists() and Path('/proc',str(oldpid),'stat').read_text().split()[21]==oldbirth:time.sleep(10)
# The old retention waiter receives no done-event if V4 source comparison raises.
meta=json.load(open('/tmp/stock-general-div-main151-controllers.json'))
for child in meta['children']:
 if child['name']!='final-retention-controller-v4':continue
 p=Path('/proc',str(child['pid']))
 if p.exists() and (p/'stat').read_text().split()[21]==child['birth']:
  assert b'final-retention-controller-v4.py' in (p/'cmdline').read_bytes()
  os.kill(child['pid'],signal.SIGTERM)
Path('/tmp/stock-general-div-main151-v6-handoff.json').write_text(json.dumps({'state':'starting_fresh_gates','old_normal_absent':True,'candidate':'"""+head+"""','utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})+'\\n')
"""
write(tmp/'stock-general-div-main151-v6-launch.py',wait+launch)
# Separate observer tail; original V4 observer and records stay intact.
s=(tmp/'stock-general-div-observe.py').read_text().replace('stock-general-div-main151-controller-required-tools-normal-v4.log','stock-general-div-main151-v6-controller-required-tools-normal-v6.log').replace("print('v4 normal: '","print('v5 normal: '")
write(tmp/'stock-general-div-observe-v6.py',s)
receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':'fresh_v6_queue_prepared_not_executed','candidate':head,'base':'1510186e56b81e8cbb36027746414a411c8e1f37','all_v4_records_preserved':True,'manifests':8,'full_gates':6,'native_tools':11,'new_shape_axiom_roots':21,'new_compatibility':'17 scalar headers/30 native grids plus10 shape headers and exact shape/generator hashes','same_one_cache':True,'resources':'16GiB/max2/OMP2/shared16CPUs','files_sha256':{p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in created}}
write(tmp/'stock-general-div-v6-preparation.json',json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items() if k!='files_sha256'}))
