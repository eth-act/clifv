from pathlib import Path
import os,json,time,subprocess,datetime
CURRENT_HEAD='22aef3dfa02980e4dfcac6276ad9ec863e546a91'
os.sched_setaffinity(0,set(range(16)))
root=Path('/home/lee/clifv/.worktrees/stock-mixed-div-20261022');e=os.environ.copy();e.update(json.load(open('/tmp/stock-mixed-div-env.json')));e['FV_MEMCAP']='8G';events=[]
def note(**row):
 row['utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();events.append(row);Path('/tmp/stock-general-div-main151-trust-controller.json').write_text(json.dumps(events,indent=2)+'\n');print(json.dumps(row),flush=True)
def run(name,args):
 log=Path('/tmp/stock-general-div-main151-controller-'+name+'.log');note(action='start',name=name,argv=args,log=str(log))
 with log.open('w') as f:p=subprocess.run(args,cwd=root,env=e,stdout=f,stderr=subprocess.STDOUT)
 note(action='done',name=name,exit=p.returncode)
 if p.returncode:raise SystemExit(p.returncode)
note(action='waiting_for_current_full_normal_v4')
while True:
 p=Path('/tmp/stock-general-div-normal-provenance-v4.json')
 if p.exists():
  r=json.load(p.open())
  if r['state']=='failed':note(action='current_full_normal_failed');raise SystemExit(1)
  if r['state']=='passed':
   assert r['source_head']==CURRENT_HEAD and r['source_unchanged']
   break
 time.sleep(20)
roots=Path('/tmp/stock-general-div-owned/normal-roots.txt').read_text().splitlines()
run('owned-normal',['python3','scripts/lake-serial-build.py','--budget','8G','--max-jobs','1','--max-cap','8G','--out','/tmp/stock-general-div-main151-owned-normal',*roots])
for category in ['axioms','owned']:
 run(category,['python3','scripts/stock-delivery-gates.py','resume','/tmp/stock-general-div-main151-'+category+'-manifest.json','--out','/tmp/stock-general-div-main151-'+category+'-current'])
run('old-production-axiom-parity',['python3','/tmp/stock-general-div-axiom-parity.py','/tmp/stock-general-div-main151-axioms-current/audits','/tmp/stock-general-div-main151-old-axiom-parity.json'])
run('old-sink-axiom-parity',['python3','/tmp/stock-div-source-axiom-parity.py','/tmp/stock-general-div-main151-axioms-current/audits/stock-no-load-sink.log','/tmp/stock-general-div-main151-old-sink-axiom-parity.json'])
run('old-headers-native-cases',['python3','/tmp/stock-general-div-compatibility-main151.py'])
note(action='trust_and_compatibility_finished',full_140_complete=False)
