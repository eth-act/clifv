from pathlib import Path
import os,signal,json,subprocess,datetime,time,sys
r=Path('/home/lee/clifv/.worktrees/stock-mixed-div-20261022');d=Path('/tmp/stock-general-div-iselshptabs30-repair');pid=1681039;proc=Path('/proc')/str(pid);assert 'scripts/lake-serial-build.py' in (proc/'cmdline').read_bytes().decode();born=(proc/'stat').read_text().split()[21];rows=[];paused=False
def handler(sig,frame):raise SystemExit(128+sig)
signal.signal(signal.SIGTERM,handler);signal.signal(signal.SIGINT,handler)
try:
 os.kill(pid,signal.SIGSTOP);paused=True
 while True:
  subprocess.run(['python3','/tmp/stock-general-div-observe.py'],stdout=subprocess.DEVNULL,check=True);o=json.loads(Path('/tmp/stock-general-div-latest-observation.json').read_text())
  if len(o['workers'])<=1 and sum(int(w['memory_cap']) for w in o['workers'])<=12*1024**3:break
  print(json.dumps({'state':'waiting_for_probe_slot_existing_compilers_untouched','workers':[(w['pid'],w['module']) for w in o['workers']]}),flush=True);time.sleep(10)
 env=os.environ.copy();env.update(json.loads(Path('/tmp/stock-mixed-div-env.json').read_text()));env.update(FV_MEMCAP='4G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2');out=d/('probe-diagnostics' if len(sys.argv)>1 else 'probe-root-fixed');out.mkdir(exist_ok=True)
 for source in ([Path(v) for v in sys.argv[1:]] if len(sys.argv)>1 else sorted((d/'candidate/FV/Backend/Proof').glob('IselShpTTabS30_rule*.lean'))):
  name=source.stem;env['FV_MEMCAP_STATS']=str(out/(name+'.mem'));start=time.monotonic();log=out/(name+'.log')
  with log.open('w') as f:ret=subprocess.run(['taskset','-c','14',str(r/'scripts/memcap.sh'),'lake','env','lean','--root='+str(d/'candidate'),str(source),'-o',str(out/(name+'.olean'))],cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
  row={'source':str(source),'exit':ret.returncode,'seconds':time.monotonic()-start,'log':str(log)};rows.append(row);print(json.dumps(row),flush=True)
  (d/'probe-receipt.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':'external_candidate_probe_not_full_normal_or_activation','cap':'4G','rows':rows,'all_ten_passed':len(rows)==10 and all(x['exit']==0 for x in rows),'scheduler_dispatch_paused':True},indent=2)+'\n')
  if ret.returncode:break
finally:
 if paused and proc.exists() and (proc/'stat').read_text().split()[21]==born:os.kill(pid,signal.SIGCONT)
 report={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':'external_candidate_probe_finished_not_activation','cap':'4G','rows':rows,'all_ten_passed':len(rows)==10 and all(x['exit']==0 for x in rows),'scheduler_dispatch_resumed':True,'existing_compiler_not_stopped':True,'aggregate_limit':'16GiB/max2'};(d/'probe-receipt.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
