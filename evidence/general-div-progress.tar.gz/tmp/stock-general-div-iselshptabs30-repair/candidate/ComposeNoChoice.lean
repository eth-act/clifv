import FV.Backend.Proof.IselShpTTabData
namespace ShapeChunkNoChoiceTest
set_option autoImplicit false
theorem all_of_chunks {α : Type} (g : α → Bool) (L : List α) (k n : Nat)
    (hn : L.length ≤ n * k) (h : ∀ c < n, ((L.drop (c * k)).take k).all g = true) :
    L.all g = true := by
  induction n generalizing L with
  | zero =>
    have empty : L = [] := List.length_eq_zero_iff.mp (Nat.eq_zero_of_le_zero (by simpa using hn))
    simp only [empty, List.all_nil]
  | succ n ih =>
    have first : (L.take k).all g = true := by
      simpa only [Nat.zero_mul, List.drop_zero] using h 0 (Nat.zero_lt_succ n)
    have bound : (L.drop k).length ≤ n * k := by
      rw [List.length_drop]
      apply Nat.sub_le_iff_le_add.mpr
      simpa only [Nat.succ_mul] using hn
    have tail : (L.drop k).all g = true := by
      apply ih (L.drop k) bound
      intro c hc
      simpa only [List.drop_drop, Nat.succ_mul, Nat.add_comm] using h (c+1) (Nat.succ_lt_succ hc)
    have both : ((L.take k) ++ L.drop k).all g = true := by
      simp only [List.all_append, Bool.and_eq_true]
      exact ⟨first,tail⟩
    simpa only [List.take_append_drop] using both
example (c : Nat) (hc : c + 8 < 8) : False :=
  Nat.not_lt_of_ge (Nat.le_add_left 8 c) hc
#print axioms all_of_chunks
end ShapeChunkNoChoiceTest
