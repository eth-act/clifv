import FV.Backend.Proof.IselShpTTabData
open Backend Backend.Proof Isle Isle.Aarch64 Backend.Proof.CovT
#eval IO.println s!"family8 environments {((aRuleEnvs program shpTabT aext actor apreST aOracleST [.inst [8]] rule_lower_2267).getD []).length}"
#eval IO.println s!"family9 environments {((aRuleEnvs program shpTabT aext actor apreST aOracleST [.inst [9]] rule_lower_2267).getD []).length}"
#eval IO.println s!"family count {famTab.length}"
