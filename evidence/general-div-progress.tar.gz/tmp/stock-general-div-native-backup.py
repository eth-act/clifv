from pathlib import Path
import subprocess,os,json,tarfile,hashlib,datetime
root=Path('/home/lee/clifv/.worktrees/stock-mixed-div-20261022');gate=Path('/tmp/stock-general-div-native-current');receipt=json.loads((gate/'receipt.json').read_text());assert receipt['state']=='passed'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert receipt['head']==head
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');out=Path('/tmp/stock-general-div-native-evidence-'+stamp);out.mkdir();paths={p for p in gate.rglob('*') if p.is_file()}
for pattern in ['stock-general-div-native*manifest.json','stock-general-div-runtime*log','stock-general-div-runtime*mem','stock-general-div-runtime*resources.json','stock-general-div-compatibility*','stock-general-div-mcp*','stock-general-div-prepare-*','stock-general-div-owned/partitions.json','stock-general-div-native-backup.py']:
 paths.update(p for p in Path('/tmp').glob(pattern) if p.is_file())
manifest={'source_head':head,'scope':'native/runtime gates only; whole production activation gates still pending','full_140_complete':False,'files':{str(p):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(paths)}};mp=out/'manifest.json';mp.write_text(json.dumps(manifest,indent=2)+'\n');archive=out/'native-runtime-evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=1) as t:
 for p in sorted(paths):t.add(p,arcname=str(p).lstrip('/'),recursive=False)
 t.add(mp,arcname='manifest.json')
assert archive.stat().st_size<80*1024*1024
with tarfile.open(archive) as t:
 for p in sorted(paths):assert hashlib.sha256(t.extractfile(str(p).lstrip('/')).read()).hexdigest()==manifest['files'][str(p)]['sha256']
def git(*args,**kw):return subprocess.check_output(['git',*args],cwd=root,**kw).decode().strip()
env=dict(os.environ,GIT_INDEX_FILE=str(out/'index'));git('read-tree',head,env=env);blob=git('hash-object','-w',str(archive));git('update-index','--add','--cacheinfo','100644',blob,'evidence/general-div-native-runtime.tar.gz',env=env);tree=git('write-tree',env=env);commit=git('commit-tree',tree,'-p',head,input=b'Back up passing general division native and runtime evidence; other activation gates pending\n');branch='agent/stock-general-div-native-evidence-'+stamp;git('update-ref','refs/heads/'+branch,commit);git('push','origin',commit+':refs/heads/'+branch);assert git('ls-remote','origin','refs/heads/'+branch).split()[0]==commit
r={'state':'remote_verified_native_runtime_only','source_head':head,'backup_commit':commit,'branch':branch,'archive':str(archive),'bytes':archive.stat().st_size,'files':len(paths),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'full_activation_gates_complete':False,'full_140_complete':False};Path('/tmp/stock-general-div-native-backup.json').write_text(json.dumps(r,indent=2)+'\n');(out/'index').unlink();print(json.dumps(r))
