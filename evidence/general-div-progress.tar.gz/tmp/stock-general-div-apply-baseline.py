from pathlib import Path
import os,signal,subprocess,time,json,datetime
root=Path('/home/lee/clifv/.worktrees/stock-mixed-div-20261022');stage=Path('/tmp/stock-general-div-ci-baseline');rows=[json.loads(x) for x in (stage/'outputs.jsonl').read_text().splitlines()][1:];assert all((stage/r[1]).is_file() for r in rows)
workers=[]
for n in os.listdir('/proc'):
 if not n.isdigit():continue
 p=Path('/proc')/n
 try:
  args=(p/'cmdline').read_bytes().split(b'\0')
  if any(x.endswith(b'/FV/Opt/Proof/RuleRestEmbedRotl.lean') for x in args) and args[0].endswith(b'/lean'):workers.append(int(n))
 except (FileNotFoundError,PermissionError,ProcessLookupError):pass
assert len(workers)==1,workers
pid=workers[0];p=Path('/proc')/str(pid);assert (p/'cwd').resolve()==root
cg=Path('/sys/fs/cgroup')/(p/'cgroup').read_text().split('0::',1)[1].strip().lstrip('/');usage=int((cg/'memory.current').read_text());assert usage<=7*1024**3,('wait for memory reservation',usage)
items=[(1608854,'/tmp/stock-general-div-retained-normal'),(1928210,'/tmp/stock-general-div-required-tools-normal'),(pid,'FV/Opt/Proof/RuleRestEmbedRotl.lean')];stopped=[];e=os.environ.copy();e.update(json.load(open('/tmp/stock-mixed-div-env.json')));e['FV_MEMCAP']='1G';e['FV_MEMCAP_STATS']='/tmp/stock-general-div-ci-baseline-unstage.mem'
def handler(sig,frame):raise SystemExit(128+sig)
signal.signal(signal.SIGTERM,handler);signal.signal(signal.SIGINT,handler);started=time.monotonic()
try:
 for i,part in items:
  q=Path('/proc')/str(i);assert part in (q/'cmdline').read_bytes().replace(b'\0',b' ').decode();birth=(q/'stat').read_text().split()[21];os.kill(i,signal.SIGSTOP);stopped.append((i,birth))
 with open('/tmp/stock-general-div-ci-baseline-unstage.log','w') as f:r=subprocess.run(['scripts/memcap.sh','lake','cache','unstage',str(stage)],cwd=root,env=e,stdout=f,stderr=subprocess.STDOUT,timeout=120)
 assert r.returncode==0,r.returncode
finally:
 for i,birth in reversed(stopped):
  q=Path('/proc')/str(i)
  if q.exists() and (q/'stat').read_text().split()[21]==birth:os.kill(i,signal.SIGCONT)
report={'state':'additive_cache_import_only_current_keys_still_required','ci_artifact':json.load(open('/tmp/stock-general-div-ci-baseline-artifact.json')),'mappings':len(rows),'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'paused_optimizer_memory_bytes':usage,'other_build_cap':'8G','maintenance_cap':'1G','force_overwrite':False,'seconds':time.monotonic()-started,'all_workers_resumed':True};Path('/tmp/stock-general-div-ci-baseline-restore.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
