from pathlib import Path,PurePosixPath
import os,json,subprocess,zipfile,hashlib,datetime,time,shutil,re,stat
os.sched_setaffinity(0,set(range(16)))
root=Path('/home/lee/clifv/.worktrees/stock-mixed-div-20261022');base='1510186e56b81e8cbb36027746414a411c8e1f37';aid=12559208638;name='stage-w1-8';env=os.environ.copy();env.update(json.loads(Path('/tmp/stock-mixed-div-env.json').read_text()));env.update(FV_MEMCAP='1G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2');cache=Path(env['FV_LAKE_CACHE']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert shutil.disk_usage(root).free>100*1024**3
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert head=='cd57ac630b3846a7b7832140b7e5f195452857fc'
meta=json.loads(subprocess.check_output(['gh','api',f'repos/eth-act/clifv/actions/artifacts/{aid}'],text=True));assert meta['workflow_run']['head_sha']==base and meta['workflow_run']['id']==40047096921 and meta['name']==name and not meta['expired']
dest=Path('/tmp/stock-general-div-main151-ci-'+name);dest.mkdir(exist_ok=False);(dest/'github-artifact.json').write_text(json.dumps(meta,indent=2)+'\n');zpath=dest/'artifact.zip'
with zpath.open('wb') as f:subprocess.run(['gh','api',f'repos/eth-act/clifv/actions/artifacts/{aid}/zip'],stdout=f,check=True,timeout=180)
digest=sha(zpath);assert meta['digest']=='sha256:'+digest
with zipfile.ZipFile(zpath) as z:
 total=sum(x.file_size for x in z.infolist());assert total<2*1024**3
 for x in z.infolist():
  p=PurePosixPath(x.filename);assert not p.is_absolute() and '..' not in p.parts and not stat.S_ISLNK(x.external_attr>>16)
 z.extractall(dest/'stage')
(dest/'download-provenance.json').write_text(json.dumps({'artifact':meta,'zip_sha256':digest,'expanded_bytes':total},indent=2)+'\n');outputs=list((dest/'stage').rglob('outputs.jsonl'));assert len(outputs)==1;out=outputs[0];values=[json.loads(x) for x in out.read_text().splitlines()];assert values[0]=='2026-03-17';entries=values[1:];assert entries
assert all(len(x)==2 and re.fullmatch('[0-9a-f]+',x[0]) and re.fullmatch('[0-9a-f]+[.]ltar',x[1]) for x in entries);archives={a for _,a in entries};assert all((out.parent/a).is_file() for a in archives)
files={str(p.relative_to(out.parent)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in [out]+[out.parent/a for a in sorted(archives)]};shutil.copyfile(out,dest/'outputs.jsonl');env['FV_MEMCAP_STATS']=str(dest/'unstage.mem');start=time.monotonic()
with (dest/'unstage.log').open('w') as f:result=subprocess.run(['scripts/memcap.sh','lake','cache','unstage',str(out.parent)],cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=60)
assert result.returncode==0,(dest/'unstage.log').read_text();receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':'cache_candidates_imported_no_gate_pass_claim','ci_run':40047096921,'ci_head':base,'artifact_id':aid,'source_head':head,'mappings':len(entries),'files':files,'exit':result.returncode,'seconds':time.monotonic()-start,'force_overwrite':False,'one_existing_cache':str(cache),'normal_current_key_checks_still_required':True};(dest/'import-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');rows=[]
for key,a in entries:
 assert sha(cache/'artifacts'/a)==files[a]['sha256'];mapping=cache/'outputs/fv'/(key+'.json');assert json.loads(mapping.read_text())['schemaVersion']=='2026-02-25';rows.append({'key':key,'archive':a,'archive_sha256':files[a]['sha256'],'cache_mapping':str(mapping),'mapping_sha256':sha(mapping)})
removed=zpath.stat().st_size+sum(p.stat().st_size for p in (dest/'stage').rglob('*') if p.is_file());(dest/'verified-import-and-cleanup.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':'imported_archive_bytes_and_mappings_verified_no_gate_pass','entries':rows,'redundant_zip_and_stage_bytes_removed':removed,'cache_preserved':str(cache)},indent=2)+'\n');zpath.unlink();shutil.rmtree(dest/'stage');print(json.dumps({'artifact':aid,'name':name,'mappings':len(entries),'zip_sha256':digest,'redundant_bytes_removed':removed,'exit':result.returncode}),flush=True)
