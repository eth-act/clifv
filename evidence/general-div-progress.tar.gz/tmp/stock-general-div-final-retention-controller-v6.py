from pathlib import Path
import os,json,time,subprocess,datetime
os.sched_setaffinity(0,set(range(16)))
root=Path('/home/lee/clifv/.worktrees/stock-mixed-div-20261022');e=os.environ.copy();e.update(json.load(open('/tmp/stock-mixed-div-env.json')));e['FV_MEMCAP']='8G';events=[]
def note(**r):
 r['utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();events.append(r);Path('/tmp/stock-general-div-main151-v6-final-retention-controller.json').write_text(json.dumps(events,indent=2)+'\n');print(json.dumps(r),flush=True)
def run(name,args):
 log=Path('/tmp/stock-general-div-main151-v6-controller-'+name+'.log');note(action='start',name=name,log=str(log))
 with log.open('w') as f:p=subprocess.run(args,cwd=root,env=e,stdout=f,stderr=subprocess.STDOUT)
 note(action='done',name=name,exit=p.returncode)
 if p.returncode:raise SystemExit(p.returncode)
note(action='waiting_for_consumer_gates')
while True:
 try:j=json.load(open('/tmp/stock-general-div-main151-v6-consumer-controller.json'))
 except (FileNotFoundError,json.JSONDecodeError):time.sleep(20);continue
 if any(x['action']=='done' and x.get('exit',0)!=0 for x in j):note(action='upstream_failed');raise SystemExit(1)
 if any(x['action']=='consumer_runtime_example_gates_finished' for x in j):break
 time.sleep(20)
run('identity-stage-parity',['python3','/tmp/stock-general-div-identity-stage-parity-main151-v6.py'])
run('retention',['python3','scripts/stock-delivery-gates.py','run','/tmp/stock-general-div-main151-v6-retention-manifest.json','--out','/tmp/stock-general-div-main151-v6-retention-current'])
note(action='identity_stage_flat_multiply_finished',full_140_complete=False)
