from pathlib import Path
import os,signal,subprocess,time,json,datetime
root=Path('/home/lee/clifv/.worktrees/stock-mixed-div-20261022');events=[]
def note(**r):
 r['utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();events.append(r);Path('/tmp/stock-general-div-unified-controller.json').write_text(json.dumps(events,indent=2)+'\n');print(json.dumps(r),flush=True)
report=json.load(open('/tmp/stock-general-div-rebalance-normal.json'));base=Path('/sys/fs/cgroup/user.slice/user-30034.slice/user@30034.service/clifv.slice')
units=[base/x['unit'] for x in report['workers']]
note(action='waiting_for_existing_healthy_scopes_to_drain',units=[str(p) for p in units])
while True:
 live=[]
 for c in units:
  try:procs=(c/'cgroup.procs').read_text().split()
  except FileNotFoundError:procs=[]
  if procs:live.append({'unit':c.name,'pids':procs})
 if not live:break
 note(action='verified_wait',live_scopes=live);time.sleep(45)
# No running compiler or packing process remains in either owned scope.
for pid,part in [(1725647,'stock-general-div-consumer-controller.py'),(2154480,'stock-general-div-full-assist-controller.py')]:
 p=Path('/proc')/str(pid)
 if p.exists():
  assert part in (p/'cmdline').read_bytes().replace(b'\0',b' ').decode();os.kill(pid,signal.SIGTERM)
for name in ['consumer-controller','full-assist-controller']:
 p=Path('/tmp/stock-general-div-'+name+'.json')
 if p.exists():Path('/tmp/stock-general-div-'+name+'-before-unified.json').write_bytes(p.read_bytes())
for pid in report['stopped_dispatchers']:
 p=Path('/proc')/str(pid)
 if p.exists():
  assert b'lake-serial-build.py' in (p/'cmdline').read_bytes();os.kill(pid,signal.SIGTERM);os.kill(pid,signal.SIGCONT)
while True:
 active=[]
 for pid in report['stopped_dispatchers']:
  p=Path('/proc')/str(pid)
  try:
   if (p/'stat').read_text().split()[2]!='Z':active.append(pid)
  except FileNotFoundError:pass
 if not active:break
 time.sleep(1)
note(action='start_unified_16GiB_two_worker_consumer_controller',old_attempts_preserved=True,source_unchanged=True)
e=os.environ.copy();e.update(json.load(open('/tmp/stock-mixed-div-env.json')))
with open('/tmp/stock-general-div-consumer-controller-v2-runner.log','w') as f:r=subprocess.run(['python3','/tmp/stock-general-div-consumer-controller-v2.py'],cwd=root,env=e,stdout=f,stderr=subprocess.STDOUT)
note(action='unified_controller_finished',exit=r.returncode)
raise SystemExit(r.returncode)
