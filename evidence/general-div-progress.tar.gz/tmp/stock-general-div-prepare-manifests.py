import json,subprocess,copy
from pathlib import Path
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();base='b631528b8c976c83bb7b181504407d99a2147f2e'
def replace(x):
 if isinstance(x,str):return x.replace('returned-div','general-div').replace('returneddiv','generaldiv').replace('RETURNED_DIV','GENERAL_DIV')
 if isinstance(x,list):return [replace(a) for a in x]
 if isinstance(x,dict):return {replace(k):replace(v) for k,v in x.items()}
 return x
for category in ['native','integration','full','examples']:
 m=replace(json.load(open('/tmp/stock-returned-div-'+category+'-manifest.json')));m.update(base=base,candidate=head);m.pop('validation_scope',None);Path('/tmp/stock-general-div-'+category+'-manifest.json').write_text(json.dumps(m,indent=2)+'\n')
m=json.load(open('/tmp/stock-returned-div-integration-manifest.json'));m.update(packet='general-div-retained-returneddiv',base=base,candidate=head);Path('/tmp/stock-general-div-retained-integration-manifest.json').write_text(json.dumps(m,indent=2)+'\n')
auditfiles=json.load(open('/tmp/stock-general-div-gate-preparation/prior-audit-files.json'))+['scripts/audit/stock-scalar-general-div.lean','scripts/audit/stock-no-load-sink.lean','scripts/audit/stock-general-div-production.lean']
m=json.load(open('/tmp/stock-general-div-full-manifest.json'));m.update(packet='general-div-affected-trust',gates=[{'id':'affected-axioms','argv':['python3','scripts/axiom-audit.py','--log-dir','{out}/audits',*auditfiles],'complete_inputs':False}]);Path('/tmp/stock-general-div-axioms-manifest.json').write_text(json.dumps(m,indent=2)+'\n')
print('PREPARED_SIX_CURRENT_HEAD_MANIFESTS',head)
