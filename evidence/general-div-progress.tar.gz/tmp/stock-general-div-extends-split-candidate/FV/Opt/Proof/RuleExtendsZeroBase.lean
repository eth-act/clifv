import FV.Opt.Proof.RuleIntSplit

/-!
# Comparisons of sign extensions against zero

The constructor's masked zero and signed re-extension evaluate before graph construction.
Preserve the non-i128 facts used by `fitsIn64_ofClif`, then specialize widths before the
right-hand side grows. Specialize the condition code before evaluating its if-let, so the
state-preserving helper reduces and the valuation chain remains connected.
At a float operand type the right-hand `iconst_s` has no rule (`tyInt_ofClif_f32`/`_f64`) and
the evaluation throws; a float extension result type (bit-level, like the integer type of its
width) adds arms, hence the heartbeat budgets.
The original `RuleOk` statements and premises are unchanged.
-/

set_option linter.unusedSimpArgs false
set_option maxRecDepth 8000
set_option Elab.async false

namespace Opt.Proof

open Isle Isle.Opt Clif

-- `Sem.icmp` returns `BitVec 8`; implicit argument checks must also see `.i8.width = 8`.
attribute [local implicit_reducible] Ty.width

theorem extends_zero_mask (x : Int) : Rust.band64 (Rust.asU64 0) x = 0 := by
  simp [Rust.band64, Rust.asU64]

theorem extends_zero_sext (w : Nat) : Rust.sext w 0 = 0 := by
  simp [Rust.sext]

attribute [local opt_imm] extends_zero_mask extends_zero_sext

open Lean Elab Tactic in
elab "extends_noinfo " t:tacticSeq : tactic => withEnableInfoTree false (evalTactic t)

set_option hygiene false in
macro "rule_extends_zero " r:ident : tactic => `(tactic| (
  rule_intro $r
  rule_lhs hG
  all_goals try opt_val_ty_subst
  opt_cases_val
  all_goals opt_split_i128
  opt_cases_ty
  opt_widths
  all_goals simp only [Ty.width, Nat.reduceLT] at *
  all_goals try contradiction
  all_goals (first | rule_no_iflets | rule_iflets_c [Rust.signedCondCode])
  all_goals rule_rhs_y [reduceCtorEq, Int.reduceBEq, tyInt_ofClif_f32, tyInt_ofClif_f64]
  all_goals opt_some_subst
  all_goals try contradiction
  all_goals rule_finish_x))

end Opt.Proof
