import FV.Opt.Proof.RuleExtendsZeroBase

set_option linter.unusedSimpArgs false
set_option maxRecDepth 8000
set_option Elab.async false
namespace Opt.Proof
open Isle Isle.Opt Clif
attribute [local implicit_reducible] Ty.width
attribute [local opt_imm] extends_zero_mask extends_zero_sext

set_option maxHeartbeats 12000000 in
/-- `extends.isle:42`: inequality to zero after sign extension. -/
theorem ok_rule_extends_42 {p : Isle.Program} (hd : Data p) : RuleOk p rule_extends_42 := by
  extends_noinfo rule_extends_zero rule_extends_42

end Opt.Proof
