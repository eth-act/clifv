import FV.Opt.Proof.RuleExtendsZeroEq
import FV.Opt.Proof.RuleExtendsZeroNe
import FV.Opt.Proof.RuleExtendsZeroSigned

set_option linter.unusedSimpArgs false
set_option maxRecDepth 8000
set_option Elab.async false
namespace Opt.Proof
open Isle Isle.Opt Clif
attribute [local implicit_reducible] Ty.width
attribute [local opt_imm] extends_zero_mask extends_zero_sext

/-! Concrete constructor and matching-guard witnesses, with zero and signed extrema. -/

example : Rust.band64 (Rust.asU64 0) (-1) = 0 := by decide
example : Rust.i64SextendU64 (CTy.ofClif .i8) 0 = .ok 0 ∧
    Rust.i64SextendU64 (CTy.ofClif .i64) 0 = .ok 0 := ⟨rfl, rfl⟩
example : Rust.sext 0 0 = 0 ∧ Rust.sext 128 0 = 0 := by decide

example : Ty.i16 ≠ .i128 ∧ Ty.i8.width < Ty.i16.width ∧ (0#16).toInt = 0 ∧
    Sem.icmp .eq (Sem.sextend 16 (0#8)) (0#16) = 1#8 ∧
    Sem.icmp .eq (0#8) (0#8) = 1#8 := by decide

example : Ty.i64 ≠ .i128 ∧ Ty.i32.width < Ty.i64.width ∧ (0#64).toInt = 0 ∧
    Sem.icmp .ne (Sem.sextend 64 (0x80000000#32)) (0#64) = 1#8 ∧
    Sem.icmp .ne (0x80000000#32) (0#32) = 1#8 := by decide

example : Ty.i32 ≠ .i128 ∧ Ty.i8.width < Ty.i32.width ∧ (0#32).toInt = 0 ∧
    Rust.signedCondCode .slt = some .slt ∧
    Sem.icmp .slt (Sem.sextend 32 (0x80#8)) (0#32) = 1#8 ∧
    Sem.icmp .slt (0x80#8) (0#8) = 1#8 := by decide

example :
    [(IntCC.sge, 0#16), (.sgt, 0x7fff#16), (.sle, 0x8000#16)].map
      (fun (cc, x) => (Rust.signedCondCode cc,
        Sem.icmp cc (Sem.sextend 64 x) (0#64), Sem.icmp cc x (0#16))) =
    [(some .sge, 1#8, 1#8), (some .sgt, 1#8, 1#8), (some .sle, 1#8, 1#8)] := by decide

end Opt.Proof
