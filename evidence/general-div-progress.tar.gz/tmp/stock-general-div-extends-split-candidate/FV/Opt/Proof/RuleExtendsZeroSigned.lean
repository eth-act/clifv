import FV.Opt.Proof.RuleExtendsZeroBase

set_option linter.unusedSimpArgs false
set_option maxRecDepth 8000
set_option Elab.async false
namespace Opt.Proof
open Isle Isle.Opt Clif
attribute [local implicit_reducible] Ty.width
attribute [local opt_imm] extends_zero_mask extends_zero_sext

set_option maxHeartbeats 48000000 in
/-- `extends.isle:44`: signed comparisons to zero after sign extension. -/
theorem ok_rule_extends_44 {p : Isle.Program} (hd : Data p) : RuleOk p rule_extends_44 := by
  extends_noinfo rule_extends_zero rule_extends_44

end Opt.Proof
