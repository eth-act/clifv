Scalar/division functions previously needed their one division result to be returned. The shared Stock selector now admits any number/order of existing scalar operations and i32/i64 divisions/remainders, including unused results and results consumed by later operations. The source check derives the existing full return/trap Domain from the source/driver proofs landed in #604; original operands, nine-argument fixtures, stack slots, and zero/overflow behavior are preserved.

The compiler/checker/linker/generated-proof consumers reuse the existing scalar route and complete legacy fallback. Earlier class selectors, theorem variants, route indices, retained artifact handling, and successful stages remain. This class does not establish Stock-only completeness or close #140.

Already passed on pushed d811c44a:

- Complete 288-configuration actual pipeline grid and source outcome/compiled-stage/arbitrary-entry witnesses.
- Nine new trust roots: standard-only generic source/selector proofs; one exact fixed native fact for the concrete grid.
- One source-bound MCP review of sourceOk_sound: standard axioms, no warnings.
- Both allocators / six ABI-width configurations / both cleanup modes, 61 functions per object (37 retained + 24 new), full retry/history and missing-oracle controls.
- 24 emitted objects, 14,640 actual Lean-byte executions vs 3,660 Cranelift reference executions: zero failures/disagreements.
- All 17 old public source-check headers and all 30 prior native profile/width case grids exact.

Before ready/merge: replace this paragraph with actual terminal current FV/FVTest/tool/consumer normal-key results, current and retained CLI/link/generated-proof cohorts, accumulated ownership and old axiom parity, runtime/encoder/both E2E identities-and-stages, original flat-multiply retention, verified examples, cleanup, remote terminal evidence, and latest-main reconciliation. Do not turn pending checks into passes or relabel earlier source provenance.

Existing evidence: native/runtime a3cda840; current full progress snapshot 0a265694 (explicitly not full activation validation). Final research receipt and obligation ledger must retain full_140_complete:false and identify the next original-scope implementation batch.

Refs #140; dependency #604. Squash only after current per-PR gates.
