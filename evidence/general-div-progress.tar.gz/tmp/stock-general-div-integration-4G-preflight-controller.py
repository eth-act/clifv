from pathlib import Path
import os,signal,subprocess,json,time,datetime
root=Path('/home/lee/clifv/.worktrees/stock-mixed-div-20261022');pid=3509078;proc=Path('/proc')/str(pid);birth=(proc/'stat').read_text().split()[21]
e=os.environ.copy();e.update(json.load(open('/tmp/stock-mixed-div-env.json')));e['FV_MEMCAP']='4G';e['FV_MEMCAP_STATS']='/tmp/stock-general-div-integration-4G-preflight.mem';events=[];held=False
out=Path('/tmp/stock-general-div-integration-4G-preflight');out.mkdir(exist_ok=False)
def note(**x):
 x['utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();events.append(x);Path('/tmp/stock-general-div-integration-4G-preflight-controller.json').write_text(json.dumps(events,indent=2)+'\n');print(json.dumps(x),flush=True)
def live():
 try:s=(proc/'stat').read_text().split();return s[21]==birth and s[2]!='Z'
 except FileNotFoundError:return False
def interrupted(sig,frame):raise SystemExit(128+sig)
signal.signal(signal.SIGINT,interrupted);signal.signal(signal.SIGTERM,interrupted)
try:
 assert live() and (proc/'cwd').resolve()==root
 assert b'scripts/lake-serial-build.py' in (proc/'cmdline').read_bytes()
 os.kill(pid,signal.SIGSTOP);held=True
 base=Path('/sys/fs/cgroup/user.slice/user-30034.slice/user@30034.service/clifv.slice');reserved=0
 for cg in base.glob(f'fvb-{pid}-*.scope'):
  try:
   if (cg/'cgroup.procs').read_text().strip():reserved+=int((cg/'memory.max').read_text())
  except FileNotFoundError:pass
 assert reserved<=12*1024**3,reserved
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()=='93257a5d711e21bae720fe44f2dd1c7494045e90'
 note(action='start',normal_reserved=reserved,preflight_cap='4GiB',source_head='93257a5d711e21bae720fe44f2dd1c7494045e90',canonical_current_gates_still_required=True)
 cpu=str(sorted(os.sched_getaffinity(0))[1]);log=Path('/tmp/stock-general-div-integration-4G-preflight.log')
 with log.open('w') as f:
  r=subprocess.run(['scripts/memcap.sh','taskset','-c',cpu,'python3','scripts/check-stock-mixed-integration.py','--output',str(out/'generaldiv'),'--class','generaldiv','--fixture-mode','native'],cwd=root,env=e,stdout=f,stderr=subprocess.STDOUT)
 note(action='done',exit=r.returncode,log=str(log),canonical_current_gates_still_required=True)
finally:
 if held and live():os.kill(pid,signal.SIGCONT);note(action='normal_dispatch_resumed')
