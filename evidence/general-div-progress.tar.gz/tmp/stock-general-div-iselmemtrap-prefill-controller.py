from pathlib import Path
import os,signal,json,subprocess,datetime,time,hashlib
root=Path('/home/lee/clifv/.worktrees/stock-mixed-div-20261022');pid=3509078;proc=Path('/proc')/str(pid);birth=(proc/'stat').read_text().split()[21];held=False;events=[]
e=os.environ.copy();e.update(json.load(open('/tmp/stock-mixed-div-env.json')));e['FV_MEMCAP']='11G';e['FV_MEMCAP_STATS']='/tmp/stock-general-div-iselmemtrap11G-prefill.mem';child=None
report=Path('/tmp/stock-general-div-iselmemtrap-prefill-controller.json');head='93257a5d711e21bae720fe44f2dd1c7494045e90'
def live():
 try:s=(proc/'stat').read_text().split();return s[21]==birth and s[2]!='Z'
 except FileNotFoundError:return False
def note(**x):
 x['utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();events.append(x);report.write_text(json.dumps(events,indent=2)+'\n');print(json.dumps(x),flush=True)
def interrupt(sig,frame):raise SystemExit(128+sig)
signal.signal(signal.SIGTERM,interrupt);signal.signal(signal.SIGINT,interrupt)
try:
 assert live() and b'/tmp/stock-general-div-required-tools-normal-v2' in (proc/'cmdline').read_bytes()
 os.kill(pid,signal.SIGSTOP);held=True
 base=Path('/sys/fs/cgroup/user.slice/user-30034.slice/user@30034.service/clifv.slice');reserved=0
 for cg in base.glob(f'fvb-{pid}-*.scope'):
  try:
   if (cg/'cgroup.procs').read_text().strip():reserved+=int((cg/'memory.max').read_text())
  except FileNotFoundError:pass
 assert reserved<=5*1024**3,reserved
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head
 assert subprocess.check_output(['nproc'],env=e,text=True).strip()=='2'
 source=root/'FV/Backend/Proof/IselMemTrap.lean';sha=hashlib.sha256(source.read_bytes()).hexdigest();pool=json.load(open('/tmp/stock-general-div-cpu-budget.json'))['shared_cpu_pool'];cpus=','.join(map(str,pool));log=Path('/tmp/stock-general-div-iselmemtrap11G-prefill.log');start=time.monotonic()
 note(action='start_single_module_retry',source_head=head,source_sha256=sha,normal_reserved_bytes=reserved,retry_cap='11GiB',aggregate_cap='16GiB/max2workers',shared_cpus=pool)
 with log.open('w') as f:
  child=subprocess.Popen(['taskset','-c',cpus,'scripts/memcap.sh','lake','build','FV.Backend.Proof.IselMemTrap'],cwd=root,env=e,stdout=f,stderr=subprocess.STDOUT);note(action='live',pid=child.pid);rc=child.wait()
 same=hashlib.sha256(source.read_bytes()).hexdigest()==sha and subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head
 note(action='done',exit=rc,seconds=time.monotonic()-start,source_unchanged=same,log=str(log),log_sha256=hashlib.sha256(log.read_bytes()).hexdigest(),canonical_full_normal_still_required=True)
finally:
 if child is not None and child.poll() is None:
  child.terminate();child.wait()
 if held and live():os.kill(pid,signal.SIGCONT);note(action='normal_dispatch_resumed')
