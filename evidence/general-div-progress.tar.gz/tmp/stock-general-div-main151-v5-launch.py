from pathlib import Path
import os,time,signal,json,subprocess,datetime
oldpid=1681039
oldbirth='250455554'
print('Waiting for existing normal1681039 to finish; no worker stopped',flush=True)
Path('/tmp/stock-general-div-main151-v5-handoff.json').write_text(json.dumps({'launcher_pid':os.getpid(),'state':'waiting_for_existing_normal','old_pid':oldpid,'old_birth':oldbirth,'candidate':'f9658adbf446bbd30f6b89ddda148e77d3a36b81','utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})+'\n')
while True:
 try: current_birth=Path('/proc',str(oldpid),'stat').read_text().split()[21]
 except FileNotFoundError: break
 if current_birth!=oldbirth: break
 time.sleep(10)
# The old retention waiter receives no done-event if V4 source comparison raises.
meta=json.load(open('/tmp/stock-general-div-main151-controllers.json'))
for child in meta['children']:
 if child['name']!='final-retention-controller-v4':continue
 p=Path('/proc',str(child['pid']))
 if p.exists() and (p/'stat').read_text().split()[21]==child['birth']:
  assert b'final-retention-controller-v4.py' in (p/'cmdline').read_bytes()
  os.kill(child['pid'],signal.SIGTERM)
Path('/tmp/stock-general-div-main151-v5-handoff.json').write_text(json.dumps({'launcher_pid':os.getpid(),'state':'starting_fresh_gates','old_normal_absent':True,'candidate':'f9658adbf446bbd30f6b89ddda148e77d3a36b81','utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})+'\n')
from pathlib import Path
import subprocess,os,json,datetime
root=Path('/home/lee/clifv/.worktrees/stock-mixed-div-20261022')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()=='f9658adbf446bbd30f6b89ddda148e77d3a36b81'
os.sched_setaffinity(0,set(range(16)))
e=os.environ.copy();e.update(json.load(open('/tmp/stock-mixed-div-env.json')))
assert e['OMP_NUM_THREADS']=='2' and e['OMP_THREAD_LIMIT']=='2'
assert subprocess.check_output(['nproc'],env=e,text=True).strip()=='2'
children=[];processes=[]
for name in ['consumer-controller-v5','trust-controller-v5','final-retention-controller-v5']:
 log=Path('/tmp/stock-general-div-main151-v5-'+name+'-runner.log')
 with log.open('w') as f:p=subprocess.Popen(['python3','/tmp/stock-general-div-'+name+'.py'],cwd=root,env=e,stdout=f,stderr=subprocess.STDOUT)
 processes.append(p)
 children.append({'name':name,'pid':p.pid,'birth':Path('/proc',str(p.pid),'stat').read_text().split()[21],'log':str(log)})
r={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':'f9658adbf446bbd30f6b89ddda148e77d3a36b81','base':'1510186e56b81e8cbb36027746414a411c8e1f37','resource_budget':'16GiB/max2compiler/shared16CPUs/onecache','effective_nproc':2,'children':children}
Path('/tmp/stock-general-div-main151-v5-controllers.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))

for p in processes:
 rc=p.wait();print(json.dumps({"terminal_pid":p.pid,"exit":rc}),flush=True)
