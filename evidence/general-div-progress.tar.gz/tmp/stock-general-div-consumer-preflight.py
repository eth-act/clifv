from pathlib import Path
import os,signal,subprocess,json,time,datetime,tomllib
root=Path('/home/lee/clifv/.worktrees/stock-mixed-div-20261022');e=os.environ.copy();e.update(json.load(open('/tmp/stock-mixed-div-env.json')));e['FV_MEMCAP']='8G';events=[]
def note(**r):
 r['utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();events.append(r);Path('/tmp/stock-general-div-consumer-preflight.json').write_text(json.dumps(events,indent=2)+'\n');print(json.dumps(r),flush=True)
def run(name,args):
 log=Path('/tmp/stock-general-div-preflight-'+name+'.log');note(action='start',name=name,argv=args,log=str(log))
 with log.open('w') as f:r=subprocess.run(args,cwd=root,env=e,stdout=f,stderr=subprocess.STDOUT)
 note(action='done',name=name,exit=r.returncode)
 if r.returncode:raise SystemExit(r.returncode)
guard=Path('/proc/3270399');assert b'stock-general-div-unified-controller.py' in (guard/'cmdline').read_bytes();assert not (guard/'task/3270399/children').read_text().strip();birth=(guard/'stat').read_text().split()[21]
assert Path('/proc/3172398').exists()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()=='d811c44a4abc8ec0331307f1540d3b570ea84338'
os.kill(3270399,signal.SIGSTOP);note(action='guardian_handoff_held_during_consumer_preflight',other_live_cap='6G',this_build_cap='8G',aggregate_max='14G',source_unchanged=True)
try:
 config=tomllib.loads((root/'lakefile.toml').read_text());names=['lean-backend','lean-backend-armrun','lean-backend-encode-test','lean-e2e-check','link-check','lean-link','arm-fault-cosim','stock-general-div-linked','stock-returned-div-runtime','stock-returned-div-linked'];targets={x['name']:x['root'] for x in config['lean_exe']}
 run('tool-normal',['python3','scripts/lake-serial-build.py','--budget','8G','--max-jobs','1','--max-cap','8G','--out','/tmp/stock-general-div-preflight-tool-normal',*[targets[n] for n in names]])
 cpu=str(min(os.sched_getaffinity(0)))
 for name in names:
  e['FV_MEMCAP_STATS']='/tmp/stock-general-div-preflight-build-'+name+'.mem'
  run('build-'+name,['scripts/memcap.sh','taskset','-c',cpu,'lake','build',name])
 e.pop('FV_MEMCAP_STATS',None)
 for category in ['integration','retained-integration','full','examples']:
  out=Path('/tmp/stock-general-div-'+category+'-current')
  run(category,['python3','scripts/stock-delivery-gates.py','resume' if out.exists() else 'run','/tmp/stock-general-div-'+category+'-manifest.json','--out',str(out)])
 note(action='consumer_preflight_finished_full_normal_still_required',full_140_complete=False)
finally:
 if guard.exists() and (guard/'stat').read_text().split()[21]==birth:os.kill(3270399,signal.SIGCONT)
 note(action='guardian_handoff_released')
