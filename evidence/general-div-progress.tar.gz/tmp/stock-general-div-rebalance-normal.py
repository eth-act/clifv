from pathlib import Path
import os,signal,subprocess,json,datetime
root=Path('/home/lee/clifv/.worktrees/stock-mixed-div-20261022')
controllers=[(1928210,'/tmp/stock-general-div-required-tools-normal'),(2518252,'/tmp/stock-general-div-full-assist-normal')]
for pid,part in controllers:
 p=Path('/proc')/str(pid);assert part in (p/'cmdline').read_bytes().replace(b'\0',b' ').decode();assert (p/'cwd').resolve()==root
for pid,_ in controllers:os.kill(pid,signal.SIGSTOP)
rows=[]
for pid,cap in [(3172398,6),(3043918,10)]:
 p=Path('/proc')/str(pid);assert (p/'cwd').resolve()==root
 c=Path('/sys/fs/cgroup')/(p/'cgroup').read_text().split('0::',1)[1].strip().lstrip('/')
 before=int((c/'memory.max').read_text());usage=int((c/'memory.current').read_text());assert usage<cap*1024**3
 subprocess.run(['systemctl','--user','set-property','--runtime',c.name,'MemoryMax='+str(cap)+'G'],check=True)
 assert int((c/'memory.max').read_text())==cap*1024**3
 rows.append({'pid':pid,'unit':c.name,'old_cap_bytes':before,'new_cap_bytes':cap*1024**3,'memory_current_at_change':usage})
report={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':'dispatch_paused_healthy_compilers_continue_until_drain','source_head':'d811c44a4abc8ec0331307f1540d3b570ea84338','aggregate_cap_bytes':sum(x['new_cap_bytes'] for x in rows),'workers':rows,'stopped_dispatchers':[p for p,_ in controllers]};assert report['aggregate_cap_bytes']==16*1024**3
Path('/tmp/stock-general-div-rebalance-normal.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
