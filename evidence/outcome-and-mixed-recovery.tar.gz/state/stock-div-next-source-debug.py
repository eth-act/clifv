from pathlib import Path
import json,os,subprocess
root=Path('/tmp/stock-div-mixed-source-check');pkg=root/'StockMixedSourceScratch';old=(pkg/'SourceChecks.lean').read_text();s=old[:old.index('private def sourceGrid')]+'''#eval do
  for config in configurations do
    for op in operations do
      for safe in [false,true] do
        for positive in [false,true] do
          let wanted := caseWanted config op safe positive
          let actual := caseRun config op safe positive
          unless outcomeAgrees (valueType config) wanted actual do
            let observed := match actual with
              | .returned vals _ => s!"returned {repr vals}"
              | .trapped code => s!"trapped {repr code}"
              | .stuck message => s!"stuck {message}"
              | .outOfFuel => "outOfFuel"
            IO.println s!"{repr config} {repr op} safe={safe} positive={positive}: wanted {repr wanted}; actual {observed}"
end E2E.StockMixedDivNIWitness
''';src=pkg/'SourceDebug.lean';src.write_text(s);e=os.environ.copy();e.update(json.load(open('/tmp/stock-div-release-env.json')));e['FV_MEMCAP']='6G';lp=subprocess.check_output(['scripts/memcap.sh','lake','env','printenv','LEAN_PATH'],env=e,text=True).strip();e['LEAN_PATH']=str(root)+':'+lp
with (root/'SourceDebug.log').open('w') as f:r=subprocess.run(['scripts/memcap.sh','lean','--root='+str(root),str(src)],env=e,stdout=f,stderr=subprocess.STDOUT)
print('rc',r.returncode);print((root/'SourceDebug.log').read_text()[:6500])
