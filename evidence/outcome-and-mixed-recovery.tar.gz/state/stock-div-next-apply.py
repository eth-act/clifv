from pathlib import Path
import subprocess,hashlib,json,datetime
root=Path.cwd();stage=Path('/tmp/stock-div-next-staged');existing=['FV/Backend/Lowering/StockScalar.lean','FV/Backend/Proof/StockScalarCheck.lean','scripts/check-stock-mixed-native.py','scripts/check-stock-mixed-integration.py'];paths=sorted(p for p in stage.rglob('*') if p.is_file() and p.suffix in ['.lean','.py']);tracked=subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],text=True);assert not tracked,'Preserve unpublished tracked source: worktree must be clean before this batch'
# Finish all preflight checks before any write; shared-file edits must still be the exact prepared base.
for p in paths:
 rel=str(p.relative_to(stage));dest=root/rel
 if rel in existing:
  old=subprocess.check_output(['git','show','6a80a595:'+rel]);assert dest.read_bytes()==old,('reconcile current source before applying',rel)
 else:assert not dest.exists(),('preserve existing unpublished path',rel)
lake=root/'lakefile.toml';addition=(stage/'lakefile-additions.toml').read_text();assert 'name = "stock-mixed-div-runtime"' not in lake.read_text();assert 'name = "stock-mixed-div-linked"' not in lake.read_text();head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();records=[]
for p in paths:
 dest=root/p.relative_to(stage);dest.parent.mkdir(parents=True,exist_ok=True);b=p.read_bytes();dest.write_bytes(b);records.append({'path':str(p.relative_to(stage)),'sha256':hashlib.sha256(b).hexdigest()})
lake.write_text(lake.read_text()+addition)
r={'base':head,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Applied complete mixed-prefix/final-division implementation and prepared consumers; normal proof/witness/native/production validation pending, not an activation success claim.','files':records};Path('/tmp/stock-div-next-applied.json').write_text(json.dumps(r,indent=2)+'\n');subprocess.run(['git','diff','--check'],check=True);print(json.dumps(r,indent=2))
