from pathlib import Path
import os,json,subprocess
root=Path('/tmp/stock-div-mixed-source-check');old=(root/'StockMixedSourceScratch/SourceChecks.lean').read_text();src=root/'ObserverProof.lean';src.write_text(old[:old.index('private def sourceGrid')].replace('match wanted with','match (generalizing := false) wanted with')+'''example (op : Clif.DivOp) : op ∈ operations := by
  cases op <;> simp [operations,StockDivNIWitness.operations]

theorem source_cases_from_checked (config : Configuration) (op : Clif.DivOp) (safe positive : Bool)
    (observed : sourceCases config op safe = true) :
    match caseWanted config op safe positive with
    | .error code => caseRun config op safe positive = .trapped code
    | .ok bits => ∃ mem,caseRun config op safe positive = .returned [⟨valueType config,bits⟩] mem := by
  simp only [sourceCases,Bool.and_eq_true] at observed
  have checked : outcomeAgrees (valueType config) (caseWanted config op safe positive)
      (caseRun config op safe positive) = true := by
    cases positive with
    | false => exact observed.1
    | true => exact observed.2
  have result := outcomeAgrees_sound (ty := valueType config)
    (wanted := caseWanted config op safe positive) (actual := caseRun config op safe positive) checked
  cases wanted : caseWanted config op safe positive <;> simpa only [wanted] using result
end E2E.StockMixedDivNIWitness
''');E=os.environ.copy();E.update(json.load(open('/tmp/stock-mixed-div-env.json')));E['FV_MEMCAP']='6G';lp=subprocess.check_output(['scripts/memcap.sh','lake','env','printenv','LEAN_PATH'],env=E,text=True).strip();E['LEAN_PATH']=str(root)+':'+lp
with (root/'ObserverProof.log').open('w') as f:r=subprocess.run(['scripts/memcap.sh','lean',str(src)],env=E,stdout=f,stderr=subprocess.STDOUT)
print(r.returncode);print((root/'ObserverProof.log').read_text()[-1800:])
