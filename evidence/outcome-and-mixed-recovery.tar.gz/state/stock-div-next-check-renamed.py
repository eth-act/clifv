from pathlib import Path
import json,os,subprocess,hashlib,datetime,re
root=Path('/tmp/stock-div-mixed-import-check-renamed');pkg=root/'StockMixedRenamedScratch';pkg.mkdir(parents=True,exist_ok=True);stage=Path('/tmp/stock-div-next-staged');parts=json.load(open(stage/'partition.json'))['parts'];E=os.environ.copy();E.update(json.load(open('/tmp/stock-div-release-env.json')));E['FV_MEMCAP']='6G';lp=subprocess.check_output(['scripts/memcap.sh','lake','env','printenv','LEAN_PATH'],env=E,text=True).strip();E['LEAN_PATH']=str(root)+':'+lp;records=[]
def imports(s):
 for p in parts:s=s.replace('import '+p['path'][:-5].replace('/','.'),'import StockMixedRenamedScratch.'+Path(p['path']).stem)
 return s
for p in parts:
 src=stage/p['path'];dest=pkg/src.name;dest.write_text(imports(src.read_text()));log=root/(dest.stem+'.log')
 with log.open('w') as f:r=subprocess.run(['scripts/memcap.sh','lean','--root='+str(root),'-o',str(dest.with_suffix('.olean')),str(dest)],env=E,stdout=f,stderr=subprocess.STDOUT)
 records.append({'module':p['path'],'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'returncode':r.returncode,'log':str(log)});print(dest.stem,r.returncode,flush=True)
 if r.returncode:print(log.read_text()[-1800:]);break
else:
 lines=(stage/'scripts/audit/stock-mixed-div-production.lean').read_text().splitlines();audit=imports(lines[0]+'\n'+'\n'.join(x for x in lines if x.startswith('#print axioms Backend.') and 'mixedDivEligible_sound' not in x)+'\n');src=root/'Review.lean';src.write_text(audit);log=root/'all-roots.log'
 with log.open('w') as f:r=subprocess.run(['scripts/memcap.sh','lean',str(src)],env=E,stdout=f,stderr=subprocess.STDOUT)
 text=' '.join(log.read_text().split());roots=re.findall(r"'(.+?)' depends on axioms: \[([^]]*)\]",text);clean=re.findall(r"'(.+?)' does not depend on any axioms",text);other={a.strip() for _,axes in roots for a in axes.split(',')} - {'propext','Classical.choice','Quot.sound'};good=r.returncode==0 and len(roots)+len(clean)==21 and not other;records.append({'module':'bundled21newgenericroots','returncode':r.returncode,'standard_only':good,'log':str(log)});print('generic roots',len(roots)+len(clean),'Std3',good,flush=True)
state='passed' if len(records)==8 and not any(x['returncode'] for x in records) and records[-1].get('standard_only') else 'failed';Path('/tmp/stock-div-next-renamed-split-check.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actual_current_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'state':state,'scope':'Isolated actual renamed split module compile; old saved generic W interfaces kept intact. Full actual production classifier/pipeline/consumer activation still pending.','records':records},indent=2)+'\n');raise SystemExit(0 if state=='passed' else 1)
