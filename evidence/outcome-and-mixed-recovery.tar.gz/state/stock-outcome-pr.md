Proof-only additions to `LowerSim` currently invalidate preparation, generated interpreter proofs and isel totality. This extracts the existing VCode return/trap outcomes, prefix lemmas, argument-entry definition and reachability inductive into `LowerOutcomes`, preserving their names and bodies. Preparation and E2E statements import the stable interface; E2E composition explicitly imports the simulation it uses.

All107 existing public theorem headers and the extracted bodies are unchanged. Static import closure confirms `IselShpTotal`, `DefGenWrap` and `IselPrgTryLast` no longer depend on `LowerSim`. The boundary was coordinated on #140. Static future `LowerSim` reverse closure shrinks from1202 to1007 modules (195removed; this is not a measured wall-clock speedup). No compiler behavior changes.

Validation is running (candidate9f16daa5, preserved first-pass missing-import failure and explicit-import repair): affected normal module keys, required executable/consumer keys and checked axiom audits. This PR will merge only after the applicable author gates pass; final results will replace this paragraph.

Part of #140; does not close its remaining production/completeness obligations.
