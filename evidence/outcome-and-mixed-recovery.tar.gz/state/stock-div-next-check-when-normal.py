from pathlib import Path
import os,signal,time,json,subprocess
matches=[]
for f in Path('/proc').iterdir():
 if not f.name.isdigit():continue
 try:args=(f/'cmdline').read_bytes().decode().split('\0')
 except OSError:continue
 if len(args)>1 and args[1]=='/tmp/stock-div-current-consumer-gates-v2.py':matches.append(int(f.name))
assert len(matches)==1,matches
p=matches[0];os.kill(p,signal.SIGSTOP)
try:
 gate=Path('/tmp/stock-div-reconciled-current-normal-author/affected-library-keys.json')
 while not gate.exists():
  worker=json.load(open('/tmp/stock-div-current-normal-worker-pid.json'))['pid']
  if not Path(f'/proc/{worker}/cmdline').exists():raise SystemExit('Current library refresh ended without key gate; no split validation attempted')
  time.sleep(1)
 while json.load(open(gate))['state']=='running':time.sleep(0.2)
 assert json.load(open(gate))['state']=='passed'
 s=Path('/tmp/stock-div-next-check-splits-2.py').read_text()
 s=s.replace('p=479609;',f'p={p};').replace("assert 'stock-div-current-final-pr-build' in cmd","assert 'stock-div-current-consumer-gates-v2' in cmd")
 s=s.replace("'/tmp/stock-div-next-split-check-2.json'","'/tmp/stock-div-next-split-check-3.json'").replace("dest.stem+'-2.log'","dest.stem+'-3.log'").replace("root/'all-roots-2.log'","root/'all-roots-3.log'")
 Path('/tmp/stock-div-next-check-splits-3.py').write_text(s)
 r=subprocess.run(['python3','/tmp/stock-div-next-check-splits-3.py']);print('isolated split checker',r.returncode,flush=True)
finally:
 if Path(f'/proc/{p}/cmdline').exists():os.kill(p,signal.SIGCONT)
