import StockMixedSourceScratch.Fixtures
namespace E2E.StockMixedDivNIWitness
open Backend.Stock.D0
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
/-- Concrete original inputs used only to witness actual source outcomes. -/
private def caseInput (config : Configuration) (positive : Bool) : Nat → BitVec (valueType config).width :=
  fun i => BitVec.ofNat _ (if positive then 2*i+1 else 0)

private def caseWanted (config : Configuration) (op : Clif.DivOp) (safe positive : Bool) :=
  let input := caseInput config positive
  Clif.Sem.div op (StockHighMulNIWitness.resultValue config input) (if safe then 2 else input 8)

private def caseRun (config : Configuration) (op : Clif.DivOp) (safe positive : Bool) : Clif.Outcome :=
  Clif.runLoop Clif.Env.empty {funcs := []} 250
    ⟨frame config op safe (caseInput config positive) 4096,[],Clif.Mem.empty⟩

private def outcomeAgrees (ty : Clif.Ty) (wanted : Except Clif.TrapCode (BitVec ty.width))
    (actual : Clif.Outcome) : Bool :=
  match wanted,actual with
  | .error code,.trapped observed => code == observed
  | .ok bits,.returned vals _ => decide (vals = [⟨ty,bits⟩])
  | _,_ => false

private def sourceCases (config : Configuration) (op : Clif.DivOp) (safe : Bool) : Bool :=
  outcomeAgrees (valueType config) (caseWanted config op safe false) (caseRun config op safe false) &&
  outcomeAgrees (valueType config) (caseWanted config op safe true) (caseRun config op safe true)

private theorem outcomeAgrees_sound {ty : Clif.Ty}
    {wanted : Except Clif.TrapCode (BitVec ty.width)} {actual : Clif.Outcome}
    (checked : outcomeAgrees ty wanted actual = true) :
    match wanted with
    | .error code => actual = .trapped code
    | .ok bits => ∃ mem,actual = .returned [⟨ty,bits⟩] mem := by
  cases wanted with
  | error code =>
    cases actual with
    | trapped observed =>
      change (code == observed) = true at checked
      have equal : code = observed := beq_iff_eq.mp checked
      cases equal
      rfl
    | returned vals mem => change false = true at checked; cases checked
    | stuck message => change false = true at checked; cases checked
    | outOfFuel => change false = true at checked; cases checked
  | ok bits =>
    cases actual with
    | returned vals mem =>
      change decide (vals = [Clif.Val.mk ty bits]) = true at checked
      have equal : vals = [Clif.Val.mk ty bits] := of_decide_eq_true checked
      subst vals
      exact ⟨mem,rfl⟩
    | trapped code => change false = true at checked; cases checked
    | stuck message => change false = true at checked; cases checked
    | outOfFuel => change false = true at checked; cases checked




#eval do
  for config in configurations do
    for op in operations do
      for safe in [false,true] do
        for positive in [false,true] do
          let wanted := caseWanted config op safe positive
          let actual := caseRun config op safe positive
          unless outcomeAgrees (valueType config) wanted actual do
            let observed := match actual with
              | .returned vals _ => s!"returned {repr vals}"
              | .trapped code => s!"trapped {repr code}"
              | .stuck message => s!"stuck {message}"
              | .outOfFuel => "outOfFuel"
            IO.println s!"{repr config} {repr op} safe={safe} positive={positive}: wanted {repr wanted}; actual {observed}"
end E2E.StockMixedDivNIWitness
