from pathlib import Path
import subprocess,json,hashlib,datetime,os
b=Path('/home/lee/clifv');e=b/'.git/agent-evidence/stock-memory-20261029';r=b/'.worktrees/stock-extending-production-20261031';stage=e/'integer-store-function-module-paths-v1';state=e/'integer-store-functions-publication-v1.json'
def save(status,**x):state.write_text(json.dumps(dict(status=status,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),full_goal_complete=False,**x),indent=2)+'\n')
def git(*args,env=None):return subprocess.check_output(['git',*args],cwd=r,env=env,text=True).strip()
try:
 check=json.loads((e/'integer-store-function-module-paths-state-v1.json').read_text());assert check['status']=='passed' and check['audit_roots']==44 and check['prior_axiom_sets_exact']==29
 base=check['base'];assert git('rev-parse','HEAD')==base and not git('status','--porcelain')
 parent=json.loads(subprocess.check_output(['gh','pr','view','797','--repo','eth-act/clifv','--json','state,headRefOid,headRefName'],cwd=r,text=True));assert parent['state']=='OPEN' and parent['headRefOid']==base,parent
 files={n:data['sha256'] for n,data in check['source'].items()};audit='scripts/audit/stock-memory-store-functions.lean';files[audit]=hashlib.sha256((stage/audit).read_bytes()).hexdigest()
 assert all(hashlib.sha256((stage/n).read_bytes()).hexdigest()==h for n,h in files.items())
 branch='agent/stock-store-functions-packet-20261031';assert not git('branch','--list',branch)
 index=e/'integer-store-functions-publish-v1.index';index.unlink(missing_ok=True);env=dict(os.environ,GIT_INDEX_FILE=str(index));git('read-tree',base,env=env)
 for n in files:
  assert not git('ls-tree',base,'--',n),n
  git('update-index','--add','--cacheinfo','100644,'+git('hash-object','-w',str(stage/n))+','+n,env=env)
 subprocess.run(['git','diff','--cached','--check'],cwd=r,env=env,check=True)
 assert set(git('diff','--cached','--name-only',env=env).splitlines())==set(files)
 commit=git('commit-tree',git('write-tree',env=env),'-p',base,'-m','Prove complete Stock store functions and source domains');git('update-ref','refs/heads/'+branch,commit);index.unlink()
 save('running',phase='push',commit=commit,branch=branch,base=base)
 subprocess.run(['git','push','origin',branch],cwd=r,check=True);assert git('ls-remote','origin','refs/heads/'+branch).split()[0]==commit
 body=e/'integer-store-functions-pr-v1.md';body.write_text('''Prove complete source contracts and paired execution for singleton integer-store functions. Derive retention, parameter types, operand mappings, scan composition and ABI entry/return from original source syntax. Keep the original memory and ABI conditions.

Complete witnesses cover all seven forms. A second witness starts with unknown source bytes and different machine bytes, then executes both complete functions with the same updated source memory. The source class derives the original return/trap contract. No compiler behavior changes in this packet.

Validation: all thirteen actual module identities passed kernel checks. All44 audited roots use standard axioms, and all29 previous axiom sets remain exact. The staged sources compile into the existing view outputs without changing its frozen source. Full per-PR checks follow parent landing.

Depends on #797. This PR targets its branch until that PR lands; it will then reconcile onto current main. The source commit is remotely verified. No review agents or human review gate apply. The full original#140, production store activation and every remaining family/completeness obligation remain active.
''')
 url=subprocess.check_output(['gh','pr','create','--repo','eth-act/clifv','--base',parent['headRefName'],'--head',branch,'--title','Prove complete Stock store functions and source domains','--body-file',str(body)],cwd=r,text=True).strip()
 save('passed',pr=int(url.rsplit('/',1)[1]),url=url,commit=commit,branch=branch,base=base,parent_pr=797,parent_branch=parent['headRefName'],remote_verified=True,source_hashes=files,audit_roots=44,prior_axiom_sets_exact=29,all_axioms_standard=True)
 print(json.dumps(dict(pr=int(url.rsplit('/',1)[1]),commit=commit,url=url,full_goal_complete=False)))
except BaseException as error:save('failed',error=repr(error));raise
