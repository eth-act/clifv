from pathlib import Path
import psutil,subprocess,json,hashlib,os,time,datetime,shutil
b=Path('/home/lee/clifv');e=b/'.git/agent-evidence/stock-memory-20261029';r=b/'.worktrees/stock-extending-production-20261031';stage=e/'integer-store-native-stage-v1';out=e/'integer-store-native-stage-artifacts-v1';state=e/'integer-store-native-stage-state-v2.json';paused=None;records=[]
files=['FV/Backend/MemoryStoreNIProductionStage.lean','FVTest/Backend/Lowering/StockMemoryStoreNativeStage.lean'];hashes={str(stage/n):hashlib.sha256((stage/n).read_bytes()).hexdigest() for n in files};c=e/'stock-memory-store-native.c';hashes[str(c)]=hashlib.sha256(c.read_bytes()).hexdigest()
def save(status,**x):state.write_text(json.dumps(dict(status=status,records=records,source_hashes=hashes,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),**x),indent=2)+'\n')
def live(p):
 try:return p.is_running() and p.status()!=psutil.STATUS_ZOMBIE
 except psutil.NoSuchProcess:return False
def frozen():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()=='330e55698e83dbfe80a6524a6e916a44f6a3dd8b'
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=r,text=True).strip()
 assert all(hashlib.sha256(Path(n).read_bytes()).hexdigest()==h for n,h in hashes.items())
try:
 assert json.loads((e/'integer-store-shared-proof-stage-state-v1.json').read_text())['status']=='passed'
 frozen();paused=psutil.Process(363555);assert 'scripts/lake-serial-build.py' in paused.cmdline();paused.suspend()
 while True:
  children=[p for p in paused.children() if live(p)];caps=[]
  for p in children:
   raw=p.environ().get('FV_MEMCAP','');caps.append(float(raw[:-1]) if raw.endswith('G') else float(raw[:-1])/1024 if raw.endswith('M') else 1000)
  if len(children)<=1 and sum(caps)<=12:break
  save('waiting',phase='finish-current-active-source',caps_GiB=caps);time.sleep(3)
 env=dict(os.environ);env.update(json.loads((e/'author-env-v1.json').read_text()));env.update(FV_ROOT=str(r),FV_MEMCAP='4G',OMP_NUM_THREADS='1',OMP_THREAD_LIMIT='1',LEAN_NUM_THREADS='1',CARGO_BUILD_JOBS='1',PYTHONDONTWRITEBYTECODE='1')
 clang=shutil.which('clang',path=env['PATH']);qemu=shutil.which('qemu-aarch64-static',path=env['PATH']);assert clang and qemu
 def run(label,args):
  frozen();save('running',phase=label);env['FV_MEMCAP_STATS']=str(e/('integer-store-native-stage-'+label+'-v2.stats'))
  with (e/('integer-store-native-stage-'+label+'-v2.log')).open('w') as log:done=subprocess.run(['nice','-n','10',str(r/'scripts/memcap.sh'),*map(str,args)],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
  records.append(dict(label=label,returncode=done.returncode));assert done.returncode==0,(label,done.returncode)
 for n in files[1:]:run(Path(n).stem,['lake','env','lean','-j1','--root='+str(stage),'-o',r/'.lake/build/lib/lean'/Path(n).with_suffix('.olean'),stage/n])
 out.mkdir(exist_ok=True)
 run('objects',['lake','env','lean','-j1','--root='+str(stage),'--run',stage/files[1],out])
 matrix=json.loads((e/'integer-store-native-matrix-source-v1.json').read_text())['pairs'];assert len(matrix)==13
 for pair in matrix:
  for cleanup in ['plain','cleanup']:
   label=pair['op']+'-'+pair['ty']+'-'+cleanup;obj=out/(label+'.o');assert obj.exists();exe=out/(label+'.elf')
   run(label+'-link',[clang,'--target=aarch64-linux-gnu','-O2','-ffreestanding','-nostdlib','-fno-builtin','-fno-stack-protector','-static','-fuse-ld=lld','-Wl,-e,_start','-DFV_STORE_FREESTANDING','-DSTORE_BYTES='+str(pair['bytes']),c,obj,'-o',exe])
   run(label+'-native',[qemu,exe])
 frozen();save('passed',pairs=13,cleanup_modes=2,operand_orders=2,native_store_calls=572,retained_calls=26,allocator_binding=True,forced_previous_file_retry_exact=True,artifacts={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.is_file()},scope='Actual compiled store objects execute under qemu through an isolated checker/producer stage. Shipped default and generic linker/generated consumers remain unchanged and unvalidated for stores.')
except BaseException as error:save('failed',error=repr(error));raise
finally:
 if paused is not None and live(paused):paused.resume()
