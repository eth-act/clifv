from pathlib import Path
import os,subprocess,json,datetime,re,hashlib
b=Path('/home/lee/clifv');r=b/'.worktrees/stock-cfg-source-20261025';e=b/'.git/agent-evidence/stock-memory-20261029';state=e/'integer-memory-integrated-state-v1.json';records=[]
env=dict(os.environ);env.update(json.loads((e/'author-env-v1.json').read_text()));env.update(FV_ROOT=str(r),FV_MEMCAP='16G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',CARGO_BUILD_JOBS='2');env.pop('FV_PIPELINE_T',None)
def save(status,**extra):state.write_text(json.dumps(dict(status=status,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),records=records,**extra),indent=2)+'\n')
def run(label,args):
 save('running',phase=label)
 with(e/('integer-memory-integrated-'+label+'-v1.log')).open('w') as log:done=subprocess.run(['nice','-n','10',str(r/'scripts/memcap.sh'),*args],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 records.append(dict(label=label,returncode=done.returncode));assert done.returncode==0,(label,done.returncode)
try:
 names=['StockMemoryHelperProjection','StockMemoryHelperContracts','StockMemoryHelperForward','StockMemoryHelperWitness'];paths=[r/('FV/Backend/Proof/'+n+'.lean') for n in names];before={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths};assert all(p.read_bytes()==(e/(p.stem+'.next.lean')).read_bytes() for p in paths)
 run('build',['python3','scripts/lake-serial-build.py','--budget','16G','--max-jobs','2','--max-cap','16G','--default-cap','8G','--profile',str(r/'scripts/lake-module-peaks.tsv'),'--out',str(e/'integer-memory-integrated-modules-v1'),*['FV.Backend.Proof.'+n for n in names]])
 run('audit',['lake','env','lean','scripts/audit/stock-memory-integer-forward.lean'])
 def axioms(text):return {n:set(x.strip() for x in a.split(',')) for n,a in re.findall(r"'([^']+)' depends on axioms: \[([^]]*)\]",text,re.S)}
 actual=axioms((e/'integer-memory-integrated-audit-v1.log').read_text());assert len(actual)==12 and all(a=={'propext','Classical.choice','Quot.sound'} for a in actual.values());assert before=={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
 save('passed',modules=4,audit_roots=12,all_axioms_standard=True,source_unchanged=True,sources=before,scope='Integer load/store helper execution and full scheduling state. Enclosing roots/source-machine effects remain the next required work.')
except BaseException as error:save('failed',error=repr(error));raise
