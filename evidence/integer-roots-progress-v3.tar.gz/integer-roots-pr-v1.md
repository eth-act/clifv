Prove actual unsigned Stock load selection for8-,16-,32- and64-bit source values. The address selector uses the mapped parameter, rules out higher-priority defining-instruction paths internally, and preserves its demand update. Each load RHS allocates the exact fresh register and emits the exact zero-offset instruction with the complete resulting state.

Positive witnesses build a real source context for every width, with the original parameter mapped to register192. Actual first-match Stock `lower` term evaluation succeeds and ends at the expected root1041–1044. Separate witnesses inhabit each exact RHS contract. Existing theorem interfaces and production routes remain unchanged.

Validation:182/182 modules passed on current main55f32cdf. All five audited public roots use only standard axioms. All four first-match witnesses use kernel evaluation. The source fingerprint remains exact. The earlier fixture syntax failure and launcher path error remain preserved separately from these successful gates. Receipt:integer-load-roots-state-v2.json.

Part of#140. This packet establishes actual selection and execution. Retained-record binding, source/machine effects and wider production classes continue next. The generic source/machine load contracts already exist and will be reused.
