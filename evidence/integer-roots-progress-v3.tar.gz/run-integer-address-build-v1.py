from pathlib import Path
import subprocess,json,datetime,os,hashlib
b=Path('/home/lee/clifv');r=b/'.worktrees/stock-cfg-source-20261025';e=b/'.git/agent-evidence/stock-memory-20261029';state=e/'integer-address-build-state-v1.json';source=r/'FV/Backend/Proof/StockMemoryIntegerAddress.lean';before=hashlib.sha256(source.read_bytes()).hexdigest();env=dict(os.environ);env.update(json.loads((e/'author-env-v1.json').read_text()));env.update(FV_ROOT=str(r),FV_MEMCAP='16G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',CARGO_BUILD_JOBS='1')
def save(status,**x):state.write_text(json.dumps(dict(status=status,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=before,**x),indent=2)+'\n')
try:
 save('running')
 with(e/'integer-address-build-v1.log').open('w') as log:done=subprocess.run(['nice','-n','10',str(r/'scripts/memcap.sh'),'python3','scripts/lake-serial-build.py','--budget','14G','--max-jobs','1','--max-cap','14G','--default-cap','14G','--out',str(e/'integer-address-modules-v1'),'FV.Backend.Proof.StockMemoryIntegerAddress'],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 assert done.returncode==0 and hashlib.sha256(source.read_bytes()).hexdigest()==before
 save('passed',returncode=0,scope='Build output required for actual load-root import. Root contracts/audits remain next.')
except BaseException as error:save('failed',error=repr(error));raise
