Prove direct Stock execution for all seven integer load helpers and all four integer store helpers. Loads allocate the exact fresh register and emit the decoded instruction. Stores return the exact side-effect payload. Every contract preserves the complete scheduling state and records the exact helper trace.

A checked27-term constructor closure transfers successful Stock helper runs to the existing legacy contracts and replays successful legacy calls. Concrete witnesses cover every variant. Existing statements, source conditions and production routes remain unchanged.

Current-base validation on main3812875d:179/179 modules passed; all four new modules build; all12 audit roots use exactly propext, Classical.choice and Quot.sound. The integrated source matches the earlier checked source exactly. The audit is maintained in scripts/audit/stock-memory-integer-forward.lean.

This packet establishes helper execution. Enclosing root emission, source/machine effects and broader production classes continue next. A separate uncommitted address-selection draft remains excluded from this PR. Full original#140 remains open.
