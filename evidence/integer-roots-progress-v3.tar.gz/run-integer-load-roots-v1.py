from pathlib import Path
import os,subprocess,json,datetime,hashlib,re
b=Path('/home/lee/clifv');r=b/'.worktrees/stock-cfg-source-20261025';e=b/'.git/agent-evidence/stock-memory-20261029';state=e/'integer-load-roots-state-v1.json';records=[];names=['StockMemoryIntegerAddress','StockMemoryIntegerLoadSelection','StockMemoryIntegerLoadWitness'];paths=[r/('FV/Backend/Proof/'+n+'.lean') for n in names];before={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
env=dict(os.environ);env.update(json.loads((e/'author-env-v1.json').read_text()));env.update(FV_ROOT=str(r),FV_MEMCAP='16G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',CARGO_BUILD_JOBS='1')
def save(status,**x):state.write_text(json.dumps(dict(status=status,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),records=records,sources=before,**x),indent=2)+'\n')
def run(label,args):
 save('running',phase=label)
 with(e/('integer-load-roots-'+label+'-v1.log')).open('w') as log:done=subprocess.run(['nice','-n','10',str(r/'scripts/memcap.sh'),*args],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 records.append(dict(label=label,returncode=done.returncode));assert done.returncode==0,(label,done.returncode)
try:
 assert json.loads((e/'integer-address-build-state-v1.json').read_text())['status']=='passed'
 run('build',['python3','scripts/lake-serial-build.py','--budget','14G','--max-jobs','1','--max-cap','14G','--default-cap','14G','--out',str(e/'integer-load-roots-modules-v1'),*['FV.Backend.Proof.'+n for n in names]])
 run('audit',['lake','env','lean','scripts/audit/stock-memory-integer-roots.lean'])
 roots={n:set(x.strip() for x in a.split(',')) for n,a in re.findall(r"'([^']+)' depends on axioms: \[([^]]*)\]",(e/'integer-load-roots-audit-v1.log').read_text(),re.S)};assert len(roots)==5 and all(a<={'propext','Classical.choice','Quot.sound'} for a in roots.values());assert before=={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
 save('passed',audit_roots=5,all_axioms_standard=True,source_unchanged=True,scope='Actual unsigned load roots for four widths; first-match source-built witnesses. Source/machine correctness, retained records and complete wider production classes remain required.')
except BaseException as error:save('failed',error=repr(error));raise
