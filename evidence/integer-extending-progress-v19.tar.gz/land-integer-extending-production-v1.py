from pathlib import Path
import json,datetime,time,subprocess,psutil
b=Path('/home/lee/clifv');e=b/'.git/agent-evidence/stock-memory-20261029';state=e/'integer-extending-production-landing-state-v1.json';head='0db8235d896fbe472f3950a544a69b66da3e2774';base='080500afd9d6e52e4af5fd13acd98ccea5516197'
def save(status,**extra):state.write_text(json.dumps(dict(status=status,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),pr=794,head=head,full_goal_complete=False,**extra),indent=2)+'\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=b,text=True).strip()
def live(pid):
 try:p=psutil.Process(pid);return p.is_running() and p.status()!=psutil.STATUS_ZOMBIE
 except psutil.NoSuchProcess:return False
try:
 while live(4016468):save('waiting',phase='combined-per-pr-gates',dependency_pid=4016468);time.sleep(3)
 gate=json.loads((e/'integer-extending-production-gates-state-v3.json').read_text());assert gate['status']=='passed',gate
 assert all(x['returncode']==0 for x in gate['records']),gate['records']
 assert gate['prior_axiom_sets_exact']==192 and gate['native_matrices']==17
 assert json.loads((e/'integer-extending-production-preservation-state-v3.json').read_text())['status']=='passed'
 assert json.loads((e/'integer-extending-production-official-state-v3.json').read_text())['ci_head']==head
 pr=json.loads(subprocess.check_output(['gh','pr','view','794','--json','headRefOid,state,mergeable,statusCheckRollup'],cwd=b,text=True))
 assert pr['headRefOid']==head and pr['state']=='OPEN' and pr['mergeable']=='MERGEABLE',pr
 checks={x['name']:x for x in pr['statusCheckRollup']};required=['Quick checks','Build and compare','Check lost matches','Publish PR result']
 assert all(checks[n]['conclusion']=='SUCCESS' and checks[n]['status']=='COMPLETED' for n in required),checks
 assert git('ls-remote','origin','refs/heads/main').split()[0]==base,'Main drift requires review before landing'
 save('running',phase='squash-merge',route='All current per-PR tests passed; no peer review is claimed.')
 subprocess.run(['gh','pr','merge','794','--squash','--match-head-commit',head],cwd=b,check=True)
 pr=json.loads(subprocess.check_output(['gh','pr','view','794','--json','state,mergeCommit'],cwd=b,text=True));assert pr['state']=='MERGED'
 merged=pr['mergeCommit']['oid'];subprocess.run(['git','fetch','origin','main'],cwd=b,check=True)
 assert git('rev-parse',merged+'^{tree}')==git('rev-parse',head+'^{tree}'),'Landed tree differs from validated source'
 save('passed',merge=merged,validated_tree_exact=True,route='All current per-PR tests passed. No review agents or human approval gate.',remaining='Full140 and the old broad normal/runtime gates remain incomplete; continue stores and every original obligation.')
 print(json.dumps(dict(pr=794,merge=merged,validated_tree_exact=True,full_goal_complete=False)))
except BaseException as error:save('failed',error=repr(error));raise
