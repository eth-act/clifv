import FV.Backend.Proof.StockReturnedSourceRetention
import FV.Backend.Proof.StockNoLoadDriver
import FV.Backend.Proof.StockMemoryReturnSpec
import FV.Backend.Proof.StockMemoryStoreMatch
import FV.Backend.Proof.StockSelectScanRefines
import FV.Backend.Proof.StockMemoryStoreSourceValues

namespace Backend.Stock.Proof
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 8192
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm emitInstruction

private theorem scans_execute {exec : Nat → State → Except String Scan}
    {indices : List Nat} {input : State} {output : BlockScan}
    (cert : ScansSpec exec indices input output) :
    ∀ record ∈ output.records,exec record.inst record.input = .ok record.output := by
  induction cert with
  | nil input => simp
  | cons head rest ih =>
    intro record member
    rcases List.mem_cons.mp member with rfl | member
    · exact head
    · exact ih record member

/-- An original store is retained and emitted in a source family without loads.
The original source shape supplies this family condition for singleton-store functions. -/
theorem stock_lower_store_emitted {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f)
    (formats : ∀ b ∈ f.blocks, ∀ stm ∈ b.body, CastComplete.MemoryFormat stm.inst)
    {event : BlockScanEvent} (events : event ∈ result.blockScans.toList)
    {b : Clif.Block} (block : f.blocks[event.block]? = some b)
    {j : Nat} {op : Clif.StoreOp} {ty : Clif.Ty} {flags : Clif.MemFlags} {value pointer : Nat} {offset : Int}
    (statement : b.body[j]? = some ⟨[],.store op ty flags value pointer offset⟩)
    {xs : List Nat} (ret : b.term = .ret xs) :
    ∃ (term record : ScanRecord) (body : BlockScan) (step : Step),
      SourceBodySplit f event b term body ∧ record ∈ body.records ∧
      record.inst = blockStart f event.block+j ∧
      record.input.sunk[record.inst]! = false ∧
      scanInstruction event.ctx event.block record.inst event.termInst event.isBranch record.input = .ok record.output ∧
      record ∈ event.output.records ∧ record.output.step = some step ∧ step.decision = .emitted := by
  obtain ⟨term,body,termStep,split,member,unsunk,branch,recorded,emitted⟩ :=
    stock_lower_retTrap_emitted run scope events block (by rw [ret]; rfl)
  have inside := (List.getElem?_eq_some_iff.mp statement).1
  have indexed : blockStart f event.block+j ∈ sourceBodyIndices f event.block b := by
    unfold sourceBodyIndices
    apply List.mem_reverse.mpr
    exact List.mem_map.mpr ⟨j,List.mem_range.mpr inside,rfl⟩
  rw [← split.scanned.order] at indexed
  obtain ⟨record,retained,current⟩ := List.mem_map.mp indexed
  obtain ⟨info,source,clif,infoResults⟩ :=
    ArithmeticBody.body_source_info run events split statement current
  have safeHere : record.input.sunk[record.inst]! = false :=
    (((SinkRules.stock_lower_no_load_unsunk run scope formats record.inst).2 event events).2
      record (split.retained record retained)).1
  have ordinary : record.inst ≠ event.termInst := by rw [current,split.termIndex]; omega
  have actual := scans_execute split.scanned record retained
  obtain ⟨step,decision,which⟩ := stock_ordinary_unsunk_decision safeHere ordinary actual
  have actualEmitted : step.decision = .emitted := by
    rcases which with omitted | remembered | emitted
    · have mandatory := (scan_omitted actual decision omitted).2.1
      simp [getElem!_def,source,clif,mustLower] at mandatory
    · exact False.elim ((Coverage.lower_record_noOpportunistic scope run events
        (split.retained record retained) decision) remembered)
    · exact emitted
  exact ⟨term,record,body,step,split,retained,current,safeHere,actual,
    split.retained record retained,decision,actualEmitted⟩

end Backend.Stock.Proof

namespace Backend.Stock.Memory.StoreRoots
open Backend.Proof Backend.Proof.Driver Backend.Stock.Proof Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000

/-- Original parameter declarations determine types in the actual scan context. -/
theorem stock_lower_source_parameter_type {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (dominated : Dominated f)
    {event : BlockScanEvent} (events : event ∈ result.blockScans.toList)
    {bi : Nat} {b : Clif.Block} (block : f.blocks[bi]? = some b) {x : Nat} {ty : Clif.Ty}
    (parameter : (x,ty) ∈ b.params) : event.ctx.valueType? x = some (CTy.ofClif ty) := by
  obtain ⟨ranges,params,earlier,suffix,starting,finishing,before,after,
    label,nodeBi,data,core,build,ordered,initial,empty,parts,folded,
    final,prefixRun,nodeRun,suffixRun,node,coreRun,eventEq,stateEq⟩ :=
    stock_lower_blockScanOrigin run events
  obtain ⟨original,st0,oldBuild,spec,view⟩ := buildCtx_source build
  have types : event.ctx.valTy = original.valTy := by
    rw [eventEq,(stock_lowerBlockCore_scanOrigin coreRun).2.1]
    exact view.valTy
  simpa only [Ctx.valueType?,types] using
    (spec.facts.types dominated.ssa).2 b (List.mem_of_getElem? block) (x,ty) parameter

/-- Actual store data for composition comes from original syntax and the complete driver. -/
structure SingleStoreReturnSpec (kind : Kind) (ty : Clif.Ty) (f : Clif.Function) (result : Result)
    (event : BlockScanEvent) (b : Clif.Block) (value pointer : Nat) (flags : Clif.MemFlags) where
  term : ScanRecord
  record : ScanRecord
  body : BlockScan
  step : Step
  info : IInfo
  valueReg : Nat
  pointerReg : Nat
  split : SourceBodySplit f event b term body
  bodyRecords : body.records = [record]
  current : record.inst = blockStart f event.block+0
  records : record ∈ event.output.records
  recorded : record.output.step = some step
  emitted : step.decision = .emitted
  source : event.ctx.insts[record.inst]? = some info
  clif : info.clif = some (.store kind.sourceOp ty flags value pointer 0)
  typed : kind.sourceOp = .store → event.ctx.valueType? value = some (.int kind.width.bits)
  valueMapped : event.ctx.valueReg? value = some (.vreg valueReg .int)
  parameter : event.ctx.defInst? pointer = none
  pointerMapped : event.ctx.valueReg? pointer = some (.vreg pointerReg .int)

/-- Store retention and operand mappings are internal consequences of original source syntax. -/
theorem stock_single_store_return_spec (kind : Kind) (ty : Clif.Ty) {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    (formats : ∀ b ∈ f.blocks, ∀ stm ∈ b.body, CastComplete.MemoryFormat stm.inst)
    {event : BlockScanEvent} (events : event ∈ result.blockScans.toList)
    {b : Clif.Block} (block : f.blocks[event.block]? = some b)
    {value pointer : Nat} {flags : Clif.MemFlags}
    (singleton : b.body = [⟨[],.store kind.sourceOp ty flags value pointer 0⟩]) (ret : b.term = .ret [])
    {pi vi : Nat} {pb vb : Clif.Block} {valueTy : Clif.Ty}
    (pointerBlock : f.blocks[pi]? = some pb) (parameter : pointer ∈ pb.params.map (·.1))
    (valueBlock : f.blocks[vi]? = some vb) (valueParameter : (value,valueTy) ∈ vb.params)
    (width : kind.sourceOp = .store → CTy.ofClif valueTy = .int kind.width.bits) :
    Nonempty (SingleStoreReturnSpec kind ty f result event b value pointer flags) := by
  have statement : b.body[0]? = some ⟨[],.store kind.sourceOp ty flags value pointer 0⟩ := by simp [singleton]
  obtain ⟨term,record,body,step,split,member,current,unsunk,actual,records,recorded,emitted⟩ :=
    stock_lower_store_emitted run scope formats events block statement ret
  obtain ⟨info,source,clif,results⟩ := ArithmeticBody.body_source_info run events split statement current
  have inv := (stock_lower_record_context run scope events).1
  have valueType := stock_lower_source_parameter_type run dominated events valueBlock valueParameter
  obtain ⟨valueReg,valueMapped⟩ := inv.typedReg value _ valueType
  obtain ⟨pointerReg,pointerMapped⟩ := inv.typedReg pointer _ (inv.addr64 _ _ _ pointer source clif rfl)
  have noDefinition := stock_lower_source_parameter_definition run dominated events pointerBlock parameter
  have typed : kind.sourceOp = .store → event.ctx.valueType? value = some (.int kind.width.bits) := by
    intro plain
    rw [valueType,width plain]
  have bodyRecords : body.records = [record] := by
    have scanned := split.scanned
    simp only [sourceBodyIndices,singleton,List.length_cons,List.length_nil,List.range_succ,
      List.range_zero,List.nil_append,List.map_cons,List.map_nil,List.reverse_cons,
      List.reverse_nil,List.nil_append,Nat.add_zero] at scanned
    cases scanned with
    | cons head tail =>
      cases tail
      exact congrArg (fun r => [r]) (List.mem_singleton.mp member).symm
  exact ⟨⟨term,record,body,step,info,valueReg,pointerReg,split,bodyRecords,current,records,recorded,emitted,
    source,clif,typed,valueMapped,noDefinition,pointerMapped⟩⟩

end Backend.Stock.Memory.StoreRoots

namespace Backend.Stock.Memory.StoreRoots
open Backend.Proof Backend.Proof.Driver Backend.Stock.Proof Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000

/-- Actual store selection discharges the existing guarded indexed scan
obligation. Original SSA/dominance derive post-source DFG; the original memory
relation supplies memory validity internally. -/
theorem stock_lower_integer_store_scan_fall_refines (kind : Kind) (ty : Clif.Ty) {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    {event : BlockScanEvent} {record : ScanRecord}
    (events : event ∈ result.blockScans.toList) (records : record ∈ event.output.records)
    {bi j : Nat} {b : Clif.Block} {stm : Clif.Stmt}
    (block : f.blocks[bi]? = some b) (statement : b.body[j]? = some stm)
    (current : record.inst = blockStart f bi+j)
    {info : IInfo} {value pointer valueReg pointerReg : Nat} {flags : Clif.MemFlags}
    (source : event.ctx.insts[record.inst]? = some info)
    (clif : info.clif = some (.store kind.sourceOp ty flags value pointer 0))
    (typed : kind.sourceOp = .store → event.ctx.valueType? value = some (.int kind.width.bits))
    (parameter : event.ctx.defInst? pointer = none)
    (pointerMapped : event.ctx.valueReg? pointer = some (.vreg pointerReg .int))
    (valueMapped : event.ctx.valueReg? value = some (.vreg valueReg .int))
    {step : Step} (recorded : record.output.step = some step) (emitted : step.decision = .emitted)
    {F : BitVec 64 → Prop} {sb : Nat} {syms : String → Option Nat} {isem : Backend.Proof.Sem}
    {MR : MemRelT} (stable : MRStable F MR) (memorySem : StoreRefines F sb isem)
    (memoryOk : MemRelOk F sb syms f MR) {env : Clif.Env} {cp : Clif.Program} :
    ScanFallRefines (IndexedSourceInst env cp f event.ctx bi) isem result.final.alias
      (GuardedScanRel f result event.ctx bi MR) record := by
  intro s s' hsource ρ w held
  obtain ⟨indexed,advance,sourceStep⟩ := hsource
  have position : s.1 = j := Nat.add_left_cancel (indexed.symm.trans current)
  obtain ⟨func,dfg,memory,values⟩ := held
  rw [position] at dfg values
  have postDFG := stock_lower_source_step_dfg run scope dominated events block statement current func dfg sourceStep
  obtain ⟨pv,w',pointer,evaluated,executed,same,memory',post⟩ := stock_lower_integer_store_source_step_of_store kind
    run scope dominated events records block statement current source clif typed
    parameter pointerMapped valueMapped recorded emitted stable memorySem memoryOk memory dfg values sourceStep
  refine ⟨ρ,w',executed,?_,?_,memory',?_⟩
  · obtain ⟨info',inst,vals,regs,rest,_,_,_,_,_,updated⟩ := sourceStep
    change s'.2.1 = _ at updated
    rw [updated]
    exact func
  · simpa only [advance,position] using postDFG
  · simpa only [advance,position] using post

end Backend.Stock.Memory.StoreRoots

namespace Backend.Stock.Memory.StoreRoots
open Backend.Proof Backend.Proof.Driver Backend.Stock.Proof Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option Elab.async false

/-- Two retained source executions preserve their virtual files and update the same source memory relation.
The virtual files may differ in unused upper bits of narrow source values. -/
theorem stock_lower_integer_store_paired_source_step (kind : Kind) {ty : Clif.Ty}
    {f : Clif.Function} {result : Result} (run : Stock.lower f = .ok result) (scope : LowerScope f)
    (dominated : Dominated f) {event : BlockScanEvent} {record : ScanRecord}
    (events : event ∈ result.blockScans.toList) (records : record ∈ event.output.records)
    {bi j : Nat} {b : Clif.Block} {stm : Clif.Stmt}
    (block : f.blocks[bi]? = some b) (statement : b.body[j]? = some stm)
    (current : record.inst = blockStart f bi+j)
    {info : IInfo} {value pointer valueReg pointerReg : Nat} {flags : Clif.MemFlags}
    (source : event.ctx.insts[record.inst]? = some info)
    (clif : info.clif = some (.store kind.sourceOp ty flags value pointer 0))
    (typed : kind.sourceOp = .store → event.ctx.valueType? value = some (.int kind.width.bits))
    (parameter : event.ctx.defInst? pointer = none)
    (pointerMapped : event.ctx.valueReg? pointer = some (.vreg pointerReg .int))
    (valueMapped : event.ctx.valueReg? value = some (.vreg valueReg .int))
    {step : Step} (recorded : record.output.step = some step) (emitted : step.decision = .emitted)
    {F : BitVec 64 → Prop} {sb : Nat} {syms : String → Option Nat} {isem : Backend.Proof.Sem}
    {MR : MemRelT} (stable : MRStable F MR) (memorySem : StoreRefines F sb isem)
    (memoryOk : MemRelOk F sb syms f MR)
    {fr fr' : Clif.Frame} {ρ otherρ : Nat → CV} {cm cm' : Clif.Mem} {w other : Arm.ArmState}
    (memory : MR fr.slots cm w) (otherMemory : MR fr.slots cm other)
    (dfg : DFGCons event.ctx (restrict fr (availOf f (availIn f result.ctx) bi j)))
    (held : ValuesHeld (fun y => Demanded record.output.state y ∧
      y ∈ availOf f (availIn f result.ctx) bi j) event.ctx fr (fun k => ρ (aliasNum result.final.alias k)))
    (otherHeld : ValuesHeld (fun y => Demanded record.output.state y ∧
      y ∈ availOf f (availIn f result.ctx) bi j) event.ctx fr
        (fun k => otherρ (aliasNum result.final.alias k)))
    {env : Clif.Env} {cp : Clif.Program}
    (sourceStep : SourceInstResult env cp event.ctx record.inst (fr,cm) (fr',cm')) :
    ∃ w' other',
      seqRun isem (record.output.emitted.toList.map (·.mapRegs
        (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1)))) ρ w =
          some (.fall ρ w') ∧
      seqRun isem (record.output.emitted.toList.map (·.mapRegs
        (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1)))) otherρ other =
          some (.fall otherρ other') ∧
      MR fr'.slots cm' w' ∧ MR fr'.slots cm' other' ∧
      ValuesHeld (fun y => Demanded record.input y ∧
        y ∈ availOf f (availIn f result.ctx) bi (j+1)) event.ctx fr'
        (fun k => ρ (aliasNum result.final.alias k)) ∧
      ValuesHeld (fun y => Demanded record.input y ∧
        y ∈ availOf f (availIn f result.ctx) bi (j+1)) event.ctx fr'
        (fun k => otherρ (aliasNum result.final.alias k)) := by
  obtain ⟨pv,w',pointer,evaluated,executed,same,memory',post⟩ := stock_lower_integer_store_source_step_of_store kind
    run scope dominated events records block statement current source clif typed
    parameter pointerMapped valueMapped recorded emitted stable memorySem memoryOk memory dfg held sourceStep
  obtain ⟨otherPointer,other',pointer',evaluated',executed',same',otherMemory',otherPost⟩ :=
    stock_lower_integer_store_source_step_of_store kind run scope dominated events records block statement current
      source clif typed parameter pointerMapped valueMapped recorded emitted stable memorySem memoryOk
      otherMemory dfg otherHeld sourceStep
  exact ⟨w',other',executed,executed',memory',otherMemory',post,otherPost⟩

end Backend.Stock.Memory.StoreRoots

namespace Backend.Stock.Memory.StoreRoots
open Backend.Proof Backend.Proof.Driver Backend.Stock.Proof Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000

/-- Original singleton store/return syntax derives the complete guarded body
proof, including retention, actual selection, value/pointer mappings and final
aliases. The pointer can be inherited from a different original source block.
No retained-record, selected-rule or emitted-code certificate is a premise. -/
theorem stock_single_store_return_body (kind : Kind) (ty : Clif.Ty) {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    (formats : ∀ b ∈ f.blocks, ∀ stm ∈ b.body, CastComplete.MemoryFormat stm.inst)
    {event : BlockScanEvent} (events : event ∈ result.blockScans.toList)
    {b : Clif.Block} (block : f.blocks[event.block]? = some b)
    {value pointer : Nat} {flags : Clif.MemFlags}
    (singleton : b.body = [⟨[],.store kind.sourceOp ty flags value pointer 0⟩]) (ret : b.term = .ret [])
    {pi vi : Nat} {pb vb : Clif.Block} {valueTy : Clif.Ty}
    (pointerBlock : f.blocks[pi]? = some pb) (parameter : pointer ∈ pb.params.map (·.1))
    (valueBlock : f.blocks[vi]? = some vb) (valueParameter : (value,valueTy) ∈ vb.params)
    (width : kind.sourceOp = .store → CTy.ofClif valueTy = .int kind.width.bits)
    {F : BitVec 64 → Prop} {sb : Nat} {syms : String → Option Nat} {isem : Backend.Proof.Sem}
    {MR : MemRelT} (stable : MRStable F MR) (memorySem : StoreRefines F sb isem)
    (memoryOk : MemRelOk F sb syms f MR) {env : Clif.Env} {cp : Clif.Program} :
    ∃ (term : ScanRecord) (body : BlockScan),SourceBodySplit f event b term body ∧
      ∀ s s',SourceSteps (IndexedSourceInst env cp f event.ctx event.block)
        ((List.range b.body.length).map (blockStart f event.block+·)) s s' →
        ∀ ρ w,GuardedScanRel f result event.ctx event.block MR event.output.state s ρ w →
          ∃ ρ' w',seqRun isem (body.code.toList.map (·.mapRegs
            (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1)))) ρ w =
              some (.fall ρ' w') ∧
            GuardedScanRel f result event.ctx event.block MR term.output.state s' ρ' w' := by
  obtain ⟨spec⟩ := stock_single_store_return_spec kind ty run scope dominated formats events block
    singleton ret pointerBlock parameter valueBlock valueParameter width
  have statement : b.body[0]? = some ⟨[],.store kind.sourceOp ty flags value pointer 0⟩ := by simp [singleton]
  have normal := stock_lower_integer_store_scan_fall_refines kind ty run scope dominated events spec.records
    block statement spec.current spec.source spec.clif spec.typed spec.parameter spec.pointerMapped
    spec.valueMapped spec.recorded spec.emitted stable memorySem memoryOk (env := env) (cp := cp)
  refine ⟨spec.term,spec.body,spec.split,?_⟩
  have each : ∀ r ∈ spec.body.records,ScanFallRefines (IndexedSourceInst env cp f event.ctx event.block)
      isem result.final.alias (GuardedScanRel f result event.ctx event.block MR) r := by
    intro r present
    have same : r = spec.record := by simpa only [spec.bodyRecords,List.mem_singleton] using present
    subst r
    exact normal
  intro s s' steps ρ w held
  apply spec.split.scanned.fall_refines each s s'
  · simpa only [sourceBodyIndices,List.reverse_reverse] using steps
  · simpa only [spec.split.state] using held

end Backend.Stock.Memory.StoreRoots
#print axioms Backend.Stock.Proof.stock_lower_store_emitted
#print axioms Backend.Stock.Memory.StoreRoots.stock_lower_source_parameter_type
#print axioms Backend.Stock.Memory.StoreRoots.stock_single_store_return_spec
#print axioms Backend.Stock.Memory.StoreRoots.stock_lower_integer_store_scan_fall_refines
#print axioms Backend.Stock.Memory.StoreRoots.stock_lower_integer_store_paired_source_step
#print axioms Backend.Stock.Memory.StoreRoots.stock_single_store_return_body
