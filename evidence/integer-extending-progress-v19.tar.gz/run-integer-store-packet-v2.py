from pathlib import Path
import os,subprocess,json,hashlib,datetime,time,re,psutil
b=Path('/home/lee/clifv');e=b/'.git/agent-evidence/stock-memory-20261029';r=b/'.worktrees/stock-extending-production-20261031';state=e/'integer-store-packet-state-v2.json';records=[];paused=None
p=json.loads((e/'integer-store-packet-source-v1.json').read_text());root=Path(p['root'])
env=dict(os.environ);env.update(json.loads((e/'author-env-v1.json').read_text()));env.update(FV_ROOT=str(r),FV_MEMCAP='12G',OMP_NUM_THREADS='1',OMP_THREAD_LIMIT='1',LEAN_NUM_THREADS='1',CARGO_BUILD_JOBS='1',PYTHONDONTWRITEBYTECODE='1')
for k in ['FV_PIPELINE_T','BLESS']:env.pop(k,None)
def save(status,**x):state.write_text(json.dumps(dict(status=status,records=records,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_hashes=p['files'],**x),indent=2)+'\n')
def live(x):
 try:return x.is_running() and x.status()!=psutil.STATUS_ZOMBIE
 except psutil.NoSuchProcess:return False
def run(label,args):
 assert all(hashlib.sha256((root/n).read_bytes()).hexdigest()==h for n,h in p['files'].items())
 save('running',phase=label,scheduler_paused=paused.pid)
 env['FV_MEMCAP_STATS']=str(e/('integer-store-packet-'+label+'-v2.stats'))
 with (e/('integer-store-packet-'+label+'-v2.log')).open('w') as out:
  result=subprocess.run(['nice','-n','10',str(r/'scripts/memcap.sh'),*map(str,args)],cwd=r,env=env,stdout=out,stderr=subprocess.STDOUT)
 records.append(dict(label=label,returncode=result.returncode));assert result.returncode==0,(label,result.returncode)
try:
 dependency=psutil.Process(4177999) if psutil.pid_exists(4177999) else None
 while dependency is not None and live(dependency):save('waiting',phase='finish-draft-witness',dependency_pid=4177999);time.sleep(3)
 witness=json.loads((e/'integer-store-source-witness-state-v3.json').read_text());assert witness['status']=='passed',witness
 while True:
  combined=psutil.Process(4016468) if psutil.pid_exists(4016468) else None
  owner=combined if combined is not None and live(combined) else psutil.Process(3167178)
  sched=[]
  for child in owner.children(recursive=True):
   try:
    if child.name().startswith('python') and any(a.endswith('/lake-serial-build.py') or a=='scripts/lake-serial-build.py' for a in child.cmdline()):sched.append(child)
   except psutil.NoSuchProcess:pass
  if not sched:save('waiting',phase='wait-for-source-scheduler',owner=owner.pid);time.sleep(3);continue
  assert len(sched)==1;paused=sched[0];paused.suspend()
  while True:
   children=[c for c in paused.children() if live(c)];caps=[]
   for c in children:
    raw=c.environ().get('FV_MEMCAP','');caps.append(float(raw[:-1]) if raw.endswith('G') else float(raw[:-1])/1024 if raw.endswith('M') else 1000)
   if len(children)<=1 and sum(caps)<=4:break
   save('waiting',phase='finish-active-source-module',active_caps_GiB=caps);time.sleep(3)
  if owner.pid==4016468:
   old=psutil.Process(3167211);assert old.status()==psutil.STATUS_STOPPED and not any(live(c) for c in old.children(recursive=True))
  break
 combined_source=json.loads((e/'integer-extending-production-source-v3.json').read_text())
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==combined_source['base']
 assert all(hashlib.sha256((r/n).read_bytes()).hexdigest()==h for n,h in combined_source['files'].items())
 env['LEAN_PATH']=str(root)+':'+subprocess.check_output(['lake','env','printenv','LEAN_PATH'],cwd=r,env=env,text=True).strip()
 for name in ['StockMemoryStoreSelection','StockMemoryStoreSource','StockMemoryStoreWitness']:
  source=root/'FV/Backend/Proof'/(name+'.lean')
  run(name,['lean','-j1','--root='+str(root),'-o',source.with_suffix('.olean'),source])
 run('audit',['lean','-j1','--root='+str(root),root/'scripts/audit/stock-memory-store.lean'])
 text=(e/'integer-store-packet-audit-v2.log').read_text()
 axioms={n:set(x.strip() for x in a.split(',')) for n,a in re.findall(r"'([^']+)' depends on axioms: \[([^]]*)\]",text,re.S)}
 axioms.update({n:set() for n in re.findall(r"'([^']+)' does not depend on any axioms",text)})
 assert len(axioms)==7 and all(a<={'propext','Classical.choice','Quot.sound'} for a in axioms.values()),axioms
 save('passed',audit_roots=7,all_axioms_standard=True,base=combined_source['base'],scope='Actual module-path checks for seven store roots, emitted side effects, original-source write transport and full lowering witnesses. No production store activation or whole-driver completion claim.')
except BaseException as error:save('failed',error=repr(error));raise
finally:
 if paused is not None and live(paused):paused.resume()
