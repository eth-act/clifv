from pathlib import Path
import os,subprocess,json,hashlib,datetime,time,psutil
b=Path('/home/lee/clifv');e=b/'.git/agent-evidence/stock-memory-20261029';r=b/'.worktrees/stock-extending-production-20261031';oldr=b/'.worktrees/stock-cfg-source-20261025';state=e/'integer-extending-production-gates-state-v4.json';paused=None;records=[]
packet=json.loads((e/'integer-extending-production-source-v3.json').read_text());old=json.loads((e/'integer-production-source-v2.json').read_text())
env=dict(os.environ);env.update(json.loads((e/'author-env-v1.json').read_text()));env.update(FV_ROOT=str(r),FV_MEMCAP='4G',OMP_NUM_THREADS='1',OMP_THREAD_LIMIT='1',LEAN_NUM_THREADS='1',CARGO_BUILD_JOBS='1',PYTHONDONTWRITEBYTECODE='1')
for k in ['FV_PIPELINE_T','BLESS']:env.pop(k,None)
def save(status,**x):state.write_text(json.dumps(dict(status=status,records=records,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_snapshot='integer-extending-production-source-v3.json',**x),indent=2)+'\n')
def live(p):
 try:return p.is_running() and p.status()!=psutil.STATUS_ZOMBIE
 except psutil.NoSuchProcess:return False
def frozen():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==packet['base']
 assert all(hashlib.sha256((r/n).read_bytes()).hexdigest()==h for n,h in packet['files'].items())
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=oldr,text=True).strip()==old['head']
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=oldr,text=True).strip()
 assert all(hashlib.sha256((oldr/n).read_bytes()).hexdigest()==h for n,h in old['files'].items())
def run(label,args):
 frozen();save('running',phase=label,scheduler_paused=paused.pid)
 with (e/('integer-extending-production-'+label+'-v4.log')).open('w') as out:result=subprocess.run(['nice','-n','10',str(r/'scripts/memcap.sh'),*map(str,args)],cwd=r,env=env,stdout=out,stderr=subprocess.STDOUT)
 records.append(dict(label=label,returncode=result.returncode));assert result.returncode==0,(label,result.returncode)
try:
 prior=json.loads((e/'integer-extending-production-gates-state-v3.json').read_text());assert prior['records'][-1]==dict(label='preservation',returncode=1)
 assert all(x['returncode']==0 for x in prior['records'][:-1]);records.extend(dict(x,reused_from='integer-extending-production-gates-state-v3.json') for x in prior['records'][:-1])
 assert len([x for x in records if x['label'].startswith('consumers-')])==17
 assert json.loads((e/'integer-extending-production-original-captures-receipt-v3.json').read_text())['status']=='passed'
 frozen();normal=psutil.Process(3167178)
 sched=[]
 for c in normal.children(recursive=True):
  try:
   if c.name().startswith('python') and any(a.endswith('/lake-serial-build.py') or a=='scripts/lake-serial-build.py' for a in c.cmdline()):sched.append(c)
  except psutil.NoSuchProcess:pass
 assert len(sched)==1;paused=sched[0];paused.suspend()
 while True:
  children=[c for c in paused.children() if live(c)];caps=[]
  for c in children:
   raw=c.environ().get('FV_MEMCAP','');caps.append(float(raw[:-1]) if raw.endswith('G') else float(raw[:-1])/1024 if raw.endswith('M') else 1000)
  if len(children)<=1 and sum(caps)<=12:break
  save('waiting',phase='finish-active-normal-source',active_caps_GiB=caps);time.sleep(3)
 imports=json.loads((e/'integer-extending-preservation-imports-v4.json').read_text())
 run('preservation-import-build',['python3','scripts/lake-serial-build.py','--budget','4G','--max-jobs','1','--max-cap','4G','--default-cap','4G','--profile',r/'scripts/lake-module-peaks.tsv','--profile',oldr/'.lake/lake-module-peaks.tsv','--out',e/'integer-extending-preservation-imports-build-v4',*imports])
 run('preservation',['python3',e/'run-integer-extending-preservation-v4.py'])
 preservation=json.loads((e/'integer-extending-production-preservation-state-v4.json').read_text());assert preservation['status']=='passed'
 official=json.loads((e/'integer-extending-production-official-state-v3.json').read_text());assert official['status']=='passed'
 closure=json.loads((e/'integer-extending-production-closure-v1.json').read_text());frozen()
 save('passed',reverse_roots=len(closure['roots']),executables=closure['executables'],production_audit_roots=13,prior_axiom_sets_exact=192,native_matrices=17,official=official['totals'],captured_source_hashes_exact=4543,original_objects_exact=8,captured_axiom_sets_exact=48,original_rejections_exact=8,scope='All current combined-source per-PR gates. Successful unchanged stages were retained; missing preservation audit artifacts were built and checked. Full140 and broad normal/runtime remain incomplete.')
except BaseException as error:save('failed',error=repr(error));raise
finally:
 if paused is not None and live(paused):paused.resume()
