import FV.Backend.Proof.StockReturnedSourceRetention
import FV.Backend.Proof.StockNoLoadDriver
import FV.Backend.Proof.StockMemoryReturnSpec
import FV.Backend.Proof.StockMemoryStoreMatch
import FV.Backend.Proof.StockSelectScanRefines
import FV.Backend.Proof.StockMemoryStoreSourceValues
import FV.E2E.StockMemoryPairedScan
import FV.E2E.StockMemoryPairedEntryReturn
import FV.Backend.Proof.StockMemoryStoreRecordFixture
import FV.Backend.Proof.StockMemoryReturnRefines
import FV.Backend.Proof.StockMemoryNotrap
import FV.Backend.Proof.StockMemoryContract
import FV.Backend.StockMemoryCheck
import FV.E2E.StockMemoryPairedFunction
import FV.Backend.Proof.DeadCleanupAdapter
import FV.E2E.StockArithmeticStage
import FV.E2E.DeadCleanupRegLevelX
import FV.E2E.DeadCleanupGot
import FV.E2E.StockArithmeticStageContract
import FV.E2E.ABIReadOnlyMachine
import FV.Backend.Lowering.StockMemoryExtLoadNI
import FV.Backend.MemoryExtLoadNIProduction

namespace Backend.Stock.Proof
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 8192
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm emitInstruction

private theorem scans_execute {exec : Nat → State → Except String Scan}
    {indices : List Nat} {input : State} {output : BlockScan}
    (cert : ScansSpec exec indices input output) :
    ∀ record ∈ output.records,exec record.inst record.input = .ok record.output := by
  induction cert with
  | nil input => simp
  | cons head rest ih =>
    intro record member
    rcases List.mem_cons.mp member with rfl | member
    · exact head
    · exact ih record member

/-- An original store is retained and emitted in a source family without loads.
The original source shape supplies this family condition for singleton-store functions. -/
theorem stock_lower_store_emitted {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f)
    (formats : ∀ b ∈ f.blocks, ∀ stm ∈ b.body, CastComplete.MemoryFormat stm.inst)
    {event : BlockScanEvent} (events : event ∈ result.blockScans.toList)
    {b : Clif.Block} (block : f.blocks[event.block]? = some b)
    {j : Nat} {op : Clif.StoreOp} {ty : Clif.Ty} {flags : Clif.MemFlags} {value pointer : Nat} {offset : Int}
    (statement : b.body[j]? = some ⟨[],.store op ty flags value pointer offset⟩)
    {xs : List Nat} (ret : b.term = .ret xs) :
    ∃ (term record : ScanRecord) (body : BlockScan) (step : Step),
      SourceBodySplit f event b term body ∧ record ∈ body.records ∧
      record.inst = blockStart f event.block+j ∧
      record.input.sunk[record.inst]! = false ∧
      scanInstruction event.ctx event.block record.inst event.termInst event.isBranch record.input = .ok record.output ∧
      record ∈ event.output.records ∧ record.output.step = some step ∧ step.decision = .emitted := by
  obtain ⟨term,body,termStep,split,member,unsunk,branch,recorded,emitted⟩ :=
    stock_lower_retTrap_emitted run scope events block (by rw [ret]; rfl)
  have inside := (List.getElem?_eq_some_iff.mp statement).1
  have indexed : blockStart f event.block+j ∈ sourceBodyIndices f event.block b := by
    unfold sourceBodyIndices
    apply List.mem_reverse.mpr
    exact List.mem_map.mpr ⟨j,List.mem_range.mpr inside,rfl⟩
  rw [← split.scanned.order] at indexed
  obtain ⟨record,retained,current⟩ := List.mem_map.mp indexed
  obtain ⟨info,source,clif,infoResults⟩ :=
    ArithmeticBody.body_source_info run events split statement current
  have safeHere : record.input.sunk[record.inst]! = false :=
    (((SinkRules.stock_lower_no_load_unsunk run scope formats record.inst).2 event events).2
      record (split.retained record retained)).1
  have ordinary : record.inst ≠ event.termInst := by rw [current,split.termIndex]; omega
  have actual := scans_execute split.scanned record retained
  obtain ⟨step,decision,which⟩ := stock_ordinary_unsunk_decision safeHere ordinary actual
  have actualEmitted : step.decision = .emitted := by
    rcases which with omitted | remembered | emitted
    · have mandatory := (scan_omitted actual decision omitted).2.1
      simp [getElem!_def,source,clif,mustLower] at mandatory
    · exact False.elim ((Coverage.lower_record_noOpportunistic scope run events
        (split.retained record retained) decision) remembered)
    · exact emitted
  exact ⟨term,record,body,step,split,retained,current,safeHere,actual,
    split.retained record retained,decision,actualEmitted⟩

end Backend.Stock.Proof

namespace Backend.Stock.Memory.StoreRoots
open Backend.Proof Backend.Proof.Driver Backend.Stock.Proof Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000

/-- Original parameter declarations determine types in the actual scan context. -/
theorem stock_lower_source_parameter_type {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (dominated : Dominated f)
    {event : BlockScanEvent} (events : event ∈ result.blockScans.toList)
    {bi : Nat} {b : Clif.Block} (block : f.blocks[bi]? = some b) {x : Nat} {ty : Clif.Ty}
    (parameter : (x,ty) ∈ b.params) : event.ctx.valueType? x = some (CTy.ofClif ty) := by
  obtain ⟨ranges,params,earlier,suffix,starting,finishing,before,after,
    label,nodeBi,data,core,build,ordered,initial,empty,parts,folded,
    final,prefixRun,nodeRun,suffixRun,node,coreRun,eventEq,stateEq⟩ :=
    stock_lower_blockScanOrigin run events
  obtain ⟨original,st0,oldBuild,spec,view⟩ := buildCtx_source build
  have types : event.ctx.valTy = original.valTy := by
    rw [eventEq,(stock_lowerBlockCore_scanOrigin coreRun).2.1]
    exact view.valTy
  simpa only [Ctx.valueType?,types] using
    (spec.facts.types dominated.ssa).2 b (List.mem_of_getElem? block) (x,ty) parameter

/-- Actual store data for composition comes from original syntax and the complete driver. -/
structure SingleStoreReturnSpec (kind : Kind) (ty : Clif.Ty) (f : Clif.Function) (result : Result)
    (event : BlockScanEvent) (b : Clif.Block) (value pointer : Nat) (flags : Clif.MemFlags) where
  term : ScanRecord
  record : ScanRecord
  body : BlockScan
  step : Step
  info : IInfo
  valueReg : Nat
  pointerReg : Nat
  split : SourceBodySplit f event b term body
  bodyRecords : body.records = [record]
  current : record.inst = blockStart f event.block+0
  records : record ∈ event.output.records
  recorded : record.output.step = some step
  emitted : step.decision = .emitted
  source : event.ctx.insts[record.inst]? = some info
  clif : info.clif = some (.store kind.sourceOp ty flags value pointer 0)
  typed : kind.sourceOp = .store → event.ctx.valueType? value = some (.int kind.width.bits)
  valueMapped : event.ctx.valueReg? value = some (.vreg valueReg .int)
  parameter : event.ctx.defInst? pointer = none
  pointerMapped : event.ctx.valueReg? pointer = some (.vreg pointerReg .int)

/-- Store retention and operand mappings are internal consequences of original source syntax. -/
theorem stock_single_store_return_spec (kind : Kind) (ty : Clif.Ty) {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    (formats : ∀ b ∈ f.blocks, ∀ stm ∈ b.body, CastComplete.MemoryFormat stm.inst)
    {event : BlockScanEvent} (events : event ∈ result.blockScans.toList)
    {b : Clif.Block} (block : f.blocks[event.block]? = some b)
    {value pointer : Nat} {flags : Clif.MemFlags}
    (singleton : b.body = [⟨[],.store kind.sourceOp ty flags value pointer 0⟩]) (ret : b.term = .ret [])
    {pi vi : Nat} {pb vb : Clif.Block} {valueTy : Clif.Ty}
    (pointerBlock : f.blocks[pi]? = some pb) (parameter : pointer ∈ pb.params.map (·.1))
    (valueBlock : f.blocks[vi]? = some vb) (valueParameter : (value,valueTy) ∈ vb.params)
    (width : kind.sourceOp = .store → CTy.ofClif valueTy = .int kind.width.bits) :
    Nonempty (SingleStoreReturnSpec kind ty f result event b value pointer flags) := by
  have statement : b.body[0]? = some ⟨[],.store kind.sourceOp ty flags value pointer 0⟩ := by simp [singleton]
  obtain ⟨term,record,body,step,split,member,current,unsunk,actual,records,recorded,emitted⟩ :=
    stock_lower_store_emitted run scope formats events block statement ret
  obtain ⟨info,source,clif,results⟩ := ArithmeticBody.body_source_info run events split statement current
  have inv := (stock_lower_record_context run scope events).1
  have valueType := stock_lower_source_parameter_type run dominated events valueBlock valueParameter
  obtain ⟨valueReg,valueMapped⟩ := inv.typedReg value _ valueType
  obtain ⟨pointerReg,pointerMapped⟩ := inv.typedReg pointer _ (inv.addr64 _ _ _ pointer source clif rfl)
  have noDefinition := stock_lower_source_parameter_definition run dominated events pointerBlock parameter
  have typed : kind.sourceOp = .store → event.ctx.valueType? value = some (.int kind.width.bits) := by
    intro plain
    rw [valueType,width plain]
  have bodyRecords : body.records = [record] := by
    have scanned := split.scanned
    simp only [sourceBodyIndices,singleton,List.length_cons,List.length_nil,List.range_succ,
      List.range_zero,List.nil_append,List.map_cons,List.map_nil,List.reverse_cons,
      List.reverse_nil,List.nil_append,Nat.add_zero] at scanned
    cases scanned with
    | cons head tail =>
      cases tail
      exact congrArg (fun r => [r]) (List.mem_singleton.mp member).symm
  exact ⟨⟨term,record,body,step,info,valueReg,pointerReg,split,bodyRecords,current,records,recorded,emitted,
    source,clif,typed,valueMapped,noDefinition,pointerMapped⟩⟩

end Backend.Stock.Memory.StoreRoots

namespace Backend.Stock.Memory.StoreRoots
open Backend.Proof Backend.Proof.Driver Backend.Stock.Proof Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000

/-- Actual store selection discharges the existing guarded indexed scan
obligation. Original SSA/dominance derive post-source DFG; the original memory
relation supplies memory validity internally. -/
theorem stock_lower_integer_store_scan_fall_refines (kind : Kind) (ty : Clif.Ty) {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    {event : BlockScanEvent} {record : ScanRecord}
    (events : event ∈ result.blockScans.toList) (records : record ∈ event.output.records)
    {bi j : Nat} {b : Clif.Block} {stm : Clif.Stmt}
    (block : f.blocks[bi]? = some b) (statement : b.body[j]? = some stm)
    (current : record.inst = blockStart f bi+j)
    {info : IInfo} {value pointer valueReg pointerReg : Nat} {flags : Clif.MemFlags}
    (source : event.ctx.insts[record.inst]? = some info)
    (clif : info.clif = some (.store kind.sourceOp ty flags value pointer 0))
    (typed : kind.sourceOp = .store → event.ctx.valueType? value = some (.int kind.width.bits))
    (parameter : event.ctx.defInst? pointer = none)
    (pointerMapped : event.ctx.valueReg? pointer = some (.vreg pointerReg .int))
    (valueMapped : event.ctx.valueReg? value = some (.vreg valueReg .int))
    {step : Step} (recorded : record.output.step = some step) (emitted : step.decision = .emitted)
    {F : BitVec 64 → Prop} {sb : Nat} {syms : String → Option Nat} {isem : Backend.Proof.Sem}
    {MR : MemRelT} (stable : MRStable F MR) (memorySem : StoreRefines F sb isem)
    (memoryOk : MemRelOk F sb syms f MR) {env : Clif.Env} {cp : Clif.Program} :
    ScanFallRefines (IndexedSourceInst env cp f event.ctx bi) isem result.final.alias
      (GuardedScanRel f result event.ctx bi MR) record := by
  intro s s' hsource ρ w held
  obtain ⟨indexed,advance,sourceStep⟩ := hsource
  have position : s.1 = j := Nat.add_left_cancel (indexed.symm.trans current)
  obtain ⟨func,dfg,memory,values⟩ := held
  rw [position] at dfg values
  have postDFG := stock_lower_source_step_dfg run scope dominated events block statement current func dfg sourceStep
  obtain ⟨pv,w',pointer,evaluated,executed,same,memory',post⟩ := stock_lower_integer_store_source_step_of_store kind
    run scope dominated events records block statement current source clif typed
    parameter pointerMapped valueMapped recorded emitted stable memorySem memoryOk memory dfg values sourceStep
  refine ⟨ρ,w',executed,?_,?_,memory',?_⟩
  · obtain ⟨info',inst,vals,regs,rest,_,_,_,_,_,updated⟩ := sourceStep
    change s'.2.1 = _ at updated
    rw [updated]
    exact func
  · simpa only [advance,position] using postDFG
  · simpa only [advance,position] using post

end Backend.Stock.Memory.StoreRoots

namespace Backend.Stock.Memory.StoreRoots
open Backend.Proof Backend.Proof.Driver Backend.Stock.Proof Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option Elab.async false

/-- Two retained source executions preserve their virtual files and update the same source memory relation.
The virtual files may differ in unused upper bits of narrow source values. -/
theorem stock_lower_integer_store_paired_source_step (kind : Kind) {ty : Clif.Ty}
    {f : Clif.Function} {result : Result} (run : Stock.lower f = .ok result) (scope : LowerScope f)
    (dominated : Dominated f) {event : BlockScanEvent} {record : ScanRecord}
    (events : event ∈ result.blockScans.toList) (records : record ∈ event.output.records)
    {bi j : Nat} {b : Clif.Block} {stm : Clif.Stmt}
    (block : f.blocks[bi]? = some b) (statement : b.body[j]? = some stm)
    (current : record.inst = blockStart f bi+j)
    {info : IInfo} {value pointer valueReg pointerReg : Nat} {flags : Clif.MemFlags}
    (source : event.ctx.insts[record.inst]? = some info)
    (clif : info.clif = some (.store kind.sourceOp ty flags value pointer 0))
    (typed : kind.sourceOp = .store → event.ctx.valueType? value = some (.int kind.width.bits))
    (parameter : event.ctx.defInst? pointer = none)
    (pointerMapped : event.ctx.valueReg? pointer = some (.vreg pointerReg .int))
    (valueMapped : event.ctx.valueReg? value = some (.vreg valueReg .int))
    {step : Step} (recorded : record.output.step = some step) (emitted : step.decision = .emitted)
    {F : BitVec 64 → Prop} {sb : Nat} {syms : String → Option Nat} {isem : Backend.Proof.Sem}
    {MR : MemRelT} (stable : MRStable F MR) (memorySem : StoreRefines F sb isem)
    (memoryOk : MemRelOk F sb syms f MR)
    {fr fr' : Clif.Frame} {ρ otherρ : Nat → CV} {cm cm' : Clif.Mem} {w other : Arm.ArmState}
    (memory : MR fr.slots cm w) (otherMemory : MR fr.slots cm other)
    (dfg : DFGCons event.ctx (restrict fr (availOf f (availIn f result.ctx) bi j)))
    (held : ValuesHeld (fun y => Demanded record.output.state y ∧
      y ∈ availOf f (availIn f result.ctx) bi j) event.ctx fr (fun k => ρ (aliasNum result.final.alias k)))
    (otherHeld : ValuesHeld (fun y => Demanded record.output.state y ∧
      y ∈ availOf f (availIn f result.ctx) bi j) event.ctx fr
        (fun k => otherρ (aliasNum result.final.alias k)))
    {env : Clif.Env} {cp : Clif.Program}
    (sourceStep : SourceInstResult env cp event.ctx record.inst (fr,cm) (fr',cm')) :
    ∃ w' other',
      seqRun isem (record.output.emitted.toList.map (·.mapRegs
        (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1)))) ρ w =
          some (.fall ρ w') ∧
      seqRun isem (record.output.emitted.toList.map (·.mapRegs
        (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1)))) otherρ other =
          some (.fall otherρ other') ∧
      MR fr'.slots cm' w' ∧ MR fr'.slots cm' other' ∧
      ValuesHeld (fun y => Demanded record.input y ∧
        y ∈ availOf f (availIn f result.ctx) bi (j+1)) event.ctx fr'
        (fun k => ρ (aliasNum result.final.alias k)) ∧
      ValuesHeld (fun y => Demanded record.input y ∧
        y ∈ availOf f (availIn f result.ctx) bi (j+1)) event.ctx fr'
        (fun k => otherρ (aliasNum result.final.alias k)) := by
  obtain ⟨pv,w',pointer,evaluated,executed,same,memory',post⟩ := stock_lower_integer_store_source_step_of_store kind
    run scope dominated events records block statement current source clif typed
    parameter pointerMapped valueMapped recorded emitted stable memorySem memoryOk memory dfg held sourceStep
  obtain ⟨otherPointer,other',pointer',evaluated',executed',same',otherMemory',otherPost⟩ :=
    stock_lower_integer_store_source_step_of_store kind run scope dominated events records block statement current
      source clif typed parameter pointerMapped valueMapped recorded emitted stable memorySem memoryOk
      otherMemory dfg otherHeld sourceStep
  exact ⟨w',other',executed,executed',memory',otherMemory',post,otherPost⟩

end Backend.Stock.Memory.StoreRoots

namespace Backend.Stock.Memory.StoreRoots
open Backend.Proof Backend.Proof.Driver Backend.Stock.Proof Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000

/-- Original singleton store/return syntax derives the complete guarded body
proof, including retention, actual selection, value/pointer mappings and final
aliases. The pointer can be inherited from a different original source block.
No retained-record, selected-rule or emitted-code certificate is a premise. -/
theorem stock_single_store_return_body (kind : Kind) (ty : Clif.Ty) {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    (formats : ∀ b ∈ f.blocks, ∀ stm ∈ b.body, CastComplete.MemoryFormat stm.inst)
    {event : BlockScanEvent} (events : event ∈ result.blockScans.toList)
    {b : Clif.Block} (block : f.blocks[event.block]? = some b)
    {value pointer : Nat} {flags : Clif.MemFlags}
    (singleton : b.body = [⟨[],.store kind.sourceOp ty flags value pointer 0⟩]) (ret : b.term = .ret [])
    {pi vi : Nat} {pb vb : Clif.Block} {valueTy : Clif.Ty}
    (pointerBlock : f.blocks[pi]? = some pb) (parameter : pointer ∈ pb.params.map (·.1))
    (valueBlock : f.blocks[vi]? = some vb) (valueParameter : (value,valueTy) ∈ vb.params)
    (width : kind.sourceOp = .store → CTy.ofClif valueTy = .int kind.width.bits)
    {F : BitVec 64 → Prop} {sb : Nat} {syms : String → Option Nat} {isem : Backend.Proof.Sem}
    {MR : MemRelT} (stable : MRStable F MR) (memorySem : StoreRefines F sb isem)
    (memoryOk : MemRelOk F sb syms f MR) {env : Clif.Env} {cp : Clif.Program} :
    ∃ (term : ScanRecord) (body : BlockScan),SourceBodySplit f event b term body ∧
      ∀ s s',SourceSteps (IndexedSourceInst env cp f event.ctx event.block)
        ((List.range b.body.length).map (blockStart f event.block+·)) s s' →
        ∀ ρ w,GuardedScanRel f result event.ctx event.block MR event.output.state s ρ w →
          ∃ ρ' w',seqRun isem (body.code.toList.map (·.mapRegs
            (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1)))) ρ w =
              some (.fall ρ' w') ∧
            GuardedScanRel f result event.ctx event.block MR term.output.state s' ρ' w' := by
  obtain ⟨spec⟩ := stock_single_store_return_spec kind ty run scope dominated formats events block
    singleton ret pointerBlock parameter valueBlock valueParameter width
  have statement : b.body[0]? = some ⟨[],.store kind.sourceOp ty flags value pointer 0⟩ := by simp [singleton]
  have normal := stock_lower_integer_store_scan_fall_refines kind ty run scope dominated events spec.records
    block statement spec.current spec.source spec.clif spec.typed spec.parameter spec.pointerMapped
    spec.valueMapped spec.recorded spec.emitted stable memorySem memoryOk (env := env) (cp := cp)
  refine ⟨spec.term,spec.body,spec.split,?_⟩
  have each : ∀ r ∈ spec.body.records,ScanFallRefines (IndexedSourceInst env cp f event.ctx event.block)
      isem result.final.alias (GuardedScanRel f result event.ctx event.block MR) r := by
    intro r present
    have same : r = spec.record := by simpa only [spec.bodyRecords,List.mem_singleton] using present
    subst r
    exact normal
  intro s s' steps ρ w held
  apply spec.split.scanned.fall_refines each s s'
  · simpa only [sourceBodyIndices,List.reverse_reverse] using steps
  · simpa only [spec.split.state] using held

end Backend.Stock.Memory.StoreRoots

namespace E2E.StockMemory.StoreRoots
open Backend Backend.Stock Backend.Proof Backend.Proof.Driver Backend.Stock.Proof Backend.Stock.Memory
open Backend.Stock.Memory.StoreRoots
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000

/-- Actual source stores compose under the existing paired scan relation.
The updated source relation handles newly initialized bytes without a new read-permission condition. -/
theorem stock_lower_integer_store_paired_scan (kind : Kind) (ty : Clif.Ty)
    {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    {event : BlockScanEvent} {record : ScanRecord}
    (events : event ∈ result.blockScans.toList) (records : record ∈ event.output.records)
    {bi j : Nat} {b : Clif.Block} {stm : Clif.Stmt}
    (block : f.blocks[bi]? = some b) (statement : b.body[j]? = some stm)
    (current : record.inst = blockStart f bi+j)
    {info : IInfo} {value pointer valueReg pointerReg : Nat} {flags : Clif.MemFlags}
    (source : event.ctx.insts[record.inst]? = some info)
    (clif : info.clif = some (.store kind.sourceOp ty flags value pointer 0))
    (typed : kind.sourceOp = .store → event.ctx.valueType? value = some (.int kind.width.bits))
    (parameter : event.ctx.defInst? pointer = none)
    (pointerMapped : event.ctx.valueReg? pointer = some (.vreg pointerReg .int))
    (valueMapped : event.ctx.valueReg? value = some (.vreg valueReg .int))
    {step : Step} (recorded : record.output.step = some step) (emitted : step.decision = .emitted)
    {Γ : Rel} {c : BitVec 64} {D : BitVec 64 → Prop} {fc : FnCtx} {X : ExtSem}
    (slot : fc.slotBase = Γ.slotOff)
    (symbols : ∀ n b,Γ.syms n = some b → X.sym n 0 = BitVec.ofNat 64 b)
    (tls : XTls Γ.F X) {env : Clif.Env} {cp : Clif.Program} :
    ScanFallRefines (IndexedSourceInst env cp f event.ctx bi) (pairSem (csem Γ.F fc X))
      result.final.alias (PairedScanRel f result event.ctx bi Γ c D) record := by
  intro s s' sourceIndex ρ q before
  obtain ⟨indexed,advance,sourceStep⟩ := sourceIndex
  have position : s.1 = j := Nat.add_left_cancel (indexed.symm.trans current)
  obtain ⟨firstHeld,secondHeld,worlds⟩ := before
  obtain ⟨func,dfg,memory,values⟩ := firstHeld
  rw [position] at dfg values
  have postDFG := stock_lower_source_step_dfg run scope dominated events block statement current func dfg sourceStep
  let guarded : Backend.Proof.Sem := csemG Γ.F fc X (fun a => ¬ Zof Γ.F D s.2.2 a) Γ.syms [] [] 0
    (fun _ _ _ _ => False)
  have memorySem : StoreRefines Γ.F Γ.slotOff guarded :=
    store_refines_of_memR (memRefinesR_csemG (ctx := fc) (X := X) (syms := Γ.syms) slot symbols)
  obtain ⟨pv,t,pointer,evaluated,first,same,memory',post⟩ := stock_lower_integer_store_source_step_of_store kind
    run scope dominated events records block statement current source clif typed parameter pointerMapped valueMapped
    recorded emitted (mrStable_relW Γ f c) memorySem (memRelOk_relW Γ f c) memory dfg values sourceStep
  have otherValues := secondHeld.2.2.2
  rw [position] at otherValues
  obtain ⟨pv',t',pointer',evaluated',second,same',otherMemory',otherPost⟩ :=
    stock_lower_integer_store_source_step_of_store kind run scope dominated events records block statement current
      source clif typed parameter pointerMapped valueMapped recorded emitted (mrStable_relW Γ f c)
      memorySem (memRelOk_relW Γ f c) secondHeld.2.2.1 dfg otherValues sourceStep
  let code := record.output.emitted.toList.map (·.mapRegs
    (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1)))
  obtain ⟨t2,equal,paired,related⟩ := pair_fall
    (fun _ _ _ _ h => (csemG_sub h).2.2)
    (guardedStep0 (D := D) (syms := Γ.syms) tls fc s.2.2 code [] []) worlds first second
  have sameWorld : t' = t2 := (SeqEnd.fall.inj equal).2
  subst t2
  have postFunc : s'.2.1.func = f := by
    obtain ⟨info',inst,vals,regs,rest,_,_,_,_,_,updated⟩ := sourceStep
    change s'.2.1 = _ at updated
    rw [updated]
    exact func
  refine ⟨ρ,(t,t'),paired,⟨postFunc,?_,memory',?_⟩,⟨postFunc,?_,otherMemory',?_⟩,?_⟩
  · simpa only [advance,position] using postDFG
  · simpa only [advance,position] using post
  · simpa only [advance,position] using postDFG
  · simpa only [advance,position] using otherPost
  · exact sameWorld_zof memory'.1.1 otherMemory'.1.1 related (zof_sub s.2.2)

end E2E.StockMemory.StoreRoots

namespace E2E.StockMemory.StoreRoots
open Backend Backend.Stock Backend.Proof Backend.Proof.Driver Backend.Stock.Proof Backend.Stock.Memory
open Backend.Stock.Memory.StoreRoots
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000

/-- Original store/return body syntax derives the complete paired body execution.
Both semantic consumers share the same retained-body derivation; neither a
record nor selected root, code, alias or read-permission certificate is an input. -/
theorem stock_single_store_return_paired_body (kind : Kind) (ty : Clif.Ty) {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    (formats : ∀ b ∈ f.blocks, ∀ stm ∈ b.body, CastComplete.MemoryFormat stm.inst)
    {event : BlockScanEvent} (events : event ∈ result.blockScans.toList)
    {b : Clif.Block} (block : f.blocks[event.block]? = some b)
    {value pointer : Nat} {flags : Clif.MemFlags}
    (singleton : b.body = [⟨[],.store kind.sourceOp ty flags value pointer 0⟩]) (ret : b.term = .ret [])
    {pi vi : Nat} {pb vb : Clif.Block} {valueTy : Clif.Ty}
    (pointerBlock : f.blocks[pi]? = some pb) (parameter : pointer ∈ pb.params.map (·.1))
    (valueBlock : f.blocks[vi]? = some vb) (valueParameter : (value,valueTy) ∈ vb.params)
    (width : kind.sourceOp = .store → CTy.ofClif valueTy = .int kind.width.bits)
    {Γ : Rel} {c : BitVec 64} {D : BitVec 64 → Prop} {fc : FnCtx} {X : ExtSem}
    (slot : fc.slotBase = Γ.slotOff)
    (symbols : ∀ n b,Γ.syms n = some b → X.sym n 0 = BitVec.ofNat 64 b)
    (tls : XTls Γ.F X) {env : Clif.Env} {cp : Clif.Program} :
    ∃ (term : ScanRecord) (body : BlockScan),SourceBodySplit f event b term body ∧
      ∀ s s',SourceSteps (IndexedSourceInst env cp f event.ctx event.block)
        ((List.range b.body.length).map (blockStart f event.block+·)) s s' →
        ∀ ρ q,PairedScanRel f result event.ctx event.block Γ c D event.output.state s ρ q →
          ∃ ρ' q',seqRun (pairSem (csem Γ.F fc X)) (body.code.toList.map (·.mapRegs
            (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1)))) ρ q =
              some (.fall ρ' q') ∧
            PairedScanRel f result event.ctx event.block Γ c D term.output.state s' ρ' q' := by
  obtain ⟨spec⟩ := stock_single_store_return_spec kind ty run scope dominated formats events block
    singleton ret pointerBlock parameter valueBlock valueParameter width
  have statement : b.body[0]? = some ⟨[],.store kind.sourceOp ty flags value pointer 0⟩ := by simp [singleton]
  have normal := stock_lower_integer_store_paired_scan kind ty run scope dominated events spec.records
    block statement spec.current spec.source spec.clif spec.typed spec.parameter spec.pointerMapped
    spec.valueMapped spec.recorded spec.emitted slot symbols tls (env := env) (cp := cp) (c := c) (D := D)
  refine ⟨spec.term,spec.body,spec.split,?_⟩
  have each : ∀ r ∈ spec.body.records,ScanFallRefines (IndexedSourceInst env cp f event.ctx event.block)
      (pairSem (csem Γ.F fc X)) result.final.alias (PairedScanRel f result event.ctx event.block Γ c D) r := by
    intro r present
    have same : r = spec.record := by simpa only [spec.bodyRecords,List.mem_singleton] using present
    subst r
    exact normal
  intro s s' steps ρ q held
  apply spec.split.scanned.fall_refines each s s'
  · simpa only [sourceBodyIndices,List.reverse_reverse] using steps
  · simpa only [spec.split.state] using held

end E2E.StockMemory.StoreRoots

namespace E2E.StockMemory.StoreRoots
open Backend Backend.Stock Backend.Proof Backend.Proof.Driver Backend.Stock.Proof
open Backend.Stock.Memory.StoreRoots
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000

/-- Source-only singleton store/return functions execute from instruction zero in
paired worlds. The original ABI/RelW and initialized-memory relations supply all
runtime premises; actual entry/body/retention/result-binding code is derived. -/
theorem single_store_return_paired_function_seeded (kind : Kind) (ty : Clif.Ty) {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    (abi : sigAbiOk f.sig = true) {b : Clif.Block} (blocks : f.blocks = [b])
    {value pointer : Nat} {flags : Clif.MemFlags} {valueTy : Clif.Ty}
    (singleton : b.body = [⟨[],.store kind.sourceOp ty flags value pointer 0⟩])
    (ret : b.term = .ret []) (parameter : pointer ∈ b.params.map (·.1))
    (valueParameter : (value,valueTy) ∈ b.params)
    (width : kind.sourceOp = .store → CTy.ofClif valueTy = .int kind.width.bits)
    {args : List Clif.Val} {cm : Clif.Mem} {fr : Clif.Frame}
    (entered : SourceEntry f args fr)
    {env : Clif.Env} {cp : Clif.Program} {fuel : Nat} {vals : List Clif.Val} {mem : Clif.Mem}
    (returned : Clif.runLoop env cp fuel ⟨fr,[],cm⟩ = .returned vals mem)
    (registerOnly : ∀ loc ∈ locsOf f.sig,∃ pin,loc = .reg pin)
    {Γ : Rel} {c : BitVec 64} {D : BitVec 64 → Prop} {fc : FnCtx} {X : ExtSem}
    (slot : fc.slotBase = Γ.slotOff)
    (symbols : ∀ n a,Γ.syms n = some a → X.sym n 0 = BitVec.ofNat 64 a)
    (tls : XTls Γ.F X)
    {w w' : Arm.ArmState} (memory : MRP Γ f c D fr.slots cm (w,w'))
    (arguments : ArgsAtEntry Γ.F f.sig args w) (otherArguments : ArgsAtEntry Γ.F f.sig args w')
    (registers : ∀ pin v,(.reg pin,v) ∈ (locsOf f.sig).zip args → regVal w' pin = regVal w pin) :
    RunOkABI f result.code (pairSem (csem Γ.F fc X)) (MRP Γ f c D) fr.slots
      ⟨0,0,entrySeed result.ctx fr,(w,w')⟩ (.returned vals mem) := by
  have family : ∀ stm ∈ b.body,OrdinaryBody.OrdinaryInst stm.inst := by
    intro stm member
    have same : stm = ⟨[],.store kind.sourceOp ty flags value pointer 0⟩ := by simpa only [singleton,List.mem_singleton] using member
    subst stm
    constructor
    · intro fn args impossible; cases impossible
    · intro sig callee args impossible; cases impossible
  have formats : ∀ b' ∈ f.blocks, ∀ stm ∈ b'.body,CastComplete.MemoryFormat stm.inst := by
    intro b' member stm present
    have same : b' = b := by simpa [blocks] using member
    subst b'
    have same : stm = ⟨[],.store kind.sourceOp ty flags value pointer 0⟩ := by
      simpa [singleton] using present
    subst stm
    simp [CastComplete.MemoryFormat,instNames]
  have entryBlock : f.blocks[0]? = some b := by simp [blocks]
  apply actual_ordinary_paired_entry_return_refines_frame run scope dominated abi blocks family ret
    entered returned registerOnly slot symbols tls ?_ memory arguments otherArguments registers
  intro event events
  obtain ⟨b',term,body,split⟩ := stock_lower_body_scan_split run scope events
  have bound : event.block < 1 := by have h := lt_of_getElem? split.block; simpa [blocks] using h
  have zero : event.block = 0 := by omega
  have actualBlock : f.blocks[event.block]? = some b := by rw [zero]; exact entryBlock
  exact stock_single_store_return_paired_body kind ty run scope dominated formats events actualBlock
    singleton ret entryBlock parameter entryBlock valueParameter width
    slot symbols tls

/-- Compatibility existential form of the canonical entry-seeded execution. -/
theorem single_store_return_paired_function (kind : Kind) (ty : Clif.Ty) {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    (abi : sigAbiOk f.sig = true) {b : Clif.Block} (blocks : f.blocks = [b])
    {value pointer : Nat} {flags : Clif.MemFlags} {valueTy : Clif.Ty}
    (singleton : b.body = [⟨[],.store kind.sourceOp ty flags value pointer 0⟩])
    (ret : b.term = .ret []) (parameter : pointer ∈ b.params.map (·.1))
    (valueParameter : (value,valueTy) ∈ b.params)
    (width : kind.sourceOp = .store → CTy.ofClif valueTy = .int kind.width.bits)
    {args : List Clif.Val} {cm : Clif.Mem} {fr : Clif.Frame}
    (entered : SourceEntry f args fr)
    {env : Clif.Env} {cp : Clif.Program} {fuel : Nat} {vals : List Clif.Val} {mem : Clif.Mem}
    (returned : Clif.runLoop env cp fuel ⟨fr,[],cm⟩ = .returned vals mem)
    (registerOnly : ∀ loc ∈ locsOf f.sig,∃ pin,loc = .reg pin)
    {Γ : Rel} {c : BitVec 64} {D : BitVec 64 → Prop} {fc : FnCtx} {X : ExtSem}
    (slot : fc.slotBase = Γ.slotOff)
    (symbols : ∀ n a,Γ.syms n = some a → X.sym n 0 = BitVec.ofNat 64 a)
    (tls : XTls Γ.F X)
    {w w' : Arm.ArmState} (memory : MRP Γ f c D fr.slots cm (w,w'))
    (arguments : ArgsAtEntry Γ.F f.sig args w) (otherArguments : ArgsAtEntry Γ.F f.sig args w')
    (registers : ∀ pin v,(.reg pin,v) ∈ (locsOf f.sig).zip args → regVal w' pin = regVal w pin) :
    ∃ ρ, RunOkABI f result.code (pairSem (csem Γ.F fc X)) (MRP Γ f c D) fr.slots
      ⟨0,0,ρ,(w,w')⟩ (.returned vals mem) := by
  exact ⟨entrySeed result.ctx fr,single_store_return_paired_function_seeded kind ty run scope dominated abi
    blocks singleton ret parameter valueParameter width entered returned registerOnly slot symbols tls memory arguments otherArguments registers⟩

end E2E.StockMemory.StoreRoots

namespace E2E.StockMemoryStoreFunctionWitness
open Backend Backend.Stock Backend.Proof Backend.Proof.Driver Backend.Stock.Proof Backend.Stock.Memory
open Backend.Stock.Memory.StoreRoots Backend.Stock.Memory.StoreRoots.Fixture
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000

private def value (kind : Kind) : Clif.Val := Clif.Val.ofNat kind.sourceTy 37
private def initial (kind : Kind) : Clif.Frame := {
  func := function kind,regs := (Clif.Regs.empty.set 0 ⟨.i64,4096⟩).set 1 (value kind),slots := [],
  body := [⟨[],.store kind.sourceOp kind.sourceTy flags 1 0 0⟩],term := .ret [] }
private def heap : Clif.Mem := {allocs := [⟨4096,8,false⟩],bytes := fun _ => some 165}
private def baseWorld : Arm.ArmState := {Arm.ArmState.default with mem := fun _ => 165}
private def relation : E2E.Rel := ⟨fun _ => False,fun _ => none,0,0⟩
private def afterHeap (kind : Kind) : Clif.Mem :=
  heap.writeBits false 4096 (kind.sourceOp.size kind.sourceTy) (value kind).bits
private theorem locations (kind : Kind) : locsOf (function kind).sig = [ArgLoc.reg (.x 0),ArgLoc.reg (.x 1)] := by
  cases kind <;> rfl
private theorem memory_base (kind : Kind) : relation.holds (function kind) (initial kind).slots heap baseWorld := by
  refine ⟨⟨?_,?_,rfl⟩,?_,outRel_zero _ _ _⟩
  · intro a b valid byte
    have equal : (165 : BitVec 8) = b := Option.some.inj byte
    subst b
    rfl
  · intro a n valid
    have bound : 4096 ≤ a ∧ a+n ≤ 4104 := by
      simpa [heap,Clif.Mem.valid,Clif.Alloc.contains] using valid
    exact ⟨by omega,fun _ _ h => h⟩
  · intro id b present
    cases present

private def world : Arm.ArmState := Arm.write_base_gpr 1#5 37 (Arm.write_base_gpr 0#5 4096 baseWorld)

private theorem memory (kind : Kind) : relation.holds (function kind) (initial kind).slots heap world := by
  refine ⟨⟨?_,(memory_base kind).1.valid,rfl⟩,?_,E2E.outRel_zero _ _ _⟩
  · intro a b valid byte; exact (memory_base kind).1.bytes a b valid byte
  · intro id b present; cases present

private theorem arguments (kind : Kind) : ArgsAtEntry relation.F (function kind).sig [⟨.i64,4096⟩,value kind] world := by
  intro loc val member
  rw [locations] at member
  simp only [List.zip_cons_cons,List.zip_nil_right,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with equal | equal <;> cases equal
  all_goals cases kind <;> simp only [VHolds,regVal,world,Arm.r,Arm.read_base_gpr,Arm.write_base_gpr,Arm.read_store,Arm.write_store,rnum] <;> rfl



private def otherWorld : Arm.ArmState := Arm.write_base_gpr 10#5 17 world
private def noExternal : ExtSem := ⟨fun _ _ _ => none,fun _ _ => 0,0,fun _ _ => Arm.PState.zero⟩

private theorem pairedMemory (kind : Kind) : MRP relation (function kind) 0 (fun _ => True)
    (initial kind).slots heap (world,otherWorld) := by
  have same : SameWorld (Zof relation.F (fun _ => True) heap) world otherWorld := by
    simpa only [otherWorld,Arm.w] using (SameWorld.refl _ world).w_right
      (f := .GPR 10#5) (v := 17) (by change (10 < 29 ∧ 10 ≠ 18) ∨ 10 = 30; decide)
  refine ⟨⟨memory kind,?_,?_⟩,⟨?_,?_,?_⟩,same⟩
  · simp [spv,Arm.r,Arm.read_base_gpr,Arm.read_store,world,baseWorld,Arm.write_base_gpr,Arm.write_store,Arm.ArmState.default]
  · simp only [Arm.r,Arm.read_base_error,world,Arm.write_base_gpr,baseWorld,Arm.ArmState.default]
  · refine ⟨⟨?_,(memory_base kind).1.valid,rfl⟩,?_,outRel_zero _ _ _⟩
    · intro a b valid byte; exact (memory_base kind).1.bytes a b valid byte
    · intro id b present; cases present
  · simp [spv,Arm.r,Arm.read_base_gpr,Arm.read_store,otherWorld,world,baseWorld,Arm.write_base_gpr,Arm.write_store,Arm.ArmState.default]
  · simp only [Arm.r,Arm.read_base_error,otherWorld,world,Arm.write_base_gpr,baseWorld,Arm.ArmState.default]

/-- Two distinct original ABI-entry worlds execute the actual complete Stock
store/return function from PC0, writing nonzero bytes and sharing one
virtual file throughout. -/
theorem complete_paired_integer_store_function_witness (kind : Kind) :
    Arm.r (.GPR 10#5) otherWorld ≠ Arm.r (.GPR 10#5) world ∧
    (afterHeap kind).bytes 4096 = some 37 ∧ heap.bytes 4096 = some 165 ∧
    ∃ (result : Result) (ρ : Nat → CV),Stock.lower (function kind) = .ok result ∧
      Clif.enterFunc (function kind) [⟨.i64,4096⟩,value kind] heap = .ok (initial kind,heap) ∧
      RunOkABI (function kind) result.code (pairSem (csem relation.F ⟨0,0⟩ noExternal))
        (MRP relation (function kind) 0 (fun _ => True)) (initial kind).slots ⟨0,0,ρ,(world,otherWorld)⟩
        (.returned [] (afterHeap kind)) := by
  refine ⟨by decide +kernel,(by cases kind <;> rfl),rfl,?_⟩
  obtain ⟨input⟩ := record_input kind
  let result := input.result
  have run : Stock.lower (function kind) = .ok result := input.run
  have entered : Clif.enterFunc (function kind) [⟨.i64,4096⟩,value kind] heap = .ok (initial kind,heap) := by cases kind <;> rfl
  have registerOnly : ∀ loc ∈ locsOf (function kind).sig,∃ pin,loc = .reg pin := by
    intro loc member
    rw [locations] at member
    simp only [List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl <;> exact ⟨_,rfl⟩
  have otherArguments : ArgsAtEntry relation.F (function kind).sig [⟨.i64,4096⟩,value kind] otherWorld := by
    intro loc val member
    rw [locations] at member
    simp only [List.zip_cons_cons,List.zip_nil_right,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with equal | equal <;> cases equal
    all_goals cases kind <;> simp only [VHolds,regVal,otherWorld,world,Arm.r,Arm.read_base_gpr,Arm.write_base_gpr,Arm.read_store,Arm.write_store,rnum] <;> rfl
  have registers : ∀ (pin : Reg) (v : Clif.Val),(.reg pin,v) ∈
      (locsOf (function kind).sig).zip [⟨.i64,4096⟩,value kind] → regVal otherWorld pin = regVal world pin := by
    intro pin v member
    rw [locations] at member
    simp only [List.zip_cons_cons,List.zip_nil_right,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with equal | equal <;> cases equal <;> simp [regVal,otherWorld,world,Arm.r,Arm.read_base_gpr,Arm.write_base_gpr,Arm.read_store,Arm.write_store,rnum]
  obtain ⟨ρ,finished⟩ := StockMemory.StoreRoots.single_store_return_paired_function kind kind.sourceTy run (scope kind) (dominated kind)
    (by cases kind <;> rfl)
    (b := (function kind).blocks[0]!) rfl rfl rfl (by simp [function])
    (valueTy := kind.sourceTy) (by simp [function])
    (by cases kind <;> intro h <;> first | rfl | cases h) (SourceEntry.of_enterFunc entered)
    (show Clif.runLoop Clif.Env.empty {funcs := []} 2 ⟨initial kind,[],heap⟩ =
      .returned [] (afterHeap kind) from by cases kind <;> rfl) registerOnly
    (Γ := relation) (c := 0) (D := fun _ => True) (fc := ⟨0,0⟩) (X := noExternal)
    rfl (fun _ _ h => by cases h) (by intro Z n w w' subset same; rfl)
    (pairedMemory kind) (arguments kind) otherArguments registers
  exact ⟨result,ρ,run,entered,finished⟩

end E2E.StockMemoryStoreFunctionWitness

namespace Backend.Stock.Memory.StoreRoots
open Backend.Proof Backend.Proof.Driver Backend.Stock.Proof
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000

/-- The original source-only single-store return class satisfies the complete
memory-capable entry/return/trap contract. Actual record retention, selected load,
result aliases, body execution and ABI entry/return are all derived internally.
The original memory/world relation supplies validity; no source certificate or
new initial heap condition is added. -/
theorem domain_of_single_store_return (kind : Kind) (ty : Clif.Ty) {f : Clif.Function}
    (scope : LowerScope f) (dominated : Dominated f) (abi : sigAbiOk f.sig = true)
    (ordinary : (sigRets f.sig).any (·.purpose == .sret) = false)
    {b : Clif.Block} (blocks : f.blocks = [b]) {value pointer : Nat} {flags : Clif.MemFlags} {valueTy : Clif.Ty}
    (singleton : b.body = [⟨[],.store kind.sourceOp ty flags value pointer 0⟩])
    (ret : b.term = .ret []) (parameter : pointer ∈ b.params.map (·.1))
    (valueParameter : (value,valueTy) ∈ b.params)
    (width : kind.sourceOp = .store → CTy.ofClif valueTy = .int kind.width.bits)
    (notrap : flags.trapCode = none) : Domain f := by
  have family : ∀ stm ∈ b.body,OrdinaryBody.OrdinaryInst stm.inst := by
    intro stm member
    have same : stm = ⟨[],.store kind.sourceOp ty flags value pointer 0⟩ := by simpa only [singleton,List.mem_singleton] using member
    subst stm
    constructor
    · intro fn args impossible; cases impossible
    · intro sig callee args impossible; cases impossible
  have formats : ∀ b' ∈ f.blocks, ∀ stm ∈ b'.body,CastComplete.MemoryFormat stm.inst := by
    intro b' member stm present
    have same : b' = b := by simpa [blocks] using member
    subst b'
    have same : stm = ⟨[],.store kind.sourceOp ty flags value pointer 0⟩ := by simpa [singleton] using present
    subst stm
    simp [CastComplete.MemoryFormat,instNames]
  have entryBlock : f.blocks[0]? = some b := by simp [blocks]
  refine ⟨scope,dominated,abi,ordinary,?_,?_⟩
  · intro result run args cm fr entered env cp fuel vals mem returned F isem refines driver
      sb syms memorySem MR stable memoryOk w memory arguments
    apply OrdinaryBody.actual_ordinary_entry_return_refines_frame run scope dominated abi blocks family ret
      entered returned refines driver memorySem stable ?_ memory arguments
    intro event events
    obtain ⟨b',term,body,split⟩ := stock_lower_body_scan_split run scope events
    have bound : event.block < 1 := by have h := lt_of_getElem? split.block; simpa [blocks] using h
    have zero : event.block = 0 := by omega
    have actualBlock : f.blocks[event.block]? = some b := by rw [zero]; exact entryBlock
    exact stock_single_store_return_body kind ty run scope dominated formats events actualBlock singleton ret
      entryBlock parameter entryBlock valueParameter width stable (store_refines_of_mem memorySem) memoryOk
  · intro result run args cm fr entered env cp fuel code trapped F isem refines driver
      sb syms memorySem MR stable memoryOk w memory arguments
    obtain ⟨b',regs,entry,argTypes,paramTypes,set,frame⟩ := entered
    have sameBlock : b' = b := by
      have found : some b = some b' := by simpa only [Clif.Function.entry?,blocks,List.head?_cons] using entry
      exact Option.some.inj found.symm
    subst b'
    have sourceFamily : ∀ stm ∈ fr.body,OrdinaryBody.OrdinaryInst stm.inst ∧
        ∀ fr cm c,Clif.evalInst fr cm stm.inst ≠ .trap c := by
      intro stm member
      have present : stm ∈ b.body := by rw [frame] at member; exact member
      refine ⟨family stm present,?_⟩
      have same : stm = ⟨[],.store kind.sourceOp ty flags value pointer 0⟩ := by simpa only [singleton,List.mem_singleton] using present
      subst stm
      intro fr cm c
      exact Clif.evalInst_notrap rfl notrap c
    exact False.elim ((OrdinaryBody.ordinary_source_notrap fuel ⟨fr,[],cm⟩ rfl sourceFamily
      (by rw [frame]; exact ret) code) trapped)

end Backend.Stock.Memory.StoreRoots

namespace Backend.Stock.Memory.StoreRoots
open Backend.Proof Backend.Proof.Driver Backend.Stock.Proof
set_option autoImplicit false
set_option Elab.async false

/-- The first production memory class is described entirely by original source
syntax and the original scope/dominance/ABI conditions. No run or output artifact
is part of this predicate. Other previously accepted classes retain fallback. -/
structure SingleClass (kind : Kind) (ty : Clif.Ty) (f : Clif.Function) : Prop where
  scope : LowerScope f
  dominated : Dominated f
  abi : sigAbiOk f.sig = true
  ordinary : (sigRets f.sig).any (·.purpose == .sret) = false
  registers : ∀ loc ∈ locsOf f.sig,∃ pin,loc = .reg pin
  shape : ∃ (b : Clif.Block) (value pointer : Nat) (flags : Clif.MemFlags) (valueTy : Clif.Ty),
    f.blocks = [b] ∧ b.body = [⟨[],.store kind.sourceOp ty flags value pointer 0⟩] ∧
      b.term = .ret [] ∧ pointer ∈ b.params.map (·.1) ∧ (value,valueTy) ∈ b.params ∧
      (kind.sourceOp = .store → CTy.ofClif valueTy = .int kind.width.bits) ∧ flags.trapCode = none

/-- The source class derives the full original-source memory contract. -/
theorem SingleClass.domain (kind : Kind) (ty : Clif.Ty) {f : Clif.Function} (family : SingleClass kind ty f) : Domain f := by
  obtain ⟨b,value,pointer,flags,valueTy,blocks,body,ret,parameter,valueParameter,width,notrap⟩ := family.shape
  exact domain_of_single_store_return kind ty family.scope family.dominated family.abi family.ordinary
    blocks body ret parameter valueParameter width notrap

end Backend.Stock.Memory.StoreRoots

namespace E2E.StockMemoryStoreFunctionWitness
open Backend Backend.Stock Backend.Proof Backend.Proof.Driver Backend.Stock.Proof Backend.Stock.Memory
open Backend.Stock.Memory.StoreRoots Backend.Stock.Memory.StoreRoots.Fixture
theorem source_class_witness (kind : Kind) : SingleClass kind kind.sourceTy (function kind) := by
  refine ⟨scope kind,dominated kind,(by cases kind <;> rfl),rfl,?_,?_⟩
  · intro loc member
    have locations : locsOf (function kind).sig = [ArgLoc.reg (.x 0),ArgLoc.reg (.x 1)] := by cases kind <;> rfl
    rw [locations] at member
    simp only [List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl <;> exact ⟨_,rfl⟩
  · exact ⟨(function kind).blocks[0]!,1,0,flags,kind.sourceTy,rfl,rfl,rfl,
      (by simp [function]),(by simp [function]),(by cases kind <;> intro h <;> first | rfl | cases h),rfl⟩
end E2E.StockMemoryStoreFunctionWitness

namespace Backend.Stock.Memory.Store

/-- Retain the existing effect forms and admit concrete store effects. -/
def effectInstruction : MInst → Bool
  | .store .. => true
  | i => Memory.effectInstruction i

/-- The store consumer checks the actual emitted instructions. -/
def effectsOnly (vc : VCode) : Bool :=
  vc.blocks.toList.all (fun b => b.insts.toList.all effectInstruction)

/-- The previous whitelist remains accepted exactly as before. -/
theorem effectsOnly_of_previous {vc : VCode} (previous : Memory.effectsOnly vc = true) :
    effectsOnly vc = true := by
  apply List.all_eq_true.mpr
  intro b member
  apply List.all_eq_true.mpr
  intro i present
  have before := List.all_eq_true.mp (List.all_eq_true.mp previous b member) i present
  cases i <;> simp_all [effectInstruction,Memory.effectInstruction]

end Backend.Stock.Memory.Store

namespace Backend.Stock.MemoryStore
open Backend.Proof.Driver
set_option autoImplicit false

def scalarParameter : Clif.Ty → Bool
  | .i8 | .i16 | .i32 | .i64 => true
  | _ => false

/-- The first store selector reads only original source syntax. -/
def eligible (f : Clif.Function) : Bool :=
  match f.blocks with
  | [b] => match b.body with
    | [⟨[],.store op ty flags value pointer 0⟩] => match b.term with
      | .ret [] => (b.params.map (·.1)).contains pointer &&
          b.params.any (fun q => q.1 == value && scalarParameter q.2) && flags.trapCode.isNone
      | _ => false
    | _ => false
  | _ => false

def sourceOk (f : Clif.Function) : Bool :=
  eligible f && lowerScopeB f && dominatedB f && sigAbiOk f.sig &&
    !(sigRets f.sig).any (·.purpose == .sret) && Memory.registerEntry f.sig

def check (f : Clif.Function) (vc : VCode) : Bool :=
  sourceOk f && match Stock.lower f with
  | .error _ => false
  | .ok result => decide (result.code = vc) && Memory.Store.effectsOnly vc

end Backend.Stock.MemoryStore

namespace E2E.StockMemory.StoreRoots
open Backend Backend.Proof Backend.Proof.Driver Backend.DeadCleanup
set_option autoImplicit false
set_option Elab.async false

/-- The first memory adapter only needs effects whose value semantics is their
concrete semantics. This property is checked on the actual emitted artifact. -/
abbrev effectsOnly := Backend.Stock.Memory.Store.effectsOnly

theorem effectsOnly_instruction {vc : VCode} (checked : effectsOnly vc = true)
    {b k : Nat} {vb : VBlock} {i : MInst}
    (block : vc.blocks[b]? = some vb) (inst : vb.insts[k]? = some i) :
    pureForm i = false := by
  have blocks := List.all_eq_true.mp checked vb (by simpa using Array.mem_of_getElem? block)
  have instruction := List.all_eq_true.mp blocks i (by simpa using Array.mem_of_getElem? inst)
  cases i <;> simp_all [Backend.Stock.Memory.Store.effectInstruction,Backend.Stock.Memory.effectInstruction,pureForm]

/-- The checked effect whitelist also excludes the compare specifications added
by the current cleanup semantics. The preserved pure-only variant stays above. -/
private theorem effectsOnly_spec_instruction {vc : VCode} (checked : effectsOnly vc = true)
    {b k : Nat} {vb : VBlock} {i : MInst}
    (block : vc.blocks[b]? = some vb) (inst : vb.insts[k]? = some i) :
    specForm i = false := by
  have blocks := List.all_eq_true.mp checked vb (by simpa using Array.mem_of_getElem? block)
  have instruction := List.all_eq_true.mp blocks i (by simpa using Array.mem_of_getElem? inst)
  cases i <;> simp_all [Backend.Stock.Memory.Store.effectInstruction,Backend.Stock.Memory.effectInstruction,specForm,pureForm,cmpForm]

private theorem value_step {vc : VCode} (checked : effectsOnly vc = true)
    {F : BitVec 64 → Prop} {fc : FnCtx} {X : ExtSem} {s t : VConf CV Arm.ArmState}
    (step : VStep vc (csem F fc X) s t) : VStep vc (valueSem F fc X) s t := by
  cases step with
  | step block inst operands run arity next =>
    refine .step block inst operands ?_ arity next
    simpa only [valueSem,effectsOnly_spec_instruction checked block inst,Bool.false_eq_true,ite_false] using run

private theorem value_star {vc : VCode} (checked : effectsOnly vc = true)
    {F : BitVec 64 → Prop} {fc : FnCtx} {X : ExtSem} {s t : VConf CV Arm.ArmState}
    (path : Star (VStep vc (csem F fc X)) s t) : Star (VStep vc (valueSem F fc X)) s t := by
  induction path with
  | refl => exact .refl _
  | step first rest ih => exact .step (value_step checked first) ih

/-- On checked actual effect-only code, the production value consumer executes
exactly the concrete run, including its final world and ABI output tuple. -/
theorem return_value {vc : VCode} (checked : effectsOnly vc = true)
    {F : BitVec 64 → Prop} {fc : FnCtx} {X : ExtSem} {vs : VState CV Arm.ArmState}
    {us : List (Reg × Reg)} {outs : List CV} {world : Arm.ArmState}
    (returned : VRetFrom vc (csem F fc X) vs us outs world) :
    VRetFrom vc (valueSem F fc X) vs us outs world := by
  obtain ⟨b,k,ρ,w,vb,ops,results,path,block,inst,operands,values,run⟩ := returned
  have transferred := value_star checked path
  refine ⟨b,k,ρ,w,vb,ops,results,transferred,block,inst,operands,values,?_⟩
  simpa only [valueSem,effectsOnly_spec_instruction checked block inst,Bool.false_eq_true,ite_false] using run

end E2E.StockMemory.StoreRoots

namespace E2E.StockMemory.StoreRoots
open Backend Backend.Proof Backend.Proof.Driver Backend.DeadCleanup
set_option autoImplicit false
set_option Elab.async false

/-- Actual effect-only Stock returns use the existing checked allocation,
cleanup/preparation, encoding and machine consumer with exact value semantics. -/
theorem machine_return {f : Clif.Function} {args : List Clif.Val}
    {vc vcp : VCode} {rf : RFunc} {af : AFunc} {fa : FnAsm} {fb : FnBin} {k : Nat}
    {cleanup : Bool} (effects : effectsOnly vc = true)
    (prep : prepCheck (Stock.Arithmetic.stage cleanup vc) vcp = true)
    (check : checkAlloc vcp rf = .ok ()) (alloc : lowerRFunc vcp rf = .ok af)
    (emit : emitFunc k af = .ok fa) (layout : fa.layout = .ok fb)
    {X : ExtSem} {K : Nat} {F Z : BitVec 64 → Prop}
    (frame : ∀ a, F a → Z a) (covered : FormsCovered ⟨fa.k,af.slotBase⟩ vcp)
    {w final reference : Arm.ArmState} (arguments : ArgsAtEntry F f.sig args w)
    (worlds : SameWorld Z final reference)
    {ρ : Nat → CV} {us : List (Reg × Reg)} {outs : List CV}
    (returned : VReturns vc (csem F ⟨fa.k,af.slotBase⟩ X) ρ w us outs final)
    (H : ArmHooks) (G : BitVec 64 → Prop) (base ra : BitVec 64) (s : Arm.ArmState)
    (entry : ActEntry vcp rf af fa fb K F G X H base ra s w) :
    ∃ n, ActRet ra Z G us outs reference s (runX (ArmStepX X H fa) n s) ∧
      PostTrace fa af base (ArmStepX X H fa) s n ∧
      ∀ i < n, actGoodX vcp rf af fa fb base s X H K G (GotV vcp)
        (runX (ArmStepX X H fa) i s) := by
  have valueRun := return_value effects returned
  let t := final
  have finalWorld := worlds
  have prepared := StockArithmeticStage_returns prep valueRun
  have machine := regLevelCorrect_worldX_value check alloc emit layout
    (X := X) (H := H) (K := K) (G := G) (gv := GotV vcp)
    covered entry.abi entry.stack entry.gfree (by rw [entry.hF]; exact entry.calls)
    (by rw [entry.hF]; exact entry.tries) (by rw [entry.hF]; exact entry.tls)
    (by rw [entry.hF]; exact entry.body) ρ
  rw [entry.hF] at machine
  obtain ⟨n,⟨h1,h2,h3,h4,h5,h6,h7⟩,h8⟩ :=
    machine.1 us outs t (vReturns_gotV_value prepared)
  refine ⟨n,⟨h1,h2,?_,?_,h5,h6⟩,h7,h8⟩
  · intro a outside
    rw [h3 a (fun hf => outside (frame a hf))]
    exact finalWorld.2.1 a outside
  · intro field unmasked fp sp
    rw [h4 field unmasked fp sp]
    exact finalWorld.1 field unmasked


end E2E.StockMemory.StoreRoots

namespace E2E
open Backend Backend.Proof Backend.Proof.Driver Backend.Stock.Proof Backend.DeadCleanup
set_option autoImplicit false
set_option Elab.async false
set_option maxHeartbeats 4000000

/-- Complete source-to-machine paired correctness for the first original
store/return class. Source writes determine both updated memory relations; the
old source, ABI, linked-world and activation premises are preserved. -/
theorem backend_correct_world_niX_stock_store_memory {kind : Stock.Memory.StoreRoots.Kind} {ty : Clif.Ty} {p : Clif.Program} {f : Clif.Function} {k : Nat} {result : Stock.Result} {vcp : VCode}
    {rf : RFunc} {af : AFunc} {fa : FnAsm} {fb : FnBin}
    (family : Stock.Memory.StoreRoots.SingleClass kind ty f) {cleanup : Bool}
    (readOnly : StockMemory.StoreRoots.effectsOnly result.code = true)
    (hc : CompiledStockArithmeticStage f cleanup k result vcp rf af fa fb)
    {X : ExtSem} {syms : String → Option Nat} {slotOff : Nat} {env : Clif.Env} {K : Nat}
    {F : BitVec 64 → Prop} {c : BitVec 64}
    (hcov : FormsCovered ⟨fa.k, af.slotBase⟩ vcp)
    (hsym : ∀ n b, syms n = some b → X.sym n 0 = BitVec.ofNat 64 b)
    (hslot : af.slotBase = slotOff)
    (hTls : XTls F X)
    {w₀ : Arm.ArmState} {args : List Clif.Val} {cs : Clif.State}
    (hcs : ClifEntry f args cs)
    (hrel : RelW ⟨F, syms, slotOff, (RAFrame.compute vcp rf).intBase⟩ f c cs.frame.slots cs.mem w₀)
    (hargs : ArgsAtEntry F f.sig args w₀)
    (fuel : Nat) :
    ∀ vals cm, Clif.runLoop env p fuel cs = .returned vals cm →
      ∃ (us : List (Reg × Reg)) (outs : List CV) (w : Arm.ArmState),
        us.map (·.2) = (List.range us.length).map Reg.x ∧ us.length = outs.length ∧
        PrefixHold vals outs ∧ MemRel F syms cm w ∧ result.code.RetsSite us ∧
        (∀ (H : ArmHooks) (G : BitVec 64 → Prop) (base ra : BitVec 64) (s : Arm.ArmState),
          ActEntry vcp rf af fa fb K F G X H base ra s w₀ →
          ∃ n, ActRet ra F G us outs w s (runX (ArmStepX X H fa) n s) ∧
            PostTrace fa af base (ArmStepX X H fa) s n ∧
            ∀ i < n, actGoodX vcp rf af fa fb base s X H K G (GotV vcp)
              (runX (ArmStepX X H fa) i s)) ∧
        (∀ (D : BitVec 64 → Prop) (w₀' : Arm.ArmState),
          RelW ⟨F, syms, slotOff, (RAFrame.compute vcp rf).intBase⟩ f c cs.frame.slots cs.mem w₀' →
          SameWorld (fun b => F b ∨ D b) w₀ w₀' →
          (∀ r v, (ArgLoc.reg r, v) ∈ (locsOf f.sig).zip args → regVal w₀' r = regVal w₀ r) →
          (∀ off v, (ArgLoc.stack off, v) ∈ (locsOf f.sig).zip args → ∀ k < v.ty.bytes,
            w₀'.mem (Arm.r (.GPR 29#5) w₀ + BitVec.ofInt 64 (16 + (off : Int)) + BitVec.ofNat 64 k) =
              w₀.mem (Arm.r (.GPR 29#5) w₀ + BitVec.ofInt 64 (16 + (off : Int)) + BitVec.ofNat 64 k)) →
          ∀ (H : ArmHooks) (G : BitVec 64 → Prop) (base ra : BitVec 64) (s : Arm.ArmState),
            ActEntry vcp rf af fa fb K F G X H base ra s w₀' →
            ∃ n, ActRet ra (fun a => F a ∨ D a) G us outs w s (runX (ArmStepX X H fa) n s) ∧
              PostTrace fa af base (ArmStepX X H fa) s n ∧
              ∀ i < n, actGoodX vcp rf af fa fb base s X H K G (GotV vcp)
                (runX (ArmStepX X H fa) i s)) := by
  intro vals cm returned
  have state : (⟨cs.frame,[],cs.mem⟩ : Clif.State) = cs := by
    have callers := hcs.callers
    cases cs
    cases callers
    rfl
  obtain ⟨b,value,pointer,flags,valueTy,blocks,body,ret,parameter,valueParameter,width,notrap⟩ := family.shape
  have sourceReturn : Clif.runLoop env p fuel ⟨cs.frame,[],cs.mem⟩ = .returned vals cm := by rwa [state]
  have source := StockMemory.StoreRoots.single_store_return_paired_function_seeded kind ty hc.lower family.scope family.dominated family.abi
    blocks body ret parameter valueParameter width hcs.stockSourceEntry sourceReturn family.registers (fc := ⟨fa.k,af.slotBase⟩) hslot hsym hTls
    (D := fun _ => False) ⟨hrel,hrel,SameWorld.refl _ w₀⟩ hargs hargs (fun _ _ _ => rfl)
  obtain ⟨us,outs,q,cm0,reached,pins,arity,values,memory,freed⟩ := source
  have first := (vRetFrom_pair reached).1
  have site : result.code.RetsSite us := by
    obtain ⟨b,k,ρ,w₁,vb,ops,outs',_,hvb,hk,_⟩ := first
    exact ⟨b,vb,k,hvb,hk⟩
  have mem : MemRel F syms cm q.1 := by
    rw [freed]
    exact memRel_leave (memRel_free memory.1.1.1 _)
  refine ⟨us,outs,q.1,pins.ordinary family.ordinary,arity,values,mem,site,?_,?_⟩
  · intro H G base ra s he
    exact StockMemory.StoreRoots.machine_return readOnly hc.prepOk hc.check hc.alloc hc.emit hc.layout
      (fun _ h => h) hcov hargs (SameWorld.refl F q.1) first H G base ra s he
  · intro D w₀' hrel' hsw hreg hstk H G base ra s he
    have arguments := ABIReadOnly.arguments_transport hargs hsw hreg hstk
    have pairedMemory : MRP ⟨F,syms,slotOff,(RAFrame.compute vcp rf).intBase⟩ f c D
        cs.frame.slots cs.mem (w₀,w₀') :=
      ⟨hrel,hrel',sameWorld_zof hrel.1.1 hrel'.1.1 hsw (fun _ h => h)⟩
    have paired := StockMemory.StoreRoots.single_store_return_paired_function_seeded kind ty hc.lower family.scope family.dominated family.abi
      blocks body ret parameter valueParameter width hcs.stockSourceEntry sourceReturn family.registers (fc := ⟨fa.k,af.slotBase⟩) hslot hsym hTls
      pairedMemory hargs arguments hreg
    obtain ⟨us',outs',q',cm0',reached',pins',arity',values',memory',freed'⟩ := paired
    obtain ⟨reference,other⟩ := vRetFrom_pair reached'
    obtain ⟨samePins,sameOuts,sameWorld⟩ := vRetFrom_det first reference
    rw [← samePins,← sameOuts] at other
    have related : SameWorld (fun a => F a ∨ D a) q'.2 q.1 := by
      rw [sameWorld]
      exact (SameWorld.mono (zof_sub cm0') memory'.2.2).symm
    exact StockMemory.StoreRoots.machine_return readOnly hc.prepOk hc.check hc.alloc hc.emit hc.layout
      (fun _ h => Or.inl h) hcov arguments related other H G base ra s he

end E2E

namespace Backend.Stock.MemoryStore
open Backend.Proof Backend.Proof.Driver Backend.Stock.Proof Backend.Stock.Memory.StoreRoots
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 20000

/-- The source selector derives the complete proved store class internally. -/
theorem sourceOk_sound {f : Clif.Function} (checked : sourceOk f = true) :
    ∃ kind ty,SingleClass kind ty f := by
  simp only [sourceOk,Bool.and_eq_true,Bool.not_eq_true'] at checked
  obtain ⟨⟨⟨⟨⟨shapeOk,scope⟩,dominated⟩,abi⟩,ordinary⟩,registers⟩ := checked
  have registerOnly : ∀ loc ∈ locsOf f.sig,∃ pin,loc = .reg pin := by
    intro loc member
    have good := List.all_eq_true.mp registers loc member
    cases loc with
    | reg pin => exact ⟨pin,rfl⟩
    | stack off => cases good
  unfold eligible at shapeOk
  split at shapeOk
  next b blocks =>
    split at shapeOk
    next op ty flags value pointer body =>
      split at shapeOk
      next terminal =>
        simp only [Bool.and_eq_true] at shapeOk
        obtain ⟨⟨parameter,valueParameter⟩,notrap⟩ := shapeOk
        obtain ⟨⟨x,valueTy⟩,member,positive⟩ := List.any_eq_true.mp valueParameter
        obtain ⟨same,scalar⟩ := Bool.and_eq_true_iff.mp positive
        have equal : x = value := by simpa only [beq_iff_eq] using same
        subst x
        have make (kind : Kind) (opcode : op = kind.sourceOp)
            (width : kind.sourceOp = .store → CTy.ofClif valueTy = .int kind.width.bits) :
            SingleClass kind ty f := by
          refine ⟨lowerScope_of scope,dominated_of dominated,abi,ordinary,registerOnly,?_⟩
          exact ⟨b,value,pointer,flags,valueTy,blocks,by simpa only [opcode] using body,
            terminal,List.contains_iff_mem.mp parameter,member,width,Option.isNone_iff_eq_none.mp notrap⟩
        cases op with
        | store =>
          cases valueTy <;> simp only [scalarParameter] at scalar
          all_goals first
            | exact ⟨.plain8,ty,make .plain8 rfl (by intro h; rfl)⟩
            | exact ⟨.plain16,ty,make .plain16 rfl (by intro h; rfl)⟩
            | exact ⟨.plain32,ty,make .plain32 rfl (by intro h; rfl)⟩
            | exact ⟨.plain64,ty,make .plain64 rfl (by intro h; rfl)⟩
            | cases scalar
        | istore8 => exact ⟨.narrow8,ty,make .narrow8 rfl (by intro h; cases h)⟩
        | istore16 => exact ⟨.narrow16,ty,make .narrow16 rfl (by intro h; cases h)⟩
        | istore32 => exact ⟨.narrow32,ty,make .narrow32 rfl (by intro h; cases h)⟩
      next => cases shapeOk
    next => cases shapeOk
  next => cases shapeOk

/-- The checked artifact comes from the proved store class and actual driver run. -/
theorem check_sound {f : Clif.Function} {vc : VCode} (checked : check f vc = true) :
    ∃ kind ty result,SingleClass kind ty f ∧ Stock.lower f = .ok result ∧
      result.code = vc ∧ Memory.Store.effectsOnly vc = true := by
  simp only [check,Bool.and_eq_true] at checked
  obtain ⟨source,lowered⟩ := checked
  obtain ⟨kind,ty,family⟩ := sourceOk_sound source
  cases run : Stock.lower f with
  | error error => rw [run] at lowered; cases lowered
  | ok result =>
    rw [run] at lowered
    obtain ⟨equal,effects⟩ := Bool.and_eq_true_iff.mp lowered
    exact ⟨kind,ty,result,family,rfl,of_decide_eq_true equal,effects⟩

end Backend.Stock.MemoryStore

namespace Backend.Stock.MemoryStore
set_option autoImplicit false

/-- Add the proved integer stores with the complete previous provider as fallback. -/
def lowerValidated (f : Clif.Function) : Except String VCode :=
  if !eligible f then MemoryExtending.lowerValidated f
  else
    let attempt := do
      let result ← Stock.lower f
      if check f result.code then pure result.code
      else throw "Stock store memory candidate failed paired semantic validation"
    match attempt with
    | .ok vc => .ok vc
    | .error _ => MemoryExtending.lowerValidated f

/-- Keep published routes0–15 and append the store provider as16. -/
def lowerRoutes : List (Clif.Function → Except String VCode) :=
  MemoryExtending.lowerRoutes ++ [lowerValidated]

def lowerWithRoutes (choices : List (String × Nat)) (f : Clif.Function) : Except String VCode :=
  match choices.lookup f.name with
  | none => lowerValidated f
  | some index => ((lowerRoutes[index]?).getD ScalarAdd.lower) f

end Backend.Stock.MemoryStore

namespace Backend
set_option autoImplicit false

def lowerCheckedMemoryStoreNI (f : Clif.Function) (verify : Bool) : Except String VCode :=
  let attempt := do
    let vc ← Stock.MemoryStore.lowerValidated f
    if verify && !SemanticNI.check f vc then
      throw "lowering rejected by the paired store memory semantic lowering validator"
    pure vc
  match attempt with
  | .ok vc => .ok vc
  | .error _ => lowerCheckedMemoryExtLoadNI f verify

def lowerForAllocationMemoryStoreNI (f : Clif.Function) (verify cleanup : Bool) : Except String VCode :=
  (lowerCheckedMemoryStoreNI f verify).map (Stock.Arithmetic.stage cleanup)

/-- Retry the previous complete pipeline on the original input and allocation
callback if store selection, allocation, emission or layout fails. -/
def compileFileMemoryStoreNIWhen {m : Type → Type} [Monad m] (enabled : Bool)
    (alloc : Array VCode → m (Array (Except String AFunc))) (pf : Clif.ParsedFile)
    (preUnverified : List (String × String) := []) (cleanup : Bool := true) : m FileAsm := do
  if !enabled then return ← compileFileMemoryExtLoadNIWhen false alloc pf preUnverified cleanup
  if !(pf.funcs.any fun p => p.func.toOption.any Stock.MemoryStore.eligible) then
    return ← compileFileMemoryExtLoadNIWhen true alloc pf preUnverified cleanup
  let attempt ← compileFileWithLowering lowerForAllocationMemoryStoreNI VCode.rulesFired
    alloc pf preUnverified cleanup
  if !attempt.unsupported.isEmpty || !attempt.layout.isOk then
    compileFileMemoryExtLoadNIWhen true alloc pf preUnverified cleanup
  else pure attempt

end Backend

namespace Backend.Stock.MemoryStore
set_option autoImplicit false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000

/-- Programs outside the optional memory selector use exactly the previous
pipeline, including allocator effects, identities, output bytes and stages.
This is a compatibility fact; it adds no compiler input requirement. -/
theorem previous_file_exact {m : Type → Type} [Monad m]
    (enabled : Bool) (allocate : Array VCode → m (Array (Except String AFunc)))
    (pf : Clif.ParsedFile) (prior : List (String × String)) (cleanup : Bool)
    (none : (pf.funcs.any fun p => p.func.toOption.any eligible) = false) :
    compileFileMemoryStoreNIWhen enabled allocate pf prior cleanup =
      compileFileMemoryExtLoadNIWhen enabled allocate pf prior cleanup := by
  cases enabled <;> simp [compileFileMemoryStoreNIWhen,none]

/-- A nonempty ordinary return input inhabits the
compatibility premise. The theorem holds for every allocator, not only this
witness's choice. -/
theorem previous_file_exact_witness :
    ∃ pf : Clif.ParsedFile,
      pf.funcs.length = 1 ∧ pf.funcs.all (·.func.isOk) = true ∧
      (pf.funcs.any fun p => p.func.toOption.any eligible) = false ∧
      compileFileMemoryStoreNIWhen (m := Id) true (fun _ => pure #[]) pf [] true =
        compileFileMemoryExtLoadNIWhen (m := Id) true (fun _ => pure #[]) pf [] true := by
  let f : Clif.Function := {
    name := "retained"
    sig := { params := [⟨.i64,.none,.normal⟩], returns := [⟨.i64,.none,.normal⟩] }
    blocks := [{ id := 0, params := [(0,.i64)], term := .ret [0] }] }
  let pf : Clif.ParsedFile := {
    header := [], funcs := [{ name := f.name, func := .ok f, runLines := 0 }] }
  have count : pf.funcs.length = 1 := by rfl
  have parsed : pf.funcs.all (·.func.isOk) = true := by rfl
  have absent : (pf.funcs.any fun p => p.func.toOption.any eligible) = false := by rfl
  exact ⟨pf,count,parsed,absent,previous_file_exact true (fun _ => pure #[]) pf [] true absent⟩

/-- Every previously published route keeps its original index. -/
theorem previous_routes_exact : lowerRoutes.take 16 = MemoryExtending.lowerRoutes := by rfl

/-- A source outside this class retains its exact previous artifact and history. -/
theorem previous_lower_exact {f : Clif.Function} (absent : eligible f = false) :
    lowerValidated f = MemoryExtending.lowerValidated f := by
  simp [lowerValidated,absent]

end Backend.Stock.MemoryStore


namespace E2E.StockMemoryStoreFunctionWitness
open Backend Backend.Proof Backend.Proof.Driver Backend.Stock.Proof
open Backend.Stock.Memory.StoreRoots Backend.Stock.Memory.StoreRoots.Fixture
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000

private theorem dominatedB_of_facts {f : Clif.Function}
    (unique : nodupB (valueDefs f) = true) (dominated : Dominated f) : dominatedB f = true := by
  simp only [dominatedB,unique,Bool.true_and]
  cases built : Backend.buildCtx f with
  | error message => rfl
  | ok output =>
    obtain ⟨ctx,ranges,st⟩ := output
    simp only
    apply List.all_eq_true.mpr
    intro bi member
    cases block : f.blocks[bi]? with
    | none => simp only [block]
    | some b =>
      simp only [block,Bool.and_eq_true,List.all_eq_true]
      have facts := ctxFacts_of built
      have defs : DefsAt ctx b (startOnly (blockStart f bi)).start := fun k stm atStatement r contains =>
        (facts.defs dominated.ssa r _).mpr ⟨bi,b,k,stm,block,atStatement,contains,rfl⟩
      refine ⟨⟨?_,?_⟩,?_⟩
      · intro j member
        cases statement : b.body[j]? with
        | none => simp only [statement]
        | some stm =>
          simp only [statement,List.all_eq_true]
          intro y contains
          exact (mem_avail block defs).mp ((dominated.uses _ _ _ built bi b block).1 j stm statement y contains)
      · intro y contains
        exact (mem_avail block defs).mp ((dominated.uses _ _ _ built bi b block).2 y contains)
      · intro x available
        simp only [Bool.or_eq_true,Std.HashSet.contains_ofList,List.contains_iff_mem,
          List.all_eq_true,Bool.not_eq_true',Bool.eq_false_iff,ne_eq]
        by_cases isLocal : x ∈ defsOf f bi
        · exact .inl isLocal
        · exact .inr (dominated.paramFree _ _ _ built bi x available isLocal)

/-- Original source functions positively inhabit the executable store selector. -/
theorem source_selector_witness (kind : Kind) : Backend.Stock.MemoryStore.sourceOk (function kind) = true := by
  simp only [Backend.Stock.MemoryStore.sourceOk,Bool.and_eq_true,Bool.not_eq_true']
  refine ⟨⟨⟨⟨⟨?_,?_⟩,?_⟩,(source_class_witness kind).abi⟩,
    (source_class_witness kind).ordinary⟩,?_⟩
  · cases kind <;> rfl
  · cases kind <;> decide +kernel
  · apply dominatedB_of_facts ?_ (dominated kind)
    change nodupB [0,1] = true
    simp [nodupB]
  · cases kind <;> rfl

end E2E.StockMemoryStoreFunctionWitness


namespace E2E.StockMemoryStoreUninitializedWitness
open Backend Backend.Stock Backend.Proof Backend.Proof.Driver Backend.Stock.Proof Backend.Stock.Memory
open Backend.Stock.Memory.StoreRoots Backend.Stock.Memory.StoreRoots.Fixture
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000

private def value (kind : Kind) : Clif.Val := Clif.Val.ofNat kind.sourceTy 37
private def initial (kind : Kind) : Clif.Frame := {
  func := function kind,regs := (Clif.Regs.empty.set 0 ⟨.i64,4096⟩).set 1 (value kind),slots := [],
  body := [⟨[],.store kind.sourceOp kind.sourceTy flags 1 0 0⟩],term := .ret [] }
private def heap : Clif.Mem := {allocs := [⟨4096,8,false⟩],bytes := fun _ => none}
private def baseWorld : Arm.ArmState := {Arm.ArmState.default with mem := fun _ => 165}
private def relation : E2E.Rel := ⟨fun _ => False,fun _ => none,0,0⟩
private def afterHeap (kind : Kind) : Clif.Mem :=
  heap.writeBits false 4096 (kind.sourceOp.size kind.sourceTy) (value kind).bits
private theorem locations (kind : Kind) : locsOf (function kind).sig = [ArgLoc.reg (.x 0),ArgLoc.reg (.x 1)] := by
  cases kind <;> rfl
private theorem memory_base (kind : Kind) : relation.holds (function kind) (initial kind).slots heap baseWorld := by
  refine ⟨⟨?_,?_,rfl⟩,?_,outRel_zero _ _ _⟩
  · intro a b valid byte
    change (none : Option (BitVec 8)) = some b at byte
    cases byte
  · intro a n valid
    have bound : 4096 ≤ a ∧ a+n ≤ 4104 := by
      simpa [heap,Clif.Mem.valid,Clif.Alloc.contains] using valid
    exact ⟨by omega,fun _ _ h => h⟩
  · intro id b present
    cases present

private def world : Arm.ArmState := Arm.write_base_gpr 1#5 37 (Arm.write_base_gpr 0#5 4096 baseWorld)

private theorem memory (kind : Kind) : relation.holds (function kind) (initial kind).slots heap world := by
  refine ⟨⟨?_,(memory_base kind).1.valid,rfl⟩,?_,E2E.outRel_zero _ _ _⟩
  · intro a b valid byte; exact (memory_base kind).1.bytes a b valid byte
  · intro id b present; cases present

private theorem arguments (kind : Kind) : ArgsAtEntry relation.F (function kind).sig [⟨.i64,4096⟩,value kind] world := by
  intro loc val member
  rw [locations] at member
  simp only [List.zip_cons_cons,List.zip_nil_right,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with equal | equal <;> cases equal
  all_goals cases kind <;> simp only [VHolds,regVal,world,Arm.r,Arm.read_base_gpr,Arm.write_base_gpr,Arm.read_store,Arm.write_store,rnum] <;> rfl



private def otherWorld : Arm.ArmState := {Arm.write_base_gpr 10#5 17 world with mem := fun _ => 203}
private def noExternal : ExtSem := ⟨fun _ _ _ => none,fun _ _ => 0,0,fun _ _ => Arm.PState.zero⟩

private theorem pairedMemory (kind : Kind) : MRP relation (function kind) 0 (fun _ => True)
    (initial kind).slots heap (world,otherWorld) := by
  have registers := (SameWorld.refl (Zof relation.F (fun _ => True) heap) world).w_right
    (f := .GPR 10#5) (v := 17) (by change (10 < 29 ∧ 10 ≠ 18) ∨ 10 = 30; decide)
  have same : SameWorld (Zof relation.F (fun _ => True) heap) world otherWorld := by
    refine ⟨?_,?_,?_⟩
    · intro field unmasked
      have equal := registers.1 field unmasked
      cases field <;> simpa only [otherWorld,Arm.w,Arm.r,Arm.read_base_gpr,Arm.read_base_sfp,Arm.read_base_pc,Arm.read_base_flag,Arm.read_base_pstate,Arm.read_base_error] using equal
    · intro a outside
      apply False.elim
      apply outside
      right
      refine ⟨trivial,?_⟩
      intro initialized
      have impossible := initialized.2
      change false = true at impossible
      cases impossible
    · simpa only [otherWorld,Arm.w] using registers.2.2
  refine ⟨⟨memory kind,?_,?_⟩,⟨?_,?_,?_⟩,same⟩
  · simp [spv,Arm.r,Arm.read_base_gpr,Arm.read_store,world,baseWorld,Arm.write_base_gpr,Arm.write_store,Arm.ArmState.default]
  · simp only [Arm.r,Arm.read_base_error,world,Arm.write_base_gpr,baseWorld,Arm.ArmState.default]
  · refine ⟨⟨?_,(memory_base kind).1.valid,rfl⟩,?_,outRel_zero _ _ _⟩
    · intro a b valid byte
      change (none : Option (BitVec 8)) = some b at byte
      cases byte
    · intro id b present; cases present
  · simp [spv,Arm.r,Arm.read_base_gpr,Arm.read_store,otherWorld,world,baseWorld,Arm.write_base_gpr,Arm.write_store,Arm.ArmState.default]
  · simp only [Arm.r,Arm.read_base_error,otherWorld,world,Arm.write_base_gpr,baseWorld,Arm.ArmState.default]

/-- Two distinct original ABI-entry worlds execute the actual complete Stock
store/return function from PC0, initializing previously unknown bytes from distinct initial memories, while sharing one
virtual file throughout. -/
theorem complete_paired_uninitialized_store_function_witness (kind : Kind) :
    Arm.read_mem 4096 world ≠ Arm.read_mem 4096 otherWorld ∧
    Arm.r (.GPR 10#5) otherWorld ≠ Arm.r (.GPR 10#5) world ∧
    (afterHeap kind).bytes 4096 = some 37 ∧ heap.bytes 4096 = none ∧
    ∃ (result : Result) (ρ : Nat → CV),Stock.lower (function kind) = .ok result ∧
      Clif.enterFunc (function kind) [⟨.i64,4096⟩,value kind] heap = .ok (initial kind,heap) ∧
      RunOkABI (function kind) result.code (pairSem (csem relation.F ⟨0,0⟩ noExternal))
        (MRP relation (function kind) 0 (fun _ => True)) (initial kind).slots ⟨0,0,ρ,(world,otherWorld)⟩
        (.returned [] (afterHeap kind)) := by
  refine ⟨by decide +kernel,by decide +kernel,(by cases kind <;> rfl),rfl,?_⟩
  obtain ⟨input⟩ := record_input kind
  let result := input.result
  have run : Stock.lower (function kind) = .ok result := input.run
  have entered : Clif.enterFunc (function kind) [⟨.i64,4096⟩,value kind] heap = .ok (initial kind,heap) := by cases kind <;> rfl
  have registerOnly : ∀ loc ∈ locsOf (function kind).sig,∃ pin,loc = .reg pin := by
    intro loc member
    rw [locations] at member
    simp only [List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl <;> exact ⟨_,rfl⟩
  have otherArguments : ArgsAtEntry relation.F (function kind).sig [⟨.i64,4096⟩,value kind] otherWorld := by
    intro loc val member
    rw [locations] at member
    simp only [List.zip_cons_cons,List.zip_nil_right,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with equal | equal <;> cases equal
    all_goals cases kind <;> simp only [VHolds,regVal,otherWorld,world,Arm.r,Arm.read_base_gpr,Arm.write_base_gpr,Arm.read_store,Arm.write_store,rnum] <;> rfl
  have registers : ∀ (pin : Reg) (v : Clif.Val),(.reg pin,v) ∈
      (locsOf (function kind).sig).zip [⟨.i64,4096⟩,value kind] → regVal otherWorld pin = regVal world pin := by
    intro pin v member
    rw [locations] at member
    simp only [List.zip_cons_cons,List.zip_nil_right,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with equal | equal <;> cases equal <;> simp [regVal,otherWorld,world,Arm.r,Arm.read_base_gpr,Arm.write_base_gpr,Arm.read_store,Arm.write_store,rnum]
  obtain ⟨ρ,finished⟩ := StockMemory.StoreRoots.single_store_return_paired_function kind kind.sourceTy run (scope kind) (dominated kind)
    (by cases kind <;> rfl)
    (b := (function kind).blocks[0]!) rfl rfl rfl (by simp [function])
    (valueTy := kind.sourceTy) (by simp [function])
    (by cases kind <;> intro h <;> first | rfl | cases h) (SourceEntry.of_enterFunc entered)
    (show Clif.runLoop Clif.Env.empty {funcs := []} 2 ⟨initial kind,[],heap⟩ =
      .returned [] (afterHeap kind) from by cases kind <;> rfl) registerOnly
    (Γ := relation) (c := 0) (D := fun _ => True) (fc := ⟨0,0⟩) (X := noExternal)
    rfl (fun _ _ h => by cases h) (by intro Z n w w' subset same; rfl)
    (pairedMemory kind) (arguments kind) otherArguments registers
  exact ⟨result,ρ,run,entered,finished⟩

end E2E.StockMemoryStoreUninitializedWitness
#print axioms Backend.Stock.Proof.stock_lower_store_emitted
#print axioms Backend.Stock.Memory.StoreRoots.stock_lower_source_parameter_type
#print axioms Backend.Stock.Memory.StoreRoots.stock_single_store_return_spec
#print axioms Backend.Stock.Memory.StoreRoots.stock_lower_integer_store_scan_fall_refines
#print axioms Backend.Stock.Memory.StoreRoots.stock_lower_integer_store_paired_source_step
#print axioms Backend.Stock.Memory.StoreRoots.stock_single_store_return_body
#print axioms E2E.StockMemory.StoreRoots.stock_lower_integer_store_paired_scan
#print axioms E2E.StockMemory.StoreRoots.stock_single_store_return_paired_body
#print axioms E2E.StockMemory.StoreRoots.single_store_return_paired_function_seeded
#print axioms E2E.StockMemory.StoreRoots.single_store_return_paired_function
#print axioms E2E.StockMemoryStoreFunctionWitness.complete_paired_integer_store_function_witness
#print axioms Backend.Stock.Memory.StoreRoots.domain_of_single_store_return
#print axioms Backend.Stock.Memory.StoreRoots.SingleClass.domain
#print axioms E2E.StockMemoryStoreFunctionWitness.source_class_witness
#print axioms Backend.Stock.Memory.Store.effectsOnly_of_previous
#print axioms E2E.StockMemory.StoreRoots.effectsOnly_instruction
#print axioms E2E.StockMemory.StoreRoots.return_value
#print axioms E2E.StockMemory.StoreRoots.machine_return
#print axioms E2E.backend_correct_world_niX_stock_store_memory
#print axioms Backend.Stock.MemoryStore.sourceOk_sound
#print axioms Backend.Stock.MemoryStore.check_sound
#print axioms Backend.Stock.MemoryStore.previous_file_exact
#print axioms Backend.Stock.MemoryStore.previous_file_exact_witness
#print axioms Backend.Stock.MemoryStore.previous_routes_exact
#print axioms Backend.Stock.MemoryStore.previous_lower_exact
#print axioms E2E.StockMemoryStoreFunctionWitness.source_selector_witness

#print axioms E2E.StockMemoryStoreUninitializedWitness.complete_paired_uninitialized_store_function_witness
