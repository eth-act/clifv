# Reuse the completed official comparison only after exact source/harness/inventory validation.
import runpy
runpy.run_path('/home/lee/clifv/.git/agent-evidence/stock-memory-20261029/adopt-integer-extending-ci-official-v3.py',run_name='__main__')
