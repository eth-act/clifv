Connect all seven integer-store forms to actual retained Stock records and original source steps. The proofs derive root selection, sunk-value exclusion, demand guards, empty-result binding and resolved store execution internally. Original input conditions and previous theorem interfaces remain intact.

Derive operand availability from the actual source and demand state. Support guarded stores through the store projection of the existing memory contract. Complete source-built witnesses cover actual records, and the guarded witness changes memory while preserving every virtual register. Narrow stores retain arbitrary original declared types in the general contracts.

Validation: all thirteen actual module paths passed their combined kernel check on current main08281d75. All29 audit roots use standard axioms. All seven previous store axiom sets remain exact. The full FV/FVTest per-PR build follows publication; its result will be recorded before landing. No compiler behavior changes. Whole-function composition, store activation and the full original#140 remain incomplete.

Landing uses the user's test route. The alternative is ONE QUICK, DIRTY, CHEAP direct peer review. No review agents or human review gate apply.
