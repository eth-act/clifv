from pathlib import Path
import subprocess,psutil,os,json,time,datetime,hashlib,re
b=Path('/home/lee/clifv');e=b/'.git/agent-evidence/stock-memory-20261029';r=b/'.worktrees/stock-extending-production-20261031';d=e/'integer-store-domain-draft-v1';state=e/'integer-store-domain-check-v1.json';paused=None;records=[]
files=list((d/'FV/E2E').glob('*.lean'));hashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
def save(status,**x):state.write_text(json.dumps(dict(status=status,records=records,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_hashes=hashes,**x),indent=2)+'\n')
def live(p):
 try:return p.is_running() and p.status()!=psutil.STATUS_ZOMBIE
 except psutil.NoSuchProcess:return False
try:
 schedulers=[]
 for c in psutil.Process(324861).children(recursive=True):
  try:
   if c.name().startswith('python') and any(a=='scripts/lake-serial-build.py' for a in c.cmdline()):schedulers.append(c)
  except psutil.NoSuchProcess:pass
 assert len(schedulers)==1,'Inspect active current PR-gate phase before resource handoff'
 paused=schedulers[0];paused.suspend()
 while True:
  children=[c for c in paused.children() if live(c)];caps=[]
  for c in children:
   raw=c.environ().get('FV_MEMCAP','');caps.append(float(raw[:-1]) if raw.endswith('G') else float(raw[:-1])/1024 if raw.endswith('M') else 1000)
  if len(children)<=1 and sum(caps)<=12:break
  save('waiting',phase='active-current-PR-source',caps_GiB=caps);time.sleep(3)
 env=dict(os.environ);env.update(json.loads((e/'author-env-v1.json').read_text()));env.update(FV_ROOT=str(r),FV_MEMCAP='4G',OMP_NUM_THREADS='1',OMP_THREAD_LIMIT='1',LEAN_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
 for p in files:
  assert all(hashlib.sha256(Path(n).read_bytes()).hexdigest()==h for n,h in hashes.items())
  save('running',phase=p.stem)
  env['FV_MEMCAP_STATS']=str(e/('integer-store-next-'+p.stem+'-v11.stats'))
  with (e/('integer-store-next-'+p.stem+'-v11.log')).open('w') as out:run=subprocess.run(['nice','-n','10',str(r/'scripts/memcap.sh'),'lake','env','lean','-j1','--root='+str(d),str(p)],cwd=r,env=env,stdout=out,stderr=subprocess.STDOUT)
  records.append(dict(module=p.stem,returncode=run.returncode));assert run.returncode==0,records
  log=(e/('integer-store-next-'+p.stem+'-v11.log')).read_text();matches=re.findall(r'depends on axioms: \[([^]]*)\]',log,re.S);assert len(matches)==14 and all(set(x.strip() for x in match.split(','))<={'propext','Classical.choice','Quot.sound'} for match in matches),log
 save('passed',scope='Fourteen draft roots: complete single/paired function domains and positive witnesses. Current PR source remains unchanged.')
except BaseException as error:save('failed',error=repr(error));raise
finally:
 if paused is not None and live(paused):paused.resume()
