from pathlib import Path
import json,datetime,time,subprocess,psutil,hashlib,os
b=Path('/home/lee/clifv');e=b/'.git/agent-evidence/stock-memory-20261029';state=e/'integer-store-packet-delivery-state-v1.json'
def save(status,**extra):state.write_text(json.dumps(dict(status=status,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),full_goal_complete=False,**extra),indent=2)+'\n')
def git(*args,env=None):return subprocess.check_output(['git',*args],cwd=b,env=env,text=True).strip()
def live(pid):
 try:p=psutil.Process(pid);return p.is_running() and p.status()!=psutil.STATUS_ZOMBIE
 except psutil.NoSuchProcess:return False
try:
 for pid,label in [(4635,'store-kernel-gate'),(4083,'extending-production-delivery')]:
  while live(pid):save('waiting',phase=label,dependency_pid=pid);time.sleep(3)
  receipt=json.loads((e/('integer-store-packet-state-v4.json' if pid==4635 else 'integer-extending-production-landing-state-v1.json')).read_text())
  assert receipt['status']=='passed',receipt
 proof=json.loads((e/'integer-store-packet-state-v4.json').read_text());assert proof['audit_roots']==7 and proof['all_axioms_standard']
 landed=json.loads((e/'integer-extending-production-landing-state-v1.json').read_text());base=landed['merge']
 subprocess.run(['git','fetch','origin','main'],cwd=b,check=True)
 assert git('rev-parse','origin/main')==base,'Inspect new main drift before publishing'
 assert git('rev-parse',base+'^{tree}')==git('rev-parse','0db8235d^{tree}')
 packet=json.loads((e/'integer-store-packet-source-v1.json').read_text());root=Path(packet['root'])
 assert all(hashlib.sha256((root/n).read_bytes()).hexdigest()==h for n,h in packet['files'].items())
 assert proof['source_hashes']==packet['files']
 assert all(not git('ls-tree',base,'--',n) for n in packet['files'])
 index=e/'integer-store-packet-publish-v1.index';index.unlink(missing_ok=True);env=dict(os.environ,GIT_INDEX_FILE=str(index));git('read-tree',base,env=env)
 for name in packet['files']:git('update-index','--add','--cacheinfo','100644,'+git('hash-object','-w',str(root/name))+','+name,env=env)
 commit=git('commit-tree',git('write-tree',env=env),'-p',base,'-m','Prove Stock integer-store roots and original-source writes')
 branch='agent/stock-integer-store-roots-20261031';assert not git('branch','--list',branch)
 git('update-ref','refs/heads/'+branch,commit);subprocess.run(['git','push','origin',branch],cwd=b,check=True)
 assert git('ls-remote','origin','refs/heads/'+branch).split()[0]==commit;index.unlink()
 body=e/'integer-store-packet-pr-v1.md';body.write_text('''Prove all seven integer-store RHS templates, including the enclosing side-effect emission and exact demand/state behavior. The source/write bridge supports arbitrary source/register numbering, transports the updated memory relation and preserves every virtual register.

Source-built witnesses cover first-match selection, complete RHS execution and full lowering for all seven roots. The witnesses use nonidentity operand registers192/193. These additions preserve existing theorem interfaces and acceptance conditions. Retained-record binding, paired writes, store production activation and the full original#140 remain incomplete.

Validation: all three actual module paths passed focused kernel checks. All seven public audit roots use only standard axioms. The complete import closure has263 repository modules; none intersects the extending activation paths. The parent tree exactly equals the validated0db8235d production tree. No compiler behavior changes in this packet.

Landing uses the user's test route after current CI checks pass. No human review gate or review agents.
''')
 url=subprocess.check_output(['gh','pr','create','--base','main','--head',branch,'--title','Prove Stock integer-store roots and source writes','--body-file',str(body)],cwd=b,text=True).strip();number=int(url.rsplit('/',1)[1])
 while True:
  pr=json.loads(subprocess.check_output(['gh','pr','view',str(number),'--json','headRefOid,state,mergeable,statusCheckRollup'],cwd=b,text=True));assert pr['headRefOid']==commit and pr['state']=='OPEN',pr
  checks={x['name']:x for x in pr['statusCheckRollup']};required=['Quick checks','Build and compare','Check lost matches','Publish PR result']
  failed=[n for n,x in checks.items() if x.get('status')=='COMPLETED' and x.get('conclusion') not in ['SUCCESS','SKIPPED','NEUTRAL']];assert not failed,(failed,checks)
  if all(n in checks and checks[n]['status']=='COMPLETED' and checks[n]['conclusion']=='SUCCESS' for n in required):break
  save('waiting',phase='pr-ci',pr=number,url=url,commit=commit,base=base);time.sleep(20)
 assert git('ls-remote','origin','refs/heads/main').split()[0]==base,'Inspect main drift before landing'
 save('running',phase='squash-merge',pr=number,url=url,commit=commit)
 subprocess.run(['gh','pr','merge',str(number),'--squash','--match-head-commit',commit],cwd=b,check=True)
 result=json.loads(subprocess.check_output(['gh','pr','view',str(number),'--json','state,mergeCommit'],cwd=b,text=True));assert result['state']=='MERGED'
 merged=result['mergeCommit']['oid'];subprocess.run(['git','fetch','origin','main'],cwd=b,check=True);assert git('rev-parse',merged+'^{tree}')==git('rev-parse',commit+'^{tree}')
 save('passed',pr=number,url=url,commit=commit,merge=merged,validated_tree_exact=True,audit_roots=7,route='Focused kernel/audit gates and all current CI checks passed. No review agents.',remaining='Retained stores,source transfer,paired writes,complete function correctness and production activation; all other original140 obligations remain active.')
 print(json.dumps(dict(pr=number,merge=merged,validated_tree_exact=True,full_goal_complete=False)))
except BaseException as error:save('failed',error=repr(error));raise
