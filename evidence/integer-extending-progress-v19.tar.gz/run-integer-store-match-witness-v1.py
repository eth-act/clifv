from pathlib import Path
import os,subprocess,json,hashlib,datetime,time,re,psutil
b=Path('/home/lee/clifv');e=b/'.git/agent-evidence/stock-memory-20261029';r=b/'.worktrees/stock-extending-production-20261031';state=e/'integer-store-match-witness-state-v1.json';paused=None;records=[]
files=['StoreMemoryMatchWitnessDraftV1.lean','StoreMemoryMatchWitnessDraftV1Audit.lean'];hashes={n:hashlib.sha256((e/n).read_bytes()).hexdigest() for n in files}
env=dict(os.environ);env.update(json.loads((e/'author-env-v1.json').read_text()));env.update(FV_ROOT=str(r),FV_MEMCAP='4G',OMP_NUM_THREADS='1',OMP_THREAD_LIMIT='1',LEAN_NUM_THREADS='1',CARGO_BUILD_JOBS='1',PYTHONDONTWRITEBYTECODE='1')
for k in ['FV_PIPELINE_T','BLESS']:env.pop(k,None)
def save(status,**x):state.write_text(json.dumps(dict(status=status,records=records,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_hashes=hashes,**x),indent=2)+'\n')
def live(p):
 try:return p.is_running() and p.status()!=psutil.STATUS_ZOMBIE
 except psutil.NoSuchProcess:return False
def run(label,args):
 assert all(hashlib.sha256((e/n).read_bytes()).hexdigest()==h for n,h in hashes.items())
 save('running',phase=label,controller_paused=paused.pid)
 env['FV_MEMCAP_STATS']=str(e/('integer-store-match-witness-'+label+'-v1.stats'))
 with (e/('integer-store-match-witness-'+label+'-v1.log')).open('w') as out:result=subprocess.run(['nice','-n','10',str(r/'scripts/memcap.sh'),*map(str,args)],cwd=r,env=env,stdout=out,stderr=subprocess.STDOUT)
 records.append(dict(label=label,returncode=result.returncode));assert result.returncode==0,(label,result.returncode)
try:
 assert json.loads((e/'integer-store-match-state-v2.json').read_text())['status']=='passed'
 owner=psutil.Process(4016468);children=[c for c in owner.children() if live(c)];assert len(children)==1;paused=children[0];paused.suspend()
 gate=json.loads((e/'integer-extending-production-gates-state-v3.json').read_text());phase=gate.get('phase','')
 assert gate['status']=='running' and (phase.startswith(('prior-','retained-','consumers-')) or phase in ['official','captures','preservation','production-audit']),gate
 old=psutil.Process(3167211);assert old.status()==psutil.STATUS_STOPPED and not any(live(c) for c in old.children(recursive=True))
 assert len([c for c in paused.children(recursive=True) if live(c) and c.name()=='lean'])<=1
 source=json.loads((e/'integer-extending-production-source-v3.json').read_text());assert all(hashlib.sha256((r/n).read_bytes()).hexdigest()==h for n,h in source['files'].items())
 env['LEAN_PATH']=str(e)+':'+str(e/'integer-store-packet-v1')+':'+subprocess.check_output(['lake','env','printenv','LEAN_PATH'],cwd=r,env=env,text=True).strip()
 run('proof',['lean','-j1','--root='+str(e),'-o',e/'StoreMemoryMatchWitnessDraftV1.olean',e/'StoreMemoryMatchWitnessDraftV1.lean'])
 run('audit',['lean','-j1','--root='+str(e),e/'StoreMemoryMatchWitnessDraftV1Audit.lean'])
 text=(e/'integer-store-match-witness-audit-v1.log').read_text();axioms={n:set(x.strip() for x in a.split(',')) for n,a in re.findall(r"'([^']+)' depends on axioms: \[([^]]*)\]",text,re.S)}
 axioms.update({n:set() for n in re.findall(r"'([^']+)' does not depend on any axioms",text)})
 assert len(axioms)==1 and all(a<={'propext','Classical.choice','Quot.sound'} for a in axioms.values())
 save('passed',audit_roots=1,all_axioms_standard=True,scope='Source-built nonidentity contexts inhabit all seven store match contracts and source metadata. Selected-root derivation,retained-record binding and production integration remain incomplete.')
except BaseException as error:save('failed',error=repr(error));raise
finally:
 if paused is not None and live(paused):paused.resume()
