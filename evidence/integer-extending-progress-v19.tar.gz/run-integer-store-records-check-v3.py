from pathlib import Path
import os,subprocess,json,hashlib,datetime,time,re,psutil,sys
b=Path('/home/lee/clifv');e=b/'.git/agent-evidence/stock-memory-20261029';r=b/'.worktrees/stock-extending-production-20261031';tag=sys.argv[1];modules=sys.argv[2:];focus_cap=os.environ.get('FV_STORE_CHECK_CAP','4G');focus_G=float(focus_cap.removesuffix('G'));assert 0<focus_G<=12;state=e/(tag+'-state.json');paused=None;records=[]
files=['FV/Backend/Proof/'+n+'.lean' for n in ['StockMemoryStoreMatch','StockMemoryStorePaired','StockMemoryStoreMatchWitness','StockMemoryStoreDispatch']]+['scripts/audit/stock-memory-store-records.lean'];hashes={n:hashlib.sha256((r/n).read_bytes()).hexdigest() for n in files};base='3a4d6539e9c5e5342f082ca8c65c7a5518309ce0'
env=dict(os.environ);env.update(json.loads((e/'author-env-v1.json').read_text()));env.update(FV_ROOT=str(r),FV_MEMCAP=focus_cap,OMP_NUM_THREADS='1',OMP_THREAD_LIMIT='1',LEAN_NUM_THREADS='1',CARGO_BUILD_JOBS='1',PYTHONDONTWRITEBYTECODE='1')
for k in ['FV_PIPELINE_T','BLESS']:env.pop(k,None)
def save(status,**x):state.write_text(json.dumps(dict(status=status,records=records,base=base,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_hashes=hashes,**x),indent=2)+'\n')
def live(p):
 try:return p.is_running() and p.status()!=psutil.STATUS_ZOMBIE
 except psutil.NoSuchProcess:return False
def frozen():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==base
 assert subprocess.run(['git','diff','--quiet'],cwd=r).returncode==0
 assert all(hashlib.sha256((r/n).read_bytes()).hexdigest()==h for n,h in hashes.items())
def run(label,args):
 frozen();save('running',phase=label,scheduler_paused=paused.pid)
 env['FV_MEMCAP_STATS']=str(e/(tag+'-'+label+'.stats'))
 with (e/(tag+'-'+label+'.log')).open('w') as out:done=subprocess.run(['nice','-n','10',str(r/'scripts/memcap.sh'),*map(str,args)],cwd=r,env=env,stdout=out,stderr=subprocess.STDOUT)
 records.append(dict(label=label,returncode=done.returncode));assert done.returncode==0,(label,done.returncode)
def axioms(file):
 text=file.read_text();a={n:set(x.strip() for x in s.split(',')) for n,s in re.findall(r"'([^']+)' depends on axioms: \[([^]]*)\]",text,re.S)}
 a.update({n:set() for n in re.findall(r"'([^']+)' does not depend on any axioms",text)});return a
try:
 frozen();normal=psutil.Process(3167178);sched=[]
 for c in normal.children(recursive=True):
  try:
   if c.name().startswith('python') and any(a.endswith('/lake-serial-build.py') or a=='scripts/lake-serial-build.py' for a in c.cmdline()):sched.append(c)
  except psutil.NoSuchProcess:pass
 assert len(sched)==1,'No normal source scheduler reservation; inspect actual active phase first'
 paused=sched[0];paused.suspend()
 while True:
  children=[c for c in paused.children() if live(c)];caps=[]
  for c in children:
   raw=c.environ().get('FV_MEMCAP','');caps.append(float(raw[:-1]) if raw.endswith('G') else float(raw[:-1])/1024 if raw.endswith('M') else 1000)
  if len(children)<=1 and sum(caps)<=16-focus_G:break
  save('waiting',phase='finish-active-normal-source',active_caps_GiB=caps);time.sleep(3)
 for name in modules:
  source=r/'FV/Backend/Proof'/(name+'.lean');out=r/'.lake/build/lib/lean/FV/Backend/Proof'/(name+'.olean')
  run(name,['lake','env','lean','-j1','--root='+str(r),'-o',out,source])
 run('audit',['lake','env','lean','-j1','scripts/audit/stock-memory-store-records.lean'])
 now=axioms(e/(tag+'-audit.log'));old=axioms(e/'integer-store-packet-audit-v4.log')
 assert len(now)==13 and all(a<={'propext','Classical.choice','Quot.sound'} for a in now.values()),now
 assert all(now[n]==a for n,a in old.items()),'Existing store axiom set changed'
 frozen();save('passed',audit_roots=13,prior_store_axiom_sets_exact=7,all_axioms_standard=True,scope='Actual module-path store match/metadata/source-witness,paired writes and in-progress dispatch. Retained binding,source composition and production activation remain incomplete.')
except BaseException as error:save('failed',error=repr(error));raise
finally:
 if paused is not None and live(paused):paused.resume()
