from pathlib import Path
import os, subprocess, json, datetime, hashlib, time, sys, re
import psutil

b=Path('/home/lee/clifv');r=b/'.worktrees/stock-extending-production-20261031'
e=b/'.git/agent-evidence/stock-memory-20261029'
state=e/'integer-extending-production-post-state-v3.json';records=[]
env=dict(os.environ);env.update(json.loads((e/'author-env-v1.json').read_text()))
env.update(FV_ROOT=str(r),FV_MEMCAP='4G',OMP_NUM_THREADS='1',OMP_THREAD_LIMIT='1',
           LEAN_NUM_THREADS='1',CARGO_BUILD_JOBS='1')
env.pop('FV_PIPELINE_T',None);env.pop('BLESS',None)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def save(status,**extra):
    state.write_text(json.dumps(dict(status=status,records=records,
        utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),**extra),indent=2)+'\n')

def run(label,args,extra=None):
    save('running',phase=label)
    with(e/('integer-extending-production-post-'+label+'-v2.log')).open('w') as log:
        done=subprocess.run(['nice','-n','10',str(r/'scripts/memcap.sh'),*map(str,args)],
            cwd=r,env=dict(env,**(extra or {})),stdout=log,stderr=subprocess.STDOUT)
    records.append(dict(label=label,returncode=done.returncode))
    assert done.returncode==0,(label,done.returncode)

try:
    official=json.loads((e/'integer-extending-production-official-state-v3.json').read_text())
    assert official['status']=='passed',official
    sources=json.loads((e/'memory-captured-inventory-current/receipt.json').read_text())['sources']
    assert len(sources)==4543 and all(sha(p)==h for p,h in sources.items())
    previous=json.loads((e/'captured-real-inputs-state-v5.json').read_text())
    reference=json.loads((e/'captured-object-reference-v1/receipt.json').read_text())
    expected={(x['function'],x['cleanup']):x for x in reference['rows']}
    assert len(previous['records'])==len(expected)==8
    out=e/'integer-extending-production-original-captures-v3';out.mkdir(exist_ok=False)
    sys.path.insert(0,str(r/'scripts'))
    from byte_compare import ELF
    from stock_common import comparison
    compared=[]
    for index,row in enumerate(previous['records']):
        source=Path(row['path']);assert sha(source)==row['source_sha256']
        label=str(index);obj=out/(label+'.o');allocation=out/(label+'.allocation.json')
        cleanup=[] if row['cleanup'] else ['--no-dead-cleanup']
        run('capture-'+label,[r/'.lake/build/bin/lean-backend',source,obj,
            '--regalloc','regalloc2',*cleanup],dict(LEAN_REGALLOC_KEEP=str(allocation)))
        trace=out/(label+'.trace.json')
        run('trace-'+label,[r/'.lake/build/bin/lean-backend-lowering-trace',source,trace,
            '--stock-schedule',*cleanup])
        actual=json.loads(allocation.read_text())['functions']
        reported=json.loads(trace.read_text())['functions']
        assert len(actual)==len(reported)==1 and reported[0]['status']=='lowered'
        lowered=reported[0]['lowering'];assert lowered['allocator_input']==actual[0]
        if not row['cleanup']:
            assert lowered['allocation_selected']==lowered['stock_schedule']['selected']
        elf=ELF(obj);symbol,code=elf.function(row['function'])
        relocs=elf.function_relocations(symbol,{})
        prior=expected[(row['function'],row['cleanup'])]
        result=comparison(bytes.fromhex(prior['stock_bytes']),code,prior['stock_metadata']['relocations'],relocs)
        assert result['exact_code_and_relocations'],result
        compared.append(dict(function=row['function'],cleanup=row['cleanup'],
            original_sha256=sha(source),object_sha256=sha(obj),comparison=result,
            actual_allocator_matches_provider=True))
    assert all(sha(p)==h for p,h in sources.items())
    (e/'integer-extending-production-original-captures-receipt-v3.json').write_text(json.dumps(dict(
        status='passed',source_hashes_exact=4543,cases=8,rows=compared,
        scope='Original default-provider function bytes and relocations. No original settings-contract claim.'),indent=2)+'\n')
    save('passed',original_source_hashes_exact=4543,original_objects_exact=8,full_goal_complete=False)
except BaseException as error:
    save('failed',error=repr(error));raise
