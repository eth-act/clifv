from pathlib import Path
import os, subprocess, json, time, datetime, hashlib, sys, importlib.util
import psutil

b=Path('/home/lee/clifv')
r=b/'.worktrees/stock-extending-production-20261031'
e=b/'.git/agent-evidence/stock-memory-20261029'
state=e/'integer-extending-production-official-state-v3.json'
out=e/'integer-extending-production-official-vectors-v3'
packet=json.loads((e/'integer-extending-production-source-v3.json').read_text())
env=dict(os.environ)
env.update(json.loads((e/'author-env-v1.json').read_text()))
env.update(FV_ROOT=str(r),FV_MEMCAP='12G',FV_COMPARE_MEMCAP='1',
    OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',CARGO_BUILD_JOBS='1',
    LEAN_BIN_DIR='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin',PYTHONDONTWRITEBYTECODE='1')
for key in ['FV_PIPELINE_T','BLESS']:
    env.pop(key,None)

def save(status,**extra):
    state.write_text(json.dumps(dict(status=status,
        utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),**extra),indent=2)+'\n')

def fingerprint():
    return {n:hashlib.sha256((r/n).read_bytes()).hexdigest() for n in packet['files']}

def identities(report):
    return {(c['test'],v['index'],row['index'],row['name']):row['status']
        for c in report['tests'] for v in c['variants'] for row in v['functions_compared']}

try:
    assert fingerprint()==packet['files'],'Packet changed after integration gates'
    old=json.loads((e/'integer-production-official-vectors-v2/results.json').read_text())
    suite=r/'third_party/wasmtime/cranelift/filetests/filetests'
    for row in old['inventory']:
        assert hashlib.sha256((suite/row['test']).read_bytes()).hexdigest()==row['sha256']
    save('running',phase='original-official-comparison')
    with (e/'integer-extending-production-official-command-v3.log').open('w') as log:
        done=subprocess.run(['nice','-n','10',str(r/'scripts/memcap.sh'),'bash',
            'scripts/stock-compiler-comparison.sh','--out',str(out),'--jobs','1'],
            cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
    assert done.returncode in (0,10),done.returncode
    sys.path.insert(0,str(r/'scripts'))
    spec=importlib.util.spec_from_file_location('ci',r/'scripts/stock-comparison-ci.py')
    ci=importlib.util.module_from_spec(spec);spec.loader.exec_module(ci)
    report=json.loads((out/'results.json').read_text())
    totals=ci.validate_report(report)
    previous={tuple(x) for x in ci.matched_entries(old)}
    current={tuple(x) for x in ci.matched_entries(report)}
    assert not previous-current,('Lost matches',sorted(previous-current))
    assert report['inventory']==old['inventory'],'Original source inventory changed'
    before=identities(old);after=identities(report)
    assert before.keys()==after.keys(),'Original stage identities changed'
    changed=[dict(identity=k,old=before[k],new=after[k]) for k in before if before[k]!=after[k]]
    allowed={'identical_code_artifact':{'identical_code_artifact'},
        'different_code_artifact':{'different_code_artifact','identical_code_artifact'},
        'unsupported_configuration':{'unsupported_configuration'},
        'expected_stock_rejection_no_binary':{'expected_stock_rejection_no_binary'},
        'lean_unsupported':{'lean_unsupported','different_code_artifact','identical_code_artifact'}}
    assert all(after[k] in allowed[v] for k,v in before.items()), 'Original acceptance or rejection stage regressed'
    assert report['totals']['source_files_modified']==0
    assert fingerprint()==packet['files'],'Packet changed during comparison'
    save('passed',returncode=done.returncode,totals=totals,
        gained=sorted(current-previous),lost=[],identity_status_changes=changed,
        original_hashes_exact=len(report['inventory']),stage_identities_exact=len(before),
        source_unchanged=True,full_goal_complete=False)
except BaseException as error:
    save('failed',error=repr(error))
    raise
