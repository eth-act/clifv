from pathlib import Path
import json,os,subprocess,datetime,time,hashlib,re,psutil
b=Path('/home/lee/clifv');e=b/'.git/agent-evidence/stock-memory-20261029';r=b/'.worktrees/stock-cfg-source-20261025'
state=e/'integer-store-source-witness-state-v3.json';records=[];paused=None
files=['StoreMemorySourceDraftV1.lean','StoreMemorySourceDraftV1Audit.lean','StoreMemoryProofDraftV2.lean','StoreMemoryWitnessDraftV1.lean','StoreMemoryWitnessDraftV1Audit.lean'];hashes={n:hashlib.sha256((e/n).read_bytes()).hexdigest() for n in files}
env=dict(os.environ);env.update(json.loads((e/'author-env-v1.json').read_text()));env.update(FV_ROOT=str(r),FV_MEMCAP='8G',OMP_NUM_THREADS='1',OMP_THREAD_LIMIT='1',LEAN_NUM_THREADS='1',CARGO_BUILD_JOBS='1',PYTHONDONTWRITEBYTECODE='1')
for k in ['FV_PIPELINE_T','BLESS']:env.pop(k,None)
def save(status,**extra):state.write_text(json.dumps(dict(status=status,records=records,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_hashes=hashes,**extra),indent=2)+'\n')
def live(p):
 try:return p.is_running() and p.status()!=psutil.STATUS_ZOMBIE
 except psutil.NoSuchProcess:return False
def run(label,args):
 assert hashes=={n:hashlib.sha256((e/n).read_bytes()).hexdigest() for n in files}
 save('running',phase=label,scheduler_paused=paused.pid)
 env['FV_MEMCAP_STATS']=str(e/('integer-store-'+label+'-v3.stats'))
 with (e/('integer-store-'+label+'-v3.log')).open('w') as log:
  done=subprocess.run(['nice','-n','10',str(r/'scripts/memcap.sh'),*map(str,args)],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 records.append(dict(label=label,returncode=done.returncode));assert done.returncode==0,(label,done.returncode)
try:
 prior=json.loads((e/'integer-store-source-witness-state-v2.json').read_text())
 assert prior['records'][:2]==[dict(label='StoreMemorySourceDraftV1',returncode=0),dict(label='StoreMemorySourceDraftV1Audit',returncode=0)]
 assert prior['source_hashes']==hashes
 records.extend(dict(x,reused_from='integer-store-source-witness-state-v2.json') for x in prior['records'][:2])
 owner=psutil.Process(4016468)
 sched=[]
 for child in owner.children(recursive=True):
  try:
   if child.name().startswith('python') and any(a.endswith('/lake-serial-build.py') or a=='scripts/lake-serial-build.py' for a in child.cmdline()):sched.append(child)
  except psutil.NoSuchProcess:pass
 assert len(sched)==1,'No unique active combined scheduler; do not compete with other phases'
 paused=sched[0];paused.suspend()
 assert psutil.Process(3167211).status()==psutil.STATUS_STOPPED
 assert not any(live(c) for c in psutil.Process(3167211).children(recursive=True))
 while True:
  children=[c for c in paused.children() if live(c)];caps=[]
  for c in children:
   raw=c.environ().get('FV_MEMCAP','');caps.append(float(raw[:-1]) if raw.endswith('G') else float(raw[:-1])/1024 if raw.endswith('M') else 1000)
  if len(children)<=1 and sum(caps)<=8:break
  save('waiting',phase='finish-active-candidate-module',active_caps_GiB=caps);time.sleep(3)
 save('running',phase='bounded-candidate-resource-handoff',candidate_caps_GiB=caps,focused_cap_GiB=8,max_source_jobs=2,aggregate_cap_GiB=16)
 old=json.loads((e/'integer-production-source-v2.json').read_text())
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==old['head']
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=r,text=True).strip()
 env['LEAN_PATH']=str(e)+':'+subprocess.check_output(['lake','env','printenv','LEAN_PATH'],cwd=r,env=env,text=True).strip()
 for name,audit,count in [('StoreMemoryWitnessDraftV1','StoreMemoryWitnessDraftV1Audit',3)]:
  run(name,['lean','-j1','--root='+str(e),'-o',e/(name+'.olean'),e/(name+'.lean')])
  run(audit,['lean','-j1','--root='+str(e),e/(audit+'.lean')])
  text=(e/('integer-store-'+audit+'-v3.log')).read_text()
  axioms={n:set(x.strip() for x in a.split(',')) for n,a in re.findall(r"'([^']+)' depends on axioms: \[([^]]*)\]",text,re.S)}
  axioms.update({n:set() for n in re.findall(r"'([^']+)' does not depend on any axioms",text)})
  assert len(axioms)==count and all(a<={'propext','Classical.choice','Quot.sound'} for a in axioms.values()),axioms
 save('passed',audit_roots=5,all_axioms_standard=True,scope='Source/machine store-write and unchanged-register bridge, seven first-match/RHS/full-lowering witnesses. Retained-record binding, paired writes and production activation remain incomplete.')
except BaseException as error:save('failed',error=repr(error));raise
finally:
 if paused is not None and live(paused):paused.resume()
