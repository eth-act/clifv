from pathlib import Path
import subprocess,json,datetime,time
b=Path('/home/lee/clifv');e=b/'.git/agent-evidence/stock-memory-20261029';r=b/'.worktrees/stock-extending-production-20261031';state=e/'integer-store-records-landing-v1.json'
def save(status,**x):state.write_text(json.dumps(dict(status=status,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),full_goal_complete=False,**x),indent=2)+'\n')
def cmd(args):return subprocess.check_output(args,cwd=r,text=True).strip()
try:
 while True:
  p=e/'integer-store-records-pr-gates-v1.json'
  if p.exists():
   gates=json.loads(p.read_text())
   if gates['status']=='passed':break
   assert gates['status']!='failed',gates
  save('waiting',phase='per-PR-gates');time.sleep(10)
 pr=gates['publication'];commit=pr['commit'];number=str(pr['pr'])
 assert cmd(['git','ls-remote','origin','refs/heads/main']).split()[0]==pr['base'],'Inspect main drift before landing'
 data=json.loads(cmd(['gh','pr','view',number,'--repo','eth-act/clifv','--json','state,headRefOid,statusCheckRollup']))
 assert data['state']=='OPEN' and data['headRefOid']==commit,data
 failures=[x for x in data['statusCheckRollup'] if x.get('status')=='COMPLETED' and x.get('conclusion') not in ['SUCCESS','SKIPPED','NEUTRAL']]
 assert not failures,failures
 body=e/'integer-store-records-pr-final-v1.md';text=(e/'integer-store-records-pr-v1.md').read_text();text=text.replace('The full FV/FVTest per-PR build follows publication; its result will be recorded before landing.','The complete FV/FVTest per-PR build passed. The final29-root audit passed and retained all seven previous axiom sets exactly.')
 body.write_text(text)
 subprocess.run(['gh','pr','edit',number,'--repo','eth-act/clifv','--body-file',str(body)],cwd=r,check=True)
 save('running',phase='squash-merge',pr=pr['pr'],commit=commit)
 subprocess.run(['gh','pr','merge',number,'--repo','eth-act/clifv','--squash','--match-head-commit',commit],cwd=r,check=True)
 data=json.loads(cmd(['gh','pr','view',number,'--repo','eth-act/clifv','--json','state,mergeCommit']))
 assert data['state']=='MERGED',data
 merged=data['mergeCommit']['oid'];subprocess.run(['git','fetch','origin','main'],cwd=r,check=True)
 assert cmd(['git','rev-parse',merged+'^{tree}'])==cmd(['git','rev-parse',commit+'^{tree}'])
 save('passed',pr=pr['pr'],url=pr['url'],commit=commit,merge=merged,validated_tree_exact=True,audit_roots=29,prior_axiom_sets_exact=7,route='Complete FV/FVTest per-PR build and kernel audits. No review agents. Runtime gates unaffected by proof-only leaf additions.',remaining='Whole-function store composition, production activation and remaining original140 obligations.')
 print(json.dumps(dict(pr=pr['pr'],merge=merged,full_goal_complete=False)))
except BaseException as error:save('failed',error=repr(error));raise
