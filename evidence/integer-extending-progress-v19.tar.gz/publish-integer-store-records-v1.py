from pathlib import Path
import subprocess, json, hashlib, datetime, time, psutil
b=Path('/home/lee/clifv');e=b/'.git/agent-evidence/stock-memory-20261029';r=b/'.worktrees/stock-extending-production-20261031';state=e/'integer-store-records-publication-v1.json'
def git(*args):return subprocess.check_output(['git',*args],cwd=r,text=True).strip()
def save(status,**x):state.write_text(json.dumps(dict(status=status,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),full_goal_complete=False,**x),indent=2)+'\n')
try:
 while True:
  check=json.loads((e/'integer-store-records-combined-v1-state.json').read_text())
  if check['status']=='passed':break
  assert check['status']!='failed',check
  save('waiting',phase='combined-kernel-check');time.sleep(5)
 assert check['audit_roots']==29 and check['prior_store_axiom_sets_exact']==7 and check['all_axioms_standard']
 assert git('rev-parse','HEAD')==check['base'];assert subprocess.run(['git','diff','--quiet'],cwd=r).returncode==0
 for n,h in check['source_hashes'].items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==h
 subprocess.run(['git','add','--',*check['source_hashes']],cwd=r,check=True)
 assert set(git('diff','--cached','--name-only').splitlines())==set(check['source_hashes'])
 subprocess.run(['git','diff','--cached','--check'],cwd=r,check=True)
 subprocess.run(['git','commit','-m','Prove retained Stock stores and guarded source steps'],cwd=r,check=True)
 commit=git('rev-parse','HEAD');branch=git('branch','--show-current')
 save('running',phase='push',commit=commit,branch=branch,base=check['base'])
 subprocess.run(['git','push','-u','origin',branch],cwd=r,check=True)
 assert git('ls-remote','origin','refs/heads/'+branch).split()[0]==commit
 body=e/'integer-store-records-pr-v1.md';body.write_text('''Connect all seven integer-store forms to actual retained Stock records and original source steps. The proofs derive root selection, sunk-value exclusion, demand guards, empty-result binding and resolved store execution internally. Original input conditions and previous theorem interfaces remain intact.

Derive operand availability from the actual source and demand state. Support guarded stores through the store projection of the existing memory contract. Complete source-built witnesses cover actual records, and the guarded witness changes memory while preserving every virtual register. Narrow stores retain arbitrary original declared types in the general contracts.

Validation: all thirteen actual module paths passed their combined kernel check on current main08281d75. All29 audit roots use standard axioms. All seven previous store axiom sets remain exact. The full FV/FVTest per-PR build follows publication; its result will be recorded before landing. No compiler behavior changes. Whole-function composition, store activation and the full original#140 remain incomplete.

Landing uses the user's test route. The alternative is ONE QUICK, DIRTY, CHEAP direct peer review. No review agents or human review gate apply.
''')
 url=subprocess.check_output(['gh','pr','create','--repo','eth-act/clifv','--base','main','--head',branch,'--title','Prove retained Stock stores and guarded source steps','--body-file',str(body)],cwd=r,text=True).strip()
 save('passed',commit=commit,branch=branch,base=check['base'],pr=int(url.rsplit('/',1)[1]),url=url,remote_verified=True,audit_roots=29)
 print(url)
except BaseException as error:save('failed',error=repr(error));raise
