from pathlib import Path
import os,subprocess,json,hashlib,datetime,time,psutil,re
b=Path('/home/lee/clifv');e=b/'.git/agent-evidence/stock-memory-20261029';r=b/'.worktrees/stock-extending-production-20261031';state=e/'integer-store-records-pr-gates-v1.json';paused=None;records=[];publication=None
def save(status,**x):state.write_text(json.dumps(dict(status=status,records=records,publication=publication,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),**x),indent=2)+'\n')
def live(p):
 try:return p.is_running() and p.status()!=psutil.STATUS_ZOMBIE
 except psutil.NoSuchProcess:return False
def frozen():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==publication['commit']
 assert subprocess.run(['git','diff','--quiet'],cwd=r).returncode==0
 for n,h in hashes.items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==h
try:
 while True:
  p=e/'integer-store-records-publication-v1.json'
  if p.exists():
   publication=json.loads(p.read_text())
   if publication['status']=='passed':break
   assert publication['status']!='failed',publication
  save('waiting',phase='publication');time.sleep(5)
 hashes=json.loads((e/'integer-store-records-combined-v1-state.json').read_text())['source_hashes'];frozen()
 normal=psutil.Process(3167178);schedulers=[]
 for c in normal.children(recursive=True):
  try:
   if c.name().startswith('python') and any(a.endswith('/lake-serial-build.py') or a=='scripts/lake-serial-build.py' for a in c.cmdline()):schedulers.append(c)
  except psutil.NoSuchProcess:pass
 assert len(schedulers)==1,'Inspect changed old validation phase before reserving resources'
 paused=schedulers[0];paused.suspend()
 while any(live(c) for c in paused.children()):save('waiting',phase='finish-old-active-source');time.sleep(3)
 env=dict(os.environ);env.update(json.loads((e/'author-env-v1.json').read_text()));env.update(FV_ROOT=str(r),OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',CARGO_BUILD_JOBS='2',PYTHONDONTWRITEBYTECODE='1')
 for k in ['FV_PIPELINE_T','BLESS']:env.pop(k,None)
 args=['nice','-n','10','python3','scripts/lake-serial-build.py','--budget','16G','--max-jobs','2','--max-cap','16G','--default-cap','8G','--profile',str(r/'scripts/lake-module-peaks.tsv'),'--profile',str(b/'.worktrees/stock-cfg-source-20261025/.lake/lake-module-peaks.tsv'),'--profile',str(e/'production-cold-overrides-v6.tsv'),'--out',str(e/'integer-store-records-full-modules-v1'),'FV','FVTest']
 save('running',phase='full-FV-FVTest',scheduler_paused=paused.pid)
 with (e/'integer-store-records-pr-full-build-v1.log').open('w') as out:done=subprocess.run(args,cwd=r,env=env,stdout=out,stderr=subprocess.STDOUT)
 records.append(dict(label='FV FVTest',returncode=done.returncode));assert done.returncode==0,records
 frozen();env.update(FV_MEMCAP='4G',OMP_NUM_THREADS='1',OMP_THREAD_LIMIT='1',LEAN_NUM_THREADS='1',FV_MEMCAP_STATS=str(e/'integer-store-records-pr-audit-v1.stats'))
 with (e/'integer-store-records-pr-audit-v1.log').open('w') as out:done=subprocess.run(['nice','-n','10',str(r/'scripts/memcap.sh'),'lake','env','lean','-j1','scripts/audit/stock-memory-store-records.lean'],cwd=r,env=env,stdout=out,stderr=subprocess.STDOUT)
 records.append(dict(label='audit',returncode=done.returncode));assert done.returncode==0,records
 def axioms(p):
  t=p.read_text();a={n:set(x.strip() for x in s.split(',')) for n,s in re.findall(r"'([^']+)' depends on axioms: \[([^]]*)\]",t,re.S)};a.update({n:set() for n in re.findall(r"'([^']+)' does not depend on any axioms",t)});return a
 now=axioms(e/'integer-store-records-pr-audit-v1.log');old=axioms(e/'integer-store-packet-audit-v4.log')
 assert len(now)==29 and all(a<={'propext','Classical.choice','Quot.sound'} for a in now.values())
 assert all(now[n]==a for n,a in old.items())
 frozen();save('passed',audit_roots=29,prior_axiom_sets_exact=7,all_axioms_standard=True,scope='Proof-only leaf additions; no executable or existing E2E importer changed.')
except BaseException as error:save('failed',error=repr(error));raise
finally:
 if paused is not None and live(paused):paused.resume()
