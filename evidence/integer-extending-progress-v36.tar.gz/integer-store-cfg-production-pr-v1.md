Use the proved Stock driver for complete NOP/jump/NOP/store/NOP/return functions. The compiler, semantic checker, traces, both linkers, and generated proofs use the new CFG provider. Route17 follows unchanged routes0–16. Original inputs, settings, allocator callbacks, and complete previous-file retry remain intact.

The source selector derives one retained store at its original index. Every other target statement must be a NOP. The proofs retain the original memory-model return/trap Domain and ABI read boundaries. Existing theorem variants remain intact. No caller execution certificate or type-equality acceptance guard is added.

Validation passed: full FV/FVTest,91 audit roots with90 exact prior axiom sets,all configured/default/trace tests,and the first complete i32 native/ELF/linker/generated matrix. Generic correctness uses standard axioms. Only fixed acceptance witnesses use permitted native decision axioms.

Validation continues for the remaining CFG forms,retained classes,runtime,encoder,E2E identities,crate proofs,preservation,and current CI. Do not merge before these gates pass. Full original#140 remains incomplete. No review agents run.
