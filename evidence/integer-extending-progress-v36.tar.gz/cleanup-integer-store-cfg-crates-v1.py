from pathlib import Path
import json,subprocess,hashlib,time,datetime,shutil,psutil
b=Path('/home/lee/clifv');r=b/'.worktrees/stock-extending-production-20261031';e=b/'.git/agent-evidence/stock-memory-20261029';crate=r/'crate-proofs';cache=crate/'.lake';state=e/'integer-store-cfg-crate-cleanup-v1.json'
def save(status,**x):state.write_text(json.dumps(dict(status=status,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),**x),indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
try:
 save('waiting',phase='all96-crate-modules-and-final-package-gate')
 while True:
  gate=json.loads((e/'integer-store-cfg-production-gates-state-v1.json').read_text());assert gate['status']!='failed',gate
  if gate['status']=='passed':break
  time.sleep(10)
 assert gate['crate_modules']==96
 assert cache.is_dir() and not cache.is_symlink()
 sources={str(p.relative_to(crate)):sha(p) for p in (crate/'Crates').rglob('*.lean')};assert len(sources)==96,len(sources)
 for proc in psutil.process_iter(['pid']):
  try:
   cwd=Path(proc.cwd())
   assert not cwd.is_relative_to(crate),('crate process still active',proc.pid,proc.cmdline())
  except (psutil.NoSuchProcess,psutil.AccessDenied,FileNotFoundError):pass
 packages=[]
 for p in (cache/'packages').iterdir():
  if p.is_symlink():continue
  assert (p/'.git').exists(),('inspect untracked package',str(p))
  clean=subprocess.check_output(['git','status','--porcelain'],cwd=p,text=True).strip();assert not clean,(str(p),clean)
  packages.append(dict(name=p.name,head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=p,text=True).strip()))
 meta=e/'integer-store-cfg-crate-command-metadata-v1';meta.mkdir(exist_ok=False)
 for p in cache.rglob('*'):
  if p.is_file() and not p.is_symlink() and '.git' not in p.parts and p.suffix in {'.trace','.hash','.rsp','.log'}:
   dest=meta/p.relative_to(cache);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(p.read_bytes())
 before=shutil.disk_usage(r).free;shutil.rmtree(cache)
 assert all(sha(crate/n)==h for n,h in sources.items())
 save('passed',crate_modules=96,source_hashes=sources,clean_duplicate_packages_removed=packages,metadata_preserved=str(meta),warm_parent_repl_and_shared_cache_retained=True,free_before=before,free_after=shutil.disk_usage(r).free)
 print(json.dumps(dict(status='passed',crate_modules=96,free_after=shutil.disk_usage(r).free)))
except BaseException as error:save('failed',error=repr(error));raise
