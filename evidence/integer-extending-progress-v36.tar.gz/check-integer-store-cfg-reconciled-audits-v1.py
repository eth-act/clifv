from pathlib import Path
import subprocess,os,json,re,hashlib,datetime
b=Path('/home/lee/clifv');r=b/'.worktrees/stock-extending-production-20261031';e=b/'.git/agent-evidence/stock-memory-20261029';out=e/'integer-store-cfg-reconciled-audits-v1';state=e/'integer-store-cfg-reconciled-audit-state-v1.json'
def save(status,**x):state.write_text(json.dumps(dict(status=status,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),**x),indent=2)+'\n')
def axioms(p):
 s=p.read_text();a={n:set(x.strip() for x in v.split(',')) for n,v in re.findall(r"'([^']+)' depends on axioms: \[([^]]*)\]",s,re.S)};a.update({n:set() for n in re.findall(r"'([^']+)' does not depend on any axioms",s)});return a
try:
 env=dict(os.environ);env.update(json.loads((e/'author-env-v1.json').read_text()));env.update(FV_ROOT=str(r),FV_MEMCAP='4G',LEAN_NUM_THREADS='1',OMP_NUM_THREADS='1',OMP_THREAD_LIMIT='1')
 files=['scripts/audit/stock-memory-store-cfg.lean','scripts/audit/stock-memory-store-nop-cfg.lean','scripts/audit/stock-memory-store-cfg-machine.lean'];save('running')
 with (e/'integer-store-cfg-reconciled-audit-runner-v1.log').open('w') as log:
  p=subprocess.run(['nice','-n','10',str(r/'scripts/memcap.sh'),'python3','scripts/axiom-audit.py','--log-dir',str(out),*files],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 assert p.returncode==0,p.returncode
 old=json.loads((e/'integer-store-cfg-production-publication-v1.json').read_text());source=old['source_hashes'].copy()
 for name,baseline,count in [('stock-memory-store-cfg','integer-store-cfg-domain-module-path-stock-memory-store-cfg-domain-v4.log',59),('stock-memory-store-nop-cfg','integer-store-nop-full-audit-v1.log',76),('stock-memory-store-cfg-machine','integer-store-cfg-production-static-audit-v1.log',91)]:
  now=axioms(out/(name+'.log'));prior=axioms(e/baseline);assert len(now)==len(prior)==count and now==prior,(name,'axiom drift')
 for n in source:
  actual=hashlib.sha256((r/n).read_bytes()).hexdigest()
  if n in files:source[n]=actual
  else:assert actual==source[n],n
 save('passed',audit_files=3,audit_entries=226,all_prior_axiom_sets_exact=True,source_hashes=source,compiler_and_harness_sources_exact=True,annotation_only=True)
except BaseException as error:save('failed',error=repr(error));raise
