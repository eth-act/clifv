from pathlib import Path
import subprocess,json,time,datetime,tarfile,hashlib,re,runpy
b=Path('/home/lee/clifv');e=b/'.git/agent-evidence/stock-memory-20261029';state=e/'integer-store-cfg-production-official-state-v3.json'
def save(status,**x):state.write_text(json.dumps(dict(status=status,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),full_goal_complete=False,**x),indent=2)+'\n')
def cmd(*a):return subprocess.check_output(a,cwd=b,text=True).strip()
try:
 save('waiting',phase='current-source-publication-and-production-gates')
 while True:
  pub=json.loads((e/'integer-store-cfg-production-publication-v2.json').read_text());assert pub['status']!='failed',pub
  gate=json.loads((e/'integer-store-cfg-production-gates-state-v2.json').read_text());assert gate['status']!='failed',gate
  if pub['status']=='passed' and gate['status']=='passed':break
  time.sleep(10)
 while True:
  pr=json.loads(cmd('gh','pr','view',str(pub['pr']),'--repo','eth-act/clifv','--json','state,headRefOid,statusCheckRollup'));assert pr['state']=='OPEN' and pr['headRefOid']==pub['commit'],pr
  checks=pr['statusCheckRollup'];names={'Quick checks','Build and compare','Check lost matches','Publish PR result'}
  assert not any(x.get('status')=='COMPLETED' and x.get('conclusion') not in ['SUCCESS','SKIPPED','NEUTRAL'] for x in checks),checks
  if names<={x.get('name') for x in checks} and all(x.get('status')=='COMPLETED' for x in checks):break
  save('waiting',phase='all-four-current-CI-checks',pr=pub['pr']);time.sleep(20)
 build=next(x for x in checks if x.get('name')=='Build and compare');run=re.search(r'/actions/runs/([0-9]+)',build['detailsUrl']);assert run,build
 run_id=run[1];save('running',phase='adopt-exact-current-CI-artifact',pr=pub['pr'],run_id=run_id)
 for name,directory in [('stock-comparison-summary-1','stock-cfg-ci-summary-v2'),('stock-comparison-artifacts-1','stock-cfg-ci-artifacts-v2')]:
  out=e/directory;out.mkdir(exist_ok=False);subprocess.run(['gh','run','download',run_id,'--repo','eth-act/clifv','--name',name,'--dir',str(out)],cwd=b,check=True)
 archives=list((e/'stock-cfg-ci-artifacts-v2').glob('*.tar.gz'));assert len(archives)==1,archives
 with tarfile.open(archives[0],'r:gz') as archive:
  matches=[m for m in archive.getmembers() if m.isfile() and (m.name=='results.json' or m.name.endswith('/results.json'))];assert len(matches)==1,matches
  data=archive.extractfile(matches[0]).read()
 report=e/'stock-cfg-ci-artifacts-v2/results.json';report.write_bytes(data)
 (e/'integer-store-cfg-ci-report-extraction-v2.json').write_text(json.dumps(dict(run_id=run_id,archive_sha256=hashlib.sha256(archives[0].read_bytes()).hexdigest(),member=matches[0].name,report_sha256=hashlib.sha256(data).hexdigest(),report_bytes=len(data)),indent=2)+'\n')
 runpy.run_path(str(e/'verify-integer-store-cfg-ci-official-v2.py'),run_name='__main__')
except BaseException as error:save('failed',error=repr(error));raise
