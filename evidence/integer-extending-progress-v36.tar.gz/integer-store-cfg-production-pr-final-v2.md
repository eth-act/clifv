Use the proved Stock driver for complete NOP/jump/NOP/store/NOP/return functions. The compiler, semantic checker, traces, both linkers, and generated proofs use the new CFG provider. Route17 follows unchanged routes0–16. Original inputs, settings, allocator callbacks, and complete previous-file retry remain intact.

The source selector derives one retained store at its original index. Every other target statement must be a NOP. The proofs retain the original memory-model return/trap Domain and ABI read boundaries. Existing theorem variants remain intact. No caller execution certificate or type-equality acceptance guard is added.

Validation passed: full FV/FVTest,91 audit roots with90 exact prior axiom sets,all configured/default/trace tests,and the first complete i32 native/ELF/linker/generated matrix. Generic correctness uses standard axioms. Only fixed acceptance witnesses use permitted native decision axioms.

Validation passed for all13 CFG matrices,17 retained memory matrices,eight retained classes,runtime,encoder,both E2E identity modes,all96 crate modules,347 previous audit entries,48 captured axiom sets,4543 hashes,eight captured objects,eight settings rejections,and all four current CI checks. The exact current-source official report has no lost matches or successful-stage regressions. Full original#140 remains incomplete. No review agents run.
