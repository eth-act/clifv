from pathlib import Path
import subprocess,os,json,datetime,hashlib,re
b=Path('/home/lee/clifv');e=b/'.git/agent-evidence/stock-memory-20261029';r=b/'.worktrees/stock-extending-production-20261031';state=e/'integer-store-mixed-pattern-witness-state-v10.json';records=[]
modules=['FV/Backend/Proof/StockProtectedSinkWitness.lean']
def save(status,**x):state.write_text(json.dumps(dict(status=status,records=records,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),**x),indent=2)+'\n')
try:
 env=dict(os.environ);env.update(json.loads((e/'author-env-v1.json').read_text()));env.update(FV_ROOT=str(r),FV_MEMCAP='4G',LEAN_NUM_THREADS='1',OMP_NUM_THREADS='1',OMP_THREAD_LIMIT='1')
 hashes={n:hashlib.sha256((r/n).read_bytes()).hexdigest() for n in modules}
 for name in modules:
  save('running',phase=name)
  output=r/'.lake/build/lib/lean'/Path(name).with_suffix('.olean');output.parent.mkdir(parents=True,exist_ok=True)
  with (e/('integer-store-mixed-eligibility-'+Path(name).stem+'-witness-v10.log')).open('w') as out:
   p=subprocess.run(['nice','-n','10',str(r/'scripts/memcap.sh'),'lake','env','lean','-j1','-o',str(output),name],cwd=r,env=env,stdout=out,stderr=subprocess.STDOUT)
  records.append(dict(module=name,returncode=p.returncode));assert p.returncode==0,records
 save('passed',source_hashes=hashes,scope='Complete non-vacuity checks for all four actual sink rules and both named production helpers beside a real protected store. The named fixed fixture uses native_decide; generic frames and four rule fixtures use kernel proofs. Source/scan/whole-driver lifting remains open.')
except BaseException as error:save('failed',error=repr(error));raise
