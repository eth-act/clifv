import FV.Backend.Lowering.StockLinearCfgNI
import FV.Backend.Lowering.StockForwardCfg

namespace Backend.Stock.ForwardCfg
set_option autoImplicit false

/-- The forward scalar CFG is checked before publication. Every failure uses
exactly the previous complete CFG provider on the original function. -/
def lowerValidated (f : Clif.Function) : Except String VCode :=
  if !eligible f then LinearCfg.lowerValidated f
  else
    let attempt := do
      let result ← Stock.lower f
      if check f result.code && ABIReadCfg.check f.sig result.code then pure result.code
      else throw "Stock forward candidate failed paired semantic validation"
    match attempt with
    | .ok vc => .ok vc
    | .error _ => LinearCfg.lowerValidated f

/-- Previously published artifact indices0–7 remain unchanged. -/
def lowerRoutes : List (Clif.Function → Except String VCode) :=
  LinearCfg.lowerRoutes ++ [lowerValidated]

def lowerWithRoutes (choices : List (String × Nat)) (f : Clif.Function) : Except String VCode :=
  match choices.lookup f.name with
  | none => lowerValidated f
  | some index => ((lowerRoutes[index]?).getD ScalarAdd.lower) f

end Backend.Stock.ForwardCfg
