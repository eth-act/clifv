from pathlib import Path
import json,subprocess,sys,re
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');sys.path.insert(0,str(root/'scripts'))
from byte_compare import ELF
base=Path('/tmp/stock-forward-cfg-paired-main-v1');env=json.loads(Path('/tmp/stock-mixed-div-env.json').read_text());rows=[]
for row in json.loads(Path('/tmp/stock-forward-cfg-changed-functions.json').read_text()):
 unit=base/row['cgu'];asm={};instructions={}
 for kind,path in [('baseline',unit/'baseline/lean.o'),('candidate',unit/'candidate/lean.o'),('reference',unit/'captured/cgclif.o')]:
  elf=ELF(path);symbol,data=elf.function(row['fn'])
  result=subprocess.run([env['LLVM_MC'],'--disassemble','-triple=aarch64','-mattr=+lse,+fp-armv8,+neon'],input=' '.join('0x%02x'%v for v in data),text=True,capture_output=True,check=True)
  asm[kind]=result.stdout;instructions[kind]=[line.strip() for line in result.stdout.splitlines() if line.strip() and not line.strip().startswith('.')]
 rows.append({**row,'disassembly':asm,'instruction_counts':{k:len(v) for k,v in instructions.items()}})
Path('/tmp/stock-forward-cfg-changed-disassembly.json').write_text(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'rows':rows},indent=2)+'\n')
seen=set()
for r in rows:
 key=r['baseline_bytes']+r['candidate_bytes']
 if key in seen:continue
 seen.add(key);print(r['fn']);print(r['instruction_counts'])
 for k,a in r['disassembly'].items():print(k+'\n'+a[:3000])
