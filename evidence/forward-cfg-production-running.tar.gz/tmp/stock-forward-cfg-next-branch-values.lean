import FV.Backend.Proof.StockSelectValues
import FV.Backend.Proof.IselCtlBrif
import FV.Backend.Proof.StockCmpConditionValues
namespace Backend.Stock.Proof.ConditionalReplacement
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
private theorem append_fall_inv {V W : Type} (sem : ISem V W) {leading suffix : List MInst}
    {ρ final : Nat → V} {w endWorld : W}
    (run : seqRun sem (leading++suffix) ρ w = some (.fall final endWorld)) :
    ∃ middle world,seqRun sem leading ρ w = some (.fall middle world) ∧
      seqRun sem suffix middle world = some (.fall final endWorld) := by
  induction leading generalizing ρ w with
  | nil => exact ⟨ρ,w,rfl,run⟩
  | cons i ms ih =>
    simp only [List.cons_append,seqRun] at run
    split at run
    · cases run
    · rename_i ops operands
      split at run
      · cases run
      · rename_i outs nextWorld ctl step
        split at run
        · rename_i length
          split at run
          · cases rest : seqRun sem (ms++suffix) (vdefUpd ops outs ρ) nextWorld with
            | none => rw [rest] at run; cases run
            | some result =>
              rw [rest] at run
              cases result with
              | fall after afterWorld =>
                cases run
                obtain ⟨middle,world,left,right⟩ := ih rest
                refine ⟨middle,world,?_,right⟩
                simp only [seqRun,operands,step,length,ite_true,left,Option.map_some]
                rfl
              | stop k j used before beforeWorld values stoppedWorld control => cases run
          · cases run
        · cases run
private theorem nf_symm {F : BitVec 64 → Prop} {a b : Arm.ArmState}
    (h : SameWorldNF F a b) : SameWorldNF F b a :=
  ⟨fun f hf hfl => (h.1 f hf hfl).symm,fun x hx => (h.2.1 x hx).symm,h.2.2.symm⟩
private theorem condition_read (c : BitVec 4) (w : Arm.ArmState) :
    Arm.ConditionHolds c w = condOn c (Arm.read_pstate w) := by
  simp only [Arm.ConditionHolds,condOn,Arm.read_pstate,Arm.read_flag,Arm.r]
  rfl
private theorem condition_invert (c : Cond) (valid : c ≠ .al ∧ c ≠ .nv) (w : Arm.ArmState) :
    Arm.ConditionHolds c.invert.bits w = !Arm.ConditionHolds c.bits w := by
  rw [condition_read,condition_read,ScalarCmp.stock_cmp_condition_invert c valid]
/-- Reuse a proved original condition's boolean companion to execute the real
branch. The ghost cset is removed, not inserted into the compiled program; only
the actual leading instructions and conditional terminator execute. -/
theorem branch_of_boolean_companion {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem}
    (refines : Refines F isem) {leading : List MInst} {ρ : Nat → CV} {world : Arm.ArmState}
    {d : Nat} {condition : Cond} (valid : condition ≠ .al ∧ condition ≠ .nv)
    {b : Bool} {P : Nat → Prop} (outside : ∀ k,P k → k ≠ d)
    (run : Runs F isem (leading++[.cset (.vreg d .int) condition]) ρ world (fun final _ =>
      VHolds ⟨.i8,Clif.Sem.bool8 b⟩ (final d) ∧ ∀ k,P k → final k = ρ k))
    (yes no : Label) :
    ∃ regs prefixWorld branchWorld,
      seqRun isem (leading++[.condBr yes no (.cond condition)]) ρ world =
        some (.stop leading.length (.condBr yes no (.cond condition)) #[] regs prefixWorld
          [] branchWorld (.goto (if b then 0 else 1))) ∧
      SameWorldNF F branchWorld world ∧ ∀ k,P k → regs k = ρ k := by
  obtain ⟨final,endWorld,full,fullNF,boolean,frame⟩ := run
  obtain ⟨middle,middleWorld,prefixRun,tailRun⟩ := append_fall_inv isem full
  obtain ⟨expected,expectedWorld,expectedRun,tailNF,updated⟩ := Runs.cset refines d valid middle middleWorld
  have both := SeqEnd.fall.inj (Option.some.inj (tailRun.symm.trans expectedRun))
  have output : final = upd middle d (ofX (if Arm.ConditionHolds condition.invert.bits middleWorld then 0#64 else 1#64)) :=
    both.1.trans updated
  have suffixNF : SameWorldNF F endWorld middleWorld := by rw [both.2]; exact tailNF
  have middleNF := (nf_symm suffixNF).trans fullNF
  rw [output,upd_same,condition_invert condition valid] at boolean
  have truth : Arm.ConditionHolds condition.bits middleWorld = b := by
    cases actual : Arm.ConditionHolds condition.bits middleWorld <;> cases b
    all_goals simp [actual,VHolds,ofX,Clif.Sem.bool8,Clif.Ty.width] at boolean ⊢
  have oldFrame : ∀ k,P k → middle k = ρ k := by
    intro k hk
    have kept := frame k hk
    rw [output] at kept
    simpa only [upd,outside k hk,ite_false] using kept
  have spec : ispec (.condBr yes no (.cond condition)) [] middleWorld =
      some ([],middleWorld,.goto (if b then 0 else 1)) := by
    simp only [ispec,condBrHolds,truth]
  obtain ⟨branchWorld,branchRun,branchNF⟩ := seqRun_one_stop refines
    (operands_condBr_cond yes no condition) (ρ := middle) (by simp) spec (by simp)
  refine ⟨middle,middleWorld,branchWorld,?_,(SameWorld.nf branchNF).trans middleNF,oldFrame⟩
  simpa only [Nat.add_zero,Nat.zero_add] using seqRun_append_fall_stop isem prefixRun branchRun

/-- A real cset execution and arbitrary original flags inhabit the semantic
replacement, with both branch outcomes and all unaffected registers covered. -/
theorem branch_companion_witness {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem}
    (refines : Refines F isem) (ρ : Nat → CV) (world : Arm.ArmState) :
    ∃ regs prefixWorld branchWorld,
      seqRun isem [.condBr 2 1 (.cond .eq)] ρ world =
        some (.stop 0 (.condBr 2 1 (.cond .eq)) #[] regs prefixWorld [] branchWorld
          (.goto (if Arm.ConditionHolds Cond.eq.bits world then 0 else 1))) ∧
      SameWorldNF F branchWorld world ∧ ∀ k,k ≠ 0 → regs k = ρ k := by
  have companion : Runs F isem [.cset (.vreg 0 .int) .eq] ρ world (fun final _ =>
      VHolds ⟨.i8,Clif.Sem.bool8 (Arm.ConditionHolds Cond.eq.bits world)⟩ (final 0) ∧
      ∀ k,k ≠ 0 → final k = ρ k) := by
    apply (Runs.cset refines 0 (by decide : Cond.eq ≠ .al ∧ Cond.eq ≠ .nv) ρ world).imp
    intro final endWorld _ updated
    rw [updated]
    constructor
    · rw [upd_same,condition_invert .eq (by decide)]
      cases h : Arm.ConditionHolds Cond.eq.bits world <;> rfl
    · intro k different
      simp only [upd,different,ite_false]
  exact branch_of_boolean_companion refines (leading := []) (by decide)
    (P := fun k => k ≠ 0) (fun _ h => h) companion 2 1

end Backend.Stock.Proof.ConditionalReplacement
#print axioms Backend.Stock.Proof.ConditionalReplacement.branch_of_boolean_companion

#print axioms Backend.Stock.Proof.ConditionalReplacement.branch_companion_witness
