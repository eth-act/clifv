from pathlib import Path
import os,json,subprocess,hashlib
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');os.chdir(root)
e=os.environ.copy();e.update(json.load(open('/tmp/stock-mixed-div-env.json')));e.update(FV_ROOT=str(root),FV_MEMCAP='8G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2')
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:2]);os.nice(10)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
with open('/tmp/stock-forward-cfg-normalized-diagnostic.log','w') as f:r=subprocess.run(['scripts/memcap.sh','lake','env','lean','--run','/tmp/stock-forward-cfg-normalized-diagnostic.lean','/tmp/stock-forward-cfg-normalized-inputs.txt','/tmp/stock-forward-cfg-normalized-diagnostic.json'],env=e,stdout=f,stderr=subprocess.STDOUT)
assert not r.returncode,r.returncode
p=Path('/tmp/stock-forward-cfg-normalized-diagnostic.json');j=json.loads(p.read_text());j['head']=head;j['inputs']='immutable paired source snapshots';j['normalization']='actual CLI Opt.Legalize128.parsedFile128';j['limits']='Captured function instances, not unique source coverage or full driver completeness';p.write_text(json.dumps(j,indent=2)+'\n');rows=j['rows'];print({'parsed':j['parsed_functions'],'eligible':len(rows),'source_ok':sum(r['source_ok'] for r in rows),'actual_stock':sum(r['actual_stock'] for r in rows),'newly_eligible':sum(not r['previous_eligible'] for r in rows),'raw_vcode_changed':sum(not r['previous_vcode_exact'] for r in rows)})
