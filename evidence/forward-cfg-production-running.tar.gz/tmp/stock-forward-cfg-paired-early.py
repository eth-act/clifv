from pathlib import Path
import os,json,subprocess,hashlib,shlex,concurrent.futures,sys,datetime,shutil
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');os.chdir(root);sys.path.insert(0,str(root/'scripts'))
from byte_compare import ELF
out=Path('/tmp/stock-forward-cfg-paired-main-v1');out.mkdir(exist_ok=False)
e=os.environ.copy();e.update(json.load(open('/tmp/stock-mixed-div-env.json')));e.update(FV_ROOT=str(root),FV_MEMCAP='8G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2');e.pop('FV_RA_OUT',None)
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:2]);os.nice(10)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();baseline='ac302a8a712d1fc01141e7d974820ac6f740c03c'
backends={'baseline':Path('/tmp/stock-general-cfg-baseline/lean-backend'),'candidate':root/'.lake/build/bin/lean-backend'}
assert sha(backends['baseline'])==json.load(open('/tmp/stock-general-cfg-baseline/provenance.json'))['binary_sha256']
units=[];jobs=[];hashes={};original_sources={}
for crate in ['fv-demo','survey']:
 for meta in sorted((root/'examples'/crate/'target/fv/plain-leanlink-verified-leanld/tmp').glob('*/fv-link.json')):
  directory=meta.parent;rsp=directory/'lean-inputs.rsp'
  if not rsp.exists():continue
  data=json.load(meta.open());metadata={str(Path(f['ra']).with_name(Path(f['ra']).name.replace('.ra.json','.o'))):f for f in data['functions'] if f.get('ra')}
  target=out/directory.name;target.mkdir();capture=target/'captured';capture.mkdir()
  for name in ['cgclif.o','redefine-lean.txt','gap.o','fv-link.json','lean-inputs.rsp']:
   source=directory/name;copy=capture/name;shutil.copy2(source,copy);assert sha(source)==sha(copy);hashes[str(copy)]=sha(copy)
  objects=shlex.split(rsp.read_text());replacement={k:{} for k in backends}
  for obj in objects:
   if Path(obj).name=='gap.o':
    for k in backends:replacement[k][obj]=str(capture/'gap.o')
    continue
   f=metadata[obj];source=directory/'split'/Path(f['dump']).name;assert source.is_file();copy=capture/('source-'+str(len(jobs))+'.clif');shutil.copy2(source,copy);digest=sha(copy);assert sha(source)==digest;hashes[str(copy)]=digest;original_sources[str(source)]=digest
   for k in backends:
    folder=target/k;folder.mkdir(exist_ok=True);binary=folder/Path(obj).name;replacement[k][obj]=str(binary);jobs.append((k,copy,binary))
  for k in backends:(target/k/'inputs.rsp').write_text('\n'.join('"'+replacement[k][obj]+'"' for obj in objects)+'\n')
  units.append((target,crate))
assert len(jobs)==9086 and len(units)==30,(len(jobs),len(units))
provenance={'head':head,'baseline':baseline,'baseline_backend_sha256':sha(backends['baseline']),'candidate_backend_sha256':None,'captured_inputs':hashes,'original_sources':original_sources,'jobs':len(jobs),'units':len(units),'flags':['--dead-cleanup','--personality','rust_eh_personality'],'source_pipeline_sha256':sha(root/'rust/crates/cargo-fv/src/pipeline.rs'),'state':'running','purpose':'Both executables run now on immutable snapshots; later native-example report must agree exactly before gate reuse.'}
(out/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
def compile_one(job):
 kind,source,target=job
 with target.with_suffix('.log').open('w') as log:r=subprocess.run([str(backends[kind]),str(source),str(target),'--dead-cleanup','--personality','rust_eh_personality'],env=e,stdout=log,stderr=subprocess.STDOUT)
 assert r.returncode==0,(kind,source,r.returncode,target.with_suffix('.log'))
 assert ELF(target).functions,('empty function',kind,source)
 return str(target)
def compile_group(kind,workers):
 group=[job for job in jobs if job[0]==kind]
 with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
  for i,_ in enumerate(pool.map(compile_one,group),1):
   if i%500==0:print(kind,'paired executable runs',i,flush=True)
compile_group('baseline',1)
provenance['baseline_completed']=True
(out/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
import time
needed=Path('/tmp/stock-forward-cfg-native-v1/tools.json')
trust=Path('/tmp/stock-forward-cfg-trust-v1/receipt.json')
while not needed.exists() or not trust.exists() or json.loads(trust.read_text()).get('state')=='running':
 for path in [trust,Path('/tmp/stock-forward-cfg-native-v1/receipt.json')]:
  if path.exists():assert json.loads(path.read_text()).get('state')!='failed',path
 time.sleep(10)
assert json.loads(trust.read_text())['state']=='passed'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head
assert sha(backends['candidate'])==json.load(open('/tmp/stock-forward-cfg-native-v1/tools.json'))['binary_sha256']['lean-backend']
provenance['candidate_backend_sha256']=sha(backends['candidate'])
(out/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
compile_group('candidate',2)
rows=[]
rel=lambda elf,s:[(r['offset'],r['type'],r['addend']) for r in elf.function_relocations(s,{})]
for target,crate in units:
 for kind in backends:
  folder=target/kind
  subprocess.run([e['CLIF_NATIVE_LLD'],'-flavor','gnu','-r','-o',str(folder/'lean.o'),'@'+str(folder/'inputs.rsp')],env=e,check=True)
  subprocess.run([e['FV_OBJCOPY'],'--redefine-syms='+str(target/'captured/redefine-lean.txt'),str(folder/'lean.o')],env=e,check=True)
 old=ELF(target/'baseline/lean.o');new=ELF(target/'candidate/lean.o');stock=ELF(target/'captured/cgclif.o')
 for name,syms in sorted(new.functions.items()):
  if len(syms)!=1 or not syms[0]['size']:continue
  ns,nb=new.function(name);bs,bb=old.function(name);ss,sb=stock.function(name)
  rows.append({'crate':crate,'cgu':target.name,'fn':name,'baseline_equal':bb==sb and rel(old,bs)==rel(stock,ss),'candidate_equal':nb==sb and rel(new,ns)==rel(stock,ss),'baseline_bytes':hashlib.sha256(bb).hexdigest(),'candidate_bytes':hashlib.sha256(nb).hexdigest()})
assert len(rows)==4543 and len({(r['cgu'],r['fn']) for r in rows})==4543
assert all(sha(p)==digest for p,digest in hashes.items()),'snapshot mutated'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head
assert all(sha(backends[k])==provenance[k+'_backend_sha256'] for k in backends)
gained=[r for r in rows if r['candidate_equal'] and not r['baseline_equal']];lost=[r for r in rows if r['baseline_equal'] and not r['candidate_equal']]
summary={'head':head,'baseline':baseline,'state':'passed' if not lost else 'failed','symbol_comparisons':len(rows),'baseline_exact':sum(r['baseline_equal'] for r in rows),'candidate_exact':sum(r['candidate_equal'] for r in rows),'gained':gained,'lost':lost,'changed_function_bytes':sum(r['baseline_bytes']!=r['candidate_bytes'] for r in rows),'same_captured_inputs_and_settings':True,'limits':'Paired byte/relocation comparisons, not unique function coverage or full goal completion. Post-native actual example report agreement remains required.'}
(out/'rows.json').write_text(json.dumps(rows,indent=2)+'\n');(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');provenance.update(state=summary['state'],rows_sha256=sha(out/'rows.json'),summary_sha256=sha(out/'summary.json'));(out/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
print(json.dumps({k:v if k not in ['gained','lost'] else len(v) for k,v in summary.items()}),flush=True);assert not lost,len(lost)
