import FV.Backend.Lowering.StockForwardCfgNI
import FV.Opt.Legalize128Pass
import FV.Clif.Parse
import Lean
open Backend
private def calls : Clif.Terminator → Option (List Clif.BlockCall)
  | .jump bc => some [bc]
  | .brif _ yes no => some [yes,no]
  | .ret _ => some []
  | _ => none
private def ranked (f : Clif.Function) : Bool :=
  f.blocks.zipIdx.all fun (b,bi) => (calls b.term).any fun edges => edges.all fun bc =>
    (f.blocks.findIdx? (·.id == bc.block)).any fun target => bi < target
private def conditional : Clif.Terminator → Bool
  | .brif .. => true
  | _ => false
private def emptyConditional : Clif.Terminator → Bool
  | .brif _ yes no => yes.args.isEmpty && no.args.isEmpty
  | _ => true

def main (args : List String) : IO Unit := do
  let paths := ((← IO.FS.readFile args[0]!).splitOn "\n").filter (!·.isEmpty)
  let mut rows := #[]
  let mut total := 0
  for path in paths do
    let parsed := (Opt.Legalize128.parsedFile128 (Clif.parseFile (← IO.FS.readFile path))).file
    for source in parsed.funcs do
      if let .ok f := source.func then
        total := total+1
        if f.blocks.any (conditional ∘ (·.term)) then
          let body := f.blocks.all fun b => b.body.all Stock.Scalar.maskMixedBodyEligible
          let abi := f.sig.params.all Stock.Scalar.narrowAbiEligible && f.sig.returns.all Stock.Scalar.narrowAbiEligible
          let input := if body && abi then Backend.Proof.Driver.lowerScopeB f && Backend.Proof.Driver.dominatedB f && Backend.sigAbiOk f.sig else false
          rows := rows.push (Lean.Json.mkObj [("path",Lean.toJson path),("function",Lean.toJson f.name),
            ("blocks",Lean.toJson f.blocks.length),("body_eligible",Lean.toJson body),
            ("abi_eligible",Lean.toJson abi),("original_input_checks",Lean.toJson input),
            ("jump_brif_return_only",Lean.toJson (f.blocks.all fun b => (calls b.term).isSome)),
            ("source_forward_ranked",Lean.toJson (ranked f)),
            ("empty_conditional_args",Lean.toJson (f.blocks.all fun b => emptyConditional b.term))])
  IO.FS.writeFile args[1]! ((Lean.Json.mkObj [("parsed_functions",Lean.toJson total),("rows",Lean.Json.arr rows)]).compress)
  IO.println s!"conditional source inventory: {total} functions, {rows.size} with brif"
