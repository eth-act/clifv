from pathlib import Path
import subprocess,os,tarfile,json,hashlib,datetime
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');os.chdir(root);os.nice(19);os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
def git(*args,input=None,env=None):return subprocess.check_output(['git',*args],input=input,env=env).decode().strip()
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
head=git('rev-parse','HEAD');assert head=='1620b2c4beeb2bc36ee50e79fb40b3b3eb2f320d';assert not git('status','--porcelain')
checks=['normal-v1.json','trust-v1/receipt.json','native-v1/receipt.json','post-native-v1/receipt.json','paired-main-v1/summary.json']
for name in checks:
 p=Path('/tmp/stock-forward-cfg-'+name);d=json.loads(p.read_text());assert d.get('state')=='passed',(name,d.get('state'));assert d.get('head',head)==head
branch='agent/stock-cfg-body-progress-20261025T025359Z';parent=git('rev-parse',branch);env=os.environ.copy();index=Path('/tmp/stock-forward-cfg-terminal.index');index.unlink(missing_ok=True);env['GIT_INDEX_FILE']=str(index);git('read-tree',parent,env=env)
files=[]
for pattern in ['stock-forward-cfg*','stock-general-cfg*']:
 for p in Path('/tmp').glob(pattern):
  if p.is_file() and p.suffix in {'.py','.json','.log','.md','.lean','.txt'}:files.append(p)
for name in ['normal-v1','trust-v1','native-v1','post-native-v1','paired-main-v1','integration-v1','parent-linear-integration-v1','parent-scalar-entry-integration-v1','parent-entry-integration-v1','parent-integration-v1','regalloc-diagnostic','parent-regalloc-diagnostic']:
 p=Path('/tmp/stock-forward-cfg-'+name);files.extend(f for f in p.rglob('*') if f.is_file())
for name in ['stock-general-cfg-traversal-axioms-v2','stock-general-cfg-forward-axioms-v1','stock-general-cfg-baseline']:
 p=Path('/tmp')/name;files.extend(f for f in p.rglob('*') if f.is_file())
archive=Path('/tmp/stock-forward-cfg-terminal.tar.gz');manifest=[]
with tarfile.open(archive,'w:gz',compresslevel=1) as tf:
 for p in sorted(set(files)):
  key=str(p).lstrip('/');manifest.append({'path':key,'bytes':p.stat().st_size,'sha256':sha(p)});tf.add(p,arcname=key,recursive=False)
 for name in git('diff','--name-only','ac302a8a','HEAD').splitlines():tf.add(root/name,arcname='repo/'+name,recursive=False)
parts=[]
with archive.open('rb') as stream:
 i=0
 while chunk:=stream.read(32*1024*1024):
  p=Path('/tmp/stock-forward-cfg-terminal.part%03d'%i);p.write_bytes(chunk);blob=git('hash-object','-w',str(p));key='evidence/forward-cfg-terminal.part%03d'%i;git('update-index','--add','--cacheinfo',f'100644,{blob},{key}',env=env);parts.append({'path':key,'bytes':len(chunk),'sha256':sha(p)});i+=1
receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'base':'ac302a8a712d1fc01141e7d974820ac6f740c03c','pr':634,'branch':branch,'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive),'parts':parts,'files':manifest,'state':'all author gates passed; full140 remains open','prior_evidence_tree_preserved':True}
p=Path('/tmp/stock-forward-cfg-terminal-manifest.json');p.write_text(json.dumps(receipt,indent=2)+'\n');blob=git('hash-object','-w',str(p));git('update-index','--add','--cacheinfo',f'100644,{blob},evidence/forward-cfg-terminal-manifest.json',env=env);tree=git('write-tree',env=env);commit=git('commit-tree',tree,'-p',parent,'-m','Preserve complete forward CFG production author gates, captured inputs and next proof work');git('update-ref','refs/heads/'+branch,commit,parent);subprocess.run(['git','push','origin',branch],check=True);assert git('ls-remote','origin','refs/heads/'+branch).split()[0]==commit
summary={k:v for k,v in receipt.items() if k!='files'};summary.update(evidence_commit=commit,manifest_git_path='evidence/forward-cfg-terminal-manifest.json',files=len(manifest));Path('/tmp/stock-forward-cfg-terminal-backup.json').write_text(json.dumps(summary,indent=2)+'\n');index.unlink(missing_ok=True);print(json.dumps(summary))
