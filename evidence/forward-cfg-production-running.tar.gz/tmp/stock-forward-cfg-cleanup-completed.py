from pathlib import Path
import os,json,hashlib,subprocess,shutil,datetime
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');os.nice(19);os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
def git(*a):return subprocess.check_output(['git',*a],cwd=root,text=True).strip()
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
b=json.loads(Path('/tmp/stock-forward-cfg-terminal-backup.json').read_text());m=json.loads(Path('/tmp/stock-forward-cfg-terminal-manifest.json').read_text());assert git('ls-remote','origin','refs/heads/'+b['branch']).split()[0]==b['evidence_commit'];assert sha(Path('/tmp/stock-forward-cfg-terminal.tar.gz'))==b['archive_sha256']
for part in m['parts']:
 oid=git('rev-parse',b['evidence_commit']+':'+part['path']);blob=subprocess.check_output(['git','cat-file','blob',oid],cwd=root);assert hashlib.sha256(blob).hexdigest()==part['sha256']
files={row['path']:row for row in m['files']};paths=[]
for name in ['integration-v1','parent-linear-integration-v1','parent-scalar-entry-integration-v1','parent-entry-integration-v1','parent-integration-v1']:
 paths.extend(Path('/tmp/stock-forward-cfg-'+name)/sub for sub in ['linked','native-objects'])
rows=json.loads(Path('/tmp/stock-forward-cfg-paired-main-v1/rows.json').read_text());paths.extend(Path('/tmp/stock-forward-cfg-paired-main-v1')/cgu for cgu in sorted({row['cgu'] for row in rows}))
removed=[]
for directory in paths:
 if not directory.exists():continue
 members=[p for p in directory.rglob('*') if p.is_file()];total=0
 for p in members:
  key=str(p).lstrip('/');assert key in files,(p,'unarchived');assert sha(p)==files[key]['sha256'],(p,'content changed');total+=p.stat().st_size
 shutil.rmtree(directory);removed.append({'path':str(directory),'files':len(members),'bytes':total})
r={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_head':b['head'],'terminal_remote_evidence':b['evidence_commit'],'archive_sha256_verified':b['archive_sha256'],'remote_commit_parts_content_verified':True,'every_removed_file_hash_verified':True,'removed':removed,'bytes_reclaimed':sum(v['bytes'] for v in removed),'free_GiB':round(shutil.disk_usage(root).free/1024**3,2),'preserved':'All dirty/unpublished source, required source views, current example outputs, one warm cache, small receipts/logs, saved next code and sole baseline executable'}
Path('/tmp/stock-forward-cfg-completed-cleanup.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='removed'}))
