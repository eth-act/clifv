import FV.Backend.Proof.StockConditionalTargets

namespace Backend.Stock.Proof.ConditionalValues
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 20000
attribute [local irreducible] Isle.Aarch64.program

/-- The actual conditional descriptor has the existing decoded branch form and
preserves the compiler base state. Its source condition semantics can therefore
reuse the established zero/nonzero/flag producers rather than a second selector. -/
theorem descriptor_shape {ctx : Ctx} {cfg : Config}
    (overlap : cfg.checkOverlap = false) {fuel : Nat} (enough : 100 ≤ fuel)
    {condition descriptor : V} {P : Nat → Prop} (shape : CondShape condition P)
    {a b : Label} {before after : State} {trace final : Array RuleId}
    (run : ApplyInternal program (Stock.sem ctx) cfg fuel 46 722
      [condition,.label a,.label b] (before,trace) descriptor (after,final)) :
    after.base = before.base ∧ descriptor = brCondV condition a b := by
  have projected := BranchHelpers.stock_br_cond_result_projects ctx cfg overlap (fuel+1)
    [condition,.label a,.label b] before trace
  have legacy : ApplyInternal program (Backend.sem ctx) cfg fuel 46 722
      [condition,.label a,.label b] (before.base,trace) descriptor (after.base,final) := by
    unfold ApplyInternal at run ⊢
    rw [run] at projected
    exact projected.symm
  exact br_cond_result_ok data_program overlap enough shape legacy

end Backend.Stock.Proof.ConditionalValues

#print axioms Backend.Stock.Proof.ConditionalValues.descriptor_shape
