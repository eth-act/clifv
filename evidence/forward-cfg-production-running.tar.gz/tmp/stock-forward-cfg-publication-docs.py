from pathlib import Path
import json,datetime,subprocess
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');r=json.loads(Path('/tmp/stock-forward-cfg-final-author-receipt.json').read_text());backup=json.loads(Path('/tmp/stock-forward-cfg-terminal-backup.json').read_text())
assert r['head']==backup['head']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert r['state']=='all_author_gates_passed'
r['terminal_remote_evidence']=backup
(root/'docs/research/stock-forward-cfg-production.json').write_text(json.dumps(r,indent=2)+'\n')
text=f'''# Arbitrary-length forward Stock scalar CFG production

Validated implementation: `{r['head']}`, based on #633 (`ac302a8a`).
The default compiler, checker, verified linker and generated-proof consumers now
use proved Stock lowering for scalar jump/return graphs of arbitrary length
whose jumps advance the original source block index. Entry must jump. Bodies
may trap; arguments may be empty; source values may be inherited directly.
Full original #140 remains open.

## Proof and production boundary

Actual source-ranked DFS/RPO/node order derives label order, including synthetic
nodes and shared joins. Retained scan identity, uniqueness and demand transport
connect source successors through arbitrary intervening traversal segments.
Return and first-trap simulation compose from instruction zero through ABI entry
and any number of blocks, deriving the unchanged Scalar.Domain and ABIReadCfg.
Only demanded, available values must be held; omitted or sunk values do not
become materialization requirements. No input proof certificate is introduced.

All production consumers append artifact route 8 while retaining routes 0–7 and
transactional fallback to the complete previous LinearCfg/earlier pipeline on
the original input, allocator and settings. All 2,474 prior backend proof files
and the three existing CompiledSemanticNI theorem headers are exact. There are
no allocator, shared LowerSim or CLIF semantic changes. Old theorem variants,
accepted identities, successful stages and required axiom sets are preserved.

Complete four-block source/ABI witnesses return rotate(7,1)=14 and trap at the
first middle-block zero divisor. Of the 48 added audit roots, 38 generic results
and four kernel witnesses use only the standard three axioms; six fixed-input
witness roots use explicitly labelled original-input checks. MCP reviews confirm
check_sound uses Std3, the complete witness retains exactly its two fixed-input
facts, and neither review reports warnings.

## Terminal author validation

| Gate | Result |
| --- | --- |
| Normal FV/FVTest module keys | 4,093/4,093; 76 rebuilt |
| All trust audits | 94 files; 3,592 roots; all 3,544 prior sets exact |
| Retained ownership checks | 6/6 |
| New integration | 78 checks; 18 generated roots and 4 CLI reconstruction roots |
| Retained linear/scalar-entry/entry/CFG cohorts | 78/70/34/34 |
| Native execution | 24 objects; 24,000 byte executions; 3,000 Cranelift references; zero failures/disagreements |
| Runtime | 5,755 runnable passes; zero failures/disagreements; seven prior unavailable cases |
| Encoder | 1,398 identical; zero different |
| Both E2E modes | 1,159 accepted; all original 1,150 and parent 1,159 identities/stages exact |
| Verified examples | fv-demo: 21 tests/2 ELFs; survey: 53 tests/18 ELFs |
| Actual crate proof package | 93 modules; 96 recorded commands; default build passes |
| Paired default allocator | 4,543 symbols; 900→900 exact; zero gains/losses; four changed instances |

The new maintained native/CLI/link/generated cohort covers 100 source functions
over four to eight blocks, all six ABI configurations, both allocators and both
cleanup modes, including forced complete fallback and missing-oracle controls.
After ordinary Cargo examples rebuilt, all 4,543 actual candidate and reference
function bytes and relocations, source inputs and comparison rows were bound to
the immutable paired capture. No pending gate is counted as passed.

## Register agreement and limits

After the actual CLI i128 legalization, 273 captured instances pass the class,
source, lower and read-boundary checks, and the lowering provider returns actual
Stock output. Ten are newly eligible, all two-block; the prior 263 raw VCode
outputs are exact. This describes the lowering provider, not a claim that every
downstream attempt avoids late fallback. Four- to eight-block activation is
covered by universal proofs and maintained native fixtures; this real capture
contains no eligible instance longer than three blocks.

The four changed byte instances are legalized i128 wrapping add/sub. Stock
removes a duplicate cmp/cset pair (12→10 instructions including prologue;
Cranelift uses 6), leaving carry instruction-selection differences. The same ten
newly eligible cases with the existing regalloc2 option have 0→0 exact matches.
Default allocation is unchanged. These are captured instances and bounded
diagnostics, not unique-function coverage or a full-goal completion percentage.

## Recovery and remaining work

[Machine receipt](stock-forward-cfg-production.json) binds gates to the validated
head. Remote evidence is preserved on
[`{backup['evidence_commit']}`](https://github.com/eth-act/clifv/tree/{backup['evidence_commit']}/evidence),
branch agent/stock-cfg-body-progress-20261025T025359Z. The manifest
`evidence/forward-cfg-terminal-manifest.json` lists bounded archive parts and
member hashes. Concatenate parts in numeric order and verify archive SHA256
`{backup['archive_sha256']}` before extraction. Prior archives remain preserved.
No new worktrees, caches or agents were created. Dirty saved work is preserved;
obsolete unlinked cache outputs were cleaned with inode/link/age checks.

Continue correct-choice semantics for ordinary conditional, bit-test and table
branches, actual critical routes, loops with inherited carried values, memory/
addressing/atomics, calls/exceptions and every uncovered reachable rule family.
Reuse existing per-edge prepare/spill/copy proofs. Then close original-domain
whole-driver simulation, Stock-only and downstream completeness. Fallback
preserves acceptance and does not prove completeness.

Saved next work derives actual brif condition/builder/emitter calls and original
condition provenance, plus a semantic boolean-companion-to-branch replacement
with real witnesses, all Std3. These are not whole-branch source simulation yet.
The same-input planning inventory finds 1,695 brif instances but only four with
current scalar bodies, original checks and source-forward control. Thus memory
and calls remain important coverage obligations after control composition.
'''
(root/'docs/research/stock-forward-cfg-production.md').write_text(text)
p=root/'docs/research/stock-general-cfg-progress.md';s=p.read_text();s='''# General CFG composition checkpoint

The arbitrary-length forward scalar CFG implementation and all production
consumers are complete in PR #634. [Terminal author evidence](stock-forward-cfg-production.md)
records the exact validated source, all gates, measured agreement and remote
recovery archive. This supersedes the pending-gate statements below. Full #140
remains open; conditional/table/critical correct-choice simulations, loops,
effects/calls and original-domain completeness are not claimed by this packet.

'''+s.split('\n',1)[1];p.write_text(s)
p=root/'docs/plans/stock-driver-incremental-delivery.md';s=p.read_text();a=s.index('## Active candidate:');b=s.index('## Starting point and next deliveries',a)
s=s[:a]+'''## Current delivery: arbitrary-length forward scalar CFGs

PR #633 (`ac302a8a`) activated three-block chains. The next substantive packet,
PR #634, removes that fixed bound and the older two-block forwarding restriction.
[Terminal author evidence](../research/stock-forward-cfg-production.md) records
4,093 normal keys, 94 audit files/3,592 roots/all 3,544 old axiom sets exact,
78 new and 78/70/34/34 retained integration checks, 24,000 native executions,
and runtime/encoder/identity/stage/example/actual-crate/paired-output gates.
All 2,474 prior backend proof files and three shared theorem headers are exact.

Default compiler/checker/verified-linker/generated consumers append route 8 and
retain complete previous-route fallback on original inputs/settings. Source-
ranked actual RPO/traversal, demand transport, return/first traps and ABI entry
derive the existing Scalar.Domain for arbitrary-length forward jump/return CFGs.
No accepted-input certificate or all-values-materialized premise is added.

The same 4,543-symbol paired comparison remains 900→900 exact with no losses and
four changed instances. Ten newly eligible captured instances are all two-block;
the provider selects actual Stock for 273 instances after CLI legalization.
The same ten cases with existing regalloc2 remain 0→0 exact. The changes remove
duplicate cmp/cset in wrapping add/sub, with carry selection still different.
These are bounded measurements, not completion percentages or allocator changes.

Continue actual ordinary conditional, bit-test/table and critical correct-choice
source simulations; then inherited loop values, memory/addressing/atomics,
calls/exceptions, uncovered reachable families and original-domain whole-driver
simulation/Stock-only/downstream completeness. Saved next code already derives
actual brif calls and source-condition provenance, and proves a witnessed
boolean-companion-to-branch semantic replacement using Std3. Connect these to
the actual emission/body/alias/CFG/ABI consumers; do not rebuild existing scalar
condition or per-edge prepare/spill/copy proofs. Preserve first traps and source
fuel/definedness, original inputs, old variants, axioms, identities and stages.

A same-input source inventory finds 1,695 brif instances but only four with
current scalar bodies, original checks and source-forward control. Control
composition remains required; effects/memory/calls are essential for broader
coverage. Backedges require original SSA/dominance and carried-value invariants
beyond forward demand order. No first-class/proof-fragment stop or wholesale
prerequisite queue. Improve the shared-checker validation boundary when it fits
a substantive batch, retaining all old gates and exact axiom sets.

Keep #44 and concrete #140 interface coordination current. Reconcile each batch
with main, push backups and squash-merge promptly after author gates. Keep one
warm cache and bounded builds; archive unique evidence before deleting completed
outputs, and preserve all dirty/unpublished source. Full original #140 remains
open; fallback is acceptance preservation, not completeness.

'''+s[b:];p.write_text(s)
p=root/'docs/research/stock-driver-obligations.json';d=json.loads(p.read_text());d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['complete']=False;d['active_candidate'].update(state='all author gates passed; default activation in PR #634',source_head=r['head'],pull_request=634,evidence='docs/research/stock-forward-cfg-production.md',terminal_remote_evidence=backup['evidence_commit']);d['production']['forward_cfg_production']={'source_head':r['head'],'base':r['base'],'state':'all author gates passed; default activation in this change','pull_request':634,'receipt':'docs/research/stock-forward-cfg-production.md','terminal_evidence':backup['evidence_commit'],'integration_checks':r['integration_checks'],'normal_keys':4093,'audit_files':94,'audit_roots':3592,'prior_axiom_sets_exact':3544,'full_140_complete':False,'unconditional_stock_only_completeness':False};d['production']['current_real_crate_agreement']={'validated_code_head':r['head'],'default_allocator':'lean','symbol_comparisons':4543,'equal_symbol_comparisons':900,'paired_parent':r['base'],'gains':0,'losses':0,'changed_function_bytes':4,'actual_cargo_candidate_and_reference_bytes_bound':4543,'limits':'Captured instances, not unique-source coverage. Same ten newly eligible instances with existing regalloc2: 0→0; no default allocator change/full-corpus regalloc2 claim.'};p.write_text(json.dumps(d,indent=2)+'\n')
print('publication docs prepared',backup['evidence_commit'])
