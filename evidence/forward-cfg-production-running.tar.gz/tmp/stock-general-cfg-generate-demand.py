from pathlib import Path
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025')
old=(root/'FV/Backend/Proof/StockEdgeAliasFrame.lean').read_text();demand=(root/'FV/Backend/Proof/StockDemandMono.lean').read_text()
header='''import FV.Backend.Proof.StockCfgTraversalScans
import FV.Backend.Proof.StockCfgJumpDemand

namespace Backend.Stock.Proof.CfgDemand
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm

private def DemandLE (before after : State) :=
  ∀ (x : Nat),before.demand[x]! ≤ after.demand[x]!

private theorem demand_refl (st : State) : DemandLE st st := fun _ => Nat.le_refl _
private theorem demand_trans {a b c : State} (ab : DemandLE a b) (bc : DemandLE b c) :
    DemandLE a c := fun x => Nat.le_trans (ab x) (bc x)

'''
a=demand.index('private theorem mark_mono');b=demand.index('private theorem marks_mono',a);mark=demand[a:b].replace('DemandMono','DemandLE')
a=demand.index('private theorem setAlias_demandFields');b=demand.index('private def tryAliasStep',a);alias=demand[a:b].replace('setAlias_demandFields','setAlias_demand').replace('demandFields next = demandFields st','next.demand = st.demand')
a=old.index('private theorem forIn_frame');b=old.index('private def argStep',a);loop=old[a:b].replace('forIn_frame','forIn_demand').replace('{α β γ : Type} (field : α → γ)','{α β : Type} (field : α → State)').replace('field b = field a','DemandLE (field a) (field b)').replace('field next = field a','DemandLE (field a) (field next)').replace('cases h; rfl','cases h; exact demand_refl _').replace('exact (ih h).trans (keeps x a b call)','exact demand_trans (keeps x a b call) (ih h)')
a=old.index('private def argStep');b=old.index('private theorem arg_frame',a);arg=old[a:b]
a=old.index('private theorem arg_frame');b=old.index('private theorem arg_no_break',a);am=old[a:b].replace('arg_frame','arg_demand').replace('frame b.1 = frame a.1','DemandLE a.1 b.1').replace('(solve | cases h <;> rfl)','(solve | cases h; exact mark_mono _ _) | (solve | cases h; exact demand_refl _)')
a=old.index('private theorem arg_no_break');b=old.index('private theorem branch_frame',a);nb=old[a:b]
a=old.index('private theorem branch_frame');b=old.index('private theorem fold_fields_eq',a);branch=old[a:b].replace('branch_frame','branch_demand').replace('frame next = frame st','DemandLE st next').replace('forIn_frame (fun a : State × Array Reg => frame a.1)','forIn_demand (fun a : State × Array Reg => a.1)').replace('(arg_frame','(arg_demand')
a=old.index('private theorem fold_fields_eq');b=old.index('private theorem outgoing_frame',a);fold=old[a:b].replace('fold_fields_eq','fold_demand').replace('{α β γ : Type} (field : α → γ)','{α β : Type} (field : α → State)').replace('field next = field a','DemandLE (field a) (field next)').replace('cases h; rfl','cases h; exact demand_refl _').replace('exact (ih h).trans (hs a x middle he)','exact demand_trans (hs a x middle he) (ih h)')
a=old.index('private theorem outgoing_frame');b=old.index('/-- Actual successor argument',a);out=old[a:b].replace('outgoing_frame','outgoing_demand').replace('frame next = frame st','DemandLE st next').replace('fold_fields_eq (fun a : State × Array (Array Reg) => frame a.1)','fold_demand (fun a : State × Array (Array Reg) => a.1)').replace('cases step; rfl','cases step; exact demand_refl _').replace('branch_frame call','branch_demand call')
public='''/-- All ordinary, returned and exceptional successor arguments preserve
previous demand, including the actual marking of ordinary source values. -/
theorem branch_args_demand_mono {ctx : Ctx} {st next : State} {block index : Nat}
    {args : Array Reg} (run : branchArgs ctx st block index = .ok (args,next)) :
    ∀ (x : Nat),st.demand[x]! ≤ next.demand[x]! := branch_demand run

/-- Actual outgoing collection preserves demand through direct and synthetic
successor rows, including returned values and exception payloads. -/
theorem outgoing_demand_mono {ctx : Ctx} {order : Order} {bi : Nat} {targets : Array Nat}
    {st next : State} {args : Array (Array Reg)}
    (run : collectOutgoing ctx order bi targets st = .ok (next,args)) :
    ∀ (x : Nat),st.demand[x]! ≤ next.demand[x]! := outgoing_demand run

'''
(root/'FV/Backend/Proof/StockCfgTraversalDemand.lean').write_text(header+mark+alias+loop+arg+am+nb+branch+fold+out+public+'end Backend.Stock.Proof.CfgDemand\n')
