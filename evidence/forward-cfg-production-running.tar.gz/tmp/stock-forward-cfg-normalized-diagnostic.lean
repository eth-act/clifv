import FV.Backend.Lowering.StockForwardCfgNI
import FV.Opt.Legalize128Pass
import FV.Clif.Parse
import Lean
open Backend

def main (args : List String) : IO Unit := do
  let paths := ((← IO.FS.readFile args[0]!).splitOn "\n").filter (!·.isEmpty)
  let mut rows := #[]
  let mut total := 0
  for path in paths do
    let original := Clif.parseFile (← IO.FS.readFile path)
    let parsed := (Opt.Legalize128.parsedFile128 original).file
    for source in parsed.funcs do
      if let .ok f := source.func then
        total := total+1
        if Stock.ForwardCfg.eligible f then
          let raw := Stock.lower f
          let sourceOk := Stock.ForwardCfg.sourceOk f
          let boundary := raw.toOption.any fun r => ABIReadCfg.check f.sig r.code
          let selected := Stock.ForwardCfg.lowerValidated f
          let previous := Stock.LinearCfg.lowerValidated f
          let actual := match raw,selected with
            | .ok r,.ok vc => decide (r.code = vc)
            | _,_ => false
          let sameCode := match selected,previous with
            | .ok vc,.ok old => decide (vc = old)
            | _,_ => false
          rows := rows.push (Lean.Json.mkObj [("path",Lean.toJson path),("function",Lean.toJson f.name),
            ("source_ok",Lean.toJson sourceOk),("lower_ok",Lean.toJson raw.isOk),
            ("boundary",Lean.toJson boundary),("actual_stock",Lean.toJson actual),
            ("previous_vcode_exact",Lean.toJson sameCode),
            ("previous_eligible",Lean.toJson (Stock.LinearCfg.eligible f || Stock.TwoBlock.Entry.eligible f)),
            ("body_lengths",Lean.toJson (f.blocks.map (·.body.length)))])
  IO.FS.writeFile args[1]! ((Lean.Json.mkObj [("parsed_functions",Lean.toJson total),("rows",Lean.Json.arr rows)]).compress)
  IO.println s!"actual normalized source: {total} functions, {rows.size} forward CFG eligible after actual CLI i128 legalization"
