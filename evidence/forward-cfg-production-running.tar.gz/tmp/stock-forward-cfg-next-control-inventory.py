from pathlib import Path
import os,json,subprocess,hashlib
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');os.chdir(root)
e=os.environ.copy();e.update(json.load(open('/tmp/stock-mixed-div-env.json')));e.update(FV_ROOT=str(root),FV_MEMCAP='8G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2')
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:2]);os.nice(10)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
with open('/tmp/stock-forward-cfg-next-control-inventory.log','w') as f:r=subprocess.run(['scripts/memcap.sh','lake','env','lean','--run','/tmp/stock-forward-cfg-next-control-inventory.lean','/tmp/stock-forward-cfg-normalized-inputs.txt','/tmp/stock-forward-cfg-next-control-inventory.json'],env=e,stdout=f,stderr=subprocess.STDOUT)
assert not r.returncode,r.returncode
p=Path('/tmp/stock-forward-cfg-next-control-inventory.json');d=json.loads(p.read_text());d['head']=head;d['limits']='Source-shape planning diagnostic only; no branch simulation/activation or match gain proved';p.write_text(json.dumps(d,indent=2)+'\n');rows=d['rows'];print({'conditional_instances':len(rows),'scalar_original_inputs':sum(r['original_input_checks'] for r in rows),'forward_scalar':sum(r['original_input_checks'] and r['source_forward_ranked'] for r in rows),'forward_scalar_empty_conditional_args':sum(r['original_input_checks'] and r['source_forward_ranked'] and r['empty_conditional_args'] for r in rows)})
