from pathlib import Path
import subprocess,os,tarfile,json,hashlib,datetime
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');os.chdir(root);os.nice(19);os.sched_setaffinity(0,[min(os.sched_getaffinity(0))])
def git(*args,input=None,env=None): return subprocess.check_output(['git',*args],input=input,env=env).decode().strip()
head=git('rev-parse','HEAD');branch='agent/stock-cfg-body-progress-20261025T025359Z';parent=git('rev-parse',branch)
assert not git('status','--porcelain')
assert git('ls-remote','origin','refs/heads/agent/stock-general-cfg-20261026').split()[0]==head
files=[p for pattern in ['stock-general-cfg*','stock-forward-cfg*'] for p in Path('/tmp').glob(pattern) if p.is_file() and p.suffix in {'.py','.json','.log','.md'}]
files += list(Path('/tmp/stock-general-cfg-traversal-axioms-v2').rglob('*'))
files += list(Path('/tmp/stock-general-cfg-forward-axioms-v1').rglob('*'))
files=[p for p in files if p.is_file()]
archive=Path('/tmp/stock-forward-cfg-production-running.tar.gz')
with tarfile.open(archive,'w:gz',compresslevel=1) as tf:
 for p in sorted(set(files)): tf.add(p,arcname=str(p).lstrip('/'),recursive=False)
 for name in git('diff','--name-only','ac302a8a','HEAD').splitlines():tf.add(root/name,arcname='repo/'+name,recursive=False)
assert archive.stat().st_size<40*1024*1024
blob=git('hash-object','-w',str(archive));env=os.environ.copy();index=Path('/tmp/stock-general-cfg-backup.index');index.unlink(missing_ok=True);env['GIT_INDEX_FILE']=str(index)
git('read-tree',parent,env=env);git('update-index','--add','--cacheinfo',f'100644,{blob},evidence/forward-cfg-production-running.tar.gz',env=env);tree=git('write-tree',env=env)
commit=git('commit-tree',tree,'-p',parent,'-m','Back up arbitrary-length forward CFG production candidate and running gates');git('update-ref','refs/heads/'+branch,commit,parent);subprocess.run(['git','push','origin',branch],check=True)
assert git('ls-remote','origin','refs/heads/'+branch).split()[0]==commit
receipt={'source_head':head,'branch':branch,'evidence_commit':commit,'archive_git_path':'evidence/forward-cfg-production-running.tar.gz','bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'prior_evidence_tree_preserved':True,'full_140_complete':False}
Path('/tmp/stock-forward-cfg-evidence-backup.json').write_text(json.dumps(receipt,indent=2)+'\n');index.unlink(missing_ok=True);print(json.dumps(receipt))
