from pathlib import Path
import os,json,sys,subprocess,hashlib,datetime
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');os.chdir(root);sys.path.insert(0,str(root/'scripts'))
from byte_compare import ELF
base=Path('/tmp/stock-forward-cfg-paired-main-v1');out=Path('/tmp/stock-forward-cfg-parent-regalloc-diagnostic');out.mkdir(exist_ok=False)
e=os.environ.copy();e.update(json.load(open('/tmp/stock-mixed-div-env.json')));e.update(FV_ROOT=str(root),FV_MEMCAP='8G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',LEAN_REGALLOC=str(root/'rust/target/release/lean-regalloc'))
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:2]);os.nice(10)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
provenance=json.load(open(base/'provenance.json'));changed=json.load(open('/tmp/stock-forward-cfg-new-activation-functions.json'));results=[]
for i,row in enumerate(changed):
 unit=base/row['cgu'];meta=json.load(open(unit/'captured/fv-link.json'));f=next(f for f in meta['functions'] if f['final']==row['fn'])
 original=next(p for p in provenance['original_sources'] if '/'+row['cgu']+'/split/' in p and Path(p).name==Path(f['dump']).name)
 digest=provenance['original_sources'][original];source=next(Path(p) for p,v in provenance['captured_inputs'].items() if v==digest and p.endswith('.clif') and '/'+row['cgu']+'/captured/' in p)
 target=out/(str(i)+'.o');log=out/(str(i)+'.log')
 with log.open('w') as stream:r=subprocess.run(['/tmp/stock-general-cfg-baseline/lean-backend',str(source),str(target),'--dead-cleanup','--personality','rust_eh_personality','--regalloc','regalloc2'],env=e,stdout=stream,stderr=subprocess.STDOUT)
 assert r.returncode==0,(row['fn'],log)
 actual=ELF(target);reference=ELF(unit/'captured/cgclif.o');a,ab=actual.function(f['symbol']);b,bb=reference.function(row['fn'])
 rel=lambda elf,s:[(x['offset'],x['type'],x['addend']) for x in elf.function_relocations(s,{})]
 equal=ab==bb and rel(actual,a)==rel(reference,b)
 asm={}
 for label,data in [('baseline_regalloc2',ab),('reference',bb)]:
  s=subprocess.run([e['LLVM_MC'],'--disassemble','-triple=aarch64','-mattr=+lse,+fp-armv8,+neon'],input=' '.join('0x%02x'%v for v in data),text=True,capture_output=True);assert s.returncode==0;asm[label]=s.stdout
 results.append({'function':row['fn'],'source':str(source),'baseline_regalloc2_exact':equal,'default_lean_exact':row['candidate_equal'],'disassembly':asm})
receipt={'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':'passed','diagnostic_functions':len(results),'regalloc2_exact':sum(r['baseline_regalloc2_exact'] for r in results),'default_lean_exact':sum(r['default_lean_exact'] for r in results),'candidate_backend_sha256':sha('/tmp/stock-general-cfg-baseline/lean-backend'),'regalloc2_oracle_sha256':sha(root/'rust/target/release/lean-regalloc'),'rows':results,'limits':'Diagnostic allocation-only setting on all ten newly activated captured instances; does not change default allocator or canonical900/4543 result; complete activation cohort, not whole-corpus regalloc2 exact count.'}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print({k:v for k,v in receipt.items() if k!='rows'})
