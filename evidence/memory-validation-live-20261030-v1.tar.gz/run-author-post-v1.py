from pathlib import Path
import subprocess,os,json,time,datetime
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');e=Path('/home/lee/clifv/.git/agent-evidence/stock-memory-20261029');os.chdir(root);source=json.loads((e/'author-source-v1.json').read_text());head=source['head'];state=e/'author-post-state-v1.json'
def save(status,**extra):state.write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),head=head,status=status,**extra),indent=2)+'\n')
try:
 save('waiting-for-runtime')
 while True:
  r=json.loads((e/'author-runtime-state-v1.json').read_text())
  if r['status']=='passed':break
  if r['status']=='failed':raise RuntimeError('Earlier runtime queue failed; post gates held')
  time.sleep(10)
 assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head
 assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
 env=json.loads((e/'author-env-v1.json').read_text());env.update(FV_MEMCAP='8G',FV_PIPELINE_T='0')
 gates=[]
 for name in ['check-public-headers-current','check-memory-axioms-current','reference-native-current','fixture-byte-binding-current','cli-native-current','memory-captured-inventory-current']:
  path=e/(name+'.py');gates.append(dict(id=name,argv=['python3',str(path)],inputs=[str(path)]))
 flags={'parameter':'--cfgparameter','conditional-forward':'--cfgconditionalforward','conditional':'--cfgconditional','forward':'--cfgforward','linear':'--cfglinear','scalar-entry':'--cfgscalarentry','entry':'--cfgentry','cfg':'--cfg'}
 for kind,flag in flags.items():
  gates.append(dict(id=kind+'-native',argv=['.lake/build/bin/stock-general-div-runtime',flag]))
  gates.append(dict(id=kind+'-compatibility',argv=['lake','env','lean','--run',str(e/'retained-matrix-current.lean'),kind],inputs=[str(e/'retained-matrix-current.lean')],requires=['STOCK_MEMORY_RETAINED_MATRIX_PASS']))
 outputs={'check-public-headers-current':e/'public-header-parity-current.json','check-memory-axioms-current':e/'memory-axiom-parity-current.json','reference-native-current':e/'reference-native-current/receipt.json','fixture-byte-binding-current':e/'fixture-byte-binding-current.json','cli-native-current':e/'cli-native-current/receipt.json','memory-captured-inventory-current':e/'memory-captured-inventory-current/receipt.json'}
 for g in gates:
  g['complete_inputs']=False
  if g['id'] in outputs:g['outputs']=[str(outputs[g['id']])]
 declared=[str(e/'memory-captured-inventory-current.lean'),str(e/'historical/stock-memory-production-paired-actual-v1/provenance.json'),str(e/'historical-root/**/*.unopt.clif'),str(e/'historical/stock-memory-production-header-parity-v1.json'),str(e/'historical-root/tmp/stock-memory-production-normal-gates-v1/all-axioms/stock-memory-source.log'),str(e/'author-normal-gates-v1/all-axioms/stock-memory-source.log'),str(e/'memory-integration-v1/receipt.json'),str(e/'memory-integration-v1/generated/**/*.lean'),str(e/'memory-integration-v1/generated/**/*.elf'),str(e/'memory-integration-v1/generated/**/*.clif'),str(e/'memory-integration-v1/generated/*.o'),str(e/'memory-integration-v1/memory-native.o'),str(e/'memory-integration-v1/memory-native.s')]
 tools=['lake','lean','python3',*[str(root/'.lake/build/bin'/name) for name in ['stock-general-div-runtime','lean-backend','lean-link','link-check','stock-memory-linked']],*[str(root/'rust/target/release'/name) for name in ['clif2obj','lean-regalloc','clif-native']],env['LLVM_MC'],env['CLIF_NATIVE_QEMU'],env['CLIF_NATIVE_LLD']]
 manifest=dict(packet='stock-memory-author-post-20261030',candidate=head,base=source['base'],env=env,tools=tools,inputs=declared+[str(p) for p in (root/'.lake/build/lib/lean').rglob('*.olean')],gates=gates,baselines=dict(full_140_complete=False))
 mp=e/'author-post-manifest-v1.json';mp.write_text(json.dumps(manifest,indent=2)+'\n');out=e/'author-post-gates-v1';save('running')
 with (e/'author-post-runner-v1.log').open('w') as log:
  r=subprocess.run(['python3','scripts/stock-delivery-gates.py','resume' if out.exists() else 'run',str(mp),'--root',str(root),'--out',str(out)],stdout=log,stderr=subprocess.STDOUT)
 save('passed' if r.returncode==0 else 'failed',returncode=r.returncode,scope='Header/memory AX parity, independent reference, final verified-byte bindings, actual CLI/default+Lean/native, eight retained native/default matrices. MCP and remaining review/whole-goal obligations are separate.')
except Exception as error:save('failed',error=str(error));raise
