from pathlib import Path
import subprocess,os,json,hashlib,tarfile,datetime
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');e=Path('/home/lee/clifv/.git/agent-evidence/stock-memory-20261029');os.chdir(root)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args,env=None):return subprocess.check_output(['git',*args],env=env,text=True).strip()
head=git('rev-parse','HEAD');assert head=='6e4ae6f6965ad9e125f0e5eb2c1f1fe50ecebf8b';assert not git('status','--porcelain')
snap=e/'validation-live-checkpoint-v1';snap.mkdir(exist_ok=False)
files=list((e/'author-normal-gates-v1').rglob('*'))
for name in ['author-source-v1.json','author-env-v1.json','author-normal-manifest-v1.json','author-normal-state-v1.json','author-runtime-state-v1.json','author-post-state-v1.json','run-author-normal-v1.py','run-author-runtime-v1.py','run-author-post-v1.py','watch-author-service.py','resume-current.json','status44.md','next-memory-reuse-current.md','memory-captured-inventory-current.py','memory-captured-inventory-current.lean','backup-validation-checkpoint-v1.py']:
 files.append(e/name)
manifest={}
for source in sorted(set(files)):
 if not source.is_file():continue
 relative=source.relative_to(e);dest=snap/relative;dest.parent.mkdir(exist_ok=True,parents=True);dest.write_bytes(source.read_bytes());manifest[str(relative)]=sha(dest)
report=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),head=head,state='INCOMPLETE snapshot: normal build running; runtime and post queues wait. No completed author gate or original140 completion claim.',files=manifest)
mp=e/'validation-live-checkpoint-v1.json';mp.write_text(json.dumps(report,indent=2)+'\n');archive=e/'validation-live-checkpoint-v1.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=1) as t:
 for relative in manifest:t.add(snap/relative,arcname=relative,recursive=False)
 t.add(mp,arcname='checkpoint.json',recursive=False)
with tarfile.open(archive) as t:
 for relative,digest in manifest.items():assert hashlib.sha256(t.extractfile(relative).read()).hexdigest()==digest
b='agent/stock-cfg-body-progress-20261025T025359Z';parent=git('rev-parse',b);idx=e/'validation-checkpoint.index';idx.unlink(missing_ok=True);env=dict(os.environ,GIT_INDEX_FILE=str(idx));git('read-tree',parent,env=env)
for p,key in [(mp,'evidence/memory-validation-live-20261030-v1.json'),(archive,'evidence/memory-validation-live-20261030-v1.tar.gz')]:git('update-index','--add','--cacheinfo','100644,'+git('hash-object','-w',str(p))+','+key,env=env)
c=git('commit-tree',git('write-tree',env=env),'-p',parent,'-m','Back up incomplete memory author validation logs and exit watchers');git('update-ref','refs/heads/'+b,c,parent);subprocess.run(['git','push','origin',b],check=True);assert git('ls-remote','origin','refs/heads/'+b).split()[0]==c
assert hashlib.sha256(subprocess.check_output(['git','show',c+':evidence/memory-validation-live-20261030-v1.tar.gz'])).hexdigest()==sha(archive)
idx.unlink();receipt=dict(commit=c,remote_verified=True,files=len(manifest),archive_sha256=sha(archive),archive_bytes=archive.stat().st_size);(e/'validation-live-backup-receipt-v1.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
# The verified archive preserves every copied byte. Retire duplicate staging.
import shutil
shutil.rmtree(snap)
