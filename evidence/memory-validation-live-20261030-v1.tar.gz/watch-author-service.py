import subprocess,sys,time,json
from pathlib import Path
service,state_path,log_path=sys.argv[1:]
while True:
 r=subprocess.run(['systemctl','--user','show',service,'-p','ActiveState','-p','MainPID'],text=True,capture_output=True)
 props=dict(line.split('=',1) for line in r.stdout.splitlines() if '=' in line)
 if props.get('ActiveState') not in ('active','activating','deactivating') or props.get('MainPID')=='0':break
 time.sleep(5)
p=Path(state_path)
try:state=json.loads(p.read_text())
except Exception as error:state={'status':'unknown','error':str(error)}
print(service,json.dumps(state),flush=True)
log=Path(log_path)
if log.exists():print('\n'.join(log.read_text().splitlines()[-25:]),flush=True)
sys.exit(0 if state.get('status')=='passed' else 1)
