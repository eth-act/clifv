Next-batch source note (not validation):
- Reuse existing Backend.Stock.Proof.MaskBody.actual_nop_record_at_block in StockMaskBlockRecords. The older saved StockMemoryNopRecords draft duplicates it and is superseded; preserve archive but do not install duplicate.
- StockMemoryRetainedReturnSpec draft derives arbitrary-index returned load and classifies every real body record as that load or an actual omitted NOP. It reuses returned-definition demand and unique source positions, with inherited parameter pointer support. Must build and witness after current frozen gates release lanes.
- StockMemoryOmittedPairedScan draft composes existing one-world omission in both initialized worlds. Must build/witness before using.
- These are internal derivations, not external accepted-input premises. Next compose guarded/paired body, entry jump/inherited values, return and actual captured PC0 witness, then provider/checker/production/full gates. Old theorem variants remain.
- Current memory author HEAD remains6e4; no tracked edits or current production class expansion while gates run.

Prepared StockMemoryNopReturnBody and StockMemoryNopPairedBody compose those actual records through the existing ScansSpec fall_refines. Both are UNVALIDATED drafts and must receive actual captured non-vacuity/PC0 witnesses and compiled axiom checks after the frozen batch. No production coverage claim.

CFG boundary found on revision6e4:
- `Control.jump_body_returns_at` requires `MaskBody.Family` in every original block.
- `Inherited.scalar_jump_carry_returns_defined` also requires `CastComplete.MemoryFormat` in every block.
- `CastComplete.MemoryFormat` excludes both LoadNoOffset and Load. A captured memory successor cannot satisfy it.
- Do not try to satisfy this premise with an extra source assumption.
- `Inherited.jump_continuation_defined` is public and supports an independently proved body.
- `Inherited.local_jump_carry_returns_defined` is private. Its body uses the local source execution and the public jump continuation.
- Add an internal ordinary-body composition variant that reuses that continuation. Derive the entry NOP execution from actual omitted records.
- `OrdinaryBody.actual_ordinary_return_refines_at` already supports memory bodies, but yields RunOkABI. The CFG uses RunOkABIAt with per-successor arguments.
- Add the corresponding per-successor variant while retaining the old public theorem.
