
.text
.global _start
_start:
  adrp x19, test_data
  add x19, x19, :lo12:test_data
  add x19, x19, #1
  mov w20, #0xa5a5
  movk w20, #0xa5a5, lsl #16
  mov x22, #2048
1:
  and x21, x20, #0xff
  and x21, x21, #0xffffffff
  str w20, [x19]
  mov x0, x19
  bl memory_load0
  and x0, x0, #0xffffffff
  cmp x0, x21
  b.ne 2f
  mov x0, #0xdead
  mov x1, x19
  bl memory_load1
  and x0, x0, #0xffffffff
  cmp x0, x21
  b.ne 2f
  mov x0, #0x1234
  bl memory_retained
  mov x21, #0x1234
  cmp x0, x21
  b.ne 2f
  add w20, w20, #123
  ror w20, w20, #7
  subs x22, x22, #1
  b.ne 1b
  mov x0, #0
  b 3f
2:
  mov x0, #1
3:
  mov x8, #93
  svc #0
.data
.balign 16
test_data:
  .quad 0
  .quad 0
