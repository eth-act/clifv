private def sinkEnv : Isle.Interp.Env V := #[some (.inst 0),none]
private def explicitInput : State :=
  { scanState built.2.2 0 with color := some ((scanState built.2.2 0).entryColor[0]!+1) }
private def explicitNext : State :=
  { explicitInput with color := some explicitInput.entryColor[0]!,
    sunk := explicitInput.sunk.set! 0 true }

private theorem direct_run :
    (evalExpr program (Stock.sem built.1) {} 3 (.term 13 236 [.var 18 0]) sinkEnv).run
      (explicitInput,#[]) = .ok (some (.op .unit),explicitNext,#[]) := by
  simp only [evalExpr,evalArgs,applyTerm,data_program.t236,Stock.sem,T.sink_inst,isel_monad]
  rfl

private theorem let_run :
    (evalExpr program (Stock.sem built.1) {} 8
      (.let 4 [(1,13,.term 13 236 [.var 18 0])] (.constInt 4 7)) sinkEnv).run
      (explicitInput,#[]) = .ok (some (.int 7),explicitNext,#[]) := by
  simp only [evalExpr,evalBinds,evalArgs,applyTerm,data_program.t236,Stock.sem,T.sink_inst,isel_monad]
  rfl

/-- The external sink helper really can change bit zero, even in a load-free
context. The generated-rule exclusion is therefore necessary. The full let-RHS
frame protects a distinct, allocated bit while that real sink executes. -/
attribute [local irreducible] built function in
theorem explicit_sink_other_witness :
    explicitNext.sunk[0]! = true ∧ explicitNext.sunk[1]! = false ∧
    explicitNext.sunk[1]! = explicitInput.sunk[1]! := by
  have direct := sink_expr_other (i := 1) (by rfl) (by decide) direct_run
  have whole := sink_let_other (i := 1) (blocked := blocked)
    (fun m _ => (no_load_frames no_loads m).mono
      (fun _ _ same => congrArg (fun bits : Array Bool => bits[1]!) same))
    (by rfl) (by decide) (by rfl) let_run
  exact ⟨by rfl,by rfl,whole⟩

end Backend.Stock.Proof.SinkRules.Witness
