import FV.Backend.Proof.StockNoLoadSink
import FV.Backend.Proof.StockSinkRuleRhs
import FV.Backend.Proof.LowerDecide
import FV.E2E.StockDivFixtures

namespace Backend.Stock.Proof.SinkRules.Witness
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64 Isle.Interp.RuleFrame
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000

/-- The original nine arguments and explicit stack slot are retained. The
division's result is unused: the source returns an original argument instead. -/
def function : Clif.Function :=
  let original := E2E.StockDivNIWitness.function .defaultI64 .sdiv
  { original with name := "stock_unused_div_no_sink", blocks := original.blocks.map fun b =>
    { b with term := .ret [1] } }

private def built : Ctx × Array (Nat × Nat) × State :=
  (Stock.buildCtx function).toOption.getD (sinkCtx,#[],sinkState)

private theorem built_run : Stock.buildCtx function = .ok built := by rfl


end Backend.Stock.Proof.SinkRules.Witness
