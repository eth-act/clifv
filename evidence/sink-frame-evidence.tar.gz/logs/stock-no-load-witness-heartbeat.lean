import FV.Backend.Proof.StockNoLoadSink
import FV.Backend.Proof.StockSinkRuleRhs
import FV.Backend.Proof.LowerDecide
import FV.E2E.StockDivFixtures

namespace Backend.Stock.Proof.SinkRules.Witness
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64 Isle.Interp.RuleFrame
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm

/-- The original nine arguments and explicit stack slot are retained. The
division's result is unused: the source returns an original argument instead. -/
def function : Clif.Function :=
  let original := E2E.StockDivNIWitness.function .defaultI64 .sdiv
  { original with name := "stock_unused_div_no_sink", blocks := original.blocks.map fun b =>
    { b with term := .ret [1] } }

private def built : Ctx × Array (Nat × Nat) × State :=
  (Stock.buildCtx function).toOption.getD (sinkCtx,#[],sinkState)

private theorem built_run : Stock.buildCtx function = .ok built := by rfl

private theorem no_loads : NoLoadData built.1 := by
  intro i info found fmt fields load decoded
  have member : info ∈ built.1.insts.toList :=
    Array.mem_toList_iff.mpr (Array.mem_of_getElem? found)
  have table : built.1.insts.toList = [built.1.insts[0]!,built.1.insts[1]!] := by rfl
  rw [table] at member
  simp only [List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · have data : ∃ values, (built.1.insts[0]!).data = .data 152 2 values := ⟨_,rfl⟩
    obtain ⟨values,data⟩ := data
    rcases load with rfl | rfl <;> simp [Backend.sem, data] at decoded
  · have data : (built.1.insts[1]!).data = .op .unit := rfl
    simp [Backend.sem, data] at decoded

private theorem scope : LowerScope function := lowerScope_of (by decide +kernel)

private def observed : Bool :=
  match Stock.runTerm built.1 "lower" [.inst 0] (scanState built.2.2 0) with
  | .error _ => false
  | .ok (out,next,_) => out.isSome &&
      decide ((scanState built.2.2 0).demand[100]! = 0) &&
      decide ((scanState built.2.2 0).sunk[0]! = false) &&
      decide (next.base.emitted.size > (scanState built.2.2 0).base.emitted.size)

private theorem observed_true : observed = true := by native_decide

/-- A real unused division with original stack arguments emits code. Its
complete helper execution inhabits the generic no-load frame without demand. -/
set_option maxHeartbeats 10000 in
attribute [local irreducible] built function in
theorem unused_division_witness : ∃ out next trace,
    Stock.buildCtx function = .ok built ∧ LowerScope function ∧
    NoLoadData built.1 ∧
    Stock.runTerm built.1 "lower" [.inst 0] (scanState built.2.2 0) = .ok (some out,next,trace) ∧
    (scanState built.2.2 0).demand[100]! = 0 ∧
    (scanState built.2.2 0).sunk[0]! = false ∧
    next.base.emitted.size > (scanState built.2.2 0).base.emitted.size ∧
    next.sunk = (scanState built.2.2 0).sunk := by
  have checked := observed_true
  unfold observed at checked
  cases run : Stock.runTerm built.1 "lower" [.inst 0] (scanState built.2.2 0) with
  | error message => rw [run] at checked; cases checked
  | ok result =>
    obtain ⟨out,next,trace⟩ := result
    rw [run] at checked
    simp only [Bool.and_eq_true, decide_eq_true_eq] at checked
    cases out with
    | none => simp at checked
    | some out =>
      refine ⟨out,next,trace,built_run,scope,no_loads,?_,?_,?_,?_,?_⟩
      · exact run
      · exact checked.1.1.2
      · exact checked.1.2
      · exact checked.2
      · have freeContext := no_loads
        generalize contextEq : built.1 = ctx at freeContext run
        generalize inputEq : scanState built.2.2 0 = input at run ⊢
        exact no_load_lower freeContext run



end Backend.Stock.Proof.SinkRules.Witness
