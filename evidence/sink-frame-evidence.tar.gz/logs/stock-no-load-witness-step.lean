import FV.Backend.Proof.StockNoLoadSink
import FV.Backend.Proof.StockSinkRuleRhs
import FV.Backend.Proof.LowerDecide
import FV.E2E.StockDivFixtures

namespace Backend.Stock.Proof.SinkRules.Witness
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64 Isle.Interp.RuleFrame
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm

/-- The original nine arguments and explicit stack slot are retained. The
division's result is unused: the source returns an original argument instead. -/
def function : Clif.Function :=
  let original := E2E.StockDivNIWitness.function .defaultI64 .sdiv
  { original with name := "stock_unused_div_no_sink", blocks := original.blocks.map fun b =>
    { b with term := .ret [1] } }

private def built : Ctx × Array (Nat × Nat) × State :=
  (Stock.buildCtx function).toOption.getD (sinkCtx,#[],sinkState)

private theorem built_run : Stock.buildCtx function = .ok built := by rfl

private theorem no_loads : NoLoadData built.1 := by
  intro i info found fmt fields load decoded
  have member : info ∈ built.1.insts.toList :=
    Array.mem_toList_iff.mpr (Array.mem_of_getElem? found)
  have table : built.1.insts.toList = [built.1.insts[0]!,built.1.insts[1]!] := by rfl
  rw [table] at member
  simp only [List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · have data : ∃ values, (built.1.insts[0]!).data = .data 152 2 values := ⟨_,rfl⟩
    obtain ⟨values,data⟩ := data
    rcases load with rfl | rfl <;> simp [Backend.sem, data] at decoded
  · have data : (built.1.insts[1]!).data = .op .unit := rfl
    simp [Backend.sem, data] at decoded

private def observed : Bool :=
  match Stock.runTerm built.1 "lower" [.inst 0] (scanState built.2.2 0) with
  | .error _ => false
  | .ok (out,next,_) => out.isSome &&
      decide ((scanState built.2.2 0).demand[100]! = 0) &&
      decide ((scanState built.2.2 0).sunk[0]! = false) &&
      decide (next.base.emitted.size > (scanState built.2.2 0).base.emitted.size)

private theorem observed_true : observed = true := by native_decide

/-- A real unused division with original stack arguments emits code. Its
complete helper execution inhabits the generic no-load frame without demand. -/
theorem unused_division_witness : ∃ out next trace,
    Stock.buildCtx function = .ok built ∧ LowerScope function ∧
    NoLoadData built.1 ∧
    Stock.runTerm built.1 "lower" [.inst 0] (scanState built.2.2 0) = .ok (some out,next,trace) ∧
    (scanState built.2.2 0).demand[100]! = 0 ∧
    (scanState built.2.2 0).sunk[0]! = false ∧
    next.base.emitted.size > (scanState built.2.2 0).base.emitted.size ∧
    next.sunk = (scanState built.2.2 0).sunk := by
  run_tac IO.FS.writeFile "/tmp/stock-no-load-witness-step.txt" "have"
  have checked := observed_true
  run_tac IO.FS.writeFile "/tmp/stock-no-load-witness-step.txt" "unfold"
  unfold observed at checked
  run_tac IO.FS.writeFile "/tmp/stock-no-load-witness-step.txt" "cases"
  cases run : Stock.runTerm built.1 "lower" [.inst 0] (scanState built.2.2 0) with
  | error message => rw [run] at checked; cases checked
  | ok result =>
    obtain ⟨out,next,trace⟩ := result
    run_tac IO.FS.writeFile "/tmp/stock-no-load-witness-step.txt" "rw"
    rw [run] at checked
    run_tac IO.FS.writeFile "/tmp/stock-no-load-witness-step.txt" "simp"
    simp only [Bool.and_eq_true, decide_eq_true_eq] at checked
    run_tac IO.FS.writeFile "/tmp/stock-no-load-witness-step.txt" "out"
    cases out with
    | none => simp at checked
    | some out =>
      run_tac IO.FS.writeFile "/tmp/stock-no-load-witness-step.txt" "tuple"
      exact ⟨out,next,trace,built_run,lowerScope_of (by decide +kernel),no_loads,
        run,checked.1.1.2,checked.1.2,checked.2,no_load_lower no_loads run⟩

private def sinkEnv : Isle.Interp.Env V := #[some (.inst 0),none]
private def explicitInput : State :=
  { scanState built.2.2 0 with color := some ((scanState built.2.2 0).entryColor[0]!+1) }
private def explicitNext : State :=
  { explicitInput with color := some explicitInput.entryColor[0]!,
    sunk := explicitInput.sunk.set! 0 true }

private theorem direct_run :
    (evalExpr program (Stock.sem built.1) {} 3 (.term 13 236 [.var 18 0]) sinkEnv).run
      (explicitInput,#[]) = .ok (some (.op .unit),explicitNext,#[]) := by
  simp only [evalExpr,evalArgs,applyTerm,data_program.t236,Stock.sem,T.sink_inst,isel_monad]
  rfl

private theorem let_run :
    (evalExpr program (Stock.sem built.1) {} 8
      (.let 4 [(1,13,.term 13 236 [.var 18 0])] (.constInt 4 7)) sinkEnv).run
      (explicitInput,#[]) = .ok (some (.int 7),explicitNext,#[]) := by
  simp only [evalExpr,evalBinds,evalArgs,applyTerm,data_program.t236,Stock.sem,T.sink_inst,isel_monad]
  rfl

/-- The external sink helper really can change bit zero, even in a load-free
context. The generated-rule exclusion is therefore necessary. The full let-RHS
frame protects a distinct, allocated bit while that real sink executes. -/
theorem explicit_sink_other_witness :
    explicitNext.sunk[0]! = true ∧ explicitNext.sunk[1]! = false ∧
    explicitNext.sunk[1]! = explicitInput.sunk[1]! := by
  have direct := sink_expr_other (i := 1) (by rfl) (by decide) direct_run
  have whole := sink_let_other (i := 1) (blocked := blocked)
    (fun m _ => (no_load_frames no_loads m).mono
      (fun _ _ same => congrArg (fun bits : Array Bool => bits[1]!) same))
    (by rfl) (by decide) (by rfl) let_run
  exact ⟨by rfl,by rfl,whole⟩

end Backend.Stock.Proof.SinkRules.Witness
