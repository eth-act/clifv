from pathlib import Path
src=Path('FV/Backend/Proof/IselFlowGen.lean').read_text()
a=src.index('structure PresAt');b=src.index('\nend Pres',a)
s=src[a:b].replace('PresAt','CtorFreeAt').replace('theorem presAt','theorem ctorFreeAt')
# Only add conditions to evaluations that may directly call the blocked constructor.
s=s.replace('→\n    R s s\'','→\n    R s s\'')
s=s.replace("expr : ∀ e env s tr r s' tr', (evalExpr", "expr : ∀ e env s tr r s' tr', exprCtorFree p blocked e = true → (evalExpr")
s=s.replace("args : ∀ es env s tr r s' tr', (evalArgs", "args : ∀ es env s tr r s' tr', argsCtorFree p blocked es = true → (evalArgs")
s=s.replace("binds : ∀ bs env s tr r s' tr', (evalBinds", "binds : ∀ bs env s tr r s' tr', bindsCtorFree p blocked bs = true → (evalBinds")
s=s.replace("apply : ∀ ty t vs s tr r s' tr', (applyTerm", "apply : ∀ ty t vs s tr r s' tr', termCtorFree p blocked t = true → (applyTerm")
s=s.replace("mrule : ∀ rl vs s tr r s' tr', (matchRule", "mrule : ∀ rl vs s tr r s' tr', ifletsCtorFree p blocked rl.iflets = true → (matchRule")
s=s.replace("iflets : ∀ ils env s tr r s' tr', (matchIfLets", "iflets : ∀ ils env s tr r s' tr', ifletsCtorFree p blocked ils = true → (matchIfLets")
s=s.replace("tryr : ∀ rl vs s tr r s' tr', (tryRule", "tryr : ∀ rl vs s tr r s' tr', ifletsCtorFree p blocked rl.iflets = true → (tryRule")
s=s.replace("select : ∀ term rs vs s tr r s' tr', (selectRule", "select : ∀ term rs vs s tr r s' tr', (∀ rl ∈ rs, ifletsCtorFree p blocked rl.iflets = true) → (selectRule")
s=s.replace("CtorFreeAt p sem cfg R n", "CtorFreeAt p sem cfg blocked R n")
s=s.replace("(hctor : ∀ term vs s v s', sem.ctor term vs s = .ok (v, s') → R s s') :", """(hctor : ∀ term vs s v s', blocked term = false → sem.ctor term vs s = .ok (v, s') → R s s')
    (noOverlap : cfg.checkOverlap = false)
    (special : Rule → Prop)
    (rules : ∀ t rl, rl ∈ p.rulesOf t → ifletsCtorFree p blocked rl.iflets = true ∧
      (exprCtorFree p blocked rl.rhs = true ∨ special rl))
    (exceptional : ∀ rl, special rl → ∀ m n vs env s tr mid trm out s' tr',
      (matchRule p sem cfg m rl vs).run (s,tr) = .ok (some env,mid,trm) →
      (evalExpr p sem cfg n rl.rhs env).run (mid,trm) = .ok (out,s',tr') → R s s') :""")
# Guards in proof entry points, then structurally split syntax guards.
for text in ['intro e env s tr r s\' tr\' h','intro es env s tr r s\' tr\' h','intro bs env s tr r s\' tr\' h','intro ty t vs s tr r s\' tr\' h','intro rl vs s tr r s\' tr\' h','intro ils env s tr r s\' tr\' h','intro term rs vs s tr r s\' tr\' h']:
 s=s.replace(text,text[:-1]+'free h')
s=s.replace('rw [evalExpr.eq_6] at h', 'have parts := Bool.and_eq_true.mp free\n        rw [evalExpr.eq_6] at h')
s=s.replace('rw [evalExpr.eq_7] at h', 'have parts := Bool.and_eq_true.mp free\n        rw [evalExpr.eq_7] at h')
s=s.replace('have r1 := ih.binds _ _ _ _ _ _ _ h1','have r1 := ih.binds _ _ _ _ _ _ _ parts.1 h1')
s=s.replace('(ih.expr _ _ _ _ _ _ _ h2)','(ih.expr _ _ _ _ _ _ _ parts.2 h2)')
s=s.replace('have r1 := ih.args _ _ _ _ _ _ _ h1','have r1 := ih.args _ _ _ _ _ _ _ parts.2 h1')
s=s.replace('(ih.apply _ _ _ _ _ _ _ _ h2)','(ih.apply _ _ _ _ _ _ _ _ parts.1 h2)')
s=s.replace('| cons e es =>\n        rw [evalArgs.eq_3]', '| cons e es =>\n        have parts := Bool.and_eq_true.mp free\n        rw [evalArgs.eq_3]')
s=s.replace('have r1 := ih.expr _ _ _ _ _ _ _ h1','have r1 := ih.expr _ _ _ _ _ _ _ parts.1 h1')
s=s.replace('have r2 := ih.args _ _ _ _ _ _ _ h3','have r2 := ih.args _ _ _ _ _ _ _ parts.2 h3')
s=s.replace('obtain ⟨x, ty, e⟩ := b\n        rw', 'obtain ⟨x, ty, e⟩ := b\n        have parts := Bool.and_eq_true.mp free\n        rw')
s=s.replace('(ih.binds _ _ _ _ _ _ _ h2)','(ih.binds _ _ _ _ _ _ _ parts.2 h2)')
s=s.replace('obtain ⟨_, -, he⟩ := liftM_ok h1\n      cases he', 'obtain ⟨_, found, he⟩ := liftM_ok h1\n      cases he')
s=s.replace('exact hctor _ _ _ _ _ hc', 'exact hctor _ _ _ _ _ (termCtorFree_lookup free found) hc')
start=s.index('        · obtain ⟨sel,');end=s.index('      · exact (throw_ok h2).elim',start)
s=s[:start]+'''        · obtain ⟨sel, ⟨s2, tr2⟩, h3, h4⟩ := bind_ok h2
          have r1 := ih.select _ _ _ _ _ _ _ _ (fun rl member => (rules t rl member).1) h3
          cases sel with
          | none =>
            simp only at h4
            split at h4
            · cases pure_ok h4; exact r1
            · exact (throw_ok h4).elim
          | some selected =>
            obtain ⟨rl,env⟩ := selected
            simp only at h4
            obtain ⟨ev, ⟨s3, tr3⟩, h5, h6⟩ := bind_ok h4
            obtain ⟨member,m,bound,matched⟩ := selectRule_some noOverlap h3
            have r2 : R s s3 := by
              rcases (rules t rl member).2 with safe | chosen
              · exact htrans _ _ _ r1 (ih.expr _ _ _ _ _ _ _ safe h5)
              · exact exceptional rl chosen m n vs env s tr s2 tr2 ev s3 tr3 matched h5
            split at h6
            · obtain ⟨u, ⟨s4, tr4⟩, h7, h8⟩ := bind_ok h6
              have hf := fire_ok h7
              cases pure_ok h8
              simp only at hf
              subst hf
              exact r2
            · cases pure_ok h6; exact r2
''' +s[end:]
s=s.replace('exact ih.iflets _ _ _ _ _ _ _ h4', 'exact ih.iflets _ _ _ _ _ _ _ free h4')
s=s.replace('| cons il ils =>\n        rw', '| cons il ils =>\n        have parts := Bool.and_eq_true.mp free\n        rw')
s=s.replace('(ih.iflets _ _ _ _ _ _ _ h6)','(ih.iflets _ _ _ _ _ _ _ parts.2 h6)')
s=s.replace('exact ih.mrule _ _ _ _ _ _ _ hm','exact ih.mrule _ _ _ _ _ _ _ free hm')
s=s.replace('have r1 := ih.tryr _ _ _ _ _ _ _ h1','have r1 := ih.tryr _ _ _ _ _ _ _ (free rl (List.mem_cons_self ..)) h1')
s=s.replace('(ih.select _ _ _ _ _ _ _ _ h2)','(ih.select _ _ _ _ _ _ _ _ (fun r member => free r (List.mem_cons_of_mem _ member)) h2)')
# With overlap disabled, no extra attempted match affects the chosen state.
a=s.index('          simp only at h2\n          split at h2',s.index('    · -- selectRule'))
s=s[:a]+'''          simp only [noOverlap, Bool.false_eq_true, ↓reduceIte] at h2
          cases pure_ok h2; exact r1
'''
header='''import FV.Backend.Proof.IselFlowGen

/-! A constructor frame with complete matched-rule exceptions. Syntax checks are
internal proof obligations; callers still run the original interpreter/program. -/
namespace Isle.Interp.RuleFrame
open Isle.Interp
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 8192
set_option maxHeartbeats 4000000

def termCtorFree (p : Program) (blocked : Term → Bool) (t : TermId) : Bool :=
  match p.term? t with | none => true | some term => !blocked term

mutual
 def exprCtorFree (p : Program) (blocked : Term → Bool) : Expr → Bool
  | .term _ t args => termCtorFree p blocked t && argsCtorFree p blocked args
  | .let _ binds body => bindsCtorFree p blocked binds && exprCtorFree p blocked body
  | _ => true
 def argsCtorFree (p : Program) (blocked : Term → Bool) : List Expr → Bool
  | [] => true
  | e :: es => exprCtorFree p blocked e && argsCtorFree p blocked es
 def bindsCtorFree (p : Program) (blocked : Term → Bool) : List (VarId × TypeId × Expr) → Bool
  | [] => true
  | (_,_,e) :: rest => exprCtorFree p blocked e && bindsCtorFree p blocked rest
end

def ifletsCtorFree (p : Program) (blocked : Term → Bool) (ils : List IfLet) : Bool :=
  ils.all (fun il => exprCtorFree p blocked il.rhs)

private theorem termCtorFree_lookup {p : Program} {blocked : Term → Bool} {t : TermId}
    {term : Term} (free : termCtorFree p blocked t = true) (found : termOf p t = .ok term) :
    blocked term = false := by
  unfold termOf at found
  unfold termCtorFree at free
  cases lookup : p.term? t with
  | none => simp [lookup] at found
  | some actual =>
    simp only [lookup, pure, Except.pure, Except.ok.injEq] at found
    subst actual
    simpa only [lookup, Bool.not_eq_true] using free

variable {V σ : Type} (p : Program) (sem : Sem V σ) (cfg : Config)
variable (blocked : Term → Bool) (R : σ → σ → Prop)
'''
# Parameters must be explicit in the structure, implicit for the theorem.
s=s.replace('variable {p sem cfg R}', 'variable {p sem cfg blocked R}')
Path('FV/Backend/Proof/StockRuleFrame.lean').write_text(header+s+'\nend Isle.Interp.RuleFrame\n')
