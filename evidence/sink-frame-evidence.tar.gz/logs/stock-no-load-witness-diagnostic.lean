import FV.Backend.Proof.StockNoLoadSink
import FV.Backend.Proof.StockSinkRuleRhs
import FV.Backend.Proof.LowerDecide
import FV.E2E.StockDivFixtures

namespace Backend.Stock.Proof.SinkRules.Witness
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64 Isle.Interp.RuleFrame
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000

/-- The original nine arguments and explicit stack slot are retained. The
division's result is unused: the source returns an original argument instead. -/
def function : Clif.Function :=
  let original := E2E.StockDivNIWitness.function .defaultI64 .sdiv
  { original with name := "stock_unused_div_no_sink", blocks := original.blocks.map fun b =>
    { b with term := .ret [1] } }

#eval IO.eprintln "checking built"
private def built : Ctx × Array (Nat × Nat) × State :=
  (Stock.buildCtx function).toOption.getD (sinkCtx,#[],sinkState)

#eval IO.eprintln "checking built_run"
private theorem built_run : Stock.buildCtx function = .ok built := by rfl

#eval IO.eprintln "checking no_loads"
private theorem no_loads : NoLoadData built.1 := by
  intro i info found fmt fields load decoded
  have member : info ∈ built.1.insts.toList :=
    Array.mem_toList_iff.mpr (Array.mem_of_getElem? found)
  have table : built.1.insts.toList = [built.1.insts[0]!,built.1.insts[1]!] := by rfl
  rw [table] at member
  simp only [List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl
  · have data : ∃ values, (built.1.insts[0]!).data = .data 152 1 values := ⟨_,rfl⟩
    obtain ⟨values,data⟩ := data
    rcases load with rfl | rfl <;> simp [Backend.sem, data] at decoded
  · have data : (built.1.insts[1]!).data = .op .unit := rfl
    simp [Backend.sem, data] at decoded

#eval IO.eprintln "checking observed"
private def observed : Bool :=
  match Stock.runTerm built.1 "lower" [.inst 0] (scanState built.2.2 0) with
  | .error _ => false
  | .ok (out,next,_) => out.isSome &&
      decide ((scanState built.2.2 0).demand[100]! = 0) &&
      decide ((scanState built.2.2 0).sunk[0]! = false) &&
      decide (next.base.emitted.size > (scanState built.2.2 0).base.emitted.size)

#eval IO.eprintln "checking observed_true"
private theorem observed_true : observed = true := by native_decide

/-- A real unused division with original stack arguments emits code. Its
complete helper execution inhabits the generic no-load frame without demand. -/
#eval IO.eprintln "checking unused_division_witness"
theorem unused_division_witness : ∃ out next trace,
    Stock.buildCtx function = .ok built ∧ LowerScope function ∧
    NoLoadData built.1 ∧
    Stock.runTerm built.1 "lower" [.inst 0] (scanState built.2.2 0) = .ok (some out,next,trace) ∧
    (scanState built.2.2 0).demand[100]! = 0 ∧
    (scanState built.2.2 0).sunk[0]! = false ∧
    next.base.emitted.size > (scanState built.2.2 0).base.emitted.size ∧
    next.sunk = (scanState built.2.2 0).sunk := by
  have checked := observed_true
  unfold observed at checked
  cases run : Stock.runTerm built.1 "lower" [.inst 0] (scanState built.2.2 0) with
  | error message => rw [run] at checked; cases checked
  | ok result =>
    obtain ⟨out,next,trace⟩ := result
    rw [run] at checked
    simp only [Bool.and_eq_true, decide_eq_true_eq] at checked
    cases out with
    | none => simp at checked
    | some out =>
      exact ⟨out,next,trace,built_run,lowerScope_of (by decide +kernel),no_loads,
        run,checked.1.1.2,checked.1.2,checked.2,no_load_lower no_loads run⟩

#eval IO.eprintln "checking sinkEnv"
private def sinkEnv : Isle.Interp.Env V := #[some (.inst 0),none]
#eval IO.eprintln "checking explicitNext"
private def explicitNext : State :=
  { scanState built.2.2 0 with color := some (scanState built.2.2 0).entryColor[0]!,
    sunk := (scanState built.2.2 0).sunk.set! 0 true }

#eval IO.eprintln "checking direct_run"
private theorem direct_run :
    (evalExpr program (Stock.sem built.1) {} 3 (.term 13 236 [.var 18 0]) sinkEnv).run
      (scanState built.2.2 0,#[]) = .ok (some (.op .unit),explicitNext,#[]) := by
  simp only [evalExpr,evalArgs,applyTerm,data_program.t236,Stock.sem,T.sink_inst,isel_monad]
  rfl

#eval IO.eprintln "checking let_run"
private theorem let_run :
    (evalExpr program (Stock.sem built.1) {} 8
      (.let 4 [(1,13,.term 13 236 [.var 18 0])] (.constInt 4 7)) sinkEnv).run
      (scanState built.2.2 0,#[]) = .ok (some (.int 7),explicitNext,#[]) := by
  simp only [evalExpr,evalBinds,evalArgs,applyTerm,data_program.t236,Stock.sem,T.sink_inst,isel_monad]
  rfl

/-- The external sink helper really can change bit zero, even in a load-free
context. The generated-rule exclusion is therefore necessary. The full let-RHS
frame protects a distinct, allocated bit while that real sink executes. -/
#eval IO.eprintln "checking explicit_sink_other_witness"
theorem explicit_sink_other_witness :
    explicitNext.sunk[0]! = true ∧ explicitNext.sunk[1]! = false ∧
    explicitNext.sunk[1]! = (scanState built.2.2 0).sunk[1]! := by
  have direct := sink_expr_other (i := 1) (by rfl) (by decide) direct_run
  have whole := sink_let_other (i := 1) (blocked := blocked)
    (fun m _ => (no_load_frames no_loads m).mono
      (fun _ _ same => congrArg (fun bits : Array Bool => bits[1]!) same))
    (by rfl) (by decide) (by rfl) let_run
  exact ⟨by rfl,by rfl,whole.trans direct.symm |>.trans direct⟩

end Backend.Stock.Proof.SinkRules.Witness
