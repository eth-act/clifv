from pathlib import Path
import subprocess,os,json,datetime
b=Path('/home/lee/clifv');e=b/'.git/agent-evidence/stock-memory-20261029';r=b/'.worktrees/stock-extending-production-20261031'
env=dict(os.environ);env.update(json.loads((e/'author-env-v1.json').read_text()));env.update(FV_ROOT=str(r),FV_MEMCAP='6G',LEAN_NUM_THREADS='1',OMP_NUM_THREADS='1',OMP_THREAD_LIMIT='1')
with (e/'integer-store-load-store-fixture-build-v1.log').open('w') as log:
 p=subprocess.run(['nice','-n','10',str(r/'scripts/memcap.sh'),'lake','build','FV.Backend.Proof.StockMemoryLoadStoreFixture'],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
(e/'integer-store-load-store-fixture-state-v1.json').write_text(json.dumps(dict(status='passed' if p.returncode==0 else 'failed',returncode=p.returncode,utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),indent=2)+'\n')
raise SystemExit(p.returncode)
