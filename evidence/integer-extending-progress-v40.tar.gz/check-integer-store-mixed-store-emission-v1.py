from pathlib import Path
import subprocess,os,json,time,datetime,hashlib
b=Path('/home/lee/clifv');e=b/'.git/agent-evidence/stock-memory-20261029';r=b/'.worktrees/stock-extending-production-20261031';state=e/'integer-store-mixed-store-emission-state-v1.json'
def save(status,**x):state.write_text(json.dumps(dict(status=status,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),**x),indent=2)+'\n')
try:
 while True:
  a=json.loads((e/'integer-store-mixed-records-full-audit-state-v2.json').read_text());assert a['status']!='failed',a
  if a['status']=='passed':break
  save('waiting',phase='811-full-audit');time.sleep(3)
 env=dict(os.environ);env.update(json.loads((e/'author-env-v1.json').read_text()));env.update(FV_ROOT=str(r),FV_MEMCAP='4G',LEAN_NUM_THREADS='1',OMP_NUM_THREADS='1',OMP_THREAD_LIMIT='1')
 source=r/'FV/Backend/Proof/StockStoreMixedRetention.lean';sha=hashlib.sha256(source.read_bytes()).hexdigest();save('running',source_hash=sha)
 with (e/'integer-store-mixed-store-emission-kernel-v1.log').open('w') as log:
  p=subprocess.run(['nice','-n','10',str(r/'scripts/memcap.sh'),'lake','build','FV.Backend.Proof.StockStoreMixedRetention'],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 assert p.returncode==0,p.returncode
 assert hashlib.sha256(source.read_bytes()).hexdigest()==sha
 save('passed',source_hash=sha,scope='Actual Lake build of guarded original-source whole-driver store unsunkness after successful language-server diagnostics. No function-wide no-load or caller execution certificate is added. Complete witnesses and full per-PR gates remain open.')
except BaseException as error:save('failed',error=repr(error));raise
