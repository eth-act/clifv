from pathlib import Path
import subprocess,os,json,datetime
b=Path('/home/lee/clifv');e=b/'.git/agent-evidence/stock-memory-20261029';r=b/'.worktrees/stock-extending-production-20261031';state=e/'integer-store-load-store-provider-imports-state-v1.json'
env=dict(os.environ);env.update(json.loads((e/'author-env-v1.json').read_text()));env.update(FV_ROOT=str(r),FV_MEMCAP='8G',LEAN_NUM_THREADS='1',OMP_NUM_THREADS='1',OMP_THREAD_LIMIT='1')
def save(status,**x):state.write_text(json.dumps(dict(status=status,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),**x),indent=2)+'\n')
try:
 save('running')
 p=subprocess.run(['nice','-n','10',str(r/'scripts/memcap.sh'),'python3','scripts/lake-serial-build.py','--budget','8G','--max-jobs','1','--max-cap','8G','--default-cap','4G','--out',str(e/'integer-store-load-store-provider-imports-v1'),'FV.Backend.Proof.StockMemoryLoadStoreCheck','FV.E2E.StockMemoryLoadStoreNI','FV.Backend.MemoryLoadStoreNIProduction'],cwd=r,env=env)
 assert p.returncode==0,p.returncode
 save('passed',scope='Focused actual module builds for selector soundness, source-to-machine paired NI and the new provider. Existing default consumers are not activated yet. Complete witnesses, dispatch integration and full per-PR gates remain open.')
except BaseException as error:save('failed',error=repr(error));raise
