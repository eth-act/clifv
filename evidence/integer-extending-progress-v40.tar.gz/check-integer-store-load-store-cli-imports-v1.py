from pathlib import Path
import subprocess,os,json,datetime
b=Path('/home/lee/clifv');e=b/'.git/agent-evidence/stock-memory-20261029';r=b/'.worktrees/stock-extending-production-20261031';state=e/'integer-store-load-store-cli-imports-state-v1.json'
env=dict(os.environ);env.update(json.loads((e/'author-env-v1.json').read_text()));env.update(FV_ROOT=str(r),FV_MEMCAP='6G',LEAN_NUM_THREADS='1',OMP_NUM_THREADS='1',OMP_THREAD_LIMIT='1')
files=['FVTest/Backend/Main.lean','FVTest/Backend/Lowering/Trace.lean','FVTest/E2E/LinkCheckMain.lean','FVTest/Link/LeanLinkMain.lean']
imports=sorted({line.split()[1] for name in files for line in (r/name).read_text().splitlines() if line.startswith('import ')})
def save(status,**x):state.write_text(json.dumps(dict(status=status,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),**x),indent=2)+'\n')
try:
 save('running',imports=imports)
 p=subprocess.run(['nice','-n','10',str(r/'scripts/memcap.sh'),'python3','scripts/lake-serial-build.py','--budget','6G','--max-jobs','1','--max-cap','6G','--default-cap','4G','--out',str(e/'integer-store-load-store-cli-imports-v1'),*imports],cwd=r,env=env)
 assert p.returncode==0,p.returncode
 save('passed',scope='Build the actual imports of all four changed CLI consumers before language-server checks. CLI executables, complete fixtures and full production validation remain open.')
except BaseException as error:save('failed',error=repr(error));raise
