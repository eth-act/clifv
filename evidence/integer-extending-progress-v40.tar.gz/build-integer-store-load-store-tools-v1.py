from pathlib import Path
import subprocess,os,json,datetime,hashlib
b=Path('/home/lee/clifv');e=b/'.git/agent-evidence/stock-memory-20261029';r=b/'.worktrees/stock-extending-production-20261031';state=e/'integer-store-load-store-tools-state-v1.json';records=[]
env=dict(os.environ);env.update(json.loads((e/'author-env-v1.json').read_text()));env.update(FV_ROOT=str(r),FV_MEMCAP='16G',LEAN_NUM_THREADS='2',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2')
names=subprocess.check_output(['git','diff','--name-only'],cwd=r,text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=r,text=True).splitlines();hashes={n:hashlib.sha256((r/n).read_bytes()).hexdigest() for n in names if (r/n).is_file()}
def save(status,**x):state.write_text(json.dumps(dict(status=status,records=records,source_hashes=hashes,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),**x),indent=2)+'\n')
try:
 args=['python3','scripts/lake-serial-build.py','--budget','16G','--max-jobs','2','--max-cap','16G','--default-cap','4G','--profile',str(r/'scripts/lake-module-peaks.tsv'),'--profile',str(e/'production-cold-overrides-v6.tsv'),'--out',str(e/'integer-store-load-store-tool-modules-v1'),'FV.Backend.Proof.StockMemoryLoadStoreCompatibility','FVTest.Backend.Main','FVTest.Backend.Lowering.Trace','FVTest.E2E.LinkCheckMain','FVTest.Link.LeanLinkMain','FVTest.E2E.Check']
 for label,args in [('modules',args),*[(tool,['lake','build',tool]) for tool in ['lean-backend','lean-backend-lowering-trace','link-check','lean-link','lean-e2e-check']]]:
  save('running',phase=label)
  with (e/('integer-store-load-store-build-'+label+'-v1.log')).open('w') as log:
   p=subprocess.run(['nice','-n','10',str(r/'scripts/memcap.sh'),*args],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
  records.append(dict(gate=label,returncode=p.returncode));assert p.returncode==0,records
 assert all(hashlib.sha256((r/n).read_bytes()).hexdigest()==h for n,h in hashes.items())
 save('passed',scope='Actual fresh compiler,lowering trace,both linker tools,and E2E checker after proper CLI diagnostics. New source/model witnesses and complete production validation remain open.')
except BaseException as error:save('failed',error=repr(error));raise
