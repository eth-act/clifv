from pathlib import Path
import os,json,hashlib,tarfile,datetime,subprocess
root=Path('/home/lee/clifv/.worktrees/stock-vector-measure-20261030');e=Path('/home/lee/clifv/.git/agent-evidence/stock-vector-measure-20261030');os.chdir(root)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args,env=None):return subprocess.check_output(['git',*args],env=env,text=True).strip()
files=[p for p in e.rglob('*') if p.is_file() and 'compiler' not in p.relative_to(e).parts and p.name not in ['evidence.tar.gz','evidence-manifest.json','backup-receipt.json','evidence.index']]
files=sorted(files);manifest=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),compiler_main='e9a91e8a84861c34f3e3c67ca053f280d2f9c921',diagnostic_fix=git('rev-parse','HEAD'),measurement=json.loads((e/'measurement-summary.json').read_text()),entrypoint=json.loads((e/'entrypoint-state.json').read_text()),files={str(p.relative_to(e)):sha(p) for p in files})
mp=e/'evidence-manifest.json';mp.write_text(json.dumps(manifest,indent=2)+'\n');archive=e/'evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=1) as t:
 for p in files+[mp]:t.add(p,arcname=str(p.relative_to(e)),recursive=False)
with tarfile.open(archive) as t:
 for p in files:assert hashlib.sha256(t.extractfile(str(p.relative_to(e))).read()).hexdigest()==manifest['files'][str(p.relative_to(e))]
b='agent/stock-cfg-body-progress-20261025T025359Z';parent=git('rev-parse',b);idx=e/'evidence.index';idx.unlink(missing_ok=True);env=dict(os.environ,GIT_INDEX_FILE=str(idx));git('read-tree',parent,env=env)
for p,key in [(mp,'evidence/official-vectors-20261030.json'),(archive,'evidence/official-vectors-20261030.tar.gz')]:git('update-index','--add','--cacheinfo','100644,'+git('hash-object','-w',str(p))+','+key,env=env)
c=git('commit-tree',git('write-tree',env=env),'-p',parent,'-m','Preserve fresh official-vector measurement and restored diagnostic checks');git('update-ref','refs/heads/'+b,c,parent);subprocess.run(['git','push','origin',b],check=True);assert git('ls-remote','origin','refs/heads/'+b).split()[0]==c
assert hashlib.sha256(subprocess.check_output(['git','show',c+':evidence/official-vectors-20261030.tar.gz'])).hexdigest()==sha(archive)
idx.unlink();receipt=dict(commit=c,remote_verified=True,archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,files=len(files));(e/'backup-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
