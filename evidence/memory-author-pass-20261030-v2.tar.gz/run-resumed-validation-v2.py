from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parent
for name in ['run-author-runtime-v2.py','run-author-post-v2.py']:
 result=subprocess.run([sys.executable,str(root/name)])
 if result.returncode:sys.exit(result.returncode)
