from pathlib import Path
import subprocess,os,json,time,datetime
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');e=Path('/home/lee/clifv/.git/agent-evidence/stock-memory-20261029');os.chdir(root)
source=json.loads((e/'author-source-v1.json').read_text());head=source['head'];state=e/'author-runtime-state-v2.json'
def save(status,**extra):state.write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),head=head,status=status,**extra),indent=2)+'\n')
def frozen():
 assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head
 assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
try:
 save('waiting-for-normal')
 while True:
  normal=json.loads((e/'author-normal-state-v1.json').read_text())
  if normal['status']=='passed':break
  if normal['status']=='failed':raise RuntimeError('normal/tools/trust failed; dependent gates held')
  time.sleep(10)
 frozen();env=json.loads((e/'author-env-v1.json').read_text());env['FV_MEMCAP']='16G';env['FV_PIPELINE_T']='0'
 tools=['lake','lean','python3',*[str(root/'.lake/build/bin'/x) for x in ['lean-backend','lean-link','link-check','lean-e2e-check','lean-backend-encode-test','clif-decode','lean-ld','stock-memory-linked']],*[str(root/'rust/target/release'/x) for x in ['cargo-fv','lean-regalloc','clif2obj','clif-native']],env['FV_CG_CLIF']]
 # Build the same package groups that the runtime script builds, before tool fingerprinting.
 save('preparing-tools')
 warm_env=dict(os.environ, **env)
 with (e/'runtime-tool-warmup-v2.log').open('w') as log:
  for packages in [['clif-native','clif-runlines'],['lean-regalloc']]:
   argv=['cargo','build','--quiet','--release','--manifest-path','rust/Cargo.toml']
   for package in packages: argv += ['-p',package]
   subprocess.run([str(root/'scripts/memcap.sh'),*argv],env=warm_env,stdout=log,stderr=subprocess.STDOUT,check=True)
 frozen()
 baseline=e/'historical/stock-memory-production-full-gates-v1'
 gates=[dict(id='runtime',argv=['bash','scripts/lean-backend-filetests.sh']),dict(id='encoder',argv=['bash','scripts/lean-backend-encode-check.sh']),dict(id='e2e',argv=['.lake/build/bin/lean-e2e-check','--identity-report','{out}/e2e-identities.json'],outputs=['{out}/e2e-identities.json']),dict(id='legacy-e2e',argv=['.lake/build/bin/lean-e2e-check','--no-dead-cleanup','--identity-report','{out}/legacy-e2e-identities.json'],outputs=['{out}/legacy-e2e-identities.json']),dict(id='identity-parity',argv=['python3',str(e/'identity-parity-current.py'),'{out}'],inputs=[str(e/'identity-parity-current.py'),str(baseline/'e2e-identities.json'),str(baseline/'legacy-e2e-identities.json')],outputs=['{out}/identity-stage-parity.json'],requires=['IDENTITY_STAGE_PARITY_PASS']),dict(id='verified-fv-demo',argv=['bash','examples/compare.sh','examples/fv-demo','--lean-link','--verified','--keep-temps']),dict(id='verified-survey',argv=['bash','examples/compare.sh','examples/survey','--lean-link','--verified','--keep-temps']),dict(id='crate-proofs',argv=['python3','-c',"import subprocess; subprocess.run(['lake','build'],cwd='crate-proofs',check=True)"]),dict(id='memory-integration',argv=['python3','scripts/check-stock-memory-integration.py','--output',str(e/'memory-integration-v1')],requires=['STOCK_MEMORY_INTEGRATION_PASS'],outputs=[str(e/'memory-integration-v1/receipt.json')])]
 for g in gates:g['complete_inputs']=False
 manifest=dict(packet='stock-memory-author-runtime-20261030',base=source['base'],candidate=head,env=env,tools=tools,inputs=[str(p) for p in (root/'.lake/build/lib/lean').rglob('*.olean')],baselines=dict(original_e2e=1150,parent_e2e=1159,full_140_complete=False),gates=gates)
 mp=e/'author-runtime-manifest-v2.json';mp.write_text(json.dumps(manifest,indent=2)+'\n');out=e/'author-runtime-gates-v2';save('running')
 with (e/'author-runtime-runner-v2.log').open('w') as log:
  r=subprocess.run(['python3','scripts/stock-delivery-gates.py','resume' if out.exists() else 'run',str(mp),'--root',str(root),'--out',str(out)],stdout=log,stderr=subprocess.STDOUT)
 save('passed' if r.returncode==0 else 'failed',returncode=r.returncode,scope='runtime/encoder/both E2E identity-stage modes/verified examples/crate proofs/memory integration; remaining author evidence and original140 obligations are not marked complete')
except Exception as err:
 save('failed',error=str(err));raise
