from pathlib import Path
import json,subprocess,datetime
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
v=json.load(open('/tmp/stock-returned-div-terminal-validation.json'))
b=json.load(open('/tmp/stock-returned-div-terminal-backup.json'))
assert head==v['validated_code_head']==b['validated_code_head']
assert v['state']=='passed' and b['state']=='remote_verified'
text=f'''# Returned division at arbitrary scalar body positions

The default Stock compiler, checker, linker and generated-proof consumers now
accept previously proved scalar computations before and after a returned
signed or unsigned i32/i64 division or remainder. The division need not be the
last statement. Original arbitrary arguments, stack arguments, memory and slots,
zero and overflow traps, accepted identities and old theorem variants remain.

The actual return request supplies positive demand. The real driver preserves
that demand and the definition's unsunk state through all intervening scans,
then derives emitted result binding. Shared scalar/division record handlers
compose guarded original-source fall and trap behavior into the existing
universal Scalar.Domain. The fixed source checker derives the domain internally.
No successful Stock run is presented as a completeness theorem.

Validated implementation: `{head}`, based on main
`{v['base']}`. Each gate keeps its actual source head. Release-only documentation
changes do not relabel the evidence.

Author evidence:

- {v['affected_normal_targets']} affected normal targets and
  {v['affected_import_closure']} imports; {v['affected_audits']} checked-in audits
  covering {v['current_audit_roots']} roots. All
  {v['prior_exact_axiom_sets']} prior required axiom sets and
  {v['old_headers_exact']} old public headers are exact.
- {v['ownership_gates']} ownership gates cover
  {v['owned_core_constants']} standard-only core constants,
  {v['fixed_witness_constants']} fixed-witness constants and exactly
  {v['exact_native_facts']} declared native facts. One bundled domain review
  reports standard axioms and no warnings.
- Complete 96 pipeline configurations and 96 source observations; both real
  allocators, both cleanup modes, six ABI/width configurations (default, System V
  and fast at i32/i64), original stack/unused arguments,
  actual safe-divisor roots and fallback/missing-oracle controls.
- 24 Lean-encoded objects, 8,304 Lean-byte executions and 2,076 Cranelift
  reference executions, zero failures or disagreements. All 14 prior native
  case grids remain exact; the runtime retains all 29 earlier functions and
  adds eight arbitrary-position division functions.
- Current and retained consumer cohorts, fresh generated proofs, original
  flat-multiply artifacts, runtime, encoder, both E2E identity/stage reports
  and both verified default-linked examples pass. Both E2E reports retain all
  original 1,150 and prior 1,159 identities and ordered successful stages.

Complete evidence: `{b['backup_commit']}` on `{b['backup_branch']}`.
Archive SHA256 `{b['archive_sha256']}`;
{b['archive_bytes']} bytes across {b['files']} files. Failed attempts and historical
records retain their original provenance. The cold current-main compiler proof
build is recorded, not confused with newly written Stock proof work.

One generated ownership audit initially lacked an explicit Lean command import.
The external audit template was repaired and its inputs declared explicitly;
ownership gates were rerun. Passed normal builds, native execution and checked-in
axiom audits were retained. The failed attempt is preserved; compiler source did
not change for that repair.

Full original #140 remains unfinished. Continue with unused or otherwise
consumed division results and genuine sink exclusion, other colored effects,
all original widths/ABIs/control/memory/calls/exceptions, source/block/whole-driver
simulation and Stock-only/downstream completeness. Legacy fallback does not
establish Stock completeness.
'''
p=Path('docs/research/stock-returned-div-production-activation.md');p.write_text(text)
plan=Path('docs/plans/stock-driver-incremental-delivery.md')
s=plan.read_text();s+='\n## Returned division at arbitrary scalar body positions\n\n'+f'Implementation `{head}` passes the current author gates; '
s+='[terminal evidence](../research/stock-returned-div-production-activation.md) records the actual results and remote backup. The arbitrary-position class extends the default shared consumers while keeping old selectors, theorem variants and original inputs. Full #140 remains open; next derive genuine sink exclusion for unused/consumed division and continue every original effect/control/whole-driver/completeness obligation.\n'
plan.write_text(s)
ledger=Path('docs/research/stock-driver-obligations.json');j=json.loads(ledger.read_text());j['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();j['complete']=False
j['production']['returned_division_arbitrary_scalar_positions']={'validated_code_head':head,'evidence_commit':b['backup_commit'],'receipt':str(p),'state':'default production activation; current author gates passed','full_140_complete':False}
ledger.write_text(json.dumps(j,indent=2)+'\n')
print('Prepared release evidence and plan/ledger checkpoint',head)
