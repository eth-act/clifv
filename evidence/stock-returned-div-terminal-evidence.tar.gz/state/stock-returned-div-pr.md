Returned `sdiv`/`udiv`/`srem`/`urem` now enter the proved default Stock route when previously proved scalar statements occur before and after the division. The real return-demand/retention proofs from #523 derive actual record/result binding; shared scalar execution, source return/trap, ABI and consumer composition supply the universal domain. Original operands, zero/overflow traps, unused/stack arguments and slots remain. Old selectors and theorem variants remain.

The internal classifier and soundness proof extend the existing shared production route. Runtime input data is shared without importing executable entrypoints. Fixtures retain all 29 shipped functions and all 14 prior native case sequences, adding eight functions with two real source statements after division. Compiler/checker/linker/generated-proof fixtures are registered for the new class.

Completed at the current implementation:

- Generic record/body/ABI return/trap/domain builds: 980 jobs; classifier/source validator: 1,014 jobs.
- All 96 actual pipeline configurations and 96 fixed source observations pass. The complete witness derivation passes (1,170 jobs); its initial list-membership proof failure is preserved. The successful finite grid was reused after that proof-only fix.
- Bundled domain MCP review: standard axioms, no warnings. All 14 prior native grids / both width case sequences are exactly retained.
- Both actual native fixture executables build successfully. Real allocator/fallback/missing-oracle checks pass. Native execution passes: 24 Lean-encoded objects, 8,304 comparisons against 2,076 Cranelift reference executions, zero failures/disagreements.

- Fresh CLI builds pass (3,383 jobs), all 1,772 affected normal import keys pass, and all 16 checked-in audits pass.
- All 1,787 ownership import keys and 31 ownership gates pass: 6,408 standard-only core constants, 1,186 fixed-witness constants and exactly 42 declared native facts. An external audit template needed an explicit Lean command import; the failed run is preserved and only ownership gates were rerun after correcting the harness/input fingerprints.

Before squash merge: exact old header/axiom parity, current/retained compiler/checker/linker/generated-proof cohorts, original retained artifacts and appropriate current runtime/encoder/E2E identity-stage/examples gates. These results will replace pending claims before landing. Prior source heads and failed attempts remain distinct; no full-main or full #140 completion is claimed.

Source is pushed at `b1990ec0`; progress evidence and native objects are remotely verified at `d57b0d23020de5c1f32b4f98be948c99f2685ad1` (558 files, SHA256 `3860805157da7d66e5b3aeb8e9883f274c1ee24b5d45adf6c162ce99b5525096`). Current integration is running; the retained cohort and full runtime/encoder/identity/examples gates follow. Full original #140 continues beyond this class through undemanded/sunk division/effects, original widths/ABIs/control/memory/calls, whole-driver simulation and Stock-only/downstream completeness.
