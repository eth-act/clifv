from pathlib import Path
import os,json,time,subprocess,datetime
root=Path('/home/lee/clifv/.worktrees/stock-mixed-div-20261022');os.chdir(root);state={'state':'waiting_final_components','head':'b1990ec02ff083882720dcc436d638c0db5f2b04'};dest=Path('/tmp/stock-returned-div-terminal-after-gates.json')
def save():state['utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();dest.write_text(json.dumps(state,indent=2)+'\n')
try:
 save()
 while True:
  r=json.load(open('/tmp/stock-returned-div-final-components.json'))
  if r['state']=='failed':raise RuntimeError('component gates failed; terminal validation not attempted')
  if r['state']=='passed':break
  time.sleep(3)
 assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==state['head']
 state['state']='validating';save()
 with open('/tmp/stock-returned-div-terminal-validation-runner.log','w') as f:r=subprocess.run(['python3','/tmp/stock-returned-div-validate-terminal.py'],stdout=f,stderr=subprocess.STDOUT)
 assert r.returncode==0,'terminal validation failed; inspect preserved log'
 state['state']='archiving';save()
 with open('/tmp/stock-returned-div-terminal-backup-runner.log','w') as f:r=subprocess.run(['nice','-n','10','python3','/tmp/stock-returned-div-archive-terminal.py'],stdout=f,stderr=subprocess.STDOUT)
 assert r.returncode==0,'terminal archive failed; inspect preserved log'
 state['state']='evidence_remote_verified_needs_main_reconciliation_and_merge';save()
except BaseException as e:state.update(state='failed',error=repr(e));save();raise
