import Crates.StockMixedDivProduction2CleanupFallbackGlobal
import Crates.StockMixedDivProduction2PlainFallbackGlobal
import Crates.StockMixedDivProduction2RetainedCleanupFallbackGlobal
import Crates.StockMixedDivProduction2RetainedPlainFallbackGlobal
import Crates.StockMixedDivProduction33CleanupFallbackEntries
import Crates.StockMixedDivProduction33CleanupFallbackGlobal
import Crates.StockMixedDivProduction6CleanupFallbackGlobal
import Crates.StockMixedDivProduction6CleanupStrictGlobal
import Crates.StockMixedDivProduction6MixedCleanupFallbackGlobal
import Crates.StockMixedDivProduction6MixedPlainFallbackGlobal
import Crates.StockMixedDivProduction6PlainFallbackGlobal
import Crates.StockMixedDivProduction6PlainStrictGlobal
import Crates.MixedDivProductionCLIcurrentPlain
import Crates.MixedDivProductionCLIretainedPlain
import Crates.MixedDivProductionCLIcurrentCleanup
import Crates.MixedDivProductionCLIretainedCleanup
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let generated := fun (name : Name) =>
    let owner := (privateToUserName? name).getD name
    owner.toString.startsWith "Crates.StockMixedDivProduction" || owner.toString.startsWith "Crates.MixedDivProductionCLI"
  let mut count : Nat := 0
  for (name, _) in env.constants.toList do
    unless generated name do continue
    for ax in ← collectAxioms name do
      if #[``propext, ``Classical.choice, ``Quot.sound].contains ax then continue
      unless generated ax && (ax.toString.splitOn "._native.native_decide.ax_").length > 1 do
        throwError "unexpected generated-proof axiom {ax} in {name}"
    count := count + 1
  unless count > 0 do throwError "empty generated-proof audit"
  logInfo m!"STOCK_MIXEDDIVPRODUCTION_GENERATED_AXIOMS_PASS {count}"
