import NextParameterJumpDomain
namespace Backend.Stock.Proof.ConditionalValues.NextNonentry
open Backend.Proof Backend.Proof.Driver
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 20000

theorem parameter_cfg_machine_return_witness (X : ExtSem) (branch : Bool) :
    ∃ result ρ0,Stock.lower function = .ok result ∧
      RunOkABI function result.code (csem (fun _ => False) ⟨0,0⟩ X) (fun _ _ _ => True)
        (initial (if branch then 1 else 0)).slots
        ⟨0,0,ρ0,Arm.write_base_gpr 0#5 (if branch then 1 else 0) Arm.ArmState.default⟩
        (.returned [⟨.i64,if branch then 1 else 2⟩] Clif.Mem.empty) := by
  obtain ⟨result,run,_⟩ := lowered
  have domain := original_domain_witness
  have entered : Clif.enterFunc function [⟨.i64,if branch then 1 else 0⟩] Clif.Mem.empty =
      .ok (initial (if branch then 1 else 0),Clif.Mem.empty) := by cases branch <;> rfl
  have returned : Clif.runLoop Clif.Env.empty {funcs := []} 4
      ⟨initial (if branch then 1 else 0),[],Clif.Mem.empty⟩ =
      .returned [⟨.i64,if branch then 1 else 2⟩] Clif.Mem.empty := by cases branch <;> rfl
  let initialWorld := Arm.write_base_gpr 0#5 (if branch then 1 else 0) Arm.ArmState.default
  have arguments : ArgsAtEntry (fun _ => False) function.sig [⟨.i64,if branch then 1 else 0⟩] initialWorld := by
    intro loc value member
    change (loc,value) ∈ [(.reg (.x 0),⟨.i64,if branch then 1 else 0⟩)] at member
    have same := List.mem_singleton.mp member
    cases same
    simp only [VHolds,regVal,initialWorld,Arm.r,Arm.read_base_gpr,Arm.write_base_gpr,
      Arm.read_store,Arm.write_store,rnum]
    cases branch <;> rfl
  have memorySem : MemRefines (fun _ => False) 0 (fun _ => none) (csem (fun _ => False) ⟨0,0⟩ X) :=
    memRefines_csem (fun _ => False) ⟨0,0⟩ X rfl (fun _ _ h => by cases h)
  have stable : MRStable (fun _ => False) (fun _ _ _ => True) := by intro _ _ _ _ _ _; trivial
  obtain ⟨ρ0,semantics⟩ := domain.returns run (SourceEntry.of_enterFunc entered) returned
    (refines_csem (fun _ => False) ⟨0,0⟩ X) (driverSem_csem (fun _ => False) ⟨0,0⟩ X)
    memorySem stable trivial arguments
  exact ⟨result,ρ0,run,semantics⟩

namespace Trap
theorem parameter_cfg_machine_trap_witness (X : ExtSem) :
    ∃ result ρ0,Stock.lower function = .ok result ∧
      RunOkABI function result.code (csem (fun _ => False) ⟨0,0⟩ X) (fun _ _ _ => True)
        (initial 0).slots ⟨0,0,ρ0,Arm.write_base_gpr 0#5 0 Arm.ArmState.default⟩ (.trapped .intDivz) := by
  obtain ⟨result,run,_⟩ := lowered
  have domain := original_domain_witness
  have entered : Clif.enterFunc function [⟨.i64,0⟩] Clif.Mem.empty = .ok (initial 0,Clif.Mem.empty) := rfl
  have trapped : Clif.runLoop Clif.Env.empty {funcs := []} 5 ⟨initial 0,[],Clif.Mem.empty⟩ = .trapped .intDivz := rfl
  let initialWorld := Arm.write_base_gpr 0#5 0 Arm.ArmState.default
  have arguments : ArgsAtEntry (fun _ => False) function.sig [⟨.i64,0⟩] initialWorld := by
    intro loc value member
    change (loc,value) ∈ [(.reg (.x 0),⟨.i64,0⟩)] at member
    cases List.mem_singleton.mp member
    simp only [VHolds,regVal,initialWorld,Arm.r,Arm.read_base_gpr,Arm.write_base_gpr,
      Arm.read_store,Arm.write_store,rnum]
    rfl
  have memorySem : MemRefines (fun _ => False) 0 (fun _ => none) (csem (fun _ => False) ⟨0,0⟩ X) :=
    memRefines_csem (fun _ => False) ⟨0,0⟩ X rfl (fun _ _ h => by cases h)
  have stable : MRStable (fun _ => False) (fun _ _ _ => True) := by intro _ _ _ _ _ _; trivial
  obtain ⟨ρ0,semantics⟩ := domain.traps run (SourceEntry.of_enterFunc entered) trapped
    (refines_csem (fun _ => False) ⟨0,0⟩ X) (driverSem_csem (fun _ => False) ⟨0,0⟩ X)
    memorySem stable trivial arguments
  exact ⟨result,ρ0,run,semantics⟩
end Trap

#print axioms parameter_cfg_machine_return_witness
#print axioms Trap.parameter_cfg_machine_trap_witness
end Backend.Stock.Proof.ConditionalValues.NextNonentry
