import NextParameterDomain
import NextParameterMachineWitness
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let mut count : Nat := 0
  for (name, info) in env.constants.toList do
    unless (match info with | .thmInfo _ => true | _ => false) do continue
    let owner := (privateToUserName? name).getD name
    let text := owner.toString
    unless text.startsWith "Backend.Stock.Proof.ConditionalValues.NextNonentry" ||
      text == "Backend.Stock.ConditionalCfg.parameter_condition_metadata_ssa_draft" ||
      text == "Backend.Stock.ConditionalCfg.parameter_condition_metadata_draft" ||
      text == "Backend.Stock.ConditionalCfg.nonentry_parameter_metadata_witness_draft" do continue
    let axes ← collectAxioms name
    for ax in axes do
      unless #[``propext, ``Classical.choice, ``Quot.sound].contains ax do
        throwError "unexpected next-control axiom {ax} in {name}"
    logInfo m!"NEXT_CONTROL_STANDARD {name}: {axes}"
    count := count + 1
  unless count ≥ 65 do throwError "incomplete next-control audit: {count}"
  logInfo m!"NEXT_PARAMETER_DOMAIN_ALL_STANDARD_PASS {count}"
