import NextNonentryPrelude
namespace Backend.Stock.Proof.ConditionalValues.NextNonentry
open Backend.Proof Backend.Proof.Driver
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 20000
set_option maxHeartbeats 16000000
private def snapshot : Bool :=
  match Stock.lower function with
  | .error _ => false
  | .ok result => decide (result.order.nodes[1]? = some (.original 1))
/-- Actual Stock compilation contains the nonentry conditional block. -/
theorem snapshot_success : snapshot = true := by decide +kernel
#print axioms snapshot_success
end Backend.Stock.Proof.ConditionalValues.NextNonentry
