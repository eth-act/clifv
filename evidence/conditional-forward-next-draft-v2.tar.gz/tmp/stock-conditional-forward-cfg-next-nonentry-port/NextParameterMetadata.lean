import FV.Backend.Proof.StockConditionalRankedShape
import FV.Backend.Proof.StockConditionalRankedWitness
import FV.Backend.Proof.StockConditionalSourceValuesWitness

namespace Backend.Stock.ConditionalCfg
open Backend.Proof Backend.Proof.Driver Backend.Stock.Proof
set_option autoImplicit false
set_option Elab.async false

/-- Original SSA gives parameter-branch metadata for any source block. -/
theorem parameter_condition_metadata_ssa_draft {f : Clif.Function} {bi : Nat}
    {b : Clif.Block} {c : Nat} {ty : Clif.Ty}
    (ssa : (valueDefs f).Nodup) (block : f.blocks[bi]? = some b)
    (parameter : (c,ty) ∈ b.params) (wide : ty = .i32 ∨ ty = .i64)
    {ctx : Ctx} {ranges : Array (Nat × Nat)} {initial : State}
    (build : Stock.buildCtx f = .ok (ctx,ranges,initial)) :
    ctx.defInst? c = none ∧
      (ctx.valueType? c = some (.int 32) ∨ ctx.valueType? c = some (.int 64)) := by
  obtain ⟨original,st,oldBuild,spec,view⟩ := buildCtx_source build
  have parameterId : c ∈ b.params.map (·.1) := List.mem_map.mpr ⟨(c,ty),parameter,rfl⟩
  have noDefinition := defInst_par spec.facts ssa block parameterId
  have originalType := (spec.facts.types ssa).2 b (List.mem_of_getElem? block) (c,ty) parameter
  refine ⟨?_,?_⟩
  · simpa only [Ctx.defInst?,view.valDef] using noDefinition
  · have typed : ctx.valueType? c = some (CTy.ofClif ty) := by
      simpa only [Ctx.valueType?,view.valTy] using originalType
    rcases wide with rfl | rfl
    · exact Or.inl typed
    · exact Or.inr typed

/-- The original-input variant remains available. -/
theorem parameter_condition_metadata_draft {f : Clif.Function} {bi : Nat}
    {b : Clif.Block} {c : Nat} {ty : Clif.Ty}
    (dominated : Dominated f) (block : f.blocks[bi]? = some b)
    (parameter : (c,ty) ∈ b.params) (wide : ty = .i32 ∨ ty = .i64)
    {ctx : Ctx} {ranges : Array (Nat × Nat)} {initial : State}
    (build : Stock.buildCtx f = .ok (ctx,ranges,initial)) :
    ctx.defInst? c = none ∧
      (ctx.valueType? c = some (.int 32) ∨ ctx.valueType? c = some (.int 64)) :=
  parameter_condition_metadata_ssa_draft dominated.ssa block parameter wide build

private def metadataSource : Clif.Function := ConditionalValues.SourceWitness.function
private def metadataBuilt : Ctx × Array (Nat × Nat) × State :=
  (Stock.buildCtx metadataSource).toOption.getD (sinkCtx,#[],sinkState)

/-- Actual original source: a nonentry wide block parameter has the derived metadata. -/
theorem nonentry_parameter_metadata_witness_draft :
    ∃ (ctx : Ctx) (ranges : Array (Nat × Nat)) (initial : State),
      Stock.buildCtx metadataSource = .ok (ctx,ranges,initial) ∧
      ctx.defInst? 31 = none ∧ ctx.valueType? 31 = some (.int 64) := by
  have ssa : (valueDefs metadataSource).Nodup := by decide +kernel
  have build : Stock.buildCtx metadataSource = .ok metadataBuilt := rfl
  have metadata := parameter_condition_metadata_ssa_draft (bi := 1)
    (b := metadataSource.blocks[1]!) (c := 31) (ty := .i64)
    ssa rfl (by decide +kernel) (Or.inr rfl) build
  refine ⟨metadataBuilt.1,metadataBuilt.2.1,metadataBuilt.2.2,build,metadata.1,?_⟩
  rcases metadata.2 with impossible | exactType
  · exact False.elim (by cases impossible)
  · exact exactType

#print axioms parameter_condition_metadata_ssa_draft
#print axioms parameter_condition_metadata_draft
#print axioms nonentry_parameter_metadata_witness_draft
end Backend.Stock.ConditionalCfg
