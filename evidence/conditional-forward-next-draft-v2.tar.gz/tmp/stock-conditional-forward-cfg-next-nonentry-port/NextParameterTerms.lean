import NextRankedSelection
namespace Backend.Stock.Proof.ConditionalValues.NextNonentry
open Backend.Proof Backend.Proof.Driver Backend.Stock.Proof.ForwardSource
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 20000

/-- A wide original parameter may be inherited from any original source block. -/
def ParameterCondition (f : Clif.Function) (c : Nat) : Prop :=
  ∃ (pbi : Nat) (pb : Clif.Block) (ty : Clif.Ty),f.blocks[pbi]? = some pb ∧
    (c,ty) ∈ pb.params ∧ (ty = .i32 ∨ ty = .i64)

def ParameterBranch (f : Clif.Function) (b : Clif.Block) : Prop :=
  ∃ c yes no,b.term = .brif c yes no ∧ yes.args = [] ∧ no.args = [] ∧ ParameterCondition f c

def NonentryParameterTerms (f : Clif.Function) : Prop :=
  ∀ bi b,f.blocks[bi]? = some b → bi ≠ 0 →
    (∃ bc,b.term = .jump bc) ∨ (∃ xs,b.term = .ret xs) ∨ ParameterBranch f b

theorem parameter_metadata {f : Clif.Function} {c : Nat} (parameter : ParameterCondition f c)
    (ssa : (valueDefs f).Nodup) {ctx : Ctx} {ranges : Array (Nat × Nat)} {initial : State}
    (build : Stock.buildCtx f = .ok (ctx,ranges,initial)) :
    ctx.defInst? c = none ∧
      (ctx.valueType? c = some (.int 32) ∨ ctx.valueType? c = some (.int 64)) := by
  obtain ⟨pbi,pb,ty,block,member,wide⟩ := parameter
  exact Backend.Stock.ConditionalCfg.parameter_condition_metadata_ssa_draft ssa block member wide build

theorem nonentry_terms : NonentryParameterTerms function := by
  intro bi b found nonentry
  have bound : bi < 4 := by have h := lt_of_getElem? found; simpa [function] using h
  have cases : bi = 0 ∨ bi = 1 ∨ bi = 2 ∨ bi = 3 := by omega
  rcases cases with rfl | rfl | rfl | rfl
  · exact False.elim (nonentry rfl)
  · simp [function] at found
    subst b
    exact Or.inr (Or.inr ⟨31,⟨2,[]⟩,⟨3,[]⟩,rfl,rfl,rfl,1,function.blocks[1]!,Clif.Ty.i64,rfl,by decide +kernel,Or.inr rfl⟩)
  · simp [function] at found
    subst b
    exact Or.inr (Or.inl ⟨[47],rfl⟩)
  · simp [function] at found
    subst b
    exact Or.inr (Or.inl ⟨[59],rfl⟩)

#print axioms parameter_metadata
#print axioms nonentry_terms
end Backend.Stock.Proof.ConditionalValues.NextNonentry
