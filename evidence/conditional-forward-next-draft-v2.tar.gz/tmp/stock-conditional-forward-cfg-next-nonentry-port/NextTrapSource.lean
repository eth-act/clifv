import NextParameterReturnWitness
namespace Backend.Stock.Proof.ConditionalValues.NextNonentry.Trap
open Backend.Proof Backend.Proof.Driver
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 20000
set_option maxHeartbeats 16000000

def function : Clif.Function := {
  name := "jump_then_parameter_conditional_divzero"
  sig := {params := [⟨.i64,.none,.normal⟩],returns := [⟨.i64,.none,.normal⟩],callConv := some .systemV}
  blocks := [{id := 0,params := [(7,.i64)],term := .jump ⟨1,[7]⟩},
    {id := 1,params := [(31,.i64)],term := .brif 31 ⟨2,[]⟩ ⟨3,[]⟩},
    {id := 2,body := [⟨[47],.iconst .i64 1⟩],term := .ret [47]},
    {id := 3,body := [⟨[59],.iconst .i64 0⟩,⟨[60],.div .udiv .i64 59 59⟩],term := .ret [60]}] }
def initial (word : BitVec 64) : Clif.Frame := {
  func := function,regs := Clif.Regs.empty.set 7 ⟨.i64,word⟩,slots := [],body := [],term := .jump ⟨1,[7]⟩ }
private def snapshot : Bool := match Stock.lower function with
  | .error _ => false
  | .ok result => decide (result.order.nodes[1]? = some (.original 1))
theorem snapshot_success : snapshot = true := by decide +kernel

theorem source_cases :
    Clif.enterFunc function [⟨.i64,0⟩] Clif.Mem.empty = .ok (initial 0,Clif.Mem.empty) ∧
    Clif.runLoop Clif.Env.empty {funcs := []} 5 ⟨initial 0,[],Clif.Mem.empty⟩ = .trapped .intDivz ∧
    Clif.runLoop Clif.Env.empty {funcs := []} 5 ⟨initial 1,[],Clif.Mem.empty⟩ = .returned [⟨.i64,1⟩] Clif.Mem.empty :=
  ⟨rfl,rfl,rfl⟩

theorem lowered : ∃ result,Stock.lower function = .ok result ∧
    result.order.nodes[1]? = some (.original 1) := by
  have checked := snapshot_success
  change (match Stock.lower function with
    | .error _ => false
    | .ok result => decide (result.order.nodes[1]? = some (.original 1))) = true at checked
  cases run : Stock.lower function with
  | error message => simp only [run] at checked; cases checked
  | ok result => simp only [run,decide_eq_true_eq] at checked; exact ⟨result,rfl,checked⟩
#print axioms snapshot_success
#print axioms source_cases
#print axioms lowered
end Backend.Stock.Proof.ConditionalValues.NextNonentry.Trap
