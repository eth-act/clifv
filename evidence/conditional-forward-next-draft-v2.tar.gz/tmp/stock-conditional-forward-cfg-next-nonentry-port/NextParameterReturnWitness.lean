import NextParameterTrap
namespace Backend.Stock.Proof.ConditionalValues.NextNonentry
open Backend.Proof Backend.Proof.Driver Backend.Stock.Proof.ForwardSource
set_option autoImplicit false
set_option Elab.async false

theorem actual_return_continuation_witness (X : ExtSem) :
    ∃ result event,Stock.lower function = .ok result ∧ event ∈ result.blockScans.toList ∧ event.block = 1 ∧
      ReturnsAt function result 1 1 function.blocks[1]! event
        (csem (fun _ => False) ⟨0,0⟩ X) (fun _ _ _ => True) Clif.Env.empty {funcs := []} := by
  obtain ⟨result,run,tag⟩ := lowered
  have stable : MRStable (fun _ => False) (fun _ _ _ => True) := by intro _ _ _ _ _ _; trivial
  obtain ⟨event,member,atBlock,returns⟩ := nonentry_parameter_returns run scope dominated rfl ranked nonentry_terms family
    (refines_csem (fun _ => False) ⟨0,0⟩ X) (driverSem_csem (fun _ => False) ⟨0,0⟩ X)
    stable Clif.Env.empty {funcs := []} tag (b := function.blocks[1]!) rfl (by decide)
  exact ⟨result,event,run,member,atBlock,returns⟩

#print axioms actual_return_continuation_witness
end Backend.Stock.Proof.ConditionalValues.NextNonentry
