import NextTrapSource
namespace Backend.Stock.Proof.ConditionalValues.NextNonentry.Trap
open Backend.Proof Backend.Proof.Driver Backend.Stock.Proof.ForwardSource
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 20000
private def original : Ctx × Array (Nat × Nat) × LState :=
  (Backend.buildCtx function).toOption.getD (sinkCtx,#[],default)
private theorem original_build : Backend.buildCtx function = .ok original := rfl
theorem dominated : Dominated function := by
  constructor
  · change ([7,31,47,59,60] : List Nat).Nodup; decide +kernel
  · intro ctx ranges st build bi b found
    have bound : bi < 4 := by have h := lt_of_getElem? found; simpa [function] using h
    have cases : bi = 0 ∨ bi = 1 ∨ bi = 2 ∨ bi = 3 := by omega
    rcases cases with rfl | rfl | rfl | rfl
    all_goals
      simp [function] at found
      subst b
      constructor
      · intro j stm present
        have cases : j = 0 ∨ j = 1 := by
          have bound := lt_of_getElem? present
          simp only [List.length_cons,List.length_nil] at bound
          omega
        rcases cases with rfl | rfl
        all_goals simp only [List.getElem?_cons_zero,List.getElem?_cons_succ,List.getElem?_nil,
          Option.some.injEq,reduceCtorEq] at present
        all_goals subst stm; intro x member; simp [Driver.instArgs] at member
        all_goals subst x; simp [availOf,function,defsBefore,defsFrom]
      · intro x member
        simp [abiTerm,Driver.termArgs,sretRet,sigRets,function] at member <;>
          subst x <;> simp [availOf,function,defsBefore,defsFrom]
  · intro ctx ranges st build tl x available notLocal y member
    have fixed := (inFix_fixOk (f := function) (ctx := ctx) (gn := id)).cand tl x available
    have values : x = 7 ∨ x = 31 ∨ x = 47 ∨ x = 59 ∨ x = 60 := by simpa [valueDefs,function] using fixed.2.2.2.1
    have context : ctx = original.1 := congrArg Prod.fst (Except.ok.inj (build.symm.trans original_build))
    rw [context] at member
    rcases values with rfl | rfl | rfl | rfl | rfl
    all_goals try (change y ∈ ([] : List Nat) at member; cases member)
    change y ∈ [59,59] at member
    simp only [List.mem_cons,List.not_mem_nil,or_false,or_self] at member
    subst y
    have bound : tl < 4 := by simpa [function] using fixed.2.1
    have choices : tl = 0 ∨ tl = 1 ∨ tl = 2 ∨ tl = 3 := by omega
    rcases choices with rfl | rfl | rfl | rfl <;> simp [parsOf,function]

theorem ranked : Ranked function id := by
  intro bi b ti destination found present target
  have bound : bi < 4 := by have h := lt_of_getElem? found; simpa [function] using h
  have cases : bi = 0 ∨ bi = 1 ∨ bi = 2 ∨ bi = 3 := by omega
  rcases cases with rfl | rfl | rfl | rfl
  all_goals simp [function] at found; subst b
  all_goals simp only [destinations,List.mem_cons,List.not_mem_nil,or_false] at present
  all_goals first | subst destination | rcases present with rfl | rfl
  all_goals first
    | change some 1 = some ti at target; cases target; decide +kernel
    | change some 2 = some ti at target; cases target; decide +kernel
    | change some 3 = some ti at target; cases target; decide +kernel

theorem nonentry_terms : NonentryParameterTerms function := by
  intro bi b found nonentry
  have bound : bi < 4 := by have h := lt_of_getElem? found; simpa [function] using h
  have cases : bi = 0 ∨ bi = 1 ∨ bi = 2 ∨ bi = 3 := by omega
  rcases cases with rfl | rfl | rfl | rfl
  · exact False.elim (nonentry rfl)
  · simp [function] at found
    subst b
    exact Or.inr (Or.inr ⟨31,⟨2,[]⟩,⟨3,[]⟩,rfl,rfl,rfl,1,function.blocks[1]!,Clif.Ty.i64,rfl,by decide +kernel,Or.inr rfl⟩)
  · simp [function] at found
    subst b
    exact Or.inr (Or.inl ⟨[47],rfl⟩)
  · simp [function] at found
    subst b
    exact Or.inr (Or.inl ⟨[60],rfl⟩)

theorem scope : LowerScope function := lowerScope_of rfl
theorem family : ∀ b ∈ function.blocks,∀ stm ∈ b.body,MaskBody.Family stm.inst := by
  have all : function.blocks.all (fun b => b.body.all Scalar.maskMixedBodyEligible) = true := rfl
  intro b member stm present
  exact Scalar.maskMixedBodyEligible_sound (List.all_eq_true.mp (List.all_eq_true.mp all b member) stm present)
#print axioms dominated
#print axioms ranked
#print axioms nonentry_terms
end Backend.Stock.Proof.ConditionalValues.NextNonentry.Trap
