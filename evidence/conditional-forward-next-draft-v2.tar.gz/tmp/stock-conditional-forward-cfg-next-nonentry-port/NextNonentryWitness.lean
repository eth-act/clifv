import NextNonentryLowering
namespace Backend.Stock.Proof.ConditionalValues.NextNonentry
open Backend.Proof Backend.Proof.Driver
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 20000

theorem lowered : ∃ result,Stock.lower function = .ok result ∧
    result.order.nodes[1]? = some (.original 1) := by
  have checked := snapshot_success
  change (match Stock.lower function with
    | .error _ => false
    | .ok result => decide (result.order.nodes[1]? = some (.original 1))) = true at checked
  cases run : Stock.lower function with
  | error message => simp only [run] at checked; cases checked
  | ok result =>
    simp only [run,decide_eq_true_eq] at checked
    exact ⟨result,rfl,checked⟩

theorem nonentry_condition_metadata {ctx : Ctx} {ranges : Array (Nat × Nat)} {initial : State}
    (build : Stock.buildCtx function = .ok (ctx,ranges,initial)) :
    ctx.defInst? 31 = none ∧
      (ctx.valueType? 31 = some (.int 32) ∨ ctx.valueType? 31 = some (.int 64)) :=
  Backend.Stock.ConditionalCfg.parameter_condition_metadata_ssa_draft
    (bi := 1) (b := function.blocks[1]!) (ty := .i64)
    dominated.ssa rfl (by decide +kernel) (Or.inr rfl) build

/-- An actual nonentry conditional body has no entry ABI prelude. -/
theorem nonentry_prelude_witness (X : ExtSem) :
    ∃ result,Stock.lower function = .ok result ∧
      ∃ spec : ConditionalBodySpec function result function.blocks[1]! 1 1 31 ⟨2,[]⟩ ⟨3,[]⟩
        (csem (fun _ => False) ⟨0,0⟩ X) (fun _ _ _ => True) Clif.Env.empty {funcs := []},
        spec.preludeCode.size = 0 := by
  obtain ⟨result,run,tag⟩ := lowered
  have stable : MRStable (fun _ => False) (fun _ _ _ => True) := by intro _ _ _ _ _ _; trivial
  obtain ⟨spec⟩ := stock_lower_conditional_body_spec run scope dominated family
    tag (b := function.blocks[1]!) rfl rfl
    (refines_csem (fun _ => False) ⟨0,0⟩ X) (driverSem_csem (fun _ => False) ⟨0,0⟩ X)
    stable Clif.Env.empty {funcs := []}
  exact ⟨result,run,spec,conditional_nonentry_prelude spec (by decide)⟩

#print axioms lowered
#print axioms nonentry_condition_metadata
#print axioms nonentry_prelude_witness
end Backend.Stock.Proof.ConditionalValues.NextNonentry
