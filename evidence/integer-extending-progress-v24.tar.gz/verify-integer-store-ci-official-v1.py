from pathlib import Path
import json,hashlib,datetime,subprocess,sys,importlib.util
b=Path('/home/lee/clifv');e=b/'.git/agent-evidence/stock-memory-20261029';r=b/'.worktrees/stock-extending-production-20261031';state=e/'integer-store-production-official-state-v1.json'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(status,**extra):state.write_text(json.dumps(dict(status=status,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),**extra),indent=2)+'\n')
try:
 packet=json.loads((e/'integer-store-production-publication-v1.json').read_text())
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==packet['commit']
 assert all(sha(r/n)==h for n,h in packet['source_hashes'].items())
 summary=json.loads((e/'pr802-ci-summary-v1/ci-comparison.ci-summary.json').read_text())
 assert summary['head_sha']==packet['commit'] and summary['measurement_complete']
 report_path=e/'pr802-ci-artifacts-v1/results.json';report=json.loads(report_path.read_text())
 assert report['upstream_commit']=='46c23a87dac1465986a8ad53ba6a7ae49372857b'
 tree=hashlib.sha256()
 for path in sorted([*(r/'FV').rglob('*.lean'),*(r/'FVTest').rglob('*.lean')]):tree.update(str(path.relative_to(r)).encode()+b'\0'+path.read_bytes()+b'\0')
 assert tree.hexdigest()==report['lean_source_tree_sha256'],'CI source tree differs'
 assert all(sha(r/n)==h for n,h in report['source_hashes'].items()),'CI harness source differs'
 old=json.loads((e/'integer-extending-production-official-vectors-v3/results.json').read_text())
 assert report['inventory']==old['inventory'] and len(report['inventory'])==1302
 suite=r/'third_party/wasmtime/cranelift/filetests/filetests'
 assert all(sha(suite/row['test'])==row['sha256'] for row in old['inventory'])
 sys.path.insert(0,str(r/'scripts'));spec=importlib.util.spec_from_file_location('comparison_ci',r/'scripts/stock-comparison-ci.py');ci=importlib.util.module_from_spec(spec);spec.loader.exec_module(ci)
 totals=ci.validate_report(report)
 before={tuple(x) for x in ci.matched_entries(old)};after={tuple(x) for x in ci.matched_entries(report)}
 assert not before-after
 def identities(s):return {(t['test'],v['index'],row['index'],row['name']):row['status'] for t in s['tests'] for v in t['variants'] for row in v['functions_compared']}
 previous=identities(old);current=identities(report);assert previous.keys()==current.keys() and len(current)==4501
 allowed={'identical_code_artifact':{'identical_code_artifact'},'different_code_artifact':{'different_code_artifact','identical_code_artifact'},'unsupported_configuration':{'unsupported_configuration'},'expected_stock_rejection_no_binary':{'expected_stock_rejection_no_binary'},'lean_unsupported':{'lean_unsupported','different_code_artifact','identical_code_artifact'}}
 assert all(current[k] in allowed[v] for k,v in previous.items())
 changed=[dict(identity=k,old=previous[k],new=current[k]) for k in previous if previous[k]!=current[k]]
 out=e/'integer-store-production-official-vectors-v1';out.mkdir(exist_ok=True);(out/'results.json').write_bytes(report_path.read_bytes())
 save('passed',returncode=summary['pipeline_exit_code'],totals=totals,gained=sorted(after-before),lost=[],identity_status_changes=changed,original_hashes_exact=1302,stage_identities_exact=4501,source_unchanged=True,reused_ci_run=summary['run_id'],ci_head=summary['head_sha'],report_sha256=sha(report_path),lean_source_tree_sha256=tree.hexdigest(),scope='Exact combined-source official compilation byte/relocation comparison from completed CI. This is not native execution or full artifact equivalence.',full_goal_complete=False)
 print(json.dumps(dict(status='passed',ci_head=summary['head_sha'],exact_code_artifacts=totals['exact_code_artifacts'],gained=len(after-before),lost=0,identity_status_changes=len(changed),original_hashes_exact=1302,stage_identities_exact=4501)))
except BaseException as error:save('failed',error=repr(error));raise
