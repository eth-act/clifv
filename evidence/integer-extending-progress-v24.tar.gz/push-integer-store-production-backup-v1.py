from pathlib import Path
import subprocess,json,datetime
b=Path('/home/lee/clifv');e=b/'.git/agent-evidence/stock-memory-20261029';p=json.loads((e/'integer-store-production-packet-state-v1.json').read_text());branch=p['branch'];head=p['commit']
assert subprocess.check_output(['git','rev-parse',branch],cwd=b,text=True).strip()==head
subprocess.run(['git','push','origin',branch],cwd=b,check=True)
assert subprocess.check_output(['git','ls-remote','origin','refs/heads/'+branch],cwd=b,text=True).split()[0]==head
(e/'integer-store-production-backup-state-v1.json').write_text(json.dumps(dict(status='passed',commit=head,branch=branch,remote_verified=True,files=len(p['files']),utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Source backup only. Exact installed shared-module and production gates remain open. No PR or merge.'),indent=2)+'\n')
print(json.dumps(dict(commit=head,remote_verified=True,files=len(p['files']))))
