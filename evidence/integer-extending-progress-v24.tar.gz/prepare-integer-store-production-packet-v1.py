from pathlib import Path
import ast,json,hashlib,subprocess,os,datetime,tomllib
b=Path('/home/lee/clifv');e=b/'.git/agent-evidence/stock-memory-20261029';r=b/'.worktrees/stock-extending-production-20261031';stage=e/'integer-store-production-packet-v1';files={str(p.relative_to(stage)):p for p in stage.rglob('*') if p.is_file()};base='21ff6d8eff3afef5cc3b88ce46dd2b3cc8f7b372';branch='agent/stock-store-production-20261031'
assert len(files)==22,(len(files),list(files))
for n,p in files.items():
 if n.endswith('.py'):ast.parse(p.read_bytes(),filename=n)
 if n.endswith('.toml'):tomllib.loads(p.read_text())
idx=e/'integer-store-production-packet-v1.index';idx.unlink(missing_ok=True);env=dict(os.environ,GIT_INDEX_FILE=str(idx))
def git(*args,env=None):return subprocess.check_output(['git',*args],cwd=b,env=env,text=True).strip()
assert git('-C',str(r),'rev-parse','HEAD')=='330e55698e83dbfe80a6524a6e916a44f6a3dd8b' and not git('-C',str(r),'status','--porcelain')
git('read-tree',base,env=env)
for n,p in files.items():
 oid=git('hash-object','-w',str(p));row=git('ls-tree',base,'--',n);mode=row.split()[0] if row else '100755' if n=='scripts/check-stock-memory-store-integration.py' else '100644'
 git('update-index','--add','--cacheinfo',mode+','+oid+','+n,env=env)
git('diff','--cached',base,'--check',env=env);tree=git('write-tree',env=env)
assert subprocess.run(['git','show-ref','--verify','--quiet','refs/heads/'+branch],cwd=b).returncode!=0
commit=git('commit-tree',tree,'-p',base,'-m','Activate proved Stock integer stores across production consumers');git('update-ref','refs/heads/'+branch,commit);idx.unlink()
receipt=dict(status='prepared',commit=commit,tree=tree,branch=branch,base=base,source_root=str(stage),files={n:hashlib.sha256(p.read_bytes()).hexdigest() for n,p in files.items()},utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),checks=['Python syntax','TOML syntax','diff --check against source parent','consumer routing inventory','provider source identities'],remaining='Exact shared module builds and full installed production gates after800. No PR or merge yet.',frozen_view_unchanged=True)
(e/'integer-store-production-packet-state-v1.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:receipt[k] for k in ['status','commit','branch','remaining']}));print('files:',len(files))
