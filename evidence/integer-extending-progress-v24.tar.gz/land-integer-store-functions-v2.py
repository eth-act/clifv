from pathlib import Path
import subprocess,json,time,datetime
b=Path('/home/lee/clifv');e=b/'.git/agent-evidence/stock-memory-20261029';r=b/'.worktrees/stock-extending-production-20261031';state=e/'integer-store-functions-landing-v2.json'
def save(status,**x):state.write_text(json.dumps(dict(status=status,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),full_goal_complete=False,**x),indent=2)+'\n')
def cmd(args):return subprocess.check_output(args,cwd=r,text=True).strip()
try:
 while True:
  p=e/'integer-store-functions-pr-gates-v3.json'
  if p.exists():
   gates=json.loads(p.read_text())
   if gates['status']=='passed':break
   assert gates['status']!='failed',gates
  save('waiting',phase='function-packet-gates');time.sleep(10)
 pub=gates['publication'];number=str(pub['pr']);head=gates['head']
 assert cmd(['git','ls-remote','origin','refs/heads/main']).split()[0]==gates['base'],'Inspect main drift before landing'
 pr=json.loads(cmd(['gh','pr','view',number,'--repo','eth-act/clifv','--json','state,headRefOid,statusCheckRollup']))
 assert pr['state']=='OPEN' and pr['headRefOid']==head,pr
 expected={'Quick checks','Build and compare','Check lost matches','Publish PR result'}
 while not (expected<={x.get('name') for x in pr['statusCheckRollup']} and all(x.get('status')=='COMPLETED' for x in pr['statusCheckRollup'])):
  save('waiting',phase='current-head-CI',pr=pub['pr'],head=head);time.sleep(10)
  pr=json.loads(cmd(['gh','pr','view',number,'--repo','eth-act/clifv','--json','state,headRefOid,statusCheckRollup']))
  assert pr['state']=='OPEN' and pr['headRefOid']==head
 assert all(x.get('conclusion') in ['SUCCESS','SKIPPED','NEUTRAL'] for x in pr['statusCheckRollup']),pr
 assert cmd(['git','ls-remote','origin','refs/heads/main']).split()[0]==gates['base'],'Inspect newer main drift before landing'
 body=e/'integer-store-functions-pr-final-v1.md';text=(e/'integer-store-functions-pr-v1.md').read_text().replace('Full per-PR checks follow parent landing.','The complete FV/FVTest build, lean-e2e-check and link-check passed. The final44-root audit preserved all29 previous axiom sets exactly.').replace('Depends on #797. This PR targets its branch until that PR lands; it will then reconcile onto current main.','Parent #797 is merged. This branch reconciles onto current main with published source history preserved.')
 body.write_text(text);subprocess.run(['gh','pr','edit',number,'--repo','eth-act/clifv','--body-file',str(body)],cwd=r,check=True)
 save('running',phase='squash-merge',pr=pub['pr'],head=head)
 subprocess.run(['gh','pr','merge',number,'--repo','eth-act/clifv','--squash','--match-head-commit',head],cwd=r,check=True)
 result=json.loads(cmd(['gh','pr','view',number,'--repo','eth-act/clifv','--json','state,mergeCommit']));assert result['state']=='MERGED'
 merged=result['mergeCommit']['oid'];subprocess.run(['git','fetch','origin','main'],cwd=r,check=True)
 assert cmd(['git','rev-parse',merged+'^{tree}'])==cmd(['git','rev-parse',head+'^{tree}'])
 save('passed',pr=pub['pr'],url=pub['url'],head=head,merge=merged,validated_tree_exact=True,audit_roots=44,prior_axiom_sets_exact=29,route='Full per-PR tests; no review agents.',remaining='Store production integration and every remaining original140 obligation.')
 print(json.dumps(dict(pr=pub['pr'],merge=merged,full_goal_complete=False)))
except BaseException as error:save('failed',error=repr(error));raise
