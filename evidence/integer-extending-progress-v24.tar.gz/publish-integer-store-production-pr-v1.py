from pathlib import Path
import subprocess,json,time,hashlib,datetime
b=Path('/home/lee/clifv');e=b/'.git/agent-evidence/stock-memory-20261029';r=b/'.worktrees/stock-extending-production-20261031';state=e/'integer-store-production-publication-v1.json'
def save(status,**kw):state.write_text(json.dumps(dict(status=status,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),full_goal_complete=False,**kw),indent=2)+'\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=r,text=True).strip()
try:
 while True:
  gates=json.loads((e/'integer-store-production-installed-gates-v3.json').read_text())
  if gates['status']=='passed':break
  assert gates['status']!='failed',gates
  save('waiting',phase='installed62-root-gates');time.sleep(10)
 assert gates['audit_roots']==62 and gates['prior_axiom_sets_exact']==56
 assert git('rev-parse','HEAD')==gates['head'] and git('branch','--show-current')==gates['branch']
 assert git('diff','--name-only').splitlines()==gates['dirty_expected'] and not git('diff','--cached','--name-only')
 assert not git('ls-files','--others','--exclude-standard')
 assert all(hashlib.sha256((r/n).read_bytes()).hexdigest()==h for n,h in gates['source_hashes'].items())
 assert git('ls-remote','origin','refs/heads/main').split()[0]==gates['base'],'Inspect further main drift before publishing'
 subprocess.run(['git','add','--',*gates['dirty_expected']],cwd=r,check=True);subprocess.run(['git','diff','--cached','--check'],cwd=r,check=True)
 subprocess.run(['git','commit','-m','Complete store cases in semantic linker boundaries'],cwd=r,check=True);head=git('rev-parse','HEAD');assert not git('status','--porcelain')
 subprocess.run(['git','push','origin',gates['branch']],cwd=r,check=True);assert git('ls-remote','origin','refs/heads/'+gates['branch']).split()[0]==head
 body=e/'integer-store-production-pr-v1.md';body.write_text('''The production driver still sends integer stores to the legacy provider. This change adds proved Stock store lowering across the production consumers.

The source checker derives the proved class from the original scope, dominance and ABI checks. It binds the actual Stock output. No caller supplies a lowering certificate. Existing theorem variants remain available.

The new provider appends route16 after unchanged routes0–15. Default/configured compilation, semantic checks, traces, both linkers and generated proofs use that provider. A failed store attempt retries the complete previous pipeline with the original input and allocator callback. The linker boundary proofs include the new case.

Validation completed:
- Proper installed module builds and62 standard-only audit roots. All56 prior axiom sets remain exact.
- Staged objects pass572 native stores and26 retained calls across13 opcode/type pairs, both parameter orders and cleanup modes.
- The custom pinned-reference comparison matches30 function byte/relocation records with equal frame settings. Three same-width narrowing fixtures fail pinned Cranelift parsing. This does not change the official4455 metric.

Validation in progress: full FV/FVTest and executable gates, all production consumer matrices, retained classes, original captures/settings, and the official byte/relocation comparison. This PR is not merge-ready until those gates pass. No review agents run.

The full original #140 remains open. Other addressing, mixed functions, effects, control, calls, simulation and completeness obligations remain.
''')
 result=subprocess.check_output(['gh','pr','create','--repo','eth-act/clifv','--base','main','--head',gates['branch'],'--title','Activate proved Stock integer stores across production consumers','--body-file',str(body)],cwd=r,text=True).strip();number=int(result.rstrip('/').rsplit('/',1)[1])
 save('passed',commit=head,base=gates['base'],branch=gates['branch'],pr=number,url=result,remote_verified=True,source_hashes=gates['source_hashes'],audit_roots=62,prior_axiom_sets_exact=56,scope='Production implementation is published. Full production gates and all current CI remain required before merge.')
 print(json.dumps(dict(pr=number,commit=head,url=result)))
except BaseException as error:save('failed',error=repr(error));raise
