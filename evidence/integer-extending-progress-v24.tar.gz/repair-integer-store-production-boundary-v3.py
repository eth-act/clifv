from pathlib import Path
import json,hashlib,subprocess,psutil,os,time,datetime,re
b=Path('/home/lee/clifv');e=b/'.git/agent-evidence/stock-memory-20261029';r=b/'.worktrees/stock-extending-production-20261031';state=e/'integer-store-production-installed-gates-v3.json';paused=None;records=[];head='72c0096f74cfc65df65f4af1481cd54ea68c1f98'
packet=json.loads((e/'integer-store-production-packet-state-v1.json').read_text());names=[*packet['files'],'FV/E2E/SemanticNIBoundary.lean'];hashes={n:hashlib.sha256((r/n).read_bytes()).hexdigest() for n in names};dirty=['FV/Backend/Proof/StockMemoryStoreCheck.lean','FV/E2E/SemanticNIBoundary.lean','scripts/audit/stock-memory-store-production.lean']
(e/'integer-store-production-source-v3.json').write_text(json.dumps(dict(root=str(r),head=head,files=hashes,dirty_expected=dirty),indent=2)+'\n')
def git(*a):return subprocess.check_output(['git',*a],cwd=r,text=True).strip()
def save(status,**kw):state.write_text(json.dumps(dict(status=status,head=head,records=records,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),**kw),indent=2)+'\n')
def live(p):
 try:return p.is_running() and p.status()!=psutil.STATUS_ZOMBIE
 except psutil.NoSuchProcess:return False
def frozen():
 assert git('rev-parse','HEAD')==head and git('diff','--name-only').splitlines()==dirty
 assert not git('ls-files','--others','--exclude-standard')
 assert all(hashlib.sha256((r/n).read_bytes()).hexdigest()==h for n,h in hashes.items())
try:
 frozen();normal=psutil.Process(3167178);sched=[]
 for child in normal.children(recursive=True):
  try:
   if child.name().startswith('python') and any(a=='scripts/lake-serial-build.py' or a.endswith('/lake-serial-build.py') for a in child.cmdline()):sched.append(child)
  except psutil.NoSuchProcess:pass
 assert len(sched)==1,'Inspect normal/runtime ownership before reserving memory';paused=sched[0];paused.suspend()
 while any(live(c) for c in paused.children()):save('waiting',phase='finish-old-active-source');time.sleep(3)
 env=dict(os.environ);env.update(json.loads((e/'author-env-v1.json').read_text()));env.update(FV_ROOT=str(r),OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',CARGO_BUILD_JOBS='2',PYTHONDONTWRITEBYTECODE='1')
 for k in ['FV_PIPELINE_T','BLESS']:env.pop(k,None)
 def run(label,args,cap='16G'):
  frozen();save('running',phase=label);env['FV_MEMCAP']=cap;env['FV_MEMCAP_STATS']=str(e/('integer-store-production-installed-'+label+'-v3.stats'))
  with (e/('integer-store-production-installed-'+label+'-v3.log')).open('w') as log:done=subprocess.run(['nice','-n','10',str(r/'scripts/memcap.sh'),*map(str,args)],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
  records.append(dict(label=label,returncode=done.returncode));assert done.returncode==0,(label,done.returncode)
 roots=['FV.Backend.Proof.StockMemoryStoreCompatibility','FV.Backend.Proof.StockMemoryStoreSelectorWitness','FV.E2E.CompiledSemanticNI','FV.E2E.SemanticNIBoundary','FVTest.Backend.Main','FVTest.Backend.Lowering.Trace','FVTest.Link.LeanLinkMain','FVTest.E2E.LinkCheckMain','FVTest.Backend.Lowering.StockMemoryStoreProductionLinked','FVTest.Backend.Lowering.StockMemoryRetainedRuntime']
 run('module-paths',['python3','scripts/lake-serial-build.py','--budget','16G','--max-jobs','2','--max-cap','16G','--default-cap','4G','--profile',r/'scripts/lake-module-peaks.tsv','--profile',r/'.lake/lake-module-peaks.tsv','--profile',e/'production-cold-overrides-v6.tsv','--out',e/'integer-store-production-installed-modules-v3',*roots])
 run('audit',['lake','env','lean','-j1','scripts/audit/stock-memory-store-production.lean'],'4G')
 def axioms(p):
  text=p.read_text();a={n:set(x.strip() for x in s.split(',')) for n,s in re.findall(r"'([^']+)' depends on axioms: \[([^]]*)\]",text,re.S)};a.update({n:set() for n in re.findall(r"'([^']+)' does not depend on any axioms",text)});return a
 now=axioms(e/'integer-store-production-installed-audit-v3.log');old=axioms(e/'integer-store-provider-module-path-stock-memory-store-provider-v1.log');assert len(now)==62 and len(old)==56
 assert all(a<={'propext','Classical.choice','Quot.sound'} for a in now.values()) and all(now[n]==a for n,a in old.items()),now
 frozen();save('passed',base='4203e2e73def33b8fee5721a96746d728f0682c0',branch='agent/stock-store-production-20261031',audit_roots=62,prior_axiom_sets_exact=56,source_hashes=hashes,dirty_expected=dirty,scope='Exact installed production module identities and repaired existing linker boundary. Full executable/native/generated/retained/capture/settings/official gates remain open. No PR or merge yet.')
except BaseException as error:save('failed',error=repr(error));raise
finally:
 if paused is not None and live(paused):paused.resume()
