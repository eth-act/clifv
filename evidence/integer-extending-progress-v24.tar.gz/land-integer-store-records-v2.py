from pathlib import Path
import subprocess,json,datetime,ast
b=Path('/home/lee/clifv');e=b/'.git/agent-evidence/stock-memory-20261029';r=b/'.worktrees/stock-extending-production-20261031';state=e/'integer-store-records-landing-v2.json'
def cmd(*args):return subprocess.check_output(args,cwd=r,text=True).strip()
def save(status,**kw):state.write_text(json.dumps(dict(status=status,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),full_goal_complete=False,**kw),indent=2)+'\n')
try:
 gates=json.loads((e/'integer-store-records-pr-gates-v1.json').read_text());assert gates['status']=='passed' and gates['audit_roots']==29 and gates['prior_axiom_sets_exact']==7
 pub=gates['publication'];old=pub['base'];head=pub['commit'];main='ff90b88aa69bfb7b8fb9ccffc2fe9d02b012b0ed'
 assert cmd('git','ls-remote','origin','refs/heads/main').split()[0]==main
 delta=cmd('git','diff','--name-only',old,main).splitlines();assert len(delta)==14 and all(n.startswith('scripts/') for n in delta)
 for name in delta:
  data=subprocess.check_output(['git','show',main+':'+name],cwd=r)
  if name.endswith('.py'):ast.parse(data,filename=name)
  elif name.endswith('.sh'):subprocess.run(['bash','-n'],input=data,check=True)
 expected=cmd('git','merge-tree','--write-tree',head,main);assert cmd('git','diff','--name-only',head,expected).splitlines()==delta
 assert not cmd('git','diff',head,expected,'--','FV','FVTest','lakefile.toml','lake-manifest.json','crate-proofs')
 data=json.loads(cmd('gh','pr','view','797','--repo','eth-act/clifv','--json','state,headRefOid,statusCheckRollup'));assert data['state']=='OPEN' and data['headRefOid']==head
 names={'Quick checks','Build and compare','Check lost matches','Publish PR result'};checks=data['statusCheckRollup'];assert names<={x.get('name') for x in checks}
 assert all(x.get('status')=='COMPLETED' and x.get('conclusion') in ['SUCCESS','NEUTRAL','SKIPPED'] for x in checks)
 upstream=json.loads(cmd('gh','pr','view','801','--repo','eth-act/clifv','--json','state,statusCheckRollup'));assert upstream['state']=='MERGED' and all(x.get('conclusion') in ['SUCCESS','SKIPPED','NEUTRAL'] for x in upstream['statusCheckRollup'])
 body=e/'integer-store-records-pr-final-v2.md';s=(e/'integer-store-records-pr-v1.md').read_text();s=s.replace('The full FV/FVTest per-PR build follows publication; its result will be recorded before landing.','The complete4929-module FV/FVTest build passed. The final29-root audit retained all seven previous axiom sets exactly. Main #801 changes only temporary-file paths; its four CI checks passed. All Lean sources, manifests and proof inputs remain exact. Explicit build output paths retain the completed gate.')
 body.write_text(s);subprocess.run(['gh','pr','edit','797','--repo','eth-act/clifv','--body-file',str(body)],cwd=r,check=True)
 save('running',phase='squash-merge',commit=head,base=main,expected_tree=expected,main_script_delta=delta)
 subprocess.run(['gh','pr','merge','797','--repo','eth-act/clifv','--squash','--match-head-commit',head],cwd=r,check=True)
 pr=json.loads(cmd('gh','pr','view','797','--repo','eth-act/clifv','--json','state,mergeCommit'));assert pr['state']=='MERGED';merged=pr['mergeCommit']['oid'];subprocess.run(['git','fetch','origin','main'],cwd=r,check=True)
 assert cmd('git','rev-parse',merged+'^{tree}')==expected
 save('passed',pr=797,url=pub['url'],commit=head,merge=merged,base=main,merged_tree_exact=True,validated_lean_tree_exact=True,main_script_delta=delta,audit_roots=29,prior_axiom_sets_exact=7,full_modules=4929,route='Completed local tests and all four CI checks. No review agents.',remaining='Complete store functions,production activation,and all original140 obligations.')
 print(json.dumps(dict(pr=797,merge=merged,full_goal_complete=False)))
except BaseException as error:save('failed',error=repr(error));raise
