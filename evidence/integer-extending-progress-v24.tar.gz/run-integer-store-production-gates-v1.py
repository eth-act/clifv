from pathlib import Path
import subprocess,json,hashlib,os,time,datetime,psutil,re
b=Path('/home/lee/clifv');e=b/'.git/agent-evidence/stock-memory-20261029';r=b/'.worktrees/stock-extending-production-20261031';state=e/'integer-store-production-gates-state-v1.json';pub=json.loads((e/'integer-store-production-publication-v1.json').read_text());paused=None;records=[]
def save(status,**kw):
 text=json.dumps(dict(status=status,head=pub['commit'],records=records,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),**kw),indent=2)+'\n';tmp=state.with_suffix('.tmp');tmp.write_text(text);tmp.replace(state)
def live(p):
 try:return p.is_running() and p.status()!=psutil.STATUS_ZOMBIE
 except psutil.NoSuchProcess:return False
def git(*a):return subprocess.check_output(['git',*a],cwd=r,text=True).strip()
def frozen():
 assert git('rev-parse','HEAD')==pub['commit'] and not git('status','--porcelain')
 assert all(hashlib.sha256((r/n).read_bytes()).hexdigest()==h for n,h in pub['source_hashes'].items())
try:
 assert pub['status']=='passed' and pub['audit_roots']==62;frozen()
 normal=psutil.Process(3167178);schedulers=[]
 for child in normal.children(recursive=True):
  try:
   if child.name().startswith('python') and any(a=='scripts/lake-serial-build.py' or a.endswith('/lake-serial-build.py') for a in child.cmdline()):schedulers.append(child)
  except psutil.NoSuchProcess:pass
 assert len(schedulers)==1,'Inspect normal/runtime ownership before reserving memory';paused=schedulers[0];paused.suspend()
 while any(live(c) for c in paused.children()):save('waiting',phase='finish-old-active-source');time.sleep(3)
 env=dict(os.environ);env.update(json.loads((e/'author-env-v1.json').read_text()));env.update(FV_ROOT=str(r),FV_MEMCAP='16G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',CARGO_BUILD_JOBS='2',PYTHONDONTWRITEBYTECODE='1')
 for k in ['FV_PIPELINE_T','BLESS']:env.pop(k,None)
 assert subprocess.check_output(['nproc'],env=env,text=True).strip()=='2'
 assert __import__('shutil').disk_usage(r).free>50*2**30
 def run(label,args,cap='16G',cwd=r):
  frozen();save('running',phase=label);env['FV_MEMCAP']=cap;env['FV_MEMCAP_STATS']=str(e/('integer-store-production-'+label+'-v1.stats'))
  with (e/('integer-store-production-'+label+'-v1.log')).open('w') as log:done=subprocess.run(['nice','-n','10',str(r/'scripts/memcap.sh'),*map(str,args)],cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
  records.append(dict(label=label,returncode=done.returncode));assert done.returncode==0,(label,done.returncode)
 run('FV-FVTest',['python3','scripts/lake-serial-build.py','--budget','16G','--max-jobs','2','--max-cap','16G','--default-cap','4G','--profile',r/'scripts/lake-module-peaks.tsv','--profile',r/'.lake/lake-module-peaks.tsv','--profile',e/'production-cold-overrides-v6.tsv','--out',e/'integer-store-production-full-modules-v1','FV','FVTest'])
 tools=json.loads((e/'integer-extending-production-closure-v1.json').read_text())['executables']+['lean-e2e-check','stock-memory-store-linked']
 for tool in tools:run('build-'+tool,['lake','build',tool])
 run('configured-provider',['python3','scripts/test_stock_configured_provider.py'])
 for kind in ['parameter','conditional-forward','conditional','forward','linear','scalar-entry','entry','cfg']:run('retained-'+kind,[r/'.lake/build/bin/stock-memory-retained',kind])
 pairs=json.loads((e/'integer-store-native-matrix-source-v1.json').read_text())['pairs'];assert len(pairs)==13
 for pair in pairs:
  label=pair['op']+'-'+pair['ty'];run('consumers-'+label,['python3','scripts/check-stock-memory-store-integration.py','--output',e/('integer-store-production-consumers-'+label+'-v1'),'--store-type',pair['ty'],'--store-op',pair['op']])
 matrices=[]
 for op,types in [('uload8',['i16','i32','i64']),('sload8',['i16','i32','i64']),('uload16',['i32','i64']),('sload16',['i32','i64']),('uload32',['i64']),('sload32',['i64'])]:
  for ty in types:matrices.append((op+'-'+ty,['--load-op',op,'--load-type',ty]))
 matrices += [(ty,['--load-type',ty]) for ty in ['i8','i16','i32','i64']]+[('cfg32',['--memory-cfg'])]
 for label,args in matrices:run('retained-consumers-'+label,['python3','scripts/check-stock-memory-integration.py','--output',e/('integer-store-production-retained-consumers-'+label+'-v1'),*args])
 run('runtime',['bash','scripts/lean-backend-filetests.sh'])
 run('encoder',['bash','scripts/lean-backend-encode-check.sh'])
 for label,args in [('e2e',[]),('legacy-e2e',['--no-dead-cleanup'])]:
  run(label,[r/'.lake/build/bin/lean-e2e-check',*args,'--identity-report',e/('integer-store-production-'+label+'-identities-v1.json')])
 # Compile local crate modules in import order; keep at most one source worker here.
 # Lake uses the same FV_LAKE_CACHE; this creates no additional artifact cache.
 crate=r/'crate-proofs';modules={'.'.join(p.relative_to(crate).with_suffix('').parts):p for p in (crate/'Crates').rglob('*.lean')};ordered=[];active=set();done=set()
 def visit(module):
  if module in done:return
  assert module not in active,('Crate import cycle',module);active.add(module)
  for name in re.findall(r'^import\s+(\S+)',modules[module].read_text(),re.M):
   if name in modules:visit(name)
  active.remove(module);done.add(module);ordered.append(module)
 for module in sorted(modules):visit(module)
 assert len(ordered)==len(modules)>0
 for module in ordered:run('crate-'+module,['lake','build','+'+module],cwd=crate)
 run('crate-proofs-final',['lake','build'],cwd=crate)
 frozen();save('passed',pr=pub['pr'],executables=tools,store_matrices=13,retained_memory_matrices=17,retained_classes=8,crate_modules=len(ordered),scope='Current-source full FV/FVTest,executable,configured/default/trace,ELF/generated/native,retained,runtime,encoder,E2E and crate gates. Official comparison,exact previous audit sets,captures/settings and identity parity remain separate mandatory gates. Full140 remains incomplete.')
except BaseException as error:save('failed',error=repr(error));raise
finally:
 if paused is not None and live(paused):paused.resume()
