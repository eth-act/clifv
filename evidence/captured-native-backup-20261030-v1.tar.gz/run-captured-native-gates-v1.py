from pathlib import Path
import os,json,subprocess,datetime
b=Path('/home/lee/clifv');r=b/'.worktrees/stock-cfg-source-20261025';e=b/'.git/agent-evidence/stock-memory-20261029';env=dict(os.environ);env.update(json.loads((e/'author-env-v1.json').read_text()));env.update(FV_ROOT=str(r),FV_MEMCAP='4G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',CARGO_BUILD_JOBS='2');env.pop('FV_PIPELINE_T',None);state=e/'captured-native-state-v1.json';records=[]
def save(status,**x):state.write_text(json.dumps(dict(status=status,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),records=records,**x),indent=2)+'\n')
def run(label,args):
 save('running',phase=label)
 with (e/('captured-native-'+label+'-v1.log')).open('w') as log:result=subprocess.run(['nice','-n','10',str(r/'scripts/memcap.sh'),*args],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 records.append(dict(label=label,returncode=result.returncode))
 if result.returncode:raise RuntimeError((label,result.returncode))
try:
 assert json.loads((e/'captured-consumer-state-v2.json').read_text())['status']=='passed'
 assert json.loads((e/'captured-consumer-audit-state-v2.json').read_text())['status']=='passed'
 run('fixture-module',['python3','scripts/lake-serial-build.py','--budget','4G','--max-jobs','1','--max-cap','4G','--default-cap','4G','--out',str(e/'captured-native-fixture-modules-v1'),'FVTest.Backend.Lowering.StockMemoryProductionLinked'])
 for exe in ['lean-backend','lean-backend-lowering-trace','link-check','lean-link','stock-memory-linked']:run('build-'+exe,['lake','build',exe])
 run('trace-regression',['python3','-m','unittest','discover','-s','scripts','-p','test_lowering_trace.py','-v'])
 for cfg in [False,True]:run('integration-'+('cfg' if cfg else 'singleton'),['python3','scripts/check-stock-memory-integration.py','--output',str(e/('captured-native-integration-'+('cfg' if cfg else 'singleton')+'-v1')),*(['--memory-cfg'] if cfg else [])])
 save('passed',source_base='preserved6e4; current-main port remains necessary')
except BaseException as error:save('failed',error=repr(error));raise
