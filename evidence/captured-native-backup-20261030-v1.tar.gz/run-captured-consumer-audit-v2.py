from pathlib import Path
import os,json,subprocess,datetime,time,re,psutil
b=Path('/home/lee/clifv');r=b/'.worktrees/stock-cfg-source-20261025';e=b/'.git/agent-evidence/stock-memory-20261029';env=dict(os.environ);env.update(json.loads((e/'author-env-v1.json').read_text()));env.update(FV_ROOT=str(r),FV_MEMCAP='4G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',CARGO_BUILD_JOBS='2');state=e/'captured-consumer-audit-state-v2.json'
def save(**x):state.write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),**x),indent=2)+'\n')
save(status='waiting',dependency=1844204)
while psutil.pid_exists(1844204):time.sleep(2)
assert json.loads((e/'captured-consumer-state-v2.json').read_text())['status']=='passed'
save(status='running')
log=e/'captured-consumer-audit-v2.log'
with log.open('w') as out:result=subprocess.run(['nice','-n','10',str(r/'scripts/memcap.sh'),'lake','env','lean','scripts/audit/stock-memory-cfg-production.lean'],cwd=r,env=env,stdout=out,stderr=subprocess.STDOUT)
roots={n:set(x.strip() for x in a.split(',')) for n,a in re.findall(r"'([^']+)' depends on axioms: \[([^]]*)\]",log.read_text(),re.S)}
allowed={'propext','Classical.choice','Quot.sound'}
ok=result.returncode==0 and len(roots)==18 and all(a<=allowed for a in roots.values())
save(status='passed' if ok else 'failed',returncode=result.returncode,roots={k:sorted(v) for k,v in roots.items()},expected_roots=18)
raise SystemExit(0 if ok else 1)
