Functions with unused, consumed or multiple i32/i64 divisions/remainders now use the proved Stock scalar route through the default compiler, checker, linker and generated-proof consumers. Earlier returned-division routes and legacy fallback remain available. Original operands, argument/slot witnesses and zero/overflow traps are preserved.

Reuses #604's retained-record/result-binding and guarded source transfers, with a source-derived return-and-trap domain and 288 complete fixed pipeline witnesses. An observed author-build memory failure is addressed by chunking the existing generated select proof while preserving its old headers and exact axiom sets; failed-attempt diagnostics are saved before retries.

Current author validation passed on `cd57ac63`, based on main `1510186e`:

- 3,947/3,947 normal keys; 19 audits/577 public roots; 33 ownership partitions. All 497 prior production and 13 sink axiom sets, 17 scalar/10 shape headers and 30 prior native grids remain exact.
- 24 encoded objects and 14,640 native Lean-byte executions against Cranelift: zero failures/disagreements. Current/retained integration passed all 76/32 command records, including fresh generated proofs, CLI checks and verified links.
- Runtime corpus, 1,398 identical encoder cases, both 1,159-identity E2E modes with original identities/ordered stages retained, actual crate-proofs (1,659-job default build), and fault co-simulation (152 forms/15,200 vectors/zero failures) passed.
- Verified fv-demo/survey passed all 2/18 executable checks and 21/53 test outcomes; artifact retention and all 17 final readiness checks passed.

Publication `b4cf48e1` changes four documentation files only; normal-key/trust replay and executable-hash equivalence retain the original code-bound receipts. [Release evidence](https://github.com/eth-act/clifv/blob/b4cf48e174ae6bf4b4fc357a84b3a3e97e1b7b21/docs/research/stock-general-div-production-activation.md) records exact scope and provenance; terminal evidence is backed at `69182545e98f69505bd1fee79c99bb3f579a5818`.

Full #140 remains open, including original widths, control/memory/calls/effects, whole-driver simulation and Stock-only/downstream completeness. The default allocator remains Lean; this class does not complete general register alignment.
