import FV.Backend.StockMemoryCheck

namespace Backend.Stock.Memory.Store

/-- Retain the existing effect forms and admit concrete store effects. -/
def effectInstruction : MInst → Bool
  | .store .. => true
  | i => Memory.effectInstruction i

/-- The store consumer checks the actual emitted instructions. -/
def effectsOnly (vc : VCode) : Bool :=
  vc.blocks.toList.all (fun b => b.insts.toList.all effectInstruction)

/-- The previous whitelist remains accepted exactly as before. -/
theorem effectsOnly_of_previous {vc : VCode} (previous : Memory.effectsOnly vc = true) :
    effectsOnly vc = true := by
  apply List.all_eq_true.mpr
  intro b member
  apply List.all_eq_true.mpr
  intro i present
  have before := List.all_eq_true.mp (List.all_eq_true.mp previous b member) i present
  cases i <;> simp_all [effectInstruction,Memory.effectInstruction]

end Backend.Stock.Memory.Store
