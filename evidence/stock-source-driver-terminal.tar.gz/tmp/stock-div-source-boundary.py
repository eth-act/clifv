from pathlib import Path
import subprocess,json,hashlib,re,sys
base=sys.argv[1];out=Path(sys.argv[2]);head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
changes=[line.split('\t',1) for line in subprocess.check_output(['git','diff','--name-status',base,head],text=True).splitlines()]
allowed='FV/Backend/Proof/StockNoLoadSink.lean'
assert all(status=='A' or path==allowed or path.startswith('docs/') for status,path in changes),changes
old=subprocess.check_output(['git','show',base+':'+allowed],text=True);new=Path(allowed).read_text();ending='end Backend.Stock.Proof.SinkRules\n';prefix=old.removesuffix(ending)
assert new.startswith(prefix) and new.endswith(ending)
addition=new[len(prefix):-len(ending)];assert addition.count('theorem ')==1 and 'theorem no_load_branch' in addition
modules=[path.removesuffix('.lean').replace('/','.') for status,path in changes if status=='A' and path.startswith('FV/') and path.endswith('.lean')]
oldpaths=subprocess.check_output(['git','ls-tree','-r','--name-only',base],text=True).splitlines()
for path in oldpaths:
 if not path.endswith('.lean'):continue
 for line in Path(path).read_text().splitlines():
  if line.startswith('import '):assert not any(m in line.split()[1:] for m in modules),(path,line)
for status,path in changes:
 if path.endswith('.lean') and path.startswith('FV/'):
  assert not re.search(r'\b(sorry|admit|axiom|trace_state)\b',Path(path).read_text()),path
mcp=json.load(open('/tmp/stock-div-source-author/mcp.json'));assert sorted(mcp['structuredContent']['axioms'])==sorted(['propext','Classical.choice','Quot.sound']) and mcp['structuredContent']['warnings']==[]
p='FV/Backend/Proof/StockScalarGeneralDivDomain.lean';original=subprocess.check_output(['git','show','898e865b:'+p]);assert Path(p).read_bytes()==original
r={'state':'passed','base':base,'candidate':head,'all_existing_sources_exact_except_one_additive_branch_lemma':True,'existing_theorem_bodies_and_headers_exact':True,'old_consumers_import_no_new_modules':True,'existing_runtime_compiler_checker_linker_generated_source_unchanged':True,'mcp_source_exact':True,'mcp_source_sha256':hashlib.sha256(original).hexdigest(),'mcp_review_original_source':'eb24f241; unchanged bytes after reconciliation','changes':changes,'full_140_complete':False}
out.write_text(json.dumps(r,indent=2)+'\n');print('SOURCE_BOUNDARY_OLD_VARIANTS_CONSUMERS_MCP_EXACT')
