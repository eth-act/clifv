from pathlib import Path
import re,json,sys,hashlib
old=Path('/tmp/stock-div-sink-author/audit.log');new=Path(sys.argv[1]);out=Path(sys.argv[2])
def parse(p):
 s=p.read_text();r={}
 for m in re.finditer(r"'([^']+)' (does not depend on any axioms|depends on axioms: \[([^\]]*)\])",s):
  r[m[1]]=set(x.strip() for x in (m[3] or '').split(',') if x.strip())
 return r
oldr=parse(old);newr=parse(new);assert len(oldr)==13
# One known fixed fact has two Lean display spellings. This is an explicit
# old-to-actual identity, not permission for other native axiom additions.
short='Backend.Stock.Proof.SinkRules.Witness.observed_true._native.native_decide.ax_1✝'
full='_private.FV.Backend.Proof.StockNoLoadSinkWitness.0.Backend.Stock.Proof.SinkRules.Witness.observed_true._native.native_decide.ax_1'
for k,v in oldr.items():
 expected={full if x==short else x for x in v}
 assert k in newr and expected==newr[k],(k,expected,newr.get(k))
r={'state':'passed','prior_roots':len(oldr),'all_prior_axiom_sets_exact':True,'display_identity':{short:full},'old_log':str(old),'old_sha256':hashlib.sha256(old.read_bytes()).hexdigest(),'new_log':str(new),'new_sha256':hashlib.sha256(new.read_bytes()).hexdigest()};out.write_text(json.dumps(r,indent=2)+'\n');print('ALL_13_PRIOR_AXIOM_SETS_EXACT')
