from pathlib import Path
import json,os,subprocess,tarfile,hashlib,datetime
root=Path('/home/lee/clifv/.worktrees/stock-mixed-div-20261022')
gates=Path(os.environ.get('SOURCE_FINAL_GATES','/tmp/stock-div-source-current-main-gates'))
# Only terminally successful evidence may be described as terminal.
summary=json.loads((gates/'receipt.json').read_text());assert summary['state']=='passed',summary
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
out=Path('/tmp/stock-source-driver-terminal-'+stamp);out.mkdir();paths=set()
for pattern in ['stock-div-source-*','stock-div-sink-author','stock-div-current-status.md','stock-div-source-axiom-parity.py','stock-div-source-terminal-backup.py','stock-outcome-view-cleanup.json','stock-outcome-view-backup.json','stock-general-div-latest-draft-backup.json']:
 for p in Path('/tmp').glob(pattern):
  if p.is_file():paths.add(p)
  elif p.is_dir():paths.update(x for x in p.rglob('*') if x.is_file())
paths={p for p in paths if p.suffix not in ['.gz','.tar','.olean','.ilean','.pyc']}
manifest={'files':{str(p):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(paths)},'summary':summary,'full_140_complete':False}
mp=out/'manifest.json';mp.write_text(json.dumps(manifest,indent=2)+'\n');archive=out/'evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=1) as t:
 for p in sorted(paths):t.add(p,arcname=str(p).lstrip('/'),recursive=False)
 t.add(mp,arcname='manifest.json')
assert archive.stat().st_size<90*1024*1024,archive.stat().st_size
with tarfile.open(archive) as t:
 for p in sorted(paths):assert hashlib.sha256(t.extractfile(str(p).lstrip('/')).read()).hexdigest()==manifest['files'][str(p)]['sha256']
def git(*args,**kw):return subprocess.check_output(['git',*args],cwd=root,**kw).decode().strip()
head=git('rev-parse','HEAD');env=dict(os.environ,GIT_INDEX_FILE=str(out/'index'));git('read-tree',head,env=env)
blob=git('hash-object','-w',str(archive));git('update-index','--add','--cacheinfo','100644',blob,'evidence/stock-source-driver-terminal.tar.gz',env=env)
tree=git('write-tree',env=env);commit=git('commit-tree',tree,'-p',head,input=b'Preserve terminal source-driver author evidence and all failed attempts\n');branch='agent/stock-source-driver-evidence-'+stamp;git('update-ref','refs/heads/'+branch,commit);git('push','origin',commit+':refs/heads/'+branch);assert git('ls-remote','origin','refs/heads/'+branch).split()[0]==commit
result={'state':'remote_verified','source_parent':head,'gates':str(gates),'backup_commit':commit,'branch':branch,'archive':str(archive),'archive_bytes':archive.stat().st_size,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':len(paths),'full_140_complete':False};Path('/tmp/stock-div-source-terminal-backup.json').write_text(json.dumps(result,indent=2)+'\n');(out/'index').unlink();print(json.dumps(result))
