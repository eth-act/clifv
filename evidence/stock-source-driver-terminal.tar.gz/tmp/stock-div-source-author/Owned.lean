import Lean
import FV.Backend.Proof.StockNoLoadSink
import FV.Backend.Proof.StockNoLoadSource
import FV.Backend.Proof.StockNoLoadScan
import FV.Backend.Proof.StockNoLoadDriver
import FV.Backend.Proof.StockScalarDivBodyRecords
import FV.Backend.Proof.StockScalarDivBodyRefines
import FV.Backend.Proof.StockScalarGeneralDivDomain
import FV.Backend.Proof.StockNoLoadDriverWitness
import FV.Backend.Proof.StockNoLoadBranchWitness
import FV.Backend.Proof.StockScalarDivSourceWitness
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let core := #["FV.Backend.Proof.StockNoLoadSink", "FV.Backend.Proof.StockNoLoadSource", "FV.Backend.Proof.StockNoLoadScan", "FV.Backend.Proof.StockNoLoadDriver", "FV.Backend.Proof.StockScalarDivBodyRecords", "FV.Backend.Proof.StockScalarDivBodyRefines", "FV.Backend.Proof.StockScalarGeneralDivDomain"]
  let witnesses := #["FV.Backend.Proof.StockNoLoadDriverWitness", "FV.Backend.Proof.StockNoLoadBranchWitness", "FV.Backend.Proof.StockScalarDivSourceWitness"]
  let fixedFacts := #["_private.FV.Backend.Proof.StockNoLoadDriverWitness.0.Backend.Stock.Proof.SinkRules.DriverWitness.observed._native.native_decide.ax_1", "_private.FV.Backend.Proof.StockNoLoadBranchWitness.0.Backend.Stock.Proof.SinkRules.BranchWitness.checked._native.native_decide.ax_1", "_private.FV.Backend.Proof.StockScalarDivSourceWitness.0.Backend.Stock.Proof.SinkRules.DriverWitness.dominated_checked._native.native_decide.ax_1"]
  let mut ncore : Nat := 0
  let mut nwitness : Nat := 0
  for (name,_) in env.constants.toList do
    let some i := env.getModuleIdxFor? name | continue
    let owner := env.header.moduleNames[i]!.toString
    unless core.contains owner || witnesses.contains owner do continue
    for ax in ← collectAxioms name do
      if #[``propext,``Classical.choice,``Quot.sound].contains ax then continue
      unless witnesses.contains owner && fixedFacts.contains ax.toString do
        throwError "disallowed axiom {ax} in {name} owned by {owner}"
    if core.contains owner then ncore := ncore+1 else nwitness := nwitness+1
  unless ncore > 0 do throwError "empty core partition"
  unless nwitness > 0 do throwError "empty witness partition"
  logInfo m!"STOCK_GENERAL_DIV_OWNED_STANDARD_CORE {ncore}; FIXED_WITNESSES {nwitness}"
