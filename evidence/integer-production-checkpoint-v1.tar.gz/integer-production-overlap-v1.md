@kevaundray @parithosh: worker-O now integrates the proved unsigned single-load classes fori8/i16/i64. The new four-width scan/body/domain, paired function and machine NI proofs pass language-server checking. A complete paired ABI-entry witness also passes for every width. The runtime selector excludesi32, preserving its existing provider.

Concrete shared changes will touch FV/Backend/SemanticNICheck.lean; FV/E2E/CompiledSemantic.lean, CompiledSemanticNI.lean and SemanticNIBoundary.lean; FVTest/Backend/Main.lean and Lowering/Trace.lean; FVTest/E2E/LinkCheckMain.lean; FVTest/Link/LeanLinkMain.lean; and maintained integration/trace tests. New provider/runtime/proof modules remain separate.

The global route list appends route14 and preserves0–13. Linker-local priorities remain internally consistent with their own recorded choices. Previous source, allocator, settings, typed/opt/try guards and complete fallback remain intact. Worker-A retains scalar/projection files; this work does not edit them. Please flag a concrete overlap. No contributor status is treated as a reservation.

Existing captured view; normal16GiB budget; no new cache/worktree. Full#140 remains active.
