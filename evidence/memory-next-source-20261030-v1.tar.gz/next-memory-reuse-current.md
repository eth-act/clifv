Next-batch source note (not validation):
- Reuse existing Backend.Stock.Proof.MaskBody.actual_nop_record_at_block in StockMaskBlockRecords. The older saved StockMemoryNopRecords draft duplicates it and is superseded; preserve archive but do not install duplicate.
- StockMemoryRetainedReturnSpec draft derives arbitrary-index returned load and classifies every real body record as that load or an actual omitted NOP. It reuses returned-definition demand and unique source positions, with inherited parameter pointer support. Must build and witness after current frozen gates release lanes.
- StockMemoryOmittedPairedScan draft composes existing one-world omission in both initialized worlds. Must build/witness before using.
- These are internal derivations, not external accepted-input premises. Next compose guarded/paired body, entry jump/inherited values, return and actual captured PC0 witness, then provider/checker/production/full gates. Old theorem variants remain.
- Current memory author HEAD remains6e4; no tracked edits or current production class expansion while gates run.
