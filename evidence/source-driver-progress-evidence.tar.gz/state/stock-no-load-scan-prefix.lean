import FV.Backend.Proof.StockNoLoadSink

/-! Complete sunk-array preservation through actual binding, opportunistic aliases
and retained scan records, derived from the generated-program invariant. -/
namespace Backend.Stock.Proof.SinkRules
open Backend.Proof Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 4096
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm

def SunkEq (st next : State) : Prop := next.sunk = st.sunk
private theorem SunkEq.refl (st : State) : SunkEq st st := rfl
private theorem SunkEq.trans {a b c : State} (ab : SunkEq a b) (bc : SunkEq b c) : SunkEq a c := Eq.trans bc ab
private def stableFields (st : State) := st.sunk
private theorem stableFields_rel {st next : State}
    (same : stableFields next = stableFields st) : SunkEq st next := same

private theorem setAlias_stableFields {st next : State} {dst src : Reg}
    (h : st.setAlias dst src = .ok next) : stableFields next = stableFields st := by
  cases dst <;> cases src <;>
    simp only [State.setAlias,bind,Except.bind,pure,Except.pure,
      throw,throwThe,MonadExceptOf.throw] at h
  all_goals repeat' first | (solve | cases h) | (solve | cases h; rfl) | split at h
private theorem fold_fields_eq {α β γ : Type} (field : α → γ)
    (step : α → β → Except String α)
    (hs : ∀ a b next, step a b = .ok next → field next = field a)
    (xs : List β) {a next : α} (h : xs.foldlM step a = .ok next) :
    field next = field a := by
  induction xs generalizing a with
  | nil => cases h; rfl
  | cons x xs ih =>
    rw [List.foldlM_cons] at h
    cases he : step a x with
    | error e => simp only [he, bind, Except.bind] at h; cases h
    | ok middle =>
      simp only [he, bind, Except.bind] at h
      exact (ih h).trans (hs a x middle he)

private theorem binding_stableFields {ctx : Ctx} {pairs : List (Nat × List Reg)}
    {st next : State} {copies : Array MInst}
    (h : bindResults ctx pairs st = .ok (next, copies)) : stableFields next = stableFields st := by
  unfold bindResults at h
  apply fold_fields_eq (fun a : State × Array MInst => stableFields a.1) _ ?_ pairs h
  intro acc pair next he
  rcases acc with ⟨s, code⟩
  rcases pair with ⟨v, rs⟩
  dsimp only at he
  cases hm : ctx.valueReg? v with
  | none => simp only [hm] at he; cases he
  | some r =>
    simp only [hm] at he
    split at he
    · rename_i _ n cls
      cases ha : s.setAlias r (.vreg n cls) with
      | error e => simp only [ha, bind, Except.bind] at he; cases he
      | ok q =>
        simp only [ha, bind, Except.bind, pure, Except.pure] at he
        cases he
        exact setAlias_stableFields ha
    · cases he; rfl
    · cases he

private theorem commit_stableFields {ctx : Ctx} {block i : Nat} {st next : State}
    (h : commitOpportunistic ctx block i st = .ok (some next)) : stableFields next = stableFields st := by
  have values {values : List Nat} {a b : State}
      (h : commitOpportunisticValues ctx values a = .ok b) : stableFields b = stableFields a := by
    unfold commitOpportunisticValues at h
    apply fold_fields_eq stableFields _ ?_ values h
    intro a v b he
    split at he
    · split at he
      · rename_i dst hdst
        split at he
        · rename_i src _
          cases hs : a.setAlias dst src with
          | error e => simp only [hs, bind, Except.bind] at he; cases he
          | ok q =>
            simp only [hs, bind, Except.bind, pure, Except.pure] at he
            cases he
            exact setAlias_stableFields (next := q) hs
        · cases he
      · cases he
    · cases he; rfl
  unfold commitOpportunistic at h
  dsimp only at h
  split at h
  · cases h
  · cases hv : commitOpportunisticValues ctx (ctx.insts[i]!.results) st with
    | error e => simp only [hv, bind, Except.bind] at h; cases h
    | ok q =>
      simp only [hv, bind, Except.bind, pure, Except.pure] at h
      cases h
      exact values hv

private theorem scan_state_stableFields (st : State) (i : Nat) : stableFields (scanState st i) = stableFields st := by
  unfold scanState
  dsimp only
  split <;> rfl


end Backend.Stock.Proof.SinkRules
