from pathlib import Path
import os, subprocess, json, datetime, time, hashlib
import psutil

b=Path('/home/lee/clifv');r=b/'.worktrees/stock-cfg-source-20261025'
e=b/'.git/agent-evidence/stock-memory-20261029'
state=e/'integer-extending-captured-preservation-state-v1.json';records=[]
source=json.loads((e/'integer-production-source-v2.json').read_text())
env=dict(os.environ);env.update(json.loads((e/'author-env-v1.json').read_text()))
env.update(FV_ROOT=str(r),FV_MEMCAP='4G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',
           LEAN_NUM_THREADS='2',CARGO_BUILD_JOBS='1')
for key in ['FV_PIPELINE_T','BLESS']:
    env.pop(key,None)
paused=None

def save(status,**extra):
    state.write_text(json.dumps(dict(status=status,records=records,head=source['head'],
        utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),**extra),indent=2)+'\n')

def live(process):
    try:
        return process.is_running() and process.status()!=psutil.STATUS_ZOMBIE
    except psutil.NoSuchProcess:
        return False

def frozen():
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==source['head']
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=r,text=True).strip()
    assert all(hashlib.sha256((r/n).read_bytes()).hexdigest()==h for n,h in source['files'].items())

def run(label,args):
    frozen();save('running',phase=label,normal_scheduler_paused=paused.pid if paused else None)
    with (e/('integer-extending-domain-'+label+'-captured-preservation-v1.log')).open('w') as log:
        done=subprocess.run(['nice','-n','10',str(r/'scripts/memcap.sh'),*map(str,args)],
            cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
    records.append(dict(label=label,returncode=done.returncode))
    assert done.returncode==0,(label,done.returncode)

try:
    dependency=psutil.Process(3524529) if psutil.pid_exists(3524529) else None
    while dependency is not None and live(dependency):
        save('waiting',phase='full-production-gate',dependency_pid=3524529)
        time.sleep(3)
    receipt=json.loads((e/'integer-extending-production-gates-state-v1.json').read_text())
    assert receipt['status']=='passed',receipt
    frozen()
    normal=psutil.Process(3167178)
    while live(normal):
        schedulers=[]
        for child in normal.children(recursive=True):
            try:
                if child.name().startswith('python') and any(arg.endswith('/lake-serial-build.py') or arg=='scripts/lake-serial-build.py' for arg in child.cmdline()):schedulers.append(child)
            except psutil.NoSuchProcess:pass
        if not schedulers:
            save('waiting',phase='normal-tool-phase');time.sleep(3);continue
        assert len(schedulers)==1
        paused=schedulers[0];paused.suspend()
        while True:
            children=[c for c in paused.children() if live(c)]
            caps=[]
            for child in children:
                raw=child.environ().get('FV_MEMCAP','')
                if raw.endswith('G'):caps.append(float(raw[:-1]))
                elif raw.endswith('M'):caps.append(float(raw[:-1])/1024)
                else:caps.append(1000)
            if len(children)<=1 and sum(caps)<=12:
                save('running',phase='bounded-concurrent-witness',normal_active_caps_GiB=caps,focused_cap_GiB=4,max_source_jobs=2)
                break
            save('waiting',phase='normal-light-worker-finish',normal_active_caps_GiB=caps);time.sleep(2)
        break
    assert paused is not None and live(paused), 'No normal scheduler reservation; avoid overlapping queued runtime.'
    env.update(LEAN_NUM_THREADS='1',OMP_NUM_THREADS='1',OMP_THREAD_LIMIT='1')
    candidate=json.loads((e/'integer-extending-production-source-v1.json').read_text())
    current=Path(candidate['root'])
    def candidate_frozen():
        assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=current,text=True).strip()==candidate['base']
        assert all(hashlib.sha256((current/n).read_bytes()).hexdigest()==h for n,h in candidate['files'].items())
    candidate_frozen()
    run('captures',['python3',e/'run-integer-extending-captures-v1.py'])
    run('preservation',['python3',e/'run-integer-extending-preservation-v1.py'])
    assert json.loads((e/'integer-extending-production-preservation-state-v2.json').read_text())['status']=='passed'
    candidate_frozen();frozen();save('passed',original_hashes_exact=4543,object_cases_exact=8,captured_axiom_sets_exact=48,original_rejections_exact=8,scope='Original captured-input, object, axiom and settings-rejection preservation. Full140 remains incomplete.')
except BaseException as error:
    save('failed',error=repr(error),scope='Unverified next-class draft, outside786. Inspect diagnostics and fix the proof; no production regression is asserted.')
    raise
finally:
    if paused is not None and live(paused):
        paused.resume()
        (e/'integer-extending-captured-preservation-normal-resumed-v1.json').write_text(json.dumps(dict(
            scheduler_pid=paused.pid,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
            reason='Focused resource handoff ended; the existing normal scheduler resumes without a restart.'),indent=2)+'\n')
