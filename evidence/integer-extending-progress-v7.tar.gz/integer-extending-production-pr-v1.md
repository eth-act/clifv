Activate the six proved signed/unsigned extending-load forms through default and configured compilation, semantic checking, traces, both linkers and generated proofs. The selector uses existing source/scope/dominance/ABI conditions without a new result-type restriction. Global route15 follows unchanged routes0–14.

Preserve the original input, allocator callback and complete previous-provider retry. Compatibility proofs retain previous routes, raw artifacts/history and whole-file outputs outside the new selector. Fixtures cover all12 valid opcode/type combinations, signed negative results, both cleanup modes, forced retry and the five previous memory classes.

Validation on the frozen7285f5e4 source:2914 affected modules,22 executable links,13 standard-only production roots,192 exact prior axiom sets and eight retained classes passed. Native/generated matrices run now. This branch reconciles current main080500af without overlapping its ABI edits. Combined-source acceptance, official comparison and captured/rejection preservation remain pending. Full original#140 remains incomplete.

Review discipline: ONE QUICK, DIRTY, CHEAP direct peer review. No review agents or repeated review builds. Existing evidence lives under `.git/agent-evidence/stock-memory-20261029/` locally; #44 tracks the current gate state.
