from pathlib import Path
import os, subprocess, json, datetime, time, hashlib
import psutil

b=Path('/home/lee/clifv');r=b/'.worktrees/stock-cfg-source-20261025'
e=b/'.git/agent-evidence/stock-memory-20261029'
state=e/'integer-store-draft-state-v2.json';records=[]
source=json.loads((e/'integer-production-source-v2.json').read_text())
env=dict(os.environ);env.update(json.loads((e/'author-env-v1.json').read_text()))
env.update(FV_ROOT=str(r),FV_MEMCAP='4G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',
           LEAN_NUM_THREADS='2',CARGO_BUILD_JOBS='1')
for key in ['FV_PIPELINE_T','BLESS']:
    env.pop(key,None)
paused=None

def save(status,**extra):
    state.write_text(json.dumps(dict(status=status,records=records,head=source['head'],
        utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),**extra),indent=2)+'\n')

def live(process):
    try:
        return process.is_running() and process.status()!=psutil.STATUS_ZOMBIE
    except psutil.NoSuchProcess:
        return False

def frozen():
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==source['head']
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=r,text=True).strip()
    assert all(hashlib.sha256((r/n).read_bytes()).hexdigest()==h for n,h in source['files'].items())

def run(label,args):
    frozen();save('running',phase=label,normal_scheduler_paused=paused.pid if paused else None)
    with (e/('integer-extending-domain-'+label+'-store-draft-v2.log')).open('w') as log:
        done=subprocess.run(['nice','-n','10',str(r/'scripts/memcap.sh'),*map(str,args)],
            cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
    records.append(dict(label=label,returncode=done.returncode))
    assert done.returncode==0,(label,done.returncode)

try:
    receipt=json.loads((e/'integer-extending-domain-state-recovered-v1.json').read_text())
    assert receipt['status']=='passed'
    frozen()
    normal=psutil.Process(3167178)
    while live(normal):
        schedulers=[]
        for child in normal.children(recursive=True):
            try:
                if child.name().startswith('python') and any(arg.endswith('/lake-serial-build.py') or arg=='scripts/lake-serial-build.py' for arg in child.cmdline()):schedulers.append(child)
            except psutil.NoSuchProcess:pass
        if not schedulers:
            save('waiting',phase='normal-tool-phase');time.sleep(3);continue
        assert len(schedulers)==1
        paused=schedulers[0];paused.suspend()
        while True:
            children=[c for c in paused.children() if live(c)]
            caps=[]
            for child in children:
                raw=child.environ().get('FV_MEMCAP','')
                if raw.endswith('G'):caps.append(float(raw[:-1]))
                elif raw.endswith('M'):caps.append(float(raw[:-1])/1024)
                else:caps.append(1000)
            if len(children)<=1 and sum(caps)<=12:
                save('running',phase='bounded-concurrent-witness',normal_active_caps_GiB=caps,focused_cap_GiB=4,max_source_jobs=2)
                break
            save('waiting',phase='normal-light-worker-finish',normal_active_caps_GiB=caps);time.sleep(2)
        break
    assert paused is not None and live(paused), 'No normal scheduler reservation; avoid overlapping queued runtime.'
    env.update(LEAN_NUM_THREADS='1',OMP_NUM_THREADS='1',OMP_THREAD_LIMIT='1')
    packet=json.loads((e/'integer-store-draft-source-v2.json').read_text());overlay=Path(packet['root'])
    before={n:hashlib.sha256((overlay/n).read_bytes()).hexdigest() for n in packet['files']};assert before==packet['files']
    env['LEAN_PATH']=str(overlay)+':'+subprocess.check_output(['lake','env','printenv','LEAN_PATH'],cwd=r,env=env,text=True).strip()
    for rel in ['StoreMemoryProofDraftV2.lean']:
        file=overlay/rel;name=rel.removesuffix('.lean').replace('/','.')
        env['FV_MEMCAP_STATS']=str(e/('integer-extending-domain-'+name+'-v2.stats'))
        run(name,['lean','-j1','--root='+str(overlay),'-o',file.with_suffix('.olean'),file])
    env['FV_MEMCAP_STATS']=str(e/'integer-store-draft-audit-v1.stats')
    run('audit',['lean','-j1','--root='+str(overlay),overlay/'StoreMemoryProofDraftV2Audit.lean'])
    import re
    text=(e/'integer-extending-domain-audit-store-draft-v2.log').read_text()
    audit={n:set(x.strip() for x in a.split(',')) for n,a in re.findall(r"'([^']+)' depends on axioms: \[([^]]*)\]",text,re.S)}
    audit.update({n:set() for n in re.findall(r"'([^']+)' does not depend on any axioms",text)})
    assert len(audit)==2 and all(a<={'propext','Classical.choice','Quot.sound'} for a in audit.values())
    assert before=={n:hashlib.sha256((overlay/n).read_bytes()).hexdigest() for n in packet['files']}
    frozen();save('passed',audit_roots=2,all_axioms_standard=True,source_files=before,scope='Seven store RHS templates with actual enclosing side-effect emission. Source/machine write semantics and complete witnesses still follow and their audit. Additions only; no production source changed.')
except BaseException as error:
    save('failed',error=repr(error),scope='Unverified next-class draft, outside786. Inspect diagnostics and fix the proof; no production regression is asserted.')
    raise
finally:
    if paused is not None and live(paused):
        paused.resume()
        (e/'integer-store-draft-normal-resumed-v2.json').write_text(json.dumps(dict(
            scheduler_pid=paused.pid,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
            reason='Focused resource handoff ended; the existing normal scheduler resumes without a restart.'),indent=2)+'\n')
