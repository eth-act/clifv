from pathlib import Path
import os,json,subprocess,hashlib,datetime,time,psutil
b=Path('/home/lee/clifv');e=b/'.git/agent-evidence/stock-memory-20261029';r=b/'.worktrees/stock-cfg-source-20261025'
state=e/'integer-extending-records-publish-state-v2.json'
def save(status,**more):state.write_text(json.dumps(dict(status=status,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),**more),indent=2)+'\n')
def git(*args,env=None):return subprocess.check_output(['git',*args],cwd=b,env=env,text=True).strip()
try:
 while psutil.pid_exists(3374289):
  try:
   if psutil.Process(3374289).status()==psutil.STATUS_ZOMBIE:break
  except psutil.NoSuchProcess:break
  save('waiting',dependency_pid=3374289);time.sleep(5)
 receipt=json.loads((e/'integer-extending-records-state-v2.json').read_text());assert receipt['status']=='passed',receipt
 assert receipt['audit_roots']==14 and receipt['all_axioms_standard']
 packet=json.loads((e/'integer-extending-record-source-v1.json').read_text());root=Path(packet['root'])
 files=packet['files'];assert all(hashlib.sha256((root/n).read_bytes()).hexdigest()==h for n,h in files.items())
 subprocess.run(['git','fetch','origin','main'],cwd=b,check=True)
 base=git('rev-parse','origin/main')
 allowed=set(json.loads((e/'integer-extending-module-source-v1.json').read_text())['files'])
 changed=set(git('diff','--name-only','c243fa6f671311ea42786b739e97c53f5a021e6a',base,'--','FV','FVTest','lakefile.lean','lake-manifest.json').splitlines())
 assert changed <= allowed,changed-allowed
 for n in changed:
  assert hashlib.sha256(subprocess.check_output(['git','show',base+':'+n],cwd=b)).hexdigest()==json.loads((e/'integer-extending-module-source-v1.json').read_text())['files'][n]
 assert git('-C',str(r),'rev-parse','HEAD')=='c243fa6f671311ea42786b739e97c53f5a021e6a'
 assert not git('-C',str(r),'status','--porcelain')
 branch='agent/stock-extending-load-records-20261031';ref='refs/heads/'+branch
 assert subprocess.run(['git','show-ref','--verify','--quiet',ref],cwd=b).returncode!=0
 index=e/'integer-extending-records-publish-v2.index';assert not index.exists();env=dict(os.environ,GIT_INDEX_FILE=str(index))
 git('read-tree',base,env=env)
 for n in files:
  assert subprocess.run(['git','cat-file','-e',base+':'+n],cwd=b,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode!=0,n
  blob=git('hash-object','-w',str(root/n));git('update-index','--add','--cacheinfo','100644,'+blob+','+n,env=env)
 tree=git('write-tree',env=env);subprocess.run(['git','diff','--check',base,tree],cwd=b,check=True)
 assert set(git('diff','--name-only',base,tree).splitlines())==set(files)
 commit=git('commit-tree',tree,'-p',base,'-m','Bind extending-load records to original source and guarded execution')
 git('update-ref',ref,commit,'0'*40);index.unlink()
 subprocess.run(['git','push','-u','origin',branch],cwd=b,check=True)
 assert git('ls-remote','origin',ref).split()[0]==commit
 url=subprocess.check_output(['gh','pr','create','--repo','eth-act/clifv','--base','main','--head',branch,'--title','Bind extending-load records to original source and guarded execution','--body-file',str(e/'integer-extending-records-pr-v1.md')],cwd=b,text=True).strip()
 save('published',commit=commit,base=base,branch=branch,pr=url,files=files,scope='Eight new retained/source proof modules and14-root audit. No production activation. Not merged; inspect final gates first.')
 print(json.dumps(dict(commit=commit,pr=url)))
except BaseException as error:
 save('failed',error=repr(error));raise
