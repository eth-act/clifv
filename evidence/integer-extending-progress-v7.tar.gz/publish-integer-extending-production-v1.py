from pathlib import Path
import subprocess,os,json,hashlib,datetime
b=Path('/home/lee/clifv');e=b/'.git/agent-evidence/stock-memory-20261029'
p=json.loads((e/'integer-extending-production-source-v1.json').read_text());r=Path(p['root'])
def git(*args,env=None):return subprocess.check_output(['git',*args],cwd=b,env=env,text=True).strip()
base='080500afd9d6e52e4af5fd13acd98ccea5516197'
subprocess.run(['git','fetch','origin','main'],cwd=b,check=True)
assert git('rev-parse','origin/main')==base,'Inspect further main drift first'
assert git('-C',str(r),'rev-parse','HEAD')==p['base']
for name,digest in p['files'].items():
 assert hashlib.sha256((r/name).read_bytes()).hexdigest()==digest
 # Every candidate file is unchanged by the intervening main commits.
 assert git('ls-tree',p['base'],'--',name)==git('ls-tree',base,'--',name),name
idx=e/'integer-extending-production-publish-v1.index';idx.unlink(missing_ok=True)
env=dict(os.environ,GIT_INDEX_FILE=str(idx));git('read-tree',base,env=env)
for name in p['files']:
 oid=git('hash-object','-w',str(r/name));git('update-index','--add','--cacheinfo','100644,'+oid+','+name,env=env)
tree=git('write-tree',env=env)
commit=git('commit-tree',tree,'-p',base,'-m','Activate proved Stock extending loads across production consumers')
branch='agent/stock-extending-production-pr-20261031'
git('update-ref','refs/heads/'+branch,commit)
subprocess.run(['git','push','origin',branch],cwd=b,check=True)
assert git('ls-remote','origin','refs/heads/'+branch).split()[0]==commit
idx.unlink()
receipt=dict(commit=commit,base=base,branch=branch,remote_verified=True,files=len(p['files']),frozen_view_unchanged=True,utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(e/'integer-extending-production-published-v1.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
