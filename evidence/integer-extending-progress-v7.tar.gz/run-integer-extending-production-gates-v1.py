from pathlib import Path
import os,subprocess,json,datetime,time,hashlib,re,psutil
b=Path('/home/lee/clifv');r=b/'.worktrees/stock-extending-production-20261031';oldr=b/'.worktrees/stock-cfg-source-20261025';e=b/'.git/agent-evidence/stock-memory-20261029'
packet=json.loads((e/'integer-extending-production-source-v1.json').read_text());old=json.loads((e/'integer-production-source-v2.json').read_text());records=[];paused=None
state=e/'integer-extending-production-gates-state-v1.json';env=dict(os.environ);env.update(json.loads((e/'author-env-v1.json').read_text()));env.update(FV_ROOT=str(r),FV_MEMCAP='12G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',CARGO_BUILD_JOBS='1',PYTHONDONTWRITEBYTECODE='1')
for k in ['FV_PIPELINE_T','BLESS']:env.pop(k,None)
def save(status,**x):state.write_text(json.dumps(dict(status=status,records=records,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),**x),indent=2)+'\n')
def live(p):
 try:return p.is_running() and p.status()!=psutil.STATUS_ZOMBIE
 except psutil.NoSuchProcess:return False
def frozen():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==packet['base']
 assert all(hashlib.sha256((r/n).read_bytes()).hexdigest()==h for n,h in packet['files'].items())
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=oldr,text=True).strip()==old['head']
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=oldr,text=True).strip()
 assert all(hashlib.sha256((oldr/n).read_bytes()).hexdigest()==h for n,h in old['files'].items())
def run(label,args):
 frozen();save('running',phase=label)
 with (e/('integer-extending-production-'+label+'-v1.log')).open('w') as log:
  result=subprocess.run(['nice','-n','10',str(r/'scripts/memcap.sh'),*map(str,args)],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 records.append(dict(label=label,returncode=result.returncode));assert result.returncode==0,(label,result.returncode)
def axioms(path):
 s=path.read_text();d={n:set(x.strip() for x in a.split(',')) for n,a in re.findall(r"'([^']+)' depends on axioms: \[([^]]*)\]",s,re.S)}
 d.update({n:set() for n in re.findall(r"'([^']+)' does not depend on any axioms",s)});return d
try:
 frozen();normal=psutil.Process(3167178)
 while live(normal):
  sched=[]
  for c in normal.children(recursive=True):
   try:
    if c.name().startswith('python') and any(a.endswith('/lake-serial-build.py') or a=='scripts/lake-serial-build.py' for a in c.cmdline()):sched.append(c)
   except psutil.NoSuchProcess:pass
  if not sched:save('waiting',phase='normal-tool-phase');time.sleep(3);continue
  assert len(sched)==1;paused=sched[0];paused.suspend();save('waiting',phase='finish-active-normal-modules',scheduler=paused.pid)
  while any(live(c) for c in paused.children(recursive=True)):time.sleep(3)
  rss=0
  for c in [normal,*normal.children(recursive=True)]:
   try:
    if live(c):rss+=c.memory_info().rss
   except psutil.NoSuchProcess:pass
  assert rss<4*1024**3,('Normal reserve exceeded',rss)
  break
 assert paused is not None and live(paused),'No normal scheduler reservation; do not overlap queued runtime.'
 closure=json.loads((e/'integer-extending-production-closure-v1.json').read_text())
 assert {'lean-backend','lean-backend-lowering-trace','link-check','lean-link','stock-memory-linked','stock-memory-retained'}<=set(closure['executables'])
 run('affected-modules',['python3','scripts/lake-serial-build.py','--budget','12G','--max-jobs','1','--max-cap','12G','--default-cap','4G','--profile',r/'scripts/lake-module-peaks.tsv','--profile',oldr/'.lake/lake-module-peaks.tsv','--profile',e/'integer-extending-production-peaks-v1.tsv','--out',e/'integer-extending-production-affected-v1',*closure['roots']])
 run('executables',['lake','build',*closure['executables']])
 run('production-audit',['lake','env','lean','scripts/audit/stock-memory-extending-production.lean'])
 actual=axioms(e/'integer-extending-production-production-audit-v1.log');assert len(actual)==13 and all(x<={'propext','Classical.choice','Quot.sound'} for x in actual.values())
 exact=0
 baselines=[('source','stock-memory-source.lean','author-normal-gates-v1/all-axioms/stock-memory-source.log',105),('helpers','stock-memory-integer-forward.lean','integer-memory-integrated-audit-v1.log',12),('roots','stock-memory-integer-roots.lean','integer-load-roots-audit-v2.log',5),('records','stock-memory-integer-records.lean','integer-records-audit-v1.log',19),('integer-production','stock-memory-integer-production.lean','integer-production-audit-v1.log',17),('ext-roots','stock-memory-extending-load.lean','integer-extending-modules-audit-v2.log',6),('ext-records','stock-memory-extending-records.lean','integer-extending-records-audit-v2.log',14),('ext-domain','stock-memory-extending-domain.lean','integer-extending-domain-audit-v3.log',12),('ext-function','stock-memory-extending-function-witness.lean','integer-extending-domain-audit-function-witness-v1.log',2)]
 for label,script,baseline,count in baselines:
  run('prior-'+label,['lake','env','lean','scripts/audit/'+script]);prior=axioms(e/baseline);now=axioms(e/('integer-extending-production-prior-'+label+'-v1.log'));assert len(now)==count and now==prior,(label,'axiom drift');exact+=count
 assert exact==192
 for kind in ['parameter','conditional-forward','conditional','forward','linear','scalar-entry','entry','cfg']:run('retained-'+kind,[r/'.lake/build/bin/stock-memory-retained',kind])
 matrices=[]
 for op,types in [('uload8',['i16','i32','i64']),('sload8',['i16','i32','i64']),('uload16',['i32','i64']),('sload16',['i32','i64']),('uload32',['i64']),('sload32',['i64'])]:
  for ty in types:matrices.append((op+'-'+ty,['--load-op',op,'--load-type',ty]))
 matrices += [(ty,['--load-type',ty]) for ty in ['i8','i16','i32','i64']]+[('cfg32',['--memory-cfg'])]
 for label,args in matrices:run('consumers-'+label,['python3','scripts/check-stock-memory-integration.py','--output',e/('integer-extending-production-consumers-'+label+'-v1'),*args])
 # The maintained comparison entrypoint runs the provider/trace/schedule/exporter/pipeline unit gates once.
 run('official',['python3',e/'run-integer-extending-official-v1.py'])
 official=json.loads((e/'integer-extending-production-official-state-v2.json').read_text());assert official['status']=='passed'
 frozen();save('passed',reverse_roots=len(closure['roots']),executables=closure['executables'],production_audit_roots=13,prior_axiom_sets_exact=192,native_matrices=len(matrices),official=official.get('totals'),scope='Current per-PR affected/Lake/native/generated/retained/official gates. Full original140 remains incomplete; broad normal/runtime and captured/rejection preservation still require their complete evidence.')
except BaseException as error:save('failed',error=repr(error));raise
finally:
 if paused is not None and live(paused):
  paused.resume();(e/'integer-extending-production-normal-resumed-v1.json').write_text(json.dumps({'scheduler':paused.pid,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reason':'Production gate ended; resume the same old normal scheduler without restarting any module.'},indent=2)+'\n')
