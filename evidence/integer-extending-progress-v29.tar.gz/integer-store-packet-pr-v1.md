Prove all seven integer-store RHS templates, including the enclosing side-effect emission and exact demand/state behavior. The source/write bridge supports arbitrary source/register numbering, transports the updated memory relation and preserves every virtual register.

Source-built witnesses cover first-match selection, complete RHS execution and full lowering for all seven roots. The witnesses use nonidentity operand registers192/193. These additions preserve existing theorem interfaces and acceptance conditions. Retained-record binding, paired writes, store production activation and the full original#140 remain incomplete.

Validation: all three actual module paths passed focused kernel checks. All seven public audit roots use only standard axioms. The complete import closure has263 repository modules; none intersects the extending activation paths. The parent tree exactly equals the validated0db8235d production tree. No compiler behavior changes in this packet.

Landing uses the user's test route after current CI checks pass. No human review gate or review agents.
