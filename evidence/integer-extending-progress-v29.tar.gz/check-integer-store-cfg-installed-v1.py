from pathlib import Path
import subprocess,os,json,datetime,hashlib,re
b=Path('/home/lee/clifv');e=b/'.git/agent-evidence/stock-memory-20261029';r=b/'.worktrees/stock-extending-production-20261031';state=e/'integer-store-cfg-installed-state-v1.json';records=[]
modules=['lean-backend','lean-e2e-check','lean-link','link-check','stock-memory-store-cfg-linked']
def save(status,**x):state.write_text(json.dumps(dict(status=status,records=records,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),**x),indent=2)+'\n')
try:
 env=dict(os.environ);env.update(json.loads((e/'author-env-v1.json').read_text()));env.update(FV_ROOT=str(r),FV_MEMCAP='16G',LEAN_NUM_THREADS='2',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2')
 hashes={}
 for name in modules:
  save('running',phase=name)
  with (e/('integer-store-cfg-installed-'+name+'-v1.log')).open('w') as out:
   p=subprocess.run(['nice','-n','10',str(r/'scripts/memcap.sh'),'lake','build',name],cwd=r,env=env,stdout=out,stderr=subprocess.STDOUT)
  records.append(dict(module=name,returncode=p.returncode));assert p.returncode==0,records
 for label,args in [('configured',['python3','scripts/test_stock_configured_provider.py']),('first-cfg-consumers',['python3','scripts/check-stock-memory-store-integration.py','--memory-cfg','--store-type','i32','--output',str(e/'integer-store-cfg-first-consumers-i32-v1')])]:
  save('running',phase=label)
  with (e/('integer-store-cfg-installed-'+label+'-v1.log')).open('w') as out:
   p=subprocess.run(['nice','-n','10',str(r/'scripts/memcap.sh'),*args],cwd=r,env=env,stdout=out,stderr=subprocess.STDOUT)
  records.append(dict(gate=label,returncode=p.returncode));assert p.returncode==0,records
 save('passed',source_hashes=hashes,scope='Actual retained arbitrary-index store and complete guarded/paired body composition with surrounding original NOPs. Witness and audit gates remain open.')
except BaseException as error:save('failed',error=repr(error));raise
