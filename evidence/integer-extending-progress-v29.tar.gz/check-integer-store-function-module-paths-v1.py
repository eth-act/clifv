from pathlib import Path
import psutil,subprocess,json,hashlib,os,time,datetime,re
b=Path('/home/lee/clifv');e=b/'.git/agent-evidence/stock-memory-20261029';r=b/'.worktrees/stock-extending-production-20261031';stage=e/'integer-store-function-module-paths-v1';state=e/'integer-store-function-module-paths-state-v1.json';paused=None;records=[]
source=json.loads((e/'integer-store-functions-source-v3.json').read_text())['files'];base='330e55698e83dbfe80a6524a6e916a44f6a3dd8b'
def save(status,**x):state.write_text(json.dumps(dict(status=status,records=records,base=base,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),**x),indent=2)+'\n')
def live(p):
 try:return p.is_running() and p.status()!=psutil.STATUS_ZOMBIE
 except psutil.NoSuchProcess:return False
def frozen():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==base
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=r,text=True).strip()
 for n,data in source.items():assert hashlib.sha256(Path(data['source']).read_bytes()).hexdigest()==data['sha256'] and not (r/n).exists()
try:
 frozen()
 for n,data in source.items():
  dest=stage/n;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(Path(data['source']).read_bytes())
 roots=['Backend.Stock.Proof.stock_lower_store_emitted']+['Backend.Stock.Memory.StoreRoots.'+n for n in ['stock_lower_source_parameter_type','stock_single_store_return_spec','stock_lower_integer_store_scan_fall_refines','stock_lower_integer_store_paired_source_step','stock_single_store_return_body']]+['E2E.StockMemory.StoreRoots.'+n for n in ['stock_lower_integer_store_paired_scan','stock_single_store_return_paired_body','single_store_return_paired_function_seeded','single_store_return_paired_function']]+['E2E.StockMemoryStoreFunctionWitness.complete_paired_integer_store_function_witness','Backend.Stock.Memory.StoreRoots.domain_of_single_store_return','Backend.Stock.Memory.StoreRoots.SingleClass.domain','E2E.StockMemoryStoreFunctionWitness.source_class_witness','E2E.StockMemoryStoreUninitializedWitness.complete_paired_uninitialized_store_function_witness']
 audit=stage/'scripts/audit/stock-memory-store-functions.lean';audit.parent.mkdir(parents=True,exist_ok=True);audit.write_text('\n'.join('import '+n[:-5].replace('/','.') for n in source)+'\n'+(r/'scripts/audit/stock-memory-store-records.lean').read_text()+'\n'+'\n'.join('#print axioms '+n for n in roots)+'\n')
 paused=psutil.Process(363555);assert any(a=='scripts/lake-serial-build.py' for a in paused.cmdline());paused.suspend()
 while True:
  children=[c for c in paused.children() if live(c)];caps=[]
  for c in children:
   raw=c.environ().get('FV_MEMCAP','');caps.append(float(raw[:-1]) if raw.endswith('G') else float(raw[:-1])/1024 if raw.endswith('M') else 1000)
  if len(children)<=1 and sum(caps)<=12:break
  save('waiting',phase='finish-current-active-source',caps_GiB=caps);time.sleep(3)
 env=dict(os.environ);env.update(json.loads((e/'author-env-v1.json').read_text()));env.update(FV_ROOT=str(r),FV_MEMCAP='4G',OMP_NUM_THREADS='1',OMP_THREAD_LIMIT='1',LEAN_NUM_THREADS='1',CARGO_BUILD_JOBS='1',PYTHONDONTWRITEBYTECODE='1')
 for name in [*source,'scripts/audit/stock-memory-store-functions.lean']:
  frozen();label=Path(name).stem;save('running',phase=name)
  args=['lake','env','lean','-j1','--root='+str(stage)]
  if name in source:
   output=r/'.lake/build/lib/lean'/Path(name).with_suffix('.olean');output.parent.mkdir(parents=True,exist_ok=True);args+=['-o',str(output)]
  args+=[str(stage/name)];env['FV_MEMCAP_STATS']=str(e/('integer-store-module-path-'+label+'-v1.stats'))
  with (e/('integer-store-module-path-'+label+'-v1.log')).open('w') as out:run=subprocess.run(['nice','-n','10',str(r/'scripts/memcap.sh'),*args],cwd=r,env=env,stdout=out,stderr=subprocess.STDOUT)
  records.append(dict(module=name,returncode=run.returncode));assert run.returncode==0,records
 def axioms(p):
  text=p.read_text();a={n:set(x.strip() for x in s.split(',')) for n,s in re.findall(r"'([^']+)' depends on axioms: \[([^]]*)\]",text,re.S)};a.update({n:set() for n in re.findall(r"'([^']+)' does not depend on any axioms",text)});return a
 now=axioms(e/'integer-store-module-path-stock-memory-store-functions-v1.log');old=axioms(e/'integer-store-records-combined-v1-audit.log')
 assert len(now)==44 and all(a<={'propext','Classical.choice','Quot.sound'} for a in now.values()),now
 assert len(old)==29 and all(now[n]==a for n,a in old.items())
 frozen();save('passed',audit_roots=44,prior_axiom_sets_exact=29,all_axioms_standard=True,source=source,scope='Thirteen real module identities compiled from identical staged sources into the existing shared view outputs. No tracked or untracked source changed in the frozen view. Next branch adoption remains queued after797 landing.')
except BaseException as error:save('failed',error=repr(error));raise
finally:
 if paused is not None and live(paused):paused.resume()
