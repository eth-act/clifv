Prove complete source contracts and paired execution for singleton integer-store functions. Derive retention, parameter types, operand mappings, scan composition and ABI entry/return from original source syntax. Keep the original memory and ABI conditions.

Complete witnesses cover all seven forms. A second witness starts with unknown source bytes and different machine bytes, then executes both complete functions with the same updated source memory. The source class derives the original return/trap contract. No compiler behavior changes in this packet.

Validation: all thirteen actual module identities passed kernel checks. All44 audited roots use standard axioms, and all29 previous axiom sets remain exact. The staged sources compile into the existing view outputs without changing its frozen source. Full per-PR checks follow parent landing.

Depends on #797. This PR targets its branch until that PR lands; it will then reconcile onto current main. The source commit is remotely verified. No review agents or human review gate apply. The full original#140, production store activation and every remaining family/completeness obligation remain active.
