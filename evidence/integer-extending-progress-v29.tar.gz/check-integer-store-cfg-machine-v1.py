from pathlib import Path
import subprocess,os,json,datetime,hashlib,re
b=Path('/home/lee/clifv');e=b/'.git/agent-evidence/stock-memory-20261029';r=b/'.worktrees/stock-extending-production-20261031';state=e/'integer-store-cfg-machine-state-v1.json';records=[]
modules=['FV/Backend/Proof/StockMemoryStoreCfgClass.lean', 'FV/Backend/StockMemoryStoreCfgCheck.lean', 'FV/E2E/StockMemoryStoreCfgValue.lean', 'FV/E2E/StockMemoryStoreCfgMachine.lean', 'FV/E2E/StockMemoryStoreCfgNI.lean']
def save(status,**x):state.write_text(json.dumps(dict(status=status,records=records,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),**x),indent=2)+'\n')
try:
 env=dict(os.environ);env.update(json.loads((e/'author-env-v1.json').read_text()));env.update(FV_ROOT=str(r),FV_MEMCAP='4G',LEAN_NUM_THREADS='1',OMP_NUM_THREADS='1',OMP_THREAD_LIMIT='1')
 hashes={n:hashlib.sha256((r/n).read_bytes()).hexdigest() for n in modules}
 for name in modules:
  save('running',phase=name)
  output=r/'.lake/build/lib/lean'/Path(name).with_suffix('.olean');output.parent.mkdir(parents=True,exist_ok=True)
  with (e/('integer-store-cfg-machine-'+Path(name).stem+'-v1.log')).open('w') as out:
   p=subprocess.run(['nice','-n','10',str(r/'scripts/memcap.sh'),'lake','env','lean','-j1','-o',str(output),name],cwd=r,env=env,stdout=out,stderr=subprocess.STDOUT)
  records.append(dict(module=name,returncode=p.returncode));assert p.returncode==0,records
 save('passed',source_hashes=hashes,scope='Actual retained arbitrary-index store and complete guarded/paired body composition with surrounding original NOPs. Witness and audit gates remain open.')
except BaseException as error:save('failed',error=repr(error));raise
