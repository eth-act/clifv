from pathlib import Path
import os,subprocess,json,hashlib,tarfile,datetime,shutil
b=Path('/home/lee/clifv');e=b/'.git/agent-evidence/stock-memory-20261029';r=b/'.worktrees/stock-extending-production-20261031';receipt=e/'integer-store-current-examples-backup-cleanup-v2.json'
def git(*args,env=None):return subprocess.check_output(['git',*args],cwd=b,env=env,text=True).strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
try:
 assert json.loads((e/'integer-store-current-examples-state-v3.json').read_text())['status']=='passed'
 archives=[];entries={};targets=[]
 for name in ['fv-demo','survey']:
  target=r/'examples'/name/'target';assert target.is_dir() and not target.is_symlink();targets.append(target)
  archive=e/('integer-store-current-example-'+name+'-target-v1.tar.gz')
  files={str(p.relative_to(target)):sha(p) for p in target.rglob('*') if p.is_file() and not p.is_symlink()};entries[name]=files
  if not archive.exists():
   with tarfile.open(archive,'w:gz',compresslevel=1) as out:out.add(target,arcname=name+'/target')
  if archive.stat().st_size>80*1024**2:
   with archive.open('rb') as stream:
    part=0
    while data:=stream.read(80*1024**2):
     chunk=archive.with_name(archive.name+'.part'+str(part));chunk.write_bytes(data);archives.append(chunk);part+=1
  else:archives.append(archive)
 manifest=e/'integer-store-current-examples-target-manifest-v1.json';manifest.write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source='d66add629bf6f2d39a8e3376d2df5ebcb8cc3a14',files=entries,archives={p.name:sha(p) for p in archives}),indent=2)+'\n')
 branch='agent/stock-cfg-body-progress-20261025T025359Z';parent=git('rev-parse',branch);idx=e/'integer-store-current-examples-backup-v1.index';idx.unlink(missing_ok=True);env=dict(os.environ,GIT_INDEX_FILE=str(idx));git('read-tree',parent,env=env)
 for p in [manifest,*archives]:git('update-index','--add','--cacheinfo','100644,'+git('hash-object','-w',str(p))+',evidence/'+p.name,env=env)
 c=git('commit-tree',git('write-tree',env=env),'-p',parent,'-m','Preserve complete current verified example outputs before cleanup');git('update-ref','refs/heads/'+branch,c,parent);subprocess.run(['git','push','origin',branch],cwd=b,check=True);assert git('ls-remote','origin','refs/heads/'+branch).split()[0]==c
 for p in [manifest,*archives]:
  actual=subprocess.check_output(['git','show',c+':evidence/'+p.name],cwd=b);assert hashlib.sha256(actual).hexdigest()==sha(p)
 idx.unlink()
 for target,name in zip(targets,['fv-demo','survey']):
  assert all(sha(target/n)==h for n,h in entries[name].items())
  shutil.rmtree(target)
 result=dict(status='passed',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),commit=c,remote_verified=True,archives={p.name:dict(bytes=p.stat().st_size,sha256=sha(p)) for p in archives},removed=[str(p) for p in targets],all_unique_outputs_preserved=True,free_bytes=shutil.disk_usage(r).free)
 receipt.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
except BaseException as error:
 receipt.write_text(json.dumps(dict(status='failed',error=repr(error)),indent=2)+'\n');raise
