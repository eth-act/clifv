import Crates.MemoryStoreCLICleanup
import Crates.MemoryStoreCLIPlain
import Crates.StockMemoryStoreProductionCleanupFallbackEntries
import Crates.StockMemoryStoreProductionCleanupFallbackGlobal
import Crates.StockMemoryStoreProductionCleanupStrictEntries
import Crates.StockMemoryStoreProductionCleanupStrictGlobal
import Crates.StockMemoryStoreProductionPlainFallbackEntries
import Crates.StockMemoryStoreProductionPlainFallbackGlobal
import Crates.StockMemoryStoreProductionPlainStrictEntries
import Crates.StockMemoryStoreProductionPlainStrictGlobal
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let generated := fun (name : Name) =>
    let owner := (privateToUserName? name).getD name
    owner.toString.startsWith "Crates.StockMemoryStoreProduction" || owner.toString.startsWith "Crates.MemoryStoreCLI"
  let mut count : Nat := 0
  for (name, _) in env.constants.toList do
    unless generated name do continue
    for ax in ← collectAxioms name do
      if #[``propext, ``Classical.choice, ``Quot.sound].contains ax then continue
      unless generated ax && (ax.toString.splitOn "._native.native_decide.ax_").length > 1 do
        throwError "unexpected generated-proof axiom {ax} in {name}"
    count := count + 1
  unless count > 0 do throwError "empty generated-proof audit"
  logInfo m!"STOCK_MEMORY_STORE_GENERATED_AXIOMS_PASS {count}"
