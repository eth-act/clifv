import FV.Backend.StockMemoryStoreCheck

namespace Backend.Stock.MemoryStoreCfg

/-- The CFG adapter retains the store whitelist and permits direct jumps. -/
def effectInstruction : MInst → Bool
  | .jump .. => true
  | i => Memory.Store.effectInstruction i

def effectsOnly (vc : VCode) : Bool :=
  vc.blocks.toList.all (fun b => b.insts.toList.all effectInstruction)

end Backend.Stock.MemoryStoreCfg
