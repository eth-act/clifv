from pathlib import Path
import subprocess,json,hashlib,os,time,datetime,psutil,re
b=Path('/home/lee/clifv');e=b/'.git/agent-evidence/stock-memory-20261029';r=b/'.worktrees/stock-extending-production-20261031';state=e/'integer-store-production-installed-gates-v1.json';paused=None;records=[];head=None;packet=json.loads((e/'integer-store-production-packet-state-v1.json').read_text())
def save(status,**x):
 data=json.dumps(dict(status=status,head=head,records=records,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),**x),indent=2)+'\n';tmp=state.with_suffix('.tmp');tmp.write_text(data);tmp.replace(state)
def git(*args):return subprocess.check_output(['git',*args],cwd=r,text=True).strip()
def live(p):
 try:return p.is_running() and p.status()!=psutil.STATUS_ZOMBIE
 except psutil.NoSuchProcess:return False
def read(p):
 try:return json.loads(p.read_text())
 except (FileNotFoundError,json.JSONDecodeError):return None
try:
 while True:
  parent=read(e/'integer-store-functions-landing-v1.json')
  if parent and parent['status']=='passed':break
  assert not parent or parent['status']!='failed',parent
  assert psutil.pid_exists(903186),'Inspect the missing parent landing watcher before adoption'
  save('waiting',phase='parent800-landing');time.sleep(10)
 backup=read(e/'integer-store-production-backup-state-v1.json');assert backup and backup['status']=='passed' and backup['commit']==packet['commit']
 assert not git('status','--porcelain'),'Preserve unpublished work before changing the view'
 assert git('rev-parse','HEAD')==parent['head']
 subprocess.run(['git','fetch','origin','main'],cwd=r,check=True);main=git('rev-parse','origin/main');assert main==parent['merge'],'Inspect further main drift first'
 assert git('rev-parse',main+'^{tree}')==git('rev-parse',packet['base']+'^{tree}')
 branch=packet['branch'];old=packet['commit'];assert git('rev-parse',branch)==old and git('ls-remote','origin','refs/heads/'+branch).split()[0]==old
 for name,digest in packet['files'].items():assert hashlib.sha256((Path(packet['source_root'])/name).read_bytes()).hexdigest()==digest
 head=git('commit-tree',packet['tree'],'-p',old,'-p',main,'-m','Reconcile store production activation onto landed function contracts')
 git('update-ref','refs/heads/'+branch,head,old);subprocess.run(['git','push','origin',branch],cwd=r,check=True)
 assert git('ls-remote','origin','refs/heads/'+branch).split()[0]==head
 subprocess.run(['git','switch',branch],cwd=r,check=True)
 def frozen():
  assert git('rev-parse','HEAD')==head and not git('status','--porcelain')
  assert all(hashlib.sha256((r/n).read_bytes()).hexdigest()==h for n,h in packet['files'].items())
 frozen();save('running',phase='source-installed',base=main,branch=branch,remote_verified=True)
 # The previous gate resumes this same scheduler. Pause future scheduling only.
 normal=psutil.Process(3167178)
 while live(normal):
  candidates=[]
  for child in normal.children(recursive=True):
   try:
    if child.name().startswith('python') and any(a=='scripts/lake-serial-build.py' or a.endswith('/lake-serial-build.py') for a in child.cmdline()):candidates.append(child)
   except psutil.NoSuchProcess:pass
  if candidates:
   assert len(candidates)==1;paused=candidates[0];paused.suspend();break
  save('waiting',phase='normal-tool-phase',base=main);time.sleep(3)
 assert paused is not None and live(paused),'Inspect normal/runtime ownership before reserving memory'
 while any(live(c) for c in paused.children()):save('waiting',phase='finish-old-active-source',base=main);time.sleep(3)
 env=dict(os.environ);env.update(json.loads((e/'author-env-v1.json').read_text()));env.update(FV_ROOT=str(r),OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',CARGO_BUILD_JOBS='2',PYTHONDONTWRITEBYTECODE='1')
 for key in ['FV_PIPELINE_T','BLESS']:env.pop(key,None)
 def run(label,args,cap='16G'):
  frozen();save('running',phase=label,base=main);env['FV_MEMCAP']=cap;env['FV_MEMCAP_STATS']=str(e/('integer-store-production-installed-'+label+'-v1.stats'))
  with (e/('integer-store-production-installed-'+label+'-v1.log')).open('w') as log:done=subprocess.run(['nice','-n','10',str(r/'scripts/memcap.sh'),*map(str,args)],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
  records.append(dict(label=label,returncode=done.returncode));assert done.returncode==0,(label,done.returncode)
 roots=['FV.Backend.Proof.StockMemoryStoreCompatibility','FV.Backend.Proof.StockMemoryStoreSelectorWitness','FV.E2E.CompiledSemanticNI','FVTest.Backend.Main','FVTest.Backend.Lowering.Trace','FVTest.Link.LeanLinkMain','FVTest.E2E.LinkCheckMain','FVTest.Backend.Lowering.StockMemoryStoreProductionLinked','FVTest.Backend.Lowering.StockMemoryRetainedRuntime']
 run('module-paths',['python3','scripts/lake-serial-build.py','--budget','16G','--max-jobs','2','--max-cap','16G','--default-cap','4G','--profile',r/'scripts/lake-module-peaks.tsv','--profile',r/'.lake/lake-module-peaks.tsv','--profile',e/'production-cold-overrides-v6.tsv','--out',e/'integer-store-production-installed-modules-v1',*roots])
 run('audit',['lake','env','lean','-j1','scripts/audit/stock-memory-store-production.lean'],'4G')
 def axioms(p):
  text=p.read_text();a={n:set(x.strip() for x in s.split(',')) for n,s in re.findall(r"'([^']+)' depends on axioms: \[([^]]*)\]",text,re.S)};a.update({n:set() for n in re.findall(r"'([^']+)' does not depend on any axioms",text)});return a
 now=axioms(e/'integer-store-production-installed-audit-v1.log');oldA=axioms(e/'integer-store-provider-module-path-stock-memory-store-provider-v1.log');assert len(now)==59 and len(oldA)==56
 assert all(a<={'propext','Classical.choice','Quot.sound'} for a in now.values()) and all(now[n]==a for n,a in oldA.items())
 frozen();save('passed',base=main,branch=branch,audit_roots=59,prior_axiom_sets_exact=56,source_hashes=packet['files'],scope='Exact installed shared module identities and current source proof audit. Full production executable/native/generated/retained/capture/settings/official gates remain open. No PR or merge yet.')
 print(json.dumps(dict(head=head,audit_roots=59,full_goal_complete=False)))
except BaseException as error:save('failed',error=repr(error));raise
finally:
 if paused is not None and live(paused):paused.resume()
