from pathlib import Path
import subprocess,os,json,datetime,hashlib,re
b=Path('/home/lee/clifv');e=b/'.git/agent-evidence/stock-memory-20261029';r=b/'.worktrees/stock-extending-production-20261031';state=e/'integer-store-nop-full-state-v1.json';records=[]
def save(status,**x):state.write_text(json.dumps(dict(status=status,records=records,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),**x),indent=2)+'\n')
def axioms(path):
 s=path.read_text();out={n:set(x.strip() for x in a.split(',')) for n,a in re.findall(r"'([^']+)' depends on axioms: \[([^]]*)\]",s,re.S)};out.update({n:set() for n in re.findall(r"'([^']+)' does not depend on any axioms",s)});return out
try:
 env=dict(os.environ);env.update(json.loads((e/'author-env-v1.json').read_text()));env.update(FV_ROOT=str(r),FV_MEMCAP='4G',LEAN_NUM_THREADS='1',OMP_NUM_THREADS='1',OMP_THREAD_LIMIT='1')
 source={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in r.glob('FV/**/StockMemoryStoreNop*.lean')}
 source['FV/Backend/Proof/StockMemoryRetainedStoreReturnSpec.lean']=hashlib.sha256((r/'FV/Backend/Proof/StockMemoryRetainedStoreReturnSpec.lean').read_bytes()).hexdigest()
 for label,args in [('modules',['lake','build','FV','FVTest','lean-backend','lean-e2e-check','link-check']),('audit',['lake','env','lean','-j1','scripts/audit/stock-memory-store-nop-cfg.lean'])]:
  save('running',phase=label)
  with (e/('integer-store-nop-full-'+label+'-v1.log')).open('w') as log:
   p=subprocess.run(['nice','-n','10',str(r/'scripts/memcap.sh'),*args],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
  records.append(dict(gate=label,returncode=p.returncode));assert p.returncode==0,records
 now=axioms(e/'integer-store-nop-full-audit-v1.log');old=axioms(e/'integer-store-cfg-domain-module-path-stock-memory-store-cfg-domain-v4.log')
 assert len(old)==59 and len(now)==76,(len(old),len(now))
 assert all(now[n]==a for n,a in old.items())
 standard={'propext','Classical.choice','Quot.sound'}
 fixed={n for n in now if n.endswith('.lowered') or n.endswith('.domain_and_lower_witness') or 'complete_paired_integer_store' in n}
 assert all(used<=standard or n in fixed and all(a in standard or '._native.native_decide.ax_' in a for a in used) for n,used in now.items())
 assert all(hashlib.sha256((r/n).read_bytes()).hexdigest()==h for n,h in source.items())
 save('passed',source_hashes=source,audit_roots=76,prior_axiom_sets_exact=59,generic_axioms_standard=True,scope='Full current FV/FVTest/tools and every original/new CFG audit. Complete witnesses cover seven forms with surrounding NOPs. Production activation remains open;full140 incomplete.')
except BaseException as error:save('failed',error=repr(error));raise
