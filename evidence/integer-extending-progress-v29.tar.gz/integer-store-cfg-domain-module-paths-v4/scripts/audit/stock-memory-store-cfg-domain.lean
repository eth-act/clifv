import FV.Backend.Proof.StockMemoryNopBodySource
import FV.Backend.Proof.StockMemoryNopJumpSource
import FV.Backend.Proof.StockMemoryStoreNonentryReturn
import FV.Backend.Proof.StockMemoryStoreTwoBlockReturn
import FV.Backend.Proof.StockMemoryStoreTwoBlockDomain
import FV.Backend.Proof.StockMemoryStoreCfgDomainWitness
import FV.Backend.Proof.StockMemoryStoreCfgFixture
import FV.E2E.StockMemoryStoreCfgFunctionWitness
import FV.E2E.StockMemoryStoreNonentryPairedReturn
import FV.E2E.StockMemoryStoreTwoBlockPaired
import FV.Backend.Proof.StockStoreRetention
import FV.Backend.Proof.StockMemoryStoreReturnSpec
import FV.Backend.Proof.StockMemoryStoreScanRefines
import FV.Backend.Proof.StockMemoryStorePairedSource
import FV.Backend.Proof.StockMemoryStoreReturnBody
import FV.E2E.StockMemoryStorePairedScan
import FV.E2E.StockMemoryStorePairedBody
import FV.E2E.StockMemoryStorePairedFunction
import FV.E2E.StockMemoryStorePairedFunctionWitness
import FV.Backend.Proof.StockMemoryStoreSingleDomain
import FV.Backend.Proof.StockMemoryStoreClass
import FV.Backend.Proof.StockMemoryStoreClassWitness
import FV.E2E.StockMemoryStoreUninitializedWitness
import FV.Backend.Proof.StockMemoryStoreGuardedWitness
import FV.Backend.Proof.StockMemoryStoreContract
import FV.Backend.Proof.StockMemoryStoreRecordFixture
import FV.Backend.Proof.StockMemoryStoreSourceValues
import FV.Backend.Proof.StockMemoryStoreRecordExec
import FV.Backend.Proof.StockMemoryStoreRecordValues
import FV.Backend.Proof.StockMemoryStoreEvaluation
import FV.Backend.Proof.StockMemoryStoreMatchWitness
import FV.Backend.Proof.StockMemoryStorePaired
import FV.Backend.Proof.StockMemoryStoreDispatch
import FV.Backend.Proof.StockMemoryStoreSource
import FV.Backend.Proof.StockMemoryStoreWitness
#print axioms Backend.Stock.Memory.StoreRoots.stock_store_side_effect
#print axioms Backend.Stock.Memory.StoreRoots.stock_parameter_integer_store_rhs
#print axioms Backend.Stock.Memory.store_source_result
#print axioms Backend.Stock.Memory.store_source_seqRun
#print axioms Backend.Stock.Memory.StoreRoots.integer_store_root_witness
#print axioms Backend.Stock.Memory.StoreRoots.integer_store_rhs_witness
#print axioms Backend.Stock.Memory.StoreRoots.integer_store_lowering_witness

#print axioms Backend.Stock.Memory.StoreRoots.stock_match_integer_store
#print axioms Backend.Stock.Memory.StoreRoots.integer_store_source_data
#print axioms Backend.Stock.Memory.StoreRoots.integer_store_source_match_witness
#print axioms Backend.Stock.Memory.store_source_result_pairR
#print axioms Backend.Stock.Memory.StoreRoots.stock_selected_integer_store_rule
#print axioms Backend.Stock.Memory.StoreRoots.stock_lower_integer_store_selected_id
#print axioms Backend.Stock.Memory.StoreRoots.stock_store_rhs_sunk
#print axioms Backend.Stock.Memory.StoreRoots.stock_store_rhs_result
#print axioms Backend.Stock.Memory.StoreRoots.stock_lower_integer_store_selected_receipts
#print axioms Backend.Stock.Memory.StoreRoots.stock_lower_integer_store_record_full
#print axioms Backend.Stock.Memory.StoreRoots.stock_lower_integer_store_record_run
#print axioms Backend.Stock.Memory.StoreRoots.stock_lower_integer_store_operand_coverage
#print axioms Backend.Stock.Memory.StoreRoots.stock_lower_integer_store_source_step
#print axioms Backend.Stock.Memory.StoreRoots.Fixture.record_input
#print axioms Backend.Stock.Memory.StoreRoots.Fixture.integer_store_record_witness
#print axioms Backend.Stock.Memory.store_refines_of_mem
#print axioms Backend.Stock.Memory.store_refines_of_memR
#print axioms Backend.Stock.Memory.store_source_result_of_store
#print axioms Backend.Stock.Memory.store_source_seqRun_of_store
#print axioms Backend.Stock.Memory.StoreRoots.stock_lower_integer_store_record_run_of_store
#print axioms Backend.Stock.Memory.StoreRoots.stock_lower_integer_store_source_step_of_store
#print axioms Backend.Stock.Memory.StoreRoots.Fixture.integer_store_guarded_source_witness

#print axioms Backend.Stock.Proof.stock_lower_store_emitted
#print axioms Backend.Stock.Memory.StoreRoots.stock_lower_source_parameter_type
#print axioms Backend.Stock.Memory.StoreRoots.stock_single_store_return_spec
#print axioms Backend.Stock.Memory.StoreRoots.stock_lower_integer_store_scan_fall_refines
#print axioms Backend.Stock.Memory.StoreRoots.stock_lower_integer_store_paired_source_step
#print axioms Backend.Stock.Memory.StoreRoots.stock_single_store_return_body
#print axioms E2E.StockMemory.StoreRoots.stock_lower_integer_store_paired_scan
#print axioms E2E.StockMemory.StoreRoots.stock_single_store_return_paired_body
#print axioms E2E.StockMemory.StoreRoots.single_store_return_paired_function_seeded
#print axioms E2E.StockMemory.StoreRoots.single_store_return_paired_function
#print axioms E2E.StockMemoryStoreFunctionWitness.complete_paired_integer_store_function_witness
#print axioms Backend.Stock.Memory.StoreRoots.domain_of_single_store_return
#print axioms Backend.Stock.Memory.StoreRoots.SingleClass.domain
#print axioms E2E.StockMemoryStoreFunctionWitness.source_class_witness
#print axioms E2E.StockMemoryStoreUninitializedWitness.complete_paired_uninitialized_store_function_witness

#print axioms E2E.StockMemory.StoreRoots.actual_nonentry_paired_store_return
#print axioms E2E.StockMemory.StoreRoots.two_block_store_return_paired
#print axioms E2E.StockMemory.StoreRoots.two_block_store_return_paired_function

#print axioms Backend.Stock.Memory.StoreCfgFixture.scope
#print axioms Backend.Stock.Memory.StoreCfgFixture.dominated
#print axioms Backend.Stock.Memory.StoreCfgFixture.lowered
#print axioms E2E.StockMemoryStoreCfgFunctionWitness.complete_paired_integer_store_cfg_function_witness

#print axioms Backend.Stock.Memory.stock_nop_body_of_split
#print axioms Backend.Stock.Proof.Control.nop_jump_body_returns_at
#print axioms Backend.Stock.Memory.StoreRoots.actual_nonentry_store_return
#print axioms Backend.Stock.Memory.StoreRoots.two_block_store_return
#print axioms Backend.Stock.Memory.StoreRoots.two_block_store_return_function
#print axioms Backend.Stock.Memory.StoreRoots.domain_of_two_block_store_return
#print axioms Backend.Stock.Memory.StoreCfgFixture.domain
#print axioms Backend.Stock.Memory.StoreCfgFixture.domain_and_lower_witness
