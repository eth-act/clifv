Extending-load roots now connect to retained records and original-source execution. Actual Stock runs derive selection, emitted code, fresh result binding, final aliases, pointer demand and source availability internally.

The proofs cover all six signed/unsigned 8/16/32-bit forms. Result types remain arbitrary under existing source invariants. Complete lowering witnesses retain each actual record. Guarded witnesses execute initialized nonzero memory in distinct machine worlds with the same exact virtual result file.

Validation: all eight repository modules and 14 standard-only axiom roots passed. Existing interfaces, accepted inputs and production routes remain unchanged. This is the retained/source execution packet after #787. Function domains and production activation follow; original #140 remains open.
