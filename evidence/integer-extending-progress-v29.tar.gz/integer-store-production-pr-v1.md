The production driver still sends integer stores to the legacy provider. This change adds proved Stock store lowering across the production consumers.

The source checker derives the proved class from the original scope, dominance and ABI checks. It binds the actual Stock output. No caller supplies a lowering certificate. Existing theorem variants remain available.

The new provider appends route16 after unchanged routes0–15. Default/configured compilation, semantic checks, traces, both linkers and generated proofs use that provider. A failed store attempt retries the complete previous pipeline with the original input and allocator callback. The linker boundary proofs include the new case.

Validation completed:
- Proper installed module builds and62 standard-only audit roots. All56 prior axiom sets remain exact.
- Staged objects pass572 native stores and26 retained calls across13 opcode/type pairs, both parameter orders and cleanup modes.
- The custom pinned-reference comparison matches30 function byte/relocation records with equal frame settings. Three same-width narrowing fixtures fail pinned Cranelift parsing. This does not change the official4455 metric.

Validation in progress: full FV/FVTest and executable gates, all production consumer matrices, retained classes, original captures/settings, and the official byte/relocation comparison. This PR is not merge-ready until those gates pass. No review agents run.

The full original #140 remains open. Other addressing, mixed functions, effects, control, calls, simulation and completeness obligations remain.
