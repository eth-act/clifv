import FV.Backend.Proof.StockReturnedSourceRetention
import FV.Backend.Proof.StockNoLoadDriver
import FV.Backend.Proof.StockMemoryReturnSpec
import FV.Backend.Proof.StockMemoryStoreMatch
import FV.Backend.Proof.StockSelectScanRefines
import FV.Backend.Proof.StockMemoryStoreSourceValues
import FV.E2E.StockMemoryPairedScan
import FV.E2E.StockMemoryPairedEntryReturn

namespace Backend.Stock.Proof
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 8192
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm emitInstruction

private theorem scans_execute {exec : Nat → State → Except String Scan}
    {indices : List Nat} {input : State} {output : BlockScan}
    (cert : ScansSpec exec indices input output) :
    ∀ record ∈ output.records,exec record.inst record.input = .ok record.output := by
  induction cert with
  | nil input => simp
  | cons head rest ih =>
    intro record member
    rcases List.mem_cons.mp member with rfl | member
    · exact head
    · exact ih record member

/-- An original store is retained and emitted in a source family without loads.
The original source shape supplies this family condition for singleton-store functions. -/
theorem stock_lower_store_emitted {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f)
    (formats : ∀ b ∈ f.blocks, ∀ stm ∈ b.body, CastComplete.MemoryFormat stm.inst)
    {event : BlockScanEvent} (events : event ∈ result.blockScans.toList)
    {b : Clif.Block} (block : f.blocks[event.block]? = some b)
    {j : Nat} {op : Clif.StoreOp} {ty : Clif.Ty} {flags : Clif.MemFlags} {value pointer : Nat} {offset : Int}
    (statement : b.body[j]? = some ⟨[],.store op ty flags value pointer offset⟩)
    {xs : List Nat} (ret : b.term = .ret xs) :
    ∃ (term record : ScanRecord) (body : BlockScan) (step : Step),
      SourceBodySplit f event b term body ∧ record ∈ body.records ∧
      record.inst = blockStart f event.block+j ∧
      record.input.sunk[record.inst]! = false ∧
      scanInstruction event.ctx event.block record.inst event.termInst event.isBranch record.input = .ok record.output ∧
      record ∈ event.output.records ∧ record.output.step = some step ∧ step.decision = .emitted := by
  obtain ⟨term,body,termStep,split,member,unsunk,branch,recorded,emitted⟩ :=
    stock_lower_retTrap_emitted run scope events block (by rw [ret]; rfl)
  have inside := (List.getElem?_eq_some_iff.mp statement).1
  have indexed : blockStart f event.block+j ∈ sourceBodyIndices f event.block b := by
    unfold sourceBodyIndices
    apply List.mem_reverse.mpr
    exact List.mem_map.mpr ⟨j,List.mem_range.mpr inside,rfl⟩
  rw [← split.scanned.order] at indexed
  obtain ⟨record,retained,current⟩ := List.mem_map.mp indexed
  obtain ⟨info,source,clif,infoResults⟩ :=
    ArithmeticBody.body_source_info run events split statement current
  have safeHere : record.input.sunk[record.inst]! = false :=
    (((SinkRules.stock_lower_no_load_unsunk run scope formats record.inst).2 event events).2
      record (split.retained record retained)).1
  have ordinary : record.inst ≠ event.termInst := by rw [current,split.termIndex]; omega
  have actual := scans_execute split.scanned record retained
  obtain ⟨step,decision,which⟩ := stock_ordinary_unsunk_decision safeHere ordinary actual
  have actualEmitted : step.decision = .emitted := by
    rcases which with omitted | remembered | emitted
    · have mandatory := (scan_omitted actual decision omitted).2.1
      simp [getElem!_def,source,clif,mustLower] at mandatory
    · exact False.elim ((Coverage.lower_record_noOpportunistic scope run events
        (split.retained record retained) decision) remembered)
    · exact emitted
  exact ⟨term,record,body,step,split,retained,current,safeHere,actual,
    split.retained record retained,decision,actualEmitted⟩

end Backend.Stock.Proof

namespace Backend.Stock.Memory.StoreRoots
open Backend.Proof Backend.Proof.Driver Backend.Stock.Proof Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000

/-- Original parameter declarations determine types in the actual scan context. -/
theorem stock_lower_source_parameter_type {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (dominated : Dominated f)
    {event : BlockScanEvent} (events : event ∈ result.blockScans.toList)
    {bi : Nat} {b : Clif.Block} (block : f.blocks[bi]? = some b) {x : Nat} {ty : Clif.Ty}
    (parameter : (x,ty) ∈ b.params) : event.ctx.valueType? x = some (CTy.ofClif ty) := by
  obtain ⟨ranges,params,earlier,suffix,starting,finishing,before,after,
    label,nodeBi,data,core,build,ordered,initial,empty,parts,folded,
    final,prefixRun,nodeRun,suffixRun,node,coreRun,eventEq,stateEq⟩ :=
    stock_lower_blockScanOrigin run events
  obtain ⟨original,st0,oldBuild,spec,view⟩ := buildCtx_source build
  have types : event.ctx.valTy = original.valTy := by
    rw [eventEq,(stock_lowerBlockCore_scanOrigin coreRun).2.1]
    exact view.valTy
  simpa only [Ctx.valueType?,types] using
    (spec.facts.types dominated.ssa).2 b (List.mem_of_getElem? block) (x,ty) parameter

/-- Actual store data for composition comes from original syntax and the complete driver. -/
structure SingleStoreReturnSpec (kind : Kind) (ty : Clif.Ty) (f : Clif.Function) (result : Result)
    (event : BlockScanEvent) (b : Clif.Block) (value pointer : Nat) (flags : Clif.MemFlags) where
  term : ScanRecord
  record : ScanRecord
  body : BlockScan
  step : Step
  info : IInfo
  valueReg : Nat
  pointerReg : Nat
  split : SourceBodySplit f event b term body
  bodyRecords : body.records = [record]
  current : record.inst = blockStart f event.block+0
  records : record ∈ event.output.records
  recorded : record.output.step = some step
  emitted : step.decision = .emitted
  source : event.ctx.insts[record.inst]? = some info
  clif : info.clif = some (.store kind.sourceOp ty flags value pointer 0)
  typed : kind.sourceOp = .store → event.ctx.valueType? value = some (.int kind.width.bits)
  valueMapped : event.ctx.valueReg? value = some (.vreg valueReg .int)
  parameter : event.ctx.defInst? pointer = none
  pointerMapped : event.ctx.valueReg? pointer = some (.vreg pointerReg .int)

/-- Store retention and operand mappings are internal consequences of original source syntax. -/
theorem stock_single_store_return_spec (kind : Kind) (ty : Clif.Ty) {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    (formats : ∀ b ∈ f.blocks, ∀ stm ∈ b.body, CastComplete.MemoryFormat stm.inst)
    {event : BlockScanEvent} (events : event ∈ result.blockScans.toList)
    {b : Clif.Block} (block : f.blocks[event.block]? = some b)
    {value pointer : Nat} {flags : Clif.MemFlags}
    (singleton : b.body = [⟨[],.store kind.sourceOp ty flags value pointer 0⟩]) (ret : b.term = .ret [])
    {pi vi : Nat} {pb vb : Clif.Block} {valueTy : Clif.Ty}
    (pointerBlock : f.blocks[pi]? = some pb) (parameter : pointer ∈ pb.params.map (·.1))
    (valueBlock : f.blocks[vi]? = some vb) (valueParameter : (value,valueTy) ∈ vb.params)
    (width : kind.sourceOp = .store → CTy.ofClif valueTy = .int kind.width.bits) :
    Nonempty (SingleStoreReturnSpec kind ty f result event b value pointer flags) := by
  have statement : b.body[0]? = some ⟨[],.store kind.sourceOp ty flags value pointer 0⟩ := by simp [singleton]
  obtain ⟨term,record,body,step,split,member,current,unsunk,actual,records,recorded,emitted⟩ :=
    stock_lower_store_emitted run scope formats events block statement ret
  obtain ⟨info,source,clif,results⟩ := ArithmeticBody.body_source_info run events split statement current
  have inv := (stock_lower_record_context run scope events).1
  have valueType := stock_lower_source_parameter_type run dominated events valueBlock valueParameter
  obtain ⟨valueReg,valueMapped⟩ := inv.typedReg value _ valueType
  obtain ⟨pointerReg,pointerMapped⟩ := inv.typedReg pointer _ (inv.addr64 _ _ _ pointer source clif rfl)
  have noDefinition := stock_lower_source_parameter_definition run dominated events pointerBlock parameter
  have typed : kind.sourceOp = .store → event.ctx.valueType? value = some (.int kind.width.bits) := by
    intro plain
    rw [valueType,width plain]
  have bodyRecords : body.records = [record] := by
    have scanned := split.scanned
    simp only [sourceBodyIndices,singleton,List.length_cons,List.length_nil,List.range_succ,
      List.range_zero,List.nil_append,List.map_cons,List.map_nil,List.reverse_cons,
      List.reverse_nil,List.nil_append,Nat.add_zero] at scanned
    cases scanned with
    | cons head tail =>
      cases tail
      exact congrArg (fun r => [r]) (List.mem_singleton.mp member).symm
  exact ⟨⟨term,record,body,step,info,valueReg,pointerReg,split,bodyRecords,current,records,recorded,emitted,
    source,clif,typed,valueMapped,noDefinition,pointerMapped⟩⟩

end Backend.Stock.Memory.StoreRoots

namespace Backend.Stock.Memory.StoreRoots
open Backend.Proof Backend.Proof.Driver Backend.Stock.Proof Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000

/-- Actual store selection discharges the existing guarded indexed scan
obligation. Original SSA/dominance derive post-source DFG; the original memory
relation supplies memory validity internally. -/
theorem stock_lower_integer_store_scan_fall_refines (kind : Kind) (ty : Clif.Ty) {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    {event : BlockScanEvent} {record : ScanRecord}
    (events : event ∈ result.blockScans.toList) (records : record ∈ event.output.records)
    {bi j : Nat} {b : Clif.Block} {stm : Clif.Stmt}
    (block : f.blocks[bi]? = some b) (statement : b.body[j]? = some stm)
    (current : record.inst = blockStart f bi+j)
    {info : IInfo} {value pointer valueReg pointerReg : Nat} {flags : Clif.MemFlags}
    (source : event.ctx.insts[record.inst]? = some info)
    (clif : info.clif = some (.store kind.sourceOp ty flags value pointer 0))
    (typed : kind.sourceOp = .store → event.ctx.valueType? value = some (.int kind.width.bits))
    (parameter : event.ctx.defInst? pointer = none)
    (pointerMapped : event.ctx.valueReg? pointer = some (.vreg pointerReg .int))
    (valueMapped : event.ctx.valueReg? value = some (.vreg valueReg .int))
    {step : Step} (recorded : record.output.step = some step) (emitted : step.decision = .emitted)
    {F : BitVec 64 → Prop} {sb : Nat} {syms : String → Option Nat} {isem : Backend.Proof.Sem}
    {MR : MemRelT} (stable : MRStable F MR) (memorySem : StoreRefines F sb isem)
    (memoryOk : MemRelOk F sb syms f MR) {env : Clif.Env} {cp : Clif.Program} :
    ScanFallRefines (IndexedSourceInst env cp f event.ctx bi) isem result.final.alias
      (GuardedScanRel f result event.ctx bi MR) record := by
  intro s s' hsource ρ w held
  obtain ⟨indexed,advance,sourceStep⟩ := hsource
  have position : s.1 = j := Nat.add_left_cancel (indexed.symm.trans current)
  obtain ⟨func,dfg,memory,values⟩ := held
  rw [position] at dfg values
  have postDFG := stock_lower_source_step_dfg run scope dominated events block statement current func dfg sourceStep
  obtain ⟨pv,w',pointer,evaluated,executed,same,memory',post⟩ := stock_lower_integer_store_source_step_of_store kind
    run scope dominated events records block statement current source clif typed
    parameter pointerMapped valueMapped recorded emitted stable memorySem memoryOk memory dfg values sourceStep
  refine ⟨ρ,w',executed,?_,?_,memory',?_⟩
  · obtain ⟨info',inst,vals,regs,rest,_,_,_,_,_,updated⟩ := sourceStep
    change s'.2.1 = _ at updated
    rw [updated]
    exact func
  · simpa only [advance,position] using postDFG
  · simpa only [advance,position] using post

end Backend.Stock.Memory.StoreRoots

namespace Backend.Stock.Memory.StoreRoots
open Backend.Proof Backend.Proof.Driver Backend.Stock.Proof Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option Elab.async false

/-- Two retained source executions preserve their virtual files and update the same source memory relation.
The virtual files may differ in unused upper bits of narrow source values. -/
theorem stock_lower_integer_store_paired_source_step (kind : Kind) {ty : Clif.Ty}
    {f : Clif.Function} {result : Result} (run : Stock.lower f = .ok result) (scope : LowerScope f)
    (dominated : Dominated f) {event : BlockScanEvent} {record : ScanRecord}
    (events : event ∈ result.blockScans.toList) (records : record ∈ event.output.records)
    {bi j : Nat} {b : Clif.Block} {stm : Clif.Stmt}
    (block : f.blocks[bi]? = some b) (statement : b.body[j]? = some stm)
    (current : record.inst = blockStart f bi+j)
    {info : IInfo} {value pointer valueReg pointerReg : Nat} {flags : Clif.MemFlags}
    (source : event.ctx.insts[record.inst]? = some info)
    (clif : info.clif = some (.store kind.sourceOp ty flags value pointer 0))
    (typed : kind.sourceOp = .store → event.ctx.valueType? value = some (.int kind.width.bits))
    (parameter : event.ctx.defInst? pointer = none)
    (pointerMapped : event.ctx.valueReg? pointer = some (.vreg pointerReg .int))
    (valueMapped : event.ctx.valueReg? value = some (.vreg valueReg .int))
    {step : Step} (recorded : record.output.step = some step) (emitted : step.decision = .emitted)
    {F : BitVec 64 → Prop} {sb : Nat} {syms : String → Option Nat} {isem : Backend.Proof.Sem}
    {MR : MemRelT} (stable : MRStable F MR) (memorySem : StoreRefines F sb isem)
    (memoryOk : MemRelOk F sb syms f MR)
    {fr fr' : Clif.Frame} {ρ otherρ : Nat → CV} {cm cm' : Clif.Mem} {w other : Arm.ArmState}
    (memory : MR fr.slots cm w) (otherMemory : MR fr.slots cm other)
    (dfg : DFGCons event.ctx (restrict fr (availOf f (availIn f result.ctx) bi j)))
    (held : ValuesHeld (fun y => Demanded record.output.state y ∧
      y ∈ availOf f (availIn f result.ctx) bi j) event.ctx fr (fun k => ρ (aliasNum result.final.alias k)))
    (otherHeld : ValuesHeld (fun y => Demanded record.output.state y ∧
      y ∈ availOf f (availIn f result.ctx) bi j) event.ctx fr
        (fun k => otherρ (aliasNum result.final.alias k)))
    {env : Clif.Env} {cp : Clif.Program}
    (sourceStep : SourceInstResult env cp event.ctx record.inst (fr,cm) (fr',cm')) :
    ∃ w' other',
      seqRun isem (record.output.emitted.toList.map (·.mapRegs
        (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1)))) ρ w =
          some (.fall ρ w') ∧
      seqRun isem (record.output.emitted.toList.map (·.mapRegs
        (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1)))) otherρ other =
          some (.fall otherρ other') ∧
      MR fr'.slots cm' w' ∧ MR fr'.slots cm' other' ∧
      ValuesHeld (fun y => Demanded record.input y ∧
        y ∈ availOf f (availIn f result.ctx) bi (j+1)) event.ctx fr'
        (fun k => ρ (aliasNum result.final.alias k)) ∧
      ValuesHeld (fun y => Demanded record.input y ∧
        y ∈ availOf f (availIn f result.ctx) bi (j+1)) event.ctx fr'
        (fun k => otherρ (aliasNum result.final.alias k)) := by
  obtain ⟨pv,w',pointer,evaluated,executed,same,memory',post⟩ := stock_lower_integer_store_source_step_of_store kind
    run scope dominated events records block statement current source clif typed
    parameter pointerMapped valueMapped recorded emitted stable memorySem memoryOk memory dfg held sourceStep
  obtain ⟨otherPointer,other',pointer',evaluated',executed',same',otherMemory',otherPost⟩ :=
    stock_lower_integer_store_source_step_of_store kind run scope dominated events records block statement current
      source clif typed parameter pointerMapped valueMapped recorded emitted stable memorySem memoryOk
      otherMemory dfg otherHeld sourceStep
  exact ⟨w',other',executed,executed',memory',otherMemory',post,otherPost⟩

end Backend.Stock.Memory.StoreRoots

namespace Backend.Stock.Memory.StoreRoots
open Backend.Proof Backend.Proof.Driver Backend.Stock.Proof Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000

/-- Original singleton store/return syntax derives the complete guarded body
proof, including retention, actual selection, value/pointer mappings and final
aliases. The pointer can be inherited from a different original source block.
No retained-record, selected-rule or emitted-code certificate is a premise. -/
theorem stock_single_store_return_body (kind : Kind) (ty : Clif.Ty) {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    (formats : ∀ b ∈ f.blocks, ∀ stm ∈ b.body, CastComplete.MemoryFormat stm.inst)
    {event : BlockScanEvent} (events : event ∈ result.blockScans.toList)
    {b : Clif.Block} (block : f.blocks[event.block]? = some b)
    {value pointer : Nat} {flags : Clif.MemFlags}
    (singleton : b.body = [⟨[],.store kind.sourceOp ty flags value pointer 0⟩]) (ret : b.term = .ret [])
    {pi vi : Nat} {pb vb : Clif.Block} {valueTy : Clif.Ty}
    (pointerBlock : f.blocks[pi]? = some pb) (parameter : pointer ∈ pb.params.map (·.1))
    (valueBlock : f.blocks[vi]? = some vb) (valueParameter : (value,valueTy) ∈ vb.params)
    (width : kind.sourceOp = .store → CTy.ofClif valueTy = .int kind.width.bits)
    {F : BitVec 64 → Prop} {sb : Nat} {syms : String → Option Nat} {isem : Backend.Proof.Sem}
    {MR : MemRelT} (stable : MRStable F MR) (memorySem : StoreRefines F sb isem)
    (memoryOk : MemRelOk F sb syms f MR) {env : Clif.Env} {cp : Clif.Program} :
    ∃ (term : ScanRecord) (body : BlockScan),SourceBodySplit f event b term body ∧
      ∀ s s',SourceSteps (IndexedSourceInst env cp f event.ctx event.block)
        ((List.range b.body.length).map (blockStart f event.block+·)) s s' →
        ∀ ρ w,GuardedScanRel f result event.ctx event.block MR event.output.state s ρ w →
          ∃ ρ' w',seqRun isem (body.code.toList.map (·.mapRegs
            (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1)))) ρ w =
              some (.fall ρ' w') ∧
            GuardedScanRel f result event.ctx event.block MR term.output.state s' ρ' w' := by
  obtain ⟨spec⟩ := stock_single_store_return_spec kind ty run scope dominated formats events block
    singleton ret pointerBlock parameter valueBlock valueParameter width
  have statement : b.body[0]? = some ⟨[],.store kind.sourceOp ty flags value pointer 0⟩ := by simp [singleton]
  have normal := stock_lower_integer_store_scan_fall_refines kind ty run scope dominated events spec.records
    block statement spec.current spec.source spec.clif spec.typed spec.parameter spec.pointerMapped
    spec.valueMapped spec.recorded spec.emitted stable memorySem memoryOk (env := env) (cp := cp)
  refine ⟨spec.term,spec.body,spec.split,?_⟩
  have each : ∀ r ∈ spec.body.records,ScanFallRefines (IndexedSourceInst env cp f event.ctx event.block)
      isem result.final.alias (GuardedScanRel f result event.ctx event.block MR) r := by
    intro r present
    have same : r = spec.record := by simpa only [spec.bodyRecords,List.mem_singleton] using present
    subst r
    exact normal
  intro s s' steps ρ w held
  apply spec.split.scanned.fall_refines each s s'
  · simpa only [sourceBodyIndices,List.reverse_reverse] using steps
  · simpa only [spec.split.state] using held

end Backend.Stock.Memory.StoreRoots

namespace E2E.StockMemory.StoreRoots
open Backend Backend.Stock Backend.Proof Backend.Proof.Driver Backend.Stock.Proof Backend.Stock.Memory
open Backend.Stock.Memory.StoreRoots
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000

/-- Actual source stores compose under the existing paired scan relation.
The updated source relation handles newly initialized bytes without a new read-permission condition. -/
theorem stock_lower_integer_store_paired_scan (kind : Kind) (ty : Clif.Ty)
    {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    {event : BlockScanEvent} {record : ScanRecord}
    (events : event ∈ result.blockScans.toList) (records : record ∈ event.output.records)
    {bi j : Nat} {b : Clif.Block} {stm : Clif.Stmt}
    (block : f.blocks[bi]? = some b) (statement : b.body[j]? = some stm)
    (current : record.inst = blockStart f bi+j)
    {info : IInfo} {value pointer valueReg pointerReg : Nat} {flags : Clif.MemFlags}
    (source : event.ctx.insts[record.inst]? = some info)
    (clif : info.clif = some (.store kind.sourceOp ty flags value pointer 0))
    (typed : kind.sourceOp = .store → event.ctx.valueType? value = some (.int kind.width.bits))
    (parameter : event.ctx.defInst? pointer = none)
    (pointerMapped : event.ctx.valueReg? pointer = some (.vreg pointerReg .int))
    (valueMapped : event.ctx.valueReg? value = some (.vreg valueReg .int))
    {step : Step} (recorded : record.output.step = some step) (emitted : step.decision = .emitted)
    {Γ : Rel} {c : BitVec 64} {D : BitVec 64 → Prop} {fc : FnCtx} {X : ExtSem}
    (slot : fc.slotBase = Γ.slotOff)
    (symbols : ∀ n b,Γ.syms n = some b → X.sym n 0 = BitVec.ofNat 64 b)
    (tls : XTls Γ.F X) {env : Clif.Env} {cp : Clif.Program} :
    ScanFallRefines (IndexedSourceInst env cp f event.ctx bi) (pairSem (csem Γ.F fc X))
      result.final.alias (PairedScanRel f result event.ctx bi Γ c D) record := by
  intro s s' sourceIndex ρ q before
  obtain ⟨indexed,advance,sourceStep⟩ := sourceIndex
  have position : s.1 = j := Nat.add_left_cancel (indexed.symm.trans current)
  obtain ⟨firstHeld,secondHeld,worlds⟩ := before
  obtain ⟨func,dfg,memory,values⟩ := firstHeld
  rw [position] at dfg values
  have postDFG := stock_lower_source_step_dfg run scope dominated events block statement current func dfg sourceStep
  let guarded : Backend.Proof.Sem := csemG Γ.F fc X (fun a => ¬ Zof Γ.F D s.2.2 a) Γ.syms [] [] 0
    (fun _ _ _ _ => False)
  have memorySem : StoreRefines Γ.F Γ.slotOff guarded :=
    store_refines_of_memR (memRefinesR_csemG (ctx := fc) (X := X) (syms := Γ.syms) slot symbols)
  obtain ⟨pv,t,pointer,evaluated,first,same,memory',post⟩ := stock_lower_integer_store_source_step_of_store kind
    run scope dominated events records block statement current source clif typed parameter pointerMapped valueMapped
    recorded emitted (mrStable_relW Γ f c) memorySem (memRelOk_relW Γ f c) memory dfg values sourceStep
  have otherValues := secondHeld.2.2.2
  rw [position] at otherValues
  obtain ⟨pv',t',pointer',evaluated',second,same',otherMemory',otherPost⟩ :=
    stock_lower_integer_store_source_step_of_store kind run scope dominated events records block statement current
      source clif typed parameter pointerMapped valueMapped recorded emitted (mrStable_relW Γ f c)
      memorySem (memRelOk_relW Γ f c) secondHeld.2.2.1 dfg otherValues sourceStep
  let code := record.output.emitted.toList.map (·.mapRegs
    (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1)))
  obtain ⟨t2,equal,paired,related⟩ := pair_fall
    (fun _ _ _ _ h => (csemG_sub h).2.2)
    (guardedStep0 (D := D) (syms := Γ.syms) tls fc s.2.2 code [] []) worlds first second
  have sameWorld : t' = t2 := (SeqEnd.fall.inj equal).2
  subst t2
  have postFunc : s'.2.1.func = f := by
    obtain ⟨info',inst,vals,regs,rest,_,_,_,_,_,updated⟩ := sourceStep
    change s'.2.1 = _ at updated
    rw [updated]
    exact func
  refine ⟨ρ,(t,t'),paired,⟨postFunc,?_,memory',?_⟩,⟨postFunc,?_,otherMemory',?_⟩,?_⟩
  · simpa only [advance,position] using postDFG
  · simpa only [advance,position] using post
  · simpa only [advance,position] using postDFG
  · simpa only [advance,position] using otherPost
  · exact sameWorld_zof memory'.1.1 otherMemory'.1.1 related (zof_sub s.2.2)

end E2E.StockMemory.StoreRoots

namespace E2E.StockMemory.StoreRoots
open Backend Backend.Stock Backend.Proof Backend.Proof.Driver Backend.Stock.Proof Backend.Stock.Memory
open Backend.Stock.Memory.StoreRoots
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000

/-- Original store/return body syntax derives the complete paired body execution.
Both semantic consumers share the same retained-body derivation; neither a
record nor selected root, code, alias or read-permission certificate is an input. -/
theorem stock_single_store_return_paired_body (kind : Kind) (ty : Clif.Ty) {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    (formats : ∀ b ∈ f.blocks, ∀ stm ∈ b.body, CastComplete.MemoryFormat stm.inst)
    {event : BlockScanEvent} (events : event ∈ result.blockScans.toList)
    {b : Clif.Block} (block : f.blocks[event.block]? = some b)
    {value pointer : Nat} {flags : Clif.MemFlags}
    (singleton : b.body = [⟨[],.store kind.sourceOp ty flags value pointer 0⟩]) (ret : b.term = .ret [])
    {pi vi : Nat} {pb vb : Clif.Block} {valueTy : Clif.Ty}
    (pointerBlock : f.blocks[pi]? = some pb) (parameter : pointer ∈ pb.params.map (·.1))
    (valueBlock : f.blocks[vi]? = some vb) (valueParameter : (value,valueTy) ∈ vb.params)
    (width : kind.sourceOp = .store → CTy.ofClif valueTy = .int kind.width.bits)
    {Γ : Rel} {c : BitVec 64} {D : BitVec 64 → Prop} {fc : FnCtx} {X : ExtSem}
    (slot : fc.slotBase = Γ.slotOff)
    (symbols : ∀ n b,Γ.syms n = some b → X.sym n 0 = BitVec.ofNat 64 b)
    (tls : XTls Γ.F X) {env : Clif.Env} {cp : Clif.Program} :
    ∃ (term : ScanRecord) (body : BlockScan),SourceBodySplit f event b term body ∧
      ∀ s s',SourceSteps (IndexedSourceInst env cp f event.ctx event.block)
        ((List.range b.body.length).map (blockStart f event.block+·)) s s' →
        ∀ ρ q,PairedScanRel f result event.ctx event.block Γ c D event.output.state s ρ q →
          ∃ ρ' q',seqRun (pairSem (csem Γ.F fc X)) (body.code.toList.map (·.mapRegs
            (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1)))) ρ q =
              some (.fall ρ' q') ∧
            PairedScanRel f result event.ctx event.block Γ c D term.output.state s' ρ' q' := by
  obtain ⟨spec⟩ := stock_single_store_return_spec kind ty run scope dominated formats events block
    singleton ret pointerBlock parameter valueBlock valueParameter width
  have statement : b.body[0]? = some ⟨[],.store kind.sourceOp ty flags value pointer 0⟩ := by simp [singleton]
  have normal := stock_lower_integer_store_paired_scan kind ty run scope dominated events spec.records
    block statement spec.current spec.source spec.clif spec.typed spec.parameter spec.pointerMapped
    spec.valueMapped spec.recorded spec.emitted slot symbols tls (env := env) (cp := cp) (c := c) (D := D)
  refine ⟨spec.term,spec.body,spec.split,?_⟩
  have each : ∀ r ∈ spec.body.records,ScanFallRefines (IndexedSourceInst env cp f event.ctx event.block)
      (pairSem (csem Γ.F fc X)) result.final.alias (PairedScanRel f result event.ctx event.block Γ c D) r := by
    intro r present
    have same : r = spec.record := by simpa only [spec.bodyRecords,List.mem_singleton] using present
    subst r
    exact normal
  intro s s' steps ρ q held
  apply spec.split.scanned.fall_refines each s s'
  · simpa only [sourceBodyIndices,List.reverse_reverse] using steps
  · simpa only [spec.split.state] using held

end E2E.StockMemory.StoreRoots

namespace E2E.StockMemory.StoreRoots
open Backend Backend.Stock Backend.Proof Backend.Proof.Driver Backend.Stock.Proof
open Backend.Stock.Memory.StoreRoots
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000

/-- Source-only singleton store/return functions execute from instruction zero in
paired worlds. The original ABI/RelW and initialized-memory relations supply all
runtime premises; actual entry/body/retention/result-binding code is derived. -/
theorem single_store_return_paired_function_seeded (kind : Kind) (ty : Clif.Ty) {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    (abi : sigAbiOk f.sig = true) {b : Clif.Block} (blocks : f.blocks = [b])
    {value pointer : Nat} {flags : Clif.MemFlags} {valueTy : Clif.Ty}
    (singleton : b.body = [⟨[],.store kind.sourceOp ty flags value pointer 0⟩])
    (ret : b.term = .ret []) (parameter : pointer ∈ b.params.map (·.1))
    (valueParameter : (value,valueTy) ∈ b.params)
    (width : kind.sourceOp = .store → CTy.ofClif valueTy = .int kind.width.bits)
    {args : List Clif.Val} {cm : Clif.Mem} {fr : Clif.Frame}
    (entered : SourceEntry f args fr)
    {env : Clif.Env} {cp : Clif.Program} {fuel : Nat} {vals : List Clif.Val} {mem : Clif.Mem}
    (returned : Clif.runLoop env cp fuel ⟨fr,[],cm⟩ = .returned vals mem)
    (registerOnly : ∀ loc ∈ locsOf f.sig,∃ pin,loc = .reg pin)
    {Γ : Rel} {c : BitVec 64} {D : BitVec 64 → Prop} {fc : FnCtx} {X : ExtSem}
    (slot : fc.slotBase = Γ.slotOff)
    (symbols : ∀ n a,Γ.syms n = some a → X.sym n 0 = BitVec.ofNat 64 a)
    (tls : XTls Γ.F X)
    {w w' : Arm.ArmState} (memory : MRP Γ f c D fr.slots cm (w,w'))
    (arguments : ArgsAtEntry Γ.F f.sig args w) (otherArguments : ArgsAtEntry Γ.F f.sig args w')
    (registers : ∀ pin v,(.reg pin,v) ∈ (locsOf f.sig).zip args → regVal w' pin = regVal w pin) :
    RunOkABI f result.code (pairSem (csem Γ.F fc X)) (MRP Γ f c D) fr.slots
      ⟨0,0,entrySeed result.ctx fr,(w,w')⟩ (.returned vals mem) := by
  have family : ∀ stm ∈ b.body,OrdinaryBody.OrdinaryInst stm.inst := by
    intro stm member
    have same : stm = ⟨[],.store kind.sourceOp ty flags value pointer 0⟩ := by simpa only [singleton,List.mem_singleton] using member
    subst stm
    constructor
    · intro fn args impossible; cases impossible
    · intro sig callee args impossible; cases impossible
  have formats : ∀ b' ∈ f.blocks, ∀ stm ∈ b'.body,CastComplete.MemoryFormat stm.inst := by
    intro b' member stm present
    have same : b' = b := by simpa [blocks] using member
    subst b'
    have same : stm = ⟨[],.store kind.sourceOp ty flags value pointer 0⟩ := by
      simpa [singleton] using present
    subst stm
    simp [CastComplete.MemoryFormat,instNames]
  have entryBlock : f.blocks[0]? = some b := by simp [blocks]
  apply actual_ordinary_paired_entry_return_refines_frame run scope dominated abi blocks family ret
    entered returned registerOnly slot symbols tls ?_ memory arguments otherArguments registers
  intro event events
  obtain ⟨b',term,body,split⟩ := stock_lower_body_scan_split run scope events
  have bound : event.block < 1 := by have h := lt_of_getElem? split.block; simpa [blocks] using h
  have zero : event.block = 0 := by omega
  have actualBlock : f.blocks[event.block]? = some b := by rw [zero]; exact entryBlock
  exact stock_single_store_return_paired_body kind ty run scope dominated formats events actualBlock
    singleton ret entryBlock parameter entryBlock valueParameter width
    slot symbols tls

/-- Compatibility existential form of the canonical entry-seeded execution. -/
theorem single_store_return_paired_function (kind : Kind) (ty : Clif.Ty) {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    (abi : sigAbiOk f.sig = true) {b : Clif.Block} (blocks : f.blocks = [b])
    {value pointer : Nat} {flags : Clif.MemFlags} {valueTy : Clif.Ty}
    (singleton : b.body = [⟨[],.store kind.sourceOp ty flags value pointer 0⟩])
    (ret : b.term = .ret []) (parameter : pointer ∈ b.params.map (·.1))
    (valueParameter : (value,valueTy) ∈ b.params)
    (width : kind.sourceOp = .store → CTy.ofClif valueTy = .int kind.width.bits)
    {args : List Clif.Val} {cm : Clif.Mem} {fr : Clif.Frame}
    (entered : SourceEntry f args fr)
    {env : Clif.Env} {cp : Clif.Program} {fuel : Nat} {vals : List Clif.Val} {mem : Clif.Mem}
    (returned : Clif.runLoop env cp fuel ⟨fr,[],cm⟩ = .returned vals mem)
    (registerOnly : ∀ loc ∈ locsOf f.sig,∃ pin,loc = .reg pin)
    {Γ : Rel} {c : BitVec 64} {D : BitVec 64 → Prop} {fc : FnCtx} {X : ExtSem}
    (slot : fc.slotBase = Γ.slotOff)
    (symbols : ∀ n a,Γ.syms n = some a → X.sym n 0 = BitVec.ofNat 64 a)
    (tls : XTls Γ.F X)
    {w w' : Arm.ArmState} (memory : MRP Γ f c D fr.slots cm (w,w'))
    (arguments : ArgsAtEntry Γ.F f.sig args w) (otherArguments : ArgsAtEntry Γ.F f.sig args w')
    (registers : ∀ pin v,(.reg pin,v) ∈ (locsOf f.sig).zip args → regVal w' pin = regVal w pin) :
    ∃ ρ, RunOkABI f result.code (pairSem (csem Γ.F fc X)) (MRP Γ f c D) fr.slots
      ⟨0,0,ρ,(w,w')⟩ (.returned vals mem) := by
  exact ⟨entrySeed result.ctx fr,single_store_return_paired_function_seeded kind ty run scope dominated abi
    blocks singleton ret parameter valueParameter width entered returned registerOnly slot symbols tls memory arguments otherArguments registers⟩

end E2E.StockMemory.StoreRoots
#print axioms Backend.Stock.Proof.stock_lower_store_emitted
#print axioms Backend.Stock.Memory.StoreRoots.stock_lower_source_parameter_type
#print axioms Backend.Stock.Memory.StoreRoots.stock_single_store_return_spec
#print axioms Backend.Stock.Memory.StoreRoots.stock_lower_integer_store_scan_fall_refines
#print axioms Backend.Stock.Memory.StoreRoots.stock_lower_integer_store_paired_source_step
#print axioms Backend.Stock.Memory.StoreRoots.stock_single_store_return_body
#print axioms E2E.StockMemory.StoreRoots.stock_lower_integer_store_paired_scan
#print axioms E2E.StockMemory.StoreRoots.stock_single_store_return_paired_body
#print axioms E2E.StockMemory.StoreRoots.single_store_return_paired_function_seeded
#print axioms E2E.StockMemory.StoreRoots.single_store_return_paired_function
