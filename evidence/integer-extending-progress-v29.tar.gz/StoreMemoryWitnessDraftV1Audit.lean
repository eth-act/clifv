import StoreMemoryWitnessDraftV1
#print axioms Backend.Stock.Memory.StoreRoots.integer_store_root_witness
#print axioms Backend.Stock.Memory.StoreRoots.integer_store_rhs_witness
#print axioms Backend.Stock.Memory.StoreRoots.integer_store_lowering_witness
