import StoreMemoryProofDraftV1

#print axioms Backend.Stock.Memory.StoreRoots.stock_store_side_effect
#print axioms Backend.Stock.Memory.StoreRoots.stock_parameter_integer_store_rhs
