from pathlib import Path
import sys,json,hashlib,subprocess,datetime,os,psutil,time
b=Path('/home/lee/clifv');e=b/'.git/agent-evidence/stock-memory-20261029';v=b/'.worktrees/stock-extending-production-20261031';out=e/'integer-store-reference-v1';out.mkdir(exist_ok=True);state=e/'integer-store-reference-state-v1.json';rows=[];paused=None
sys.path.insert(0,str(b/'scripts'));from byte_compare import ELF,byte_diff
binary=v/'tools/prejit-export/target/debug/prejit-export';src=e/'integer-store-native-stage-artifacts-v1'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(status,**kw):state.write_text(json.dumps(dict(status=status,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),rows=rows,scope='Custom store fixtures, not the official4455 inventory. Original function text retained exactly; explicit compile/ISA header added and recorded. Compare raw function bytes and relocation records, not ELFs. No default-production activation claim.',**kw),indent=2)+'\n')
try:
 upstream=b/'.worktrees/stock-memory-reference-production-20261031';pin=subprocess.check_output(['git','rev-parse','HEAD'],cwd=upstream,text=True).strip();assert pin=='46c23a87dac1465986a8ad53ba6a7ae49372857b'
 paused=psutil.Process(363555);assert 'scripts/lake-serial-build.py' in paused.cmdline();paused.suspend()
 while True:
  children=[p for p in paused.children() if p.is_running() and p.status()!=psutil.STATUS_ZOMBIE];caps=[]
  for p in children:
   raw=p.environ().get('FV_MEMCAP','');caps.append(float(raw[:-1]) if raw.endswith('G') else 1000)
  if len(children)<=1 and sum(caps)<=12:break
  save('waiting',caps=caps);time.sleep(3)
 env=dict(os.environ,FV_MEMCAP='4G',OMP_NUM_THREADS='1',OMP_THREAD_LIMIT='1',LEAN_NUM_THREADS='1')
 for p in sorted(src.glob('*-plain.clif')):
  label=p.stem.removesuffix('-plain');folder=out/label;folder.mkdir(exist_ok=True);test=folder/'input.clif';header=b'test compile\nset opt_level=none\ntarget aarch64\n\n';test.write_bytes(header+p.read_bytes());assert test.read_bytes()[len(header):]==p.read_bytes()
  with (folder/'export.log').open('w') as log:done=subprocess.run(['nice','-n','10',str(v/'scripts/memcap.sh'),str(binary),str(test),str(folder/'stock'),'aarch64-unknown-linux-gnu','--all-stages'],env=env,cwd=v,stdout=log,stderr=subprocess.STDOUT)
  row=dict(label=label,source_sha256=digest(p),fixture_sha256=digest(test),header=header.decode(),exit=done.returncode,functions=[]);rows.append(row);assert done.returncode==0
  manifest=json.loads((folder/'stock/manifest.json').read_text());row['manifest']=manifest
  if not manifest.get('variants') or manifest.get('parse_error'):continue
  elf=ELF(p.with_suffix('.o'))
  for meta in sorted((folder/'stock/variant-0').glob('*.json')):
   m=json.loads(meta.read_text())
   if not isinstance(m,dict) or 'relocations' not in m or 'name' not in m:continue
   symbol,code=elf.function(m['name'].removeprefix('%'));rel=elf.function_relocations(symbol,{})
   row['functions'].append(dict(name=m['name'],bytes=byte_diff(meta.with_suffix('.bin').read_bytes(),code),stock_relocations=m['relocations'],lean_relocations=rel,relocations_equal=(m['relocations']==[] and rel==[])))
  save('running')
 funcs=[f for row in rows for f in row['functions']];save('passed',upstream_commit=pin,exporter_sha256=digest(binary),pairs=len(rows),compared_functions=len(funcs),exact_bytes_and_relocations=sum(f['bytes']['equal'] and f['relocations_equal'] for f in funcs),rejected_pairs=sum(not r['functions'] for r in rows))
except BaseException as error:save('failed',error=repr(error));raise
finally:
 if paused is not None and paused.is_running():paused.resume()
