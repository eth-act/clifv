from pathlib import Path
import subprocess,psutil,json,hashlib,time,datetime,os,re
b=Path('/home/lee/clifv');e=b/'.git/agent-evidence/stock-memory-20261029';r=b/'.worktrees/stock-extending-production-20261031';stage=e/'integer-store-shared-proof-stage-v1';state=e/'integer-store-shared-proof-stage-state-v1.json';paused=None;records=[]
files=['FV/Backend/SemanticNIStoreStage.lean','FV/E2E/CompiledSemanticNIStoreStage.lean'];hashes={n:hashlib.sha256((stage/n).read_bytes()).hexdigest() for n in files}
def save(status,**x):state.write_text(json.dumps(dict(status=status,records=records,source_hashes=hashes,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),**x),indent=2)+'\n')
def live(p):
 try:return p.is_running() and p.status()!=psutil.STATUS_ZOMBIE
 except psutil.NoSuchProcess:return False
def frozen():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()=='330e55698e83dbfe80a6524a6e916a44f6a3dd8b'
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=r,text=True).strip()
 assert all(hashlib.sha256((stage/n).read_bytes()).hexdigest()==h for n,h in hashes.items())
try:
 assert json.loads((e/'integer-store-provider-module-paths-state-v1.json').read_text())['status']=='passed'
 frozen();paused=psutil.Process(363555);assert 'scripts/lake-serial-build.py' in paused.cmdline();paused.suspend()
 while True:
  children=[c for c in paused.children() if live(c)];caps=[]
  for c in children:
   raw=c.environ().get('FV_MEMCAP','');caps.append(float(raw[:-1]) if raw.endswith('G') else float(raw[:-1])/1024 if raw.endswith('M') else 1000)
  if len(children)<=1 and sum(caps)<=12:break
  save('waiting',phase='finish-current-active-source',caps_GiB=caps);time.sleep(3)
 env=dict(os.environ);env.update(json.loads((e/'author-env-v1.json').read_text()));env.update(FV_ROOT=str(r),FV_MEMCAP='4G',OMP_NUM_THREADS='1',OMP_THREAD_LIMIT='1',LEAN_NUM_THREADS='1',CARGO_BUILD_JOBS='1',PYTHONDONTWRITEBYTECODE='1')
 for n in files:
  frozen();label=Path(n).stem;save('running',phase=n);env['FV_MEMCAP_STATS']=str(e/('integer-store-shared-'+label+'-v1.stats'));out=r/'.lake/build/lib/lean'/Path(n).with_suffix('.olean')
  with (e/('integer-store-shared-'+label+'-v1.log')).open('w') as log:done=subprocess.run(['nice','-n','10',str(r/'scripts/memcap.sh'),'lake','env','lean','-j1','--root='+str(stage),'-o',str(out),str(stage/n)],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
  records.append(dict(module=n,returncode=done.returncode));assert done.returncode==0,records
 log=(e/'integer-store-shared-CompiledSemanticNIStoreStage-v1.log').read_text();sets=re.findall(r'depends on axioms: \[([^]]*)\]',log,re.S);assert len(sets)==3 and all(set(x.strip() for x in s.split(','))<={'propext','Classical.choice','Quot.sound'} for s in sets),log
 frozen();save('passed',audit_roots=3,all_axioms_standard=True,scope='Shared checker and paired semantic artifact logic checked under isolated namespaces. Original global checker/type and frozen source remain unchanged. Exact production integration still requires installed source and consumer/runtime gates.')
except BaseException as error:save('failed',error=repr(error));raise
finally:
 if paused is not None and live(paused):paused.resume()
