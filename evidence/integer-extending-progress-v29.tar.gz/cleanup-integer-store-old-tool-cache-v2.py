from pathlib import Path
import os,stat,time,json,shutil,datetime,psutil
b=Path('/home/lee/clifv');e=b/'.git/agent-evidence/stock-memory-20261029';c=b/'.worktrees/driver-proof-resume/.lake/artifact-cache/artifacts';assert c.resolve().is_relative_to(b)
cutoff=time.time()-24*3600;target=101*2**30;limit=3*2**30;before=shutil.disk_usage(c).free;protected=set();candidates=[];removed=[];total=0
for p in psutil.process_iter(['pid']):
 try:
  s=Path('/proc')/str(p.pid)/'exe';v=s.stat();protected.add((v.st_dev,v.st_ino))
 except (OSError,psutil.NoSuchProcess,psutil.AccessDenied):pass
for p in c.iterdir():
 v=p.lstat()
 if not stat.S_ISREG(v.st_mode) or v.st_nlink!=1 or v.st_mtime>=cutoff or p.suffix or (v.st_dev,v.st_ino) in protected:continue
 with p.open('rb') as f:header=f.read(20)
 if header[:6]!=b'\x7fELF\x02\x01' or int.from_bytes(header[18:20],'little')!=62:continue
 candidates.append((v.st_mtime,p.name,v.st_size,v.st_ino))
for old,name,size,inode in sorted(candidates):
 if shutil.disk_usage(c).free>=target or total>=limit:break
 p=c/name;v=p.lstat()
 if not stat.S_ISREG(v.st_mode) or v.st_nlink!=1 or v.st_mtime>=cutoff or v.st_ino!=inode or v.st_size!=size:continue
 p.unlink();removed.append(dict(name=name,bytes=size,mtime=old));total+=size
receipt=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Only old unlinked generated x86_64 ELF tool binaries inside this project cache. Preserve every linked artifact, running executable, source, validation record and native object. Retain the single warm cache.',removed_files=len(removed),removed_bytes=total,free_before=before,free_after=shutil.disk_usage(c).free,rows=removed)
(e/'integer-store-old-tool-cache-cleanup-v2.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:receipt[k] for k in ['removed_files','removed_bytes','free_before','free_after']}))
