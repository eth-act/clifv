from pathlib import Path
import subprocess,json,hashlib,time,datetime,psutil,os,re
b=Path('/home/lee/clifv');e=b/'.git/agent-evidence/stock-memory-20261029';r=b/'.worktrees/stock-extending-production-20261031';state=e/'integer-store-functions-actual-check-v3.json';paused=None;records=[];base=None
def save(status,**x):state.write_text(json.dumps(dict(status=status,records=records,base=base,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),**x),indent=2)+'\n')
def live(p):
 try:return p.is_running() and p.status()!=psutil.STATUS_ZOMBIE
 except psutil.NoSuchProcess:return False
def git(*a):return subprocess.check_output(['git',*a],cwd=r,text=True).strip()
try:
 while True:
  landing=json.loads((e/'integer-store-records-landing-v1.json').read_text())
  if landing['status']=='passed':break
  assert landing['status']!='failed',landing
  save('waiting',phase='current-PR-landing');time.sleep(10)
 assert git('rev-parse','HEAD')==landing['commit']
 assert not git('status','--porcelain'),'Preserve unexpected saved work before adopting the next packet'
 subprocess.run(['git','fetch','origin','main'],cwd=r,check=True);base=git('rev-parse','origin/main')
 assert base==landing['merge'],'Inspect newer main drift before next adoption'
 subprocess.run(['git','switch','-c','agent/stock-store-functions-20261031',base],cwd=r,check=True)
 source=json.loads((e/'integer-store-functions-source-v3.json').read_text())['files']
 for n,data in source.items():
  p=Path(data['source']);assert hashlib.sha256(p.read_bytes()).hexdigest()==data['sha256'];assert not (r/n).exists();(r/n).write_bytes(p.read_bytes())
 oldAudit=r/'scripts/audit/stock-memory-store-records.lean';text=oldAudit.read_text();imports=[]
 for n in source:imports.append('import '+n[:-5].replace('/','.'))
 roots=['Backend.Stock.Proof.stock_lower_store_emitted']+['Backend.Stock.Memory.StoreRoots.'+n for n in ['stock_lower_source_parameter_type','stock_single_store_return_spec','stock_lower_integer_store_scan_fall_refines','stock_lower_integer_store_paired_source_step','stock_single_store_return_body']]+['E2E.StockMemory.StoreRoots.'+n for n in ['stock_lower_integer_store_paired_scan','stock_single_store_return_paired_body','single_store_return_paired_function_seeded','single_store_return_paired_function']]+['E2E.StockMemoryStoreFunctionWitness.complete_paired_integer_store_function_witness','Backend.Stock.Memory.StoreRoots.domain_of_single_store_return','Backend.Stock.Memory.StoreRoots.SingleClass.domain','E2E.StockMemoryStoreFunctionWitness.source_class_witness','E2E.StockMemoryStoreUninitializedWitness.complete_paired_uninitialized_store_function_witness']
 audit='scripts/audit/stock-memory-store-functions.lean';(r/audit).write_text('\n'.join(imports)+'\n'+text+'\n'+'\n'.join('#print axioms '+n for n in roots)+'\n')
 hashes={n:hashlib.sha256((r/n).read_bytes()).hexdigest() for n in [*source,audit]}
 def frozen():
  assert git('rev-parse','HEAD')==base and subprocess.run(['git','diff','--quiet'],cwd=r).returncode==0
  assert all(hashlib.sha256((r/n).read_bytes()).hexdigest()==h for n,h in hashes.items())
 frozen();normal=psutil.Process(3167178);schedulers=[]
 for c in normal.children(recursive=True):
  try:
   if c.name().startswith('python') and any(a.endswith('/lake-serial-build.py') or a=='scripts/lake-serial-build.py' for a in c.cmdline()):schedulers.append(c)
  except psutil.NoSuchProcess:pass
 assert len(schedulers)==1,'Inspect changed old normal gate phase before reserving resources'
 paused=schedulers[0];paused.suspend()
 while True:
  children=[c for c in paused.children() if live(c)];caps=[]
  for c in children:
   raw=c.environ().get('FV_MEMCAP','');caps.append(float(raw[:-1]) if raw.endswith('G') else float(raw[:-1])/1024 if raw.endswith('M') else 1000)
  if len(children)<=1 and sum(caps)<=12:break
  save('waiting',phase='finish-active-old-normal-source',caps_GiB=caps);time.sleep(3)
 env=dict(os.environ);env.update(json.loads((e/'author-env-v1.json').read_text()));env.update(FV_ROOT=str(r),FV_MEMCAP='4G',OMP_NUM_THREADS='1',OMP_THREAD_LIMIT='1',LEAN_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
 for n in [*source,audit]:
  frozen();label=Path(n).stem;save('running',phase=label,source_hashes=hashes)
  args=['lake','env','lean','-j1','--root='+str(r)]
  if n!=audit:args+=['-o',str(r/'.lake/build/lib/lean'/Path(n).with_suffix('.olean'))]
  args+=[str(r/n)];env['FV_MEMCAP_STATS']=str(e/('integer-store-functions-'+label+'-actual-v1.stats'))
  with (e/('integer-store-functions-'+label+'-actual-v1.log')).open('w') as out:run=subprocess.run(['nice','-n','10',str(r/'scripts/memcap.sh'),*args],cwd=r,env=env,stdout=out,stderr=subprocess.STDOUT)
  records.append(dict(module=n,returncode=run.returncode));assert run.returncode==0,records
 def axioms(p):
  t=p.read_text();a={n:set(x.strip() for x in s.split(',')) for n,s in re.findall(r"'([^']+)' depends on axioms: \[([^]]*)\]",t,re.S)};a.update({n:set() for n in re.findall(r"'([^']+)' does not depend on any axioms",t)});return a
 now=axioms(e/'integer-store-functions-stock-memory-store-functions-actual-v1.log');old=axioms(e/'integer-store-records-pr-audit-v1.log')
 assert len(now)==44 and all(a<={'propext','Classical.choice','Quot.sound'} for a in now.values()),now
 assert len(old)==29 and all(now[n]==a for n,a in old.items())
 frozen();save('passed',audit_roots=44,prior_axiom_sets_exact=29,all_axioms_standard=True,source_hashes=hashes,branch=git('branch','--show-current'),remaining='Actual store-aware machine consumer, production adapters, production activation and remaining original140 obligations.')
except BaseException as error:save('failed',error=repr(error));raise
finally:
 if paused is not None and live(paused):paused.resume()
