import Crates.MemoryCLICleanup
import Crates.MemoryCLIPlain
import Crates.StockMemoryProductionCleanupFallbackEntries
import Crates.StockMemoryProductionCleanupFallbackGlobal
import Crates.StockMemoryProductionCleanupStrictEntries
import Crates.StockMemoryProductionCleanupStrictGlobal
import Crates.StockMemoryProductionPlainFallbackEntries
import Crates.StockMemoryProductionPlainFallbackGlobal
import Crates.StockMemoryProductionPlainStrictEntries
import Crates.StockMemoryProductionPlainStrictGlobal
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let generated := fun (name : Name) =>
    let owner := (privateToUserName? name).getD name
    owner.toString.startsWith "Crates.StockMemoryProduction" || owner.toString.startsWith "Crates.MemoryCLI"
  let mut count : Nat := 0
  for (name, _) in env.constants.toList do
    unless generated name do continue
    for ax in ← collectAxioms name do
      if #[``propext, ``Classical.choice, ``Quot.sound].contains ax then continue
      unless generated ax && (ax.toString.splitOn "._native.native_decide.ax_").length > 1 do
        throwError "unexpected generated-proof axiom {ax} in {name}"
    count := count + 1
  unless count > 0 do throwError "empty generated-proof audit"
  logInfo m!"STOCK_MEMORY_GENERATED_AXIOMS_PASS {count}"
