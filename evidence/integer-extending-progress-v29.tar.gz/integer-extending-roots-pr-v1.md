Extending loads lacked actual Stock root contracts and source-derived dispatch proofs. This change proves signed and unsigned 8/16/32-bit root execution, exact pointer demand, fresh results, emitted loads and trace/state effects.

Original mapped source metadata determines the selected root internally. Source result types remain arbitrary. Source-built witnesses exercise actual first-match selection for all six roots.

Validation: four repository modules and six public axiom audits. Every audited root uses only standard axioms. Existing source dependencies match main. The normal production source remains frozen for its separate full validation. Production activation and retained/source execution follow in separate substantive batches; original #140 remains open.
