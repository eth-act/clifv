from pathlib import Path
import psutil,subprocess,os,json,time,datetime
b=Path('/home/lee/clifv');e=b/'.git/agent-evidence/stock-memory-20261029';r=b/'.worktrees/stock-extending-production-20261031';p=psutil.Process(363555);state=e/'integer-store-small-module-handoff-v1.json';paused=False
modules=['FV.Backend.Proof.StockMemoryStorePaired','FV.Backend.Proof.StockMemoryStoreMatchWitness','FV.Backend.Proof.StockMemoryStoreRecordValues','FV.Backend.Proof.StockMemoryStoreRecordExec','FV.Backend.Proof.StockMemoryStoreCoverage','FV.Backend.Proof.StockMemoryStoreSourceValues']
def save(status,**x):state.write_text(json.dumps(dict(status=status,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),primary_scheduler=p.pid,modules=modules,**x),indent=2)+'\n')
def live(c):
 try:return c.is_running() and c.status()!=psutil.STATUS_ZOMBIE
 except psutil.NoSuchProcess:return False
try:
 assert any(a=='scripts/lake-serial-build.py' for a in p.cmdline())
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()=='330e55698e83dbfe80a6524a6e916a44f6a3dd8b'
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=r,text=True).strip()
 p.suspend();paused=True
 while True:
  children=[c for c in p.children() if live(c)];caps=[]
  for c in children:
   raw=c.environ().get('FV_MEMCAP','');caps.append(float(raw[:-1]) if raw.endswith('G') else float(raw[:-1])/1024 if raw.endswith('M') else 1000)
  if len(children)<=1 and sum(caps)<=12:break
  save('waiting',phase='finish-current-active-source',caps_GiB=caps);time.sleep(3)
 env=dict(os.environ);env.update(json.loads((e/'author-env-v1.json').read_text()));env.update(FV_ROOT=str(r),OMP_NUM_THREADS='1',OMP_THREAD_LIMIT='1',LEAN_NUM_THREADS='1',CARGO_BUILD_JOBS='1',PYTHONDONTWRITEBYTECODE='1')
 save('running',phase='small-module-Lake-build',existing_caps_GiB=caps,budget_GiB=4)
 args=['nice','-n','10','python3','scripts/lake-serial-build.py','--budget','4G','--max-jobs','1','--max-cap','4G','--default-cap','4G','--out',str(e/'integer-store-small-modules-v1'),*modules]
 with (e/'integer-store-small-modules-v1.log').open('w') as out:run=subprocess.run(args,cwd=r,env=env,stdout=out,stderr=subprocess.STDOUT)
 assert run.returncode==0,run.returncode
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=r,text=True).strip()
 save('passed',phase='small-module-Lake-build',source_unchanged=True,budget_GiB=4)
except BaseException as error:save('failed',error=repr(error));raise
finally:
 if paused and live(p):p.resume()
