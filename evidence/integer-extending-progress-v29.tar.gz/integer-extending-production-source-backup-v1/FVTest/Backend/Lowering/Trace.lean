import FV.Backend
import FV.Backend.Lowering.StockReplay
import FV.Backend.MemoryExtLoadNIProduction
import FV.Opt.Legalize128Pass
import FVTest.Backend.CraneliftInput

/-!
# Instruction-selection diagnostics

`lean-backend-lowering-trace INPUT.clif OUTPUT.json` records initial value registers,
raw selected VCode, fired rules, cleanup output and the default regalloc2 input. It does not allocate or
emit code and does not change the compiler's lowering/checking path. Give it the
stock-effective Lean input from a settings-matched comparison to inspect that case.

The input is legalized exactly as in `lean-backend`; the report records this fact and
the legalization validator's results. These are structural diagnostics, not a
semantic-equivalence verdict or a replacement for the stock configuration receipt.
-/

namespace LoweringTrace

open Backend Lean

def regJson (r : Reg) : Json := toJson ((repr r).pretty)

def codeJson (vc : VCode) : Json := Json.mkObj [
  ("name", toJson vc.name),
  ("classes", toJson (vc.classes.map fun c => (repr c).pretty)),
  ("slot_bytes", toJson vc.slotBytes),
  ("outgoing_bytes", toJson vc.outgoing),
  ("rule_ids", toJson vc.rulesFired),
  ("rule_names", toJson (Isle.Aarch64.program.ruleNames vc.rulesFired.toList)),
  ("blocks", Json.arr (vc.blocks.map fun b => Json.mkObj [
    ("label", toJson b.label),
    ("params", Json.arr (b.params.map regJson)),
    ("branch_args", Json.arr (b.branchArgs.map regJson)),
    ("instructions", toJson (b.insts.map fun i => (repr i).pretty))]))]

/-- The current driver's checker replay, including each instruction's temporary range.
The checker independently reconstructs these calls; this is not an instrumented compiler. -/
def replayJson (f : Clif.Function) (ctx : Ctx) (initial : LState) : Except String Json := do
  let some blocks := Proof.Driver.lowBlocks f (Proof.Driver.stmtCall ctx)
      (Proof.Driver.termCallF ctx) (Proof.Driver.tryCallF ctx) 0 f.blocks initial f.blocks.length
    | throw "lowering checker replay failed"
  let mut calls := #[]
  for (b, bi) in blocks.zipIdx do
    for (s, j) in b.sl.zipIdx do
      let (_, _, rules) ← runTerm ctx "lower" [.inst (b.start + j)] s.st
      calls := calls.push (Json.mkObj [
        ("block_index", toJson bi), ("inst_index", toJson (b.start + j)),
        ("kind", toJson "statement"),
        ("first_temp", toJson s.st.nextVreg), ("next_temp", toJson s.st'.nextVreg),
        ("result_regs", toJson (s.rss.map fun rs => rs.map regJson)),
        ("rule_ids", toJson rules),
        ("instructions", toJson (s.st'.emitted.map fun i => (repr i).pretty))])
    calls := calls.push (Json.mkObj [
      ("block_index", toJson bi), ("inst_index", toJson (b.start + b.sl.length)),
      ("kind", toJson "terminator"),
      ("first_temp", toJson b.tst.nextVreg), ("next_temp", toJson b.tst'.nextVreg),
      ("targets", toJson b.targets),
      ("instructions", toJson (b.tst'.emitted.map fun i => (repr i).pretty))])
  pure (Json.arr calls)

/-- Diagnostic request with stock's per-successor arguments. The production
allocator adapter is unchanged until the corresponding proofs are migrated. -/
def stockAllocatorJson (r : Stock.Result) : Except String Json := do
  let j ← Json.parse (← vcodeJson r.code)
  let mut insts ← (← j.getObjVal? "insts").getArr?
  let mut start := 0
  for (b, bi) in r.code.blocks.zipIdx do
    let last := start + b.insts.size - 1
    if b.insts.back!.isTerminator && !b.insts.back!.isRet then
      let args ← r.edgeArgs[bi]!.mapM fun rs => rs.mapM vregNum
      insts := insts.modify last (fun i => i.setObjVal! "args" (toJson args))
    start := start + b.insts.size
  return j.setObjVal! "insts" (Json.arr insts)

def stockSnapshot (f : Clif.Function) : Except String Json := do
  let r ← Stock.lower f
  let allocator ← stockAllocatorJson r
  let values := r.ctx.valReg.toList.zipIdx |>.filterMap fun (reg, v) =>
    reg.map fun reg => Json.mkObj [
      ("value", toJson v), ("reg", regJson reg),
      ("ir_uses", toJson ((repr r.initial.uses[v]!).pretty)),
      ("register_demands", toJson r.final.demand[v]!)]
  let steps := r.schedule.map fun s => Json.mkObj [
    ("block_index", toJson s.block), ("inst_index", toJson s.inst),
    ("decision", toJson ((repr s.decision).pretty)),
    ("first_temp", toJson s.before.base.nextVreg),
    ("next_temp", toJson s.after.base.nextVreg),
    ("color_before", toJson s.before.color), ("color_after", toJson s.after.color),
    ("result_regs", toJson (s.results.map fun rs => rs.map regJson)),
    ("rule_ids", toJson s.rules),
    ("chunk", toJson (s.emitted.map fun i => (repr i).pretty)),
    ("instructions", toJson (s.after.base.emitted.map fun i => (repr i).pretty))]
  return Json.mkObj [
    ("status", toJson "lowered"), ("initial_next_vreg", toJson r.initial.base.nextVreg),
    ("value_regs", toJson values),
    ("block_order", toJson (r.order.nodes.map fun n => (repr n).pretty)),
    ("aliases", toJson r.final.alias), ("sunk", toJson r.final.sunk),
    ("schedule", Json.arr steps), ("selected", codeJson r.code),
    ("scan_replay", Json.mkObj [
      ("checked", toJson r.scans.size),
      ("accepted", toJson (r.scans.all Stock.ScanEvent.check))]),
    ("block_scan_replay", Json.mkObj [
      ("checked", toJson r.blockScans.size),
      ("records", toJson (r.blockScans.foldl (fun n b => n + b.output.records.length) 0)),
      ("accepted", toJson (r.blockScans.all Stock.BlockScanEvent.check))]),
    ("edge_args", toJson (r.edgeArgs.map fun args => args.map fun rs => rs.map regJson)),
    ("allocator_input", allocator)]

def snapshot (f : Clif.Function) (stockSchedule : Bool) (deadCleanup : Bool := true)
    (routes : Bool := true) (verify : Bool := true) : Except String Json := do
  let (ctx, ranges, initial) ← buildCtx f
  let selected ← lowerFunction f
  let allocationSelected ← if routes then lowerForAllocationMemoryExtLoadNI f verify deadCleanup
    else lowerForAllocation f verify deadCleanup
  let prepared ← prepare allocationSelected
  let replay ← replayJson f ctx initial
  let allocator ← match Json.parse (← vcodeJson (CraneliftInput.shape (some f) deadCleanup prepared).code) with
    | .ok j => pure j
    | .error e => throw s!"invalid allocator JSON: {e}"
  let values := ctx.valReg.toList.zipIdx |>.filterMap fun (r, value) =>
    r.map fun reg => Json.mkObj [
      ("value", toJson value), ("reg", regJson reg),
      ("def_inst", toJson ((ctx.valDef[value]?).join))]
  pure (Json.mkObj <| [
    ("initial_next_vreg", toJson initial.nextVreg),
    ("value_regs", toJson values),
    ("source_blocks", toJson (f.blocks.map (·.id))),
    ("instruction_ranges", toJson (ranges.map fun (start, stop) => #[start, stop])),
    ("checker_replay", replay),
    ("selected", codeJson selected),
    ("allocation_selected", codeJson allocationSelected),
    ("dead_cleanup", toJson deadCleanup), ("prepared", codeJson prepared),
    ("allocator_input", allocator)] ++ if stockSchedule then [
    ("stock_schedule", match stockSnapshot f with
      | .ok j => j
      | .error e => Json.mkObj [("status", toJson "unsupported"), ("reason", toJson e)])] else [])

def run (input output : String) (stockSchedule : Bool := false) (deadCleanup : Bool := true) : IO UInt32 := do
  let source ← IO.FS.readFile input
  let legalized := Opt.Legalize128.parsedFile128 (Clif.parseFile source)
  let routes := !(legalized.file.funcs.any fun p => p.func.toOption.any fun f => f.blocks.any (·.term.isTry))
  let rows := legalized.file.funcs.map fun parsed =>
    let result := match parsed.func with
      | .ok f =>
        let verify := ((unverifiedReason? f).isSome ||
          (legalized.unverified.lookup parsed.name).isSome || (overBudget? f).isSome).not
        snapshot f stockSchedule deadCleanup routes verify
      | .error e => .error e.toString
    match result with
    | .ok report => Json.mkObj [
        ("name", toJson parsed.name), ("status", toJson "lowered"), ("lowering", report)]
    | .error reason => Json.mkObj [
        ("name", toJson parsed.name), ("status", toJson "unsupported"),
        ("reason", toJson reason)]
  let report := Json.mkObj [
    ("schema", toJson (1 : Nat)), ("input", toJson input),
    ("dead_cleanup", toJson deadCleanup),
    ("legalization_accepted", toJson legalized.accepted),
    ("legalization_unverified", toJson legalized.unverified),
    ("functions", toJson rows)]
  IO.FS.writeFile output (report.pretty ++ "\n")
  return 0

end LoweringTrace

private def traceOptions : List String → Bool → Bool → Except String (Bool × Bool)
  | [], stock, cleanup => pure (stock, cleanup)
  | "--regalloc" :: "regalloc2" :: rest, stock, cleanup => traceOptions rest stock cleanup
  | "--stock-schedule" :: rest, _, cleanup => traceOptions rest true cleanup
  | "--dead-cleanup" :: rest, stock, _ => traceOptions rest stock true
  | "--no-dead-cleanup" :: rest, stock, _ => traceOptions rest stock false
  | _, _, _ => throw "unknown lowering-trace option (allocator diagnostics support regalloc2)"

def main (args : List String) : IO UInt32 := do
  match args with
  | input :: output :: flags =>
    match traceOptions flags false true with
    | .ok (stock, cleanup) => LoweringTrace.run input output stock cleanup
    | .error error =>
      IO.eprintln error
      return 2
  | _ =>
    IO.eprintln "usage: lean-backend-lowering-trace INPUT.clif OUTPUT.json [--regalloc regalloc2] [--stock-schedule] [--dead-cleanup|--no-dead-cleanup]"
    return 2
