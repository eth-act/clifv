import FV.Backend.MemoryStoreNIProductionStage
import FVTest.Backend.Lowering.StockScalarTestSupport
import FV.Backend.LinearScan

namespace FVTest.StockMemoryStoreNativeStage
open Backend Backend.Proof.Driver
set_option autoImplicit false

private def require (b : Bool) (message : String) : IO Unit :=
  unless b do throw (IO.userError message)
private def get {α : Type} (r : Except String α) : IO α :=
  match r with | .ok a => pure a | .error e => throw (IO.userError e)

def fixture (cfg : Bool) (name : String) (i : Nat) (loadTy : String := "i32") (loadOp : String := "load") : String :=
  if i == 2 then
    "function %" ++ name ++ "(i64) -> i64 system_v {\nblock0(v0: i64):\n    return v0\n}\n"
  else
    let params := if i == 0 then "i64, " ++ loadTy else loadTy ++ ", i64"
    let block := if i == 0 then "v0: i64, v1: " ++ loadTy else "v0: " ++ loadTy ++ ", v1: i64"
    let pointer := if i == 0 then "v0" else "v1"
    let value := if i == 0 then "v1" else "v0"
    "function %" ++ name ++ "(" ++ params ++ ") system_v {\nblock0(" ++ block ++ "):\n" ++
      "    " ++ loadOp ++ "." ++ loadTy ++ " notrap " ++ value ++ ", " ++ pointer ++ "\n    return\n}\n"

def check (out : System.FilePath) : IO Unit := do
  let pairs := [("store","i8"),("store","i16"),("store","i32"),("store","i64"),
    ("istore8","i8"),("istore8","i16"),("istore8","i32"),("istore8","i64"),
    ("istore16","i16"),("istore16","i32"),("istore16","i64"),("istore32","i32"),("istore32","i64")]
  IO.FS.createDirAll out
  for (op,ty) in pairs do
    let names := ["memory_store0","memory_store1","memory_retained"]
    let clif := String.join (names.zipIdx.map fun (name,i) => fixture false name i ty op)
    let parsed := Clif.parseFile clif
    require (parsed.funcs.length == 3 && parsed.funcs.all (·.func.isOk)) "store source parse failed"
    for p in parsed.funcs.take 2 do
      let f ← match p.func with | .ok f => pure f | .error error => throw (IO.userError s!"{repr error}")
      let result ← get (Stock.lower f)
      let selected ← get (Stock.MemoryStore.lowerValidated f)
      require (Stock.MemoryStore.check f result.code && SemanticNIStoreStage.check f result.code &&
        decide (selected = result.code) && !Backend.Proof.Driver.lowerCheck f result.code)
        "store candidate did not select the actual register-aligned driver"
    for cleanup in [false,true] do
      let production ← compileFileMemoryStoreNIStageWhen true (fun vcs => do
        for vc in vcs do
          let some source := parsed.funcs.find? (fun p => p.name == vc.name)
            | throw (IO.userError "allocator source missing")
          let f ← match source.func with | .ok f => pure f | .error error => throw (IO.userError s!"{repr error}")
          let expected ← get ((Stock.MemoryStore.lowerValidated f).bind fun raw => prepare (Stock.Arithmetic.stage cleanup raw))
          require (decide (vc = expected)) "allocator received a different prepared artifact"
        pure (allocateLean vcs)) parsed [] cleanup
      require (production.funcs.length == 3 && production.unsupported.isEmpty && production.unverified.isEmpty &&
        production.unvalidated.isEmpty) "store compilation lost a successful stage"
      let prior ← compileFileMemoryExtLoadNIWhen true (fun vcs => pure (allocateLean vcs)) parsed [] cleanup
      let attempts ← IO.mkRef (0 : Nat)
      let retried ← compileFileMemoryStoreNIStageWhen true (fun vcs => do
        let count ← attempts.get
        attempts.set (count+1)
        if count == 0 then pure (vcs.map fun _ => .error "forced store allocator failure")
        else pure (allocateLean vcs)) parsed [] cleanup
      let priorBytes ← get prior.object
      let retriedBytes ← get retried.object
      require ((← attempts.get) ≥ 2 && retriedBytes == priorBytes &&
        retried.tableJson == prior.tableJson && retried.unsupported == prior.unsupported &&
        retried.unverified == prior.unverified && retried.unvalidated == prior.unvalidated)
        "whole-file retry changed the prior bytes, identities or stages"
      let label := op ++ "-" ++ ty ++ (if cleanup then "-cleanup" else "-plain")
      IO.FS.writeBinFile (out / (label ++ ".o")) (← get production.object)
      IO.FS.writeFile (out / (label ++ ".json")) production.tableJson
      IO.FS.writeFile (out / (label ++ ".clif")) clif
      IO.println s!"STOCK_STORE_STAGE_OBJECT_PASS {label}: actual driver, allocator binding, complete file retry"
end FVTest.StockMemoryStoreNativeStage

def main (args : List String) : IO UInt32 := do
  FVTest.StockMemoryStoreNativeStage.check (System.FilePath.mk (args[0]?.getD "/tmp/stock-store-native-stage"))
  pure 0
