from pathlib import Path
import subprocess,runpy
b=Path('/home/lee/clifv');e=b/'.git/agent-evidence/stock-memory-20261029'
for name,directory in [('stock-comparison-summary-1','pr802-ci-summary-v1'),('stock-comparison-artifacts-1','pr802-ci-artifacts-v1')]:
 out=e/directory;out.mkdir(exist_ok=False);subprocess.run(['gh','run','download','41214570378','--repo','eth-act/clifv','--name',name,'--dir',str(out)],cwd=b,check=True)
s=(e/'adopt-integer-extending-ci-official-v3.py').read_text().replace('integer-extending-production-official-state-v3.json','integer-store-production-official-state-v1.json').replace('integer-extending-production-source-v3.json','integer-store-production-publication-v1.json').replace("packet['base']","packet['commit']").replace("packet['files']","packet['source_hashes']").replace('pr794-ci-summary-v1','pr802-ci-summary-v1').replace('pr794-ci-artifacts-v1','pr802-ci-artifacts-v1').replace('integer-production-official-vectors-v2/results.json','integer-extending-production-official-vectors-v3/results.json').replace('integer-extending-production-official-vectors-v3\'','integer-store-production-official-vectors-v1\'')
helper=e/'verify-integer-store-ci-official-v1.py';helper.write_text(s);runpy.run_path(str(helper),run_name='__main__')
