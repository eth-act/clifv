from pathlib import Path
import psutil,subprocess,json,hashlib,os,time,datetime,re
b=Path('/home/lee/clifv');e=b/'.git/agent-evidence/stock-memory-20261029';r=b/'.worktrees/stock-extending-production-20261031';stage=e/'integer-store-cfg-domain-module-paths-v2';state=e/'integer-store-cfg-domain-module-paths-state-v2.json';paused=None;records=[]
source=json.loads((e/'integer-store-cfg-domain-source-v2.json').read_text())['files'];base='9bbb619d7ed7ce59bc311c70df9f056da0c59217'
def save(status,**x):state.write_text(json.dumps(dict(status=status,records=records,base=base,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),**x),indent=2)+'\n')
def live(p):
 try:return p.is_running() and p.status()!=psutil.STATUS_ZOMBIE
 except psutil.NoSuchProcess:return False
def frozen():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==base
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=r,text=True).strip()
 for n,data in source.items():assert hashlib.sha256(Path(data['source']).read_bytes()).hexdigest()==data['sha256'] and not (r/n).exists()
try:
 frozen()
 for n,data in source.items():
  dest=stage/n;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(Path(data['source']).read_bytes())
 roots=['Backend.Stock.Memory.stock_nop_body_of_split','Backend.Stock.Proof.Control.nop_jump_body_returns_at']+['Backend.Stock.Memory.StoreRoots.'+n for n in ['actual_nonentry_store_return','two_block_store_return','two_block_store_return_function','domain_of_two_block_store_return']]+['Backend.Stock.Memory.StoreCfgFixture.domain','Backend.Stock.Memory.StoreCfgFixture.domain_and_lower_witness']
 audit=stage/'scripts/audit/stock-memory-store-cfg-domain.lean';audit.parent.mkdir(parents=True,exist_ok=True);audit.write_text('\n'.join('import '+n[:-5].replace('/','.') for n in source)+'\n'+(e/'integer-store-cfg-witness-module-paths-v3/scripts/audit/stock-memory-store-cfg-witness.lean').read_text()+'\n'+'\n'.join('#print axioms '+n for n in roots)+'\n')
 paused=psutil.Process(1213150);assert any(a=='scripts/lake-serial-build.py' for a in paused.cmdline());paused.suspend()
 while True:
  children=[c for c in paused.children() if live(c)];caps=[]
  for c in children:
   raw=c.environ().get('FV_MEMCAP','');caps.append(float(raw[:-1]) if raw.endswith('G') else float(raw[:-1])/1024 if raw.endswith('M') else 1000)
  if len(children)<=1 and sum(caps)<=12:break
  save('waiting',phase='finish-current-active-source',caps_GiB=caps);time.sleep(3)
 env=dict(os.environ);env.update(json.loads((e/'author-env-v1.json').read_text()));env.update(FV_ROOT=str(r),FV_MEMCAP='4G',OMP_NUM_THREADS='1',OMP_THREAD_LIMIT='1',LEAN_NUM_THREADS='1',CARGO_BUILD_JOBS='1',PYTHONDONTWRITEBYTECODE='1')
 for name in [*source,'scripts/audit/stock-memory-store-cfg-domain.lean']:
  if name=='FV/Backend/Proof/StockMemoryNopBodySource.lean':
   prior=json.loads((e/'integer-store-cfg-domain-module-paths-state-v1.json').read_text());assert prior['records'][0]['returncode']==0 and prior['source'][name]['sha256']==source[name]['sha256'] if 'source' in prior else prior['records'][0]['returncode']==0
   assert hashlib.sha256((e/'integer-store-cfg-domain-module-paths-v1'/name).read_bytes()).hexdigest()==source[name]['sha256']
   records.append(dict(module=name,returncode=0,reused_exact_passed_module=True));continue
  frozen();label=Path(name).stem;save('running',phase=name)
  args=['lake','env','lean','-j1','--root='+str(stage)]
  if name in source:
   output=r/'.lake/build/lib/lean'/Path(name).with_suffix('.olean');output.parent.mkdir(parents=True,exist_ok=True);args+=['-o',str(output)]
  args+=[str(stage/name)];env['FV_MEMCAP_STATS']=str(e/('integer-store-cfg-domain-module-path-'+label+'-v2.stats'))
  with (e/('integer-store-cfg-domain-module-path-'+label+'-v2.log')).open('w') as out:run=subprocess.run(['nice','-n','10',str(r/'scripts/memcap.sh'),*args],cwd=r,env=env,stdout=out,stderr=subprocess.STDOUT)
  records.append(dict(module=name,returncode=run.returncode));assert run.returncode==0,records
 def axioms(p):
  text=p.read_text();a={n:set(x.strip() for x in s.split(',')) for n,s in re.findall(r"'([^']+)' depends on axioms: \[([^]]*)\]",text,re.S)};a.update({n:set() for n in re.findall(r"'([^']+)' does not depend on any axioms",text)});return a
 now=axioms(e/'integer-store-cfg-domain-module-path-stock-memory-store-cfg-domain-v2.log');old=axioms(e/'integer-store-cfg-witness-module-path-stock-memory-store-cfg-witness-v3.log')
 assert len(now)==59,now
 standard={'propext','Classical.choice','Quot.sound'}
 fixed={'Backend.Stock.Memory.StoreCfgFixture.lowered','Backend.Stock.Memory.StoreCfgFixture.domain_and_lower_witness','E2E.StockMemoryStoreCfgFunctionWitness.complete_paired_integer_store_cfg_function_witness'}
 for n,used in now.items():
  assert used<=standard or n in fixed and all(a in standard or '._native.native_decide.ax_' in a for a in used),(n,used)
 assert len(old)==51 and all(now[n]==a for n,a in old.items())
 frozen();save('passed',audit_roots=59,prior_axiom_sets_exact=51,generic_axioms_standard=True,fixed_acceptance_native_witnesses=True,source=source,scope='Six actual helper identities derive the original memory-model Domain across NOP entry,jump,store and return,including trap preservation. All51 previous sets stay exact. Generic contracts stay standard-only;only fixed concrete acceptance witnesses use permitted native_decide. Surrounding target NOPs,machine transport and CFG production activation remain open. The802 source stays frozen.')
except BaseException as error:save('failed',error=repr(error));raise
finally:
 if paused is not None and live(paused):paused.resume()
