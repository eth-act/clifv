from pathlib import Path
import os,subprocess,json,datetime,sys
base=Path('/home/lee/clifv');root=base/'.worktrees/stock-cfg-source-20261025';e=base/'.git/agent-evidence/stock-memory-20261029'
env=dict(os.environ);env.update(json.loads((e/'author-env-v1.json').read_text()));env.update(FV_ROOT=str(root),FV_MEMCAP='4G',FV_PIPELINE_T='0',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',CARGO_BUILD_JOBS='2')
state=e/'captured-proof-state-v4.json'
def save(status,**extra):state.write_text(json.dumps(dict(status=status,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),root=str(root),**extra),indent=2)+'\n')
try:
 for label,args in [('build-captured',['python3','scripts/lake-serial-build.py','--budget','4G','--max-jobs','1','--max-cap','4G','--default-cap','4G','--out',str(e/'captured-proof-build-v4'),*json.loads((e/'captured-proof-modules-v4.json').read_text())])]:
  save('running',phase=label)
  with (e/('captured-'+label+'-v4.log')).open('w') as log:
   result=subprocess.run([str(root/'scripts/memcap.sh'),*args],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
  if result.returncode:raise RuntimeError(str((label,result.returncode)))
 save('passed')
except Exception as error:save('failed',error=str(error));raise
