from pathlib import Path
import os,subprocess,json,hashlib,tarfile,datetime,io
os.nice(19);os.sched_setaffinity(0,{3});root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');os.chdir(root)
def git(*a,env=None):return subprocess.check_output(['git',*a],env=env,text=True).strip()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();prefix='/tmp/stock-conditional-forward-cfg-';files=[];expendable={}
for name in ['normal-gates-v1','full-gates-v1','current-gates-v1','current-integration-v1','next-nonentry-port']:
 directory=Path(prefix+name)
 for p in directory.rglob('*'):
  if not p.is_file():continue
  if p.suffix in {'.olean','.ilean','.c','.so','.a','.bc'}:expendable[str(p)]=sha(p)
  else:files.append(p)
for p in Path('/tmp').glob('stock-conditional-forward-cfg-*'):
 if p.is_file() and p.suffix in {'.json','.py','.log','.lean','.md'} and not any(x in p.name for x in ['conditional-runner','forward-runner','consumer-batch','post-runner','post-gates','current-backup-manifest','current-backup-receipt']):files.append(p)
files.append(Path('/tmp/stock-general-cfg-status.md'))
files=sorted(set(files));head=git('rev-parse','HEAD');assert not git('status','--porcelain')
for name in ['normal-gates-v1','full-gates-v1','current-gates-v1']:
 d=json.load(open(prefix+name+'/receipt.json'));assert d['state']=='passed' and d['head']==head
manifest=dict(head=head,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),state='Current production integration/full regressions passed on frozen7170a146:4172normal/4976tools/96audits/3716roots/all3698oldAXsets comparisonexact;78currentcommands/64generatedmodules/18rootpackages;24000native/3000references/0failure/0disagreement;fullruntime/encoder/bothE2E/identities/examples pass. Six retained integrations and post gates remain pending. Next65Std-only draft audit remains valid for its closed import chain; later NextParameterCompatibility/Entry/JumpDomain source is pending, NOT validated. Failed compatibility drafts retained. No merge-ready/full140/agreement-improvement claim.',files={str(p):sha(p) for p in files},omitted_expendable_module_outputs=expendable)
m=Path(prefix+'current-backup-manifest-v1.json');m.write_text(json.dumps(manifest,indent=2)+'\n');files.append(m);archive=Path(prefix+'current-backup-v1.tar.gz')
with tarfile.open(archive,'w:gz',compresslevel=1) as t:
 for p in files:
  assert p==m or sha(p)==manifest['files'][str(p)],str(p)
  t.add(p,arcname=str(p).lstrip('/'),recursive=False)
assert archive.stat().st_size<32*1024*1024,archive.stat().st_size
branch='agent/stock-cfg-body-progress-20261025T025359Z';parent=git('rev-parse',branch);idx=Path(prefix+'current-backup-v1.index');idx.unlink(missing_ok=True);e=os.environ.copy();e['GIT_INDEX_FILE']=str(idx);git('read-tree',parent,env=e)
for p,k in [(m,'evidence/conditional-forward-current-manifest-v1.json'),(archive,'evidence/conditional-forward-current-v1.tar.gz')]:
 b=git('hash-object','-w',str(p));git('update-index','--add','--cacheinfo',f'100644,{b},{k}',env=e)
tree=git('write-tree',env=e);commit=git('commit-tree',tree,'-p',parent,'-m','Back up complete current ranked-conditional production integration, actual native bytes and frozen regressions');git('update-ref','refs/heads/'+branch,commit,parent);subprocess.run(['git','push','origin',branch],check=True);assert git('ls-remote','origin','refs/heads/'+branch).split()[0]==commit
blob=subprocess.check_output(['git','show',commit+':evidence/conditional-forward-current-v1.tar.gz']);assert blob==archive.read_bytes();checked=0
with tarfile.open(fileobj=io.BytesIO(blob),mode='r:gz') as t:
 for entry in t:
  key='/'+entry.name
  if key in manifest['files']:assert hashlib.sha256(t.extractfile(entry).read()).hexdigest()==manifest['files'][key];checked+=1
assert checked==len(manifest['files']);receipt=dict(head=head,evidence_commit=commit,archive_sha256=hashlib.sha256(blob).hexdigest(),bytes=len(blob),verified_files=checked,omitted_expendable_outputs=len(expendable),state='passed; retained/post gates pending');Path(prefix+'current-backup-receipt-v1.json').write_text(json.dumps(receipt,indent=2)+'\n');idx.unlink();print(json.dumps(receipt))
p=Path('/tmp/stock-general-cfg-status.md');s=p.read_text();s+='\nCurrent complete production integration/native/full-regression evidence backed '+commit+'; '+str(checked)+'archivedfiles verified. Expendable compiled-module hashes recorded without archiving cache bytes. Retained/post gates remain active/pending; current source7170a146 still frozen. Later compatibility/entry/domain drafts are saved pending code, not included in the65Std-only audit claim. Updated UTC: '+manifest['utc']+'\n';p.write_text(s)
