import NextParameterEntry
import NextParameterCompatibility
import FV.Backend.Proof.StockScalarContract
namespace Backend.Stock.Proof.ConditionalValues.NextNonentry
open Backend.Proof Backend.Proof.Driver Backend.Stock.Proof.ForwardSource
set_option autoImplicit false
set_option Elab.async false

theorem domain_of_parameter_jump_cfg {f : Clif.Function} {rank : Nat → Nat}
    (scope : LowerScope f) (dominated : Dominated f) (abi : sigAbiOk f.sig = true)
    (ordinary : (sigRets f.sig).any (·.purpose == .sret) = false)
    (ranked : Ranked f rank) (terms : ParameterTerms f)
    (family : ∀ b ∈ f.blocks,∀ stm ∈ b.body,MaskBody.Family stm.inst)
    {entry : Clif.Block} {bc : Clif.BlockCall} (source : f.blocks[0]? = some entry)
    (jump : entry.term = .jump bc) : Scalar.Domain f := by
  refine ⟨scope,dominated,abi,ordinary,?_,?_⟩
  · intro result run args cm fr entered env cp fuel vals mem returned F isem refines driver
      sb syms memorySem MR stable w memory arguments
    obtain ⟨ρ,simulation⟩ := parameter_jump_return_frame run scope dominated abi ranked
      (parameter_terms_nonentry terms) family source jump entered returned refines driver memorySem stable memory arguments
    exact ⟨ρ,simulation.legacyCompatible
      (parameter_legacy_compatible terms run scope dominated family refines driver stable env cp)⟩
  · intro result run args cm fr entered env cp fuel code trapped F isem refines driver
      sb syms memorySem MR stable w memory arguments
    obtain ⟨ρ,simulation⟩ := parameter_jump_trap_frame run scope dominated abi ranked
      (parameter_terms_nonentry terms) family source jump entered trapped refines driver memorySem stable memory arguments
    exact ⟨ρ,simulation.legacyCompatible
      (parameter_legacy_compatible terms run scope dominated family refines driver stable env cp)⟩

theorem all_parameter_terms : ParameterTerms function := by
  intro bi b block
  by_cases nonentry : bi ≠ 0
  · exact nonentry_terms bi b block nonentry
  · have entry : bi = 0 := Classical.not_not.mp nonentry
    subst bi
    simp [function] at block
    subst b
    exact Or.inl ⟨⟨1,[7]⟩,rfl⟩

theorem original_domain_witness : Scalar.Domain function :=
  domain_of_parameter_jump_cfg scope dominated rfl rfl ranked all_parameter_terms family
    (entry := function.blocks[0]!) (bc := ⟨1,[7]⟩) rfl rfl

namespace Trap
theorem all_parameter_terms : ParameterTerms function := by
  intro bi b block
  by_cases nonentry : bi ≠ 0
  · exact nonentry_terms bi b block nonentry
  · have entry : bi = 0 := Classical.not_not.mp nonentry
    subst bi
    simp [function] at block
    subst b
    exact Or.inl ⟨⟨1,[7]⟩,rfl⟩

theorem original_domain_witness : Scalar.Domain function :=
  domain_of_parameter_jump_cfg scope dominated rfl rfl ranked all_parameter_terms family
    (entry := function.blocks[0]!) (bc := ⟨1,[7]⟩) rfl rfl
end Trap
#print axioms domain_of_parameter_jump_cfg
#print axioms original_domain_witness
#print axioms Trap.original_domain_witness
end Backend.Stock.Proof.ConditionalValues.NextNonentry
