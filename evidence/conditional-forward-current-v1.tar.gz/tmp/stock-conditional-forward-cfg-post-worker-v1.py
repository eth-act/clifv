from pathlib import Path
import os,json,subprocess,time
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');os.chdir(root);os.nice(10);os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:2])
prefix='/tmp/stock-conditional-forward-cfg-';receipt=Path(prefix+'consumer-batch-v1.json')
while not receipt.exists() or json.load(receipt.open())['state']=='running':
 time.sleep(10)
assert json.load(receipt.open())['state']=='passed'
with open(prefix+'post-runner-v1.log','w') as f:r=subprocess.run(['python3','scripts/stock-delivery-gates.py','run',prefix+'post-manifest-v1.json','--root',str(root),'--out',prefix+'post-gates-v1'],stdout=f,stderr=subprocess.STDOUT)
print('POST_BATCH_TERMINAL',r.returncode,flush=True)
