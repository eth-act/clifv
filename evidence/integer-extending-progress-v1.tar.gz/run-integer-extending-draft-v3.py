from pathlib import Path
import os, subprocess, json, datetime, time, hashlib
import psutil

b=Path('/home/lee/clifv');r=b/'.worktrees/stock-cfg-source-20261025'
e=b/'.git/agent-evidence/stock-memory-20261029'
state=e/'integer-extending-draft-state-v3.json';records=[]
source=json.loads((e/'integer-production-source-v2.json').read_text())
env=dict(os.environ);env.update(json.loads((e/'author-env-v1.json').read_text()))
env.update(FV_ROOT=str(r),FV_MEMCAP='12G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',
           LEAN_NUM_THREADS='2',CARGO_BUILD_JOBS='1')
for key in ['FV_PIPELINE_T','BLESS']:
    env.pop(key,None)
paused=None

def save(status,**extra):
    state.write_text(json.dumps(dict(status=status,records=records,head=source['head'],
        utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),**extra),indent=2)+'\n')

def live(process):
    try:
        return process.is_running() and process.status()!=psutil.STATUS_ZOMBIE
    except psutil.NoSuchProcess:
        return False

def frozen():
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==source['head']
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=r,text=True).strip()
    assert all(hashlib.sha256((r/n).read_bytes()).hexdigest()==h for n,h in source['files'].items())

def run(label,args):
    frozen();save('running',phase=label,normal_scheduler_paused=paused.pid if paused else None)
    with (e/('integer-extending-'+label+'-v3.log')).open('w') as log:
        done=subprocess.run(['nice','-n','10',str(r/'scripts/memcap.sh'),*map(str,args)],
            cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
    records.append(dict(label=label,returncode=done.returncode))
    assert done.returncode==0,(label,done.returncode)

try:
    frozen()
    normal=psutil.Process(3167178)
    assert 'integer-production-normal-v2' in ' '.join(normal.cmdline())
    while live(normal):
        candidates=[]
        for child in normal.children(recursive=True):
            try:
                if child.name().startswith('python') and any(arg.endswith('/lake-serial-build.py') or arg=='scripts/lake-serial-build.py' for arg in child.cmdline()):
                    candidates.append(child)
            except psutil.NoSuchProcess:
                pass
        if candidates:
            assert len(candidates)==1
            paused=candidates[0]
            paused.suspend()
            save('waiting',phase='finish-current-normal-modules',normal_scheduler_paused=paused.pid,
                 reason='Finish every active module without interruption. Pause only future scheduling. Reserve4GiB for the paused normal tree and12GiB for focused checks.')
            while any(live(child) for child in paused.children(recursive=True)):
                time.sleep(5)
            rss=sum(p.memory_info().rss for p in [normal,*normal.children(recursive=True)] if live(p))
            assert rss < 4*1024**3,('Paused normal tree exceeds reserved4GiB',rss)
            break
        save('waiting',phase='normal-tool-phase',dependency_pid=normal.pid)
        time.sleep(5)
    env['LEAN_NUM_THREADS']='1'
    env['OMP_NUM_THREADS']='1'
    env['OMP_THREAD_LIMIT']='1'
    env['FV_MEMCAP_STATS']=str(e/'integer-extending-draft-memory-v3.stats')
    run('draft',['lake','env','lean','-j1','--root='+str(e),e/'StockMemoryExtLoadDraftV3.lean'])
    import re
    text=(e/'integer-extending-draft-v3.log').read_text()
    audit={n:set(x.strip() for x in a.split(',')) for n,a in re.findall(r"'([^']+)' depends on axioms: \[([^]]*)\]",text,re.S)}
    assert len(audit)==6 and all(a<={'propext','Classical.choice','Quot.sound'} for a in audit.values())
    frozen();save('passed',audit_roots=6,all_axioms_standard=True,scope='Next extending-load draft only. No production source changed. Not a786 regression gate.')
except BaseException as error:
    save('failed',error=repr(error),scope='Unverified next-class draft, outside786. Inspect diagnostics and fix the proof; no production regression is asserted.')
    raise
finally:
    if paused is not None and live(paused):
        paused.resume()
        (e/'integer-extending-normal-resumed-v3.json').write_text(json.dumps(dict(
            scheduler_pid=paused.pid,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
            reason='Focused resource handoff ended; the existing normal scheduler resumes without a restart.'),indent=2)+'\n')
