from pathlib import Path
import os,json,subprocess,datetime
r=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');e=Path('/home/lee/clifv/.git/agent-evidence/stock-memory-20261029')
env=dict(os.environ);env.update(json.loads((e/'author-env-v1.json').read_text()));env.update(FV_ROOT=str(r),FV_MEMCAP='4G',OMP_NUM_THREADS='1',OMP_THREAD_LIMIT='1',LEAN_NUM_THREADS='1')
with (e/'integer-extending-draft-v2.log').open('w') as log:
 done=subprocess.run(['nice','-n','10',str(r/'scripts/memcap.sh'),'lake','env','lean','-j1','--root='+str(e),str(e/'StockMemoryExtLoadDraftV2.lean')],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
(e/'integer-extending-draft-state-v2.json').write_text(json.dumps(dict(status='passed' if done.returncode==0 else 'failed',returncode=done.returncode,utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),indent=2)+'\n')
raise SystemExit(done.returncode)
