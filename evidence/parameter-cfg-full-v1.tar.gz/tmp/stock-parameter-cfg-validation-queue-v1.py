from pathlib import Path
import concurrent.futures,datetime,json,os,queue,subprocess,threading,time
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');prefix='/tmp/stock-parameter-cfg-';os.chdir(root)
normal=json.load(open(prefix+'normal-gates-v1/receipt.json'));assert normal['state']=='passed',normal['state']
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head=='9f27ad6c3b13f3fd378693389e82e9cdaf616b65';assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
items=queue.Queue()
for kind in ['current','full','next-memory-probe','conditional-forward','conditional','forward','linear','scalar-entry','entry','cfg']:items.put(kind)
lock=threading.Lock();failed=threading.Event();records=[];progress=Path(prefix+'validation-queue-v1.json')
def save():
 progress.write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),head=head,max_parallel=2,memory_per_lane='8G',cpu_lanes=[[0,1],[2,3]],source_frozen=True,records=records),indent=2)+'\n')
def run(kind,lane):
 mp=Path(prefix+kind+'-manifest-v1.json');m=json.load(mp.open());assert m['candidate']==head and m['env']['FV_MEMCAP']=='8G'
 with lock:rec=dict(kind=kind,lane=lane,state='running',started=datetime.datetime.now(datetime.timezone.utc).isoformat());records.append(rec);save();print('START',kind,'lane',lane,flush=True)
 with open(prefix+kind+'-runner-v1.log','w') as log:
  r=subprocess.run(['taskset','-c',('0,1' if lane==0 else '2,3'),'nice','-n','10','python3','scripts/stock-delivery-gates.py','run',str(mp),'--root',str(root),'--out',prefix+kind+'-gates-v1'],stdout=log,stderr=subprocess.STDOUT)
 with lock:rec.update(state='passed' if r.returncode==0 else 'failed',returncode=r.returncode,ended=datetime.datetime.now(datetime.timezone.utc).isoformat());save();print('END',kind,rec['state'],flush=True)
 if r.returncode and kind!='next-memory-probe':failed.set()
 return r.returncode

def worker(lane):
 while not failed.is_set():
  try:kind=items.get_nowait()
  except queue.Empty:return
  run(kind,lane);items.task_done()
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 futures=[pool.submit(worker,lane) for lane in [0,1]]
 for f in futures:f.result()
if failed.is_set():raise SystemExit('A gate failed; independent active cohorts finished and new work was held. Inspect receipts before resuming.')
assert items.empty();raise SystemExit(run('post',0))
