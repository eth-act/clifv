"""Optional bounded elaboration experiment on an exact copied generated root.
No repository or active integration artifact is edited. Run only with a free 8G lane.
"""
from pathlib import Path
import datetime,hashlib,json,os,re,subprocess,time
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');generated=Path('/tmp/stock-parameter-cfg-current-integration-v1/linked');name='StockCfgParameterProduction100CleanupFallbackEntries';original=generated/'Crates'/(name+'.lean');out=Path('/tmp/stock-parameter-cfg-generated-root-probe-v1');out.mkdir(exist_ok=False);copy=out/'Crates'/(name+'.lean');copy.parent.mkdir();text=original.read_text();needle='/-- **`backend_correct_program` for `actual_stock_general_div_0`** -/';assert text.count(needle)==1
text=text.replace(needle,'-- Elaboration-only experiment; the entire original input/import/theorem source is retained.\nattribute [local irreducible] input\n\n'+needle)
assert re.findall(r'(?m)^theorem (\w+)',text)==re.findall(r'(?m)^theorem (\w+)',original.read_text())
copy.write_text(text)
env=os.environ.copy();leanpath=subprocess.check_output(['lake','env','printenv','LEAN_PATH'],cwd=root,env=env,text=True).strip();env['LEAN_PATH']=str(generated)+':'+leanpath
start=time.monotonic();argv=['lean','--root='+str(out),'-o',str(copy.with_suffix('.olean')),str(copy)];log=out/'compile.log';timeout=False
with log.open('w') as f:
 try:r=subprocess.run(argv,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=120);rc=r.returncode
 except subprocess.TimeoutExpired:rc=124;timeout=True
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();receipt=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),kind='optional elaboration-only diagnostic, not an author gate or implementation change',source_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),original_source=str(original),original_source_sha256=sha(original),copy_source_sha256=sha(copy),argv=argv,seconds=time.monotonic()-start,returncode=rc,timeout=timeout,identical_imports_and_public_theorem_headers=True,all_original_input_definitions_untouched=True,log_sha256=sha(log),next='If fast and correct, compare exact generated axiom sets and port only alongside the next substantive source/effects class. Otherwise keep this failed/timeout diagnostic and remove expendable outputs; never count it as validation.')
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
