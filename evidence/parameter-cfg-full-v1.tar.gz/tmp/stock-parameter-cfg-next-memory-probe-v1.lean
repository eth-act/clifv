import FV.Clif.Parse
import FV.Backend.SemanticNICheck
import FV.Backend.Lowering.Stock

-- Diagnostic observation of an unchanged real captured source, not a new correctness theorem.
#eval show IO Unit from do
  let text ← IO.FS.readFile "/home/lee/clifv/.worktrees/stock-cfg-source-20261025/examples/survey/target/fv/plain-leanlink-verified-leanld/tmp/29204d9a8e90/split/_RNxC13h_dyn_generic12H3GPtIT8Zs5B.unopt.clif"
  let parsed := Clif.parseFile text
  let some f := parsed.funcs[0]?.bind (fun p => p.func.toOption)
    | throw (IO.userError "actual memory source did not parse")
  IO.println s!"ACTUAL_SOURCE {f.name} blocks={f.blocks.length}"
  IO.println s!"ORIGINAL_CHECKS scope={Backend.Proof.Driver.lowerScopeB f} dominated={Backend.Proof.Driver.dominatedB f} abi={Backend.sigAbiOk f.sig}"
  match Backend.Stock.lower f with
  | .error message => throw (IO.userError message)
  | .ok result =>
    IO.println s!"ACTUAL_STOCK_LEGACY_CHECK {Backend.Proof.Driver.lowerCheck f result.code}"
    IO.println s!"ACTUAL_STOCK_SEMANTIC_NI_CHECK {Backend.SemanticNI.check f result.code}"
    IO.println s!"ACTUAL_STOCK_ABI_CFG_CHECK {Backend.ABIReadCfg.check f.sig result.code}"
    IO.println s!"ACTUAL_STOCK_NODES {reprStr result.order.nodes}"
    IO.println s!"ACTUAL_STOCK_INSTRUCTIONS {reprStr (result.code.blocks.map (fun b => b.insts.toList))}"
    for step in result.schedule do
      IO.println s!"ACTUAL_RECORD block={step.block} inst={step.inst} decision={reprStr step.decision} rules={reprStr step.rules} emitted={reprStr step.emitted}"
