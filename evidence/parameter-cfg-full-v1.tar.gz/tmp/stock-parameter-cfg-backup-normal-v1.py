from pathlib import Path
import json,os,subprocess,tarfile,hashlib,datetime
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');os.chdir(root)
def git(*args,env=None):return subprocess.check_output(['git',*args],env=env,text=True).strip()
branch='agent/stock-cfg-body-progress-20261025T025359Z';parent=git('rev-parse','refs/heads/'+branch);prefix='/tmp/stock-parameter-cfg-'
files=set()
for label in ['normal']:
 for p in Path('/tmp').glob('stock-parameter-cfg-'+label+'*'):
  if p.is_file() and p.suffix in {'.json','.log','.py','.lean','.md'}:files.add(p)
  elif p.is_dir():files.update(f for f in p.rglob('*') if f.is_file() and f.suffix in {'.json','.log','.lean','.md'})
for p in Path('/tmp').glob('stock-parameter*.py'):files.add(p)
for p in [Path(prefix+'source-priorities-v1.json'),Path(prefix+'cleanup-v1.json'),Path(prefix+'mcp-cleanup-v1.json'),Path(prefix+'validation-planning-v1.json'),Path(prefix+'mcp-v1.json'),Path(prefix+'owned-v1.lean'),Path('/tmp/stock-general-cfg-status.md')]:files.add(p)
files.update(Path('/tmp/stock-parameter-cfg-owned-v1').glob('*.lean'));files=sorted(files);sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
m=Path(prefix+'normal-backup-manifest-v1.json');a=Path(prefix+'normal-backup-v1.tar.gz')
manifest=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),head=git('rev-parse','HEAD'),state='Frozen9f27ad6c normal4196keys/5014tooljobs/97audits/six partitioned owner gates pass. Historical single-bundle duplicate-main audit failure and bad historical-evidence schema retained. Current and full runtime integration lanes active, not yet full author gates/merge/goal complete. Same-source lexical memory/call priority inventory and cleanup receipts preserved.',files={str(p):sha(p) for p in files});m.write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(a,'w:gz',compresslevel=1) as tar:
 for p in files+[m]:tar.add(p,arcname=str(p).lstrip('/'),recursive=False)
idx=Path(prefix+'normal-backup-v1.index');idx.unlink(missing_ok=True);e=os.environ.copy();e['GIT_INDEX_FILE']=str(idx);git('read-tree',parent,env=e)
for p,k in [(m,'evidence/parameter-cfg-normal-manifest-v1.json'),(a,'evidence/parameter-cfg-normal-v1.tar.gz')]:
 blob=git('hash-object','-w',str(p));git('update-index','--add','--cacheinfo',f'100644,{blob},{k}',env=e)
tree=git('write-tree',env=e);commit=git('commit-tree',tree,'-p',parent,'-m','Back up complete frozen parameter-CFG build, trust and partitioned ownership evidence');git('update-ref','refs/heads/'+branch,commit,parent);subprocess.run(['git','push','origin',branch],check=True);assert git('ls-remote','origin','refs/heads/'+branch).split()[0]==commit
blob=subprocess.check_output(['git','show',commit+':evidence/parameter-cfg-normal-v1.tar.gz']);assert hashlib.sha256(blob).hexdigest()==sha(a)
with tarfile.open(a) as tar:
 for p in files:assert hashlib.sha256(tar.extractfile(str(p).lstrip('/')).read()).hexdigest()==manifest['files'][str(p)]
receipt=dict(head=manifest['head'],evidence_commit=commit,archive_sha256=sha(a),bytes=a.stat().st_size,verified_files=len(files),remote_bytes_verified=True);Path(prefix+'normal-backup-receipt-v1.json').write_text(json.dumps(receipt,indent=2)+'\n');idx.unlink();print(json.dumps(receipt))
