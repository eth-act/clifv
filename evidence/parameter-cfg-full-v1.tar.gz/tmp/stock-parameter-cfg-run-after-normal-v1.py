from pathlib import Path
import json,subprocess,time
p=Path('/tmp/stock-parameter-cfg-normal-gates-v1/receipt.json')
while not p.exists():time.sleep(5)
r=json.load(p.open());assert r['state']=='passed',r['state']
raise SystemExit(subprocess.run(['python3','/tmp/stock-parameter-cfg-validation-queue-v1.py'],stdout=open('/tmp/stock-parameter-cfg-validation-queue-v1.log','w'),stderr=subprocess.STDOUT).returncode)
