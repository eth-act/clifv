from pathlib import Path
import collections,datetime,hashlib,json,re
p=Path('/tmp/stock-conditional-forward-cfg-paired-actual-v1/provenance.json');m=json.load(p.open());rows=[];counts=collections.Counter();ops=collections.Counter()
for path,expected in m['original_sources'].items():
 data=Path(path).read_bytes();assert hashlib.sha256(data).hexdigest()==expected
 instructions=[]
 for line in data.decode().splitlines():
  match=re.match(r'^    (?:v\d+(?:,\s*v\d+)*\s*=\s*)?([a-z][a-z0-9_]*)(?:\.|\s|$)',line)
  if match:instructions.append(match[1])
 effects=sorted({x for x in instructions if x in {'load','store','stack_load','stack_store','call','call_indirect','try_call','try_call_indirect','return_call','return_call_indirect','atomic_load','atomic_store','atomic_rmw','atomic_cas','fence','trap','trapz','trapnz','debugtrap','get_pinned_reg','set_pinned_reg'}})
 branch='brif' in instructions;calls=any('call' in x for x in effects);memory=any(x in {'load','store','stack_load','stack_store'} or x.startswith('atomic') for x in effects)
 counts['functions']+=1;counts['with_brif']+=branch;counts['with_memory']+=memory;counts['with_calls']+=calls;counts['with_brif_and_effects']+=branch and bool(effects);counts['memory_without_calls']+=memory and not calls;counts['with_brif_without_effects']+=branch and not effects
 ops.update(effects);rows.append(dict(path=path,sha256=expected,brif=branch,effects=effects,instruction_count=len(instructions)))
small=sorted((r for r in rows if any(x in ['load','store','stack_load','stack_store'] for x in r['effects']) and not any('call' in x for x in r['effects'])),key=lambda r:r['instruction_count'])[:30]
result=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_provenance_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),state='same-source lexical priority inventory only; not a parser, supported-class verdict, agreement metric or proof-coverage percentage',counts=dict(counts),effect_function_counts=dict(ops),small_memory_without_calls=small)
Path('/tmp/stock-parameter-cfg-source-priorities-v1.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(counts=counts,effect_function_counts=ops,smallest_memory_without_calls=[dict(path=r['path'],instructions=r['instruction_count'],effects=r['effects']) for r in small[:3]])))
