# Conditional source composition checkpoint

Current packet: returning original source execution now composes the actual
retained scalar body and wide parameter branch into one core run, with original
fuel, source steps/definedness, selected source continuation, terminal position
and guarded post-frame. A complete actual csem/result.final.alias witness covers
every64-bit input. All1122normal module keys/74Std3audit roots pass. Production
remains #634; later-trap/chosen-edge/CFG/ABI/consumer activation and full author
gates remain pending.

Main #634 (`d6218f29`) activates arbitrary-length forward scalar jump/return
CFGs. Full original #140 remains open. This next implementation reuses the same
source view and existing condition/per-edge proofs; no production activation or
whole-branch source simulation is claimed at this checkpoint.

`StockConditionalCalls` derives the actual ordinary-brif 650/722/242 call chain,
all intermediate states/traces/fuel, exact labels and original condition
provenance from the actual prepared terminator slot. Complete original-scope,
dominated driver witnesses inhabit selection and source provenance.

`StockConditionalValues` reuses proved boolean companion executions to execute
the actual flag or zero/nonzero branch, removing the ghost cset and, for direct
zero branches, its ghost comparison. Arbitrary-word/flag witnesses cover both
operand sizes, both test polarities and both branch outcomes. Actual execution
preserves the required source-register frame and memory/program world relation.
The descriptor bridge derives the decoded form and unchanged compiler base.

The existing certified branch helper closure now also exposes its actual242
emitter projection; it is reused rather than copied. `StockConditionalEmission`
derives the entire appended zero/nonzero/flag branch fragment from actual
builder and emitter runs, including its flag producer and arbitrary existing
prefix. A complete source driver inhabits this result. The new shared
`StockSequence` lemma factors sequence inversion for the two semantic cases.

Validation: all 675 targeted module keys pass. All 15 new audit roots in
`scripts/audit/stock-conditional-source.lean` use only standard axioms. No new
native fact, accepted-program proof certificate, scope restriction, changed
allocator or CLIF semantic definition is introduced. Full author gates remain
required before a substantive production PR; they are not claimed by these
focused checks.

Continue final-resolver transport and original650 condition/source execution,
including comparison look-through without requiring materialized comparison
results. Connect actual emitted branch code, source body/first-trap execution,
chosen successor demand/arguments, ranked CFG return/trap induction, ABI entry
and all production consumers. Cover bit-test/table/critical routes and loops,
then memory/addressing/atomics/calls/exceptions, uncovered families and full
original-domain whole-driver/Stock-only/downstream completeness. Existing
per-edge prepare/spill/copy proofs are already available and must be reused.

The paired corpus planning diagnostic finds 1,695 brif instances but only four
with current scalar bodies, original checks and source-forward control. Thus
conditional scalar composition is required, while memory/calls remain important
coverage obligations. This diagnostic proves no activation or byte-match gain.

Source branch: `agent/stock-conditional-cfg-20261026`, based on merged #634;
worktree `.worktrees/stock-cfg-source-20261025`. The exact parent executable is
preserved at `/tmp/stock-conditional-cfg-baseline/lean-backend` (SHA256
`6046930eab7151504eff5087f77d57299634d01e35d8df09f3a60cef7a359c5a`).
Remote #634 terminal evidence is `95a286c0`, with postmerge/baseline evidence
`8faa461b` and manifests `f784ec04` on the existing evidence branch. All dirty
saved views are preserved. One warm cache, bounded builds, no new agents or
worktrees. Completed #634 cleanup reclaimed 669,644,996 bytes after remote
archive and individual content-hash verification; about 577 GiB remains free.

The next source/alias checkpoint also proves original650 source truth for every
supported scalar condition, including comparison look-through and zero extension,
by constructing the715 proof companion internally. Existing8/16/32/64 source
proofs are reused; no source comparison result must be materialized. Actual
conditional-source witnesses cover arbitrary64-bit inputs. Final-resolver branch
replacement is proved for both flag and direct-zero forms, with nonidentity
alias0→1 witnesses, including a companion destination equal to the real operand.
All23new audit roots are standard-only; two MCP packet reviews (generic original
source theorem and complete source witness) report Std3 and no warnings.

The producer-bound checkpoint closes the internal prefix/frame obligation:
actual original651/652/650 executions derive a Frag covering exactly their real
fresh definitions. All nonzero widths, mirrored zero tests/inversion, narrow
comparison extensions, wide register/immediate/predecessor comparisons and DFG
comparison look-through reuse existing observed-state/value proofs. Old source
and theorem variants remain; no new accepted-input inequality is added.

`StockResolvedDefs` makes the existing private renaming argument reusable and
proves the resolved fresh interval and its complete frame. A real extension
witness reads nonidentity alias0→2, writes fresh1 and preserves2, exactly the
otherwise problematic companion endpoint. `StockSequenceFrame` adds stopped-run
framing and its nonempty-prefix/jump witness. All686targeted keys and40audit
roots pass; all roots use only standard axioms. Production remains #634.

The first placement appended the producer lemmas to three existing shape
modules and triggered unchanged fixtures to rebuild. Those three files have
been restored byte-for-byte. The added prefix results now live in separate
modules, reusing their existing private inversion/observation arguments. The
relocated build restored677of683keys and built only the new modules, without
repeating the unchanged expensive fixtures. The unpublished pre-relocation
source is preserved under /tmp/stock-conditional-cfg-prefix-relocation-before.
This is a dependency-boundary improvement, not a dropped validation gate.

Next compose the established original source truth and complete actual emitted
branch fragment into one source-branch execution result. Use the actual real
fresh interval and stopped-run frame to preserve all available values, including
the removed companion's number; do not assume it differs from source aliases.
Then derive the retained core/guarded source-body/first-trap and chosen-edge
contracts, source-ranked CFG/ABI simulation and every production consumer, with
complete witnesses and full author gates before a substantive activation PR.
Continue bit-test/table/critical routes, loops, memory/addressing/atomics,
calls/exceptions, uncovered families and original-domain whole-driver/Stock-only/
downstream completeness. The original #140 remains open.

The composed branch checkpoint now proves `original_source_branch_values`:
actual650/722/242 calls derive the full real emitted fragment, correct original
true/false successor, world relation and every register outside the real fresh
interval. No assumption excludes an available value at the removed ghost cset
number. The proof derives the actual prefix and uses stopped-sequence framing.
`named_source_branch_witness` inhabits the complete theorem from an actual named
branch of the original-scope/dominated three-block driver, for every64-bit word.
All684targeted keys and43audit roots pass, standard axioms only; two bundled MCP
reviews report Std3/no warnings. These are focused proof checks; full production
per-PR gates and consumer activation remain pending. Next extract actual retained
conditional core/emission origins and compose source body/first-trap execution
and chosen-successor demand/arguments before ranked CFG/ABI/consumer activation.

The retained-core checkpoint proves `conditional_core_origin`: successful real
conditional lowering supplies the exact named call, first-match selection,
retained branch state/buffer, branch-scan flag and body/terminator concatenation.
The witness comes from the complete original three-block driver at its real
entry and actual retained scan. `Calls.source_values` now derives intermediate
condition demand from the branch output demand using existing interpreter
monotonicity. The complete named source-branch witness uses this interface and
retains its old theorem statement. All692targeted module keys and46audit roots
pass, Std3 only. This closes compiler origin and intermediate-demand bookkeeping;
source body/chosen-edge/CFG/ABI/consumer composition remains. No new production
PR or full-gate claim is made at this checkpoint.

The scratch-free checkpoint adds nonzero651 and original parameter650 branch
variants with no scratch-separation callback, plus selected-call output-demand
composition. Common branch fragment/execution algebra is factored once; all old
public theorem headers stay exact. The complete named source witness exercises
nonidentity alias192→the actual allocation frontier for every64-bit word. This
is a generic final-resolver transport instance, not a claim that the particular
whole-driver result has that alias table. All692targeted keys/50audit roots pass,
Std3 only; two bundled MCP checks report Std3/no warnings. Original comparison
look-through still uses its earlier scratch callback; derive it from real
allocation/availability or add the needed weaker path-sensitive variant before
connecting arbitrary retained source comparisons. It must not become a new
accepted-input predicate. Remaining work is actual body/first-trap/chosen-edge,
CFG/ABI and production consumer composition, then remaining full140 obligations.

The retained-body checkpoint reuses `MaskBody.actual_body_refines_at_block` and
original `LocalBody` source continuations in `ConditionalBodySpec`. It derives
actual scan/body/branch placement, full source fuel, normal body execution and
first-body-trap versus later-continuation behavior. Its executable complete
three-block source witness derives the guarded machine input from `enterFunc`;
no supplied machine body run or empty-caller restriction is added to the theorem.

`conditional_core_calls` factors the real branch/outgoing/scan decomposition once,
retaining the old `conditional_core_origin` header exactly. Actual per-successor
argument collection derives branch-output→scan-input demand monotonicity; the
complete executed source fixture inhabits this too. All1110targeted keys and55
packet audit roots pass, standard-only. Two bundled body/MCP checks report Std3
and no warnings. These remain focused checks; full author gates precede activation.

Next derive original conditional operand availability/getters and selected root,
source values outside the actual branch allocation interval, the guarded branch
post-frame, source-chosen direct/synthetic edges, ranked conditional CFG/ABI and
all production consumers. For ordinary parameters/nonzero there is no scratch
callback. General comparison look-through's remaining internal scratch callback
must be discharged or weakened on paths that allocate no real scratch. Existing
per-edge, prepare, spill and copy proofs are reused; other bit-test/table/critical
cases, loops/effects/calls/full-domain completeness remain in full140.

Current main remains d6218f29 after fresh fetch. Four saved views and one warm
cache are retained. Completed idle MCP workers were released;143obsolete unlinked
cache artifacts reclaimed43,709,588bytes after inode/link/age rechecks, leaving
about572GiB free. No dirty source, unique evidence or recovery backup was deleted.

The wide-parameter packet derives every priority rejection and ordinary3231
selection from the real parameter branch slot and absence of a definition.
`ParameterBranch.named_calls` supplies the whole actual helper packet/source
provenance without a selected-rule input. The complete named source witness now
uses this derivation, not an externally supplied selection case.

`StockConditionalNoDefs` derives the full real wide branch fragment, proves it
defines no virtual registers, and composes it with original source truth under
final aliases. Its arbitrary64-bit complete witness resolves the operand to the
allocation frontier and proves every register is preserved by the actual stop.
All1112targeted keys/61audit roots pass, standard-only; named-call and full-frame
MCP reviews report Std3/no warnings. Old public variants remain. This is source
proof integration; the new conditional class is not activated in production.

Advance wide parameter branches first through the retained guarded block/body,
source-chosen edges, ranked CFG/ABI and existing compatible consumers; their
write-free code avoids making general branch-scratch analysis a wholesale
prerequisite. Derive actual outgoing base/extent and original source context
facts where needed. Then widen to other conditions, modern per-edge consumers,
bit-test/table/critical paths, loops/effects/calls and full original140. No old
accepted identity/stage or input condition is removed by the staged route.

The guarded retained-branch packet is now complete for wide parameter choices.
`StockOutgoingFrame` reuses the actual argument-loop field proof to preserve
both compiler base and demand extent, including per-successor/synthetic and
exception argument paths. The complete executable conditional fixture inhabits
this through its real nonempty outgoing collector and scan boundary.

`StockConditionalWideAllocation` derives unchanged fresh frontier/demand size
from actual650/651/722/242 execution. The new `ConditionalBodySpec.parameter_branch_values`
then derives original context/slot, selection, source typing, final alias bounds,
demand extent and held restricted values from the actual core and retained
terminator record. It executes the real branch buffer under result.final.alias,
chooses the original truth index, retains exact successor order and derives the
complete guarded post-frame via no real vreg writes and stable memory relation.
No rule/code/alias/demand/execution callback is added to accepted programs.

The complete original-scope/dominated source enters and returns for every64-bit
input on either source branch. Its actual csem branch executes from the real
entry seed using the real final alias table and preserves the guarded source
frame; this is no longer only a generic resolver instance. All1117targeted keys
and67audit roots pass, Std3 only; two bundled retained-branch/complete-witness MCP
reviews report Std3/no warnings. Full author gates and production activation are
not claimed. Next derive source conditional continuation/getters/availability,
compose body/first traps with actual source-selected direct/synthetic edge
transfer, ranked CFG/ABI and compatible consumers. Broader conditions/per-edge
consumers, bit-test/table/critical paths, loops/effects/calls and full140 remain.

The returning-core checkpoint derives original terminator-operand availability
from the existing dominance condition and actual Stock build. The complete
all-input witness uses this general result. The actual slot/context/parameter
selection is factored into `ConditionalBodySpec.parameter_calls` and reused;
old guarded/allocation interfaces remain exact. One shared actual emission proof
supplies both no-allocation and exact appended-instruction count.

`ConditionalBodySpec.returning_parameter_core` derives source body execution,
exact remaining fuel, all source definedness, the actual condition getter/width,
source-selected successor binding and continuation, real core machine execution,
correct truth index, real terminal position and full guarded frame. It reuses
existing MaskBody/LocalBody proofs and source-definedness transfer. The boolean
normalization mismatch found during composition was corrected by a kernel proof
of the two source-value cases; failed debug runs remain historical evidence.

For every64-bit input, a complete original source enters/returns, and its entire
actual retained core executes under csem with the real final aliases and entry
seed. The witness ties the source steps/getter to the original input and real
last machine instruction. All1122targeted keys/74audit roots pass, Std3 only;
two packet MCP reviews report Std3/no warnings. Four previous public headers
were checked exact. No production activation or full author gates are claimed.
Next complete the later-trap continuation, source-chosen direct/synthetic copies
and successor demand/definedness, ranked CFG/ABI and compatible production
consumers. Broader conditions/per-edge consumers and remaining original140 stay
open; first scalar/branch class is not full-domain completeness.

The trapping-core checkpoint adds the original trapped-run counterpart: either
the actual body has its first trap, or the complete actual core takes the
source-selected branch with the exact remaining source fuel, a still-trapping
source continuation, last-instruction position and guarded post-frame. Its
complete original source witness enters, selects a reachable trapping successor,
and runs the real csem core with the actual final aliases and entry seed. The
expensive executable compiler fixture is a stable leaf; the witness uses the
existing manual source-dominance argument rather than an unreducible fixedpoint
decision. All1125targeted keys and77audit roots pass, standard axioms only; two
packet MCP reviews report Std3/no warnings. Initial failed witness builds remain
historical evidence. No conditional production activation or full author gates
are claimed. Next: actual selected-successor values/demand/definedness, ranked
CFG and ABI composition, then compatible production consumers and the remaining
original140 obligations.

The selected-successor checkpoint transfers only successor-demanded inherited
values, using original source availability and the actual retained guard. Real
selected copies, including synthetic critical routes, establish source-definedness,
DFG consistency and the next retained scan guard. The forward variant derives
the demand inequality from the actual compiler traversal. Outgoing argument
values remain an internal composition obligation; the accepted input predicate
is unchanged. The next compatible class may use empty outgoing vectors while
the existing full-domain per-successor obligation stays open.

`SelectedCopyRoute.execute` executes both actual routes under VStepAt: direct
copies, or first copies plus the real emitted synthetic jump and second copies.
Actual computed CFG correspondence and terminal positions are derived or tied
to the real placed block. A complete entered/returning original conditional
source with a nonempty vector witnesses actual csem branch execution, its real
position in assembled VCode, selected copies and guarded successor entry.
All1131targeted keys and82audit roots pass, Std3 only; two bundled MCP reviews
report Std3/no warnings. Five completed idle MCP workers were released; one warm
cache and all saved source/evidence remain, with563GiB free. Main was fetched and
remains d6218f29. No conditional production activation/full author gates claimed.
Next compose whole-body return/trap and successor continuations through ABI,
activate the smallest compatible conditional class across existing consumers,
then broaden ranked CFG/conditions/per-edge coverage and every remaining140
obligation. Avoid a separate PR for each proof fragment.

Whole-body conditional return composition now reaches an ABI-correct successor
continuation through actual copies and synthetic jumps. Empty outgoing vectors
identify the first legacy-compatible class, leaving general per-edge argument
composition open. The successor contract is an induction hypothesis over actual
retained scans, rather than a new accepted-program certificate.

The existing jump entry proof is factored through shared `EntryCoreSpec` and
`original_entry_prelude`. Conditional entries reuse the same ABI/source-parameter,
alias, memory and value derivations; actual wide-parameter emission derives the
required nonempty core. Both old jump/source-definedness theorem headers and
axiom sets were checked exact against the old standalone source proof. A complete
original source with nonempty scalar successor bodies now executes from actual
instruction-zero ABI entry through the branch, selected copies and ABI return.
All1174targeted keys and90audit roots (88 packet roots plus2preserved old roots)
pass, Std3 only. Two packet MCP reviews report Std3/no warnings. The kernel-only
executable fixture builds in a stable leaf; its source dominance is manual and
standard-only. No conditional production activation/full author gates claimed.
Next: trapped-run/ABI counterpart, source-class/domain check, shared production
consumers and full per-PR gates; then broaden CFG/per-edge/condition coverage and
all remaining original140 obligations.

The compatible conditional source class now derives `Scalar.Domain` universally,
including original source execution, instruction-zero ABI entry, whole scalar
bodies, source-selected direct/synthetic copies, ABI return and first traps.
The legacy edge-copy agreement is proved from actual original/synthetic metadata;
no consumer certificate or stronger accepted-program premise is introduced.
Original entry parameter membership/SSA derives real built-context parameter
status and32/64-bit width. Actual nonentry return cores supply both continuation
contracts through shared adapters, removing duplicate witness derivations.

`Stock.ConditionalCfg.eligible` is the first compatible source selector: a wide
entry-parameter branch, empty outgoing vectors/nonentry parameters and scalar
return leaves. Its source facts, universal domain and source/artifact checker
soundness build. It is not wired into default production yet. Complete original
returning and reachable-divide-by-zero sources inhabit the selector, actual
compiler, original source checks, checker and universal contract. Their separate
csem witnesses execute actual instruction-zero entry, branch/copies and return or
trap. This first class does not close general branching/condition/per-edge scope.

All1190targeted keys pass. The108-root audit has106standard-only roots, including
all universal correctness/compatibility/checker roots. Exactly two fixed-example
roots depend additionally on the two explicitly inventoried native input-check
axioms, as permitted by TO-PROVE§7 for fixed proofs. Kernel/cbv evaluation of
those original executable input checks exceeded reduction limits; their native
checks contain no emitted-code or universal semantic claim. Actual compilation
fixtures remain kernel-proved; manual source dominance remains standard-only.
All90previous trust sets and both prior public return-witness headers are exact.
Three bundled MCP reviews (trap composition, universal domain, complete ABI trap
witness) report Std3/no warnings. Four completed idle workers released; all saved
source/evidence and one warm cache preserved, with562GiB free.

Next immediately wire the class into the shared default compiler, semantic
checker, verified linker and generated-proof reconstruction. Append route9,
retain routes0–8 and complete prior pipeline fallback, and complete all current
per-PR author gates/paired byte evidence before a substantive squash PR. Then
continue ranked/other conditional classes, nonempty per-edge consumers, other
condition/table/bit-test families, loops/effects/calls and every remaining140
simulation/completeness obligation. No full author gates or conditional production
activation is claimed by this proof checkpoint.
