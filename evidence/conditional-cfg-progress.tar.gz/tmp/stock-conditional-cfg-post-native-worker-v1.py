from pathlib import Path
import os,json,subprocess,time,datetime,hashlib
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');os.chdir(root)
e=os.environ.copy();e.update(json.load(open('/tmp/stock-mixed-div-env.json')));e.update(FV_ROOT=str(root),FV_MEMCAP='8G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',CARGO_BUILD_JOBS='2')
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:2]);os.nice(10)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();out=Path('/tmp/stock-conditional-cfg-post-native-v1');out.mkdir(exist_ok=False);records={}
p=Path('/tmp/stock-conditional-cfg-native-v1/receipt.json')
while True:
 d=json.load(p.open()) if p.exists() else {}
 if d.get('state')!='running' and d.get('state'):
  assert d['state']=='passed' and d['head']==head,d;break
 time.sleep(10)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run(label,args,cwd=root):
 assert head==subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
 log=out/(label+'.log');print(datetime.datetime.now(datetime.timezone.utc).isoformat(),label,flush=True)
 with log.open('w') as f:r=subprocess.run(['scripts/memcap.sh',*args],cwd=cwd,env=e,stdout=f,stderr=subprocess.STDOUT)
 records[label]={'returncode':r.returncode,'log':str(log),'sha256':sha(log)}
 (out/'receipt.json').write_text(json.dumps({'head':head,'state':'running' if not r.returncode else 'failed','records':records},indent=2)+'\n')
 if r.returncode:raise SystemExit(r.returncode)
run('real-crate-parity',['python3','/tmp/stock-cfg-production-real-crate-parity.py','--json',str(out/'real-crate-report.json'),'--diffs',str(out/'real-crate-diffs'),*[str(root/'examples'/name/'target/fv/plain-leanlink-verified-leanld/tmp') for name in ['fv-demo','survey']]])
run('crate-proofs',['python3','/tmp/stock-cfg-production-crate-validation.py','--out',str(out/'crate-proofs')])
run('paired-main',['python3','/tmp/stock-conditional-cfg-paired-main-v1.py'])
(out/'receipt.json').write_text(json.dumps({'head':head,'state':'passed','records':records},indent=2)+'\n');print('POST_NATIVE_CRATE_AND_PAIRED_GATES_PASS',flush=True)
