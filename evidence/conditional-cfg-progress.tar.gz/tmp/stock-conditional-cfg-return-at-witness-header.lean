theorem returning_empty_parameter_at_witness (X : ExtSem) :
    ∃ result, ∃ (spec : ConditionalBodySpec function result function.blocks[0]! 0 0 7
      ⟨1,[]⟩ ⟨2,[]⟩ (csem (fun _ => False) ⟨0,0⟩ X)
      (fun _ _ _ => True) Clif.Env.empty {funcs := []}),
      Stock.lower function = .ok result ∧ LowerScope function ∧ Dominated function ∧
      Clif.enterFunc function [⟨.i64,1⟩] Clif.Mem.empty = .ok (EmptyFixture.initial,Clif.Mem.empty) ∧
      Clif.runLoop Clif.Env.empty {funcs := []} 3 ⟨EmptyFixture.initial,[],Clif.Mem.empty⟩ =
        .returned [⟨.i64,1⟩] Clif.Mem.empty ∧
      RunOkABIAt function result.code result.edgeArgs (csem (fun _ => False) ⟨0,0⟩ X)
        (fun _ _ _ => True) EmptyFixture.initial.slots
        ⟨0,spec.preludeCode.size,entrySeed spec.core.scan.ctx EmptyFixture.initial,Arm.ArmState.default⟩
        (.returned [⟨.i64,1⟩] Clif.Mem.empty)