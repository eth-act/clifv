from pathlib import Path
import os,json,subprocess
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');os.chdir(root);e=os.environ.copy();e.update(json.load(open('/tmp/stock-mixed-div-env.json')));e.update(FV_ROOT=str(root),FV_MEMCAP='8G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2');os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:2]);os.nice(10)
e.update(json.load(open('/tmp/stock-mixed-div-env.json')));e.update(FV_ROOT=str(root),FV_MEMCAP='8G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2');e['PATH']=str(root/'rust/target/release')+':'+e['PATH']
with open('/tmp/stock-conditional-cfg-native-byte-preflight.log','w') as f:r=subprocess.run(['scripts/memcap.sh','python3','scripts/check-stock-mixed-native.py','/tmp/stock-conditional-cfg-integration-v3/native-objects','--class','cfgconditional'],env=e,stdout=f,stderr=subprocess.STDOUT)
print('native byte preflight',r.returncode)
