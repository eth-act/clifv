from pathlib import Path
import os,json,hashlib,subprocess,time,sys
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');out=Path('/tmp/stock-conditional-cfg-paired-main-v2')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
while not (out/'summary.json').exists():
 workers=subprocess.run(['pgrep','-f','^python3 /tmp/stock-conditional-cfg-paired-early-v2.py$'],capture_output=True,text=True)
 assert workers.returncode==0,'early paired worker absent without terminal receipt'
 time.sleep(10)
s=json.load(open(out/'summary.json'));p=json.load(open(out/'provenance.json'));head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert s['state']==p['state']=='passed' and s['head']==p['head']==head and not s['lost']
assert s['baseline']=='d6218f299c97d82d560e74ec0a75813a05f5b558'
assert sha(root/'.lake/build/bin/lean-backend')==p['candidate_backend_sha256']
assert sha('/tmp/stock-conditional-cfg-baseline/lean-backend')==p['baseline_backend_sha256']
assert all(sha(path)==value for path,value in p['captured_inputs'].items())
assert all(sha(path)==value for path,value in p['original_sources'].items()),'actual example normalized inputs changed; repeat paired comparison on new inputs'
assert sha(root/'rust/crates/cargo-fv/src/pipeline.rs')==p['source_pipeline_sha256']
assert sha(out/'rows.json')==p['rows_sha256'] and sha(out/'summary.json')==p['summary_sha256']
report=Path('/tmp/stock-conditional-cfg-post-native-v2/real-crate-report.json');current={(r['cgu'],r['fn']):r for r in json.load(report.open())};rows=json.load(open(out/'rows.json'))
assert len(current)==len(rows)==4543 and set(current)=={(r['cgu'],r['fn']) for r in rows}
assert all(r['candidate_equal']==current[(r['cgu'],r['fn'])]['equal'] for r in rows),'actual cargo-fv example output differs from paired candidate'
sys.path.insert(0,str(root/'scripts'))
from byte_compare import ELF
rel=lambda elf,symbol:[(r['offset'],r['type'],r['addend']) for r in elf.function_relocations(symbol,{})]
groups={}
for row in rows:groups.setdefault((row['crate'],row['cgu']),[]).append(row)
for (crate,cgu),items in groups.items():
 directory=root/'examples'/crate/'target/fv/plain-leanlink-verified-leanld/tmp'/cgu
 actual=ELF(directory/'lean.o');expected=ELF(out/cgu/'candidate/lean.o')
 reference=ELF(directory/'cgclif.o');captured=ELF(out/cgu/'captured/cgclif.o')
 for row in items:
  a,ab=actual.function(row['fn']);b,bb=expected.function(row['fn']);r,rb=reference.function(row['fn']);c,cb=captured.function(row['fn'])
  assert hashlib.sha256(ab).hexdigest()==row['candidate_bytes'] and ab==bb and rel(actual,a)==rel(expected,b),(cgu,row['fn'],'candidate bytes/relocations changed')
  assert rb==cb and rel(reference,r)==rel(captured,c),(cgu,row['fn'],'reference bytes/relocations changed')

(out/'post-native-reuse-receipt.json').write_text(json.dumps({'head':head,'state':'passed','paired_summary_sha256':sha(out/'summary.json'),'actual_real_crate_report_sha256':sha(report),'actual_normalized_sources_exact':len(p['original_sources']),'all4543actual_example_rows_agree':True,'actual_candidate_function_bytes_and_relocations_exact':4543,'actual_cranelift_reference_function_bytes_and_relocations_exact':4543,'reuse':'exact frozen source, executable hashes, immutable snapshot and actual examples verified; no duplicate compilation'},indent=2)+'\n')
print(json.dumps({k:v if k not in ['gained','lost'] else len(v) for k,v in s.items()}))
