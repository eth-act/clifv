from pathlib import Path
import os,tarfile,hashlib,json,shutil,datetime
os.nice(19);os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
archive=Path('/tmp/stock-conditional-cfg-progress.tar.gz');receipt=json.load(open('/tmp/stock-conditional-cfg-backup.json'));assert hashlib.sha256(archive.read_bytes()).hexdigest()==receipt['sha256']
dirs=[Path('/tmp')/n for n in ['stock-conditional-cfg-paired-main-v2','stock-conditional-cfg-paired-main-v3']]
files={str(p).lstrip('/'):p for d in dirs if d.exists() for p in d.rglob('*') if p.is_file()};verified=set();total=0
digests={}
with tarfile.open(archive,'r|gz') as tf:
 for member in tf:
  if member.isfile():digest=hashlib.sha256(tf.extractfile(member).read()).digest();digests[member.name]=digest
  elif member.islnk():digest=digests[member.linkname];digests[member.name]=digest
  else:continue
  if member.name not in files:continue
  p=files[member.name];assert digest==hashlib.sha256(p.read_bytes()).digest(),p
  verified.add(member.name);total+=p.stat().st_size
assert verified==set(files)
for d in dirs:
 if d.exists():shutil.rmtree(d)
Path('/tmp/stock-conditional-cfg-superseded-snapshot-cleanup.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'removed':list(map(str,dirs)),'logical_bytes':total,'evidence_commit':receipt['evidence_commit'],'all_file_hashes_verified':True,'parent_v1_and_active_v4_retained':True},indent=2)+'\n')
print('Removed obsolete v2/v3 snapshots; archive file hashes verified; retained v1 and active v4.')
