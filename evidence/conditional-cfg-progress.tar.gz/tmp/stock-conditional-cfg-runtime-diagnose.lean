import FVTest.Backend.Lowering.StockTwoBlockProductionRuntime
open Backend
set_option autoImplicit false
def main : IO Unit := do
  let config := Stock.D0.configurations.headD .defaultI32
  let fs := FVTest.StockTwoBlockProductionRuntime.conditionalFunctions config
  let source := String.join (fs.map fun (f,_) => f.print ++ "\n")
  let pf := Clif.parseFile source
  let calls ← IO.mkRef 0
  let alloc := fun vcs => do
    let n ← calls.get
    calls.set (n+1)
    IO.println s!"allocator batch{n}: {vcs.size}"
    for vc in vcs do
      if vc.name == "stock_cfgconditional_4" then
        let some parsed := pf.funcs.find? (fun p => p.name == vc.name) | throw (IO.userError "missing source")
        let .ok f := parsed.func | throw (IO.userError "parse error")
        let .ok raw := Stock.lower f | throw (IO.userError "lower error")
        let .ok prepared := prepare raw.code | throw (IO.userError "prepare error")
        IO.println s!"critical boundary: equalsRaw={decide (vc = raw.code)} equalsPrepared={decide (vc = prepared)} rawBlocks={raw.code.blocks.size} preparedBlocks={prepared.blocks.size}"
    let results := allocateLean vcs
    for i in [:results.size] do
      if let .error e := results[i]! then IO.println s!"alloc failure {vcs[i]!.name}: {e}"
    pure results
  let attempt ← compileFileWithLowering lowerForAllocationConditionalCfgNI VCode.rulesFired alloc pf [] false
  IO.println s!"funcs={attempt.funcs.length} unsupported={repr attempt.unsupported} unverified={repr attempt.unverified} unvalidated={repr attempt.unvalidated}"
  match attempt.layout with
  | .error e => IO.println s!"layout failed: {e}"
  | .ok _ => IO.println "layout passed"
