from pathlib import Path
import subprocess,os,tarfile,json,hashlib,datetime
root=Path('/home/lee/clifv/.worktrees/stock-cfg-source-20261025');os.chdir(root);os.nice(19);os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
def git(*a,env=None):return subprocess.check_output(['git',*a],env=env,text=True).strip()
head=git('rev-parse','HEAD');assert not git('status','--porcelain');assert git('ls-remote','origin','refs/heads/agent/stock-conditional-cfg-20261026').split()[0]==head
files=[]
for p in Path('/tmp').glob('stock-conditional-cfg*'):
 if p.is_file() and p.suffix in {'.py','.json','.log','.md','.lean'}:files.append(p)
 elif p.is_dir() and p.name != 'stock-conditional-cfg-baseline':files.extend(f for f in p.rglob('*') if f.is_file())
files += [Path('/tmp/stock-general-cfg-status.md')]
archive=Path('/tmp/stock-conditional-cfg-progress.tar.gz')
with tarfile.open(archive,'w:gz',compresslevel=1) as tf:
 for p in sorted(set(files)):tf.add(p,arcname=str(p).lstrip('/'),recursive=False)
 for name in git('diff','--name-only','d6218f29','HEAD').splitlines():tf.add(root/name,arcname='repo/'+name,recursive=False)
assert archive.stat().st_size<40*1024*1024
branch='agent/stock-cfg-body-progress-20261025T025359Z';parent=git('rev-parse',branch);index=Path('/tmp/stock-conditional-cfg-backup.index');index.unlink(missing_ok=True);e=os.environ.copy();e['GIT_INDEX_FILE']=str(index);git('read-tree',parent,env=e);blob=git('hash-object','-w',str(archive));git('update-index','--add','--cacheinfo',f'100644,{blob},evidence/conditional-cfg-progress.tar.gz',env=e);tree=git('write-tree',env=e);commit=git('commit-tree',tree,'-p',parent,'-m','Back up conditional source truth, resolved branch witnesses and focused audit evidence');git('update-ref','refs/heads/'+branch,commit,parent);subprocess.run(['git','push','origin',branch],check=True);assert git('ls-remote','origin','refs/heads/'+branch).split()[0]==commit
r={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'source_branch':'agent/stock-conditional-cfg-20261026','evidence_commit':commit,'evidence_branch':branch,'archive_git_path':'evidence/conditional-cfg-progress.tar.gz','sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'prior_evidence_tree_preserved':True,'state':'focused retained conditional core/source execution checkpoint;74Std3audits pass; production activation and full author gates remain','full_140_complete':False};Path('/tmp/stock-conditional-cfg-backup.json').write_text(json.dumps(r,indent=2)+'\n');index.unlink(missing_ok=True);print(json.dumps(r))
