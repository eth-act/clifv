import FV.Backend.Lowering.StockConditionalCfgNI
import FV.E2E.SemanticChecksWith
import FV.E2E.SemanticStackBound
import Crates.StockCfgConditionalProduction100PlainFallbackGlobal.Input

/-! Slice 3 of `Crates.StockCfgConditionalProduction100PlainFallbackGlobal`'s checks (generated; see there). -/

namespace Crates.StockCfgConditionalProduction100PlainFallbackGlobal

open E2E E2E.LinkCheck E2E.BinCheck

/-- The checks of the functions of slice 3 (`staticChks`, the validators, and `linkChks`). -/
theorem slice3_ok : SemanticChecksWith.fnsBProduction actualLower input false slice3 = true := by native_decide

/-- The executable's bytes of the code of slice 3 (and of the GOT slots it loads). -/
def ex3 : Elf.Excerpt := []

/-- The binary check of the functions of slice 3 (`ArtOk`: their code in the executable). -/
theorem slice3_bin : SemanticChecksWith.codeBProduction actualLower input false (exHdr ++ ex3) slice3 = true := by native_decide

end Crates.StockCfgConditionalProduction100PlainFallbackGlobal
