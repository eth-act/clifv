from pathlib import Path
p=Path('FV/Backend/Proof/StockConditionalBranchValues.lean');s=p.read_text();start=s.index('  obtain ⟨suffix,compiled,suffixFragment⟩',s.index('theorem original_source_branch_values'));end=s.index('\nend Backend.Stock.Proof.ConditionalValues',start);body=s[start:end].rstrip();body=body.replace('(test != 0)','truth')
helper='''private theorem compose_branch_values {ctx : Ctx}
    {constructFuel emitFuel : Nat} (enoughConstruct : 100 ≤ constructFuel) (enoughEmit : 30 ≤ emitFuel)
    {before middle constructed next : State} {conditionTrace constructTrace final : Array RuleId}
    {raw descriptor out : V} {yes no : Label}
    (constructRun : ApplyInternal program (Stock.sem ctx) {} constructFuel 46 722
      [raw,.label yes,.label no] (middle,conditionTrace) descriptor (constructed,constructTrace))
    (emitRun : ApplyInternal program (Stock.sem ctx) {} emitFuel 13 242
      [descriptor] (constructed,constructTrace) out (next,final))
    {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem} (refines : Refines F isem)
    {aliases : Array (Option Nat)} {ρ : Nat → CV} (bounded : aliases.size ≤ before.base.nextVreg)
    {leading : List MInst} (prefixFragment : Frag before.base middle.base leading)
    (shape : CondShape raw (fun _ => True)) {producer : MInst} {condition : Cond}
    (flags : CondFlag cmpImm0 raw producer condition) {truth : Bool}
    (execution : BooleanExecution F isem aliases truth before
      {middle with base := (((middle.base.fresh .int).2.emit producer).emit
        (.cset (middle.base.fresh .int).1 condition))}
      (.reg (middle.base.fresh .int).1) ρ) :
    ∃ code,Frag before.base next.base code ∧
      ∀ world,BranchExecution F isem yes no (code.map
        (·.mapRegs (Backend.lowerFunction.resolve aliases (aliases.size+1))))
        truth before.base next.base ρ world := by
'''+body+'\n\n'
s=s[:start]+'''  exact compose_branch_values enoughConstruct enoughEmit constructRun emitRun refines bounded
    prefixFragment shape flags execution
'''+s[end:]
insert=s.index('/-- Original condition execution')
s=s[:insert]+helper+s[insert:]
# Derive the nonzero-source interface from the preserved original signature.
a=s.index('theorem original_source_branch_values');b=s.index(' := by',a)
header=s[a:b];header=header.replace('theorem original_source_branch_values','theorem nonzero_source_branch_values').replace('    (typedReads : ∀ {value : Nat} {ty : Clif.Ty} {bits : BitVec ty.width},\n      fr.getAs value ty = .ok bits → ctx.valueType? value = some (.int ty.width))','    (typed : ctx.valueType? c = some (.int cty.width))').replace('(enoughCondition : 400 ≤ conditionFuel)','(enoughCondition : 300 ≤ conditionFuel)').replace('conditionFuel 123 650','conditionFuel 123 651')
a2=header.index('\n    (separatedReads');b2=header.index(' :\n    ∃ code',a2);header=header[:a2]+header[b2:]
new='''
/-- Scalar nonzero branch execution needs no source/scratch inequality. It
covers all supported widths and aliases, including a source operand at the
next allocation number on paths that allocate no real scratch. -/
'''+header+''' := by
  have width : cty.width = 8 ∨ cty.width = 16 ∨ cty.width = 32 ∨ cty.width = 64 := by
    have valid := inv.valTyE c (.int cty.width) typed
    cases cty <;> simp [eCTys,Clif.Ty.width] at valid ⊢
  obtain ⟨leading,prefixFragment⟩ := ScalarSelect.stock_select_nonzero_prefix inv width
    (by omega) typed conditionRun
  have shape := ScalarSelect.stock_select_nonzero_actual_condition_shape inv width
    (by omega) typed conditionRun
  obtain ⟨producer,condition,booleanTrace,flags,noDefs,notAl,notNv,companion⟩ :=
    ScalarSelect.stock_select_condition_boolean_companion ctx shape middle conditionTrace
  have execution := nonzero_boolean_values inv width dfg getC typed (by omega) (by decide)
    conditionRun companion refines bounded extent held
  exact compose_branch_values enoughConstruct enoughEmit constructRun emitRun refines bounded
    prefixFragment shape flags execution
'''
s=s.replace('\nend Backend.Stock.Proof.ConditionalValues','\n'+new+'\nend Backend.Stock.Proof.ConditionalValues');p.write_text(s)
