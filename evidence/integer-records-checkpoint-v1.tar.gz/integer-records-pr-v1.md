Extend actual Stock load records to8-,16-,32- and64-bit unsigned loads. Original source metadata now determines selected rules, typed execution receipts, exact emitted code, fresh-result binding and final aliases. The guarded source-step theorem derives demanded/source-available operands internally. It needs no caller-supplied root ID or code certificate.

The paired record theorem executes the resolved code on two source-related worlds with one exact virtual result. Concrete witnesses lower a real source function for every width, load nonzero initialized bytes, and run guarded semantics on distinct machine worlds. Read permissions come from the original heap. Existing i32 variants and production routes remain unchanged.

Validation on current mainc09461f4:
-431/431 modules passed, including all nine new modules and their complete dependencies.
- All19 new public audit roots use only standard axioms.
- All122 previous axiom sets remain exact:105 memory,12 integer helper and five integer root theorems.
- All four complete-lowering record witnesses use kernel evaluation. Guarded source and distinct-world witnesses cover every width.
- Source fingerprints remain exact. No existing source file changed.

Receipt:integer-records-batch-state-v1.json. The earlier launcher lacked Lake on PATH and performed no source build; its failure remains preserved separately. The corrected gate used the pinned toolchain and existing shared cache.

Part of#140. Complete wider production classes follow this source/record integration. No new production acceptance or official agreement gain is claimed here. The full original driver goal remains open.
