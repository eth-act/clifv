from pathlib import Path
import os,json,subprocess,datetime,hashlib,re
b=Path('/home/lee/clifv');r=b/'.worktrees/stock-cfg-source-20261025';e=b/'.git/agent-evidence/stock-memory-20261029';state=e/'integer-records-batch-state-v1.json';records=[]
names=['Selected','Dispatch','RecordValues','SelectedValues','SourceValues','PairedRecord','RecordFrame','RecordFixture','GuardedWitness'];files=[r/f'FV/Backend/Proof/StockMemoryInteger{n}.lean' for n in names];before={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
env=dict(os.environ);env.update(json.loads((e/'author-env-v1.json').read_text()));env.update(FV_ROOT=str(r),FV_MEMCAP='16G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',CARGO_BUILD_JOBS='1');env.pop('FV_PIPELINE_T',None)
def save(status,**x):state.write_text(json.dumps(dict(status=status,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),records=records,sources=before,**x),indent=2)+'\n')
def run(label,args):
 save('running',phase=label)
 with(e/('integer-records-'+label+'-v1.log')).open('w') as log:done=subprocess.run(['nice','-n','10',str(r/'scripts/memcap.sh'),*args],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 records.append(dict(label=label,returncode=done.returncode));assert done.returncode==0,(label,done.returncode)
def axioms(path):return {n:set(x.strip() for x in a.split(',')) for n,a in re.findall(r"'([^']+)' depends on axioms: \[([^]]*)\]",path.read_text(),re.S)}
try:
 assert subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=r)==b'', 'An existing tracked source changed'
 run('reverse-build',['python3','scripts/lake-serial-build.py','--budget','14G','--max-jobs','1','--max-cap','14G','--default-cap','14G','--profile',str(r/'.lake/lake-module-peaks.tsv'),'--out',str(e/'integer-records-modules-v1'),*['FV.Backend.Proof.StockMemoryInteger'+n for n in names]])
 run('audit',['lake','env','lean','scripts/audit/stock-memory-integer-records.lean']);current=axioms(e/'integer-records-audit-v1.log');assert len(current)==19 and all(a<={'propext','Classical.choice','Quot.sound'} for a in current.values())
 for label,script,baseline,count in [('old-memory','stock-memory-source.lean','author-normal-gates-v1/all-axioms/stock-memory-source.log',105),('old-helpers','stock-memory-integer-forward.lean','integer-memory-integrated-audit-v1.log',12),('old-roots','stock-memory-integer-roots.lean','integer-load-roots-audit-v2.log',5)]:
  run(label,['lake','env','lean','scripts/audit/'+script]);actual=axioms(e/('integer-records-'+label+'-v1.log'));assert len(actual)==count and actual==axioms(e/baseline),(label,'axiom drift')
 assert before=={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
 save('passed',modules=9,new_audit_roots=19,all_new_axioms_standard=True,old_axiom_sets_exact=122,source_unchanged=True,scope='Complete actual integer-load retained binding and source/paired-world transfer across four widths. Wider production activation and remaining original140 obligations stay open.')
except BaseException as error:save('failed',error=repr(error));raise
