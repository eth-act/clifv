from pathlib import Path
import os,json,subprocess,datetime
b=Path('/home/lee/clifv');r=b/'.worktrees/stock-cfg-source-20261025';e=b/'.git/agent-evidence/stock-memory-20261029';env=dict(os.environ);env.update(json.loads((e/'author-env-v1.json').read_text()));env.update(FV_ROOT=str(r),FV_MEMCAP='4G',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2',LEAN_NUM_THREADS='2',CARGO_BUILD_JOBS='2');state=e/'captured-consumer-state-v1.json'
state.write_text(json.dumps(dict(status='running',utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))+'\n')
with (e/'captured-consumer-build-v1.log').open('w') as log:result=subprocess.run(['nice','-n','10',str(r/'scripts/memcap.sh'),'python3','scripts/lake-serial-build.py','--budget','4G','--max-jobs','1','--max-cap','4G','--default-cap','4G','--out',str(e/'captured-consumer-modules-v1'),'FV.E2E.SemanticNIBoundary','FV.Backend.Proof.StockMemoryCfgCompatibility'],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
state.write_text(json.dumps(dict(status='passed' if result.returncode==0 else 'failed',returncode=result.returncode,utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),indent=2)+'\n');raise SystemExit(result.returncode)
