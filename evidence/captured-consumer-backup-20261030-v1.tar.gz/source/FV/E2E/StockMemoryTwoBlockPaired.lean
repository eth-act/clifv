import FV.E2E.StockMemoryOriginalEntryPaired
import FV.E2E.StockMemoryNonentryPairedReturn
import FV.E2E.StockMemoryPairedNopJump
import FV.Backend.Proof.StockMemoryNopJumpSpec
import FV.Backend.Proof.StockTwoBlockShape
import FV.Backend.Proof.StockTwoBlockCompatibility

namespace E2E.StockMemory
open Backend Backend.Proof Backend.Proof.Driver Backend.Stock Backend.Stock.Proof Backend.Stock.Proof.Control
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000

/-- Original two-block source syntax derives the complete paired run from PC0.
The driver supplies order, retained records, code placement, and jump demands internally. -/
theorem stock_two_block_load_return_paired {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    (abi : sigAbiOk f.sig = true)
    {entry target : Clif.Block} (blocks : f.blocks = [entry,target])
    (nops : ∀ stm ∈ entry.body,stm.inst = .nop)
    (jump : entry.term = .jump ⟨target.id,[]⟩)
    {loadIndex x z : Nat} {flags : Clif.MemFlags}
    (statement : target.body[loadIndex]? = some ⟨[z],.load .load .i32 flags x 0⟩)
    (shape : ∀ j stm,target.body[j]? = some stm → j = loadIndex ∨ stm.inst = .nop)
    (ret : target.term = .ret [z]) (parameter : x ∈ entry.params.map (·.1))
    {args : List Clif.Val} {cm : Clif.Mem} {fr : Clif.Frame}
    (entered : SourceEntry f args fr)
    (registerOnly : ∀ loc ∈ locsOf f.sig,∃ pin,loc = .reg pin)
    {Γ : Rel} {c : BitVec 64} {D : BitVec 64 → Prop} {fc : FnCtx} {X : ExtSem}
    (slot : fc.slotBase = Γ.slotOff)
    (symbols : ∀ n a,Γ.syms n = some a → X.sym n 0 = BitVec.ofNat 64 a)
    (tls : XTls Γ.F X)
    {env : Clif.Env} {cp : Clif.Program} {fuel : Nat} {vals : List Clif.Val} {mem : Clif.Mem}
    (returned : Clif.runLoop env cp fuel ⟨fr,[],cm⟩ = .returned vals mem)
    {w w' : Arm.ArmState} (memory : MRP Γ f c D fr.slots cm (w,w'))
    (arguments : ArgsAtEntry Γ.F f.sig args w) (otherArguments : ArgsAtEntry Γ.F f.sig args w')
    (registers : ∀ pin v,(.reg pin,v) ∈ (locsOf f.sig).zip args → regVal w' pin = regVal w pin) :
    RunOkABIAt f result.code result.edgeArgs (pairSem (csem Γ.F fc X)) (MRP Γ f c D) fr.slots
      ⟨0,0,entrySeed result.ctx fr,(w,w')⟩ (.returned vals mem) := by
  have entrySource : f.blocks[0]? = some entry := by rw [blocks]; rfl
  have targetSource : f.blocks[1]? = some target := by rw [blocks]; rfl
  have different : entry.id ≠ target.id := by
    intro same
    have absent := scope.noEntryPred entry (by simp [blocks]) target.id
      (by simp [succIds,dests,jump])
    apply absent
    simp [blockIdx?,blocks,List.findIdx?_cons,same]
  have order : result.order = ⟨#[.original 0,.original 1],#[#[1],#[]]⟩ :=
    Except.ok.inj ((stock_lower_order run).symm.trans
      (TwoBlock.block_order blocks jump ret rfl different))
  have tag : result.order.nodes[0]? = some (.original 0) := by rw [order]; rfl
  obtain ⟨spec⟩ := stock_lower_nop_jump_body_spec run scope dominated tag entrySource nops jump
    (driverSem_csem Γ.F fc X) (MR := RelW Γ f c) env cp
  have targetEq : spec.target = 1 := by
    have targets := spec.targets
    rw [order] at targets
    exact (List.cons.inj targets).1.symm
  have targetTag : result.order.nodes[spec.target]? = some (.original 1) := by
    rw [targetEq,order]
    rfl
  have index : blockIdx? f target.id = some 1 := by
    simp [blockIdx?,blocks,List.findIdx?_cons,different,Ne.symm different]
  obtain ⟨targetBlock,targetFound,found⟩ := block?_of_idx index
  have sameTarget : targetBlock = target := Option.some.inj (found.symm.trans targetSource)
  subst targetBlock
  obtain ⟨ranges,params,input,data,core,raw,prelude,coreRun,assembled,build,sizes,prepared,
    nextEvents,nextBlock,rawCode,placed⟩ := stock_lower_original_block_scan_assembly run targetTag
  have nextSource : f.blocks[core.scan.block]? = some target := by rw [nextBlock]; exact targetSource
  have nonempty : 0 < spec.core.code.size := by
    rw [spec.bodyCode]
    simp only [Array.size_append,Array.size_singleton]
    omega
  let entryCore : EntryCoreSpec f result entry := {
    ranges := spec.ranges
    params := spec.params
    core := spec.core
    raw := spec.raw
    preludeCode := spec.preludeCode
    build := spec.build
    sizes := spec.sizes
    assembled := spec.assembled
    events := spec.events
    block := entrySource
    rawCode := spec.rawCode
    placed := spec.placed
    nonempty := nonempty }
  obtain ⟨ρ',path,held⟩ := original_entry_prelude_paired run scope dominated entryCore entered
    registerOnly slot symbols memory arguments otherArguments registers
  have continuation : ∀ (left : Nat) (s : Clif.State) (ρ : Nat → CV) (q : W2),
      s.frame.func = f → s.callers = [] → s.frame.body = target.body →
      s.frame.term = target.term → SourceDefinedAt f result.ctx 1 0 s.frame →
      Clif.runLoop env cp left s = .returned vals mem →
      PairedScanRel f result core.scan.ctx core.scan.block Γ c D core.scan.output.state
        (0,s.frame,s.mem) ρ q →
      RunOkABIAt f result.code result.edgeArgs (pairSem (csem Γ.F fc X)) (MRP Γ f c D)
        s.frame.slots ⟨spec.target,0,ρ,q⟩ (.returned vals mem) := by
    intro left s ρ q func callers body terminal defined returned held
    exact actual_nonentry_paired_load_return run scope dominated abi targetTag targetSource
      (by decide) nextEvents nextBlock statement shape ret entrySource parameter slot symbols tls
      func callers body terminal (by simpa only [nextBlock] using defined) returned held
  have entryFacts := entered
  obtain ⟨original,regs,entryLookup,argTypes,paramTypes,set,frame⟩ := entryFacts
  have originalSource : f.blocks[0]? = some original := by
    simpa only [Clif.Function.entry?,List.head?_eq_getElem?] using entryLookup
  have sameEntry : original = entry := Option.some.inj (originalSource.symm.trans entrySource)
  subst original
  have defined : SourceDefinedAt f result.ctx spec.core.scan.block 0 fr := by
    rw [spec.atBlock]
    exact Control.source_defined_entry_frame dominated result.ctx entered
  have finished := paired_nop_jump_body_returns_at run scope dominated spec nops tag jump
    targetTag index targetFound nextEvents nextBlock (by rw [targetEq]; omega) continuation
    (s := ⟨fr,[],cm⟩) rfl (by rw [frame]) (by rw [frame]) defined returned held
  have seed : entrySeed spec.core.scan.ctx fr = entrySeed result.ctx fr := by
    classical
    let make (lookup : Nat → Option Reg) (key : Nat) : CV :=
      if h : ∃ pair : Nat × Clif.Val,
          lookup pair.1 = some (.vreg key .int) ∧ fr.regs pair.1 = some pair.2 then
        (Classical.choose h).2.bits.setWidth 128
      else 0
    change make spec.core.scan.ctx.valueReg? = make result.ctx.valueReg?
    rw [funext (stock_lower_record_context run scope spec.events).2.1]
  rw [← seed]
  exact RunOkABIAt.prefix path finished

/-- The original source class also satisfies the unchanged compiler ABI contract. -/
theorem stock_two_block_load_return_paired_function {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    (abi : sigAbiOk f.sig = true)
    {entry target : Clif.Block} (blocks : f.blocks = [entry,target])
    (nops : ∀ stm ∈ entry.body,stm.inst = .nop)
    (jump : entry.term = .jump ⟨target.id,[]⟩)
    {loadIndex x z : Nat} {flags : Clif.MemFlags}
    (statement : target.body[loadIndex]? = some ⟨[z],.load .load .i32 flags x 0⟩)
    (shape : ∀ j stm,target.body[j]? = some stm → j = loadIndex ∨ stm.inst = .nop)
    (ret : target.term = .ret [z]) (parameter : x ∈ entry.params.map (·.1))
    {args : List Clif.Val} {cm : Clif.Mem} {fr : Clif.Frame}
    (entered : SourceEntry f args fr)
    (registerOnly : ∀ loc ∈ locsOf f.sig,∃ pin,loc = .reg pin)
    {Γ : Rel} {c : BitVec 64} {D : BitVec 64 → Prop} {fc : FnCtx} {X : ExtSem}
    (slot : fc.slotBase = Γ.slotOff)
    (symbols : ∀ n a,Γ.syms n = some a → X.sym n 0 = BitVec.ofNat 64 a)
    (tls : XTls Γ.F X)
    {env : Clif.Env} {cp : Clif.Program} {fuel : Nat} {vals : List Clif.Val} {mem : Clif.Mem}
    (returned : Clif.runLoop env cp fuel ⟨fr,[],cm⟩ = .returned vals mem)
    {w w' : Arm.ArmState} (memory : MRP Γ f c D fr.slots cm (w,w'))
    (arguments : ArgsAtEntry Γ.F f.sig args w) (otherArguments : ArgsAtEntry Γ.F f.sig args w')
    (registers : ∀ pin v,(.reg pin,v) ∈ (locsOf f.sig).zip args → regVal w' pin = regVal w pin) :
    RunOkABI f result.code (pairSem (csem Γ.F fc X)) (MRP Γ f c D) fr.slots
      ⟨0,0,entrySeed result.ctx fr,(w,w')⟩ (.returned vals mem) := by
  have executed := stock_two_block_load_return_paired run scope dominated abi blocks nops jump
    statement shape ret parameter entered registerOnly slot symbols tls returned memory
    arguments otherArguments registers
  have different : entry.id ≠ target.id := by
    intro same
    have absent := scope.noEntryPred entry (by simp [blocks]) target.id
      (by simp [succIds,dests,jump])
    apply absent
    simp [blockIdx?,blocks,List.findIdx?_cons,same]
  exact RunOkABIAt.legacyCompatible (TwoBlock.legacy_compatible run scope blocks jump ret rfl different) executed

end E2E.StockMemory
