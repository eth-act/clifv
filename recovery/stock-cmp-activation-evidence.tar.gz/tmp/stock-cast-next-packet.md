# Next delivery after cast activation

Keep original140 scope and contracts. Reuse the now-compiled source bridges:
StockCountSourceValues (CLZ/CTZ derives selection and original operand internally),
StockBitrevSourceValues, StockBswapSourceValues, and StockRotateDispatch plus
wide/narrow/register/immediate source transfers. Do not recreate their executions.

Consider one coherent bit-operation class for CLZ/CTZ/bitrev/bswap/rotl/rotr with
complete witnesses and a single full validation batch. Popcnt remains in original
Compile.unaryE and cannot be silently excluded from full-goal completion; CLS is
excluded by the unchanged original Compile.unaryE. Preserve original i8/i16 and
all selected theorem variants even when the first production class uses i32/i64.

Generalize cast look-through exclusion composition with additional public
SafeFormat variants; keep the existing CastBody.Family theorem signatures.
Future pure bit syntax derives the same absence of load/IntCompare directly.
Avoid copying the entire cast or all older body proof stacks. Shared retained
record handler should accept this derived format property; all old variants stay.

ABI additions should use a new producer predicate, preserving constant/shift/
extension selectors and cleanup whitelist. Actual rotations use ALUOp.extr,
including register and immediate forms (not a guessed ror constructor). Count and
reverse code use bitRR.clz/rbit/rev; verify all actual forms from existing Rhs.

Freeze tracked source/HEAD for maintained author gates. Run old identity/stage,
AX-set/header, original artifact and native input-vector parity. Keep one cache,
max16GiB/max2jobs, no extra worktrees. Keep44current; next is not a reservation.

Gate scheduling improvement: split current and retained integration cohorts into
separate one-gate manifests up front, allowing them to share the two available
slots once full/example gates finish. Do not mutate or stop a running manifest,
copy successful records, or launch a redundant cohort to change scheduling.
No new runner/framework required. Keep one physical warm cache and aggregate cap.

Important saved implementation found: StockUnaryDispatch already exports
stock_selected_neg_rule / stock_selected_bswap_rule / stock_selected_bitrev_rule
and stock_lower_{neg,bitrev,bswap}_source_by_instruction. Reuse these directly;
do not reimplement source-data/type/inventory dispatch. Include negation with
the next coherent bit-operation class. External family/no-trap and ABI bitRR/
EXTR framing drafts compile; transfer into normal modules only after cast squash.

External fixtures compile arbitrary-input entry/complete67-step execution in
all6configurations. Non-proof discovery Stock.lower succeeds in all6 and selects
9newroots/config:shared756neg/922clz/927ctz/918bitrev,bswap933/934,
rotl901/902(register),903/904(immediate),rotr907/908(register),910/911(immediate).
All actual code passes current ABI producer predicate OR compiled bitProducer.
These observations are discovery, not replacement for the two fixed complete
witness facts and final normal/trust/production gates. Current activation remains
cast-only until the next batch. Add an observable CTZ(0) native vector only to
newbitclass; earlier class vector inventories stay exact. Nextnativegrid86cases/
object (projected2064comparisons/516reference; verify actual receipt).

Production runtime/link fixture drafts preserve all12current functions and add the newbitfunction (13total); backed with cast terminal evidence. Compile them only after real class/ABI/consumer activation and normal keys.
