from pathlib import Path
out=Path('/tmp/stock-cmp-next-highmul-draft')
for suffix in ['Runtime','Linked']:
 s=Path('FVTest/Backend/Lowering/StockCmpProduction'+suffix+'.lean').read_text().replace('StockCmp','StockHighMul').replace('stock_cmp','stock_highmul').replace('STOCK_CMP','STOCK_HIGHMUL').replace('comparison fixture','high multiplication fixture')
 if suffix=='Runtime':
  s=s.replace('  ({E2E.StockMinMaxNIWitness.function config','  ({E2E.StockCmpNIWitness.function config with name := "retained_cmp"}).print ++ "\\n" ++\n  ({E2E.StockMinMaxNIWitness.function config',1).replace('funcs.length == 16','funcs.length == 17')
 (out/('StockHighMulProduction'+suffix+'.lean')).write_text(s)
s=Path('FV/E2E/SemanticNIBoundary.lean').read_text().replace('Backend.ABIReadScalar.booleanProducer,','Backend.ABIReadScalar.booleanProducer,Backend.ABIReadScalar.highmulProducer,');(out/'SemanticNIBoundary.lean').write_text(s)
s=Path('scripts/check-stock-mixed-integration.py').read_text().replace('"minmax", "cmp"]','"minmax", "cmp", "highmul"]').replace('"cmp": "CmpProduction"','"cmp": "CmpProduction", "highmul": "HighMulProduction"').replace('"cmp": "stock-cmp"','"cmp": "stock-cmp", "highmul": "stock-highmul"');(out/'check-stock-mixed-integration.py').write_text(s)
s=Path('scripts/check-stock-mixed-native.py').read_text().replace('"minmax", "cmp")','"minmax", "cmp", "highmul")').replace('"minmax", "cmp"]','"minmax", "cmp", "highmul"]').replace('if kind == "cmp":','if kind in ("cmp", "highmul"):')
needle='''                                            cases.append(("stock_cmp_ni",args,signed(cmp_result,bits)))'''
replacement='''                                            if kind == "highmul":
                                                def highproduct(a,b,signed_inputs):
                                                    a,b = a & mask,b & mask
                                                    if signed_inputs:
                                                        a,b = signed(a,bits),signed(b,bits)
                                                    return ((a*b) >> bits) & mask
                                                constant = 0x123456789abcdef & mask
                                                result = cmp_result ^ highproduct(args[1],args[2],True) ^ highproduct(args[1],args[2],False)
                                                result ^= highproduct(args[2],constant,True) ^ highproduct(args[1],constant,False)
                                                cases.append(("stock_highmul_ni",args,signed(result,bits)))
                                                cases.append(("retained_cmp",args,signed(cmp_result,bits)))
                                            else:
                                                cases.append(("stock_cmp_ni",args,signed(cmp_result,bits)))'''
assert needle in s;s=s.replace(needle,replacement)
needle='''        if options.kind == "cmp":''';replacement='''        if options.kind == "highmul":
            wanted = (wanted - {"stock_mixed_ni"}) | {"stock_highmul_ni", "retained_cmp", "retained_minmax", "retained_popcount", "retained_bit", "retained_cast", "retained_shift", "retained_mul", "retained_not", "retained_constant", "retained_logical", "retained_mixed"}
        elif options.kind == "cmp":''';assert needle in s;s=s.replace(needle,replacement);compile(s,'highmul-native','exec');(out/'check-stock-mixed-native.py').write_text(s)
s=Path('lakefile.toml').read_text();start=s.index('[[lean_exe]]\nname = "stock-cmp-runtime"');tail=s[start:];assert tail.count('[[lean_exe]]')==2;append=tail.replace('stock-cmp','stock-highmul').replace('StockCmp','StockHighMul');(out/'lakefile-additions.toml').write_text(append)
print('Prepared fixture/native/integration consumer drafts; not validated.')
