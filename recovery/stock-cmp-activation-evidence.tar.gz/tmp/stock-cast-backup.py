from pathlib import Path
import tarfile,json,hashlib,subprocess,os,tempfile,datetime
root=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');out=Path('/tmp/stock-cast-activation-backup');out.mkdir(exist_ok=True);archive=out/'evidence.tar.gz';assert not archive.exists()
terminal=Path('/tmp/stock-cast-terminal-receipt.json');assert json.loads(terminal.read_text())['state']=='per_pr_gates_passed'
paths={p for p in Path('/tmp').glob('stock-cast-*') if p.is_file() and p.suffix not in ['.gz','.tar']}
paths.update(p for p in Path('/tmp').glob('stock-shift-*') if p.is_file())
for folder in [p for p in Path('/tmp').glob('stock-cast-*') if p.is_dir() and p!=out]:
 paths.update(p for p in folder.rglob('*') if p.is_file() and p.suffix not in ['.olean','.ilean','.pyc'])
paths.update([Path('/tmp/stock-mul-retained-flat-multiply.py'),Path('/tmp/stock-ni-current-status44.md')])
for mode in ['Plain','Cleanup']:
 base=Path('/tmp/stock-not-integration-author/not/linked');name='StockNotProduction6Mixed'+mode+'FallbackGlobal'
 paths.update([base/(name+'.elf'),base/'Crates'/(name+'.lean')])
for example in ['fv-demo','survey']:
 p=root/'examples'/example/'target'
 for pattern in ['fv-report.json','fv/plain-leanlink-verified-leanld/bin-check/**/*.lean','fv/plain-leanlink-verified-leanld/bin-check/**/report.json']:
  paths.update(x for x in p.glob(pattern) if x.is_file())
with tarfile.open(archive,'w:gz') as t:
 for p in sorted(paths):t.add(p,arcname=str(p).lstrip('/'),recursive=False)
assert archive.stat().st_size<100*1024*1024,archive.stat().st_size
def git(*args,**kw):return subprocess.check_output(['git',*args],cwd=root,**kw).decode().strip()
head=git('rev-parse','HEAD');stamp=datetime.datetime.now(datetime.timezone.utc)
meta={'utc':stamp.isoformat(),'source_head':head,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size,'files':len(paths),'terminal_receipt_sha256':hashlib.sha256(terminal.read_bytes()).hexdigest(),'preserves_failures':True,'next_bit_family_no_trap_abi_drafts_included':True};mp=out/'metadata.json';mp.write_text(json.dumps(meta,indent=2)+'\n')
fd,index=tempfile.mkstemp(prefix='stock-cast-backup-index-');os.close(fd);os.unlink(index);env=dict(os.environ,GIT_INDEX_FILE=index)
try:
 git('read-tree',head,env=env)
 for src,dst in [(archive,'recovery/stock-cast-activation-evidence.tar.gz'),(mp,'recovery/stock-cast-activation-metadata.json')]:
  oid=git('hash-object','-w',str(src));git('update-index','--add','--cacheinfo','100644,'+oid+','+dst,env=env)
 tree=git('write-tree',env=env);commit=git('commit-tree',tree,'-p',head,input=b'Back up complete cast activation terminal evidence and retained artifacts\n');branch='agent/stock-cast-evidence-'+stamp.strftime('%Y%m%dT%H%M%SZ');assert not git('ls-remote','origin','refs/heads/'+branch)
 git('update-ref','refs/heads/'+branch,commit);git('push','origin',branch);remote=git('ls-remote','origin','refs/heads/'+branch).split()[0];assert remote==commit
 meta.update({'backup_commit':commit,'backup_branch':branch,'remote_verified':True});mp.write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(meta,indent=2))
finally:Path(index).unlink(missing_ok=True)
