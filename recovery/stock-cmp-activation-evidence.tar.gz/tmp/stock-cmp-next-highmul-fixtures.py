from pathlib import Path
out=Path('/tmp/stock-cmp-next-highmul-draft')
(out/'StockHighMulFixtures.lean').write_text('''import FV.E2E.StockCmpFixtures
namespace E2E.StockHighMulNIWitness
open Backend.Stock.D0
set_option autoImplicit false
set_option Elab.async false

/-- Signed/unsigned products of original inputs and a large constant, retaining
all earlier source computations in the returned value. -/
def extraBody (config : Configuration) : List Clif.Stmt :=
  let ty := valueType config
  [⟨[4001],.binary .smulhi ty 1 2⟩,
   ⟨[4002],.binary .umulhi ty 1 2⟩,
   ⟨[4003],.binary .smulhi ty 2 304⟩,
   ⟨[4004],.binary .umulhi ty 1 304⟩,
   ⟨[4005],.binary .bxor ty 4001 4002⟩,
   ⟨[4006],.binary .bxor ty 4003 4004⟩,
   ⟨[4007],.binary .bxor ty 4005 4006⟩,
   ⟨[4008],.binary .bxor ty 1196 4007⟩]

def function (config : Configuration) : Clif.Function :=
  let old := StockCmpNIWitness.function config
  {old with name := "stock_highmul_ni",blocks := old.blocks.map fun b =>
    {b with body := b.body ++ extraBody config,term := .ret [4008]}}

def resultValue (config : Configuration) (input : Nat → BitVec (valueType config).width) :
    BitVec (valueType config).width :=
  let constant := BitVec.ofNat (valueType config).width 0x123456789abcdef
  StockCmpNIWitness.resultValue config input ^^^
    ((Clif.Sem.binary .smulhi (input 1) (input 2) ^^^ Clif.Sem.binary .umulhi (input 1) (input 2)) ^^^
      (Clif.Sem.binary .smulhi (input 2) constant ^^^ Clif.Sem.binary .umulhi (input 1) constant))
end E2E.StockHighMulNIWitness
''')
s=Path('FV/E2E/StockCmpWitness.lean').read_text().replace('StockCmp','StockHighMul').replace('StockMinMax','StockCmp').replace('CmpBody','HighMulBody').replace('domain_of_cmp','domain_of_highmul').replace('cmpBodyEligible','highmulBodyEligible').replace('[1196]','[4008]').replace(' 242 ⟨frame',' 250 ⟨frame').replace('cmpRoots','highmulRoots')
s=s.replace('def highmulRoots (_config : Backend.Stock.D0.Configuration) : List Nat := [811,819,958]','def highmulRoots (config : Backend.Stock.D0.Configuration) : List Nat :=\n  if valueType config == .i64 then [777,779] else [778,780]')
s=s.replace('all four original comparison roots','both width-appropriate signed/unsigned high-multiply roots')
s=s.replace('comparison','high multiplication')
# Keep exact comparison producer coverage in addition to new high products.
s=s.replace('def high multiplicationFormsCovered','def highmulFormsCovered').replace('high multiplicationFormsCovered','highmulFormsCovered')
s=s.replace(' && highmulFormsCovered result',' && highmulFormsCovered result')
(out/'StockHighMulWitness.lean').write_text(s)
print('Prepared complete highmul witness draft (8 new live statements), not validated.')
