from pathlib import Path
import json,datetime
r=json.loads(Path('/tmp/stock-minmax-terminal-receipt.json').read_text());b=json.loads(Path('/tmp/stock-minmax-activation-backup/metadata.json').read_text());assert b['remote_verified'] and b['source_head']==r['validated_source_head'];r['remote_backup']=b
Path('docs/research/stock-minmax-production-activation.json').write_text(json.dumps(r,indent=2)+'\n')
Path('docs/research/stock-minmax-production-activation.md').write_text(f'''# Stock signed and unsigned min/max in production

Validated source `{r['validated_source_head']}`, based on main `80280f11`.
The default shared scalar compiler/checker/linker/generated-proof consumers now
support smin/smax/umin/umax for i32/i64, mixed with all prior classes. Original
input conditions, old theorem variants/selectors, exact required axioms,
accepted identities and ordered successful stages remain. The cleanup whitelist
and Arm/MInst/allocator models are unchanged.

## Reused source proofs and exact consumer boundary

Existing ScalarSelect min/max source wrappers supply actual matching, selection,
request/execution, retained binding and original guarded post-frames at all four
scalar widths. No alternate numerical/RHS proof chain is introduced. Existing
stock_lower_available_getAs_type derives the old explicit operand-type guards
from original availability/getters and restricted DFG typing. Runs already
supplies SameWorldNF, so the body proof uses that actual world frame directly.
Source formats derive the existing cast exclusions internally.

The universal body/entry/return/no-trap proofs construct the existing Scalar.Domain.
Existing first-match ordering selects roots 796/797/798/799 ahead of matching
fallbacks; historical root inventories are not coverage percentages. The actual
min/max witness exposed the old ABI check's zero-only comparison boundary.
A precise scalar comparison producer now handles the emitted register/register
and immediate SUBS forms, with flag framing, transport and machine realization.
All old ABIReadFlags and scalar selectors remain. Source getters/types and
comparison facts are derived internally, not new accepted-program certificates.

Complete mixed witnesses span six ABI configurations and both cleanup modes,
with arbitrary source inputs and the original arbitrary explicit slot. Four
register cases, positive/negative right constants and large left constants feed
an alternating add/xor aggregate; the final XOR keeps all previous computation
live. Actual selected roots and both comparison instruction forms are checked.
Existing source proofs continue to cover i8/i16; production activation is i32/i64.
Only two new fixed native facts enter witnesses; universal proofs stay standard-only.

## Validation and execution cost

All {r['primary_gate_count']} primary gates and {len(r['owned_gate_records'])} ownership partitions passed on frozen source:
{r['normal_library_jobs']:,} normal keys / {r['normal_scheduled_modules']:,} modules, four existing tools and four native fixture targets,
current crate keys, {r['checked_in_audits']} audits / {r['audited_roots']:,} roots; all 1,571 prior axiom sets
and 30 old public headers exact. Ownership covers {r['owned_core_constants']:,} standard-only core /
{r['owned_fixed_witness_constants']:,} fixed witness constants, {r['core_owners']} core / {r['witness_owners']} witness /
{r['executable_owners']} executable owners and exactly 33 permitted native facts (previous31 +2).
One bundled domain MCP review reports only propext/Classical.choice/Quot.sound
and no source warnings.

All 24 objects pass 2,448 native comparisons / 612 Cranelift reference executions,
with zero failures/disagreements. All nine previous native grids and expected
results are exact. Real oracle, missing-binary and whole-attempt retry controls
remain. Current min/max and retained popcount actual CLI/link/generated cohorts
each pass 32 checks, including 33-function slices, reconstruction, stack bounds
and both preparation modes. Original flat-multiply bytes/proof sources remain
exact and current proofs compile in both modes.

Runtime:4,737 passed /0 failed, same7 known non-runnable cases. Encoder:1,321
identical /0 different. Both E2E modes accept1,159 /reject0, retaining original1,150
and prior1,159 identities and ordered stages exactly. Verified demo:21 tests /
2 binaries; survey:53 tests /18 binaries. JSON keeps command/log/output hashes
and original evidence provenance.

The unchanged popcount fixture was measured before min/max activation as ordinary
native executables: runtime10.21s and linked10.13s, versus minutes interpreted.
All72 source/table/object artifacts and12 ELF artifacts are byte-exact against
the validated interpreted run. The final candidate rebuilds its executables;
both actual integration cohorts run native with Lake-key and binary-hash checks.
The existing interpreted default remains; --fixture-mode native is explicit.
No fixture checks or proof gates are removed, and generated proofs still compile
fresh against current imports.

## Provenance, resources and remaining obligations

Early private-proof syntax/simplification errors and a failed pipeline witness
are preserved. The latter identified the actual comparison ABI gap and was fixed
before freezing author inputs. A draft assertion about an un-emitted ADDS form
was removed, together with that unused producer; emitted forms are checked.
Failed prechecks never count as passing gates.

Terminal evidence is remotely verified at `{b['backup_commit']}` on
`{b['backup_branch']}`; archiveSHA256 `{b['archive_sha256']}`,
{b['archive_bytes']:,} bytes / {b['files']:,} files. Four necessary views, one physical
warm cache, over700GiB free and at most16GiB/two jobs. Canonical dirty recovery
source is untouched. Expendable generated outputs are archived before removal.

Full original #140 remains unfinished. Successful Stock lowering remains a
source-refinement premise; universal lowering/request/downstream completeness
is still open. Fallback is not Stock completeness. Next are integer comparisons,
including real cast-of-icmp811 (no narrowing of original accepted syntax), high
multiply/division/remainder, complete original widths/ABIs and all remaining
control/memory/trap/effect/call/source/block/whole-driver/consumer obligations.
''')
p=Path('docs/plans/stock-driver-incremental-delivery.md');s=p.read_text();a=s.index('Next: comparisons/min/max, high multiply/division/remainder, complete original');z=s.index('\n## Maintained validation runner',a)
s=s[:a]+f'''Signed/unsigned min/max passes author gates through the same scalar consumers.
[Terminal evidence](../research/stock-minmax-production-activation.md) records
{r['primary_gate_count']} primary / {len(r['owned_gate_records'])} ownership gates, {r['audited_roots']:,} audited roots, all 1,571 prior axiom sets /
30 old headers exact and 2,448 native comparisons. Current and retained actual
CLI/link/generated cohorts each pass32 checks. Validated `{r['validated_source_head'][:8]}`;
remote evidence `{b['backup_commit'][:8]}`. Existing complete source wrappers, original
operand-type derivation and actual SameWorldNF framing are reused.

Measured ordinary native fixture runners retain identical checks/artifacts and
reduce repeated interpreted runs from minutes to about10 seconds. Keep the
interpreted default and explicit native mode, validate target keys/binary hashes,
and compile generated proofs freshly. Reuse existing complete source wrappers
before introducing another proof chain.

Next: integer comparisons and actual cast-of-icmp811; high multiply/division/
remainder; complete original widths/ABIs; every unchanged original #140 control/
memory/trap/effect/call/source/block/whole-driver/completeness/consumer obligation.
Never exclude original accepted compare/cast syntax to simplify composition.
Universal successful lowering and downstream completeness remain. Fallback is
not Stock completeness; full original #140 remains unfinished.
'''+s[z:];p.write_text(s)
p=Path('docs/research/stock-driver-obligations.json');x=json.loads(p.read_text());x['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();x['production']['landed'].append('i32/i64 signed and unsigned min/max through shared scalar consumers (validated, squash pending)');x['production']['pending']=r['next']
for entry in x['production']['landed']:
 pass
for item in x['roots']:
 if item['id'] in r['executed_new_roots']:
  item['status']='existing actual-source selection/execution/retained binding/guarded transfer reused; derived operand types; min/max body/entry/default consumers validated, squash pending; universal lowering/downstream completeness remains';item['current_proof']='docs/research/stock-minmax-production-activation.md'
 if item['id'] in [800,802,804,806]:
  item['status']='later matching fallback excluded by existing scalar-first matching order under original source conditions';item['current_proof']='FV/Backend/Proof/StockMinMaxSourceMatch.lean'
x['complete']=False;p.write_text(json.dumps(x,indent=2)+'\n')
