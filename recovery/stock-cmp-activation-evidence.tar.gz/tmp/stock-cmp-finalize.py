from pathlib import Path
import json,hashlib,subprocess,datetime,re
root=Path.cwd();head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
records=[]
for group in ['normal','native','owned','integration','minmax-integration','full','retention']:
 m=read('/tmp/stock-cmp-'+group+'-manifest.json');assert m['candidate']==head
 for g in m['gates']:
  r=read('/tmp/stock-cmp-'+group+'-author/'+g['id']+'.json');assert r['state']=='passed' and r['returncode']==0,g['id'];assert r['source_head']==head
  assert sha(r['log'])==r['log_sha256']
  for p,h in r['outputs'].items():assert sha(p)==h,p
  records.append(r)
integrations={}
for kind,path in [('cmp',Path('/tmp/stock-cmp-integration-author/cmp')),('minmax',Path('/tmp/stock-cmp-minmax-integration-author/minmax'))]:
 r=read(path/'receipt.json');assert r['state']=='passed' and len(r['records'])==32 and r['head']==head
 assert r['fixture_execution']=='native' and len(r['fixture_binary_sha256'])==2
 for p,h in r['fixture_binary_sha256'].items():assert sha(p)==h
 assert all(x['returncode']==0 and sha(x['log'])==x['sha256'] for x in r['records'].values())
 for field,folder in [('generated_sources',path/'linked'),('linked_artifacts',path/'linked'),('cli_sources',path)]:
  for n,h in r[field].items():assert sha(folder/n)==h
 integrations[kind]=r
retained=read('/tmp/stock-cmp-retention-author/retained/receipt.json');assert retained['state']=='passed';assert all(x.get('files_untouched',True) for x in retained['records'].values())
parity=read('/tmp/stock-cmp-identity-stage-parity.json');assert all(x['current']>=1159 and x['all_original_and_prior_identities_and_ordered_stages_preserved'] for x in parity.values())
ax=read('/tmp/stock-cmp-axiom-parity.json');assert ax['exact_old_required_axiom_sets_preserved'] and ax['baseline_roots']==1601
headers=read('/tmp/stock-cmp-header-parity.json');assert headers['unchanged'] and headers['old_public_headers']==35
review=read('/tmp/stock-cmp-mcp-review.json');assert not review['isError'] and not review['structuredContent']['warnings'];assert set(review['structuredContent']['axioms'])=={'propext','Classical.choice','Quot.sound'}
owned=[r for r in records if r['id'].startswith('owned-')];primary=[r for r in records if not r['id'].startswith('owned-')];assert len(primary)==22 and len(owned)==23
owners=read('/tmp/stock-cmp-owned/partitions.json')
ownedlog=Path(next(r for r in owned if r['id']=='owned-0')['log']).read_text();core,witness=map(int,re.search(r'STANDARD_CORE (\d+); FIXED_WITNESSES (\d+)',ownedlog).groups())
normal=Path(next(r for r in primary if r['id']=='all-normal-library-keys')['log']).read_text();normalkeys=int(re.search(r'All targets up-to-date \((\d+) jobs\)',normal)[1])
native=read('/tmp/stock-cmp-native-author/native/native-receipt.json');assert native['state']=='passed' and native['failures']==native['disagreements']==0;assert sha(root/'rust/target/release/clif-native')==native['native_binary_sha256'];assert native['lean_byte_executions']==2640
moduleplan=read('/tmp/stock-cmp-reconciled-impact-module-plan.json')
def gate_text(gate):return Path(next(r for r in primary if r['id']==gate)['log']).read_text()
runtime=gate_text('runtime-corpus');assert re.search(r'lean pass 4737 fail 0 error 0 .*not-runnable 7',runtime)
encoding=gate_text('encoder');assert 'functions 1321: identical 1321, differ 0' in encoding
for label,tests in [('verified-fv-demo',21),('verified-survey',53)]:assert 'SAME: '+str(tests)+' test outcomes identical' in gate_text(label),label
receipt={'state':'per_pr_gates_passed','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'validated_source_head':head,'base_main':'e95bb871','primary_gate_count':len(primary),'primary_gate_records':primary,'owned_gate_records':owned,'owned_core_constants':core,'owned_fixed_witness_constants':witness,'exact_declared_native_facts':len(owners['exact_native_facts']),'core_owners':len(owners['core']),'witness_owners':len(owners['witnesses']),'executable_owners':len(owners['executable_owners']),'normal_scheduled_modules':moduleplan['all'],'normal_library_jobs':normalkeys,'checked_in_audits':len(list(Path('scripts/audit').glob('*.lean'))),'audited_roots':ax['current_roots'],'runtime_corpus':{'passed':4737,'failed':0,'errors':0,'known_non_runnable':7},'encoder':{'identical':1321,'different':0},'mcp_review':review,'parity':{'axiom_sets':ax,'old_headers':headers},'identity_stage_parity':parity,'native_execution':native,'old_native_expected_vectors_preserved':read('/tmp/stock-cmp-native-grid-retention.json'),'new_proved_source_operations':['icmp','uextend-of-icmp811'],'production_widths':[32,64],'source_transfer_widths':[8,16,32,64],'executed_new_roots':[811,958],'executed_fixture_roots':[811,819,958],'fallback_first_match_exclusions_reused':True,'complete_witness_in_all_six_ABIs_and_both_cleanup_modes':True,'arbitrary_source_inputs_and_original_slot_witness':True,'all_old_computation_remains_live':True,'negative_and_large_constants_and_register_operands_and_both_comparison_producers':True,'retained_original_flat_multiply':retained,'native_fixture_execution_in_both_integrations':True,'verified_examples':{'fv-demo':{'tests':21,'verified_binaries':2},'survey':{'tests':53,'verified_binaries':18}},'full_original_140_complete':False,'next':'High multiply/division/remainder and complete original integer widths/ABIs; every remaining original #140 control/memory/trap/effect/call/source/block/whole-driver simulation/completeness/consumer obligation remains.'}
Path('/tmp/stock-cmp-terminal-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print('passed',len(primary),'primary/',len(owned),'ownership;',normalkeys,'normal keys;',core,'Std3/',witness,'fixed witnesses')
