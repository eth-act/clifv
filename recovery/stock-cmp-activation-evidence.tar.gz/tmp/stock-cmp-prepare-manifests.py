from pathlib import Path
import json,subprocess
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();base='e95bb871'
def replace(v):
 if isinstance(v,str):
  if v=='minmax':return 'cmp'
  return v.replace('stock-minmax','stock-cmp').replace('StockMinMax','StockCmp').replace('STOCK_MINMAX','STOCK_CMP').replace('Stock minmax','Stock cmp').replace('{out}/minmax','{out}/cmp').replace('minmax-actual','cmp-actual')
 if isinstance(v,list):return [replace(x) for x in v]
 if isinstance(v,dict):return {replace(k):replace(x) for k,x in v.items()}
 return v
for kind in ['normal','native','full','retention','integration']:
 m=replace(json.loads(Path('/tmp/stock-minmax-'+kind+'-manifest.json').read_text()));m.update(packet='cmp-production-'+kind,base=base,candidate=head,historical_evidence=['docs/research/stock-minmax-production-activation.json'],validation_scope='All original scalar comparison predicates and fused cast811 through mixed production consumers; original source conditions, theorem variants, exact axioms, identity/stage retention. Full original #140 remains unfinished.')
 if kind=='normal':
  for g in m['gates']:
   if g['id']=='all-trust-audits':g['argv'][-1]='/tmp/stock-cmp-final-audits'
  m['gates']=[g for g in m['gates'] if not g['id'].startswith('build-stock-popcount')]
  for target in ['stock-minmax-runtime','stock-minmax-linked']:
   m['gates'].insert(-1,{'id':'build-'+target,'argv':['lake','build',target],'env':{'FV_MEMCAP':'8G'},'complete_inputs':False})
 if kind=='retention':m['gates'][0]['argv'][1]='/tmp/stock-mul-retained-flat-multiply.py'
 Path('/tmp/stock-cmp-'+kind+'-manifest.json').write_text(json.dumps(m,indent=2)+'\n')
m=json.loads(Path('/tmp/stock-cmp-integration-manifest.json').read_text());m=replace(m)
# Fresh retained min/max actual consumer run on this candidate, not historical relabeling.
s=json.dumps(m).replace('stock-cmp','stock-minmax').replace('StockCmp','StockMinMax').replace('STOCK_CMP','STOCK_MINMAX').replace('"cmp"','"minmax"').replace('{out}/cmp','{out}/minmax')
m=json.loads(s);m['packet']='cmp-production-retained-minmax-integration';m['candidate']=head
Path('/tmp/stock-cmp-minmax-integration-manifest.json').write_text(json.dumps(m,indent=2)+'\n')
print(head)
