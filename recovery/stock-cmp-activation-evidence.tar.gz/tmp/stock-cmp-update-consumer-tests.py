from pathlib import Path
p=Path('FVTest/Backend/Lowering/StockCmpProductionRuntime.lean');s=p.read_text().replace('funcs.length == 15','funcs.length == 16');p.write_text(s)
p=Path('scripts/check-stock-mixed-integration.py');s=p.read_text().replace('"popcount", "minmax"]','"popcount", "minmax", "cmp"]').replace('"minmax": "MinMaxProduction"','"minmax": "MinMaxProduction", "cmp": "CmpProduction"').replace('"minmax": "stock-minmax"','"minmax": "stock-minmax", "cmp": "stock-cmp"');p.write_text(s)
p=Path('scripts/check-stock-mixed-native.py');s=p.read_text().replace('"popcount", "minmax")','"popcount", "minmax", "cmp")').replace('"popcount", "minmax"]','"popcount", "minmax", "cmp"]').replace('if kind == "minmax":','if kind in ("minmax", "cmp"):')
a=s.index('                                        cases.append(("stock_minmax_ni",args,');b=s.index('                                        cases.append(("retained_popcount"',a)
s=s[:a]+'''                                        minmax_result = signed((count_result & mask) ^ combined,bits)
                                        if kind == "cmp":
                                            specs = [(cc,1,2) for cc in ("eq","ne","slt","sle","sgt","sge","ult","ule","ugt","uge")]
                                            specs += [("eq",1,301),("ne",2,301),("eq",301,1),("ne",301,2),
                                                      ("slt",1,205),("ule",2,302),("sge",1,303),("ugt",2,302),
                                                      ("slt",304,1),("ult",304,2)]
                                            def read(key):
                                                constants = {301:0,302:4097,303:-4097,304:0x123456789abcdef,205:7}
                                                return constants[key] if key in constants else args[key]
                                            cmp_result = minmax_result & mask
                                            for k,(cc,x,y) in enumerate(specs):
                                                a,b = read(x) & mask,read(y) & mask
                                                if cc.startswith("s"):
                                                    a,b = signed(a,bits),signed(b,bits)
                                                relation = cc[1:] if cc[0] in "su" else cc
                                                truth = {"eq":a==b,"ne":a!=b,"lt":a<b,"le":a<=b,"gt":a>b,"ge":a>=b}[relation]
                                                cmp_result ^= (int(truth)*2) << k
                                            cases.append(("stock_cmp_ni",args,signed(cmp_result,bits)))
                                            cases.append(("retained_minmax",args,minmax_result))
                                        else:
                                            cases.append(("stock_minmax_ni",args,minmax_result))
'''+s[b:]
s=s.replace('        if options.kind == "minmax":','''        if options.kind == "cmp":
            wanted = (wanted - {"stock_mixed_ni"}) | {"stock_cmp_ni", "retained_minmax", "retained_popcount", "retained_bit", "retained_cast", "retained_shift", "retained_mul", "retained_not", "retained_constant", "retained_logical", "retained_mixed"}
        elif options.kind == "minmax":''')
p.write_text(s)
