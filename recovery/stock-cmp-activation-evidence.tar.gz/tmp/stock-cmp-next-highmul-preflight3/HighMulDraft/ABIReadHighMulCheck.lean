import FV.Backend.ABIReadScalar
namespace Backend.ABIReadHighMulDraft
def highmulProducer : MInst → Bool
  | .aluRRR .sMulH .size64 (.vreg _ .int) (.vreg _ .int) (.vreg _ .int)
  | .aluRRR .uMulH .size64 (.vreg _ .int) (.vreg _ .int) (.vreg _ .int) => true
  | _ => false

end Backend.ABIReadHighMulDraft
