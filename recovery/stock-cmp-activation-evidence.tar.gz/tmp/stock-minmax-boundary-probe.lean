import FV.E2E.StockMinMaxFixtures
import FV.E2E.StockScalarNI
open Backend Backend.Proof Backend.Proof.Driver
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000

def main : IO Unit := do
  let f := E2E.StockMinMaxNIWitness.function .systemVI64
  IO.println s!"scope={lowerScopeB f} dominated={dominatedB f} abi={sigAbiOk f.sig} source={Stock.Scalar.sourceOk f}"
  match Stock.lower f with
  | .error e => IO.println s!"lower error: {e}"
  | .ok result =>
    IO.println s!"legacy={lowerCheck f result.code} scalar={Stock.Scalar.check f result.code} boundary={E2E.ScalarBoundary.check f.sig result.code}"
    for bi in [:result.code.blocks.size] do
      let b := result.code.blocks[bi]!
      for ki in [:b.insts.size] do
        let i := b.insts[ki]!
        unless Backend.ABIReadScalar.instruction f.sig bi ki i do
          IO.println s!"unsupported boundary {bi}:{ki}: {repr i}"
