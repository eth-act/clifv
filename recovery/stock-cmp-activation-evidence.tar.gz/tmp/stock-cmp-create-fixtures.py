from pathlib import Path
fixture='''import FV.E2E.StockMinMaxFixtures
namespace E2E.StockCmpNIWitness
open Backend.Stock.D0
set_option autoImplicit false
set_option Elab.async false

/-- Every original integer condition, plus both zero sides, adjusted immediates
and nonencodable constants. Each result contributes distinct observable bits. -/
def comparisons : List (Clif.IntCC × Nat × Nat) :=
  [(.eq,1,2),(.ne,1,2),(.slt,1,2),(.sle,1,2),(.sgt,1,2),(.sge,1,2),
   (.ult,1,2),(.ule,1,2),(.ugt,1,2),(.uge,1,2),
   (.eq,1,301),(.ne,2,301),(.eq,301,1),(.ne,301,2),
   (.slt,1,205),(.ule,2,302),(.sge,1,303),(.ugt,2,302),(.slt,304,1),(.ult,304,2)]

def extraBody (config : Configuration) : List Clif.Stmt :=
  let ty := valueType config
  [⟨[301],.iconst ty (BitVec.ofNat ty.width 0)⟩,
   ⟨[302],.iconst ty (BitVec.ofNat ty.width 4097)⟩,
   ⟨[303],.iconst ty (BitVec.ofInt ty.width (-4097))⟩,
   ⟨[304],.iconst ty (BitVec.ofNat ty.width 0x123456789abcdef)⟩] ++
  comparisons.zipIdx.flatMap fun ((cc,x,y),k) =>
    let base := 1000+10*k
    let previous := if k = 0 then 226 else 1000+10*(k-1)+6
    [⟨[base],.icmp cc ty x y⟩,
     ⟨[base+1],.extend .uextend ty base⟩,
     ⟨[base+2],.extend .sextend ty base⟩,
     ⟨[base+3],.binary .iadd ty (base+1) (base+2)⟩,
     ⟨[base+4],.iconst ty (BitVec.ofNat ty.width k)⟩,
     ⟨[base+5],.binary .ishl ty (base+3) (base+4)⟩,
     ⟨[base+6],.binary .bxor ty previous (base+5)⟩]

def function (config : Configuration) : Clif.Function :=
  let old := StockMinMaxNIWitness.function config
  {old with name := "stock_cmp_ni",blocks := old.blocks.map fun b =>
    {b with body := b.body ++ extraBody config,term := .ret [1196]}}

def resultValue (config : Configuration) (input : Nat → BitVec (valueType config).width) :
    BitVec (valueType config).width :=
  let width := (valueType config).width
  let read := fun key =>
    if key = 301 then BitVec.ofNat width 0
    else if key = 302 then BitVec.ofNat width 4097
    else if key = 303 then BitVec.ofInt width (-4097)
    else if key = 304 then BitVec.ofNat width 0x123456789abcdef
    else if key = 205 then BitVec.ofNat width 7
    else input key
  comparisons.zipIdx.foldl (fun acc ((cc,x,y),k) =>
    let b := Clif.Sem.icmp cc (read x) (read y)
    let doubled := Clif.Sem.binary .iadd (Clif.Sem.uextend width b) (Clif.Sem.sextend width b)
    acc ^^^ Clif.Sem.binary .ishl doubled (BitVec.ofNat width k))
    (StockMinMaxNIWitness.resultValue config input)
end E2E.StockCmpNIWitness
'''
Path('FV/E2E/StockCmpFixtures.lean').write_text(fixture)
s=Path('FV/E2E/StockMinMaxWitness.lean').read_text().replace('StockMinMax','StockCmp').replace('StockPopcount','StockMinMax').replace('MinMaxBody','CmpBody').replace('domain_of_minmax','domain_of_cmp').replace('minmaxRoots','cmpRoots').replace('[226]','[1196]').replace(' 98 ⟨frame',' 242 ⟨frame')
a=s.index('  · dsimp only [extraBody]');b=s.index('\n/-- Actual checked',a)
s=s[:a]+'''  · have checked : (extraBody config).all Backend.Stock.Scalar.cmpBodyEligible = true := by
      cases config <;> rfl
    exact Backend.Stock.Scalar.cmpBodyEligible_sound (List.all_eq_true.mp checked stm minmax)
'''+s[b:]
s=s.replace('[796,797,798,799]','[811,819,958]')
s=s.replace('min/max','comparison').replace('all four signed/unsigned comparison','direct and fused comparison')
s=s.replace('  code.any (fun i => match i with | .aluRRImm12 .subS _ .xzr _ _ => true | _ => false)','  code.any (fun i => match i with | .aluRRImm12 .subS _ .xzr _ _ => true | _ => false) &&\n  code.any (fun i => match i with | .cset (.vreg _ .int) _ => true | _ => false)')
Path('FV/E2E/StockCmpWitness.lean').write_text(s)
for suffix in ['Runtime','Linked']:
 s=Path('FVTest/Backend/Lowering/StockMinMaxProduction'+suffix+'.lean').read_text().replace('StockMinMax','StockCmp').replace('stock_minmax','stock_cmp').replace('STOCK_MINMAX','STOCK_CMP').replace('minmax','cmp').replace('min/max','comparison')
 # Retain the immediately previous production class as an additional remote/native cohort.
 if suffix=='Runtime':
  s=s.replace('  ({E2E.StockPopcountNIWitness.function config','  ({E2E.StockMinMaxNIWitness.function config with name := "retained_minmax"}).print ++ "\\n" ++\n  ({E2E.StockPopcountNIWitness.function config',1).replace('pf.funcs.length == 15','pf.funcs.length == 16')
 Path('FVTest/Backend/Lowering/StockCmpProduction'+suffix+'.lean').write_text(s)
