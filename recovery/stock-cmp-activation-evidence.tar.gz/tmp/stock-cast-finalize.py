from pathlib import Path
import json,hashlib,subprocess,datetime,re
root=Path.cwd();head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
records=[]
for group in ['normal','native','owned','integration','full','retention']:
 m=read('/tmp/stock-cast-'+group+'-manifest.json');assert m['candidate']==head
 for g in m['gates']:
  r=read('/tmp/stock-cast-'+group+'-author/'+g['id']+'.json');assert r['state']=='passed' and r['returncode']==0,g['id'];assert r['source_head']==head
  assert sha(r['log'])==r['log_sha256']
  for p,h in r['outputs'].items():assert sha(p)==h,p
  records.append(r)
for kind in ['cast','shift']:
 path=Path('/tmp/stock-cast-integration-author')/kind;r=read(path/'receipt.json');assert r['state']=='passed' and len(r['records'])==32 and r['head']==head
 assert all(x['returncode']==0 and sha(x['log'])==x['sha256'] for x in r['records'].values())
 for field,folder in [('generated_sources',path/'linked'),('linked_artifacts',path/'linked'),('cli_sources',path)]:
  for n,h in r[field].items():assert sha(folder/n)==h
retained=read('/tmp/stock-cast-retention-author/retained/receipt.json');assert retained['state']=='passed';assert all(x.get('files_untouched',True) for x in retained['records'].values())
parity=read('/tmp/stock-cast-identity-stage-parity.json');assert all(x['current']==1159 and x['all_original_and_prior_identities_and_ordered_stages_preserved'] for x in parity.values())
ax=read('/tmp/stock-cast-axiom-parity.json');assert ax['exact_old_required_axiom_sets_preserved'] and ax['baseline_roots']==1470
headers=read('/tmp/stock-cast-header-parity.json');assert headers['unchanged'] and headers['old_public_headers']==43
review=read('/tmp/stock-cast-mcp-review.json');assert not review['isError'] and not review['structuredContent']['warnings'];assert set(review['structuredContent']['axioms'])=={'propext','Classical.choice','Quot.sound'}
owned=[r for r in records if r['id'].startswith('owned-')];primary=[r for r in records if not r['id'].startswith('owned-')];assert len(primary)==18 and len(owned)==15
ownedlog=Path(next(r for r in owned if r['id']=='owned-0')['log']).read_text();core,witness=map(int,re.search(r'STANDARD_CORE (\d+); FIXED_WITNESSES (\d+)',ownedlog).groups())
normal=Path(next(r for r in primary if r['id']=='all-normal-library-keys')['log']).read_text();normalkeys=int(re.search(r'All targets up-to-date \((\d+) jobs\)',normal)[1])
native=read('/tmp/stock-cast-native-author/native/native-receipt.json');assert native['state']=='passed' and native['failures']==native['disagreements']==0;assert sha(root/'rust/target/release/clif-native')==native['native_binary_sha256'];assert native['lean_byte_executions']==1680
receipt={'state':'per_pr_gates_passed','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'validated_source_head':head,'base_main':'4966cf92f6be6d981b3600410708c5cd89cd9b36','primary_gate_count':len(primary),'primary_gate_records':primary,'owned_gate_records':owned,'owned_core_constants':core,'owned_fixed_witness_constants':witness,'exact_declared_native_facts':27,'core_owners':149,'witness_owners':26,'executable_owners':14,'normal_scheduled_modules':2739,'normal_library_jobs':normalkeys,'checked_in_audits':50,'audited_roots':ax['current_roots'],'mcp_review':review,'parity':{'axiom_sets':ax,'old_headers':headers},'identity_stage_parity':parity,'native_execution':native,'old_native_expected_vectors_preserved':read('/tmp/stock-cast-native-grid-retention.json'),'actual_source_opcode_candidates':{'Uextend':[810,811,815,808],'Sextend':[824,819],'Ireduce':[946]},'executed_base_roots':[808,819,946],'lookthrough_excluded_by_proved_original_source_family':[810,811,815,824],'complete_witness_in_all_six_ABIs_and_both_cleanup_modes':True,'arbitrary_source_inputs_and_original_slot_witness':True,'signed_extension_high_bits_remain_live':True,'retained_original_flat_multiply':retained,'verified_examples':{'fv-demo':{'tests':21,'verified_binaries':2},'survey':{'tests':53,'verified_binaries':18}},'full_original_140_complete':False,'next':'Counts, reversals and rotations; then every remaining original140 obligation.'}
Path('/tmp/stock-cast-terminal-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print('passed',len(primary),'primary/',len(owned),'ownership;',normalkeys,'normal keys;',core,'Std3/',witness,'fixed witnesses')
