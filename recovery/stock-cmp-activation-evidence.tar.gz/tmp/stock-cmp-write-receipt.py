from pathlib import Path
import json,datetime
r=json.loads(Path('/tmp/stock-cmp-terminal-receipt.json').read_text());backup=json.loads(Path('/tmp/stock-cmp-activation-backup/metadata.json').read_text());r['remote_backup']=backup
p=Path('docs/research/stock-cmp-production-activation.json');p.write_text(json.dumps(r,indent=2)+'\n')
text=f'''# Stock comparison production activation

Validated source `{r['validated_source_head']}` reconciles main `{r['base_main']}`.
Default shared Scalar compiler, checker, linker and generated-proof consumers
accept i32/i64 integer comparisons mixed with every previously shipped class.
The original #140 goal remains unfinished.

Actual cast-of-icmp root811 follows the real original definition and original
operands. Restricted DFG derives their availability and types; actual helper
calls derive code and complete scheduling state. Existing comparison numerical
proofs are reused. A final-CSET theorem establishes full zero-extension from the
old low-byte guarantee. Real record allocation, scratch separation, result
binding/final aliases and guarded original-source transfer compose through
mixed scan/body/ABI entry/return. Memory-only cast format variants permit actual
IntCompare look-through; old variants and selectors remain. No Arm/MInst,
allocator, cleanup whitelist or original source-condition changes.

The complete fixture retains every prior computation and exercises all ten
integer conditions, zero on either side, adjusted immediates, large constants,
direct comparisons and fused casts. Both cast records remain live through a
multiplication; an additive draft legitimately absorbed the cast into an add
and was rejected by provenance validation. Actual roots811/819/958 occur in all
six ABIs. Inputs and the original explicit slot are arbitrary. Source transfers
cover8/16/32/64; this production classifier remains32/64. Broader original widths
and ABIs stay on the full-goal list.

Generated entry-presence proofs keep their original public statement and checks.
A private Boolean with a scoped opaque native certificate prevents elaboration
from expanding the full 33-function pipeline at the default heartbeat limit.
The integration audit recovers private declarations' owning namespaces and
still permits only owned fixed native facts plus standard axioms. The actual
certificate passes; foreign and non-native negative controls are rejected.
Earlier failed elaboration experiments remain preserved as failures.

All {r['primary_gate_count']} primary and {len(r['owned_gate_records'])} ownership gates pass on the frozen source:

- {r['normal_library_jobs']} normal library keys / {r['normal_scheduled_modules']} modules; {r['checked_in_audits']} checked-in audits / {r['audited_roots']} theorem roots.
- All1601 prior required axiom sets and35 old public headers exact. {r['owned_core_constants']} owned core constants use only the standard axioms; {r['owned_fixed_witness_constants']} fixed witness constants use only the declared35 exact native facts. {r['core_owners']} core,30 witness and22 executable owners.
- 24 actual encoded objects,2640 QEMU comparisons and660 Cranelift references,0 failures/disagreements. All ten prior native grids exact.
- Actual current-comparison and retained-min/max CLI/checker/link/generated-proof cohorts each pass32 checks. Native fixture binary hashes are frozen; generated proofs compile freshly.
- Original flat-multiply bytes and sources retained, with current proofs. Runtime4737/0/0 with the same7 known non-runnable cases; encoder1321 identical/0 differ.
- Both E2E modes1159 accepted/0 rejected. All original1150 and prior1159 identities and ordered stages retained. Verified demo21 tests/2 binaries and survey53 tests/18 binaries.
- One bundled MCP domain review: standard axioms, no warnings. Failed drafts remain backed and are not validation passes.

Terminal evidence is remotely backed at `{backup['backup_commit']}` on
`{backup['backup_branch']}`. Archive SHA256 `{backup['archive_sha256']}`;
{backup['archive_bytes']:,} bytes / {backup['files']} files. The adjacent JSON records
command/input/output/log hashes and provenance.

Successful `Stock.lower` remains a correctness premise. This is neither universal
request/lowering completeness nor completion of #140. Next: high multiplication,
division/remainder, complete original widths/ABIs, and all remaining control,
memory, traps, effects, calls, source/block/whole-driver simulation, completeness
and consumer obligations. Legacy fallback is not Stock completeness.
'''
Path('docs/research/stock-cmp-production-activation.md').write_text(text)
p=Path('docs/plans/stock-driver-incremental-delivery.md');s=p.read_text();needle='Next: integer comparisons and actual cast-of-icmp811; high multiply/division/'
assert needle in s
insert=f'''Integer comparisons and real cast-of-icmp811 pass author gates through shared
production consumers. [Terminal evidence](../research/stock-cmp-production-activation.md)
records22 primary/23 ownership gates,{r['audited_roots']} audited roots, all1601 prior axiom sets/
35 headers exact and2640 native comparisons. Both current/retained actual
consumer cohorts pass32 checks. Validated `{r['validated_source_head'][:8]}`;
remote terminal evidence `{backup['backup_commit'][:8]}`. Real CSET normalization,
restricted original DFG operands, actual retained binding and memory-only cast
variants compose mixed body/entry/return without excluding IntCompare syntax.
Existing comparison numerical/helper proofs and all old theorem variants remain.
All original identities/stages and ten prior native grids are retained.

Next: high multiply/division/'''
s=s.replace(needle,insert);s=s.replace('Next: remaining pure scalar classes, starting with constants and NOT/fused logical\nforms, using saved guarded bridges and existing body/consumer composition.', 'Continue remaining pure scalar classes, starting with high multiplication and\ndivision/remainder, using complete saved source wrappers and shared consumer composition.');p.write_text(s)
p=Path('docs/research/stock-driver-obligations.json');d=json.loads(p.read_text());d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['complete']=False
d['production']['landed']=[x.replace(' (validated, squash pending)','') for x in d['production']['landed']]
d['production']['landed'].append('i32/i64 integer comparisons and actual cast-of-icmp811 through shared scalar consumers (validated, squash pending)')
d['production']['pending']=r['next']
for item in d['roots']:
 if item['id'] in [811,958]:
  item['saved_guarded_bridge']='FV/Backend/Proof/StockCastCmpSourceValues.lean' if item['id']==811 else 'FV/Backend/Proof/StockCmpActualDispatch.lean'
  item['status']='actual source/retained record, guarded scan/body/entry-return and default shared production consumers validated; Stock-only completeness remains'
  item['production_evidence']='docs/research/stock-cmp-production-activation.json'
  item['stock_only_completeness']=False
  if item['id']==811:item['cast_class_exclusion']='Old CastBody.SafeFormat variants retained; broader memory-only variants execute real IntCompare look-through.'
p.write_text(json.dumps(d,indent=2)+'\n')
print('Wrote comparison receipt, current plan and obligation ledger; original140 remains incomplete.')
