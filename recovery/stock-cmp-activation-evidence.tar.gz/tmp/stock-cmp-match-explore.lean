import FV.E2E.StockCmpFixtures
import FV.Backend.Proof.StockCastCmpMatch
open Backend Isle Isle.Interp Isle.Aarch64
#eval do
  let f := E2E.StockCmpNIWitness.function .systemVI64
  match Stock.buildCtx f with
  | .error e => IO.println e
  | .ok (ctx,_,st) =>
    IO.println s!"def={ctx.defInst? 1000} xType={repr (ctx.valueType? 1)}"
    IO.println s!"cmp={repr ctx.insts[101]!.data}, res={repr ctx.insts[101]!.resTys}"
    IO.println s!"ext={repr ctx.insts[102]!.data}, res={repr ctx.insts[102]!.resTys}"
    let m := (matchRule program (Stock.sem ctx) {} 1000 rule_lower_1281 [.inst 102]).run (st,#[])
    match m with
    | .error e => IO.println s!"error={repr e}"
    | .ok (v,_,_) => IO.println s!"match={repr v}"
    match (evalExpr program (Stock.sem ctx) {} 999999 rule_lower_1281.rhs (Stock.Proof.ScalarCmp.cmpEnv .eq 1 2)).run (st,#[]) with
    | .error e => IO.println s!"rhs error={repr e}"
    | .ok (v,_,trace) => IO.println s!"rhs={repr v}; trace={trace}"
