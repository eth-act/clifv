from pathlib import Path
r=Path('FV/E2E')
(r/'StockMinMaxFixtures.lean').write_text('''import FV.E2E.StockPopcountFixtures
namespace E2E.StockMinMaxNIWitness
open Backend.Stock.D0
set_option autoImplicit false
set_option Elab.async false

def extraBody (config : Configuration) : List Clif.Stmt :=
  let ty := valueType config
  [⟨[201],.binary .smin ty 1 2⟩,⟨[202],.binary .smax ty 1 8⟩,
   ⟨[203],.binary .umin ty 2 3⟩,⟨[204],.binary .umax ty 0 8⟩,
   ⟨[205],.iconst ty (BitVec.ofNat ty.width 7)⟩,
   ⟨[206],.iconst ty (BitVec.ofNat ty.width 0x123456789abcdef)⟩,
   ⟨[207],.binary .smin ty 1 205⟩,⟨[208],.binary .smax ty 2 205⟩,
   ⟨[209],.binary .umin ty 8 205⟩,⟨[210],.binary .umax ty 0 205⟩,
   ⟨[211],.binary .smin ty 206 1⟩,⟨[212],.binary .smax ty 206 2⟩,
   ⟨[213],.binary .umin ty 206 8⟩,⟨[214],.binary .umax ty 206 0⟩,
   ⟨[215],.binary .iadd ty 201 202⟩,⟨[216],.binary .bxor ty 215 203⟩,
   ⟨[217],.binary .iadd ty 216 204⟩,⟨[218],.binary .bxor ty 217 207⟩,
   ⟨[219],.binary .iadd ty 218 208⟩,⟨[220],.binary .bxor ty 219 209⟩,
   ⟨[221],.binary .iadd ty 220 210⟩,⟨[222],.binary .bxor ty 221 211⟩,
   ⟨[223],.binary .iadd ty 222 212⟩,⟨[224],.binary .bxor ty 223 213⟩,
   ⟨[225],.binary .iadd ty 224 214⟩,⟨[226],.binary .bxor ty 78 225⟩]

def function (config : Configuration) : Clif.Function :=
  let old := StockPopcountNIWitness.function config
  {old with name := "stock_minmax_ni", blocks := old.blocks.map fun b =>
    {b with body := b.body ++ extraBody config, term := .ret [226]}}

def resultValue (config : Configuration) (input : Nat → BitVec (valueType config).width) :
    BitVec (valueType config).width :=
  let small := BitVec.ofNat (valueType config).width 7
  let large := BitVec.ofNat (valueType config).width 0x123456789abcdef
  let a := Clif.Sem.binary .smin (input 1) (input 2)
  let b := Clif.Sem.binary .smax (input 1) (input 8)
  let c := Clif.Sem.binary .umin (input 2) (input 3)
  let d := Clif.Sem.binary .umax (input 0) (input 8)
  let e := Clif.Sem.binary .smin (input 1) small
  let f := Clif.Sem.binary .smax (input 2) small
  let g := Clif.Sem.binary .umin (input 8) small
  let h := Clif.Sem.binary .umax (input 0) small
  let i := Clif.Sem.binary .smin large (input 1)
  let j := Clif.Sem.binary .smax large (input 2)
  let k := Clif.Sem.binary .umin large (input 8)
  let l := Clif.Sem.binary .umax large (input 0)
  let mixed := ((((((((((a+b) ^^^ c)+d) ^^^ e)+f) ^^^ g)+h) ^^^ i)+j) ^^^ k)+l
  StockPopcountNIWitness.resultValue config input ^^^ mixed
end E2E.StockMinMaxNIWitness
''')
s=(r/'StockPopcountWitness.lean').read_text().replace('StockPopcountFixtures','StockMinMaxFixtures').replace('import FV.E2E.StockBitWitness','import FV.E2E.StockPopcountWitness').replace('namespace E2E.StockPopcountNIWitness','namespace E2E.StockMinMaxNIWitness').replace('end E2E.StockPopcountNIWitness','end E2E.StockMinMaxNIWitness').replace('Stock.Proof.PopcountBody.Family','Stock.Proof.MinMaxBody.Family').replace('Stock.Scalar.domain_of_popcount','Stock.Scalar.domain_of_minmax').replace('[78]','[226]').replace('} 71 ⟨','} 97 ⟨')
a=s.index('  change stm ∈');z=s.index('\n/-- Actual checked',a)
s=s[:a]+'''  change stm ∈ (E2E.StockPopcountNIWitness.function config).blocks[0]!.body ++ extraBody config at member
  rcases List.mem_append.mp member with old | minmax
  · exact Or.inl (E2E.StockPopcountNIWitness.source_family config stm old)
  · dsimp only [extraBody] at minmax
    simp only [List.mem_cons,List.not_mem_nil,or_false] at minmax
    rcases minmax with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first
      | exact .inr ⟨false,false,_,_,_,rfl⟩
      | exact .inr ⟨false,true,_,_,_,rfl⟩
      | exact .inr ⟨true,false,_,_,_,rfl⟩
      | exact .inr ⟨true,true,_,_,_,rfl⟩
      | exact .inl (.inl (.inl (.inl (.inl (.inl (.inl (.inr ⟨_,_,rfl⟩)))))))
      | exact .inl (.inl (.inl (.inl (.inl (.inl (.inl (.inl (.inr (.inr ⟨.bxor,_,_,_,rfl⟩)))))))))
      | exact .inl (.inl (.inl (.inl (.inl (.inl (.inl (.inl (.inl (.inr (.inl (.inl ⟨_,_,rfl⟩)))))))))))
'''+s[z:]
s=s.replace('def popcountRoots','def minmaxRoots').replace('popcountRoots config','minmaxRoots config').replace('popcountRootsCovered','minmaxRootsCovered')
a=s.index('def minmaxRoots (');z=s.index('\ndef minmaxRootsCovered',a)
s=s[:a]+'''def minmaxRoots (_config : Backend.Stock.D0.Configuration) : List Nat := [796,797,798,799]
'''+s[z:]
s=s.replace('Actual retained roots for scalar popcount.','Actual retained roots for all four signed/unsigned min/max operations.').replace('Every ABI selects the actual scalar popcount root.','Every ABI selects all four original min/max roots.')
(r/'StockMinMaxWitness.lean').write_text(s)
p=Path('FVTest/Backend/Lowering')
s=(p/'StockPopcountProductionRuntime.lean').read_text().replace('StockPopcount','StockMinMax').replace('STOCK_POPCOUNT_NATIVE_OUT','STOCK_MINMAX_NATIVE_OUT').replace('== 14','== 15').replace('Stock popcount','Stock minmax').replace('popcount fixture','min/max fixture')
a=s.index('  ({E2E.StockBitNIWitness.function')
s=s[:a]+'''  ({E2E.StockPopcountNIWitness.function config with name := "retained_popcount"}).print ++ "\\n" ++
'''+s[a:]
(p/'StockMinMaxProductionRuntime.lean').write_text(s)
s=(p/'StockPopcountProductionLinked.lean').read_text().replace('StockPopcount','StockMinMax').replace('stock_popcount','stock_minmax');(p/'StockMinMaxProductionLinked.lean').write_text(s)
