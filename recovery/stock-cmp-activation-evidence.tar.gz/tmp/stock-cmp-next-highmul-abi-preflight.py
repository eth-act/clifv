from pathlib import Path
import json,os,subprocess,time
out=Path('/tmp/stock-cmp-next-highmul-preflight3');draft=Path('/tmp/stock-cmp-next-highmul-draft');e=os.environ.copy();e.update(json.load(open('/tmp/stock-cmp-terminal-normal-manifest.json'))['env']);e['LEAN_PATH']=str(out)+':'+str(Path.cwd()/'.lake/build/lib/lean')
s=(draft/'BackendABIReadScalar.lean').read_text();a=s.index('def highmulProducer');b=s.index('\ndef instruction',a)
check='import FV.Backend.ABIReadScalar\nnamespace Backend.ABIReadHighMulDraft\n'+s[a:b]+'\nend Backend.ABIReadHighMulDraft\n'
step=(draft/'ABIReadHighMulSteps.lean').read_text().replace('import FV.Backend.ABIReadScalar','import HighMulDraft.ABIReadHighMulCheck').replace('Backend.ABIReadScalar.highmulProducer','Backend.ABIReadHighMulDraft.highmulProducer')
records=[]
for name,source in [('ABIReadHighMulCheck',check),('ABIReadHighMulSteps',step)]:
 p=out/'HighMulDraft'/(name+'.lean');p.write_text(source);start=time.monotonic()
 with (out/(name+'.log')).open('w') as f:r=subprocess.run(['scripts/memcap.sh','lean','--root='+str(out),'-o',str(p.with_suffix('.olean')),str(p)],env=e,stdout=f,stderr=subprocess.STDOUT)
 records.append({'module':name,'returncode':r.returncode,'seconds':time.monotonic()-start});(out/'abi-records.json').write_text(json.dumps(records,indent=2)+'\n');print(name,r.returncode,flush=True)
 if r.returncode:print((out/(name+'.log')).read_text());raise SystemExit(r.returncode)
