from pathlib import Path
import re,json,subprocess,os
files=[*Path('FV/Backend/Proof').glob('StockCast*.lean'),Path('FV/Backend/Proof/StockScalarCastDomain.lean'),Path('FV/Backend/Proof/StockSourceStatementFamily.lean'),Path('FV/E2E/ABIReadCastSteps.lean'),Path('FV/E2E/StockCastWitness.lean')]
lines=['import FV.E2E.StockCastWitness','']
for p in files:
 scope=''
 for line in p.read_text().splitlines():
  if line.startswith('namespace '):scope=line.split()[1]
  m=re.match(r'theorem (\w+)',line)
  if m:
   name=scope+'.'+m[1];witness=p.name=='StockCastWitness.lean' and m[1] not in ['source_entry','source_returns']
   lines.append('#print axioms '+name+(' -- witness: native_decide' if witness else ''))
for name in ['Backend.Stock.Proof.stock_lower_mixed_shift_record_fall_refines','Backend.Stock.Proof.ShiftBody.emitted_record_family','Backend.Stock.Scalar.castBodyEligible_sound','Backend.Stock.Scalar.sourceOk_sound','Backend.Stock.Scalar.check_sound','E2E.StockShiftNIWitness.source_family']:
 lines.append('#print axioms '+name)
Path('scripts/audit/stock-cast-production.lean').write_text('\n'.join(lines)+'\n');print('audit',len(lines)-2)
