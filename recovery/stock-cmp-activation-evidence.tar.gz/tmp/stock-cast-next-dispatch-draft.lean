import FV.Backend.Proof.StockCastSourceValues
import FV.Backend.Proof.StockReduceSourceValues
import FV.Backend.Proof.StockRootOpcodeMatch
namespace Backend.Stock.Proof.CastComplete
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm

-- Draft only: the current original-source opcode inventory must be kernel checked.
example : sourceOpcodeIds 141 = [810,811,815,808] := by
  unfold sourceOpcodeIds
  rw [show TId.lower = 686 from rfl,data_program.r686]
  decide +kernel
example : sourceOpcodeIds 142 = [824,819] := by
  unfold sourceOpcodeIds
  rw [show TId.lower = 686 from rfl,data_program.r686]
  decide +kernel
example : sourceOpcodeIds 131 = [946] := by
  unfold sourceOpcodeIds
  rw [show TId.lower = 686 from rfl,data_program.r686]
  decide +kernel
end Backend.Stock.Proof.CastComplete
