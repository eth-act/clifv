from pathlib import Path
p=Path('FV/E2E/StockShiftWitness.lean');s=p.read_text();s+='''
namespace E2E.StockShiftNIWitness
/-- Reusable original syntax for subsequent scalar-family extensions. -/
theorem source_family (config : Backend.Stock.D0.Configuration) :
    ∀ stm ∈ (function config).blocks[0]!.body, Backend.Stock.Proof.ShiftBody.Family stm.inst := family config
end E2E.StockShiftNIWitness
''';p.write_text(s)
Path('FV/E2E/StockCastFixtures.lean').write_text('''import FV.E2E.StockShiftFixtures
namespace E2E.StockCastNIWitness
open Backend.Stock.D0
set_option autoImplicit false

/-- Keep the high sign-extension bits observable in the final source result. -/
def extraBody (config : Configuration) : List Clif.Stmt :=
  if valueType config == .i64 then
    [⟨[54],.ireduce .i32 1⟩,⟨[55],.extend .uextend .i64 54⟩,
     ⟨[56],.extend .sextend .i64 54⟩,⟨[57],.binary .bxor .i64 55 56⟩,
     ⟨[58],.iconst .i32 32⟩,⟨[59],.binary .ushr .i64 57 58⟩,
     ⟨[60],.binary .bxor .i64 59 53⟩]
  else
    [⟨[54],.extend .uextend .i64 1⟩,⟨[55],.extend .sextend .i64 1⟩,
     ⟨[56],.binary .bxor .i64 54 55⟩,⟨[57],.iconst .i32 32⟩,
     ⟨[58],.binary .ushr .i64 56 57⟩,⟨[59],.ireduce .i32 58⟩,
     ⟨[60],.binary .bxor .i32 59 53⟩]

def function (config : Configuration) : Clif.Function :=
  let old := StockShiftNIWitness.function config
  {old with name := "stock_cast_ni", blocks := old.blocks.map fun b =>
    {b with body := b.body ++ extraBody config, term := .ret [60]}}

def resultValue (config : Configuration) (input : Nat → BitVec (valueType config).width) :
    BitVec (valueType config).width :=
  let low := (input 1).setWidth 32
  let signs := ((low.zeroExtend 64 ^^^ low.signExtend 64) >>> 32).setWidth (valueType config).width
  signs ^^^ StockShiftNIWitness.resultValue config input
end E2E.StockCastNIWitness
''')
s=Path('FV/E2E/StockShiftWitness.lean').read_text();s=s[:s.rindex('\nnamespace E2E.StockShiftNIWitness\n/-- Reusable')];s=s.replace('StockShift','StockCast').replace('import FV.E2E.StockMulWitness','import FV.E2E.StockShiftWitness').replace('domain_of_shift','domain_of_cast').replace('[53]','[60]').replace('} 46 ⟨','} 53 ⟨')
a=s.index('private theorem family');b=s.index('/-- Actual checked/allocated',a)
s=s[:a]+'''private theorem family (config : Configuration) :
    ∀ stm ∈ (function config).blocks[0]!.body, Stock.Proof.CastBody.Family stm.inst := by
  intro stm member
  change stm ∈ (E2E.StockShiftNIWitness.function config).blocks[0]!.body ++ extraBody config at member
  rcases List.mem_append.mp member with old | cast
  · exact Or.inl (E2E.StockShiftNIWitness.source_family config stm old)
  · unfold extraBody at cast
    split at cast
    all_goals
      simp only [List.mem_cons,List.not_mem_nil,or_false] at cast
      rcases cast with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first
      | exact .inr (.inl ⟨_,_,_,rfl⟩)
      | exact .inr (.inr ⟨_,_,rfl⟩)
      | exact .inl (.inr ⟨.lsr,_,_,_,rfl⟩)
      | exact .inl (.inl (.inl (.inl (.inr ⟨_,_,rfl⟩))))
      | exact .inl (.inl (.inl (.inl (.inl (.inr (.inr ⟨.bxor,_,_,_,rfl⟩))))))

'''+s[b:]
a=s.index('def shiftRoots (');b=s.index('\ndef shiftRootsCovered',a);s=s[:a]+'''def castRoots (_config : Backend.Stock.D0.Configuration) : List Nat := [808,819,946]
'''+s[b:];s=s.replace('shiftRoots','castRoots');Path('FV/E2E/StockCastWitness.lean').write_text(s)
for part in ['Runtime','Linked']:
 p=Path('FVTest/Backend/Lowering/StockShiftProduction'+part+'.lean');s=p.read_text().replace('StockShift','StockCast').replace('stock_shift','stock_cast').replace('STOCK_SHIFT','STOCK_CAST').replace('Stock shift','Stock cast')
 if part=='Runtime':
  s=s.replace('(E2E.StockCastNIWitness.function config).print ++ "\\n" ++','(E2E.StockCastNIWitness.function config).print ++ "\\n" ++\n  ({E2E.StockShiftNIWitness.function config with name := "retained_shift"}).print ++ "\\n" ++').replace('== 11','== 12')
 Path('FVTest/Backend/Lowering/StockCastProduction'+part+'.lean').write_text(s)
