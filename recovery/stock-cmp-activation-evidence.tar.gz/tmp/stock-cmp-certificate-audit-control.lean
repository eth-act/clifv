import Lean
import «stock-cmp-entry-opaque-bool-certificate»
open Lean Elab Command in
run_cmd do
  let generated := fun (name : Name) =>
    let owner := (privateToUserName? name).getD name
    owner.toString.startsWith "Crates.StockCmpProduction" || owner.toString.startsWith "Crates.CmpProductionCLI"
  let permitted := fun (ax : Name) =>
    #[``propext, ``Classical.choice, ``Quot.sound].contains ax ||
      (generated ax && (ax.toString.splitOn "._native.native_decide.ax_").length > 1)
  let axs ← collectAxioms ``Crates.StockCmpProduction33CleanupFallbackEntries.entries_present
  for ax in axs do
    unless permitted ax do throwError "rejected actual owned fact {ax}"
  unless axs.any (fun ax => isPrivateName ax && generated ax) do
    throwError "positive control did not exercise an actual private owned fact"
  for ax in #[`Crates.Other._native.native_decide.ax_1_1,
      `Crates.StockCmpProduction.injected_axiom,
      mkPrivateNameCore `Bad `Crates.Other._native.native_decide.ax_1_1,
      mkPrivateNameCore `Bad `Crates.StockCmpProduction.injected_axiom] do
    if permitted ax then throwError "accepted negative control {ax}"
  logInfo "OWNED_PRIVATE_NATIVE_AND_FOREIGN_NEGATIVE_CONTROLS_PASS"
