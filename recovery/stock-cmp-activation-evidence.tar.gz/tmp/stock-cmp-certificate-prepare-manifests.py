from pathlib import Path
import json,subprocess
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
for group in ['normal','native','full','retention','integration','minmax-integration','owned']:
 p=Path('/tmp/stock-cmp-'+group+'-manifest.json');m=json.loads(p.read_text());m.update(candidate=head,base='031df150fa2aeb626906814783011a805b4ae92b',packet='cmp-certificate-production-'+group)
 if group=='normal':
  for g in m['gates']:
   if g['id']=='all-trust-audits':g['argv'][-1]='/tmp/stock-cmp-certificate-final-audits'
 Path('/tmp/stock-cmp-certificate-'+group+'-manifest.json').write_text(json.dumps(m,indent=2)+'\n')
# Keep the original failed canonical directories intact; every group gets new paths.
s=Path('/tmp/stock-cmp-finalize.py').read_text()
s=s.replace("'/tmp/stock-cmp-'+group+'-manifest.json'","'/tmp/stock-cmp-certificate-'+group+'-manifest.json'").replace("'/tmp/stock-cmp-'+group+'-author/'","'/tmp/stock-cmp-certificate-'+group+'-author/'")
for group in ['integration','minmax-integration','retention','native','full']:
 s=s.replace('/tmp/stock-cmp-'+group+'-author/','/tmp/stock-cmp-certificate-'+group+'-author/')
s=s.replace("'/tmp/stock-cmp-reconciled-impact-module-plan.json'","'/tmp/stock-cmp-certificate-module-plan.json'").replace("'base_main':'e95bb871'","'base_main':'031df150fa2aeb626906814783011a805b4ae92b'")
Path('/tmp/stock-cmp-certificate-finalize.py').write_text(s)
# Fresh identity comparison, still against original and prior min/max snapshots.
s=Path('/tmp/stock-cmp-identity-parity.py').read_text().replace('/tmp/stock-cmp-full-author/','/tmp/stock-cmp-certificate-full-author/');Path('/tmp/stock-cmp-certificate-identity-parity.py').write_text(s)
p=Path('/tmp/stock-cmp-header-parity.py');s=p.read_text().replace("base='e95bb871'","base='031df150fa2aeb626906814783011a805b4ae92b'");Path('/tmp/stock-cmp-certificate-header-parity.py').write_text(s)
print(head)
