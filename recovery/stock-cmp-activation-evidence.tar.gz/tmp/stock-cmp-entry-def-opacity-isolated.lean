import FV.Backend.Lowering.StockScalarNI
import FV.E2E.SemanticChecksWith
import FV.E2E.SemanticStackBound
import Crates.StockCmpProduction33CleanupFallbackEntries.Slice0
import Crates.StockCmpProduction33CleanupFallbackEntries.Slice1
import FV.E2E.StackBound
namespace Crates.StockCmpProduction33CleanupFallbackEntries
open E2E E2E.LinkCheck E2E.BinCheck
def checkedResults := compilerInput.results
section
attribute [local irreducible] checkedResults
theorem entries_present :
    ["actual_stock_cmp_0", "actual_stock_cmp_1", "actual_stock_cmp_2", "actual_stock_cmp_3", "actual_stock_cmp_4", "actual_stock_cmp_5", "actual_stock_cmp_6", "actual_stock_cmp_7", "actual_stock_cmp_8", "actual_stock_cmp_9", "actual_stock_cmp_10", "actual_stock_cmp_11", "actual_stock_cmp_12", "actual_stock_cmp_13", "actual_stock_cmp_14", "actual_stock_cmp_15", "actual_stock_cmp_16", "actual_stock_cmp_17", "actual_stock_cmp_18", "actual_stock_cmp_19", "actual_stock_cmp_20", "actual_stock_cmp_21", "actual_stock_cmp_22", "actual_stock_cmp_23", "actual_stock_cmp_24", "actual_stock_cmp_25", "actual_stock_cmp_26", "actual_stock_cmp_27", "actual_stock_cmp_28", "actual_stock_cmp_29", "actual_stock_cmp_30", "actual_stock_cmp_31", "actual_stock_cmp_32"].all
      (fun n => ((progOf checkedResults).func? n).isSome) = true := by native_decide
end

#print axioms entries_present
end Crates.StockCmpProduction33CleanupFallbackEntries
