from pathlib import Path
import json
r=json.loads(Path('/tmp/stock-cmp-terminal-receipt.json').read_text());b=json.loads(Path('/tmp/stock-cmp-activation-backup/metadata.json').read_text())
body=f'''Functions containing i32/i64 comparisons, including comparison results consumed by zero-extension, now use the proved Stock scalar route through the default compiler, checker, linker and generated-proof consumers. The class composes with every previously activated scalar operation.

The proof reuses existing comparison arithmetic and helper lemmas. It derives original operands/types, retained result binding, scratch separation and guarded source transfer from actual selected records. A final-CSET lemma establishes the full destination value needed by cast root 811. Broader memory-only cast variants permit IntCompare look-through; all older theorem variants and selectors remain. No Arm/MInst, allocator or cleanup whitelist changes.

Generated entry checks retain their public statements and default heartbeat limit using a private Boolean certificate. The generated-proof audit recovers private ownership while retaining its namespace and native-fact restrictions; actual-certificate and foreign/non-native controls pass.

Validation on `{r['validated_source_head']}`, reconciled with main `{r['base_main']}`:

- 22 primary gates and 23 ownership partitions passed; {r['normal_library_jobs']:,} normal library keys; {r['checked_in_audits']} audits covering {r['audited_roots']:,} roots. All 1,601 prior axiom sets and 35 public headers are exact. All {r['owned_core_constants']:,} owned core constants use standard axioms; fixed witnesses use the declared 35 exact native facts.
- Complete witnesses cover all six ABIs, both cleanup modes, arbitrary inputs/slot, and actual roots 811/819/958. Native execution: 24 objects, 2,640 QEMU comparisons, 660 Cranelift references, zero failures/disagreements; ten prior grids unchanged.
- Current comparison and retained min/max CLI/link/generated-proof cohorts each passed 32/32. Original flat-multiply artifacts remain untouched and pass current proof reconstruction. One bundled MCP review passed with standard axioms and no warnings.
- Runtime 4,737/0/0 with the same seven non-runnable cases; encoder 1,321 identical/0 different; both E2E modes 1,159 accepted/0 rejected, preserving original/prior identities and ordered stages. Verified demo: 21 tests/2 binaries; survey: 53 tests/18 binaries.

Receipt: `docs/research/stock-cmp-production-activation.md` and adjacent JSON. Terminal evidence is remotely backed at `{b['backup_commit']}`; archive SHA256 `{b['archive_sha256']}`.

Full original #140 remains open. Successful Stock.lower is still a correctness premise; universal Stock lowering/downstream completeness and remaining widths, ABIs, control, memory, traps, effects, calls and whole-driver obligations remain. Next packet: high multiplication using the existing complete source transfer.

Refs #140, #44.
'''
Path('/tmp/stock-cmp-pr-body.md').write_text(body)
