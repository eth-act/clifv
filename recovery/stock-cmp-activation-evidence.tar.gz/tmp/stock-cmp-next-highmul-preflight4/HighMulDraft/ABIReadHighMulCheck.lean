import FV.Backend.ABIReadScalar
namespace Backend.ABIReadHighMulDraft
def highmulProducer : MInst → Bool
  | .aluRRR .sMulH .size64 (.vreg _ .int) (.vreg _ .int) (.vreg _ .int)
  | .aluRRR .uMulH .size64 (.vreg _ .int) (.vreg _ .int) (.vreg _ .int) => true
  | _ => false

def instruction (sig : Clif.Signature) (b k : Nat) (i : MInst) : Bool :=
  ABIReadFlags.instruction sig b k i || ABIReadScalar.constant i || ABIReadScalar.shift i || ABIReadScalar.extension i || ABIReadScalar.bitProducer i || ABIReadScalar.popcountProducer i || ABIReadScalar.comparisonProducer i || ABIReadScalar.booleanProducer i || highmulProducer i
def check (sig : Clif.Signature) (vc : VCode) : Bool :=
  vc.blocks.toList.zipIdx.all fun (block,b) =>
    block.insts.toList.zipIdx.all fun (i,k) => instruction sig b k i
end Backend.ABIReadHighMulDraft
