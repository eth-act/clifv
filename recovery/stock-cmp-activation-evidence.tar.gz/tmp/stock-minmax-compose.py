from pathlib import Path
r=Path('FV/Backend/Proof')
s=(r/'StockPopcountFamily.lean').read_text().replace('import FV.Backend.Proof.StockBitFamily','import FV.Backend.Proof.StockPopcountFamily').replace('import FV.Backend.Proof.StockPopcountSourceValues','import FV.Backend.Proof.StockMinMaxActualDispatch\nimport FV.Backend.Proof.StockAvailableTypes').replace('namespace Backend.Stock.Proof.PopcountBody','namespace Backend.Stock.Proof.MinMaxBody').replace('end Backend.Stock.Proof.PopcountBody','end Backend.Stock.Proof.MinMaxBody')
s=s.replace('def Family (inst','abbrev operation := ScalarSelect.MinMaxRegisterFixture.minmaxOperation\n\ndef Family (inst').replace('BitBody.Family inst ∨ ∃ ty x, inst = .unary .popcnt ty x','PopcountBody.Family inst ∨ ∃ unsigned maximum ty x y, inst = .binary (operation unsigned maximum) ty x y')
s=s.replace('old | ⟨ty,x,rfl⟩','old | ⟨unsigned,maximum,ty,x,y,rfl⟩').replace('BitBody.family_','PopcountBody.family_').replace('BitBody.bit_inst_notrap','PopcountBody.popcount_inst_notrap').replace('popcount_inst_notrap','minmax_inst_notrap').replace('popcount_source_notrap','minmax_source_notrap')
# Restore the actual name of the reused prior family theorem after the local rename.
s=s.replace('PopcountBody.minmax_inst_notrap','PopcountBody.popcount_inst_notrap')
s=s.replace('  · rfl','  · cases unsigned <;> cases maximum <;> rfl').replace('  · simp [CastBody.SafeFormat,instNames]','  · cases unsigned <;> cases maximum <;> simp [CastBody.SafeFormat,instNames,operation,ScalarSelect.MinMaxRegisterFixture.minmaxOperation]')
a=s.index('  · cases getX :',s.index('theorem minmax_inst_notrap'));z=s.index('\ntheorem minmax_source_notrap',a)
s=s[:a]+'''  · cases unsigned <;> cases maximum
    all_goals
      cases getX : fr.getAs x ty with
      | trap code => exact False.elim (PureBody.frame_getAs_notrap fr x ty code getX)
      | stuck message => simp [Clif.evalInst,operation,ScalarSelect.MinMaxRegisterFixture.minmaxOperation,getX]
      | ok u =>
        cases getY : fr.getAs y ty with
        | trap code => exact False.elim (PureBody.frame_getAs_notrap fr y ty code getY)
        | stuck message => simp [Clif.evalInst,operation,ScalarSelect.MinMaxRegisterFixture.minmaxOperation,getX,getY]
        | ok v => simp [Clif.evalInst,operation,ScalarSelect.MinMaxRegisterFixture.minmaxOperation,getX,getY]
'''+s[z:]
(r/'StockMinMaxFamily.lean').write_text(s)
s=(r/'StockPopcountScanRefines.lean').read_text().replace('StockBitScanRefines','StockPopcountScanRefines').replace('StockPopcountFamily','StockMinMaxFamily').replace('stock_lower_popcount_scan_fall_refines','stock_lower_minmax_scan_fall_refines').replace('stock_lower_mixed_popcount','stock_lower_mixed_minmax').replace('MixedPopcountOrOmittedRecord','MixedMinMaxOrOmittedRecord')
s=s.replace('    {info : IInfo} {ty : Clif.Ty} {x z a : Nat}','    (unsigned maximum : Bool)\n    {info : IInfo} {ty : Clif.Ty} {x y z a : Nat}').replace('some (.unary .popcnt ty x)','some (.binary (MinMaxBody.operation unsigned maximum) ty x y)')
a=s.index('  obtain ⟨u,d,ρ\'');z=s.index('  have postDFG',a)
s=s[:a]+'''  obtain ⟨u,v,getX,getY⟩ := ScalarSelect.stock_lower_minmax_source_operands
    run scope dominated events block statement current unsigned maximum source clif sourceStep
  have availableX := restrict_regs_isSome (by rw [getAs_ok getX]; rfl)
  have availableY := restrict_regs_isSome (by rw [getAs_ok getY]; rfl)
  have typeX := stock_lower_available_getAs_type run events availableX dfg getX
  have typeY := stock_lower_available_getAs_type run events availableY dfg getY
  obtain ⟨d,output,lower,upper,unchanged,execution⟩ := ScalarSelect.stock_lower_minmax_actual_source_values
    run scope dominated events records block statement current unsigned maximum source clif typeX typeY
    results statementResults mapped recorded emitted refines dfg getX getY values sourceStep
  obtain ⟨ρ',w',executed,world,value,kept,post⟩ := execution w
'''+s[z:]
s=s.replace('(SameWorld.nf world) memory','world memory').replace('  MixedBitOrOmittedRecord f ctx bi r ∨','  MixedPopcountOrOmittedRecord f ctx bi r ∨').replace('∃ info ty x z a,','∃ info unsigned maximum ty x y z a,')
s=s.replace('old | popcount','old | minmax').replace('stock_lower_mixed_bit_record_fall_refines','stock_lower_mixed_popcount_record_fall_refines').replace('emitted,info,ty,x,z,a,','emitted,info,unsigned,maximum,ty,x,y,z,a,').replace(' := popcount',' := minmax').replace('block statement current source clif results statementResults mapped recorded emitted refines stable','block statement current unsigned maximum source clif results statementResults mapped recorded emitted refines stable')
(r/'StockMinMaxScanRefines.lean').write_text(s)
s=(r/'StockPopcountBodyRefines.lean').read_text().replace('StockBitBodyRefines','StockPopcountBodyRefines').replace('StockPopcountFamily','StockMinMaxFamily').replace('StockPopcountScanRefines','StockMinMaxScanRefines').replace('Backend.Stock.Proof.PopcountBody','Backend.Stock.Proof.MinMaxBody').replace('actual_popcount','actual_minmax').replace('MixedPopcountOrOmittedRecord','MixedMinMaxOrOmittedRecord').replace('stock_lower_mixed_popcount','stock_lower_mixed_minmax').replace('Popcount composes','Min/max composes')
s=s.replace('old | ⟨ty,x,shape⟩','old | ⟨unsigned,maximum,ty,x,y,shape⟩').replace('BitBody.emitted_record_family','PopcountBody.emitted_record_family').replace('some (.unary .popcnt ty x)','some (.binary (operation unsigned maximum) ty x y)').replace('info,ty,x,z,a,','info,unsigned,maximum,ty,x,y,z,a,')
s=s.replace('Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inl','Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inl').replace('Or.inl omitted⟩))))))))','Or.inl omitted⟩)))))))))')
(r/'StockMinMaxBodyRefines.lean').write_text(s)
for src,dst in [('StockPopcountReturnRefines','StockMinMaxReturnRefines'),('StockScalarPopcountDomain','StockScalarMinMaxDomain')]:
 s=(r/(src+'.lean')).read_text().replace('StockPopcount','StockMinMax').replace('Backend.Stock.Proof.PopcountBody','Backend.Stock.Proof.MinMaxBody').replace('PopcountBody','MinMaxBody').replace('actual_popcount','actual_minmax').replace('domain_of_popcount','domain_of_minmax').replace('popcount_source_notrap','minmax_source_notrap').replace('mixed popcount','mixed min/max').replace('Fixed popcount','Fixed min/max')
 (r/(dst+'.lean')).write_text(s)
