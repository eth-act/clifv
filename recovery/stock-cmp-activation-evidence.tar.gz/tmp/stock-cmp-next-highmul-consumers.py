from pathlib import Path
out=Path('/tmp/stock-cmp-next-highmul-draft')
s=Path('FV/Backend/ABIReadScalar.lean').read_text();needle='def instruction (sig : Clif.Signature)';s=s.replace(needle,'''/-- Exact virtual-register high products; earlier ABI selectors remain fixed. -/
def highmulProducer : MInst → Bool
  | .aluRRR .sMulH .size64 (.vreg _ .int) (.vreg _ .int) (.vreg _ .int)
  | .aluRRR .uMulH .size64 (.vreg _ .int) (.vreg _ .int) (.vreg _ .int) => true
  | _ => false

'''+needle).replace('|| booleanProducer i','|| booleanProducer i || highmulProducer i');(out/'BackendABIReadScalar.lean').write_text(s)
s=Path('FV/E2E/ABIReadScalar.lean').read_text().replace('import FV.E2E.ABIReadBooleanSteps','import FV.E2E.ABIReadBooleanSteps\nimport FV.E2E.ABIReadHighMulSteps')
s=s.replace('=> Backend.ABIReadScalar.shiftOp op || op == .extr','=> Backend.ABIReadScalar.shiftOp op || op == .extr || op == .sMulH || op == .uMulH')
s=s.replace('private theorem comparison_sem_eq','''private theorem highmul_special {i : MInst} (checked : Backend.ABIReadScalar.highmulProducer i = true) : special i = true := by
  cases i with
  | aluRRR op sz rd rn rm => cases op <;> first | rfl | cases checked
  | _ => cases checked

private theorem comparison_sem_eq''')
s=s.replace('((((((old | added) | shifted) | extended) | bit) | popcount) | comparison) | boolean','(((((((old | added) | shifted) | extended) | bit) | popcount) | comparison) | boolean) | highmul')
# Reuse each Boolean transport/realization branch, preserving all earlier variants.
segments=s.split('\n  · simp only [sem,boolean_special boolean,↓reduceIte]')
assert len(segments)==4
for i in range(1,4):
 tail=segments[i];end=tail.index('\n\n')
 branch='\n  · simp only [sem,boolean_special boolean,↓reduceIte]'+tail[:end]
 extra=branch.replace('boolean_special boolean','highmul_special highmul').replace('BooleanRead','HighMulRead').replace(' boolean',' highmul')
 segments[i]=tail[:end]+extra+tail[end:]
s='\n  · simp only [sem,boolean_special boolean,↓reduceIte]'.join(segments)
# semanticNoTLS must include the exact new producers, following Boolean's branch.
# This separate definition lives later; inspect before applying the draft.
(out/'E2EABIReadScalar.lean').write_text(s)
s=Path('FV/Backend/Lowering/StockScalar.lean').read_text();needle='def eligible (f : Clif.Function)'
s=s.replace(needle,'''/-- High multiplication extends the original source family; prior selectors stay. -/
def highmulEligible (stm : Clif.Stmt) : Bool :=
  match stm.inst with
  | .binary .smulhi ty _ _ | .binary .umulhi ty _ _ => ty == .i32 || ty == .i64
  | _ => false

def highmulBodyEligible (stm : Clif.Stmt) : Bool := cmpBodyEligible stm || highmulEligible stm

'''+needle).replace('b.body.all cmpBodyEligible','b.body.all highmulBodyEligible');(out/'StockScalar.lean').write_text(s)
s=Path('FV/Backend/Proof/StockScalarCheck.lean').read_text().replace('import FV.Backend.Proof.StockScalarCmpDomain','import FV.Backend.Proof.StockScalarCmpDomain\nimport FV.Backend.Proof.StockScalarHighMulDomain')
needle='theorem sourceOk_sound'
s=s.replace(needle,'''/-- Original signed/unsigned high-multiply syntax derives the universal mixed source domain. -/
theorem highmulBodyEligible_sound {stm : Clif.Stmt} (checked : highmulBodyEligible stm = true) :
    Stock.Proof.HighMulBody.Family stm.inst := by
  simp only [highmulBodyEligible,Bool.or_eq_true] at checked
  rcases checked with old | highmul
  · exact Or.inl (cmpBodyEligible_sound old)
  · cases inst : stm.inst <;> simp only [highmulEligible,inst] at highmul
    all_goals try contradiction
    next op ty x y =>
      cases op <;> simp only [highmulEligible] at highmul
      all_goals try contradiction
      all_goals first
        | exact Or.inr ⟨true,_,_,_,rfl⟩
        | exact Or.inr ⟨false,_,_,_,rfl⟩

'''+needle)
a=s.index('theorem sourceOk_sound');s=s[:a]+s[a:].replace('Stock.Proof.CmpBody.Family','Stock.Proof.HighMulBody.Family').replace('exact cmpBodyEligible_sound','exact highmulBodyEligible_sound').replace('domain_of_cmp','domain_of_highmul');(out/'StockScalarCheck.lean').write_text(s)
print('Prepared shared scalar/ABI consumer drafts outside repository; not validated.')
