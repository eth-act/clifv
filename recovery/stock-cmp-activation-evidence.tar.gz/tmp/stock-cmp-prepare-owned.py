from pathlib import Path
import json,re,subprocess
old=json.loads(Path('/tmp/stock-minmax-owned/partitions.json').read_text());out=Path('/tmp/stock-cmp-owned');out.mkdir(exist_ok=True)
paths=subprocess.check_output(['git','diff','--name-only','e95bb871'],text=True).splitlines();new_names=[p[:-5].replace('/','.') for p in paths if p.startswith('FV/') and p.endswith('.lean')]
new_names += ['FV.Backend.Proof.'+n for n in ['StockCmpActualDispatch','StockCmpWideActualOriginalSourceValues','StockCmpNarrowActualOriginalSourceValues','StockCmpWideActualRecordValues','StockCmpNarrowActualRecordValues','StockCmpWideActualRootValues','StockCmpNarrowActualRootValues','StockCmpWideActualValues','StockCmpNarrowMatchedValues','StockCmpNarrowActualAllocation','StockCmpSelectedCalls','StockCmpRootMatch','StockCmpSourceMatch','StockCmpOutput','StockCmpCondition','StockCmpConditionValues','StockSelectComparisonConditionShape','StockSelectWideComparisonShape','StockSelectNarrowComparisonShape','StockSelectCompanionFragment','StockAvailableTypes','StockCmpNonconstantSourceValues']]
core=old['core']+list(dict.fromkeys(n for n in new_names if n not in old['core'] and n!='FV.E2E.StockCmpWitness'));witness=old['witnesses']+['FV.E2E.StockCmpWitness']
log=Path('/tmp/stock-cmp-final-audits/stock-cmp-production.log').read_text();new=sorted(set(re.findall(r'E2E\.StockCmpNIWitness\.(?:checks_true|source_checks_true)\._native\.native_decide\.ax_[\w]+',log)));assert len(new)==2,new
facts=sorted(set(old['exact_native_facts'])|set(new));assert len(facts)==35
owners=old['executable_owners']+['FVTest.Backend.Lowering.StockCmpProductionRuntime','FVTest.Backend.Lowering.StockCmpProductionLinked'];assert len(set(core))==len(core)
part={'base':'e95bb871','candidate':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'core':core,'witnesses':witness,'exact_native_facts':facts,'executable_owners':owners};(out/'partitions.json').write_text(json.dumps(part,indent=2))
body=Path('/tmp/stock-minmax-owned/Owned0.lean').read_text();body=body[body.index('open Lean Elab Command'):];arr=lambda x:'#['+', '.join(json.dumps(s) for s in x)+']'
for name,values in [('core',core),('witnesses',witness),('fixedFacts',facts)]:body=re.sub(r'  let '+name+r' := #\[.*\]',lambda m:'  let '+name+' := '+arr(values),body)
body=body.replace('STOCK_MINMAX_OWNED','STOCK_CMP_OWNED');(out/'Owned0.lean').write_text(''.join('import '+n+'\n' for n in core+witness)+body)
for i,owner in enumerate(owners,1):(out/f'Owned{i}.lean').write_text('import Lean\n'+Path('/tmp/stock-not-owned/Owned1.lean').read_text().replace('FVTest.Backend.Main',owner).replace('STOCK_NOT_OWNED','STOCK_CMP_OWNED'))
m=json.loads(Path('/tmp/stock-cmp-normal-manifest.json').read_text());m['packet']='cmp-production-owned';m['gates']=[]
for i in range(len(owners)+1):m['gates'].append({'id':'owned-'+str(i),'argv':['lake','env','lean',str(out/f'Owned{i}.lean')],'requires':['STOCK_CMP_OWNED'],'complete_inputs':False})
Path('/tmp/stock-cmp-owned-manifest.json').write_text(json.dumps(m,indent=2));print(len(core),len(witness),len(facts),len(owners))
