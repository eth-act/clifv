import FV.E2E.StockCmpFixtures
import FV.Backend.Proof.StockScalarCheck
open Backend
#eval do
  let f := E2E.StockCmpNIWitness.function .systemVI64
  IO.println s!"sourceOk={Stock.Scalar.sourceOk f}"
  match Stock.lower f with
  | .error e => IO.println e
  | .ok result =>
    IO.println s!"check={Stock.Scalar.check f result.code}"
    let roots := result.blockScans.toList.flatMap fun (event : Stock.BlockScanEvent) =>
      event.output.records.filterMap fun (record : Stock.ScanRecord) => record.output.step.bind fun (step : Stock.Step) => step.rules.getLast?
    IO.println s!"roots={roots.eraseDups}"
    let code := result.code.blocks.toList.flatMap (fun (b : VBlock) => b.insts.toList)
    IO.println s!"rr={code.any (fun (i : MInst) => match i with | .aluRRR .subS _ .xzr _ _ => true | _ => false)} imm={code.any (fun (i : MInst) => match i with | .aluRRImm12 .subS _ .xzr _ _ => true | _ => false)} cset={code.any (fun (i : MInst) => match i with | .cset (.vreg _ .int) _ => true | _ => false)}"
