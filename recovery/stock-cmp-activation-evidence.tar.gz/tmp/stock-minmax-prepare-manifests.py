from pathlib import Path
import json,subprocess,copy
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();base='80280f11c03b77d78bee4c50ed43ca94216bfd0a'
def replace(v):
 if isinstance(v,str):
  if v=='popcount':return 'minmax'
  return v.replace('stock-popcnt','stock-minmax').replace('StockPopcount','StockMinMax').replace('STOCK_POPCOUNT','STOCK_MINMAX').replace('Stock popcount','Stock minmax').replace('{out}/popcount','{out}/minmax').replace('popcount-actual','minmax-actual')
 if isinstance(v,list):return [replace(x) for x in v]
 if isinstance(v,dict):return {replace(k):replace(x) for k,x in v.items()}
 return v
for kind in ['normal','native','full','retention','integration']:
 m=replace(json.loads(Path('/tmp/stock-popcnt-'+kind+'-manifest.json').read_text()));m.update(packet='minmax-production-'+kind,base=base,candidate=head,historical_evidence=['docs/research/stock-popcount-production-activation.json'],validation_scope='Signed/unsigned i32/i64 min/max mixed with every prior class, plus unchanged original source conditions, theorem variants/axioms, identities and stages. Full original #140 remains unfinished.')
 if kind=='normal':
  for g in m['gates']:
   if g['id']=='all-trust-audits':g['argv'][-1]='/tmp/stock-minmax-final-audits'
  for target in ['stock-minmax-runtime','stock-minmax-linked','stock-popcount-runtime','stock-popcount-linked']:
   m['gates'].insert(-1,{'id':'build-'+target,'argv':['lake','build',target],'env':{'FV_MEMCAP':'8G'},'complete_inputs':False})
 if kind=='native':
  m['gates'][0]['argv']=['.lake/build/bin/stock-minmax-runtime'];m['gates'][0]['inputs'].append('.lake/build/bin/stock-minmax-runtime')
 if kind=='retention':m['gates'][0]['argv'][1]='/tmp/stock-mul-retained-flat-multiply.py'
 if kind=='integration':
  m['gates'][0]['argv'] += ['--fixture-mode','native'];m['gates'][0]['inputs']=['.lake/build/bin/stock-minmax-runtime','.lake/build/bin/stock-minmax-linked']
 Path('/tmp/stock-minmax-'+kind+'-manifest.json').write_text(json.dumps(m,indent=2)+'\n')
m=json.loads(Path('/tmp/stock-popcnt-integration-manifest.json').read_text());m.update(packet='minmax-production-retained-popcount-integration',base=base,candidate=head,historical_evidence=['docs/research/stock-popcount-production-activation.json']);m['gates'][0]['argv'] += ['--fixture-mode','native'];m['gates'][0]['inputs']=['.lake/build/bin/stock-popcount-runtime','.lake/build/bin/stock-popcount-linked'];Path('/tmp/stock-minmax-popcount-integration-manifest.json').write_text(json.dumps(m,indent=2)+'\n')
print('Six frozen min/max manifests for',head)
