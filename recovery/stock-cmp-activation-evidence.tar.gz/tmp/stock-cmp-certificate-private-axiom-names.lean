import Lean
import «stock-cmp-entry-opaque-bool-certificate»
open Lean Elab Command in
run_cmd do
  let names ← collectAxioms ``Crates.StockCmpProduction33CleanupFallbackEntries.entries_present
  for n in names do
    logInfo m!"ACTUAL_NAME {n.toString}; USER_NAME {(privateToUserName? n).getD n}"
