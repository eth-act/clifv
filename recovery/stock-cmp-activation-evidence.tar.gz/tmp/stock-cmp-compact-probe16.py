from pathlib import Path
import subprocess as sp,os,json,datetime,signal,time,traceback
v=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');root=Path('/tmp/stock-cmp-compact-probe16');root.mkdir(exist_ok=True);scheduler=2876601
records={}
def report(state,**kw):
 d=dict(state=state,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=os.getpid(),scheduler_pid=scheduler,records=records,**kw);(root/'progress.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:x for k,x in d.items() if k!='records'}),flush=True)
def active_children():
 out=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:st=(p/'stat').read_text().rsplit(')',1)[1].split()
  except OSError:continue
  if int(st[1])==scheduler and st[0]!='Z':out.append(int(p.name))
 return out
try:
 report('draining_existing_build_jobs')
 while children:=active_children():
  report('draining_existing_build_jobs',active_build_pids=children);time.sleep(5)
 env=dict(os.environ,FV_MEMCAP='16G',FV_LAKE_CACHE='/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache',LEAN_NUM_THREADS='2',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2');env['PATH']='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:'+env['PATH']
 assert sp.check_output(['git','rev-parse','HEAD'],cwd=v,text=True).strip()=='0951bfec675ec66f150f5090d7c57cc5973a5f32'
 assert not sp.check_output(['git','diff','--name-only'],cwd=v,text=True).strip()
 report('running_solo_compact_exact_statement_proof',cap_GiB=16)
 with (root/'proof.log').open('w') as f:
  r=sp.run(['python3','/tmp/stock-delivery-time.py',str(root/'proof.time'),str(v/'scripts/memcap.sh'),'lake','env','lean','--root=/tmp','-o','/tmp/StockCmpWithFlagsCompact.olean','/tmp/StockCmpWithFlagsCompact.lean'],cwd=v,env=env,stdout=f,stderr=sp.STDOUT)
 records['compact-proof']={'rc':r.returncode,'log':str(root/'proof.log'),'time':str(root/'proof.time')}
 report('compact_proof_passed' if r.returncode==0 else 'compact_proof_failed',rc=r.returncode)
finally:
 try:
  assert b'stock-execute-scheduler.py' in Path('/proc/'+str(scheduler)+'/cmdline').read_bytes();os.kill(scheduler,signal.SIGCONT)
  report('launcher_resumed',experiment_records=records)
 except FileNotFoundError:report('launcher_already_terminal',experiment_records=records)
