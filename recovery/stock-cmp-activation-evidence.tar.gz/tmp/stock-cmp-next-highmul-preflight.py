from pathlib import Path
import json,os,subprocess,time
root=Path.cwd();draft=Path('/tmp/stock-cmp-next-highmul-draft');out=Path('/tmp/stock-cmp-next-highmul-preflight3');out.mkdir(exist_ok=True)
e=os.environ.copy();e.update(json.load(open('/tmp/stock-cmp-terminal-normal-manifest.json'))['env']);e['LEAN_PATH']=str(out)+':'+str(root/'.lake/build/lib/lean')
names=['StockHighMulFamily','StockHighMulScanRefines','StockHighMulBodyRefines','StockHighMulReturnRefines','StockScalarHighMulDomain'];records=[]
for n in names:
 target=out/'HighMulDraft'/(n+'.lean');target.parent.mkdir(parents=True,exist_ok=True);source=(draft/(n+'.lean')).read_text()
 for module in names:source=source.replace('import FV.Backend.Proof.'+module,'import HighMulDraft.'+module)
 target.write_text(source);start=time.monotonic()
 with (out/(n+'.log')).open('w') as log:
  code=subprocess.run(['scripts/memcap.sh','lean','--root='+str(out),'-o',str(target.with_suffix('.olean')),str(target)],env=e,stdout=log,stderr=subprocess.STDOUT).returncode
 records.append({'module':n,'returncode':code,'seconds':time.monotonic()-start});(out/'records.json').write_text(json.dumps(records,indent=2)+'\n');print(n,code,flush=True)
 if code:print((out/(n+'.log')).read_text(),flush=True);raise SystemExit(code)
