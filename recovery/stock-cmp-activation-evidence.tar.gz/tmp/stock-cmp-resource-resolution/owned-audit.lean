import FV.Backend.Proof.StockCmpWithFlags
open Lean Elab Command
#print axioms Backend.Stock.Proof.ScalarCmp.stock_cmp_with_flags_reg
run_cmd do
  let env ← getEnv
  let mut count : Nat := 0
  for (name,_) in env.constants.toList do
    let some idx := env.getModuleIdxFor? name | continue
    unless env.header.moduleNames[idx]!.toString == "FV.Backend.Proof.StockCmpWithFlags" do continue
    for ax in ← collectAxioms name do
      unless #[``propext,``Classical.choice,``Quot.sound].contains ax do
        throwError "disallowed axiom {ax} in {name}"
    count := count + 1
  unless count > 0 do throwError "empty owned proof partition"
  logInfo m!"CMP_FLAGS_ALL_OWNED_STANDARD_ONLY {count}"
