from pathlib import Path
b=Path('FV/Backend/Proof')
# Reusable prior-family dispatch: keep all earlier theorem variants unchanged.
p=b/'StockShiftScanRefines.lean';s=p.read_text();end='end Backend.Stock.Proof\n';s=s.removesuffix(end)
old=s;s=s[:];a=old.index('theorem stock_lower_mixed_mul_record_fall_refines');z=old.index(' := by',a);h=old[a:z].replace('stock_lower_mixed_mul_record_fall_refines','stock_lower_mixed_shift_record_fall_refines').replace('MixedMulOrOmittedRecord','MixedShiftOrOmittedRecord')
a=old.index('  rcases families record member with old | mul',old.index('theorem stock_lower_mixed_shift_body_fall_refines'));body=old[a:];body=body.replace('  rcases families record member','  rcases family').replace('(retained record member)','records');s+='\n'+h+' := by\n'+body+'\n'+end;p.write_text(s)
p=b/'StockShiftBodyRefines.lean';s=p.read_text();end='end Backend.Stock.Proof.ShiftBody\n';s=s.removesuffix(end)
base=(b/'StockBnotBodyRefines.lean').read_text();a=base.index('theorem emitted_record_family');z=base.index(' := by',a);h=base[a:z].replace('MixedBnotOrOmittedRecord','MixedShiftOrOmittedRecord')
s+='\n'+h+''' := by
  rcases family with old | ⟨kind,ty,x,y,shape⟩
  · exact Or.inl (mul_record_family block statement current recorded emitted source clif one results mapped old)
  · have original : info.clif = some (.binary kind.cop ty x y) := by rw [clif,shape]
    exact Or.inr ⟨j,b,stm,block,statement,current,step,recorded,emitted,
      kind,info,ty,x,y,z,a,source,original,one,results,mapped⟩
'''+end;p.write_text(s)
# Cast-specific source scans use the same guarded scan relation and composition.
old=(b/'StockShiftScanRefines.lean').read_text();a=old.index('theorem stock_lower_shift_scan_fall_refines');z=old.index('\n\n\n',a);template=old[a:z]
s='''import FV.Backend.Proof.StockShiftScanRefines
import FV.Backend.Proof.StockCastCompleteSourceTransfer
namespace Backend.Stock.Proof
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm emitBranch scanBlock
'''
for kind in ['extend','reduce']:
 ext=kind=='extend';t=template.replace('stock_lower_shift_scan_fall_refines','stock_lower_'+kind+'_scan_fall_refines')
 t=t.replace('    (kind : ScalarShift.Kind) {info : IInfo}',('    (syntax : ∀ b ∈ f.blocks,∀ stm ∈ b.body,CastBody.Family stm.inst) (sg : Bool)\n    {info : IInfo}' if ext else '    {info : IInfo}'))
 t=t.replace('{x y z a : Nat}','{x z a : Nat}').replace('.binary kind.cop ty x y','.extend (ScalarCast.extendOp sg) ty x' if ext else '.ireduce ty x')
 t=t.replace('ShiftComplete.record_source','CastComplete.'+kind+'_source').replace('current kind source','current syntax sg source' if ext else 'current source')
 t=t.replace('mapped recorded emitted refines dfg values sourceStep','mapped recorded emitted refines dfg values sourceStep' if ext else 'mapped recorded emitted values sourceStep')
 if not ext:t=t.replace(' (refines : Refines F isem)','')
 s+='\n'+t+'\n'
s+='''
def MixedCastOrOmittedRecord (f : Clif.Function) (ctx : Ctx) (bi : Nat) (r : ScanRecord) : Prop :=
  MixedShiftOrOmittedRecord f ctx bi r ∨
    (∃ j b stm,f.blocks[bi]? = some b ∧ b.body[j]? = some stm ∧ r.inst = blockStart f bi+j ∧
      ∃ step,r.output.step = some step ∧ step.decision = .emitted ∧
      ∃ info op ty x z a,ctx.insts[r.inst]? = some info ∧ info.clif = some (.extend op ty x) ∧
        info.results = [z] ∧ stm.results = [z] ∧ ctx.valueReg? z = some (.vreg a .int)) ∨
    (∃ j b stm,f.blocks[bi]? = some b ∧ b.body[j]? = some stm ∧ r.inst = blockStart f bi+j ∧
      ∃ step,r.output.step = some step ∧ step.decision = .emitted ∧
      ∃ info ty x z a,ctx.insts[r.inst]? = some info ∧ info.clif = some (.ireduce ty x) ∧
        info.results = [z] ∧ stm.results = [z] ∧ ctx.valueReg? z = some (.vreg a .int))

/-- Prior families, both extensions and zero-code reductions share the original
record simulation; class syntax derives all source-pattern exclusions. -/
theorem stock_lower_mixed_cast_record_fall_refines {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    {event : BlockScanEvent} (events : event ∈ result.blockScans.toList)
    {bi : Nat} {record : ScanRecord} (records : record ∈ event.output.records)
    (syntax : ∀ b ∈ f.blocks,∀ stm ∈ b.body,CastBody.Family stm.inst)
    (family : MixedCastOrOmittedRecord f event.ctx bi record)
    {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem} (refines : Refines F isem)
    (driver : DriverSem isem) {MR : MemRelT} (stable : MRStable F MR)
    {env : Clif.Env} {cp : Clif.Program} :
    ScanFallRefines (IndexedSourceInst env cp f event.ctx bi) isem result.final.alias
      (GuardedScanRel f result event.ctx bi MR) record := by
  rcases family with old | extended | reduced
  · exact stock_lower_mixed_shift_record_fall_refines run scope dominated events records old refines driver stable
  · obtain ⟨j,b,stm,block,statement,current,step,recorded,emitted,info,op,ty,x,z,a,
      source,clif,results,statementResults,mapped⟩ := extended
    cases op
    all_goals exact stock_lower_extend_scan_fall_refines run scope dominated events records
      block statement current syntax _ source clif results statementResults mapped recorded emitted refines stable
  · obtain ⟨j,b,stm,block,statement,current,step,recorded,emitted,info,ty,x,z,a,
      source,clif,results,statementResults,mapped⟩ := reduced
    exact stock_lower_reduce_scan_fall_refines run scope dominated events records
      block statement current source clif results statementResults mapped recorded emitted stable
'''
a=old.index('theorem stock_lower_mixed_shift_body_fall_refines');z=old.index(' := by',a);t=old[a:z].replace('stock_lower_mixed_shift_body_fall_refines','stock_lower_mixed_cast_body_fall_refines').replace('MixedShiftOrOmittedRecord','MixedCastOrOmittedRecord');t=t.replace('    (families :','    (syntax : ∀ b ∈ f.blocks,∀ stm ∈ b.body,CastBody.Family stm.inst)\n    (families :')
s+='\n'+t+''' := by
  apply scanned.fall_refines
  intro record member
  exact stock_lower_mixed_cast_record_fall_refines run scope dominated events
    (retained record member) syntax (families record member) refines driver stable
end Backend.Stock.Proof
''';(b/'StockCastScanRefines.lean').write_text(s)
