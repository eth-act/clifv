import ast,json,hashlib,subprocess
from pathlib import Path
p=Path('scripts/check-stock-mixed-native.py');old=subprocess.check_output(['git','show','80280f11:scripts/check-stock-mixed-native.py'],text=True);new=p.read_text()
def funcs(s):
 t=ast.parse(s);ns={};exec(compile(ast.Module([n for n in t.body if isinstance(n,(ast.Import,ast.ImportFrom,ast.FunctionDef))],type_ignores=[]),'<native-function-grid>','exec'),ns);return ns
before,after=funcs(old),funcs(new);counts={}
for kind in ['mixed','logical','scalar','not','mul','shift','cast','bit','popcount']:
 counts[kind]={}
 for bits in [32,64]:
  a=before['run_commands'](bits,kind);b=after['run_commands'](bits,kind);assert a==b,(kind,bits);counts[kind][str(bits)]=len(b)
r={'state':'passed','baseline':'80280f11c03b77d78bee4c50ed43ca94216bfd0a','source_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'current_script_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'all_nine_previous_class_vectors_and_expectations_exact':True,'prior_counts':counts,'minmax_cases_per_object':{str(b):len(after['run_commands'](b,'minmax')) for b in [32,64]}}
Path('/tmp/stock-minmax-native-grid-retention.json').write_text(json.dumps(r,indent=2)+'\n');print('All nine old grids exact; minmax',r['minmax_cases_per_object'])
