from pathlib import Path
import json
r=json.loads(Path('/tmp/stock-minmax-terminal-receipt.json').read_text());b=json.loads(Path('/tmp/stock-minmax-activation-backup/metadata.json').read_text());assert r['state']=='per_pr_gates_passed' and b['remote_verified']
Path('/tmp/stock-minmax-pr-body.md').write_text(f'''Route i32/i64 signed and unsigned min/max through the default Stock scalar compiler, checker, linker and generated-proof consumers. Reuse the existing complete actual-source wrappers, derive their operand-type guards internally, and compose the actual flag/world frame into body/entry/return/no-trap correctness. Extend the scalar ABI boundary only for emitted register/register and immediate SUBS comparisons.

Old selectors, theorem variants, source conditions, required axioms and accepted identities/stages remain. Complete mixed witnesses cover all four selected roots, both comparison forms, negative/large constants, six ABIs and both cleanup modes, keeping prior computation live. No alternate RHS/math chain or new program certificate is introduced.

Ordinary native fixture targets execute the same checked Lean code in about10 seconds per runtime/linked fixture. Against the prior interpreted fixture, all72 source/table/object artifacts and12 ELFs are byte-exact. Existing interpreted invocation stays the default; explicit native mode checks Lake keys and binary hashes. Generated proofs still compile freshly.

Validation on `{r['validated_source_head']}`:

- {r['normal_library_jobs']:,} normal keys; four tools/four native fixtures; current crate keys;53 audits/1601 roots; all1571 prior axiom sets/30 old headers exact. One bundled MCP review:Std3/no warnings.
- {r['owned_core_constants']:,} Std3core/{r['owned_fixed_witness_constants']:,} fixed witness constants,21 ownership partitions and exactly33 permitted native facts.
- 24 objects/2448 native comparisons/612 Cranelift references,0 failures/disagreements; all nine prior grids exact; real-oracle, missing-binary and complete-attempt retry controls.
- Current min/max and retained popcount actual CLI/link/generated cohorts32/32 each; original flat-multiply artifacts retained/current proofs; full4737/0 runtime,1321/0 encoder,both1159/0 E2E with identity/ordered-stage parity; demo21 tests/2 binaries,survey53 tests/18 binaries.

Receipt: docs/research/stock-minmax-production-activation.md and JSON. Remote terminal evidence `{b['backup_commit']}`. Failed prechecks remain archived and never count as passing gates.

Continues #140. Integer comparisons require actual cast-of-icmp811 support; remaining classes, widths/ABIs, effects/control/memory/traps/calls, whole-driver simulation and universal successful lowering/downstream completeness remain open. Fallback is not Stock completeness. #44 holds current status.
''')
