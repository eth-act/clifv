import Crates.StockMinMaxProduction2CleanupFallbackGlobal
import Crates.StockMinMaxProduction2PlainFallbackGlobal
import Crates.StockMinMaxProduction2RetainedCleanupFallbackGlobal
import Crates.StockMinMaxProduction2RetainedPlainFallbackGlobal
import Crates.StockMinMaxProduction33CleanupFallbackEntries
import Crates.StockMinMaxProduction33CleanupFallbackGlobal
import Crates.StockMinMaxProduction6CleanupFallbackGlobal
import Crates.StockMinMaxProduction6CleanupStrictGlobal
import Crates.StockMinMaxProduction6MixedCleanupFallbackGlobal
import Crates.StockMinMaxProduction6MixedPlainFallbackGlobal
import Crates.StockMinMaxProduction6PlainFallbackGlobal
import Crates.StockMinMaxProduction6PlainStrictGlobal
import Crates.MinMaxProductionCLIcurrentPlain
import Crates.MinMaxProductionCLIretainedPlain
import Crates.MinMaxProductionCLIcurrentCleanup
import Crates.MinMaxProductionCLIretainedCleanup
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let generated := fun (name : Name) =>
    name.toString.startsWith "Crates.StockMinMaxProduction" || name.toString.startsWith "Crates.MinMaxProductionCLI"
  let mut count : Nat := 0
  for (name, _) in env.constants.toList do
    unless generated name do continue
    for ax in ← collectAxioms name do
      if #[``propext, ``Classical.choice, ``Quot.sound].contains ax then continue
      unless generated ax && (ax.toString.splitOn "._native.native_decide.ax_").length > 1 do
        throwError "unexpected generated-proof axiom {ax} in {name}"
    count := count + 1
  unless count > 0 do throwError "empty generated-proof audit"
  logInfo m!"STOCK_MINMAXPRODUCTION_GENERATED_AXIOMS_PASS {count}"
