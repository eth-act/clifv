# Apply only AFTER terminal cast evidence and squash, on the next implementation branch.
# Reuse existing proofs under the actual required source-format property, while
# retaining every old public theorem header as a wrapper.
from pathlib import Path
import re
base=Path('FV/Backend/Proof')
def generalize(path,name,parameter,wrapper,edits=()):
 p=base/path;s=p.read_text();a=s.index('theorem '+name+' ');h=s.index(' := by',a);match=re.search(r'\n(?:theorem |end )',s[h:]);assert match
 z=h+match.start();old=s[a:z];header=s[a:h];generic=old.replace('theorem '+name+' ','theorem '+name+'_of_formats ',1).replace(parameter,parameter.replace('CastBody.Family','CastBody.SafeFormat'))
 for src,dst in edits:assert src in generic,(name,src);generic=generic.replace(src,dst)
 p.write_text(s[:a]+generic+'\n\n'+header+' := by\n  '+wrapper+'\n'+s[z:])
fm='(fun b block stm statement => CastBody.family_formats (family b block stm statement))'
generalize('StockCastDispatch.lean','stock_lower_cast_selected_rule',
 '(family : ∀ b ∈ f.blocks,∀ stm ∈ b.body,CastBody.Family stm.inst)',
 'exact stock_lower_cast_selected_rule_of_formats run scope events '+fm+' sg source clif selected',
 [('(fun b block stm statement => CastBody.family_formats (family b block stm statement)) found original','family found original')])
generalize('StockCastCompleteSourceTransfer.lean','extend_source',
 '(family : ∀ b ∈ f.blocks,∀ stm ∈ b.body,CastBody.Family stm.inst)',
 'exact extend_source_of_formats run scope dominated events records block statement current '+fm+' sg source clif results statementResults mapped recorded emitted refines dfg held sourceStep',
 [('stock_lower_cast_selected_rule run scope events family','stock_lower_cast_selected_rule_of_formats run scope events family')])
fm='(fun b block stm statement => CastBody.family_formats (sourceFamily b block stm statement))'
generalize('StockCastScanRefines.lean','stock_lower_extend_scan_fall_refines',
 '(sourceFamily : ∀ b ∈ f.blocks,∀ stm ∈ b.body,CastBody.Family stm.inst)',
 'exact stock_lower_extend_scan_fall_refines_of_formats run scope dominated events records block statement current '+fm+' sg source clif results statementResults mapped recorded emitted refines stable',
 [('CastComplete.extend_source\n','CastComplete.extend_source_of_formats\n')])
generalize('StockCastScanRefines.lean','stock_lower_mixed_cast_record_fall_refines',
 '(sourceFamily : ∀ b ∈ f.blocks,∀ stm ∈ b.body,CastBody.Family stm.inst)',
 'exact stock_lower_mixed_cast_record_fall_refines_of_formats run scope dominated events records '+fm+' family refines driver stable',
 [('stock_lower_extend_scan_fall_refines run','stock_lower_extend_scan_fall_refines_of_formats run')])
