from pathlib import Path
import json,re,subprocess
old=json.loads(Path('/tmp/stock-popcnt-owned/partitions.json').read_text());out=Path('/tmp/stock-minmax-owned');out.mkdir(exist_ok=True)
paths=subprocess.check_output(['git','diff','--name-only','80280f11'],text=True).splitlines();new_names=[p[:-5].replace('/','.') for p in paths if p.startswith('FV/') and p.endswith('.lean')]
new_names += ['FV.Backend.Proof.'+n for n in ['StockMinMaxActualDispatch','StockMinMaxSourceMatch','StockMinMaxRegisterOriginalSourceValues','StockMinMaxWideOriginalSourceValues','StockMinMaxNarrowOriginalSourceValues','StockMinMaxRegisterSourceReads','StockMinMaxWideSourceReads','StockMinMaxNarrowSourceReads','StockAvailableTypes']]
core=old['core']+list(dict.fromkeys(n for n in new_names if n not in old['core'] and n!='FV.E2E.StockMinMaxWitness'));witness=old['witnesses']+['FV.E2E.StockMinMaxWitness']
log=Path('/tmp/stock-minmax-final-audits/stock-minmax-production.log').read_text();new=sorted(set(re.findall(r'E2E\.StockMinMaxNIWitness\.(?:checks_true|source_checks_true)\._native\.native_decide\.ax_[\w]+',log)));assert len(new)==2,new
facts=sorted(set(old['exact_native_facts'])|set(new));assert len(facts)==33
owners=old['executable_owners']+['FVTest.Backend.Lowering.StockMinMaxProductionRuntime','FVTest.Backend.Lowering.StockMinMaxProductionLinked'];assert len(set(core))==len(core)
part={'base':'80280f11c03b77d78bee4c50ed43ca94216bfd0a','candidate':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'core':core,'witnesses':witness,'exact_native_facts':facts,'executable_owners':owners};(out/'partitions.json').write_text(json.dumps(part,indent=2))
body=Path('/tmp/stock-popcnt-owned/Owned0.lean').read_text();body=body[body.index('open Lean Elab Command'):];arr=lambda x:'#['+', '.join(json.dumps(s) for s in x)+']'
for name,values in [('core',core),('witnesses',witness),('fixedFacts',facts)]:body=re.sub(r'  let '+name+r' := #\[.*\]',lambda m:'  let '+name+' := '+arr(values),body)
body=body.replace('STOCK_POPCOUNT_OWNED','STOCK_MINMAX_OWNED');(out/'Owned0.lean').write_text(''.join('import '+n+'\n' for n in core+witness)+body)
for i,owner in enumerate(owners,1):(out/f'Owned{i}.lean').write_text('import Lean\n'+Path('/tmp/stock-not-owned/Owned1.lean').read_text().replace('FVTest.Backend.Main',owner).replace('STOCK_NOT_OWNED','STOCK_MINMAX_OWNED'))
m=json.loads(Path('/tmp/stock-minmax-normal-manifest.json').read_text());m['packet']='minmax-production-owned';m['gates']=[]
for i in range(len(owners)+1):m['gates'].append({'id':'owned-'+str(i),'argv':['lake','env','lean',str(out/f'Owned{i}.lean')],'requires':['STOCK_MINMAX_OWNED'],'complete_inputs':False})
Path('/tmp/stock-minmax-owned-manifest.json').write_text(json.dumps(m,indent=2));print(len(core),len(witness),len(facts),len(owners))
