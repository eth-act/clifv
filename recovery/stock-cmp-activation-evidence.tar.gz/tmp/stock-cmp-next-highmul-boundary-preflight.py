from pathlib import Path
import json,os,subprocess,time
out=Path('/tmp/stock-cmp-next-highmul-preflight4');out.mkdir(exist_ok=True);draft=Path('/tmp/stock-cmp-next-highmul-draft');e=os.environ.copy();e.update(json.load(open('/tmp/stock-cmp-terminal-normal-manifest.json'))['env']);e['LEAN_PATH']=str(out)+':'+str(Path.cwd()/'.lake/build/lib/lean')
s=(draft/'BackendABIReadScalar.lean').read_text();a=s.index('def highmulProducer');b=s.index('\ndef instruction',a);check=s[a:b]
old=['constant','shift','extension','bitProducer','popcountProducer','comparisonProducer','booleanProducer'];parts=['ABIReadFlags.instruction sig b k i']+['ABIReadScalar.'+n+' i' for n in old]+['highmulProducer i']
check='import FV.Backend.ABIReadScalar\nnamespace Backend.ABIReadHighMulDraft\n'+check+'\ndef instruction (sig : Clif.Signature) (b k : Nat) (i : MInst) : Bool :=\n  '+' || '.join(parts)+'\ndef check (sig : Clif.Signature) (vc : VCode) : Bool :=\n  vc.blocks.toList.zipIdx.all fun (block,b) =>\n    block.insts.toList.zipIdx.all fun (i,k) => instruction sig b k i\nend Backend.ABIReadHighMulDraft\n'
step=(draft/'ABIReadHighMulSteps.lean').read_text().replace('import FV.Backend.ABIReadScalar','import HighMulDraft.ABIReadHighMulCheck').replace('Backend.ABIReadScalar.highmulProducer','Backend.ABIReadHighMulDraft.highmulProducer')
boundary=(draft/'E2EABIReadScalar.lean').read_text().replace('import FV.Backend.ABIReadScalar','import HighMulDraft.ABIReadHighMulCheck').replace('import FV.E2E.ABIReadHighMulSteps','import HighMulDraft.ABIReadHighMulSteps').replace('E2E.ScalarBoundary','E2E.HighMulBoundaryDraft')
for name in ['highmulProducer','instruction','check']:boundary=boundary.replace('Backend.ABIReadScalar.'+name,'Backend.ABIReadHighMulDraft.'+name)
records=[]
for name,source in [('ABIReadHighMulCheck',check),('ABIReadHighMulSteps',step),('ABIReadHighMulBoundary',boundary)]:
 p=out/'HighMulDraft'/(name+'.lean');p.parent.mkdir(exist_ok=True);p.write_text(source);start=time.monotonic()
 with (out/(name+'.log')).open('w') as f:r=subprocess.run(['scripts/memcap.sh','lean','--root='+str(out),'-o',str(p.with_suffix('.olean')),str(p)],env=e,stdout=f,stderr=subprocess.STDOUT)
 records.append({'module':name,'returncode':r.returncode,'seconds':time.monotonic()-start});(out/'records.json').write_text(json.dumps(records,indent=2)+'\n');print(name,r.returncode,flush=True)
 if r.returncode:print((out/(name+'.log')).read_text());raise SystemExit(r.returncode)
