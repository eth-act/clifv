from pathlib import Path
import os,signal,subprocess as sp,json,time,datetime,hashlib,traceback
v=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');root=Path('/tmp/stock-cmp-resource-batch4');root.mkdir(exist_ok=True);scheduler=2876601;source=Path('/tmp/StockCmpWithFlagsCompact.lean');records=[]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def report(state,**kw):
 d=dict(state=state,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=os.getpid(),scheduler_pid=scheduler,records=records,**kw);(root/'progress.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items() if k!='records'}),flush=True)
def active_children():
 out=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:st=(p/'stat').read_text().rsplit(')',1)[1].split()
  except OSError:continue
  if int(st[1])==scheduler and st[0]!='Z':out.append(int(p.name))
 return out
try:
 report('draining_existing_jobs')
 while jobs:=active_children():report('draining_existing_jobs',active_jobs=jobs);time.sleep(5)
 env=dict(os.environ,FV_MEMCAP='16G',FV_LAKE_CACHE='/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache',LEAN_NUM_THREADS='2',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2');env['PATH']='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:'+env['PATH']
 for i in range(10):
  assert sp.check_output(['git','rev-parse','HEAD'],cwd=v,text=True).strip()=='0951bfec675ec66f150f5090d7c57cc5973a5f32'
  assert not sp.check_output(['git','diff','--name-only'],cwd=v,text=True).strip()
  old=(v/'FV/Backend/Proof/StockCmpWithFlags.lean').read_text();new=source.read_text();header=lambda s:s[s.index('theorem stock_cmp_with_flags_reg'):s.index(' := by',s.index('theorem stock_cmp_with_flags_reg'))];assert header(old)==header(new)
  snap=root/('source-'+str(i)+'.lean');snap.write_text(new);log=root/('proof-'+str(i)+'.log');tim=root/('proof-'+str(i)+'.time');report('running_exact_statement_proof',iteration=i,source_sha256=sha(snap),cap_GiB=16)
  with log.open('w') as f:r=sp.run(['python3','/tmp/stock-delivery-time.py',str(tim),str(v/'scripts/memcap.sh'),'lake','env','lean','--root=/tmp','-o','/tmp/StockCmpWithFlagsCompact.olean',str(source)],cwd=v,env=env,stdout=f,stderr=sp.STDOUT)
  assert source.read_text()==new,'scratch source changed while compiler live'
  records.append({'iteration':i,'rc':r.returncode,'source':str(snap),'source_sha256':sha(snap),'log':str(log),'time':str(tim)})
  if r.returncode==0:report('exact_statement_proof_passed',iteration=i);break
  report('awaiting_scratch_revision',iteration=i,rc=r.returncode,timeout_seconds=60)
  deadline=time.monotonic()+60;command=root/'command.json'
  while time.monotonic()<deadline:
   if command.exists():
    data=json.loads(command.read_text());command.unlink()
    if data.get('command')=='finish':raise SystemExit(0)
    if data.get('command')=='next':break
   time.sleep(1)
  else:report('scratch_revision_timeout');break
finally:
 try:
  assert b'stock-execute-scheduler.py' in Path('/proc/'+str(scheduler)+'/cmdline').read_bytes();os.kill(scheduler,signal.SIGCONT);report('launcher_resumed')
 except FileNotFoundError:report('launcher_already_terminal')
