import Crates.StockCmpProduction2CleanupFallbackGlobal
import Crates.StockCmpProduction2PlainFallbackGlobal
import Crates.StockCmpProduction2RetainedCleanupFallbackGlobal
import Crates.StockCmpProduction2RetainedPlainFallbackGlobal
import Crates.StockCmpProduction33CleanupFallbackEntries
import Crates.StockCmpProduction33CleanupFallbackGlobal
import Crates.StockCmpProduction6CleanupFallbackGlobal
import Crates.StockCmpProduction6CleanupStrictGlobal
import Crates.StockCmpProduction6MixedCleanupFallbackGlobal
import Crates.StockCmpProduction6MixedPlainFallbackGlobal
import Crates.StockCmpProduction6PlainFallbackGlobal
import Crates.StockCmpProduction6PlainStrictGlobal
import Crates.CmpProductionCLIcurrentPlain
import Crates.CmpProductionCLIretainedPlain
import Crates.CmpProductionCLIcurrentCleanup
import Crates.CmpProductionCLIretainedCleanup
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let generated := fun (name : Name) =>
    let owner := (privateToUserName? name).getD name
    owner.toString.startsWith "Crates.StockCmpProduction" || owner.toString.startsWith "Crates.CmpProductionCLI"
  let mut count : Nat := 0
  for (name, _) in env.constants.toList do
    unless generated name do continue
    for ax in ← collectAxioms name do
      if #[``propext, ``Classical.choice, ``Quot.sound].contains ax then continue
      unless generated ax && (ax.toString.splitOn "._native.native_decide.ax_").length > 1 do
        throwError "unexpected generated-proof axiom {ax} in {name}"
    count := count + 1
  unless count > 0 do throwError "empty generated-proof audit"
  logInfo m!"STOCK_CMPPRODUCTION_GENERATED_AXIOMS_PASS {count}"
