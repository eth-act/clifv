from pathlib import Path
s=Path('FV/Backend/Proof/StockLogicalScanRefines.lean').read_text();s=s[:s.index('/-- Internal record partition')];s=s.replace('import FV.Backend.Proof.StockAddSubScanRefines\nimport FV.Backend.Proof.StockLogicalCompleteValues','import FV.Backend.Proof.StockConstantScanRefines\nimport StockBnotSourceTransfer').replace('stock_lower_logical_scan_fall_refines','stock_lower_bnot_scan_fall_refines').replace('(kind : LogicalSelected.Kind) {info : IInfo} {ty : Clif.Ty} {x y z a : Nat}','{info : IInfo} {ty : Clif.Ty} {x z a : Nat}').replace('.binary kind.cop ty x y','.unary .bnot ty x').replace('⟨u,v,ρ\',getX,getY,execution','⟨u,ρ\',getX,execution').replace('LogicalComplete.record_source_from_step','BnotComplete.source_from_step').replace('current kind source','current source')
s+='''
/-- Retained constant/logical records plus original unary NOT statements. -/
def MixedBnotOrOmittedRecord (f : Clif.Function) (ctx : Ctx) (bi : Nat) (r : ScanRecord) : Prop :=
  MixedConstantOrOmittedRecord f ctx bi r ∨
    ∃ j b stm, f.blocks[bi]? = some b ∧ b.body[j]? = some stm ∧
      r.inst = blockStart f bi + j ∧ ∃ step, r.output.step = some step ∧
        step.decision = .emitted ∧ ∃ info ty x z a,
          ctx.insts[r.inst]? = some info ∧ info.clif = some (.unary .bnot ty x) ∧
          info.results = [z] ∧ stm.results = [z] ∧ ctx.valueReg? z = some (.vreg a .int)

theorem stock_lower_mixed_bnot_body_fall_refines {f : Clif.Function} {result : Result}
    (run : Stock.lower f = .ok result) (scope : LowerScope f) (dominated : Dominated f)
    {event : BlockScanEvent} (events : event ∈ result.blockScans.toList)
    {bi : Nat} {indices : List Nat} {input : State} {body : BlockScan}
    (scanned : ScansSpec (fun i => scanInstruction event.ctx event.block i event.termInst event.isBranch)
      indices input body)
    (retained : ∀ r ∈ body.records, r ∈ event.output.records)
    (families : ∀ r ∈ body.records, MixedBnotOrOmittedRecord f event.ctx bi r)
    {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem} (refines : Refines F isem)
    (driver : DriverSem isem)
    {MR : MemRelT} (stable : MRStable F MR) {env : Clif.Env} {cp : Clif.Program} :
    ∀ s s', SourceSteps (IndexedSourceInst env cp f event.ctx bi) indices.reverse s s' →
      ∀ ρ w, GuardedScanRel f result event.ctx bi MR body.state s ρ w → ∃ ρ' w',
        seqRun isem (body.code.toList.map (·.mapRegs
          (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size + 1)))) ρ w =
          some (.fall ρ' w') ∧ GuardedScanRel f result event.ctx bi MR input s' ρ' w' := by
  apply scanned.fall_refines
  intro record member
  rcases families record member with (old | constant) | bnot
  · exact stock_lower_mixed_logical_record_fall_refines run scope dominated events
      (retained record member) old refines stable
  · obtain ⟨j,b,stm,block,statement,current,step,recorded,emitted,info,ty,imm,x,a,
      source,clif,results,statementResults,mapped⟩ := constant
    exact stock_lower_constant_scan_fall_refines run scope dominated events (retained record member)
      block statement current source clif results statementResults mapped recorded emitted refines driver stable
  · obtain ⟨j,b,stm,block,statement,current,step,recorded,emitted,info,ty,x,z,a,
      source,clif,results,statementResults,mapped⟩ := bnot
    exact stock_lower_bnot_scan_fall_refines run scope dominated events (retained record member)
      block statement current source clif results statementResults mapped recorded emitted refines stable
end Backend.Stock.Proof
'''
Path('/tmp/stock-not-next/StockBnotScanRefines.lean').write_text(s)
