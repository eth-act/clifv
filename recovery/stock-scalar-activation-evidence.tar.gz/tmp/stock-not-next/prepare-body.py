from pathlib import Path
s=Path('FV/Backend/Proof/StockConstantBodyRefines.lean').read_text().replace('import FV.Backend.Proof.StockLogicalBodyRefines\nimport FV.Backend.Proof.StockConstantScanRefines','import FV.Backend.Proof.StockConstantBodyRefines\nimport StockBnotScanRefines').replace('Backend.Stock.Proof.ConstantBody','Backend.Stock.Proof.BnotBody')
s=s.replace('LogicalBody.Family inst ∨ ∃ (ty : Clif.Ty) (imm : BitVec ty.width), inst = .iconst ty imm','ConstantBody.Family inst ∨ ∃ (ty : Clif.Ty) (x : Nat), inst = .unary .bnot ty x')
a=s.index('  rcases family with');b=s.index('/-- Original syntax',a)
s=s[:a]+'''  rcases family with old | ⟨ty,x,rfl⟩
  · exact ConstantBody.family_pure old
  · rfl

'''+s[b:]
s=s.replace('actual_constant','actual_bnot').replace('MixedConstantOrOmittedRecord','MixedBnotOrOmittedRecord')
s=s.replace('(⟨subtract,ty,x,y,shape⟩ | ⟨ty,c,x,y,shape⟩ | ⟨kind,ty,x,y,shape⟩) | ⟨ty,imm,shape⟩','((⟨subtract,ty,x,y,shape⟩ | ⟨ty,c,x,y,shape⟩ | ⟨kind,ty,x,y,shape⟩) | ⟨ty,imm,shape⟩) | ⟨ty,x,shape⟩')
s=s.replace('    · rfl\n  have single','    · rfl\n    · rfl\n  have single')
s=s.replace('exact Or.inl (Or.inl (Or.inl ⟨j,b,stm,block,statement,current,step,recorded,Or.inl omitted⟩))','exact Or.inl (Or.inl (Or.inl (Or.inl ⟨j,b,stm,block,statement,current,step,recorded,Or.inl omitted⟩)))')
s=s.replace('exact Or.inl (Or.inl (Or.inr ⟨','exact Or.inl (Or.inl (Or.inl (Or.inr ⟨').replace('original,one,results,mapped⟩))','original,one,results,mapped⟩)))')
s=s.replace('exact Or.inl (Or.inl (Or.inl ⟨j,b,stm,block,statement,current,step,recorded,Or.inr','exact Or.inl (Or.inl (Or.inl (Or.inl ⟨j,b,stm,block,statement,current,step,recorded,Or.inr').replace('original,one,results,mapped⟩⟩))','original,one,results,mapped⟩⟩)))')
s=s.replace('exact Or.inl (Or.inr ⟨','exact Or.inl (Or.inl (Or.inr ⟨')
s=s.replace('exact Or.inr ⟨j,b,stm,block,statement,current,step,recorded,emitted,\n        info,ty,imm,z,a,source,original,one,results,mapped⟩','exact Or.inl (Or.inr ⟨j,b,stm,block,statement,current,step,recorded,emitted,\n        info,ty,imm,z,a,source,original,one,results,mapped⟩)\n    · have original : info.clif = some (.unary .bnot ty x) := by rw [clif,shape]\n      exact Or.inr ⟨j,b,stm,block,statement,current,step,recorded,emitted,\n        info,ty,x,z,a,source,original,one,results,mapped⟩')
s=s.replace('stock_lower_mixed_constant_body_fall_refines','stock_lower_mixed_bnot_body_fall_refines')
Path('/tmp/stock-not-next/StockBnotBodyRefines.lean').write_text(s)
