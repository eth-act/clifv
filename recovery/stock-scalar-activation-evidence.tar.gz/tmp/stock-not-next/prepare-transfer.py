from pathlib import Path
s=Path('FV/Backend/Proof/StockLogicalSourceTransfer.lean').read_text();s=s[s.index('theorem source_operands'):s.index('private theorem not_values_same_order')]
s=s.replace('(kind : Kind) {info : IInfo} {ty : Clif.Ty} {x y : Nat}', '{info : IInfo} {ty : Clif.Ty} {x : Nat}').replace('(kind : Kind) {info : IInfo} {x y z a : Nat}', '{info : IInfo} {x z a : Nat}')
s=s.replace('.binary kind.cop ty x y','.unary .bnot ty x').replace('Clif.Sem.binary kind.cop u v','Clif.Sem.unary .bnot u')
s=s.replace('∃ u v,','∃ u,').replace('∃ (u v : BitVec ty.width)','∃ (u : BitVec ty.width)').replace('{u v : BitVec ty.width}','{u : BitVec ty.width}')
s=s.replace(' ∧\n      (restrict fr (availOf f (availIn f result.ctx) bi j)).getAs y ty = .ok v','')
s=s.replace('    (getY : (restrict fr (availOf f (availIn f result.ctx) bi j)).getAs y ty = .ok v)\n','')
s=s.replace('    (selectedId : step.rules.getLast? = some kind.rule.id)\n','')
s=s.replace('    cases kind <;> simpa [Kind.cop,instOutcome] using evaluated','    simpa [instOutcome] using evaluated')
s=s.replace('  obtain ⟨u,v,getX,getY,_⟩ := evalInst_binary_inv (by cases kind <;> rfl) plain','  obtain ⟨u,getX,_⟩ := evalInst_unary_inv plain')
a=s.index('  have availableY :');b=s.index('theorem available_source',a)
s=s[:a]+'''  exact ⟨u,(getAs_congr (fr := fr) (fr' := restrict fr (availOf f (availIn f result.ctx) bi j))
      (x := x) (ty := ty) (restrict_regs_of_mem availableX)).trans getX⟩
'''+s[b:]
s=s.replace('  have availableY := restrict_regs_isSome (by rw [getAs_ok getY]; rfl)\n','')
a=s.index('  have originalY :');b=s.index('  have computed :',a);s=s[:a]+s[b:]
s=s.replace('    cases kind <;> simp [Kind.cop,instOutcome,Clif.evalInst,Clif.BinaryOp.isShift,originalX,originalY]','    simp [instOutcome,Clif.evalInst,originalX]')
a=s.index('  obtain ⟨ρ\',execution,value,kept,installed⟩ :=');b=s.index('  have post :=',a)
s=s[:a]+'''  have inventory := record_selected_rule_ids run scope events records source clif recorded emitted
  obtain ⟨id,last,member⟩ : ∃ id, step.rules.getLast? = some id ∧ id ∈ candidateIds := by
    simpa only [Option.any_eq_true,List.contains_iff_mem] using inventory
  have values : ∃ ρ', PRun F isem (record.output.emitted.toList.map (·.mapRegs
      (Backend.lowerFunction.resolve result.final.alias (result.final.alias.size+1)))) ρ ρ' ∧
      VHolds ⟨ty,Clif.Sem.unary .bnot u⟩ (ρ' record.input.base.nextVreg) ∧
      (∀ n, n ≠ record.input.base.nextVreg → ρ' n = ρ n) ∧
      ValuesHeld (fun y => Demanded record.input y ∧ y ∈ availOf f (availIn f result.ctx) bi (j+1))
        event.ctx (withValue fr z ⟨ty,Clif.Sem.unary .bnot u⟩)
        (fun k => ρ' (aliasNum result.final.alias k)) := by
    simp only [candidateIds,List.mem_cons,List.not_mem_nil,or_false] at member
    rcases member with rfl | rfl | rfl
    · exact LogicalNot.stock_lower_not_xor_available_values run scope dominated events records block statement current
        source clif results statementResults mapped recorded emitted last refines dfg held getX
    · exact Bnot.stock_lower_bnot_available_values run scope dominated events records block statement current
        true source clif results statementResults mapped recorded emitted last refines dfg held getX
    · exact Bnot.stock_lower_bnot_available_values run scope dominated events records block statement current
        false source clif results statementResults mapped recorded emitted last refines dfg held getX
  obtain ⟨ρ',execution,value,kept,installed⟩ := values
'''+s[b:]
s=s.replace('obtain ⟨u,v,getX,getY⟩ := source_operands','obtain ⟨u,getX⟩ := source_operands').replace('current kind source clif','current source clif').replace('emitted selectedId refines dfg held getX getY sourceStep','emitted refines dfg held getX sourceStep').replace('⟨u,v,ρ\',getX,getY,execution','⟨u,ρ\',getX,execution')
s='''import StockBnotDispatch
import FV.Backend.Proof.StockGuardedRecordValues
import FV.Backend.Proof.IselFamALUALogicNot
namespace Backend.Stock.Proof.BnotComplete
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm
'''+s+'\nend Backend.Stock.Proof.BnotComplete\n'
Path('/tmp/stock-not-next/StockBnotSourceTransfer.lean').write_text(s)
