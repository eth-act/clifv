import FVTest.Link.LeanLinkMain
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let mut count : Nat := 0
  for (name,_) in env.constants.toList do
    let some i := env.getModuleIdxFor? name | continue
    unless env.header.moduleNames[i]!.toString == "FVTest.Link.LeanLinkMain" do continue
    for ax in ← collectAxioms name do
      unless #[``propext,``Classical.choice,``Quot.sound].contains ax do
        throwError "disallowed executable axiom {ax} in {name}"
    count := count+1
  unless count > 0 do throwError "empty executable partition"
  logInfo m!"STOCK_SCALAR_OWNED_STANDARD_CORE {count}; executable FVTest.Link.LeanLinkMain"
