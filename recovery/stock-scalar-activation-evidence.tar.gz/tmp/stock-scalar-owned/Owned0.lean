import FV.Backend.ABIReadFlags
import FV.Backend.Lowering.StockMixed
import FV.Backend.Lowering.StockMixedNI
import FV.Backend.MixedNIProduction
import FV.Backend.Proof.StockMixedBodyRefines
import FV.Backend.Proof.StockMixedCheck
import FV.Backend.StockMixedCheck
import FV.E2E.ABIReadFlags
import FV.E2E.StockMixedNI
import FV.E2E.StockMixedWorldX
import FV.E2E.StockProductionFixtures
import FV.Backend.Proof.StockCmpWithFlags
import FV.Backend.Proof.StockContext
import FV.Backend.ABIReadOnly
import FV.Backend.ArithmeticNIProduction
import FV.Backend.ArithmeticProduction
import FV.Backend.Lowering.StockArithmetic
import FV.Backend.Lowering.StockArithmeticNI
import FV.Backend.Proof.ArithmeticProduction
import FV.Backend.Proof.StockArithmeticCheck
import FV.Backend.SemanticNICheck
import FV.Backend.StockArithmeticCheck
import FV.E2E.ABIReadOnlyCheck
import FV.E2E.ABIReadOnlyMachine
import FV.E2E.ABIReadOnlyRealize
import FV.E2E.ABIReadOnlySem
import FV.E2E.ABIReadOnlyTransport
import FV.E2E.ArithmeticPipeline
import FV.E2E.CompiledSemantic
import FV.E2E.CompiledSemanticNI
import FV.E2E.LinkSemanticNI
import FV.E2E.SemanticBinary
import FV.E2E.SemanticBinaryGood
import FV.E2E.SemanticChecksWith
import FV.E2E.SemanticExecBytes
import FV.E2E.SemanticExecFrameSim
import FV.E2E.SemanticExecGoodReads
import FV.E2E.SemanticExecGoodRun
import FV.E2E.SemanticExecGot
import FV.E2E.SemanticExecProven
import FV.E2E.SemanticExecRunN
import FV.E2E.SemanticExecStatic
import FV.E2E.SemanticLinkGood
import FV.E2E.SemanticNIBoundary
import FV.E2E.SemanticPipelineCheck
import FV.E2E.SemanticPreparedPipeline
import FV.E2E.SemanticStackBound
import FV.E2E.StockArithmeticNI
import FV.E2E.StockArithmeticStage
import FV.E2E.StockArithmeticWorldX
import FV.Link.SemanticCompileDefs
import FV.Link.SemanticCompileWith
import FV.Link.SemanticExeSourceWith
import FV.Link.SemanticExeWith
import FVTest.E2E.SemanticLinkProofWith
import FV.Backend.LogicalNIProduction
import FV.Backend.Lowering.StockLogical
import FV.Backend.Lowering.StockLogicalNI
import FV.Backend.Proof.StockLogicalBodyRefines
import FV.Backend.Proof.StockLogicalCheck
import FV.Backend.Proof.StockLogicalCompleteValues
import FV.Backend.Proof.StockLogicalDispatch
import FV.Backend.Proof.StockLogicalExtrMatch
import FV.Backend.Proof.StockLogicalExtrMatchReceipt
import FV.Backend.Proof.StockLogicalExtrMatchedValues
import FV.Backend.Proof.StockLogicalExtrRecord
import FV.Backend.Proof.StockLogicalExtrRhs
import FV.Backend.Proof.StockLogicalExtrSelectedValues
import FV.Backend.Proof.StockLogicalExtrSemantics
import FV.Backend.Proof.StockLogicalExtrSourceTransfer
import FV.Backend.Proof.StockLogicalExtrValues
import FV.Backend.Proof.StockLogicalNotrap
import FV.Backend.Proof.StockLogicalReturnRefines
import FV.Backend.Proof.StockLogicalScanRefines
import FV.Backend.Proof.StockLogicalSourceExecution
import FV.Backend.Proof.StockLogicalSourceTransfer
import FV.Backend.StockLogicalCheck
import FV.E2E.StockArithmeticStageContract
import FV.E2E.StockLogicalFixtures
import FV.E2E.StockLogicalNI
import FV.E2E.StockLogicalWorldX
import FV.Backend.ABIReadScalar
import FV.Backend.Lowering.StockScalar
import FV.Backend.Lowering.StockScalarNI
import FV.Backend.Proof.StockConstantRecordValues
import FV.Backend.Proof.StockConstantDispatch
import FV.Backend.Proof.StockConstantCompleteValues
import FV.Backend.Proof.StockConstantScanRefines
import FV.Backend.Proof.StockConstantBodyRefines
import FV.Backend.Proof.StockConstantNotrap
import FV.Backend.Proof.StockConstantReturnRefines
import FV.Backend.Proof.StockPureBodyFamilies
import FV.Backend.Proof.StockPureNotrap
import FV.Backend.Proof.StockPureReturnRefines
import FV.Backend.Proof.StockPureSourceExecution
import FV.Backend.Proof.StockScalarCheck
import FV.Backend.Proof.StockScalarConstantDomain
import FV.Backend.Proof.StockScalarContract
import FV.Backend.ScalarNIProduction
import FV.Backend.StockScalarCheck
import FV.E2E.ABIReadBoundary
import FV.E2E.ABIReadFlagsSteps
import FV.E2E.ABIReadScalar
import FV.E2E.StockScalarFixtures
import FV.E2E.StockScalarNI
import FV.E2E.StockScalarWorldX
import FV.E2E.SemanticFallbackWitness
import FV.E2E.SemanticMixedCompilerWitness
import FV.E2E.StockMixedWitness
import FV.E2E.ArithmeticPipelineWitness
import FV.E2E.SemanticCompilerWitness
import FV.E2E.StockArithmeticNIWitness
import FV.E2E.StockArithmeticStageWitness
import FV.Backend.Proof.StockLogicalCheckWitness
import FV.Backend.Proof.StockLogicalExtrValuesWitness
import FV.Backend.Proof.StockLogicalNotrapWitness
import FV.Backend.Proof.StockLogicalReturnWitness
import FV.Backend.Proof.StockLogicalSourceWitness
import FV.E2E.SemanticLogicalCompilerWitness
import FV.E2E.SemanticRoutesWitness
import FV.E2E.StockLogicalExtrCanonicalWitness
import FV.E2E.StockLogicalExtrMatchWitness
import FV.E2E.StockLogicalExtrRootWitness
import FV.E2E.StockLogicalExtrWitness
import FV.E2E.StockLogicalWitness
import FV.Backend.Proof.StockConstantBoundaryWitness
import FV.Backend.Proof.StockConstantCompleteWitness
import FV.E2E.StockScalarWitness
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let core := #["FV.Backend.ABIReadFlags", "FV.Backend.Lowering.StockMixed", "FV.Backend.Lowering.StockMixedNI", "FV.Backend.MixedNIProduction", "FV.Backend.Proof.StockMixedBodyRefines", "FV.Backend.Proof.StockMixedCheck", "FV.Backend.StockMixedCheck", "FV.E2E.ABIReadFlags", "FV.E2E.StockMixedNI", "FV.E2E.StockMixedWorldX", "FV.E2E.StockProductionFixtures", "FV.Backend.Proof.StockCmpWithFlags", "FV.Backend.Proof.StockContext", "FV.Backend.ABIReadOnly", "FV.Backend.ArithmeticNIProduction", "FV.Backend.ArithmeticProduction", "FV.Backend.Lowering.StockArithmetic", "FV.Backend.Lowering.StockArithmeticNI", "FV.Backend.Proof.ArithmeticProduction", "FV.Backend.Proof.StockArithmeticCheck", "FV.Backend.SemanticNICheck", "FV.Backend.StockArithmeticCheck", "FV.E2E.ABIReadOnlyCheck", "FV.E2E.ABIReadOnlyMachine", "FV.E2E.ABIReadOnlyRealize", "FV.E2E.ABIReadOnlySem", "FV.E2E.ABIReadOnlyTransport", "FV.E2E.ArithmeticPipeline", "FV.E2E.CompiledSemantic", "FV.E2E.CompiledSemanticNI", "FV.E2E.LinkSemanticNI", "FV.E2E.SemanticBinary", "FV.E2E.SemanticBinaryGood", "FV.E2E.SemanticChecksWith", "FV.E2E.SemanticExecBytes", "FV.E2E.SemanticExecFrameSim", "FV.E2E.SemanticExecGoodReads", "FV.E2E.SemanticExecGoodRun", "FV.E2E.SemanticExecGot", "FV.E2E.SemanticExecProven", "FV.E2E.SemanticExecRunN", "FV.E2E.SemanticExecStatic", "FV.E2E.SemanticLinkGood", "FV.E2E.SemanticNIBoundary", "FV.E2E.SemanticPipelineCheck", "FV.E2E.SemanticPreparedPipeline", "FV.E2E.SemanticStackBound", "FV.E2E.StockArithmeticNI", "FV.E2E.StockArithmeticStage", "FV.E2E.StockArithmeticWorldX", "FV.Link.SemanticCompileDefs", "FV.Link.SemanticCompileWith", "FV.Link.SemanticExeSourceWith", "FV.Link.SemanticExeWith", "FVTest.E2E.SemanticLinkProofWith", "FV.Backend.LogicalNIProduction", "FV.Backend.Lowering.StockLogical", "FV.Backend.Lowering.StockLogicalNI", "FV.Backend.Proof.StockLogicalBodyRefines", "FV.Backend.Proof.StockLogicalCheck", "FV.Backend.Proof.StockLogicalCompleteValues", "FV.Backend.Proof.StockLogicalDispatch", "FV.Backend.Proof.StockLogicalExtrMatch", "FV.Backend.Proof.StockLogicalExtrMatchReceipt", "FV.Backend.Proof.StockLogicalExtrMatchedValues", "FV.Backend.Proof.StockLogicalExtrRecord", "FV.Backend.Proof.StockLogicalExtrRhs", "FV.Backend.Proof.StockLogicalExtrSelectedValues", "FV.Backend.Proof.StockLogicalExtrSemantics", "FV.Backend.Proof.StockLogicalExtrSourceTransfer", "FV.Backend.Proof.StockLogicalExtrValues", "FV.Backend.Proof.StockLogicalNotrap", "FV.Backend.Proof.StockLogicalReturnRefines", "FV.Backend.Proof.StockLogicalScanRefines", "FV.Backend.Proof.StockLogicalSourceExecution", "FV.Backend.Proof.StockLogicalSourceTransfer", "FV.Backend.StockLogicalCheck", "FV.E2E.StockArithmeticStageContract", "FV.E2E.StockLogicalFixtures", "FV.E2E.StockLogicalNI", "FV.E2E.StockLogicalWorldX", "FV.Backend.ABIReadScalar", "FV.Backend.Lowering.StockScalar", "FV.Backend.Lowering.StockScalarNI", "FV.Backend.Proof.StockConstantRecordValues", "FV.Backend.Proof.StockConstantDispatch", "FV.Backend.Proof.StockConstantCompleteValues", "FV.Backend.Proof.StockConstantScanRefines", "FV.Backend.Proof.StockConstantBodyRefines", "FV.Backend.Proof.StockConstantNotrap", "FV.Backend.Proof.StockConstantReturnRefines", "FV.Backend.Proof.StockPureBodyFamilies", "FV.Backend.Proof.StockPureNotrap", "FV.Backend.Proof.StockPureReturnRefines", "FV.Backend.Proof.StockPureSourceExecution", "FV.Backend.Proof.StockScalarCheck", "FV.Backend.Proof.StockScalarConstantDomain", "FV.Backend.Proof.StockScalarContract", "FV.Backend.ScalarNIProduction", "FV.Backend.StockScalarCheck", "FV.E2E.ABIReadBoundary", "FV.E2E.ABIReadFlagsSteps", "FV.E2E.ABIReadScalar", "FV.E2E.StockScalarFixtures", "FV.E2E.StockScalarNI", "FV.E2E.StockScalarWorldX"]
  let witnesses := #["FV.E2E.SemanticFallbackWitness", "FV.E2E.SemanticMixedCompilerWitness", "FV.E2E.StockMixedWitness", "FV.E2E.ArithmeticPipelineWitness", "FV.E2E.SemanticCompilerWitness", "FV.E2E.StockArithmeticNIWitness", "FV.E2E.StockArithmeticStageWitness", "FV.Backend.Proof.StockLogicalCheckWitness", "FV.Backend.Proof.StockLogicalExtrValuesWitness", "FV.Backend.Proof.StockLogicalNotrapWitness", "FV.Backend.Proof.StockLogicalReturnWitness", "FV.Backend.Proof.StockLogicalSourceWitness", "FV.E2E.SemanticLogicalCompilerWitness", "FV.E2E.SemanticRoutesWitness", "FV.E2E.StockLogicalExtrCanonicalWitness", "FV.E2E.StockLogicalExtrMatchWitness", "FV.E2E.StockLogicalExtrRootWitness", "FV.E2E.StockLogicalExtrWitness", "FV.E2E.StockLogicalWitness", "FV.Backend.Proof.StockConstantBoundaryWitness", "FV.Backend.Proof.StockConstantCompleteWitness", "FV.E2E.StockScalarWitness"]
  let fixedFacts := #["Backend.Stock.Logical.actualChecked_true._native.native_decide.ax_1_1", "E2E.ArithmeticPipelineWitness.checks_true._native.native_decide.ax_1", "E2E.SemanticCompilerWitness.checks_true._native.native_decide.ax_1", "E2E.SemanticFallbackWitness.checks_true._native.native_decide.ax_1", "E2E.SemanticLogicalCompilerWitness.checks_true._native.native_decide.ax_1", "E2E.SemanticMixedCompilerWitness.checks_true._native.native_decide.ax_1", "E2E.SemanticRoutesWitness.checks_true._native.native_decide.ax_1", "E2E.StockArithmeticNIWitness.checks_true._native.native_decide.ax_1", "E2E.StockArithmeticStageWitness.checks_true._native.native_decide.ax_1", "E2E.StockLogicalExtrWitness.checks_true._native.native_decide.ax_1", "E2E.StockLogicalExtrWitness.match_checks_true._native.native_decide.ax_1", "E2E.StockLogicalNIWitness.checks_true._native.native_decide.ax_1", "E2E.StockLogicalNIWitness.source_checks_true._native.native_decide.ax_1_1", "E2E.StockMixedNIWitness.checks_true._native.native_decide.ax_1", "E2E.StockMixedNIWitness.source_checks_true._native.native_decide.ax_1_1", "E2E.StockScalarNIWitness.checks_true._native.native_decide.ax_1", "E2E.StockScalarNIWitness.source_checks_true._native.native_decide.ax_1_1", "_private.FV.E2E.StockLogicalExtrRootWitness.0.E2E.StockLogicalExtrWitness.recordChecks_true._native.native_decide.ax_1", "_private.FV.E2E.StockLogicalExtrRootWitness.0.E2E.StockLogicalExtrWitness.selectedRootChecks_true._native.native_decide.ax_1"]
  let mut ncore : Nat := 0
  let mut nwitness : Nat := 0
  for (name,_) in env.constants.toList do
    let some i := env.getModuleIdxFor? name | continue
    let owner := env.header.moduleNames[i]!.toString
    unless core.contains owner || witnesses.contains owner do continue
    for ax in ← collectAxioms name do
      if #[``propext,``Classical.choice,``Quot.sound].contains ax then continue
      unless witnesses.contains owner && fixedFacts.contains ax.toString do
        throwError "disallowed axiom {ax} in {name} owned by {owner}"
    if core.contains owner then ncore := ncore+1 else nwitness := nwitness+1
  unless ncore > 0 do throwError "empty core partition"
  unless nwitness > 0 do throwError "empty witness partition"
  logInfo m!"STOCK_SCALAR_OWNED_STANDARD_CORE {ncore}; FIXED_WITNESSES {nwitness}"
