from pathlib import Path
import json,hashlib,subprocess,datetime
root=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert head=='edfe4f4f13c65dd965a435f46bda63619965f065'
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
records=[]
for manifest,out in [('repaired-normal','repaired-normal-author'),('runtime','runtime-author'),('integration-repaired','integration-repaired-author'),('crate','crate-author'),('retention','retention-gates')]:
 m=read('/tmp/stock-scalar-'+manifest+'-manifest.json')
 for g in m['gates']:
  r=read('/tmp/stock-scalar-'+out+'/'+g['id']+'.json');assert r['state']=='passed' and r['returncode']==0,(g['id'],r)
  assert sha(r['log'])==r['log_sha256'],r['log']
  for p,h in r['outputs'].items():assert sha(p)==h,p
  records.append(r)
parity={}
for mode in ['e2e','legacy-e2e']:
 original=Path('/tmp/legacy-dead-cleanup-final-'+mode+'-identities.json');prior=Path('/tmp/stock-logical-retention-author/'+mode+'-identities.json');current=Path('/tmp/stock-scalar-retention-gates/'+mode+'-identities.json')
 def indexed(p):return {(x['file'],x['function'],x['index']):x['stages'] for x in read(p)['functions']}
 a,b,c=map(indexed,[original,prior,current]);assert len(a)==1150 and len(b)==1159
 for base in [a,b]:assert all(c.get(k)==v for k,v in base.items()),mode
 parity[mode]={'original':len(a),'prior_shipped':len(b),'current':len(c),'all_original_and_prior_identities_and_ordered_stages_preserved':True,'report_sha256':{str(p):sha(p) for p in [original,prior,current]}}
Path('/tmp/stock-scalar-identity-stage-parity.json').write_text(json.dumps(parity,indent=2))
for name in ['scalar','logical','mixed']:
 r=read('/tmp/stock-scalar-integration-repaired-author/'+name+'/receipt.json');assert r['state']=='passed'
 assert all(x['returncode']==0 and sha(x['log'])==x['sha256'] for x in r['records'].values())
owned=[r for r in records if r['id'].startswith('owned-')]; primary=[r for r in records if not r['id'].startswith('owned-')]
native=read('/tmp/stock-scalar-runtime-author/native/native-receipt.json');assert native['state']=='passed' and native['failures']==native['disagreements']==0
assert sha(root/'rust/target/release/clif-native')==native['native_binary_sha256']
receipt={'state':'per_pr_gates_passed','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'validated_source_head':head,'base_main':'22a05d3b94f9874ba4f408a7338c07d57fa12a0a','primary_gate_count':len(primary),'primary_gate_records':primary,'owned_gate_records':owned,'owned_core_constants':2588,'owned_fixed_witness_constants':634,'exact_declared_native_facts':19,'core_owners':106,'witness_owners':22,'normal_source_files':2674,'normal_library_jobs':2683,'checked_in_audits':46,'audited_roots':1378,'mcp_review':read('/tmp/stock-scalar-mcp-review.json'),'parity':{'axiom_sets':read('/tmp/stock-scalar-current-axiom-parity.json'),'old_headers':read('/tmp/stock-scalar-current-header-parity.json')},'identity_stage_parity':parity,'native_execution':native,'earlier_source_equivalence':read('/tmp/stock-scalar-later-delta-equivalence.json'),'prior_failures_preserved':True,'full_original_140_complete':False}
Path('/tmp/stock-scalar-terminal-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print('passed',len(primary),'primary gates,',len(owned),'ownership records')
