@kevaundray I inspected the RED CI run on arithmetic squash95b87108 (39621237870), rather than treating its skipped downstream gates as a compiler failure. Failed job119295314846 built all489/489 modules successfully, then normal replay failed while **leantar packed FV.Link.Ld.Layout**:

`thread 'main' panicked at src/lgz.rs:1317:9: assertion failed: s2.len() == s.len()`; leantar exited101. Source/proof compilation had completed; Layout.lean was not changed by #356. Current local unchanged-source normal-key replay includes Layout and passes. Full job log preserved at /tmp/stock-scalar-ci95b-shard0.log for the next remote evidence archive.

This appears to be the cache-packing/tool failure in that run, not an identified source regression to revert. Please investigate the CI artifact-packing path. The #140 scalar activation author gates continue locally on current22a05d3b, preserving normal Lake keys and original failed CI evidence; no failed gate is being relabelled green.
