import FV.E2E.StockScalarNI
import FV.E2E.StockScalarFixtures
open Backend E2E

def main : IO Unit := do
  for config in [Stock.D0.Configuration.systemVI32, .systemVI64] do
    match Stock.lower (StockScalarNIWitness.function config) with
    | .error e => IO.println e
    | .ok r =>
      for (b,bi) in r.code.blocks.toList.zipIdx do
        for (i,k) in b.insts.toList.zipIdx do
          unless Backend.ABIReadFlags.instruction (StockScalarNIWitness.function config).sig bi k i do
            IO.println s!"{repr config} {bi}/{k}: {repr i}"
