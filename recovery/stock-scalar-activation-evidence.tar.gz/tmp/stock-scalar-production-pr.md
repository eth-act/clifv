Enable actual Stock lowering for complete two-argument scalar-add functions across i32/i64 and default/SystemV/fast ABIs. The compiler, checked linker and generated proofs use the same selected artifacts; existing D0/prologue classes and transactional legacy retry remain available.

The complete source and executable witnesses cover every argument pair and arbitrary dirty upper bits. Actual retained-record execution connects the existing add/subtract source semantics to body composition. Generic compiler/execution/source/peak consumers are reused, and generated proofs explicitly import their selected lowerer while preserving the previous renderer default.

Validation (replace with terminal frozen author receipt before publishing):

- Targeted: 28 standard public compiler/class roots; 23 boundary roots, including 15 explicitly marked fixed native-data witnesses; 248 standard owned constants before expanded witness/fixture scans. One bundled MCP body-composition check uses standard three axioms with no source warnings.
- Actual mixed scalar/prologue/D0/legacy compilation, six configurations, both cleanup modes and forced allocator retry; ten linked cases and sixteen generated Lean files, including global/per-entry slicing; real verified linker/checker CLIs and both emitted proofs.
- Frozen current author gate: PENDING. Preserve all 1,150 original and 1,159 previously shipped identities and ordered stages in both modes. Include expanded owned scans and matched regalloc2 comparison.

Last continuous main gate is GREEN on #335/5a143135. This is one additional complete production class. Original #140 rule/effect coverage, source/block/whole-driver simulation and Stock-only completeness remain open, along with optimizer/exception consumers and eventual fallback retirement. Old theorem variants and input conditions are retained.
