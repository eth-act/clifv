from pathlib import Path
import os,time,json,subprocess as sp,datetime
view=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');p=Path('/tmp/stock-production-all-author-gates/progress.json');root=Path('/tmp/stock-scalar-class-probe');root.mkdir(exist_ok=True)
def report(state,**kw):
 d={'state':state,'pid':os.getpid(),'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),**kw};(root/'state.json').write_text(json.dumps(d,indent=2));print(json.dumps(d),flush=True)
report('waiting_for_owned_author_scheduler',author_pid=2099646)
while True:
 d=json.loads(p.read_text())
 if d['state']=='failed':report('deferred_author_gate_failed');raise SystemExit(0)
 if d.get('phase')!='all-modules':break
 try:os.kill(2099646,0)
 except ProcessLookupError:report('deferred_author_controller_missing');raise SystemExit(0)
 time.sleep(5)
env=dict(os.environ,FV_MEMCAP='4G',LEAN_NUM_THREADS='2',OMP_NUM_THREADS='2',OMP_THREAD_LIMIT='2');env['PATH']='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:'+env['PATH']
report('running_observation_only',cap='4G',concurrent_author_phase=d.get('phase'))
with (root/'observations.log').open('w') as f:r=sp.run(['scripts/memcap.sh','lake','env','lean','--root=/tmp','/tmp/StockScalarClassProbe.lean'],cwd=view,env=env,stdout=f,stderr=sp.STDOUT)
report('observations_complete' if r.returncode==0 else 'probe_failed',rc=r.returncode)
