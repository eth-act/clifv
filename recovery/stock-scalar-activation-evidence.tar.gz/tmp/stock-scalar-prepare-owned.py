from pathlib import Path
import json,re,subprocess
root=Path.cwd();out=Path('/tmp/stock-scalar-owned');old=json.load(open('/tmp/stock-logical-owned/partitions.json'))
core=list(old['core']);witness=list(old['witnesses'])
newcore=['FV.Backend.ABIReadScalar','FV.Backend.Lowering.StockScalar','FV.Backend.Lowering.StockScalarNI','FV.Backend.Proof.StockConstantRecordValues','FV.Backend.Proof.StockConstantDispatch','FV.Backend.Proof.StockConstantCompleteValues','FV.Backend.Proof.StockConstantScanRefines','FV.Backend.Proof.StockConstantBodyRefines','FV.Backend.Proof.StockConstantNotrap','FV.Backend.Proof.StockConstantReturnRefines','FV.Backend.Proof.StockPureBodyFamilies','FV.Backend.Proof.StockPureNotrap','FV.Backend.Proof.StockPureReturnRefines','FV.Backend.Proof.StockPureSourceExecution','FV.Backend.Proof.StockScalarCheck','FV.Backend.Proof.StockScalarConstantDomain','FV.Backend.Proof.StockScalarContract','FV.Backend.ScalarNIProduction','FV.Backend.StockScalarCheck','FV.E2E.ABIReadBoundary','FV.E2E.ABIReadFlagsSteps','FV.E2E.ABIReadScalar','FV.E2E.StockScalarFixtures','FV.E2E.StockScalarNI','FV.E2E.StockScalarWorldX']
newwitness=['FV.Backend.Proof.StockConstantBoundaryWitness','FV.Backend.Proof.StockConstantCompleteWitness','FV.E2E.StockScalarWitness']
core=list(dict.fromkeys(core+newcore));witness=list(dict.fromkeys(witness+newwitness))
text=Path('/tmp/stock-scalar-final-audits/stock-scalar-production.log').read_text();facts=sorted(set(re.findall(r'E2E\.StockScalarNIWitness\.(?:checks_true|source_checks_true)\._native\.native_decide\.ax_[\w]+',text)));assert len(facts)==2,facts
facts=sorted(set(old['exact_native_facts'])|set(facts));assert len(facts)==19
part={'base':'22a05d3b94f9874ba4f408a7338c07d57fa12a0a','candidate':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'core':core,'witnesses':witness,'exact_native_facts':facts,'executable_owners':['FVTest.Backend.Main','FVTest.E2E.LinkCheckMain','FVTest.Link.LeanLinkMain','FVTest.Backend.Lowering.StockScalarProductionRuntime','FVTest.Backend.Lowering.StockScalarProductionLinked']};(out/'partitions.json').write_text(json.dumps(part,indent=2))
oldscript=Path('/tmp/stock-logical-owned/Owned0.lean').read_text();body=oldscript[oldscript.index('open Lean Elab Command'):]
arr=lambda xs:'#['+', '.join(json.dumps(x) for x in xs)+']'
body=re.sub(r'  let core := #\[.*\]',lambda m:'  let core := '+arr(core),body)
body=re.sub(r'  let witnesses := #\[.*\]',lambda m:'  let witnesses := '+arr(witness),body)
body=re.sub(r'  let fixedFacts := #\[.*\]',lambda m:'  let fixedFacts := '+arr(facts),body).replace('STOCK_LOGICAL_OWNED','STOCK_SCALAR_OWNED')
(out/'Owned0.lean').write_text(''.join('import '+m+'\n' for m in core+witness)+body)
# Independent executable imports keep their global main/Opts declarations separate.
for i,owner in enumerate(part['executable_owners'],start=1):
 s=Path('/tmp/stock-logical-owned/Owned3.lean').read_text().replace('FVTest.Backend.Main',owner).replace('STOCK_LOGICAL_OWNED','STOCK_SCALAR_OWNED');(out/f'Owned{i}.lean').write_text(s)
print(len(core),'core owners;',len(witness),'fixed-witness owners;',len(facts),'exact native facts')
