import FV.E2E.StockScalarNI
import FV.E2E.StockScalarFixtures
import FV.Backend.LinearScan
open Backend Backend.Proof Backend.Proof.Driver E2E

def main : IO Unit := do
  for config in Stock.D0.configurations do
    let f := StockScalarNIWitness.function config
    IO.println s!"{repr config} source={lowerScopeB f} dominated={dominatedB f} abi={sigAbiOk f.sig} eligible={Stock.Scalar.activationEligible f}"
    match Stock.lower f with
    | .error e => IO.println s!"lower ERROR {e}"
    | .ok result =>
      IO.println s!"legacy={lowerCheck f result.code} reads={MixedFlagBoundary.check f.sig result.code} sourceOk={Stock.Scalar.sourceOk f} actual={Stock.Scalar.check f result.code}"
      for cleanup in [false,true] do
        match prepare (Stock.Arithmetic.stage cleanup result.code) with
        | .error e => IO.println s!"prepare ERROR {e}"
        | .ok vcp =>
          IO.println s!"cleanup={cleanup} prep={prepCheck (Stock.Arithmetic.stage cleanup result.code) vcp}"
          match leanAlloc vcp with
          | .error e => IO.println s!"allocation ERROR {e}"
          | .ok rf =>
            IO.println s!"allocation check={(checkAlloc vcp rf).isOk}"
            match lowerRFunc vcp rf with
            | .error e => IO.println s!"physical ERROR {e}"
            | .ok af =>
              match emitFunc 0 af with
              | .error e => IO.println s!"emit ERROR {e}"
              | .ok fa => IO.println s!"forms={formsCoveredB ⟨fa.k,af.slotBase⟩ vcp} layout={fa.layout.isOk}"
