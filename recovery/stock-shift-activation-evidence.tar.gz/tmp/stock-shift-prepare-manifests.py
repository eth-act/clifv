from pathlib import Path
import json,subprocess,os
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();base='1246b4554ba5c56efd0097c40c099fa897341f1c'
for name in ['normal','current-normal','native','integration','full','retention']:
 old=Path('/tmp/stock-mul-'+name+'-manifest.json').read_text();m=json.loads(old.replace('stock-mul','stock-shift'))
 m['base']=base;m['candidate']=head;m['packet']='shift-production-'+name
 m['env']['PATH']='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:/home/lee/.cargo/bin:/home/lee/clifv/.worktrees/stock-driver-incremental/rust/target/release:/home/lee/.local/share/clifv-test-tools/usr/bin:/home/lee/.rustup/toolchains/nightly-2026-09-26-x86_64-unknown-linux-gnu/lib/rustlib/x86_64-unknown-linux-gnu/bin:'+os.environ['PATH']
 m['historical_evidence']=['docs/research/stock-mul-production-activation.json']
 m['validation_scope']='Current shifts, retained multiplication, original flat multiply artifacts, all previous classes, and current full runtime/encoder/E2E/examples. Original input conditions and public headers/axiom sets and accepted identity/stage sets preserved.'
 if name=='native':
  m=json.loads(json.dumps(m).replace('STOCK_MUL','STOCK_SHIFT').replace('StockMulProduction','StockShiftProduction').replace('Stock mul','Stock shift').replace('"mul"','"shift"'))
  m['gates'][0]['outputs']=['{out}/native/*-plain.o','{out}/native/*-cleanup.o','{out}/native/*-plain.clif','{out}/native/*-cleanup.clif','{out}/native/*-plain.json','{out}/native/*-cleanup.json']
 if name=='integration':
  for g,kind in zip(m['gates'],['shift','mul']):
   g['outputs']=['{out}/'+kind+'/receipt.json'];g['id']=kind+'-actual-cli-link-generated';g['argv']=['python3','scripts/check-stock-mixed-integration.py','--output','{out}/'+kind,'--class',kind]
 if name=='retention':
  # Re-run the preserved original input/ELF, rather than manufacturing an equivalent source.
  for g in m['gates']:
   g['inputs']=['/tmp/stock-mul-retained-flat-multiply.py']
   g['argv']=[v.replace('/tmp/stock-shift-retained-flat-multiply.py','/tmp/stock-mul-retained-flat-multiply.py') for v in g['argv']]
 for g in m['gates']:
  if g['id']=='all-normal-library-keys':g['requires']=['All targets up-to-date']
 Path('/tmp/stock-shift-'+name+'-manifest.json').write_text(json.dumps(m,indent=2)+'\n')
print(head,'prepared 6 manifests')
