from pathlib import Path
import json,re,subprocess
old=json.loads(Path('/tmp/stock-mul-owned/partitions.json').read_text());out=Path('/tmp/stock-shift-owned');out.mkdir(exist_ok=True)
new_names=['StockScalarShiftDomain','StockShiftBitfieldHelper','StockShiftBitfieldMatch','StockShiftBitfieldRecordValues','StockShiftBitfieldRhs','StockShiftBitfieldSemantics','StockShiftBitfieldValues','StockShiftBodyRefines','StockShiftCompleteSourceTransfer','StockShiftDispatch','StockShiftNotrap','StockShiftReturnRefines','StockShiftScanRefines','StockShiftSourceTransfer']
core=old['core']+['FV.Backend.Proof.'+n for n in new_names]+['FV.E2E.ABIReadShiftSteps','FV.E2E.StockShiftFixtures'];witness=old['witnesses']+['FV.E2E.StockShiftWitness']
log=Path('/tmp/stock-shift-final-audits/stock-shift-production.log').read_text();new=sorted(set(re.findall(r'E2E\.StockShiftNIWitness\.(?:checks_true|source_checks_true)\._native\.native_decide\.ax_[\w]+',log)));assert len(new)==2,new
facts=sorted(set(old['exact_native_facts'])|set(new));assert len(facts)==25
owners=old['executable_owners']+['FVTest.Backend.Lowering.StockShiftProductionRuntime','FVTest.Backend.Lowering.StockShiftProductionLinked'];assert len(set(core))==len(core)
part={'base':'1246b4554ba5c56efd0097c40c099fa897341f1c','candidate':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'core':core,'witnesses':witness,'exact_native_facts':facts,'executable_owners':owners};(out/'partitions.json').write_text(json.dumps(part,indent=2))
body=Path('/tmp/stock-mul-owned/Owned0.lean').read_text();body=body[body.index('open Lean Elab Command'):];arr=lambda x:'#['+', '.join(json.dumps(s) for s in x)+']'
for name,values in [('core',core),('witnesses',witness),('fixedFacts',facts)]:body=re.sub(r'  let '+name+r' := #\[.*\]',lambda m:'  let '+name+' := '+arr(values),body)
body=body.replace('STOCK_MUL_OWNED','STOCK_SHIFT_OWNED');(out/'Owned0.lean').write_text(''.join('import '+n+'\n' for n in core+witness)+body)
for i,owner in enumerate(owners,1):(out/f'Owned{i}.lean').write_text('import Lean\n'+Path('/tmp/stock-not-owned/Owned1.lean').read_text().replace('FVTest.Backend.Main',owner).replace('STOCK_NOT_OWNED','STOCK_SHIFT_OWNED'))
m=json.loads(Path('/tmp/stock-shift-normal-manifest.json').read_text());m['packet']='shift-production-owned';m['gates']=[]
for i in range(len(owners)+1):m['gates'].append({'id':'owned-'+str(i),'argv':['lake','env','lean',str(out/f'Owned{i}.lean')],'requires':['STOCK_SHIFT_OWNED'],'complete_inputs':False})
Path('/tmp/stock-shift-owned-manifest.json').write_text(json.dumps(m,indent=2));print(len(core),len(witness),len(facts),len(owners))
