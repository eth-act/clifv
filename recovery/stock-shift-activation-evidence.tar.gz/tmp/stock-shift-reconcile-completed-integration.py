"""Validate completed successful subgates after an outer output-path reporting failure."""
from pathlib import Path
import json,hashlib,subprocess,runpy,os,sys
root=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');original=Path('/tmp/stock-shift-integration-author');inner=original/'shift';output=Path(sys.argv[1]);output.mkdir(parents=True,exist_ok=False)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
outer=read(original/'shift-actual-cli-link-generated.json')
assert outer['state']=='failed' and outer['returncode']==0,outer
expected='input/output pattern matched no files: '+str(original/'mul/receipt.json')
assert outer['error']==expected,outer['error']
assert sha(outer['log'])==outer['log_sha256']
# The hashed runner checks unchanged inputs before trying output collection.
# Preserve that original failed reporting record; never rewrite its state.
old=read(original/(outer['input_key']+'.inputs.json'))
lib=runpy.run_path(str(root/'scripts/stock-delivery-gates.py'),run_name='stock_gate_input_validation')
m=lib['load_manifest'](Path('/tmp/stock-shift-integration-manifest.json'))
m.update(_manifest_path='/tmp/stock-shift-integration-manifest.json',_manifest_sha256=sha('/tmp/stock-shift-integration-manifest.json'))
current={};lib['fingerprint'](m,m['gates'][0],root,original,current)
extra=set(current['environment'])-set(old['environment'])
allowed={'LAKE_ARTIFACT_CACHE','LAKE_RESTORE_ARTIFACTS','LAKE_CACHE_DIR','INVOCATION_ID'}
assert extra<=allowed,extra
if 'INVOCATION_ID' in extra:
 assert len(os.environ['INVOCATION_ID'])==32 and all(c in '0123456789abcdef' for c in os.environ['INVOCATION_ID'])
for k in extra:current['environment'].pop(k)
assert current==old,[k for k in current if current[k]!=old.get(k)]
assert lib['identity'](old)==outer['input_key']
r=read(inner/'receipt.json');assert r['state']=='passed' and len(r['records'])==32,r.get('state')
assert r['head']==outer['source_head']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert sha(root/'scripts/check-stock-mixed-integration.py')==r['script_sha256']
assert sha(inner/'sources.json')==r['source_manifest_sha256']
for name,h in read(inner/'sources.json').items():assert sha(root/name)==h,name
for x in r['records'].values():assert x['returncode']==0 and sha(x['log'])==x['sha256'],x
for name,h in r['generated_sources'].items():assert sha(inner/'linked'/name)==h,name
for name,h in r['linked_artifacts'].items():assert sha(inner/'linked'/name)==h,name
for name,h in r['cli_sources'].items():assert sha(inner/name)==h,name
assert sha(inner/'GeneratedAxioms.lean')==r['generated_axiom_audit_sha256']
assert sha(root/'rust/target/release/lean-regalloc')==r['regalloc_binary_sha256']
result={'state':'passed','source_head':r['head'],'successful_subgates':32,'original_outer_record':str(original/'shift-actual-cli-link-generated.json'),'original_outer_state':'failed','reason':expected,'original_command_exit':0,'original_input_key':outer['input_key'],'all_original_inputs_and_successful_subgate_logs_and_artifacts_verified':True,'outer_wrapper_only_environment_additions_excluded':sorted(extra),'inner_receipt':str(inner/'receipt.json'),'inner_receipt_sha256':sha(inner/'receipt.json'),'failed_record_preserved':True}
(output/'receipt.json').write_text(json.dumps(result,indent=2));print('COMPLETED_SHIFT_INTEGRATION_INPUTS_LOGS_AND_ARTIFACTS_PASS 32')
