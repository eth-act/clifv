import Crates.StockShiftProduction2CleanupFallbackGlobal
import Crates.StockShiftProduction2PlainFallbackGlobal
import Crates.StockShiftProduction2RetainedCleanupFallbackGlobal
import Crates.StockShiftProduction2RetainedPlainFallbackGlobal
import Crates.StockShiftProduction33CleanupFallbackEntries
import Crates.StockShiftProduction33CleanupFallbackGlobal
import Crates.StockShiftProduction6CleanupFallbackGlobal
import Crates.StockShiftProduction6CleanupStrictGlobal
import Crates.StockShiftProduction6MixedCleanupFallbackGlobal
import Crates.StockShiftProduction6MixedPlainFallbackGlobal
import Crates.StockShiftProduction6PlainFallbackGlobal
import Crates.StockShiftProduction6PlainStrictGlobal
import Crates.ShiftProductionCLIcurrentPlain
import Crates.ShiftProductionCLIretainedPlain
import Crates.ShiftProductionCLIcurrentCleanup
import Crates.ShiftProductionCLIretainedCleanup
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let generated := fun (name : Name) =>
    name.toString.startsWith "Crates.StockShiftProduction" || name.toString.startsWith "Crates.ShiftProductionCLI"
  let mut count : Nat := 0
  for (name, _) in env.constants.toList do
    unless generated name do continue
    for ax in ← collectAxioms name do
      if #[``propext, ``Classical.choice, ``Quot.sound].contains ax then continue
      unless generated ax && (ax.toString.splitOn "._native.native_decide.ax_").length > 1 do
        throwError "unexpected generated-proof axiom {ax} in {name}"
    count := count + 1
  unless count > 0 do throwError "empty generated-proof audit"
  logInfo m!"STOCK_SHIFTPRODUCTION_GENERATED_AXIOMS_PASS {count}"
