from pathlib import Path
import json,hashlib,subprocess,datetime,re
root=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
groups=[('normal','normal-author'),('native','native-current-author'),('owned','owned-author'),('integration-evidence','integration-evidence-current-author'),('mul-integration','mul-integration-author'),('full','full-author'),('retention-repaired','retention-current-author')]
records=[]
for manifest,out in groups:
 m=read('/tmp/stock-shift-'+manifest+'-manifest.json');assert m['candidate']==head
 for g in m['gates']:
  r=read('/tmp/stock-shift-'+out+'/'+g['id']+'.json');assert r['state']=='passed' and r['returncode']==0,(g['id'],r)
  assert r['source_head']==head
  assert sha(r['log'])==r['log_sha256']
  for p,h in r['outputs'].items():assert sha(p)==h,p
  records.append(r)
for path in ['/tmp/stock-shift-integration-author/shift','/tmp/stock-shift-mul-integration-author/mul']:
 r=read(path+'/receipt.json');assert r['state']=='passed' and len(r['records'])==32
 assert r['head']==head
 assert all(x['returncode']==0 and sha(x['log'])==x['sha256'] for x in r['records'].values())
 for n,h in r['generated_sources'].items():assert sha(Path(path)/'linked'/n)==h
 for n,h in r['linked_artifacts'].items():assert sha(Path(path)/'linked'/n)==h
 for n,h in r['cli_sources'].items():assert sha(Path(path)/n)==h
retained=read('/tmp/stock-shift-retention-current-author/retained/receipt.json');assert retained['state']=='passed';assert all(x.get('files_untouched',True) for x in retained['records'].values())
parity=read('/tmp/stock-shift-identity-stage-parity.json');assert all(x['current']==1159 and x['all_original_and_prior_identities_and_ordered_stages_preserved'] for x in parity.values())
ax=read('/tmp/stock-shift-axiom-parity.json');assert ax['exact_old_required_axiom_sets_preserved'] and ax['baseline_roots']==1428
headers=read('/tmp/stock-shift-header-parity.json');assert headers['unchanged'] and headers['old_public_headers']==34
review=read('/tmp/stock-shift-mcp-review.json');assert not review['isError'] and not review['structuredContent']['warnings'];assert set(review['structuredContent']['axioms'])=={'propext','Classical.choice','Quot.sound'}
owned=[r for r in records if r['id'].startswith('owned-')];primary=[r for r in records if not r['id'].startswith('owned-')]
assert len(primary)==18 and len(owned)==13,(len(primary),len(owned))
ownedlog=Path(next(r for r in owned if r['id']=='owned-0')['log']).read_text();core,witness=map(int,re.search(r'STANDARD_CORE (\d+); FIXED_WITNESSES (\d+)',ownedlog).groups())
normal=Path(next(r for r in primary if r['id']=='all-normal-library-keys')['log']).read_text();normalkeys=int(re.search(r'All targets up-to-date \((\d+) jobs\)',normal)[1])
native=read('/tmp/stock-shift-native-current-author/native/native-receipt.json');assert native['state']=='passed' and native['failures']==native['disagreements']==0;assert sha(root/'rust/target/release/clif-native')==native['native_binary_sha256'];assert native['lean_byte_executions']==1512
receipt={'state':'per_pr_gates_passed','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'validated_source_head':head,'base_main':'1246b4554ba5c56efd0097c40c099fa897341f1c','primary_gate_count':len(primary),'primary_gate_records':primary,'owned_gate_records':owned,'owned_core_constants':core,'owned_fixed_witness_constants':witness,'exact_declared_native_facts':25,'core_owners':138,'witness_owners':25,'executable_owners':12,'normal_scheduled_modules':2725,'normal_library_jobs':normalkeys,'checked_in_audits':len(list((root/'scripts/audit').glob('*.lean'))),'audited_roots':ax['current_roots'],'mcp_review':review,'parity':{'axiom_sets':ax,'old_headers':headers},'identity_stage_parity':parity,'native_execution':native,'prior_runtime_output_equivalence':read('/tmp/stock-shift-runtime-output-equivalence.json'),'old_native_expected_vectors_preserved':read('/tmp/stock-shift-native-grid-retention.json'),'actual_source_opcode_candidates':{'Ishl':[874,873],'Ushr':[893,884,883],'Sshr':[892,891,890]},'complete_witness_in_all_six_ABIs_and_both_cleanup_modes':True,'arbitrary_source_inputs_and_original_slot_witness':True,'count_source_type_deliberately_differs_from_result_type':True,'retained_original_flat_multiply':retained,'integration_reporting_reconciliation':read('/tmp/stock-shift-integration-evidence-current-author/validated/receipt.json'),'failed_attempts_preserved_never_counted':True,'verified_examples':{'fv-demo':{'tests':21,'verified_binaries':2},'survey':{'tests':53,'verified_binaries':18}},'full_original_140_complete':False,'next_cast_packet':read('/tmp/stock-cast-next-packet.json')}
Path('/tmp/stock-shift-terminal-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print('passed',len(primary),'primary gates,',len(owned),'ownership partitions;',normalkeys,'normal Lake keys;',core,'core/',witness,'fixed witnesses')
