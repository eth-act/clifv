from pathlib import Path
import json,datetime
receipt=json.loads(Path('/tmp/stock-shift-terminal-receipt.json').read_text());backup=json.loads(Path('/tmp/stock-shift-activation-backup/metadata.json').read_text());assert backup['remote_verified'] and backup['source_head']==receipt['validated_source_head'];receipt['remote_backup']=backup
Path('docs/research/stock-shift-production-activation.json').write_text(json.dumps(receipt,indent=2)+'\n')
Path('docs/research/stock-shift-production-activation.md').write_text('''# Stock shifts in default production

Validated source ca069aa6e6402915b0ecca4482e6bb2edcd37b6e, based on actual
main1246b455. The default shared scalar route now supports ordinary i32/i64
LSL/LSR/ASR and fused UBFM/SBFM shift pairs, including shifted NOT and count
values whose original source type differs from the shifted value. Original
input conditions, old theorem variants/selectors, required axiom sets, accepted
identities and successful stages remain. The cleanup whitelist is unchanged.

## Proof and production boundary

Actual original-source matching proves eight candidates: Ishl874/873,
Ushr893/884/883, Sshr892/891/890. ShiftComplete.record_source derives the chosen
case internally, reusing six existing bridges. The two fused cases derive
nested original definitions/counts, guarded requests, exact emission and
fresh-write preservation; actual retained binding and demand/availability
transfer establish original source execution. ShiftBody composes source order,
ABI entry/return and no-trap through the existing Scalar.Domain. Generic
compiler/checker/linker/generated-proof consumers are reused. Proved shift
step/frame/transport/machine facts extend the existing scalar ABI read boundary.

The complete witness includes all eight roots across six ABIs and two cleanup
modes, both register and immediate counts, opposite-width count constants,
fused shift pairs, shared values, shifted NOT, dead work, a ninth stack-passed
argument, arbitrary source inputs and the original arbitrary explicit slot.
Only two new fixed native facts enter witnesses; universal compiler proofs
remain standard-only. Successful Stock lowering remains a premise of the
source refinement; fallback does not prove Stock-only completeness.

## Validation

All18primary gates and13ownership partitions passed on the frozen source:
2728normal Lake keys (2725scheduled modules), four affected tools and1579crate
keys;49trust audits/1470roots;all1428previous required axiom sets and34old public
headers exact. Ownership audit covers2898Std3core/760fixedwitness constants,
138core/25witness/12executable owners and25exactnative facts (previous23+2).
One bundled domain MCP review reports only standard axioms and no warnings.

Strict real-regalloc2 and Lean allocation exercise whole-attempt retry and
missing-oracle controls.24actual objects pass1512native comparisons and378
Cranelift reference executions with zero failures/disagreements. Current shift
and retained-multiply actual CLI/link/generated cohorts each pass32subchecks,
including33-function slices, retained reconstruction, actual bytes, stack and
both preparation modes. Original flat-multiply inputs/ELF/proof sources remain
byte-exact and freshly regenerated current proofs compile in both modes.

Corpus4737pass/0fail with the same7known non-runnable cases; encoder1321identical/
0different. BothE2Emodes retain1159accepted/0rejected, preserving original1150
and prior1159identities and orderedstages exactly. Verifiedfv-demo passes21tests/
2binaries; survey53tests/18binaries.

## Provenance and recovery

The JSON receipt retains every passing record, input key, source head, log and
output hash. A wrong grouping in the witness expectation and a copied runtime
footer were caught and corrected; failures never count. The corrected arbitrary
input proof builds in6s with a bounded heartbeat budget. All72earlier strict
runtime outputs remain byte-identical to the fresh final run.

The original shift integration command completed all32subchecks with unchanged
inputs and intact artifact hashes, but outer reporting used a copied multiply
receipt path. Its failed outer record remains failed. A separate passing gate
verifies the complete original input fingerprint, all32successful subgates and
all generated/CLI/artifact hashes; only the known memcap cache exports and scope
INVOCATION_ID added by the validation wrapper are excluded when reproducing the
outer environment. The retained-multiply cohort ran separately with the correct
output path. A copied retained-script input path was repaired before that command
ran. No expensive successful subgate was relabelled or silently replayed.

Terminal evidence and all failures are remotely verified at
'''+backup['backup_commit']+' on '+backup['backup_branch']+'''.
Archive SHA256 '''+backup['archive_sha256']+''',
'''+str(backup['archive_bytes'])+'bytes/'+str(backup['files'])+'''files. It includes next-cast kernel inventory/drafts and unique retained
artifacts. Preserved recovery sources remain untouched; four necessary worktrees,
one warm cache,742GiBfree and max16GiBaggregate/max2jobs.

Full original #140 remains open: casts and every remaining scalar/effect/control/
call/source/block/whole-driver/completeness/production-consumer obligation.
Next cast inventory is kernel checked: Uextend810/811/815/808, Sextend824/819,
Ireduce946. Reuse existing guarded cast and zero-code alias-reduction bridges;
prove execution/exclusions before claiming complete cast activation.
''')
p=Path('docs/plans/stock-driver-incremental-delivery.md');s=p.read_text();a=s.index('Next: shifts/casts through the same contract.');z=s.index('\n## Maintained validation runner',a);s=s[:a]+'''The complete shift class passes all author gates through the same scalar
consumers. [Terminal evidence](../research/stock-shift-production-activation.md)
records18primary gates/13ownership partitions,2728normalkeys,1470audited roots,
1428oldAXsets/34oldheaders exact,1512native comparisons, two32subcheck actual
CLI/link/generated cohorts, original flat-multiply retention and all current
full gates. Validatedca069aa6 and terminal evidence are backed remotely at
'''+backup['backup_commit'][:8]+'''. Current source dispatch proves eight reachable shift roots;
historical counts are not semantic coverage. Both fused bitfield cases,
guarded source/body/entry-return/no-trap and ABI producer support are complete.
Old selectors, theorem variants and cleanup behavior remain.

Next: casts through the same contract. Kernel-checked original-source candidates
are Uextend810/811/815/808, Sextend824/819, Ireduce946. Reuse existing guarded
base extension and zero-code reduction/alias bridges. Discharge the remaining
look-through cases by execution or proved source-family exclusions before class
activation. Then finish every unchanged original140scalar/control/memory/trap/
effect/call/source/block/whole-driver/completeness/consumer obligation. Fallback
is not Stock-only completeness; full original140 remains unfinished.
'''+s[z:];p.write_text(s)
p=Path('docs/research/stock-driver-obligations.json');x=json.loads(p.read_text());x['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();x['production']['landed'].append('i32/i64 ordinary shifts and fused bitfield pairs through shared scalar consumers (validated, squash pending)');x['production']['pending']='Casts: kernel-checked Uextend810/811/815/808, Sextend824/819, Ireduce946. Reuse guarded base cast/reduction bridges, discharge look-through cases, extend scalar ABI step facts and complete production class. Then all remaining original scalar/control/memory/trap/effect/call/source/block/whole-driver/completeness/consumer obligations.'
actual={873,874,883,884,890,891,892,893}
for r in x['roots']:
 if r['id'] in actual:
  r['status']='actual source selection/request/execution/retained binding/guarded transfer and complete shipped shift-body/entry/default consumers validated; squash pending'
  r['current_proofs']=['ShiftComplete.selected_rule_ids','ShiftComplete.record_source','stock_lower_shift_scan_fall_refines','stock_lower_mixed_shift_body_fall_refines','ShiftBody.actual_shift_body_refines','ShiftBody.actual_shift_entry_return_refines_frame','Scalar.domain_of_shift']
  if r['id'] in {892,893}:r['saved_guarded_bridge']='FV/Backend/Proof/StockShiftBitfieldRecordValues.lean'
  r['production_receipt']='docs/research/stock-shift-production-activation.json';r['completeness']='Stock-only selection/request/lowering success and whole-driver completeness remain open; successful-run refinement is not totality.'
 elif r['primary_opcode'] in ['Ishl','Ushr','Sshr']:
  r['current_original_source_scope']='Excluded under unchanged original-source LowerScope/MappedCtxInv by ShiftComplete.selected_rule_ids and opcode_inventory; no reachability or execution conclusion for other scopes.'
  r['scope_exclusion_proof']='FV/Backend/Proof/StockShiftDispatch.lean'
p.write_text(json.dumps(x,indent=2)+'\n')
