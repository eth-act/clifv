# Stock driver completion (#140)

State: active. Full original #140 remains unfinished. Owner @codygunton and this agent.
Updated UTC: 2026-10-21T21:55:25.709095+00:00

## Current delivery

Branch agent/stock-shift-cast-activation-20261021, pushed ca069aa6e6402915b0ecca4482e6bb2edcd37b6e, based actual main1246b455. Active view /home/lee/clifv/.worktrees/stock-driver-incremental. Preserved source /home/lee/clifv/.worktrees/driver-proof-resume remains untouched.

Complete shift source class and production wiring implemented: all8actual source roots (873/874,883/884,890/891,892/893), ordinary register/immediate shifts and fused bitfields, original typed counts, guarded requests/retained bindings/source/body/entry-return/no-trap, reusable Scalar.Domain, existing ABI read/transport/machine and compiler/checker/linker/generated-proof consumers. Old selectors/theorem variants and cleanup whitelist remain. No shared Arm/MInst/allocator edits.

Passed:2725normal library keys and4affected tools;49trust audits/1470roots;all1428prior required axiom sets/34old public headers exact;2898Std3core/760fixedwitness constants,25exactnativefacts(previous23+2),138core/25witness/12executable owners. One bundled domain MCP Std3/no warnings; completed owned server released.

Strict runtime: all6ABIs×2cleanup modes with both allocators, whole-attempt retry and missing-real-oracle controls.24objects/1512native comparisons/378Cranelift reference executions,0failures/disagreements. All72pre-fix runtime outputs remain byte-exact. A witness formula grouping bug and copied footer were caught and fixed; failed records preserved and never counted. Correct arbitrary-input/source-slot witness compiles in6s with bounded proof elaboration.

Current full gates:1579crate keys, corpus4737pass/0fail/same7known non-runnable cases; encoder1321identical/0different. BothE2Emodes1159accepted/0rejected preserve original1150/prior1159identities and orderedstages exactly. Verified fv-demo 21 tests / 2 binaries and survey 53 tests / 18 binaries passed. Current shift and retained-multiply actual CLI/link/generated-proof cohorts and original flat-multiply artifact retention remain in progress before PR/merge. Sources/HEAD frozen during these gates.

Likely modules: StockShift* and StockScalarShiftDomain, existing StockScalar/check, ABIReadScalar/ABIReadShiftSteps, SemanticNIBoundary and complete fixture/test/audit helpers. Plan docs/plans/stock-driver-incremental-delivery.md; full remaining obligations docs/research/stock-driver-obligations.json. Next (not a reservation): finish author gates, remotely back terminal evidence and squash this class, then casts and every remaining original140scalar/control/memory/trap/effect/call/source/block/whole-driver/completeness/consumer obligation. Fallback is not Stock-only completeness. Cast discovery finds7original-source candidates; reconcile/exclude/prove all before claiming a complete cast class.

## Landed during this implementation resume

#357 ba08bcaf add/sub/select; #35840333cb4 bounded gate runner; #359779bc7ba AND/OR/XOR; #36022a05d3b constant selected-record/body prerequisite; #361150738a9 complete constants/shared scalar consumers; #3620ce772eb NOT/NOT-of-XOR; #3631246b455 multiplication/fused multiply. Exact squash trees verified against validated source plus documentation receipts; integrator notified140/261. Permanent docs/research/stock-{mixed,logical,scalar,not,mul}-production-activation receipts retain the evidence.

## Preservation/resources

All original input conditions, theorem variants, required axioms, accepted identities/stages and saved source remain mandatory. Canonical dirty driver-proof-resume1874paths untouched/backed29f6be2f; superseded logical source backedfc1bb8e1; constant prerequisite backedaeaaf5e5. Terminal scalar evidence fe81690d, NOT817b6526, multiply9c3f26fd. Shift source checkpoints1f592ff0/58a6e0e2/currentca069aa6 pushed. An inherited NOT export path was repaired by restoring194scalar files byte-exact from the prior archive, with unique NOT data separately preserved; recovery evidence is retained.

Four necessary worktrees, one physical warm cache,742GiBfree, max16GiB aggregate/max2jobs. No new worktree/cache, no other-project cleanup and no healthy kernel kills. Unneeded generated outputs are archived then removed after each delivery. Current contributor statuses52/71 and task140 read; no concrete conflict or additional main drift detected.

Terminal shift gates complete:18primary/13ownership records; validatedca069aa6 plus documentation-only d733bcf478b05e27f3a3baea11e5b887ce62a31f. Remote evidence de6aae6e05c2a21ae1cc5709ed575fcb67dea354; archiveSHA0001730428d06e8ad64bf73e233f45ffd1469369b2e9a3d13f37ba1c04840e51,10,143,570bytes/998files. Both current shift and retained-multiply cohorts32checks passed. Original shift outer reporting typo remains a failed record; independent passing validation confirms exact unchanged original inputs and every successful subgate/artifact hash. Preparing non-draft PR/squash. Current normal footer2728Lakekeys/2725scheduled modules. Updated UTC: 2026-10-21T22:09:13.319085+00:00

#364 merged4966cf92f6be6d981b3600410708c5cd89cd9b36 at2026-10-21T22:09:26Z; exact squash tree equals validatedca069aa6+documentationd733bcf4. Integrator notified140/261. Current branch agent/stock-cast-activation-20261021 at actual main4966cf92 in the same view. Cast inventory3kernel-checked examples backed in shift evidence: Uextend810/811/815/808, Sextend824/819, Ireduce946. Starting pure-source exclusions/selection and existing guarded cast/alias bridges, then complete production activation and remaining140scope. Removed46expendable generated outputs/7.8MB after verified backup; unique sources/logs/encoded bytes remain. Four views/one warm cache/741GiBfree. Updated UTC: 2026-10-21T22:12:20.875292+00:00

Cast source checkpoint db42a162962a94db5f745ac787e7ef237170d64e:4new modules compile. Current7root inventory, original-statement-family provenance, syntax-derived load/comparison pattern exclusions and base cast selection are proved; existing guarded extension/source and zero-code reduction/alias bridges now transfer actual source steps with no caller root certificate. Original LowerScope and old theorem variants remain. This is a remote proof/source backup; cast production activation, ABI read support, complete witnesses and author gates still pending. Updated UTC: 2026-10-21T22:29:02.799937+00:00
