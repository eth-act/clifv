import StockPopcountScope
#print axioms Backend.Stock.Proof.UnchangedHelper.observe
#print axioms Backend.Stock.Proof.Popcount.helpers_unchanged
#print axioms Backend.Stock.Proof.Popcount.helpers_closed
