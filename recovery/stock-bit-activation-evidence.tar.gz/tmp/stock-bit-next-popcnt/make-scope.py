from pathlib import Path
import json
x=json.loads(Path('/tmp/stock-bit-next-popcnt/closure.json').read_text());ts=x['terms'];branches=' | '.join('rfl' for _ in ts)
s='''import StockUnchangedHelper
import FV.Backend.Proof.IselFamAluBPopcnt
namespace Backend.Stock.Proof.Popcount
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option Elab.async false
set_option maxHeartbeats 1000000

def helperScope : List Nat := '''+str(ts)+'''

theorem helpers_unchanged {p : Program} (hp : Data p) :
    ∀ t term,t ∈ helperScope → termOf p t = .ok term → term.id ∉ revisedCtors := by
  intro t term member lookup
  simp only [helperScope,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with '''+branches+'\n'
for t in ts:s+=f'  · rw [hp.t{t}] at lookup\n    cases lookup\n    decide +kernel\n'
s+='''
theorem helpers_closed {p : Program} (hp : Data p) :
    ∀ t term,t ∈ helperScope → termOf p t = .ok term →
      ∀ flags ex,term.kind = .decl flags (some .internal) ex →
        ∀ r ∈ p.rulesOf t,RuleScoped (fun k => k ∈ helperScope) r := by
  intro t term member lookup flags ex kind r recorded
  simp only [helperScope,List.mem_cons,List.not_mem_nil,or_false] at member
  rcases member with '''+branches+'\n'
for t in ts:
 s+=f'  · rw [hp.t{t}] at lookup\n    cases lookup\n'
 rs=x['internal_rules'].get(str(t))
 if not rs:s+='    cases kind\n'
 else:
  s+=f'    rw [hp.r{t}] at recorded\n    simp only [List.mem_cons,List.not_mem_nil,or_false] at recorded\n'
  facts='RuleScoped,IfLetsScoped,ExprScoped,exprCalls,bindCalls,argCalls,helperScope,'+','.join(r['rule'] for r in rs)
  if len(rs)>1:s+='    rcases recorded with '+' | '.join('rfl' for _ in rs)+'\n    all_goals simp ['+facts+']\n'
  else:s+='    subst r\n    simp ['+facts+']\n'
s+='end Backend.Stock.Proof.Popcount\n';Path('/tmp/stock-bit-next-popcnt/StockPopcountScope.lean').write_text(s)
