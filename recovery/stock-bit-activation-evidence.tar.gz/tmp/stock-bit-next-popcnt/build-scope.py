import os,subprocess
from pathlib import Path
folder=Path('/tmp/stock-bit-next-popcnt');env=dict(os.environ);env['LEAN_PATH']=env.get('LEAN_PATH','')+':'+str(folder)
r=subprocess.run(['lean','--root='+str(folder),'-o',str(folder/'StockPopcountScope.olean'),str(folder/'StockPopcountScope.lean')],env=env,text=True,capture_output=True)
(folder/'scope-build.log').write_text(r.stdout+r.stderr);print(r.stdout+r.stderr);raise SystemExit(r.returncode)
