import os,subprocess,re,json
from pathlib import Path
folder=Path('/tmp/stock-bit-next-popcnt');env=dict(os.environ);env['LEAN_PATH']=env.get('LEAN_PATH','')+':'+str(folder)
r=subprocess.run(['lean','--root='+str(folder),str(folder/'Review.lean')],env=env,text=True,capture_output=True);out=r.stdout+r.stderr;(folder/'helper-audit.log').write_text(out)
assert r.returncode==0,out
roots={n:[a.strip() for a in axes.split(',') if a.strip()] for n,axes in re.findall(r"^'(.+)' depends on axioms: \[([^]]*)\]",out,re.M)}
roots.update({n:[] for n in re.findall(r"^'(.+)' does not depend on any axioms",out,re.M)});assert len(roots)==3;assert all(set(a)<={'propext','Classical.choice','Quot.sound'} for a in roots.values());(folder/'helper-audit.json').write_text(json.dumps({'prototype_only':True,'roots':roots},indent=2)+'\n');print(out)
