from pathlib import Path
import re,json
rules={}
for p in Path('FV/Isle/Generated').glob('Rules*.lean'):
 s=p.read_text();starts=list(re.finditer(r'^def (\w+) : Rule where\n',s,re.M))
 for i,m in enumerate(starts):
  chunk=s[m.end():starts[i+1].start() if i+1<len(starts) else len(s)]
  term=re.search(r'^  term := (\d+)\s*$',chunk,re.M)
  if not term:continue
  a=chunk.index('  iflets :=');z=chunk.index('  vars :=',a)
  calls=set(map(int,re.findall(r'\.term\s+\d+\s+(\d+)',chunk[a:z])))
  rules.setdefault(int(term[1]),[]).append({'rule':m[1],'calls':sorted(calls)})
roots=[409,410,414,524,469,473];scope=set(roots)
while True:
 nxt=scope|{t for k in scope for r in rules.get(k,[]) for t in r['calls']}
 if nxt==scope:break
 scope=nxt
x={'kind':'conservative textual discovery; kernel closure proof still required','roots':roots,'terms':sorted(scope),'internal_rules':{str(k):rules[k] for k in sorted(scope) if k in rules}}
Path('/tmp/stock-bit-next-popcnt/closure.json').write_text(json.dumps(x,indent=2)+'\n');print('terms',sorted(scope));print('rules',sum(len(v) for v in x['internal_rules'].values()))
