import Crates.StockCastProduction2CleanupFallbackGlobal
import Crates.StockCastProduction2PlainFallbackGlobal
import Crates.StockCastProduction2RetainedCleanupFallbackGlobal
import Crates.StockCastProduction2RetainedPlainFallbackGlobal
import Crates.StockCastProduction33CleanupFallbackEntries
import Crates.StockCastProduction33CleanupFallbackGlobal
import Crates.StockCastProduction6CleanupFallbackGlobal
import Crates.StockCastProduction6CleanupStrictGlobal
import Crates.StockCastProduction6MixedCleanupFallbackGlobal
import Crates.StockCastProduction6MixedPlainFallbackGlobal
import Crates.StockCastProduction6PlainFallbackGlobal
import Crates.StockCastProduction6PlainStrictGlobal
import Crates.CastProductionCLIcurrentPlain
import Crates.CastProductionCLIretainedPlain
import Crates.CastProductionCLIcurrentCleanup
import Crates.CastProductionCLIretainedCleanup
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let generated := fun (name : Name) =>
    name.toString.startsWith "Crates.StockCastProduction" || name.toString.startsWith "Crates.CastProductionCLI"
  let mut count : Nat := 0
  for (name, _) in env.constants.toList do
    unless generated name do continue
    for ax in ← collectAxioms name do
      if #[``propext, ``Classical.choice, ``Quot.sound].contains ax then continue
      unless generated ax && (ax.toString.splitOn "._native.native_decide.ax_").length > 1 do
        throwError "unexpected generated-proof axiom {ax} in {name}"
    count := count + 1
  unless count > 0 do throwError "empty generated-proof audit"
  logInfo m!"STOCK_CASTPRODUCTION_GENERATED_AXIOMS_PASS {count}"
