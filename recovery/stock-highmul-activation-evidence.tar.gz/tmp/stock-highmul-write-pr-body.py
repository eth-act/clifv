from pathlib import Path
import json
r=json.load(open('/tmp/stock-highmul-terminal-receipt.json'));b=json.load(open('/tmp/stock-highmul-activation-backup/metadata.json'))
text=f'''The default shared Stock scalar route now handles signed and unsigned i32/i64 high multiplication alongside every previously activated class, across compiler, checker, linker and generated-proof consumers.

This reuses the existing complete instruction-derived highmul source transfer and adds mixed scan/body/entry-return/domain composition plus exact virtual SMULH/UMULH ABI framing. All earlier theorem variants, selectors, source conditions and required axioms remain. No Arm/MInst, allocator or cleanup whitelist edits.

Validation reconciled with main `{r['base_main']}` at `{r['validated_source_head']}`:

- 22 primary checks / 25 ownership partitions; {r['normal_library_jobs']:,} normal keys; {r['checked_in_audits']} audits / {r['audited_roots']:,} roots. All 1,675 recorded prior axiom sets and 32 public headers exact. {r['owned_core_constants']:,} core constants use standard axioms; fixed witnesses use the declared 37 exact native facts.
- Complete six-ABI/cleanup witnesses retain arbitrary inputs/slot and every prior computation. Actual roots 777/778/779/780 and retained 811/819/958 are covered. Native execution: 24 objects, 2,832 QEMU comparisons, 708 Cranelift references, zero failures/disagreements; eleven prior grids exact.
- Current highmul and retained comparison CLI/link/generated-proof cohorts each pass 32/32. The new 33-entry cohort uses one complete highmul function plus 32 D0 companions, preserving multi-slice/per-entry coverage. Original flat-multiply artifacts and current proof reconstruction pass.
- Runtime 4,737/0/0, same seven non-runnable cases; encoder 1,321 identical/0 different; both E2E modes 1,159 accepted/0 rejected with identities/stages exact; verified demo 21 tests/2 binaries, survey 53 tests/18 binaries. One bundled MCP review: standard axioms, no warnings.

The fixture repair and additive main reconciliation have explicit source/import-closure/tool-hash evidence. Current normal/trust, affected executable ownership and the repaired cohort were rerun; unaffected earlier records retain their actual source heads. Every unrelated captured executable is byte-identical. No historical pass was relabelled. Logs preserve the pre-existing StockBlockScan witness-initializer diagnostic also present in #384; symbolization/baseline comparison are recorded separately from outcomes.

Receipt: `docs/research/stock-highmul-production-activation.md` and adjacent JSON. Remote evidence `{b['backup_commit']}`, archive SHA256 `{b['archive_sha256']}`.

Full original #140 remains open. Successful Stock.lower is still a correctness premise; Stock-only completeness, remaining widths/ABIs/control/memory/traps/effects/calls and whole-driver obligations remain. Next: division/remainder with genuine zero/overflow outcomes, reusing existing source/trap proofs.

Refs #140, #44.
'''
Path('/tmp/stock-highmul-pr-body.md').write_text(text)
