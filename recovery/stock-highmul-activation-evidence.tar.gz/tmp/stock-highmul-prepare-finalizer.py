from pathlib import Path
s=Path('/tmp/stock-cmp-terminal-finalize.py').read_text()
s=s.replace('/tmp/stock-cmp-terminal-','/tmp/stock-highmul-final-').replace('/tmp/stock-cmp-','/tmp/stock-highmul-').replace('minmax-integration','cmp-integration')
a=s.index('for kind,path in ');b=s.index('\n r=read(path/',a);s=s[:a]+"for kind,path in [('highmul',Path('/tmp/stock-highmul-final-integration-author/highmul')),('cmp',Path('/tmp/stock-highmul-final-cmp-integration-author/cmp'))]:"+s[b:]
s=s.replace("ax['baseline_roots']==1601","ax['baseline_roots']==1675").replace("headers['old_public_headers']==35","headers['old_public_headers']==32").replace('len(owned)==23','len(owned)==25').replace("native['lean_byte_executions']==2640","native['lean_byte_executions']==2832")
s=s.replace("'base_main':'031df150fa2aeb626906814783011a805b4ae92b'","'base_main':'13138d1d316e9f1a4cd2b69481841af0c929964e'").replace("'new_proved_source_operations':['icmp','uextend-of-icmp811']","'new_proved_source_operations':['smulhi','umulhi']").replace("'executed_new_roots':[811,958]","'executed_new_roots':[777,778,779,780]").replace("'executed_fixture_roots':[811,819,958]","'executed_fixture_roots':[777,778,779,780,811,819,958]")
s=s.replace("'next':'High multiply/division/remainder and complete original integer widths/ABIs; every remaining original #140 control/memory/trap/effect/call/source/block/whole-driver simulation/completeness/consumer obligation remains.'","'next':'Division/remainder including original trapped outcomes; complete original widths/ABIs; every remaining original #140 control/memory/effect/call/source/block/whole-driver simulation/completeness/consumer obligation remains.'")
s=s.replace("Path('/tmp/stock-highmul-final-receipt.json')","Path('/tmp/stock-highmul-terminal-receipt.json')")
# The unchanged generic private-native audit's negative controls are historical #384 evidence.
a=s.index('auditControl=');b=s.index("receipt={'state'",a);s=s[:a]+s[b:]
a=s.index("'generated_private_native_ownership_controls':");b=s.index("'mcp_review':",a);s=s[:a]+s[b:]
# Verify the reviewed source closure directly; the only later change was a test log label.
s=s.replace("review=read('/tmp/stock-highmul-mcp-review.json');", "assert all(sha(p)==h for p,h in reviewProvenance['source_sha256'].items());review=read('/tmp/stock-highmul-mcp-review.json');")
s=s.replace("'native_fixture_execution_in_both_integrations':True,","'native_fixture_execution_in_both_integrations':True,'new_33_entry_cohort':'one complete highmul function plus32D0 entries; all six ABI/cleanup witnesses and unchanged retained comparison cohort preserved',")
Path('/tmp/stock-highmul-finalize.py').write_text(s);compile(s,'highmul-finalizer','exec');print('Prepared highmul terminal collector; no pass claimed until all gates complete.')
