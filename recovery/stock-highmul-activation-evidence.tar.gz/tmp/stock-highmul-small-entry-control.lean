import FV.Backend.Lowering.StockScalarNI
import FV.Backend.Lowering.StockD0
open Backend

def main : IO Unit := do
  for config in Stock.D0.configurations do
    let f := Stock.D0.source "small_highmul_cohort_entry" config []
    let actual ← match Stock.Scalar.lowerValidated f with
      | .ok vc => pure vc
      | .error message => throw (IO.userError message)
    let previous ← match Stock.Arithmetic.lowerValidated f with
      | .ok vc => pure vc
      | .error message => throw (IO.userError message)
    unless decide (actual = previous) && Backend.Proof.Driver.lowerCheck f actual do
      throw (IO.userError s!"small existing-class provenance failed: {repr config}")
  IO.println "SMALL_D0_ENTRIES_RETAIN_EXISTING_VALIDATED_ROUTE_PASS_6"
