from pathlib import Path
import json,datetime
r=json.loads(Path('/tmp/stock-highmul-terminal-receipt.json').read_text());b=json.loads(Path('/tmp/stock-highmul-activation-backup/metadata.json').read_text());r['remote_backup']=b
Path('docs/research/stock-highmul-production-activation.json').write_text(json.dumps(r,indent=2)+'\n')
text=f'''# Stock high-multiply production activation

Validated source `{r['validated_source_head']}` reconciles main `{r['base_main']}`.
The default shared Scalar compiler, checker, linker and generated-proof consumers
accept signed/unsigned i32/i64 high multiplication mixed with every prior class.
The original #140 goal remains unfinished.

The existing complete `ScalarHighMul.stock_lower_highmul_source_by_instruction`
bridge supplies actual operand extraction, selected emission, retained binding,
final aliases, fresh-register separation and guarded original-source transfer.
The new family/scan/body/entry-return/domain composition reuses that bridge and
all previous handlers. Exact virtual-register SMULH/UMULH ABI framing extends
shared consumers. No Arm/MInst, allocator, cleanup whitelist, original source
condition or old theorem-variant changes. Source proofs cover 8/16/32/64;
production activation remains i32/i64.

A complete witness appends eight live statements to the comparison function.
All prior computation and comparison/cast roots 811/819/958 remain live;
width-appropriate signed/unsigned roots cover 777/778/779/780. Inputs and the
original explicit slot are arbitrary in all six ABIs and both cleanup modes.
Every prior native test grid is retained exactly.

The newly introduced 33-entry fixture uses one complete high-multiply function
and 32 small D0 companions. It tests both proof slices and per-entry/global
linking without compiling 33 copies of the same large function. High-multiply
entries retain strict semantic-route assertions; D0 companions require exact
existing Arithmetic output and its original checker. The unchanged full
comparison cohort also passes. Failed fixture drafts remain preserved.

All {r['primary_gate_count']} primary checks and {len(r['owned_gate_records'])} ownership partitions pass with explicit source provenance:

- {r['normal_library_jobs']:,} normal keys / {r['normal_scheduled_modules']:,} modules; {r['checked_in_audits']} checked-in audits / {r['audited_roots']:,} roots. All 1,675 previously recorded axiom sets and 32 public headers remain exact. The new main trap proofs have unchanged source/dependency closures and pass the refreshed audit.
- {r['owned_core_constants']:,} owned core constants use only standard axioms; {r['owned_fixed_witness_constants']:,} fixed-witness constants use the declared 37 exact native facts. Ownership covers 248 core, 31 witness and 24 executable modules.
- 24 actual objects, 2,832 QEMU comparisons and 708 Cranelift references; zero failures/disagreements. All eleven prior grids are exact.
- Current high-multiply and retained comparison CLI/checker/link/generated-proof cohorts each pass 32/32. Original flat-multiply artifacts remain untouched and pass current proof reconstruction.
- Runtime: 4,737/0/0, with the same seven non-runnable cases. Encoder: 1,321 identical/0 different. Both E2E modes: 1,159 accepted/0 rejected; original/prior identities and ordered stages exact. Verified demo: 21 tests/2 binaries; survey: 53 tests/18 binaries.
- One bundled MCP domain review: standard axioms, no warnings; its 893-source-module closure is unchanged.

The final fixture repair and main reconciliation affected only that fixture,
four additive proof modules, documentation and resource controls. Current normal
keys/trust, the affected executable audit and the repaired cohort were rerun.
Earlier unaffected records keep their actual source head `8eebd1ef`; the JSON
includes a checked source-delta/import-closure/binary-hash applicability
certificate. Every unrelated captured executable is byte-identical. No old
record was relabelled as a run on the new head. Unknown dependencies require
fresh checks.

The linked-fixture logs retain the same pre-existing `StockBlockScan` module
initializer diagnostic as the landed comparison baseline; symbolization and
baseline comparison are preserved. It is separate from test outcomes.

Terminal evidence: `{b['backup_commit']}` on `{b['backup_branch']}`.
Archive SHA256 `{b['archive_sha256']}`; {b['archive_bytes']:,} bytes / {b['files']} files.

Successful `Stock.lower` remains a correctness premise. Universal Stock-only
lowering/downstream completeness is open. Next: division/remainder with real
zero/overflow outcomes; all remaining original widths, ABIs, control, memory,
effects, calls, source/block/whole-driver simulation and completeness. Legacy
fallback is not Stock completeness.
'''
Path('docs/research/stock-highmul-production-activation.md').write_text(text)
p=Path('docs/plans/stock-driver-incremental-delivery.md');s=p.read_text();needle='Next: high multiply/division/';assert needle in s
s=s.replace(needle,f'''Signed/unsigned high multiplication passes author gates through shared consumers.
[Terminal evidence](../research/stock-highmul-production-activation.md) records
22 primary / 25 ownership checks, {r['audited_roots']:,} audited roots, 1,675 prior axiom sets /
32 public headers exact, and 2,832 native comparisons. Both current/retained
consumer cohorts pass32 checks. Validated `{r['validated_source_head'][:8]}`; remote
evidence `{b['backup_commit'][:8]}`. Complete existing highmul source transfer and
shared composition are reused. All prior computations, identities and stages remain.

For an isolated fixture repair or additive main reconciliation, preserve original
record source heads. Carry unaffected evidence only after checking the exact
source delta, import closure and unchanged relevant executable hashes; rerun
current normal keys/trust, affected executable ownership and affected consumer
cohorts. Never relabel historical passes. Unknown dependencies require reruns.

Next: division/''')
s=s.replace('starting with high multiplication and\ndivision/remainder','starting with\ndivision/remainder');p.write_text(s)
p=Path('docs/research/stock-driver-obligations.json');d=json.loads(p.read_text());d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['complete']=False;d['production']['landed']=[v.replace(' (validated, squash pending)','') for v in d['production']['landed']];d['production']['landed'].append('i32/i64 signed/unsigned high multiplication through shared scalar consumers (validated, squash pending)');d['production']['pending']=r['next']
for item in d['roots']:
 if item['id'] in [777,778,779,780]:
  item['saved_guarded_bridge']='FV/Backend/Proof/StockHighMulSourceValues.lean';item['status']='actual source/retained record, guarded scan/body/entry-return and default shared production consumers validated; Stock-only completeness remains';item['production_evidence']='docs/research/stock-highmul-production-activation.json';item['stock_only_completeness']=False
p.write_text(json.dumps(d,indent=2)+'\n');print('Wrote highmul terminal receipt, current plan and obligation ledger; full140 remains incomplete.')
