from pathlib import Path
import re,json

def roots(folder):
 result={}
 for p in Path(folder).glob('*.log'):
  s=p.read_text()
  for n,axs in re.findall(r"'(.+?)' depends on axioms: \[([^]]*)\]",s):result[n]=sorted(set(re.findall(r'[^\s,]+',axs)))
  for n in re.findall(r"'(.+?)' does not depend on any axioms",s):result[n]=[]
 return result
old=roots('/tmp/stock-cmp-terminal-final-audits');new=roots('/tmp/stock-highmul-reconciled-audits');assert len(old)==1675,len(old);missing=sorted(set(old)-set(new));changed=[k for k,v in old.items() if k in new and new[k]!=v];assert not missing and not changed,(missing,changed)
r={'baseline_roots':len(old),'current_roots':len(new),'new_roots':len(new)-len(old),'exact_old_required_axiom_sets_preserved':True,'baseline':'13138d1d316e9f1a4cd2b69481841af0c929964e','baseline_audits':'/tmp/stock-cmp-terminal-final-audits','current_audits':'/tmp/stock-highmul-reconciled-audits','new':{k:v for k,v in new.items() if k not in old}};Path('/tmp/stock-highmul-axiom-parity.json').write_text(json.dumps(r,indent=2)+'\n');print(len(old),'old axiom sets exact;',len(new),'current roots')
