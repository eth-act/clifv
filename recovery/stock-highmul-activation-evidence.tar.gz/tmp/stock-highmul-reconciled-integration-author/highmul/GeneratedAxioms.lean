import Crates.StockHighMulProduction2CleanupFallbackGlobal
import Crates.StockHighMulProduction2PlainFallbackGlobal
import Crates.StockHighMulProduction2RetainedCleanupFallbackGlobal
import Crates.StockHighMulProduction2RetainedPlainFallbackGlobal
import Crates.StockHighMulProduction33CleanupFallbackEntries
import Crates.StockHighMulProduction33CleanupFallbackGlobal
import Crates.StockHighMulProduction6CleanupFallbackGlobal
import Crates.StockHighMulProduction6CleanupStrictGlobal
import Crates.StockHighMulProduction6MixedCleanupFallbackGlobal
import Crates.StockHighMulProduction6MixedPlainFallbackGlobal
import Crates.StockHighMulProduction6PlainFallbackGlobal
import Crates.StockHighMulProduction6PlainStrictGlobal
import Crates.HighMulProductionCLIcurrentPlain
import Crates.HighMulProductionCLIretainedPlain
import Crates.HighMulProductionCLIcurrentCleanup
import Crates.HighMulProductionCLIretainedCleanup
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let generated := fun (name : Name) =>
    let owner := (privateToUserName? name).getD name
    owner.toString.startsWith "Crates.StockHighMulProduction" || owner.toString.startsWith "Crates.HighMulProductionCLI"
  let mut count : Nat := 0
  for (name, _) in env.constants.toList do
    unless generated name do continue
    for ax in ← collectAxioms name do
      if #[``propext, ``Classical.choice, ``Quot.sound].contains ax then continue
      unless generated ax && (ax.toString.splitOn "._native.native_decide.ax_").length > 1 do
        throwError "unexpected generated-proof axiom {ax} in {name}"
    count := count + 1
  unless count > 0 do throwError "empty generated-proof audit"
  logInfo m!"STOCK_HIGHMULPRODUCTION_GENERATED_AXIOMS_PASS {count}"
