from pathlib import Path
import json,re,subprocess
old=json.loads(Path('/tmp/stock-cmp-owned/partitions.json').read_text());out=Path('/tmp/stock-highmul-owned');out.mkdir(exist_ok=True)
paths=subprocess.check_output(['git','diff','--name-only','13138d1d'],text=True).splitlines();new=[p[:-5].replace('/','.') for p in paths if p.startswith('FV/') and p.endswith('.lean')]
new += [str(p.with_suffix('')).replace('/','.') for p in Path('FV/Backend/Proof').glob('StockHighMul*.lean')]
core=list(dict.fromkeys(old['core']+[n for n in new if n!='FV.E2E.StockHighMulWitness']));witness=old['witnesses']+['FV.E2E.StockHighMulWitness'];owners=old['executable_owners']+['FVTest.Backend.Lowering.StockHighMulProductionRuntime','FVTest.Backend.Lowering.StockHighMulProductionLinked']
log=Path('/tmp/stock-highmul-new-audit.log').read_text();newfacts=set(re.findall(r'E2E\.StockHighMulNIWitness\.(?:checks_true|source_checks_true)\._native\.native_decide\.ax_[\w]+',log));assert len(newfacts)==2;facts=sorted(set(old['exact_native_facts'])|newfacts);assert len(facts)==37
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();part={'base':'13138d1d316e9f1a4cd2b69481841af0c929964e','candidate':head,'core':core,'witnesses':witness,'exact_native_facts':facts,'executable_owners':owners};(out/'partitions.json').write_text(json.dumps(part,indent=2)+'\n')
s=Path('/tmp/stock-cmp-owned/Owned0.lean').read_text();s=s[s.index('open Lean Elab Command'):];arr=lambda xs:'#['+', '.join(json.dumps(x) for x in xs)+']'
for name,values in [('core',core),('witnesses',witness),('fixedFacts',facts)]:s=re.sub(r'  let '+name+r' := #\[.*\]',lambda _: '  let '+name+' := '+arr(values),s)
s=s.replace('STOCK_CMP_OWNED','STOCK_HIGHMUL_OWNED');(out/'Owned0.lean').write_text(''.join('import '+n+'\n' for n in core+witness)+s)
for i,owner in enumerate(owners,1):(out/f'Owned{i}.lean').write_text('import Lean\n'+Path('/tmp/stock-not-owned/Owned1.lean').read_text().replace('FVTest.Backend.Main',owner).replace('STOCK_NOT_OWNED','STOCK_HIGHMUL_OWNED'))
m=json.loads(Path('/tmp/stock-highmul-normal-manifest.json').read_text());m['packet']='highmul-production-owned';m['gates']=[{'id':'owned-'+str(i),'argv':['lake','env','lean',str(out/f'Owned{i}.lean')],'requires':['STOCK_HIGHMUL_OWNED'],'complete_inputs':False} for i in range(len(owners)+1)];Path('/tmp/stock-highmul-owned-manifest.json').write_text(json.dumps(m,indent=2)+'\n');print('Owners:',len(core),'core;',len(witness),'witness;',len(owners),'executables;',len(facts),'exact facts')
