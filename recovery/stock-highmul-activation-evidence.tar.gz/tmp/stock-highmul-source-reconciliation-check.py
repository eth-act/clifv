from pathlib import Path
import json,subprocess,hashlib,importlib.util,datetime
root=Path.cwd();old=json.load(open('/tmp/stock-highmul-leaf-reconciliation-baseline.json'));head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();upstream='6be79a1bc3d84f32a4e2343476439308c9655cf3';leaf=old['only_planned_change']
main_changes=set(subprocess.check_output(['git','diff','--name-only','13138d1d',upstream],text=True).splitlines());changes=set(subprocess.check_output(['git','diff','--name-only',old['base_head'],head],text=True).splitlines());assert changes==main_changes|{leaf},changes
added=set(subprocess.check_output(['git','diff','--diff-filter=A','--name-only','13138d1d',upstream,'--','FV','FVTest'],text=True).splitlines());assert len(added)==4;assert not any(p.startswith(('FV/','FVTest/')) for p in main_changes-added)
spec=importlib.util.spec_from_file_location('scheduler','scripts/lake-serial-build.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s);_,mods,deps=s.load_modules(root);new_modules={p[:-5].replace('/','.') for p in added};affected=new_modules|{old['changed_module']}
while True:
 next_=affected|{m for m,d in deps.items() if set(d)&affected}
 if next_==affected:break
 affected=next_
assert affected==new_modules|{old['changed_module']},affected
# These changes govern resource grouping and continuous-main scheduling, not compiler inputs.
oldcap=subprocess.check_output(['git','show',old['base_head']+':scripts/memcap.sh'],text=True);newcap=Path('scripts/memcap.sh').read_text();marker="watchdog='";assert oldcap[oldcap.index(marker):]==newcap[newcap.index(marker):]
manager=subprocess.run(['systemctl','--user','show-environment'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0
changed_bins=[]
for p,h in old['binary_sha256'].items():
 if hashlib.sha256(Path(p).read_bytes()).hexdigest()!=h:changed_bins.append(p)
allowed=str(root/'.lake/build/bin/stock-highmul-linked');unexpected=[p for p in changed_bins if p!=allowed];assert not unexpected,unexpected
r={'state':'unchanged_dependency_inputs_verified','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'old_actual_source_head':old['base_head'],'applicable_current_head':head,'upstream_main':upstream,'changed_paths':sorted(changes),'new_additive_modules':sorted(new_modules),'all_affected_modules':sorted(affected),'no_existing_production_or_proof_module_changed':True,'only_changed_existing_lean_module':old['changed_module'],'old_source_heads_kept_in_original_records':True,'unchanged_tool_hashes':{p:h for p,h in old['binary_sha256'].items() if p!=allowed},'changed_binaries':changed_bins,'systemd_user_manager_available':manager,'watchdog_fallback_byte_exact':True,'resource_only_changes':['scripts/memcap.sh','scripts/main-gate.sh'],'fresh_required':['all normal library/tool keys and all trust audits including new main roots','current highmul actual CLI/link/generated cohort','owned-24 new linked-fixture declarations'],'reuse_scope':['native runtime/QEMU/reference gates','full corpus/encoder/E2E/examples','retained comparison actual cohort','original artifact retention','owned-0 through owned-23'],'not_a_relabel':'Every reused record keeps source_head8eebd1ef; this certificate checks applicability using exact source delta, import closure and tool hashes.'};Path('/tmp/stock-highmul-source-reconciliation.json').write_text(json.dumps(r,indent=2)+'\n');print('Verified narrow source reconciliation:',len(affected),'affected modules; no unrelated tool binary changed')
