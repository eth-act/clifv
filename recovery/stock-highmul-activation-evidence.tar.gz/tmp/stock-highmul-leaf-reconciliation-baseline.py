from pathlib import Path
import importlib.util,subprocess,json,hashlib,tomllib,datetime
root=Path.cwd();head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head=='8eebd1ef33329abb7c0dc9dafe565cd2cc7a53f0'
spec=importlib.util.spec_from_file_location('scheduler','scripts/lake-serial-build.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s);_,mods,deps=s.load_modules(root)
leaf='FVTest.Backend.Lowering.StockHighMulProductionLinked';affected={leaf}
while True:
 next_=affected|{m for m,d in deps.items() if set(d)&affected}
 if next_==affected:break
 affected=next_
assert affected=={leaf},affected
cfg=tomllib.loads(Path('lakefile.toml').read_text());exes={v['name']:v['root'] for v in cfg['lean_exe']};names=['lean-backend','lean-link','link-check','lean-e2e-check','stock-highmul-runtime','stock-highmul-linked','stock-cmp-runtime','stock-cmp-linked'];tools={str(root/'.lake/build/bin'/n):hashlib.sha256((root/'.lake/build/bin'/n).read_bytes()).hexdigest() for n in names}
for p in [root/'rust/target/release/lean-regalloc',root/'rust/target/release/clif-native']:
 assert p.is_file();tools[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
r={'base_head':head,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'only_planned_change':str(mods[leaf].relative_to(root)),'changed_module':leaf,'reverse_import_closure':sorted(affected),'executable_roots':{n:exes[n] for n in names},'binary_sha256':tools,'only_affected_executable':'stock-highmul-linked','unchanged_production_code_required':True,'old_records_will_keep_actual_source_head':True};Path('/tmp/stock-highmul-leaf-reconciliation-baseline.json').write_text(json.dumps(r,indent=2)+'\n');print('Fixture leaf has no importing modules; captured ten executable hashes before repair.')
