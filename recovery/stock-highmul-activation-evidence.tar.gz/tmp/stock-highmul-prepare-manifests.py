from pathlib import Path
import json,subprocess
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();base='13138d1d316e9f1a4cd2b69481841af0c929964e'
def change(v):
 if isinstance(v,str):
  if v=='cmp':return 'highmul'
  return v.replace('stock-cmp','stock-highmul').replace('StockCmp','StockHighMul').replace('STOCK_CMP','STOCK_HIGHMUL').replace('Stock cmp','Stock highmul').replace('{out}/cmp','{out}/highmul').replace('cmp-actual','highmul-actual')
 if isinstance(v,list):return [change(x) for x in v]
 if isinstance(v,dict):return {change(k):change(x) for k,x in v.items()}
 return v
for group in ['normal','native','full','retention','integration']:
 old=json.loads(Path('/tmp/stock-cmp-terminal-'+group+'-manifest.json').read_text());m=change(old);m.update(packet='highmul-production-'+group,base=base,candidate=head,historical_evidence=['docs/research/stock-cmp-production-activation.json'],validation_scope='Actual signed/unsigned high multiply composes with every shipped class through default shared consumers; original inputs, variants, required axioms, accepted identities and stages preserved. Full original140 remains unfinished.')
 if group=='normal':
  for g in m['gates']:
   if g['id']=='all-trust-audits':g['argv'][-1]='/tmp/stock-highmul-final-audits'
   if g['id'].startswith('build-stock-minmax'):
    g['id']=g['id'].replace('stock-minmax','stock-cmp');g['argv'][-1]=g['argv'][-1].replace('stock-minmax','stock-cmp')
 Path('/tmp/stock-highmul-'+group+'-manifest.json').write_text(json.dumps(m,indent=2)+'\n')
# Retained comparison consumer is a fresh run on the current candidate.
m=json.loads(Path('/tmp/stock-cmp-terminal-integration-manifest.json').read_text());m.update(packet='highmul-production-retained-cmp-integration',base=base,candidate=head,historical_evidence=['docs/research/stock-cmp-production-activation.json']);Path('/tmp/stock-highmul-cmp-integration-manifest.json').write_text(json.dumps(m,indent=2)+'\n')
print('Prepared six fresh source-bound gate manifests on',head)
