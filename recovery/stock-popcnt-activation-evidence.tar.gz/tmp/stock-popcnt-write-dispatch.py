from pathlib import Path
b=Path('FV/Backend/Proof');old=(b/'StockCountSelected.lean').read_text();a=old.index('private theorem count_source_data');z=old.index('\nend Data',a)
data=old[a:z].replace('private theorem count_source_data','theorem source_data').replace('(trailing : Bool)','').replace('(countOp trailing)','.popcnt').replace('(countOpcode trailing)','111').replace('cases trailing <;> ','').replace('countOp,countOpcode,','')
s='''import FV.Backend.Proof.StockSourceTypeMatch
import FV.Backend.Proof.StockPopcountScope
namespace Backend.Stock.Proof.Popcount
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 20000
set_option maxHeartbeats 1000000
attribute [local irreducible] Isle.Aarch64.program

def popcountRule (w : Nat) : Rule :=
  if w = 8 then rule_lower_2074 else if w = 16 then rule_lower_2080
  else if w = 32 then rule_lower_2086 else rule_lower_2092

/-- Original scope closure already excludes the i128 and vector roots. -/
theorem opcode_inventory : sourceOpcodeIds 111 = [937,938,939,940] := by decide +kernel

section Data
attribute [local semireducible] Isle.Aarch64.program
'''+data+'''
end Data

/-- Original source and successful matching determine the scalar count root.
The existing global scope closure discharges the unrelated type roots. -/
theorem selected_rule {f : Clif.Function} {ctx : Ctx} (inv : MappedCtxInv f ctx)
    {i x : Nat} {info : IInfo} {ty : Clif.Ty}
    (source : ctx.insts[i]? = some info) (clif : info.clif = some (.unary .popcnt ty x))
    {st next : State} {out : V} {trace : List RuleId} (selected : LowerSelection ctx i st out next trace) :
    selected.rule = popcountRule ty.width := by
  obtain ⟨width,data,type⟩ := source_data inv source clif
  have ids := stock_selected_source_opcode_ids inv source clif data selected
  rw [opcode_inventory] at ids
  have roots : (program.rulesOf TId.lower).length = 517 := by
    rw [show TId.lower = 686 from rfl,data_program.r686]; rfl
  have enough := selected.fuelBound
  obtain ⟨fuel,fuelEq⟩ : ∃ fuel,selected.matchFuel = fuel+1 := ⟨selected.matchFuel-1,by omega⟩
  have matched := selected.matchedRun
  rw [fuelEq] at matched
  obtain ⟨bound,args,_⟩ := matchRule_some_inv matched
  rw [stock_matchArgs] at args
  simp only [List.mem_cons,List.not_mem_nil,or_false] at ids
  rcases ids with one | two | three | four
'''
for h,line,w in [('one',2074,8),('two',2080,16),('three',2086,32),('four',2092,64)]:
 s+=f'''  · have chosen : selected.rule = rule_lower_{line} := eq_of_mem_of_id lower_ids_nodup selected.rule_mem
      (by rw [show TId.lower = 686 from rfl,data_program.r686]; decide +kernel) {h}
    rw [chosen] at args
    have same := stock_match_source_type (wanted := .int {w}) (name := "I{w}") rfl rfl source type args
    have typed : ty.width = {w} := CTy.int.inj same
    rw [chosen,typed]
    rfl
'''
s+='end Backend.Stock.Proof.Popcount\n';(b/'StockPopcountDispatch.lean').write_text(s)
