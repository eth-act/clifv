from pathlib import Path
import re
p=Path('FV/Backend/Proof/StockScalarBitDomain.lean');s=p.read_text().replace('Fixed cast/shift/multiply/NOT/constant/mixed source proofs','Fixed unary-bit/rotation and earlier scalar source proofs');p.write_text(s)
p=Path('FV/Backend/Proof/StockBitReturnRefines.lean');s=p.read_text().replace('an arbitrary mixed cast body','an arbitrary mixed bit-operation body');p.write_text(s)
p=Path('FV/E2E/StockBitWitness.lean');s=p.read_text().replace('Actual retained root IDs, including ordinary shifts and both fused bitfield forms.','Actual retained roots for unary operations and register/immediate rotations.').replace('Every ABI selects all three ordinary shifts and both fused bitfield roots.','Every ABI selects the five unary operations and all four rotation forms.');s+='''
namespace E2E.StockBitNIWitness
/-- Reusable original syntax for subsequent scalar-family extensions. -/
theorem source_family (config : Backend.Stock.D0.Configuration) :
    ∀ stm ∈ (function config).blocks[0]!.body, Backend.Stock.Proof.BitBody.Family stm.inst := family config
end E2E.StockBitNIWitness
''';p.write_text(s)
p=Path('FVTest/Backend/Lowering/StockBitProductionRuntime.lean');s=p.read_text().replace('arithmetic fixture parse failed','bit-operation fixture parse failed').replace('complete arithmetic attempt','complete Stock attempt');p.write_text(s)
files=[Path('FV/Backend/Proof')/n for n in ['StockBitFamily.lean','StockBitScanRefines.lean','StockBitBodyRefines.lean','StockBitReturnRefines.lean','StockScalarBitDomain.lean']]+[Path('FV/E2E/ABIReadBitSteps.lean'),Path('FV/E2E/StockBitWitness.lean')]
lines=['import FV.E2E.StockBitWitness','']
for p in files:
 scope=''
 for line in p.read_text().splitlines():
  if line.startswith('namespace '):scope=line.split()[1]
  m=re.match(r'theorem (\w+)',line)
  if m:
   name=scope+'.'+m[1];witness=p.name=='StockBitWitness.lean' and m[1] not in ['source_entry','source_returns','source_family']
   lines.append('#print axioms '+name+(' -- witness: native_decide' if witness else ''))
for name in ['Backend.Stock.Proof.CastComplete.stock_lower_cast_selected_rule_of_formats','Backend.Stock.Proof.CastComplete.extend_source_of_formats','Backend.Stock.Proof.stock_lower_extend_scan_fall_refines_of_formats','Backend.Stock.Proof.stock_lower_mixed_cast_record_fall_refines_of_formats','Backend.Stock.Scalar.bitBodyEligible_sound','Backend.Stock.Scalar.sourceOk_sound','Backend.Stock.Scalar.check_sound','E2E.StockCastNIWitness.source_family']:
 lines.append('#print axioms '+name)
Path('scripts/audit/stock-bit-production.lean').write_text('\n'.join(lines)+'\n');print('new audit roots',len(lines)-2)
