#!/usr/bin/env bash
set -eu
export PATH=/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:/home/lee/.cargo/bin:/home/lee/clifv/.worktrees/stock-driver-incremental/rust/target/release:/home/lee/.local/share/clifv-test-tools/usr/bin:/home/lee/.rustup/toolchains/nightly-2026-09-26-x86_64-unknown-linux-gnu/lib/rustlib/x86_64-unknown-linux-gnu/bin:$PATH
export FV_LAKE_CACHE=/home/lee/clifv/.worktrees/driver-proof-resume/.lake/artifact-cache
export FV_MEMCAP=16G OMP_NUM_THREADS=2 OMP_THREAD_LIMIT=2 LEAN_NUM_THREADS=2 CARGO_BUILD_JOBS=2
exec scripts/memcap.sh lake build "$@"
