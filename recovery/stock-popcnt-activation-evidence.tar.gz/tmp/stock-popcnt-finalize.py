from pathlib import Path
import json,hashlib,subprocess,datetime,re
root=Path.cwd();head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
records=[]
for group in ['normal','native','owned','integration','bit-integration','full','retention']:
 m=read('/tmp/stock-popcnt-'+group+'-manifest.json');assert m['candidate']==head
 for g in m['gates']:
  r=read('/tmp/stock-popcnt-'+group+'-author-final/'+g['id']+'.json');assert r['state']=='passed' and r['returncode']==0,g['id'];assert r['source_head']==head
  assert sha(r['log'])==r['log_sha256']
  for p,h in r['outputs'].items():assert sha(p)==h,p
  records.append(r)
for kind,path in [('popcount',Path('/tmp/stock-popcnt-integration-author-final/popcount')),('bit',Path('/tmp/stock-popcnt-bit-integration-author-final/bit'))]:
 r=read(path/'receipt.json');assert r['state']=='passed' and len(r['records'])==32 and r['head']==head
 assert all(x['returncode']==0 and sha(x['log'])==x['sha256'] for x in r['records'].values())
 for field,folder in [('generated_sources',path/'linked'),('linked_artifacts',path/'linked'),('cli_sources',path)]:
  for n,h in r[field].items():assert sha(folder/n)==h
retained=read('/tmp/stock-popcnt-retention-author-final/retained/receipt.json');assert retained['state']=='passed';assert all(x.get('files_untouched',True) for x in retained['records'].values())
parity=read('/tmp/stock-popcnt-identity-stage-parity.json');assert all(x['current']>=1159 and x['all_original_and_prior_identities_and_ordered_stages_preserved'] for x in parity.values())
ax=read('/tmp/stock-popcnt-axiom-parity.json');assert ax['exact_old_required_axiom_sets_preserved'] and ax['baseline_roots']==1541
headers=read('/tmp/stock-popcnt-header-parity.json');assert headers['unchanged'] and headers['old_public_headers']==29
review=read('/tmp/stock-popcnt-mcp-review.json');assert not review['isError'] and not review['structuredContent']['warnings'];assert set(review['structuredContent']['axioms'])=={'propext','Classical.choice','Quot.sound'}
review_equivalence=read('/tmp/stock-popcnt-mcp-input-equivalence.json');assert review_equivalence['final_source_head']==head and review_equivalence['all_Lean_sources_and_imports_unchanged']
owned=[r for r in records if r['id'].startswith('owned-')];primary=[r for r in records if not r['id'].startswith('owned-')];assert len(primary)==18 and len(owned)==19
owners=read('/tmp/stock-popcnt-owned/partitions.json')
ownedlog=Path(next(r for r in owned if r['id']=='owned-0')['log']).read_text();core,witness=map(int,re.search(r'STANDARD_CORE (\d+); FIXED_WITNESSES (\d+)',ownedlog).groups())
normal=Path(next(r for r in primary if r['id']=='all-normal-library-keys')['log']).read_text();normalkeys=int(re.search(r'All targets up-to-date \((\d+) jobs\)',normal)[1])
native=read('/tmp/stock-popcnt-native-author-final/native/native-receipt.json');assert native['state']=='passed' and native['failures']==native['disagreements']==0;assert sha(root/'rust/target/release/clif-native')==native['native_binary_sha256'];assert native['lean_byte_executions']==2256
moduleplan=read('/tmp/stock-popcnt-module-plan.json')
def gate_text(gate):
 return Path(next(r for r in primary if r['id']==gate)['log']).read_text()
runtime=gate_text('runtime-corpus');assert re.search(r'lean pass 4737 fail 0 error 0 .*not-runnable 7',runtime)
encoding=gate_text('encoder');assert 'functions 1321: identical 1321, differ 0' in encoding
for label,tests in [('verified-fv-demo',21),('verified-survey',53)]:
 assert 'SAME: '+str(tests)+' test outcomes identical' in gate_text(label),label
receipt={'state':'per_pr_gates_passed','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'validated_source_head':head,'base_main':'5e563a0baf63f9d582acb4cd49b43c1648250217','primary_gate_count':len(primary),'primary_gate_records':primary,'owned_gate_records':owned,'owned_core_constants':core,'owned_fixed_witness_constants':witness,'exact_declared_native_facts':len(owners['exact_native_facts']),'core_owners':len(owners['core']),'witness_owners':len(owners['witnesses']),'executable_owners':len(owners['executable_owners']),'normal_scheduled_modules':moduleplan['all'],'normal_library_jobs':normalkeys,'checked_in_audits':len(list(Path('scripts/audit').glob('*.lean'))),'audited_roots':ax['current_roots'],'runtime_corpus':{'passed':4737,'failed':0,'errors':0,'known_non_runnable':7},'encoder':{'identical':1321,'different':0},'mcp_review':review,'mcp_input_equivalence':review_equivalence,'parity':{'axiom_sets':ax,'old_headers':headers},'identity_stage_parity':parity,'native_execution':native,'old_native_expected_vectors_preserved':read('/tmp/stock-popcnt-native-grid-retention.json'),'new_proved_source_operations':['popcnt'],'production_widths':[32,64],'source_transfer_widths':[8,16,32,64],'executed_new_roots':[939,940],'all_scoped_scalar_roots':[937,938,939,940],'excluded_by_unchanged_scope':[941,942],'complete_witness_in_all_six_ABIs_and_both_cleanup_modes':True,'arbitrary_source_inputs_and_original_slot_witness':True,'all_old_computation_remains_live':True,'reuses_existing_zero_nonzero_direct_aliased_dirty_upper_bits_witnesses_in_all_four_widths':True,'preserved_alternative_proof_branch':'agent/stock-popcnt-scoped-alternatives-20261022','preserved_alternative_source_head':'e2f1564202041d1c36833ba0adb2480410b74dff','retained_original_flat_multiply':retained,'verified_examples':{'fv-demo':{'tests':21,'verified_binaries':2},'survey':{'tests':53,'verified_binaries':18}},'full_original_140_complete':False,'next':'Comparisons/min/max, high multiply/division/remainder and complete original integer widths/ABIs; every remaining original #140 control/memory/trap/effect/call/source/block/whole-driver simulation/completeness/consumer obligation remains.'}
Path('/tmp/stock-popcnt-terminal-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print('passed',len(primary),'primary/',len(owned),'ownership;',normalkeys,'normal keys;',core,'Std3/',witness,'fixed witnesses')
