from pathlib import Path
p=Path('FV/Backend/Proof/StockBitBodyRefines.lean');s=p.read_text().replace('import FV.Backend.Proof.StockBitFamily','import FV.Backend.Proof.StockCastBodyRefines\nimport FV.Backend.Proof.StockBitFamily',1);p.write_text(s)
s=Path('/tmp/stock-cast-next-bit/ABIReadBitSteps.lean').read_text();a=s.index('namespace Backend.ABIReadScalar');z=s.index('end Backend.ABIReadScalar',a)+len('end Backend.ABIReadScalar');decl=s[a:z];p=Path('FV/Backend/ABIReadScalar.lean');t=p.read_text();defn=decl[decl.index('/--'):decl.rindex('end Backend.ABIReadScalar')];t=t.replace('\ndef instruction','\n'+defn+'\ndef instruction',1).replace('|| shift i || extension i','|| shift i || extension i || bitProducer i');p.write_text(t);Path('FV/E2E/ABIReadBitSteps.lean').write_text(s[:a]+s[z:])
p=Path('FV/E2E/ABIReadScalar.lean');s=p.read_text().replace('import FV.E2E.ABIReadCastSteps','import FV.E2E.ABIReadCastSteps\nimport FV.E2E.ABIReadBitSteps',1).replace('| .movK .. | .bitfieldMove .. | .extend .. => true','| .movK .. | .bitfieldMove .. | .extend .. | .bitRR .. => true').replace('=> Backend.ABIReadScalar.shiftOp op','=> Backend.ABIReadScalar.shiftOp op || op == .extr',1).replace('| extend rd rn sg fromB toB => cases checked','| extend rd rn sg fromB toB => cases checked\n  | bitRR op sz rd rn => cases checked',1)
a=s.index('private theorem shift_special');z=s.index('\nprivate theorem extension_special',a)
s=s[:a]+'''private theorem shift_special {i : MInst} (checked : Backend.ABIReadScalar.shift i = true) : special i = true := by
  cases i <;> simp_all [special,Backend.ABIReadScalar.shift]

private theorem bit_special {i : MInst} (checked : Backend.ABIReadScalar.bitProducer i = true) : special i = true := by
  cases i with
  | bitRR op sz rd rn => rfl
  | aluRRR op sz rd rn rm => cases op <;> first | rfl | cases checked
  | aluRRImmShift op sz rd rn imm => cases op <;> first | rfl | cases checked
  | _ => cases checked
'''+s[z:]
s=s.replace('rcases checked with ((old | added) | shifted) | extended','rcases checked with (((old | added) | shifted) | extended) | bit')
marker='\ntheorem checked_step_transport';at=s.index(marker);s=s[:at]+'''  · simp only [sem,bit_special bit,↓reduceIte] at run
    obtain ⟨frame,control⟩ := BitRead.step_frame bit run
    exact ⟨frame,.inl control⟩
'''+s[at:]
marker='\nnamespace Realize';at=s.index(marker);s=s[:at]+'''  · simp only [sem,bit_special bit,↓reduceIte] at run ⊢
    exact mspec_lockstep (BitRead.no_mem bit) worlds run
'''+s[at:]
marker='\nend Realize';at=s.index(marker);s=s[:at]+'''  · simp only [sem,bit_special bit,↓reduceIte] at executed
    obtain ⟨spec,run,related⟩ := mspec_lockstep (BitRead.no_mem bit) worlds.symm executed
    rw [BitRead.spec_eq bit] at run
    obtain ⟨actual,realized,related'⟩ := refines_valueSem F ctx X _ us t outs spec run
    exact ⟨actual,realized,related'.trans related.symm⟩
'''+s[at:];p.write_text(s)
p=Path('FV/E2E/SemanticNIBoundary.lean');s=p.read_text().replace('Backend.ABIReadScalar.extension,','Backend.ABIReadScalar.extension,Backend.ABIReadScalar.bitProducer,');p.write_text(s)
