from pathlib import Path
p=Path('FV/Backend/Lowering/StockScalar.lean');s=p.read_text();at=s.index('\ndef eligible');s=s[:at]+'''
/-- Unary bit operations and rotations extend the class while old selectors stay fixed. -/
def bitEligible (stm : Clif.Stmt) : Bool :=
  match stm.inst with
  | .unary .ineg ty _ | .unary .clz ty _ | .unary .ctz ty _
  | .unary .bitrev ty _ | .unary .bswap ty _
  | .binary .rotl ty _ _ | .binary .rotr ty _ _ => ty == .i32 || ty == .i64
  | _ => false

def bitBodyEligible (stm : Clif.Stmt) : Bool := castBodyEligible stm || bitEligible stm
'''+s[at:];s=s.replace('b.body.all castBodyEligible','b.body.all bitBodyEligible');p.write_text(s)
p=Path('FV/Backend/Proof/StockScalarCheck.lean');s=p.read_text().replace('import FV.Backend.Proof.StockScalarCastDomain','import FV.Backend.Proof.StockScalarCastDomain\nimport FV.Backend.Proof.StockScalarBitDomain');at=s.index('\ntheorem sourceOk_sound');s=s[:at]+'''
/-- The original source classifier derives bit/rotate syntax; no selected root is a premise. -/
theorem bitBodyEligible_sound {stm : Clif.Stmt} (checked : bitBodyEligible stm = true) :
    Stock.Proof.BitBody.Family stm.inst := by
  simp only [bitBodyEligible,Bool.or_eq_true] at checked
  rcases checked with old | bit
  · exact Or.inl (castBodyEligible_sound old)
  · cases inst : stm.inst <;> simp only [bitEligible,inst] at bit
    all_goals try contradiction
    next op ty x =>
      cases op <;> simp only [bitEligible] at bit
      all_goals try contradiction
      all_goals exact Or.inr (Or.inl ⟨_,_,_,by simp [Stock.Proof.BitBody.Unary],rfl⟩)
    next op ty x y =>
      cases op <;> simp only [bitEligible] at bit
      all_goals try contradiction
      all_goals first
        | exact Or.inr (Or.inr ⟨true,_,_,_,rfl⟩)
        | exact Or.inr (Or.inr ⟨false,_,_,_,rfl⟩)
'''+s[at:];s=s.replace('have families : ∀ stm ∈ b.body, Stock.Proof.CastBody.Family','have families : ∀ stm ∈ b.body, Stock.Proof.BitBody.Family').replace('exact castBodyEligible_sound supported','exact bitBodyEligible_sound supported').replace('exact domain_of_cast','exact domain_of_bit');p.write_text(s)
# Minimal fixture definitions; source execution theorems live in the complete witness below.
s=Path('/tmp/stock-cast-next-bit/StockBitFixtures.lean').read_text();a=s.index('def arguments');s=s[:a]+'end E2E.StockBitNIWitness\n';s=s.replace('import FV.E2E.StockCastWitness','import FV.E2E.StockCastFixtures').replace('open Backend.Stock.D0 Backend.Proof.Driver','open Backend.Stock.D0');Path('FV/E2E/StockBitFixtures.lean').write_text(s)
p=Path('FV/E2E/StockCastWitness.lean');s=p.read_text();s+='''
namespace E2E.StockCastNIWitness
/-- Reusable original syntax for subsequent scalar-family extensions. -/
theorem source_family (config : Backend.Stock.D0.Configuration) :
    ∀ stm ∈ (function config).blocks[0]!.body, Backend.Stock.Proof.CastBody.Family stm.inst := family config
end E2E.StockCastNIWitness
''';p.write_text(s)
s=s[:s.rindex('\nnamespace E2E.StockCastNIWitness\n/-- Reusable')].replace('StockCast','StockBit').replace('import FV.E2E.StockShiftWitness','import FV.E2E.StockCastWitness').replace('domain_of_cast','domain_of_bit').replace('[60]','[74]').replace('} 53 ⟨','} 67 ⟨')
a=s.index('private theorem family');z=s.index('/-- Actual checked/allocated',a)
s=s[:a]+'''private theorem family (config : Configuration) :
    ∀ stm ∈ (function config).blocks[0]!.body, Stock.Proof.BitBody.Family stm.inst := by
  intro stm member
  change stm ∈ (E2E.StockCastNIWitness.function config).blocks[0]!.body ++ extraBody config at member
  rcases List.mem_append.mp member with old | bit
  · exact Or.inl (E2E.StockCastNIWitness.source_family config stm old)
  · dsimp only [extraBody] at bit
    simp only [List.mem_cons,List.not_mem_nil,or_false] at bit
    rcases bit with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    all_goals first
      | exact .inr (.inl ⟨.ineg,_,_,by simp [Stock.Proof.BitBody.Unary],rfl⟩)
      | exact .inr (.inl ⟨.clz,_,_,by simp [Stock.Proof.BitBody.Unary],rfl⟩)
      | exact .inr (.inl ⟨.ctz,_,_,by simp [Stock.Proof.BitBody.Unary],rfl⟩)
      | exact .inr (.inl ⟨.bitrev,_,_,by simp [Stock.Proof.BitBody.Unary],rfl⟩)
      | exact .inr (.inl ⟨.bswap,_,_,by simp [Stock.Proof.BitBody.Unary],rfl⟩)
      | exact .inr (.inr ⟨true,_,_,_,rfl⟩)
      | exact .inr (.inr ⟨false,_,_,_,rfl⟩)
      | exact .inl (.inl (.inl (.inl (.inl (.inr ⟨_,_,rfl⟩)))))
      | exact .inl (.inl (.inl (.inl (.inl (.inl (.inr (.inr ⟨.bxor,_,_,_,rfl⟩)))))))

'''+s[z:]
a=s.index('def castRoots (');z=s.index('\ndef castRootsCovered',a);s=s[:a]+'''def bitRoots (config : Backend.Stock.D0.Configuration) : List Nat :=
  if (Backend.Stock.D0.valueType config).width = 64 then
    [756,922,927,918,934,902,904,908,911]
  else [756,922,927,918,933,901,903,907,910]
'''+s[z:];s=s.replace('castRoots','bitRoots');Path('FV/E2E/StockBitWitness.lean').write_text(s)
for part in ['Runtime','Linked']:
 Path('FVTest/Backend/Lowering/StockBitProduction'+part+'.lean').write_text(Path('/tmp/stock-cast-next-bit/StockBitProduction'+part+'.lean').read_text())
Path('scripts/check-stock-mixed-native.py').write_text(Path('/tmp/stock-cast-next-bit/check-stock-mixed-native.py').read_text())
p=Path('scripts/check-stock-mixed-integration.py');s=p.read_text().replace('"shift", "cast"], default','"shift", "cast", "bit"], default').replace('"cast": "CastProduction"','"cast": "CastProduction", "bit": "BitProduction"');p.write_text(s)
