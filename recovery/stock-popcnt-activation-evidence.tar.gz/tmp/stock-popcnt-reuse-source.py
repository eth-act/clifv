from pathlib import Path
import subprocess
root=Path('FV/Backend/Proof')
base='5e563a0baf63f9d582acb4cd49b43c1648250217'
keep={'StockPopcountFamily','StockPopcountScanRefines','StockPopcountBodyRefines','StockPopcountReturnRefines','StockScalarPopcountDomain'}
new=subprocess.check_output(['git','diff','--diff-filter=A','--name-only',base,'HEAD','--','FV/Backend/Proof'],text=True).splitlines()
removed=[]
for path in new:
 p=Path(path)
 if p.stem not in keep:
  subprocess.run(['git','rm',str(p)],check=True);removed.append(str(p))
for stem in ['StockCountRecordValues','StockPopcountZeroWitness','StockPopcountNonzeroWitness']:
 p=root/(stem+'.lean');p.write_bytes(subprocess.check_output(['git','show',base+':'+str(p)]))
p=root/'StockPopcountFamily.lean';s=p.read_text().replace('import FV.Backend.Proof.StockScopedPopcountSourceValues','import FV.Backend.Proof.StockPopcountSourceValues');p.write_text(s)
p=root/'StockPopcountScanRefines.lean';s=p.read_text().replace(':= Popcount.source_by_instruction',':= ScalarPopcount.stock_lower_popcount_source_by_instruction').replace('mapped recorded emitted refines values sourceStep','mapped recorded emitted refines dfg values sourceStep');p.write_text(s)
lines=['import FV.E2E.StockPopcountWitness','import FV.Backend.Proof.StockPopcountZeroWitness','import FV.Backend.Proof.StockPopcountNonzeroWitness','']
import re
for mod in sorted(keep):
 s=(root/(mod+'.lean')).read_text();ns=re.search(r'^namespace (\S+)',s,re.M).group(1)
 for name in re.findall(r'^theorem (\w+)',s,re.M):lines.append('#print axioms '+ns+'.'+name)
for name in ['step_frame','no_mem','spec_eq']:lines.append('#print axioms E2E.PopcountRead.'+name)
for name in ['checks_true','compiled_exists','source_entry','source_returns','source_checks_true','classifier_accepts','selected_roots_present','compiled_semantic_exists','source_family']:
 lines.append('#print axioms E2E.StockPopcountNIWitness.'+name+(' -- witness: native_decide' if name not in ['source_entry','source_returns','source_family'] else ''))
lines += ['#print axioms Backend.Stock.Scalar.popcountBodyEligible_sound','#print axioms Backend.Stock.Proof.ScalarPopcount.stock_lower_popcount_source_by_instruction','#print axioms Backend.Stock.Proof.ScalarPopcount.ZeroWitness.stock_lower_popcount_source_witness','#print axioms Backend.Stock.Proof.ScalarPopcount.NonzeroWitness.stock_lower_popcount_source_witness']
Path('scripts/audit/stock-popcount-production.lean').write_text('\n'.join(lines)+'\n')
print('Reusing existing complete source proof; preserved alternatives at e2f15642. Removed unused new modules:',len(removed))
