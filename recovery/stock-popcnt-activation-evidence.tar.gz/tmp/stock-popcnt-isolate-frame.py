from pathlib import Path
import subprocess
p=Path('FV/Backend/Proof/StockGuardedRecordValues.lean');s=p.read_text();a=s.index('/-- A family may supply its proved fresh-write frame directly;');z=s.index('/-- A successful source instruction with one result',a);new=s[a:z];original=s[:a]+s[z:]
base=subprocess.check_output(['git','show','8442c3314c727904d872b7bcb34cdaeb81151f6a:'+str(p)],text=True);assert original==base,'unexpected saved changes; preserve them'
newpath=Path('FV/Backend/Proof/StockGuardedRecordFrame.lean');assert not newpath.exists()
newpath.write_text('''import FV.Backend.Proof.StockGuardedRecordValues
namespace Backend.Stock.Proof
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 20000
set_option maxHeartbeats 1000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm emitBranch scanBlock

'''+new+'end Backend.Stock.Proof\n')
p.write_text(original)
p=Path('FV/Backend/Proof/StockPopcountRecordValues.lean');p.write_text(p.read_text().replace('import FV.Backend.Proof.StockGuardedRecordValues','import FV.Backend.Proof.StockGuardedRecordFrame'))
