import ast,json,hashlib,subprocess
from pathlib import Path
p=Path('scripts/check-stock-mixed-native.py');old=subprocess.check_output(['git','show','8442c331:scripts/check-stock-mixed-native.py'],text=True);new=p.read_text()
def funcs(s):
 t=ast.parse(s);ns={};exec(compile(ast.Module([n for n in t.body if isinstance(n,(ast.Import,ast.ImportFrom,ast.FunctionDef))],type_ignores=[]),'<native-function-grid>','exec'),ns);return ns
before,after=funcs(old),funcs(new);counts={}
for kind in ['mixed','logical','scalar','not','mul','shift','cast','bit']:
 counts[kind]={}
 for bits in [32,64]:
  a=before['run_commands'](bits,kind);b=after['run_commands'](bits,kind);assert a==b,(kind,bits);counts[kind][str(bits)]=len(b)
r={'state':'passed','baseline':'8442c3314c727904d872b7bcb34cdaeb81151f6a','source_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'current_script_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'all_eight_previous_class_vectors_and_expectations_exact':True,'prior_counts':counts,'popcount_cases_per_object':{str(b):len(after['run_commands'](b,'popcount')) for b in [32,64]}}
Path('/tmp/stock-popcnt-native-grid-retention.json').write_text(json.dumps(r,indent=2)+'\n');print('All eight old grids exact; popcount',r['popcount_cases_per_object'])
