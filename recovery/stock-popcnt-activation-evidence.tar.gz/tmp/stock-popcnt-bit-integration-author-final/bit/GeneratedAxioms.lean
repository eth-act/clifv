import Crates.StockBitProduction2CleanupFallbackGlobal
import Crates.StockBitProduction2PlainFallbackGlobal
import Crates.StockBitProduction2RetainedCleanupFallbackGlobal
import Crates.StockBitProduction2RetainedPlainFallbackGlobal
import Crates.StockBitProduction33CleanupFallbackEntries
import Crates.StockBitProduction33CleanupFallbackGlobal
import Crates.StockBitProduction6CleanupFallbackGlobal
import Crates.StockBitProduction6CleanupStrictGlobal
import Crates.StockBitProduction6MixedCleanupFallbackGlobal
import Crates.StockBitProduction6MixedPlainFallbackGlobal
import Crates.StockBitProduction6PlainFallbackGlobal
import Crates.StockBitProduction6PlainStrictGlobal
import Crates.BitProductionCLIcurrentPlain
import Crates.BitProductionCLIretainedPlain
import Crates.BitProductionCLIcurrentCleanup
import Crates.BitProductionCLIretainedCleanup
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let generated := fun (name : Name) =>
    name.toString.startsWith "Crates.StockBitProduction" || name.toString.startsWith "Crates.BitProductionCLI"
  let mut count : Nat := 0
  for (name, _) in env.constants.toList do
    unless generated name do continue
    for ax in ← collectAxioms name do
      if #[``propext, ``Classical.choice, ``Quot.sound].contains ax then continue
      unless generated ax && (ax.toString.splitOn "._native.native_decide.ax_").length > 1 do
        throwError "unexpected generated-proof axiom {ax} in {name}"
    count := count + 1
  unless count > 0 do throwError "empty generated-proof audit"
  logInfo m!"STOCK_BITPRODUCTION_GENERATED_AXIOMS_PASS {count}"
