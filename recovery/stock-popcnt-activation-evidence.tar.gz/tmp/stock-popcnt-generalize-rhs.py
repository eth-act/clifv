from pathlib import Path
p=Path('FV/Backend/Proof/StockPopcountRhs.lean');s=p.read_text();a=s.index('theorem rhs64_observed');z=s.index('\nend Backend.Stock.Proof.Popcount',a);old=s[a:z];header=old.split(' := by')[0];body=old.split(' := by\n',1)[1].rstrip()
h=header.replace('rhs64_observed','rhs_wide_observed').replace('(ctx : Ctx) {x n : Nat}','(ctx : Ctx) {w : Nat} (width : w = 32 ∨ w = 64) {x n : Nat}').replace('rule_lower_2092.rhs','(popcountRule w).rhs').replace('popcountEnv 64','popcountEnv w').replace('popcountBase 64','popcountBase w')
body=body.replace('isel_inv [*,rule_lower_2092,','isel_inv [*,popcountRule,rule_lower_2086,rule_lower_2092,').replace('(by omega) (.inr rfl) h1','(by omega) (by first | exact .inl rfl | exact .inr rfl) h1').replace(' rx .size64 :=',' rx sz :=')
generic=h+''' := by
  let sz : ScalarSize := if w = 64 then .size64 else .size32
  rcases width with rfl | rfl
  all_goals
'''+''.join('  '+line+'\n' for line in body.splitlines())
wrapper=header+''' := by
  exact rhs_wide_observed hp ctx (Or.inr rfl) run
'''
h32=header.replace('rhs64_observed','rhs32_observed').replace('rule_lower_2092.rhs','rule_lower_2086.rhs').replace('popcountEnv 64','popcountEnv 32').replace('popcountBase 64','popcountBase 32')
wrapper32=h32+''' := by
  exact rhs_wide_observed hp ctx (Or.inl rfl) run
'''
p.write_text(s[:a]+generic+'\n'+wrapper+'\n'+wrapper32+s[z:])
