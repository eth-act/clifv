from pathlib import Path
r=Path('FV/E2E')
(r/'StockPopcountFixtures.lean').write_text('''import FV.E2E.StockBitFixtures
namespace E2E.StockPopcountNIWitness
open Backend.Stock.D0
set_option autoImplicit false
set_option Elab.async false

def extraBody (config : Configuration) : List Clif.Stmt :=
  let ty := valueType config
  [⟨[75],.unary .popcnt ty 1⟩,⟨[76],.unary .popcnt ty 2⟩,
   ⟨[77],.binary .bxor ty 75 76⟩,⟨[78],.binary .bxor ty 74 77⟩]

def function (config : Configuration) : Clif.Function :=
  let old := StockBitNIWitness.function config
  {old with name := "stock_popcount_ni", blocks := old.blocks.map fun b =>
    {b with body := b.body ++ extraBody config, term := .ret [78]}}

def resultValue (config : Configuration) (input : Nat → BitVec (valueType config).width) :
    BitVec (valueType config).width :=
  StockBitNIWitness.resultValue config input ^^^
    (Clif.Sem.unary .popcnt (input 1) ^^^ Clif.Sem.unary .popcnt (input 2))
end E2E.StockPopcountNIWitness
''')
s=(r/'StockBitWitness.lean').read_text().replace('StockBitFixtures','StockPopcountFixtures').replace('import FV.E2E.StockCastWitness','import FV.E2E.StockBitWitness').replace('namespace E2E.StockBitNIWitness','namespace E2E.StockPopcountNIWitness').replace('end E2E.StockBitNIWitness','end E2E.StockPopcountNIWitness').replace('Stock.Proof.BitBody.Family','Stock.Proof.PopcountBody.Family').replace('Stock.Scalar.domain_of_bit','Stock.Scalar.domain_of_popcount').replace('[74]','[78]').replace('} 67 ⟨','} 71 ⟨')
a=s.index('  change stm ∈');z=s.index('\n/-- Actual checked',a)
s=s[:a]+'''  change stm ∈ (E2E.StockBitNIWitness.function config).blocks[0]!.body ++ extraBody config at member
  rcases List.mem_append.mp member with old | popcount
  · exact Or.inl (E2E.StockBitNIWitness.source_family config stm old)
  · dsimp only [extraBody] at popcount
    simp only [List.mem_cons,List.not_mem_nil,or_false] at popcount
    rcases popcount with rfl | rfl | rfl | rfl
    all_goals first
      | exact .inr ⟨_,_,rfl⟩
      | exact .inl (.inl (.inl (.inl (.inl (.inl (.inl (.inr (.inr ⟨.bxor,_,_,_,rfl⟩)))))))))
'''+s[z:]
s=s.replace('def bitRoots','def popcountRoots').replace('bitRoots config','popcountRoots config').replace('bitRootsCovered','popcountRootsCovered')
s=s.replace('[756,922,927,918,934,902,904,908,911]','[940]').replace('[756,922,927,918,933,901,903,907,910]','[939]')
s=s.replace('Actual retained roots for unary operations and register/immediate rotations.','Actual retained roots for scalar popcount.').replace('Every ABI selects the five unary operations and all four rotation forms.','Every ABI selects the actual scalar popcount root.')
(r/'StockPopcountWitness.lean').write_text(s)
p=Path('FVTest/Backend/Lowering')
s=(p/'StockBitProductionRuntime.lean').read_text().replace('StockBit','StockPopcount').replace('STOCK_BIT_NATIVE_OUT','STOCK_POPCOUNT_NATIVE_OUT').replace('== 13','== 14').replace('Stock bit','Stock popcount').replace('bit-operation fixture','popcount fixture')
a=s.index('  ({E2E.StockCastNIWitness.function')
s=s[:a]+'''  ({E2E.StockBitNIWitness.function config with name := "retained_bit"}).print ++ "\\n" ++
'''+s[a:]
(p/'StockPopcountProductionRuntime.lean').write_text(s)
s=(p/'StockBitProductionLinked.lean').read_text().replace('StockBit','StockPopcount').replace('stock_bit','stock_popcount')
(p/'StockPopcountProductionLinked.lean').write_text(s)
