from pathlib import Path
import json,subprocess,os,ast,types
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();base='f74880a6ff5eafda12c20b7c5e04b910929e699d'
for name in ['normal','native','full','retention']:
 m=json.loads(Path('/tmp/stock-cast-'+name+'-manifest.json').read_text().replace('stock-cast','stock-bit').replace('STOCK_CAST','STOCK_BIT').replace('StockCastProduction','StockBitProduction').replace('Stock cast','Stock bit'))
 m.update(base=base,candidate=head,packet='bit-production-'+name,historical_evidence=['docs/research/stock-cast-production-activation.json'])
 m['env']['PATH']='/home/lee/.elan/toolchains/leanprover--lean4---v4.34.1/bin:/home/lee/.cargo/bin:/home/lee/clifv/.worktrees/stock-driver-incremental/rust/target/release:/home/lee/.local/share/clifv-test-tools/usr/bin:/home/lee/.rustup/toolchains/nightly-2026-09-26-x86_64-unknown-linux-gnu/lib/rustlib/x86_64-unknown-linux-gnu/bin:'+os.environ['PATH']
 m['validation_scope']='Unary integer bit operations and rotations, and all retained classes. Exact original input conditions, old public headers/required axioms, accepted identities and ordered stages remain. Original140 remains incomplete.'
 if name=='native':
  for g in m['gates']:g['argv']=['bit' if v=='cast' else v for v in g['argv']]
 Path('/tmp/stock-bit-'+name+'-manifest.json').write_text(json.dumps(m,indent=2)+'\n')
# Separate independent cohorts rather than serializing them in one running manifest.
old=json.loads(Path('/tmp/stock-cast-integration-manifest.json').read_text());template=old['gates'][0]
for kind,label in [('bit','integration'),('cast','cast-integration')]:
 m=dict(old);m.update(base=base,candidate=head,packet='bit-production-'+label,historical_evidence=['docs/research/stock-cast-production-activation.json']);m['env']=json.loads(Path('/tmp/stock-bit-normal-manifest.json').read_text())['env'];g=dict(template);g.update(id=kind+'-actual-cli-link-generated',argv=['python3','scripts/check-stock-mixed-integration.py','--output','{out}/'+kind,'--class',kind],outputs=['{out}/'+kind+'/receipt.json']);m['gates']=[g];Path('/tmp/stock-bit-'+label+'-manifest.json').write_text(json.dumps(m,indent=2)+'\n')
# Preserve all previous mathematical reference vectors exactly, including casts.
old=subprocess.check_output(['git','show',base+':scripts/check-stock-mixed-native.py'],text=True);now=Path('scripts/check-stock-mixed-native.py').read_text();mods=[]
for src in [old,now]:
 tree=ast.parse(src);tree.body=[x for x in tree.body if isinstance(x,(ast.FunctionDef,ast.Import,ast.ImportFrom))];m=types.ModuleType('native');exec(compile(tree,'native-grid','exec'),m.__dict__);mods.append(m)
result={}
for kind in ['mixed','logical','scalar','not','mul','shift','cast']:
 for bits in [32,64]:
  a,b=(m.run_commands(bits,kind) for m in mods);assert a==b;result[kind+'-'+str(bits)]=len(a)
result['bit']={str(bits):len(mods[1].run_commands(bits,'bit')) for bits in [32,64]};assert set(result['bit'].values())=={86};Path('/tmp/stock-bit-native-grid-retention.json').write_text(json.dumps(result,indent=2)+'\n')
for name in ['normal','native','full','retention','integration','cast-integration']:
 m=json.loads(Path('/tmp/stock-bit-'+name+'-manifest.json').read_text());print(name,[(g['id'],g['argv'],g.get('inputs'),g.get('outputs')) for g in m['gates']])
