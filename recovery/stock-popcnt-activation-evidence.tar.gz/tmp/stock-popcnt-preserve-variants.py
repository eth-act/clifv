from pathlib import Path
import subprocess
root=Path('FV/Backend/Proof')
names=['Rhs','Selected','Semantics','RecordValues','SourceValues']
for stem in names:
 old=root/f'StockPopcount{stem}.lean';new=root/f'StockScopedPopcount{stem}.lean'
 assert not new.exists()
 new.write_bytes(old.read_bytes())
 old.write_bytes(subprocess.check_output(['git','show',f'8442c331:{old}']))
for p in root.glob('Stock*Popcount*.lean'):
 if p.name in [f'StockPopcount{x}.lean' for x in names]: continue
 s=p.read_text()
 for stem in names:
  s=s.replace(f'import FV.Backend.Proof.StockPopcount{stem}\n',f'import FV.Backend.Proof.StockScopedPopcount{stem}\n')
 p.write_text(s)
