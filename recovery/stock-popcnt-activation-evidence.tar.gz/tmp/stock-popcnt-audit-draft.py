from pathlib import Path
r=Path('FV/Backend/Proof')
modules=['StockUnchangedHelper','StockSourceTypeMatch','StockPopcountScope','StockPopcountHelpers','StockPopcountDispatch','StockScopedPopcountRhs','StockPopcountMatch','StockPopcountForms','StockScopedPopcountSemantics','StockScopedPopcountSelected','StockGuardedRecordFrame','StockScopedPopcountRecordValues','StockScopedPopcountSourceValues','StockPopcountFamily','StockPopcountScanRefines','StockPopcountBodyRefines','StockPopcountReturnRefines','StockScalarPopcountDomain']
import re
lines=['import FV.E2E.StockPopcountWitness','']
for mod in modules:
 p=r/(mod+'.lean')
 if not p.exists(): continue
 s=p.read_text();ns=re.search(r'^namespace (\S+)',s,re.M).group(1)
 for name in re.findall(r'^theorem (\w+)',s,re.M): lines.append('#print axioms '+ns+'.'+name)
for name in ['step_frame','no_mem','spec_eq']: lines.append('#print axioms E2E.PopcountRead.'+name)
for name in ['checks_true','compiled_exists','source_entry','source_returns','source_checks_true','classifier_accepts','selected_roots_present','compiled_semantic_exists','source_family']:
 lines.append('#print axioms E2E.StockPopcountNIWitness.'+name+(' -- witness: native_decide' if name not in ['source_entry','source_returns','source_family'] else ''))
lines.append('#print axioms Backend.Stock.Scalar.popcountBodyEligible_sound')
Path('scripts/audit/stock-popcount-production.lean').write_text('\n'.join(lines)+'\n')
