from pathlib import Path
b=Path('FV/Backend/Proof');s=(b/'StockCountRecordValues.lean').read_text();a=s.index('theorem stock_lower_count_available_values');z=s.index('\n/-- Reusable state frontier',a);part=s[a:z];h=part.split(' := by',1)[0].replace('stock_lower_count_available_values','available_values').replace(' (trailing : Bool)','').replace('(countOp trailing)','.popcnt')
h='\n'.join(line for line in h.splitlines() if '(selectedId :' not in line and '(dfg :' not in line)
body=part.split(' := by\n',1)[1];a=body.index('  have last :');z=body.index('  have boundBase :=',a);body=body[:a]+'''  have inv := (stock_lower_record_context run scope events).1
  obtain ⟨width,data,type⟩ := source_data inv source clif
'''+body[z:]
body=body.replace('binding_base receipt.binding','ScalarCount.stock_binding_base receipt.binding').replace('stock_count_selected_values\n    (stock_lower_record_context run scope events).1 trailing source clif refines dfg getX\n    receipt.selected chosen','selected_values\n    inv source clif refines getX\n    receipt.selected').replace('countResult trailing','popcountResult').replace('countAlloc trailing','popcountAlloc').replace('countCode trailing','popcountCode').replace('scan_frontier','ScalarCount.stock_scan_frontier')
body=body.replace('cases trailing <;> rcases width','rcases width').replace('countResult,countAlloc','popcountResult,popcountAlloc')
a=body.index('    rw [recordBase,nextEq]');z=body.index('  have inside',a);body=body[:a]+'''    rw [recordBase,nextEq]
    exact (base_code width _ _).2
'''+body[z:]
a=body.index('    cases trailing <;> rcases width') if '    cases trailing <;> rcases width' in body else -1
# Replace code-template simplification from the previous family.
a=body.index('    rcases width',body.index('  have recordCode'));z=body.index('  have recordExec',a)
body=body[:a]+'''    rcases width with h | h | h | h
    all_goals simp [popcountCode,popcountBase,h,start,State.mark,LState.fresh,LState.emit,ScalarCount.stock_scan_emitted_empty]
'''+body[z:]
a=body.index('  · intro v required oldVal lookup');body=body[:a]+'''  · apply stock_lower_fresh_record_values_of_frame run scope dominated events records block statement current
      source clif results statementResults mapped recorded emitted (receipt.resultRegs.trans rss) fresh held ?_ value
    intro n outside
    apply kept
    rwa [high,starts] at outside
'''
pre='''import FV.Backend.Proof.StockPopcountSelected
import FV.Backend.Proof.StockCountRecordValues
import FV.Backend.Proof.StockGuardedRecordValues
namespace Backend.Stock.Proof.Popcount
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 20000
set_option maxHeartbeats 1000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm
'''
(b/'StockPopcountRecordValues.lean').write_text(pre+'\n'+h+' := by\n'+body+'\nend Backend.Stock.Proof.Popcount\n')
