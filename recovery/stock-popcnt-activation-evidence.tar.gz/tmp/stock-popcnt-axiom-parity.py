from pathlib import Path
import re,json

def read(root):
 out={}
 for p in Path(root).glob('*.log'):
  s=p.read_text()
  for n,axes in re.findall(r"^'(.+)' depends on axioms: \[([^]]*)\]",s,re.M):
   a=sorted(x.strip() for x in axes.split(',') if x.strip());assert n not in out or out[n]==a;out[n]=a
  for n in re.findall(r"^'(.+)' does not depend on any axioms",s,re.M):
   assert n not in out or out[n]==[];out[n]=[]
 return out
old=read('/tmp/stock-bit-final-audits');new=read('/tmp/stock-popcnt-final-audits-final');assert len(old)==1541
missing=sorted(set(old)-set(new));changed=sorted(n for n in old.keys()&new.keys() if old[n]!=new[n]);result={'baseline_roots':len(old),'current_roots':len(new),'missing':missing,'changed':changed,'exact_old_required_axiom_sets_preserved':not missing and not changed};Path('/tmp/stock-popcnt-axiom-parity.json').write_text(json.dumps(result,indent=2)+'\n');print(result);assert result['exact_old_required_axiom_sets_preserved']
