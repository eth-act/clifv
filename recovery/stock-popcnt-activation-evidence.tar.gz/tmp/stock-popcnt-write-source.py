from pathlib import Path
p=Path('FV/Backend/Proof/StockCountSourceValues.lean');s=p.read_text().replace('import FV.Backend.Proof.StockCountRecordValues','import FV.Backend.Proof.StockPopcountRecordValues').replace('namespace Backend.Stock.Proof.ScalarCount','namespace Backend.Stock.Proof.Popcount').replace('end Backend.Stock.Proof.ScalarCount','end Backend.Stock.Proof.Popcount').replace('stock_lower_count_available_source','available_source').replace('stock_lower_count_source_by_instruction','source_by_instruction').replace('stock_lower_count_available_values','available_values').replace(' (trailing : Bool)','').replace('(countOp trailing)','.popcnt')
s='\n'.join(line for line in s.splitlines() if '(selectedId :' not in line and '(dfg :' not in line)+'\n'
s=s.replace('mapped recorded emitted selectedId refines dfg held getX','mapped recorded emitted refines held getX')
a=s.index('  obtain ⟨receipt⟩ :=',s.index('theorem source_by_instruction'));z=s.index('  obtain ⟨u,getX⟩ :=',a);s=s[:a]+s[z:]
s=s.replace('mapped recorded emitted selectedId refines dfg held getX sourceStep','mapped recorded emitted refines held getX sourceStep')
Path('FV/Backend/Proof/StockPopcountSourceValues.lean').write_text(s)
