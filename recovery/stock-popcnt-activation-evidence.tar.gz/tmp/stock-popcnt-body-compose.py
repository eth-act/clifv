from pathlib import Path
root=Path('FV/Backend/Proof')
family='''import FV.Backend.Proof.StockBitFamily
import FV.Backend.Proof.StockPopcountSourceValues
namespace Backend.Stock.Proof.PopcountBody
open Backend.Proof Backend.Proof.Driver
set_option autoImplicit false
set_option Elab.async false

def Family (inst : Clif.Inst) : Prop :=
  BitBody.Family inst ∨ ∃ ty x, inst = .unary .popcnt ty x

theorem family_pure {inst : Clif.Inst} (family : Family inst) : pureInst inst = true := by
  rcases family with old | ⟨ty,x,rfl⟩
  · exact BitBody.family_pure old
  · rfl

theorem family_quiet {inst : Clif.Inst} (family : Family inst) : colored inst = false := by
  rcases family with old | ⟨ty,x,rfl⟩
  · exact BitBody.family_quiet old
  · rfl

theorem family_single {inst : Clif.Inst} (family : Family inst) (f : Clif.Function) :
    (inst.resultTypes (fun r => (f.extern? r).map (·.sig)) (f.sigDecls.lookup ·)).map List.length = some 1 := by
  rcases family with old | ⟨ty,x,rfl⟩
  · exact BitBody.family_single old f
  · rfl

theorem family_formats {inst : Clif.Inst} (family : Family inst) : CastBody.SafeFormat inst := by
  rcases family with old | ⟨ty,x,rfl⟩
  · exact BitBody.family_formats old
  · simp [CastBody.SafeFormat,instNames]

theorem popcount_inst_notrap {inst : Clif.Inst} (family : Family inst)
    (fr : Clif.Frame) (cm : Clif.Mem) (c : Clif.TrapCode) : Clif.evalInst fr cm inst ≠ .trap c := by
  rcases family with old | ⟨ty,x,rfl⟩
  · exact BitBody.bit_inst_notrap old fr cm c
  · cases getX : fr.getAs x ty with
    | trap code => exact False.elim (PureBody.frame_getAs_notrap fr x ty code getX)
    | stuck message => simp [Clif.evalInst,getX]
    | ok u => simp [Clif.evalInst,getX]

theorem popcount_source_notrap {env : Clif.Env} {cp : Clif.Program} (fuel : Nat)
    (s : Clif.State) (callers : s.callers = []) (family : ∀ stm ∈ s.frame.body,Family stm.inst)
    {xs : List Nat} (ret : s.frame.term = .ret xs) (code : Clif.TrapCode) :
    Clif.runLoop env cp fuel s ≠ .trapped code := by
  apply PureBody.pure_source_notrap fuel s callers ?_ ret code
  intro stm member
  exact ⟨family_pure (family stm member),popcount_inst_notrap (family stm member)⟩
end Backend.Stock.Proof.PopcountBody
'''
(root/'StockPopcountFamily.lean').write_text(family)
s=(root/'StockBitScanRefines.lean').read_text()
a=s.index('theorem stock_lower_unary_bit_scan_fall_refines');z=s.index('\ntheorem stock_lower_rotate_scan_fall_refines',a)
scan=s[a:z].replace('stock_lower_unary_bit_scan_fall_refines','stock_lower_popcount_scan_fall_refines').replace('    {op : Clif.UnaryOp} (unary : BitBody.Unary op)\n','').replace('(.unary op ty x)','(.unary .popcnt ty x)')
scan=scan.replace('obtain ⟨ρ\',execution,unchanged,post⟩ := BitBody.unary_source','obtain ⟨u,d,ρ\',getX,output,bounds,execution,value,unchanged,kept,post⟩ := Popcount.source_by_instruction').replace('current unary source','current source').replace('refines dfg values sourceStep','refines values sourceStep')
# Type-name formatting is checked against the generated file before compilation.
header=s[:a].replace('import FV.Backend.Proof.StockBitFamily','import FV.Backend.Proof.StockPopcountFamily').replace('import FV.Backend.Proof.StockCastScanRefines','import FV.Backend.Proof.StockBitScanRefines')
rest='''
def MixedPopcountOrOmittedRecord (f : Clif.Function) (ctx : Ctx) (bi : Nat) (r : ScanRecord) : Prop :=
  MixedBitOrOmittedRecord f ctx bi r ∨
    (∃ j b stm,f.blocks[bi]? = some b ∧ b.body[j]? = some stm ∧ r.inst = blockStart f bi+j ∧
      ∃ step,r.output.step = some step ∧ step.decision = .emitted ∧
      ∃ info ty x z a,ctx.insts[r.inst]? = some info ∧ info.clif = some (.unary .popcnt ty x) ∧
        info.results = [z] ∧ stm.results = [z] ∧ ctx.valueReg? z = some (.vreg a .int))
'''
a=s.index('theorem stock_lower_mixed_bit_record_fall_refines');z=s.index('\ntheorem stock_lower_mixed_bit_body_fall_refines',a)
record=s[a:z].replace('stock_lower_mixed_bit_record_fall_refines','stock_lower_mixed_popcount_record_fall_refines').replace('MixedBitOrOmittedRecord','MixedPopcountOrOmittedRecord')
record=record[:record.index('  rcases family with')]+'''  rcases family with old | popcount
  · exact stock_lower_mixed_bit_record_fall_refines run scope dominated events records sourceFamily old refines driver stable
  · obtain ⟨j,b,stm,block,statement,current,step,recorded,emitted,info,ty,x,z,a,
      source,clif,results,statementResults,mapped⟩ := popcount
    exact stock_lower_popcount_scan_fall_refines run scope dominated events records
      block statement current source clif results statementResults mapped recorded emitted refines stable
'''
body=s[z:].replace('stock_lower_mixed_bit','stock_lower_mixed_popcount').replace('MixedBitOrOmittedRecord','MixedPopcountOrOmittedRecord')
(root/'StockPopcountScanRefines.lean').write_text(header+scan+rest+'\n'+record+body)
s=(root/'StockBitBodyRefines.lean').read_text().replace('StockCastBodyRefines','StockBitBodyRefines').replace('StockBitFamily','StockPopcountFamily').replace('StockBitScanRefines','StockPopcountScanRefines').replace('namespace Backend.Stock.Proof.BitBody','namespace Backend.Stock.Proof.PopcountBody').replace('end Backend.Stock.Proof.BitBody','end Backend.Stock.Proof.PopcountBody').replace('MixedBitOrOmittedRecord','MixedPopcountOrOmittedRecord').replace('actual_bit_','actual_popcount_').replace('stock_lower_mixed_bit','stock_lower_mixed_popcount')
a=s.index('  rcases family with');z=s.index('\ntheorem actual_popcount_families',a)
s=s[:a]+'''  rcases family with old | ⟨ty,x,shape⟩
  · exact Or.inl (BitBody.emitted_record_family block statement current recorded emitted source clif one results mapped old)
  · have original : info.clif = some (.unary .popcnt ty x) := by rw [clif,shape]
    exact Or.inr ⟨j,b,stm,block,statement,current,step,recorded,emitted,
      info,ty,x,z,a,source,original,one,results,mapped⟩
'''+s[z:]
s=s.replace('Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inl','Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inl').replace('Or.inl omitted⟩)))))))','Or.inl omitted⟩))))))))')
s=s.replace('/-- Extension and zero-code reduction compose with every shipped scalar family','/-- Popcount composes with every shipped scalar family')
(root/'StockPopcountBodyRefines.lean').write_text(s)
for src,dst in [('StockBitReturnRefines','StockPopcountReturnRefines'),('StockScalarBitDomain','StockScalarPopcountDomain')]:
 s=(root/(src+'.lean')).read_text().replace('StockBit','StockPopcount').replace('BitBody','PopcountBody').replace('actual_bit_','actual_popcount_').replace('domain_of_bit','domain_of_popcount').replace('bit_source_notrap','popcount_source_notrap').replace('unary-bit/rotation','popcount').replace('mixed bit-operation','mixed popcount')
 (root/(dst+'.lean')).write_text(s)
