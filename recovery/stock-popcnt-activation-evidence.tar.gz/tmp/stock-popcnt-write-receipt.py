from pathlib import Path
import json,datetime
receipt=json.loads(Path('/tmp/stock-popcnt-terminal-receipt.json').read_text());backup=json.loads(Path('/tmp/stock-popcnt-activation-backup/metadata.json').read_text());assert backup['remote_verified'] and backup['source_head']==receipt['validated_source_head'];receipt['remote_backup']=backup
Path('docs/research/stock-popcount-production-activation.json').write_text(json.dumps(receipt,indent=2)+'\n')
Path('docs/research/stock-popcount-production-activation.md').write_text(f'''# Stock scalar popcount in production

Validated source `{receipt['validated_source_head']}`, reconciled onto main
`5e563a0b`. The shared default scalar route now supports i32/i64 popcount,
including combinations with every previously shipped scalar class. Original
input conditions, old theorem variants/selectors, exact required axiom sets,
accepted identities and ordered successful stages remain. The cleanup whitelist
is unchanged.

## Proof and production boundary

The existing complete original-source theorem is reused directly:
`ScalarPopcount.stock_lower_popcount_source_by_instruction`. It already derives
selection, operand reads, retained binding, fresh execution and the guarded
post-frame from the original successful driver and source step. Its existing
source-scope proof excludes i128/vector roots 941/942. All old popcount modules
and old witness modules remain byte-exact. Scalar roots 937/938/939/940 retain
existing zero/nonzero witnesses at i8/i16/i32/i64, with direct and prior aliases
and dirty upper machine bits. Body composition supplies its DFG relation
internally from the unchanged guarded source relation.

Stronger alternate variants developed during this batch are preserved separately
on `agent/stock-popcnt-scoped-alternatives-20261022` at `e2f15642`. They are not
required by this activation and are not included in the delivery packet.

Body/entry/return/no-trap proofs construct the existing universal Scalar.Domain.
The same compiler/checker/linker/generated-proof consumers use exact FMOV, CNT,
ADDP/ADDV and UMOV forms through shared ABI frame/transport/realization proofs.
No Arm/MInst/allocator model is changed. Whole mixed fixtures select actual roots
939/940 in six ABI configurations and both cleanup modes; prior computation stays
live, with arbitrary source inputs, an original arbitrary explicit slot, and a
ninth stack argument. Only two new fixed native facts enter witnesses; universal
compiler and source-transfer proofs use standard axioms only.

## Validation

All {receipt['primary_gate_count']} primary gates and {len(receipt['owned_gate_records'])} ownership partitions passed on frozen source:
{receipt['normal_library_jobs']:,} normal Lake keys; {receipt['normal_scheduled_modules']:,} scheduled modules;
four affected tools; current crate keys; {receipt['checked_in_audits']} trust audits /
{receipt['audited_roots']:,} roots. All 1,541 old axiom sets and 29 old public
headers in changed files are exact. Ownership covers
{receipt['owned_core_constants']:,} standard-only core / {receipt['owned_fixed_witness_constants']:,} fixed witness constants,
{receipt['core_owners']} core / {receipt['witness_owners']} witness / {receipt['executable_owners']} executable owners and
31 exact fixed native facts (previous 29 + 2). One bundled domain review reports
only the three standard axioms and no source warnings.

Real regalloc2 and Lean allocation retain complete-attempt retry and missing
oracle controls. All 24 objects pass 2,256 native comparisons with zero
failures/disagreements. Every vector and expected result of all eight previous
classes is exact. Zero and all-ones inputs exercise popcount. Current popcount
and retained bit-operation actual CLI/link/generated cohorts each pass 32 checks,
including 33-function slices, retained reconstruction, stack bounds and both
preparation modes. Original flat-multiply inputs/ELF/proof sources stay byte-exact;
fresh current proofs compile in both modes.

The attached JSON records corpus/encoder results, both E2E identity reports and
all original 1,150 / prior 1,159 identities and ordered stages, verified fv-demo
and survey results, exact source heads, input keys, logs and output hashes.

## Provenance, resources and remaining scope

The early alternate helper/RHS drafts and failed builds remain archived. Two 8 GiB build scopes
OOMed on existing arithmetic dependencies; a subsequent 16 GiB build succeeded.
The alternate guarded-frame lemma was isolated to avoid that dependency fan-out.
A draft interface-preservation mistake was corrected before author validation:
old theorem variants remain byte-exact, and alternatives are backed separately. Parse errors
in consumer/witness drafts were corrected before the frozen checks. The first native
checker stopped at an incomplete expected-name list before byte execution; its
failed record is retained. The harness fix passed a preflight and then all gates
were rerun on the final source commit. Failures
never count as passing validation. Independent integration cohorts use separate
one-gate manifests within the shared resource budget.

Terminal evidence is remotely verified at `{backup['backup_commit']}` on
`{backup['backup_branch']}`; archive SHA256 `{backup['archive_sha256']}`,
{backup['archive_bytes']:,} bytes / {backup['files']:,} files. Canonical recovery source
remains untouched. Four necessary views, one physical warm cache, over 700 GiB
free and max 16 GiB aggregate / two jobs. Expendable generated outputs are
archived before removal; no other projects are cleaned.

Full original #140 remains unfinished. Successful Stock lowering is still a
source-refinement premise; universal request/lowering and downstream completeness
remain obligations. Fallback is not Stock completeness. Next are comparisons /
min/max, high multiplication, division/remainder, complete original integer
widths/ABIs and all remaining original control, memory, traps, effects, calls,
source/block/whole-driver simulation, completeness and consumer obligations.
''')
p=Path('docs/plans/stock-driver-incremental-delivery.md');s=p.read_text();a=s.index('Next: popcount, reusing existing numerical/vector helper proofs and scoped');z=s.index('\n## Maintained validation runner',a)
s=s[:a]+f'''Popcount passes author gates through the same scalar consumers.
[Terminal evidence](../research/stock-popcount-production-activation.md) records
{receipt['primary_gate_count']} primary / {len(receipt['owned_gate_records'])} ownership gates, {receipt['audited_roots']:,} audited roots, all 1,541 old axiom
sets / 29 old public headers exact, 2,256 native comparisons and two 32-check
actual CLI/link/generated cohorts. Validated source `{receipt['validated_source_head'][:8]}`;
terminal evidence backed at `{backup['backup_commit'][:8]}`. Existing numerical/helper proofs
and original scope closure are reused; old variants remain. Existing complete source-transfer witnesses cover all four scalar
widths; production activation is i32/i64.

Next: comparisons/min/max, high multiply/division/remainder, complete original
integer widths and ABIs, and every unchanged original #140 control/memory/trap/
effect/call/source/block/whole-driver/completeness/consumer obligation. Universal
successful lowering and downstream completeness remain. Fallback is not Stock
completeness; full original #140 remains unfinished.
'''+'\nReuse existing complete source wrappers before writing alternate proofs. The\ncurrent interpreted runtime and linked fixtures each take minutes; measure ordinary\nnative lean_exe targets for the same fixture code in the next batch, preserving\nevery gate and its inputs. This is a bounded execution improvement, not a new\nworkflow system.\n'+s[z:];p.write_text(s)
p=Path('docs/research/stock-driver-obligations.json');x=json.loads(p.read_text());x['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();x['production']['landed'].append('i32/i64 popcount through shared scalar consumers (validated, squash pending)');x['production']['pending']=receipt['next']
for r in x['roots']:
 if r['id'] in [937,938,939,940]:
  r['status']='actual source selection/RHS matching/execution/retained binding/guarded transfer validated at four scalar widths; i32/i64 body/entry/default consumers validated, squash pending; universal lowering/downstream completeness remains';r['current_proof']='docs/research/stock-popcount-production-activation.md'
 if r['id'] in [941,942]:
  r['status']='excluded by existing original-scope selected-root closure and current scalar opcode inventory; no new scope restriction';r['current_proof']='FV/Backend/Proof/StockPopcountDispatch.lean'
x['complete']=False;p.write_text(json.dumps(x,indent=2)+'\n')
