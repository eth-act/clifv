from pathlib import Path
s='''import FV.Backend.Proof.StockPopcountForms
import FV.Backend.Proof.StockCountSemantics
namespace Backend.Stock.Proof.Popcount
open Backend.Proof Backend.Proof.Driver
set_option autoImplicit false
set_option Elab.async false
set_option maxHeartbeats 1000000

private theorem mapped_code {aliases : Array (Option Nat)} {d x : Nat}
    (bounded : aliases.size ≤ d) (w : Nat) :
    ((popcountCode w d x).map (·.mapRegs (Backend.lowerFunction.resolve aliases (aliases.size+1)))) =
      popcountCode w d (aliasNum aliases x) := by
  have a : aliasNum aliases d = d := by
    apply chaseF_none; rw [Array.getElem?_eq_none bounded]; rfl
  have b : aliasNum aliases (d+1) = d+1 := by
    apply chaseF_none; rw [Array.getElem?_eq_none (by omega : aliases.size ≤ d+1)]; rfl
  have c : aliasNum aliases (d+2) = d+2 := by
    apply chaseF_none; rw [Array.getElem?_eq_none (by omega : aliases.size ≤ d+2)]; rfl
  have e : aliasNum aliases (d+3) = d+3 := by
    apply chaseF_none; rw [Array.getElem?_eq_none (by omega : aliases.size ≤ d+3)]; rfl
  simp only [aliasNum] at a b c e
  unfold popcountCode
  split <;> split <;> simp only [ite_false,ite_true,List.map_append,List.map_cons,List.map_nil,
    MInst.mapRegs,resolve_vreg,a,b,c,e]
  all_goals first | rfl | split <;> rfl

/-- Actual resolved scalar/vector templates implement the source bit count and
write only their fresh allocation, even when old register high bits are arbitrary. -/
theorem resolved {F : BitVec 64 → Prop} {isem : Backend.Proof.Sem}
    (refines : Refines F isem) {ty : Clif.Ty} (width : IW ty.width)
    {aliases : Array (Option Nat)} {ρ : Nat → CV} {d x : Nat}
    (bounded : aliases.size ≤ d) {u : BitVec ty.width}
    (held : VHolds ⟨ty,u⟩ (ρ (aliasNum aliases x))) :
    ∃ ρ',PRun F isem ((popcountCode ty.width d x).map
        (·.mapRegs (Backend.lowerFunction.resolve aliases (aliases.size+1)))) ρ ρ' ∧
      VHolds ⟨ty,Clif.Sem.unary .popcnt u⟩ (ρ' (popcountResult ty.width d)) ∧
      ∀ n,n < d ∨ d+popcountAlloc ty.width ≤ n → ρ' n = ρ n := by
  rw [mapped_code bounded]
  rcases width with h | h | h | h
'''
for w in [8,16,32,64]:
 a='(lo64 (ρ (aliasNum aliases x))).setWidth 128' if w==64 else '((lo64 (ρ (aliasNum aliases x))).setWidth 32).setWidth 128'
 s+=f'''  · let a : CV := {a}
    let first := upd ρ d a
    let b : CV := (cntBytes (lo64 (first d))).setWidth 128
    let second := upd first (d+1) b
'''
 if w!=8:
  c='(addpBytes (lo64 (second (d+1))) (lo64 (second (d+1)))).setWidth 128' if w==16 else '(addvBytes (lo64 (second (d+1)))).setWidth 128'
  s+=f'''    let c : CV := {c}
    let third := upd second (d+2) c
'''
 j=2 if w==8 else 3;current='second' if w==8 else 'third';src=1 if w==8 else 2
 s+=f'''    let result : CV := ofX ((({current} (d+{src})).extractLsb' (8*0) 8).setWidth 64)
    refine ⟨upd {current} (d+{j}) result,?_,?_,?_⟩
    · simp only [popcountCode,h]
      exact '''+'('.join([])
 steps=3 if w==8 else 4
 s+='prun_rr_c refines rfl (fun _ => rfl) ('*(steps-1)+'prun_rr_c refines rfl (fun _ => rfl) (prun_nil _)'+')'*(steps-1)+'\n'
 s+=f'''    · simp only [popcountResult,popcountAlloc,h,upd_same]
      change result.setWidth ty.width = Clif.Sem.unary .popcnt u
      have computed : result.setWidth ty.width = ((ρ (aliasNum aliases x)).setWidth ty.width).cpop := by
        rw [h]
        dsimp only [result,{current},'''+('third,c,' if w!=8 else '')+'''second,b,first,a]
        simp only [upd_same]
'''
 s+=f'''        exact Backend.Proof.popcnt{w}_fin (ρ (aliasNum aliases x))
      exact computed.trans (congrArg (fun v => v.cpop) held)
    · intro n outside
      simp only [popcountAlloc,h] at outside
      simp only [result,{current},'''+('third,' if w!=8 else '')+'''second,first,upd,
        show n ≠ d by omega,show n ≠ d+1 by omega,show n ≠ d+2 by omega,
'''+('        show n ≠ d+3 by omega,\n' if w!=8 else '')+'''        ite_false]
'''
s+='end Backend.Stock.Proof.Popcount\n';Path('FV/Backend/Proof/StockPopcountSemantics.lean').write_text(s)
