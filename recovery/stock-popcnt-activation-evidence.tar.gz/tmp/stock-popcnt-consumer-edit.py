from pathlib import Path
p=Path('FV/Backend/ABIReadScalar.lean');s=p.read_text();a=s.index('def instruction (sig')
s=s[:a]+'''/-- The exact vector producers used by scalar popcount. -/
def popcountProducer : MInst → Bool
  | .movToFpu _ _ .size32 | .movToFpu _ _ .size64
  | .movFromVec _ _ 0 .size8 | .vecMisc .cnt _ _ .size8x8
  | .vecLanes .addv _ _ .size8x8 | .vecRRR .addp _ _ _ .size8x8 => true
  | _ => false

'''+s[a:];s=s.replace('|| bitProducer i\n','|| bitProducer i || popcountProducer i\n');p.write_text(s)
p=Path('FV/Backend/Lowering/StockScalar.lean');s=p.read_text();a=s.index('def eligible (f')
s=s[:a]+'''/-- Popcount extends the source family while all previous selectors stay fixed. -/
def popcountEligible (stm : Clif.Stmt) : Bool :=
  match stm.inst with
  | .unary .popcnt ty _ => ty == .i32 || ty == .i64
  | _ => false

def popcountBodyEligible (stm : Clif.Stmt) : Bool := bitBodyEligible stm || popcountEligible stm

'''+s[a:];s=s.replace('b.body.all bitBodyEligible','b.body.all popcountBodyEligible');p.write_text(s)
p=Path('FV/Backend/Proof/StockScalarCheck.lean');s=p.read_text().replace('import FV.Backend.Proof.StockScalarBitDomain','import FV.Backend.Proof.StockScalarBitDomain\nimport FV.Backend.Proof.StockScalarPopcountDomain');a=s.index('theorem sourceOk_sound')
s=s[:a]+'''/-- Original popcount syntax derives the universal source contract internally. -/
theorem popcountBodyEligible_sound {stm : Clif.Stmt} (checked : popcountBodyEligible stm = true) :
    Stock.Proof.PopcountBody.Family stm.inst := by
  simp only [popcountBodyEligible,Bool.or_eq_true] at checked
  rcases checked with old | popcount
  · exact Or.inl (bitBodyEligible_sound old)
  · cases inst : stm.inst <;> simp only [popcountEligible,inst] at popcount
    all_goals try contradiction
    next op ty x =>
      cases op <;> simp only [popcountEligible] at popcount
      all_goals try contradiction
      exact Or.inr ⟨ty,x,rfl⟩

'''+s[a:];a=s.index('theorem sourceOk_sound');s=s[:a]+s[a:].replace('Stock.Proof.BitBody.Family','Stock.Proof.PopcountBody.Family').replace('exact bitBodyEligible_sound supported','exact popcountBodyEligible_sound supported').replace('exact domain_of_bit','exact domain_of_popcount');p.write_text(s)
p=Path('FV/E2E/SemanticNIBoundary.lean');s=p.read_text().replace('Backend.ABIReadScalar.bitProducer,','Backend.ABIReadScalar.bitProducer,Backend.ABIReadScalar.popcountProducer,');p.write_text(s)
p=Path('FV/E2E/ABIReadScalar.lean');s=p.read_text().replace('import FV.E2E.ABIReadBitSteps','import FV.E2E.ABIReadBitSteps\nimport FV.E2E.ABIReadPopcountSteps');s=s.replace('| .movK .. | .bitfieldMove .. | .extend .. | .bitRR .. => true','| .movK .. | .bitfieldMove .. | .extend .. | .bitRR ..\n  | .movToFpu .. | .movFromVec .. | .vecMisc .. | .vecLanes .. | .vecRRR .. => true')
s=s.replace('  | bitRR op sz rd rn => cases checked','  | bitRR op sz rd rn => cases checked\n  | movToFpu .. | movFromVec .. | vecMisc .. | vecLanes .. | vecRRR .. => cases checked',1)
a=s.index('private theorem extension_special');s=s[:a]+'''private theorem popcount_special {i : MInst} (checked : Backend.ABIReadScalar.popcountProducer i = true) : special i = true := by
  cases i <;> first | rfl | cases checked

'''+s[a:]
s=s.replace('rcases checked with (((old | added) | shifted) | extended) | bit','rcases checked with ((((old | added) | shifted) | extended) | bit) | popcount')
s=s.replace('    obtain ⟨frame,control⟩ := BitRead.step_frame bit run\n    exact ⟨frame,.inl control⟩','    obtain ⟨frame,control⟩ := BitRead.step_frame bit run\n    exact ⟨frame,.inl control⟩\n  · simp only [sem,popcount_special popcount,↓reduceIte] at run\n    obtain ⟨frame,control⟩ := PopcountRead.step_frame popcount run\n    exact ⟨frame,.inl control⟩')
s=s.replace('    exact mspec_lockstep (BitRead.no_mem bit) worlds run','    exact mspec_lockstep (BitRead.no_mem bit) worlds run\n  · simp only [sem,popcount_special popcount,↓reduceIte] at run ⊢\n    exact mspec_lockstep (PopcountRead.no_mem popcount) worlds run')
s=s.replace('\nend Realize','''
  · simp only [sem,popcount_special popcount,↓reduceIte] at executed
    obtain ⟨spec,run,related⟩ := mspec_lockstep (PopcountRead.no_mem popcount) worlds.symm executed
    rw [PopcountRead.spec_eq popcount] at run
    obtain ⟨actual,realized,related'⟩ := refines_valueSem F ctx X _ us t outs spec run
    exact ⟨actual,realized,related'.trans related.symm⟩

end Realize''');p.write_text(s)
