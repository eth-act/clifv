from pathlib import Path
import json,subprocess,copy
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
base='5e563a0baf63f9d582acb4cd49b43c1648250217'
def change(v):
 if isinstance(v,str):
  if v=='bit':return 'popcount'
  return v.replace('stock-bit','stock-popcnt').replace('StockBit','StockPopcount').replace('STOCK_BIT','STOCK_POPCOUNT').replace('Stock bit','Stock popcount').replace('{out}/bit','{out}/popcount').replace('bit-actual','popcount-actual')
 if isinstance(v,list):return [change(x) for x in v]
 if isinstance(v,dict):return {change(k):change(x) for k,x in v.items()}
 return v
for kind in ['normal','native','full','retention','integration']:
 m=change(json.loads(Path('/tmp/stock-bit-'+kind+'-manifest.json').read_text()))
 m.update(packet='popcount-production-'+kind,base=base,candidate=head,historical_evidence=['docs/research/stock-bit-production-activation.json'],validation_scope='Scalar popcount and all prior retained classes. Preserve original input conditions, public theorem variants and exact required axioms, accepted identities and ordered stages. Original #140 remains unfinished; legacy fallback is not Stock completeness.')
 if kind=='retention':m['gates'][0]['argv'][1]='/tmp/stock-mul-retained-flat-multiply.py'
 Path('/tmp/stock-popcnt-'+kind+'-manifest.json').write_text(json.dumps(m,indent=2)+'\n')
m=json.loads(Path('/tmp/stock-bit-integration-manifest.json').read_text());m.update(packet='popcount-production-retained-bit-integration',base=base,candidate=head,historical_evidence=['docs/research/stock-bit-production-activation.json'])
Path('/tmp/stock-popcnt-bit-integration-manifest.json').write_text(json.dumps(m,indent=2)+'\n')
print('Prepared six frozen manifests for',head)
