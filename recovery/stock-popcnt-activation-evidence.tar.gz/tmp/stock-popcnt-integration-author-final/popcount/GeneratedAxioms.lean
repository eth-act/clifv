import Crates.StockPopcountProduction2CleanupFallbackGlobal
import Crates.StockPopcountProduction2PlainFallbackGlobal
import Crates.StockPopcountProduction2RetainedCleanupFallbackGlobal
import Crates.StockPopcountProduction2RetainedPlainFallbackGlobal
import Crates.StockPopcountProduction33CleanupFallbackEntries
import Crates.StockPopcountProduction33CleanupFallbackGlobal
import Crates.StockPopcountProduction6CleanupFallbackGlobal
import Crates.StockPopcountProduction6CleanupStrictGlobal
import Crates.StockPopcountProduction6MixedCleanupFallbackGlobal
import Crates.StockPopcountProduction6MixedPlainFallbackGlobal
import Crates.StockPopcountProduction6PlainFallbackGlobal
import Crates.StockPopcountProduction6PlainStrictGlobal
import Crates.PopcountProductionCLIcurrentPlain
import Crates.PopcountProductionCLIretainedPlain
import Crates.PopcountProductionCLIcurrentCleanup
import Crates.PopcountProductionCLIretainedCleanup
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let generated := fun (name : Name) =>
    name.toString.startsWith "Crates.StockPopcountProduction" || name.toString.startsWith "Crates.PopcountProductionCLI"
  let mut count : Nat := 0
  for (name, _) in env.constants.toList do
    unless generated name do continue
    for ax in ← collectAxioms name do
      if #[``propext, ``Classical.choice, ``Quot.sound].contains ax then continue
      unless generated ax && (ax.toString.splitOn "._native.native_decide.ax_").length > 1 do
        throwError "unexpected generated-proof axiom {ax} in {name}"
    count := count + 1
  unless count > 0 do throwError "empty generated-proof audit"
  logInfo m!"STOCK_POPCOUNTPRODUCTION_GENERATED_AXIOMS_PASS {count}"
