# Stock driver completion (#140)

State: active. Full original #140 remains unfinished. Owner @codygunton and this agent.
Updated UTC: 2026-10-21T23:11:46.058121+00:00

## Current delivery

Branch agent/stock-bit-activation-20261021, based actual main f74880a6 (#365); pushed checkpoint ab08eefa. Active view /home/lee/clifv/.worktrees/stock-driver-incremental. Original dirty driver-proof-resume remains untouched/backed29f6be2f.

Next coherent class: negation, CLZ/CTZ, bit reversal/byte swap, register/immediate left/right rotations. Reuse StockUnaryDispatch/StockCountSourceValues/StockRotateSourceValues instruction-derived proofs. External family/no-trap/guarded source-transfer/ABI producer/arbitrary-input fixture drafts compile; actual Stock.lower discovery succeeds across six ABIs with all nine intended new roots/configuration and compatible producer forms. These are prototypes, not production activation or complete author gates.

First implement generic cast format variants preserving every old header, then compose new bit records/body/entry-return/domain and production classifier/ABI, complete witnesses and existing consumers. Run one complete batch, splitting independent integration cohorts into separate one-gate manifests within max16GiB/two slots. All unchanged original140 scalar/control/memory/effects/calls/source/block/whole-driver/completeness/consumer obligations remain after it. Fallback is not Stock-only completeness.

## Landed and evidence

#357 ba08bcaf add/sub/select; #35840333cb4 bounded gate runner; #359779bc7ba logical; #36022a05d3b constant prerequisite; #361150738a9 constants/shared consumers; #3620ce772eb NOT/fused NOT; #3631246b455 multiply/fused multiply; #3644966cf92 shifts/fused bitfields; #365f74880a6 casts. Each squash tree exact against validated implementation plus documentation receipts; integrator notified140/261.

Cast terminal18primary/15ownership gates,2742normalkeys/2739scheduledmodules,50audits/1506roots,1470priorAXsets/43oldheaders exact;3016Std3core/804fixedwitness constants,27exactfixednativefacts.24objects/1680nativecomparisons/420Craneliftreferences, both32-check actualCLI/link/generated cohorts, originalartifactretention and fullruntime/encoder/E2E/verifiedexamples passed. Permanent docs/research/stock-cast-production-activation.{md,json}; remote evidence60dab84bb4b3936a5aff8af2be85e12438d5857c, archiveSHA5b4685bffc68bab5a67dd87cb59de8656df4258d0cd037ca9ab258f79e490264,10,414,966bytes/972files. Includes all next-class drafts and failed attempts.

## Preservation/resources/coordination

Original input conditions, old theorem variants/selectors, exact required axiom sets, accepted identities and ordered successful stages remain mandatory. Four necessary worktrees, one physical warm cache,740GiBfree; max16GiB aggregate/max2jobs. No shared Arm/MInst/allocator edits. Removed44expendable generatedOLEAN/ILEAN outputs (7.6MB) after archive; unique sources/logs/ELFs/recovery evidence preserved. No healthy kernel kills or other-project cleanup.

Contributor statuses52/71 unchanged on reread; current140/261 notices include actual squash and next scope. No concrete overlap or additional drift. Next is not a reservation; follow specific-conflict coordination before touching overlapping behaviour/assumptions.

Implementation batch compiled:original-source/retained-record/body/entry-return/no-trap/domain, production classifier soundness, ABI framing/transport/realization, complete witnesses for all6ABIs/bothcleanup modes/all9newroots per configuration. All45priorpublicheaders exact. Source checkpointab08eefa pushed; normal-key rebuild94affectedmodules now starts (2749scheduled). Added37newchecked-inauditroots. Actualruntime/native/CLI/link/generated/full/AXparity gates pending; not merge-ready yet. Frozen source/HEAD for author gates. UTC:2026-10-21T23:18:56.591379+00:00

Normal/trust batch passed:2749scheduledmodules(75rebuilt;93actualaffectedlibrarymodules),2752normalkeys,4tools,51trustaudits/1541roots; all1506priorAXsets/45oldpublicheaders exact. One bundled domain_of_bit review Std3/no warnings; completedownedserver4047798 released.17ownership records and realruntime/native active. Corrected an audit-script path in pre-gate library scheduling; failed pre-gate record preserved, audit remains trust-gated. Sources/HEAD remain frozen atab08eefa;mainf74880a6 unchanged. UTC:2026-10-21T23:27:13.206835+00:00

Realruntime/native and17ownership partitions passed:24objects/2064nativecomparisons/516Craneliftreferences,0failures/disagreements;3093Std3core/849fixedwitness constants,156core/27witness/16executable owners with29exactfixednativefacts(previous27+2). Full batch passed:1579cratekeys,runtime4737/0(same7knownnon-runnable),encoder1321identical/0different,bothE2Emodes1159/0withoriginal1150/prior1159identityandorderedstageparity exact;verifiedfv-demo21tests/2binaries,survey53tests/18binaries. Originalflat-multiplyartifactretention/freshproofsbothmodespassed. Independent currentbit andretainedcast CLI/link/generated cohorts now runinparallel within2slots. UTC:2026-10-21T23:38:43.769256+00:00

Terminal evidence complete:18primary/17ownership gates and bothactualcohorts32/32passed on validatedab08eefa. Documentation-onlyreceipt24878f22 pushed (exactly4docfiles differ). Remote backup9f4c6d0ed389e6f5c2738a27e54d6f259d2ef232 verified;archiveSHA03be53bd0f5497df9d329cb7e6ff69172b75300ce6a38116dc2f7e89fde514ca,11,198,080bytes/1026files,includescompiledstandard-onlypopcountbridge/closureprototypesandfailures. Preparing non-draft PR/squash. UTC:2026-10-21T23:48:23.894670+00:00

Non-draft PR366 https://github.com/eth-act/clifv/pull/366, head24878f22214afea6f9f6eb4b332d16c24903bd0b pushed. Main remainsf74880a6; comparison check queued, no failed source check. All author gates complete; squash now under per-PR author-gate discipline. UTC:2026-10-21T23:48:39.941962+00:00
