# Next packet after unary bit/rotation activation

Full original140 scope remains unchanged. Next concrete packet: popcount.
Existing IselFamAluBPopcnt contains all four numerical facts popcnt{8,16,32,64}_fin
and helper inversions (mov_to_fpu_ok, vec_cnt_ok, addp_ok, addv_ok,
mov_from_vec_ok). Reuse them through existing scoped projection. CV is128bits;
float-class temporaries are already supported by the legacy model. Do not
rewrite numerical proofs or change shared Arm/MInst/allocator modules.

Actual source opcode is111. Historical root ledger has integer937/938/939/940,
i128941 and vector942. Rule941 explicitly matches I128 and942 I8X16. Original
Compile.tyE excludes both; derive exclusions from actual matched source types.
Kernel-check the inventory/closure before counting it. A conservative textual
helper-call closure (22terms/10rules) and generic unchanged-helper observation
proof are in stock-bit-next-popcnt. Both compile as external prototypes; all three public roots audit under standard axioms. They are not production activation or author gates.
The bridge preserves all scheduling fields and lets existing helper inversions
establish actual emission. Finite Data-based constructor/closure assumptions
must be discharged internally; add no caller-selected certificate premise.

Pure source/body/entry/no-trap and existing scalar consumer composition can be
extended using BitBody's generic record handler with derived SafeFormat. Earlier
cast variants remain fixed. ABI producer support needs the actual integer-vector
moves/CNT/sum/UMOV forms; preserve old selectors and cleanup whitelist. Complete
fixed witness must retain the current bit+cast computations and all earlier
classes, use arbitrary inputs/slot and stack arguments, exercise actual roots
in all6ABIs/bothcleanup modes, and include observable0/all-one popcounts.

After popcount: comparisons/min/max (including cast-of-icmp look-through),
high multiply/division/remainder; complete original i8/i16 widths and ABI cases;
control/memory/traps/effects/calls/source/block/whole-driver simulation,
completeness and every production consumer. Current first classes use i32/i64;
do not treat this staging or legacy fallback as full original140 completeness.

Keep one warm cache, four necessary views, max16GiB/two jobs and ample free space.
Independent integration cohorts get separate one-gate manifests up front.
Preserve exact original axioms/headers/identities/ordered stages and artifacts.
