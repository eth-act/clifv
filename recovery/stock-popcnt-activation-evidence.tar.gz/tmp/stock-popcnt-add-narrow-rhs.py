from pathlib import Path
p=Path('FV/Backend/Proof/StockPopcountRhs.lean');s=p.read_text();a=s.index('theorem rhs_wide_observed');z=s.index('\ntheorem rhs64_observed',a);block=s[a:z];body=block.split('  all_goals\n',1)[1];body='\n'.join(line[2:] if line.startswith('  ') else line for line in body.splitlines()).rstrip()+'\n'
a=s.index('theorem rhs64_observed');h=s[a:s.index(' := by',a)]
def header(w,line):
 return h.replace('rhs64_observed',f'rhs{w}_observed').replace('rule_lower_2092.rhs',f'rule_lower_{line}.rhs').replace('popcountEnv 64',f'popcountEnv {w}').replace('popcountBase 64',f'popcountBase {w}').replace('st.base.nextVreg+3','st.base.nextVreg+2' if w==8 else 'st.base.nextVreg+3')
b16=body.replace('*,popcountRule,rule_lower_2086,rule_lower_2092,','*,rule_lower_2080,').replace(' rx sz :=',' rx .size32 :=').replace('27 473','27 469').replace('addv_observed','addp_observed').replace('.vecLanes .addv (.vreg (st.base.nextVreg+2) .float) (.vreg (st.base.nextVreg+1) .float) .size8x8','.vecRRR .addp (.vreg (st.base.nextVreg+2) .float) (.vreg (st.base.nextVreg+1) .float) (.vreg (st.base.nextVreg+1) .float) .size8x8')
b8=body.replace('*,popcountRule,rule_lower_2086,rule_lower_2092,','*,rule_lower_2074,').replace(' rx sz :=',' rx .size32 :=')
a=b8.index('  have h3 :=');z=b8.index('  have h4 :=',a);b8=b8[:a]+b8[z:]
a=b8.index('  rw [hs3] at hm4 hs4');z=b8.index('  have e1',a);b8=b8[:a]+'''  rw [hs2] at hm4 hs4
  rw [hs1] at hm2 hs2 hm4 hs4
'''+b8[z:]
a=b8.index('  have e3 :');z=b8.index('  have e4 :',a);b8=b8[:a]+b8[z:]
b8=b8.replace('.movFromVec (.vreg (st.base.nextVreg+3) .int) (.vreg (st.base.nextVreg+2) .float) 0 .size8','.movFromVec (.vreg (st.base.nextVreg+2) .int) (.vreg (st.base.nextVreg+1) .float) 0 .size8').replace('  · rw [hs3]','  · rw [hs2]')
s=s.replace('\nend Backend.Stock.Proof.Popcount','\n'+header(8,2074)+' := by\n'+b8+'\n'+header(16,2080)+' := by\n'+b16+'\nend Backend.Stock.Proof.Popcount');p.write_text(s)
