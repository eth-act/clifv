from pathlib import Path
import re
b=Path('FV/Backend/Proof');s=(b/'StockCastScanRefines.lean').read_text()
def theorem(s,name):
 a=s.index('theorem '+name+' ');m=re.search(r'\n(?:theorem |end )',s[a:]);return s[a:a+m.start()]
base=theorem(s,'stock_lower_extend_scan_fall_refines_of_formats')
param='(sourceFamily : ∀ b ∈ f.blocks,∀ stm ∈ b.body,CastBody.SafeFormat stm.inst) (sg : Bool)'
u=base.replace('stock_lower_extend_scan_fall_refines_of_formats','stock_lower_unary_bit_scan_fall_refines').replace(param,'{op : Clif.UnaryOp} (unary : BitBody.Unary op)').replace('.extend (ScalarCast.extendOp sg) ty x','.unary op ty x').replace('CastComplete.extend_source_of_formats','BitBody.unary_source').replace('current sourceFamily sg','current unary')
r=base.replace('stock_lower_extend_scan_fall_refines_of_formats','stock_lower_rotate_scan_fall_refines').replace(param,'(left : Bool)').replace('{x z a : Nat}','{x y z a : Nat}').replace('.extend (ScalarCast.extendOp sg) ty x','.binary (ScalarRotate.rotateOp left) ty x y').replace('CastComplete.extend_source_of_formats','BitBody.rotate_source').replace('current sourceFamily sg','current left')
record='''
def MixedBitOrOmittedRecord (f : Clif.Function) (ctx : Ctx) (bi : Nat) (r : ScanRecord) : Prop :=
  MixedCastOrOmittedRecord f ctx bi r ∨
    (∃ j b stm,f.blocks[bi]? = some b ∧ b.body[j]? = some stm ∧ r.inst = blockStart f bi+j ∧
      ∃ step,r.output.step = some step ∧ step.decision = .emitted ∧
      ∃ info op ty x z a,ctx.insts[r.inst]? = some info ∧ info.clif = some (.unary op ty x) ∧
        info.results = [z] ∧ stm.results = [z] ∧ ctx.valueReg? z = some (.vreg a .int) ∧ BitBody.Unary op) ∨
    (∃ j b stm,f.blocks[bi]? = some b ∧ b.body[j]? = some stm ∧ r.inst = blockStart f bi+j ∧
      ∃ step,r.output.step = some step ∧ step.decision = .emitted ∧
      ∃ info left ty x y z a,ctx.insts[r.inst]? = some info ∧
        info.clif = some (.binary (ScalarRotate.rotateOp left) ty x y) ∧
        info.results = [z] ∧ stm.results = [z] ∧ ctx.valueReg? z = some (.vreg a .int))
'''
h=theorem(s,'stock_lower_mixed_cast_record_fall_refines_of_formats').split(' := by')[0].replace('stock_lower_mixed_cast_record_fall_refines_of_formats','stock_lower_mixed_bit_record_fall_refines').replace('MixedCastOrOmittedRecord','MixedBitOrOmittedRecord')
h+=''' := by
  rcases family with old | unary | rotated
  · exact stock_lower_mixed_cast_record_fall_refines_of_formats run scope dominated events records sourceFamily old refines driver stable
  · obtain ⟨j,b,stm,block,statement,current,step,recorded,emitted,info,op,ty,x,z,a,
      source,clif,results,statementResults,mapped,supported⟩ := unary
    exact stock_lower_unary_bit_scan_fall_refines run scope dominated events records
      block statement current supported source clif results statementResults mapped recorded emitted refines stable
  · obtain ⟨j,b,stm,block,statement,current,step,recorded,emitted,info,left,ty,x,y,z,a,
      source,clif,results,statementResults,mapped⟩ := rotated
    exact stock_lower_rotate_scan_fall_refines run scope dominated events records
      block statement current left source clif results statementResults mapped recorded emitted refines stable
'''
body=theorem(s,'stock_lower_mixed_cast_body_fall_refines').replace('stock_lower_mixed_cast_body_fall_refines','stock_lower_mixed_bit_body_fall_refines').replace('MixedCastOrOmittedRecord','MixedBitOrOmittedRecord').replace('CastBody.Family stm.inst','CastBody.SafeFormat stm.inst').replace('stock_lower_mixed_cast_record_fall_refines','stock_lower_mixed_bit_record_fall_refines')
pre='''import FV.Backend.Proof.StockCastScanRefines
import FV.Backend.Proof.StockBitFamily
namespace Backend.Stock.Proof
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 20000
set_option maxHeartbeats 1000000
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm emitBranch scanBlock
'''
(b/'StockBitScanRefines.lean').write_text(pre+'\n'+u+'\n'+r+'\n'+record+'\n'+h+'\n'+body+'\nend Backend.Stock.Proof\n')
s=(b/'StockCastBodyRefines.lean').read_text();pre=s[:s.index('/-- Source syntax')].replace('StockCastFamily','StockBitFamily').replace('StockCastScanRefines','StockBitScanRefines').replace('namespace Backend.Stock.Proof.CastBody','namespace Backend.Stock.Proof.BitBody')
emit=theorem(s,'emitted_record_family').split(' := by')[0].replace('MixedCastOrOmittedRecord','MixedBitOrOmittedRecord')
emit+=''' := by
  rcases family with old | ⟨op,ty,x,supported,shape⟩ | ⟨left,ty,x,y,shape⟩
  · exact Or.inl (CastBody.emitted_record_family block statement current recorded emitted source clif one results mapped old)
  · have original : info.clif = some (.unary op ty x) := by rw [clif,shape]
    exact Or.inr (Or.inl ⟨j,b,stm,block,statement,current,step,recorded,emitted,
      info,op,ty,x,z,a,source,original,one,results,mapped,supported⟩)
  · have original : info.clif = some (.binary (ScalarRotate.rotateOp left) ty x y) := by rw [clif,shape]
    exact Or.inr (Or.inr ⟨j,b,stm,block,statement,current,step,recorded,emitted,
      info,left,ty,x,y,z,a,source,original,one,results,mapped⟩)
'''
actual=theorem(s,'actual_cast_families').replace('actual_cast_families','actual_bit_families').replace('MixedCastOrOmittedRecord','MixedBitOrOmittedRecord')
a=actual.index('  · exact Or.inl');z=actual.index('\n  · exact emitted_record_family',a)
actual=actual[:a]+'''  · exact Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inl (Or.inl
      ⟨j,b,stm,block,statement,current,step,recorded,Or.inl omitted⟩)))))))'''+actual[z:]
body=theorem(s,'actual_cast_body_refines').replace('actual_cast_body_refines','actual_bit_body_refines').replace('actual_cast_families','actual_bit_families').replace('stock_lower_mixed_cast_body_fall_refines','stock_lower_mixed_bit_body_fall_refines').replace("have sourceFamily : ∀ b' ∈ f.blocks,∀ stm ∈ b'.body,Family stm.inst", "have sourceFamily : ∀ b' ∈ f.blocks,∀ stm ∈ b'.body,CastBody.SafeFormat stm.inst").replace('exact family stm present','exact family_formats (family stm present)')
(b/'StockBitBodyRefines.lean').write_text(pre+'\n'+emit+'\n'+actual+'\n'+body+'\nend Backend.Stock.Proof.BitBody\n')
s=(b/'StockCastReturnRefines.lean').read_text().replace('StockCast','StockBit').replace('Proof.CastBody','Proof.BitBody').replace('actual_cast','actual_bit');(b/'StockBitReturnRefines.lean').write_text(s)
s=(b/'StockScalarCastDomain.lean').read_text().replace('StockCastReturnRefines','StockBitReturnRefines').replace('StockCastNotrap','StockBitFamily').replace('domain_of_cast','domain_of_bit').replace('CastBody','BitBody').replace('actual_cast','actual_bit').replace('cast_source_notrap','bit_source_notrap');(b/'StockScalarBitDomain.lean').write_text(s)
