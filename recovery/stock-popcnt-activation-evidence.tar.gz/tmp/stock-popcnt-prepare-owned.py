from pathlib import Path
import json,re,subprocess
old=json.loads(Path('/tmp/stock-bit-owned/partitions.json').read_text());out=Path('/tmp/stock-popcnt-owned');out.mkdir(exist_ok=True)
paths=subprocess.check_output(['git','diff','--name-only','5e563a0b'],text=True).splitlines()
new_names=[p[:-5].replace('/','.') for p in paths if p.startswith('FV/') and p.endswith('.lean')]
new_names += ['FV.Backend.Proof.StockPopcount'+n for n in ['Math','Pure','Rhs','Semantics','Selected','RecordValues','SourceValues','ZeroWitness','NonzeroWitness']]
core=old['core']+[n for n in new_names if n not in old['core'] and n!='FV.E2E.StockPopcountWitness'];witness=old['witnesses']+['FV.E2E.StockPopcountWitness']
log=Path('/tmp/stock-popcnt-final-audits-final/stock-popcount-production.log').read_text();new=sorted(set(re.findall(r'E2E\.StockPopcountNIWitness\.(?:checks_true|source_checks_true)\._native\.native_decide\.ax_[\w]+',log)));assert len(new)==2,new
facts=sorted(set(old['exact_native_facts'])|set(new));assert len(facts)==31
owners=old['executable_owners']+['FVTest.Backend.Lowering.StockPopcountProductionRuntime','FVTest.Backend.Lowering.StockPopcountProductionLinked'];assert len(set(core))==len(core)
part={'base':'5e563a0baf63f9d582acb4cd49b43c1648250217','candidate':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'core':core,'witnesses':witness,'exact_native_facts':facts,'executable_owners':owners};(out/'partitions.json').write_text(json.dumps(part,indent=2))
body=Path('/tmp/stock-bit-owned/Owned0.lean').read_text();body=body[body.index('open Lean Elab Command'):];arr=lambda x:'#['+', '.join(json.dumps(s) for s in x)+']'
for name,values in [('core',core),('witnesses',witness),('fixedFacts',facts)]:body=re.sub(r'  let '+name+r' := #\[.*\]',lambda m:'  let '+name+' := '+arr(values),body)
body=body.replace('STOCK_BIT_OWNED','STOCK_POPCOUNT_OWNED');(out/'Owned0.lean').write_text(''.join('import '+n+'\n' for n in core+witness)+body)
for i,owner in enumerate(owners,1):(out/f'Owned{i}.lean').write_text('import Lean\n'+Path('/tmp/stock-not-owned/Owned1.lean').read_text().replace('FVTest.Backend.Main',owner).replace('STOCK_NOT_OWNED','STOCK_POPCOUNT_OWNED'))
m=json.loads(Path('/tmp/stock-popcnt-normal-manifest.json').read_text());m['packet']='popcount-production-owned';m['gates']=[]
for i in range(len(owners)+1):m['gates'].append({'id':'owned-'+str(i),'argv':['lake','env','lean',str(out/f'Owned{i}.lean')],'requires':['STOCK_POPCOUNT_OWNED'],'complete_inputs':False})
Path('/tmp/stock-popcnt-owned-manifest.json').write_text(json.dumps(m,indent=2));print(len(core),len(witness),len(facts),len(owners))
