import FV.Backend.Proof.StockShiftRecordValues
import FV.Backend.Proof.StockRootOpcodeMatch
open Backend.Stock.Proof Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
#eval sourceOpcodeIds 103
#eval sourceOpcodeIds 104
#eval sourceOpcodeIds 105
