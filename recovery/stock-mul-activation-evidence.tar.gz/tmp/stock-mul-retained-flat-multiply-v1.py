from pathlib import Path
import os,json,subprocess,hashlib,re,sys
root=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=False);records={};sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run(name,args,env=None):
 p=out/(name+'.log')
 with p.open('w') as log:r=subprocess.run(['scripts/memcap.sh',*args],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 records[name]={'returncode':r.returncode,'log':str(p),'sha256':sha(p)};assert r.returncode==0,(name,r.returncode,p);assert 'Error: index out of bounds' not in p.read_text();return p
lp=subprocess.check_output(['scripts/memcap.sh','lake','env','printenv','LEAN_PATH'],cwd=root,text=True).strip()
try:
 for mode,flags in [('Plain',['--no-dead-cleanup']),('Cleanup',[])]:
  bundle=Path('/tmp/stock-not-integration-author/not/linked')/('StockNotProduction6Mixed'+mode+'FallbackGlobal-bundle');assert bundle.exists();before={str(p):sha(p) for p in bundle.rglob('*') if p.is_file()}
  texts='\n'.join(p.read_text() for p in bundle.glob('*.clif'));match=re.search(r'function %actual_stock_not_4\b[^\n]*\{(.*?)^\}',texts,re.M|re.S);assert match and 'imul' in match.group(1) and 'jump' not in match.group(1),'original one-block legacy multiply input was changed'
  proof=out/'Crates'/('RetainedFlatMultiply'+mode+'.lean');proof.parent.mkdir(exist_ok=True)
  run('current-check-original-bytes-'+mode,['lake','env',str(root/'.lake/build/bin/link-check'),str(bundle),'--lean',str(proof),'--module',proof.stem,*flags])
  env=dict(os.environ,LEAN_PATH=str(out)+':'+lp)
  run('current-generated-proof-'+mode,['lean','--root='+str(out),'-o',str(proof.with_suffix('.olean')),str(proof)],env)
  after={str(p):sha(p) for p in bundle.rglob('*') if p.is_file()};assert before==after,'retained original artifact mutated'
  records['original-bundle-'+mode]={'files_untouched':before,'single_block_imul_preserved':True,'current_proof_sha256':sha(proof)}
 (out/'receipt.json').write_text(json.dumps({'state':'passed','records':records,'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()},indent=2));print('RETAINED_ORIGINAL_FLAT_MULTIPLY_BYTES_AND_CURRENT_PROOFS_PASS 2')
except BaseException as error:
 (out/'receipt.json').write_text(json.dumps({'state':'failed','error':repr(error),'records':records},indent=2));raise
