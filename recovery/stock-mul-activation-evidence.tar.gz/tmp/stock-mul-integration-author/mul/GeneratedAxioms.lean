import Crates.StockMulProduction2CleanupFallbackGlobal
import Crates.StockMulProduction2PlainFallbackGlobal
import Crates.StockMulProduction2RetainedCleanupFallbackGlobal
import Crates.StockMulProduction2RetainedPlainFallbackGlobal
import Crates.StockMulProduction33CleanupFallbackEntries
import Crates.StockMulProduction33CleanupFallbackGlobal
import Crates.StockMulProduction6CleanupFallbackGlobal
import Crates.StockMulProduction6CleanupStrictGlobal
import Crates.StockMulProduction6MixedCleanupFallbackGlobal
import Crates.StockMulProduction6MixedPlainFallbackGlobal
import Crates.StockMulProduction6PlainFallbackGlobal
import Crates.StockMulProduction6PlainStrictGlobal
import Crates.MulProductionCLIcurrentPlain
import Crates.MulProductionCLIretainedPlain
import Crates.MulProductionCLIcurrentCleanup
import Crates.MulProductionCLIretainedCleanup
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let generated := fun (name : Name) =>
    name.toString.startsWith "Crates.StockMulProduction" || name.toString.startsWith "Crates.MulProductionCLI"
  let mut count : Nat := 0
  for (name, _) in env.constants.toList do
    unless generated name do continue
    for ax in ← collectAxioms name do
      if #[``propext, ``Classical.choice, ``Quot.sound].contains ax then continue
      unless generated ax && (ax.toString.splitOn "._native.native_decide.ax_").length > 1 do
        throwError "unexpected generated-proof axiom {ax} in {name}"
    count := count + 1
  unless count > 0 do throwError "empty generated-proof audit"
  logInfo m!"STOCK_MULPRODUCTION_GENERATED_AXIOMS_PASS {count}"
