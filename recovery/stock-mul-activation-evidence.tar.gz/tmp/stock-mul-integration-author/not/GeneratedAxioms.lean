import Crates.StockNotProduction2CleanupFallbackGlobal
import Crates.StockNotProduction2PlainFallbackGlobal
import Crates.StockNotProduction2RetainedCleanupFallbackGlobal
import Crates.StockNotProduction2RetainedPlainFallbackGlobal
import Crates.StockNotProduction33CleanupFallbackEntries
import Crates.StockNotProduction33CleanupFallbackGlobal
import Crates.StockNotProduction6CleanupFallbackGlobal
import Crates.StockNotProduction6CleanupStrictGlobal
import Crates.StockNotProduction6MixedCleanupFallbackGlobal
import Crates.StockNotProduction6MixedPlainFallbackGlobal
import Crates.StockNotProduction6PlainFallbackGlobal
import Crates.StockNotProduction6PlainStrictGlobal
import Crates.NotProductionCLIcurrentPlain
import Crates.NotProductionCLIretainedPlain
import Crates.NotProductionCLIcurrentCleanup
import Crates.NotProductionCLIretainedCleanup
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let generated := fun (name : Name) =>
    name.toString.startsWith "Crates.StockNotProduction" || name.toString.startsWith "Crates.NotProductionCLI"
  let mut count : Nat := 0
  for (name, _) in env.constants.toList do
    unless generated name do continue
    for ax in ← collectAxioms name do
      if #[``propext, ``Classical.choice, ``Quot.sound].contains ax then continue
      unless generated ax && (ax.toString.splitOn "._native.native_decide.ax_").length > 1 do
        throwError "unexpected generated-proof axiom {ax} in {name}"
    count := count + 1
  unless count > 0 do throwError "empty generated-proof audit"
  logInfo m!"STOCK_NOTPRODUCTION_GENERATED_AXIOMS_PASS {count}"
