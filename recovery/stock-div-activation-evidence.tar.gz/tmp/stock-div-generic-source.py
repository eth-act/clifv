from pathlib import Path
src=Path('FV/Backend/Proof/StockDivSignedSourceValues.lean').read_text()
header=src[src.index('theorem stock_lower_sdiv_source_by_instruction'):src.index(' := by',src.index('theorem stock_lower_sdiv_source_by_instruction'))]
header=header.replace('stock_lower_sdiv_source_by_instruction','stock_lower_div_source_by_instruction').replace('{ty : Clif.Ty} {info', '{op : Clif.DivOp} {ty : Clif.Ty} {info').replace('.div .sdiv','.div op').replace('Clif.Sem.div .sdiv','Clif.Sem.div op')
imports=['StockDivSignedSourceTrap','StockDivUdivWideSourceValues','StockDivUdivNarrowSourceValues','StockDivRemWideSourceValues','StockDivRemNarrowSourceValues']
s='\n'.join('import FV.Backend.Proof.'+x for x in imports)+'\nnamespace Backend.Stock.Proof.ScalarDiv\nopen Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64\nset_option autoImplicit false\nset_option Elab.async false\n\n'+header+' := by\n'
s+='''  have inv := (stock_lower_record_context run scope events).1
  have supported : eTy ty = true := by
    cases op <;> simpa [Compile.instE,Compile.tyE,eTy] using inv.instE _ info _ source clif
  have width : ty = .i64 ∨ ty.width ≤ 32 := by
    cases ty <;> simp_all [eTy,Clif.Ty.width]
  cases op with
'''
for op,signed in [('sdiv',None),('udiv',None),('srem','true'),('urem','false')]:
 s+='  | '+op+' =>\n'
 base='run scope dominated '+(('('+signed+') ') if signed else '')+'events records block statement current '
 # actual header uses foundBlock/foundStmt
 base=base.replace('block statement','foundBlock foundStmt')
 tail='source clif results statementResults mapped recorded emitted refines dfg held sourceStep'
 if op=='sdiv':s+='    exact stock_lower_sdiv_source_by_instruction '+base+tail+'\n'
 else:
  s+='    rcases width with rfl | narrow\n'
  stem='udiv' if op=='udiv' else 'rem'
  s+='    · exact stock_lower_'+stem+'_wide_source_by_instruction '+base+tail+'\n'
  s+='    · exact stock_lower_'+stem+'_narrow_source_by_instruction '+base+'narrow '+tail+'\n'
s+='\nend Backend.Stock.Proof.ScalarDiv\n'
Path('FV/Backend/Proof/StockDivSourceValues.lean').write_text(s)
