from pathlib import Path
import os,json,subprocess,re
root=Path.cwd();env=os.environ.copy();env.update(json.load(open('/tmp/stock-div-final-normal-manifest.json'))['env']);out=Path('/tmp/stock-div-cli-preflight');out.mkdir(exist_ok=False)
cmd=['scripts/memcap.sh','.lake/build/bin/stock-div-linked',str(out)]
with (out/'fixture.log').open('w') as stream:p=subprocess.run(cmd,env=env,stdout=stream,stderr=subprocess.STDOUT)
assert p.returncode==0,('fixture',p.returncode)
for mode,flags in [('Plain',['--no-dead-cleanup']),('Cleanup',[])]:
 for label,retained in [('current',''),('retained','Retained')]:
  name='StockDivProduction2'+retained+mode+'FallbackGlobal';proof=out/(label+mode+'.lean');log=out/(label+mode+'.log')
  cmd=['scripts/memcap.sh','lake','env',str(root/'.lake/build/bin/link-check'),str(out/(name+'-bundle')),'--lean',str(proof),'--module',proof.stem,*flags]
  with log.open('w') as stream:p=subprocess.run(cmd,env=env,stdout=stream,stderr=subprocess.STDOUT)
  assert p.returncode==0,(label,mode,log.read_text()[-1800:])
  if label=='retained' and mode=='Plain':
   selected=re.search(r'Backend\.Stock\.Scalar\.lowerWithRoutes \[(.*?)\]',proof.read_text(),re.S)
   assert selected and re.search(r',\s*[1-4]\)',selected.group(1)),selected
  print(label,mode,'actual CLI check passed',flush=True)
