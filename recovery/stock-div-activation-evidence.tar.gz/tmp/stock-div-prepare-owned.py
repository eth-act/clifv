from pathlib import Path
import json,re,subprocess
old=json.loads(Path('/tmp/stock-highmul-owned/partitions.json').read_text());out=Path('/tmp/stock-div-owned');out.mkdir(exist_ok=True)
paths=subprocess.check_output(['git','diff','--name-only','d522474c'],text=True).splitlines();new=[p[:-5].replace('/','.') for p in paths if p.startswith('FV/') and p.endswith('.lean')]
core=list(dict.fromkeys(old['core']+[n for n in new if n!='FV.E2E.StockDivWitness']));witness=old['witnesses']+['FV.E2E.StockDivWitness'];owners=old['executable_owners']+['FVTest.Backend.Lowering.StockDivProductionRuntime','FVTest.Backend.Lowering.StockDivProductionLinked']
log=Path('/tmp/stock-div-new-audit.log').read_text();newfacts=set(re.findall(r'E2E\.StockDivNIWitness\.checks_true\._native\.native_decide\.ax_[\w]+',log));assert len(newfacts)==1;facts=sorted(set(old['exact_native_facts'])|newfacts)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();part={'base':'d522474ca5887bf5698ec1f725be2f029fc1bc6a','candidate':head,'core':core,'witnesses':witness,'exact_native_facts':facts,'executable_owners':owners};(out/'partitions.json').write_text(json.dumps(part,indent=2)+'\n')
s=Path('/tmp/stock-highmul-owned/Owned0.lean').read_text();s=s[s.index('open Lean Elab Command'):];arr=lambda xs:'#['+', '.join(json.dumps(x) for x in xs)+']'
for name,values in [('core',core),('witnesses',witness),('fixedFacts',facts)]:s=re.sub(r'  let '+name+r' := #\[.*\]',lambda _: '  let '+name+' := '+arr(values),s)
s=s.replace('STOCK_HIGHMUL_OWNED','STOCK_DIV_OWNED');(out/'Owned0.lean').write_text(''.join('import '+n+'\n' for n in core+witness)+s)
for i,owner in enumerate(owners,1):(out/f'Owned{i}.lean').write_text('import Lean\n'+Path('/tmp/stock-not-owned/Owned1.lean').read_text().replace('FVTest.Backend.Main',owner).replace('STOCK_NOT_OWNED','STOCK_DIV_OWNED'))
m=json.loads(Path('/tmp/stock-div-normal-manifest.json').read_text());m['packet']='div-production-owned';m['gates']=[{'id':'owned-'+str(i),'argv':['lake','env','lean',str(out/f'Owned{i}.lean')],'requires':['STOCK_DIV_OWNED'],'complete_inputs':False} for i in range(len(owners)+1)];Path('/tmp/stock-div-owned-manifest.json').write_text(json.dumps(m,indent=2)+'\n');print('Owners:',len(core),'core;',len(witness),'witness;',len(owners),'executables;',len(facts),'exact facts')
