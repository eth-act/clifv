from pathlib import Path
import json,hashlib,re,subprocess,datetime
root=Path.cwd();head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
cert=read('/tmp/stock-div-source-reconciliation.json');assert cert['applicable_current_head']==head
old=cert['old_actual_source_head'];prior=cert['prior_complete_consumer_head'];assert all(sha(p)==h for p,h in cert['unchanged_tool_hashes'].items())
assert subprocess.check_output(['git','diff','--name-only',old,head],text=True).splitlines()==cert['changed_paths']
def applicable(h):assert h in [old,prior,head],h
records=[]
for group,prefix,manifestPrefix in [('main2-normal','reconciled',''),('native','reconciled',''),('full','reconciled',''),('retention','terminal','final-'),('integration','terminal','final-'),('highmul-integration','terminal','final-')]:
 m=read('/tmp/stock-div-'+manifestPrefix+group+'-manifest.json');applicable(m['candidate'])
 for g in m['gates']:
  r=read('/tmp/stock-div-'+prefix+'-'+group+'-author/'+g['id']+'.json');assert r['state']=='passed' and r['returncode']==0,g['id'];applicable(r['source_head']);assert sha(r['log'])==r['log_sha256']
  for p,h in r['outputs'].items():assert sha(p)==h,p
  if group=='main2-normal':assert r['source_head']==head
  elif group not in ['native','full']:assert r['source_head']==prior
  records.append(r)
m=read('/tmp/stock-div-owned-manifest.json')
for g in m['gates']:
 prefix='terminal' if g['id']=='owned-26' else 'reconciled';r=read('/tmp/stock-div-'+prefix+'-owned-author/'+g['id']+'.json');assert r['state']=='passed' and r['returncode']==0;applicable(r['source_head']);assert sha(r['log'])==r['log_sha256'];records.append(r)
assert len(records)==49,len(records)
integrations={}
for kind in ['div','highmul']:
 group='integration' if kind=='div' else 'highmul-integration';p=Path('/tmp/stock-div-terminal-'+group+'-author')/kind;r=read(p/'receipt.json')
 assert r['state']=='passed' and r['head']==prior and len(r['records'])==32
 assert r['fixture_execution']=='native' and len(r['fixture_binary_sha256'])==2
 assert all(sha(x)==h for x,h in r['fixture_binary_sha256'].items())
 assert all(x['returncode']==0 and sha(x['log'])==x['sha256'] for x in r['records'].values())
 for field,folder in [('generated_sources',p/'linked'),('linked_artifacts',p/'linked'),('cli_sources',p)]:
  for n,h in r[field].items():assert sha(folder/n)==h
 integrations[kind]=r
retained=read('/tmp/stock-div-terminal-retention-author/retained/receipt.json');assert retained['state']=='passed';assert all(x.get('files_untouched',True) for x in retained['records'].values())
parity=read('/tmp/stock-div-identity-stage-parity.json');assert all(x['current']==1159 and x['all_original_and_prior_identities_and_ordered_stages_preserved'] and x['paths']['prior']!=x['paths']['current'] for x in parity.values())
ax=read('/tmp/stock-div-axiom-parity.json');assert ax['exact_old_required_axiom_sets_preserved'] and ax['baseline_roots']==1732
headers=read('/tmp/stock-div-header-parity.json');assert headers['unchanged'] and headers['old_public_headers']==29
reviewProvenance=read('/tmp/stock-div-mcp-review-provenance.json');assert reviewProvenance['applicable_source_head']==head;assert all(sha(p)==h for p,h in reviewProvenance['source_sha256'].items());review=read('/tmp/stock-div-mcp-review.json');assert sha('/tmp/stock-div-mcp-review.json')==reviewProvenance['review_sha256'];assert not review['isError'] and not review['structuredContent']['warnings'];assert set(review['structuredContent']['axioms'])=={'propext','Classical.choice','Quot.sound'}
owned=[r for r in records if r['id'].startswith('owned-')];primary=[r for r in records if not r['id'].startswith('owned-')];assert len(primary)==22 and len(owned)==27
owners=read('/tmp/stock-div-owned/partitions.json');assert len(owners['exact_native_facts'])==38
ownedlog=Path(next(r for r in owned if r['id']=='owned-0')['log']).read_text();core,witness=map(int,re.search(r'STANDARD_CORE (\d+); FIXED_WITNESSES (\d+)',ownedlog).groups())
normal=Path(next(r for r in primary if r['id']=='all-normal-library-keys')['log']).read_text();normalkeys=int(re.search(r'All targets up-to-date \((\d+) jobs\)',normal)[1]);assert normalkeys==2860
nativeRoot=Path('/tmp/stock-div-reconciled-native-author/native');native=read(nativeRoot/'native-receipt.json');assert native['state']=='passed' and native['failures']==native['disagreements']==0;assert sha(root/'rust/target/release/clif-native')==native['native_binary_sha256'];assert native['lean_byte_executions']==4080 and native['cranelift_reference_executions']==1020
traps={'lean':0,'cranelift':0}
for r in native['records']:
 stem=r['allocator']+'-Backend.Stock.D0.Configuration.'+r['configuration']+'-'+r['cleanup']
 for engine in traps:
  if engine=='cranelift' and r['cranelift_reference_reused']:continue
  rows=[json.loads(l) for l in (nativeRoot/(stem+'-'+engine+'.jsonl')).read_text().splitlines() if l.strip()]
  traps[engine]+=sum('trapped' in row['actual'] for row in rows)
assert traps=={'lean':312,'cranelift':78},traps
def gate_text(gate):return Path(next(r for r in primary if r['id']==gate)['log']).read_text()
assert re.search(r'lean pass 4737 fail 0 error 0 .*not-runnable 7',gate_text('runtime-corpus'));assert 'functions 1321: identical 1321, differ 0' in gate_text('encoder')
for label,tests in [('verified-fv-demo',21),('verified-survey',53)]:assert 'SAME: '+str(tests)+' test outcomes identical' in gate_text(label)
receipt={'state':'per_pr_gates_passed','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'validated_source_head':head,'base_main':'b9415cfb60d8579b5e768e3bbf62d42ce1871df3','source_reconciliation':cert,'reused_records_keep_actual_source_heads':True,'primary_gate_count':22,'primary_gate_records':primary,'owned_gate_records':owned,'owned_core_constants':core,'owned_fixed_witness_constants':witness,'exact_declared_native_facts':38,'core_owners':len(owners['core']),'witness_owners':len(owners['witnesses']),'executable_owners':len(owners['executable_owners']),'normal_scheduled_modules':2857,'normal_library_jobs':normalkeys,'checked_in_audits':58,'audited_roots':ax['current_roots'],'parity':{'axiom_sets':ax,'old_headers':headers},'identity_stage_parity':parity,'mcp_review':review,'mcp_review_provenance':reviewProvenance,'native_execution':native,'actual_coded_trap_executions':traps,'prior_expected_native_grids':read('/tmp/stock-div-native-grid-retention.json'),'integrations':integrations,'generated_trust_controls':read('/tmp/stock-div-generated-audit-controls/receipt.json'),'retained_original_flat_multiply':retained,'runtime_corpus':{'passed':4737,'failed':0,'errors':0,'known_non_runnable':7},'encoder':{'identical':1321,'different':0},'verified_examples':{'fv-demo':{'tests':21,'verified_binaries':2},'survey':{'tests':53,'verified_binaries':18}},'actual_selected_roots_observation':read('/tmp/stock-div-selected-roots.json'),'new_proved_source_operations':['sdiv','udiv','srem','urem'],'first_production_source_class':'single returned division/remainder with arbitrary original SSA operand values; original stack slots/args/ABI settings','production_widths':[32,64],'source_transfer_widths':[8,16,32,64],'all_six_ABIs_both_cleanup_and_both_real_allocators':True,'pipeline_witness_configurations':48,'original_zero_overflow_and_minimum_remainder_outcomes_retained':True,'no_purity_or_nonzero_or_no_overflow_assumptions_added':True,'full_original_140_complete':False,'next':'Mixed/colored/sunk trap-prefix source simulation; original widths/ABIs/control/memory/effects/calls/block/whole-driver simulation and universal Stock-only lowering/downstream completeness. Continue after first class.'}
Path('/tmp/stock-div-terminal-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print('passed22primary/27ownership;',normalkeys,'keys;',core,'Std3/',witness,'fixed witnesses;coded traps',traps)
