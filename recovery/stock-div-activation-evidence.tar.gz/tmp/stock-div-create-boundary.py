from pathlib import Path
old=Path('FV/E2E/ABIReadScalar.lean').read_text();a=old.index('theorem refines');b=old.index('private theorem constant_cases')
common=old[a:b].replace('MixedFlagBoundary.','ScalarBoundary.')
start='''import FV.Backend.ABIReadDiv
import FV.E2E.ABIReadDivSteps
import FV.E2E.ABIReadScalar
namespace E2E.DivBoundary
open Backend Backend.Proof Backend.Proof.Driver Backend.DeadCleanup E2E.MixedFlagBoundary
set_option autoImplicit false
set_option Elab.async false

private def special : MInst → Bool
  | .aluRRR op .. => op == .sDiv || op == .uDiv
  | .aluRRImm12 op .. => op == .addS
  | .ccmpImm .. | .trapIf .. => true
  | _ => false

noncomputable def sem (F : BitVec 64 → Prop) (ctx : FnCtx) (X : ExtSem) : Sem :=
  fun i us w => if special i then mspec ctx.slotBase i us w else ScalarBoundary.sem F ctx X i us w

'''
helpers='''private theorem old_not_special {sig : Clif.Signature} {b k : Nat} {i : MInst}
    (checked : Backend.ABIReadScalar.instruction sig b k i = true) : special i = false := by
  cases i with
  | aluRRR op sz rd rn rm => cases op <;> first | rfl | cases checked
  | aluRRImm12 op sz rd rn imm => cases op <;> first | rfl | cases checked
  | ccmpImm sz rn imm nzcv c => cases checked
  | trapIf kind code => cases checked
  | _ => rfl

private theorem additional_special {i : MInst} (checked : Backend.ABIReadDiv.additional i = true) :
    special i = true := by
  cases i with
  | aluRRR op sz rd rn rm => cases op <;> first | rfl | cases checked
  | aluRRImm12 op sz rd rn imm => cases op <;> first | rfl | cases checked
  | ccmpImm sz rn imm nzcv c => rfl
  | trapIf kind code => rfl
  | _ => cases checked

'''
# Preserve the full original ABI argument/read conditions, replacing only model/dispatch bodies.
a=old.index('theorem checked_step_frame');b=old.index('theorem checked_step_transport',a);frame=old[a:b];h=frame.index(' := by');frame=frame[:h].replace('Backend.ABIReadScalar.instruction','Backend.ABIReadDiv.instruction').replace('(ctl = .next ∨ ctl = .ret)','(ctl = .next ∨ ctl = .ret ∨ ctl = .halt)')+''' := by
  simp only [Backend.ABIReadDiv.instruction,Bool.or_eq_true] at checked
  rcases checked with old | added
  · simp only [sem,old_not_special old,Bool.false_eq_true,↓reduceIte] at run
    obtain ⟨frame,control⟩ := ScalarBoundary.checked_step_frame old run
    refine ⟨frame,?_⟩
    rcases control with next | ret
    · exact Or.inl next
    · exact Or.inr (Or.inl ret)
  · simp only [sem,additional_special added,↓reduceIte] at run
    exact DivRead.step_frame added run

'''
a=b;b=old.index('namespace Realize',a);transport=old[a:b];h=transport.index(' := by');transport=transport[:h].replace('Backend.ABIReadScalar.instruction','Backend.ABIReadDiv.instruction')+''' := by
  simp only [Backend.ABIReadDiv.instruction,Bool.or_eq_true] at checked
  rcases checked with old | added
  · simp only [sem,old_not_special old,Bool.false_eq_true,↓reduceIte] at run ⊢
    exact ScalarBoundary.checked_step_transport types old current other worlds registers stack run
  · simp only [sem,additional_special added,↓reduceIte] at run ⊢
    exact mspec_lockstep (DivRead.no_mem added) worlds run

'''
a=old.index('theorem step_realize',b);b=old.index('end Realize',a);realize=old[a:b];h=realize.index(' := by');realize=realize[:h].replace('Backend.ABIReadScalar.instruction','Backend.ABIReadDiv.instruction')+''' := by
  simp only [Backend.ABIReadDiv.instruction,Bool.or_eq_true] at checked
  rcases checked with old | added
  · simp only [sem,old_not_special old,Bool.false_eq_true,↓reduceIte] at executed ⊢
    exact ScalarBoundary.Realize.step_realize types old frame arguments worlds entry executed
  · simp only [sem,additional_special added,↓reduceIte] at executed
    obtain ⟨spec,run,related⟩ := mspec_lockstep (DivRead.no_mem added) worlds.symm executed
    rw [DivRead.spec_eq added] at run
    obtain ⟨actual,realized,related'⟩ := refines_valueSem F ctx X _ us t outs spec run
    exact ⟨actual,realized,related'.trans related.symm⟩

'''
a=old.index('private noncomputable def boundaryModel');tail=old[a:].replace('ABIReadBoundary.Model','ABIReadTrapBoundary.Model').replace('ABIReadBoundary.','ABIReadTrapBoundary.').replace('Backend.ABIReadScalar.','Backend.ABIReadDiv.').replace('end E2E.ScalarBoundary','end E2E.DivBoundary')
Path('FV/E2E/ABIReadDiv.lean').write_text(start+common+helpers+frame+transport+'namespace Realize\n'+realize+'end Realize\n\n'+tail)
