from pathlib import Path
p=Path('FVTest/Backend/Lowering/StockDivProductionLinked.lean');s=p.read_text();old='sourceText s!"u0:{i}" (configFor i) retainedMixed)';new='sourceText s!"u0:{i}" (configFor i) retainedMixed i)';assert s.count(old)==1;s=s.replace(old,new);p.write_text(s)
