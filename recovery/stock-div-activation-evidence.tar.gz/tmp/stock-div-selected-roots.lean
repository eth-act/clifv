import FV.E2E.StockDivFixtures
import FV.Backend.Proof.StockDivDispatch
open Backend Backend.Stock.D0
#eval do
  for config in configurations do
    for op in E2E.StockDivNIWitness.operations do
      match Stock.lower (E2E.StockDivNIWitness.function config op) with
      | .error e => throw (IO.userError e)
      | .ok result =>
        let roots := result.blockScans.toList.flatMap fun (event : Stock.BlockScanEvent) =>
          event.output.records.filterMap fun (record : Stock.ScanRecord) => record.output.step.bind fun step =>
            if record.inst == 0 then step.rules.getLast? else none
        IO.println s!"{repr config} {repr op}: {roots}"
