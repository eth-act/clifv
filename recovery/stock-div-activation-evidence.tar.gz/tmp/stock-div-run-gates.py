from pathlib import Path
import subprocess,sys,json
kind=sys.argv[1];prefix=sys.argv[2] if len(sys.argv)>2 else 'reconciled';outtag=sys.argv[3] if len(sys.argv)>3 else prefix
manifest='/tmp/stock-div-'+('final-' if prefix=='final' else '')+kind+'-manifest.json';out='/tmp/stock-div-'+outtag+'-'+kind+'-author';log='/tmp/stock-div-'+outtag+'-'+kind+'-runner.log'
with open(log,'w') as stream:
 p=subprocess.run(['python3','scripts/stock-delivery-gates.py','run',manifest,'--root',str(Path.cwd()),'--out',out],stdout=stream,stderr=subprocess.STDOUT)
print(kind,p.returncode)
if p.returncode:print(Path(log).read_text()[-1800:])
else:
 m=json.loads(Path(manifest).read_text());print(len(m['gates']),'gates passed on',m['candidate'])
raise SystemExit(p.returncode)
