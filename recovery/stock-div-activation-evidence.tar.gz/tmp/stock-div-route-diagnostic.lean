import FV.E2E.StockDivWitness
import FV.Backend.Lowering.StockScalarNI
open Backend Backend.Proof.Driver
#eval do
  for c in Stock.D0.configurations do
    let f := E2E.StockDivNIWitness.function c .sdiv
    IO.println s!"{repr c}: eligible={Stock.Scalar.eligible f} logical={Stock.Logical.eligible f} active={Stock.Scalar.activationEligible f} source={Stock.Scalar.sourceOk f}"
    match Stock.Scalar.lowerValidated f with
    | .error e => IO.println e
    | .ok vc => IO.println s!"scalar={Stock.Scalar.check f vc} legacy={lowerCheck f vc} paired={SemanticNI.check f vc} divReads={ABIReadDiv.check f.sig vc}"
