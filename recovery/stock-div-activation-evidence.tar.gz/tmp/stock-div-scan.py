from pathlib import Path
src=Path('FV/Backend/Proof/StockHighMulScanRefines.lean').read_text()
a=src.index('theorem stock_lower_highmul_scan_fall_refines');b=src.index('\n\ndef MixedHighMul',a)
s=src[a:b]
s=s.replace('stock_lower_highmul_scan_fall_refines','stock_lower_div_scan_fall_refines').replace('(signed : Bool)','(op : Clif.DivOp)').replace('.binary (if signed then .smulhi else .umulhi)','.div op')
a=s.index('  obtain ⟨u,v,d,ρ\'');b=s.index('  have postDFG',a)
s=s[:a]+'''  obtain ⟨u,v,d,q,output,bounds,division,unchanged,execution⟩ := ScalarDiv.stock_lower_div_source_by_instruction
    run scope dominated events records block statement current source clif results statementResults
    mapped recorded emitted refines dfg values sourceStep
  obtain ⟨ρ',w',executed,world,value,kept,post⟩ := execution w
'''+s[b:]
s=s.replace('(SameWorld.nf world)','world.symm')
s='''import FV.Backend.Proof.StockDivSourceValues
import FV.Backend.Proof.StockSourceDFG
namespace Backend.Stock.Proof
open Backend.Proof Backend.Proof.Driver Isle Isle.Interp Isle.Aarch64
set_option autoImplicit false
set_option Elab.async false
set_option maxRecDepth 8192
attribute [local irreducible] Isle.Aarch64.program Stock.runTerm

'''+s+'\nend Backend.Stock.Proof\n'
# Existing scalar/source relation is declared in Arithmetic body, not SourceDFG.
s=s.replace('import FV.Backend.Proof.StockSourceDFG','import FV.Backend.Proof.StockArithmeticBodyRefines')
Path('FV/Backend/Proof/StockDivScanRefines.lean').write_text(s)
