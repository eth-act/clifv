from pathlib import Path
import json,os,subprocess,hashlib
root=Path.cwd();out=Path('/tmp/stock-div-generated-audit-controls');out.mkdir(exist_ok=False)
audit=(Path('/tmp/stock-div-terminal-integration-author/div/GeneratedAxioms.lean')).read_text();body=audit[audit.index('open Lean Elab Command'):]
positive='''namespace Crates.StockDivProductionControls
theorem publicWitness : True := by native_decide
private theorem privateWitness : 1 = 1 := by native_decide
end Crates.StockDivProductionControls
'''
cases={'positive':positive}
for privacy,label in [('', 'public'),('private ', 'private')]:
 cases[label+'-foreign-native']='''namespace Foreign
theorem fact : True := by native_decide
end Foreign
namespace Crates.StockDivProductionControls
'''+privacy+'''theorem leak : True := Foreign.fact
end Crates.StockDivProductionControls
'''
 cases[label+'-own-nonnative']='namespace Crates.StockDivProductionControls\n'+privacy+'axiom assumption : True\n'+privacy+'theorem leak : True := assumption\nend Crates.StockDivProductionControls\n'
env=os.environ.copy();env.update(json.load(open('/tmp/stock-div-final-normal-manifest.json'))['env']);records={}
for name,source in cases.items():
 file=out/(name+'.lean');file.write_text('import Lean\n'+source+body);log=out/(name+'.log')
 with log.open('w') as stream:p=subprocess.run(['scripts/memcap.sh','lake','env','lean',str(file)],env=env,stdout=stream,stderr=subprocess.STDOUT)
 text=log.read_text()
 if name=='positive':assert p.returncode==0 and 'GENERATED_AXIOMS_PASS' in text,(name,text[-2000:])
 else:assert p.returncode!=0 and 'unexpected generated-proof axiom' in text,(name,text[-2000:])
 records[name]={'expected_rejection':name!='positive','returncode':p.returncode,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(file.read_bytes()).hexdigest()};print(name,'pass',flush=True)
(out/'receipt.json').write_text(json.dumps({'state':'passed','actual_audit_body_sha256':hashlib.sha256(body.encode()).hexdigest(),'source_audit_file':'/tmp/stock-div-terminal-integration-author/div/GeneratedAxioms.lean','records':records},indent=2)+'\n')
