from pathlib import Path
src=Path('FV/Backend/Proof/StockPureSourceExecution.lean').read_text()
s=src.replace('import FV.Backend.Proof.StockArithmeticBodyRefines','import FV.Backend.Proof.StockPureSourceExecution').replace('namespace Backend.Stock.Proof.PureBody','namespace Backend.Stock.Proof.LocalBody').replace('end Backend.Stock.Proof.PureBody','end Backend.Stock.Proof.LocalBody')
s=s.replace('/-! Executable original-source runs supply complete pure body steps. -/','/-! Executable source runs for ordinary scalar instructions, including real division.\nThis predicate governs step shape only; it makes no no-trap claim. -/')
s=s.replace('private theorem step_of_family', '''/-- A local scalar step evaluates without calls or control transfer. Division
can still trap, and its original input conditions are retained. -/
def LocalInst : Clif.Inst → Prop
  | .div .. => True
  | inst => pureInst inst = true

private theorem step_of_family''')
s=s.replace('pureInst stm.inst = true','LocalInst stm.inst').replace('pureInst inst = true','LocalInst inst')
# Restore the definition's old-family branch after replacing signatures.
s=s.replace('| inst => LocalInst inst','| inst => pureInst inst = true')
s=s.replace('[shape,pureInst]','[shape,LocalInst,pureInst]').replace('[pureInst]','[LocalInst,pureInst]')
s=s.replace('actual_pure','actual_local').replace('pure_next','local_next')
s=s.replace('/-- Frame components untouched by the pure source body. -/\ndef SourceFrameEq (s t : Clif.State) : Prop :=\n  t.callers = s.callers ∧ t.frame.func = s.frame.func ∧\n    t.frame.slots = s.frame.slots ∧ t.frame.term = s.frame.term','abbrev SourceFrameEq := PureBody.SourceFrameEq')
s=s.replace('pure-family','local-family').replace('ordinary pure source','ordinary local source')
Path('FV/Backend/Proof/StockLocalSourceExecution.lean').write_text(s)
