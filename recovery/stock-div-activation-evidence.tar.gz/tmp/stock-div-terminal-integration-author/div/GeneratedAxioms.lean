import Crates.StockDivProduction2CleanupFallbackGlobal
import Crates.StockDivProduction2PlainFallbackGlobal
import Crates.StockDivProduction2RetainedCleanupFallbackGlobal
import Crates.StockDivProduction2RetainedPlainFallbackGlobal
import Crates.StockDivProduction33CleanupFallbackEntries
import Crates.StockDivProduction33CleanupFallbackGlobal
import Crates.StockDivProduction6CleanupFallbackGlobal
import Crates.StockDivProduction6CleanupStrictGlobal
import Crates.StockDivProduction6MixedCleanupFallbackGlobal
import Crates.StockDivProduction6MixedPlainFallbackGlobal
import Crates.StockDivProduction6PlainFallbackGlobal
import Crates.StockDivProduction6PlainStrictGlobal
import Crates.DivProductionCLIcurrentPlain
import Crates.DivProductionCLIretainedPlain
import Crates.DivProductionCLIcurrentCleanup
import Crates.DivProductionCLIretainedCleanup
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let generated := fun (name : Name) =>
    let owner := (privateToUserName? name).getD name
    owner.toString.startsWith "Crates.StockDivProduction" || owner.toString.startsWith "Crates.DivProductionCLI"
  let mut count : Nat := 0
  for (name, _) in env.constants.toList do
    unless generated name do continue
    for ax in ← collectAxioms name do
      if #[``propext, ``Classical.choice, ``Quot.sound].contains ax then continue
      unless generated ax && (ax.toString.splitOn "._native.native_decide.ax_").length > 1 do
        throwError "unexpected generated-proof axiom {ax} in {name}"
    count := count + 1
  unless count > 0 do throwError "empty generated-proof audit"
  logInfo m!"STOCK_DIVPRODUCTION_GENERATED_AXIOMS_PASS {count}"
