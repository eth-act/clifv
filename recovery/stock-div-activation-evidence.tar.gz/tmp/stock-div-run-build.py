import json,os,subprocess,sys
from pathlib import Path
env=os.environ.copy();env.update(json.load(open('/tmp/stock-highmul-reconciled-normal-manifest.json'))['env'])
env['FV_MEMCAP']='8G'
with open(sys.argv[2],'w') as out:
 p=subprocess.run(['scripts/memcap.sh','lake','build',sys.argv[1]],env=env,stdout=out,stderr=subprocess.STDOUT)
print(p.returncode)
print('\n'.join(x for x in Path(sys.argv[2]).read_text().splitlines() if x.startswith('error:') or x.startswith('✖') or x.startswith('Build completed')))
sys.exit(p.returncode)
