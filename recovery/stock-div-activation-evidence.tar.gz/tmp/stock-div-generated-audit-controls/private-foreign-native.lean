import Lean
namespace Foreign
theorem fact : True := by native_decide
end Foreign
namespace Crates.StockDivProductionControls
private theorem leak : True := Foreign.fact
end Crates.StockDivProductionControls
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let generated := fun (name : Name) =>
    let owner := (privateToUserName? name).getD name
    owner.toString.startsWith "Crates.StockDivProduction" || owner.toString.startsWith "Crates.DivProductionCLI"
  let mut count : Nat := 0
  for (name, _) in env.constants.toList do
    unless generated name do continue
    for ax in ← collectAxioms name do
      if #[``propext, ``Classical.choice, ``Quot.sound].contains ax then continue
      unless generated ax && (ax.toString.splitOn "._native.native_decide.ax_").length > 1 do
        throwError "unexpected generated-proof axiom {ax} in {name}"
    count := count + 1
  unless count > 0 do throwError "empty generated-proof audit"
  logInfo m!"STOCK_DIVPRODUCTION_GENERATED_AXIOMS_PASS {count}"
