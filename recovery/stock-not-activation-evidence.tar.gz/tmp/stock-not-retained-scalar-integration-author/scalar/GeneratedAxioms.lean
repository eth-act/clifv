import Crates.StockScalarProduction2CleanupFallbackGlobal
import Crates.StockScalarProduction2PlainFallbackGlobal
import Crates.StockScalarProduction2RetainedCleanupFallbackGlobal
import Crates.StockScalarProduction2RetainedPlainFallbackGlobal
import Crates.StockScalarProduction33CleanupFallbackEntries
import Crates.StockScalarProduction33CleanupFallbackGlobal
import Crates.StockScalarProduction6CleanupFallbackGlobal
import Crates.StockScalarProduction6CleanupStrictGlobal
import Crates.StockScalarProduction6MixedCleanupFallbackGlobal
import Crates.StockScalarProduction6MixedPlainFallbackGlobal
import Crates.StockScalarProduction6PlainFallbackGlobal
import Crates.StockScalarProduction6PlainStrictGlobal
import Crates.ScalarProductionCLIcurrentPlain
import Crates.ScalarProductionCLIretainedPlain
import Crates.ScalarProductionCLIcurrentCleanup
import Crates.ScalarProductionCLIretainedCleanup
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let generated := fun (name : Name) =>
    name.toString.startsWith "Crates.StockScalarProduction" || name.toString.startsWith "Crates.ScalarProductionCLI"
  let mut count : Nat := 0
  for (name, _) in env.constants.toList do
    unless generated name do continue
    for ax in ← collectAxioms name do
      if #[``propext, ``Classical.choice, ``Quot.sound].contains ax then continue
      unless generated ax && (ax.toString.splitOn "._native.native_decide.ax_").length > 1 do
        throwError "unexpected generated-proof axiom {ax} in {name}"
    count := count + 1
  unless count > 0 do throwError "empty generated-proof audit"
  logInfo m!"STOCK_SCALARPRODUCTION_GENERATED_AXIOMS_PASS {count}"
