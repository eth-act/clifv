from pathlib import Path
import json,hashlib,subprocess,datetime
root=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
records=[]
for manifest,out in [('normal','normal-author'),('native-bytes','native-bytes-repaired-author'),('owned','owned-author'),('full','full-author'),('retained-integration','retained-scalar-integration-author'),('current-keys','current-keys-author')]:
 m=read('/tmp/stock-not-'+manifest+'-manifest.json')
 for g in m['gates']:
  r=read('/tmp/stock-not-'+out+'/'+g['id']+'.json');assert r['state']=='passed' and r['returncode']==0,(g['id'],r)
  assert sha(r['log'])==r['log_sha256'],r['log']
  for p,h in r['outputs'].items():assert sha(p)==h,p
  records.append(r)
for folder in ['/tmp/stock-not-integration-author/not','/tmp/stock-not-retained-scalar-integration-author/scalar']:
 r=read(Path(folder)/'receipt.json');assert r['state']=='passed' and len(r['records'])==32
 assert all(x['returncode']==0 and sha(x['log'])==x['sha256'] for x in r['records'].values())
parity=read('/tmp/stock-not-identity-stage-parity.json');assert all(x['current']==1159 and x['all_original_and_prior_identities_and_ordered_stages_preserved'] for x in parity.values())
# All previous standalone class fixtures and the existing consumer sources are untouched.
changes=subprocess.check_output(['git','diff','--name-only','150738a9',head],cwd=root,text=True).splitlines();existing=[p for p in changes if subprocess.run(['git','cat-file','-e','150738a9:'+p],cwd=root,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0];assert set(existing)=={'FV/Backend/Lowering/StockScalar.lean','FV/Backend/Proof/StockScalarCheck.lean','scripts/check-stock-mixed-integration.py','scripts/check-stock-mixed-native.py'},existing
owned=[r for r in records if r['id'].startswith('owned-')];primary=[r for r in records if not r['id'].startswith('owned-')];native=read('/tmp/stock-not-native-artifacts/native-receipt.json');assert native['state']=='passed' and native['failures']==native['disagreements']==0;assert sha(root/'rust/target/release/clif-native')==native['native_binary_sha256']
receipt={'state':'per_pr_gates_passed','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'validated_source_head':head,'base_main':'150738a95f619380001100ca791fd3cdcb233cdc','primary_gate_count':len(primary),'primary_gate_records':primary,'owned_gate_records':owned,'owned_core_constants':2632,'owned_fixed_witness_constants':673,'exact_declared_native_facts':21,'core_owners':114,'witness_owners':23,'executable_owners':7,'normal_source_files':2685,'normal_library_jobs':2694,'checked_in_audits':47,'audited_roots':1399,'mcp_review':read('/tmp/stock-not-mcp-review.json'),'parity':{'axiom_sets':read('/tmp/stock-not-axiom-parity.json'),'old_headers':read('/tmp/stock-not-header-parity.json')},'identity_stage_parity':parity,'native_execution':native,'earlier_source_equivalence':read('/tmp/stock-not-later-delta-equivalence.json'),'integration_input_equivalence':read('/tmp/stock-not-integration-input-equivalence.json'),'artifact_directory_recovery':read('/tmp/stock-not-artifact-directory-recovery.json'),'existing_sources_modified':existing,'prior_fixture_and_consumer_sources_unchanged':True,'retention_validation':'Current NOT and retained scalar native/CLI/link/generated cohorts cover previous production classes; older standalone fixture helper evidence stays historical at361, not relabelled or redundantly replayed. Full affected runtime/encoder/E2E/examples run fresh.','prior_failures_preserved':True,'full_original_140_complete':False,'verified_examples':{'fv-demo':{'tests':21,'verified_binaries':2},'survey':{'tests':53,'verified_binaries':18}}}
Path('/tmp/stock-not-terminal-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print('passed',len(primary),'primary gates,',len(owned),'ownership partitions')
