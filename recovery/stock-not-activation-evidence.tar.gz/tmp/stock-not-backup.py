from pathlib import Path
import tarfile,json,hashlib,subprocess,os,tempfile,datetime
root=Path('/home/lee/clifv/.worktrees/stock-driver-incremental');out=Path('/tmp/stock-not-activation-backup');out.mkdir(exist_ok=True);archive=out/'evidence.tar.gz';assert not archive.exists()
terminal=Path('/tmp/stock-not-terminal-receipt.json');assert json.loads(terminal.read_text())['state']=='per_pr_gates_passed'
names=['stock-not-affected-build','stock-not-new-test-build','stock-not-repaired-test-build','stock-not-normal-author','stock-not-final-audits','stock-not-native-author','stock-not-native-bytes-author','stock-not-native-bytes-repaired-author','stock-not-native-artifacts','stock-not-owned','stock-not-owned-author','stock-not-integration-author','stock-not-retained-scalar-integration-author','stock-not-full-author','stock-not-current-keys-author','stock-mul-next']
paths=set(p for p in Path('/tmp').glob('stock-not-*') if p.is_file() and p.suffix not in ['.gz','.tar'])
for n in names:
 p=Path('/tmp',n)
 if p.exists():paths.update(x for x in p.rglob('*') if x.is_file() and x.suffix not in ['.olean','.ilean','.pyc'])
# Preserve unique current example reports, proof sources and verification outputs.
for example in ['fv-demo','survey']:
 p=root/'examples'/example/'target'
 for pattern in ['fv-report.json','fv/plain-leanlink-verified-leanld/bin-check/**/*.lean','fv/plain-leanlink-verified-leanld/bin-check/**/report.json']:
  paths.update(x for x in p.glob(pattern) if x.is_file())
with tarfile.open(archive,'w:gz') as t:
 for p in sorted(paths):t.add(p,arcname=str(p).lstrip('/'),recursive=False)
def git(*args,**kw):return subprocess.check_output(['git',*args],cwd=root,**kw).decode().strip()
head=git('rev-parse','HEAD');meta={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_head':head,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size,'files':len(paths),'terminal_receipt_sha256':hashlib.sha256(terminal.read_bytes()).hexdigest(),'preserves_failures':True,'next_mul_drafts_included':True};mp=out/'metadata.json';mp.write_text(json.dumps(meta,indent=2)+'\n')
fd,index=tempfile.mkstemp(prefix='stock-not-backup-index-');os.close(fd);os.unlink(index);env=dict(os.environ,GIT_INDEX_FILE=index)
try:
 git('read-tree',head,env=env)
 for src,dst in [(archive,'recovery/stock-not-activation-evidence.tar.gz'),(mp,'recovery/stock-not-activation-metadata.json')]:
  oid=git('hash-object','-w',str(src));git('update-index','--add','--cacheinfo','100644,'+oid+','+dst,env=env)
 tree=git('write-tree',env=env);commit=git('commit-tree',tree,'-p',head,input=b'Back up NOT activation terminal evidence and next multiplication drafts\n');branch='agent/stock-not-evidence-20261021';git('update-ref','refs/heads/'+branch,commit);git('push','origin',branch);remote=git('ls-remote','origin','refs/heads/'+branch).split()[0];assert remote==commit
 meta.update({'backup_commit':commit,'backup_branch':branch,'remote_verified':True});mp.write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(meta,indent=2))
finally:Path(index).unlink(missing_ok=True)
