from pathlib import Path
p=Path('FV/E2E/StockScalarFixtures.lean');s=p.read_text().replace('StockScalarNIWitness','StockNotNIWitness').replace('stock_scalar_ni','stock_not_ni');s=s.replace('import FV.E2E.StockLogicalFixtures','import FV.E2E.StockScalarFixtures')
s=s.replace('⟨[19],.binary .band ty 1 8⟩]','''⟨[19],.binary .band ty 1 8⟩,
        ⟨[20],.unary .bnot ty 17⟩,⟨[21],.binary .bxor ty 20 2⟩,
        ⟨[22],.unary .bnot ty 21⟩,⟨[23],.binary .iadd ty 22 10⟩,
        ⟨[24],.binary .band ty 23 8⟩,⟨[25],.unary .bnot ty 24⟩,
        ⟨[26],.unary .bnot ty 1⟩]''').replace('term := .ret [17]','term := .ret [25]')
s=s.replace('Two live constants, including multi-word materialization and a shared\nlogical operand; both dead constants and prior pure families, nine parameters,','Plain NOT, NOT-of-XOR and NOT/logical look-through share a complete\nconstant/mixed source body, with dead producers, nine parameters,')
s=s.replace('end E2E.StockNotNIWitness','''/-- Independent reference expression over arbitrary original inputs. -/
def resultValue (config : Configuration) (input : Nat → BitVec (valueType config).width) :
    BitVec (valueType config).width :=
  let constant := BitVec.ofNat (valueType config).width 0x123456789abcdef
  let band := (input 1 + constant) &&& input 8
  let selected := Clif.Sem.select (input 0) ((band ^^^ input 2) ||| constant) band
  let previous := selected - input 2 + BitVec.ofNat (valueType config).width 4097
  let inverted := Clif.Sem.unary .bnot previous
  let xor := inverted ^^^ input 2
  let complemented := Clif.Sem.unary .bnot xor
  Clif.Sem.unary .bnot ((complemented + BitVec.ofNat (valueType config).width 4097) &&& input 8)
end E2E.StockNotNIWitness''');Path('FV/E2E/StockNotFixtures.lean').write_text(s)
s=Path('FV/E2E/StockScalarWitness.lean').read_text().replace('import FV.E2E.StockScalarFixtures','import FV.E2E.StockNotFixtures').replace('StockScalarNIWitness','StockNotNIWitness').replace('Stock.Proof.ConstantBody.Family','Stock.Proof.BnotBody.Family').replace('domain_of_constant','domain_of_bnot').replace('term := .ret [17]','term := .ret [25]')
s=s.replace('⟨[19],.binary .band ty 1 8⟩] at member','''⟨[19],.binary .band ty 1 8⟩,
    ⟨[20],.unary .bnot ty 17⟩,⟨[21],.binary .bxor ty 20 2⟩,
    ⟨[22],.unary .bnot ty 21⟩,⟨[23],.binary .iadd ty 22 10⟩,
    ⟨[24],.binary .band ty 23 8⟩,⟨[25],.unary .bnot ty 24⟩,
    ⟨[26],.unary .bnot ty 1⟩] at member''')
a=s.index('  rcases member with');b=s.index('/-- Actual checked',a)
old=s[a:b];lines=old.splitlines();lines[0]+=' | rfl'*7
for i,line in enumerate(lines[1:],1):
 if line.startswith('  · exact '):lines[i]='  · exact .inl ('+line[len('  · exact '):]+')'
s=s[:a]+'\n'.join(lines)+'''\n  · exact .inr ⟨ty,17,rfl⟩
  · exact .inl (.inl (.inr (.inr ⟨.bxor,ty,20,2,rfl⟩)))
  · exact .inr ⟨ty,21,rfl⟩
  · exact .inl (.inl (.inl ⟨false,ty,22,10,rfl⟩))
  · exact .inl (.inl (.inr (.inr ⟨.band,ty,23,8,rfl⟩)))
  · exact .inr ⟨ty,24,rfl⟩
  · exact .inr ⟨ty,1,rfl⟩

'''+s[b:]
s=s.replace('Clif.runLoop Clif.Env.empty {funcs := []} 12','Clif.runLoop Clif.Env.empty {funcs := []} 19');a=s.index('      .returned [⟨valueType config,',s.index('theorem source_returns'));b=s.index(' := by',a);s=s[:a]+'.returned [⟨valueType config,resultValue config input⟩] Clif.Mem.empty'+s[b:];Path('FV/E2E/StockNotWitness.lean').write_text(s)
s=Path('FVTest/Backend/Lowering/StockScalarProductionRuntime.lean').read_text().replace('StockScalarProduction','StockNotProduction').replace('import FV.E2E.StockScalarFixtures','import FV.E2E.StockNotFixtures').replace('StockScalarNIWitness.function','StockNotNIWitness.function').replace('STOCK_SCALAR_NATIVE_OUT','STOCK_NOT_NATIVE_OUT');s=s.replace('(E2E.StockNotNIWitness.function config).print ++ "\\n" ++','''(E2E.StockNotNIWitness.function config).print ++ "\\n" ++
  ({E2E.StockScalarNIWitness.function config with name := "retained_constant"}).print ++ "\\n" ++''').replace('pf.funcs.length == 8','pf.funcs.length == 9').replace('retained.funcs.length == 8','retained.funcs.length == 9').replace('production.funcs.length == 8','production.funcs.length == 9').replace('Stock.Logical.lowerValidated old','Stock.Scalar.lowerValidated old');Path('FVTest/Backend/Lowering/StockNotProductionRuntime.lean').write_text(s)
s=Path('FVTest/Backend/Lowering/StockScalarProductionLinked.lean').read_text().replace('StockScalarProduction','StockNotProduction').replace('import FV.E2E.StockScalarWitness','import FV.E2E.StockNotWitness').replace('StockScalarNIWitness.function','StockNotNIWitness.function').replace('actual_stock_scalar','actual_stock_not').replace('⟨[20],.binary .iadd','⟨[27],.binary .iadd');Path('FVTest/Backend/Lowering/StockNotProductionLinked.lean').write_text(s)
p=Path('scripts/check-stock-mixed-integration.py');s=p.read_text().replace('["mixed", "logical", "scalar"]','["mixed", "logical", "scalar", "not"]').replace('{"mixed": "Mixed", "logical": "Logical", "scalar": "ScalarProduction"}','{"mixed": "Mixed", "logical": "Logical", "scalar": "ScalarProduction", "not": "NotProduction"}').replace('options.kind == "scalar"','options.kind in ("scalar", "not")');p.write_text(s)
p=Path('scripts/check-stock-mixed-native.py');s=p.read_text().replace('["mixed", "logical", "scalar"]','["mixed", "logical", "scalar", "not"]').replace('if kind == "scalar":','if kind in ("scalar", "not"):');s=s.replace('cases.append(("stock_scalar_ni", args, signed(chosen - args[2] + 4097, bits)))','''previous = signed(chosen - args[2] + 4097, bits)
            if kind == "not":
                inverted = (~previous) & mask
                complemented = (~(inverted ^ (args[2] & mask))) & mask
                result = ~((complemented + 4097) & args[8])
                cases.append(("stock_not_ni", args, signed(result, bits)))
                cases.append(("retained_constant", args, previous))
            else:
                cases.append(("stock_scalar_ni", args, previous))''');p.write_text(s)
