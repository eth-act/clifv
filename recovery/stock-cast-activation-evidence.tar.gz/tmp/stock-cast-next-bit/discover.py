import os,subprocess
from pathlib import Path
folder=Path('/tmp/stock-cast-next-bit')
env=dict(os.environ);env['LEAN_PATH']=env.get('LEAN_PATH','')+':'+str(folder)
r=subprocess.run(['lean','--root='+str(folder),str(folder/'Discover.lean')],env=env,text=True,capture_output=True)
(folder/'discovery.log').write_text(r.stdout+r.stderr);print(r.stdout+r.stderr);raise SystemExit(r.returncode)
