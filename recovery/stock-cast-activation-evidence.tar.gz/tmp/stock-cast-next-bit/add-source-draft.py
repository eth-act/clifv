from pathlib import Path
p=Path('/tmp/stock-cast-next-bit/StockBitFamily.lean');s=p.read_text().replace('import FV.Backend.Proof.StockCastNotrap','import FV.Backend.Proof.StockUnaryDispatch\nimport FV.Backend.Proof.StockCastNotrap',1)
t=Path('FV/Backend/Proof/StockCastCompleteSourceTransfer.lean').read_text();a=t.index('theorem extend_source ');b=t.index(' := by',a);header=t[a:b]
param='(family : ∀ b ∈ f.blocks,∀ stm ∈ b.body,CastBody.Family stm.inst) (sg : Bool)'
u=header.replace('theorem extend_source ','theorem unary_source ').replace(param,'{op : Clif.UnaryOp} (unary : Unary op)').replace('.extend (ScalarCast.extendOp sg) ty x','.unary op ty x')
body=' := by\n  rcases unary with rfl | rfl | rfl | rfl | rfl\n'
for fn,flag in [('stock_lower_neg_source_by_instruction',''),('ScalarCount.stock_lower_count_source_by_instruction','false '),('ScalarCount.stock_lower_count_source_by_instruction','true '),('stock_lower_bitrev_source_by_instruction',''),('stock_lower_bswap_source_by_instruction','')]:
 body+='  · obtain ⟨u,d,ρ\',getX,output,bounds,execution,value,unchanged,kept,post⟩ :=\n      '+fn+' run scope dominated '+flag+'events records block statement current\n        source clif results statementResults mapped recorded emitted refines '+('dfg ' if flag else '')+'held sourceStep\n    exact ⟨ρ\',execution,unchanged,post⟩\n'
r=header.replace('theorem extend_source ','theorem rotate_source ').replace(param,'(left : Bool)').replace('{x z a : Nat}','{x y z a : Nat}').replace('.extend (ScalarCast.extendOp sg) ty x','.binary (ScalarRotate.rotateOp left) ty x y')
r+=''' := by
  obtain ⟨u,amount,d,ρ',getX,getY,output,bounds,execution,value,unchanged,kept,post⟩ :=
    ScalarRotate.stock_lower_rotate_source_by_instruction run scope dominated left events records
      block statement current source clif results statementResults mapped recorded emitted refines dfg held sourceStep
  exact ⟨ρ',execution,unchanged,post⟩
'''
s=s.replace('end Backend.Stock.Proof.BitBody\n',u+body+'\n'+r+'\nend Backend.Stock.Proof.BitBody\n');p.write_text(s)
