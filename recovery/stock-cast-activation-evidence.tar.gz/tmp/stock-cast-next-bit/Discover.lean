import StockBitFixtures
import ABIReadBitSteps
open Backend Backend.Stock.D0

def observe (config : Configuration) : Except String (List (String × Nat) × Bool) := do
  let result ← Stock.lower (E2E.StockBitNIWitness.function config)
  let records := result.blockScans.toList.flatMap fun (event : Stock.BlockScanEvent) =>
    event.output.records.filterMap fun (record : Stock.ScanRecord) => do
      let info ← event.ctx.insts[record.inst]?
      let inst ← info.clif
      let key ← match inst with
        | .unary op .. => if [.ineg,.clz,.ctz,.bitrev,.bswap].contains op then some (reprStr op) else none
        | .binary op .. => if [.rotl,.rotr].contains op then some (reprStr op) else none
        | _ => none
      let step ← record.output.step
      let root ← step.rules.getLast?
      some (key,root)
  let abi := result.code.blocks.toList.zipIdx.all fun (block,b) =>
    block.insts.toList.zipIdx.all fun (inst,k) =>
      Backend.ABIReadScalar.instruction (E2E.StockBitNIWitness.function config).sig b k inst ||
        Backend.ABIReadScalar.bitProducer inst
  pure (records,abi)
#eval configurations.map fun config => (reprStr config,observe config)
