from pathlib import Path
import ast,types,json
p=Path('scripts/check-stock-mixed-native.py');old=p.read_text();s=old.replace('"shift", "cast")','"shift", "cast", "bit")').replace('"shift", "cast"], default','"shift", "cast", "bit"], default').replace('if kind == "cast":','if kind in ("cast", "bit"):')
s=s.replace('                            cases.append(("stock_cast_ni", args, cast_result))','''                            if kind == "bit":
                                negated = (-args[1]) & mask
                                reversed_bits = int(f"{negated:0{bits}b}"[::-1], 2)
                                swapped = int.from_bytes(reversed_bits.to_bytes(bits // 8, "little"), "big")
                                def rol(value, amount):
                                    amount %= bits
                                    return ((value << amount) | (value >> ((bits - amount) % bits))) & mask
                                def ror(value, amount):
                                    return rol(value, -amount)
                                rotated = ror(rol(swapped, args[2] & mask), args[1] & mask)
                                immediate = ror(rol(rotated, 0x105), 0x103)
                                leading = bits - (args[1] & mask).bit_length()
                                x = args[2] & mask
                                trailing = bits if x == 0 else (x & -x).bit_length() - 1
                                bit_result = signed(immediate ^ leading ^ trailing ^ cast_result, bits)
                                cases.append(("stock_bit_ni", args, bit_result))
                                cases.append(("retained_cast", args, cast_result))
                            else:
                                cases.append(("stock_cast_ni", args, cast_result))''')
s=s.replace('    cases = []\n', '    if kind == "bit":\n        vectors.append([1, 1, 0, 11, 22, 33, 44, 55, 7])  # observable CTZ(0)\n    cases = []\n', 1)
s=s.replace('        if options.kind == "cast":','''        if options.kind == "bit":
            wanted = (wanted - {"stock_mixed_ni"}) | {"stock_bit_ni", "retained_cast", "retained_shift", "retained_mul", "retained_not", "retained_constant", "retained_logical", "retained_mixed"}
        elif options.kind == "cast":''')
out=Path('/tmp/stock-cast-next-bit/check-stock-mixed-native.py');out.write_text(s)
mods=[]
for src in [old,s]:
 tree=ast.parse(src);tree.body=[x for x in tree.body if isinstance(x,(ast.FunctionDef,ast.Import,ast.ImportFrom))];m=types.ModuleType('helper');exec(compile(tree,'native-grid','exec'),m.__dict__);mods.append(m)
checks={}
for kind in ['mixed','logical','scalar','not','mul','shift','cast']:
 for bits in [32,64]:
  a,b=(m.run_commands(bits,kind) for m in mods);assert a==b;checks[kind+'-'+str(bits)]=len(a)
checks['bit']={str(bits):len(mods[1].run_commands(bits,'bit')) for bits in [32,64]}
Path('/tmp/stock-cast-next-bit/native-grid-retention.json').write_text(json.dumps(checks,indent=2)+'\n');print(checks)
