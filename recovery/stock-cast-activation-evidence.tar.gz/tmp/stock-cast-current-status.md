# Stock driver completion (#140)

State: active. Full original #140 remains unfinished. Owner @codygunton and this agent.
Updated UTC: 2026-10-21T22:41:49.212732+00:00

## Current delivery

Branch agent/stock-cast-activation-20261021, checkpoint845327d4 (pushed; implementationd4303010), based current main4966cf92. Active view /home/lee/clifv/.worktrees/stock-driver-incremental; original dirty driver-proof-resume preserved untouched.

PR364 landed at4966cf92: complete shifts/fused bitfields, all18primary/13ownership gates, exact prior axioms/headers/identities/stages and native/CLI/link/generated evidence. Terminal evidence de6aae6e retained remotely; integrator notified140/261.

Current cast class implemented: actual808/819/946 base selection; source-derived exclusions for810/811/815/824; guarded original-source/retained-result/body/entry-return/no-trap proofs; production classifier and soundness; valid extension ABI transport; complete six-ABI/two-cleanup arbitrary-input witnesses including live high sign bits, all3actualbase roots. These modules and witnesses compile. Old selectors, theorem variants, cleanup whitelist and consumer contracts retained. Earlier native vector grids are byte-for-byte unchanged as Python values.

Next: normal-key consumer rebuild/trust and exact parity audits, real allocator/runtime/native, actual CLI/link/generated proofs, retained classes/artifacts and full corpus/identity/stage/examples. Source and HEAD frozen for author gates. Not yet approved for merge; full original140 remains unfinished, including later scalar/control/memory/effects/calls/whole-driver simulation/completeness. Fallback is not Stock-only completeness.

Likely modules: StockCast* / StockScalarCastDomain, shared Scalar classifier/check, ABIReadCastSteps/ABIReadScalar and complete fixtures/audits. No shared Arm/MInst/allocator edits. Contributor statuses52/71 and task140 reread; no concrete overlap. Next after this class: remaining pure scalar families, then every unchanged original140 obligation.

## Preservation/resources

Canonical saved dirty driver-proof-resume1874paths remains untouched/backed29f6be2f; prior class receipts and terminal archives remain. Four necessary worktrees, one warm cache,741GiBfree, max16GiB aggregate/max2jobs. No additional worktrees/caches or other-project cleanup. Remove expendable generated artifacts only after archive. No healthy kernel kills.

Added38cast audit roots for the complete source/ABI/witness packet. Normal consumer rebuild active (92affected modules). UTC:2026-10-21T22:42:47.147949+00:00

Audit scope limited to new delivery roots; existing cast bridge/witness audits stay in their original files. All43oldpublicheaders exact. UTC:2026-10-21T22:43:38.183071+00:00

Validation batch passed:2739scheduledmodules (61rebuilt), normal library keys and4tools,50trustaudits/1506roots;all1470prior requiredAXsets/43oldpublicheaders exact. One bundled domain_of_cast review Std3/no warnings; completed owned LSP server3951864 released. Real runtime/native and15ownership partitions active. Main remains4966cf92. UTC:2026-10-21T22:47:07.405797+00:00

Runtime/native and15ownership partitions passed:24objects/1680nativecomparisons/420Craneliftreferenceexecutions;0failures/disagreements;149core/26witness/14executable owners,27exactfixednativefacts(previous25+2). Actualcast+retainedshift CLI/link/generated cohorts and fullcorpus/identity/stage/examples active before merge. Source/HEAD frozen. UTC:2026-10-21T22:48:29.738861+00:00

Full current batch passed:1579cratekeys;runtime4737/0(same7knownnon-runnable),encoder1321identical/0different;bothE2Emodes1159accepted/0rejected with original1150/prior1159identities and orderedstages exact;fv-demo21tests/2verifiedbinaries,survey53tests/18verifiedbinaries. Originalflat-multiply inputs/ELFs/proof sources retainedbyte-exact;currentregeneratedproofsbothmodespassed. Cast linkedfixture passed all14program/checker/ELF/history/stack/proof-emission cases,including33-function/entryslices; actual generated proof compilation and retainedshift cohort remain. UTC:2026-10-21T22:53:47.068852+00:00

Currentcast cohort passed32/32actualCLI/link/generatedproofchecks;retainedshift cohort active. External next-class drafts compile:bit-family purity/quiet/single/source-format exclusion/no-trap and ABI bit/EXTR framing. These are not production activation and do not alter frozen sources. Located StockUnaryDispatch existing selected_neg/bitrev/bswap rules and original-source-by-instruction wrappers: reuse these instead of redoing dispatch. UTC:2026-10-21T22:59:36.496208+00:00

Externalnext7-opclass source/ABI/no-trap/fixture drafts compiled; actualStock.lower discovery selects9newroots/config inall6ABIs and everyinstruction passes oldABI-or-newbitproducer. Not counted as production activation or author gate evidence. Retainedshift generated33-function proofs continue healthy; cast32/32/full/retention already passed. UTC:2026-10-21T23:06:28.166575+00:00
