Route i32/i64 popcount through the default Stock scalar compiler, checker, linker and generated-proof consumers. Reuse the existing complete original-source transfer, then compose body/entry/return/no-trap correctness and extend ABI framing for the exact FMOV/CNT/ADDP/ADDV/UMOV producers.

Old theorem variants, source conditions, selectors, required axioms, accepted identities and successful stages remain. Complete mixed witnesses keep all prior computation live across six ABI configurations, both cleanup modes, arbitrary source inputs and the original slot. Existing four-width zero/nonzero/alias/dirty-upper-bit witnesses are reused. Stronger alternate drafts are separately backed at e2f15642; this delivery contains the required activation only.

Validation on `1369656323f4c5f8a121021a93298a6517b8b2a0`:

- 2,763 normal keys, four tools, current crate keys; 52 audits / 1,571 roots; all 1,541 prior axiom sets and 29 old public headers exact. One bundled MCP review: standard axioms only, no warnings.
- 3,747 standard-only core / 893 fixed witness constants, 19 ownership partitions, exactly 31 permitted native facts.
- 24 objects / 2,256 native comparisons / 564 Cranelift references, zero failures or disagreements; real-oracle/missing-binary/whole-attempt retry controls and all eight prior native grids retained.
- Current popcount and retained bit actual CLI/link/generated cohorts 32/32 each, original flat-multiply bytes/sources retained with current proofs, runtime 4,737/0, encoder 1,321/0, both E2E modes 1,159/0 with original/prior identity and ordered-stage parity. Verified demo 21 tests / 2 binaries; survey 53 tests / 18 binaries.

Permanent receipt: `docs/research/stock-popcount-production-activation.md` and JSON. Remote terminal evidence `6e9e92da938cf056332b203599dbb823030b9191`. Early failed drafts/checker records remain archived and are not counted as passed.

Continues #140. Universal successful lowering/downstream completeness, remaining classes, widths/ABIs, effects/control/memory/traps/calls and whole-driver closure remain open; fallback is not Stock completeness. #44 has current status.
