from pathlib import Path
import json
r=json.loads(Path('/tmp/stock-cmp-terminal-receipt.json').read_text());b=json.loads(Path('/tmp/stock-cmp-activation-backup/metadata.json').read_text())
body=f"""Default shared Scalar consumers now handle mixed i32/i64 integer comparisons and actual zero-extension-of-comparison root811, alongside every earlier class. The real retained comparison and cast records are proved from original source conditions through matching, operand requests, result binding/final aliases, guarded source transfer, scan/body/ABI entry/return and existing compiler/checker/linker/generated-proof consumers.

Existing comparison numerical/helper proofs are reused. Actual final-CSET normalization establishes full zero-extension while preserving the older low-byte variants. New memory-only cast variants permit IntCompare look-through; every old theorem variant and selector remains. Precise virtual CSET ABI framing uses the existing machine semantics. No Arm/MInst/allocator or cleanup-rule edits.

Validation on `{r['validated_source_head']}` reconciled with main `{r['base_main']}`:

- 22 primary /23 ownership gates;{r['normal_library_jobs']} normal library keys;55 audits/1651 roots;1601 old required axiom sets/35 old public headers exact. All{r['owned_core_constants']} owned core constants use standard axioms;35 exact fixed witness native facts.
- Complete all-ABI/cleanup witnesses with arbitrary inputs/slot and actual roots811/819/958.24 emitted objects/2640 QEMU comparisons/660 Cranelift references,0 failures or disagreements;ten prior native grids unchanged.
- Current comparison and retained min/max actual CLI/link/generated-proof cohorts each32/32;original flat-multiply bytes/sources retained with current proofs. One bundled MCP review:standard axioms/no warnings.
- Runtime4737/0/0 with the same7 known non-runnable cases;encoder1321 identical/0 differ;both E2E modes1159 accepted/0 rejected,original1150 and prior1159 identities/ordered stages exact;verified demo21 tests/2 binaries,survey53 tests/18 binaries.

Receipt: docs/research/stock-cmp-production-activation.md and JSON. Terminal evidence remotely backed at `{b['backup_commit']}` (archive SHA256`{b['archive_sha256']}`). Failed drafts are preserved and not counted as passes.

Successful Stock.lower remains a correctness premise;Stock-only request/lowering/downstream completeness is still open. Full original #140, remaining widths/ABIs/control/memory/traps/effects/calls/source/block/whole-driver obligations remain active. Legacy fallback is not completeness. Next production packet:high multiplication, reusing existing complete source wrappers.

Refs #140,#44.
"""
Path('/tmp/stock-cmp-pr-body.md').write_text(body)
